#!/usr/bin/env python3
"""Born--Hopf Planck-curvature / observable Newton response audit v1_4.

Strictly scoped mathematical and numerical checks. This tool does NOT prove that
an actual physical joint-action projection, baryonic state, or cosmological
history has been constructed. Earlier v1_2 checks are preserved and extended.

Read together with Paper00-PlanckCurvatureConsistency-v1_4.md.
"""
from math import pi, sqrt, exp, log, isclose
import mpmath as mp
from fractions import Fraction

mp.mp.dps = 190
P = mp.pi
A = 4*P**2 + 1/(6*mp.sqrt(2))
alpha = mp.exp(A)
Q = 8*mp.sqrt(alpha)
q = mp.exp(-7*A)  # C/U
B = q/(1+q)      # C/(U+C)

def n7_at_scaled(t):
    # q_R = ln(U/R)/ln(alpha) = 7-ln(t)/A, R=t*C
    qr = 7-mp.log(t)/A
    return (mp.log(mp.cosh(7*A/2))-
            mp.log(mp.cosh((mp.mpf('3.5')-qr)*A)))/(qr*A)

def kernel(t):
    return (1+n7_at_scaled(t))*(1-t**(-2))

def I(t):
    return mp.quad(lambda v: (2*v-t)*kernel(v), [1,t])

# D_2=1 precisely on the near-terminal 1 < R/C <= 3 sector (Paper III-F).
y = B*I(mp.mpf(2))
for _ in range(4):
    y = B*I(2+y)
residual = -y + B*I(2+y)
lower = (2-2*mp.log(2))*q/(1+5*q)
upper = 2*q/(1-5*q)
n_2 = n7_at_scaled(mp.mpf(2))
m2_over_U_leading = 4*(1+q)/(9*(1+n_2))
Hrat = mp.sqrt(1+y/2)

# Exact scalaron stationary-root local quantities from the same active f(R).
tstar = 2+y
Fstar_minus_1 = B*mp.quad(kernel, [1,tstar])
Fstar = 1+Fstar_minus_1
chi_times_U = (1+n7_at_scaled(tstar))*(1-tstar**(-2))/(1+q)
m2_over_U = (Fstar-tstar*q*chi_times_U)/(3*chi_times_U)
scalaron_range_over_lscal = mp.sqrt(2*P)/mp.sqrt(m2_over_U)

# Canonical source and action coefficient, natural units: S_g=a integral sqrt(-g) R.
U = mp.mpf(1)
a_scal = U/8
a_joint = 12*U
s = mp.mpf(1)/96
b_scal = mp.mpf(1)
b_joint = mp.mpf(1)
response_scal_unormalized = b_scal/(2*a_scal)
response_raw_unormalized = b_joint/(2*a_joint)
response_uniform_unormalized = (s*b_joint)/(2*s*a_joint)
response_grav_only_unormalized = b_joint/(2*s*a_joint)

# Physical 1/r Newton coefficient for canonical source energy: G_N=1/(16 pi a).
GN_scal = 1/(16*P*a_scal)
GN_raw = 1/(16*P*a_joint)
GN_rescaled = 1/(16*P*(s*a_joint))

# Explicit quadratic toy Dirac source: b times psi^2 with canonical amplitude
# psi_c=sqrt(b)*psi; coefficient b cancels for a fixed canonical source.
def canonical_stress(b, psi_can=mp.mpf(1)):
    psi_coordinate=psi_can/mp.sqrt(b)
    return b*psi_coordinate**2

# Uniform-density compact sphere: solve Poisson by radial Gauss flux, independently
# of the point-source potential convention. At r>R, r^2 Phi'(r)=M/(16*pi*a).
Msource=mp.mpf('1.7')
Rsource=mp.mpf('0.8')
rtest=mp.mpf('7')
rho_uniform=3*Msource/(4*P*Rsource**3)
flux_raw=(1/(4*a_joint))*mp.quad(lambda rr:rho_uniform*rr**2,[0,Rsource])
flux_scal=(1/(4*a_scal))*mp.quad(lambda rr:rho_uniform*rr**2,[0,Rsource])

# Unscreend metric-f(R) local response, with canonically normalized source.
def yukawa_amp(x):
    return 1+(1+x)*mp.exp(-x)/3

def raw_scalar_ratio(x):
    return yukawa_amp(x)/(96*Fstar)


# VI-B's native static RAR kernel (when the same owner-law and same a0 are
# conditionally retained): nu(y)=1/[1-exp(-sqrt(y))]. With a canonical fixed
# baryon mass and the raw Newton input g_b->g_b/96 at the same structural U,
# the ratio of the raw and scalar RAR predictions is bounded by 1/96..1/sqrt96.
def rar_raw_scalar_ratio(y):
    t=mp.sqrt(y)
    return (1-mp.exp(-t))/(96*(1-mp.exp(-t/mp.sqrt(96))))


# Controlled metrology comparison: fix one measured Gobs, but choose either
# scalar or raw Einstein coefficient as its physical owner. The matched
# curvature U_raw(Gobs)=U_scal(Gobs)/96.
c = mp.mpf(299792458)
Gobs = mp.mpf('6.67430e-11')
hbar = mp.mpf('1.054571817e-34')
parsec = mp.mpf('3.085677581491367e16')
H100 = mp.mpf(100000)/(10**6*parsec)
U_scal_obs = c**3/(2*P*hbar*Gobs)
U_raw_obs = c**3/(192*P*hbar*Gobs)
C_scal = U_scal_obs*q
C_raw = U_raw_obs*q
Lam_scal=C_scal/2
Lam_raw=C_raw/2
a0_scal=c**2*mp.sqrt(C_scal)/(4*P)
a0_raw=c**2*mp.sqrt(C_raw)/(4*P)
H_scal=c*mp.sqrt(C_scal/6)
H_raw=c*mp.sqrt(C_raw/6)
om_scal=Lam_scal*c**2/(3*H100**2)
om_raw=Lam_raw*c**2/(3*H100**2)
r0=2*mp.exp(-mp.mpf('1.5'))
N=mp.mpf(56)
As_uv_scalar=N**2/(36*P**2*Q)
As_uv_raw=As_uv_scalar/96

old_checks = {
    'U_scalar_EH': mp.almosteq(a_scal,U/8),
    'joint_coefficient_ratio_96': mp.almosteq(a_joint/a_scal,96),
    'global_scaling_selects_EH_scalar_coefficient': mp.almosteq(s*a_joint,a_scal),
    'global_scaling_changes_canonical_gauge_gsq_x96': mp.almosteq(1/s,96),
    'no_s_preserving_gsq_and_matching_EH': s!=1,
    'source_response_scalar_is_4_over_U': mp.almosteq(response_scal_unormalized,4/U),
    'source_response_raw_is_scalar_over_96': mp.almosteq(response_raw_unormalized,response_scal_unormalized/96),
    'uniform_full_action_scaling_invariant_tree_response': mp.almosteq(response_uniform_unormalized,response_raw_unormalized),
    'gravity_only_rescaling_changes_response': mp.almosteq(response_grav_only_unormalized,response_scal_unormalized),
    'n7_2C_reproduced': abs(n_2-mp.mpf('0.0025070360984245'))<mp.mpf('1e-15'),
    'C_over_U': abs(q-mp.mpf('4.216119310922e-121'))/q<mp.mpf('1e-12'),
    'I_integral_positive': I(2)>0,
    'terminal_T_C_positive': (2-1)>0,
    'terminal_T_0_positive': (2-0)>0,
    'active_T_2C_positive': B*I(2)>0,
    'active_T_3C_negative': (-1+B*I(3))<0,
    'root_inside_source_bound': lower<=y<=upper,
    'root_above_2C': y>0,
    'root_below_3C': y<1,
    'root_equation_small_residual': abs(residual)<mp.mpf('1e-170'),
    'active_vacuum_frac_shift_tiny': y<mp.mpf('1e-119'),
    'terminal_dust_trace_off_domain': 2*q+4*(q/4)>q,
    'terminal_radiation_trace_off_domain': 2*q>q,
    'terminal_stiff_source_on_domain_control': 2*q-4*(2*(q/4))<=q,
    'terminal_domain_requires_positive_trace': (2*q-4*(q/8)>q) and (2*q-4*(q/4)<=q),
    'm_scalaron_positive': m2_over_U_leading>0,
    'scalon_mass_ratio_source': abs(m2_over_U_leading-mp.mpf('0.44333'))<mp.mpf('3e-5'),
    'active_deSitter_H_correction': mp.almosteq(Hrat**2,1+y/2),
    'active_deSitter_ratio_correction': mp.almosteq(1/Hrat,mp.sqrt(2/(2+y))),
    'conditional_uv_As_scalar_reasonable': abs(As_uv_scalar/mp.mpf('2.7826802983093e-9')-1)<mp.mpf('1e-12'),
    'conditional_uv_As_changes_over96_raw': mp.almosteq(As_uv_raw*96,As_uv_scalar),
}

new_checks = {
    'canonical_fermion_b1': mp.almosteq(canonical_stress(1),1),
    'canonical_fermion_b96': mp.almosteq(canonical_stress(96),1),
    'canonical_fermion_b_one_over_96': mp.almosteq(canonical_stress(s),1),
    'canonical_G_scal_standard': mp.almosteq(GN_scal,1/(2*P*U)),
    'canonical_G_joint_is_96_weaker': mp.almosteq(GN_raw/GN_scal,mp.mpf(1)/96),
    'canonical_G_after_common_rescaling_changes': mp.almosteq(GN_rescaled/GN_raw,96),
    'coordinate_stress_uniform_rescale_still_invariant': mp.almosteq(response_uniform_unormalized,response_raw_unormalized),
    'canonical_vs_coordinate_reference_is_different': not mp.almosteq(GN_rescaled,GN_raw),
    'radial_Poisson_flux_matches_scalar_point': mp.almosteq(flux_scal,Msource*GN_scal),
    'radial_Poisson_flux_matches_joint_point': mp.almosteq(flux_raw,Msource*GN_raw),
    'active_Fstar_above_one': Fstar_minus_1>0,
    'active_Fstar_small': Fstar_minus_1<mp.mpf('1e-119'),
    'active_fRR_positive': chi_times_U>0,
    'active_m2_exact_positive': m2_over_U>0,
    'active_m2_leading_agreement': abs(m2_over_U/m2_over_U_leading-1)<mp.mpf('1e-118'),
    'Yukawa_mass_range_Planckian': 3<scalaron_range_over_lscal<5,
    'Yukawa_local_max_bounded_four_thirds': all(yukawa_amp(mp.mpf(x))<=mp.mpf(4)/3 for x in ['0','0.01','0.1','1','10','100']),
    'Yukawa_monotone_sample': all(yukawa_amp(mp.mpf(x))>=yukawa_amp(mp.mpf(y)) for x,y in [('0','1'),('1','2'),('2','3'),('3','20')]),
    'raw_Yukawa_max_less_than_1_over_72': raw_scalar_ratio(0)<mp.mpf(1)/72,
    'raw_Yukawa_large_r_near_1_over_96': abs(raw_scalar_ratio(100)-1/(96*Fstar))<mp.mpf('1e-40'),
    'raw_Yukawa_no_96_recovery': all(raw_scalar_ratio(mp.mpf(x))<1 for x in ['0','0.1','1','10','100']),
    'RAR_raw_to_scalar_ratio_lower_bound': all(rar_raw_scalar_ratio(mp.mpf(y))>=mp.mpf(1)/96 for y in ['1e-20','1e-7','0.1','1','100','1e5']),
    'RAR_raw_to_scalar_ratio_upper_bound': all(rar_raw_scalar_ratio(mp.mpf(y))<=1/mp.sqrt(96) for y in ['1e-20','1e-7','0.1','1','100','1e5']),
    'RAR_raw_to_scalar_ratio_deep_asymptotic': abs(rar_raw_scalar_ratio(mp.mpf('1e-36'))*mp.sqrt(96)-1)<mp.mpf('1e-15'),
    'RAR_raw_to_scalar_ratio_high_asymptotic': abs(rar_raw_scalar_ratio(mp.mpf('1e6'))*96-1)<mp.mpf('1e-40'),
    'RAR_cannot_restore_scalar_Newton_normalization': all(rar_raw_scalar_ratio(mp.mpf(y))<1 for y in ['1e-20','1','100','1e5']),
    'raw_G_observation_requires_U_over96': mp.almosteq(U_raw_obs*96,U_scal_obs),
    'physical_lP_inverse_square_raw_192piU': mp.almosteq(c**3/(hbar*Gobs),192*P*U_raw_obs),
    'physical_lP_inverse_square_scalar_2piU': mp.almosteq(c**3/(hbar*Gobs),2*P*U_scal_obs),
    'C_scales_inverse_96': mp.almosteq(C_raw/C_scal,mp.mpf(1)/96),
    'lambda_scales_inverse_96': mp.almosteq(Lam_raw/Lam_scal,mp.mpf(1)/96),
    'RAR_acceleration_scales_inverse_sqrt96': mp.almosteq(a0_raw/a0_scal,1/mp.sqrt(96)),
    'vacuum_H_scales_inverse_sqrt96': mp.almosteq(H_raw/H_scal,1/mp.sqrt(96)),
    'density_omega_scales_inverse96': mp.almosteq(om_raw/om_scal,mp.mpf(1)/96),
    'matter_density_dhalf_scales_inverse96': mp.almosteq((r0*om_raw)/(r0*om_scal),mp.mpf(1)/96),
    'RAR_Hubble_dimensionless_ratio_identical': mp.almosteq(a0_scal/(c*H_scal),a0_raw/(c*H_raw)),
    'inflationUV_amplitude_uses_canonical_EH_normalization': mp.almosteq(As_uv_raw/As_uv_scalar,mp.mpf(1)/96),
    # A multiplication of a vacuum metric f(R) action by a positive a
    # multiplies its E-L equation but cannot change the set of zeros.
    'active_root_normalization_independent': abs(96*residual)<mp.mpf('1e-168') and abs(residual)<mp.mpf('1e-170'),
}


# v1.4: independent finite 192-dimensional primitive-owner retraction checks.
# Concrete weak-generator model: 12 spin-1/2 SU(2) doublets (24 states),
# remaining 24 states weak singlets, arranged 6+6 across the internal grading.
# It reproduces the trace-index facts Tr_F((T_2^3)^2)=6 from Paper V-A.
import numpy as np
Sdim, Fdim = 4, 48
chirality = np.diag([1.,1.,-1.,-1.])
internal_grading = np.diag([1.]*24+[-1.]*24)
Gamma = np.kron(chirality,internal_grading)
Pplus=(np.eye(192)+Gamma)/2
Zret=Pplus/48

weak_T3_diag=np.zeros(48)
for offset in (0,24):
    for j in range(6):
        weak_T3_diag[offset+2*j]=.5
        weak_T3_diag[offset+2*j+1]=-.5
weak_T3=np.diag(weak_T3_diag)
weak_Q = np.kron(np.eye(4), weak_T3@weak_T3)
raw_weak_weight=np.trace(weak_Q)
ret_weak_weight=np.trace(Zret@weak_Q)
# Any positive semidefinite Z of trace 2 satisfies Tr(Z Q) <= 2||Q||.
weak_operator_norm = np.linalg.norm(weak_Q,ord=2)
gauge_general_upper = 2*weak_operator_norm

spin_Q=np.array([[2.,1.,0.,0.],[1.,3.,0.,0.],
                 [0.,0.,5.,0.],[0.,0.,0.,7.]])
metric_Q=np.kron(spin_Q,np.eye(48))

# Invertible metric-field-coordinate map h_phys = sqrt(96) h_raw.
# The kinetic coefficient appears reduced but source is reduced too;
# the normalized source-to-source exchange (and hence the force) is invariant.
kinetic_raw = mp.mpf(12)
source_raw = mp.mpf(1)
field_scale = mp.sqrt(96)
kinetic_new=kinetic_raw/field_scale**2
source_new=source_raw/field_scale
exchange_raw=source_raw**2/kinetic_raw
exchange_new=source_new**2/kinetic_new

# Gapped Schur sector: B(k)=beta k^2, C(k)=m^2+gamma k^2.
# No such analytic Schur correction changes the residue of the k^2 pole.
beta=mp.mpf(11)
msq=mp.mpf(3)
gamma=mp.mpf(7)
def k_reduced(k):
    return 12*k*k - beta**2*k**4/(msq+gamma*k*k)

v14_checks={
    'primitive_192_spin_internal_dimension': Sdim*Fdim==192,
    'relative_grading_involution': np.array_equal(Gamma@Gamma,np.eye(192)),
    'relative_grading_trace_zero': np.trace(Gamma)==0,
    'retained_projector_is_projector': np.array_equal(Pplus@Pplus,Pplus),
    'retained_projector_rank_96': np.linalg.matrix_rank(Pplus)==96,
    'primitive_retraction_trace_two': np.isclose(np.trace(Zret),2,rtol=0,atol=1e-14),
    'pure_metric_trace_ratio_1_over_96': np.isclose(np.trace(Zret@metric_Q)/np.trace(metric_Q),1/96,rtol=0,atol=1e-15),
    'pure_metric_retraction_equals_half_spin_trace': np.isclose(np.trace(Zret@metric_Q), np.trace(spin_Q)/2),
    'weak_generator_tr_F_index_6': np.trace(weak_T3@weak_T3)==6,
    'weak_generator_squared_norm_quarter': weak_operator_norm==.25,
    'raw_weak_generator_trace_24': raw_weak_weight==24,
    'retained_weak_generator_trace_quarter': ret_weak_weight==.25,
    'retained_parity_even_gauge_ratio_1_over_96': ret_weak_weight/raw_weak_weight==1/96,
    'retained_gauge_coupling_square_grows_x96': raw_weak_weight/ret_weak_weight==96,
    'positive_trace_two_general_weak_bound_half': gauge_general_upper==.5,
    'positive_trace_two_cannot_retain_raw_gauge': gauge_general_upper<raw_weak_weight,
    'strongest_positive_trace_two_gauge_weight_ratio_at_most_1_over_48': gauge_general_upper/raw_weak_weight==1/48,
    'field_redefinition_apparent_EH_ratio_1_over_96': mp.almosteq(kinetic_new,mp.mpf(1)/8),
    'field_redefinition_source_vertex_reduced': mp.almosteq(source_new,1/mp.sqrt(96)),
    'field_redefinition_exchange_invariant': mp.almosteq(exchange_new,exchange_raw),
    'gapped_schur_pole_coefficient_kept': all(abs(k_reduced(mp.mpf(k))/(mp.mpf(k)**2)-12)<mp.mpf('1e-10') for k in ['1e-6','1e-8','1e-12']),
    'gapped_schur_correction_order_k4': all(abs((12*mp.mpf(k)**2-k_reduced(mp.mpf(k)))/mp.mpf(k)**4-beta**2/msq)<mp.mpf('1e-8') for k in ['1e-6','1e-8','1e-12']),
}

checks={**old_checks,**new_checks,**v14_checks}
for key,passed in checks.items():
    print(('PASS ' if passed else 'FAIL ')+key)
print('OLD CHECKS:',sum(old_checks.values()),'/',len(old_checks))
print('NEW CHECKS:',sum(new_checks.values()),'/',len(new_checks))
print('V1.4 CHECKS:',sum(v14_checks.values()),'/',len(v14_checks))
print('TOTAL CHECKS:',sum(checks.values()),'/',len(checks))
assert all(checks.values()),'At least one scoped check failed'

print('C/U =',mp.nstr(q,24))
print('(R*-2C)/C =',mp.nstr(y,25))
print('Fstar-1 =',mp.nstr(Fstar_minus_1,25))
print('fRRstar * U =',mp.nstr(chi_times_U,22))
print('mstar^2 / U =',mp.nstr(m2_over_U,22))
print('Yukawa range / l_scal =',mp.nstr(scalaron_range_over_lscal,22))
print('G_N raw / G_scal =',mp.nstr(GN_raw/GN_scal,18))
print('raw short-range G_eff / G_scal =',mp.nstr(raw_scalar_ratio(0),22))
print('raw long-range G_eff / G_scal =',mp.nstr(raw_scalar_ratio(100),22))
print('if Gobs fixed, U_scal SI =',mp.nstr(U_scal_obs,17),'m^-2')
print('if Gobs fixed, U_raw SI =',mp.nstr(U_raw_obs,17),'m^-2')
print('if Gobs fixed, Lambda raw =',mp.nstr(Lam_raw,17),'m^-2')
print('if Gobs fixed, a0 raw =',mp.nstr(a0_raw,17),'m/s^2')
print('if Gobs fixed, Hinf raw =',mp.nstr(H_raw,17),'s^-1')
print('if Gobs fixed, omegaLambda raw =',mp.nstr(om_raw,17))
print('at fixed U, RAR ratio raw/scalar y=1 =',mp.nstr(rar_raw_scalar_ratio(1),18))
print('if Gobs fixed, UV As raw =',mp.nstr(As_uv_raw,17))

print('retained primitive EH trace ratio =', np.trace(Zret@metric_Q)/np.trace(metric_Q))
print('retained gauge even trace ratio =', ret_weak_weight/raw_weak_weight)
print('universal positive trace-two gauge ratio ceiling =', gauge_general_upper/raw_weak_weight)
print('metric reparametrization source-exchange ratio =', mp.nstr(exchange_new/exchange_raw,20))
