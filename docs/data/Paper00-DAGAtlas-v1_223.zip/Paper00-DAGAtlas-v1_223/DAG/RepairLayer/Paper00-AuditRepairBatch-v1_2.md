# Born–Hopf Geometry — Audit finding repairs, batch 2 (v1.2)

**Date:** 13 November 2026  
**Input:** Papers v2.372, DAG Atlas v1.124, ProofChainAudits v1.42; current TeX authoritative.  
**Output:** Papers v2.373, DAG Atlas v1.125, ProofChainAudits v1.43.  
**Scope:** 21 distinct findings in VII-A and VII-B, 48 recorded substring replacements plus four directly reviewed scope guards; two changed paper/pdfs.  
**Controls:** 24/24 scoped mathematical/numerical checks passed; no new empirical or continuum evidence is claimed.  

## 1. Source-level mathematical corrections

| Issue | Current source lines | Change | Disposition |
|---|---|---|---|
| `BH-G-000134` | `Paper7A-QCDKernel-v1_166.tex:304,676` | Retired fermion SVD source replaced by current charged-preterminal parent contraction and certified hierarchy-arrow interface. | SOURCE_CORRECTED; PHYSICAL/EXTERNAL GATE OPEN |
| `BH-G-000135` | `Paper7A-QCDKernel-v1_166.tex:452,460,986` | A2 roots decomposed in sl3(C); su3 is the eight-real-dimensional compact form, not all End0(C). | SOURCE_CORRECTED; REAUDIT PENDING |
| `BH-G-000136` | `Paper7A-QCDKernel-v1_166.tex:1210,1228` | Scalar curvature shell is required to be a nonzero orthogonal projection before its Rayleigh infimum is defined. | SOURCE_CORRECTED; REAUDIT PENDING |
| `BH-G-000137` | `Paper7A-QCDKernel-v1_166.tex:1210,1217,1225,1228` | Rayleigh-gap loss is separated from actual compressed heat-kernel loss unless the shell reduces H. | SOURCE_CORRECTED; REAUDIT PENDING |
| `BH-G-000138` | `Paper7A-QCDKernel-v1_166.tex:1339,1344` | Diagonal/global color singlet is distinguished from vertexwise Gauss-invariant physical QCD block. | SOURCE_CORRECTED; PHYSICAL/EXTERNAL GATE OPEN |
| `BH-G-000139` | `Paper7A-QCDKernel-v1_166.tex:1568` | Finite exponential-transfer source-derivative sign corrected; log responses carry Duhamel ordering and contact jets. | SOURCE_CORRECTED; REAUDIT PENDING |
| `BH-G-000140` | `Paper7A-QCDKernel-v1_166.tex:1688,1708` | Static susceptibility includes the source-Hessian contact term and a spectral sum on the excited subspace. | SOURCE_CORRECTED; REAUDIT PENDING |
| `BH-G-000141` | `Paper7A-QCDKernel-v1_166.tex:1688` | Spectral susceptibility sum explicitly requires a simple isolated finite ground state and positive gap. | SOURCE_CORRECTED; PHYSICAL/EXTERNAL GATE OPEN |
| `BH-VIIB-G-0134` | `Paper7B-QCDReadouts-v1_151.tex:210,212` | Transfer spectrum is taken on Ran(P) instead of ambient PHP with spurious zero eigenvalues. | SOURCE_CORRECTED; REAUDIT PENDING |
| `BH-VIIB-G-0135` | `Paper7B-QCDReadouts-v1_151.tex:727,729,737` | Physical nucleon-sector spectral claim now requires a nonzero reducing projection [PN,H]=0. | SOURCE_CORRECTED; PHYSICAL/EXTERNAL GATE OPEN |
| `BH-VIIB-G-0137` | `Paper7B-QCDReadouts-v1_151.tex:908,922,934` | Two-state Hermitian mixing eigenvalues corrected from kappa squared to absolute kappa squared. | SOURCE_CORRECTED; REAUDIT PENDING |
| `BH-VIIB-G-0138` | `Paper7B-QCDReadouts-v1_151.tex:1085,1103` | Reported two-loop QCD scale explicitly requires and states the external MZ reference and beta normalization. | SOURCE_CORRECTED; PHYSICAL/EXTERNAL GATE OPEN |
| `BH-VIIB-G-0139` | `Paper7B-QCDReadouts-v1_151.tex:845,856` | Simple-pole residue uses holomorphic numerator at pole divided by denominator derivative; higher jets affect finite part. | SOURCE_CORRECTED; REAUDIT PENDING |
| `BH-VIIB-G-0140` | `Paper7B-QCDReadouts-v1_151.tex:1731,1740,1747` | Finite-volume Feynman–Hellmann hadron mass response subtracts the vacuum-energy derivative. | SOURCE_CORRECTED; PHYSICAL/EXTERNAL GATE OPEN |
| `BH-VIIB-G-0141` | `Paper7B-QCDReadouts-v1_151.tex:1847,1870,1873` | Winding number alone no longer identifies Noether baryon current without action/current-matched map. | SOURCE_CORRECTED; PHYSICAL/EXTERNAL GATE OPEN |
| `BH-VIIB-G-0142` | `Paper7B-QCDReadouts-v1_151.tex:2626,2641` | PDF normalization on [0,1] requires actual support/crossing and endpoint and zero-mode controls. | SOURCE_CORRECTED; PHYSICAL/EXTERNAL GATE OPEN |
| `BH-VIIB-G-0143` | `Paper7B-QCDReadouts-v1_151.tex:2919,2929` | Negative-x GPD antiquark branch signs are stated separately for unpolarized and helicity sectors. | SOURCE_CORRECTED; PHYSICAL/EXTERNAL GATE OPEN |
| `BH-VIIB-G-0144` | `Paper7B-QCDReadouts-v1_151.tex:3521,3537` | Dimensionful Hamiltonian source uses -T/V times logZ derivative, distinct from dimensionless-exponent convention. | SOURCE_CORRECTED; REAUDIT PENDING |
| `BH-VIIB-G-0145` | `Paper7B-QCDReadouts-v1_151.tex:3724,3737,3741` | Abstract geometric F_sigma is separated from Hurwitz E_sigma by a chosen, not automatic, isometric map. | SOURCE_CORRECTED; PHYSICAL/EXTERNAL GATE OPEN |
| `BH-VIIB-G-0146` | `Paper7B-QCDReadouts-v1_151.tex:4226,4264` | Positive spectral measures are not claimed to imply analytic continuation to a second resonance sheet. | SOURCE_CORRECTED; PHYSICAL/EXTERNAL GATE OPEN |
| `BH-VIIB-G-0147` | `Paper7B-QCDReadouts-v1_151.tex:4713,4715` | Pure-glue member is a typed restriction of QCD data with its own vacuum energy, not literal tuple inclusion. | SOURCE_CORRECTED; PHYSICAL/EXTERNAL GATE OPEN |

## 2. Mathematics and adversarial controls

1. **Color Lie algebra:** $E_{12}$ is traceless complex but not anti-Hermitian. The $A_2$ root-space splitting is an $\mathfrak{sl}_3(\mathbb C)$ complexification; $\mathfrak{su}(3)$ is the eight-*real*-dimensional compact form.
2. **Projected spectral shell:** for $H=\mathrm{diag}(0,4)$ and $P=|+\rangle\langle+|$, $\gamma=2$, so $e^{-\gamma}=0.13533528$, while $\|P e^{-H}P\|_{\operatorname{Ran}P}=0.50915782$. Both quantities are defined separately unless $[P,H]=0$; a zero projector has no unit-vector infimum.
3. **Gauss constraint:** the two-site global singlet $\sum_i|i\bar i\rangle/\sqrt3$ is invariant under diagonal $U\otimes\bar U$, but not under local transformations $U\otimes I$. Global color selection is not a local gauge/Gauss-law certificate.
4. **Finite source sign and contacts:** $K=e^{-tH(J)}$ implies $-t^{-1}\partial_J\log K=\partial_JH$ and $\partial_J\log Z=-t\langle H_J\rangle$. For $\chi=-\partial_A\partial_BE_0$ on a simple isolated ground state, $\chi_{AB}=2\sum_{n>0}\operatorname{Re}(\langle0|H_A|n\rangle\langle n|H_B|0\rangle)/(E_n-E_0)-\langle0|H_{AB}|0\rangle$. $E_0=-|J|$ gives a counterexample if the ground state is degenerate.
5. **Sector compression:** ambient $PHP$ has unwanted kernel zeroes. Use $(PHP)|_{\mathrm{Ran}P}$ and require $[P,H]=0$ to identify the invariant physical sector. A noncommuting projected Hamiltonian is not an exact superselection block.
6. **Complex two-state mixing:** for Hermitian $\begin{pmatrix}a&\kappa\\\bar\kappa&b\end{pmatrix}$, the eigenvalues are $(a+b\pm\sqrt{(a-b)^2+4|\kappa|^2})/2$. Using $\kappa^2$ fails for $\kappa=1+2i$.
7. **Two-loop scale is input dependent:** with $n_f=5$, $\alpha_s=1/\sqrt{72}$ and an *external* $M_Z=91.1876$ GeV boundary, the quoted formula gives $\Lambda_5=206.949940369$ MeV. This computation is not an independent prediction of $M_Z$ or $\alpha_s$.
8. **Residues and Feynman–Hellmann:** if $B(s_*)=0$, $B'(s_*)\ne0$ and $A$ is regular, $\operatorname{Res}_{s_*}(A/B)=A(s_*)/B'(s_*)$. For a vacuum-subtracted finite hadron mass $M_h=E_h-E_0$, $\partial_mM_h=E_h'-E_0'$, not merely $E_h'$.
9. **Physical interface guards:** topological degree does not fix a Noether current normalization; $[0,1]$ parton moments require support/crossing; negative-$x$ GPDs encode distinct quark/antiquark signs; $-T\partial_h\log Z$ applies to a Hamiltonian source at finite temperature; Hurwitz-to-hadron Gram identification is a chosen map; spectral positivity alone does not imply second-sheet continuation.
10. **Pure-glue typing:** restricting full-QCD data to a pure-YM subdatum needs a typed restriction map and a separate pure-glue vacuum-energy subtraction. Full-QCD vacuum data cannot simply be reused.

## 3. Conditions retained; not claimed closed

- **`BH-G-000134`:** Current Paper V imported source/hierarchy-arrow contract still required.
- **`BH-G-000138`:** A source-owned local Gauss projector commuting with H is not supplied by global singlet averaging.
- **`BH-G-000141`:** Application to a particular channel requires its lowest eigenvalue to be simple and isolated.
- **`BH-VIIB-G-0135`:** Physical nucleon spin/isospin sector must reduce H, or use a distinct valid Feshbach construction.
- **`BH-VIIB-G-0138`:** Diagnostic depends on externally given M_Z and alpha; no geometric derivation of numeric scale follows.
- **`BH-VIIB-G-0140`:** Hamiltonian/source and continuum normalization and matched scalar insertion remain to be supplied.
- **`BH-VIIB-G-0141`:** Topological winding equals baryon Noether charge only on an action/current-matched chiral map.
- **`BH-VIIB-G-0142`:** Quark/antiquark crossing, support, endpoint and zero-mode controls remain physical-interface gates.
- **`BH-VIIB-G-0143`:** Physical distribution support and crossing conventions remain separate certificates.
- **`BH-VIIB-G-0145`:** A chosen identification of abstract Hurwitz support with the physical Gram carrier remains a datum.
- **`BH-VIIB-G-0146`:** Meromorphic second-sheet continuation and resonance localization need analytic control beyond positivity.
- **`BH-VIIB-G-0147`:** Actual pure-YM restriction and independent pure-glue vacuum/transfer/OS convergence require evidence.

Other audit issues in the 30-report corpus remain as historically adjudicated. No source correction is promoted to a globally VERIFIED theorem or to an experimentally established hadron, confinement, strong scale, or continuum mass gap.

## 4. Executable controls and compilation scope

- `Proofs/Paper00-AuditRepairBatch2-v1_1-verify.py`: self-contained finite algebra, numerical identity, and explicit counterexample controls.
- `Proofs/Paper00-AuditRepairBatch2-v1_1-results.json`: 24 passed of 24. Controls independently test local mathematical identities but do **not** establish that actual framework objects satisfy every conditional hypothesis.
- Both updated TeX sources built successfully into PDF with `pdflatex` and `bibtex8`, zero missing bibliography citations. Their standalone builds retained unresolved external cross-paper *LaTeX reference* warnings (VII-A: 115 occurrences, VII-B: 58 occurrences), since imported .aux files of other papers were not present in this compilation. No silent claim of warning-free compilation is made.
- Latest ZIP paper manifest: 30 TeX and 30 matched PDF entries, one current version per paper, plus unchanged macro/bibliography.
- DAG canonical theorem graph and combined typed edges remain byte-for-byte inherited; current source anchors are rebound with no theorem-label additions or losses. Prior proof statuses are historical and still await claim-specific re-audit.

## 5. Current source checksums

- `Paper7A-QCDKernel-v1_166.tex`: SHA-256 `dcbc2551f9fc08eebeedc41c83a3c2a0f0a9b5144e4471218bb3307d1e73afb6`
- `Paper7B-QCDReadouts-v1_151.tex`: SHA-256 `efe40952e04b0c845e1009c94a0acf95b5260a85280eaa379f948bca6c5318e1`

## 6. Provenance and interpretation

The audit addenda document the repair event separately from the original 195-statement and 314-statement verification records. A source edit can eliminate a particular formula error without supplying a physical realization. The original evidence and issue histories are preserved verbatim as a historical audit baseline.
