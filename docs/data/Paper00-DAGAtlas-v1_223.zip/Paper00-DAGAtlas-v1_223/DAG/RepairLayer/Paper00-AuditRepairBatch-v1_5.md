# Born–Hopf Geometry — proof-chain source repair, batch 5 (v1.5)

**Date:** 13 November 2026  
**Input:** Papers v2.375; DAG Atlas v1.127; ProofChainAudits v1.45.  
**Output:** Papers v2.376; DAG Atlas v1.128; ProofChainAudits v1.46.  
**Scope:** Five original open audit issue IDs, repaired at their earliest source locations in Paper III-D and V-C. Mathematical proof/derivation, coordinate and observable typing; **not** a full theorem-DAG re-audit or new physical-occurrence certificate.

## Main derived results

### 1. Actual positive junction measure, not the constant trace

With U,C_j>0, the original terminal trace is constant and has zero distributional derivative. Introduce a *separate, expressly nonphysical bookkeeping representative*

\[
H_j^{\rm junc}(R)=\begin{cases} C_j,&0<R\le C_j,\\ (R^2+UC_j)/(U+C_j),&R>C_j.\end{cases}
\]

This function is continuous at C_j but has a first-derivative jump 2C_j/(U+C_j). Its distributional Hessian is exactly

\[
d(H_j^{\rm junc})'=\frac{2}{U+C_j}\mathbf1_{(C_j,\infty)}\,dR+\frac{2C_j}{U+C_j}\delta_{C_j}\ge0.
\]

The old claim for the constant C_j itself was false; this construction fixes its mathematical object. It does **not** prove off-shell action gluing or a cosmological crossing history.

### 2. A typed coefficient character at the first actual protected grade

At the existing first actual carrier grade 4 and existing positive coefficient base Q_sigma=8 sqrt(alpha_sigma)>1, the positive normalized one-dimensional character is

\[\rho_Q(s)=e^{s\log Q_\sigma}.\]

Positive functional calculus proves its multiplicativity and uniqueness among continuous positive characters with rho_Q(1)=Q_sigma. Evaluation at the already defined positive Laurent exponent yields D_4(R)=rho_Q(n_4^+(R)). This derives the **mathematical coefficient pullback** and removes the missing-owner ambiguity without importing later Paper III-F as a premise. The same-action metric-action insertion of P_4 remains unproved.

### 3. Gauge Gram kernel after kinetic whitening

For an occurring h and positive source metrics Q_rho on gauge coordinates and B_h on scalar coordinates, let J_h(X)=rho(X)h, J_tilde=B_h^(1/2) J_h Q_rho^(-1/2), and M_G^2=J_tilde^dagger J_tilde. Then, by positivity,

\[
\ker(J_h^\dagger B_hJ_h)=\ker J_h=\mathfrak g_h,\qquad
\ker M_G^2=Q_\rho^{1/2}\mathfrak g_h.
\]

Raw and kinetic-coordinate null subspaces are **not generally identical**. A finite counterexample with J=[1,1], Q_rho=diag(4,1), B_h=3 yields raw null (1,-1) and canonical null (2,-1). Massless multiplicity and abstract stabilizer dimension are unchanged; on the stated Standard Model solder branch, the canonical kernel has dimension 8+1=9. The downstream Goldstone Hessian-zero statement is transported with the same scalar metric B_h.

### 4. Which e+e- observable is actually computed

The color-weight identity R_gamma=3 sum_active Q_q^2 [1+alpha_s/pi+...] is **photon-exchange-current projected**, not the physical total neutral-current inclusive ratio at arbitrary energies. For massless, unpolarized open Born channels, a correctly typed full neutral-current formula is

\[
R_{\gamma+Z}^{(0)}(s)=3\frac{\sum_q F_q(s)}{F_\mu(s)},\qquad
F_f=\frac14\sum_{\lambda,\lambda'\in\{L,R\}}
\left|Q_eQ_f+\zeta_Z(s)g^e_\lambda g^f_{\lambda'}\right|^2.
\]

The photon projection zeta_Z=0 gives 2, 10/3, 11/3, 5 for 3–6 active flavors. A controlled SM-like example with sin²theta_W=1/4, high-energy chi_Z=4/3 gives F_u=46/81, F_d=22/81, F_mu=10/9 and six-flavor **R_gamma+Z=34/5** rather than photon-only 5. This is an observable-definition repair, not a framework-derived precision prediction: native couplings, pole/width and threshold owners remain required.

### 5. Physical-unit charge derivative

For i hbar dV/dt=H_phys V and an explicitly time-dependent Schrodinger-picture Q(t),

\[
\frac{d}{dt}\langle Q\rangle=\operatorname{Tr}\rho_t\left(\partial_t Q+\frac{i}{\hbar}[H_{\rm phys},Q]\right).
\]

A two-level noncommuting example with hbar=2 confirms that omitting 1/hbar doubles the derivative. This repairs units only, not the occurrence of an actual signed baryon source/history.

## Issue ledger and residual obligations

| Audit finding | Source and present disposition | Remaining independent obligation |
|---|---|---|
| `BH-IIID-HATJUNC-001` | Paper3D v1.160, lines 1699–1798; **mathematical issue source-corrected** by separate glued representative and distributional proof | Genuine action/history crossing not thereby realized |
| `BH-IIID-DCHARPORT-002` | Paper3D v1.160, theorem line 1853; **mathematical character pullback source-corrected**, original occurrence claim restricted | Same-action incidence of P4 into gravity coefficient remains open |
| `BH-VC-G-0001` | Paper5C v2.172, theorem line 1207 and Goldstone line 1288; **kernel type/math source-corrected** | Stated occurring-solder/physical-branch antecedent not re-certified |
| `BH-VC-G-0003` | Paper5C v2.172, proposition line 2837, new Eq. line 2866; **observable-type/math source-corrected** | Full neutral-current numerical output still requires action-owned currents and matching |
| `BH-VC-G-0006` | Paper5C v2.172, section line 7286; **dimensional identity source-corrected** | Actual charge-source/current dynamics separate |

Historical audit OPEN/UNRESOLVED labels are retained in their archived contexts; the new repair addendum does not alter original evidence or silently promote the global DAG. Other V-C roots G-0002, G-0004, G-0005, and inherited V-A roots remain open.

## Verification and build evidence

- Source-level mathematical controls: **41/41 passed** (`Proofs/Paper00-AuditRepairBatch5-v1_1-verify.py` and adjacent results JSON), including distributional weak-derivative control, explicit nontrivial kinetic metric counterexample, Ward-zero example, full neutral-current counterexample and hbar!=1 unit control.
- Both changed TeX files compile with pdflatex, bibtex8, pdflatex, pdflatex to PDFs (50 and 107 pages), no undefined bibliography citations. **Standalone cross-paper reference warnings remain** (III-D 32, V-C 43) because companion .aux files are absent; V-C has 47 overfull-line diagnostics in its PDF build. Do not classify either as a fully warning-free project-wide build.
- All 30 current paper `.tex/.pdf` pairs retained; 28 unchanged pairs byte-identical. Previous label set of 13,560 is retained, with **two new equation labels** (13,562 current, none duplicated or missing). The 535 changes in source anchor locations are rebases caused by revised sources, *not* new mathematical certificates.
- Canonical theorem DAG, historical audit layers and combined material edges remain **bit-for-bit unmodified**. New source locator/repair overlays are separate.
- Cumulative across repair batches 1–5: 59 previous + 5 new original audit findings **addressed = 64** (including conditional source corrections, not 64 unconditional physical closures).

## Compatibility and release boundaries

This batch repairs *the observable to be explained* at each origin: a junction measure, a coefficient character, a massless gauge kernel, a photon-projected versus full neutral-current ratio, and a dimensionally valid charge derivative. It does not demand reproduction of mechanisms not established by the source chain. Any physical promotion requires the precise source-owner/action/observable certificate already named in the audits. The unchanged TeX macros still carry an inherited cross-paper AUX registry; standalone citations are resolved but some cross-references are not. No global source-map status is claimed as a whole-paper E3 re-audit.
