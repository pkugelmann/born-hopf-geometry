# Born–Hopf Geometry — Audit Repair Batch 1

**Record:** `Paper00-AuditRepairBatch-v1_1.md`  
**Date:** 13 November 2026  
**Inputs:** papers v2.371, audit v1.41, atlas v1.123, supplied ProofChain Audit protocol v1.1 and rigorous verification/DAG work protocol v2.4.  
**Outputs:** papers **v2.372**, audit **v1.42**, atlas **v1.124**.  
**Scope:** 14 distinct identified audit issues, 23 source-text edits, seven papers.  
**Status:** **SOURCE_REPAIRED + SCOPED_MATH_CHECKED, NOT REAUDITED GLOBALLY**.

This is **a repair run, not a fresh full-paper mathematical audit**. It preserves established proofs and their precise domains. The earlier report body for each affected paper is retained verbatim as historical evidence in its successor report. All findings outside the 14 enumerated IDs retain their previous audit dispositions. The historical graph/edges are not globally reverified or inferred to have changed status. For repaired issues, a source-level error has been corrected, not certified to have supplied a previously absent experimental/physical realization.

## Target-observable and proof-scope guide

The goal is correctness of the result **actually claimed** in each theorem: typed global maps (I-A), invariant finite cubature (II-E), genuine 2-jet Hessian law (III-A), gravitational symplectic/Hessian distinction and projected Schur transfer (III-F), closed-spectrum and numerical readouts (VI-C), finite transfer decay versus OS reconstruction (VII-C), and physical-channel transfer compression (VII-D). No generic continuum mechanism or added fundamental axiom is required for these repairs.

## Repaired issue ledger

| Audit issue | Updated source line(s) | Corrective statement | Verification scope |
|---|---|---|---|
| `BH-IA-G-000105` | `Paper1A-Geometry-v5_169.tex:7917` | The isometry differential lives in Iso(T_p M,T_{f(p)}M), not a fixed tangent-endomorphism O(T_pM). | Source edit and scoped independent checks; downstream/global gates unchanged. |
| `BH-IA-G-000106` | `Paper1A-Geometry-v5_169.tex:8134` | Only rank-one projector is intrinsically defined over CP¹; normalized vector depends on homogeneous phase. | Source edit and scoped independent checks; downstream/global gates unchanged. |
| `BH-IIE-G-0001` | `Paper2E-KinematicExports-v3_132.tex:2367, 2377` | The ≤d-node cubature guarantee is for the initial positive rule, not the later symmetry-averaged finite rule. | Source edit and scoped independent checks; downstream/global gates unchanged. |
| `BH-IIIA-G-0008` | `Paper3A-GeneratedDynamics-v1_170.tex:5507` | Omitting Hessian contact breaks the actual scalar Hessian chain law but not associativity of a truncated tensor congruence. | Source edit and scoped independent checks; downstream/global gates unchanged. |
| `BH-IIIF-G-0002` | `Paper3F-CompleteDynamics-v1_257.tex:8278, 8292` | The linear aR curvature action changes the full symplectic current; only constant b is invisible, while Hessian blindness is a different property. | Source edit and scoped independent checks; downstream/global gates unchanged. |
| `BH-IIIF-G-0005` | `Paper3F-CompleteDynamics-v1_257.tex:13225, 13250` | Schur edge has positive smallest nonzero singular value only with aligned full-column-rank couplings on one complement; row rank alone fails. | Source edit and scoped independent checks; downstream/global gates unchanged. |
| `BH-IIIF-G-0003` | `Paper3F-CompleteDynamics-v1_257.tex:9854` | The curvature-to-U equality explicitly inherits Paper III-E’s CELL_{K→U} hypothesis. | Source edit and scoped independent checks; downstream/global gates unchanged. |
| `BH-VIC-G-0138` | `Paper6C-TechnicalMaterial-v1_44.tex:2773, 2785` | Use S³ eigen-wavenumber sqrt[k(k+2)] instead of identifying mode index k with momentum. | Source edit and scoped independent checks; downstream/global gates unchanged. |
| `BH-VIC-G-0141` | `Paper6C-TechnicalMaterial-v1_44.tex:4036, 4045` | Compute 2.9588×10⁹·(3/5)^(1/4) ≈ 2.6041×10⁹; do not use 2.96×10⁹ as the product. | Source edit and scoped independent checks; downstream/global gates unchanged. |
| `BH-VIC-G-0143` | `Paper6C-TechnicalMaterial-v1_44.tex:4942` | The normalized Reeb return sum has y>0 domain; acceleration may extend continuously to y=0 even though the multiplier does not. | Source edit and scoped independent checks; downstream/global gates unchanged. |
| `BH-VIC-G-0147` | `Paper6C-TechnicalMaterial-v1_44.tex:6416, 9929` | C56 equals ℛ56², not ℛ56²/U; repair primary equality and downstream reuse without altering its physical readout. | Source edit and scoped independent checks; downstream/global gates unchanged. |
| `BH-G-000152` | `Paper6C-TechnicalMaterial-v1_44.tex:10051` | SymPy verification snippet uses the prescribed 1/(4π) factor. | Source edit and scoped independent checks; downstream/global gates unchanged. |
| `BH-VIIC-G-0001` | `Paper7C-ContinuousQFT-v2_196.tex:808, 2891, 2902` | Transfer contraction acts on complement of complete ground eigenspace; QFT4/OS semigroup passage needs convergence of full-ground-projected matrix elements. | Source edit and scoped independent checks; downstream/global gates unchanged. |
| `BH-VIID-G-0004` | `Paper7D-TechnicalMaterial-v1_47.tex:1861, 1888` | Combined primitive span projector is supp(ΣPχ); the positive spectrum is on its range, not on the whole Hilbert space. | Source edit and scoped independent checks; downstream/global gates unchanged. |

## Independent mathematics and failure controls

- **VII-C:** If \(P_0\) is the **entire** ground eigenspace projection and \(Q_0=I-P_0\), then finite-dimensional spectral calculus gives \(\|e^{-t(H-E_0)}Q_0\|=e^{-t\gamma}\) (provided an excited subspace exists). Degenerate ground spaces invalidate the previous claim with a single vector \(\Omega^\perp\). This repairs the finite transfer theorem. The physical pure-glue continuum inference **still requires** the explicitly stated convergence of the *projected* QFT4/OS semigroup matrix elements.
- **VII-D:** \(\sum_\chi P_\chi\) is generally **not** a projection when channels overlap. \(\mathbf 1_{(0,\infty)}(\sum_\chi P_\chi)\) projects orthogonally to the combined channel span. If every channel projector reduces \(H\), its spectral support also reduces \(H\); the compressed heat kernel restricted to that range has eigenvalues in \((0,1]\). The full-space compression may have zero eigenvalues.
- **III-F:** Full rank by itself does not prevent cancellation in \(A_LUA_R^\dagger\). The corrected result assumes **full column rank with the same paired channel dimension** and bounds only \(\sigma_{\min}^{+}\). A polar decomposition proves the stated estimate and a rank-misalignment counterexample rejects the old unconditional form.
- **III-F gravitational currents:** Equality of scalar curvature-action Hessians with respect to curvature does not imply equality of the full covariant Einstein–Hilbert presymplectic current. The \(aR\) direction contributes to the latter. This is a mathematical distinction, not an assertion of physical coupling selection.
- **VI-C:** Exact closed-S³ spectral parameter is \(\sqrt{k(k+2)}\); continuous or high-k approximations are separately marked. Numeric and domain checks cover the stated normalization examples.
- **I-A / II-E / III-A:** Exact target type, projective descent, symmetry-averaged cubature quantifier, and full second-jet contact are repaired without replacing any foundational theorem.

**Executable control log:** `RepairVerification-v1_1.json` with 23 passing named checks (including counterexamples). These controls demonstrate the listed identities and counterexample mechanisms; they are not a theorem-wide formal proof, source regression suite, complete TeX compilation certificate, or an empirical check of observables.

## Unresolved work, not silently reclassified

1. All other open findings in the original 30 audits and their upstream/downstream proof obligations remain open. A current automated count would not substitute for source adjudication of duplicate/alias issue roots.
2. The VII-C physical mass-gap consequence remains conditional on projected QFT4/OS semigroup convergence and any other existing physical-interface premises. A finite spectral gap does not alone prove a continuum Yang–Mills mass gap.
3. The III-F rank-restricted Schur estimate does not assert that actual framework-specific couplings satisfy the new rank condition; that must be checked at the particular claimed source-generated channel.
4. Historical atlas DAG edges, source-line anchors, and audit statuses are historical evidence. The release overlay records exactly the changed sources and labels; no global DAG theorem-status promotion is asserted.
5. Seven affected source files have new version suffixes. Untouched paper versions remain exactly as supplied. Outdated source/PDF versions are not retained at the active top level.
