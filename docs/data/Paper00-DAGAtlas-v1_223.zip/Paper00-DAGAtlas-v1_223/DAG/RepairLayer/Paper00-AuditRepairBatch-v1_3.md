# Born–Hopf Geometry — Audit finding repairs, batch 3 (v1.3)

**Date:** 13 November 2026  
**Input:** Papers v2.373, DAG Atlas v1.125, ProofChainAudits v1.43, supplied work/audit protocols; current TeX authoritative.  
**Output:** Papers v2.374, DAG Atlas v1.126, ProofChainAudits v1.44.  
**Scope:** 9 distinct audit findings, 29 source substitutions across five current papers (two core repairs with downstream typing/scheme propagation).  
**Scoped verification:** 28/28 controls passed; five PDF builds, no LaTeX errors, zero unresolved bibliography citations; standalone external cross-paper-reference warnings persist.  

## 1. Claim-by-claim source repairs

| Audit issue | New primary source | Correction and disposition |
|---|---|---|
| `BH-G-000100` | `Paper4B-QuantumResponse-v1_43.tex:2922` | Corrected restricted-composition Cauchy leap; a determining full-real or dense additive composition-domain certificate is now explicit. **SOURCE_CORRECTED; CLAIM-SCOPE REAUDIT PENDING.** |
| `BH-G-000101` | `Paper4B-QuantumResponse-v1_43.tex:4553` | Equilibrium is characterized by all additive collision invariants; Gibbs form follows only if the actual positive-rate collision-invariant space is complete. **SOURCE_CORRECTED; CLAIM-SCOPE REAUDIT PENDING.** |
| `BH-IIIE-G-0001` | `Paper3E-GravityAction-v1_191.tex:840` | Separated seven-real-dimensional Clifford response W_7 from complex spin W_spin and corrected J_Delta codomain and V-A consumers. **SOURCE_CORRECTED; CLAIM-SCOPE REAUDIT PENDING.** |
| `BH-IIIE-G-0002` | `Paper3E-GravityAction-v1_191.tex:984` | Retyped CRP4 as unique scheme-depth partial B-connection; no full BxM connection uniqueness without independent M-direction data. **SOURCE_CORRECTED; CLAIM-SCOPE REAUDIT PENDING.** |
| `BH-IIIE-G-0003` | `Paper3E-GravityAction-v1_191.tex:1371` | Scoped ordinary heat trace class to finite/compact parents; noncompact localized/relative/volume trace is a distinct readout requiring a trace certificate. **SOURCE_CORRECTED; CLAIM-SCOPE REAUDIT PENDING.** |
| `BH-IIIE-G-0004` | `Paper3E-GravityAction-v1_191.tex:4287` | Carrier-four D_4(C_2)/Q is scheme dependent; 0.825729956674 is the REG0 numeric value, propagated to VI-A/VI-B. **SOURCE_CORRECTED; CLAIM-SCOPE REAUDIT PENDING.** |
| `BH-IIIE-G-0005` | `Paper3E-GravityAction-v1_191.tex:4656` | Bare reciprocal midpoint derivative is zero at x=1; at q=7/2 it requires R_s^2=UC, not a generic cap reference. **SOURCE_CORRECTED; CLAIM-SCOPE REAUDIT PENDING.** |
| `BH-IIIE-G-0006` | `Paper3E-GravityAction-v1_191.tex:4600` | Consistent curvature dimensions for Y,j and h_eff; dimensionless rescaling y=Y/R_s now retains R_s^16 Jacobian. **SOURCE_CORRECTED; CLAIM-SCOPE REAUDIT PENDING.** |
| `BH-IIIE-G-0007` | `Paper3E-GravityAction-v1_191.tex:6147` | Replaced nonexistent III-F section reference with exact current proposition and remark labels, separating restricted tests. **SOURCE_CORRECTED; CLAIM-SCOPE REAUDIT PENDING.** |

## 2. Exact mathematical controls and counterexamples

1. **Euclidean weight, IV-B.** On only integer action pairs, the positive, strictly decreasing continuous weight $w(x)=\exp[-x+0.05\sin(2\pi x)]$ obeys $w(n+m)=w(n)w(m)$ but is not globally $\exp(cx)$. The repaired theorem proves the continuous Cauchy equation when composition holds on all reals or on all pairs of a dense additive subgroup. The actual dense/full action-coordinate owner is **not** established by this logical repair.
2. **H-theorem, IV-B.** For $0<f_a<1$, $\eta_a=\log[(1-f_a)/f_a]$ is an additive collision invariant at zero entropy production. Four opposite momentum pairs with three positive pair exchanges have a connected reaction hypergraph and $\eta(+u)=-\ln3$, $\eta(-u)=+\ln3$, axis-cell $\eta=0$; reaction balance holds, but no single energy--momentum affine Gibbs parameter fits these mode values. The Gibbs clause requires the explicit complete invariant-space hypothesis.
3. **Spin types, III-E to V-A.** $W_7$ is seven real dimensional, whereas $W_{\rm spin}=W_L\oplus W_R$ has complex half-spin type (four complex components on the cited branch). $J_\Delta$ and its internal chirality operator must be typed on the same spin target, not identified with $W_7$ by symbol reuse.
4. **CRP4, III-E.** The positive character $H_{b_1b_0}$ fixes a $B$-direction connection, not a unique $M$-direction connection on the pulled-back rank-four bundle; changing the independent $M$-connection leaves the $B$ cocycle untouched.
5. **Heat trace, III-E.** On $\mathbb R^4$, $K_t(x,x)=(4\pi t)^{-2}$ gives a finite trace per unit volume but infinite unlocalized full trace. Finite and compact scalar owners admit ordinary $\mathcal L^1$ heat operators; a noncompact localized/relative readout requires a separately defined functional.
6. **REG scheme, III-E to VI-A/VI-B.** At the rank-four midpoint, $n_4^+(C_2)=\log\cosh(2A)/(2A)$, $A=\log\alpha_\sigma$ and $D_4(C_2)/Q=\exp[(n_4^+(C_2)-1)(\log8+A/2)]$. On $A_0=4\pi^2+1/(6\sqrt2)$ the result is $0.8257299566743899\dots$; varying $A$ changes it.
7. **Reciprocal midpoint, III-E.** Reciprocal symmetry makes $\partial_q\log[b(x)b(1/x)]^{-1}=0$ at $x=1$. With $x=R/R_s$ and $q=\log(U/R)/\log\alpha$, this happens at $q=7/2$ only if $R_s^2=UC$. A positive in-domain counterexample with $U=10,C=1,R_s=2,B_I=3,B_U=1$ yields a nonzero derivative at $q=7/2$.
8. **Finite Gaussian typing, III-E.** $[Y]=[j_s]=\mathrm{curvature}$, $[\hbar_{\rm eff}]=\mathrm{curvature}^2$ make $W_s/(8\hbar_{\rm eff})$ dimensionless. For the 16 entry variables, $\sqrt{\det(I_4\otimes T_s)}=b^8$; the curvature-to-dimensionless-coordinate change $Y=R_s y$ contributes $R_s^{16}$. These facts validate the finite algebra, not selection of a native gravitational path measure.
9. **Source reference, III-E.** The non-existent `p3f:sec:v229-action-tests` link is replaced by current checked III-F labels for the same-chart Hessian comparison, restricted positive auxiliary-Schur diagnostic and terminal affine extrapolation. No implication is expanded beyond those tests.

## 3. Unclosed proof/physical obligations

- **`BH-G-000100`:** Actual generated action-domain composability/density remains unproved; globally unique positive weight conditional.
- **`BH-G-000101`:** Actual quasiparticle-scattering kernel and invariant-space classification remain physical inputs.
- **`BH-IIIE-G-0001`:** Actual spin ancestry identity still inherits its upstream orientation-preserving-lift premise.
- **`BH-IIIE-G-0002`:** Independent spacetime connection on W* remains an additional domain if full connection is claimed.
- **`BH-IIIE-G-0003`:** No source-supplied full noncompact L1 operator or noncompact trace functor has been certified.
- **`BH-IIIE-G-0004`:** REG0 physical owner anchoring remains a separate branch certificate; numbers not universal across REGσ.
- **`BH-IIIE-G-0005`:** Actual midpoint identification for free R_s not selected by the algebra.
- **`BH-IIIE-G-0006`:** Geometric/native quantum integration measure and its normalization remain independent certificates.
- **`BH-IIIE-G-0007`:** No mathematical gap from the repaired citation; imported source tests retain their conditional scopes.

## 4. Reproducibility and release gates

- `Proofs/Paper00-AuditRepairBatch3-v1_1-verify.py` and `Proofs/Paper00-AuditRepairBatch3-v1_1-results.json` contain 28 scoped independent finite, counterexample, source-link and unit tests. Tests **do not** globally re-audit the papers or prove actual physical occurrence.
- The five changed TeX sources were independently built to PDFs using `bibtex8` and repeated `pdflatex`; bibliography-citation warnings are zero in all five final logs. VI-B BibTeX issued six pre-existing empty-journal warnings, not missing citations. External cross-paper LaTeX `.aux` warnings remain and are counted in the certificate.
- Exactly 30 current TeX/PDF paper pairs, 30 latest audit reports and the complete historical atlas are preserved. The source-anchor map is rebased without altering the canonical theorem DAG, combined typed edges or inherited proof statuses.
- SOURCE_CORRECTED is a source event, **not** CLOSED/VERIFIED in the canonical audit graph. Existing physical import, same-action realization, calibration and observable gates remain conditional.

## 5. Source hashes

- `Paper4B-QuantumResponse-v1_43.tex`: SHA-256 `7e34acf99133089396835891bcad540d337e899e385da6c8654aa621f7fd967d`
- `Paper3E-GravityAction-v1_191.tex`: SHA-256 `4483fa84b3d5de8113171edbb6177ffdb303bd65d6dd47effacd9d47f9ec896c`
- `Paper5A-FiniteMatterGeometry-v3_203.tex`: SHA-256 `8a643cf145ad405e7e5f0aca5668c7198cb9154662b5220c5ac64297f9797160`
- `Paper6A-GravityCosmology-v2_254.tex`: SHA-256 `0979595a645668d8c447c88e077c0e30ac32393f0b5b909290cbd8f2e9228915`
- `Paper6B-CosmologyReadouts-v1_200.tex`: SHA-256 `7075c6e505e490b81455bca2a435e2bf77b1bf930910274ca12f8b0a6db75d84`

## 6. Provenance

The five report addenda retain the full prior audit texts verbatim as historical baselines. Only current source paths and issue-scope corrections are rebased; all original review-status flags remain unchanged pending dedicated re-audit.
