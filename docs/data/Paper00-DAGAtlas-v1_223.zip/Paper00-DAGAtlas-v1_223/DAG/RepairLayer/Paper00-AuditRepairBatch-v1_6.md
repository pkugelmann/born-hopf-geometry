# Born–Hopf Geometry — proof-chain source repair, batch 6 (v1.6)

**Date:** 13 November 2026  
**Input:** Papers v2.376; DAG Atlas v1.128; ProofChainAudits v1.46.  
**Output:** Papers v2.377; DAG Atlas v1.129; ProofChainAudits v1.47.  
**Scope:** 11 distinct VI-A audit issue IDs, source corrected in Paper VI-A v2.255. This is not an independent whole-paper re-audit or a physical-occurrence certificate. Historical evidence/statuses remain separate.

## Mathematical proofs and corrected observable types

### A. The normalized scalar charge is an integrated action-source ratio

On the explicit quasi-static spherical source domain, take the *same linearized action-owned scalar equation* `(∇²−m²)φ=−J_act` with a nonnegative compactly supported radial source and comparison `0≤J_act≤J_uns` that uses the same operator. The Yukawa Green function gives the exact exterior form for `r≥r_B`:

\[
\phi_{\rm out}(r)=\frac{e^{-mr}}{r}\int_0^{r_B} s^2 J_{\rm act}(s)\frac{\sinh(ms)}{ms}\,ds.
\]

The normalized exterior source fraction therefore is

\[
q_B^{\rm act}(m)=\frac{\int_0^{r_B}s^2 J_{\rm act}(s)\frac{\sinh(ms)}{ms}ds}{\int_0^{r_B}s^2J_{\rm uns}(s)\frac{\sinh(ms)}{ms}ds}\in[0,1].
\]

The proof uses the angular average of the Yukawa kernel, where for `r>s`, `1/2∫_{-1}^{1}exp(−m√(r²+s²−2rsu))/√(...)du = exp(−mr) sinh(ms)/(mrs)`. For a constant-density shell in the limit `m r_B→0`, the exact source fraction is `q=1-(1-Δr/r_B)^3=3δ-3δ²+δ³`, so identifying the thickness fraction δ with the integrated exterior scalar charge loses the leading factor 3. The difference in boundary values `|F_env−F_in|/(2Φ_B)` is a *different proxy*, not automatically the physical integrated charge. Matching the explicitly required action-owned `J_act`, the exterior metric, and the current-background mapping is **still open**. This construction does not create a scalar source ex nihilo.

### B. Two independent sufficient upper-bound routes

For a Hermitian finite insertion `O`, the Gershgorin/eigenvector comparison gives `||O||_2 ≤ b_O:=max_i Σ_j |O_ij|`. Separately, for an evaluated complete finite word expansion `O=Σ c_α W_α`, the triangle inequality gives `||O||_2 ≤ K_O:=Σ|c_α| ||W_α||`. These imply **distinct** sufficient trace-source certificates. The general inequality `b_O ≤ K_O` is false: the normalized `2×2` Hadamard matrix has operator norm 1 and row sum √2. The source no longer conflates them. Actual physical K48 operator word coefficients and source history have not been evaluated in this repair.

### C. Other mathematical corrections

- **Dust:** Continuous additive F on nonnegative response amplitudes is `F(ζ)=μζ` with `μ∈R`. The `μ≥0` claim requires a nonnegative effective-energy branch; when `μ=0`, `dp/dF` is not a derivative on a valid energy-density chart.
- **Geometric hierarchy:** With the source's illustrative `U=6.09×10^68 m⁻²` and `α=1.571958279122504×10^17`, the root wavenumbers are `R_8≈6.22×10^25 m⁻¹`, `R_16≈1.57×10^17 m⁻¹`. The separate Born midpoint curvatures are `C_8^B≈1.54×10^60 m⁻²`, `C_16^B≈3.87×10^51 m⁻²`. Previous table values were midpoint curvatures mislabeled as root wavenumbers.
- **Scalaron WKB:** For physical time, `ω_s=c m_s`; the dimensionless small parameters are `|H|/(c m_s)` and `|m_s-dot|/(c m_s²)`, with nonzero positive local restoring curvature and smooth well residence required.
- **Weak-field readout:** Dimensionless potentials require `GM/(F c²r)`, and the displayed PPN ratio applies to the `1/r` pieces after background-curvature subtraction, not to the quotient of the complete potentials.
- **Horizon coupling:** With native `κ_grav=M⁻²`, the floor is `ρ_inf=C_56/(2κ_grav)=M²C_56/2`, not `C_56/(2κ_grav²)`.
- **Horizon endpoint:** The crossing equivalence `w_DE=-1 iff Θ_A=1/3` is valid for `M(a)>0`; at `M=0`, the allowed unique root is `Y=1`, `Θ_A=1`, and `w_DE=-1` independently of the crossing.
- **Conformal clock:** `H_E dt_E=H_J dt_J+(1/2)d ln F`, for Hubble rates `H=d ln a/dt`, and equality without the additional term requires `dF=0`. A Dirac Hamiltonian one-form is a distinct object.
- **24-cell walk:** The full `T=A_+/8` spectrum has invariant eigenvalue 1 with multiplicity 1, so `1^n` belongs to the exhaustive channel-factor list; the other three nonzero factors are the mean-zero channels, with the 9-dimensional zero channel killed after one step.

## Audited issue ledger

| Issue ID | Current source label and line | Source-level repair | Remaining obligation |
|---|---|---|---|
| `BH-VIA-G-0001` | `p8:thm:k48-conditional-exact-dust` (line 2129) | Cauchy additivity yields real slope; mu>=0 now explicitly requires nonnegative effective energy. | Positivity of actual physical branch not derived by neutral current alone. |
| `BH-VIA-G-0002` | `p8:thm:k48-conditional-exact-dust` (line 2129) | Sound-speed derivative c_s^2=0 restricted to mu!=0; mu=0 is degenerate. | No physical-density realization is inferred from the degenerate zero-stress branch. |
| `BH-VIA-G-0003` | `p8:tab:geometric-outputs` (line 3036) | Recomputed wavenumber roots R8,R16 in m^-1; displayed Born midpoint curvatures separately in m^-2. | Metrological U identification remains inherited and conditional. |
| `BH-VIA-G-0004` | `p8:cor:lower-scalaron-matter-like-average` (line 4117) | Corrected physical WKB omega_s=c m_s and H/(c m_s), /dm_s/dt//(c m_s^2). | Local-well residence, slow variation and action source remain conditional. |
| `BH-VIA-G-0005` | `p8:thm:smooth-solar-system-screening-ppn` (line 4559) | Potentials dimensionless GM/(F c^2 r); gamma is ratio of 1/r contributions, not full background-inclusive fields. | Real exterior metric/source matching is still conditional. |
| `BH-VIA-G-0006` | `p8:thm:smooth-solar-system-screening-ppn` (line 4559) | Derived Yukawa-weighted radial action-source fraction; shell volume 1-(1-delta)^3, not delta. | Action-owned J_act and unscreened comparison and equality of boundary excursion to integrated charge remain unproved. |
| `BH-VIA-G-0008` | `p8:eq:hs-lambda-infty` (line 7257) | Horizon rho_inf=C56/(2 kappa_grav)=M^2 C56/2 with kappa_grav=M^-2. | Horizon action/physical stress identification remains inherited. |
| `BH-VIA-G-0009` | `p8:eq:hs-crossing-geometric` (line 7432) | w_DE=-1 iff Theta_A=1/3 only on positive-matter branch; M=0 vacuum endpoint exception recorded. | Physical branch/model prerequisites unchanged. |
| `BH-VIA-G-0010` | `p8:prop:v2188-trace-coefficient-certificate` (line 8587) | Separated maximum row-sum bound B from independent operator-norm coefficient bound K with valid proof. | Actual K16/K48 coefficient lists and first-hit numeric cap not certified. |
| `BH-VIA-G-0011` | `p8:sec:tensor-frame-ledger` (line 11178) | Corrected Hubble one-form H_E dt_E=H_J dt_J+1/2 d ln F; Dirac Hamiltonian operator distinguished. | Native frame/Dirac source occurrence and matching remain conditional. |
| `BH-VIA-G-0012` | `p8:prop:shell-algebra-nonterminal-rar` (line 9939) | Restored invariant 1^n eigenchannel, retaining nontrivial factors only for mean-zero sector. | Projection of physical halo response onto finite cell algebra remains conditional. |


## Verification and build evidence

- **16/16 scoped checks passed**, including direct angular quadrature against the closed Yukawa kernel, finite-mass source ratio, zero-mass shell limit, dimensionful root/readout calculations, explicit additivity and row-norm counterexamples, a seeded family of 45 Hermitian finite-word controls, a conformal Hubble counterexample, the vacuum endpoint and the 24-cell spectral census. See `Proofs/Paper00-AuditRepairBatch6-v1_1-verify.py` and its JSON results.
- Paper VI-A v2.255 compiles via `pdflatex, bibtex8, pdflatex, pdflatex` (240 pages, no fatal LaTeX errors or undefined bibliographic citations). **Standalone cross-paper reference warnings remain**; peer AUX data were not compiled together. Representative edited PDF pages 42 and 64 were rendered and inspected. These checks do not certify all other material in the manuscript.
- **Historical 13,562 source labels preserved**: new source label set is checked against the frozen VI-A label-set hash and the 30-paper corpus. The current source-anchor map is rebased for changed locations; this is not a mathematical status promotion.
- All 30 source/PDF pairs retained; 29 pairs are byte-identical to v2.376. Historical theorem DAG, global combined proof routes, and old audit layer evidence are preserved unmodified; only current source and a namespaced repair overlay are updated.
- Cumulative **64 prior addressed + 11 new = 75** audit finding IDs addressed in six source-repair batches. This count includes *conditional* mathematical scope corrections, not 75 independently verified physical closure certificates.

## Open physical and numerical proof frontier

The new source-integral theorem explicitly **assumes** an occurring, same-action radial `J_act`; the matching from the VI-A gravitational action to the exterior scalar and observed PPN parameters is not supplied by the algebraic ratio. The positive effective dust energy branch, the native physical-frame matching, and the actual first-K48 source-word/trajectory numerical bound remain distinct owners. Unchanged VI-A roots `BH-VIA-G-0007`, `BH-VIA-G-0013`–`BH-VIA-G-0017` remain open. All historical report OPEN labels retain their original-date status, with current source corrections explicitly layered above them; no bulk DAG status upgrade is warranted.
