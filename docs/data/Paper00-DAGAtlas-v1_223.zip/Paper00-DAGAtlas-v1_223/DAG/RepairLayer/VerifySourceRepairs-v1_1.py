#!/usr/bin/env python3
"""Independent scoped mathematical controls for Born–Hopf repair v2_372.
These verify exact finite algebra/typos, not physical occurrence or global theorem validity.
"""
import numpy as np
import math, json
from pathlib import Path
r=[]
def test(name,condition,detail):
 r.append({'check':name,'passed':bool(condition),'detail':detail})
 if not condition:raise AssertionError(name+': '+detail)
# IA: projective phase descends to a global projector.
z=np.array([1.3+0.7j, -0.6+1.9j]);lam=2.1-3.2j
for k in [0,1,2,5]:
 v=np.linalg.multi_dot([]) if False else np.array([1+0j])
 for _ in range(k):v=np.kron(v,z)
 v=v/(np.linalg.norm(z)**k)
 w=np.array([1+0j]);
 for _ in range(k):w=np.kron(w,lam*z)
 w=w/(np.linalg.norm(lam*z)**k)
 test(f'IA-projector-invariance-k{k}',np.linalg.norm(np.outer(v,v.conj())-np.outer(w,w.conj()))<1e-11,'P([lambda z])=P([z])')
# IIIA tensor-congruence is associative even while it misses nonlinear Hessian contact.
f=lambda x:x; g=lambda x:x*x
x=3.;H_f=0.;D_f=1.;Dg=2*x;D2g=2.
actual=Dg*Dg*H_f+D_f*D2g
truncated=Dg*Dg*H_f
test('IIIA-second-jet-contact',actual==2 and truncated==0,'f(x)=x, g(x)=x^2; second derivative 2 vs truncated 0')
# IIIF full row rank can be misaligned.
A=np.array([[1.,0.]]);B=np.array([[0.,1.]])
test('IIIF-row-rank-counterexample',np.linalg.matrix_rank(A)==1 and np.linalg.matrix_rank(B)==1 and np.linalg.norm(A@B.T)==0,'Each 1x2 coupling full row rank; Schur edge zero')
# IIIF valid full column rank nonzero-singular lower bound for random examples.
rng=np.random.default_rng(216)
for rdim in [1,2,3]:
 for m,n in [(rdim,rdim),(rdim+2,rdim+1)]:
  X=rng.normal(size=(m,rdim))+1j*rng.normal(size=(m,rdim));Y=rng.normal(size=(n,rdim))+1j*rng.normal(size=(n,rdim))
  Q,_=np.linalg.qr(rng.normal(size=(rdim,rdim))+1j*rng.normal(size=(rdim,rdim)))
  D=2.3
  T=X@Q@Y.conj().T/D
  sval=np.linalg.svd(T,compute_uv=False)
  left=np.linalg.svd(X,compute_uv=False)[-1]; right=np.linalg.svd(Y,compute_uv=False)[-1]
  smallest_nonzero=sorted(sval,reverse=True)[rdim-1]
  test(f'IIIF-fullcolumn-{rdim}-{m}-{n}',np.linalg.matrix_rank(T)==rdim and smallest_nonzero >= left*right/abs(D)-1e-9,'rank r and sigma_min^+ product lower bound')
# VIC band eigenvalues versus integers.
k1,k2=1,2
exact=np.sqrt(k2*(k2+2)/(k1*(k1+2)))
test('VIC-closed-s3-wave-number',abs(exact-2)>0.1 and abs(exact-math.sqrt(8/3))<1e-12,'k2/k1=2 not the exact eigen-wavenumber ratio sqrt(8/3)')
# VI-C full precision and lower rounded precursor.
factor=(3/5)**.25
n1=factor*2.9588e9;n2=factor*2.96e9
test('VIC-reheating-input',abs(n1/1e9-2.604074606824292)<1e-12 and abs(n2/1e9-2.6051307409084445)<1e-12,'2.6041e9 requires the 2.9588e9 precursor')
# VI-C positive return series and zero-source acceleration limit.
for y in [1e-8,1e-4,1.]:
 s=1/(1-math.exp(-math.sqrt(y)))
 test(f'VIC-positive-return-y{y}',math.isfinite(s) and s>1,'Series converges iff y>0')
test('VIC-zero-source-continuity', 1e-8/(1-math.exp(-math.sqrt(1e-8))) < 0.0002, 'at fixed a*=1, g_b=y ->0, nu(y)*g_b ->0')
# VI-C curvature terminal equalities and normalized a0.
c=299792458.;Lambda=1.2835e-52
val=c*c*math.sqrt(2*Lambda)/(4*math.pi)
test('VIC-a0-4pi-numerical',abs(val/1e-10-1.146)<0.001, f'a0={val:.13e} m/s^2')
U=7.;R56sq=U*(137.0**-7); C56=R56sq
test('VIC-terminal-identity',C56==R56sq and abs(math.sqrt(C56)-math.sqrt(R56sq/U))>1e-18,'C56=R56^2; dividing by U changes value')
# VII-C exact transfer contraction on whole ground complement.
E=1.3;t0=.9;T=np.diag([1.,1.,math.exp(-t0*E)])
Omega=np.array([1.,0.,0.]);P0=np.diag([1.,1.,0.]);Q=np.eye(3)-P0
normexc=np.linalg.norm(T@Q,ord=2)
normomega=np.linalg.norm(T@(np.eye(3)-np.outer(Omega,Omega)),ord=2)
test('VIIC-degenerate-ground-bound',abs(normexc-math.exp(-t0*E))<1e-12 and abs(normomega-1)<1e-12,'rank-2 P0; full-ground norm e^-tg while Omega^perp norm 1')
# VII-D nonorthogonal primitive channels, support=union and finite transfer eigenvalues <=1.
e1=np.array([1.,0.,0.]);plus=np.array([1/math.sqrt(2),1/math.sqrt(2),0.])
P1=np.outer(e1,e1);P2=np.outer(plus,plus);S=P1+P2
w,V=np.linalg.eigh(S);supp=V@np.diag((w>1e-9).astype(float))@V.T
H=np.diag([0.,0.,2.]);K=supp@np.diag([1.,1.,math.exp(-2.)])@supp
keigs=np.linalg.eigvalsh(K)
test('VIID-projection-join',np.linalg.norm(supp@supp-supp)<1e-12 and np.linalg.norm(supp@H-H@supp)<1e-12 and max(keigs)<=1+1e-12 and min(keigs)>=-1e-12,'two overlapping reducing channels, support sum is projection; K contracts')
test('VIID-original-counterexample',np.linalg.eigvalsh(S@S)[-1]>1.1,'Original sum S of nonorthogonal projections produces norm >1 with H=0')
res={'scope':'selected finite/mathematical issue controls only; no physical occurrence or global theorem certification','tests':r,'passed':sum(i['passed'] for i in r),'total':len(r)}
path=Path('RepairVerification-v1_1.json');path.write_text(json.dumps(res,indent=2))
print('PASSED',res['passed'],'/',res['total'])
for q in r:print(('OK ' if q['passed'] else 'FAIL ')+q['check'])
