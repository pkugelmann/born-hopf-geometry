# Born–Hopf Geometry — source/proof-chain repair, batch 4 (v1.4)

**Date:** 13 November 2026  
**Input releases:** Papers `v2.374`, DAG Atlas `v1.126`, ProofChainAudits `v1.44`.  
**Output releases:** Papers `v2.375`, DAG Atlas `v1.127`, ProofChainAudits `v1.45`.  
**Scope:** 15 original audit finding IDs in three target papers (III-C, IV-C, V-B), including source corrections and precise conditional theorem statements. This is **not** a new whole-paper audit or physical-constructor/observable closure.

## Result summary

- **Paper III-C**: `Paper3C-ProtectedHierarchy-v1_181.tex` — three findings addressed.
- **Paper IV-C**: `Paper4C-TechnicalMaterial-v1_43.tex` — five findings addressed.
- **Paper V-B**: `Paper5B-TerminalSpectrum-v5_193.tex` — seven findings addressed.
- **Independent/scoped checks**: **57/57 passed** in `Proofs/Paper00-AuditRepairBatch4-v1_1-verify.py`, including finite counterexamples and positive controls. This excludes any claim of a complete E1/E3/E4 re-audit.
- All three changed TeX files compile into PDFs, with zero LaTeX errors and zero unresolved bibliography citations in their final runs. Standalone cross-paper AUX-reference warnings persist and are **not** described as absent.

## Source edits by original audit finding

| Finding ID | Source correction | Mathematical disposition and remaining condition |
|---|---|---|
| `BH-G-000102` (IV-C) | The approximate-microcausality theorem now includes a **word-level occupation** estimate, or a constructive total-occupation margin `n ≤ N-d_N` with `d_N` covering *all* factors in both ordered products. The proof now expands before compression. | Elementary compressed CCR defects can vanish although higher-degree commutators fail. The sufficient occupation margin fixes this inference; source-selected refinement and dynamical locality remain separate hypotheses. |
| `BH-G-000103` (IV-C) | The instantaneous Nambu/defect law uses `m ∈ C³`, `ell ∈ C¹`, and `Omega_eff² > 0` on the differentiated interval. | Guarantees `Omega_eff ∈ C¹`; excludes `ell(t)=1+|t|` at the cusp. Does not construct a cosmic physical mode. |
| `BH-G-000104` (IV-C) | Removed unrestricted recurrence for time-dependent finite unitary blocks. | Autonomous finite unitary evolution has approximate return; arbitrary nonautonomous drive need not. Kinetic/Markov limit remains independent. |
| `BH-G-000105` (IV-C) | Interference disappearance for one detector effect is separated from state dephasing. | Path-diagonal POVM can suppress observed cross terms in a coherent state; absence for all effects characterizes removal of off-diagonal blocks. |
| `BH-G-000106` (IV-C) | The strict-negative multimode first-cumulant theorem explicitly requires at least one nonzero coefficient. | The all-zero case is `Q=0`, characteristic function 1 and all positive cumulants zero. |
| `BH-IIIC-ALTMEASURE-001` (III-C) | The alternative regularization examples now include determinant exponent/field measure and expressly are non-exhaustive. | The established REG uniqueness proves another value changes a defining clause, not an exhaustive catalogue of how. REG₀ finite part unchanged. |
| `BH-IIIC-DEPTHARG-002` (III-C) | Defined the depth-variable character `hat chi(q)` distinct from `chi(tau)` and explicit hits `tau_j=-log(1-j/7)`. Rebound all scalar-level and reflection displays to `hat chi(j)`. | Exact depth and reflection identities reproduced independently. The terminal `j=7` is a limit as `tau → ∞`, not finite flow time 7. |
| `BH-IIIC-G25PROMOTION-003` (III-C) | Removed promotion of a generated **local** PCAD/Clifford boundary germ to an already-constructed physical same-action `B48 → J_partial` source/trace. | Schur pullback remains valid *if* the physical source, stationary boundary and owner-preserving port are supplied. Actual physical K48 response not certified by the local germ alone. |
| `BH-G-000110` (V-B) | Distinguished an equivariant singular-value comparison half-line from admissible structural/physical quotient members. Updated integrated/corollary summaries. | Physical non-singleton follows only if at least two inequivalent maps are **admissible and role-extendible**. No source-matched witness established in this batch. |
| `BH-G-000111` (V-B) | Corrected raw bridge subtuple from retired `H_norm` to actual historical `H_comp`, including sufficiency, minimality and ownership table. | Consistent source type; optional scalar comparison coordinate does not become a native scalar vacuum/action selector. |
| `BH-G-000112` (V-B) | Separated `K_p=6/R_mom²` from `U=(3/pi)K_p=18/(pi R_mom²)` on existing `CELL_{K→U}` and scoped the `M_P` radius rewrite accordingly. | Factor corrected; conditional cell action/geometry identity **not independently discharged**. Neutral U-owned formulas preserved. |
| `BH-G-000114` (V-B) | Two charged Koide-shell intersections are asserted on anchored `REG₀`, with local persistence via transversality, not over the whole positive REGσ family. | Two REG₀ roots and nonzero derivatives independently checked. A generic positive scheme can lack both; global two-root claim withdrawn. |
| `BH-G-000115` (V-B) | Added role-column Gram/polar-frame hypothesis for identifying Hopf geometric relation rays with post-polar charged-current rays. Physical-current implication is now conditional, while geometric orientation remains exact. | Explicit 3×3 counterexample: polar normalization rotates a raw muon ray to `(-g_e+2g_mu)/sqrt(5)`. Actual native source-column Gram certificate remains open. |
| `BH-G-000116` (V-B) | Reconciled integrated theorem/status table with current K56 harmonic branch: positive radical operator remains **historical comparison**, no current physical neutral replacement proven. | Historical mathematics retained; physical K56 spectral selector and role source unresolved. |
| `BH-G-000117` (V-B) | Added nonzero beta/integrable-ratio condition to the coupling-variable quark RGE integral and a universally typed log-scale ODE integral. | At beta zero with nonzero gamma, mass can run while coupling-based integral is undefined. Formula valid on declared change-of-variable path. |

## Independent mathematical/adversarial controls

The 57 executable checks include: (a) a degree-four finite CCR identity below the occupation margin and an in-domain boundary counterexample where the elementary compressed CCR defect vanishes; (b) nonsmooth positive frequency and finite nonautonomous no-return examples; (c) a coherent two-path state whose diagonal detector suppresses the interference readout; (d) explicit nonzero and all-zero multimode cumulants; (e) each six finite time-to-depth hits and each reflected depth product; (f) momentum-curvature and Planck-radius factor checks; (g) both REG₀ charged roots and their transverse derivative signs; (h) polar-normalizer failure/success on non-diagonal/diagonal Gram frames; (i) exact beta-zero and beta-nonzero quark-flow controls; and (j) source-label preservation for the three changed manuscripts.

These are local E3/E4 finite/calculus controls and some E0 source guards. They do **not** certify existence, uniqueness or physical occurrence of any missing framework constructor.

## Outstanding claims and next proof obligations

1. **III-C physical boundary promotion:** produce the actual same-action stationary boundary action, source trace and owner-preserving `B48 → J_partial` word. Only then infer a physical K48 Hessian from the conditional Schur theorem.
2. **IV-C continuum microcausality:** choose a licensed occupation-margin refinement, demonstrate uniform polynomial norm bounds, spatial localizer leakage and independent DLOC transport. The theorem's mathematical sufficient condition is repaired, not demonstrated for the eventual physical refinement.
3. **V-B admissible quotient:** exhibit at least two fully typed compatible terminal maps (and role extensions) before claiming a physically non-singleton quotient.
4. **V-B charged source:** compute or certify the actual generated role-column Gram/polar frame, rather than identifying an unnormalized Hopf relation ray with a normalized current eigenray.
5. **V-B physical K56:** derive the selected current neutral rank/energy/source operator. No historical radical comparison shall be counted as this closure.
6. **Upstream `CELL_{K→U}` and observable interfaces:** inherit their original conditions; no new axiom or automatic realization has been added.

## Release/check policy

The new audit addenda preserve the previous audit text under explicit historical headings; past OPEN/UNRESOLVED statuses are not silently upgraded to VERIFIED. The historical theorem DAG and combined material edges are reused without changes; a current source anchor map and repair overlay identify exact corrections and line shifts. Current-source compatibility and full ZIP integrity are checked separately from mathematical validation. 
