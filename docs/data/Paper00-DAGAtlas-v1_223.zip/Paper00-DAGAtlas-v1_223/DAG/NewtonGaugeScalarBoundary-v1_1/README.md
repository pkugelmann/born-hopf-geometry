Source-anchored gauge/scalar boundary algebra, localizer and source-port checks. Bounded evidence only. See Findings.json and ConditionalGates.json.
