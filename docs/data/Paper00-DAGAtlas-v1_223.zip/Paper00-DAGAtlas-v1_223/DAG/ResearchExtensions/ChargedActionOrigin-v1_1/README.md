# Charged action-origin typed frontier v1_1

Only existing source claims and conditional relationships are represented. The geometry-to-physical-action constructor edge is missing and must not be used as a proof path. The canonical TheoremDAG is deliberately unchanged; older E3/E4 audits remain their original historical scopes.
