#!/usr/bin/env python3
"""Paper00-GraphClosureDiscovery-v1_6: exact finite group/core-pair/two-shell verification.

All matrix equalities involving the 25D operator representations are verified in
SymPy rational arithmetic; independent native 600-cell coordinates are checked.
No claim of occurring physical channel, particle decay vertex, clock or detector.
Run from anywhere: python Paper00-GraphClosureDiscovery-v1_5.py
"""
from collections import Counter
import hashlib
import itertools
import json
from pathlib import Path
import sympy as s

ROOT=Path(__file__).resolve().parent
src=json.loads((ROOT/'inputs'/'exceptional_600cell_instance.json').read_text())
r25=json.loads((ROOT/'inputs'/'twisted25_v127_instance.json').read_text())
V={v['id']:tuple(tuple(x) for x in v['qcoords']) for v in src['vertices']}
Vin={q:i for i,q in V.items()}
assert len(V)==len(Vin)==120

def add(a,b):return a[0]+b[0],a[1]+b[1]
def neg(a):return -a[0],-a[1]
def fm(a,b):return a[0]*b[0]+5*a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def qm(a,b):
 x,y,z,w=a;u,v,k,t=b
 z0=[add(add(fm(x,u),neg(fm(y,v))),add(neg(fm(z,k)),neg(fm(w,t)))),
     add(add(fm(x,v),fm(y,u)),add(fm(z,t),neg(fm(w,k)))),
     add(add(fm(x,k),neg(fm(y,t))),add(fm(z,u),fm(w,v))),
     add(add(fm(x,t),fm(y,k)),add(neg(fm(z,v)),fm(w,u)))]
 assert all(a%4==0 and b%4==0 for a,b in z0)
 return tuple((a//4,b//4) for a,b in z0)
def conj(q):return(q[0],)+tuple(neg(z) for z in q[1:])
M=[[Vin[qm(V[i],V[j])] for j in range(120)] for i in range(120)]
e=Vin[((4,0),(0,0),(0,0),(0,0))]
minus=Vin[((-4,0),(0,0),(0,0),(0,0))]
inverse=[Vin[conj(V[i])] for i in range(120)]
assert all(M[i][inverse[i]]==e for i in range(120))

# Five Q8s from order-four elements; subgroup normalizers are exactly five 2Ts.
order4=[g for g in range(120) if V[g][0]==(0,0)]
assert len(order4)==30
QQ=set()
for i,j in itertools.combinations(order4,2):
 k=M[i][j]
 if k not in order4:continue
 q=tuple(sorted({e,minus,i,j,k,M[minus][i],M[minus][j],M[minus][k]}))
 assert len(q)==8 and all(M[x][y] in q for x in q for y in q)
 QQ.add(q)
QQ=sorted(QQ)
assert len(QQ)==5 and len(set().union(*[set(q)-{e,minus} for q in QQ]))==30
Qindex={q:i for i,q in enumerate(QQ)}
perms={}
for g in range(120):
 perms[g]=tuple(Qindex[tuple(sorted(M[M[g][h]][inverse[g]] for h in Q))] for Q in QQ)
 assert sorted(perms[g])==list(range(5))
normalizers=[sum(perms[g][i]==i for g in range(120)) for i in range(5)]
assert normalizers==[24]*5
assert all(perms[M[g][h]]==tuple(perms[g][perms[h][i]] for i in range(5))
           for g in range(120) for h in range(120))

# Two distinguished five-cycle shells. The first is the native 600-cell edge shell.
sh={'nearest':sorted(g for g in V if V[g][0]==(1,1)),
    'f40':sorted(g for g in V if V[g][0]==(-1,1))}
assert all(len(a)==12 for a in sh.values())
assert not (set(sh['nearest'])&set(sh['f40']))
for lab,S in sh.items():
 assert {inverse[g] for g in S}==set(S)
 for g in S:
  p=perms[g]
  assert all(p[i]!=i for i in range(5))
  assert {p[i] for i in range(5)}==set(range(5))
  assert all((lambda x: x)(p[p[p[p[p[i]]]]])==i for i in range(5))
edge={tuple(sorted((int(z['u']),int(z['v'])))) for z in src['nearest_edges']}
assert len(edge)==720
for g in V:
 assert {tuple(sorted((g,M[g][h]))) for h in sh['nearest']}<=edge
assert len(edge)==len({tuple(sorted((g,M[g][h]))) for g in V for h in sh['nearest']})

# Five core marks and ten 2-subset channels: literal quotient counts.
pairs=list(itertools.combinations(range(5),2))
pidx={x:i for i,x in enumerate(pairs)}
H=s.zeros(10,5)
for a,edgepair in enumerate(pairs):
 for i in edgepair:H[a,i]=1
J5=s.ones(5,5);J10=s.ones(10,10)
assert H.T*H==3*s.eye(5)+J5
M5_target=3*(J5-s.eye(5))
M10_target=2*J10-H*H.T
count_matrices={}
for lab,S in sh.items():
 M5=s.zeros(5,5);M10=s.zeros(10,10)
 for g in S:
  p=perms[g]
  for i,j in enumerate(p):M5[i,j]+=1
  for ai,a in enumerate(pairs):
   bi=pidx[tuple(sorted((p[a[0]],p[a[1]])))]
   M10[ai,bi]+=1
 assert M5==M5_target and M10==M10_target
 count_matrices[lab]=(M5,M10)
assert M10_target==M10_target.T
assert all(M10_target[i,j]==(0 if i==j else (1 if len(set(a)&set(b))==1 else 2))
           for i,a in enumerate(pairs) for j,b in enumerate(pairs))
P0=J10/10
Pcol=H*(H.T*H).inv()*H.T
P4=Pcol-P0
PW=s.eye(10)-Pcol
assert PW==s.eye(10)-H*H.T/3+J10/6
assert PW*PW==PW and PW*H==s.zeros(10,5)
assert (s.trace(P0),s.trace(P4),s.trace(PW))==(1,4,5)
K10=M10_target/12
assert K10==P0-P4/4
assert K10*PW==s.zeros(10,10)
for n in range(1,7):assert K10**n==P0+(-s.Rational(1,4))**n*P4

# Electrical resistance of the native pair transport graph, no introduced weights.
Lplus=P4/15+PW/12
assert (12*s.eye(10)-M10_target)*Lplus==s.eye(10)-P0
res_counts=Counter()
for ai,a in enumerate(pairs):
 for bi,b in enumerate(pairs):
  if bi<=ai:continue
  R=s.factor(Lplus[ai,ai]+Lplus[bi,bi]-2*Lplus[ai,bi])
  shared=len(set(a)&set(b))==1
  assert R==(s.Rational(7,45) if shared else s.Rational(13,90))
  res_counts[('shared' if shared else 'disjoint',str(R))]+=1
# Mean hitting time under the stochastic kernel, for all ordered pairs.
K=K10
hit_counts=Counter()
for b in range(10):
 ids=[i for i in range(10) if i!=b]
 v=(s.eye(9)-K.extract(ids,ids)).inv()*s.ones(9,1)
 for pos,a in enumerate(ids):
  share=len(set(pairs[a])&set(pairs[b]))==1
  expected=s.Rational(28,3) if share else s.Rational(26,3)
  assert v[pos]==expected
  hit_counts[('shared' if share else 'disjoint',str(v[pos]))]+=1

# The 5D module W=ker H^T is an intrinsic rational model of the quintet.
W=s.Matrix.hstack(*H.T.nullspace())
assert W.shape==(10,5) and H.T*W==s.zeros(5,5)
Left=(W.T*W).inv()*W.T
assert W*Left==PW
char_counts=Counter()
for g,p in perms.items():
 fixedmarks=sum(i==p[i] for i in range(5))
 fixedpairs=sum(set(edgepair)=={p[edgepair[0]],p[edgepair[1]]} for edgepair in pairs)
 chi=int(fixedpairs-fixedmarks)
 a,b=V[g][0]
 t=(s.Integer(a)+s.Integer(b)*s.sqrt(5))/4
 assert s.simplify(16*t**4-12*t**2+1)==chi
 char_counts[chi]+=1
assert char_counts==Counter({0:48,-1:40,1:30,5:2})
# The signed conference Gram of the 10 projected coordinate lines is forced.
Gline=2*PW
Ssign=3*(Gline-s.eye(10))
assert Gline*Gline==2*Gline and Ssign*Ssign==9*s.eye(10)
for a in range(10):
 for b in range(10):
  assert Gline[a,b]==(1 if a==b else (-s.Rational(1,3) if len(set(pairs[a])&set(pairs[b])) else s.Rational(1,3)))
triple_signs=Counter()
for a,b,c in itertools.combinations(range(10),3):
 prod=Gline[a,b]*Gline[b,c]*Gline[c,a]
 degs=sorted(Counter(x for e2 in (pairs[a],pairs[b],pairs[c]) for x in e2).values(),reverse=True)
 expected=s.Rational(1,27) if degs==[2,2,1,1] else -s.Rational(1,27)
 assert prod==expected
 triple_signs[str(prod)]+=1
assert triple_signs==Counter({'1/27':60,'-1/27':60})

# Class-averaged random-unitary superoperators on End(W), exact rational 25x25.
Phi={}
for lab,S in sh.items():
 out=s.zeros(25,25)
 for g in S:
  P=s.zeros(10,10)
  p=perms[g]
  for a,e2 in enumerate(pairs):
   P[pidx[tuple(sorted((p[e2[0]],p[e2[1]])))],a]=1
  R=Left*P*W
  Ri=Left*P.T*W
  assert R*Ri==s.eye(5)
  out+=s.kronecker_product(Ri.T,R)
 Phi[lab]=out/12
I=s.eye(25)
A=Phi['nearest'];B=Phi['f40'];C=(A+B)/2;D=A-B
assert A*B==B*A and C*D==D*C
assert C*D==D/6 and D**3==s.Rational(5,9)*D
assert C*(C-I)*(C-I/6)*(C+I/4)==s.zeros(25,25)
Pr1=s.Rational(24,25)*(C-I/6)*(C+I/4)*C
Pr33=s.Rational(9,5)*D**2
Pr4=-s.Rational(192,25)*(C-I)*(C-I/6)*C
Pr5=24*(C-I)*(C-I/6)*(C+I/4)
for P,rank in [(Pr1,1),(Pr33,6),(Pr4,8),(Pr5,10)]:
 assert P**2==P and s.trace(P)==rank
assert Pr1+Pr33+Pr4+Pr5==I
assert A==Pr1+Pr33/6+D/2-Pr4/4
assert B==Pr1+Pr33/6-D/2-Pr4/4
assert D*Pr1==s.zeros(25,25) and D*Pr4==s.zeros(25,25) and D*Pr5==s.zeros(25,25)
# Exact algebraic triplet projectors are proved without expanding 625
# algebraic-number entries: Q=(9/5)D^2, QD=D, D^2=(5/9)Q imply
# T_±=(Q ± (3/sqrt(5))D)/2 are orthogonal idempotents.
assert Pr33*D==D and D*Pr33==D
assert D**2==s.Rational(5,9)*Pr33
assert s.trace(D)==0
# Rational part of both projector idempotency and mutual orthogonality:
assert Pr33**2==Pr33 and D**2==s.Rational(5,9)*Pr33
assert s.trace(Pr33)==6
# Their traces are both exactly three; eigenvalue ±sqrt(5)/3 follows D^3=5D/9.
# Center scalar (identity) and no fixed traceless right modes.
assert s.trace(A)==s.trace(B)==0
assert A*Pr1==Pr1 and B*Pr1==Pr1
# Restricted 10-channel effects are insensitive to the difference D.
# Define line projectors from W^T basis. The ten rank-one effects span 1+4+5.
line_effects=[]
for a in range(10):
 x=Left*s.eye(10)[:,a]
 # vector in rational W-coordinates; dual/projector uses induced Gram (W^T W)
 # Q_a = 2 P_W e_a e_a^T P_W, normalized to trace 1 on W.
 z=Left*PW[:,a] # W-coordinates of projected position
 row=(PW[a,:]*W)
 E=2*z*row
 assert s.trace(E)==1 and E*E==E
 line_effects.append(E)
assert len(line_effects)==10
# Operator vec col (all rational); verify shell superoperator annihilates differences.
for E in line_effects:
 vec=s.Matrix([E[i,j] for j in range(5) for i in range(5)])
 assert D*vec==s.zeros(25,1)
assert s.Matrix.hstack(*[s.Matrix([E[i,j] for j in range(5) for i in range(5)]) for E in line_effects]).rank()==10


# --- v1.6 exact closures: no independent F40 shell, single-shell algebra,
#     canonical covariant coefficient-frame POVM, 15D pair-line blind sector,
#     and a rigorous dynamics non-identification witness. ---

# GC27: power-map bijection from native shell to F40 shell.
assert {M[g][g] for g in sh['nearest']}==set(sh['f40'])
assert len({M[g][g] for g in sh['nearest']})==12

def power(g,n):
    y=e
    for _ in range(n):y=M[y][g]
    return y
assert all(power(g,5)==minus and power(g,10)==e for g in sh['nearest'])
assert all(power(g,5)==e for g in sh['f40'])
assert all(perms[power(g,5)]==tuple(range(5)) for g in sh['nearest'])

# GC28: first twirl algebra generates the entire second twirl and all
# irreducible sector projectors. Exact rational polynomial identities.
Q6=-s.Rational(648,5)*A*(A-I)*(A-I/2)*(A+I/4)
B_from_A=-s.Rational(432,5)*A**4+s.Rational(576,5)*A**3-s.Rational(81,5)*A**2-s.Rational(58,5)*A
assert B_from_A==B
assert Q6==Pr33 and Q6**2==Q6 and s.trace(Q6)==6
assert A*(A-I)*(A+I/4)*(A**2-A/3-I/9)==s.zeros(25,25)
D_from_A=(2*A-I/3)*Q6
assert D_from_A==D
assert Pr1+Pr33+Pr4+Pr5==I

# GC29/30: exact full 60-orbit equivariant frame. Work in a rational,
# nonorthonormal W-basis and use its *metric-adjusted* Hilbert-Schmidt dual;
# no inappropriate Euclidean transpose assumption.
vec=lambda X:s.Matrix([X[i,j] for j in range(5) for i in range(5)])
representations={}
for g,p in perms.items():
    if p in representations:continue
    T=s.zeros(10,10)
    for a,ij in enumerate(pairs):
        T[pidx[tuple(sorted((p[ij[0]],p[ij[1]])))],a]=1
    R=Left*T*W
    Rinv=Left*T.T*W
    assert R*Rinv==s.eye(5)
    representations[p]=(R,Rinv)
assert len(representations)==60
reps=list(representations.values())
full_frame=s.zeros(25,25)
for R,Rinv in reps:
    full_frame+=vec(R)*vec(Rinv.T).T
assert full_frame==12*I
# This is the covariant rank-one POVM on real/complex H25=End(V5),
# with positive operators |R><R|/12 under the Hilbert-Schmidt metric.
# Every effect has trace 5/12, sum I25.
assert all(s.trace(Rinv*R)==5 for R,Rinv in reps)

# For any normalized frame ray R_h/sqrt(5), p(g|h)=chi5(h^-1 g)^2/60.
# Verify every one of the 60*60 entries using actual group matrices.
chi=s.Matrix(60,60,lambda i,j:s.trace(reps[i][1]*reps[j][0]))
K60=s.Matrix(60,60,lambda i,j:chi[i,j]**2/60)
assert K60==K60.T and K60*s.ones(60,1)==s.ones(60,1)
assert all(K60[i,j]>=0 for i in range(60) for j in range(60))
row_distribution=Counter(str(K60[0,j]) for j in range(60))
assert row_distribution==Counter({'5/12':1,'1/60':35,'0':24})
assert all(Counter(str(K60[i,j]) for j in range(60))==row_distribution for i in range(60))
assert all(Counter(int(chi[i,j]) for j in range(60))==Counter({5:1,1:15,-1:20,0:24}) for i in range(60))
K60sq=K60*K60
assert s.trace(K60)==25 and s.trace(K60sq)==11
assert Counter((str(K60[0,j]),str(K60sq[0,j])) for j in range(60))==Counter({
    ('5/12','11/60'):1,('1/60','17/900'):15,('1/60','1/50'):20,('0','1/180'):24})
# Exact character-square decomposition in A5:
# chi5^2=chi1+chi3+chi3prime+2 chi4+2 chi5.
# The eigenvalues of convolution by chi5^2/60 on R[A5] are m_lambda/d_lambda.
# Distinct eigenvalues: 1^1,(1/2)^16,(2/5)^25,(1/3)^18.
assert s.trace(K60)==(1+16*s.Rational(1,2)+25*s.Rational(2,5)+18*s.Rational(1,3))
assert s.trace(K60sq)==(1+16*s.Rational(1,4)+25*s.Rational(4,25)+18*s.Rational(1,9))
# Third independent exact check: polynomial annihilation, no 60x60 rank call.
# Check eigenvalues numerically independently; theoretical spectrum is exact via character theory.
import numpy as np
ke=np.linalg.eigvalsh(np.asarray(K60,dtype=float))
for val,mult in [(1.0,1),(0.5,16),(0.4,25),(1/3,18)]:
    assert int(np.count_nonzero(np.abs(ke-val)<1e-9))==mult

# GC31: exact 10D visible / 15D blind decomposition for ten line readouts.
# Here each Q_a is a rank-one projector on V5 (not a rank-five T_ij
# on H25). They are the 10 unit-trace line effects of the v1.5 report.
assert len(line_effects)==10
tracegram=s.Matrix(10,10,lambda i,j:s.trace(line_effects[i]*line_effects[j]))
assert tracegram==s.Rational(8,9)*s.eye(10)+J10/9
assert (s.Rational(9,8)*s.eye(10)-J10/16)*tracegram==s.eye(10)
assert sum(line_effects,s.zeros(5,5))==2*s.eye(5)
identity_vec=vec(s.eye(5))
Pvis=sum((vec(Ea)*vec(Ea.T).T for Ea in line_effects),s.zeros(25,25))*s.Rational(9,8)-identity_vec*identity_vec.T/4
Pdark=I-Pvis
assert Pvis**2==Pvis and s.trace(Pvis)==10
assert Pdark**2==Pdark and s.trace(Pdark)==15
assert Pvis*Pdark==s.zeros(25,25)
assert Pvis*A==A*Pvis and Pvis*B==B*Pvis
assert Pvis*D==s.zeros(25,25) and D*Pvis==s.zeros(25,25)
assert [(int(s.trace(Pvis*P)),int(s.trace(Pdark*P))) for P in [Pr1,Pr33,Pr4,Pr5]]==[(1,0),(0,6),(4,4),(5,5)]
# Thus Pdark has A5 type 3+3'+4+5, matching the existing Petersen sl4
# carrier as a representation (not an asserted canonical intertwiner).

# GC32: uniform nearest-shell one-step marginals do not determine
# multi-time dynamics.  IID generators and one reused generator have
# identical first steps but distinct second returns. Both are invariant.
K5=M5_target/12
K10=M10_target/12
assert all(K5[i,i]==0 and (K5*K5)[i,i]==s.Rational(1,4) for i in range(5))
assert all(K10[i,i]==0 and (K10*K10)[i,i]==s.Rational(1,8) for i in range(10))
# For a fixed generator drawn once and reused, second displacement is
# the square shell, which reproduces K5/K10 and has no diagonal.
assert all(count_matrices[lab][0]/12==K5 and count_matrices[lab][1]/12==K10 for lab in sh)

cert16={
  'version':'Paper00-GraphClosureDiscovery-v1_6',
  'source_scope':'Paper1B-v1_18; 2I exact 600-cell coordinates; native 5D A5 quintet; v1.5 exact source and certificate',
  'inputs_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'inputs').iterdir() if p.is_file()},
  'GC27':{'nearest_shell_size':12,'squares_bijective_to_f40':True,
          'nearest_power5':'central -1','nearest_power10':'identity','f40_power5':'identity'},
  'GC28':{'second_shell_operator':'B=(-432 A^4+576 A^3-81 A^2-58 A)/5',
          'combined_triplet_projector':'Q6=-648 A(A-I)(A-I/2)(A+I/4)/5',
          'native_minimal_polynomial':'A(A-I)(A+I/4)(A^2-A/3-I/9)=0',
          'exact_full_25by25_replay':True},
  'GC29':{'covariant_POVM_outcomes':60,'outcome_trace':'5/12',
          'frame_identity':'sum |rho(g)><rho(g)|=12 I25',
          'full_25by25_rational_HS_check':True,
          'not_informationally_complete_for_all_25D_density_operators':True},
  'GC30':{'relative_character_values_counts':{'5':1,'1':15,'-1':20,'0':24},
          'conditional_probabilities':dict(row_distribution),
          'zero_fivecycle_outcomes':24,
          'convolution_kernel_spectrum':{'1':1,'1/2':16,'2/5':25,'1/3':18},
          'K2_fivecycle_probability':'1/180','K2_trace':'11'},
  'GC31':{'ten_line_effects_Gram':'(8/9)I+(1/9)J',
          'visible_rank':10,'blind_rank':15,
          'visible_A5_type':'1+4+5','blind_A5_type':'3+3prime+4+5',
          'both_shells_identical_on_visible_readout':True,
          'Pvis_is_exact_idempotent':True},
  'GC32':{'same_one_step_kernels':True,
          'independent_2step_five_mark_return':'1/4','reused_2step_five_mark_return':'0',
          'independent_2step_ten_pair_return':'1/8','reused_2step_ten_pair_return':'0',
          'native_vertex_reused_power5':'antipode','five_mark_reused_power5':'identity'},
  'source_owned_prior_results':['p1:thm:v344-induced-hurwitz-quintet',
                                'p1:thm:v344-twisted-25-gram',
                                'p1:thm:v342-class-frame-three-cycle-tomography',
                                'p1:thm:v345-f40-edge-regular'],
  'physical_occurrence':False,
  'remaining_owner':['physical use of coherent map/readout','mass-energy/particle-state embedding',
                     'time-unit conversion','multi-time independence versus generator re-use']}
(ROOT/'Paper00-GraphClosureDiscovery-v1_6.json').write_text(json.dumps(cert16,indent=2,sort_keys=True)+'\n')
print('PASS v1_6 exact: power shell, 25D single-generator algebra, 60-outcome POVM, 24 zero outcomes, rank15 blind complement, multi-time no-go')
print('cert:',ROOT/'Paper00-GraphClosureDiscovery-v1_6.json')
