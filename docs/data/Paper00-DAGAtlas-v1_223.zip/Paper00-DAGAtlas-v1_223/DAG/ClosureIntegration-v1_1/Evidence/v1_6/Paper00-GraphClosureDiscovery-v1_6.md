# Born–Hopf Geometry — native-shell power closure, coherent frame readout, and exact observer boundary (v1.6)

**Release:** `Paper00-GraphClosureDiscovery-v1_6`, 19 November 2026.  **Epistemic status:** exact, independently replayable finite-mathematical derivations **proposed for source/DAG integration**. The supplied **authoritative archives were inspected and not edited**. No physical occurrence of an interaction, mass/decay vertex, experimental measurement, preparation, clock or irreversible process is claimed.

## 0. Original sources and what is *not* being rediscovered

Source inspected: `Paper00-PapersMinimal-v3_040(1).zip/Paper1B-ExceptionalGeometry-v1_18.tex`; `Paper00-S3StructureNetwork-v1_40(1).zip/data/exceptional_600cell_instance.json`; `Paper00-DAGAtlas-v1_190(1).zip`; and the predecessor `Paper00-GraphClosureDiscovery-v1_5` report and exact verifier.

Already present in Paper I-B are: the quaternionic nearest-shell spectral theorem `p1:thm:exceptional-nearest-shell-spectra`; the induced quintet `p1:thm:v344-induced-hurwitz-quintet`; the **exact source-proved** coefficient frame `F†F=24 I_25` in `p1:thm:v344-twisted-25-gram`; the F40 shell and five-core transfer theorem `p1:thm:v345-f40-edge-regular`; the three-cycle class-frame theorem `p1:thm:v342-class-frame-three-cycle-tomography`; and the class contrast `p1:prop:v343-fivefold-signed-contrast`. In v1.5, both shell twirls and their spectra were established on `End(V5)` as a proposed extension. The six results below are **new dependency links, derived readouts, exact projector compression and nonidentification witnesses**, not attempts to reclassify those established source theorems as new.

We write `G=2I`, `S_1={q∈G:Re(q)=(1+√5)/4}`, `S_2={q∈G:Re(q)=(√5−1)/4}`. Both shells have twelve elements. The positive, real five-dimensional icosahedral quintet is `V5`, centre-even under `−1∈2I`, with character `χ5=U4(Re q)`; its matrix coefficient block is 25-dimensional. Let `H=End(V5)` equipped with its Hilbert–Schmidt inner product and `Adρ(q): X↦ρ(q)Xρ(q)^{-1}`.

## GC-27. F40 is not an independent twelve-element input

**Statement.** The native nearest-shell power map is a bijection onto the F40 shell:

\[
\boxed{S_2=\{q^2:q\in S_1\},\quad |S_1|=|S_2|=12.}
\]

For a unit quaternion, `Re(q²)=2 Re(q)²−1`, so squaring takes the defining height of `S_1` to the height of `S_2`. The group-class data show the image is all of `S_2`: the twelve distinct elements of the near class square bijectively onto the twelve-element F40 class. An **independent exact multiplication-table check** establishes cardinality 12 and full set equality, not merely height inclusion.

Moreover each `q∈S_1` has order 10 with `q^5=−1, q^10=1`, whereas each `q²∈S_2` has order five. Thus the full 120-vertex geometry retains a central sign after five repeated nearest-shell steps, but every centre-even quintet/core-label readout identifies that sign with the identity. **Removed input:** F40-shell support need not be supplied separately once the native quaternion shell is fixed. This does not force using F40 as a physical process.

## GC-28. The coherent 25D operator algebra needs only one shell

Define the mathematically specified normalized class averages

\[
 A=\frac1{12}\sum_{q\in S_1}\operatorname{Ad}_{\rho_5(q)},\qquad
 B=\frac1{12}\sum_{q\in S_2}\operatorname{Ad}_{\rho_5(q)}.
\]

The real `A5` decomposition is

\[
\operatorname{End}(V_5)\cong \mathbf1\oplus\mathbf3\oplus\mathbf3'\oplus2\mathbf4\oplus2\mathbf5.
\]

The `A` eigenvalues on these sectors are respectively
`1`, `a=(1+√5)/6`, `b=(1−√5)/6`, `−1/4`, `0` (with respective multiplicities `1,3,3,8,10`). The `B` eigenvalues exchange `a` and `b` and leave the other three eigenvalues unchanged. Both are central class averages and diagonal on the same isotypic blocks. Therefore the unique degree-at-most-four polynomial interpolating `f(1)=1,f(−1/4)=−1/4,f(0)=0,f(a)=b,f(b)=a` must satisfy `B=f(A)`:

\[
\boxed{B=\frac{-432A^4+576A^3-81A^2-58A}{5}.}
\]

The exact matrix identity, not merely its spectrum, was checked on the full rational 25×25 representation. It follows that

\[
\boxed{A(A-I)(A+\tfrac14I)(A^2-\tfrac13A-\tfrac19I)=0,}
\]

and the six-dimensional paired-triplet projector is the rational polynomial

\[
\boxed{P_6=-\tfrac{648}{5}A(A-I)(A-\tfrac12I)(A+\tfrac14I),\quad P_6^2=P_6,\ \mathrm{tr}P_6=6.}
\]

The original two-shell contrast is reconstructible from the single shell:

\[
\boxed{D=A-B=(2A-\tfrac13I)P_6},\quad
P_{3,\pm}=\frac12\left(P_6\pm\frac3{\sqrt5}D\right).
\]

These final rank-three idempotents use the actual positive real embedding of the native `√5` coordinates; they require no preselected triplet vectors. The algebra `Q[A]` has the irreducible degree-two factor `x²−x/3−1/9`: over `Q`, only the combined six-dimensional idempotent is rational; over `Q(√5)` the two rank-three idempotents split. **Removed inputs:** independent second-shell adjoint average and independent triplet-splitting operator within this class-average algebra. **Not removed:** selection of the class-average channel as physically occurring dynamics.

**Important non-equivalence.** Because the same quaternion is squared before averaging, `B=(1/12)∑_q Adρ(q)^2`; generally `B≠A²`, the latter corresponding to two *independently chosen* quaternion generators. The exact comparison is treated in GC-32.

## GC-29. A natural positive 60-outcome POVM on the coefficient carrier

Paper I-B already proves `F†F=24I25` on the full 120-element group. Since `−1` acts trivially in `V5`, each coefficient row is duplicated centrally. On `A5` we therefore have, by Schur orthogonality,

\[
\boxed{\sum_{g\in A_5}|v_g\rangle\langle v_g|=12 I_{25},\quad v_g=\operatorname{vec}(\rho_5(g)),\quad\|v_g\|^2=5.}
\]

The 60 positive rank-one effects

\[
\boxed{E_g=\tfrac1{12}|v_g\rangle\langle v_g|,\qquad \sum_g E_g=I_{25},\quad \operatorname{tr}(E_g)=5/12}
\]

form a normalized POVM on the **mathematical coefficient Hilbert space** `H=End(V5)` (not a POVM on the original five-dimensional `V5`). They are not 60 independent projectors and not claimed to be a physically occurring detector.

**Why the seed is not arbitrary within this construction:** the conjugation-fixed line in `End(V5)` is precisely `R I5` by Schur's lemma. Acting with the natural left–right `A5×A5` action on its unique normalized ray produces exactly the 60 coefficient rays `v_g`. The uniform effect coefficient is then forced by the frame identity. This is **uniqueness within the identity-orbit covariant rank-one construction**, not uniqueness among every possible POVM.

The verifier works in a rational nonorthonormal basis of `V5` and correctly uses the metric-adjusted Hilbert–Schmidt dual. Its exact result is the full 25×25 identity `Σ|v_g><v_g|=12I`.

**Completeness warning:** `Σ E_g=I25` means *POVM normalization*. Sixty outcome probabilities are **not informationally complete** for an arbitrary 25×25 complex density matrix (which has 625 real Hermitian coordinates). The 60 coefficient **vectors**, if their complex linear amplitudes are available, form a complete linear frame for the 25D vector space. Do not conflate these two statements.

## GC-30. Exact zero-outcome theorem and all spectral response weights

Prepare a normalized mathematical coefficient ray `|\psi_h⟩=|v_h⟩/√5`. The POVM gives the parameter-free conditional probabilities

\[
\boxed{p(g\mid h)=\langle\psi_h|E_g|\psi_h\rangle
=\frac{\chi_5(h^{-1}g)^2}{60}.}
\]

For each `h`, exactly one relative identity has probability `5/12`; the fifteen order-two and twenty order-three relative labels each have `1/60`; and the twenty-four relative five-cycles have **zero** probability because `χ5(5A)=χ5(5B)=0`. The complete row is stochastic: `5/12+35/60=1`. Each of the `60×60` entries is derived from exact group-matrix traces and checked. This is a **static geometric readout selection rule**, not a particle-decay prohibition.

Writing `K_{h,g}=p(g|h)` produces a symmetric positive-semidefinite stochastic matrix. The exact representation identity

\[
\chi_5^2=\chi_{\mathbf1}+\chi_{\mathbf3}+\chi_{\mathbf3'}+2\chi_{\mathbf4}+2\chi_{\mathbf5}
\]

and Schur character orthogonality give the complete central-convolution spectrum

\[
\boxed{\operatorname{spec}(K)=\{1^{(1)},(1/2)^{(16)},(2/5)^{(25)},(1/3)^{(18)}\}.}
\]

Indeed the eigenvalue on a `d_λ`-dimensional irreducible is its multiplicity `m_λ` in `5⊗5` divided by `d_λ`, with `d_λ²` occurrences in the regular representation. Exact matrix traces give `tr K=25`, `tr K²=11`; independent numerical diagonalization confirms all integer multiplicities. Conditional on defining repeated independent applications of this **static kernel** as a stochastic process, its spectral gap is `1/2` and its convergence rate is `(1/2)^n` in the operator norm on zero-mean vectors. Such repeated preparation is an extra physical/instrument rule, not entailed by the POVM alone.

The `24` first-readout zeros are not absorbing or permanent exclusions: direct exact convolution gives `K²(g,h)=1/180` whenever `h^{-1}g` has order five. For relative identity, order two, order three, order five the respective exact two-step values are `11/60`, `17/900`, `1/50`, `1/180` (with `1,15,20,24` labels).

## GC-31. The ten line effects have an exact, intrinsic 15D blind complement

Let `u_a`, `a=1,...,10`, be the normalized ten canonical projected Petersen pair lines in `V5`, and `Q_a=|u_a⟩⟨u_a|` their rank-one projectors. The projectors satisfy

\[
\boxed{\mathrm{tr}(Q_aQ_b)=\begin{cases}1,&a=b,\\1/9,&a\ne b,\end{cases}\quad \sum_{a=1}^{10}Q_a=2I_5.}
\]

The ten Gram eigenvalues are `2^(1)` and `(8/9)^(9)`, so the ten effects are exactly linearly independent as operators: their span `V_vis` has dimension 10 and its `A5` type is `1⊕4⊕5`. The **orthogonal projector in the 25D Hilbert–Schmidt operator space** is

\[
\boxed{\mathscr P_{\rm vis}(X)
=\frac98\sum_{a=1}^{10}\mathrm{tr}(Q_aX)Q_a
-\frac14\mathrm{tr}(X)I_5.}
\]

The formula follows from the exact inverse of `G=(8/9)I10+(1/9)J10`, namely `G^{-1}=(9/8)I10-(1/16)J10`. It satisfies `P_vis²=P_vis`, `rank=10`; its complement

\[
\boxed{\mathscr P_{\rm dark}=I_{\mathrm{End}(V5)}-\mathscr P_{\rm vis},\qquad \operatorname{rank}=15}
\]

is therefore forced without choosing a 2T mark, an additional 15D basis or a fitted overlap. Under *diagonal* `A5` conjugation,

\[
\boxed{\operatorname{ran}\mathscr P_{\rm dark}\cong \mathbf3\oplus\mathbf3'\oplus\mathbf4\oplus\mathbf5.}
\]

The same `A5` representation type occurs in Paper I-B's 15-dimensional Petersen `sl(4,R)` module. This establishes **representation equivalence**, not a canonical intertwiner, Lie-algebra identification, coupling to the physical 15D momentum carrier `H1`, or restoration of full `2I×2I` symmetry. Selecting diagonal conjugation changes the symmetry group relative to the unmarked two-sided action; it must not be hidden.

The two class-average operators commute with `P_vis`; all two-shell contrast lies in the dark sector:

\[
\boxed{\mathscr P_{\rm vis}(A-B)=0=(A-B)\mathscr P_{\rm vis}.}
\]

Consequently **no single-time expectation value of any combination of the ten pair-line effects can distinguish `A^n` from `B^n` at any `n`**, regardless of initial operator input, as `P_vis A^n=P_vis B^n`. A triplet-sensitive observable outside the visible sector is necessary. The exact rational verifier checks the projectors, commutation, contrast annihilation, and visible/dark spectral multiplicities `1+4+5` vs `3+3'+4+5`.

## GC-32. A sharp no-go: one-step geometry does not force Markov independence

The native class `S1` and its invariant uniform measure fix the **one-step** transport on five marks (`K5=(J5−I5)/4`) and ten pairs (`K10=(2J10−HH^T)/12`). But they do not fix a joint law of successive generators. Two fully symmetry-respecting constructions demonstrate the missing condition:

* `IID`: each step draws a new independent uniform `q_n∈S1`. The second marginal is `K5²` or `K10²`.
* `REUSED`: draw one uniform `q∈S1` and apply the same generator twice. The second marginal is its square-shell average, which equals `K5` or `K10`, not the square of the first marginal.

Every vertex/mark has exactly

\[
\boxed{\Pr_{\rm IID}(\mathrm{return\ at\ step\ 2})=1/4,\qquad
\Pr_{\rm REUSED}(\mathrm{return\ at\ step\ 2})=0}
\]

on the five-mark quotient, and respectively `1/8` versus `0` on the ten pair labels. These are exact rational checks. Both models respect the full one-step class symmetry. The reused path has quotient period five but at the 120-vertex level sends `x↦−x` after five and returns to `x` only after ten; the central sign is invisible to centre-even quintet readouts.

This is **not** a derivation of a physical random clock. It is an exact adversarial witness showing the conditional Markov/independence premise cannot be removed *from one-step group geometry and symmetry alone*. The framework needs an occurring action, or a legitimate derived dynamical independence mechanism, to choose between these processes. It would be incorrect to call either one physically necessary merely because its one-step kernel is canonical.

## Verification and exact evidence levels

The package verifier executes the entire v1.5 exact chain as a prefix, then separately checks all v1.6 identities. `GC-27` uses the literal exact quaternion multiplication table (`E3`); `GC-28` is proved independently by class-character interpolation and replayed with full rational 25×25 matrix identities (`E1+E3`); `GC-29` and `GC-30` use independently constructed 60 group matrices and the rational Hilbert–Schmidt dual (`E3`) plus character theory (`E1`); `GC-31` uses explicit rational Gram/inverse projector and isotypic trace tests (`E3`); `GC-32` uses two constructive symmetry-preserving models and exact difference calculation (`E4`). The script's separate numeric check of the 60×60 spectrum is corroboration, not the proof of the analytical character formula.

**Logical closure vs physical occurrence:** All finite mathematical statements above are proved **inside the fixed quaternionic `2I` and quintet data**. They cannot be promoted automatically to the occurrence of a particle-decay operator, a physical POVM, energy descent, irreversible time direction, seconds, branching ratios, or the physical `H1` momentum 15. The strongest new dependency removal is `GC-27–28`, eliminating the second-shell input and triplet selector. The strongest new readout consequence is the exact 60-effect coefficient POVM and its 24 coherent zeros. The main remaining physical-owner test is to derive *which* of these finite operators is produced by the actual same-action source, not to import a chosen model because it has pleasing spectral properties.
