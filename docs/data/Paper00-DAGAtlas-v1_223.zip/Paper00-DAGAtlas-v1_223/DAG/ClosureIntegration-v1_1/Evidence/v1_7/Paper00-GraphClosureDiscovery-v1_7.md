# Born–Hopf Geometry — Petersen quadratic observability, exact coherent channel discrimination and III-A solder normalization

**Release:** `Paper00-GraphClosureDiscovery-v1_7` — 19 November 2026.  
**Basis:** supplied Paper00-PapersMinimal-v3_040(1), DAGAtlas-v1_190(1), S3StructureNetwork-v1_40(1), ProofChainAudits-v1_79(1), and GraphClosureDiscovery-v1_6.  
**Status:** proposed source extensions with **replayed exact finite mathematics**, not a modification of the authoritative papers or an unconditional physical-action/decay derivation.

## 0. The precise problem and source boundary

Prior v1.6 proved the rank-ten *linear* visibility of ten projected Petersen pair-line effects and a 15-dimensional linear blind complement on the mathematical quintet. It explicitly left the mathematical production of triplet-sensitive readouts and physical occurrence open. This release **derives a canonical complete readout from the same ten line operators, with no independently selected fiducial, phase or weights**; proves exact frame stability and full Lie closure; and repairs the factor-of-two ambiguity in the Paper III-A local vector descent **as a proposed source replacement**.

### Source references, do not duplicate established results

1. **Paper I-B** `Paper1B-ExceptionalGeometry-v1_18.tex`, `p1:thm:v344-induced-hurwitz-quintet` and `p1:prop:v344-petersen-quintet-intertwiner`: the centre-even irreducible five-dimensional module `V5`, and its *five-dimensional* real realization as the rank-five projected 10-pair permutation module `P_Pet`. The exact 10-by-5 incidence formula `P_Pet=I−D^T(3I+J)^{-1}D` is already in source.
2. **Paper I-B** `p1:thm:exceptional-nearest-shell-spectra`, `p1:thm:v345-f40-edge-regular`: the two real-height quaternion shells, independently constituted as mathematical graph data. The native squared-shell relation and rational adjoint algebra were established in v1.6.
3. **Paper I-C** `p1b:thm:cartan`: relative solder `E=(theta_x−theta_p)/2`.
4. **Paper II-C** `p2:thm:canonical-transvection-bridge`, `p2c:thm:first-symbol-pairing`, `p2c:cor:compact-transvection-cotangent-germ`: evaluation `ev(X,−X)=2X`, canonical inversion-odd inverse evaluation, and frame-free local cotangent transport.
5. **Paper III-A** `p3a:cor:v187-rank-four-parent-root` and the vector-descent paragraph immediately before it; audit `BH-IIIA-G-0005`: `tau` was undefined and the inverse-dual factor of two unresolved in the source-as-printed.
6. **Paper V-C** `p5c:cor:v269-visible-primitivity` and `p5c:def:v3027-geometric-decay-certificate`: any physical promotion still requires *actual source-owned* Hamiltonian/jumps, full spin/color/clock resolvent and physical Fock/multiset/wavefunction and width interfaces.

**CRITICAL TYPING:** The present ten projectors are `Q_a=2P_Pet e_a e_a^T P_Pet` on `V5` (five-dimensional), **not** the *three-dimensional Hopf-axis* projectors also denoted `Q_{ij}=u_ij u_ij^T−I_3/3` in `p1:thm:petersen-angular-quadrupole`. Those 3D axes have a different 5/9-vs-1/9 overlap pattern and are not substituted here. Likewise `V5`, the twisted-25 coefficient carrier `End(V5)`, the separate 15D Petersen `sl4`, and the momentum carrier `H1` are distinct sorts.

## GC-33. Parameter-free 90-effect informationally complete Petersen POVM on V5

Let `a=0,...,9` enumerate the ten unordered pairs of five core labels in lexicographic order. On the rank-five real orthogonal subspace `W=im P_Pet⊂R^10`, define the source-owned projected coordinate lines

\[
Q_a=2P_{\rm Pet}e_ae_a^TP_{\rm Pet}.
\]

Since `P_Pet` is an orthogonal projection with diagonal 1/2, each `Q_a` is rank one. The known Petersen Gram gives

\[
\sum_aQ_a=2I_W,\quad Q_a^2=Q_a,\quad
\operatorname{tr}(Q_aQ_b)=1/9\quad(a\ne b).
\]

For each unordered pair `a<b`, write `C_ab=[Q_a,Q_b]` and

\[
P_{ab}={9\over8}(Q_a+Q_b-Q_aQ_b-Q_bQ_a),\qquad
J_{ab}={9\over2\sqrt2}\,iC_{ab}.
\]

Since two lines have nonzero squared inner product `1/9`, their real plane satisfies

\[
P_{ab}^2=P_{ab},\ \operatorname{tr}P_{ab}=2,\quad
C_{ab}^2=-{8\over81}P_{ab},\quad
J_{ab}^2=P_{ab},\ P_{ab}J_{ab}=J_{ab}.
\]

It follows that `R_ab^±=(P_ab±J_ab)/2` are two orthogonal rank-one *complex* projections. An exact summation using only `Σ Q=2I`, `Q_a²=Q_a` gives

\[
\sum_{a<b}P_{ab}=\frac98\left(9\sum_aQ_a-
\left[(\sum_aQ_a)^2-\sum_aQ_a\right]\right)
=\frac98(18I-2I)=18I.
\]

Hence the **90 positive effects**

\[
\boxed{E_{ab}^\pm={1\over18}R_{ab}^\pm},\qquad
\boxed{\sum_{a<b,\pm}E_{ab}^\pm=I_W}
\]

form an intrinsically normalized, full-five-label-covariant mathematical POVM. It uses the existing complex involution `i` and both signs; exchanging an arbitrary sign convention on the original lines does not change the outcome set.

### Exact completeness certificate

The 45 pair planes are real symmetric; the 45 `iC_ab` are imaginary antisymmetric. They span complementary Hermitian sectors of real dimensions 15 and 10. The verifier establishes this **in exact rational arithmetic** by exhibiting 15 and 10 independent member Gram minors. With the lexicographic pair labels, the principal determinants are

\[
\boxed{\det G_{\rm plane,15}=\frac{3^{14}}{2^{32}}\ne0},\qquad
\boxed{\det G_{\rm skew,10}=\frac{2^{26}}{3^{36}}\ne0}.
\]

Therefore

\[
\boxed{\operatorname{span}_{\mathbb R}\{E_{ab}^{\pm}\}
=\operatorname{Herm}(V_5),\qquad \dim_{\mathbb R}=25.}
\]

The old 15D blind sector is **blind only to the original ten first-order line measurements**, not to the *intrinsic quadratic pair-plane effects*. The closure is finite mathematical readout completeness; no existing physical detector or instrument is claimed to implement these derived POVM effects.

## GC-34. Exact invertible tomography and a sharp conditioning certificate

Define the Hilbert–Schmidt analysis/frame operator on 5-by-5 Hermitian matrices:

\[
\mathcal F(X)=\sum_{a<b,\epsilon=\pm}
 E_{ab}^{\epsilon}\operatorname{tr}(E_{ab}^{\epsilon}X).
\]

The real symmetric and imaginary antisymmetric parts decouple. The full exactly calculated spectrum is

\[
\boxed{\operatorname{Spec}\mathcal F=
 (1/18)^{(1)}\oplus(43/5184)^{(9)}
 \oplus(1/576)^{(5)}\oplus(1/72)^{(10)}.}
\]

The verifier evaluates two *rational* Gram compression matrices of sizes 15 and 10, then computes their exact characteristic polynomials. Every eigenvalue is strictly positive, so the inverse is not assumed. The sharp universal bounds are

\[
\boxed{{1\over576}\|X\|_{\rm HS}^2\le
\sum_{ab,\epsilon}\bigl(\operatorname{tr}(E_{ab}^\epsilon X)\bigr)^2
\le{1\over18}\|X\|_{\rm HS}^2.}
\]

The frame eigenvalue condition number is **32**. Every Hermitian state operator `ρ` has a *fixed, linear* reconstruction from the 90 probability values:

\[
\boxed{\rho=\mathcal F^{-1}
\left(\sum_{ab,\epsilon}p_{ab}^\epsilon E_{ab}^\epsilon\right),\quad
 p_{ab}^\epsilon=\operatorname{tr}(E_{ab}^\epsilon\rho).}
\]

No independently chosen dual frame or assumed inversion regularity is needed. There is a bounded, fully determined inverse on the mathematical carrier.

## GC-35. Same ten projectors generate the complete u(5) operator Lie algebra

Because the ten line vectors span the real `V5`, select any five that are linearly independent. Their pair inner products never vanish. For each of those five, the commutator `C_ab` is a nonzero multiple of the wedge `u_a\wedge u_b`. The ten such wedges form a basis of `Λ²V5=so(5)`. Thus the Lie algebra generated by `iQ_a` contains **all** skew-real `so(5)` directions at bracket depth two.

Moreover `Σ_a Q_a=2I` gives the central `iI`. The `so(5)` adjoint orbit of the traceless part of any `iQ_a` spans `i Sym²_0(V5)` (dimension 14), because this is the irreducible traceless-symmetric representation of `so(5)`. Hence

\[
\boxed{\operatorname{Lie}_{\mathbb R}\{iQ_1,\ldots,iQ_{10}\}
=\mathfrak u(5),\qquad\dim_{\mathbb R}=25.}
\]

This has a shorter exact *constructive* certificate: the 10 original `Q_a` plus five explicit triple-bracket symmetric expressions have an HS Gram determinant

\[
\boxed{\det G_{\rm sym,15}=2^{40}/3^{42}\ne0}. 
\]

The 45 first commutators already have rank ten, so **bracket depth at most three** suffices. This is algebraic controllability, not the physical occurrence of independently switchable Hamiltonian controls.

**Consequential no-go:** v1.6's 15D blind complement equals `so(5)` (10) plus a nonzero traceless symmetric five-dimensional component. Its commutator closure is **all** `sl5(R)` (dimension 24), not a fifteen-dimensional Lie subalgebra. Therefore it cannot be identified *as an embedded commutator Lie algebra* with Paper I-B's existing abstract Petersen `sl4(R)` merely from the matching 15 and `A5` character content. The module-level comparison remains legitimate, but the Lie-bracket identification is not.

**Source tie:** Paper V-C's scalar-commutant prerequisite is fulfilled for the *mathematical* `V5` algebra generated by these ten projectors, since `C*(Q_a)=M5(C)` and its commutant is scalar. This does **not** certify the actual same-owner Hamiltonian/jump algebra on an entire exact-charge physical component.

## GC-36. A concrete exactly computed coherent shell discriminant

Reuse the v1.6 twelve native nearest and twelve F40 quaternion shells, induced from the source's `2I` multiplication table. On `End(V5)`, their random-unitary class-average channels `Φ_near, Φ_F40` are distinct only on the triplet subspaces, although their ten-line *single-effect* tests cannot distinguish them.

The new 90-effect POVM can. Label the ten quintet lines by lexicographic pair indices `0,...,9`. Prepare `R^+_{0,1}` and measure effect `E^+_{0,5}` after one channel action. Exact quaternionic enumeration yields

\[
\boxed{p_{\rm near}=\frac3{256}},\qquad
\boxed{p_{\rm F40}=\frac{11}{2304}},\qquad
\boxed{p_{\rm near}-p_{\rm F40}=\frac1{144}}.
\]

These probabilities come from the source-proved quaternion permutations and the *new derived* POVM; no triplet basis, external readout ray, or fitted coefficient was inserted. This is a finite quantum comparison observable, **not** a physical branching ratio or lifetime.

The `90×90` preparations/effects span both domain and codomain Hermitian spaces. Therefore their exact probability table `tr(E_j Φ(R_i))` determines **any linear Hermiticity-preserving channel `Φ` on the mathematical V5 carrier uniquely**. This discharges any separate *mathematical* process-tomography completeness condition on that carrier. It does not certify which channel physically occurs.

## GC-37. Make the formerly assumed two-step memory law distinguishable

The single-shell geometry alone does not decide whether two generator events are independently resampled. The old v1.6 no-go remains logically valid. But we can remove a **new observational ambiguity** using the same derived preparations and effects.

Keep preparation `R^+_{0,1}` and effect `E^+_{0,5}`. Compare `Φ_near∘Φ_near` (independent averaging) with `Φ_F40` (average of `Ad(ρ(g)^2)` with the same nearest `g` reused). An exact count of `12²` and `12` group-permutation words gives

\[
\boxed{p_{\rm IID}=\frac{13}{1024}},\qquad
\boxed{p_{\rm reuse}=\frac{11}{2304}},\qquad
\boxed{p_{\rm IID}-p_{\rm reuse}=\frac{73}{9216}}.
\]

Thus Markov/IID history is not *derived* from symmetry; rather, different admissible histories are exactly discriminable by an observable generated from the original finite geometry. Reinterpreting a performed measurement remains an occurrence/clock question.

## GC-38. No empirical weights in the 90-ray response hierarchy

For a prepared rank-one ray `R_a`, the derived POVM probability for another outcome `b` is `K_ab=tr(E_b R_a)`. Computing all **8,100** entries exactly gives only ten values:

| `p` | Number of entries among 8,100 |
|---:|---:|
| `0` | 90 |
| `1/1152` | 1,440 |
| `1/288` | 1,080 |
| `1/144` | 1,440 |
| `1/128` | 720 |
| `1/72` | 360 |
| `17/1152` | 1,440 |
| `25/1152` | 720 |
| `1/32` | 720 |
| `1/18` | 90 |

Every preparation row has exactly one forbidden counterpart: the orthogonal partner ray in its own plane. All other effects are possible. The **symmetric stochastic** kernel `K` has rank 25 and exact spectrum

\[
\boxed{\operatorname{Spec}K=
 1^{(1)}\oplus(1/4)^{(10)}\oplus(43/288)^{(9)}
 \oplus(1/32)^{(5)}\oplus0^{(65)}.}
\]

The result is a completely derived finite **readout kernel**, not a model of measured particle decays. Repeated Markov use of `K` is **not** inferred from one static preparation/measurement.

## GC-39. Source-ready elimination of III-A's local vector normalization ambiguity

The exact source audit `BH-IIIA-G-0005` concerns the undefined map `tau` in the III-A vector composite. This is a **different issue** from `V5` and is resolved by the earlier established II-C/I-C normalizations, with no second physical assumption.

Let `g=su(2)`, `p={(X,-X)}`. Define the two previously available maps

\[
\tau_{\rm ev}(X)=(X/2,-X/2),\qquad
\tau_{\mathcal E}(X)=(X,-X)=2\tau_{\rm ev}(X).
\]

II-C proves `ev|p(X,-X)=2X`; the I-C relative solder satisfies `\mathcal E|p(X,-X)=X`. Hence `\mathcal E=ev/2` on `p`. Transport cotangent fibres by II-C's established first-symbol map. For III-A's *relative solder* coframe (not the full Maurer–Cartan coframe), **define exactly**

\[
\boxed{\tau:=\tau_{\mathcal E},\qquad
\Phi_v:=((d\iota_1)^*)^{-1}\circ(ev^*)^{-1}.}
\]

Here `ev*` is the dual of `ev|p`, and the cotangent transport also includes the natural left-translation identification of `su(2)*` with `T_a*A`; all the arrows are the pre-existing, frame-free II-C arrows. Then

\[
\tau_{\mathcal E}^*\,ev^*=2I_{\mathfrak g^*},\qquad
\boxed{\Phi_v\circ(\tau_{\mathcal E}^*)^{-1}
=\frac12((d\iota_1)^*)^{-1}.}
\]

This reproduces exactly the source's relative-solder factor `1/2`. The alternative `tau_ev` yields the full evaluation coframe and must not silently be substituted in this source sentence. The rank-three vector, separate rank-one scalar, total rank four, and determinant exponent four are unchanged. This is a **source-ready mathematical repair**, not yet a certified closure of the *as-published* source and audit until the corrected paragraph is committed and its new version audited.

## GC-40. Final source/action boundary, no hidden conditions promoted

The exact finite constructions above remove, **within the stated mathematical V5 and first-order cotangent scopes**:

- the need for independently selected triplet-sensitive POVM effects or fiducial rays;
- the assumption of state readout or process tomography completeness/invertibility;
- the assumption of extra algebra-generating/triplet Hamiltonian directions, **if** the original ten `iQ_a` are admitted controls;
- the ambiguity between two coherent shell maps and between independent/reused histories **at the level of mathematical readout outcomes**, not by deriving physical time dynamics;
- the III-A local vector map factor-of-two as a proposed exact source correction.

**Still not derived:** source occurrence of these 10 operators as interactions or detector effects; choice of physical Hamiltonian versus channel, time/clock and irreversible evolution; full spin/colour/Clifford and Fock-sector state map; physical energy hierarchy, phase space, pole residues and branching/width calculations; any identification with `H1` or the Petersen `sl4` as a Lie algebra. Therefore **SOURCE_600_EDGE, SOURCE_RESOLVENT, SOURCE_PATH_ASSEMBLY, STATE_MAP and PHYSICAL_WIDTH of Paper V-C remain open**, as does the actual microscopic same-owner scalar-commutant condition outside this separate finite model.

## E4 challenge certificates and independent replay

The included `Paper00-GraphClosureDiscovery-v1_7.py` reconstructs the 120 native quaternions, all five intrinsic `Q8` groups, their action on five markings and ten pairs, the source `P_Pet`, all 10 lines, 45 pair planes, exact Gram minors, real/imaginary frame spectra, degree-three Lie certificate, 8,100 outcome probabilities, coherent shell contrasts and the solder normalization check. It uses only the original network JSON, no cached result matrices, physical data or fitted parameters. The certificate contains its input SHA-256.

Adversarial controls: the static 10-line readout has rank **10, not 25**; the proposed 90-ray construction becomes only symmetric rank 15 when its `i[Q,Q]` term is removed; the entire v1.6 15D blind complement is not commutator-Lie-closed; no single fixed `Q` is a physical decay amplitude; and the competing shell/history probabilities differ despite identical source 600-cell geometry. Those failures are retained, not reclassified as solved physical assertions.

**Disposition:** rigorous mathematical new nodes suitable for Paper I-B source integration; an exact proposed Paper III-A normalization patch suitable for audit issue `BH-IIIA-G-0005`; typed DAG edges in the companion proposed delta. No authoritative archive was modified.
