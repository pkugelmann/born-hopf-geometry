#!/usr/bin/env python3
"""Exact finite proof checks for GC-48–50, Paper II-C six-outcome endpoint.

Verification of algebraic identities and examples; the universal proof is the
analytic argument recorded in the report and source-ready theorem. No SDP
numeric test is used as proof of universal nonexistence.
"""
import json, hashlib
from pathlib import Path
from sympy import (symbols, Rational as Q, sqrt, simplify, factor, Matrix, zeros, eye, diag)

ROOT = Path(__file__).resolve().parent
source = (ROOT/'Source/Paper2C-ReciprocalLocalization-v2_170.tex').read_text()
checks={}
def ok(label, pred):
    assert bool(pred), label
    checks[label]='PASS'
for label in ['p2c:thm:v226-equality','p2c:cor:v226-five',
              'p2c:thm:v255-seven-outcome-attainment',
              'p2c:thm:v266-six-trines','p2c:cor:v266-outcome-count']:
    ok('source '+label, label in source)

z,a,b,v,m,h= symbols('z a b v m h',real=True)
s2=1-z*z
wp=(1-4*z)/(8*(1-z))
wm=(1+4*z)/(8*(1+z))
wt=Q(3,16)/s2
# Protected 4D tight design, after antipodal and tetra rigidity.
ok('latitude protected weights normalize',simplify(wp+wm+4*wt-1)==0)
ok('latitude axial first moment',simplify(wp-wm+4*wt*z)==0)
ok('latitude axial second moment',simplify(wp+wm+4*wt*z*z-Q(1,4))==0)
ok('latitude transverse second moment',simplify(4*wt*s2/Q(3)-Q(1,4))==0)
ok('latitude scalar weights at z=0', all(simplify(expr.subs(z,0)-val)==0 for expr,val in [(wp,Q(1,8)),(wm,Q(1,8)),(wt,Q(3,16))]))
ok('latitude weight zero endpoints',simplify(wp.subs(z,Q(1,4)))==0 and simplify(wm.subs(z,-Q(1,4)))==0)

# n_j = z e1 + sqrt(1-z²) q_j. Explicit regular tetrahedron.
T=Matrix([[1,1,1],[1,-1,-1],[-1,1,-1],[-1,-1,1]])/sqrt(3)
ok('tetra normals unit', T*T.T == Matrix(4,4,lambda i,j: 1 if i==j else -Q(1,3)))
ok('tetra zero mean', T.T*Matrix([1]*4)==zeros(3,1))
ok('tetra covariance', T.T*T==Q(4,3)*eye(3))

# Pair resource exact inversion: A,B and C_j from one S.
# Square root units R=1. Y_a on 0-form + 1-forms + 2-forms.
Y=[zeros(11) for _ in range(4)]
W={(0,1):5,(0,2):6,(0,3):7,(1,2):8,(1,3):9,(2,3):10}
for i in range(4):
    Y[i][0,i+1]=Y[i][i+1,0]=Q(1,2)
    for j in range(4):
        if i==j:continue
        k=W[(min(i,j),max(i,j))]
        Y[i][j+1,k]=Y[i][k,j+1]=(1 if i<j else -1)*sqrt(2)/3
ok('native scalar-vector coefficient',Y[0][0,1]==Q(1,2) and Y[1][0,2]==Q(1,2))
ok('native vector-bivector coefficient',Y[0][2,5]==sqrt(2)/3 and Y[1][1,5]==-sqrt(2)/3)
ok('directional spectrum exact',Y[0].eigenvals()=={Q(1,2):1,-Q(1,2):1,sqrt(2)/3:3,-sqrt(2)/3:3,0:3})

# Derive invariants from rank-one 2x2 tests after S4 tetrahedral twirl.
# A,B=( (1 ± z)S ∓ zI ±Y1/r )/2;
# 4C_j=(I-S)+3Y(q_j)/(r sqrt(1-z²)).
a_max = simplify(1 - Q(3,4)/s2)
b_max = simplify(1 - Q(2,3)/s2)
ok('resource scalar bound exact',simplify(a_max-(1-4*z*z)/(4*s2))==0)
ok('resource axial bound exact',simplify(b_max-(1-3*z*z)/(3*s2))==0)
ok('upper-bound separation exact',simplify(b_max-a_max-1/(12*s2))==0)

U=(1+z)*a-z
V=(1-z)*a+z
Up=(1+z)*b-z
Vp=(1-z)*b+z
ok('pair elimination cancels free h',simplify((1-z)*((1+z)*h+Q(1,2))-(1+z)*((1-z)*h-Q(1,2))-1)==0)
ok('weighted Cauchy first resource',simplify((1-z)*U+(1+z)*V-2*(s2*a+z*z))==0)
ok('weighted Cauchy second resource',simplify((1-z)*Up+(1+z)*Vp-2*(s2*b+z*z))==0)
ok('Cauchy equality cross determinant',simplify(U*Vp-V*Up-2*z*(a-b))==0)
ok('at both resource ceilings scalar = quarter',simplify((s2*a+z*z).subs(a,a_max)-Q(1,4))==0)
ok('at both resource ceilings axial = third',simplify((s2*b+z*z).subs(b,b_max)-Q(1,3))==0)
ok('optimal radius Cauchy ceiling equality',simplify(2*sqrt(Q(1,4)*Q(1,3))-1/sqrt(3))==0)
ok('strict Cauchy for tilted tetra at ceilings',simplify((U*Vp-V*Up).subs({a:a_max,b:b_max})+z/(6*s2))==0)

# At z=0 equality forces v=m=0, but Y1 couples transverse vector to mixed 2-form.
ok('z zero maximal resources', a_max.subs(z,0)==Q(1,4) and b_max.subs(z,0)==Q(1,3))
ok('z zero tetra transverse saturation', simplify((1-a_max.subs(z,0))*(1-v)-Q(3,4))==-Q(3,4)*v)
ok('z zero tetra mixed saturation',simplify((1-b_max.subs(z,0))*(1-m)-Q(2,3))==-Q(2,3)*m)
ok('z zero remaining forbidden nonzero vector wedge edge', Y[0][2,5]!=0)

# Check whole geometric moment inversion on a rational axial tilt z=1/10
Z=Q(1,10);S=eye(11)*Q(2,5); R= sqrt(3); s=sqrt(1-Z*Z)
Ap=((1+Z)*S-Z*eye(11)+Y[0]/R)/2
Am=((1-Z)*S+Z*eye(11)-Y[0]/R)/2
Q4=[]; geo=[]
for j in range(4):
    qq=Matrix([0]+list(T.row(j)))
    Yq=sum((qq[k]*Y[k] for k in range(4)),zeros(11))
    geo.append((eye(11)-S+Q(3)/(R*s)*Yq)/4)
    Q4.append(Z*Matrix([1,0,0,0])+s*qq)
ok('sample tilt effects normalize algebraically',(Ap+Am+sum(geo,zeros(11))).applyfunc(simplify)==eye(11))
for k in range(4):
    mom=R*((1 if k==0 else 0)*Ap - (1 if k==0 else 0)*Am+
        sum((Q4[j][k]*geo[j] for j in range(4)),zeros(11)))
    ok(f'sample tilt exact geometric moment k={k}',(mom-Y[k]).applyfunc(simplify)==zeros(11))

# Rank argument for four repeated Naimark entries: constant Gram, 3D differences.
d=Q(1,5);ww=(1-d*d)/5
rho=-(1+d*d/ww)/4
Gram=Matrix(4,4,lambda i,j: 1 if i==j else rho)
Dif=Matrix(4,3,lambda i,j:(1 if i==j else 0)-(1 if i==3 else 0))
ok('four equal t implies tetra-difference rank three', (Dif.T*Gram*Dif).rank()==3)
ok('all distinct-design latitude weights positive at z=1/10',all((e.subs(z,Z)>0) for e in (wp,wm,wt)))

# A direct example demonstrates z !=0 is a legitimate protected design,
# despite the proved geometric obstruction.
N=[Matrix([1,0,0,0]),Matrix([-1,0,0,0])]+Q4
weights=[wp.subs(z,Z),wm.subs(z,Z)]+[wt.subs(z,Z)]*4
ok('nonzero tilted design normalized',simplify(sum(weights)-1)==0)
ok('nonzero tilted design mean zero',sum((weights[i]*N[i] for i in range(6)),zeros(4,1)).applyfunc(simplify)==zeros(4,1))
ok('nonzero tilted design tight covariance',sum((weights[i]*N[i]*N[i].T for i in range(6)),zeros(4)).applyfunc(simplify)==eye(4)/4)

cert={'package':'Paper00-GraphClosureDiscovery-v1_10','owner':'Paper II-C','source_sha256':hashlib.sha256(source.encode()).hexdigest(),
      'closures':['GC-48','GC-49','GC-50'],'exact_checks':len(checks),'status':'PASS',
      'check_results':checks,'global_six_vs_seven':'UNRESOLVED'}
(ROOT/'Paper00-GraphClosureDiscovery-v1_10.json').write_text(json.dumps(cert,indent=2,ensure_ascii=False,sort_keys=True)+'\n')
print(json.dumps({'status':'PASS','exact_checks':len(checks),'source_sha256':cert['source_sha256'],'unrestricted_six_vs_seven':'UNRESOLVED'}))
