# Born–Hopf geometry — universal antipodal exclusion at the six-outcome endpoint

**Paper00-GraphClosureDiscovery-v1_10 · 19 November 2026**  
**Supersedes:** `Paper00-GraphClosureDiscovery-v1_9` for the Paper II-C endpoint investigation.  
**Source:** `Paper2C-ReciprocalLocalization-v2_170.tex` in `Paper00-PapersMinimal-v3_041.zip`.  
**Scope:** exact finite mathematical first-moment POVMs on the intrinsic position tuple, not actual apparatus construction.  
**Integration status:** new theorem and DAG additions proposed only; source papers and atlas unchanged.

## 1. Source theorem and target observable

At $r_0=\sqrt3 R$, `p2c:thm:v226-equality` forces positive protected outcomes of any exact position POVM to form a weighted spherical two-design. The source's `p2c:cor:v226-five` rules out five or fewer outcomes, `p2c:thm:v255-seven-outcome-attainment` constructs seven at $r_0$, and `p2c:cor:v266-outcome-count` leaves unrestricted $N_{\min}(r_0)\in\{6,7\}$. The mathematical observable is the least **number of classical outcome labels**, not a physical detector probability or particle decay.

Previous closure v1.8 (GC-40–45) proved that any hypothetical six-outcome endpoint solution has all six protected weights positive, admits a $5\times6$ Parseval frame with one Naimark complement $t$, and has its geometric effects controlled by one shared Hermitian matrix. Closure v1.9 (GC-46–47) excluded the exact antipodal-plus-orthogonal-tetrahedron support, along with all two-level Naimark sign-class configurations. Its antipodal theorem assumed *orthogonality* of the tetrahedron to the pair. This update removes that assumption.

## 2. GC-48 — any antipodal pair forces a one-parameter tilted tetrahedron

**Exact theorem.** Consider six unit directions $n_i\in S^3$ and positive weights $w_i$ with

$$
\sum_iw_i=1,\qquad\sum_iw_in_i=0,\qquad\sum_iw_i n_in_i^T=I_4/4.
$$

If $n_+=e_1$ and $n_-=-e_1$, then the remaining four directions are necessarily

$$
\boxed{n_j=z e_1+\sqrt{1-z^2}\,q_j,\quad q_j\cdot q_k=-1/3\ (j\ne k),\quad-1/4<z<1/4.}
$$

No additional tetrahedral or equal-weight condition was assumed. The weights are **uniquely**

$$
\boxed{w_+=\frac{1-4z}{8(1-z)},\quad
w_-=\frac{1+4z}{8(1+z)},\quad
w_j=\frac3{16(1-z^2)}.}
$$

**Proof.** Set $f_i=\sqrt{w_i}(1,2n_i)^T$. The design equations give $FF^T=I_5$ and $F^TF=I_6-tt^T$ for a unit $t$. The antipodal Gram entry gives $t_+t_-=3\sqrt{w_+w_-}>0$. For each remaining $j$, the two Gram entries give

$$
-t_+t_j=\sqrt{w_+w_j}(1+4z_j),\qquad
-t_-t_j=\sqrt{w_-w_j}(1-4z_j).
$$

Here $z_j=e_1\cdot n_j$ and $t_j\ne0$. Their quotient forces all $z_j=z$. Write the perpendicular components as $s q_j$, $s=\sqrt{1-z^2}$. The transverse first and second moments give $\sum_{j=1}^4w_j q_j=0$ and $\sum w_j q_jq_j^T=I_3/(4s^2)$. The $3\times4$ matrix with columns $2s\sqrt{w_j}\,q_j$ has orthonormal rows and one-dimensional kernel $\sqrt{w_j}/\sqrt{\sum w_j}$. The diagonal Gram equations force all four weights equal; the off-diagonal equations force $q_j\cdot q_k=-1/3$. The axial moments then determine the displayed $w_\pm$ and the open $z$ interval.

**New classification:** a general six-weight antipodal design is never an arbitrary irregular configuration; it belongs to a single explicitly parametrized latitude-tetrahedron family. For $z\ne0$ the two antipodal protected weights are genuinely unequal, so GC-46 alone did **not** exclude it.

## 3. GC-49 — none of the tilted tetrahedra extend to positive geometric effects at $r_0$

**Exact no-go.** For every $-1/4<z<1/4$, no six-outcome positive POVM with these protected directions can realize all native intrinsic first moments at $r_0=\sqrt3R$, even with completely unrestricted geometric effect matrices or initial noncentral effect entries.

Central pinching leaves the block-diagonal coordinate tuple and all moments unchanged. Set $R=1$ and $r=\sqrt3$. Let $A,B$ denote the two geometric effects at $\pm e_1$, let $C_j$ denote the four tetrahedral effects, put $S=A+B$ and $s=\sqrt{1-z^2}$. Exact normalization and moments uniquely give

$$
\boxed{2A=(1+z)S-zI_G+Y(e_1)/r,\qquad
 2B=(1-z)S+zI_G-Y(e_1)/r,\qquad
 4C_j=I_G-S+3Y(q_j)/(rs).}
$$

Since all six effects are positive, $0\preceq S\preceq I$. Average any hypothetical solution over tetrahedral rotations that fix $e_1$, simultaneously permuting the $C_j$. This is a mathematical averaging used in a *necessary* test, not a physical apparatus covariance assumption. Let $a,b$ be the resource diagonal values of $S$ on the 0-form and the axial vector, and $v,m$ those on each transverse-vector and mixed-bivector sector (each three-dimensional). They obey $0\le a,b,v,m\le1$ even if all invariant off-diagonal blocks are retained.

In $4C_j$, the 0-form--transverse-vector and axial-vector--mixed-bivector native couplings have squared magnitudes $9/(4r^2s^2)$ and $2/(r^2s^2)$. Their $2\times2$ positive principal minors force

$$
(1-a)(1-v)\ge\frac9{4r^2s^2},\qquad
(1-b)(1-m)\ge\frac2{r^2s^2}.
$$

At $r^2=3$, these imply

$$
\boxed{a\le a_*=\frac{1-4z^2}{4(1-z^2)},\qquad
b\le b_*=\frac{1-3z^2}{3(1-z^2)}.}
$$

The pair effects $A,B$ are positive on the 0-form/axial-vector $2\times2$ compression. Writing $h=\langle e_0,Su_1\rangle$, $c=1/(2r)$, and

$$
U=(1+z)a-z,\quad U'=(1+z)b-z,\qquad
V=(1-z)a+z,\quad V'=(1-z)b+z,
$$

we obtain

$$
|(1+z)h+c|\le\sqrt{UU'},\qquad
|(1-z)h-c|\le\sqrt{VV'}.
$$

The weighted difference eliminates $h$, and weighted Cauchy–Schwarz then proves the **closed exact chain**

$$
\boxed{
\frac1{\sqrt3}=\frac1r\le
 (1-z)\sqrt{UU'}+(1+z)\sqrt{VV'}
 \le2\sqrt{[(1-z^2)a+z^2][(1-z^2)b+z^2]}
 \le\frac1{\sqrt3}.}
$$

Every inequality must be an equality. The last forces $a=a_*$, $b=b_*$, yet $b_*-a_*=1/[12(1-z^2)]>0$. The Cauchy equality condition requires $UV'=VU'$, whereas

$$
\boxed{UV'-VU'=2z(a-b).}
$$

Thus equality forces $z=0$. For $z=0$, the two tetra minor inequalities force $v=m=0$. Because $S\succeq0$, the corresponding vector and mixed-bivector rows vanish in $S$. But $Y(e_1)$ has a nonzero coupling $\langle u_2,Y(e_1)w_{12}\rangle=\sqrt2/3$. Therefore $2A=S+Y(e_1)/r$ has a principal two-by-two matrix with zero diagonal and nonzero off-diagonal, contradicting positivity. **Every tilt is excluded.**

This uses *both* native coupling types. Replacing the vector--bivector part of $Y$ by zero destroys the final contradiction; that would be a different coordinate tuple.

## 4. GC-50 — fourfold Naimark degeneracy removed and a compactness consequence

If four Naimark entries $t_j$ are equal, the frame diagonal and off-diagonal formulas give four equal weights and identical mutual inner products of their spatial directions. The differences among these four vectors span three dimensions. The other two directions have constant inner product with every member of that four-set, so both lie in the one-dimensional orthogonal complement. They must be opposite; equality would allow two outcome labels to merge, contradicting the source-proved five-outcome lower bound. GC-49 therefore excludes **all fourfold-equal Naimark components**, including all $2+4$ candidates with four equal magnitudes but two arbitrary unequal opposite-sign magnitudes.

A further qualitative consequence is exact: if a six-outcome endpoint POVM exists, its six directions have a uniform positive angular gap away from antipodality and coincidence. Indeed the set of feasible six-effect/six-label families is compact in the finite-dimensional positive-operator and sphere topology. A sequence approaching an antipodal pair would converge to the just-excluded case; a sequence approaching coincident labels would converge to a five-effect realization. Both are impossible. Thus for some $\epsilon>0$ every hypothetical feasible six-effect endpoint has $-1+\epsilon\le n_i\cdot n_j\le1-\epsilon$ for all distinct pairs. The argument does **not** compute a numeric $\epsilon$ and does not establish that a six-outcome rule exists.

## 5. Verification, limitations and proposed integration

`Paper00-GraphClosureDiscovery-v1_10.py` independently constructs the native 11-dimensional geometric $Y_a$ matrices; checks the spectral and coupling values; checks the exact latitude weights, frame and tetra moments, exact algebraic resource bounds, the weighted Cauchy determinant, equality contradiction, and a nonzero latitude protected-design example at $z=1/10$. It uses exact SymPy arithmetic and writes the deterministic JSON certificate. **The verifier has 42 passing exact checks.** The analytic proof above is the universal argument; finite checks alone are not substituted for the all-$z$ quantifiers. The source is packaged without changes.

**Source-ready insertion:** `Paper2C-AntipodalFreeEndpointClosure-v1_1.tex`, proposed immediately after the previous endpoint-rigidity insertions in Paper II-C. **DAG proposal:** `Paper00-GraphClosureDAGDelta-v1_8.json` with explicit upstream theorem and construction links. The authoritative papers, DAG Atlas, audits and S³ network remain unchanged.

**Still open:** six-support designs with **no** antipodal pair and without a fourfold Naimark degeneracy. These may have nonuniform magnitudes within their sign classes. The unrestricted endpoint count remains

$$\boxed{N_{\min}(\sqrt3R)\in\{6,7\}.}$$

Physical apparatus occurrence is unaddressed and not required by this mathematical theorem.
