# Born–Hopf Geometry — unmarked Sylow–quintet–Petersen closure (v1.4)

**Release:** `Paper00-GraphClosureDiscovery-v1_4` (successor to v1_3; 2026-11-19).  
**Primary current source:** `Paper00-PapersMinimal-v3_040(1).zip`, especially `Paper1B-ExceptionalGeometry-v1_18.tex` and `Paper2B-MomentumCarrier-v2_145.tex`.  
**Native geometry:** `Paper00-S3StructureNetwork-v1_40(1).zip`, exact vertex and zero-projector instances reproduced in `inputs/`.  
**Prior mathematics:** v1.3 derived a **marked** 15D complementary carrier and the associated 9D/3D/Petersen chain. This release constructs a **new, unmarked** 25D/5×10D/5×15D/10×5D/Petersen chain, derives its normalization and finite readout weights, and sharply identifies the full-symmetry no-go for a preferred 15D sector.  
**Proof status:** exact finite group/representation arguments plus independently checkable 120-by-120 integer-matrix certificates, `PASS` on the supplied native instances. Source insertion proposed, **not** applied to authoritative archive. No physical action/decay identification, clock conversion, occurrence or full cross-paper E3 audit claimed.

## 1. What is derived instead of assumed

The source already proves: (a) 600-cell vertices are `G=2I` and the nearest adjacency `A` is a central 12-neighbour conjugacy-class operator (`p1:cor:v3026-600-hs-spectral-gap`); (b) its canonical rank-25 adjacency-zero projector `P25` is the `U_4` quintet matrix-coefficient projection (`p1:cor:v3026-twisted25-adjacency-kernel`); (c) a **chosen** `H=2T` produces five left Hurwitz cosets and ten supported `C3` zero modes (`p1b:thm:v3023-five-coset-adjacency`, `p1b:thm:v3027-hurwitz-character-zero-modes`). These inputs and their precise scopes are preserved.

The previous v1.3 mathematical construction needed a marked H to write the projector P10. Here **all five** such projectors arise from G, its Sylow-2 subgroups and the already certified P25. No privileged H, coset partition, local character basis, independent scalar weights or supplementary 15D module is required for the complete unmarked family.

**No physical assumption is implicitly promoted:** G is the already constituted exceptional finite comparison group. Its **occurrence as a physical operator/action** is an additional question, not proved by finite incidence alone.

## 2. GC-15: Construct the five Hurwitz core projectors without a marking

There are 30 order-four elements of G (the 30 nonzero imaginary Hurwitz/icosian units in the embedded quaternionic model). The Sylow-2 theorem and explicit quaternion products generate exactly five order-eight quaternion subgroups

\[
\mathscr Q=\{Q_{8,1},\ldots,Q_{8,5}\},\qquad
\#\mathscr Q=5,\quad |Q_{8,i}|=8.
\]

Their six noncentral elements partition the 30 order-four elements. Each has normalizer `N_G(Q8_i)=H_i≅2T`, so **the set** of five Hurwitz subgroups follows from G without a selected starting subgroup. Conjugation of G permutes these five labels by the natural A5 action; the 120 group elements induce exactly 60 distinct even five-point permutations, each twice.

The rank-25 band is, by the source's Peter–Weyl identification, the real matrix-coefficient bimodule

\[
\mathcal K_{25}\cong V_5\otimes V_5^*,\qquad
\chi_5(q)=U_4(\operatorname{Re}q),\qquad
U_4(t)=16t^4-12t^2+1,
\]

where V5 is the real irreducible five-dimensional A5 quintet. For each Q8_i define **without selecting a coset**

\[
\pi_i=\frac18\sum_{h\in Q_{8,i}}\rho_5(h),\qquad
P_i=I_{V_5}\otimes\pi_i\quad\text{on }\mathcal K_{25}.
\tag{15.1}
\]

The projector trace is exact:

\[
\operatorname{rank}\pi_i
=\frac18\left(2\chi_5(\pm1)+6\chi_5(0)\right)
=\frac{10+6}{8}=2,
\quad \boxed{\operatorname{rank}P_i=10.}
\tag{15.2}
\]

In the real 120-vertex model, this means `P_i=P25 E_{Q8_i}`, where E is **right subgroup averaging**. Reconstructing all five by literal 8-element sums of integer kernel entries reproduces the marked 24-cell C3-character P10 of the source **exactly**, and also reproduces the complete right G orbit of that P10. This is a derivation of the prior local projector from unmarked group data, not a new postulate.

## 3. GC-16: Five rank-ten projectors are an exact isoclinic tight fusion frame

Every \(\pi_i\) is a real rank-two projector, conjugate under the A5 action, on the irreducible \(V_5\). By Schur's lemma and the trace,

\[
\boxed{\sum_i\pi_i=2I_5,\qquad\sum_iP_i=2P_{25}.}\tag{16.1}
\]

For distinct i,j, the ordered pair stabilizer in the two-transitive five-point A5 action is C3. Its action on \(\operatorname{ran}\pi_i\cong\mathbb R^2\) is the nontrivial real rotation representation (the two nontrivial C3 characters combined), so the real symmetric compression \(\pi_i\pi_j\pi_i\) is scalar. Two-transitivity makes the scalar the same for all i≠j. Tracing (16.1) against \(\pi_i\) shows

\[
4\operatorname{tr}(\pi_i\pi_j)=\operatorname{tr}\pi_i(2I_5-\pi_i)=2,
\quad\operatorname{tr}(\pi_i\pi_j)=\frac12,
\]

thus the scalar is 1/4, giving

\[
\boxed{P_iP_jP_i=\tfrac14P_i\quad(i\ne j).}\tag{16.2}
\]

Therefore all ten unordered pairs of the 10D subspaces have ten principal angles of exactly 60°. This statement follows from native 2I representation symmetry and is independently checked using exact integer matrices (Pnum/24).

## 4. GC-17: Canonical five-by-fifteen and ten-by-five dual Petersen structures

Set \(Q_i=P_{25}-P_i\). Each Q_i is a rank-15 projector, and

\[
\boxed{\sum_iQ_i=3P_{25}.}\tag{17.1}
\]

Since the 2-planes \(\operatorname{ran}\pi_i\) and \(\operatorname{ran}\pi_j\) are pairwise isoclinic at 60°, their 3D orthogonal complements in the right V5 intersect in a line and have remaining squared principal cosines 1/4. After tensoring the left V5 factor, the 15D subspaces satisfy

\[
\operatorname{spec}\bigl((Q_iQ_jQ_i)|_{\operatorname{ran}Q_i}\bigr)
=\{1^{(5)},(1/4)^{(10)}\}.
\tag{17.2}
\]

The intersection projector, with no new basis or spectral cutoff, is the polynomial

\[
\boxed{T_{ij}:=\frac{4Q_iQ_jQ_i-Q_i}{3},\qquad
T_{ij}^2=T_{ij},\quad\operatorname{rank}T_{ij}=5.}\tag{17.3}
\]

By invariance and trace, the full ten-pair family and each 4-edge star obey

\[
\boxed{\sum_{i<j}T_{ij}=2P_{25},\qquad
\sum_{j\ne i}T_{ij}=\frac43Q_i.}\tag{17.4}
\]

For distinct core-pair labels a,b, the 5D channels are equi-isoclinic:

\[
\boxed{T_aT_bT_a=\tfrac19 T_a.}\tag{17.5}
\]

An analytic verification of the value: within one star, the four one-dimensional right-factor lines form an A4-symmetric tetrahedral configuration in the 3D complement; the star identity gives |overlap|²=1/9 for three other star lines. Any two different pair labels are either intersecting (six possibilities) or disjoint (three possibilities). The global tight identity forces 6(1/9)+3b=1, hence b=1/9 too. All 45 cases are also checked by integer arithmetic.

For each triple of distinct pair labels a,b,c the exact orientation-independent cubic holonomy satisfies

\[
\boxed{T_aT_bT_cT_a=\frac{\sigma_{abc}}{27}T_a},\quad
\sigma_{abc}=\begin{cases}
+1,&\text{the three K5 edges form a path on four labels},\\
-1,&\text{otherwise}.
\end{cases}\tag{17.6}
\]

The 120 triples split into 60 positive and 60 negative signs. This was replayed exhaustively, not assigned by a sign convention. The ten underlying right-factor lines form a rank-five 10-line equiangular tight frame; their Seidel matrix is switching-equivalent to the Petersen conference matrix \(2A_P+I-J\), with \(S^2=9I\). This is a **different rank-five construction** from v1.3's marked ten rank-three channels, although the signed Petersen invariant is shared.

## 5. GC-18: Symmetry-derived normalized finite readouts

The projector sums define exact positive operator resolutions of the identity **on K25**, and in every selected 15D Q_i:

| Scope | Effects | Exactly forced sum |
|---|---|---|
| K25, five local-class outcomes | \(E_i=P_i/2\) | \(P_{25}\) |
| K25, five complementary outcomes | \(F_i=Q_i/3\) | \(P_{25}\) |
| K25, ten pair channels | \(G_{ij}=T_{ij}/2\) | \(P_{25}\) |
| Q_i, four incident pair channels | \(G_{j\mid i}=3T_{ij}/4\) | \(Q_i\) |

These are mathematical POVMs on the stated subspaces, not a claim of an occurring detector. The normalization is forced by symmetry and the frame constants.

For **any** normalized density operator supported on the named preparation subspace, the following mathematical probabilities are state-independent within that subspace:

- Supported in P_i and measured using the five P_j/2 effects: own outcome 1/2, four others each 1/8.
- Supported in T_ij and measured using Q_k/3: each endpoint i,j has probability 1/3, the other three each 1/9.
- Supported in T_a and measured using the ten T_b/2 effects: own 1/2, nine others each 1/18.
- Supported in T_ij and measured in the 4-effect star of Q_i: own pair 3/4, other incident three each 1/12.

All follow by compression e.g. \(T_{ij}Q_kT_{ij}=(1/3)T_{ij}\) for k outside {i,j}, and \(T_aT_bT_a=T_a/9\) for a≠b. Source-generated preparations, devices and occurrence remain open.

## 6. GC-19: No separate uniform-edge-weight assumption for the symmetric nearest graph walk

The source already proves the 12 nearest generators form one conjugacy class of G (Paper I-B v3.026). Since the group acts transitively on vertices by left multiplication, and conjugation acts transitively on the 12 nearest neighbours of a fixed vertex, its symmetry group acts transitively on directed nearest edges.

Every **stochastic, zero-holding, nearest-edge supported kernel** invariant under these native left and conjugation symmetries therefore has identical positive entry p on all 12 neighbours. Stochastic row normalization forces 12p=1:

\[
\boxed{K=A_{600}/12.}\tag{19.1}
\]

Thus v1.3's simple graph walk is mathematically *uniquely forced* under the expressly stated symmetry and nearest-edge domain; the normalization 1/12 is not an additional free source weight. This strengthens the provenance of GC-09's exact return law. It does **not** say a physical transition action must be nearest-edge, stochastic, symmetric or run in physical seconds. The existing source already defines its normalized walk; the new point is its uniqueness relative to these precise structural hypotheses, not rediscovery of the normalized matrix.

## 7. Exact obstruction: no preferred physical rank15 follows from unmarked 2I alone

The 25D kernel is the irreducible \(V_5\otimes V_5^*\) representation of the independent left and right copies of 2I (factoring through A5×A5). By Schur's lemma, a projector commuting with **both** actions is 0 or P25. Therefore there is **no** rank-15 projector invariant under the full unmarked left-right finite geometry.

The five Q_i are canonical **as an orbit**, not individually selected by the unmarked parent. This is an exact no-go: a claim that full left-right symmetry *alone* uniquely selects one of these 15-dimensional subspaces is impossible. A further generated owner/source/role distinction would have to break the symmetry (and be proved to occur).

Moreover, these rank15 modules must not be silently identified with the *different* \(\mathcal H_1\) from Paper II-B: the entire P25 band is even under the central quaternionic sign in either left or right action, whereas \(\mathcal H_1\) contains half-integer chiral spinor constituents odd under at least one Spin(4) central factor. Therefore a Spin(4)-equivariant identification of the whole 15D structures cannot follow merely from matching dimensions. This protects the established \(m_p=1\) / \(\mathcal H_1\) source chain from false cross-identifications.

## 8. Conditions removed, conditions retained

| Former extra input / condition | Discharged by | Status |
|---|---|---|
| Pick a specific 2T marking merely to **define the full mathematical exceptional family** | enumerate five Sylow-2 Q8 subgroups, normalizers, group-average projectors | REMOVED for unmarked orbit/family |
| Choose each local 10D character projector separately | Q8-average P25; exact agreement with marked C3 character projectors | REMOVED |
| Introduce a supplementary 15D vector space and its 5-way relative angles | Q_i=P25-P_i, pair isoclinic spectrum | REMOVED for marked-family geometry |
| Choose ten rank5 intersections and their relative normalization | polynomial T_ij, frame identities, 60° and arccos(1/3) principal angles | REMOVED |
| Assign Petersen cubic signs independently | exact triple products (120 checks) | REMOVED |
| Choose numerical weights for the four stated mathematical POVMs | projector resolution of identity | REMOVED |
| Assume independent uniform weights for **symmetric nearest stochastic walk** | vertex/edge symmetry plus normalization | REMOVED within that exact domain; source walk itself pre-existing |
| Select **one** 15D subspace without breaking full left/right symmetry | mathematically impossible by irreducibility | NOT REMOVABLE BY THESE INPUTS |
| Physically realize this finite band as the occurring action/detector/decay operator; assign physical masses/seconds | no source-certified constructor present in this package | OPEN, not promoted |
| Derive 2I as physical rather than established finite comparison geometry, or assert GP3 universal uniqueness | not established by these finite identities | OPEN at distinct constitutional/physical boundary |

## 9. Reproducibility, source/DAG delta

Run in extracted directory:

```bash
OPENBLAS_NUM_THREADS=1 python Paper00-GraphClosureDiscovery-v1_4.py
```

The exact verifier regenerates all 14,400 entries of P25 directly from the quaternionic U4 kernel; detects all 30 order-four elements; enumerates and checks closure of every one of the five Q8 groups; constructs each P10 by a literal sum over Q8 right translations; matches the existing local C3 source projector and its entire right group orbit; checks all 120 right actions induce exactly 60 five-point permutations twice each; proves five P10/Q15 frames; all 10 rank5 intersection idempotents; all 45 pair and 120 triple identities; symmetric graph-edge orbit; and the exact compressions required by all four POVM families. The SHA-256 values of its retained input instances are written into the JSON certificate.

Proposed additions are in `Paper1B-UnmarkedSylowFusionClosure-v1_1.tex` and `Paper00-GraphClosureDAGDelta-v1_2.json`. They are source-ready proposals only, not amendments of the original 145 MB DAG atlas, the authoritative manuscripts, or the 2 MB S³ network.
