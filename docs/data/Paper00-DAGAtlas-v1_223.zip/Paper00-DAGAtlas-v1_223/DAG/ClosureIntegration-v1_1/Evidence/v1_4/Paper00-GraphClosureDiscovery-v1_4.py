#!/usr/bin/env python3
"""Born--Hopf graph closure v1_4: unmarked spectral fusion and unique normalized readouts.

Exact integer matrix certificates, no fitting and no external network.
Reads original 600-cell and rank-25 source certificates in inputs/.
Run: OPENBLAS_NUM_THREADS=1 python Paper00-GraphClosureDiscovery-v1_4.py
Not a physical dynamics, mass, decay, or instrument occurrence certificate.
"""
import collections
import hashlib
import itertools
import json
from pathlib import Path
import numpy as np

root = Path(__file__).resolve().parent
source = json.loads((root/'inputs'/'exceptional_600cell_instance.json').read_text())
rank25 = json.loads((root/'inputs'/'twisted25_v127_instance.json').read_text())
sha = {p.name:hashlib.sha256(p.read_bytes()).hexdigest()
       for p in (root/'inputs').iterdir() if p.is_file()}
V={v['id']:tuple(tuple(q) for q in v['qcoords']) for v in source['vertices']}
Vinv={q:i for i,q in V.items()}
assert len(V)==len(Vinv)==120
colors=[list(map(int,x)) for x in source['coset_blocks']]
assert len(colors)==5 and all(len(c)==24 for c in colors)
A=np.zeros((120,120),dtype=np.int64)
for e in source['nearest_edges']:
 i,j=e['u'],e['v'];A[i,j]=A[j,i]=1
assert np.array_equal(A,A.T) and np.all(A.sum(axis=1)==12) and A.sum()==1440

def add(a,b):return a[0]+b[0],a[1]+b[1]
def neg(a):return -a[0],-a[1]
def fm(a,b):return a[0]*b[0]+5*a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def qm(a,b):
 x,y,z,w=a;u,v,s,t=b
 c=[add(add(fm(x,u),neg(fm(y,v))),add(neg(fm(z,s)),neg(fm(w,t)))),
    add(add(fm(x,v),fm(y,u)),add(fm(z,t),neg(fm(w,s)))),
    add(add(fm(x,s),neg(fm(y,t))),add(fm(z,u),fm(w,v))),
    add(add(fm(x,t),fm(y,s)),add(neg(fm(z,v)),fm(w,u)))]
 assert all(a%4==b%4==0 for a,b in c)
 return tuple((a//4,b//4) for a,b in c)
def conjugate(q):return (q[0],)+tuple(neg(z) for z in q[1:])
def dotnum(i,j):
 d=(0,0)
 for x,y in zip(V[i],V[j]):d=add(d,fm(x,y))
 return d

def U4_num(d):
 sq=fm(d,d);qu=fm(sq,sq)
 t=add(add(qu,(-192*sq[0],-192*sq[1])),(4096,0))
 assert t[1]==0 and t[0]%4096==0
 return t[0]//4096

# The exact zero-band projector of the source (the rank25 witness is also reconstructed).
Z25=np.zeros((120,120),dtype=np.int64)
for i in range(120):
 for j in range(120):
  d=dotnum(i,j)
  if i!=j:assert bool(A[i,j])==(d==(4,4))
  Z25[i,j]=U4_num(d)
assert np.array_equal(Z25,np.asarray(rank25['projector_numerator_120x120'],dtype=np.int64))
assert np.array_equal(Z25@Z25,24*Z25)
assert np.array_equal(A@Z25,np.zeros((120,120),dtype=np.int64))
assert np.trace(Z25)==25*24

# Marked starting projector P10, two local C3 characters per left Hurwitz coset.
Z10=np.zeros((120,120),dtype=np.int64)
for ids in colors:
 for i in ids:
  for j in ids:
   d=dotnum(i,j)
   assert d[1]==0 and d[0] in (-16,-8,0,8,16)
   Z10[i,j]=2 if d[0] in (-16,0,16) else -1
assert np.array_equal(Z10@Z10,24*Z10)
assert np.array_equal(Z25@Z10,24*Z10)
assert np.array_equal(A@Z10,np.zeros((120,120),dtype=np.int64))
assert np.trace(Z10)==10*24

# Unmarked construction: ALL five Sylow-2 quaternion subgroups are generated
# from the 30 intrinsic order-four (pure imaginary) elements of 2I.
identity=Vinv[((4,0),(0,0),(0,0),(0,0))]
minus_identity=Vinv[((-4,0),(0,0),(0,0),(0,0))]
order4=[g for g in range(120) if V[g][0]==(0,0)]
assert len(order4)==30
quaternion_subgroups={}
for i,j in itertools.combinations(order4,2):
 k=Vinv[qm(V[i],V[j])]
 if k not in order4:continue
 sub={identity,minus_identity,i,j,k}
 sub.update(Vinv[qm(V[minus_identity],V[t])] for t in (i,j,k))
 assert len(sub)==8
 assert all(Vinv[qm(V[a],V[b])] in sub for a,b in itertools.product(sub,sub))
 quaternion_subgroups[tuple(sorted(sub))]=sub
assert len(quaternion_subgroups)==5
assert sorted([len(s-{identity,minus_identity}) for s in quaternion_subgroups.values()])==[6]*5
assert set.union(*[s-{identity,minus_identity} for s in quaternion_subgroups.values()])==set(order4)

# RIGHT subgroup averaging on the canonical 25D band, no chosen 2T coset.
# (P_i)(g,h)=(1/8) sum_{q in Q8_i} P25(g,h q).
P=[]
for sub in quaternion_subgroups.values():
 num=np.zeros((120,120),dtype=np.int64)
 for g in sub:
  perm=[Vinv[qm(V[h],V[g])] for h in range(120)]
  num+=Z25[:,perm]
 assert np.all(num%8==0)
 Mi=num//8
 assert np.array_equal(Mi@Mi,24*Mi)
 assert np.array_equal(Z25@Mi,24*Mi)
 assert np.array_equal(A@Mi,np.zeros((120,120),dtype=np.int64))
 assert np.trace(Mi)==24*10
 P.append(Mi)
assert len({m.tobytes() for m in P})==5
# Independently match the marked C3 character construction from Paper I-B.
assert any(np.array_equal(m,Z10) for m in P)

# The right 2I orbit of the historical marked P10 is exactly the five
# independently reconstructed Q8-averaging projectors.
right_orbit=set()
for g in range(120):
 p=[Vinv[qm(V[h],V[g])] for h in range(120)]
 right_orbit.add(Z10[np.ix_(p,p)].tobytes())
assert right_orbit=={m.tobytes() for m in P}
marks=list(range(5))
Q=[Z25-M for M in P]                # Q_i=Qnum_i/24: rank15
assert np.array_equal(sum(P),2*Z25)
assert np.array_equal(sum(Q),3*Z25)
assert all(np.array_equal(M@M,24*M) for M in Q)
assert all(np.trace(M)==24*15 for M in Q)
for i,j in itertools.combinations(range(5),2):
 assert np.array_equal(P[i]@P[j]@P[i],144*P[i]) # Pi Pj Pi = Pi/4
 assert np.array_equal(P[j]@P[i]@P[j],144*P[j])

# The full right action permutes the five markings by the natural A5 action.
keys={m.tobytes():i for i,m in enumerate(P)}
right_perm_counts=collections.Counter()
for g in range(120):
 p=[Vinv[qm(V[h],V[g])] for h in range(120)]
 sig=tuple(keys[Pi[np.ix_(p,p)].tobytes()] for Pi in P)
 assert sorted(sig)==list(range(5))
 right_perm_counts[sig]+=1
assert len(right_perm_counts)==60
assert set(right_perm_counts.values())=={2}
assert right_perm_counts[tuple(range(5))]==2

# Left translations commute with all mark/projector choices.
for g in range(120):
 p=[Vinv[qm(V[g],V[h])] for h in range(120)]
 assert np.array_equal(Z25[np.ix_(p,p)],Z25)
 assert all(np.array_equal(M[np.ix_(p,p)],M) for M in P)

# Ten pair-intersection projectors T_ij=Z_ij/72, all exact.
pairs=list(itertools.combinations(range(5),2))
T={}
for i,j in pairs:
 # (4 Qi Qj Qi-Qi)/3 where Qi=Qnum/24; simplify numerator by 576:
 E=4*(Q[i]@Q[j]@Q[i])-24**2*Q[i]
 assert np.all(E%576==0)
 Z=E//576                  # T=Z/72
 assert np.array_equal(Z@Z,72*Z)
 assert np.trace(Z)==72*5
 assert np.array_equal(Z@Q[i],24*Z) and np.array_equal(Z@Q[j],24*Z)
 assert np.array_equal(A@Z,np.zeros((120,120),dtype=np.int64))
 T[i,j]=Z
assert np.array_equal(sum(T.values()),6*Z25)   # sum T =2P25
for i in range(5):
 star=sum((T[p] for p in pairs if i in p),np.zeros((120,120),dtype=np.int64))
 assert np.array_equal(star,4*Q[i])           # star sum=4/3 Qi
for a,b in itertools.combinations(pairs,2):
 assert np.array_equal(T[a]@T[b]@T[a],576*T[a]) # Ta Tb Ta=Ta/9

# One common rank5 Petersen Seidel class from the marking-free intersections.
def triple_type(edges):
 return tuple(sorted(collections.Counter(x for e in edges for x in e).values(),reverse=True))
triple_counts=collections.Counter()
for a,b,c in itertools.combinations(pairs,3):
 tag=triple_type((a,b,c))
 sig=1 if tag==(2,2,1,1) else -1
 assert np.array_equal(T[a]@T[b]@T[c]@T[a],sig*13824*T[a])
 triple_counts[(str(tag),str(sig))]+=1
assert sum(triple_counts.values())==120
assert sum(n for (t,s),n in triple_counts.items() if s=='1')==60

# Graph-minimal stochastic kernel is uniquely determined by transitive edge symmetry.
e=Vinv[((4,0),(0,0),(0,0),(0,0))]
neighbor_ids=list(np.flatnonzero(A[e]))
assert len(neighbor_ids)==12
s=neighbor_ids[0]
conjugacy_orbit={Vinv[qm(qm(V[g],V[s]),conjugate(V[g]))] for g in range(120)}
assert conjugacy_orbit==set(neighbor_ids)
assert all(np.array_equal(A[np.ix_(p,p)],A)
           for p in ([Vinv[qm(V[g],V[h])] for h in range(120)] for g in range(120)))

# On the 25-band, 5 and 10 symmetric positive-effect resolutions have
# unique weights, and a conditioned 4-effect one is fixed for every marking.
# P_i/2, Q_i/3, T_ij/2 and (3/4)T_ij (sum over j!=i) respectively.
for p,Z in T.items():
 i,j=p
 for k in range(5):
  factor=1728 if k in p else 576
  assert np.array_equal(Z@Q[k]@Z,factor*Z) # compressed Q eigen 1 or 1/3
 for q in pairs:
  factor=5184 if q==p else 576
  assert np.array_equal(Z@T[q]@Z,factor*Z)  # compressed T eigen 1 or 1/9

# Centre parity: every member of the 25-band is even under quaternion -1.
negative=next(i for i,q in V.items() if q==((-4,0),(0,0),(0,0),(0,0)))
parity=[Vinv[qm(V[negative],V[h])] for h in range(120)]
assert all(np.array_equal(M[np.ix_(parity,range(120))],M) for M in (Z25,*P,*Q,*T.values()))

certificate={
 'version':'Paper00-GraphClosureDiscovery-v1_4',
 'scope':'native finite 600-cell graph, exact 25-band and natural positive-effect algebra; no physical occurrence',
 'sources_sha256':sha,
 'source_origin':{'paper1b':'Paper1B-ExceptionalGeometry-v1_18.tex',
 'theorems':['p1b:thm:v3023-five-coset-adjacency','p1b:thm:v3027-hurwitz-character-zero-modes',
 'p1:cor:v3026-twisted25-adjacency-kernel'],
 's3_archive':'Paper00-S3StructureNetwork-v1_40'},
 'quaternionic_source_free_construction':{'order_four_elements':30,'sylow_Q8_subgroups':5,
  'each_Q8_order':8,'P10_from_Q8_average':True,'matches_marked_C3_local_projector':True},
 'exact_projector_ranks':{'P25':25,'five_P10':[10]*5,'five_Q15':[15]*5,'ten_T5':[5]*10},
 'right_action':{'distinct_markings':5,'distinct_permutations':len(right_perm_counts),
 'elements_per_permutation':2,'image':'A5, two-transitive on five markings'},
 'exact_identities':{
 'sum_P10':'2 P25','sum_Q15':'3 P25','P_i P_j P_i':'(1/4) P_i, all ordered i!=j',
 'Tij':'(4 Qi Qj Qi-Qi)/3', 'sum_Tij':'2 P25',
 'sum_star_Tij':'(4/3) Qi', 'Ta Tb Ta':'(1/9)Ta for all a!=b',
 'Ta Tb Tc Ta':'sigma_abc Ta/27; sigma + iff three labels form a 3-edge path on four vertices',
 'A600 T':'0 for all ten T'},
 'signed_petersen_triple_counts':{f'{k[0]} / {k[1]}':v for k,v in triple_counts.items()},
 'symmetric_stochastic_600_walk':{'nearest_neighbors':12,'conjugacy_orbit_size':12,
 'unique_invariant_normalized_nearest_edge_probability':'1/12'},
 'exact_povm_resolutions':{'five_P10':'{P_i/2}, sum=P25',
 'five_Q15':'{Q_i/3}, sum=P25',
 'ten_T5':'{T_ij/2}, sum=P25',
 'conditioned_star':'{3T_ij/4}_{j!=i}, sum=Qi'},
 'mathematical_probabilities':{
 'state_in_Pi_for_five_P_POVM':{'own':'1/2','each_other':'1/8'},
 'state_in_Tij_for_five_Q_POVM':{'two_endpoints':'1/3 each','other_three':'1/9 each'},
 'state_in_Ta_for_ten_T_POVM':{'own':'1/2','other_nine':'1/18 each'},
 'state_in_Tij_for_star_at_i':{'own_edge':'3/4','other_three':'1/12 each'}},
 'limits':{'single_rank15_from_unmarked_GxG':'obstructed by irreducible quintet-biquintet 25D representation',
 'Spin4_H1_identification':'not an equivariant consequence; center parity mismatch',
 'physical_action':'not selected', 'physical_decay':'not derived', 'physical_measurement':'not occurred'},
 'all_assertions_passed':True
}
(root/'Paper00-GraphClosureDiscovery-v1_4.json').write_text(json.dumps(certificate,indent=2)+'\n')
print('PASS v1_4 exact unmarked fusion, 120 right actions, 10 pair channels, 45 overlaps, 120 triples, POVMs and symmetry')
print('derived five Q8 subgroups',list(quaternion_subgroups.keys()));print('triple sign counts',dict(triple_counts));print('certificate',root/'Paper00-GraphClosureDiscovery-v1_4.json')
