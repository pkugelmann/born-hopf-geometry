#!/usr/bin/env python3
"""Exact source-anchored checks for GC-40..44, Paper II-C endpoint rigidity.

This program checks the nontrivial finite symbolic identities used in the
proof. It does not turn an open six-effect existence question into a no-go.
"""
from pathlib import Path
from hashlib import sha256
import json, sys, zipfile
from sympy import (Matrix,eye,zeros,diag,Rational,sqrt, simplify, I)

ROOT = Path(__file__).resolve().parent
PAPER_ZIP = Path('/mnt/data/Paper00-PapersMinimal-v3_041.zip')
SOURCE_NAME='Paper2C-ReciprocalLocalization-v2_170.tex'
pass_checks={}

def check(name, condition):
    assert bool(condition), name
    pass_checks[name] = 'PASS'

# 1. The compiled source matches the retained native theorem labels.
src=(ROOT/'Source'/SOURCE_NAME).read_bytes() if (ROOT/'Source'/SOURCE_NAME).is_file() else zipfile.ZipFile(PAPER_ZIP).read(SOURCE_NAME)
if True:
    for s in ['p2c:thm:v226-equality','p2c:cor:v226-five',
              'p2c:thm:v255-seven-outcome-attainment',
              'p2c:thm:v266-six-trines','p2c:cor:v266-outcome-count']:
        check('source:' + s, s.encode() in src)
    check('insertion label not already in source', b'p2c:thm:vGC18-six-endpoint-rigidity' not in src)

# 2. Exact intrinsic geometric coordinates, R=1, in basis
# e0, u1..u4, w12,w13,w14,w23,w24,w34.
wedge={(0,1):5,(0,2):6,(0,3):7,(1,2):8,(1,3):9,(2,3):10}
Y=[zeros(11,11) for _ in range(4)]
for a in range(4):
    Y[a][0,a+1] = Y[a][a+1,0] = Rational(1,2)
    for b in range(4):
        if a==b: continue
        k=wedge[(min(a,b),max(a,b))]
        v=(1 if a<b else -1)*sqrt(2)/3
        Y[a][b+1,k] = Y[a][k,b+1] = v
spec=Y[0].eigenvals()
expected={Rational(1,2):1,-Rational(1,2):1,sqrt(2)/3:3,-sqrt(2)/3:3,0:3}
check('exact 11d geometric directional spectrum', spec == expected)
check('negative 5-simplex geometric effect eigenvalue', (1-2/sqrt(3))<0)

# 3. Six-frame Naimark complement classification, symbolic nonuniform witness.
# This is an exact **design** example, not a positive six-effect POVM.
t = Matrix([Rational(1,2),-Rational(1,2),sqrt(2)/4,-sqrt(2)/4,sqrt(2)/4,-sqrt(2)/4])
w=Matrix([(1-x*x)/5 for x in t]); q=Matrix([sqrt(x) for x in w])
check('nonuniform t norm 1', simplify(t.dot(t)-1)==0)
check('weights sum 1', simplify(sum(w)-1)==0)
check('nonuniform orthogonality t sqrtw',simplify(t.dot(q))==0)
check('strict positive sub-fifth nonuniform weights',all(0<x<Rational(1,5) for x in w))
Ngram=eye(6)-q*q.T-t*t.T
check('Naimark complement orthogonal projector', (Ngram*Ngram-Ngram).applyfunc(simplify)==zeros(6))
check('Naimark complement annihilates t and sqrtw', (Ngram*t).applyfunc(simplify)==zeros(6,1) and (Ngram*q).applyfunc(simplify)==zeros(6,1))
check('Naimark complement diagonal normalizations',all(simplify(Ngram[i,i]-4*w[i])==0 for i in range(6)))
G=Matrix(6,6,lambda i,j:simplify(Ngram[i,j]/(4*q[i]*q[j])))
check('reconstructed unit direction Gram', all(simplify(G[i,i]-1)==0 for i in range(6)))
check('reconstructed zero first moment', (G*w).applyfunc(simplify)==zeros(6,1))
check('reconstructed isotropic second moment', (G*diag(*w)*G-G/4).applyfunc(simplify)==zeros(6))
check('reconstructed Gram rank 4', G.rank()==4)
check('genuinely nonuniform design exists',len(set(w))==2)
check('all nonuniform Gram offdiagonal formula',all(simplify(G[i,j]+(1+t[i]*t[j]/(q[i]*q[j]))/4)==0 for i in range(6) for j in range(6) if i!=j))

# 4. Equal weights -> exactly two orthogonal trines.
t0=Matrix([1,-1,1,-1,1,-1])/sqrt(6)
w0=Matrix([Rational(1,6)]*6)
q0=Matrix([1/sqrt(6)]*6)
G0=Matrix(6,6,lambda i,j:simplify((eye(6)-q0*q0.T-t0*t0.T)[i,j]/(4*q0[i]*q0[j])))
check('uniform six t signs 3+3',sum(1 for i in t0 if i>0)==3 and sum(1 for i in t0 if i<0)==3)
check('same-sign trine inner products',all(simplify(G0[i,j]+Rational(1,2))==0 for i in range(6) for j in range(i+1,6) if t0[i]*t0[j]>0))
check('opposite-sign trine spaces orthogonal',all(G0[i,j]==0 for i in range(6) for j in range(i+1,6) if t0[i]*t0[j]<0))
check('uniform support has impossible r0',sqrt(34)/3>sqrt(3))

# 5. The 5+1 branch: simplex inversion coefficients always sum 1.
# For arbitrary sixth label x in four dimensions the mean cancels exactly.
v=Matrix([1,2,3,4])
# Gram-simplex centered projection: n_i as 5 vectors in R4, sum n_i=0.
simplex_g=Matrix(5,5,lambda i,j: 1 if i==j else -Rational(1,4))
check('5-simplex barycenter zero', simplex_g*Matrix([1]*5)==zeros(5,1))
check('5-simplex Gram has rank 4',simplex_g.rank()==4)
check('5+1 subtraction coefficients sum one for arbitrary x6',simplex_g*Matrix([1]*5)==zeros(5,1))
# This is independent of x6 because sum_i n_i=0; source proof supplies
# the negative eigenvalue making any coefficient >=0 fatal.

# 6. Exact Clifford support intersection example and general anticommutation.
s1=Matrix([[0,1],[1,0]]); s2=Matrix([[0,-I],[I,0]]);s3=Matrix([[1,0],[0,-1]])
Id2=eye(2)
from sympy.physics.quantum import TensorProduct
Gamma=[TensorProduct(s1,Id2),TensorProduct(s2,Id2),TensorProduct(s3,s1),TensorProduct(s3,s2)]
for a in range(4):
    for b in range(4):
        check(f'Clifford anticommutator {a}{b}',Gamma[a]*Gamma[b]+Gamma[b]*Gamma[a]==(2*eye(4) if a==b else zeros(4)))
check('positive eigenspaces e1,e2 intersect trivially', ((Gamma[0]-Gamma[1])*(Gamma[0]-Gamma[1])-2*eye(4)).applyfunc(simplify)==zeros(4))

# 7. An entirely scalar, H-independent obstruction for opposite signs.
a=Rational(1,20)
b=sqrt(Rational(199,800))
t_extreme=Matrix([a,-a,b,-b,b,-b])
w_extreme=Matrix([(1-x*x)/5 for x in t_extreme])
check('asymmetric negative-control complement normalized',simplify(t_extreme.dot(t_extreme)-1)==0 and simplify(t_extreme.dot(Matrix([sqrt(x) for x in w_extreme])))==0)
alpha_sq=simplify(w_extreme[0]/t_extreme[0]**2)
beta_sq=simplify(w_extreme[2]/t_extreme[2]**2)
check('negative-control alpha rational',alpha_sq==Rational(399,5))
check('negative-control beta rational',beta_sq==Rational(601,995))
check('pairwise Loewner inequality fails exactly', (alpha_sq+beta_sq+2)**2-64*alpha_sq*beta_sq>0)
check('pairwise Loewner inequality fails not by rounding',alpha_sq+beta_sq-8*sqrt(alpha_sq*beta_sq)+2>0)

# 8. Rigidity of sign partitions.
check('same-sign class of 5 has strict negative sum-square bound',5+2*10*(-Rational(1,4))==0)
check('only positive feasible sign partitions', [(p,6-p) for p in range(1,6) if p<=4 and 6-p<=4]==[(2,4),(3,3),(4,2)])

cert={
  'name':'Paper00-GraphClosureDiscovery-v1_8',
  'status':'EXACT_SYMBOLIC_CHECKS_PASS_BUT_SIX_VS_SEVEN_UNRESOLVED',
  'source_file':SOURCE_NAME,
  'source_sha256':sha256(src).hexdigest(),
  'checks':pass_checks,
  'pass_count':len(pass_checks),
  'remaining':'Find any asymmetric unit t and single Hermitian H meeting all six 11d LMIs, or certify infeasibility for all t.'
}
(ROOT/'Paper00-GraphClosureDiscovery-v1_8.json').write_text(json.dumps(cert,indent=2,sort_keys=True)+'\n')
print('PASS',len(pass_checks),'exact checks; source sha256',sha256(src).hexdigest())
