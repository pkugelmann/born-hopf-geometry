# Born–Hopf Geometry: exact six-outcome endpoint reduction

**Paper00-GraphClosureDiscovery-v1_8 · 19 November 2026**  
**Status:** new exact mathematical rigidity and branch eliminations for the Paper II-C optimal-radius localization frontier. No physical detector or GP3 occurrence is asserted. No change to the authoritative source or DAG.

## Source chain and observable

Source: `Paper2C-ReciprocalLocalization-v2_170.tex` in `Paper00-PapersMinimal-v3_041.zip`. Exact upstream results:

- `p2c:thm:v226-equality` proves support saturation and a unit-sphere weighted spherical two-design for all protected-nonzero effects at the intrinsic optimum `r0 = sqrt(3) R`.
- `p2c:cor:v226-five` proves that 5 total effects fail there.
- `p2c:thm:v255-seven-outcome-attainment` provides a positive exact 7-effect realization.
- `p2c:thm:v266-six-trines` proves sharp fixed-support radius `sqrt(34) R/3` for the two-orthogonal-trines support.
- `p2c:cor:v266-outcome-count` explicitly leaves the unrestricted 6-vs-7 minimum at `r0` open.

Observable mathematical question: how many positive effects (not apparatus clicks known to occur) suffice for **exact first moments of the intrinsic four-position tuple** when every assigned position has length at most `r0`?

## GC-40: no geometry-only sixth effect at the optimal radius

**Theorem.** An exact first-moment six-effect POVM at `r0` cannot have only five protected-nonzero effects and one protected-zero (geometry-only) effect. The outcome label of the sixth effect is arbitrary within the permitted ball.

**Proof.** By the protected equality theorem, the five positive protected weights necessarily form a 5-column Parseval frame in `R^5`. They are a regular four-simplex: `w_i=1/5`, unit directions `n_i`, `sum_i n_i=0`, `n_i·n_j=-1/4` for `i!=j`. Let `G_i=P_G E_i P_G >=0` for the first five and `H=G_6>=0` for the sixth. Its assigned label is `x_6`; write `Y(n)=sum_a n_a Y_a` for the native geometric coordinate. Inverting the 5-simplex normalization and first moment identities gives, for all `i<=5`,

`G_i = G_i^0 - lambda_i H`,  
`G_i^0 = (I_G + 4 Y(n_i)/r0)/5`,  
`lambda_i = (1 + 4 n_i·x_6/r0)/5`, `sum_{i=1}^5 lambda_i=1`.

The directional native spectrum contains `-R/2`, hence every `G_i^0` has strictly negative eigenvalue `(1-2/sqrt(3))/5`. At least one `lambda_i>0`; for that `i`, `G_i <= G_i^0` in the Loewner order and therefore cannot be positive. Contradiction. This holds even if the sixth label is not on the endpoint sphere. A positive full-carrier effect with zero protected compression also has zero protected–geometric off-diagonal blocks, so none can rescue the contradiction. QED.

**Eliminated condition:** a putative six-outcome realization cannot be assembled by taking a saturated protected five-simplex and adding an arbitrary geometric repair effect. **All six effects must carry nonzero protected weight.**

## GC-41: full six-support parameterization from one Naimark complement

**Theorem.** If any six-effect endpoint realization exists, then all six labels equal `r0 n_i`, with positive protected weights `w_i` satisfying the tight moment design. Define a real `5 x 6` frame with columns

`f_i = sqrt(w_i) (1, 2 n_i)^T`.

Its row Gram is the identity: `F F^T=I_5`. The one-dimensional orthogonal complement is a unit vector `t in R^6`, unique up to overall sign, with

`F^T F = I_6 - t t^T`,  `w_i=(1-t_i^2)/5`, `sum_i t_i sqrt(w_i)=0`,

and for `i != j`,

`n_i·n_j = -(1+t_i t_j/sqrt(w_i w_j))/4`.

Conversely, for any real unit `t` with `|t_i|<1` and `sum_i t_i sqrt((1-t_i^2)/5)=0`, set `w_i=(1-t_i^2)/5`, choose the `4 x 6` orthonormal row frame `N` of the orthogonal complement of `span{sqrt(w),t}`, and put `n_i=N_{*i}/(2sqrt(w_i))`. These are unit vectors obeying the exact weighted two-design. Up to `O(4)` and outcome relabelling, the support is fully described by `t`.

**Proof.** The weighted two-design is precisely `FF^T=I_5`. Rank-nullity supplies a one-dimensional unit kernel. The diagonal and off-diagonal entries of `F^T F=I-tt^T` give all displayed identities. Conversely `sqrt(w)` and `t` are orthonormal; completing them to an orthonormal basis of `R^6` gives `N`. Its row identities give normalization/first moments; its column norms give `|n_i|^2=(1-w_i-t_i^2)/(4w_i)=1`. QED.

This is a complete **support parameterization**, not a claim that every such support admits a positive geometric POVM.

## GC-42: the spinor effects are uniquely fixed and the full problem has one free Hermitian matrix

**Theorem.** If any six-effect endpoint POVM exists, then after harmless central pinching it has precisely

`E_i = G_i direct_sum 2 w_i P_+(n_i)`,  
`G_i = w_i (I_G + 4 Y(n_i)/r0) + t_i sqrt(w_i) H`,

where **one** Hermitian `11 x 11` matrix `H` is shared by all six effects. Thus endpoint existence for six effects is equivalent to finding admissible `t` as in GC-41 and one Hermitian `H` such that

`w_i(I_G+4Y(n_i)/r0)+t_i sqrt(w_i)H >= 0`, `i=1,...,6`.

**Proof.** The canonical matrices `G_i^0=w_i(I_G+4Y(n_i)/r0)` satisfy all five geometric moment equations by the design. Their differences from any proposed `G_i` lie in the one-dimensional kernel of the `5 x 6` label/moment matrix, generated by `c_i=t_i sqrt(w_i)`. Hence `G_i-G_i^0=c_i H` for one Hermitian `H`. In the protected block the canonical `S_i^0=2w_iP_+(n_i)` also meets normalization and moments; any difference must be `c_i K` for one Hermitian `4 x 4` matrix `K`. For every nonzero `c_i`, the saturation support rule forces `K=P_+(n_i) K P_+(n_i)`. There are at least two distinct directions with nonzero `c_i` (proved in GC-43 below). But for distinct unit `n,m` the intersection of their Clifford positive eigenspaces is zero: if `gamma(n)u=gamma(m)u=u`, then `gamma(n-m)u=0`, and `gamma(n-m)^2=|n-m|^2 I` implies `u=0`. Hence `K=0`. Finally central pinching `E_i -> P_GE_iP_G + P_SE_iP_S` preserves positivity, normalization and first moments because the native coordinate tuple is block-diagonal. Conversely the displayed positive blocks produce a valid full POVM. QED.

**What is eliminated:** six independent geometric effect matrices, all freely chosen protected effect matrices, and arbitrary six-point coordinates. Only one `t` and one `H` remain in an explicit finite semidefinite feasibility problem.

## GC-43: strict weights, mixed-sign correction and two allowed sign partitions

**Theorem.** For any hypothetical six-effect endpoint solution,

`0 < w_i < 1/5` and `t_i != 0` for all six indices;

`t` contains both positive and negative entries; their counts are necessarily `(2,4)` or `(3,3)` up to exchanging signs. The shared correction `H` must be indefinite.

**Proof.** Positivity and GC-40 give `w_i>0`. From GC-41, `w_i<=1/5`; equality would imply `t_i=0`. But then `G_i=G_i^0` has negative eigenvalue `w_i(1-2/sqrt(3))`, contradiction; thus all inequalities are strict. Since `sum_i t_i sqrt(w_i)=0`, both signs occur. For any two indices of the same sign, the off-diagonal Gram formula gives `n_i·n_j < -1/4`. A same-sign class of five vectors would satisfy `|sum_{i=1}^5 n_i|^2 < 5 + 2*10*(-1/4)=0`, impossible. Each sign class therefore has at most four members; with six nonzero `t_i`, the only partitions are `2+4` and `3+3`. Finally `G_i^0` has a negative eigenvector `v_i` for every `i`. If `c_i>0`, positivity of `G_i^0+c_iH` forces `<v_i,Hv_i> >0`; if `c_j<0`, it forces `<v_j,Hv_j> <0`. Hence `H` is indefinite. QED.

## GC-44: uniform six-outcome endpoint branch is impossible

**Theorem.** No six-effect endpoint first-moment POVM has equal protected weights.

**Proof.** If `w_i=1/6`, then the diagonal frame equations give `t_i= +/-1/sqrt(6)`. Orthogonality to `sqrt(w)=(1,...,1)/sqrt(6)` forces three signs of each kind. For indices of the same sign, `n_i·n_j=-1/2`; for opposite signs, `n_i·n_j=0`. Therefore the support is **necessarily two orthogonal planar trines**, up to `O(4)`. The already source-proved fixed-support optimum (`p2c:thm:v266-six-trines`) is `sqrt(34)R/3 > sqrt(3)R=r0`, even allowing arbitrary geometric positive effect assignments. Thus no such endpoint POVM exists. QED.

This **removes the fixed-support premise** of the existing six-trines theorem *within the equal-protected-weight endpoint class*. It does not say that all six-effect POVMs at larger radii have this support, because endpoint Clifford saturation was used critically.

## GC-45: exact two-effect positivity obstruction, eliminating a class of asymmetric supports

For a hypothetical six-effect realization, define `Q_i=I_G+4Y(n_i)/r0`, `c_i=t_i sqrt(w_i)`, and `a_i=sqrt(w_i)/|t_i|>0`. Fix any pair with opposite signs, `t_i>0>t_j`. The two geometric positivity conditions give

`G_i/c_i = a_i Q_i + H >=0` and `G_j/|c_j|=a_jQ_j-H >=0`.

Adding them eliminates the unknown correction exactly:

`a_i Q_i + a_j Q_j >=0`.

The source-proved geometric directional spectrum `lambda_min(Y(v))=-R|v|/2`, together with `r0=sqrt(3)R`, makes this equivalent to

`(a_i+a_j)^2 >= (4/3)|a_i n_i+a_j n_j|^2`.

Insert GC-41's exact opposite-sign Gram identity `n_i·n_j = -1/4 + 1/(4a_i a_j)` to get the **pure scalar necessary condition**

`boxed{a_i^2+a_j^2-8a_i a_j+2 <= 0}`

for **every** opposite-sign pair. This is independent of `H`; its failure rules out the entire six-effect support. It is necessary, not sufficient, because different Loewner bounds need not admit one common matrix `H`.

As a certified negative control, take paired signs with `t=(a,-a,b,-b,b,-b)`, `a=1/20`, `b=sqrt(199/800)`. This is an admissible exact weighted spherical two-design: `|t|^2=2a^2+4b^2=1`, `t·sqrt(w)=0`. But for the pair of magnitudes `a,b`, the scalar condition fails: `a_i^2=399/5`, `a_j^2=601/995` and `a_i^2+a_j^2-8a_i a_j+2>0`. Thus **not every six-point spherical design can be completed to a geometric endpoint POVM**. No arbitrary numerical tolerance is used.

## Distinct conclusions and remaining open question

- **Closed exactly:** all five-protected/one-unprotected six-outcome attempts fail; all six endpoint candidates have strictly positive, strictly sub-`1/5` protected weights; the protected matrices are fixed, and their support has the Naimark parameterization; the equal-weight/symmetric six branch is excluded; the opposite-sign scalar inequality excludes further asymmetric designs. All six candidates must be asymmetric and solve one shared 11-dimensional Hermitian LMI.
- **Still open:** whether any asymmetric `t` and `H` satisfy all six LMI inequalities. Consequently the source's unrestricted `N_min(r0)=6 or 7` remains `6 or 7`, *not* automatically `7`.
- **Physical status:** these are exact intrinsic-position POVM capability results, not an occurring apparatus, decay law or measured spatial localization.

## Exact dependency crosswalk

`p2c:thm:v226-equality` + `p2c:cor:v226-five` + native geometric directional spectrum (Paper II-C's `p2c:thm:v266-five-threshold`) -> GC-40..43 and GC-45. GC-44 additionally consumes `p2c:thm:v266-six-trines`. Proposed target: Paper II-C immediately after `p2c:cor:v266-outcome-count`, with typed DAG notes on this same frontier. There is **no new assumption** and no promotion of physical occurrence. The author-supplied audit protocols remain controlling for any later integration/re-audit.
