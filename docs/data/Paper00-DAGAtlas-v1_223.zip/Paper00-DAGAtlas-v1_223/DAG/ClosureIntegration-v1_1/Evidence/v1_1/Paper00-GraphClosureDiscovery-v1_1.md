# Paper00 — Born–Hopf Graph-to-Proof Closure Discovery v1.1

**Date:** 2026-11-19. **Status:** independent mathematical discovery report and reproducible source-bridge proposal; **not** a modification of the authoritative papers, DAG, or S³ network. **Scope:** current papers v3.040, DAG atlas v1.190, S³ structure network v1.40, proof-chain audits v1.79. **Reference inputs:** included unmodified `input_data_v1_1/exceptional_600cell_instance.json` and `input_data_v1_1/hurwitz_cellular_v129_instance.json` from S³ network v1.40. SHA-256 hashes appear in the certificate JSON.

## Executive disposition

| ID | New result | Evidence | Status in source-level proof chain |
|---|---|---|---|
| GC-01 | Canonical vector transvection–solder normalization and precise factor-two mapping | Current II-C/I-C/III-A source theorem reconstruction; exact linear algebra | **Mathematical coefficient fixed; III-A composition/notation remains to be source-integrated** (`BH-IIIA-G-0005` open) |
| GC-02 | Exact effective resistance classes on the native 24-cell nearest Cayley graph | Full exact 24×24 rational Green function; all 276 pairs | **New mathematical theorem candidate**; no decay-width owner |
| GC-03 | Exact effective resistance classes on 600-cell nearest graph | Exact 9×9 equitable quotient; all 7,140 pairs checked independently to floating precision | **New mathematical theorem candidate**; no mass/clock owner |
| GC-04 | Five exact identities recovering each 24-cell adjacency from two-step 600-cell paths | Full 120×120 integer adjacency squared, all five cosets | **New exact graph constructor bridge**; strong candidate for S³ network/DAG incorporation |
| GC-05 | Exact 600-cell → 24-cell chain-complex/edge-curl transport | Five independent oriented incidence complexes, exact integer polynomial and eight moments each | **New derivation path for existing VII-A curvature theorem**; physical EM Hessian not thereby generated |
| GC-06 | Canonical two-step return Markov kernel and spectral normalization | Exact integer adjacency identity and rational Markov matrix | **Derived mathematical corollary**, conditional on choosing the uniform parent nearest-neighbour walk |

## Source and audit chain (do not infer from labels alone)

Current sources explicitly inspected:

- `Paper2C-ReciprocalLocalization-v2_170.tex`, theorem `p2:thm:canonical-transvection-bridge` (near lines 628–660), proves the unique inversion-odd inverse of evaluation.
- `Paper1C-M8Geometry-v1_142.tex`, theorem `p1b:thm:cartan` (near lines 672–698), proves the diagonal Cartan connection and relative solder.
- `Paper3B-SpectralAction-v1_190.tex`, theorem `p3b:thm:v187-m8-cartan-split` (near lines 1590–1625), gives the relative solder's anti-diagonal evaluation.
- `Paper3A-GeneratedDynamics-v1_178.tex`, `p3a:cor:v187-rank-four-parent-root` and preceding vector-descent paragraph (near lines 3290–3318), contains the untyped transvection symbol `τ`.
- `Paper7A-QCDKernel-v1_179.tex`, theorem `p10:thm:v340-s3lit-hurwitz-edge-spectrum` (near lines 4490–4540), gives the existing native 24-cell unit-incidence edge-curvature spectrum; the present contribution derives its *whole incidence complex from the 600-cell*.
- `Paper3A-ProofChainAudit-v1_*.md` in proof-chain audit release v1.79, issue `BH-IIIA-G-0005`, distinguishes source annotation from an actual complete normalization proof.

The proof DAG is a **locator and dependency guide**; source proofs govern. The current network explicitly leaves physical hierarchy-source and response-owner boundaries open. No such status is promoted here.

## GC-01 — Exactly identify the vector factor, without claiming a completed source patch

Let `g = su(2)`, `p={(X,-X)}`, and evaluation `ev(X,-X)=2X`. From II-C,

\[
\tau_{\rm ev}(X)=(X/2,-X/2),\qquad
\iota_{-}(X)=(X,-X)=2\tau_{\rm ev}(X).
\]

From I-C and III-B the relative solder is `E(X,-X)=X`, so

\[
E=\tfrac12\,ev|_p,\qquad
E\circ\tau_{\rm ev}=\tfrac12\mathrm{id},\qquad
E\circ\iota_-=\mathrm{id}.
\]

Duality yields the *two equivalent descriptions with different named transvection maps*:

\[
(\tau_{\rm ev}^{*})^{-1}=ev^{*}=2E^{*},
\qquad (\iota_-^{*})^{-1}=E^{*}.
\]

**Source integration condition:** III-A's displayed composite `(τ*)^{-1}` followed by the II-C first-symbol map must specify `τ`, and must decide whether the resulting local coframe carries the evaluation or solder convention. Writing the canonical `τ_ev` but leaving the rest unchanged gives twice the cotangent injection of the solder convention; either explicitly include the `1/2` factor or use the anti-diagonal inclusion in the slot where the solder is intended. The source audit's `BH-IIIA-G-0005` remains open until this is actually committed and the complete composite is replayed. This is **not** a reopened issue about `m_p=1`, the rank-four determinant exponent, or the scalar clock.

## GC-02 — Exact native 24-cell resistance geometry

Take the eight source-selected nearest quaternionic Hurwitz generators `S_H` and form the undirected Cayley adjacency `A24`. Each vertex has degree eight. Define

\[
L_{24}=8I-A_{24},\qquad
G_{24}=(L_{24}+J/24)^{-1}-J/24,
\]

with `J` the all-ones 24×24 matrix. Independent integer construction and exact rational inversion verify

\[
L_{24}G_{24}=I-J/24,\qquad G_{24}\mathbf1=0,
\]

and exact spectrum `0^(1), 4^(4), 8^(9), 10^(8), 12^(2)`. For distinct unit-quaternion vertices, `R(u,v)=G_uu+G_vv−2G_uv` takes exactly:

| Exact real inner product | Count of unordered pairs | R, unit-edge resistance |
|---|---:|---:|
| `+1/2` | 96 | `23/96 = 115/480` |
| `0` | 72 | `11/40 = 132/480` |
| `−1/2` | 96 | `139/480` |
| `−1` | 12 | `3/10 = 144/480` |

These 276 pairs exhaust the complete native graph. For unit-edge conductance the corresponding relative **electrical** conductance values, nearest shell normalized to one, are `1, 115/132, 115/139, 115/144`. Electrical weights are **not** physical decay probabilities until a same-owner dynamics is derived to realize them.

## GC-03 — Exact 600-cell response via nine-shell quotient

The supplied exceptional geometry contains 120 quaternion vertices with entries `(a+b√5)/4`, 720 nearest edges and regular degree 12. Root at the identity. Its nine distinct real-coordinate shells (including the root) have populations

\[
(1,12,20,12,30,12,20,12,1).
\]

An exact nine-dimensional equitable adjacency quotient is

```text
B = [
 [0,12,0,0,0,0,0,0,0],
 [1,5,5,1,0,0,0,0,0],
 [0,3,3,3,3,0,0,0,0],
 [0,1,5,0,5,1,0,0,0],
 [0,0,2,2,4,2,2,0,0],
 [0,0,0,1,5,0,5,1,0],
 [0,0,0,0,3,3,3,3,0],
 [0,0,0,0,0,1,5,5,1],
 [0,0,0,0,0,0,0,12,0]
]
```

We verified the equitable condition for *every* source vertex, not merely a representative. Solve exactly

\[
(12I_9-B)g=e_0-\tfrac1{120}\mathbf1,
\qquad \sum_{k=0}^{8}n_kg_k=0.
\]

The Green column is

\[
g=\left(\tfrac{3701}{37800},\tfrac{2309}{151200},
\tfrac{73}{21600},\tfrac2{4725},-\tfrac1{360},
-\tfrac{23}{4725},-\tfrac{127}{21600},
-\tfrac{1091}{151200},-\tfrac{299}{37800}\right).
\]

The nine resistance values `2(g0−gk)` are:

```text
0,
119/720,
14293/75600,
737/3780,
1903/9450,
37/180,
5231/25200,
3179/15120,
40/189.
```

These shell values are exact rational arithmetic. A distinct full 120×120 floating-point inverse checked **every one of 7,140 unordered vertex pairs**, matching the quotient prediction below `2×10^−12` error. The exact extension to all pairs relies on source-defined binary-icosahedral vertex-transitive quaternion multiplication; the full-pair check is numerical corroboration, not a second exact proof.

## GC-04 — A precise missing 600-cell → 24-cell operator bridge

Let `A=A600`. The v1.40 five-color partition is a partition of the 120 vertices into five isometric 24-vertex Hurwitz cosets. Each vertex has three neighbours in every other coset and zero in its own, so its color quotient is

\[
B_5=3(J_5-I_5).
\]

Let `P_c` be the diagonal coordinate projection for one of these cosets and `A24^(c)` its internal **geometric** nearest adjacency, embedded by zeros outside the selected coset. The following exact integer identity holds for **each `c=0,1,2,3,4`**:

\[
\boxed{P_cA^2P_c=12P_c+3A_{24}^{(c)}}.
\]

**Proof certificate:** for all 24×24 blocks, the 24 diagonal entries are exactly 12, the 96 internal nearest undirected pairs have squared-adjacency entry exactly 3, and the remaining distinct pairs have entry exactly 0. This was verified for all five cosets, not just the marked tetrahedral subgroup. Equivalently the group-algebra nearest-neighbour convolution restricted to the Hurwitz subgroup has coefficient 12 on the identity and 3 on each of the eight nearest internal generators; all other internal group elements have coefficient 0.

Consequences:

\[
A_{24}^{(c)}=\frac13(P_cA^2P_c-12P_c),
\qquad
L_{24}^{(c)}=12P_c-\frac13P_cA^2P_c.
\]

Thus the internal graph is not the **one-step** restriction of the 600-cell (that restriction is the zero graph); it is the normalized **two-step return structure**. The canonical factor **3** counts distinct geometric paths, not fitted transition weights. This is a direct new S³ network mathematical relation, suitable for a new typed relation from the 600-cell nearest adjacency to each 24-cell nearest adjacency.

## GC-05 — Parent reconstruction of the existing native electromagnetic edge-curl theorem

For each `A24^(c)` reconstructed above, form the 96 unordered edges and all 96 triangular three-cliques. Orient each edge `(i,j)` with `i<j`, and triangle `(i,j,k)` with `i<j<k`. The boundary/coboundary signs are chosen as the usual simplicial convention. Independently form

\[
d_0:\mathbb R^{24}\to\mathbb R^{96},\qquad
 d_1:\mathbb R^{96}\to\mathbb R^{96},\qquad M_1=d_1^Td_1.
\]

For all five cosets, exact integer arithmetic checks `d1 d0=0`, the polynomial identity

\[
\boxed{M_1(M_1-I)(M_1-2I)(M_1-4I)(M_1-5I)
(M_1-8I)(M_1-9I)(M_1^2-9M_1+16I)=0},
\]

and the first eight exact trace moments

```text
Tr(M1^k), k=0,...,7:
96, 288, 1440, 8352, 53280, 363168, 2600352, 19337760.
```

They agree with the spectrum already established in Paper VII-A:

\[
\begin{split}
\operatorname{Spec}(M_1)={}&0^{(23)}\oplus1^{(6)}\oplus2^{(16)}
\oplus\left(\frac{9-\sqrt{17}}2\right)^{(9)}
\oplus4^{(12)}\\
&\oplus5^{(16)}\oplus\left(\frac{9+\sqrt{17}}2\right)^{(9)}
\oplus8^{(4)}\oplus9^{(1)}.
\end{split}
\]

**Meaning:** a second independent route now reconstructs the *underlying* edge/face geometry from the parent 600-cell, so the VII-A finite unit-incidence operator can be generated from its parent adjacency. The existing theorem already proved its spectrum; this proposal supplies an upstream constructor, **not** a new physical photon/Hessian theorem.

## GC-06 — Derived conditional two-step return stochastic law

Choose, **as a mathematical model only**, the uniform nearest-neighbour random walk on the 600-cell, `P600=A/12`. The two-step probability of returning to a given 24-vertex *coset* is

\[
\frac{12+3\cdot8}{12^2}=\frac14.
\]

Conditioning on return to the same coset gives an **exact** lazy 24-cell random walk:

\[
\boxed{K_c=\frac{P_cA_{600}^2P_c}{36}
=\frac13I_{24}+\frac1{12}A_{24}
=\frac13I_{24}+\frac23\left(\frac{A_{24}}8\right)}.
\]

In particular

\[
I_{24}-K_c=\frac1{12}L_{24},
\qquad \operatorname{Spec}(K_c)
=1^{(1)}\oplus\left(\frac23\right)^{(4)}
\oplus\left(\frac13\right)^{(9)}
\oplus\left(\frac16\right)^{(8)}\oplus0^{(2)}.
\]

The holding fraction `1/3`, move fraction `2/3`, and spectral gap `1/3` have no free **relative** rate parameter. However, a symmetric finite nearest-neighbour walk is reversible with a uniform stationary distribution and *does not encode a decay direction or seconds*. To explain observed directional decays, an **action-owned** energy/Clifford/sector-selection and physical clock are still indispensable; a free `h`-transform or arbitrarily imposed lower-energy graph orientation would not count as a Born–Hopf closure.

## Proposed route registration (not yet an official DAG update)

1. **Correct II-C → III-A vector normalization edge.** Route `p2:thm:canonical-transvection-bridge` plus `p1b:thm:cartan` plus `p3b:thm:v187-m8-cartan-split` to the vector-descent paragraph preceding `p3a:cor:v187-rank-four-parent-root`, specifying the exact factor and keeping issue `BH-IIIA-G-0005` *open until source composition is patched and checked*.
2. **Add typed S³ graph relation** `600-cell unit nearest adjacency` → `24-cell coset nearest adjacency`: `P_cA²P_c=12P_c+3A24^(c)` with five-coset exact proof certificate.
3. **Add derived finite operator** `L24=12I−P_cA²P_c/3` and new 24-/600-cell Green/resistance identities as mathematical response tools. Do not add physical current, decay or lifetime edges.
4. **Add new proof route for VII-A**: `600-cell adjacency` → `24-cell edge set` → `24-cell triangle incidence` → `p10:thm:v340-s3lit-hurwitz-edge-spectrum`. Existing spectrum theorem unchanged.
5. **Optional restricted evolution branch** `P600=A/12` → `K_c=I−L24/12`, marked `MATHEMATICAL_UNIFORM_WALK`, not an actual evolution-owner or continuous-time clock.

## Explicit frontier retained

The following are *not* solved by the above: selection of actual physical transition Hamiltonian/action and reducing sectors; placement of the Clifford hierarchy inside the graph-native transport; resolution of weak/electromagnetic/hadronic channel selection; mass/phase-space and energy release; conversion of graph time into lifetime units; normalized matrix elements and full partial widths; physical electromagnetic current and contact jets; derivation of measured branching ratios. An exact conductance response is a **candidate** geometric quantity to be tested against action-owned matrix elements, not a license to fit free weights or to claim a decay theory.

## Replay instructions and evidence levels

```bash
python Paper00-GraphClosureDiscovery-v1_1.py
```

The script reads only the two included source JSON inputs. It performs exact integer checks of five `A²` identities, five `d1d0=0` identities, five edge-curl annihilating polynomials and trace moments; a full exact rational 24-cell Green-function inverse and 276-pair classification; an exact 600-cell nine-shell Green-function calculation; and an independent 120×120 numerical Green-function inverse across all 7,140 pairs. It writes `Paper00-GraphClosureDiscovery-v1_1.json` containing source hashes and check results.

**Evidence taxonomy:** `GC-04` and the integer portion of `GC-05` are exact independent finite calculations; `GC-02` and the nine-shell portion of `GC-03` are exact rational calculations; full 600-cell Green pairing is numerical independent corroboration plus vertex-transitive group logic. The transvection/source repair and the physical-action owner require further source integration and formal replay. This is *not* a complete framework audit or validation of the entire 2,992-file DAG atlas.
