#!/usr/bin/env python3
"""Independent, exact finite-graph checks for Paper00-GraphClosureDiscovery-v1_1.

Inputs copied unmodified from S3 Structure Network v1_40.  No current
physics action, graph owner, or observational data is assumed.
Requires: numpy, sympy (Python 3.10+).  Run: python Paper00-GraphClosureDiscovery-v1_1.py
"""
from __future__ import annotations
import collections
import hashlib
import json
import math
from pathlib import Path
import numpy as np
import sympy as sp

HERE = Path(__file__).resolve().parent
DAT = HERE / "input_data_v1_1"
FILES = ("exceptional_600cell_instance.json", "hurwitz_cellular_v129_instance.json")
SOURCE_SHA256 = {name: hashlib.sha256((DAT / name).read_bytes()).hexdigest() for name in FILES}
Z = json.loads((DAT / FILES[0]).read_text())
H = json.loads((DAT / FILES[1]).read_text())

# 600-cell nearest graph (0/1 symmetric integer adjacency).
N = 120
A = np.zeros((N,N), dtype=np.int64)
for e in Z["nearest_edges"]:
    i,j = e["u"],e["v"]
    assert i != j and A[i,j] == 0 and A[j,i] == 0
    A[i,j] = A[j,i] = 1
assert len(Z["vertices"]) == N and len(Z["nearest_edges"]) == 720
assert np.array_equal(A,A.T) and np.all(A.sum(axis=1) == 12)
A2 = A @ A
V = {v["id"]:v for v in Z["vertices"]}
assert set(V) == set(range(N))
colors = {c: sorted(i for i in V if V[i]["color"] == c) for c in range(5)}
assert all(len(ids) == 24 for ids in colors.values())
assert all(np.all(A[np.ix_(ids, ids)] == 0) for ids in colors.values())
assert np.array_equal(np.array(Z["five_color_quotient_B"],dtype=int),
    np.array([[0 if c==d else 3 for d in range(5)] for c in range(5)]))
for c, ids in colors.items():
    for i in ids:
        assert all(int(A[i, colors[d]].sum()) == (0 if c == d else 3) for d in range(5))

# Coordinates are (a+b sqrt(5))/4.  Exact dot numerator:
# dot(q,r) = (a+b sqrt(5))/16, with integer pair (a,b).
def dot_num(u,v):
    a = sum(x[0]*y[0]+5*x[1]*y[1] for x,y in zip(u,v))
    b = sum(x[0]*y[1]+x[1]*y[0] for x,y in zip(u,v))
    return a,b

# Reconstruct all 5 24-cell internal graph adjacencies from the parent A^2.
T_by_color = {}
source_crosscheck = []
incidence_checks = []
t = sp.symbols('t')
annihilator = sp.Poly(t*(t-1)*(t-2)*(t-4)*(t-5)*(t-8)*(t-9)*(t*t-9*t+16),t)
coefs = [int(x) for x in annihilator.all_coeffs()]
source_24_units = H["hurwitz_group"]["units_2q"]

for c, ids in colors.items():
    T = np.zeros((24,24),dtype=np.int64)
    for a,i in enumerate(ids):
        for b,j in enumerate(ids):
            if i!=j and dot_num(V[i]["qcoords"],V[j]["qcoords"]) == (8,0):
                T[a,b] = 1
    assert np.array_equal(T,T.T) and np.all(np.diag(T)==0)
    assert np.all(T.sum(axis=1)==8) and int(T.sum())==192
    C = A2[np.ix_(ids,ids)]
    assert np.array_equal(C,12*np.eye(24,dtype=np.int64)+3*T)
    T_by_color[c] = T
    source_crosscheck.append({"coset":c,"identity_A600_squared_eq_12I_plus_3A24":True,
                              "internal_vertices":24,"internal_edges":int(T.sum()//2)})
    # Unit-incidence edge -> triangle chain complex, built only from T.
    edges = [(i,j) for i in range(24) for j in range(i+1,24) if T[i,j]]
    triangles = [(i,j,k) for i in range(24) for j in range(i+1,24)
                 for k in range(j+1,24) if T[i,j] and T[i,k] and T[j,k]]
    assert len(edges)==96 and len(triangles)==96
    edge_index = {edge:n for n,edge in enumerate(edges)}
    d0 = np.zeros((96,24),dtype=np.int64)
    for n,(i,j) in enumerate(edges): d0[n,i]=-1; d0[n,j]=1
    d1 = np.zeros((96,96),dtype=np.int64)
    for n,(i,j,k) in enumerate(triangles):
        d1[n,edge_index[(i,j)]]=1
        d1[n,edge_index[(j,k)]]=1
        d1[n,edge_index[(i,k)]]=-1
    assert not np.any(d1@d0)
    M = d1.T@d1
    # Independent exact integer spectral certificate: annihilator + moments.
    P = np.zeros((96,96),dtype=np.int64)
    I = np.eye(96,dtype=np.int64)
    for coef in coefs:
        P = P@M+coef*I
    assert not np.any(P), 'Exact integer annihilating polynomial failed'
    moments = []
    power = I.copy()
    for k in range(8):
        moments.append(int(np.trace(power)))
        power = power@M
    assert moments == [96,288,1440,8352,53280,363168,2600352,19337760]
    expected = ([0]*23+[1]*6+[2]*16+[(9-math.sqrt(17))/2]*9+[4]*12+
                [5]*16+[(9+math.sqrt(17))/2]*9+[8]*4+[9])
    actual = np.linalg.eigvalsh(M)
    assert np.allclose(actual,sorted(expected),atol=1e-12)
    assert sum(abs(actual)<1e-10)==23
    incidence_checks.append({"coset":c,"C0_C1_C2":[24,96,96],
       "d1_d0_equals_zero":True,"rank_M1":73,"zero_M1":23,
       "M1_annihilator_exact_integer_verified":True,
       "M1_moments_0_7_exact_integer_verified":True,
       "numerical_spectrum_max_diff":float(max(abs(actual-np.array(sorted(expected)))) )})

# Check that the canonical Hurwitz unit-group nearest graph is the color-0 block.
idmap={tuple(v):i for i,v in enumerate(source_24_units)}
assert len(idmap)==24
color0_qs=[tuple(int(x[0]//2) for x in V[i]["qcoords"])
           for i in colors[0]]
assert set(color0_qs)==set(idmap)
canon_24 = np.zeros((24,24),dtype=np.int64)
Hg=H["hurwitz_group"]
for i in range(24):
    for g in Hg["nearest_neighbor_generators"]:
        canon_24[i,Hg["multiplication_table"][i][g]]=1
perm=np.array([idmap[k] for k in color0_qs])
assert np.array_equal(T_by_color[0],canon_24[np.ix_(perm,perm)])

# Exact rational 24-cell Green operator and all 276 resistance entries.
L24 = 8*sp.eye(24)-sp.Matrix(canon_24.tolist())
J24 = sp.ones(24,24)/24
G24 = (L24+J24).inv()-J24
assert L24*G24 == sp.eye(24)-J24
assert G24*sp.ones(24,1) == sp.zeros(24,1)
charpoly = sp.factor(L24.charpoly(t).as_expr())
assert sp.expand(charpoly-t*(t-4)**4*(t-8)**9*(t-10)**8*(t-12)**2)==0
R24 = collections.defaultdict(collections.Counter)
for i in range(24):
    for j in range(i+1,24):
        dot = sp.Rational(sum(x*y for x,y in zip(source_24_units[i],source_24_units[j])),4)
        rij = sp.factor(G24[i,i]+G24[j,j]-2*G24[i,j])
        R24[str(dot)][str(rij)]+=1
assert dict(R24)=={
  "1/2":collections.Counter({"23/96":96}),
  "0":collections.Counter({"11/40":72}),
  "-1/2":collections.Counter({"139/480":96}),
  "-1":collections.Counter({"3/10":12})}

# Exact nine-shell equitable quotient and 600-cell Green column.
root = 119
assert V[root]["qcoords"] == [[4,0],[0,0],[0,0],[0,0]]
keys=sorted({tuple(v["qcoords"][0]) for v in V.values()},
            key=lambda q:q[0]+q[1]*math.sqrt(5),reverse=True)
shells = [sorted(i for i in V if tuple(V[i]["qcoords"][0])==key) for key in keys]
sizes=[len(ids) for ids in shells]
assert sizes==[1,12,20,12,30,12,20,12,1]
assert shells[0]==[root]
B=np.zeros((9,9),dtype=np.int64)
for k,ids in enumerate(shells):
    for l,other in enumerate(shells):
        vals=[int(A[i,other].sum()) for i in ids]
        assert len(set(vals))==1
        B[k,l]=vals[0]
assert np.all(B.sum(axis=1)==12)
D=sp.eye(9)*12-sp.Matrix(B.tolist())
rhs=sp.Matrix([sp.Rational(int(k==0),1)-sp.Rational(1,120) for k in range(9)])
# Invert on mean-zero by replacing one redundant row with weighted average zero.
for k in range(9):D[0,k]=sizes[k]
rhs[0]=0
g=D.inv()*rhs
assert sum(sizes[k]*g[k] for k in range(9))==0
assert g == sp.Matrix([sp.Rational(3701,37800),sp.Rational(2309,151200),
  sp.Rational(73,21600),sp.Rational(2,4725),-sp.Rational(1,360),
  -sp.Rational(23,4725),-sp.Rational(127,21600),
  -sp.Rational(1091,151200),-sp.Rational(299,37800)])
R600=[sp.factor(2*(g[0]-g[k])) for k in range(9)]
expected_R=[sp.Rational(0),sp.Rational(119,720),sp.Rational(14293,75600),
 sp.Rational(737,3780),sp.Rational(1903,9450),sp.Rational(37,180),
 sp.Rational(5231,25200),sp.Rational(3179,15120),sp.Rational(40,189)]
assert R600==expected_R

# Global numerical independent test (all 7140 vertex-pair resistances).
L120=12*np.eye(N)-A
J120=np.ones((N,N))/N
G120=np.linalg.inv(L120+J120)-J120
assert np.max(abs(L120@G120-(np.eye(N)-J120)))<1e-12
rmap={(4*k[0],4*k[1]):float(r) for k,r in zip(keys,R600)}
pairs=collections.Counter()
maxerror=0.0
for i in range(N):
    for j in range(i+1,N):
        dot=dot_num(V[i]["qcoords"],V[j]["qcoords"])
        r=G120[i,i]+G120[j,j]-2*G120[i,j]
        assert dot in rmap, ('Unexpected dot class',dot)
        maxerror=max(maxerror,abs(r-rmap[dot]))
        pairs[str(dot)]+=1
assert maxerror<2e-12 and sum(pairs.values())==7140

# Exact 24-cell induced return Markov chain from 600-cell 2-step random walk.
for c,ids in colors.items():
    K=sp.Matrix(A2[np.ix_(ids,ids)].tolist())/36
    T=sp.Matrix(T_by_color[c].tolist())
    assert K==sp.eye(24)/3+T/12
    assert K*sp.ones(24,1)==sp.ones(24,1)
    assert sp.eye(24)-K==(8*sp.eye(24)-T)/12

certificate={
  "release":"Paper00-GraphClosureDiscovery-v1_1",
  "scope":"exact finite geometry only; physical occurrence and rate calibration OPEN",
  "source_sha256":SOURCE_SHA256,
  "native_parent": {"vertices":120,"edges":720,"degree":12,"colors":5,
    "color_quotient_B": Z["five_color_quotient_B"]},
  "core_source_crosscheck":source_crosscheck,
  "core_Green": {"L_spectrum":"0^1 4^4 8^9 10^8 12^2",
    "resistances_by_dot":{x:dict(v) for x,v in sorted(R24.items())},
    "num_unordered_pairs":276},
  "parent_Green":{"shell_dot_qreal_numerators_div4":keys,
    "shell_sizes":sizes,"B":B.tolist(),
    "Green_column":[str(v) for v in g],
    "resistances":[str(v) for v in R600],
    "max_full_pair_numerical_error":maxerror,
    "num_unordered_pairs":7140,"class_pair_counts":dict(pairs)},
  "incidence_from_parent":incidence_checks,
  "induced_two_step_return":{"return_to_same_coset_probability":"1/4",
     "conditional_markov_kernel":"(1/3) I_24 + (1/12) A_24",
     "L_normalization":"I_24-K=L_24/12"},
  "source_bridge":{"p2:thm:canonical-transvection-bridge":"tau(X)=(X/2,-X/2)",
    "p1b:thm:cartan":"E(X,-X)=X",
    "p3a:cor:v187-rank-four-parent-root":"(tau^*)^{-1}=2E^* in relative Lie fibres"},
  "explicit_nonclaims":["not a complete physical decay theory",
     "not a physical generator owner or its units",
     "not proof of branching fractions, mass direction or lifetimes",
     "not a closed global momentum-position/gravitation bridge",
     "not a physical electromagnetic action occurrence"]}
assert len(source_crosscheck)==5 and len(incidence_checks)==5
outfile=HERE/"Paper00-GraphClosureDiscovery-v1_1.json"
outfile.write_text(json.dumps(certificate,indent=2,sort_keys=True)+"\n")
print("PASS: exact 24-cell resistance, exact 600-cell shells, 5 core adjacency identities,")
print("      5 integer edge-curvature certificates, 7140 global pair crosschecks.")
print("Output:",outfile)
