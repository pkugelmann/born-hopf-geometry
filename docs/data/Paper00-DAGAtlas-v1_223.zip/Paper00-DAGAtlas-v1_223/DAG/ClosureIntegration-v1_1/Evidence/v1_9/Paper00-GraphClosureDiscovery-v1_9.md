# Born–Hopf geometry — a sharp new six-outcome localization closure

**Paper00-GraphClosureDiscovery-v1_9 · 19 November 2026**  
**Supersedes:** `Paper00-GraphClosureDiscovery-v1_8` for the mathematical endpoint investigation.  
**Source owner:** Paper II-C, `Paper2C-ReciprocalLocalization-v2_170.tex` in `Paper00-PapersMinimal-v3_041.zip`.  
**Status:** proved, exact finite mathematical closure for the antipodal–tetrahedral support; overall unrestricted six-or-seven endpoint remains open. Proposed manuscript and DAG delta only; authoritative archives untouched.

## 1. The observable and source dependencies

The observable is the mathematical **least number of classical outcome labels** needed for a positive POVM with exact intrinsic four-position first moments `X_a^D` and bounded outcome-label radius. A mathematical POVM is not a physically occurring detector.

Source theorems consumed:

- `p2c:thm:v226-equality`: at the intrinsic optimum `r0=√3 R`, all protected-nonzero effects saturate on the sphere and form a weighted spherical two-design.
- `p2c:cor:v226-five`: five or fewer endpoint outcomes are impossible.
- `p2c:thm:v255-seven-outcome-attainment`: seven endpoints are sufficient at `r0`.
- `p2c:thm:v266-six-trines`: sharp radius `r6=√34 R/3` for six points on two orthogonal planar trines.
- `p2c:cor:v266-outcome-count`: the unrestricted six-versus-seven frontier is explicitly unresolved for `r0≤r<r6`.

The v1.8 mathematical result (GC-40–45) reduced all hypothetical endpoint six-effect rules to a Naimark vector `t`, with `∑t_i²=1`, protected weights `w_i=(1-t_i²)/5`, `∑t_i√w_i=0`, and exactly one common Hermitian 11×11 correction `H`. It excluded all equal weights, a geometry-only sixth outcome and several asymmetric candidate designs.

## 2. GC-46: sharp antipodal–tetrahedral six-support threshold

Choose fixed labels `x=rn` at six directions in `R^4`: one antipodal pair `±e1` and four regular-tetrahedral unit vectors `q_j` in `e1^⊥` with

```
q1=(0,+1,+1,+1)/√3       q2=(0,+1,-1,-1)/√3
q3=(0,-1,+1,-1)/√3       q4=(0,-1,-1,+1)/√3
```

**Theorem:** On the native intrinsic tuple `X^D = Y ⊕ (√3 R/4)γ`, unrestricted positive POVM effects exist on exactly this support if and only if

\[
\boxed{r\ge r_{\mathrm{tet}}=\frac{\sqrt{85+\sqrt{2617}}}{6}R
       \approx1.9447694968364264R.}
\]

In particular

\[
\sqrt3R < \frac{\sqrt{34}}3R < r_{\mathrm{tet}},
\qquad r_{\mathrm{tet}}^2-r_6^2=
\frac{\sqrt{2617}-51}{36}R^2>0.
\]

This is a **global exact optimum on the fixed six-point support**, not an optimum under an extra covariant POVM ansatz. Symmetry averaging is used solely in the impossibility proof; it preserves every feasible arbitrary effect assignment.

### 2.1 Symmetric resource reduction is exhaustive

Pinch the full effects along the native geometric/spinor central blocks. On the 11-dimensional geometric carrier in the form basis `R ⊕ R^4 ⊕ Λ² R^4`, average under the reflection `e1→−e1` and all `S4` symmetries of the regular tetrahedron. The geometric tuple is `O(4)`-equivariant. The pair-resource sum `A=G_{e1}+G_{−e1}` must then be scalar on the five inequivalent symmetry blocks

\[
\mathbf1\oplus\mathbf1_{\rm sign}\oplus
 V_3\oplus(e_1\wedge V_3)\oplus\Lambda^2 V_3
\qquad(1+1+3+3+3=11).
\]

Thus

\[
A=\operatorname{diag}(a_0,a_1,a_VI_3,a_MI_3,a_WI_3),
\quad 0\le a_0,a_1,a_V,a_M,a_W\le1,
\qquad B=I_G-A.
\]

The exact moments uniquely fix every averaged geometric effect:

\[
G_{\pm e_1}=\frac12\left(A\pm\frac{Y(e_1)}r\right),\quad
G_{q_j}=\frac14\left(B+\frac{3Y(q_j)}r\right).
\]

Set `s=(r/R)²`. The source's scalar/vector coefficient `R/2` and vector/bivector coefficient `√2 R/3` reduce **all** geometric positivity constraints to five scalar inequalities:

\[
\begin{aligned}
a_0a_1&\ge\frac1{4s}, &a_Va_M&\ge\frac2{9s},\\
(1-a_0)(1-a_V)&\ge\frac9{4s},
 &(1-a_1)(1-a_M)&\ge\frac2s,\\
(1-a_V)(1-a_W)&\ge\frac2s.
\end{aligned}
\]

No effect normalization or positivity degree of freedom remains hidden in this symmetric reduction.

### 2.2 Exact lower bound

The first and third inequalities imply `s≥5/2`, with equality excluded by the fourth. For `s>5/2`, eliminate `a0,a1,aM` and put `v=aV`. Feasibility requires

\[
N_s(v):=(-36s^2+81s)v^2+(36s^2-154s+160)v+20-8s\ge0.
\]

The rational elimination denominator is strictly positive on a feasible branch. The quadratic is concave in `v` and has exact discriminant

\[
\boxed{\operatorname{disc}_vN_s
=4(2s-5)(9s-20)(18s^2-85s+64).}
\]

For `5/2<s<(85+√2617)/36`, its discriminant is negative. Therefore `N_s(v)<0` for every real `v`, contradiction. This proves the stated lower bound **for all positive effect assignments**, not just diagonal ones.

### 2.3 Exact attainment

Set `s*=(85+√2617)/36` and choose

\[
\begin{aligned}
a_0&=(\sqrt{2617}-21)/128,& a_1&=(\sqrt{2617}-13)/136,\\
a_V&=(\sqrt{2617}-21)/136,&a_M&=(\sqrt{2617}-13)/144,\\
a_W&=0.
\end{aligned}
\]

All lie in `[0,1]`. They saturate the first four scalar positivity determinants; the fifth is strictly positive. The preceding formulas therefore give six **explicit positive geometric effects**, normalized and possessing all four exact first moments. The protected effects are independently fixed by the tetra-design weights:

\[
w_{\pm e_1}=\frac18,\quad w_{q_j}=\frac3{16},\qquad
S_n=w_n\left(I_S+\frac{\sqrt3R}r\gamma(n)\right).
\]

They are positive at `r=r_tet>√3R`; their weighted moment design is exact. Hence `E_n=G_n⊕S_n` is an explicit six-effect POVM at the threshold. It remains positive for every larger radius because the off-diagonal geometric couplings decrease as `1/r`.

## 3. GC-47: remove all two-level sign-class endpoint candidates

The v1.8 Naimark complement permits sign partitions `3+3` and `2+4` only. Suppose all positive entries of `t` have one common magnitude and all negative entries another (the most natural remaining two-level hypothesis).

- **`3+3`:** the two frame constraints force all six magnitudes to equal `1/√6`; the support is two orthogonal trines, excluded by the source's sharp `r6>r0` theorem and v1.8 GC-44.
- **`2+4`:** writing `t=(p,p,-q,-q,-q,-q)`, the frame equations give `p²=3/8`, `q²=1/16`, weights `1/8,1/8,3/16,3/16,3/16,3/16`. The exact Gram formula makes the positive pair antipodal, the four negative directions a regular tetrahedron, and the two sets orthogonal. GC-46 therefore excludes this case at `r0`.

**Conclusion:** every hypothetical six-effect endpoint rule must have genuinely varying absolute `t_i` *within at least one sign class*. Merely breaking the size of the two sign classes is insufficient.

The stronger result is not redundant with GC-45: the symmetric `2+4` design actually **passes** the earlier necessary opposite-sign scalar inequality by a margin of `−8/3`; the new cross-grade resource proof is needed to exclude it.

## 4. Exact verification, provenance and open frontier

`Paper00-GraphClosureDiscovery-v1_9.py` runs the original v1.8 exact tests and new SymPy checks of the quadratic discriminant, threshold, explicit resource identities, Naimark Gram, tetra design, normalization, all four geometric first moments and the exact five-dimensional invariant-resource commutant of the full tetrahedral symmetry group. The verifier passes **101 exact symbolic checks**. Its deterministic certificate is `Paper00-GraphClosureDiscovery-v1_9.json`. The retained `Source/` file is copied from the named `PapersMinimal v3_041` archive, not rewritten.

**Proposed manuscript owner:** Paper II-C after `p2c:cor:v266-outcome-count` and the previously proposed v1.8 endpoint-rigidity insertion. TeX insertion: `Paper2C-AntipodalTetraClosure-v1_1.tex`. Proposed DAG addition: `Paper00-GraphClosureDAGDelta-v1_7.json`. The authoritative paper, atlas, S³ network and audit archive are not changed by this mathematical investigation.

**Unclosed question:** there may still be an asymmetric `t` and Hermitian `H` meeting the six 11×11 LMIs at the intrinsic optimal radius. Until that unrestricted feasibility problem is proved or disproved, the source statement remains `N_min(√3R)=6 or 7`. No physical apparatus or occurrence is deduced here.

## 5. Next mathematically decisive move

The remaining target is to construct a **noncommutative dual certificate** for infeasibility of the entire `(t,H)` family, or exhibit an explicit asymmetric positive solution. Scalar pairwise tests alone cannot prove the global no-go, as the antipodal–tetra design demonstrates. A candidate certificate must exploit competition between the scalar–vector and vector–bivector blocks sharing the same four-dimensional vector resources.
