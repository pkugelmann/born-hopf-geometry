#!/usr/bin/env python3
"""Exact source-anchored checks for GC-40..47, Paper II-C endpoint rigidity.

This program checks the nontrivial finite symbolic identities used in the
proof. It does not turn an open six-effect existence question into a no-go.
"""
from pathlib import Path
from hashlib import sha256
import json, sys, zipfile
from sympy import (Matrix,eye,zeros,diag,Rational,sqrt, simplify, I)

ROOT = Path(__file__).resolve().parent
PAPER_ZIP = Path('/mnt/data/Paper00-PapersMinimal-v3_041.zip')
SOURCE_NAME='Paper2C-ReciprocalLocalization-v2_170.tex'
pass_checks={}

def check(name, condition):
    assert bool(condition), name
    pass_checks[name] = 'PASS'

# 1. The compiled source matches the retained native theorem labels.
src=(ROOT/'Source'/SOURCE_NAME).read_bytes() if (ROOT/'Source'/SOURCE_NAME).is_file() else zipfile.ZipFile(PAPER_ZIP).read(SOURCE_NAME)
if True:
    for s in ['p2c:thm:v226-equality','p2c:cor:v226-five',
              'p2c:thm:v255-seven-outcome-attainment',
              'p2c:thm:v266-six-trines','p2c:cor:v266-outcome-count']:
        check('source:' + s, s.encode() in src)
    check('insertion label not already in source', b'p2c:thm:vGC18-six-endpoint-rigidity' not in src)

# 2. Exact intrinsic geometric coordinates, R=1, in basis
# e0, u1..u4, w12,w13,w14,w23,w24,w34.
wedge={(0,1):5,(0,2):6,(0,3):7,(1,2):8,(1,3):9,(2,3):10}
Y=[zeros(11,11) for _ in range(4)]
for a in range(4):
    Y[a][0,a+1] = Y[a][a+1,0] = Rational(1,2)
    for b in range(4):
        if a==b: continue
        k=wedge[(min(a,b),max(a,b))]
        v=(1 if a<b else -1)*sqrt(2)/3
        Y[a][b+1,k] = Y[a][k,b+1] = v
spec=Y[0].eigenvals()
expected={Rational(1,2):1,-Rational(1,2):1,sqrt(2)/3:3,-sqrt(2)/3:3,0:3}
check('exact 11d geometric directional spectrum', spec == expected)
check('negative 5-simplex geometric effect eigenvalue', (1-2/sqrt(3))<0)

# 3. Six-frame Naimark complement classification, symbolic nonuniform witness.
# This is an exact **design** example, not a positive six-effect POVM.
t = Matrix([Rational(1,2),-Rational(1,2),sqrt(2)/4,-sqrt(2)/4,sqrt(2)/4,-sqrt(2)/4])
w=Matrix([(1-x*x)/5 for x in t]); q=Matrix([sqrt(x) for x in w])
check('nonuniform t norm 1', simplify(t.dot(t)-1)==0)
check('weights sum 1', simplify(sum(w)-1)==0)
check('nonuniform orthogonality t sqrtw',simplify(t.dot(q))==0)
check('strict positive sub-fifth nonuniform weights',all(0<x<Rational(1,5) for x in w))
Ngram=eye(6)-q*q.T-t*t.T
check('Naimark complement orthogonal projector', (Ngram*Ngram-Ngram).applyfunc(simplify)==zeros(6))
check('Naimark complement annihilates t and sqrtw', (Ngram*t).applyfunc(simplify)==zeros(6,1) and (Ngram*q).applyfunc(simplify)==zeros(6,1))
check('Naimark complement diagonal normalizations',all(simplify(Ngram[i,i]-4*w[i])==0 for i in range(6)))
G=Matrix(6,6,lambda i,j:simplify(Ngram[i,j]/(4*q[i]*q[j])))
check('reconstructed unit direction Gram', all(simplify(G[i,i]-1)==0 for i in range(6)))
check('reconstructed zero first moment', (G*w).applyfunc(simplify)==zeros(6,1))
check('reconstructed isotropic second moment', (G*diag(*w)*G-G/4).applyfunc(simplify)==zeros(6))
check('reconstructed Gram rank 4', G.rank()==4)
check('genuinely nonuniform design exists',len(set(w))==2)
check('all nonuniform Gram offdiagonal formula',all(simplify(G[i,j]+(1+t[i]*t[j]/(q[i]*q[j]))/4)==0 for i in range(6) for j in range(6) if i!=j))

# 4. Equal weights -> exactly two orthogonal trines.
t0=Matrix([1,-1,1,-1,1,-1])/sqrt(6)
w0=Matrix([Rational(1,6)]*6)
q0=Matrix([1/sqrt(6)]*6)
G0=Matrix(6,6,lambda i,j:simplify((eye(6)-q0*q0.T-t0*t0.T)[i,j]/(4*q0[i]*q0[j])))
check('uniform six t signs 3+3',sum(1 for i in t0 if i>0)==3 and sum(1 for i in t0 if i<0)==3)
check('same-sign trine inner products',all(simplify(G0[i,j]+Rational(1,2))==0 for i in range(6) for j in range(i+1,6) if t0[i]*t0[j]>0))
check('opposite-sign trine spaces orthogonal',all(G0[i,j]==0 for i in range(6) for j in range(i+1,6) if t0[i]*t0[j]<0))
check('uniform support has impossible r0',sqrt(34)/3>sqrt(3))

# 5. The 5+1 branch: simplex inversion coefficients always sum 1.
# For arbitrary sixth label x in four dimensions the mean cancels exactly.
v=Matrix([1,2,3,4])
# Gram-simplex centered projection: n_i as 5 vectors in R4, sum n_i=0.
simplex_g=Matrix(5,5,lambda i,j: 1 if i==j else -Rational(1,4))
check('5-simplex barycenter zero', simplex_g*Matrix([1]*5)==zeros(5,1))
check('5-simplex Gram has rank 4',simplex_g.rank()==4)
check('5+1 subtraction coefficients sum one for arbitrary x6',simplex_g*Matrix([1]*5)==zeros(5,1))
# This is independent of x6 because sum_i n_i=0; source proof supplies
# the negative eigenvalue making any coefficient >=0 fatal.

# 6. Exact Clifford support intersection example and general anticommutation.
s1=Matrix([[0,1],[1,0]]); s2=Matrix([[0,-I],[I,0]]);s3=Matrix([[1,0],[0,-1]])
Id2=eye(2)
from sympy.physics.quantum import TensorProduct
Gamma=[TensorProduct(s1,Id2),TensorProduct(s2,Id2),TensorProduct(s3,s1),TensorProduct(s3,s2)]
for a in range(4):
    for b in range(4):
        check(f'Clifford anticommutator {a}{b}',Gamma[a]*Gamma[b]+Gamma[b]*Gamma[a]==(2*eye(4) if a==b else zeros(4)))
check('positive eigenspaces e1,e2 intersect trivially', ((Gamma[0]-Gamma[1])*(Gamma[0]-Gamma[1])-2*eye(4)).applyfunc(simplify)==zeros(4))

# 7. An entirely scalar, H-independent obstruction for opposite signs.
a=Rational(1,20)
b=sqrt(Rational(199,800))
t_extreme=Matrix([a,-a,b,-b,b,-b])
w_extreme=Matrix([(1-x*x)/5 for x in t_extreme])
check('asymmetric negative-control complement normalized',simplify(t_extreme.dot(t_extreme)-1)==0 and simplify(t_extreme.dot(Matrix([sqrt(x) for x in w_extreme])))==0)
alpha_sq=simplify(w_extreme[0]/t_extreme[0]**2)
beta_sq=simplify(w_extreme[2]/t_extreme[2]**2)
check('negative-control alpha rational',alpha_sq==Rational(399,5))
check('negative-control beta rational',beta_sq==Rational(601,995))
check('pairwise Loewner inequality fails exactly', (alpha_sq+beta_sq+2)**2-64*alpha_sq*beta_sq>0)
check('pairwise Loewner inequality fails not by rounding',alpha_sq+beta_sq-8*sqrt(alpha_sq*beta_sq)+2>0)

# 8. Rigidity of sign partitions.
check('same-sign class of 5 has strict negative sum-square bound',5+2*10*(-Rational(1,4))==0)
check('only positive feasible sign partitions', [(p,6-p) for p in range(1,6) if p<=4 and 6-p<=4]==[(2,4),(3,3),(4,2)])

# 9. New sharp antipodal-tetrahedral six-support threshold (GC-46).
from sympy import symbols, factor, expand, discriminant
x,z=symbols('x z', real=True)
a0x=1-Rational(9,4)/(x*(1-z))
a1x=1/(4*x*a0x)
amx=Rational(2,9)/(x*z)
f= (1-a1x)*(1-amx)-2/x
N=factor(f.as_numer_denom()[0])
D=factor(f.as_numer_denom()[1])
# Polynomial equality after rational simplification; use together for normalized forms.
from sympy import together
N=factor(together(f).as_numer_denom()[0]); D=factor(together(f).as_numer_denom()[1])
Nexp=-36*x*x*z*z+36*x*x*z+81*x*z*z-154*x*z-8*x+160*z+20
check('resource feasibility numerator exact', expand(N-Nexp)==0)
check('resource feasibility denominator sign form', expand(D-9*x*z*(4*x*(1-z)-9))==0)
delta=factor(discriminant(N,z))
check('resource quadratic discriminant exact', simplify(delta-4*(2*x-5)*(9*x-20)*(18*x*x-85*x+64))==0)

qroot=sqrt(2617)
sstar=(85+qroot)/36
rstar=sqrt(sstar)
vstar=(qroot-21)/136
a0star=(qroot-21)/128
a1star=(qroot-13)/136
amstar=(qroot-13)/144
awstar=Rational(0)
check('threshold solves quadratic factor', simplify(18*sstar*sstar-85*sstar+64)==0)
check('threshold strictly exceeds known trines squared radius', sstar>Rational(34,9))
check('minimizing vertex position', simplify(vstar-(36*sstar*sstar-154*sstar+160)/(18*sstar*(4*sstar-9)))==0)
check('resource exact pair scalar-vector',simplify(a0star*a1star-1/(4*sstar))==0)
check('resource exact pair vector-mixed',simplify(vstar*amstar-2/(9*sstar))==0)
check('resource exact tetra scalar-vector',simplify((1-a0star)*(1-vstar)-Rational(9,4)/sstar)==0)
check('resource exact tetra axial-mixed',simplify((1-a1star)*(1-amstar)-2/sstar)==0)
check('remaining pure wedge resource positive',simplify((1-vstar)*(1-awstar)-2/sstar)>0)
check('all resource parameters within [0,1]',all(0<=p<=1 for p in [a0star,a1star,vstar,amstar,awstar]))
check('resource quadratic double root at threshold',simplify(N.subs({x:sstar,z:vstar}))==0 and simplify(simplify(N.diff(z)).subs({x:sstar,z:vstar}))==0)

# 10. Endpoint Naimark sign-class rigidity: 2+4 two-level ->
# antipodal pair orthogonal to regular tetrahedron, unlike two trines.
tpair=Matrix([sqrt(Rational(3,8)),sqrt(Rational(3,8))]+[-Rational(1,4)]*4)
wpair=Matrix([simplify((1-u*u)/5) for u in tpair]);qp=Matrix([sqrt(u) for u in wpair]);
check('two-level t norm', simplify(tpair.dot(tpair)-1)==0)
check('two-level t weighted centering', simplify(tpair.dot(qp))==0)
check('two-level protected weight multiplicities',list(wpair)==[Rational(1,8)]*2+[Rational(3,16)]*4)
GP=Matrix(6,6,lambda i,j:simplify(((eye(6)-qp*qp.T-tpair*tpair.T)[i,j])/(4*qp[i]*qp[j])))
check('two-level pair antipodal',GP[0,1]==-1)
check('two-level tetra mutual cosine -1/3',all(GP[i,j]==-Rational(1,3) for i in range(2,6) for j in range(i+1,6)))
check('two-level pair-tetra orthogonal',all(GP[i,j]==0 for i in range(2) for j in range(2,6)))
check('two-level design has Gram rank four',GP.rank()==4)
check('opposite sign scalar obstruction cannot reject tetra by itself',simplify(Rational(1,3)+3-8+2)==-Rational(8,3))

# 11. Exact six-effect construction at sstar; the geometric native
# first moments use the same Y_a and form basis as the paper source.
AA=diag(a0star,a1star,vstar,vstar,vstar,amstar,amstar,amstar,awstar,awstar,awstar)
BB=eye(11)-AA
n1=Matrix([1,0,0,0]);tet=Matrix([[1,1,1],[1,-1,-1],[-1,1,-1],[-1,-1,1]])/sqrt(3)
qs=[n1,-n1]+[Matrix([0]+list(tet.row(i))) for i in range(4)]
check('tetra sum zero',sum(qs[2:],zeros(4,1))==zeros(4,1))
check('tetra isotropic second moment',sum([u*u.T for u in qs[2:]],zeros(4,4))==diag(0,Rational(4,3),Rational(4,3),Rational(4,3)))
E_geo=[(AA+Y[0]/rstar)/2,(AA-Y[0]/rstar)/2]
for u in qs[2:]:
  Yn=sum([u[a]*Y[a] for a in range(4)],zeros(11,11))
  E_geo.append((BB+3*Yn/rstar)/4)
check('exact six geometric effect normalization',(sum(E_geo,zeros(11,11))-eye(11)).applyfunc(simplify)==zeros(11))
for a in range(4):
  mom=sum([rstar*qs[i][a]*E_geo[i] for i in range(6)],zeros(11,11))
  check('exact geometric moment '+str(a),(mom-Y[a]).applyfunc(simplify)==zeros(11))
# The spinor part needs no arbitrary effect: w_i[I+(r0/r) gamma(n_i)];
# its positivity is equivalent to r>=r0. Its exact moments follow from
# Gram identities below.
w_fixed=Matrix([Rational(1,8)]*2+[Rational(3,16)]*4)
check('fixed support spinor weights normalized',sum(w_fixed)==1)
check('fixed support spinor first design moment',sum([w_fixed[i]*qs[i] for i in range(6)],zeros(4,1))==zeros(4,1))
check('fixed support spinor second design moment',sum([w_fixed[i]*qs[i]*qs[i].T for i in range(6)],zeros(4,4))==eye(4)/4)
check('protected sector eigenvalues positive',rstar>sqrt(3))

# 12. Independently verify that tetrahedral twirling has exactly five
# symmetric resource parameters, rather than simply assuming the ansatz.
from itertools import combinations
pairs4=[(a,b) for a in range(4) for b in range(a+1,4)]
sym_generators=[
    diag(-1,1,1,1), # reflection along the antipodal-pair axis
    Matrix([[1,0,0,0],[0,0,1,0],[0,0,0,1],[0,1,0,0]]), # cycle e2,e3,e4
    Matrix([[1,0,0,0],[0,0,1,0],[0,1,0,0],[0,0,0,1]]), # swap e2,e3
    diag(1,-1,-1,1)  # two tetra-coordinate sign flips
]
def form_lift(g):
    U=eye(11)
    for a in range(4):
        for b in range(4): U[1+a,1+b]=g[a,b]
    for k,(a,b) in enumerate(pairs4):
        for j,(c,d) in enumerate(pairs4):
            U[5+k,5+j]=g[a,c]*g[b,d]-g[a,d]*g[b,c]
    return U
lifts=[form_lift(g) for g in sym_generators]
for k,(g,U) in enumerate(zip(sym_generators,lifts)):
    check(f'tetrahedral symmetry lift {k} orthogonal',U*U.T==eye(11))
    check(f'tetrahedral symmetry lift {k} preserves pair/tetra support',
          {tuple(g*q) for q in qs}=={tuple(q) for q in qs})
    check(f'tetrahedral symmetry lift {k} preserves resource A',
          (U*AA*U.T-AA).applyfunc(simplify)==zeros(11))
    check(f'tetrahedral symmetry lift {k} native Y covariance',
          all((U*Y[a]*U.T-sum([g[b,a]*Y[b] for b in range(4)],zeros(11))).applyfunc(simplify)==zeros(11) for a in range(4)))

columns=[]
for a in range(11):
    for b in range(a,11):
        unit=zeros(11);unit[a,b]=unit[b,a]=1
        columns.append(Matrix([x for U in lifts for x in (U*unit*U.T-unit)]))
linear=Matrix.hstack(*columns)
check('full tetra group symmetric commutant exactly 5-dimensional',linear.rank()==61)

cert={
  'name':'Paper00-GraphClosureDiscovery-v1_9',
  'status':'SHARP_ANTIPODAL_TETRA_BRANCH_CLOSED;_GLOBAL_6_VS_7_OPEN',
  'source_file':SOURCE_NAME,
  'source_sha256':sha256(src).hexdigest(),
  'checks':pass_checks,
  'pass_count':len(pass_checks),
  'remaining':'No global six-vs-seven closure: asymmetric within-sign weights may remain feasible; new sharp 2+4 symmetric branch ruled out.'
}
(ROOT/'Paper00-GraphClosureDiscovery-v1_9.json').write_text(json.dumps(cert,indent=2,sort_keys=True)+'\n')
print('PASS',len(pass_checks),'exact checks; source sha256',sha256(src).hexdigest())
