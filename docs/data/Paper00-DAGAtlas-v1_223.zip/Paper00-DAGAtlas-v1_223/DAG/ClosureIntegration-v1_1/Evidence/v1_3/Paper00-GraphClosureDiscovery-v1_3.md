# Born–Hopf geometry — graph closure discovery, v1.3

**Release:** `Paper00-GraphClosureDiscovery-v1_3` (successor to `v1_2`, dated 2026-11-19)  
**Source base:** `Paper00-PapersMinimal-v3_040(1).zip`, especially `Paper1B-ExceptionalGeometry-v1_18.tex`; `Paper00-S3StructureNetwork-v1_40(1).zip`, data files `exceptional_600cell_instance.json` and `twisted25_v127_instance.json`; DAG atlas v1.190 used to check dependency scope.  
**Output:** exact mathematical consequences, independent integer and rational verification, proposed source insertions. **Not** a claim of physical particle decay, measurement, field occurrence, action ownership, mass, coupling, or time conversion.  
**Integrity:** The provided paper/DAG/network ZIPs are *not modified*. This package proposes additions after complete algebraic checking.

## Executive result

Combining (i) Paper I-B's *five cosets and 10 compactly supported zero modes* with (ii) the S³ network's *exact rank-25 600-cell adjacency-zero projector* yields a new source-level chain:

\[
\boxed{\ker A_{600}=\underbrace{\mathcal K_{10}}_{5\times2}\oplus\underbrace{\mathcal K_{15}}_{\text{collective}}}\quad\longrightarrow\quad
\boxed{5\text{ canonical }9\text{-planes}}\quad\longrightarrow\quad
\boxed{10\text{ canonical }3\text{-planes}}\quad\longrightarrow\quad
\boxed{\text{Petersen conference matrix / }(10,5)\text{ equiangular lines}}.
\]

All of the transition *subspaces*, the relative angles, the tight-frame constants and the real signed third-order products are forced by the fixed marked geometry. A separate free choice of an auxiliary 15-space, five 9-space charts, ten pair-channel triplets, overlap weights or cubic signs is unnecessary **for this mathematical adjacency-zero construction**.

Separately, the upstream complementary resolvent determines the **entire** first-return law on any Hurwitz coset, including destination-conditioned times. This eliminates a Markov-return-law assumption *once the uniform nearest-neighbour graph walk is specified*, without turning graph steps into physical seconds.

## Provenance and scopes

- `p1b:thm:v3023-five-coset-adjacency` already proves that the 120 quaternionic 600-cell vertices split into five 24-vertex left Hurwitz cosets, with no one-step internal edges; each vertex has three neighbours in each of the other four cosets.
- `p1b:thm:v3027-600-hurwitz-returns` already proves the first four complementary return identities and that the 96-vertex complement is 9-regular.
- `p1b:thm:v3027-600-hurwitz-mode-resolvent` already proves the five rational resolvent modes `F_\lambda(x)`.
- `p1b:thm:v3027-hurwitz-character-zero-modes` already proves **ten** independent, one-coset-supported adjacency-zero modes, two per coset.
- The S³ `twisted25_v127_instance.json` already has the **full rank-25 adjacency-zero projector** `\Pi_{25}` and an independent exact rank-95 certificate for `A_{600}`. Its canonical kernel is `U_4(\operatorname{Re}(g^{-1}h))/24`, with `U_4(t)=16t^4-12t^2+1`.

**Novel result:** the `10+15` orthogonal splitting and all its subsequent five-by-nine/ten-by-three/equiangular/Petersen geometry follow from *combining* these two existing upstream components. The rank25 and ten local zero modes themselves were **not newly discovered** here. Likewise, the v1.2 two-step return identity is already in Paper I-B; do not double-count it.

All statements below are relative to the **marked** `2T\subset2I`, its five left cosets, and the unit-incidence adjacency. No universal GP3 selection of this marking or physical action is inferred.

## GC-09: exact native first-return process, no free lifetime distribution

Let `H` be one left Hurwitz coset, `O` its 96-vertex complement, and write

\[
A_{600}=\begin{pmatrix}0&B\\B^T&C\end{pmatrix}.
\]

Define the simple unit-edge walk `P=A_{600}/12`. Starting at `h\in H`, the first step is necessarily to `O`. Each vertex of `O` has exactly nine neighbours in `O` and three in `H`, so the event of avoiding `H` for another step has probability `3/4`, independent of the particular outside vertex. Hence the first return time `T_H` satisfies **for every starting point**

\[
\boxed{\Pr(T_H=n)=\tfrac14(\tfrac34)^{n-2}\quad(n\ge2),\qquad
\mathbb E T_H=5,\quad\mathrm{Var}(T_H)=12.}\tag{GC-09.1}
\]

The **joint destination-and-duration generating kernel** has the exact full-path expression

\[
\boxed{K(z)=\sum_{n\ge2}z^n\Pr(T_H=n,\,X_{T_H}=v\mid X_0=u)
=\frac z{12}B\bigl(\frac{12}{z}I-C\bigr)^{-1}B^T.}\tag{GC-09.2}
\]

Proof: paths with `k=n-2` exterior moves have matrix `(1/12^{k+2})B C^k B^T`, and the Neumann series sums to (GC-09.2). This is exactly the Paper I-B exterior resolvent evaluated at the appropriate *generating-variable* argument, not an independently chosen Markov kernel.

Writing `K=K(1)` and `N` for the native 24-cell nearest adjacency,

\[
K=\tfrac1{12}B(12I-C)^{-1}B^T,
\qquad \operatorname{spec}(K)=1^{(1)}\oplus(5/12)^{(4)}\oplus(11/86)^{(9)}\oplus(1/22)^{(8)}\oplus0^{(2)}.\tag{GC-09.3}
\]

For individual destinations, not whole shell aggregates, the exact probabilities and exact conditional expectations are:

| `u·v` | Number of destinations | `Pr(X_T=v|X_0=u)` | `E[T | X_T=v]` | Minimum `T` with nonzero probability |
|---|---:|---:|---:|---:|
| `1` | 1 | `11867/68112` | `58968058/16839273` ≈ **3.50182** | 2 |
| `1/2` | 8 | `115/1584` | `16889/3795` ≈ **4.45033** | 2 |
| `0` | 6 | `53/2064` | `14800/2279` ≈ **6.49408** | 3 |
| `−1/2` | 8 | `17/1584` | `4891/561` ≈ **8.71836** | 4 |
| `−1` | 1 | `343/68112` | `5413622/486717` ≈ **11.12273** | 5 |

**Exact moment proof.** Paper I-B supplies `F_\lambda(x)`, with `\lambda(N)=8,4,0,-2,-4`. Put `k_\lambda(z)=\tfrac z{12}F_\lambda(12/z)`. Spectral interpolation in the five Hurwitz shells gives `K(1)`, `K'(1)` and `K''(1)+K'(1)`. Their rows sum to `1`, `5` and `37`, respectively; thus `E[T²]=37` and `Var(T)=12`. All entries and fractions are recalculated independently in the verifier. Direct 96-vertex inversion on **each of five cosets** agrees to `2.22×10⁻16` in double precision.

**Exact bounded no-go:** Every pair of sites in a fixed Hurwitz coset has strictly positive first-return probability; each distinct shell already appears in the first four return matrices. Thus *scalar nearest-neighbour 600-cell incidence alone* cannot forbid any within-coset destination. Particle-specific forbidden channels must be determined by additional source-selected quantum numbers, operator constraints, or a genuinely different action, not by inserting unproved zeros into this positive kernel. The time unit here is a **graph step** only.

## GC-10: exact `25 = 10 + 15` spectral projector decomposition

Let `\Pi_{25}` be the v1.27 rank-25 orthogonal projector onto `\ker A_{600}`. For the five disjoint cosets `H_i`, let `\Pi_{-4}^{(i)}` denote the normalized Hurwitz adjacency `N=-4` spectral projector extended by zero outside its coset. From the Paper I-B first-return identity

\[
BB^T=12I+3N
\]

and positivity, `B^*\Pi_{-4}^{(i)}=0`. Therefore `\Pi_{-4}^{(i)}` is exactly a rank-two subprojection of `\Pi_{25}`, not just a candidate.

Define

\[
P_{10}=\sum_{i=1}^5\Pi_{-4}^{(i)},\qquad
\boxed{P_{15}=\Pi_{25}-P_{10}.}\tag{GC-10.1}
\]

The supports are disjoint and the summands orthogonal; hence `P_{10}` is a rank-ten orthogonal projection. Since its range lies in `\operatorname{ran}\Pi_{25}`, `P_{15}` is an orthogonal projection of **exact rank 15**. It is neither an arbitrary subtraction nor an independent 15D hypothesis.

The source Chebyshev kernel has diagonal `5/24`; each local `−4` projector has diagonal `2/24` on its own coset. Therefore

\[
\boxed{(P_{15})_{gg}=\frac{5-2}{24}=\frac18\qquad\forall g\in2I.}\tag{GC-10.2}
\]

The 120 vertex evaluations thus form a normalized equal-leverage Parseval frame for this rank-15 subspace. No vertex has a preferred mathematical leverage weight.

For the **left** `2I` action, direct exact quaternionic multiplication and character traces for all 120 group elements give

\[
\chi_{P_{25}}=5\chi_{\mathbf5},\qquad
\chi_{P_{10}}=2\chi_{\mathbf5},\qquad
\boxed{\chi_{P_{15}}=3\chi_{\mathbf5}}.\tag{GC-10.3}
\]

Here `\mathbf5` is the unique complex five-dimensional irreducible representation of `A_5`, whose character values on the five standard classes are `(5,1,-1,0,0)`. Consequently the complexified modules are `P_{25}\simeq5\mathbf5`, `P_{10}\simeq2\mathbf5`, `P_{15}\simeq3\mathbf5`. Source group elements lifting `A_5` classes have counts `2,30,40,48` for character values `5,1,−1,0`, respectively.

**Local support rigidity:** `\ker(B^*\vert_{\mathbb C^{H_i}})` has exact dimension two because `12I+3N` vanishes only on `N=-4`. Therefore *no nonzero vector in the collective 15-band can be supported on one coset alone*. It is genuinely inter-coset in this precise linear-algebraic sense.

**Important non-identification:** this 15 is a **real graph adjacency-zero subspace** (with complexification carrying `3\mathbf5` under left `A_5`). It is not automatically the source's complex `\Spin(4)` momentum carrier `\mathcal H_1`; an explicit equivariant identification would be necessary. Moreover `A_{600}`-zero is **not** `L_{600}`-zero: these vectors have unit-edge Laplacian eigenvalue `12`, not massless or zero physical energy.

## GC-11: five rank-nine projectors form an exact equichordal fusion frame

Let `Q_i` be diagonal projection onto the 24 coordinate sites of `H_i`, and define on `\operatorname{ran}P_{15}`

\[
\boxed{S_i=3P_{15}Q_iP_{15}.}\tag{GC-11.1}
\]

Restrict the exact projector kernel to one coset. In native shell notation `I,N,Z,D,J_{\rm opp}` (inner product classes `1,1/2,0,-1/2,-1`),

\[
24\Pi_{25}\vert_{H_i} =5I-N+Z-D+5J_{\rm opp},
\quad 24P_{10}\vert_{H_i}=2I-N+2Z-D+2J_{\rm opp},
\]

so

\[
\boxed{24P_{15}\vert_{H_i}=3I-Z+3J_{\rm opp}.}\tag{GC-11.2}
\]

Its eigenvalues are `(1/3)^9,0^{15}` (verified by the exact Hurwitz shell multiplication table), proving `S_i²=S_i`, `rank S_i=9`. Because `\sum_iQ_i=I_{120}`,

\[
\boxed{\sum_{i=1}^{5}S_i=3P_{15}.}\tag{GC-11.3}
\]

For distinct `i,j`, the `24×24` integer cross-block Gram

\[
H_{ij}=(24P_{15})_{H_i,H_j}(24P_{15})_{H_j,H_i}
\]

satisfies, **for all ten pairs**,

\[
\boxed{H_{ij}(H_{ij}-16I)(H_{ij}-64I)=0,\quad
\mathrm{tr}\,H_{ij}=288,\quad\mathrm{tr}\,H_{ij}^{2}=13824.}\tag{GC-11.4}
\]

The two traces force `64^(3),16^(6),0^(15)`; the squared singular values of `3P_{15}|_{H_i,H_j}` are thus `1^(3),(1/4)^(6),0^(15)`. These are precisely the pairwise principal-angle squares of `\operatorname{ran}S_i` and `\operatorname{ran}S_j`. In particular **every pair intersects in exactly three dimensions and the six remaining angles are exactly 60 degrees.**

## GC-12: ten rank-three pair-channel projectors have no free overlaps

For pair labels `a=(i,j)` define `M_{ij}=S_iS_jS_i`. It has eigenvalues `1^(3),(1/4)^(6),0^(111)` on the ambient real 120-space. The orthogonal projector onto `W_{ij}=\mathrm{ran}S_i\cap\mathrm{ran}S_j` is therefore explicitly

\[
\boxed{T_{ij}=\frac13M_{ij}(4M_{ij}-I).}\tag{GC-12.1}
\]

There are exactly ten such pair labels. Their *entire* algebra is fixed by the parent projector; in particular,

\[
\boxed{T_{ij}^{2}=T_{ij},\ \operatorname{rank}T_{ij}=3,
\qquad \sum_{i<j}T_{ij}=2P_{15},}\tag{GC-12.2}
\]

\[
\boxed{T_aT_bT_a=\frac19T_a\quad\text{for all distinct pairs }a,b.}\tag{GC-12.3}
\]

Equation (GC-12.3) says every pair of rank-three subspaces is *isoclinic* with cosine exactly `1/3`. These are stronger than equal average overlaps or numerical eigenvalue fits.

**Exact proof/certificate:** all ten `T_{ij}` admit a common 120×120 integer matrix numerator `Z_{ij}` over denominator **72**. The verifier checks `Z²=72Z`, `tr Z=216`, `\sum Z=6(24P_{15})`, and all `45` identities `Z_aZ_bZ_a=576Z_a` using integer arithmetic. The diagonal of `T_{ij}` is `3/72` at vertices of the named two cosets and `1/72` at the remaining three cosets, a completely forced relative site-leverage law.

The ten labels agree combinatorially with the ten two-subsets of five used in the Petersen graph. These are **different operators** from the pre-existing 3×3 rank-one ten-axis projectors and the 25-sector's eight-plane fusion frame; only the index set is shared automatically.

## GC-13 and GC-14: cubic signed holonomy and the exact Petersen conference matrix

For three distinct two-subset labels `a,b,c`, the surprisingly stronger **matrix**, not just trace, identity is

\[
\boxed{T_aT_bT_cT_a=\frac{\sigma_{abc}}{27}T_a,\qquad
\sigma_{abc}=\begin{cases}
+1,&\text{three pairs form a three-edge path on four core labels},\\
-1,&\text{otherwise}.
\end{cases}}\tag{GC-13.1}
\]

**Complete combinatorial count:** 60 path triples have positive sign, while 20 three-stars, 10 triangles and 30 disconnected length-two-plus-single-edge triples have negative sign. The sign is independent of a local basis or line orientation. All 120 cubic 120×120 integer identities were checked; in numerator notation the exact test is `Z_aZ_bZ_cZ_a=\sigma_{abc} 13824 Z_a`.

Choose one pair reference `r` and a three-dimensional frame of `\mathrm{ran}T_r`. For each other pair `a`, the map `V_a=3T_a|_{\mathrm{ran}T_r}` is an isometry into `\mathrm{ran}T_a`, and let `V_r` be the identity inclusion. Equations (GC-12.3) and (GC-13.1) give scalar cross-Gram blocks

\[
V_a^*V_b=g_{ab}I_3,\qquad g_{aa}=1,\quad |g_{ab}|=\frac13.
\]

Because `\sum_aT_a=2P_{15}`, these ten isometries span the rank-15 carrier. Their scalar Gram `G=(g_{ab})` therefore has rank **5**, obeying

\[
\boxed{G^2=2G,\quad \operatorname{spec}(G)=2^{(5)},0^{(5)}.}\tag{GC-14.1}
\]

This is an exact real `N=10,d=5` **unit-norm equiangular tight frame** tensored with a rank-three identity. It saturates the Welch bound `\mu^2=(N-d)/(d(N-1))=1/9`.

Let `S=3(G-I)` be its zero-diagonal signed Seidel matrix. The cubic signs fix its switching class. With pair labels ordered

`01,02,03,04,12,13,14,23,24,34`

and reference `01`, exact switching by

`D=diag(1,−1,−1,−1,−1,−1,−1,+1,+1,+1)`

gives

\[
\boxed{DSD=2A_{\rm Petersen}+I_{10}-J_{10},\qquad S^2=9I_{10}.}\tag{GC-14.2}
\]

Here `A_Petersen` is the usual adjacency of *disjoint* two-subsets of five core labels. In particular, the Petersen sign structure is **derived** from the 600-cell's zero band, rather than appended as an independently assigned inter-channel sign matrix. `D` reflects the harmless choice of line signs; the cubic cycle signs `\sigma_{abc}` do not change under such switching.

**Conceptual result:** The low-order absolute overlaps are completely uniform. The first combinatorial discrimination between triplets of pair channels occurs at **third order**, through a fixed signed geometric invariant. This opens a legitimate native finite-geometry candidate for *relative* response signs; it does **not** provide physical amplitudes, channel prohibitions, mass ordering, CP asymmetry or lifetimes without the actual action-owner map.

## Conditions genuinely removed versus remaining source gates

| Candidate condition or free input | New status | Precise scope |
|---|---|---|
| Select an extra 15D collective spectral carrier after knowing the 600-cell's adjacency-zero band and the 10 local characters | **REMOVED**: unique orthogonal complement `P15=P25−P10` | marked finite graph |
| Choose five independent 9D coset charts or their normalization constants | **REMOVED**: `S_i=3P15 Q_i P15`, exact rank 9 and tight constant 3 | marked finite graph |
| Choose ten independent 3D pair intersections, overlaps, or relative tensor-frame weights | **REMOVED**: exact polynomial spectral projectors `T_ij`, tight constant 2, pair cosine 1/3 | marked finite graph |
| Add arbitrary ± signs to third-order pair-channel products | **REMOVED**: all 120 signed holonomy identities and Petersen conference switching class | marked finite graph |
| Independently specify first-return times, probabilities or positive destination weights under the uniform nearest graph walk | **REMOVED**: exact geometric law, generating kernel and shell moments | stipulated simple graph walk |
| Assume some same-core destinations are forbidden by scalar 600-cell nearest connectivity alone | **REFUTED**: all are reached by first-return paths of at most five edges | scalar adjacency only |
| Derive unique global subgroup marking or physically occurring Hamiltonian/action solely from `G0/GP1–GP3` | **NOT CLOSED** | physical/constitutional source owner |
| Identify collective `15` with `\mathcal H_1`, five 9-planes with color-family modules, or ten 3-planes with actual particles | **NOT CLOSED**: must prove compatible representations and action ownership | quantum source/physical observable |
| Assign **seconds, masses, branching ratios or absolute response units** | **NOT CLOSED**: needs clock, full action Hessian, source and readout | physical observables |

Avoid calling graph adjacency-zero modes “massless”: `L_{600}=12I-A_{600}` gives eigenvalue **12** on them. Avoid calling all mathematical 600-cell paths permitted particle decays: charge, spin, chirality and actual interaction operators impose separate selection rules.

## Proposed source/DAG additions, not silently executed

1. **Paper I-B** after `p1b:thm:v3027-hurwitz-character-zero-modes`: theorem `p1b:thm:600-zero-split-collective15`, relying on the source-proved 10 zero modes, full exact `twisted25` projector, and projector subtraction.
2. **Paper I-B / technical appendix:** theorem `p1b:thm:fivecoset-nineplane-fusion` and corollaries `tenpair-triplet-projectors`, `petersen-cubic-conference`, relying on the fixed five-coset marking and exact finite integer certificates.
3. **Paper I-B / Markov comparison:** `p1b:thm:600-first-return-law`, relying on existing `v3023` and `v3027` theorems and no new scalar dynamical parameters.
4. **S³ structural network:** add typed edges `rank25_zero_projector + ten_coset_characters -> P15 -> five_9planes -> ten_3planes -> signed_Petersen_conference`. Mark all as **mathematical incidence / group representation**, not physical transition operators.
5. **DAG exclusion edges:** no inference from `A600` zero band to `L600` zero energies, from 15 real graph dimensions to `\mathcal H_1`, from pair triplets to physical decay vertices, or from graph-step return statistics to lifetimes.

A source-ready LaTeX insertion is included as `Paper1B-CollectivePetersenClosure-v1_1.tex`. The separate material is a proposal, not a replacement for the current `.tex`.

## Reproducibility and independent checks

Run in this folder:

```bash
OPENBLAS_NUM_THREADS=1 python Paper00-GraphClosureDiscovery-v1_3.py
```

Requires NumPy and SymPy. The complete verifier performs:

1. Regenerate the 120-vertex 600-cell nearest adjacency from exact quaternionic coordinates; check all 720 edges and five 24-site cosets.
2. Regenerate **all 14,400 entries** of the rank-25 `U4` projector directly using integer `\mathbb Q(\sqrt5)` arithmetic; compare with the pre-existing source certificate.
3. Construct the exact rank-ten local and rank-fifteen collective projector numerators and verify idempotence, orthogonality, diagonal leverage and adjacency annihilation.
4. Independently multiply all 120 finite quaternions on the left and check the complete character identities `5\chi_5`, `2\chi_5`, `3\chi_5` and left equivariance of the projected subspaces.
5. Verify all five rank-nine idempotents and the **ten** principal-angle Gram polynomials and trace moments.
6. Construct all ten rank-three projectors over common denominator **72**; verify all ten idempotences, the fusion-frame sum, and all **45** pairwise isoclinic identities.
7. Verify **120** cubic signed holonomy matrix identities, their four combinatorial classes, the rank-five equiangular scalar Gram, and exact signed switching to the Petersen conference matrix.
8. Independently derive all rational first-return probabilities and conditional first and second moments from Paper I-B's rational `F_lambda(x)`; check exact total expectations and monotone shell-conditioned means.
9. For all **five** source cosets, replay the original first-four return identities with exact integer matrices and independently invert the 96-vertex complement in double precision. Largest discrepancy is `2.22×10⁻16`.
10. Write `Paper00-GraphClosureDiscovery-v1_3.json` with scope, source hashes, integer checks, isotypic classes, combinatorial counts, return probabilities, and the remaining unresolved physical gates.

**Correction / provenance discipline:** This release does not treat any v1.1/v1.2 derivation as new merely because it has been rechecked. The central discoveries here are the *cross-source projector subtraction* and the ensuing rank-nine / rank-three / signed-Petersen identities, plus the new complete first-return moment law. The single-coset zero modes, parent graph, five rational resolvents, and rank25 projector were source-established inputs.
