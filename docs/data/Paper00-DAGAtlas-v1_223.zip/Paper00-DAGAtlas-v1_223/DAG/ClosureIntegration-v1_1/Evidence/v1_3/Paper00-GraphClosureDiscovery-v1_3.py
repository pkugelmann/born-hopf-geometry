#!/usr/bin/env python3
"""Born--Hopf geometry, graph closures v1_3. Exact mathematical certificate.

Source inputs: exact v1_40 marked 600-cell (120 vertices, 720 edges),
              exact v1_27 twisted25 projective zero-band certificate,
              Paper I-B v3.023/v3.027 five-coset/return source theorems.
Scope: finite unit-incidence mathematics; does not construct physical action.
Dependencies: Python 3.11+, numpy, sympy. No network or fitting needed.
"""
from __future__ import annotations
import itertools,collections,hashlib,math,json,sys
from pathlib import Path
from fractions import Fraction
import numpy as np
import sympy as sp

ROOT=Path(__file__).resolve().parent
inputs={f.name:hashlib.sha256(f.read_bytes()).hexdigest()
        for f in sorted((ROOT/'inputs').iterdir()) if f.is_file()}
geometry=json.loads((ROOT/'inputs'/'exceptional_600cell_instance.json').read_text())
seed=json.loads((ROOT/'inputs'/'twisted25_v127_instance.json').read_text())
assert len(geometry['vertices'])==120 and len(geometry['nearest_edges'])==720
V={v['id']:tuple(tuple(q) for q in v['qcoords']) for v in geometry['vertices']}
Vback={q:i for i,q in V.items()}
assert set(V)==set(range(120)) and len(Vback)==120
colors=[list(block) for block in geometry['coset_blocks']]
assert len(colors)==5 and all(len(q)==24 for q in colors)
assert sorted(sum(colors,[]))==list(range(120))
assert all(geometry['vertices'][v]['color']==c for c,ids in enumerate(colors) for v in ids)
A=np.zeros((120,120),dtype=np.int64)
for e in geometry['nearest_edges']:
 u,v=e['u'],e['v'];assert u!=v and A[u,v]==0
 A[u,v]=A[v,u]=1
assert np.array_equal(A,A.T) and np.all(A.sum(axis=1)==12)

def fm(a,b):
 return a[0]*b[0]+5*a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def fa(a,b):return a[0]+b[0],a[1]+b[1]
def fn(a):return -a[0],-a[1]
def qm(a,b):
 x,y,z,w=a;u,v,s,t=b
 r=[fa(fa(fm(x,u),fn(fm(y,v))),fa(fn(fm(z,s)),fn(fm(w,t)))),
    fa(fa(fm(x,v),fm(y,u)),fa(fm(z,t),fn(fm(w,s)))),
    fa(fa(fm(x,s),fn(fm(y,t))),fa(fm(z,u),fm(w,v))),
    fa(fa(fm(x,t),fm(y,s)),fa(fn(fm(z,v)),fm(w,u)))]
 assert all(all(t%4==0 for t in w) for w in r)
 return tuple(tuple(t//4 for t in w) for w in r)

def dotnum(i,j):
 A0=B0=0
 for a,b in zip(V[i],V[j]):
  t=fm(a,b);A0+=t[0];B0+=t[1]
 return A0,B0  # actual dot = (A0+B0 sqrt5)/16

def positive_surd(x,y):
 # exact sign of x+y*sqrt5 using integer inequalities
 if y==0:return x>0
 if x==0:return y>0
 if x>0 and y>0:return True
 if x<0 and y<0:return False
 if x>0 and y<0:return x*x>5*y*y
 return 5*y*y>x*x

def U4(A0,B0):
 # U_4(t)=16t^4-12t^2+1, t=(A0+B0 sqrt5)/16.
 sq=fm((A0,B0),(A0,B0));qu=fm(sq,sq)
 a=qu[0]-192*sq[0]+4096;b=qu[1]-192*sq[1]
 assert b==0 and a%4096==0,(A0,B0,a,b)
 return a//4096

# Regenerate the two geometries from coordinates and verify source matrices.
P25num=np.zeros((120,120),dtype=np.int64)
for i in range(120):
 for j in range(120):
  d=dotnum(i,j)
  if i!=j:
   # 600-cell edge criterion dot>=phi/2=(4+4sqrt5)/16 (max distinct)
   assert bool(A[i,j])== (d==(4,4)),(i,j,d,A[i,j])
  P25num[i,j]=U4(*d)
assert np.array_equal(P25num,np.asarray(seed['projector_numerator_120x120'],dtype=np.int64))
assert np.array_equal(P25num@P25num,24*P25num)
assert np.array_equal(A@P25num,np.zeros((120,120),dtype=np.int64))
assert np.trace(P25num)==24*25

# Native H/Q8 C3 characters: projector rank 2 in each marked 24-cell.
P10num=np.zeros((120,120),dtype=np.int64)
for ids in colors:
 N=np.zeros((24,24),dtype=np.int64)
 for a,i in enumerate(ids):
  for b,j in enumerate(ids):
   d=dotnum(i,j)
   assert d[1]==0 and d[0] in [16,8,0,-8,-16]
   P10num[i,j]=2 if d[0] in [16,0,-16] else -1
   N[a,b]=int(d[0]==8)
 assert np.array_equal(N,N.T) and np.all(N.sum(axis=1)==8)
 assert np.array_equal(N @ P10num[np.ix_(ids,ids)],-4*P10num[np.ix_(ids,ids)])
 assert np.array_equal(A[np.ix_(ids,ids)],np.zeros((24,24),dtype=np.int64))
assert np.array_equal(P10num@P10num,24*P10num)
assert np.array_equal(A@P10num,np.zeros((120,120),dtype=np.int64))
assert np.trace(P10num)==24*10
assert np.array_equal(P25num@P10num,24*P10num)
P15num=P25num-P10num
assert np.array_equal(P15num@P15num,24*P15num)
assert np.array_equal(P15num@P10num,np.zeros((120,120),dtype=np.int64))
assert np.array_equal(A@P15num,np.zeros((120,120),dtype=np.int64))
assert np.trace(P15num)==24*15
assert np.all(np.diag(P15num)==3)

# All 120 exact left group translations act equivariantly on 10+15.
left_character_mult=collections.Counter()
for g in range(120):
 p=[Vback[qm(V[g],V[h])] for h in range(120)]
 assert len(set(p))==120
 chi5=U4(4*V[g][0][0],4*V[g][0][1])
 ch25=sum(P25num[h,p[h]] for h in range(120))
 ch10=sum(P10num[h,p[h]] for h in range(120))
 ch15=sum(P15num[h,p[h]] for h in range(120))
 assert (ch25,ch10,ch15)==(24*5*chi5,24*2*chi5,24*3*chi5),(g,chi5,ch25,ch10,ch15)
 assert np.array_equal(P10num[np.ix_(p,p)],P10num)
 assert np.array_equal(P15num[np.ix_(p,p)],P15num)
 left_character_mult[str(chi5)]+=1
assert left_character_mult=={'5':2,'1':30,'-1':40,'0':48}

# Five mutually equichordal 9-dimensional subspaces in collective rank15.
# S_i=3 P15 Q_i P15 = M_i/192, with M_i=P15num Q_i P15num.
M9={i:P15num[:,ids]@P15num[ids,:] for i,ids in enumerate(colors)}
for i,M in M9.items():
 assert np.array_equal(M@M,192*M)
 assert np.trace(M)==192*9
 assert np.array_equal(M@P15num,24*M)
assert np.array_equal(sum(M9.values()),24*P15num) # sum S_i = 3 P15

# Source-independent exact principal angle check through 24x24 Gram blocks.
principal={}
for i,j in itertools.combinations(range(5),2):
 X=P15num[np.ix_(colors[i],colors[j])]
 H=X@X.T;I=np.eye(24,dtype=np.int64)
 assert np.array_equal(H@(H-16*I)@(H-64*I),np.zeros((24,24),dtype=np.int64))
 assert np.trace(H)==288 and np.trace(H@H)==13824
 principal[f'{i}-{j}']={'intersection':3,'cos_squared_nontrivial':'1/4','multiplicity_nontrivial':6}

# Ten rank-three intersection projectors. Each T_ij=Z_ij/72.
# The spectral projection is T_ij=[M(4M-I)]/3,
# M=S_i S_j S_i, with spectrum {1^3,(1/4)^6,0^111}.
pairs=list(itertools.combinations(range(5),2));Z={}
for a,b in pairs:
 D=M9[a]@M9[b]@M9[a]
 assert np.all(D%18432==0)
 U=D//18432  # M=U/384
 E=4*(U@U)-384*U
 assert np.all(E%6144==0)
 Y=E//6144   # T_ij=Y/72
 assert np.array_equal(Y@Y,72*Y)
 assert np.trace(Y)==72*3
 assert np.array_equal(Y@M9[a],192*Y) and np.array_equal(Y@M9[b],192*Y)
 assert np.all(np.diag(Y)[colors[a]]==3) and np.all(np.diag(Y)[colors[b]]==3)
 for c in range(5):
  if c not in (a,b):assert np.all(np.diag(Y)[colors[c]]==1)
 Z[a,b]=Y
assert np.array_equal(sum(Z.values()),6*P15num) # sum T_ij=2P15
for a,b in itertools.combinations(pairs,2):
 assert np.array_equal((Z[a]@Z[b])@Z[a],576*Z[a]) # T_a T_b T_a=1/9 T_a

# Gauge-invariant cubic signs and exact 3-dimensional holonomy.
cubic=collections.Counter()
def edge_type(es):
 return tuple(sorted(collections.Counter(x for e in es for x in e).values(),reverse=True))
for a,b,c in itertools.combinations(pairs,3):
 t=edge_type((a,b,c))
 sig=1 if t==(2,2,1,1) else -1
 assert np.array_equal((Z[a]@Z[b])@(Z[c]@Z[a]),sig*13824*Z[a])
 assert int(np.trace((Z[a]@Z[b])@Z[c]))==sig*41472
 cubic[f'{t}:{sig}']+=1
assert sum(cubic.values())==120
assert cubic=={'(3, 1, 1, 1):-1':20,'(2, 2, 2):-1':10,
               '(2, 2, 1, 1):1':60,'(2, 1, 1, 1, 1):-1':30}

# Scalar cross-Gram matrix of 10 isometries from reference W_{01}.
Sconf=np.zeros((10,10),dtype=np.int64)
for a in range(10):
 for b in range(a+1,10):
  sign=1 if a==0 or edge_type((pairs[0],pairs[a],pairs[b]))==(2,2,1,1) else -1
  Sconf[a,b]=Sconf[b,a]=sign
I10=np.eye(10,dtype=np.int64);J10=np.ones((10,10),dtype=np.int64)
assert np.array_equal(Sconf@Sconf,9*I10)
G3=3*I10+Sconf  # G=G3/3, rank5, tight eigen 2
assert np.array_equal(G3@G3,6*G3)
AP=np.zeros((10,10),dtype=np.int64)
for a,b in itertools.combinations(range(10),2):
 AP[a,b]=AP[b,a]=int(set(pairs[a]).isdisjoint(pairs[b]))
assert np.all(AP.sum(axis=1)==3)
SP=2*AP+I10-J10
assert np.array_equal(SP@SP,9*I10)
d=np.ones(10,dtype=np.int64);d[1:]=SP[0,1:]
assert np.array_equal(d[:,None]*Sconf*d[None,:],SP)

# Exact first-return stochastic kernel on one retained 24-coset.
# Source: Paper I-B rational complementary resolvent F_lambda(x).
inner=[sp.Integer(1),sp.Rational(1,2),sp.Integer(0),sp.Rational(-1,2),sp.Integer(-1)]
matrices=[];ids=colors[0]
for k,t in enumerate(inner):
 M=np.zeros((24,24),dtype=np.int64)
 for a,i in enumerate(ids):
  for b,j in enumerate(ids):
   A0,B0=dotnum(i,j);assert B0==0
   M[a,b]=int(sp.Rational(A0,16)==t)
 matrices.append(M)
assert np.array_equal(sum(matrices),np.ones((24,24),dtype=np.int64))
mshell=[1,8,6,8,1]
assert [int(M[0].sum()) for M in matrices]==mshell
mul=np.zeros((5,5,5),dtype=np.int64)
for a in range(5):
 for b in range(5):
  v=matrices[a]@matrices[b]
  for c in range(5):
   vals=set(int(z) for z in v[matrices[c]==1]);assert len(vals)==1
   mul[a,b,c]=vals.pop()
  assert np.array_equal(v,sum(int(mul[a,b,c])*matrices[c] for c in range(5)))
def product(a,b):
 return sp.Matrix([sum(a[i]*b[j]*int(mul[i,j,k]) for i in range(5) for j in range(5)) for k in range(5)])
unit=sp.Matrix([1,0,0,0,0]);N=sp.Matrix([0,1,0,0,0]);lams=[8,4,0,-2,-4];lmults=[1,4,9,8,2]
Pmode={}
for lam,rank in zip(lams,lmults):
 q=unit
 for other in lams:
  if other!=lam:q=product(q,(N-other*unit)/(lam-other))
 assert product(q,q)==q and int(24*q[0])==rank
 Pmode[lam]=q
assert sum(Pmode.values(),sp.zeros(5,1))==unit
x,z=sp.symbols('x z')
F={8:36/(x-9),4:24*(x+3)/(x*x-4*x-24),
   0:4*x*(3*x+8)/(x**3-x**2-16*x-16),-2:6/(x-1),-4:sp.Integer(0)}
Gz={lam:sp.factor(z/12*f.subs(x,12/z)) for lam,f in F.items()}
prob=sum((sp.factor(f.subs(z,1))*Pmode[lam] for lam,f in Gz.items()),sp.zeros(5,1))
meanweighted=sum((sp.factor(sp.diff(f,z).subs(z,1))*Pmode[lam] for lam,f in Gz.items()),sp.zeros(5,1))
secondweighted=sum((sp.factor((sp.diff(f,z,2)+sp.diff(f,z)).subs(z,1))*Pmode[lam]
 for lam,f in Gz.items()),sp.zeros(5,1))
assert list(prob)==[sp.Rational(11867,68112),sp.Rational(115,1584),sp.Rational(53,2064),sp.Rational(17,1584),sp.Rational(343,68112)]
assert sum(v*m for v,m in zip(prob,mshell))==1
assert sum(v*m for v,m in zip(meanweighted,mshell))==5
assert sum(v*m for v,m in zip(secondweighted,mshell))==37
conditional_means=[sp.factor(meanweighted[k]/prob[k]) for k in range(5)]
assert conditional_means==[sp.Rational(58968058,16839273),sp.Rational(16889,3795),sp.Rational(14800,2279),sp.Rational(4891,561),sp.Rational(5413622,486717)]
assert all(conditional_means[i]<conditional_means[i+1] for i in range(4))
assert [sp.factor(Gz[lam].subs(z,1)) for lam in lams]==[1,sp.Rational(5,12),sp.Rational(11,86),sp.Rational(1,22),0]

# Direct 96-vertex eliminations, check all five boundaries against exact shells.
expected=np.array([float(x) for x in prob]);expectedmean=np.array([float(x) for x in meanweighted])
maxerror=0.0
first_return={}
for c,ids in enumerate(colors):
 outside=[i for i in range(120) if i not in set(ids)]
 B=A[np.ix_(ids,outside)];C=A[np.ix_(outside,outside)]
 assert np.all(B.sum(axis=1)==12) and np.all(C.sum(axis=1)==9)
 mat=np.eye(96,dtype=np.int64)
 bword=[]
 for k in range(4):
  W=B@mat@B.T
  bword.append(W)
  mat=mat@C
 dot=np.zeros((24,24),dtype=int)
 for i,u in enumerate(ids):
  for j,v in enumerate(ids):
   A0,B0=dotnum(u,v);assert B0==0
   dot[i,j]=[16,8,0,-8,-16].index(A0)
 for k,co in enumerate([[12,3,0,0,0],[60,27,8,0,0],
                        [420,225,92,18,0],[3024,1845,952,342,12]]):
  assert np.array_equal(bword[k],np.array(co)[dot])
 M=12*np.eye(96)-C
 Y=np.linalg.solve(M,B.T)
 K=B@Y/12
 Z0=np.linalg.solve(M,Y)
 KM=K+B@Z0
 err=max(float(np.max(abs(K-expected[dot]))),float(np.max(abs(KM-expectedmean[dot]))))
 assert err<5e-13,err
 maxerror=max(maxerror,err)
 first_return[str(c)]={'integer_first_four_return_shells':True,'direct_K_and_first_time_moment_max_error':err}

certificate={
 'id':'Paper00-GraphClosureDiscovery-v1_3',
 'basis':{'papers':'PapersMinimal-v3_040','source':'Paper1B-ExceptionalGeometry-v1_18.tex',
  'upstream_labels':['p1b:thm:v3023-five-coset-adjacency','p1b:thm:v3027-600-hurwitz-returns',
                     'p1b:thm:v3027-600-hurwitz-mode-resolvent','p1b:thm:v3027-hurwitz-character-zero-modes'],
  'S3_network':'v1_40','S3_inputs':['exceptional_600cell_instance.json','twisted25_v127_instance.json']},
 'SHA256':inputs,
 'exact_coordinate_regeneration':{'nearest_edges':720,'P25_matches_source':True,
   'P25_rank':25,'P10_rank':10,'P15_rank':15,'P15_diag':'1/8 all 120'},
 'left_A5_irreducible_5_character_values_multiplicities':dict(left_character_mult),
 'representation_isotypic':{'global25':'5 x V5','local10':'2 x V5','collective15':'3 x V5',
                            'verified_all_left_translations':120},
 'five_core_9D':{'rank_each':9,'sum_projectors':'3 P15',
   'pair_principal_cos_squared':{'intersection_3':'1','other_6':'1/4'},
   'all_10_pairs_exact':True},
 'ten_pair_3D':{'rank_each':3,'count':10,'sum_projectors':'2 P15',
  'all_45_pair_isoclinic':'T_a T_b T_a = T_a/9',
  'projector_integer_numerator_denominator':'Z_ab/72',
  'diagonal_entries':'3/72 on the two labeled cosets; 1/72 on the other three'},
 'cubic_signs':{'all_120_triples':'T_a T_b T_c T_a = sign*T_a/27',
                 'positive_exactly':'three edges form path P4 on four core labels',
                 'counts':dict(cubic)},
 'petersen_conference':{'G':'(3I+S)/3','G_squared':'2G','Gram_rank':5,
    'switching':'D S D = 2 A_Petersen + I - J','S_squared':'9I'},
 'first_return':{'prob_T_n':'(1/4)*(3/4)^(n-2) for n >= 2',
   'mean_steps':5,'variance_steps':12,
   'destination_shell_probabilities':[str(q) for q in prob],
   'shell_destination_conditioned_mean_steps':[str(q) for q in conditional_means],
   'mean_step_spectral':{str(k):str(sp.factor(sp.diff(Gz[k],z).subs(z,1))) for k in lams},
   'return_kernel_spectrum':{str(k):str(sp.factor(Gz[k].subs(z,1))) for k in lams},
   'first_return_shortest_n_by_shell':[2,2,3,4,5],
   'all_five_cosets':first_return,'max_numeric_error':maxerror},
 'removed_mathematical_assumptions':['free collective 15-dimensional subspace',
   'five independently chosen 9-dimensional charts','ten independently chosen 3-dimensional pair subspaces',
   'independent equal-angle pair couplings and arbitrary triple signs',
   'independent first-return probability and return-time distribution'],
 'not_dischargeable_from_these_results':['occurring physical action','geometric source-to-physical operator map',
   'particle decay direction and absolute rates','identification with H1 momentum module'],
 'mathematical_verification':'all exact integer identities, SymPy rational spectral moments and independent five-coset numerical inversions passed',
}
path=ROOT/'Paper00-GraphClosureDiscovery-v1_3.json'
path.write_text(json.dumps(certificate,indent=2)+'\n')
print('SUCCESS: graph v1.3 exact certificate')
print('rank chain: 25=10+15; 5x9 tight; 10x3 equi-isoclinic; 10-line Petersen conference')
print('cubic class counts:',dict(cubic))
print('first-return exact mean/variance:',5,12,'and all 5 direct inversions max error',maxerror)
print('wrote',path)
