#!/usr/bin/env python3
"""Exact symbolic certificates for v1_28's scoped Newton interfaces.
Depends only on SymPy. This tests algebra, not occurrence of the physical state.
"""
from pathlib import Path
import json
import sympy as s

G, x, k, a, nu, hb, beta = s.symbols('g x k a nu hbar beta', real=True, nonzero=True)
C = s.symbols('chi', positive=True)
R = s.symbols('R', positive=True)
reports = {}

def certify(name, equation):
    value = s.trigsimp(s.simplify(equation))
    if value != 0:
        raise AssertionError(f'{name}: {value}')
    reports[name] = 'PASS_EXACT'

M = k*G**2/2
J = s.Rational(1, 2)*(x-a*G)**2
v = a*G
S = s.expand(M+J-J.subs(x, v))
Smatrix = s.hessian(S, (G,x))
Hxx=Smatrix[1,1]
Schur=s.simplify(Smatrix[0,0]-Smatrix[0,1]/Hxx*Smatrix[1,0])
certify('stationary-reference-physical-hessian', Schur-k)
certify('stationary-reference-section-equation',s.diff(J,x).subs(x,v))
certify('stationary-reference-action-on-section',S.subs(x,v)-M)
certify('stationary-reference-Hgg',Smatrix[0,0]-(k+a*a))
certify('stationary-reference-Hgx',Smatrix[0,1]+a)
certify('stationary-reference-Hxx',Smatrix[1,1]-1)

v_bad = s.Integer(0)
S_bad=s.expand(M+J-J.subs(x,v_bad))
B=s.hessian(S_bad,(G,x))
Schur_bad=s.simplify(B[0,0]-B[0,1]/B[1,1]*B[1,0])
# Full same-action response including direct metric and material probes.
# Here Hxx=1 and the on-shell reference metric tangent is V=a.
jg1,jx1,jg2,jx2=s.symbols('jg1 jx1 jg2 jx2',real=True)
J1=s.Matrix([jg1,jx1])
J2=s.Matrix([jg2,jx2])
amp_direct=(J1.T*Smatrix.inv()*J2)[0]
amp_onshell=(jg1+a*jx1)*(jg2+a*jx2)/k+jx1*jx2
certify('full-two-probe-source-exchange',amp_direct-amp_onshell)
expected_inv=s.Matrix([[1/k,a/k],[a/k,1+a*a/k]])
certify('full-block-inverse-response',sum((Smatrix.inv()-expected_inv)[i,j]**2 for i in range(2) for j in range(2)))

certify('off-shell-reference-schur-shift', Schur_bad-(k-a*a))
certify('off-shell-reference-is-not-stationary-for-all-metrics',s.diff(J,x).subs(x,v_bad)+a*G)

# Universal local Newton inverse coefficient on the Einstein tensor branch.
U=s.symbols('U',positive=True)
certify('marked-to-Gscal-coefficient', 1/(16*s.pi*(U/8))-1/(2*s.pi*U))
certify('NR-tensor-source-factor',((1-s.Rational(1,2))/(2*nu)) -1/(4*nu))

# Exact compact S^3(R) zero-average Poisson Green function.
G3=((s.pi-C)*s.cot(C)-s.Rational(1,2))/(4*s.pi**2*R)
radial_lap=(s.diff(G3,C,2)+2*s.cot(C)*s.diff(G3,C))/R**2
certify('S3-offdiag-Poisson-equation',radial_lap-1/(2*s.pi**2*R**3))
mean=2/s.pi*s.integrate(G3*s.sin(C)**2,(C,0,s.pi))
certify('S3-mean-zero',mean)
certify('S3-universal-diagonal-singularity',s.limit(R*C*G3,C,0)-1/(4*s.pi))
volume_ball_frac=(C-s.sin(C)*s.cos(C))/s.pi
flux=-4*s.pi*R**2*s.sin(C)**2*(s.diff(G3,C)/R)
certify('S3-Gauss-flux-with-zero-mode',flux-(1-volume_ball_frac))
force_ratio=-4*s.pi*R**2*C**2*(s.diff(G3,C)/R)
certify('S3-local-force-coefficient',s.limit(force_ratio,C,0)-1)
certify('S3-local-force-curvature-coefficient',s.limit((force_ratio-1)/C**2,C,0)-s.Rational(1,3))

# Exact finite-dimensional proof that a stationary reference does not protect the quantum stiffness.
H=1+beta*G**2
Seffquantum=M+hb*s.log(H)/2
certify('quantum-Gaussian-determinant-stiffness-shift',s.diff(Seffquantum,G,2).subs(G,0)-(k+hb*beta))

meta={
 'document':'Paper00-NewtonTensorExchange-v1_28',
 'source_baseline':'Paper00-PapersMinimal-v3_041.zip',
 'atlas_baseline':'Paper00-DAGAtlas-v1_213.zip',
 'status':'CLASSICAL_SCOPED_THEOREMS_AND_NO_GO; NO_UNCONDITIONAL_PHYSICAL_NEWTON_CLOSURE',
 'exact_check_count':len(reports),
 'checks':reports,
 'remarks':[
   'Hessian theorem requires one regular stationary source member and a gauge-fixed invertible physical material block.',
   'S3 Poisson Green is an exact geometric kernel; equivalence to the full gravitational constraint requires a licensed principal-symbol/constraint reduction.',
   'Quantum determinant example is a countermodel to unqualified loop protection, not a calculation of Born-Hopf quantum loops.',
   'No fitted Newton coupling, scalar vacuum, regulator, source section or matter pole is provided by this verifier.'
 ]
}
out=Path(__file__).with_suffix('.json')
out.write_text(json.dumps(meta,indent=2,sort_keys=True)+'\n')
print('PASS',len(reports),'exact symbolic tests')
print('Exact S3 inverse, on-shell Schur, off-shell and quantum countermodels verified.')
