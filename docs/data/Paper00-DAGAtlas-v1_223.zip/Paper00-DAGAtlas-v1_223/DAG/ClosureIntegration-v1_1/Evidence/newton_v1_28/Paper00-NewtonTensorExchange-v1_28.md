# Newton tensor exchange: on-shell reference closure and the remaining physical gate

**Paper00-NewtonTensorExchange-v1_28 · 19 November 2026**  
**Frozen source baseline:** `Paper00-PapersMinimal-v3_041.zip`, especially `Paper3F-CompleteDynamics-v1_274.tex`, `Paper3G-TechnicalMaterial-v1_56.tex`, `Paper5A-FiniteMatterGeometry-v3_216.tex`, `Paper5B-TerminalSpectrum-v5_201.tex`, `Paper6A-GravityCosmology-v2_266.tex`. **Graph baseline:** `Paper00-DAGAtlas-v1_213.zip`. **Prior research:** `Paper00-NewtonTensorExchange-v1_25`, `v1_26`, and the supplied `v1_27` clarification. The proposed source insertion is in `Paper3F-OnShellReferenceNewtonClosure-v1_1.tex`.

## Executive decision

Three separate choices previously treated as experimental source conditions can be sharpened or removed *mathematically*: (1) a full local reference section is forced by the existing material Euler equations once a regular stationary seed is present; (2) the classical metric–material Schur correction cancels exactly along that derived reference section, so it need not be postulated as an independent low-energy tensor-stiffness cancellation; and (3) for any normalized on-shell Dirac particle the forward Hilbert gravitational charge is fixed by stress-tensor Ward identities, not by a new species-dependent coupling. In addition, the universal local inverse-distance singularity is exact on the compact round position $S^3$, so global Euclidean spatial flatness is unnecessary for *local* Newton normalization.

**Full unconditional empirical Newton closure is NOT demonstrated.** The v3_041 choice of physical action is a model adoption. Its exact original scalar heat has **no nonzero stationary parallel scalar member** in the tested sector, and the source theorem for the nonzero odd electroweak solder does not establish a stationary full material reference or a measured particle pole. No existing theorem proves quantum gravitational pole nonrenormalization, absolute source/clock calibration, or the actual gravitational constraint on the occurring cosmological background. These are precise surviving conditions, not arbitrarily reintroduced premises.

## 1. Start from the action that actually occurs in the manuscripts

Paper III-F Definition `p3f:def:v3041-adopted-metric-assembly` adopts

$$
S_{\rm phys}^{(v)}[g,X;b]
  =M_{\rm rp}[g;b]+S_J[g,X;b]-S_J[g,X_v(g,b);b]. \tag{1}
$$

The original joint action has Einstein coefficient $\kappa_J=12U=96\nu$ in natural units, while the marked primitive metric action has $\nu=U/8$. The existing `p3f:prop:v3041-reference-exchange` proves $G_{\rm tensor}=G_{\rm scal}$ after a specific physical Einstein/sourced-background reduction. It is not a theorem forcing (1) from G0–GP3; the DAG's Newton-owner condition `BH-IIIF-A-0039` remains relevant.

The exact material-variation identity is

$$
D_X S_{\rm phys}^{(v)}(g,X;b)=D_X S_J(g,X;b). \tag{2}
$$

Therefore **no purely metric reference correction can repair a nonstationary scalar background**; the reference material equation is genuinely that of the original ordinary action on the admitted field domain.

## 2. NEW: replace a chosen reference-transport family with an on-shell theorem

Work on one gauge-fixed/constraint-reduced $C^3$ Banach chart. Suppose a material seed $X_0$ satisfies

$$
D_XS_J(g_0,X_0)=0,\qquad
H:=D_X^2S_J(g_0,X_0)\text{ invertible}. \tag{3}
$$

The implicit-function theorem applied to $F(g,X)=D_XS_J(g,X)$ gives a unique local section $v(g)$ with $v(g_0)=X_0$ and $F(g,v(g))=0$. Its metric derivative is *computed*, not fitted:

$$
\boxed{D_gv=-H^{-1}D_gD_XS_J}\quad\text{at }(g_0,X_0). \tag{4}
$$

The same result works for an equivariant reference under a symmetry of $S_J$ preserving the seed, since locally unique solutions transform into the same unique solution.

### Exact Hessian identity

Set $Y=X-v(g)$, so that

$$
S_{\rm phys}^{(v)}(g,Y)=M_{\rm rp}(g)
 +S_J(g,v(g)+Y)-S_J(g,v(g)). \tag{5}
$$

The last two terms have zero value and zero first $Y$ derivative at $Y=0$ **for every nearby $g$**. Hence $D_gD_Y S_{\rm phys}^{(v)}(g,0)=0$. At the seed the adapted Hessian is block diagonal,

$$
\boxed{H_{\rm phys}^{(g,Y)}=\operatorname{diag}(M_{\rm rp,gg},H).} \tag{6}
$$

In the original coordinates, with $V=D_gv$, the three Hessian blocks are

$$
H_{gg}^{\rm phys}=M_{\rm rp,gg}+V^*HV,\quad
H_{gX}^{\rm phys}=-V^*H,\quad H_{XX}^{\rm phys}=H.
$$

Consequently

$$
\boxed{H_{gg}^{\rm phys}-H_{gX}^{\rm phys}H^{-1}H_{Xg}^{\rm phys}
 =M_{\rm rp,gg}.}\tag{7}
$$

### Full same-action two-probe exchange (no discarded mixed leg)

The original-coordinate Hessian has a completely explicit inverse, where $K=M_{\rm rp,gg}$ and $H=S_{J,XX}$:

$$
\boxed{\begin{pmatrix}K+V^*HV&-V^*H\\-HV&H\end{pmatrix}^{-1}
=\begin{pmatrix}K^{-1}&K^{-1}V^*\\VK^{-1}&H^{-1}+VK^{-1}V^*\end{pmatrix}.} \tag{7a}
$$

For two independent probes with complete external linear insertion vectors $(j_g,j_X)$ (and with the centering reference held independent of the applied probe), the Gaussian tree cross response is therefore **exactly**

$$
\boxed{\mathcal A_{12}=
(j_{g,1}+V^*j_{X,1})^*K^{-1}(j_{g,2}+V^*j_{X,2})
+j_{X,1}^*H^{-1}j_{X,2}.}\tag{7b}
$$

The induced metric source $j_g^{\rm eff}=j_g+V^*j_X$ is *derived* from the same ordinary action via $V=-H^{-1}S_{J,Xg}$; it is not a separate adjustable coupling. If $H^{-1}$ is infrared regular and this induced source is regular as $q\to0$, only the marked metric inverse contributes the Einstein $1/q$ pole. This does **not** set the direct scalar or electromagnetic force to zero: their exchange survives through the second term and through actual external charges; gapless blocks cannot be treated as regular. For a fermionic zero-background branch, $V_\psi=0$ follows from fermion parity of the bilinear at $\psi=0$, so canonical Dirac probes have no independent reference-induced *one-fermion* gravitational mixing.

**Conditions actually eliminated:** no independent smooth reference-transport function once the seed is fixed; no independent classical tensor/matter Schur-cancellation parameter. This is an exact classical same-action identity, not a claim of microscopic physical occurrence or quantum protection. The paper already has related generic stationary-Schur formulas for other operators; the new content is their application to the *adopted marked reference subtraction* and its cancellation.

### Why just one stationary point is not enough without derived transport

Let $g,x$ be scalars and $M(g)=kg^2/2$, $S_J(g,x)=(x-ag)^2/2$. The actual stationary section is $v(g)=ag$. Centering on it gives $S_{\rm phys}=M+(x-ag)^2/2$, with metric Schur stiffness exactly $k$.

Centering instead on a fixed $v(g)\equiv0$ makes $v(0)=0$ stationary only **at** $g=0$, while its reduced metric stiffness becomes $k-a^2$. This exact counterexample proves why a reference must be transported by its material equation rather than arbitrarily held fixed. Both outcomes are verified by the included SymPy certificate.

## 3. NEW SOURCE LINK: the canonical particle stress is not a free Newton parameter

In the ordinary joint action, the independently varied canonical Dirac component is of the form

$$
S_D=\int e\left[\frac{i}{2}\bar\psi\gamma^ae_a{}^\mu
\overleftrightarrow{D}_\mu\psi-m\bar\psi\psi\right].
$$

The reference subtraction in (1) is independent of an independent fermionic fluctuation; therefore the fermion's local metric vertex comes from the same $S_D$. On shell the Hilbert/Belinfante stress is

$$
T_{\mu\nu}=\frac i4\bar\psi
(\gamma_\mu\overleftrightarrow D_\nu+
\gamma_\nu\overleftrightarrow D_\mu)\psi.
$$

With $\bar u(p)\gamma_\mu u(p)=2p_\mu$ the forward matrix element is

$$
\boxed{\langle p|T_{\mu\nu}(0)|p\rangle=2p_\mu p_\nu.}\tag{8}
$$

More generally, stress conservation and the translation charge $\int T_{0\nu}=P_\nu$ fix this forward normalization for a physical one-particle pole with the standard covariant state norm; no adjustable species-dependent *gravitational charge* survives. This removes an independent probe-vertex normalization assumption **conditional on an actual normalized particle pole, a conserved Hilbert source, and the accepted same action**. It does not establish the mass $m$, the actual state or an ultraviolet completion of its current.

For two nonrelativistic neutral probes, the already established Einstein tensor exchange reads

$$
\mathcal A^{(2)}_{12}(q)=
\frac{T_1:T_2-T_1T_2/2}{2\nu q}
 \;\longrightarrow\;
\frac{m_1m_2}{4\nu q}.\tag{9}
$$

Fourier inversion of $1/q=1/\boldsymbol{k}^2$ gives the local pair potential

$$
\boxed{V_{12}(r)=-\frac{m_1m_2}{16\pi\nu r}
 =-\frac{G_{\rm scal}m_1m_2}{r},\quad
G_{\rm scal}=\frac1{2\pi U}.}\tag{10}
$$

This is an exact normalization consequence of the licensed local Einstein/Dirac **branch**. It is not an assertion that the actual Born–Hopf background contains two isolated stable physical Dirac poles with no competing long-range forces.

## 4. NEW GEOMETRIC CONNECTION: an exact Newton Green function on closed $S^3$

There is no need to model space as an infinite flat $\mathbb R^3$ to identify the **local $1/r$ singular coefficient**. For the round position three-sphere $S^3(R)$, let $\chi\in(0,\pi)$ be the geodesic angle and $r=R\chi$ the geodesic distance. The unique mean-zero Poisson Green distribution is

$$
\boxed{G_R(\chi)=\frac{(\pi-\chi)\cot\chi-1/2}{4\pi^2R}.}\tag{11}
$$

It satisfies, distributionally,

$$
-\Delta_{S^3(R)}G_R=\delta-\frac1{2\pi^2R^3},\quad
\int_{S^3(R)}G_R\,d\mu=0.
$$

The second term is mandatory on compact space: a single uncompensated point charge has no global Poisson inverse. It is the homogeneous mode of the constraint that must be treated with the cosmological/background equations in a physical gravity calculation. It is not a free subtraction.

Its exact small-distance expansion is

$$
\boxed{G_R(r)=\frac1{4\pi r}-\frac3{8\pi^2R}
 -\frac{r}{12\pi R^2}+O(r^2/R^3).}\tag{12}
$$

Its inward flux through a geodesic sphere of angle $\chi$ equals

$$
\boxed{-4\pi R^2\sin^2\chi\,\partial_rG_R
 =1-\frac{\chi-\sin\chi\cos\chi}{\pi}.}\tag{13}
$$

If the actual constrained Newtonian operator specializes to the scalar Laplacian with the Einstein prefactor, its pair potential is $-4\pi G_{\rm scal}m_1m_2G_R$, which has exactly the same leading coefficient as (10). The normalized scalar-Poisson force has local correction $1+(r/R)^2/3+O((r/R)^3)$. This is a *geometric comparison*; higher-curvature and dynamical lapse/metric constraint terms must be included before claiming an observed compact-cosmology force correction.

The robust conclusion is narrower and stronger: a local Einstein principal symbol always has the Euclidean $1/(4\pi r)$ elliptic parametrix, independent of the finite global radius. Hence an exactly flat, globally noncompact spatial background is not necessary for the **short-distance normalization of the tensor Newton coefficient**.

## 5. Distinguish the three irremovable physical gates

### 5.1 Existence of one stationary material seed is not derived

Equation (2) is an identity. On the exact positive parallel scalar-heat branch proved in III-F, Theorem `p3f:thm:v250-exact-parallel-scalar-heat`,

$$
S_J(a,s)=Z_g(a)\operatorname{Tr}_F e^{-s^2\Phi_0^2/L},\qquad
\partial_s S_J
=-\frac{2s}{L}Z_g(a)\operatorname{Tr}_F(\Phi_0^2e^{-s^2\Phi_0^2/L})<0
$$

for every finite $s>0$ and nonzero $\Phi_0$. Therefore the tested quartic reference $s\ne0$ is **not stationary in that exact admitted parallel-heat realization**. A metric-only reference subtraction cannot fix its radial equation. A nonparallel, charged, constrained or different genuinely occurring branch is not excluded by this theorem, but a proof of a suitable stationary seed is still needed.

Paper V-A `p5:cor:v377-no-independent-ew-vacuum-token` gives the electroweak solder from an actual nonzero odd source *without requiring a second electroweak vacuum token*. It does **not** assert that source is a solution of the full scalar field equations. These two roles are logically independent. Paper V-B's terminal mass matrices are not physical propagator poles by that theorem alone.

### 5.2 The action selection is still an adoption

The exact ratio of metric coefficients $K_J/\nu=96$ does not determine which source-normalized physical action nature realizes. In the already adopted model, the centering theorem provides internal consistency and fixes the action uniquely **given the imposed marked-reference restriction and unchanged material derivatives**. Those two selecting requirements are not derived from the original G0–GP3 geometry. Calling that adoption 'unconditional derivation' would promote a choice into an axiom without proof.

### 5.3 Classical cancellation does not prohibit quantum or other soft response

Even for an on-shell reference the exact Gaussian example

$$
S(g,x)=M(g)+\tfrac12(1+\beta g^2)x^2,\quad v(g)=0
$$

has classical stationary action $M(g)$, but integrating the independent material variable gives

$$
\Gamma_{\rm 1loop}(g)=M(g)+\frac\hbar2\log(1+\beta g^2)+\mathrm{const}.
$$

The metric stiffness shifts by $\hbar\beta$ at $g=0$. This is a precise finite countermodel to *automatic all-order protection*, not a computation of the Born–Hopf quantum correction. Similarly, independent truly massless material channels or noncanonical source contacts may contribute additional long-range terms. These must be derived from the actual quantum effective action and observables.

The existing VI-A QROOT closure concerns the native fresh-root scalar/tensor **perturbation state**, and leaves the state-independent vacuum baseline separate; it is not a theorem furnishing the required stationary nonzero full material reference or the laboratory Newton experiment.

## 6. Result and honest closure status

| Requirement | Current result | Status |
|---|---|---|
| Independent reference transport | Derived locally by $D_X S_J=0$ and the implicit-function theorem from one regular stationary seed | **Conditional mathematical closure** |
| Separate classical mixing cancellation | Exactly cancels by (7) | **Conditional mathematical closure** |
| Independent species gravitational vertex | Fixed by canonical Hilbert variation and translation Ward identity, once on-shell normalized poles occur | **Conditional source-normalization closure** |
| Global spatial flatness for local $1/r$ normalization | Replaced by exact $S^3$ Green and local elliptic principal symbol | **Geometric closure** |
| Nonzero stationary material seed of the exact original action | Exact parallel branch counterexample; other branches not proven | **Open** |
| Unique physical action from G0–GP3 rather than adoption | No selection theorem | **Open** |
| Actual full quantum tensor response and source calibration | Determinants, extra soft exchanges, clock/background selection | **Open** |

**DAG action:** add conditional new theorem nodes with explicit dependency edges; retain existing physical owner condition `BH-IIIF-A-0039` as open. No existing proof label, quantifier or physical status is silently upgraded. Do not modify the particle construction in Paper V because this calculation supplies no new particle mass pole.

## 7. Verification

Run `python Paper00-NewtonTensorExchange-v1_28.py`. It independently checks **19 exact symbolic identities**: stationary and off-shell Hessians, marker-normalized Newton coefficient, closed-$S^3$ mean-zero inverse, distributional off-diagonal equation, local singularity, Gauss flux, force expansion, and a quantum determinant counterexample. The deterministic `Paper00-NewtonTensorExchange-v1_28.json` records the results. The tests are algebraic certificates and intentionally do not claim a physical occurrence theorem.

**Key source labels:** `p3f:def:v3041-adopted-metric-assembly`; `p3f:prop:v3041-reference-exchange`; `p3f:prop:v2211-newton-owner-matching`; `p3f:thm:v250-exact-parallel-scalar-heat`; `p3f:prop:v250-boson-elimination-fermion-jet`; `p5:cor:v377-no-independent-ew-vacuum-token`; `p6:def:conditional-pole-packet`; `p8:thm:v2114-fresh-root-neutral-qroot`; `p3f:thm:v1125-terminal-scalaron-schur-decoupling`.
