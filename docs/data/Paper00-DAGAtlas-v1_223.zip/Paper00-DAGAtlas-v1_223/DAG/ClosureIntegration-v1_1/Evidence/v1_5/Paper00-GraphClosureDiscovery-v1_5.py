#!/usr/bin/env python3
"""Paper00-GraphClosureDiscovery-v1_5: exact finite group/core-pair/two-shell verification.

All matrix equalities involving the 25D operator representations are verified in
SymPy rational arithmetic; independent native 600-cell coordinates are checked.
No claim of occurring physical channel, particle decay vertex, clock or detector.
Run from anywhere: python Paper00-GraphClosureDiscovery-v1_5.py
"""
from collections import Counter
import hashlib
import itertools
import json
from pathlib import Path
import sympy as s

ROOT=Path(__file__).resolve().parent
src=json.loads((ROOT/'inputs'/'exceptional_600cell_instance.json').read_text())
r25=json.loads((ROOT/'inputs'/'twisted25_v127_instance.json').read_text())
V={v['id']:tuple(tuple(x) for x in v['qcoords']) for v in src['vertices']}
Vin={q:i for i,q in V.items()}
assert len(V)==len(Vin)==120

def add(a,b):return a[0]+b[0],a[1]+b[1]
def neg(a):return -a[0],-a[1]
def fm(a,b):return a[0]*b[0]+5*a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def qm(a,b):
 x,y,z,w=a;u,v,k,t=b
 z0=[add(add(fm(x,u),neg(fm(y,v))),add(neg(fm(z,k)),neg(fm(w,t)))),
     add(add(fm(x,v),fm(y,u)),add(fm(z,t),neg(fm(w,k)))),
     add(add(fm(x,k),neg(fm(y,t))),add(fm(z,u),fm(w,v))),
     add(add(fm(x,t),fm(y,k)),add(neg(fm(z,v)),fm(w,u)))]
 assert all(a%4==0 and b%4==0 for a,b in z0)
 return tuple((a//4,b//4) for a,b in z0)
def conj(q):return(q[0],)+tuple(neg(z) for z in q[1:])
M=[[Vin[qm(V[i],V[j])] for j in range(120)] for i in range(120)]
e=Vin[((4,0),(0,0),(0,0),(0,0))]
minus=Vin[((-4,0),(0,0),(0,0),(0,0))]
inverse=[Vin[conj(V[i])] for i in range(120)]
assert all(M[i][inverse[i]]==e for i in range(120))

# Five Q8s from order-four elements; subgroup normalizers are exactly five 2Ts.
order4=[g for g in range(120) if V[g][0]==(0,0)]
assert len(order4)==30
QQ=set()
for i,j in itertools.combinations(order4,2):
 k=M[i][j]
 if k not in order4:continue
 q=tuple(sorted({e,minus,i,j,k,M[minus][i],M[minus][j],M[minus][k]}))
 assert len(q)==8 and all(M[x][y] in q for x in q for y in q)
 QQ.add(q)
QQ=sorted(QQ)
assert len(QQ)==5 and len(set().union(*[set(q)-{e,minus} for q in QQ]))==30
Qindex={q:i for i,q in enumerate(QQ)}
perms={}
for g in range(120):
 perms[g]=tuple(Qindex[tuple(sorted(M[M[g][h]][inverse[g]] for h in Q))] for Q in QQ)
 assert sorted(perms[g])==list(range(5))
normalizers=[sum(perms[g][i]==i for g in range(120)) for i in range(5)]
assert normalizers==[24]*5
assert all(perms[M[g][h]]==tuple(perms[g][perms[h][i]] for i in range(5))
           for g in range(120) for h in range(120))

# Two distinguished five-cycle shells. The first is the native 600-cell edge shell.
sh={'nearest':sorted(g for g in V if V[g][0]==(1,1)),
    'f40':sorted(g for g in V if V[g][0]==(-1,1))}
assert all(len(a)==12 for a in sh.values())
assert not (set(sh['nearest'])&set(sh['f40']))
for lab,S in sh.items():
 assert {inverse[g] for g in S}==set(S)
 for g in S:
  p=perms[g]
  assert all(p[i]!=i for i in range(5))
  assert {p[i] for i in range(5)}==set(range(5))
  assert all((lambda x: x)(p[p[p[p[p[i]]]]])==i for i in range(5))
edge={tuple(sorted((int(z['u']),int(z['v'])))) for z in src['nearest_edges']}
assert len(edge)==720
for g in V:
 assert {tuple(sorted((g,M[g][h]))) for h in sh['nearest']}<=edge
assert len(edge)==len({tuple(sorted((g,M[g][h]))) for g in V for h in sh['nearest']})

# Five core marks and ten 2-subset channels: literal quotient counts.
pairs=list(itertools.combinations(range(5),2))
pidx={x:i for i,x in enumerate(pairs)}
H=s.zeros(10,5)
for a,edgepair in enumerate(pairs):
 for i in edgepair:H[a,i]=1
J5=s.ones(5,5);J10=s.ones(10,10)
assert H.T*H==3*s.eye(5)+J5
M5_target=3*(J5-s.eye(5))
M10_target=2*J10-H*H.T
count_matrices={}
for lab,S in sh.items():
 M5=s.zeros(5,5);M10=s.zeros(10,10)
 for g in S:
  p=perms[g]
  for i,j in enumerate(p):M5[i,j]+=1
  for ai,a in enumerate(pairs):
   bi=pidx[tuple(sorted((p[a[0]],p[a[1]])))]
   M10[ai,bi]+=1
 assert M5==M5_target and M10==M10_target
 count_matrices[lab]=(M5,M10)
assert M10_target==M10_target.T
assert all(M10_target[i,j]==(0 if i==j else (1 if len(set(a)&set(b))==1 else 2))
           for i,a in enumerate(pairs) for j,b in enumerate(pairs))
P0=J10/10
Pcol=H*(H.T*H).inv()*H.T
P4=Pcol-P0
PW=s.eye(10)-Pcol
assert PW==s.eye(10)-H*H.T/3+J10/6
assert PW*PW==PW and PW*H==s.zeros(10,5)
assert (s.trace(P0),s.trace(P4),s.trace(PW))==(1,4,5)
K10=M10_target/12
assert K10==P0-P4/4
assert K10*PW==s.zeros(10,10)
for n in range(1,7):assert K10**n==P0+(-s.Rational(1,4))**n*P4

# Electrical resistance of the native pair transport graph, no introduced weights.
Lplus=P4/15+PW/12
assert (12*s.eye(10)-M10_target)*Lplus==s.eye(10)-P0
res_counts=Counter()
for ai,a in enumerate(pairs):
 for bi,b in enumerate(pairs):
  if bi<=ai:continue
  R=s.factor(Lplus[ai,ai]+Lplus[bi,bi]-2*Lplus[ai,bi])
  shared=len(set(a)&set(b))==1
  assert R==(s.Rational(7,45) if shared else s.Rational(13,90))
  res_counts[('shared' if shared else 'disjoint',str(R))]+=1
# Mean hitting time under the stochastic kernel, for all ordered pairs.
K=K10
hit_counts=Counter()
for b in range(10):
 ids=[i for i in range(10) if i!=b]
 v=(s.eye(9)-K.extract(ids,ids)).inv()*s.ones(9,1)
 for pos,a in enumerate(ids):
  share=len(set(pairs[a])&set(pairs[b]))==1
  expected=s.Rational(28,3) if share else s.Rational(26,3)
  assert v[pos]==expected
  hit_counts[('shared' if share else 'disjoint',str(v[pos]))]+=1

# The 5D module W=ker H^T is an intrinsic rational model of the quintet.
W=s.Matrix.hstack(*H.T.nullspace())
assert W.shape==(10,5) and H.T*W==s.zeros(5,5)
Left=(W.T*W).inv()*W.T
assert W*Left==PW
char_counts=Counter()
for g,p in perms.items():
 fixedmarks=sum(i==p[i] for i in range(5))
 fixedpairs=sum(set(edgepair)=={p[edgepair[0]],p[edgepair[1]]} for edgepair in pairs)
 chi=int(fixedpairs-fixedmarks)
 a,b=V[g][0]
 t=(s.Integer(a)+s.Integer(b)*s.sqrt(5))/4
 assert s.simplify(16*t**4-12*t**2+1)==chi
 char_counts[chi]+=1
assert char_counts==Counter({0:48,-1:40,1:30,5:2})
# The signed conference Gram of the 10 projected coordinate lines is forced.
Gline=2*PW
Ssign=3*(Gline-s.eye(10))
assert Gline*Gline==2*Gline and Ssign*Ssign==9*s.eye(10)
for a in range(10):
 for b in range(10):
  assert Gline[a,b]==(1 if a==b else (-s.Rational(1,3) if len(set(pairs[a])&set(pairs[b])) else s.Rational(1,3)))
triple_signs=Counter()
for a,b,c in itertools.combinations(range(10),3):
 prod=Gline[a,b]*Gline[b,c]*Gline[c,a]
 degs=sorted(Counter(x for e2 in (pairs[a],pairs[b],pairs[c]) for x in e2).values(),reverse=True)
 expected=s.Rational(1,27) if degs==[2,2,1,1] else -s.Rational(1,27)
 assert prod==expected
 triple_signs[str(prod)]+=1
assert triple_signs==Counter({'1/27':60,'-1/27':60})

# Class-averaged random-unitary superoperators on End(W), exact rational 25x25.
Phi={}
for lab,S in sh.items():
 out=s.zeros(25,25)
 for g in S:
  P=s.zeros(10,10)
  p=perms[g]
  for a,e2 in enumerate(pairs):
   P[pidx[tuple(sorted((p[e2[0]],p[e2[1]])))],a]=1
  R=Left*P*W
  Ri=Left*P.T*W
  assert R*Ri==s.eye(5)
  out+=s.kronecker_product(Ri.T,R)
 Phi[lab]=out/12
I=s.eye(25)
A=Phi['nearest'];B=Phi['f40'];C=(A+B)/2;D=A-B
assert A*B==B*A and C*D==D*C
assert C*D==D/6 and D**3==s.Rational(5,9)*D
assert C*(C-I)*(C-I/6)*(C+I/4)==s.zeros(25,25)
Pr1=s.Rational(24,25)*(C-I/6)*(C+I/4)*C
Pr33=s.Rational(9,5)*D**2
Pr4=-s.Rational(192,25)*(C-I)*(C-I/6)*C
Pr5=24*(C-I)*(C-I/6)*(C+I/4)
for P,rank in [(Pr1,1),(Pr33,6),(Pr4,8),(Pr5,10)]:
 assert P**2==P and s.trace(P)==rank
assert Pr1+Pr33+Pr4+Pr5==I
assert A==Pr1+Pr33/6+D/2-Pr4/4
assert B==Pr1+Pr33/6-D/2-Pr4/4
assert D*Pr1==s.zeros(25,25) and D*Pr4==s.zeros(25,25) and D*Pr5==s.zeros(25,25)
# Exact algebraic triplet projectors are proved without expanding 625
# algebraic-number entries: Q=(9/5)D^2, QD=D, D^2=(5/9)Q imply
# T_±=(Q ± (3/sqrt(5))D)/2 are orthogonal idempotents.
assert Pr33*D==D and D*Pr33==D
assert D**2==s.Rational(5,9)*Pr33
assert s.trace(D)==0
# Rational part of both projector idempotency and mutual orthogonality:
assert Pr33**2==Pr33 and D**2==s.Rational(5,9)*Pr33
assert s.trace(Pr33)==6
# Their traces are both exactly three; eigenvalue ±sqrt(5)/3 follows D^3=5D/9.
# Center scalar (identity) and no fixed traceless right modes.
assert s.trace(A)==s.trace(B)==0
assert A*Pr1==Pr1 and B*Pr1==Pr1
# Restricted 10-channel effects are insensitive to the difference D.
# Define line projectors from W^T basis. The ten rank-one effects span 1+4+5.
line_effects=[]
for a in range(10):
 x=Left*s.eye(10)[:,a]
 # vector in rational W-coordinates; dual/projector uses induced Gram (W^T W)
 # Q_a = 2 P_W e_a e_a^T P_W, normalized to trace 1 on W.
 z=Left*PW[:,a] # W-coordinates of projected position
 row=(PW[a,:]*W)
 E=2*z*row
 assert s.trace(E)==1 and E*E==E
 line_effects.append(E)
assert len(line_effects)==10
# Operator vec col (all rational); verify shell superoperator annihilates differences.
for E in line_effects:
 vec=s.Matrix([E[i,j] for j in range(5) for i in range(5)])
 assert D*vec==s.zeros(25,1)
assert s.Matrix.hstack(*[s.Matrix([E[i,j] for j in range(5) for i in range(5)]) for E in line_effects]).rank()==10

cert={
 'version':'Paper00-GraphClosureDiscovery-v1_5',
 'source_scope':'2I native vertex-group graph and two 12-element 5-cycle classes; proposed exact finite mathematical results only',
 'inputs_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'inputs').iterdir() if p.is_file()},
 'native_counts':{'vertices':120,'nearest_edges':720,'order4':30,'Q8_subgroups':5,
                  'normalizer_size':24,'shells':{k:len(v) for k,v in sh.items()}},
 'previous_source_5mark_theorem':'Paper1B p1:thm:v345-f40-edge-regular (NOT claimed new)',
 'core_marking_transition_counts':'3(J5-I5) for BOTH shells; already present for F40 in Paper I-B',
 'ten_pair_transition_counts':'2J10-HH^T, diagonal 0, share-one 1, disjoint 2 for BOTH shells',
 'ten_pair_spectrum':{'1':1,'-1/4':4,'0':5},
 'resistance_undirected_pairs':{str(k):v for k,v in res_counts.items()},
 'mean_hitting_times_ordered_pairs':{str(k):v for k,v in hit_counts.items()},
 'quintet_character_counts':{str(k):v for k,v in sorted(char_counts.items())},
 'petersen_signed_gram':'2(I-HH^T/3+J10/6), offdiag -1/3 shared and +1/3 disjoint',
 'triple_signs':dict(triple_signs),
 'full_endV5_channel_spectra':{
   'nearest':{'1':1,'(1+sqrt5)/6':3,'(1-sqrt5)/6':3,'-1/4':8,'0':10},
   'f40':'same multiset; triplet sectors exchanged'},
 'full_EndK25_spectrum_multiplicity_factor':25,
 'exact_two_shell_polynomials':{'C':'(A+B)/2', 'D':'A-B', 'CD':'D/6', 'D^3':'5D/9',
   'minpoly_C':'C(C-1)(C-1/6)(C+1/4)=0',
   'rank_three_projectors':'(9 D^2/5 +/- 3 D/sqrt5)/2'},
 'exact_25x25_rational_replay_passed':True,
 'physical_occurrence':False,
 'conditions_not_removed':['physically occurring 600-cell right-conjugation dynamics',
   'why random-unitary Markov rather than unitary or other dynamics',
   'source Hamiltonian and particle-state assignment',
   'dimensional conversion from graph step to lifetime',
   'physical detector sensitivity to 3 and 3prime triplets']}
(ROOT/'Paper00-GraphClosureDiscovery-v1_5.json').write_text(json.dumps(cert,indent=2,sort_keys=True)+'\n')
print('PASS v1_5 exact: five Q8s, two shells, ten-pair transport, resistance/hitting, Petersen Gram, two 25D rational twirls, cubic/polynomial projectors')
print('native five and ten transition-count identities verified for both shells')
print('ranks C sectors (1,6,8,10); triplet projectors rank 3+3; pair effects blind to D')
print('certificate',ROOT/'Paper00-GraphClosureDiscovery-v1_5.json')
