# Born–Hopf Geometry — two-shell coherent transport and exact ten-channel closure (v1.5)

**Release:** `Paper00-GraphClosureDiscovery-v1_5`, 19 November 2026. **Status:** newly derived exact finite mathematical theorems, with a complete rational-arithmetic verifier and source crosswalk. **Not** an insertion into authoritative papers, DAG or S³ archives. **No** physical action occurrence, mass assignment, decay vertex, clock or detector is inferred.

## 1. Scope, sources and provenance discipline

The authoritative current user-supplied sources inspected are `Paper00-PapersMinimal-v3_040(1).zip` (especially `Paper1B-ExceptionalGeometry-v1_18.tex`) and `Paper00-S3StructureNetwork-v1_40(1).zip`. The original source dataset is `exceptional_600cell_instance.json` in `inputs/`; `twisted25_v127_instance.json` accompanies it as the already source-certified zero-band witness. The dependency audit is `Paper00-DAGAtlas-v1_190(1).zip`.

**Already known, not newly discovered:**

- `p1:thm:v345-f40-edge-regular` in Paper I-B *already proves* that the twelve-element F40 shell acts via all twelve five-cycles of one class and that its five-core transfer-count matrix equals `3(J_5-I_5)` with eigenvalues `1,-1/4` after normalization. GC-20 is only an independent source connection, not a novel theorem.
- `p1b:thm:cc20-two-core-lumping` gives the continuous-time chamber-walk core-marginal generator `(J_5-5I_5)/4`; the new vertex-shell quotient has exactly this generator after a unit-event Poissonization. **This does not identify physical time units between the two walks.**
- `p1:thm:petersen-angular-quadrupole` already constructs the rank-five `P_5` in the ten-axis permutation module; the novel component below is the independent link from the *unmarked v1.4 rank-five pair-channel projectors* to both distinguished five-cycle shell twirls and their coherence-sector separation.
- `p1:cor:v3026-twisted25-adjacency-kernel`, `p1b:thm:v3023-five-coset-adjacency`, `p1b:thm:v3027-hurwitz-character-zero-modes` fix the prior zero-band/quaternionic data; they are not reclassified as new.
- Prior v1.4 derived five unmarked rank-10 projectors `P_i`, five rank-15 complements and ten rank-five projectors `T_{ij}` on the 25D adjacency-zero band, including exact signed Petersen triple products. These are a mathematical family, not a new physical 15D momentum carrier.

## 2. GC-20 (source bridge, not a newly proved original theorem)

Let `G=2I` and let `Q_{8,1},...,Q_{8,5}` be its five Sylow-2 subgroups. Their normalizers are the five conjugate `2T` subgroups. Let

\[
S_+=\{g\in2I:\operatorname{Re}g=(1+\sqrt5)/4\},\qquad
S_-=\{g\in2I:\operatorname{Re}g=(\sqrt5-1)/4\}.
\]

The first is the native nearest-neighbour shell of the 120-vertex 600-cell, and the second is the F40 shell specified by Paper I-B. Both have twelve elements and act by conjugation on the five `Q8` labels as twelve distinct five-cycles. The two shells are the two distinct conjugacy classes of five-cycles in `A5` (after the quotient by the central `±1`). For either shell, the induced unweighted transition **count** matrix on five subgroup labels is

\[
M_5=3(J_5-I_5),\quad K_5=M_5/12=(J_5-I_5)/4,
\quad\mathrm{spec}(K_5)=\{1,(-1/4)^4\}.
\]

The F40 instance is already an exact source theorem. The 120-vertex nearest-shell realization is an independently checked bridge to the source's F40 and chamber-walk classes, not an additional physical rate. In dimensionless unit-event time, the Poissonized generator is `K_5-I=(J_5-5I_5)/4`, matching the quoted chamber-marginal generator exactly.

## 3. GC-21: ten-pair transition counts are exactly unequal and shell-independent

Let `E` be the ten unordered 2-subsets `a={i,j}` of the five marks, and let `H` be their ten-by-five point-incidence matrix, `H_{a,i}=1` for `i∈a`. Thus `H^T H=3I_5+J_5`. Each of the 12 automorphisms in either shell permutes the ten pair labels. For either `S=S_+` or `S=S_-`:

\[
\boxed{M_{10}(a,b)=\#\{s\in S:s(a)=b\}=\begin{cases}
0,&a=b,\\1,&|a\cap b|=1,\\2,&a\cap b=\varnothing,
\end{cases}}
\]

and hence

\[
\boxed{M_{10}=2J_{10}-HH^{T}},\qquad
\boxed{K_{10}=M_{10}/12}.
\]

**Source-level proof, avoiding a fit:** An individual five-cycle fixes no unordered pair. On the 12 cycles in a class, any chosen mark `i` is sent three times to each of its four other targets, by the transitive point-stabilizer. For `a={i,j}`, the six cycles with `s(i)=j` or `s(j)=i` (disjoint alternatives, because a five-cycle cannot contain a 2-cycle) yield an intersecting target. There are six possible intersecting targets, permuted transitively by the pair stabilizer. Thus each occurs once. The other six cycles give three possible disjoint targets, each twice. This proves the matrix identity simultaneously for the two classes.

The kernel is symmetric with degree twelve. Its eigenvalues follow without diagonalization: `H^TH=3I+J` implies `R^{10}=1⊕4⊕5` as five-mark permutation representations, and on these three summands `M10` acts by `12,-3,0`. Thus

\[
\boxed{\operatorname{spec}(K_{10})=\{1^{(1)},(-1/4)^{(4)},0^{(5)}\}.}
\]

Let `P_0=J10/10`, `P_4=H(H^TH)^{-1}H^T-P0`, and `P_W=I-P0-P4`. Every `n≥1` obeys the exact (non-asymptotic) formula

\[
K_{10}^{n}=P_0+(-1/4)^nP_4.
\]

**Assumption removed:** on the fixed class of nearest/F40 induced pair-label transfers, there are no free relative weights for the six intersecting and three disjoint outgoing channels. They are `1/12` and `1/6`, respectively. The choice to physically realize such a stochastic transport is *not* derived.

## 4. GC-22: two distinct shell twirls split the coherent triplets exactly

On `W=ker H^T≅R^5`, denote the orthogonal action of `s∈2I` by `ρ5(s)` in the induced inner product. Define the two **mathematical** random-unitary channels (not asserted to occur):

\[
\Phi_\pm(X)=\frac1{12}\sum_{s\in S_\pm}\rho_5(s)X\rho_5(s)^*,\quad X\in\mathrm{End}(W).
\]

Conjugation covariance, the fact that each 12-shell is a full conjugacy class, and normalization make these the unique **class-invariant, shell-supported random-unitary averages**; this does **not** uniquely select random-unitary physical dynamics from G0/GP1–3.

As an `A5` module,

\[
\operatorname{End}(W)=\mathbf1\oplus\mathbf3\oplus\mathbf3'\oplus2\mathbf4\oplus2\mathbf5.
\]

The class-average scalar on any irreducible sector `V_λ` is its shell character divided by its dimension. For `S+` (rotation class 72°) and `S−` (144°):

| Sector | Dimension | `Φ+` eigenvalue | `Φ−` eigenvalue |
|---|---:|---|---|
| `1` | 1 | `1` | `1` |
| `3` | 3 | `(1+√5)/6` | `(1−√5)/6` |
| `3′` | 3 | `(1−√5)/6` | `(1+√5)/6` |
| `4` twice | 8 | `−1/4` | `−1/4` |
| `5` twice | 10 | `0` | `0` |

The near-neighbour coherent class average **on amplitude vectors** is zero, since `χ5(S+)=0`: `Σ_{s∈S+}ρ5(s)=0`, faithfully reflecting `A600 P25=0`. Nevertheless the **quadratic adjoint/quantum-density** transport is nonzero and has the complete nontrivial spectrum above. This resolves the zero-band adjacency degeneracy for the specified second-order comparison operator without adding a potential or splitting its 25-vector eigenspace by hand.

## 5. GC-23: Basis-free polynomial spectral closure

Put `C=(Φ++Φ−)/2`, `D=Φ+−Φ−`. The two rational 25×25 matrices satisfy, by exact rational replay,

\[
\boxed{CD=DC=\tfrac16D,\quad D^3=\tfrac59D,\quad C(C-I)(C-\tfrac16I)(C+\tfrac14I)=0.}
\]

The eigenvalue multiplicities of `C` are `(1,1),(1/6,6),(-1/4,8),(0,10)`, and `D` has `(√5/3,3),(-√5/3,3),(0,19)`. Consequently the two rank-three projectors are derived without preassigning any triplet basis:

\[
\boxed{\Pi_{3,\pm}=\frac12\left(\frac95D^2\pm\frac3{\sqrt5}D\right)}.
\]

The polynomial identities prove these operators are orthogonal idempotents of rank three. The other isotypic projectors are rational polynomials in `C`:

\[
\begin{aligned}
\Pi_1 &= \tfrac{24}{25}(C-\tfrac16I)(C+\tfrac14I)C,\\
\Pi_4 &= -\tfrac{192}{25}(C-I)(C-\tfrac16I)C,\\
\Pi_{5\oplus5} &=24(C-I)(C-\tfrac16I)(C+\tfrac14I).
\end{aligned}
\]

**Removed assumption:** within the two class-averaged geometric operator algebra, the full representation-sector projectors—including the two inequivalent triplets and their assignment to the near vs F40 shell—are polynomial consequences of fixed geometry. No chosen basis or extra sector-splitting coupling is needed. The exact proof does not assert that either shell channel is a realized decay mechanism.

## 6. GC-24: exact pair-transport resistance and hitting-time response

With unit multiplicities `M10` as weighted conductance edges, the graph Laplacian is `L10=12I-M10` and has exact pseudoinverse

\[
L_{10}^{+}=\frac1{15}P_4+\frac1{12}P_W.
\]

Consequently, for two **different** pair labels:

| Relation | Direct generator count | Effective resistance | Mean first hitting time of `K10` |
|---|---:|---:|---:|
| Intersect (`|a∩b|=1`) | 1 | `7/45` | `28/3` steps |
| Disjoint (`a∩b=∅`) | 2 | `13/90` | `26/3` steps |

The resistance values follow by `R_ab=(e_a-e_b)^T L+ (e_a-e_b)`. By regularity/reversibility and pair-transitivity, the mean commute time is `120 R_ab`, the mean one-way hitting time half of that. In addition to that analytic argument, the verifier solves **all ten absorbing-chain 9×9 rational linear systems**, checking all 90 ordered hitting times exactly. These are graph-step observables, not physical lifetimes.

## 7. Incidence proof strengthening: the exact quintet and signed Petersen Gram are reconstructed from incidence

The existing Paper I-B ten-axis rank-five projector is, in this notation,

\[
\boxed{P_W=I_{10}-\frac13 HH^T+\frac16J_{10}},\quad
W=\ker H^T\cong\mathbf5.
\]

The character of this `A5` module is **directly** `χ_W(g)=#fixed 2-subsets-#fixed marks`, and for the classes `(1,2A,3A,5A,5B)` is `(5,1,-1,0,0)`. This equals the source's `U4(Re q)` quintet character at every one of the 120 quaternionic elements, as the verifier checks exactly.

The normalized projected coordinate lines have ten-by-ten Gram `G=2P_W`. Their diagonals are one, their off-diagonal entries are `-1/3` when the two pair labels intersect and `+1/3` when disjoint. Thus

\[
G^2=2G,\qquad S:=3(G-I_{10})=2A_{\rm Petersen}+I_{10}-J_{10},\quad S^2=9I_{10}.
\]

For three distinct pair labels, `G_ab G_bc G_ca=+1/27` exactly if the three K5 edges form a path on four distinct vertices; otherwise it equals `-1/27` (60 configurations each). This is a **new direct elementary incidence proof and cross-representation identification** for the signed cubic rule already verified numerically in v1.3–v1.4; it is not falsely advertised as an entirely new signed Petersen theorem.

## 8. GC-25: sharp observable limitation and derived dimensionless relaxation ratios

The v1.4 `T_{ij}` rank-five projectors transform as the ten 2-subset labels. Their right-factor effects span the `1⊕4⊕5` permutation module, containing **no** `3` or `3′`. Hence `D` annihilates every one of the ten pair-projector effects. In particular, for every initial density operator `ρ`, every single-time readout `T_a`, and every `n≥0`:

\[
\boxed{\operatorname{Tr}(T_a\Phi_+^n(\rho))
=\operatorname{Tr}(T_a\Phi_-^n(\rho)).}
\]

This statement concerns the two mathematical shell channels and pair-effect marginal readouts. It does not automatically extend to arbitrarily instrumented multi-time histories. A measurement sensitive to at least one triplet operator is necessary to distinguish the two shell classes in these single-time statistics.

The unique fixed point of each right-factor channel on a trace-one `5×5` state is `I5/5`. On the full native **rank-25 band** `V5_left⊗V5_right`, the channel is `id_left⊗Φ±`; therefore its fixed operator algebra has dimension **25**, not one: it does *not* erase the left degrees of freedom.

The elementary continuous-time Poissonization `L±=Φ±−I` is a mathematically valid GKLS generator. Its nonzero *dimensionless* relaxation rates are

\[
\gamma_{3}^{(+)}=\frac{5-\sqrt5}{6},\quad
\gamma_{3'}^{(+)}=\frac{5+\sqrt5}{6},\quad
\gamma_{4}=\frac54,\quad\gamma_{5}=1.
\]

The `3↔3′` rates exchange for `Φ−`. The ratio

\[
\boxed{\frac{\gamma_{3'}^{(+)}}{\gamma_{3}^{(+)}}
=\frac{3+\sqrt5}{2}=\varphi^2}
\]

is therefore fixed without channel-specific weights. A **physical** inverse-time rate remains underived: multiplying `L` by any rate `Γ>0` is a distinct physical clock/owner choice. No Standard Model decay branch, lifetime or hadronic width has been inferred.

## 9. GC-26: a sharp no-go for assigning a physical decay arrow to the bare shell kernel

The derived `K10` is symmetric and has **strictly positive off-diagonal entries** between every two distinct pair labels. It is irreducible and aperiodic (there are 3-cycles), and its only stationary probability law is the uniform distribution on ten labels. The stationary probability currents vanish identically:

\[
\pi_a=1/10,\qquad \pi_a K_{10}(a,b)-\pi_b K_{10}(b,a)=0.
\]

Likewise each mathematical right-quintet channel `Φ±` is **unital**, and its only stationary right-factor density matrix is `I5/5`. Consequently, the bare shell transports cannot by themselves produce absorbing final channels, a mass-ordered irreversible arrow, or forbidden channel pairs. This is a precise negative statement *within the derived shell Markov/channel class*; it is not a no-go for an action-derived dynamical law that contains additional already generated physical structure. The earliest remaining physical dependency is an occurring spectral/action source specifying the relevant particle states and asymmetric interaction with them—not a free adjustment of the ten geometric transfer weights.

## 10. Exact verification and condition ledger

The verifier reconstructs native quaternion multiplication from the supplied exact vertices; enumerates five `Q8` groups and their order-24 normalizers; checks the 720 native nearest edges, two independent 12-element shells, all 120 five-marking conjugations, each shell's `5×5` and `10×10` transition matrices, the exact `10×10` incidence projector and its signed cubic rule; solves all 90 directed hitting times exactly; verifies `U4` character identities on every group element; and builds **both 25×25 superoperators in rational arithmetic**, verifying their joint cubic/minimal-polynomial identities and all sector projectors. The triplet projectors involve `√5` but are proved algebraically from rational matrix identities (no floating-point eigensolver or arbitrary cutoff). It also verifies that all ten projected rank-one effects are annihilated by the channel difference.

| Dependency/question | Outcome |
|---|---|
| Independent five-core kernel from F40 shell | Already proved in Paper I-B; independently replayed and cross-linked; **not counted new** |
| Separate rates for ten pair channels under class-invariant shell transfer | **Removed**; exact 1 vs 2 generator counts |
| Exact pair transport spectrum, resistance and first hitting times | **Derived**, no numerical fit |
| Independent quintet-coordinate model and Petersen signs in this two-shell calculation | **Removed via incidence**; source-projector equivalence and cubic rule verified |
| Choosing `3/3′` basis or introducing a triplet splitting parameter | **Removed** in the joint shell-channel operator algebra; rank-three projectors polynomial in `D` |
| Assuming pair-only readout distinguishes the two classes | **Refuted**; exact `D T_a=0` blind subspace |
| Selecting random-unitary stochastic evolution rather than an arbitrary unitary/other action | **Not derived** from constitutional foundations; a mathematical choice of dynamical class |
| Physical source occurrence, decay direction, mass pole and clock | **Open**; no promotion or new axiom |

**Reproduce:** `OPENBLAS_NUM_THREADS=1 python Paper00-GraphClosureDiscovery-v1_5.py` in the extracted package. Source-ready proposal: `Paper1B-TwoShellCoherentTransportClosure-v1_1.tex`; proposed but unapplied DAG delta: `Paper00-GraphClosureDAGDelta-v1_3.json`. This package does not edit the authoritative 145 MB DAG Atlas or any existing `.tex` paper.
