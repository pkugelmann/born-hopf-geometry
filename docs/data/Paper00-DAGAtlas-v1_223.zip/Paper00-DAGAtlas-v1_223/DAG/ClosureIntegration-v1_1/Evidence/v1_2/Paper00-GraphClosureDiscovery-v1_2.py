#!/usr/bin/env python3
"""Exact no-free-weight 600-cell->24-cell Dirichlet response certificate.

Input data is unmodified from S3 Structure Network v1_40.
Theorem import: Paper I-B p1b:thm:v3027-600-hurwitz-mode-resolvent.
No physical action, rate, pole or measured constant is asserted.

Run: python Paper00-GraphClosureDiscovery-v1_2.py
Requires numpy, sympy; checks exact rational shell algebra and all five
cosets with independent floating-point Schur elimination.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
from collections import Counter
import numpy as np
import sympy as s

ROOT=Path(__file__).resolve().parent
IN=ROOT/'inputs'
file600=IN/'exceptional_600cell_instance.json'
file24=IN/'hurwitz_cellular_v129_instance.json'
X=json.loads(file600.read_text())
H=json.loads(file24.read_text())['hurwitz_group']
sha={x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in [file600,file24]}

# Paper I-B's native 2I nearest-neighbour adjacency and its five marked cosets.
A=np.zeros((120,120),dtype=np.int64)
for e in X['nearest_edges']:
    i,j=e['u'],e['v'];assert i!=j and not A[i,j];A[i,j]=A[j,i]=1
assert len(X['vertices'])==120 and len(X['nearest_edges'])==720
assert np.array_equal(A,A.T) and np.all(A.sum(axis=1)==12)
vertices={v['id']:v for v in X['vertices']}
colors={c:sorted(k for k in vertices if vertices[k]['color']==c) for c in range(5)}
assert all(len(ids)==24 for ids in colors.values())
assert all(np.all(A[np.ix_(ids,ids)]==0) for ids in colors.values())

# Exact rational five-shell algebra of the native 24-cell.
quats=H['units_2q'];N=24
assert len(quats)==24
shells=[s.Integer(1),s.Rational(1,2),s.Integer(0),s.Rational(-1,2),s.Integer(-1)]
matrices=[]
for k,angle in enumerate(shells):
    D=np.zeros((24,24),dtype=np.int64)
    for i in range(N):
        for j in range(N):
            if s.Rational(sum(p*q for p,q in zip(quats[i],quats[j])),4)==angle:
                D[i,j]=1
    matrices.append(D)
assert np.array_equal(sum(matrices),np.ones((24,24),dtype=np.int64))
shell_counts=[int(d[0].sum()) for d in matrices]
assert shell_counts==[1,8,6,8,1]
assert all(np.array_equal(D,D.T) for D in matrices)
# The nearest Hurwitz adjacency N is precisely the inner-product 1/2 shell.
T=np.zeros((N,N),dtype=np.int64)
for i in range(N):
    for g in H['nearest_neighbor_generators']:
        T[i,H['multiplication_table'][i][g]]=1
assert np.array_equal(T,matrices[1])

# Multiplication coefficients in the five-dimensional rational shell algebra.
mul=np.zeros((5,5,5),dtype=int)
for a in range(5):
    for b in range(5):
        z=matrices[a]@matrices[b]
        for c in range(5):
            values=set(int(v) for v in z[matrices[c]==1]);assert len(values)==1
            mul[a,b,c]=values.pop()
        assert np.array_equal(z,sum(int(mul[a,b,c])*matrices[c] for c in range(5)))
assert np.array_equal(mul,mul.transpose(1,0,2))

def mult(a,b):
    return s.Matrix([sum(a[i]*b[j]*int(mul[i,j,k]) for i in range(5) for j in range(5))
                     for k in range(5)])

unit=s.Matrix([1,0,0,0,0]);near=s.Matrix([0,1,0,0,0]);lap=8*unit-near
lambdas=[8,4,0,-2,-4]  # eigenvalues of N (Paper I-B, same source theorem)
mults=[1,4,9,8,2]
P={}
for eigen,rank in zip(lambdas,mults):
    p=unit
    for other in lambdas:
        if other!=eigen:p=mult(p,(near-other*unit)/(eigen-other))
    assert mult(p,p)==p
    assert int(N*p[0])==rank
    P[eigen]=p
assert sum(P.values(),s.zeros(5,1))==unit
assert all(mult(P[i],P[j])==s.zeros(5,1) for i in lambdas for j in lambdas if i!=j)

# Paper I-B exactly provides F_eigen(x).  Evaluate, no fitted scalar shift.
x=s.Integer(12)
F={
    8: 36/(x-9),
    4: 24*(x+3)/(x*x-4*x-24),
    0: 4*x*(3*x+8)/(x**3-x*x-16*x-16),
    -2: 6/(x-1),
    -4: s.Integer(0),
}
F={a:s.factor(v) for a,v in F.items()}
assert [F[e] for e in lambdas]==[12,5,s.Rational(66,43),s.Rational(6,11),0]
lev={e:s.factor(12-F[e]) for e in lambdas}
assert [lev[e] for e in lambdas]==[0,7,s.Rational(450,43),s.Rational(126,11),12]
Scoeff=sum((lev[e]*P[e] for e in lambdas),s.zeros(5,1))
assert list(Scoeff)==[s.Rational(56245,5676),-s.Rational(115,132),
                      -s.Rational(53,172),-s.Rational(17,132),
                      -s.Rational(343,5676)]
assert all(Scoeff[i]<0 for i in range(1,5))
assert sum(shell_counts[i]*Scoeff[i] for i in range(5))==0
assert all(mult(Scoeff,P[e])==lev[e]*P[e] for e in lambdas)

# Full exact response/pseudoinverse.  Electrical resistance is intrinsic
# to this graph Dirichlet form and is exactly preserved under Schur reduction.
Gcoeff=sum((P[e]/lev[e] for e in lambdas if lev[e]!=0),s.zeros(5,1))
J24=s.Matrix([s.Rational(1,24)]*5)
assert mult(Scoeff,Gcoeff)==unit-J24
Rvals=[s.factor(2*(Gcoeff[0]-Gcoeff[i])) for i in range(5)]
assert Rvals==[0,s.Rational(14293,75600),s.Rational(1903,9450),
               s.Rational(5231,25200),s.Rational(40,189)]
L24vals={e:8-e for e in lambdas}
differences={e:s.factor(lev[e]-L24vals[e]) for e in lambdas}
assert list(differences.values())==[0,3,s.Rational(106,43),s.Rational(16,11),0]
assert all(v>=0 for v in differences.values())
# GC-08: the all-path Neumann series is automatically convergent because
# each complement is 9-regular but the full graph degree is 12.
# ||B||^2 = 36 from the k=0 return identity; ||C|| = 9.
# Consequently the bound 12*(3/4)^(n+1) is sharp for EVERY n>=0:
# the coset-constant mode has C-eigenvalue 9 and BB* eigenvalue 36.
first_four_return=[s.Matrix(v) for v in [(12,3,0,0,0),
    (60,27,8,0,0),(420,225,92,18,0),(3024,1845,952,342,12)]]
partial=s.zeros(5,1)
sharp_tail_checks=[]
for n,return_word in enumerate(first_four_return):
    partial += return_word / (12**(n+1))
    eigerr={e:s.factor(F[e]-24*mult(P[e],partial)[0]/mults[i])
            for i,e in enumerate(lambdas)}
    exact_norm=max(abs(z) for z in eigerr.values())
    expected_tail=s.Integer(12)*(s.Rational(3,4)**(n+1))
    assert exact_norm==expected_tail
    assert eigerr[8]==expected_tail
    sharp_tail_checks.append({'truncation_last_power':n,
             'exact_operator_norm_error':str(exact_norm)})

# Independent direct 96-vertex Schur eliminations, *for all five cosets*.
L600=12*np.eye(120)-A
integer_checks=[]
err={}
for c, ids in colors.items():
    outside=[i for i in range(120) if i not in set(ids)]
    B=A[np.ix_(ids,outside)]
    C=A[np.ix_(outside,outside)]
    assert np.all(B.sum(axis=1)==12) and np.all(C.sum(axis=1)==9)
    dot_mat=np.empty((24,24),dtype=int)
    for ai,i in enumerate(ids):
        qi=vertices[i]['qcoords']
        for bi,j in enumerate(ids):
            qj=vertices[j]['qcoords']
            a=sum(p[0]*q[0]+5*p[1]*q[1] for p,q in zip(qi,qj))
            b=sum(p[0]*q[1]+p[1]*q[0] for p,q in zip(qi,qj))
            assert b==0 and a in [16,8,0,-8,-16]
            dot_mat[ai,bi]=[16,8,0,-8,-16].index(a)
    assert all(np.all(np.sum(dot_mat==k,axis=1)==shell_counts[k]) for k in range(5))
    Ns=(dot_mat==1).astype(np.int64)
    assert np.array_equal(B@B.T,12*np.eye(24,dtype=np.int64)+3*Ns)
    # Replay Paper I-B's first four complementary returns, exact integer.
    mat=np.eye(96,dtype=np.int64)
    source_coeffs=[(12,3,0,0,0),(60,27,8,0,0),(420,225,92,18,0),
                   (3024,1845,952,342,12)]
    for k in range(4):
        return_k=B@mat@B.T
        target=np.array([source_coeffs[k][j] for j in dot_mat.flat],dtype=np.int64).reshape(24,24)
        assert np.array_equal(return_k,target),(c,k)
        mat=mat@C
    predicted=np.array([float(Scoeff[j]) for j in dot_mat.flat]).reshape(24,24)
    computed=12*np.eye(24)-B@np.linalg.solve(12*np.eye(96)-C,B.T)
    val=float(np.max(np.abs(predicted-computed)))
    err[c]=val
    assert val<5e-13,(c,val)
    assert np.max(abs(predicted@np.ones(24)))<1e-13
    integer_checks.append({'coset':c,'four_return_identities_exact_integer':True,
                           'unit_incidence_A_squared_identity':True,
                           'direct_Schur_max_abs_error':val})

# No arbitrary equal-edge walk, intermediate path truncation, or physical owner.
certificate={
    'id':'Paper00-GraphClosureDiscovery-v1_2',
    'scope':'native unit-incidence 600-cell graph Dirichlet energy only',
    'source':'Paper1B-ExceptionalGeometry-v1_18.tex',
    'imported_theorem':'p1b:thm:v3027-600-hurwitz-mode-resolvent',
    'source_version':'PapersMinimal-v3_040',
    'S3_version':'S3StructureNetwork-v1_40',
    'inputs_sha256':sha,
    'Hurwitz_inner_products':[str(k) for k in shells],
    'shell_sizes':shell_counts,
    'F_lambda_at_12':{str(k):str(F[k]) for k in lambdas},
    'L_eff_eigenvalues':{str(k):{'multiplicity':mults[i],'value':str(lev[k])}
                         for i,k in enumerate(lambdas)},
    'effective_Laplacian_coeff_by_inner_product':[str(z) for z in Scoeff],
    'effective_resistances_by_inner_product':[str(z) for z in Rvals],
    'L_eff_minus_L24_eigenvalues':{str(k):str(differences[k]) for k in lambdas},
    'geometric_kernel_dim':1,'geometric_min_positive_eigenvalue':'7',
    'full_resolvent_Neumann_ratio':'3/4',
    'sharp_all_path_tail_formula':'12*(3/4)^(n+1) for powers 0..n',
    'exact_tail_checks':sharp_tail_checks,
    'exact_rational_shell_algebra':True,
    'all_five_cosets':integer_checks,
    'max_numerical_abs_error':max(err.values()),
    'physical_owner_status':'NOT GENERATED by graph Dirichlet reduction',
}
print(json.dumps(certificate,indent=2))
if __name__=='__main__':
    (ROOT/'Paper00-GraphClosureDiscovery-v1_2.json').write_text(json.dumps(certificate,indent=2)+'\n')
