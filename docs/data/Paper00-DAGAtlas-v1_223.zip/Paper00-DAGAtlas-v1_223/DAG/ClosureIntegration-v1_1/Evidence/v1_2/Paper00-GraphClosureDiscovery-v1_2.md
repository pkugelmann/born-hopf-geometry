# Paper00 — Graph Closure Discovery v1.2

**Date:** 19 November 2026. **Baseline:** Paper00-GraphClosureDiscovery-v1_1. **Current authoritative corpus inspected:** PapersMinimal v3.040, Paper I-B `Paper1B-ExceptionalGeometry-v1_18.tex`, S³ Structure Network v1.40, DAG Atlas v1.190, ProofChainAudits v1.79. **Type:** source-derived exact mathematical closure, with independent reproducible verification. **Does not edit authoritative papers or register a physical action occurrence.**

## Executive result: GC-07, the exact, parameter-free finite graph Dirichlet closure

A previously unexploited consequence of the already proved Paper I-B resolvent is the **complete** graph Dirichlet-to-Neumann map from the 120-vertex 600-cell to any of its five 24-vertex Hurwitz cosets. This removes a separate *stochastic-walk choice*, any *two-step-only truncation*, and any *independent 24-cell boundary conductance assignments* in the **canonical unit-edge Dirichlet comparison**. It does **not** prove that the physical heat/gauge/decay action uses that comparison.

### Exact source dependencies

1. Paper I-B, `p1b:thm:v3023-five-coset-adjacency`, gives the five 24-vertex cosets, 12-regular 600-cell graph, no within-coset 600-nearest links, and three neighbours in each other coset.
2. Paper I-B, `p1b:thm:v3027-600-hurwitz-returns`, gives the complete exact first four return matrices, including `BB*=12I+3N`. **This already establishes the identity presented in v1.1 as GC-04.** It must not be promoted as an originally missing source theorem.
3. Paper I-B, `p1b:thm:v3027-600-hurwitz-mode-resolvent`, already proves the entire complementary spectral resolvent `B(xI-C)^(-1)B* = sum F_lambda(x) E_lambda`, not just its first four terms. This is the crucial upstream input to GC-07.
4. Paper I-B, `p1b:thm:v3027-hurwitz-character-zero-modes`, already proves the `N=-4` two-dimensional external-annihilation sector, and its paper's physical-boundary remark explicitly excludes treating these graph identities as a selected decay Hamiltonian.
5. S³ Structure Network v1.40 supplies the exact native adjacency and unit-quaternion coordinate bank, used for the independent matrix verification. The network is a mathematical relation graph, not a substitute for the source proofs.

### Closed derivation

Use the source's 120-by-120 adjacency decomposition for one Hurwitz coset `H` and its 96-node complement `O`:

\[
A_{600}=\begin{pmatrix}0&B\\B^\ast&C\end{pmatrix},\qquad
L_{600}=12I-A_{600}
=\begin{pmatrix}12I_{24}&-B\\-B^\ast&12I_{96}-C\end{pmatrix}.
\]

Define the canonical **unit-incidence graph Dirichlet form**, which uses no fitted weights, by

\[
\mathscr D(f)=\tfrac12 f^\ast L_{600} f=\tfrac12\sum_{\{u,v\}\in E_{600}}|f_u-f_v|^2.
\]

For fixed boundary values `x=f|_H`, minimize the form over all outside values `y=f|_O`. Since the 600-cell nearest graph is connected and `H` is nonempty, `12I_96-C` is strictly positive and the minimizer is unique:

\[
y_\ast=(12I-C)^{-1}B^\ast x,
\qquad \min_{y}\mathscr D(x,y)
=\tfrac12x^\ast L_{\rm eff}x,
\]

\[
\boxed{L_{\rm eff}=12I_{24}-B(12I_{96}-C)^{-1}B^\ast.}\tag{GC-07.1}
\]

No arbitrary `Delta`, boundary return cutoff, random walk, or 24-cell internal edge matrix enters (GC-07.1). The number **12** is the *existing exact vertex degree*, not a phenomenological source energy or a new adjustable quantity.

### GC-08: the all-path return is automatically convergent, with exact sharp error

The source also establishes that the 96-node complementary graph `C` is **9-regular**. Thus `||C||_2=9`, while the parent 600-cell vertex degree is **12**. It follows without an independent spectral-domain assumption that `||C/12||=3/4<1` and

\[
\boxed{B(12I-C)^{-1}B^* = \sum_{k=0}^{\infty} \frac{BC^kB^*}{12^{k+1}}.}\tag{GC-08.1}
\]

The source's first-return relation `BB*=12I+3N` gives the exact operator norm `||B||²=36`. Therefore, truncating after `k=n` gives the rigorous uniform bound

\[
\left\| B(12I-C)^{-1}B^* -\sum_{k=0}^{n}\frac{BC^kB^*}{12^{k+1}}\right\|_2
\le 12\left(\frac34\right)^{n+1}.\tag{GC-08.2}
\]

**This bound is attained exactly**, for every nonnegative integer `n`, on the constant Hurwitz mode: the complement-constant channel has `C`-eigenvalue `9` and `BB*`-eigenvalue `36`. Hence equality holds in (GC-08.2). This is an exact answer to how incomplete return-path truncations differ from the full response, not a guessed approximation. The finite resolvent's **convergence condition is automatically discharged** at the geometrically fixed Laplacian shift `12`. The formula is not a time-dependent decay law.

Paper I-B explicitly gives, on the five eigenspaces of the Hurwitz nearest adjacency `N`, whose multiplicities are `1,4,9,8,2`,

| `lambda(N)` | Source exact `F_lambda(x)` | `F_lambda(12)` | `lambda(L_eff)=12-F_lambda(12)` |
|---:|---|---:|---:|
| 8 | `36/(x-9)` | 12 | **0** |
| 4 | `24(x+3)/(x²-4x-24)` | 5 | **7** |
| 0 | `4x(3x+8)/(x³-x²-16x-16)` | 66/43 | **450/43** |
| −2 | `6/(x-1)` | 6/11 | **126/11** |
| −4 | 0 | 0 | **12** |

Thus

\[
\boxed{\operatorname{Spec}(L_{\rm eff})
=0^{(1)}\oplus7^{(4)}\oplus(450/43)^{(9)}
\oplus(126/11)^{(8)}\oplus12^{(2)}.}\tag{GC-07.2}
\]

The exact positive gap **7** and exact kernel `span{1}` are no longer extra conjectures *for this graph Dirichlet operator*. They follow from Paper I-B and a variational identity.

### Complete operator, not merely its spectrum

Write `I,N,Z,D,J_opp` for the five disjoint Hurwitz shell matrices at inner products `1,1/2,0,-1/2,-1` (note `J_opp` denotes the *antipodal* shell, not the all-ones matrix). Exact spectral interpolation yields

\[
\boxed{L_{\rm eff}
=\frac{56245}{5676}I
-\frac{115}{132}N
-\frac{53}{172}Z
-\frac{17}{132}D
-\frac{343}{5676}J_{\rm opp}.}\tag{GC-07.3}
\]

Every induced off-diagonal entry is negative, the diagonal is positive, and the weighted row sum is exactly zero. The induced **edge conductances** are consequently `115/132` (8 neighbours), `53/172` (6), `17/132` (8), `343/5676` (1). These are *effective local coefficients of the reduced unit-resistance graph*, not a particle partial-width fit.

The previous native standalone 24-cell vertex Laplacian is `L_24=8I-N`, with spectrum `0^(1), 4^(4), 8^(9), 10^(8), 12^(2)`. Since `L_eff` is a function of the same `N`, their exact difference has spectrum

\[
\boxed{\operatorname{Spec}(L_{\rm eff}-L_{24})
=0^{(3)}\oplus3^{(4)}\oplus(106/43)^{(9)}\oplus(16/11)^{(8)}.}\tag{GC-07.4}
\]

Therefore `L_eff \succeq L_24` on the 24-dimensional comparison space. Equality occurs on constants and the two protected `N=-4` Hurwitz character modes (as is consistent with Paper I-B's previously proved `B* E_-4=0`). This is an exact, nontrivial new **graph stiffness comparison**, not a claim that a physical action includes both vertex operators.

### Exact Green response and resistance preservation

Electrical Dirichlet reduction preserves every effective resistance among the retained vertices. The exact pseudoinverse gives the four separation classes

| `u · v` | `R_eff^600(u,v)` |
|---:|---:|
| +1/2 | `14293/75600` |
| 0 | `1903/9450` |
| −1/2 | `5231/25200` |
| −1 | `40/189` |

These values independently match the exact nine-shell 600-cell Green result GC-03 of v1.1. The standalone 24-cell resistance values from GC-02 are **different**: the eliminated 96-node exterior supplies additional pathways. No equality of the parent and standalone 24-cell kinetic operators is inferred.

### Conditions genuinely discharged and conditions *not* discharged

| Proposed condition | Verdict | Scope |
|---|---|---|
| Choose a uniform nearest-neighbour random walk to define an inner 24-cell response | **Removed** by fixed unit-incidence Dirichlet minimization | finite scalar graph only |
| Truncate 600-cell return to exactly two steps | **Removed** by full existing Paper I-B resolvent | finite scalar graph only |
| Assume convergence of the full exterior-return series at an unspecified energy shift | **Removed at Laplacian shift 12**; exact ratio `3/4` and sharp error `12(3/4)^(n+1)` | unit-edge parent energy |
| Assign individual internal boundary conductances | **Removed** by exact Schur kernel (GC-07.3) | unit-edge parent energy |
| Assume existence/positivity of the reduced geometric gap | **Removed**: kernel=constants and positive gap=7 | unit-edge parent energy |
| Identify the parent unit-edge Dirichlet form with the *occurring physical same-action Hessian* | **Still OPEN**; not a consequence of graph incidence alone | physics/action owner |
| Set absolute temporal rate, mass, Newton coupling, electric charge or physical decay amplitude | **Still OPEN**; a real action and clock/source matching are necessary | observable sector |

**Careful quantifiers:** A unit-edge graph has a canonical combinatorial Dirichlet form `d_0* d_0`. The choice of **physical action** using that form is not proved by geometric spectral equivalence, so we do *not* claim that foundational G0/GP1–GP3 selects a unique physical Hamiltonian. The novelty is an exact upstream **mathematical** consequence and a source-DAG dependency consolidation.

### Source/DAG integration proposal (not silently applied)

- Register one theorem-level descendant `p1b:thm:graph-kron-600-hurwitz` with direct imports from `p1b:thm:v3023-five-coset-adjacency`, `p1b:thm:v3027-600-hurwitz-mode-resolvent`, and standard positive graph Dirichlet minimization.
- Register GC-07.2 as the exact spectral corollary, GC-07.3 as the exact shell coefficient corollary, and GC-07.4 as the stiffness comparison.
- Add a **typed mathematical** S³ graph relation from `geo:600cell_nearest_vertex_graph` to its induced 24-cell DtN kernel. The previously existing native 24-cell nearest adjacency is **not equal** to this kernel.
- Preserve a **non-edge** from `L_eff` to any physical decay operator or physical electromagnetic Hessian pending the same-action constructor certificate.
- Correct GC-04 provenance in the v1.1 report: its two-step identity is source-proved already by `p1b:thm:v3027-600-hurwitz-returns`; the v1.1 exact checker was a useful independent reproduction, not a new source closure.

### Reproducibility and independent checks

Run `python Paper00-GraphClosureDiscovery-v1_2.py` from this folder. Dependencies: Python, NumPy, SymPy. This verifier:

1. Reconstructs 120 vertices, 720 edges, all five Hurwitz cosets from *unmodified v1.40 source data*.
2. Independently verifies all four existing Paper I-B return formulas **for each** of the five cosets by exact integer matrix arithmetic.
3. Constructs the rational 5-class Bose–Mesner shell multiplication algebra, spectral idempotents, all Dirichlet eigenvalues, exact shell coefficients, Green pseudoinverse, resistances, and nonnegative stiffness differences.
4. Replays the exact first-four sharp return-series tail norms; for every truncation length, the source's spectral bound also gives the exact closed formula `12(3/4)^(n+1)`.
5. Computes the 96-node complement direct Schur elimination independently in floating arithmetic for **each of the five cosets** and compares all 576 entries with the exact coefficients (maximum discrepancy `1.7764e-15`).
5. Writes `Paper00-GraphClosureDiscovery-v1_2.json` with the per-coset evidence and SHA-256 of its immutable input files.

**Previous result GC-01:** The vector inverse evaluation/solder factor-of-two remains mathematically identified, but III-A source-level interpretation and composition normalization still require an actual source patch. It is not silently marked closed here.

**Previous exploratory II-C six-versus-seven POVM boundary:** Tested, not solved. No new all-support impossibility or six-outcome certificate was found; the published `6 or 7` answer remains intact. A few symmetric finite supports were numerically diagnostic only and are not counted as a closure.
