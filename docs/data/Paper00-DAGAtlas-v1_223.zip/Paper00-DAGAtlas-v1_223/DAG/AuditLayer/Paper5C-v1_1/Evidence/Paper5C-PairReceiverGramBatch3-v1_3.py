#!/usr/bin/env python3
"""Independent 14-CAR mode full 3-E-family trace certificates for pair+centered-density norms."""
from scipy import sparse
import numpy as np, json
from pathlib import Path
f=14;d=2**f;ao=[]
for i in range(f):
 rows=[];cols=[];vals=[]
 for st in range(d):
  if st>>i&1:
   rows.append(st^(1<<i));cols.append(st);vals.append((-1)**((st&((1<<i)-1)).bit_count()))
 ao.append(sparse.csr_matrix((np.asarray(vals,dtype=complex),(rows,cols)),shape=(d,d)))
cr=[a.conj().T.tocsr() for a in ao]
M=np.array([(-1-1j)/2,(1+1j)/2])
gmu=np.array([-1-3j,-1+3j,2])/(2*np.sqrt(6)) # inv=e2, dir=e1, Gram=e0
Pmu=np.outer(gmu,gmu.conj())
p=sparse.csr_matrix((d,d),dtype=complex)
for fm in range(2):p+=M[fm]*cr[2*fm]@cr[2*fm+1]
Ts=sum((cr[6+s]@ao[2+s] for s in range(2)),sparse.csr_matrix((d,d),dtype=complex))
Tr=sum((cr[s]@ao[4+s] for s in range(2)),sparse.csr_matrix((d,d),dtype=complex))
jmu=sparse.csr_matrix((d,d),dtype=complex)
for s in range(2):
 for a in range(3):
  for b in range(3):jmu+=Pmu[a,b]*cr[8+2*a+s]@ao[8+2*b+s]
wp=sum((cr[8+2*fm+s]@ao[4+2*fm+s] for fm in range(2) for s in range(2)),sparse.csr_matrix((d,d),dtype=complex))
wm=wp.conj().T.tocsr();II=sparse.eye(2,dtype=complex,format='csr')
X=sparse.csr_matrix([[0,1],[0,0]],dtype=complex)
kron=lambda A,B:sparse.kron(A,B,format='csr')
C=kron(p,II)
for op in [kron(Ts,II),kron(wp,X.conj().T),kron(jmu,II),kron(wm,X),kron(Tr,II)]:
 C=op@C-C@op;C.eliminate_zeros()
# X lowering boson: D=I/2, K=diag(1,-1), so C_even=(Ppure/2+Y), C_odd=(Ppure/2-Y)
even=C[0::2,0::2];odd=C[1::2,1::2]
Ppure=even+odd;Y=(even-odd)*0.5
N1=(Ppure.conj().T@Ppure).diagonal().sum().real/d
N2=(Y.conj().T@Y).diagonal().sum().real/d
cross=(Ppure.conj().T@Y).diagonal().sum()/d
expect1=25/576; expect2=5/96
# compare explicit pure P_R(L_A Γ) with coefficient g_dir * (Pmu)_{inv,dir}
fac=M[1]*Pmu[0,1]
pr=fac*(cr[0]@cr[3]-cr[1]@cr[2])
err=float(sparse.linalg.norm(Ppure-pr))/max(1.,float(sparse.linalg.norm(pr)))
result={'full_fock_dims':d,'fermion_roles':'R inv+dir each 2 spin, L inv+dir each 2 spin, E inv+dir+Gram each 2 spin',
'pure_norm':N1,'pure_expected':expect1,'density_norm':N2,'density_expected':expect2,'pure_density_cross':repr(cross),'pure_full_operator_relative_error':err,
'passed':bool(np.allclose([N1,N2],[expect1,expect2],atol=1e-10) and abs(cross)<1e-12 and err<1e-11),
'claim_ids':['P5C-118','P5C-119'],'no_separate_agents':True}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
print(result)
