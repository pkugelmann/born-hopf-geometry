#!/usr/bin/env python3
"""Domain-matched E4 attempts; includes valid domain ambiguity and failed/out-of-domain attacks."""
from pathlib import Path
import sympy as s, json, mpmath as mp
mp.mp.dps=55
out=[]
def attack(name,claim,scope,negation,verdict,witness):
    out.append({'id':f'VCB2-E4-{len(out)+1:02d}','name':name,'claim_ids':claim,'scope_test':scope,'negation_tested':negation,'verdict':verdict,'certificate':witness})
# Full inclusive electroweak e+ e- cross section at s >> M_Z^2, as opposed to photon-only.
x=s.Rational(1,4);chi=1/(4*x*(1-x));ve=-s.Rational(1,2)+2*x;ae=-s.Rational(1,2)
def contrib(Q,t3):
    v=t3-2*Q*x;a=t3
    return s.simplify(Q**2+2*(-1)*Q*ve*v*chi+(ve**2+ae**2)*(v**2+a**2)*chi**2)
Cu=contrib(s.Rational(2,3),s.Rational(1,2));Cd=contrib(-s.Rational(1,3),-s.Rational(1,2));Cmu=contrib(-s.Integer(1),-s.Rational(1,2))
R=s.simplify(3*(3*Cu+3*Cd)/Cmu)
assert (Cu,Cd,Cmu,R)==(s.Rational(46,81),s.Rational(22,81),s.Rational(10,9),s.Rational(34,5))
attack('High-energy gamma+Z inclusive quark ratio',['P5C-069'], 's >> M_Z² and top threshold; all six flavors light relative to s; away from the Z pole and resonances; conventional electroweak currents', 'R total Born=5 if formula holds as written for full sigma','IN-DOMAIN COUNTEREXAMPLE TO FULL-SIGMA INTERPRETATION; BYPASS IF PHOTON-ONLY IS INTENDED',{'sin2thetaW':'1/4','chiZ_asymptotic':str(chi),'Cu':str(Cu),'Cd':str(Cd),'Cmu':str(Cmu),'full_R':str(R),'photon_only_R':5,'interpretation':'A missing photon-only/projected-current scope qualifier, not a disproof of the QCD photon channel.'})
# EM branch difference is expressly acknowledged; not a new issue.
d=1/mp.sqrt(72)
f=lambda a: mp.exp((4*mp.pi**2-a+a**2/mp.pi**2+(-a**4-a**6+a**8)/8)/8)
value=f(d)-f(d-d**8/16)
assert abs(value)>mp.mpf('1e-8')
attack('Electromagnetic branch nonuniqueness',['P5C-037','P5C-040'],'two source-admitted candidate coordinates','unconditional EM numerical uniqueness','NEGATION CONFIRMED AND ALREADY ACKNOWLEDGED BY THE PAPER, NOT A NEW ISSUE',{'difference_log_branch':mp.nstr(value,30)})
attack('Singular massive block at Thomson elimination',['P5C-047'],'C=0 in Kxx; violates source C>0','Schur inverse may not exist','INVALID / OUT OF DOMAIN',{'witness':'C=0 excluded; no counterexample to stated theorem'})
attack('Orientation reversing scalar coordinate',['P5C-052'],'fprime<0; violates orientation preserving branch','G^-1/2 d/dh flips sign','INVALID / OUT OF DOMAIN',{'witness':'signed unit tangent flips under orientation reversal; statement explicitly fprime>0'})
attack('Oscillator Z discontinuity',['P5C-062'],'Z has jump discontinuity; violates absolute continuity','total variation estimate via integral derivative fails','INVALID / OUT OF DOMAIN',{'witness':'jump is not AC, but smooth steep limit is allowed and saturates sup bound'})
attack('Potential convex criterion missing strictness',['P5C-085'],'V\'\'=0 everywhere, violates strict positive criterion','nonunique minimum possible','INVALID / OUT OF DOMAIN',{'witness':'V≡0 cannot meet V\'(0)<0 either'})
attack('Quark singular mass determinant',['P5C-075'],'det D_u=0 violates nonzero full rank','determinant phase undefined','INVALID / OUT OF DOMAIN',{'witness':'strong CP determinant statement scoped to nonzero full-rank branch'})
attack('Pair target without equivariance',['P5C-065'],'arbitrary linear nonintertwining map violates stated Spin4 condition','rank-six or spinor source could map to arbitrary target','INVALID / OUT OF DOMAIN',{'witness':'source explicitly requires action intertwiner, not just two matching representation labels'})
attack('Unowned absolute EM coefficient',['P5C-038','P5C-053','P5C-055'],'no physical Gamma/vacuum or IR limit','finite candidate forced to equal measured Thomson value','NO CLAIM: CLAIMS ARE CONDITIONALLY SCOPED',{'witness':'source expressly declines physical candidate identification until same-action equality and IR bound'})
attack('Photon-only Rgamma channel',['P5C-069'],'photonic neutral current only, no Z exchange','photon-only Born nf=6 differs from 5','REFUTATION FAILED UNDER PHOTON-ONLY INTERPRETATION',{'witness':'R=3[3(2/3)^2+3(-1/3)^2]=5'})
path=Path(__file__).with_suffix('.json');path.write_text(json.dumps({'checks':out,'classification_policy':'Valid counterexamples require exact source quantifier domain; negative tests preserved and non-promoting.'},indent=2,ensure_ascii=False)+'\n');print('E4 probes',len(out),'one Rgamma scope counterexample, all witness outcomes recorded')
