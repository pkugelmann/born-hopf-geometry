#!/usr/bin/env python3
"""Independent exact algebra checks of Paper V-C v2.171 lines 1-1623.
NO occurrence/physical-owner/perturbative-validity inference is made by these tests.
"""
import sympy as s
from fractions import Fraction
import json
from pathlib import Path
I,rt=s.I,s.sqrt
checks=[]
def check(name, condition, detail=''):
    ok=bool(condition);checks.append({'id':name,'passed':ok,'detail':str(detail)[:750]})
    print(('PASS' if ok else 'FAIL'),name, detail)

# Exact imported family ray and symmetric BL2 matrix, in source basis e0,e1,e2.
gmu=s.Matrix([2,-1+3*I,-1-3*I])/(2*rt(6))
P=s.simplify(gmu*gmu.conjugate().T)
M=s.diag((-1+I)/2,(1+I)/2,(-1-I)/2)
check('VCB1-01-RayUnit',s.simplify((gmu.conjugate().T*gmu)[0]-1)==0,'||g_mu||=1')
check('VCB1-02-Ray21',s.simplify(P[2,1]-(-s.Rational(1,3)+I/4))==0, P[2,1])
check('VCB1-03-MSource',s.simplify(s.conjugate(M[2,2])*M[1,1]+s.Rational(1,2))==0,s.conjugate(M[2,2])*M[1,1])
A=s.zeros(3);A[2,1]=P[2,1]
Z=s.simplify(s.trace(M.conjugate().T*A*M*A.T))
check('VCB1-04-SourceTrace',s.simplify(Z-(-s.Rational(7,288)+I/12))==0, Z)
# Nontrivial change of presentation: DFT-3. The transpose, not dagger, is essential.
omega=(-1+I*rt(3))/2
U=s.Matrix([[omega**(j*k) for k in range(3)] for j in range(3)])/rt(3)
Ap=s.simplify(U.conjugate().T*A*U)
Mp=s.simplify(U.conjugate().T*M*U.conjugate())
Zp=s.simplify(s.trace(Mp.conjugate().T*Ap*Mp*Ap.T))
check('VCB1-05-UnitaryCongruence',s.simplify(Zp-Z)==0,s.simplify(Zp-Z))
check('VCB1-06-FullFamilyAlgebra',all(s.simplify(P[i,j])!=0 for i in range(3) for j in range(3)),P)
# The 9x9 port-family matrix units E_pq tensor E_ij.
E=lambda i,j,n: s.eye(n)[:,i]*s.eye(n)[:,j].T
VR=E(0,0,3);VL=E(1,0,3);VE=E(2,0,3)
V=[VR,VL,VE]
check('VCB1-07-PortMatrixUnits',all(V[p]*VR*V[q].T==E(p,q,3) for p in range(3) for q in range(3)), 'all 9 port E_pq, hence 81 tensor units')
# Native hermitian algebra and tomography
check('VCB1-08-137-88-225',11**2+4**2==137 and 2*11*4==88 and 137+88==15**2 and 15**2-1==224,'block even, odd, and affine-state dimensions')
# Central shifts
c=s.symbols('c0:3',real=True); H=s.diag(*s.symbols('h0:3',real=True)); C=s.diag(*c)
q=E(0,1,3)
comm=lambda x,y: x*y-y*x
check('VCB1-09-CentralShift',comm(H+C,q)-comm(H,q)==(c[0]-c[1])*q, 'componentwise shift')
# Defect counts and common-heat
check('VCB1-10-DefectCounts', s.Rational(1,8)*s.Rational(1,9)==s.Rational(1,72) and s.Rational(1,8)*s.Rational(1,7)==s.Rational(1,56) and 72+56==128 and 72-56==16, 'normalized counts')
check('VCB1-11-CommonHeat',s.simplify((4*s.pi**2/s.Integer(2))/(4*s.pi)-s.pi/2)==0,'k3=2, alpha3=pi/2')
g12=2*s.pi**2;gy2=s.Rational(3,5)*g12
check('VCB1-12-HeatEW',s.simplify(gy2/(g12+gy2)-s.Rational(3,8))==0 and s.simplify(g12/(g12+gy2)-s.Rational(5,8))==0,'3/8,5/8')
# 7/9 own ratio, tree shell numbers
rhoV=s.pi/rt(10)
g2=rt(s.Rational(24,25))*rt(7)/(4*rhoV)
gY=g2*rt(s.Rational(2,7));g1=gY*rt(s.Rational(5,3))
alpha2inv=4*s.pi/g2**2;alpha1inv=4*s.pi/g1**2;alphaEMinv=alpha2inv+s.Rational(5,3)*alpha1inv
check('VCB1-13-TreeShellNumerics',all(abs(float(z)-t)<1e-7 for z,t in [(g2,.6523411464),(gY,.3486910099),(g1,.4501581581),(alpha2inv,29.52978731),(alpha1inv,62.01255336),(alphaEMinv,132.88404292)]),s.N(s.Matrix([g2,gY,g1,alpha2inv,alpha1inv,alphaEMinv]),12))
# Beta vector from independent Standard Model Weyl/complex scalar sums.
b3=-11+s.Rational(2,3)*3*2
b2=-s.Rational(22,3)+s.Rational(2,3)*3*2+s.Rational(1,3)*s.Rational(1,2)
Yweyl_per_gen=6*s.Rational(1,6)**2+3*s.Rational(2,3)**2+3*s.Rational(1,3)**2+2*s.Rational(1,2)**2+1
bY=s.Rational(2,3)*3*Yweyl_per_gen+s.Rational(1,3)*2*s.Rational(1,2)**2
b1=s.Rational(3,5)*bY
check('VCB1-14-SMOneLoopCoefficients',(b1,b2,b3)==(s.Rational(41,10),-s.Rational(19,6),-7), (b1,b2,b3))
L=s.symbols('L',real=True)
ratio=(4-b2*L)/(4-b1*L)
sol=s.solve(s.Eq(ratio,s.Rational(10,21)),L)
check('VCB1-15-Heat79Running',len(sol)==1 and sol[0]==-s.Rational(88,215),sol)
# Proca longitudinal mode: correct algebraic temporal elimination and oscillator frequency
lam,m,vel=s.symbols('lambda m vel',positive=True)
u=s.symbols('u',real=True)
Lag=s.Rational(1,2)*(lam*(vel-u)**2+m**2*u**2-m**2*lam*s.Symbol('phi')**2)
ustar=s.solve(s.diff(Lag,u),u)[0]
red=s.simplify(Lag.subs(u,ustar))
check('VCB1-16-ProcaEliminate',s.simplify(ustar-lam*vel/(lam+m**2))==0 and s.simplify(s.diff(red,vel,2)-lam*m**2/(lam+m**2))==0, (ustar,red))
check('VCB1-17-SphereSplitting',s.expand((s.Symbol('n')**2)-((s.Symbol('n')**2)-1))==1,'Etrans^2 - Elong^2 = Eper^2')
# Kernel subtlety: both raw and whitened kernels have dimension 1, but their coordinates differ.
# The source theorem p7v2:thm:v245-gauge-hessian-kernel-clock-lock writes an untransported equality.
J=s.Matrix([[1,-1]])
Qhalf=s.diag(1,2);Qinhalf=s.diag(1,s.Rational(1,2))
Mcanon=s.simplify(Qinhalf*J.T*J*Qinhalf)
raw=s.Matrix([1,1]);canon=Qhalf*raw
check('VCB1-18-WhiteningPositiveControl', J*raw==s.zeros(1,1) and Mcanon*canon==s.zeros(2,1) and Mcanon.rank()==1,'raw null (1,1), canonical null (1,2)')
check('VCB1-19-WhiteningCounterexample',Mcanon*raw!=s.zeros(2,1) and raw!=canon,'RAW kernel != CANONICAL kernel without Q^(1/2) transport')
if __name__=='__main__':
    out=Path(__file__).with_name('Paper5C-ExactChecksBatch1-v1_1.json')
    out.write_text(json.dumps({'source':'Paper5C-InteractionResponse-v2_171.tex','scope':'lines 1-1623','test_type':'independently coded exact algebra, NOT independent agents / physical occurrence','checks':checks,'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks)},indent=2,default=str)+'\n')
    print('SUMMARY',sum(x['passed'] for x in checks),'passed',sum(not x['passed'] for x in checks),'failed; saved',out)
    if not all(x['passed'] for x in checks):raise SystemExit(1)
