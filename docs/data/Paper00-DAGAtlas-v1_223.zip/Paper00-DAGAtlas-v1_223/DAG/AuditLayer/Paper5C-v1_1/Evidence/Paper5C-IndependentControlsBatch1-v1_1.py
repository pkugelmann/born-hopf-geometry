#!/usr/bin/env python3
"""Independent algebraic/adversarial controls for Paper V-C Batch 1.
Checks are separate recomputations by the same auditor; NOT independent people/agents.
No source files or original archives are modified.
"""
import json
import sympy as s
from pathlib import Path
results=[]
def check(tag, condition, note):
    passed=bool(condition)
    results.append({'id':tag,'passed':passed,'note':note})
    assert passed, tag
# (1) Explicit orthogonal splitting and arbitrary block amplitudes.
a,b=s.symbols('a b',real=True,positive=True)
P7=s.diag(*([1]*7+[0]*9));P9=s.eye(16)-P7
J=a*P7+b*P9
check('VCB1-C01-79GRAM',s.trace((J*P7).T*(J*P7))==7*a*a and s.trace((J*P9).T*(J*P9))==9*b*b,'7|9 Hessian ratio 7a²/9b²; rank does not force a=b')
# (2) Fully generic Weinberg neutral mass block: one massless eigenvector and mass ratio.
g,h,v=s.symbols('g h v',positive=True)
K=v*v*s.Matrix([[g*g,-g*h],[-g*h,h*h]])/4
check('VCB1-C02-NEUTRAL',s.simplify(K*s.Matrix([h,g]))==s.zeros(2,1) and s.simplify(s.trace(K)-(g*g+h*h)*v*v/4)==0,'massless photon (h,g), m_Z²=(g²+h²)v²/4')
check('VCB1-C03-HEAT_RATIO',s.simplify((g*g/(g*g+h*h)).subs({g*g:2*s.pi*s.pi,h*h:6*s.pi*s.pi/5})-s.Rational(5,8))==0,'common heat same scale m_W²/m_Z²=5/8')
# (3) Rank and kernel under arbitrary positive diagonal kinetic whitening.
q=s.symbols('q',positive=True)
J=s.Matrix([[1,-1]])
Qhalf=s.diag(1,s.sqrt(q))
Jphys=J*Qhalf.inv()
M=Jphys.T*Jphys
vraw=s.Matrix([1,1]); vcanonical=Qhalf*vraw
check('VCB1-C04-GRAM-RANK',M.rank()==1 and J.nullspace()[0]==vraw and s.simplify(M*vcanonical)==s.zeros(2,1),'rank survives whitening; physical null vector is Q^{1/2} raw null')
check('VCB1-C05-RAW-NOT-CANONICAL',s.simplify(M*vraw)!=s.zeros(2,1) if q!=1 else True,'literal equality ker M=ker J fails for arbitrary nonunit kinetic Q')
# (4) Principal symbol invariance under basis rotation and zero-order mass.
p0,p1,p2,p3=s.symbols('p0 p1 p2 p3',real=True)
qform=-p0*p0+p1*p1+p2*p2+p3*p3
rot=s.Matrix([[2,1],[-1,1]])
P=qform*s.eye(2)
check('VCB1-C06-PRINCIPAL',s.simplify(rot.inv()*P*rot-P)==s.zeros(2) and rot.det()!=0,'invertible internal rotation leaves common spacetime principal cone unchanged')
# (5) Ward-null at stationary point in a gauge-invariant radial potential.
x,y,v=s.symbols('x y v',real=True,positive=True)
V=(x*x+y*y-v*v)**2
H=s.hessian(V,(x,y)).subs({x:v,y:0})
Xh=s.Matrix([0,v])
check('VCB1-C07-WARD-STATIONARITY',s.simplify(H*Xh)==s.zeros(2,1),'stationary radial potential: Hessian kills orbit tangent')
# (6) Finite mode clock locking only for massless after sufficiently large index.
n,mu2=s.symbols('n mu2',positive=True)
# For n>mu²/2 one has n²+mu²<(n+1)², while n²+mu²>n².
check('VCB1-C08-CLOCK-LOCK',s.simplify((n+1)**2-(n*n+mu2))==2*n+1-mu2,'for positive mu², all sufficiently large n lie strictly between consecutive squares')
# (7) Longitudinal Proca mode gives positive kinetic and omega²=lambda+m².
lam,m=s.symbols('lam m',positive=True)
kin=lam*m*m/(lam+m*m)
pot=m*m*lam
check('VCB1-C09-PROCA',s.simplify(pot/kin-(lam+m*m))==0 and kin.is_positive,'stationary longitudinal mode has ω²=λ+m² and positive kinetic')
# (8) Degree transfer count and absolute scale nonselection test.
check('VCB1-C10-DEGREES',4*2+4==2+3*3+1,'EW: 8+4=2+9+1 physical d.o.f.')
c,R=s.symbols('c R',positive=True)
check('VCB1-C11-DIMENSIONAL',s.simplify((c*R)/(c*R)-1)==0,'uniform dimensionful rescaling invisible to dimensionless ratios')
out=Path(__file__).with_suffix('.json')
out.write_text(json.dumps({'paper':'Paper5C','batch':1,'source_scope':'lines 1-1623','auditor_model':'single model, independently programmed checks; no delegated reviewers','checks':results,'passed':sum(t['passed'] for t in results),'failed':sum(not t['passed'] for t in results)},indent=2)+'\n')
print('independent controls:',len(results),'passed:',sum(t['passed'] for t in results))
