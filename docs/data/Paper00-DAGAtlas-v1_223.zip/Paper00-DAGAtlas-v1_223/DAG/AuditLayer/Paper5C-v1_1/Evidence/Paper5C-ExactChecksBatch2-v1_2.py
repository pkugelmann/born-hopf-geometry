#!/usr/bin/env python3
"""Paper5C batch2: exact calculations of already-claimed equalities.
This is NOT a physical-ownership proof, independent human review, or source edit.
"""
from pathlib import Path
import sympy as s, mpmath as mp, json, hashlib, math
mp.mp.dps=60
out=[]
def check(name, proposition, passed, evidence, claim_ids):
    rec={'id':'VCB2-X%02d'% (len(out)+1),'name':name,'proposition':proposition,'passed':bool(passed),'method':'exact symbolic / independent numerical evaluator as indicated','evidence':str(evidence),'claim_ids':claim_ids}
    out.append(rec)
    if not passed: raise AssertionError(rec)

u=s.symbols('u',real=True,positive=True)
I=s.eye(8);P=s.zeros(8);P[3,3]=1
check('rank-one ordinary determinant','det(I+uP)=1+u',s.simplify((I+u*P).det()-(1+u))==0,'8x8 diagonal rank-one projector', ['P5C-033'])
check('normalized octet determinant','det_tau8(I+uP)=(1+u)^(1/8)',s.trace(s.log(1+u)*P)==s.log(1+u),'tau=Tr/8; spectral logarithm on positive branch', ['P5C-033'])
a=s.symbols('a')
f=1-a**4-a**6+s.Rational(3,2)*a**8
log_f=s.series(s.log(f),a,0,10).removeO()
check('finite connected log coefficient','log(1-a4-a6+3a8/2)=-a4-a6+a8+O(a10)',s.expand(log_f+a**4+a**6-a**8)==0,log_f, ['P5C-035','P5C-036'])
d=1/mp.sqrt(72); ah=d-d**8/16
A=lambda x,comp: mp.exp((4*mp.pi**2-x+x*x/mp.pi**2+(mp.log(1-x**4-x**6+mp.mpf('1.5')*x**8) if comp else (-x**4-x**6+x**8))/8)/8)
for name,x,target,comp in [('delta-log',d,'137.035999137806',False),('half-octic-log',ah,'137.035999176726',False),('half-octic-compact',ah,'137.035999175630',True)]:
    actual=A(x,comp)
    check('EM number '+name,'quoted 12-decimal EM inverse coupling',abs(actual-mp.mpf(target))<mp.mpf('5e-13'),mp.nstr(actual,45),['P5C-040'])
check('delta power 10','delta^10=5.16817865e-10',abs(d**10-mp.mpf('5.16817865e-10'))<mp.mpf('1e-18'),mp.nstr(d**10,30),['P5C-040'])
check('outer-log sensitivity','Delta A ~ A*delta^10/8 times C',abs(A(ah,True)*d**10/8-mp.mpf('8.85e-9'))<mp.mpf('4e-12'),mp.nstr(A(ah,True)*d**10/8,30),['P5C-040'])
b1=s.Rational(41,10);b2=-s.Rational(19,6)
check('EM one-loop b from SU2 U1','b2+5b1/3=11/3',b2+s.Rational(5,3)*b1==s.Rational(11,3),b2+s.Rational(5,3)*b1,['P5C-044'])
check('EM one-loop charged pieces','32/3+1/3-22/3=11/3',s.Rational(32,3)+s.Rational(1,3)-s.Rational(22,3)==s.Rational(11,3),'full charged-field count in stated common scheme',['P5C-044'])
L=s.symbols('L',real=True)
alpha1=2/s.pi-s.Rational(41,20)/s.pi*L;alpha2=2/s.pi+s.Rational(19,12)/s.pi*L
check('heat corridor L>=0','alpha1inv<=2/pi for L>=0',s.simplify((alpha1-2/s.pi).subs(L,2))<0,'alpha1inv decreases with positive L',['P5C-045'])
check('heat corridor L<=0','alpha2inv<=2/pi for L<=0',s.simplify((alpha2-2/s.pi).subs(L,-2))<0,'alpha2inv decreases with negative L',['P5C-045'])
t,c,a0,b0,dd=s.symbols('t c a0 b0 dd',real=True,positive=True)
K=s.Matrix([[t*a0,t*b0],[t*b0,c+t*dd]])
schur=t*a0-(t*b0)**2/(c+t*dd)
check('Schur kernel factorization','Keff=t(a-t b²/(c+t d))',s.simplify(schur-t*(a0-t*b0*b0/(c+t*dd)))==0,schur,['P5C-047'])
check('IR Schur coefficient','lim Keff/t=a(0)',s.limit(schur/t,t,0)==a0,'positive c keeps inverse bounded',['P5C-047'])
kappa=s.symbols('kappa',positive=True)
check('uniform source derivative','|d(k^-1/2)/dk|=1/(2k^3/2)',s.diff(kappa**(-s.Rational(1,2)),kappa)==-s.Rational(1,2)*kappa**(-s.Rational(3,2)),'mean value theorem',['P5C-048'])
p,ang=s.symbols('p ang',real=True)
expr=s.expand_trig((1-p+p*s.exp(-s.I*ang))*(1-p+p*s.exp(s.I*ang)))
check('pure two-phase survival','P=1-4p(1-p) sin²(Delta/2)',s.simplify(s.expand_complex(expr)-(1-4*p*(1-p)*s.sin(ang/2)**2))==0,'direct amplitude modulus',['P5C-050'])
for pv,value in [(s.Rational(1,4),s.Rational(3,4)),(s.Rational(1,2),s.Integer(1))]:
    check('disappearance p='+str(pv),'4p(1-p)='+str(value),4*pv*(1-pv)==value,str(value),['P5C-051'])
q=(1-mp.sqrt(1-mp.mpf('0.0851')))/2
amp=mp.sqrt(mp.mpf('.25')*q)+mp.sqrt(mp.mpf('.75')*(1-q))
check('reactor q','q=.021747974390..',abs(q-mp.mpf('0.021747974390'))<mp.mpf('2e-12'),mp.nstr(q,30),['P5C-051'])
check('reactor minimal state angle','angle=.37559',abs(mp.acos(amp)-mp.mpf('.37559'))<mp.mpf('5e-6'),mp.nstr(mp.acos(amp),25),['P5C-051'])
check('reactor minimal trace distance','distance=.36682',abs(mp.sqrt(1-amp**2)-mp.mpf('.36682'))<mp.mpf('5e-6'),mp.nstr(mp.sqrt(1-amp**2),25),['P5C-051'])
fprime,G=s.symbols('fprime G',positive=True)
check('scalar coordinate chain rule','(G/fprime²)^-1/2 * (d/dh)/fprime=G^-1/2 d/dh',s.simplify((G/fprime**2)**(-s.Rational(1,2))/fprime-G**(-s.Rational(1,2)))==0,'orientation preserving fprime>0',['P5C-052'])
check('heat electromagnetic inverse alpha','2/pi+5(2/pi)/3=16/(3pi)',s.simplify(2/s.pi+s.Rational(5,3)*2/s.pi-s.Rational(16,3)/s.pi)==0,'GUT normalized coupling',['P5C-054'])
check('heat source coefficient','Zheat=alphaQinv/(4pi)=4/(3pi²)',s.simplify((s.Rational(16,3)/s.pi)/(4*s.pi)-s.Rational(4,3)/s.pi**2)==0,'source-native Hessian convention',['P5C-054','P5C-055'])
check('G17 endpoint sum identity','4pi*(Zheat+DeltaZ)=16/(3pi)+4pi DeltaZ',s.simplify(4*s.pi*(s.Rational(4,3)/s.pi**2+u)-(s.Rational(16,3)/s.pi+4*s.pi*u))==0,'definition of Delta Z',['P5C-055'])
C=s.Matrix([[1,2+3*s.I],[0,1]])
D=s.Matrix([[s.Rational(1,3),1-s.I],[-1,s.I]])
inner=lambda X,Y: s.trace(X.conjugate().T*Y)
g=s.simplify(inner(C,D)/inner(C,C)); Err=D-g*C
check('Hilbert-Schmidt one-line residual','||D-gC||²=||D||²-|<C,D>|²/||C||²',s.simplify(inner(Err,Err)-(inner(D,D)-inner(C,D).conjugate()*inner(C,D)/inner(C,C)))==0,{'normC':str(inner(C,C)),'g':str(g)},['P5C-059'])
alpha=mp.exp(4*mp.pi**2+1/(6*mp.sqrt(2)))
check('geometric Weyl/breathing ratio','sqrt(6/alpha)=6.17810e-9',abs(mp.sqrt(6/alpha)-mp.mpf('6.17810e-9'))<mp.mpf('5e-14'),mp.nstr(mp.sqrt(6/alpha),25),['P5C-061'])
check('native scalar gauge heat weights','b_i*2pi²/(8pi²)=(41/40,-19/24,-7/4)',tuple([b1/4,b2/4,-s.Integer(7)/4])==(s.Rational(41,40),-s.Rational(19,24),-s.Rational(7,4)),[str(v) for v in [b1/4,b2/4,-s.Integer(7)/4]],['P5C-060'])
Z1,Z2=s.symbols('Z1 Z2',positive=True)
r=s.log(Z2/Z1)/2
check('sudden positive-Z squeeze','N_quench=sinh²(ln(Zf/Zi)/2)',s.simplify(s.cosh(r)**2-s.sinh(r)**2-1)==0,'canonical beta amplitude = |sqrt(Zf/Zi)-sqrt(Zi/Zf)|/2',['P5C-062'])
nn,ZZ,aa=s.symbols('n Z a',positive=True)
c_osc=s.sqrt(nn*ZZ/s.Integer(2)); d_osc=1/s.sqrt(2*nn*ZZ)
qcoef=s.simplify(d_osc*ZZ*nn**2/aa-nn/aa*c_osc)
pcoef=s.simplify(c_osc/(aa*ZZ)-nn/aa*d_osc)
check('quadratic oscillator canonical b flow','bdot=-i omega b +(k/2) bdag',qcoef==0 and pcoef==0,{'qcoef':str(qcoef),'pcoef':str(pcoef)},['P5C-062','P5C-063'])
check('quadratic oscillator scalar force','hbar omega L Re M = L(Zn²<Q²>-<P²>/Z)/(2a)',s.simplify(nn/aa*c_osc**2-nn**2*ZZ/(2*aa))==0 and s.simplify(nn/aa*d_osc**2-1/(2*aa*ZZ))==0,'coefficient comparison for Q² and P²',['P5C-063'])
cf=(3**2-1)/s.Integer(2*3)
check('SU3 Casimir fundamentals','CF=4/3 CA=3 TR=1/2',cf==s.Rational(4,3),cf,['P5C-066'])
cas=[(s.Rational(0),s.Rational(4,3),s.Rational(4,3)),(s.Integer(3),s.Rational(4,3),s.Rational(4,3)),(s.Rational(4,3),s.Rational(4,3),s.Rational(4,3)),(s.Rational(10,3),s.Rational(4,3),s.Rational(4,3))]
results=[(a-b-c)/2 for a,b,c in cas]
check('q qbar & qq color channels','[-4/3,1/6,-2/3,1/3]',results==[-s.Rational(4,3),s.Rational(1,6),-s.Rational(2,3),s.Rational(1,3)],[str(x) for x in results],['P5C-067'])
flavors=[(1,2),(2,2),(2,3),(3,3)]
check('inclusive photon Born charge sums','2,10/3,11/3,5',[(3*(nup*s.Rational(4,9)+ndown*s.Rational(1,9))) for nup,ndown in flavors]==[2,s.Rational(10,3),s.Rational(11,3),5],str(flavors),['P5C-069'])
nf=s.symbols('n_f',integer=True,nonnegative=True)
check('QCD one-loop beta0','11-2 nf/3',s.simplify((s.Rational(11,3)*3-s.Rational(4,3)*s.Rational(1,2)*nf)-(11-s.Rational(2,3)*nf))==0,'color Casimir substitution',['P5C-068'])
Pu=s.Matrix([[2,1],[1,3]])
U=s.Matrix([[1,s.I],[s.I,1]])
Dplus=Pu*U*Pu; Dminus=Pu*U.conjugate()*Pu
check('quark determinants conjugate','det Dplus Dminus>0',s.simplify(s.im((Dplus*Dminus).det()))==0 and float(s.re((Dplus*Dminus).det()))>0,(Dplus*Dminus).det(),['P5C-075'])
r=s.symbols('r',positive=True); lam,v=s.symbols('lam v',positive=True);mu2=-lam*v**2
V=mu2*r+lam*r*r
check('single-doublet Higgs stationary orbit','V\'(v²/2)=0',s.simplify(s.diff(V,r).subs(r,v*v/2))==0,'V = μ²r+λr²',['P5C-083'])
h=s.symbols('h',real=True)
check('single-doublet Higgs radial Hessian','V_hh(0)=2λv²',s.simplify(s.diff(V.subs(r,(v+h)**2/2),h,2).subs(h,0)-2*lam*v*v)==0,'canonical doublet radial chart',['P5C-083'])
MM,CC,lg,al,c4,x=s.symbols('M C Lambda alpha c4 x',real=True,positive=True)
W=(MM**2*CC/2-6*MM**2*lg**2*x+9*c4*MM**4*x*x/al)/(1-x)**2
AA=MM**2*CC-6*MM**2*lg**2
BB=18*c4*MM**4/al-6*MM**2*lg**2
check('bare terminal radial first derivative','W0\'=(A+Bx)/(1-x)^3',s.simplify(s.diff(W,x)-(AA+BB*x)/(1-x)**3)==0,'exact rational differentiation',['P5C-086'])
check('bare terminal radial second derivative','W0\'\'=(3A+B+2Bx)/(1-x)^4',s.simplify(s.diff(W,x,2)-(3*AA+BB+2*BB*x)/(1-x)**4)==0,'exact rational differentiation',['P5C-086'])
U0=s.Integer(4)*MM**2; alpha_phi=1/(16*s.pi**2); Lambda_g2=96*s.pi**2*U0
A0=s.simplify(AA.subs({lg**2:Lambda_g2,al:alpha_phi}));B0=s.simplify(BB.subs({lg**2:Lambda_g2,al:alpha_phi}))
check('bare terminal A native','A=M²C-2304 pi² M4',s.simplify(A0-(MM**2*CC-2304*s.pi**2*MM**4))==0,A0,['P5C-086'])
check('bare terminal B native','B=288 pi² M4 (c4-8)',s.simplify(B0-288*s.pi**2*MM**4*(c4-8))==0,B0,['P5C-086'])
check('auxiliary-shell reported difference','221.0882021 - 221.5844320 = -0.4962299',s.Rational('221.0882021')-s.Rational('221.5844320')==s.Rational('-0.4962299'),'does not reproduce either root or hard-shift without old inputs',['P5C-091'])
hh=s.symbols('hh',real=True)
K1=1+2*hh;K2=1+8*hh
check('mass does not determine 3pt vertex','two scalar response families same pole at h=0 but different derivatives',K1.subs(hh,0)==K2.subs(hh,0) and s.diff(K1,hh)!=s.diff(K2,hh),'K1(0)=K2(0)=1, K1\'=2, K2\'=8',['P5C-093'])
path=Path(__file__).with_suffix('.json')
path.write_text(json.dumps({'evidence_level':'E3 exact controls where not requiring imported physical occurrence','all_passed':all(q['passed'] for q in out),'checks':out},indent=2,ensure_ascii=False,default=str)+'\n')
print('exact controls',len(out),'PASS',path)
