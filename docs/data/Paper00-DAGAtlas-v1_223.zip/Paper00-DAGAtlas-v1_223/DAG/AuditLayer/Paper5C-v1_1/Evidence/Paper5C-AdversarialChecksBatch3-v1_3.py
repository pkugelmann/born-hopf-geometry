#!/usr/bin/env python3
"""Independent controls, adversarial scope tests for Batch3. Strict claims, no framework extension."""
from pathlib import Path
import numpy as np, json
from scipy.linalg import expm
checks=[]
def check(id,description,passed,result,claim_ids,scope):
 checks.append({'id':id,'description':description,'passed':bool(passed),'result':result,'claim_ids':claim_ids,'scope':scope})
 if not passed:print('FAIL',id,description,result)
rng=np.random.default_rng(3434)
# exact current symmetry of complete charged memory, arbitrary complex nonhermitian K
ge=np.array([(-1-1j)/2,1j/2,.5]); gm=np.array([2,-1+3j,-1-3j])/(2*np.sqrt(6));gt=np.ones(3)/np.sqrt(3)
U=np.column_stack((ge,gm,gt));C=U.conj().T@np.eye(3)[:,[2,1,0]]
K=rng.normal(size=(3,3))+1j*rng.normal(size=(3,3));Sigma=np.pi**2*C@K@C.conj().T;v=C.conj().T@np.array([1,0,0]);leak=abs(Sigma[1,0])**2+abs(Sigma[2,0])**2
variance=np.pi**4*(np.linalg.norm(K@v)**2-abs(v.conj()@K@v)**2)
check('VCB3-E4-01','Electron-line variance holds for nonnormal complex K',np.allclose(leak,variance),{'leakage':float(leak),'variance':float(variance)},['P5C-107'],'Within declared generic 3x3 return domain; do not insert a diagonal-memory assumption')
# exact Krylov failure example when only first 0-th moment zero but higher nonzero
D=np.array([[0,1,0],[1,0,0],[0,0,3]],complex);F=np.eye(3,dtype=complex)
K0=F.conj().T@F
moment=F.conj().T@D@F
ret=F.conj().T@np.linalg.inv((2+1j)*np.eye(3)-D)@F
check('VCB3-E4-02','Zeroth Gram isotropy is insufficient for diagonal memory',np.allclose(K0,np.eye(3)) and abs(moment[0,1])>0 and abs(ret[0,1])>0,{'moment12':float(np.real(moment[0,1])),'return12':str(ret[0,1])},['P5C-106','P5C-111'],'Negative control against illicit first-moment to full-resolvent inference')
# right commutant: family-blind not necessary
J=np.array([[0,1,0],[-1,0,0],[0,0,0]],complex);P=np.diag([1,1,0]);Q=np.eye(3)-P
Kright=1.2*P+0.5j*J+2.3*Q
check('VCB3-E4-03','Nontrivial Hermitian right block commuting with orbit',np.linalg.norm(Kright@J-J@Kright)<1e-12 and np.linalg.norm(Kright-np.eye(3)*np.trace(Kright)/3)>1e-6,{'eigs':np.linalg.eigvalsh(Kright).tolist()},['P5C-101','P5C-102'],'Countercheck to stronger false condition: right family-blindness necessary')
# F has deficient rank and K_W positive semidefinite only
Ccomp=np.diag([-1.,1.,3.]); F0=np.array([[1,0,0],[0,0,0],[0,0,0]],complex); z=1j
Kweak=F0.conj().T@np.linalg.inv(z*np.eye(3)-Ccomp)@F0
minEig=np.linalg.eigvalsh(-(Kweak-Kweak.conj().T)/(2j))
check('VCB3-E4-04','Rank-deficient receiver cannot gain strict positivity from a unitary current',np.all(minEig>=-1e-12) and np.count_nonzero(minEig>1e-9)==1,{'imag_eigenvalues':minEig.tolist()},['P5C-105'],'Countercheck to omitted full-column-rank premise')
# singular R annihilates nonzero antisymmetric pair
R=np.diag([1.,0.,0.,0.]);B=np.zeros((4,4),complex);B[2,3]=1;B[3,2]=-1
contract=np.trace(B.conj().T@R@B@R.T)
check('VCB3-E4-05','Nonzero external pair and return separately do not imply joint support',np.linalg.norm(R)>0 and np.linalg.norm(B)>0 and abs(contract)<1e-12,{'joint_return':str(contract)},['P5C-117'],'Negative control for unsupported positive-return inference')
# full nontracial charge jet with coherent vs incoherent state; two fermion modes
N=2;dd=2**N;an=[]
for i in range(N):
 op=np.zeros((dd,dd),complex)
 for st in range(dd):
  if st>>i&1:op[st^(1<<i),st]=(-1)**((st&((1<<i)-1)).bit_count())
 an.append(op)
cr=[x.conj().T for x in an];g=(-1+1j)/2;Pair=g*cr[0]@cr[1];H=Pair+Pair.conj().T;Q=-sum(cr[i]@an[i] for i in range(N))
rho=np.diag([1.,0,0,0]);D2=-np.trace(rho@(H@(H@Q-Q@H)-(H@Q-Q@H)@H)).real
want=4*np.trace(rho@(Pair@Pair.conj().T-Pair.conj().T@Pair)).real
check('VCB3-E4-06','Charge-jet sign, zero first derivative and exact nontracial double commutator',abs(D2-want)<1e-12 and want<0 and abs(np.trace(rho@(H@Q-Q@H)))<1e-12,{'jet':D2,'source_value':want},['P5C-128','P5C-129'],'In-domain empty pair support, not a statement that physical K16 state is empty')
# prepair Gibbs transfer sign from spectral theorem test negative and switched sign
E=np.diag([0.,2.,4.]);PP=np.zeros((3,3),complex);PP[2,0]=2.
rgibbs=np.exp(-np.diag(E));rgibbs/=sum(rgibbs);rho=np.diag(rgibbs)
jet=4*np.trace(rho@(PP@PP.conj().T-PP.conj().T@PP)).real
check('VCB3-E4-07','Prepair Gibbs energy-raising insertion produces negative initial second derivative',jet<0,{'jet':jet,'p_low':rgibbs[0],'p_high':rgibbs[2]},['P5C-131'],'Includes complete selected offdiag P and spectral state; no K16 physical preparation assumed')
# direct particle-hole all-time example of actual 4-mode primitive
f=4;dim=2**f;aa=[]
for i in range(f):
 op=np.zeros((dim,dim),complex)
 for st in range(dim):
  if st>>i&1:op[st^(1<<i),st]=(-1)**((st&((1<<i)-1)).bit_count())
 aa.append(op)
cc=[x.conj().T for x in aa];number=sum(c@a for c,a in zip(cc,aa));
# index R0 R1 L0 L1; m hopping real
hop=sum(cc[2+s]@aa[s]+cc[s]@aa[2+s] for s in range(2))
for j,g in enumerate([(-1+1j)/2,(1+1j)/2,(-1-1j)/2]):
 Pc=g*cc[0]@cc[1];Hc=1.4*hop; val,vec=np.linalg.eigh(Hc); beta=0.7;rho=vec@np.diag(np.exp(-beta*val)/np.sum(np.exp(-beta*val)))@vec.conj().T
 rho0=rho.copy();Uall=np.eye(dim,dtype=complex)
 for t in [0.2,0.5,1.1,1.4]:
  Ht=(1+0.2*np.sin(t))*hop+(0.6+0.1*np.cos(t))*(Pc+Pc.conj().T)
  Uall=expm(-1j*Ht*0.17)@Uall
 state=Uall@rho0@Uall.conj().T
 expectation=np.trace(state@number).real
 check(f'VCB3-E4-0{8+j}','All-time PH N=2 test family '+str(j),abs(expectation-2)<2e-12,{'g':repr(g),'occupation':expectation},['P5C-133'],'In-domain actual primitive with real hopping/pair strength and Hc-Gibbs input')
# chiral cancellation random complex normal mixing, time profile real and asymmetric
from scipy.linalg import expm
T=np.array([[1.3+0.3j,-.5+.8j],[.4-.7j,1.9-.2j]])
h=np.block([[np.zeros((2,2)),T],[T.conj().T,np.zeros((2,2))]])
q,v=np.linalg.eigh(h);J=np.diag([1,1,-1,-1]);Gam=np.zeros((4,4),complex);Gam[2,3]=.5+1.4j;Gam[3,2]=-Gam[2,3]
ts=np.linspace(-.9,1.5,2501);dt=ts[1]-ts[0];eta=1.0+0.4*ts+0.1*np.cos(2*ts)
Bn=np.zeros((4,4),complex)
for time,wt in zip(ts,eta):
 ev=v@np.diag(np.exp(1j*q*time))@v.conj().T
 Bn+=ev@Gam@ev.T*wt*dt
for k,beta in enumerate([0,0.7]):
 if beta==0:C=v@np.diag((q<0).astype(float))@v.conj().T
 else:C=v@np.diag(1/(1+np.exp(beta*q)))@v.conj().T
 cp=np.trace((2*C-np.eye(4))@Bn@Bn.conj().T)
 check(f'VCB3-E4-1{k+1}','Static chiral chronological cancellation with real asymmetric time profile '+('ground' if beta==0 else 'Gibbs'),abs(cp)<1e-8,{'charge_second':repr(complex(cp))},['P5C-132'],'In-domain, physical mixed frequency and complex T retained; no even-in-time eta imposed')
# η(t) complex varying can break cancellation; negative guard
eta_complex=eta*np.exp(1j*1.3*ts);Bnc=np.zeros((4,4),complex)
for time,wt in zip(ts,eta_complex):
 ev=v@np.diag(np.exp(1j*q*time))@v.conj().T
 Bnc+=ev@Gam@ev.T*wt*dt
C=v@np.diag((q<0).astype(float))@v.conj().T
cp_complex=np.trace((2*C-np.eye(4))@Bnc@Bnc.conj().T)
check('VCB3-E4-13','Time-varying complex phase can violate the real-eta cancellation',abs(cp_complex)>1e-3,{'charge_second':repr(complex(cp_complex))},['P5C-132'],'Outside theorem: η is not real; it is a guard mutation, not an in-domain refutation')
# verify appendix negative R instance shows lack generic positivity
D=4;aa0=np.zeros((D,D),complex);b=aa0.copy();c=aa0.copy();d=aa0.copy();aa0[0,2]=1;b[0,3]=1;c[1,2]=1;d[1,3]=1
n2=lambda x:np.trace(x.conj().T@x).real/D; cm=lambda x,y:x@y-y@x; tau=lambda x:np.trace(x)/D
R=(n2(cm(aa0,b))+n2(cm(c,d))+n2(aa0@d-b@c)+n2(d@aa0-c@b)+n2(aa0.conj().T@d)+n2(aa0@d.conj().T)+n2(b@c.conj().T)+n2(b.conj().T@c)-2*np.real(tau(b.conj().T@d@c.conj().T@aa0+b.conj().T@aa0@c.conj().T@d)))/8
check('VCB3-E4-14','Negative R on charge-graded boson space does not violate scoped nonpositivity theorem',np.isclose(R,-1/16),{'R':R},['P5C-121'],'Adversarial negative control; source explicitly does not assert global positivity')
result={'batch':3,'source':'Paper5C-InteractionResponse-v2_171.tex','checks':checks,'passed':sum(x['passed'] for x in checks),'total':len(checks),'no_independent_agents':True}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2,default=str))
print('adversarial checks',result['passed'],'/',result['total'])
