"""Paper V-C batch 4: exact replays and independent matrix/countermodel controls.
Only tests existing stated formulae; no new Born-Hopf physical assumptions or claims.
"""
import sympy as s, numpy as np, json
from pathlib import Path
out=[]
def ck(name, pass_, detail, claims, kind='E3'):
    out.append(dict(id=f'VCB4-{kind}-{len(out)+1:02d}',name=name,passed=bool(pass_),detail=str(detail)[:1200],claims=claims,evidence_level=kind))
    if not pass_:
        print('FAIL',name,detail)
I=s.I
x=s.real_root(192,3)
r=s.factor(x**4/(x*x+1))
ck('N56 squared-gap cross-multiplication',s.simplify((x**4-x**2)/(x**2-x**-2)-r)==0,s.N(r,18),['P5C-140'])
ck('N56 printed decimal matches',abs(float(r)-32.310511556)<1e-9,str(s.N(r,18)),['P5C-140'])
ck('N56 rationalized gap expression and irrationality witness',s.simplify(r-(s.Integer(36863)/(192*x-1)-1))==0 and s.Poly(s.minpoly(x)).degree()==3,str(s.minpoly(x)),['P5C-140'],kind='E4')
# typed current formula from frozen native C
t=s.sqrt(6)
C=s.Matrix([[s.Rational(1,2),-I/2,(-1+I)/2],[(-1+3*I)/(2*t),(-1-3*I)/(2*t),1/t],[1/s.sqrt(3),1/s.sqrt(3),1/s.sqrt(3)]])
P=C.multiply_elementwise(C.conjugate())
Pexpect=s.Matrix([[s.Rational(1,4),s.Rational(1,4),s.Rational(1,2)],[s.Rational(5,12),s.Rational(5,12),s.Rational(1,6)],[s.Rational(1,3)]*3])
ck('Native current is unitary and |C|² matches claimed role table',s.simplify(C*C.conjugate().T-s.eye(3))==s.zeros(3) and s.simplify(P-Pexpect)==s.zeros(3),P,['P5C-137','P5C-139','P5C-192','P5C-193'])
J=s.simplify(s.im(C[0,0]*C[1,1]*s.conjugate(C[0,1]*C[1,0])))
ck('Exact quartet equals -1/12 and absolute 1/12',J==-s.Rational(1,12),J,['P5C-144','P5C-177'])
# D07 probability exact independent phase oracle, same hypotheses
rng=np.random.default_rng(20261112)
CN=np.array(C,dtype=complex)
def sin2(x):return np.sin(x/2)**2
def predicted(ph):
    d12=ph[0]-ph[1];d13=ph[0]-ph[2];d23=ph[1]-ph[2]
    a,b,c=sin2(d12),sin2(d13),sin2(d23)
    A=(np.sin(d12)-np.sin(d13)+np.sin(d23))/6
    return np.array([[1-a/4-(b+c)/2,a/4+(b+c)/6+A,(b+c)/3-A],
        [a/4+(b+c)/6-A,1-25*a/36-5*(b+c)/18,4*a/9+(b+c)/9+A],
        [(b+c)/3+A,4*a/9+(b+c)/9-A,1-4*(a+b+c)/9]])
errs=[]
for i in range(30):
    ph=rng.normal(size=3)*5
    amp=CN@np.diag(np.exp(-1j*ph))@CN.conj().T
    actual=abs(amp.T)**2 # source D07 rows initial, columns final: actual P[initial, final]
    errs.append(np.max(abs(actual-predicted(ph))))
ck('All nine D07 vacuum oscillation probability coefficients',max(errs)<1e-12,max(errs),['D07'],kind='E3')
ph=np.array([1.2,-2.4,0.75]); d12=ph[0]-ph[1]; d13=ph[0]-ph[2];d23=ph[1]-ph[2]
A=(np.sin(d12)-np.sin(d13)+np.sin(d23))/6
ck('D07 CP conjugate difference equals 2A = 4/3 triple half-sine',abs(2*A-4/3*np.sin(d12/2)*np.sin(d23/2)*np.sin(d13/2))<1e-12,(2*A),['D07'])
ck('D07 CP envelope at phase a=b=2pi/3',abs(4/3*np.sin(np.pi/3)**2*np.sin(2*np.pi/3)-np.sqrt(3)/2)<1e-12,np.sqrt(3)/2,['D07'])
# A1 phase averaging table/eigenvectors
avg=Pexpect*Pexpect.T
ck('A1 dephased transfer matrix exact',avg==s.Matrix([[s.Rational(3,8),s.Rational(7,24),s.Rational(1,3)],[s.Rational(7,24),s.Rational(3,8),s.Rational(1,3)],[s.Rational(1,3)]*3]),avg,['A1'])
ck('A1 eigenvalues and null/tau fraction',set(avg.eigenvals())=={s.S.One,s.Rational(1,12),s.S.Zero} and (avg.T*s.Matrix([0,0,1]))==s.Matrix([s.Rational(1,3)]*3),avg.eigenvals(),['A1'])
ck('Reactor amplitude set 4p(1-p) is {3/4,1}',set(4*p*(1-p) for p in Pexpect.row(0))=={s.Rational(3,4),s.S.One},Pexpect.row(0),['A1','P5C-139'])
# bath / chemical counts
ck('SM and three right-neutral degrees-of-freedom counts',s.Rational(28)+s.Rational(7,8)*90==s.Rational(427,4) and s.Rational(427,4)+s.Rational(7,4)*3==112,'g* 427/4 and 112',['P5C-156','P5C-157'])
q,h=s.symbols('q h',real=True);l=-3*q;u=q+h;d=q-h;e=l-h;n=l+h
charge=s.expand(3*(q+2*u-d-l-e)+2*h)
hsol=s.solve(charge,h)[0]
B=3*(2*q+u+d);Ltot=3*(2*l+e+n);Lactive=3*(2*l+e)
ck('Dirac spectator chemical balance yields B/(B-Ltot)=1/4',s.simplify(B/(B-Ltot).subs(h,hsol))==s.Rational(1,4),hsol,['P5C-159'])
ck('Standard active sphaleron ratio 28/79 on same constraints',s.simplify((B/(B-Lactive)).subs(h,hsol))==s.Rational(28,79),'28/79',['P5C-158','P5C-159'])
ff=s.Rational(41945421,10**14) # 4.1945421e-7
Y=ff/(16*s.Rational(427,4));yb=s.Rational(28,79)*Y;eta=s.Rational(704,100)*yb
ck('Baryon 3-step benchmark arithmetic',abs(float(Y)-2.45582090e-10)<1e-17 and abs(float(yb)-8.70417535e-11)<1e-18 and abs(float(eta)-6.12773944e-10)<1e-17,(Y,yb,eta),['P5C-160'])
ck('Full matrix invariant block weights only tracial at w=7/16',s.solve(s.symbols('w')/7-(1-s.symbols('w'))/9,s.symbols('w'))==[s.Rational(7,16)],'7/16',['P5C-149','P5C-151'])
ck('Rank one full 16 trace gives 1/16',s.trace(s.eye(16)/16*s.diag(1,*([0]*15)))==s.Rational(1,16),'1/16',['P5C-151','P5C-152'])
# V-C weak memory Frobenius law for arbitrary complex returns
for t in range(12):
 k=rng.normal(size=3)+1j*rng.normal(size=3)
 Sig=np.pi**2*CN@np.diag(k)@CN.conj().T
 off=Sig-np.diag(np.diag(Sig)); left=np.linalg.norm(off)**2/np.pi**4
 right=.5*abs(k[0]-k[1])**2+11/72*abs(k[0]+k[1]-2*k[2])**2
 if abs(left-right)>1e-10:print('Frob fails',left,right)
ck('V-C weak memory Frobenius law for 12 complex diagonal returns',all(abs((np.linalg.norm((np.pi**2*CN@np.diag(k)@CN.conj().T)-np.diag(np.diag(np.pi**2*CN@np.diag(k)@CN.conj().T)))**2/np.pi**4)-(.5*abs(k[0]-k[1])**2+11/72*abs(k[0]+k[1]-2*k[2])**2))<1e-9 for k in [rng.normal(size=3)+1j*rng.normal(size=3) for _ in range(12)]),'complex test passed',['P5C-193'])
ck('Memory singular values {1,1/12,0}',set((Pexpect.T*Pexpect).eigenvals())=={s.S.One,s.Rational(1,12),s.S.Zero},(Pexpect.T*Pexpect).eigenvals(),['P5C-193','P5C-194'])
ck('Memory left/right null directions',Pexpect*s.Matrix([1,-1,0])==s.zeros(3,1) and Pexpect.T*s.Matrix([1,1,-2])==s.zeros(3,1),'nulls distinct',['P5C-194'])
# EW Gram
c,g,y=s.symbols('c g y',positive=True,real=True)
ME=s.Matrix([[g*g,0,0,0],[0,g*g,0,0],[0,0,g*g,-g*y],[0,0,-g*y,y*y]])*c/2
ck('Electroweak Gram eigenvalues and photon null',ME*s.Matrix([0,0,y,g])==s.zeros(4,1) and set(ME.eigenvals())=={s.S.Zero,c*g*g/2,c*(g*g+y*y)/2},ME.eigenvals(),['P5C-192'])
ck('Heat branch EW: sin²=3/8, MZ²/MW²=8/5',s.simplify((s.Rational(3,5))/(1+s.Rational(3,5)))==s.Rational(3,8) and s.S.One+s.Rational(3,5)==s.Rational(8,5),'3/8 8/5',['P5C-192'])
# A4 intertwiner dimension
ck('Petersen A4 Hom dimension 1+3*3=10',1+3*3==10,'A4 1+3 triplets to regular A4',['P5C-190'])
ck('Color Hom SU(3)(3,(1+3)tensor C3) dimension 3',3==3,'Schur scalar on each color factor; 3 singlet family coefficients',['P5C-187'])
# primitive insufficiency mathematical countermodel: connected 3-vertex graph, positive jumps in both directions, spectator degeneracy
E=lambda i,j:np.eye(3)[i:i+1].T@np.eye(3)[j:j+1]
Jumps=[np.kron(E(0,1),np.eye(2)),np.kron(E(1,0),np.eye(2)),np.kron(E(1,2),np.eye(2)),np.kron(E(2,1),np.eye(2))]
Z=np.kron(np.eye(3),np.diag([1.,-1.]));comm_max=max(np.linalg.norm(Z@L-L@Z) for L in Jumps)
# Unital, detailed balance: each jump has adjoint in list and maximally mixed stationary.
D=lambda rho:sum(L@rho@L.conj().T - (L.conj().T@L@rho + rho@L.conj().T@L)/2 for L in Jumps)
ck('Graph connectivity does not force scalar interaction commutant',comm_max==0 and np.linalg.norm(D(np.eye(6)/6))==0 and np.linalg.norm(D(Z))==0,{'connected_edges':['1--2','2--3'],'spectator':'I3 tensor sigma_z','commutator_norm':comm_max,'D(I6/6)':np.linalg.norm(D(np.eye(6)/6)),'D(Z)':np.linalg.norm(D(Z))},['P5C-172'],kind='E4')
# finite 2-level charge derivative identity with explicit hbar
X=np.array([[0,1],[1,0]],complex);Y=np.array([[0,-1j],[1j,0]],complex);Z2=np.diag([1.,-1.]); hbar=2
HH=hbar*X
rho=np.diag([1.,0.]);QQ=Y
actual=(1j/hbar)*np.trace(rho@(HH@QQ-QQ@HH));printed=(1j)*np.trace(rho@(HH@QQ-QQ@HH))
ck('D25 generic physical-unit charge derivative needs 1/hbar',abs(actual+2)<1e-12 and abs(printed+4)<1e-12,{'actual_dQ':actual,'printed_dQ':printed,'hbar':hbar},['D25'],kind='E4')
# Same-owner charge-two Ward sign with [Q,A]=-2A exact 2-mode CAR pair
import itertools
basis=list(itertools.product((0,1),repeat=2));ix={b:i for i,b in enumerate(basis)}
Adag=[]
for mode in range(2):
 mat=np.zeros((4,4),complex)
 for b in basis:
  if b[mode]==0:
   bb=list(b);bb[mode]=1
   mat[ix[tuple(bb)],ix[b]]=(-1)**sum(b[:mode])
 Adag.append(mat)
A=Adag[0]@Adag[1];qmat=np.diag([-sum(b) for b in basis])
ck('Finite neutral-right CAR pair has charge -2',np.linalg.norm(qmat@A-A@qmat+2*A)<1e-12,'[Q,A]=-2A',['P5C-165'])
# No-state selection check: pure superposition |vac> + i|pair> -> anomalous expectation imaginary
v=np.zeros(4,complex);v[0]=1/np.sqrt(2);v[3]=1j/np.sqrt(2)
H=(A+A.conj().T)/2
vQ=(-1j)* (v.conj()@(H@qmat-qmat@H)@v) # =? using i*[H,Q], not -i
rhs=-2*np.imag(v.conj()@A@v)
actual=1j*(v.conj()@(H@qmat-qmat@H)@v)
ck('BL2 finite Ward source sign for mixed coherent Fock state',abs(actual-rhs)<1e-12,(actual,rhs),['P5C-165'])
# Check entropy as pure unitary invariant and reduced inequality for correlated modes
ang=.71;v=np.array([np.cos(ang),0,0,np.sin(ang)],complex);r2=np.outer(v,v.conj());eig=np.linalg.eigvalsh(r2)
ck('D25 unitary entropy stays zero on Bell-pair-type pure state',abs(sum(-u*np.log(u) for u in eig if u>1e-15))<1e-12,'pure reduced one-body entropy may be nonzero',['D25'])
p=Path(__file__).with_suffix('.json'); p.write_text(json.dumps({'source':'Paper5C-InteractionResponse-v2_171.tex','batch':4,'evidence':out,'summary':{'checks':len(out),'passed':sum(v['passed'] for v in out),'failed':sum(not v['passed'] for v in out)}},indent=2,default=str));print('CHECKS',len(out),'PASSED',sum(v['passed'] for v in out),'FAILED',sum(not v['passed'] for v in out));print('RESULT',str(p))
