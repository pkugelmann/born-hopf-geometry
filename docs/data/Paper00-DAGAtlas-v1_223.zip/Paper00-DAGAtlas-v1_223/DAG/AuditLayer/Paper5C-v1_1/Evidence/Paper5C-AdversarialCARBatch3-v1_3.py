#!/usr/bin/env python3
"""Sparse Fock matrix implementation of the declared 2-family, 2-spin marked chain; E4 control."""
from scipy import sparse
import numpy as np,time,json
from pathlib import Path
f=12; d=2**f
print('CAR modes',f,'dim',d,flush=True)
# source R, L, E for inv/dir, spin 0/1
an=[]
for i in range(f):
 rows=[];cols=[];vals=[]
 for j in range(d):
  if j>>i&1:
   lower=j&((1<<i)-1)
   sgn=(-1)**lower.bit_count()
   rows.append(j^(1<<i));cols.append(j);vals.append(sgn)
 an.append(sparse.csr_matrix((np.array(vals,complex),(rows,cols)),shape=(d,d)))
cre=[x.conj().T.tocsr() for x in an]
I=sparse.eye(d,format='csr',dtype=complex)
Pmu=np.array([[5/12,-1/3+1j/4],[-1/3-1j/4,5/12]],dtype=complex)
M=np.array([(-1-1j)/2,(1+1j)/2])
# each family R0 spin=(0,1), R1 spin=(2,3), L0=(4,5),L1=(6,7), E0=(8,9),E1=(10,11)
p=sparse.csr_matrix((d,d),dtype=complex)
for fam in range(2):p+=M[fam]*(cre[2*fam]@cre[2*fam+1])
Ts=sum((cre[6+s]@an[2+s] for s in range(2)),sparse.csr_matrix((d,d),dtype=complex)) # dir R1->L1
Tr=sum((cre[s]@an[4+s] for s in range(2)),sparse.csr_matrix((d,d),dtype=complex)) # inverse L0->R0 (T_r^dag)
jmu=sparse.csr_matrix((d,d),dtype=complex)
for s in range(2):
 for a in range(2):
  for b in range(2):
   jmu+=Pmu[a,b]*(cre[8+2*a+s]@an[8+2*b+s])
wp=sum((cre[8+2*fm+s]@an[4+2*fm+s] for fm in range(2) for s in range(2)),sparse.csr_matrix((d,d),dtype=complex))
wm=wp.conj().T.tocsr()
X=sparse.csr_matrix([[0,1],[0,0]],dtype=complex) # charge lowering, two-state finite port
I_b=sparse.eye(2,format='csr',dtype=complex)
ops={
'P':sparse.kron(p,I_b,format='csr'),
'T_s':sparse.kron(Ts,I_b,format='csr'),
'W_+':sparse.kron(wp,X.conj().T,format='csr'),
'J_mu':sparse.kron(jmu,I_b,format='csr'),
'W_-':sparse.kron(wm,X,format='csr'),
'T_rdag':sparse.kron(Tr,I_b,format='csr')}
print('ops',[ (k,v.nnz) for k,v in ops.items()],flush=True)
def com(A,B):
 C=A@B-B@A
 C.sum_duplicates();C.eliminate_zeros()
 return C
V=ops['P']; start=time.monotonic()
for i,step in enumerate(['T_s','W_+','J_mu','W_-','T_rdag']*2,1):
 V=com(ops[step],V)
 print(i,step,'nnz',V.nnz,'seconds',round(time.monotonic()-start,2),flush=True)
# physical trace with complete fock and d boson
raw=(ops['P'].conj().T@V).diagonal().sum()/(d*2)
z=-7/288+1j/12
BX=((X@X.conj().T)@(X@X.conj().T)).diagonal().sum().real/2
expected=z*BX/4
result={'test':'direct sparse Fock 12 CAR modes + finite charge lowering boson, two nested 5-mark commutators',
'physical_basis':'2 family (inv,dir), 2 spins, 3 roles R L E','fock_dim':d,'boson_dim':2,
'actual_complex_raw':repr(complex(raw)),'expected_raw':repr(complex(expected)),
'ratio_actual_to_expected':repr(complex(raw/expected)),'isclose':bool(np.allclose(raw,expected,rtol=5e-9,atol=5e-9)),
'elapsed_seconds':time.monotonic()-start}
print(result)
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2))
