#!/usr/bin/env python3
"""E3/E4 operator-level CAR evaluation of the complete spin-slot coefficient on charge-graded boson spaces."""
import runpy, numpy as np, json, time
from pathlib import Path
from scipy import sparse
r=runpy.run_path('/mnt/data/bh_paper5c_work/Checkpoints/Paper5C-AdversarialCARBatch3-v1_3.py')
# reuse creation matrices only, not earlier verdict
cre=r['cre'];an=r['an'];Ts=r['Ts'];Tr=r['Tr'];jmu=r['jmu'];p=r['p'];d=r['d'];z=-7/288+1j/12
rng=np.random.default_rng(1940)
def calculate(a,b,c,d0):
 bd=len(a);Ib=sparse.eye(bd,dtype=complex,format='csr');kron=lambda op,coeff:sparse.kron(op,sparse.csr_matrix(coeff),format='csr')
 pp=kron(p,Ib);T_s=kron(Ts,Ib);T_rd=kron(Tr,Ib);J=kron(jmu,Ib)
 v=[ [a.conj().T,b.conj().T],[c.conj().T,d0.conj().T] ]
 Wp=sparse.csr_matrix((d*bd,d*bd),dtype=complex)
 for family in range(2):
  for e_spin in range(2):
   for l_spin in range(2):
    Wp+=kron(cre[8+2*family+e_spin]@an[4+2*family+l_spin],v[e_spin][l_spin])
 Wm=Wp.conj().T.tocsr();C=pp
 for op in [T_s,Wp,J,Wm,T_rd]*2:
  C=op@C-C@op;C.sum_duplicates();C.eliminate_zeros()
 actual=(pp.conj().T@C).diagonal().sum()/(d*bd)
 tau=lambda X:np.trace(X)/bd
 norm2=lambda X:np.real(tau(X.conj().T@X))
 cm=lambda x,y:x@y-y@x
 rv=(norm2(cm(a,b))+norm2(cm(c,d0))+norm2(a@d0-b@c)+norm2(d0@a-c@b)+norm2(a.conj().T@d0)+norm2(a@d0.conj().T)+norm2(b@c.conj().T)+norm2(b.conj().T@c)-2*np.real(tau(b.conj().T@d0@c.conj().T@a+b.conj().T@a@c.conj().T@d0)))/8
 return actual,rv
out=[]
# trial 1 source 4-dim external-charge test from appendix
D=4
a=np.zeros((D,D),complex);b=a.copy();c=a.copy();dd=a.copy()
a[0,2]=1;b[0,3]=1;c[1,2]=1;dd[1,3]=1
for title,values in [('four-dimensional nilpotent negative comparison',(a,b,c,dd))]:
 actual,R=calculate(*values);expected=z*R
 out.append({'title':title,'R_value':R,'actual':repr(complex(actual)),'expected':repr(complex(expected)),'passed':bool(np.allclose(actual,expected,rtol=1e-10,atol=1e-10))})
# trial 2 genuine charge lowering Q=diag(0,1,2) with noncommuting ports, row-only
D=3
a=np.zeros((D,D),complex);b=a.copy();a[0,1]=1;b[1,2]=1
actual,R=calculate(a,b,np.zeros((D,D),complex),np.zeros((D,D),complex))
expected=z*R
out.append({'title':'noncommuting charge-lowering single-row ports','R_value':R,'actual':repr(complex(actual)),'expected':repr(complex(expected)),'passed':bool(np.allclose(actual,expected,rtol=1e-10,atol=1e-10))})
# trial 3 all random graded ports on Q=diag(0,1,2), including direct and sequential transitions
for run in range(3):
 D=3
 maps=[]
 for k in range(4):
  Q=np.zeros((D,D),complex)
  Q[0,1]=(rng.standard_normal()+1j*rng.standard_normal())/2
  Q[1,2]=(rng.standard_normal()+1j*rng.standard_normal())/2
  maps.append(Q)
 actual,R=calculate(*maps);expected=z*R
 out.append({'title':'random graded noncommutative spin-slot ensemble '+str(run),'R_value':float(R),'actual':repr(complex(actual)),'expected':repr(complex(expected)),'passed':bool(np.allclose(actual,expected,rtol=1e-10,atol=1e-10))})
print('Spin-slot CAR results',out)
Path(__file__).with_suffix('.json').write_text(json.dumps({'E3_fock_basis':'full 12-mode CAR with 3/4-d charge-graded finite boson coefficient space','results':out,'passed':sum(x['passed'] for x in out),'count':len(out),'no_external_agents':True},indent=2))
