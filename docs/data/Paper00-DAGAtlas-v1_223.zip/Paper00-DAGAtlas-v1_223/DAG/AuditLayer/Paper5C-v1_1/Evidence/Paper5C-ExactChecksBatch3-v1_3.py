#!/usr/bin/env python3
"""Batch 3 exact/checkable numerical controls, source v2.371. No modifications to corpus."""
import sympy as s, numpy as np, json, hashlib, itertools
from pathlib import Path
from fractions import Fraction
OUT=Path(__file__).with_suffix('.json')
checks=[]
def chk(id,desc,ok,detail,claims):
 checks.append({'id':id,'description':desc,'passed':bool(ok),'result':str(detail),'claim_ids':claims})
 if not ok: print('FAIL',id,desc,detail)
I=s.I
sqrt=s.sqrt
ge=s.Matrix([(-1-I)/2,I/2,s.Rational(1,2)])
gm=s.Matrix([2,-1+3*I,-1-3*I])/(2*sqrt(6));gt=s.ones(3,1)/sqrt(3)
U=s.Matrix.hstack(ge,gm,gt)
# e2,e1,e0 role order
V=s.eye(3)[:,[2,1,0]]
C=s.simplify(U.conjugate().T*V)
expected=s.Matrix([[s.Rational(1,2),-I/2,(-1+I)/2],[(-1+3*I)/(2*sqrt(6)),(-1-3*I)/(2*sqrt(6)),1/sqrt(6)],[1/sqrt(3)]*3])
chk('VCB3-X01','Rooted charged basis unitary and current C exact',C.equals(expected) and s.simplify(C*C.conjugate().T)==s.eye(3),C,['P5C-095','P5C-098','P5C-100'])
quart=s.simplify(C[0,0]*C[1,1]*s.conjugate(C[0,1]*C[1,0]))
chk('VCB3-X02','Ordered complex quartet (-1/16 - i/12)',quart==(-s.Rational(1,16)-I/s.Integer(12)),quart,['P5C-094','P5C-095','P5C-098','P5C-108'])
P=s.simplify(C.multiply_elementwise(C.conjugate()))
chk('VCB3-X03','Full modulus Gram rank two and kernel',P.rank()==2 and P*s.Matrix([1,-1,0])==s.zeros(3,1) and all(sum(P.row(i))==1 for i in range(3)),P,['P5C-107','P5C-109'])
g2=s.sqrt(2)*s.pi;gy=s.sqrt(s.Rational(6,5))*s.pi;gz=s.sqrt(g2**2+gy**2);sin2=s.simplify(gy**2/gz**2);e=s.simplify(g2*gy/gz)
coef=[s.simplify(gz*(t+sin2)) for t in [-s.Rational(1,2),0]]
chk('VCB3-X04','Canonical EW e, gZ, s2 and electron Z coefficients',sin2==s.Rational(3,8) and s.simplify(e**2)==3*s.pi**2/4 and s.simplify(gz**2)==16*s.pi**2/5 and coef==[-s.pi/(2*sqrt(5)),3*s.pi/(2*sqrt(5))],coef,['P5C-100'])
ve=C.conjugate().T[:,0]
chk('VCB3-X05','Electron neutral vector and weights',ve==s.Matrix([s.Rational(1,2),I/2,(-1-I)/2]) and [s.simplify(s.Abs(z)**2) for z in ve]==[s.Rational(1,4),s.Rational(1,4),s.Rational(1,2)],ve,['P5C-107'])
k1,k2,k3=s.symbols('k1 k2 k3',real=True)
K=s.diag(k1,k2,k3);T=s.simplify(C*K*C.conjugate().T);aa=s.simplify(sum(T[i,0]*s.conjugate(T[i,0]) for i in (1,2)))
expectedv=(k1-k2)**2/16+(k1-k3)**2/8+(k2-k3)**2/8
chk('VCB3-X06','Exact diagonal neutral variance pair differences',s.simplify(aa-expectedv)==0,s.simplify(aa),['P5C-107','P5C-109'])
checks_ij=[(0,1,((-1-3*I)*k1+(3+I)*k2+(-2+2*I)*k3)/(4*sqrt(6))),(0,2,(k1-I*k2+(-1+I)*k3)/(2*sqrt(3))),(1,2,((-1+3*I)*k1+(-1-3*I)*k2+2*k3)/(2*sqrt(18)))]
chk('VCB3-X07','All three upper coherent weak-return entries',all(s.simplify(T[i,j]-v)==0 for i,j,v in checks_ij),[s.simplify(T[i,j]) for i,j,v in checks_ij],['P5C-109'])
# Jarlskog commutator cubic exact / sign
x1,x2,x3=s.symbols('x1 x2 x3',real=True)
Delta=lambda a,b,c:(a-b)*(b-c)*(c-a)
comm=s.diag(x1,x2,x3)*T-T*s.diag(x1,x2,x3)
invariant=s.simplify(s.trace(comm**3)/(6*I));want=-s.pi**0*s.Rational(1,12)*Delta(x1,x2,x3)*Delta(k1,k2,k3)
# T = C*K*Cdag, no pi^2; normalized
chk('VCB3-X08','Commutator cubic CP coefficient and Delta sign',s.simplify(invariant-want)==0,s.factor(invariant),['P5C-108'])
# complete local pair coefficients
M=s.diag((-1+I)/2,(1+I)/2,(-1-I)/2)
Xs=[]
for g in [ge,gm,gt]:
 P0=g*g.conjugate().T
 Xs.append(s.simplify(s.trace(M.conjugate().T*P0*M*P0.T)))
chk('VCB3-X09','Completed scalar pair current Xi on e/mu/tau',Xs==[s.Rational(0),s.Rational(2,9),s.Rational(1,18)],Xs,['P5C-125'])
# current pair marked Z in inv/dir indices 2,1
pmu=gm*gm.conjugate().T
z=s.simplify(s.conjugate(M[2,2])*M[1,1]*pmu[2,1]**2) # this ordering may not match actual, actual N_inv=e2 N_dir=e1 and M22 vs M11
chk('VCB3-X10','Mixed pair/current Z sign and modulus',z==-s.Rational(7,288)+I/s.Integer(12),z,['P5C-118','P5C-119','P5C-121'])
# Finite right commutant by direct matrix solve
u=s.symbols('u',real=True); J=s.Matrix([[0,1,0],[-1,0,0],[0,0,0]])
a,b,c=s.symbols('a b c',real=True)
H=s.Matrix([[s.symbols('d0',real=True),s.symbols('r01',real=True)+I*s.symbols('i01',real=True),s.symbols('r02',real=True)+I*s.symbols('i02',real=True)],
[s.symbols('r01',real=True)-I*s.symbols('i01',real=True),s.symbols('d1',real=True),s.symbols('r12',real=True)+I*s.symbols('i12',real=True)],
[s.symbols('r02',real=True)-I*s.symbols('i02',real=True),s.symbols('r12',real=True)-I*s.symbols('i12',real=True),s.symbols('d2',real=True)]])
unknowns=[s.symbols(q,real=True) for q in ['d0','d1','d2','r01','i01','r02','i02','r12','i12']]
sol=s.linsolve([s.re(z) for z in H*J-J*H]+[s.im(z) for z in H*J-J*H],unknowns)
chk('VCB3-X11','Hermitian J-commutant exactly three real dimensions',len(sol.free_symbols)==3,sol,['P5C-102'])
# moment certificate K_R(z) for finite env random, hermitian matrices
rng=np.random.default_rng(20261112)
U0=rng.normal(size=(3,3))+1j*rng.normal(size=(3,3));HR=(U0+U0.conj().T)/2
T0=rng.normal(size=(3,3))+1j*rng.normal(size=(3,3));HE=(T0+T0.conj().T)/2
V0=rng.normal(size=(3,3))+1j*rng.normal(size=(3,3));JN=np.array(J,dtype=complex)
commut=lambda a,b:a@b-b@a
samples=[3j,1+4j,2+5j,3+6j]
# n=3 -> numerator degree3. Fit polynomial with Vandermonde via np.poly, test reconstructed rational numerator at distinct points.
p=np.poly(HE)
Fvals=[]
for z0 in samples:
 KR=z0*np.eye(3)-HR-V0@np.linalg.inv(z0*np.eye(3)-HE)@V0.conj().T
 Fvals.append(commut(KR,JN)*np.polyval(p,z0))
extra=4+7j;kr=extra*np.eye(3)-HR-V0@np.linalg.inv(extra*np.eye(3)-HE)@V0.conj().T
coef=np.stack(Fvals)
Vd=np.array([[z0**3,z0**2,z0,1] for z0 in samples]);fit=np.linalg.solve(Vd,coef.reshape(4,-1))
pred=np.array([extra**3,extra**2,extra,1])@fit
chk('VCB3-X12','Finite K_R resolvent commutator degree-n interpolation',np.allclose(pred.reshape(3,3),commut(kr,JN)*np.polyval(p,extra),rtol=1e-9,atol=1e-9),float(np.max(np.abs(pred.reshape(3,3)-commut(kr,JN)*np.polyval(p,extra)))),['P5C-102'])
# random matrices for Schur source residue; construct complementary, derive finite derivative
Gdim=3;Cmem=np.diag([1.1,2.3,4.8]).astype(complex); B0=rng.normal(size=(3,3))+1j*rng.normal(size=(3,3));A0=np.diag([0.7,1.2,2.1]).astype(complex)
z0=7.7
R0=np.linalg.inv(z0*np.eye(3)-Cmem)
S=lambda z:z*np.eye(3)-A0-B0.conj().T@np.linalg.inv(z*np.eye(3)-Cmem)@B0
# isolate spectral via direct block eigenvalues with B block choose roots from full H
HF=np.block([[A0,B0.conj().T],[B0,Cmem]])
evals,evec=np.linalg.eigh(HF)
for j,lam in enumerate(evals):
 if min(abs(lam-np.diag(Cmem)))>1e-5 and np.linalg.norm(evec[:3,j])>1e-6:
  u=evec[:3,j]/np.linalg.norm(evec[:3,j]); a=1+np.linalg.norm(np.linalg.inv(lam*np.eye(3)-Cmem)@B0@u)**2
  v=evec[:3,j]
  chk('VCB3-X13','Schur residue / normalized full block eigenprojection',np.linalg.norm(v)**2>0 and np.allclose(np.outer(v,v.conj()),np.outer(u,u.conj())/a), {'lambda':float(lam),'weight':float(1/a)},['P5C-104']);break
# positive resolvent exact matrix numerical
Cmem2=np.diag([-2.,0.,3.,5.]);F=(rng.normal(size=(4,3))+1j*rng.normal(size=(4,3)))/3
zz=0.3+0.71j
Rz=np.linalg.inv(zz*np.eye(4)-Cmem2)
KW=F.conj().T@Rz@F
ImKW=-(KW-KW.conj().T)/(2j)
Rpos=zz.imag*F.conj().T@np.linalg.inv((zz.real*np.eye(4)-Cmem2)**2+zz.imag**2*np.eye(4))@F
chk('VCB3-X14','Upper-half-plane Herglotz positive return identity',np.allclose(ImKW,Rpos) and np.min(np.linalg.eigvalsh(ImKW))>0, np.linalg.eigvalsh(ImKW).tolist(),['P5C-105'])
# finite resolvent Krylov diagonal: if receivers eigenvectors mutually orthogonal, K diagonal
D=np.diag([-2.,0.,3.,5.]); Fgood=np.eye(4)[:,:3]; Fbad=np.stack([Fgood[:,0],Fgood[:,0]+Fgood[:,1],Fgood[:,2]],axis=1)
chk('VCB3-X15','Krylov moments distinguish diagonal and off-diagonal memory',np.allclose(Fgood.T@np.linalg.inv(zz*np.eye(4)-D)@Fgood,np.diag(np.diag(Fgood.T@np.linalg.inv(zz*np.eye(4)-D)@Fgood))) and abs((Fbad.T@np.linalg.inv(zz*np.eye(4)-D)@Fbad)[0,1])>1e-4, 'cross Krylov overlap = 1 in bad basis',['P5C-106'])
# real positive pair-return HS norm under conjugate transpose
Br=rng.normal(size=(4,4))+1j*rng.normal(size=(4,4));Banti=Br-Br.T
Cr=rng.normal(size=(4,4))+1j*rng.normal(size=(4,4));Rr=Cr.conj().T@Cr
w,vec=np.linalg.eigh(Rr);root=vec@np.diag(np.sqrt(np.maximum(w,0)))@vec.conj().T
left=np.trace(Banti.conj().T@Rr@Banti@Rr.T);right=np.linalg.norm(root@Banti@root.T,'fro')**2
chk('VCB3-X16','Positive pair return equals HS norm for complex R',np.allclose(left,right) and abs(left.imag)<1e-8,(complex(left).__repr__(),float(right)),['P5C-117'])
# 4-index tensor Schur source jets via finite difference 1st and 2nd
n=3
base=rng.normal(size=(n,n))+1j*rng.normal(size=(n,n));b_u=rng.normal(size=(n,n))+1j*rng.normal(size=(n,n));b_v=rng.normal(size=(n,n))+1j*rng.normal(size=(n,n));h0=np.diag([0.1,0.6,1.0]);H_u=np.diag([0.2,-0.1,0.1]);H_v=np.diag([-0.3,0.5,0.4]);h_uv=np.diag([0.1,0.2,-0.3]);B_uv=rng.normal(size=(n,n))+1j*rng.normal(size=(n,n));zet=4.
def sigma(u,v):
 B=base+u*b_u+v*b_v+u*v*B_uv
 h=h0+u*H_u+v*H_v+u*v*h_uv
 GG=np.linalg.inv(zet*np.eye(n)-h)
 return B@GG@B.conj().T
GG=np.linalg.inv(zet*np.eye(n)-h0);GU=GG@H_u@GG;GV=GG@H_v@GG;GUV=GG@h_uv@GG+GG@H_u@GG@H_v@GG+GG@H_v@GG@H_u@GG
analytic_u=b_u@GG@base.conj().T+base@GG@b_u.conj().T+base@GU@base.conj().T
analytic_uv=(B_uv@GG@base.conj().T+b_u@GV@base.conj().T+b_u@GG@b_v.conj().T+b_v@GU@base.conj().T+base@GUV@base.conj().T+base@GU@b_v.conj().T+b_v@GG@b_u.conj().T+base@GV@b_u.conj().T+base@GG@B_uv.conj().T)
eps=1e-4
fdu=(sigma(eps,0)-sigma(-eps,0))/(2*eps)
fduv=(sigma(eps,eps)-sigma(-eps,eps)-sigma(eps,-eps)+sigma(-eps,-eps))/(4*eps**2)
chk('VCB3-X17','Full return first-order jets vs separate finite differencing',np.allclose(fdu,analytic_u,atol=1e-7),float(np.max(np.abs(fdu-analytic_u))),['P5C-126'])
chk('VCB3-X18','Full nine-term mixed return jets vs separate finite differencing',np.allclose(fduv,analytic_uv,rtol=1e-5,atol=1e-6),float(np.max(np.abs(fduv-analytic_uv))),['P5C-126'])
# energy difference prepair Gibbs formula two state toy
Pa=np.array([[0,0],[1,0]],dtype=complex); Q=np.diag([0,-2]); Hc=np.diag([1,3]); rr=np.exp(-np.diag(Hc));rho=np.diag(rr/sum(rr));
comm=lambda x,y:x@y-y@x
spectral=4*(rho[1,1]-rho[0,0])*abs(Pa[1,0])**2
actual=4*np.trace(rho@comm(Pa,Pa.conj().T))
chk('VCB3-X19','Prepair weighted spectral charge jet, including sign',np.allclose(spectral,actual) and spectral<0,(float(spectral),float(np.real(actual))),['P5C-128','P5C-131'])
# basis X particles on truncated 2 boson modes, ncap=1 and2 direct vectors. X=chi(a_-dag+a_+) acts |0> etc, test N=2
for cap in (1,2,3):
 states=[(plus,minus) for plus in range(cap+1) for minus in range(cap-plus+1)]
 idx={st:j for j,st in enumerate(states)}
 q=len(states);chi=0.6+0.8j;xx=np.zeros((q,q),complex)
 for (p,m),i in idx.items():
  if p+m<cap:xx[idx[p,m+1],i]+=chi*np.sqrt(m+1)
  if p>0:xx[idx[p-1,m],i]+=chi*np.sqrt(p)
 v0=np.zeros(q);v0[idx[0,0]]=1
 vm=np.zeros(q);vm[idx[0,1]]=1
 want=v0.copy()
 if cap>=2: want[idx[1,1]]=1
 chk(f'VCB3-X{20+cap}','Finite charged coordinate first/two returns cap='+str(cap),np.allclose(xx@v0,chi*vm) and np.allclose(xx.conj().T@xx@v0,abs(chi)**2*want),{'cap':cap,'coeff':abs(chi)**2},['P5C-113','P5C-114','P5C-115'])
 # K(X)=comm(Xdag,X), QB=Nplus - Nminus; check charge witness and bound
 QB=np.diag([p-m for p,m in states]);Kb=comm(xx.conj().T,xx);tau=lambda x:np.trace(x)/q
 kap=tau(xx.conj().T@xx);witness=tau(QB@Kb);varq=tau((QB-tau(QB)*np.eye(q))**2);low=kap**2/varq;kn=tau(Kb@Kb)
 chk(f'VCB3-X{24+cap}','Finite charge Cauchy witness and lower HS bound cap='+str(cap),np.allclose(witness,kap) and np.real(kn)>=np.real(low)-1e-10,{'kappa':np.real(kap),'KN':np.real(kn),'lower':np.real(low)},['P5C-113'])
# Matrix slot polynomial R: compare operator-valued expression vs cyclic word table in independent exact noncommuting boson matrices
rng=np.random.default_rng(1337)
def R_slot(aa,bb,cc,dd):
 norm2=lambda A:np.real(np.trace(A.conj().T@A))/len(A)
 tau=lambda A:np.trace(A)/len(A)
 u=(norm2(comm(aa,bb))+norm2(comm(cc,dd))+
    norm2(aa@dd-bb@cc)+norm2(dd@aa-cc@bb)+
    norm2(aa.conj().T@dd)+norm2(aa@dd.conj().T)+norm2(bb@cc.conj().T)+norm2(bb.conj().T@cc)-
    2*np.real(tau(bb.conj().T@dd@cc.conj().T@aa+bb.conj().T@aa@cc.conj().T@dd)))/8
 return u
for j in range(3):
 arr=[(rng.normal(size=(3,3))+1j*rng.normal(size=(3,3)))/3 for t in range(4)]
 aa,bb,cc,dd=arr
 letters={'a':aa,'b':bb,'c':cc,'d':dd,'A':aa.conj().T,'B':bb.conj().T,'C':cc.conj().T,'D':dd.conj().T}
 pos='AdDa ADda AabB AadD AaDd ABba BbCc BcCb BbcC BCcb CcdD CDdc'.split()
 neg='BdCa BCda ABab BadC BaCd AbaB AbDc AcDb AbcD ADcb CDcd CdcD'.split()
 tword=lambda word: np.trace(np.linalg.multi_dot([letters[z] for z in word]))/3
 tab=np.real(sum(tword(w) for w in pos)-sum(tword(w) for w in neg))/8
 Rval=R_slot(*arr)
 chk(f'VCB3-X{28+j}','24 cyclic word table equals compact R for generic noncommuting matrices',np.allclose(tab,Rval),{'cyclic':tab,'compact':Rval},['P5C-121'])
# verify K X† scalar factor of B_X
for t in range(3):
 aa=(rng.normal(size=(3,3))+1j*rng.normal(size=(3,3)))/3
 KK=(rng.normal(size=(2,2))+1j*rng.normal(size=(2,2)))/3
 v=KK*1
 # V = K X^dag => a=K00 X^dag etc
 vals=[KK[0,0]*aa.conj().T,KK[0,1]*aa.conj().T,KK[1,0]*aa.conj().T,KK[1,1]*aa.conj().T]
 BX=np.real(np.trace((aa@aa.conj().T)@(aa@aa.conj().T)+(aa@aa).conj().T@(aa@aa)))/3
 expectedR=np.real(np.linalg.det(KK.conj().T@KK))*BX/4
 rr=R_slot(*vals)
 chk(f'VCB3-X{31+t}','Single-factor K*Xdag determinant specialization of full slot R',np.allclose(rr,expectedR,rtol=1e-10,atol=1e-10),{'R':rr,'detB4':expectedR},['P5C-120','P5C-121'])
# row and complementary slot cancellations
na=np.array([[0,1,0],[0,0,0],[0,0,0]],dtype=complex)
nb=np.array([[0,0,0],[0,0,1],[0,0,0]],dtype=complex)
row=R_slot(na,nb,np.zeros((3,3)),np.zeros((3,3)))
want=np.real(np.trace(comm(na,nb).conj().T@comm(na,nb)))/3/8
chk('VCB3-X34','Single-row noncommuting slot value',np.allclose(row,want) and row>0,(row,want),['P5C-123','P5C-124'])
# self-check report
result={'source':'Paper5C-InteractionResponse-v2_171.tex','batch_index':3,'checks':checks,'pass_count':sum(x['passed'] for x in checks),'total':len(checks),'method':'Exact SymPy rational arithmetic, independent finite-difference and spectral controls, finite boson cap occupation matrices, and two independent bosonic cyclic-operator expansions','independent_agents':False}
OUT.write_text(json.dumps(result,indent=2,default=str))
print('checks',result['pass_count'],'/',result['total']); print('failures',[x['id'] for x in checks if not x['passed']]);print('output',OUT)
