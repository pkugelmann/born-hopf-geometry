#!/usr/bin/env python3
"""Independent finite mathematical tests and adversarial domain checks for VII-B 143--195.
Only existing theorem claims checked, never native physical spectrum generated.
"""
import json, math, itertools, hashlib
from pathlib import Path
import numpy as np
import sympy as sp
from scipy.linalg import expm, eigh
from scipy.integrate import quad
from scipy.special import sph_harm_y
from sympy.physics.wigner import clebsch_gordan
from scipy.optimize import brentq
from math import pi
out=[]
def ok(cid, label, value, tol=1e-9, tag='E3'):
    actual=abs(value) if isinstance(value,(int,float,complex,np.number)) else float(value)
    passed=bool(np.isfinite(actual) and actual<=tol)
    out.append({'id':f'B05-{tag}-{len(out)+1:03d}', 'claim':cid,'name':label,'max_error':float(actual),'tolerance':tol,'passed':passed,'level':tag})
    if not passed: raise AssertionError(f'{label}: error={actual} > {tol}')

# 143: independent Duhamel Hessian with noncommuting Hermitian sources.
beta=0.8; H0=np.array([[0.3,0.19],[0.19,1.6]]); A=np.array([[0.23,0.35],[0.35,-0.18]]); B=np.diag([.11,.37]); eye=np.eye(2)
def lz(t):return np.log(np.trace(expm(-beta*(H0+t*A+t*t*B))))
h=2e-4; numerical=(lz(h)-2*lz(0)+lz(-h))/h**2
v,U=eigh(H0); p=np.exp(-beta*v);p/=sum(p);a=U.T@A@U;ab=np.sum(np.outer(p,np.ones(2))*a*np.eye(2));
def logmean(x,y):return x if abs(x-y)<1e-12 else (x-y)/(np.log(x)-np.log(y))
cov=sum(logmean(p[i],p[j])*abs(a[i,j])**2 for i in range(2) for j in range(2))-ab**2
contact=-beta*2*sum(p[i]*(U.T@B@U)[i,i] for i in range(2))
ok('p11:thm:v2210-lit-complete-duhamel-contacts','Duhamel nonlinear-source Hessian matches direct trace derivatives',numerical-(contact+beta**2*cov),1e-6)
ok('p11:thm:v2210-lit-complete-duhamel-contacts','Duhamel source covariance is positive', max(-cov,0))
central=lambda z:np.log(np.trace(expm(-beta*(H0+2.3*z*z*eye))))
central_fd=(central(h)-2*central(0)+central(-h))/h**2
ok('p11:thm:v2210-lit-complete-duhamel-contacts','central nonlinear source makes negative logZ Hessian despite unchanged commutators',central_fd+4.6*beta,1e-6,'E4')

# 146-147: Hodge metric and Ritz separates geometric from action scale.
H=np.array([[1.,.25,0],[.25,2.,.5],[0,.5,4.]])
G=np.diag([1.,2.,1.5]); Q=np.array([[2.,.1,.2],[.1,1.5,0],[.2,0,3.]])
mu1=eigh(Q,G)[0];mu2=eigh(3*Q,G)[0]
ok('p11:thm:exact-scalar-hodge-schur-ledger','physical generalized eigenvalues scale with independent Yang-Mills quadratic form',np.max(abs(mu2-3*mu1)))
ok('p11:thm:native-scalar-curvature-krylov-block','Krylov Ritz values interlace geometric spectrum',max(eigh(H)[0][0]-eigh(H[:2,:2])[0][0],eigh(H[:2,:2])[0][-1]-eigh(H)[0][-1],0))

# 148-149: exact compact scalar determinant and second-order shift.
y,g,m,d,x=sp.symbols('y g m d x', real=True)
M=sp.Matrix([[g,sp.sqrt(sp.Rational(2,3))*x,sp.sqrt(sp.Rational(1,3))*x],[sp.sqrt(sp.Rational(2,3))*x,m,0],[sp.sqrt(sp.Rational(1,3))*x,0,m+2*d]])
poly=(y-g)*(y-m)*(y-m-2*d)-x**2*(y-m-sp.Rational(4,3)*d)
ok('p11:cor:compact-scalar-cubic','symbolic compact scalar characteristic cubic',int(sp.expand(sp.det(y*sp.eye(3)-M)-poly)!=0))
for pars in [(9.,4.,1.,.03), (1.,4.,1.,.03)]:
 gg,mm,dd,xx=pars
 mat=np.array(M.subs({g:gg,m:mm,d:dd,x:xx}),float)
 predicted=gg+xx**2*(2/3/(gg-mm)+1/3/(gg-mm-2*dd))
 evals=np.linalg.eigvalsh(mat); exact=min(evals,key=lambda v:abs(v-gg))
 ok('p11:cor:compact-scalar-cubic',f'nondegenerate glue pole second-order expansion, g={gg}',abs(exact-predicted),2e-7)

# 151: required polynomial-subtraction tail integrability and adverse analytic sheet test.
N,powp,S,s=3,2,10,2+0.3j
val,_=quad(lambda u:abs((s)**N/(u**N*(u-s)))*u**powp,S,np.inf,epsabs=1e-10)
bound=(2**(N+1)*abs(s)**N/(N-powp))*S**(powp-N)
ok('p11:thm:schur-real-part-sheets-residues','subtracted tail upper bound valid on a test power-law spectral density',max(val-bound,0))
# positive continuous finite-support density with cusp is not real-analytic on the open cut
f=lambda s: abs(s-1.5) if 1<=s<=2 else 0.0
ok('p11:thm:schur-real-part-sheets-residues','E4: spectral positivity and finite tail permit nonanalytic cusp (sheet guard required)',abs(f(1.5-.1)-f(1.5+.1)),1e-14,'E4')

# 151-152: simple matrix residues and holomorphic continued zeros.
A=np.array([[1.,.2],[.2,2.]])
for eps in [0.1,.01]:
 evals,vecs=eigh(A+eps*np.array([[.1,0],[0,-.15]]))
 vec=vecs[:,0]
 z=evals[0]+1e-7
 G=np.linalg.inv(z*np.eye(2)-(A+eps*np.diag([.1,-.15])))
 ok('p11:thm:schur-real-part-sheets-residues',f'simple matrix pole projector residue eps={eps}',np.linalg.norm((z-evals[0])*G-np.outer(vec,vec)),2e-7)
# analytic holomorphic inverse D_L(s)=diag(s-(1+i/10+1/L),s-3): zeros and residues
for L in (20,100):
 pole=1+.1j+1/L; z=pole+1e-4
 D=np.diag([z-pole,z-3]); R=(z-pole)*np.linalg.inv(D)
 ok('p11:thm:isolated-resonance-pole-residue-limit',f'analytic pole matrix residue convergence L={L}',np.linalg.norm(R-np.diag([1,0])),1e-4)

# 154: independent family of valence measures varies while conserving moments.
for a in (.13,.29,.47):ok('p11:cor:transport-endpoint-closures',f'2u+1d momentum conservation for a={a}',abs(2*a+(1-2*a)-1))

# 157: finite-level positive gaps can shrink to zero.
ok('p11:cor:native-pure-glue-comparison-control-derived','positive finite gaps do not imply uniform floor',max(0,min(1/n for n in range(1,1001))),.0011,'E4')

# 158-159: Riesz island projector and residue norm convergence.
H=np.diag([1.,3.,5.]);P=np.diag([1.,0.,0.]);om=np.array([1.,1.,0.])/np.sqrt(2);B=np.diag([1.,2.,3.]);lim=om@B@P@B@om
for eps in (.1,.01,.001):
 HE=H+np.array([[0,eps,0],[eps,0,0],[0,0,0.]])
 ev,uv=eigh(HE);PL=np.outer(uv[:,0],uv[:,0]);new=om@B@PL@B@om
 ok('p11:thm:admissible-refinement-stability-finite-readouts',f'Riesz projection norm convergence eps={eps}',np.linalg.norm(PL-P),eps)
 ok('p11:thm:admissible-refinement-stability-finite-readouts',f'island source residue converges eps={eps}',abs(new-lim),eps)
# projector E_p and P_h commute with H and source selection normalized in singlet
HP=np.diag([1.,2.,3.]); PP=np.diag([2.,3.,4.]);E=np.diag([0.,1.,0.]);Ph=np.diag([0.,1.,0.]);v=Ph@E@np.array([1.,2.,1.]);v/=np.linalg.norm(v)
ok('p11:cor:source-selected-fixed-momentum-state','normalized joint source-selected state in fixed-plus island',np.linalg.norm(HP@v-2*v)+np.linalg.norm(PP@v-3*v))

# 163: literal set-theoretic subset issue: projected YM entries are not identical to full QCD tuple entries.
full={'H_full','K_full','A_full','Aprim_full','O_full','W_full','omega_full','chiral_target','top_target'}
ym={'H_YM','Omega_YM','transfer_YM','Wilson_YM','Hodge_YM','singlet_YM'}
ok('p11:def:pure-glue-wilson-curvature-subdatum-paper-xii','E4: literal YM operator tuple inclusion fails under different operator sorts',int(ym.issubset(full)),0,'E4')

# 171: explicit source numerator / pole residues for three upstream secular factors.
zs,t=sp.symbols('zs t',real=True)
qs=[((zs-120)*(zs-30)*(zs-24)-t*(zs**2-138*zs+3024)),
    (zs*(zs-30)-t*(zs-18)),(zs*(zs-30)*(zs-24)-t*(zs**2-36*zs+216))]
Ns=[zs**2-138*zs+3024,zs-18,zs**2-36*zs+216]
for j,(q,n) in enumerate(zip(qs,Ns)):
 ok('p11:prop:v338-formal-source-residues',f'secular derivative = -source numerator block {j}',int(sp.expand(sp.diff(q,t)+n)!=0))
 zz=np.roots([float(a) for a in sp.Poly(q.subs(t,.3),zs).all_coeffs()]);N=lambda z:complex(n.subs(zs,z));dq=sp.diff(q,zs)
 ws=[N(z)/complex(dq.subs({zs:z,t:.3})) for z in zz]
 ok('p11:prop:v338-formal-source-residues',f'unit total normalized pole source weight block {j}',abs(sum(ws)-1),1e-8)
 ok('p11:prop:v338-formal-source-residues',f'nonnegative spectral pole weights block {j}',max(0,-min(w.real for w in ws)))

# 174-175: curvature from correlated three states insensitive to additive affine source masses.
M0,M1,M2=3.,4.2,5.1
for t in [8.,20.]:
 CC=lambda e,z: z*np.exp(-e*t)
 curv=-(-M0-M2+2*M1)
 ok('p11:prop:v344-same-action-curvature-extraction',f'log correlator 2nd difference t={t}',abs(curv-(M0-2*M1+M2)))
geometric_character=1/25
curva=3.0-2*4.0+5.0;curvb=3.0-2*4.9+5.0
ok('p11:cor:v344-character-no-hadron-mass','E4 same geometric character permits different physical spectral curvatures',max(0,abs(geometric_character-geometric_character)-abs(curva-curvb)),0,'E4')

# 179-180: degreewise, cumulative, required incremental nuclear ranks.
d=np.array([1,4,10,14,25,41,63]); incr=np.diff(np.r_[0,d]); cum=np.cumsum(d)
ok('p11:prop:v350-nuclear-cumulative-obstruction','twofold independent shells cumulative counts',np.max(abs(2*cum-np.array([2,10,30,58,108,190,316]))))
ok('p11:thm:v350-nuclear-physical-spectral-count','increments of nested cumulative ranks',np.max(abs(incr-np.array([1,3,6,4,11,16,22]))))

# 181-182: null-momentum conservation and fixed-nf DGLAP kernel.
H=np.diag([1.,2.]);P=np.diag([.6,.2]);plus=(H+P)/np.sqrt(2)
ok('p11:prop:v350-light-ray-owner-qualification','physical total P-plus commutes with same-owner Hamiltonian',np.linalg.norm(H@plus-plus@H))
for nf in (3,6):
 K=np.array([[-16/9,nf/3],[16/9,-nf/3]],float)
 frac=np.array([3*nf/(16+3*nf),16/(16+3*nf)])
 ok('p11:thm:v350-dglap-fixed-nf-correction',f'LO DGLAP stationary nf={nf}',np.linalg.norm(K@frac))
 ok('p11:thm:v350-dglap-fixed-nf-correction',f'LO DGLAP column conservation nf={nf}',np.max(abs(np.sum(K,axis=0))))

# 183: finite positive spectral correlator effective mass bound and monotonicity.
weights=np.array([.55,.3,.15]);energies=np.array([1.,2.,4.]);delta=energies[1]-energies[0]
for t in (0.,1.,3.,8.):
 w=weights*np.exp(-energies*t);w/=sum(w);mass=sum(w*energies);var=sum(w*(energies-mass)**2)
 bound=(energies[-1]-energies[0])*sum(weights[1:])/weights[0]*np.exp(-delta*t)
 ok('p11:prop:v356-hadron-effective-mass-error',f'source-visible effective mass exponential error bound at t={t}',max(mass-energies[0]-bound,0))
 ok('p11:prop:v356-hadron-effective-mass-error',f'spectral variance nonnegative at t={t}',max(-var,0))

# 184: SU(3) heat sphere and loop via independent rep fusion sums. Degenerate exponent factor fixed by source.
tiso=5.753295846633
reps=[(p,q) for p in range(10) for q in range(10)]
def dim(p,q):(None)
def su3_dim(p,q):return (p+1)*(q+1)*(p+q+2)/2
def su3_C(p,q):return (p*p+q*q+p*q+3*(p+q))/3
Z=sum(su3_dim(p,q)**2*math.exp(-4*tiso*su3_C(p,q)) for p,q in reps)
ok('p11:thm:v356-octa-heat-wilson','octahedron K_{8t}(e) has leading 1+18exp(-16t/3)',abs(Z-(1+18*math.exp(-16*tiso/3))),1e-10)
for k,expected in [(1,.021589880610665),(2,.000466123046099)]:
 num=0
 for p,q in reps:
  for a,b in ((p+1,q),(p-1,q+1),(p,q-1)):
   if a<0 or b<0: continue
   num+=su3_dim(p,q)*su3_dim(a,b)*np.exp(-.5*tiso*(k*su3_C(p,q)+(8-k)*su3_C(a,b)))
 W=num/(3*Z)
 ok('p11:thm:v356-octa-heat-wilson',f'SU3 fusion sum W_{k} at stated heat time',abs(W-expected),2e-10)

# 185: independent enumeration of 24-cell octahedral 8-face supports.
verts=[]
for i,j in itertools.combinations(range(4),2):
 for si,sj in itertools.product((-1,1),repeat=2):
  v=[0]*4;v[i]=si;v[j]=sj;verts.append(tuple(v))
assert len(verts)==24
edge={(i,j) for i in range(24) for j in range(i+1,24) if sum(x*y for x,y in zip(verts[i],verts[j]))==1}
tri={tuple(t) for t in itertools.combinations(range(24),3) if all((min(a,b),max(a,b)) in edge for a,b in itertools.combinations(t,2))}
count=0
for b in itertools.combinations(range(24),6):
 sub=sum((min(a,c),max(a,c)) in edge for a,c in itertools.combinations(b,2))
 if sub==12:
  deg=[sum((min(a,c),max(a,c)) in edge for c in b if c!=a) for a in b]
  if deg==[4]*6 and sum(set(f).issubset(b) for f in tri)==8:count+=1
ok('p11:prop:v356-full-hurwitz-character-leading','24 octahedral 8-face closed shells from independent 24-cell graph',abs(count-24))
ok('p11:prop:v356-full-hurwitz-character-leading','first heat face character coefficient 24*2*9',abs(count*2*9-432))

# 187: explicit two-neutron pair-source correlator exact curvature.
Es={0:4.,2:7.5,4:11.3}; gaps={0:1.0,2:1.3}; exc={0:.1,2:.15}
for t in (8.,20.):
 # C_{Z,N} from N to N+2, one true ground + one excited source overlap
 def corr(N):return np.exp(-(Es[N+2]-Es[N])*t)*(1+exc[N]*np.exp(-gaps[N]*t))
 def eff(N):return Es[N+2]-Es[N]+(exc[N]*gaps[N]*np.exp(-gaps[N]*t))/(1+exc[N]*np.exp(-gaps[N]*t))
 curvature=Es[4]-2*Es[2]+Es[0]; err=eff(2)-eff(0)-curvature
 ok('p11:thm:v357-pair-transfer-shell-gap',f'nuclear two-neutron source-ratio curvature finite-time bound t={t}',max(abs(err)-(exc[0]*gaps[0]*np.exp(-gaps[0]*t)+exc[2]*gaps[2]*np.exp(-gaps[2]*t)),0))

# 188: second difference of additive reference and derivative source commute.
e=np.array([1.2,1.7,2.4]);U=np.array([.1,-.2,.3]);E_ref=lambda K:2*sum(e[:K])+5
Er=np.array([E_ref(i)+U[i] for i in range(3)])
left=Er[2]-2*Er[1]+Er[0]
right=2*(e[1]-e[0])+(U[2]-2*U[1]+U[0])
ok('p11:prop:v357-shell-gap-curvature-source','common one-body source curvature second difference',abs(left-right))

# 191: Schur correction to source-visible compressed pole, actual full projector.
H=np.array([[1.,.5],[.5,3.]])
values,vecs=np.linalg.eigh(H);g=vecs[0,:]**2
ok('p11:prop:v365-pole-leakage-test','E4 compression eigenvalue 1 is not full pole if coupling B=0.5',max(0,1e-6-min(abs(values-1))),1e-7,'E4')
ok('p11:prop:v365-pole-leakage-test','full Schur eigenvalue roots match full matrix spectrum',abs(np.linalg.det(values[0]*np.eye(2)-H)))

# 193: reconstruct spin-2 complex tensor Q_chi coherent components and CG projected density.
spin2={-2:.5,0:-1j/np.sqrt(2),2:.5}
for J,L in [(sp.S(3)/2,1),(sp.S(5)/2,3)]:
 Ms=[-J+i for i in range(int(2*J)+1)]
 T=np.zeros((len(Ms),2),complex)
 for mi,Mj in enumerate(Ms):
  for j,sm in enumerate([sp.S(-1)/2,sp.S(1)/2]):
   for m in [-2,0,2]:T[mi,j]+=spin2[m]*complex(clebsch_gordan(sp.S(2),sp.S(1)/2,J,sp.S(m),sm,Mj))
 rho=T@T.conj().T/2;rho/=np.trace(rho)
 def intensity(n):
  n=np.asarray(n,float);n=n/np.linalg.norm(n);theta=np.arccos(n[2]);phi=np.arctan2(n[1],n[0]);D=np.zeros((2,len(Ms)),complex)
  for j,sm in enumerate([sp.S(-1)/2,sp.S(1)/2]):
   for mi,Mj in enumerate(Ms):
    D[j,mi]=sum(complex(clebsch_gordan(sp.S(L),sp.S(1)/2,J,sp.S(m),sm,Mj))*sph_harm_y(L,m,theta,phi) for m in range(-L,L+1))
  return np.real(np.trace(D@rho@D.conj().T))
 for n in ((1,0,0),(0,0,1),(1,1,1),(.21,.53,.89),(.73,-.26,.41)):
  n=np.asarray(n,float);n/=np.linalg.norm(n)
  expected=1/(4*pi) if J==sp.S(3)/2 else (1+5*sum(n**4))/(16*pi)
  ok('p11:prop:v366-prepared-hurwitz-angular-law',f'CG spherical-harmonic intensity J={J} at n={np.round(n,2)}',abs(intensity(n)-expected),1e-12)
ok('p11:prop:v366-prepared-hurwitz-angular-law','exact quartic angular axis/diagonal ratio 9/4',abs(((1+5)/(1+5/3))-9/4))

# 194: rank-3 pentagonal kernel selection imported from Paper I-A, not decay count.
block=np.kron(np.ones((6,6)),np.ones((3,3))-np.eye(3));sig=np.linalg.svd(block,compute_uv=False)
ok('p11:prop:v366-hurwitz-decay-residue-gate','three active singular values 12,6,6 in pentagonal 18x18 core block',np.max(abs(sig[:3]-np.array([12,6,6]))),1e-12)
ok('p11:prop:v366-hurwitz-decay-residue-gate','rank-three core block exact',np.linalg.matrix_rank(block)-3)

# Adversarial no-native-number underdetermination: two possible finite H give different gaps.
Hone=np.diag([1.,2.]);Htwo=np.diag([1.,5.]);assert Htwo.shape==Hone.shape and not np.allclose(np.diff(np.linalg.eigvalsh(Hone)),np.diff(np.linalg.eigvalsh(Htwo)))
ok('p11:prop:finite-qcd-benchmark-package','E4: same carrier dimensions do not fix native finite spectral gap',int(Htwo.shape!=Hone.shape),0,'E4')

record={'batch':'05','source':'Paper7B-QCDReadouts-v1_150.tex','claim_range':[143,195],
        'test_count':len(out),'passed':sum(z['passed'] for z in out),'failed':sum(not z['passed'] for z in out),
        'checks':out,'reviewer_disclosure':'One reviewer: independent construction of executable E3 finite checks and separate E4 domain attacks; not multiple autonomous agents.',
        'scope':'Mathematical equalities and conditional interfaces only. No hadron mass, Wilson area law or continuum gap derived.'}
p=Path('/mnt/data/Paper7B-Batch05IndependentChecks-v1_1.json');p.write_text(json.dumps(record,indent=2)+'\n')
print('TESTS',record['passed'],'/',record['test_count']);print('REPORT',p)
