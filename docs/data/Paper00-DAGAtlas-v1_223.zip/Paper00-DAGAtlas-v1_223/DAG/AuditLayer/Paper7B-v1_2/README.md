# Paper VII-B complete source audit — Atlas 1.120

**Status:** 195/195 named source claims examined; 14 issue roots (13 open / 1 resolved); `FULLY_AUDITED_WITH_OPEN_GAPS`.

The versioned canonical theorem graph is preserved mathematically. VII-B contributions are integrated via the
`DAG/Paper00-TheoremDAG.json::graph_layers` and the `DAG/CurrentRegisteredAuditLayers-v1_120.json`
entry pointing at `DAG/AuditLayer/Paper7B-v1_2/Index.json`.

`AuditClaimLedger.json` records exact source proof status, `ProofEvidenceLedger.json` E0/E1/E3/E4 checks,
`AssumptionRegistry.json` pending aliases to first-established owner conditions (no new foundational BH-A),
`GapRegistry.json` every issue origin, `TypedDependencyEdges.json` reviewed material and nonpromoting scope edges,
`ProofRoutes.json` conjunctive source inputs and explicitly distinct alternative guards,
`ImpactIndex.json` only supported impact routes, and `CoverageAndValidation.json` release checks.

For `conditions(claim)`: resolve aliases in the combined graph, traverse the **reviewed material** backward
edges, then intersect with the canonical assumption registry and the target proof route's `AND_inputs`.
A named `uncertified_scope_inputs` remains a guard, not an automatically true premise.
For `descendants(issue)`: locate its `first_origin.theorem_id`, then traverse forward only reviewed material
edges; inspect `ImpactIndex.json` for source-limited routes. Do not treat citation or scope edges as theorem
ancestry. `OR` branches remain alternatives, not a single universal conjunction.

Current source: `Sources-v2_371/Paper7B-QCDReadouts-v1_150.tex`; unchanged SHA-256
`d23f9643784f1963e50d51a45fcdecb3f37508414154d855008bfd5cdb7bc2c0`.

The independent checks are finite mathematical audits, not computed physical QCD observables.

### v1.120 merge-only issue-ID provenance

The VII-B mathematical audit is unchanged. Its 14 source-local issue IDs have globally unique `BH-VIIB-G-0134`–`BH-VIIB-G-0147` identities; see `DAG/IssueIDReconciliation-v1_120.json`. The bare `BH-G-000134`–`BH-G-000147` IDs now denote **Paper VII-A** and must not be used to refer to Paper VII-B without the paper-qualified provenance.
