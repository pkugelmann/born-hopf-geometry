Paper V-D complete source audit layer. Canonical immutable DAG: DAG/Paper00-TheoremDAG.json.
Combined query index: DAG/CombinedGraphIndex-v1_114.json; current material graph: DAG/CombinedMaterialEdges-v1_114.json.
199 source claims, 792 independently computed exact subchecks. Open source-level issues BH-VD-G-0001, BH-VD-G-0002.
Formal statuses source-limited; all inherited V-A issues preserved. No unproved physical occurrence promoted.
Material edges from source-reviewed matches only. Scope and citation-only references do not traverse.
