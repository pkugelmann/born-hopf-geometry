#!/usr/bin/env python3
"""Independent finite adversarial witnesses for Paper I-A v5.177; infinite claims certified analytically in paper."""
import numpy as np, json, math, hashlib
from pathlib import Path
P=Path(__file__).parent
checks=0; failures=[]; records=[]
def check(tag,ok):
 global checks
 checks+=1
 if not ok:failures.append(tag)
 if checks<=20:records.append([tag,bool(ok)])
for twicej in range(0,43):
 j=twicej/2
 m=np.arange(-j,j+1,dtype=float); d=len(m)
 J3=np.diag(m)
 Jp=np.zeros((d,d),complex)
 for q in range(d-1):Jp[q+1,q]=math.sqrt((j-m[q])*(j+m[q]+1))
 Jm=Jp.T.conj();J1=(Jp+Jm)/2
 J2=(Jp-Jm)/(2*1j)
 check('su2 casimir '+str(j), np.allclose(J1@J1+J2@J2+J3@J3,j*(j+1)*np.eye(d),atol=1e-10))
 for a,b,c in [(1.,1.,1.),(0.6,1.5,0.03),(2.3,0.31,12.),(0.7,0.4,200.),(0.5,2.9,0.8)]:
  u=min(a**-2,b**-2);weights=[a**-2,b**-2,c**-2]
  H=weights[0]*(J1@J1)+weights[1]*(J2@J2)+weights[2]*(J3@J3)
  check('Hermitian '+str((j,a,b,c)),np.allclose(H,H.conj().T,atol=1e-10))
  evals=np.linalg.eigvalsh(H)
  check('uniform collapse majorant '+str((j,a,b,c)),evals.min()+1e-8>=u*j)
  check('strict scalar cutoff '+str((j,a,b,c)),evals.min()+1e-8>=min(weights)*j*(j+1))
  tridiag=np.diag((weights[0]+weights[1])/2*j*(j+1)+(weights[2]-(weights[0]+weights[1])/2)*m*m).astype(complex)
  for q in range(d-2):
   term=(weights[0]-weights[1])/4*math.sqrt((j-m[q])*(j-m[q]-1)*(j+m[q]+1)*(j+m[q]+2))
   tridiag[q+2,q]=term;tridiag[q,q+2]=term
  check('Jacobi exact '+str((j,a,b,c)),np.allclose(H,tridiag,atol=1e-9))
for k in range(300):
 A=(k+1)*(k+4); B=(k+2)*(k+3)
 check('RS transverse reps '+str(k), (k+4)*(k+1)==A)
 check('RS twistor reps '+str(k), (k+3)*(k+2)==B)
 check('RS gap ratios '+str(k),abs((k+2.5)/3*3-(k+2.5))<1e-10)
for n in range(1,101):
 theta=2*math.pi*n/101
 dist=math.sqrt(theta*(2*math.pi-theta))
 check('CC vertical symmetric '+str(n),abs(dist-math.sqrt((2*math.pi-theta)*theta))<1e-12)
res={'source':'Paper1A-Geometry-v5_177.tex','count':checks,'failed':len(failures),'failures':failures[:50],'tests':'analytic identities cross-checked using all j<=21, five anisotropic metric choices; signed Spin4 dimension families k<300; CC phase symmetry', 'note':'Finite controls do not replace the manuscript all-spin proofs or external primary theorem certificates.','sample':records}
(P/'Paper1A-RepairWitness-v1_1.json').write_text(json.dumps(res,indent=2)+'\n')
print('tests',checks,'failed',len(failures),failures[:5]);assert not failures
