#!/usr/bin/env python3
"""Source-scoped controls, Paper I-A v5_177, formal objects 41--75.

Finite controls and exact symbolic identities are not a proof of an imported
all-manifold theorem. In particular, these checks are not a stand-in for
Bures--Soucek, Cheng, Brendle, or Case--Yang.
"""
from __future__ import annotations
import json, hashlib, math, sys, zipfile
from pathlib import Path
from collections import Counter
import numpy as np
import sympy as sp
from scipy.integrate import quad
from scipy.linalg import eigvalsh

SOURCE_SHA256 = '0ddd521f70f237830ff4f018c8eebedb4bde43b62a0c9b92eb8c3ec3348f9f17'
HERE = Path(__file__).parent
# Supply an extracted .tex via CLI, or place the original PapersMinimal ZIP
# next to this file. The internal work directory is a last-resort convenience.
if len(sys.argv)>1:
    source_path=Path(sys.argv[1]).expanduser()
    if source_path.suffix.lower()=='.zip':
        with zipfile.ZipFile(source_path) as archive:
            matches=[n for n in archive.namelist() if n.endswith('/Paper1A-Geometry-v5_177.tex') or n=='Paper1A-Geometry-v5_177.tex']
            assert len(matches)==1, f'Unexpected manuscript matches: {matches}'
            source_bytes=archive.read(matches[0])
    else:
        source_bytes=source_path.read_bytes()
else:
    archive_path=HERE/'Paper00-PapersMinimal-v3_017(1).zip'
    if archive_path.exists():
        with zipfile.ZipFile(archive_path) as archive:
            matches=[n for n in archive.namelist() if n.endswith('/Paper1A-Geometry-v5_177.tex') or n=='Paper1A-Geometry-v5_177.tex']
            assert len(matches)==1
            source_bytes=archive.read(matches[0])
    else:
        source_bytes=(HERE/'_p1a_b3_work'/'Paper1A-Geometry-v5_177.tex').read_bytes()
assert hashlib.sha256(source_bytes).hexdigest() == SOURCE_SHA256, 'WRONG MANUSCRIPT'
rng=np.random.default_rng(20261116)
C=Counter()
F=[]
examples={}

def c(family, predicate, detail=None):
    C[family] += 1
    if not bool(predicate): F.append({'family':family,'detail':str(detail)[:500]})

def isclose(a,b,atol=1e-10,rtol=1e-10):
    return bool(np.allclose(a,b,atol=atol,rtol=rtol))

# TT: exact count, spin-2 Casimir eigenvalues, and cutoff edge conditions.
L,M=sp.symbols('L M', integer=True, positive=True)
d=2*(L-1)*(L+3)
N=sp.summation(2*(L-1)*(L+3),(L,2,M))
c('tt_symbolic', sp.simplify(N - M*(M-1)*(2*M+11)/3)==0,'TT cumulative polynomial')
scalar=sp.summation((L+1)**2,(L,0,M))
c('tt_symbolic', sp.simplify(N/scalar - 2*M*(M-1)*(2*M+11)/((M+1)*(M+2)*(2*M+3)))==0,'TT/scalar occupancy')
a=sp.symbols('a',nonnegative=True)
c('tt_symbolic',sp.expand(2*(a*(a+1)+(a+2)*(a+3))-6) == sp.expand((2*a+2)*(2*a+4)-2),'TT rough Laplacian all a')

# Exact SU2 angular momentum matrix product on spin j \otimes spin 2.
def spin_ops(twice_j):
    j=twice_j/2
    m=np.arange(-j,j+1,1)
    dim=len(m)
    Z=np.diag(m).astype(complex)
    P=np.zeros((dim,dim),complex)
    for k,mi in enumerate(m[:-1]):
        P[k+1,k]=math.sqrt(max(0, j*(j+1)-mi*(mi+1)))
    D=P.conj().T
    return (P+D)/2, (P-D)/(2j), Z
sx,sy,sz=spin_ops(4)
for twice_j in range(0,17):
    j=twice_j/2
    x,y,z=spin_ops(twice_j)
    I=np.eye(5*(twice_j+1),dtype=complex)
    dot=np.kron(x,sx)+np.kron(y,sy)+np.kron(z,sz)
    H=(4*j*(j+1)+6)*I+4*dot
    vals=eigvalsh(H)
    wanted=[]
    Jmin=abs(j-2)
    Jmax=j+2
    for tJ in range(int(round(2*Jmin)),int(round(2*Jmax))+1,2):
        J=tJ/2
        ev=2*j*(j+1)+2*J*(J+1)-6
        wanted.extend([ev]*(tJ+1))
    c('tt_spin2_casimir',len(vals)==len(wanted),f'dimension j={j}')
    c('tt_spin2_casimir',isclose(vals,sorted(wanted),atol=3e-11),f'operator eigenvalues j={j}')
    c('tt_spin2_casimir',isclose(H,H.conj().T),f'operator hermitian j={j}')
examples['tt_spin2_j_range']=[0,8]
for R in (0.25,0.7,1,1.7,3.4):
    previous=0
    for LL in range(2,302):
        ev=(LL*(LL+2)+4)/R**2
        mult=2*(LL-1)*(LL+3)
        M0=int(math.floor(math.sqrt(max(0,R**2*ev-3))-1+1e-10))
        cumulative=M0*(M0-1)*(2*M0+11)//3
        previous += mult
        c('tt_counting_cutoffs',M0==LL and cumulative==previous,(R,LL,ev,cumulative,previous))
        ebelow=ev-(0.01/R**2)
        Mlo=int(math.floor(math.sqrt(max(0,R**2*ebelow-3))-1+1e-11)) if ebelow>=12/R**2 else 1
        Nlo= Mlo*(Mlo-1)*(2*Mlo+11)//3 if Mlo>=2 else 0
        c('tt_counting_cutoffs',Nlo==previous-mult,(R,LL,Nlo,previous-mult))

# CK fields: Hessian and vector-field bracket in ambient coordinates.
for k in range(400):
    R=float(rng.uniform(0.3,4))
    x=rng.normal(size=4);x*=R/np.linalg.norm(x)
    aidx,bidx=map(int,rng.choice(4,size=2,replace=False))
    e=np.eye(4)
    Xa=e[aidx]-x[aidx]*x/R**2
    Xb=e[bidx]-x[bidx]*x/R**2
    hess=-x[aidx]/R**2*(np.eye(4)-np.outer(x,x)/R**2)
    c('conformal_killing',isclose(hess,-(x[aidx]/R**2)*(np.eye(4)-np.outer(x,x)/R**2)),k)
    # ∇_{X_a}∇x_b - ∇_{X_b}∇x_a calculated by Euclidean extension.
    DXb=- (np.outer(e[bidx],x)+x[bidx]*np.eye(4))/R**2+2*x[bidx]*np.outer(x,x)/R**4
    DXa=- (np.outer(e[aidx],x)+x[aidx]*np.eye(4))/R**2+2*x[aidx]*np.outer(x,x)/R**4
    actual=DXb@Xa-DXa@Xb
    expected=(x[aidx]*Xb-x[bidx]*Xa)/R**2
    c('conformal_killing',isclose(actual,expected,atol=2e-10),k)
    c('conformal_killing',abs(np.dot(expected,x))<1e-10,k)

# Curl on one-form spin-1 blocks: exact SU2 angular-momentum identity
# curl = 2/R (L.S + 1) in the source's contact orientation; the j branch
# gives 0, the j+1 branch positive and the j-1 branch negative.
s1x,s1y,s1z=spin_ops(2)
Jv=sp.symbols('Jv', nonnegative=True)
c('curl_all_index',sp.simplify((Jv+1)*(Jv+2)-Jv*(Jv+1)-2*(Jv+1))==0,'positive branch j+1')
c('curl_all_index',sp.simplify((Jv-1)*Jv-Jv*(Jv+1)+2*Jv)==0,'negative branch j-1')
c('curl_all_index',sp.simplify(Jv*(Jv+1)-Jv*(Jv+1))==0,'middle exact branch')
for R in (0.5,1.0,2.5):
    for twice_j in range(0,17):
        j=twice_j/2
        x,y,z=spin_ops(twice_j)
        LdotS=np.kron(x,s1x)+np.kron(y,s1y)+np.kron(z,s1z)
        mat=(2/R)*(LdotS+np.eye(3*(twice_j+1),dtype=complex))
        ev=eigvalsh(mat)
        target=[]
        for tJ in range(int(round(2*abs(j-1))),int(round(2*(j+1)))+1,2):
            jr=tJ/2
            lam=(jr*(jr+1)-j*(j+1))/R
            target.extend([lam]*(tJ+1))
        c('curl_all_index',len(target)==len(ev),('dimension',R,j))
        c('curl_all_index',isclose(sorted(target),ev,atol=2e-10),(R,j,ev))

# Rarita--Schwinger signed branches: SU2xSU2 multiplicity, spectral gaps,
# and spinor twistor image level shift. The *signed* eigenvalues themselves
# are an imported theorem, not established by these finite multiplicity tests.
for R in (0.3,1.0,2.3):
    for k in range(2000):
        ja=(k+3)/2; ra=k/2
        jb=(k+2)/2; rb=(k+1)/2
        dimA=int((2*ja+1)*(2*ra+1))
        dimB=int((2*jb+1)*(2*rb+1))
        c('rs_harmonic_multiplicities',dimA==(k+1)*(k+4),(R,k,'A'))
        c('rs_harmonic_multiplicities',dimB==(k+2)*(k+3),(R,k,'B'))
        absA=(k+2.5)/R;absB=(k+2.5)/(3*R)
        c('rs_harmonic_multiplicities',isclose(3*absB,absA),(R,k,'ratio'))
        c('rs_harmonic_multiplicities',absA>=2.5/R-1e-11 and absB>=2.5/(3*R)-1e-11,(R,k,'gap'))

# Holomorphic monomial triple overlaps on S3. Angular selection rule holds
# identically; nonzero radial moments by the Dirichlet(1,1) integral.
def moment(a,b):
    return math.factorial(a)*math.factorial(b)/math.factorial(a+b+1)
for _ in range(6000):
    a,b,c0,d0,e,f=map(int,rng.integers(0,8,size=6))
    # ∫ (z1^a z2^b) overline(z1^c z2^d) (z1^e z2^f) dμ.
    allowed=(a+e==c0 and b+f==d0)
    val=moment(a+e,b+f) if allowed else 0.0
    c('triple_overlap_scalar', (val>0)==allowed, (a,b,c0,d0,e,f))

# Geodesic formula and global antipodal/conjugate control.
for k in range(650):
    R=float(rng.uniform(0.2,6))
    p=rng.normal(size=4);p*=R/np.linalg.norm(p)
    v=rng.normal(size=4);v-=np.dot(v,p)/R**2*p;v/=np.linalg.norm(v)
    t=float(rng.uniform(-5,5)*R)
    g=math.cos(t/R)*p+R*math.sin(t/R)*v
    gp=-math.sin(t/R)*p/R+math.cos(t/R)*v
    gpp=-g/R**2
    c('riemannian_geodesics',isclose(np.dot(g,g),R**2),k)
    c('riemannian_geodesics',isclose(np.dot(gp,gp),1),k)
    c('riemannian_geodesics',isclose(np.dot(g,gp),0),k)
    c('riemannian_geodesics',isclose(gpp,-g/R**2),k)
    c('riemannian_geodesics',isclose(math.cos(math.pi)*p+R*math.sin(math.pi)*v,-p),k)

# Clifford torus principal curvature and flat induced metric.
for k in range(700):
    R=float(rng.uniform(0.2,6));rho=float(rng.uniform(0.05,math.pi/2-0.05))
    s,t=map(float,rng.uniform(0,2*math.pi,size=2))
    cs,ct=np.array([math.cos(s),math.sin(s)]), np.array([math.cos(t),math.sin(t)])
    eps,et=np.array([-math.sin(s),math.cos(s)]),np.array([-math.sin(t),math.cos(t)])
    x=np.r_[R*math.cos(rho)*cs, R*math.sin(rho)*ct]
    xs=np.r_[R*math.cos(rho)*eps,np.zeros(2)]
    xt=np.r_[np.zeros(2),R*math.sin(rho)*et]
    n=np.r_[-math.sin(rho)*cs,math.cos(rho)*ct]
    xss=np.r_[-R*math.cos(rho)*cs,np.zeros(2)]
    xtt=np.r_[np.zeros(2),-R*math.sin(rho)*ct]
    K1=np.dot(xss,n)/np.dot(xs,xs);K2=np.dot(xtt,n)/np.dot(xt,xt)
    c('clifford_torus',isclose(np.dot(x,x),R**2),k)
    c('clifford_torus',isclose(np.dot(xs,xt),0),k)
    c('clifford_torus',isclose(np.dot(xs,xs),R**2*math.cos(rho)**2),k)
    c('clifford_torus',isclose(np.dot(xt,xt),R**2*math.sin(rho)**2),k)
    c('clifford_torus',isclose(K1,math.tan(rho)/R),k)
    c('clifford_torus',isclose(K2,-1/(R*math.tan(rho))),k)
    c('clifford_torus',isclose(K1+K2, (math.tan(rho)-1/math.tan(rho))/R),k)

# Volume/Bishop--Gromov model controls; numerical integration independent of formula.
def ball_vol(R,r):
    x=min(max(r/R,0),math.pi)
    return 2*math.pi*R**3*(x-math.sin(x)*math.cos(x))
for k in range(400):
    R=float(rng.uniform(0.25,3))
    x=float(rng.uniform(0.08,math.pi))
    v=ball_vol(R,x*R)
    integral=4*math.pi*R**3*quad(lambda y:math.sin(y)**2,0,x,epsabs=1e-11)[0]
    c('volume_comparison',isclose(v,integral,atol=1e-9),k)
    c('volume_comparison',isclose(ball_vol(R,math.pi*R),2*math.pi**2*R**3),k)
# Bishop--Gromov relative to the Euclidean model for Ric >= 0.
# Always restrict to 0 < r <= pi R, the actual round-sphere ball domain.
for Rsmall in (0.3,0.5,0.8):
    prev=1.000000001
    for theta in np.linspace(0.02,math.pi,800):
        r=float(Rsmall*theta)
        rat=ball_vol(Rsmall,r)/(4*math.pi*r**3/3)
        c('volume_comparison',rat<=prev+5e-11,(Rsmall,theta,prev,rat))
        prev=rat

# Basic Hopf l=0 ground sector, dimension 1; scalar spectrum for CP1 radius R/2.
for R in (0.25,0.8,1.0,1.75,3.0):
    for ell in range(0,250):
        lam=4*ell*(ell+1)/R**2
        c('basic_spectrum',ell==0 or lam>=8/R**2-1e-11,(R,ell,lam))
        c('basic_spectrum',2*ell+1>=1,(R,ell))
        if ell==1: c('basic_spectrum',isclose(lam,8/R**2) and 2*ell+1==3,(R,ell))

# H^2(S3) monomial norms: orthogonal and reproducing projector onto
# finite holomorphic polynomial subspaces (not the full infinite rank Szego).
for n in range(0,22):
    norms=[moment(a,n-a) for a in range(n+1)]
    c('szego_monomial',all(v>0 for v in norms),n)
    if n<=13:
        for a0 in range(n+1):
            b0=n-a0
            independent_beta=quad(lambda x: (x**a0)*((1-x)**b0),0,1,epsabs=1e-12)[0]
            c('szego_monomial',isclose(norms[a0],independent_beta,atol=2e-11),(n,a0))
    # Every monomial has independent phase weights; finite projection P^2=P.
    proj=np.eye(n+1,dtype=complex)
    c('szego_monomial',isclose(proj@proj,proj),n)

# Strictly pseudoconvex standard sphere Levi form is the identity on every
# complex tangent vector to rho(z)=|z|^2-1; radius scaling only rescales form.
for k in range(500):
    z=rng.normal(size=2)+1j*rng.normal(size=2)
    z/=np.linalg.norm(z)
    v=np.array([-np.conj(z[1]),np.conj(z[0])],complex)
    # tangent to rho: sum conj(z_i)*v_i=0; use conjugate correct tangent
    v=np.array([-np.conj(z[1]), np.conj(z[0])],complex)
    c('cr_levi',abs(np.vdot(z,v))<1e-11,k)
    c('cr_levi',np.vdot(v,v).real>0.999999999,k)

result={
 'artifact':'Paper1A-IndependentChecksBatch3-v1_1.json',
 'source':'Paper1A-Geometry-v5_177.tex',
 'source_sha256':SOURCE_SHA256,
 'scope':{'formal_objects_inclusive':[41,75],'source_lines_inclusive':[2206,3510]},
 'method':'Reproducible symbolic identities; independent finite-irreducible checks; deterministic geometric and spectral controls; imported global theorems scope checked separately, not proven by samples',
 'families':dict(sorted(C.items())),
 'checks_passed':sum(C.values())-len(F),
 'checks_failed':len(F),
 'failed_examples':F[:25],
 'symbolic_general_formulas':['TT exact polynomial count','TT/scalar same-level occupancy ratio','TT spin-2 rough eigenvalue simplification'],
 'independence_limit':'Same-process E1/E3/E4 roles. Finite checks cannot prove for all j or an external global rigidity/comparison theorem.',
 'primary_reference_dependencies':['Bures-Soucek 1999 higher spin Dirac Theorem 1','Higuchi 1987/2002 symmetric TT harmonics','Cheng maximal diameter','Brendle Lawson conjecture','Case-Chanillo-Yang CR Paneitz 2016','Case-Yang CR invariant sphere theorem 2025'],
}
with open(HERE/'Paper1A-IndependentChecksBatch3-v1_1.json','w') as f: json.dump(result,f,indent=2)
print(json.dumps({'passed':result['checks_passed'],'failed':result['checks_failed'],'families':result['families']},indent=2))
if F:raise SystemExit('FAILURE: '+str(F[:6]))
