# Paper I-A — Rigorous Verification, Batch 1 (v1.3)

**Source:** `Paper1A-Geometry-v5_177.tex` in `Paper00-PapersMinimal-v3_017(1).zip`.
**SHA256:** `0ddd521f70f237830ff4f018c8eebedb4bde43b62a0c9b92eb8c3ec3348f9f17`.
**Method:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4` + source-matched proof-chain guard. Source and original ZIPs were not modified.
**Scope:** 20 of 179 current formal objects, source lines 1–1388, including the full chosen Hopf normalization and the all-spin left-invariant scalar/Hodge/Dirac spectral compiler. Next batch begins at line 1390.
**Status:** batch complete; entire paper `PARTIALLY_AUDITED` until remaining 159 objects have undergone current audit. There are no newly confirmed mathematical gaps in this batch.

## Core proof and independent challenge results

1. **Hopf scales and Chern signs** (`p1:prop:hopf-scale-dictionary`, `p1:prop:contact-normalization`, `p1:prop:base_fiber_ratio`; 125–628). Replayed η₀(X_H)=1, η₀∧dη₀=2 vol_E for the chosen orientation, R-scalings of Δ and D, and c₁=+1 for the reversed base orientation. Independent symbolic integration confirms the contact density, +2π descended curvature, base/fiber ratio 1/(4π), and contact integral 4π²R² (unscaled 4π²). No physical phase-axis uniqueness is claimed.
2. **Marked inversion** (`p1:prop:marked-hopf-inversion-transport`; 500–597). Rechecked dι_q(v)=−q⁻¹vq⁻¹, right-invariant bracket sign and inversion-related opposite left frame. The complete global isometry/intertwining remains `REPRODUCED` (source replay), not independently E3-certified by the finite controls alone.
3. **Milnor reference family** (`p1a:proposition:atlas-milnor-normal-form-0d88235`; 797–844). An Ad-invariant positive inner product diagonalizes by an SO(3) automorphism. The positive triple (a,b,c) is metric-defining reference data, not a derived physical deformation/selector.
4. **Complete scalar compiler** (`p1:thm:general-left-invariant-scalar-spectrum`, `p1:cor:general-spectral-consistency-and-recovery`; 897–1009). The Peter–Weyl block H_j=∑a_i⁻²J_i², step-two weight chains, external multiplicity 2j+1, and uniform Casimir cutoff are internally consistent. The j=1/2 and j=1 graded bands recover the expected round/anisotropic coefficients. The source all-j certificate derives from the algebraic Casimir identity; finite numerical checks alone would not establish completeness.
5. **Hodge and signed Dirac** (`p1:thm:general-left-invariant-hodge-dirac-compiler`, `p1:prop:general-spectral-cutoff-all-operators`; 1011–1195). On 7 metric triples and 15 spin values j∈{0,1/2,…,7}, verified d_j²=0, Δ₀=H_j, Δ₃=H_j, block Hermiticity, Koszul zero-order κ=(a²+b²+c²)/(4abc), Dirac square Pauli identity, round signed multiplicities and proposed conservative lower bounds. Source all-j extension is the Chevalley–Eilenberg/Jacobi and operator norm argument, independent of a finite maximum j.
6. **Heat, Weyl and both singular limits** (`p1:thm:general-spectral-heat-and-limits`; 1197–1332). Verified scalar-curvature formula in two algebraically different forms, round volume and coefficient 8abc/3 in Weyl counting. Source trace-norm convergence follows from a uniform-in-c summable (2j+1)² exp(−t u j) majorant, with u=min(a⁻²,b⁻²)>0. Fresh anisotropic finite-block heat controls approach the c↓0 compressed zero-weight and c→∞ horizontal operators at both t=0.7 and 1.7. Non-commutation with t↓0 is preserved, not treated as a defect.
7. **Isotropy and boundary** (`p1a:proposition:atlas-full-isotropy-forces-roundness-b0fac04`; 1351–1383). Full Ad(SU2) invariance iff a=b=c by the irreducible real three-dimensional isotropy representation. The source says the compiler is mathematical reference material, not a physical metric selection, spectral particle state, interaction or decay mechanism.

**Fresh independent/scoped E4 controls:** 2112 passed, zero failed, across the declared matrices/geometric identities and tested limits. Full analytic scope is justified only where the source provides valid all-j arguments; computations do not establish a physical realization.

## Formal claim disposition (exact current IDs)

| # | Source span | Claim ID | Status |
|---:|---|---|---|
| 1 | 125–181 | `p1:prop:hopf-scale-dictionary` | `VERIFIED` |
| 2 | 431–476 | `p1:prop:contact-normalization` | `VERIFIED` |
| 3 | 487–498 | `p1:conv:global-orientation-signs` | `FORMALIZED` |
| 4 | 500–566 | `p1:prop:marked-hopf-inversion-transport` | `REPRODUCED` |
| 5 | 600–611 | `p1:prop:base_fiber_ratio` | `VERIFIED` |
| 6 | 633–654 | `p1a:theorem:atlas-hopf-map-as-a-riemannian-submersion-b3988b5` | `REPRODUCED` |
| 7 | 663–667 | `UNLABELED:Paper1A:remark:v5_177:663` | `FORMALIZED` |
| 8 | 695–728 | `p1:rem:euler-complex-dictionary` | `FORMALIZED` |
| 9 | 752–757 | `p1:lem:hopf-penalty` | `VERIFIED` |
| 10 | 797–824 | `p1a:proposition:atlas-milnor-normal-form-0d88235` | `VERIFIED` |
| 11 | 846–858 | `UNLABELED:Paper1A:remark:v5_177:846` | `FORMALIZED` |
| 12 | 869–895 | `p1:def:general-spectral-frame` | `FORMALIZED` |
| 13 | 897–936 | `p1:thm:general-left-invariant-scalar-spectrum` | `VERIFIED` |
| 14 | 964–999 | `p1:cor:general-spectral-consistency-and-recovery` | `VERIFIED` |
| 15 | 1011–1063 | `p1:thm:general-left-invariant-hodge-dirac-compiler` | `VERIFIED` |
| 16 | 1121–1152 | `p1:prop:general-spectral-cutoff-all-operators` | `VERIFIED` |
| 17 | 1197–1248 | `p1:thm:general-spectral-heat-and-limits` | `VERIFIED` |
| 18 | 1334–1346 | `p1:rem:general-spectral-compiler-scope` | `FORMALIZED` |
| 19 | 1351–1366 | `p1a:proposition:atlas-full-isotropy-forces-roundness-b0fac04` | `VERIFIED` |
| 20 | 1385–1387 | `UNLABELED:Paper1A:remark:v5_177:1385` | `FORMALIZED` |

**Batch outcome:** {'VERIFIED': 11, 'FORMALIZED': 7, 'REPRODUCED': 2}. These are source-matched prior evidence-backed statuses retained after replay, not 20 new universal independent proofs. Definitions/conventions/remarks are `FORMALIZED` rather than proof-certified.

## Found issue — metadata, not mathematical

**`BH-IA-DAG-000001` — `DAG_ONLY_INTEGRITY`, MINOR.** The active `DAG/AuditLayer/Paper1A-v1_5/README.md` says layer v1.4 and gives older manuscript SHA (`4592ca30…`), with four previously open issues, whereas the current source SHA is `0ddd521f…`, its `Index.json` names v5.177 and `GapRegistry.json` has `current_open_ids=[]`. This is a stale documentation locator/status. **Immediate upstream:** legacy layer documentation. **Conditions:** none. **Verified cross-paper or observable impact:** none. **Remedy after all batches:** synchronize the active README and verify its consistency with the source, index and gap registry in the final newly versioned ZIP. The older resolved issue IDs remain historical and are not reopened.

## Condition / boundary provenance

The root mathematical domains are `R_mom>0`, `a,b,c>0`, `epsilon>0`, together with the **chosen** oriented Hopf marking. They are scoped definitions and conventions, not new framework axioms. No canonical assumptions were introduced in this batch. The local `BND-P1A-B1-001/002` records distinguish constituted smooth reference geometry from a physically selected metric or Hopf axis; neither physical occurrence nor uniqueness of a physical selector follows from a universal matrix compiler.

## Source / DAG integration and caveats

Existing verified-material use-edge records into these 20 objects: **10**; existing claim-route records: **20**. The machine ledger preserves exact SOURCE-AS-PRINTED statements, status evidence, typed edges and proof route references, without re-promoting citation-only edges.

All checks were carried out as sequential source replay, separate mathematical computation, and adversarial sample/normalization passes **within a single execution**. No claim of coordinated independent human or Work agents is made. No new physical theorem, paper edit or PDF creation was performed.

**Artifacts retained for final integration:** `Paper1A-RigorousVerificationBatch1Ledger-v1_3.json`, `Paper1A-IndependentChecksBatch1-v1_1.json`, and script `Paper1A-IndependentChecksBatch1-v1_1.py`.
**Final delivery only:** create version-incremented global DAG and proof-chain-audits ZIPs after the remaining batches, preserving other papers’ latest audit files and removing duplicate obsolete active copies as allowed by the release contract.
