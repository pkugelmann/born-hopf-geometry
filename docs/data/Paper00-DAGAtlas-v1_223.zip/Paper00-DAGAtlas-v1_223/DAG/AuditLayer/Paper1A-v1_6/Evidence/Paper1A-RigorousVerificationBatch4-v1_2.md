# Born–Hopf Paper I-A — Rigorous Verification DAG, Batch 4

**Frozen source:** `Paper1A-Geometry-v5_177.tex`, SHA-256 `0ddd521f70f237830ff4f018c8eebedb4bde43b62a0c9b92eb8c3ec3348f9f17` (the exact file in `Paper00-PapersMinimal-v3_017(1).zip`).  
**Protocols:** RigorousVerificationDAG v2.4, ProofChainAudit v1.1.  
**Baseline:** `Paper00-DAGAtlas-v1_150(1).zip`, `Paper00-ProofChainAudits-v1_64.zip`.

**Exact coverage:** formal objects **76–116** (41/179); current source **lines 3512–4865**. The next object #117 is `p1:thm:scalar-band-evaluation-povm` at **line 4867**. Cumulative audited **116/179 = 64.8%**. This is an incremental audit, not the final archive release; manuscript/macro/bibliography/original ZIP unchanged.

## Adjudicated result

| Status | Batch 4 | Cumulative #1–116 |
|---|---:|---:|
| `VERIFIED` | 23 | 66 |
| `REPRODUCED` | 4 | 18 |
| `FORMALIZED` | 14 | 32 |
| `UNRESOLVED` | 0 | 0 |

**New confirmed mathematical gaps: 0. Newly established DAG-only issue: `BH-IA-DAG-000002` (moderate); existing `BH-IA-DAG-000001` persists with newly identified broken index links.** These are distinct from mathematical counterexamples. **E3/E4 verification controls: 5,857 passed, 0 failed** after correcting an internal harness test, across 25 test families. Source statements match the current TeX bytes for all 41 objects.

## Mathematical verification and evidence ceiling

### A. Spin, Clifford and quaternionic geometry (#76–87)

The uniqueness of the spin structure follows from parallelizability of S³ and H¹(S³;Z₂)=0. An exact matrix-algebra certificate realizes Cl₃,₀ in 2×2 complex matrices using three Pauli generators; its eight Clifford monomials are real-linearly independent. A second exact construction sends Cl₀,₃ to H⊕H, with eight independent monomials, correct central volume-element signs, and quaternionic even subalgebras. The **Clifford sign conventions are deliberately different**: the Riemannian spinor convention has c(v)²=−|v|² and is not an assertion that Cl₃,₀ and Cl₀,₃ are isomorphic real algebras. The ABS/Bott eightfold *global* module periodicity remains a referenced standard theorem, not inferred from the dimension-three check.

Quaternion multiplication, its radius-dependent transported product, left Hopf U(1) fibers, right actions, and the kernel {±1} of the quaternionic spin cover were checked with exact rational arithmetic. At general radius R>0, the identity of the transported product is R, and the inverse is the quaternion conjugate. The isometry result Isom(S³(R))=O(4) follows from the source's **one-jet rigidity argument**, not just from the obvious embedding O(4)⊂Isom(S³).

Borel–Weil on CP¹ has a complete independent low-rank SU(2) proof: the sections of O(n) are exactly degree-n homogeneous polynomials on C², acted on by the contragredient SU(2), with dimension n+1 and irreducibility from the raising/lowering action. This supports lifting #85 from `REPRODUCED` to `VERIFIED`; similarly #84 and #86 gain exact source-specific proofs using quaternionic projectivization and the already checked Chern-number convention. **Duality caution:** an invariant Hermitian inner product alone gives an antilinear Riesz identification; a complex-linear SU(2) self-duality intertwiner uses the invariant alternating two-form, which exists in this SU(2) setting. This does not change the true Borel–Weil representation statement.

### B. Hopf-marked shell symbol and projective normal forms (#88–98)

The map β_H compares two homogeneous **rotation-sphere** quotients through projection ΔSU(2)→SU(2)_R and maps their selected isotropy circles. It is not the Hopf map S³→S². The shell-symbol theorem identifies End(Symᵏ C²) with the scalar harmonic shell Eₖ(S³), and sends each matrix A to its coherent-state expectation on the selected CP¹. The projector is independent of a local phase, and the symbol is injective: in an affine coordinate w, matrix entries are proportional to the distinct monomials wᵇ \bar{w}ᵃ/(1+|w|²)ᵏ. Angular Fourier modes d=b−a separate, while their radial powers are independent by a Vandermonde determinant. For all k≥0 this gives (k+1)² independent coefficients. Clebsch–Gordan then enforces the **complete** degree window l=0,…,k on S². Finite full-rank tests through k=6 corroborate the analytic derivation.

The scope barrier is essential: ordinary Hopf pullback of base degree-l harmonics occupies the even scalar shell k=2l; it does *not* implement the reconstructive shell-symbol map. The Möbius hyperbolic normal form, order-three elliptic generator, and Cayley transform were checked by exact rational/algebraic identities with fixed points, parameter ranges and projective normalization retained.

### C. Finite Spin(4) module and level-one checkpoint (#99–104)

For m≥0 the finite carrier is the **full sum of SU(2)_L×SU(2)_R irreps** with j_L+j_R≤m, not the scalar Peter–Weyl diagonal sum. Exact finite-sum reductions give

\[
  \dim\mathcal H_m=\binom{2m+4}{4},\quad
  \dim_\CC\mathcal A_m
  =\frac{(n+1)(n+2)(n+3)(n+4)(2n^2+10n+15)}{360},\quad n=2m.
\]

The equivariant commutant has dimension C(n+2,2), while the **full** endomorphism algebra has dimension C(n+4,4)²; these are not the block-preserving algebra. At m=1 the six irreps have dimensions 1,2,2,4,3,3; hence **dim H₁=15**, **dim A₁=43**, and **dim commutant=6**. Exact Casimir labels, the vector tensor-square split 10+6 and faithfulness of S₊⊕S₋ were checked. The mathematical representation package does not itself assert physical occurrence.

### D. 3-Sasakian geometry, flat cone, Sobolev and heat kernel (#105–116)

The source restricts “3-Sasakian” at dimension 3 to conventions that admit n=0; other usage is explicitly acknowledged. The flat cone over the Einstein-normalized unit round sphere is isometric to R⁴ minus the origin, with three closed Kähler 2-forms. Direct exterior algebra verifies dω_a=0 and ω_a∧ω_b=±2δ_ab vol (sign controlled by chosen orientation). Radial homothety gives the positive four-covector-density character s⁴. None of this is a new 4D dynamical/physical mechanism.

The general compact **3-dimensional 3-Sasakian rigidity** statement is valid under the stated 3-Sasakian and quotient-preservation hypotheses: an orthonormal Sasakian triple yields Ric=2g, and in dimension three the Einstein condition forces sectional curvature 1. Compact completeness then yields spherical space forms. The global theorem remains cited/imported, and it must not be “proved” in the DAG by the existence of just one standard S³ example. This is the DAG-only finding below.

For the unit sphere, Beckner's sharp inequality has coefficient 4/3 before the energy and 1 before the L² term under Haar probability. Exact homothety gives the manuscript's sharp Riemannian-volume coefficients 4/[3(2π²)^(2/3)] and 1/[(2π²)^(2/3)R²]. Independent high-precision zonal quadrature reproduces equality on the entire tested conformal family at multiple radii, while off-family controls are strictly unequal. The **global all-W¹,² sharp inequality/equality theorem is retained as an imported result**, not proven by quadrature. Primary input: William Beckner, *Annals of Mathematics* 138 (1993), 213–242, https://annals.math.princeton.edu/1993/138-1/p05 .

The Hopf map to the base radius R/2 is a Riemannian submersion with geodesic minimal fibers; harmonic-morphism status uses the imported Fuglede–Ishihara characterization. For the heat kernel, the source's zonal factor is the SU(2) character sin((k+1)θ)/sin θ with coefficient (k+1)/Vol. On the diagonal this becomes (k+1)²/Vol, while the antipodal limit is (−1)ᵏ(k+1). Orthogonality makes its integral equal one (only k=0 survives). Numerical trace and endpoint checks support the complete spectral formula.

### E. Two uncensused reference tables in this span

The advanced geometry table (lines 4341–4451) and analytic-consequences table (lines 4459–4573) restate mathematical inputs already proved, imported, or addressed by other formal objects. Their named proof references were tracked. In particular the later Dirac perturbation/stability row is **not silently declared audited in this batch**; it awaits its source formal object later in the paper.

## All distinct issues (source-anchored)

**`BH-IA-DAG-000001` — prior documentation/index integrity issue, unresolved.** Active `Paper1A-v1_5/README.md` gives older v1.4/source-hash/open-issue wording; the current DAG index contains v1_125 combined-layer paths that are *absent* from the input v1_150 ZIP. The actual active combined graph is `DAG/CombinedGraphIndex-v1_150.json`; material edges reside in `DAG/CombinedMaterialEdges-v1_140.json`. One stale Berger-decoupling source line locator had already been found in Batch 3. This is a link/version documentation defect. **Mathematical impact:** no source-paper refutation; global query entrypoints must be reconciled at the final release. Earlier classification minor is retained for metadata, with moderate graph-index integration risk now demonstrated.

**`BH-IA-DAG-000002` — new unsupported material premise edge, moderate DAG coverage issue.** Source: lines **4606–4614**, `p1:cor:3sasakian-rigidity`; atlas edge **`BH-IA-V176-EDGE-0030`** currently says `p1:thm:round-s3-3sasakian-model` `PREMISE_OF` the universal compact rigidity claim. The **source proof instead imports general three-dimensional 3-Sasakian rigidity**; existence of an example never supplies universality. The inherited edge's witness line 4613 is only *“This is standard 3-dimensional 3-Sasakian rigidity in the normalized scale”*. It does not consume the example theorem as a premise. **Proof-route impact:** incorrect ancestry into `p1:cor:3sasakian-rigidity`; source theorem remains supported by the independent general Einstein/3D space-form route. Combined material-edge index has no certified outgoing descendant from this corollary, hence **no proven downstream cross-paper impact**. **Required final action:** quarantine/retype the edge as non-traversable candidate and register the true imported-theorem route; do not alter paper source.

**Mathematical defects:** none confirmed. **Conditional/imported results:** #105, #107, #111, #113 retain exact restrictions, not labeled false. **Missing source evidence:** none confirmed in the examined claims. **DAG integrity/coverage defects:** both issues above; keep separate from source truth.

## Claim-by-claim disposition

| # | Lines | Source object | Verdict | Source-matched audit finding |
|---:|---:|---|---|---|
| 76 | 3512–3517 | `(unlabeled remark)` | **FORMALIZED** | CR rigidity does not imply Riemannian round-metric uniqueness; scope and pseudo-Einstein normalization retained. |
| 77 | 3527–3535 | `p1a:theorem:atlas-the-3-sphere-admits-a-unique-spin-structure-as-7608b1a` | **VERIFIED** | H¹(S³;Z₂)=0, together with parallelizability, gives unique spin structure; SU(2)≅Spin(3). |
| 78 | 3548–3566 | `p1a:theorem:atlas-algebraic-structure-b08f94a` | **VERIFIED** | Explicit Pauli realization of Cl(3,0) as M₂(C) and quaternion-pair realization of Cl(0,3) as H⊕H; eight real basis elements, correct even algebra. |
| 79 | 3611–3614 | `p1:def:quaternions` | **FORMALIZED** | Quaternion generator, conjugation and norm definitions; positive norm and multiplication convention specified. |
| 80 | 3616–3632 | `p1:prop:scaled-unit-quaternions` | **VERIFIED** | Multiplicative quaternion norm, R-scaled product and inverse confirmed including R≠1. |
| 81 | 3642–3647 | `p1:prop:isom-s3-so4` | **VERIFIED** | One-jet injectivity plus ambient orthogonal isotropy O(3) yields full isometry group O(4). |
| 82 | 3691–3696 | `(unlabeled remark)` | **FORMALIZED** | Right inclusion requires one-jet determination; scope reminder, no separate global theorem. |
| 83 | 3700–3708 | `p1:prop:unit-quaternion-left-right-actions` | **VERIFIED** | Left common-phase/right quaternion actions commute, preserve radius and induced metric. |
| 84 | 3752–3763 | `p1:thm:quat-projline` | **VERIFIED** | A right quaternionic line, after a compatible I, is a complex 2-plane and P_C=CP¹; chosen I is not canonical. |
| 85 | 3780–3788 | `p1:thm:borel-weil-cp1` | **VERIFIED** | Homogeneous degree-n polynomials on C² are H⁰(CP¹,O(n)); SU(2) lowering/raising generates the irreducible (n+1)-dimensional irrep, with dual action convention. |
| 86 | 3795–3813 | `p1:cor:cp1-geometric-quantization` | **VERIFIED** | Earlier Hopf curvature c₁=+1 and Borel–Weil give the stated integer-k prequantization; no physical band selector inferred. |
| 87 | 3819–3826 | `(unlabeled remark)` | **FORMALIZED** | Contragredient/dual convention distinguished; SU(2) self-duality uses its invariant alternating form for a complex-linear intertwiner. |
| 88 | 3828–3855 | `p1:prop:hopf-marked-diagonal-base-comparison` | **VERIFIED** | Diagonal projection onto the right SU(2) factor maps the same U(1) stabilizer and gives a homogeneous-quotient isomorphism, not π. |
| 89 | 3868–3918 | `p1:thm:hopf-marked-diagonal-shell-symbol` | **VERIFIED** | Coherent-projector symbol is globally well-defined and injective; angular Fourier/radial Vandermonde route independently proves full (k+1)² rank; CG yields l=0..k window. |
| 90 | 3956–3969 | `p1:rem:shell-symbol-not-hopf-pullback` | **FORMALIZED** | Ordinary basic Hopf pullback gives only even shells k=2l, not the full shell-symbol reassembly. |
| 91 | 3971–3973 | `(unlabeled remark)` | **FORMALIZED** | Chern-class convention follows the chosen Hopf fiber/base orientation; O(1) vs tautological O(-1) sign tracked. |
| 92 | 3991–3996 | `(unlabeled remark)` | **FORMALIZED** | Pauli Bloch map is phase invariant; matches the fixed quaternionic Hopf map after an SO(3) basis rotation. |
| 93 | 4011–4020 | `p1:thm:hyperbolic-normal-form` | **VERIFIED** | Normalized positive-trace hyperbolic matrices have trace²>4 and fixed points ±1; positive t is recovered uniquely from trace²; conjugacy follows real eigenspaces. |
| 94 | 4036–4044 | `p1:thm:z3-elliptic` | **VERIFIED** | Multiplication by e^{2πi/3} has projective order 3, two fixed points, and a determinant-one representative. |
| 95 | 4075–4088 | `p1:thm:cayley` | **VERIFIED** | Cayley transform from unit circle minus 1 onto R, w=-cot(φ/2), checked with exact rational parametrization and u=w². |
| 96 | 4101–4109 | `p1:thm:unit-quaternion-double-cover-so3` | **VERIFIED** | Quaternion conjugation yields determinant-one orthogonal action on Im(H), surjective rotation covering, kernel ±1. |
| 97 | 4118–4140 | `p1:cor:left-invariant-global-frame-s3` | **VERIFIED** | e_a(p)=p·i_a is tangent, global and has norm R; bracket and opposite-frame conventions checked. |
| 98 | 4147–4155 | `(unlabeled remark)` | **FORMALIZED** | Choice-dependence of Hopf axis distinguished from intrinsic group structure and parallelizability. |
| 99 | 4175–4188 | `p1:def:spin4-truncation` | **FORMALIZED** | Defines the full non-diagonal Spin(4) representation cutoff and sector-preserving block operator algebra; integer m≥0. |
| 100 | 4190–4195 | `p1:rem:scalar-vs-spin4` | **FORMALIZED** | Explicit exclusion: the scalar Peter–Weyl space includes only diagonal sectors; non-diagonal summands are abstract Spin(4) representation carriers. |
| 101 | 4197–4205 | `p1:prop:dimHm` | **VERIFIED** | Exact double-sum identity dim H_m=C(2m+4,4) for all nonnegative integers m. |
| 102 | 4222–4243 | `p1:prop:block-algebra-dimensions` | **VERIFIED** | Exact generating function yields dim A_m; full End and equivariant commutant are distinct, with multiplicity-one Schur blocks. |
| 103 | 4267–4277 | `p1:cor:H1-structure` | **VERIFIED** | At m=1 exactly six irreps of dimensions 1,2,2,4,3,3 sum to 15; A₁=43 and commutant=6. |
| 104 | 4284–4319 | `p1:prop:spin4-low-degree-dictionary` | **VERIFIED** | Spin(4) dimensions, Casimirs, symmetric/antisymmetric vector tensor-square, and Dirac faithfulness checked. |
| 105 | 4579–4591 | `p1:thm:round-s3-3sasakian-model` | **REPRODUCED** | 3-Sasakian S³ statement carries the n=0 convention caveat; flat quaternionic cone independently corroborated, classification imported. |
| 106 | 4601–4604 | `(unlabeled remark)` | **FORMALIZED** | Explanatory bridge to the hyper-Kähler cone, without a separate physical curvature mechanism. |
| 107 | 4606–4610 | `p1:cor:3sasakian-rigidity` | **REPRODUCED** | Three Sasakian Reeb fields provide Ric=2g in dimension three; 3D Einstein is constant sectional curvature. Global quotient and automorphism scopes require imported global theorem. The single S... |
| 108 | 4620–4628 | `p1:thm:hyperkahler-cone` | **VERIFIED** | Explicit closed 2-form triple from dθ_i=-2θ_j∧θ_k plus polar Euclidean cone proves flat hyper-Kähler realization and orientation conventions. |
| 109 | 4658–4666 | `p1:cor:flat-cone-canonical-scale` | **VERIFIED** | Flat Euclidean cone has no independent cone curvature invariant; direct consequence of #108. |
| 110 | 4672–4691 | `p1:cor:flat-cone-four-density-homothety` | **VERIFIED** | Under r↦sr all four orthonormal covectors scale by s; absolute top-density character is s⁴ for s>0. |
| 111 | 4709–4730 | `p1:thm:beckner-sobolev-s3` | **REPRODUCED** | Source rescaling from probability-measure Beckner exactly reproduces both sharp constants; equality profiles matched by independent angular quadrature. All W¹,² global sharpness is imported. |
| 112 | 4773–4775 | `(unlabeled remark)` | **FORMALIZED** | Euclidean tangent blow-up is qualitative remark in regime much smaller than R, not a separate exact norm equality. |
| 113 | 4781–4791 | `p1:thm:hopf-harmonic-morphism` | **REPRODUCED** | With base radius R/2 Hopf map is a Riemannian submersion with geodesic minimal fibers; Fuglede/Ishihara harmonic-morphism criterion is imported. |
| 114 | 4803–4823 | `p1:thm:heat-kernel-s3` | **VERIFIED** | Peter–Weyl SU(2) characters and zonal addition kernel give heat series; diagonal, antipodal, k=0 and spectrum multiplicities independently controlled. |
| 115 | 4852–4860 | `(unlabeled remark)` | **FORMALIZED** | Markov kernel integrates to one because only k=0 shell has nonzero average; t down to zero is distributional. |
| 116 | 4862–4865 | `(unlabeled remark)` | **FORMALIZED** | Camporesi comparison correctly distinguishes eigenvalue multiplicity (k+1)² from zonal addition coefficient k+1. |


## Source-replayed DAG dependencies and release checkpoint

Of the nine existing typed source-associated edges touching this batch, **eight** have source-matched proof-use witnesses. Edge `BH-IA-V176-EDGE-0030` is the sole rejected material witness. The ledger additionally records **six** reviewed candidate material links to be merged only after final graph validation (Hopf-marking, finite truncation definition, hyper-Kähler cone corollaries, and Hopf minimal fibers). A citation-only or candidate record is never proof-traversable before adjudication.

The global graph retains canonical claim/condition IDs; **no new foundation axiom, physical carrier mechanism, or duplicate condition node** was created. The single-runtime audit independently replayed source E1, checked source-independent algebra E3, and ran boundary/counterexample controls E4. These are functional evidence checks, **not falsely advertised as independent parallel agents**.

**Final-release policy:** do not mutate the supplied archives in an intermediate batch. At completion of the remaining formal objects, merge all batch ledgers and reviewed edges into the active graph; preserve existing unrelated material; remove stale/duplicate versions and close the index consistency errors; emit post-write-reopened **`Paper00-DAGAtlas-v1_151.zip`** and **`Paper00-ProofChainAudits-v1_65.zip`**, containing only the latest active named versions plus needed provenance under the proper archive structures. If the final release validation fails, disclose it rather than labeling the artifacts verified.
