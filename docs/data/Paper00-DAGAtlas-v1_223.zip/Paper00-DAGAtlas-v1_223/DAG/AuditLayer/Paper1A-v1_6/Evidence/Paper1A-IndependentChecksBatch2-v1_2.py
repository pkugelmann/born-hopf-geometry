#!/usr/bin/env python3
"""Independent, bounded-scope numerical and exact checks of Paper I-A v5.177
source lines 1390--2205, formal objects 21--40.  Does not import Batch 1 checks.
The E1 universal proofs and externally imported theorems are assessed separately.
"""
import json, hashlib, math
from collections import Counter
from pathlib import Path
import numpy as np
import scipy.linalg as la
import sympy as sp

SRC=Path('/mnt/data/bh_audit_work/source/Paper1A-Geometry-v5_177.tex')
HASH='0ddd521f70f237830ff4f018c8eebedb4bde43b62a0c9b92eb8c3ec3348f9f17'
assert hashlib.sha256(SRC.read_bytes()).hexdigest()==HASH
COUNTS=Counter();MAX_ERROR={};RECORDS=[]
def ck(group, condition, residual=None, metadata=None):
    ok=bool(condition); COUNTS[group+('::PASS' if ok else '::FAIL')]+=1
    if residual is not None:
        MAX_ERROR[group]=max(float(abs(residual)), MAX_ERROR.get(group,0.0))
    if not ok: raise AssertionError((group,residual,metadata))

# Normalization-matched SU(2) generator algebra and global BR cutoff.
i=1j
p1=np.array([[0,1],[-1,0]],complex)/2
p2=np.array([[0,i],[i,0]],complex)/2
v=np.array([[i,0],[0,-i]],complex)/2
for A,B,C in [(p1,p2,v),(p2,v,p1),(v,p1,p2)]:
    ck('BR_normalized_su2_bracket',la.norm(A@B-B@A-C)<1e-12,la.norm(A@B-B@A-C))
    ck('BR_normalized_killing_norm',abs((-2*np.trace(A@A)).real-1)<1e-12)
for R in (0.61,1.,3.1):
  for z in (-8.1,-4,-2,-1,-.1,0,.1,.5,1,2,4,8.1):
    for angle in (0,.33,1.2,2.6):
      U=math.cos(angle)*p1+math.sin(angle)*p2
      tcut=2*math.pi/math.sqrt(1+z*z)
      gt=la.expm(tcut*(U+z*v))@la.expm(-tcut*z*v)
      ck('BR_geodesic_unitary',la.norm(gt@gt.conj().T-np.eye(2))<2e-12)
      ck('BR_vertical_cut_endpoint',abs(gt[0,1])<2e-12,abs(gt[0,1]))
      theta=float(np.angle(gt[0,0]))%(2*math.pi)
      dbr=2*math.sqrt(theta*(2*math.pi-theta))
      ck('BR_vertical_distance_full_period',abs(tcut-dbr)<2e-7,abs(tcut-dbr),{'R':R,'z':z,'theta':theta})
      ck('BR_radius_scaling',abs((R/2*tcut)-(R*math.sqrt(theta*(2*math.pi-theta))))<1e-7)
      ck('BR_inversion_symmetric_angle',abs(dbr-2*math.sqrt((2*math.pi-theta)*theta))<1e-12)

# Exact Heisenberg normalized bracket, and anisotropic homogeneity.
x,y,z=sp.symbols('x y z', real=True)
X=sp.Matrix([1,0,-y/2]); Y=sp.Matrix([0,1,x/2])
coord=[x,y,z]; bracket=sp.Matrix([sum(X[j]*sp.diff(Y[k],coord[j])-Y[j]*sp.diff(X[k],coord[j]) for j in range(3)) for k in range(3)])
ck('heisenberg_bracket_exact',bracket==sp.Matrix([0,0,1]))
kappa=sp.symbols('kappa',nonzero=True)
# z=t/kappa => d/dt=(1/kappa)d/dz; coefficients become +/-1/2.
ck('heisenberg_vertical_rescale_exact',sp.simplify(kappa*(-y*kappa/2)/kappa**2+y/2)==0)
ck('homogeneous_hdim_is_4',1+1+2==4)

# SU(2) representation spectra and charge sectors, independently from matrix eigenvalues.
def Jvec(twice_j):
  j=twice_j/2.; ms=np.arange(-j,j+1);d=twice_j+1
  raising=np.zeros((d,d),complex)
  for h,m in enumerate(ms[:-1]):raising[h+1,h]=math.sqrt((j-m)*(j+m+1))
  return [(raising+raising.conj().T)/2,(raising-raising.conj().T)/(2j),np.diag(ms)]

for R in (0.61,1.,2.4):
 for k in range(0,51):
   q_values=list(range(-k,k+1,2))
   ck('hopf_charge_weight_parity',(len(q_values)==k+1) and all((k-q)%2==0 for q in q_values))
   ck('hopf_charge_total_multiplicity',sum(k+1 for q in q_values)==(k+1)**2)
   if k<=15:
     J=Jvec(k)
     op=(4/R**2)*(J[0]@J[0]+J[1]@J[1]); spectrum=np.sort(la.eigvalsh(op))
     expected=np.sort([(k*(k+2)-q*q)/(R**2) for q in q_values])
     err=np.max(abs(spectrum-expected));ck('horizontal_su2_matrix_spectrum',err<2e-11,err)
     full=(4/R**2)*sum(M@M for M in J)
     ck('round_scalar_casimir_matrix',la.norm(full-(k*(k+2)/R**2)*np.eye(k+1))<2e-11)
   for q in q_values:
     ck('horizontal_nonnegative',(k*(k+2)-q*q)>=0)
     ck('charge_gap_min_k',k>=abs(q) and (k-abs(q))%2==0)

# Exact heat trace factorization independent double sum vs single sinh sum.
for s in (.7,.23,.1,.05,.025):
    maxAB=int(math.ceil(22/(2*s)))
    aa=np.arange(maxAB+1,dtype=float)
    uv=(2*aa[:,None]+1)*(2*aa[None,:]+1)
    hdouble=float(np.sum((aa[:,None]+aa[None,:]+1)*np.exp(-s*(uv-1))))
    odd=2*aa+1
    hsingle=float(np.sum(np.exp(s)/2*odd/np.sinh(s*odd)))
    err=abs(hdouble-hsingle);ck('horizontal_heat_double_sum_vs_sinh',err<2e-8,err)
    RECORDS.append({'s':s,'heat_double':hdouble,'heat_sinh':hsingle,'s2_heat':s*s*hdouble,'limit_pi2_over16':math.pi**2/16})
# fixed Hopf q heat coefficient, 4D heat and 2D charge dimension are distinct UV limits.
for q in (0,1,3,8):
  hs=[]
  for s in (.06,.03,.015,.0075):
    ks=np.arange(abs(q),abs(q)+5000,2)
    h=float(np.sum((ks+1)*np.exp(-s*(ks*(ks+2)-q*q))))
    expected=1/(4*s)
    ck('fixed_charge_heat_approx_small_s',abs(h/expected-1)<.15)
    hs.append((s,h*s))
  ck('fixed_charge_heat_coefficient_convergence',abs(hs[-1][1]-.25)<abs(hs[0][1]-.25))
  RECORDS.append({'q':q,'fixed_charge_s_times_heat':hs})

# N_H exact-count coefficient via divisor-sum approach: positive Tauberian relation.
def nh(L):
  target=L+1; n=0
  # eigenvalue (2a+1)(2b+1)-1<=L, mult=a+b+1
  for a in range((target-1)//2+1):
    B=(target//(2*a+1)-1)//2
    if B>=0:n+=(B+1)*(a+1)+B*(B+1)//2
  return n
for L in (50,100,250,500,1000,2500,5000,10000):
  val=nh(L); c=math.pi**2/32;rat=val/(c*L**2)
  ck('horizontal_count_ratio_bounded',.75<rat<1.5)
  RECORDS.append({'count_cutoff':L,'count_exact':val,'ratio_to_asymptotic':rat})
ck('horizontal_count_asymptotic_improves',abs(nh(10000)/(math.pi**2/32*10000**2)-1)<abs(nh(250)/(math.pi**2/32*250**2)-1))

# Exterior algebra/Chevalley-Eilenberg/Hodge 1-form spectrum from matrices,
# not lifted from previous batch scripts.
eps=[]
for h in range(3):
    M=np.zeros((8,8),float)
    for mask in range(8):
        if (mask>>h)&1==0:
            M[mask|(1<<h),mask]=(-1)**((mask & ((1<<h)-1)).bit_count())
    eps.append(M)
iota=[M.T for M in eps]
for R in (.5,1,2.3):
 for k in range(0,17):
   j=k/2.;J=Jvec(k);D=k+1
   C=np.zeros((3,3,3))
   for a,b,c in ((0,1,2),(1,2,0),(2,0,1)):
     C[a,b,c]=2/R;C[b,a,c]=-2/R
   A=[(-2j/R)*M for M in J]
   dM=sum(np.kron(eps[a],A[a]) for a in range(3))
   dM-=.5*sum(C[a,b,c]*np.kron(eps[a]@eps[b]@iota[c],np.eye(D)) for a in range(3) for b in range(3) for c in range(3))
   ck('round_form_CE_d2',la.norm(dM@dM)<2e-10)
   L=dM@dM.conj().T+dM.conj().T@dM
   inds=[mask*D+m for mask in (1,2,4) for m in range(D)]
   L1=L[np.ix_(inds,inds)]
   got=np.sort(la.eigvalsh(L1))
   predicted=[((2*j+2)/R)**2]*(k+3)
   if k>0:predicted.extend([(4*j*(j+1)/R**2)]*(k+1))
   if k>=2:predicted.extend([((2*j)/R)**2]*(k-1))
   ck('round_hodge1_total_block_dim',len(predicted)==3*(k+1))
   err=np.max(abs(got-np.sort(predicted)))
   ck('round_hodge1_exact_coexact_block',err<3e-10,err,{'R':R,'k':k})
   # All-spin Casimir alternative (Weitzenbock), tested as an OPERATOR, not just eigenvalues.
   # (S_i)_{ab}=-i epsilon_{iab}, spin-1 frame-index representation.
   S=[]
   for a in range(3):
       smat=np.zeros((3,3),complex)
       for b,c,d in ((0,1,2),(1,2,0),(2,0,1)):
           if a==b:smat[c,d]=-1j;smat[d,c]=1j
       S.append(smat)
   JS=sum(np.kron(S[a],J[a]) for a in range(3))
   identity1=np.eye(3*D)
   casimir=(4/R**2)*((j*(j+1)+1)*identity1+JS)
   residual=la.norm(L1-casimir)
   ck('hodge1_weitz_casimir_operator_identity',residual<3e-10,residual,{'R':R,'k':k})
   # The Hopf contact orientation is opposite the frame e1^e2^e3; curl_Hopf = -(*de)_frame.
   oneinds=[h*D+m for h in (1,2,4) for m in range(D)]
   twoinds=[h*D+m for h in (3,5,6) for m in range(D)]
   de10=dM[np.ix_(twoinds,oneinds)]
   # *frame(12)=3; *frame(13)=-2; *frame(23)=1, using bit masks 3,5,6.
   starframe=np.zeros((3,3),complex)
   starframe[2,0]=1;starframe[1,1]=-1;starframe[0,2]=1
   curlhopf=-np.kron(starframe,np.eye(D))@de10
   predicted_curl=(2/R)*(JS+identity1)
   residualcurl=la.norm(curlhopf-predicted_curl)
   ck('hopf_oriented_curl_operator_identity',residualcurl<3e-10,residualcurl,{'R':R,'k':k})
   # Curl on the coexact branches, consistent with left-right chirality signs.
   cres=la.norm(curlhopf@curlhopf-casimir)
   # Does NOT equal Delta on the exact branch; tested as a projected statement below.
   projection_exact=dM[np.ix_(oneinds,range(D))]
   ck('curl_annihilates_exact_one_forms',la.norm(curlhopf@projection_exact)<3e-10)
   # Round Dirac from connection and coupling; full signed branch with multiplicities.
   sig=[np.array([[0,1],[1,0]],complex),np.array([[0,-1j],[1j,0]],complex),np.array([[1,0],[0,-1]],complex)]
   dirac=(2/R)*sum(np.kron(sig[a],J[a]) for a in range(3)) +3/(2*R)*np.eye(2*D)
   ds=la.eigvalsh(dirac);e=[(k+1.5)/R]*(k+2)
   if k>0:e.extend([-(k+.5)/R]*k)
   ck('round_spin_signed_block_dim',len(e)==2*(k+1))
   ck('round_spin_signed_block',max(abs(np.sort(ds)-np.sort(e)))<2e-11)
   sigmaJ=sum(np.kron(sig[a],J[a]) for a in range(3))
   conn_lap=(4*j*(j+1)*np.eye(2*D)+2*sigmaJ+0.75*np.eye(2*D))/R**2
   lich_res=la.norm(dirac@dirac-conn_lap-1.5/R**2*np.eye(2*D))
   ck('spin_lichnerowicz_operator_identity',lich_res<5e-10,lich_res)
   ck('lichnerowicz_positive_gap',min(ds**2) >=1.5/R**2-1e-10)

# Scalar Weyl function, floor thresholds and sharp asymptotic error O(lambda).
for R in (.5,1.,2.2):
  for k in range(0,51):
    lam=k*(k+2)/R**2
    m=math.floor(math.sqrt(1+R*R*lam)-1+1e-11)
    ck('scalar_count_floor_exact_at_eig',m==k)
    closed=(m+1)*(m+2)*(2*m+3)//6
    ck('scalar_count_sum_squares',closed==sum((n+1)**2 for n in range(m+1)))
    if k>=2:
       mid=(lam+(k-1)*(k+1)/R**2)/2
       mm=math.floor(math.sqrt(1+R*R*mid)-1)
       ck('scalar_count_step_midpoint',mm==k-1)
  for lam in (1e2,1e3,1e4,1e5,1e6):
    m=math.floor(math.sqrt(1+R*R*lam)-1)
    N=(m+1)*(m+2)*(2*m+3)//6
    lead=R**3/3*lam**1.5
    ck('scalar_count_weyl_O_lambda',abs(N-lead)<10*(1+R**2)*lam)
    RECORDS.append({'R':R,'scalar_cutoff':lam,'scalar_N':N,'N_over_leading':N/lead})

# Concentration check for hemisphere, not an arbitrary-set L-G proof.
for u in np.linspace(0,math.pi/2,51):
    tail=.5-u/math.pi-math.sin(2*u)/(2*math.pi)
    ck('round_s3_hemisphere_tail_nonnegative',tail>=-2e-15)
    ck('round_s3_hemisphere_trivial_dimension_bound',tail<=math.exp(-.1*u*u)+1e-15)

out={
 'artifact':'Paper1A-IndependentChecksBatch2-v1_2.json',
 'source_file':SRC.name,'source_sha256':HASH,'coverage_source_lines':[1390,2205],
 'formal_objects':[21,40],
 'counts':dict(sorted(COUNTS.items())),
 'pass_count':sum(v for k,v in COUNTS.items() if k.endswith('::PASS')),
 'fail_count':sum(v for k,v in COUNTS.items() if k.endswith('::FAIL')),
 'maximum_absolute_residuals':MAX_ERROR,
 'data_samples':RECORDS,
 'evidence_limit':'All computational controls are finite samples/exact formula tests, not global proofs or independently established CC metric/John-domain/measure inequalities. Imported primary theorems and source all-j proofs are reviewed separately.',
 'not_tested':'Global geodesic optimality, CC topology, Mitchell metric cone convergence, Jerison/HK uniform analytic inequalities, arbitrary-set Levy-Gromov inequality and every k all-spin completeness were not deduced from finite sampling.'
}
OUT=Path('/mnt/data/Paper1A-IndependentChecksBatch2-v1_2.json')
OUT.write_text(json.dumps(out,indent=2,ensure_ascii=False))
print('PASSED',out['pass_count'],'FAILED',out['fail_count'])
print('OUT',OUT)
print('HEAT',[x for x in RECORDS if 's' in x]);print('COUNT',[x for x in RECORDS if 'count_cutoff' in x]);
