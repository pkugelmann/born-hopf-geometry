# Born–Hopf Geometry I-A — Rigorous Verification DAG, Final Batch 6

**Frozen source:** `Paper1A-Geometry-v5_177.tex`, SHA-256 `0ddd521f70f237830ff4f018c8eebedb4bde43b62a0c9b92eb8c3ec3348f9f17` in `Paper00-PapersMinimal-v3_018.zip`.  
**Protocols:** RigorousVerificationDAG v2.4 and ProofChainAudit v1.1 (with the no-theory-development priority of v2.4).  
**Base archives:** DAG Atlas v1.152 and Proof-Chain Audits v1.65, replaced by successor releases v1.153 and v1.66 after readback.  
**Coverage:** formal objects **154–179** (26 items), statements at **lines 6293–7290** and proofs through line **7316**. Cumulative **179/179** formal objects audited.

## Batch results

| Verified | Reproduced | Formalized | Unresolved among formal claims |
|---:|---:|---:|---:|
| **17** | **3** | **6** | **0** |

Independent suite: **12122 passed / 0 failed**, spanning 37 finite and exact test families. Test family count includes repetitive finite-sampling checks, not 12122 independent mathematical proofs. Source E1 and E3/E4 evidence must be read jointly.

## Rigorous proof checks

1. **Berger tensor:** Koszul from the exact structure constants yields `K12=(4−3ε²)/R²`, `K13=K23=ε²/R²`; Ricci/Einstein/positivity follow without importing the paper’s displayed Christoffels. The collapsed branch has uniformly bounded curvature.
2. **Curvature cap and shape:** `3|Rm|²/Kp²=(11ε⁴−24ε²+16)/3`; the difference factorizes as `(ε²−1)(11ε²−13)/3`. Therefore the cap in 0<ε≤1 permits ε=1 only. Spin-frame c1=1 is a marked orientation result, while shape-normalized base radius R/2 is a chosen comparison scale and does not determine original b.
3. **Submersion and collapse:** vertical circles have length `2πRε`, diameter `πRε`; the horizontal lift plus a shortest fiber arc controls point distances. The GH estimate in the paper is conservative and holds uniformly.
4. **Berger spectrum and spectral crossing:** the doubled charge q has allowed parity and per-weight multiplicity ℓ+1; `λ_{ℓ,q}` matches Casimir plus vertical penalty. The first positive eigenvalue is `min(8,2+ε⁻²)/R²` and crossing at ε=1/√6 has multiplicities 3/4/7. The fixed spectral-window decoupling limit agrees exactly with the base S²(R/2) eigenvalues/multiplicities; it does not assert all-frequency decoupling.
5. **Einstein TT response:** on TT fields, `L_Ein=(Δ_L−4K)/2`; using the prior audited TT spectrum yields smallest eigenvalue 4K, inverse norm 1/(4K) and positive gap. The source separately solves the Bianchi-gauge equation and excludes scalar trace kernel; no generic physical uniqueness beyond the fixed-λ Einstein claim is asserted.
6. **Dirac doublets:** the 3D quaternionic charge conjugation satisfies C²=−I and commutes with Clifford action; Riesz projection preserves rank two. Conformal covariance independently checks the volume derivative factor `−λν/3` for a broad special case, while the source’s full metric-variation proof supplies the arbitrary perturbation step. Fang–Levitin–Vassiliev (2018) independently treats the same physical-operator quantity in the literature.
7. **Finite group support:** orders 24/48/120, 2O=2T⊔g2T and nonsplit C₂ extension are consistent with SU2 involutions; explicit A4⊂A5 normalizer enumeration verifies `N_{A5}(A4)=A4`, while `N_{S4}(A4)=S4`. The finite-support atlas is not the atlas of arbitrary finite subsets, and the five I/H cosets are not a quotient group.

## Imported and conditional results

- `p1:thm:hamilton-ricci-flow-convergence`: Hamilton (1982) proves the positive-Ricci compact three-manifold normalized-flow convergence used at lines 6848–6859; status remains `REPRODUCED` because this audit does not independently reproduce the entire global flow proof. The stability corollary is valid within its C²-neighborhood and Ric>0 domain.
- `p1a:theorem:atlas-finite-subgroup-classification-b4f160f`: the general classification is imported; concrete binary-polyhedral order and normalizer controls independently corroborate current applications, not the entire classification theorem.
- Carrier physical realization and a chosen vertical scale ε are not inferred from ambient metric deformation alone.

## All current audit findings and release dispositions

1. **`BH-IA-DAG-000001` — DAG_INTEGRITY, minor (index risk moderate), RESOLVED by release reconciliation.** The inherited I-A README and layer indices named obsolete source hashes/combined views and a stale Berger-decoupling locator. Correct current location is **6782–6815**; source hash and current release pointers are corrected. No proven cross-paper mathematical impact.
2. **`BH-IA-DAG-000002` — DAG_COVERAGE, moderate, RESOLVED by quarantine.** Wrong proof-traversable `BH-IA-V176-EDGE-0030` asserted that the round-S³ 3-Sasakian **example** proved the universal compact rigidity theorem `p1:cor:3sasakian-rigidity` (4606–4614). This was not a source-consumed theorem premise. The edge is removed from live material graph/routes and retained as a rejected candidate; the actual imported global theorem route remains. No other proven downstream descendants.
3. **`BH-IA-SRC-000003` — TYPE_OR_DOMAIN / source-evidence scope, moderate, OPEN FOR CLARIFICATION.** Summary-table line **6017** reads “Level-1 closure property” without specifying projected vs unprojected tensor product. The cutoff reading is true; a stronger unprojected CG closure fails because `(1/2,0)⊗(1/2,1/2)` contains `(1,1/2)` outside H₁. This is not a refutation of the defined 15D H₁ or independently established m_p=1. There is no source-certified downstream impact; stronger physical-closure interpretations remain nontraversable. **Obligation:** clarify exactly which operation is intended, with explicit projection if claimed.

**Mathematical defects in 179 formal objects:** none newly confirmed. **Open issues:** one source summary-table scope ambiguity (not a failed formal theorem proof). **Closed DAG-only defects:** two.

## Claim-by-claim adjudication (26 of 26)

| # | Exact source label | Source statement lines | E1/E3/E4 verdict | Scope / evidence |
|---:|---|---|---|---|
| 154 | `p1:def:berger-canonical-variation` | 6293–6300 | FORMALIZED | Berger canonical variation sets only the vertical metric coefficient, not a new physical selector. |
| 155 | `p1:prop:submersion-fiber-length` | 6302–6316 | VERIFIED | Horizontal submersion is exact; Hopf psi-period 4pi gives fiber length 2pi R epsilon, intrinsic diameter pi R epsilon. |
| 156 | `p1:lem:fibers-geodesic` | 6344–6346 | VERIFIED | Constant-length Killing vector integral curves satisfy ∇_K K=0. |
| 157 | `p1:thm:berger-sectional` | 6394–6405 | VERIFIED | Independent Koszul-symbolic derivation yields horizontal K=(4−3ε²)/R² and mixed K=ε²/R². |
| 158 | `p1:cor:berger-ricci` | 6437–6454 | VERIFIED | Ricci entries are sums of sectional curvatures; positivity thresholds and Einstein iff ε=1 follow exactly. |
| 159 | `p1:cor:berger-primitive-cap-rigidity` | 6471–6510 | VERIFIED | Curvature budget factor (ε²−1)(11ε²−13)/3 verified symbolically; collapse half-family 0<ε≤1 has only round survivor. |
| 160 | `p1:rem:berger-primitive-cap-scope` | 6537–6543 | FORMALIZED | Scope remark correctly limits cap to the canonical Berger/Hopf variation. |
| 161 | `p1:cor:spinframe-hopf-shape-descendant` | 6545–6592 | VERIFIED | Spin(2) frame double-cover gives c1=1 from Euler=2; spherical shape normalization is homothety invariant; one positive invariant fiber coefficient remains. |
| 162 | `p1:rem:spinframe-hopf-shape-scope` | 6623–6629 | FORMALIZED | Radius b remains arbitrary; R enters comparison normalization, not a derived microscopic radius. |
| 163 | `p1:cor:berger-vol-diam` | 6631–6640 | VERIFIED | Volume scales ε; base horizontal lift plus fiber arc yields stated diameter upper bound. |
| 164 | `p1:thm:berger-gh` | 6653–6660 | VERIFIED | Graph of π is a correspondence with distortion ≤πRε; GH ≤(πRε)/2 in standard correspondence convention, so source weaker estimate holds. |
| 165 | `UNLABELED:Paper1A:remark:v5_177:6691` | 6691–6695 | FORMALIZED | Bounded curvature follows from explicit K formula for ε∈(0,1]. |
| 166 | `p1:thm:berger-spectrum` | 6719–6733 | VERIFIED | Peter–Weyl Casimir and doubled vertical charges give λ_{ℓ,q}=[ℓ(ℓ+2)+(ε⁻²−1)q²]/R² with per-charge multiplicity ℓ+1. |
| 167 | `p1:cor:berger-first-positive-eigenvalue` | 6751–6763 | VERIFIED | First modes (ℓ,q)=(2,0) and (1,±1) cross at ε=1/√6, multiplicities 3,4,7; no omitted ℓ≥2 mode is lower. |
| 168 | `p1:cor:berger-decoupling` | 6782–6795 | VERIFIED | For q≠0 lower bound (ε⁻²−1)/R² diverges; q=0 only even ℓ and precisely base spectrum and multiplicities survive. |
| 169 | `p1:thm:einstein-uniqueness-s3` | 6822–6826 | VERIFIED | In dimension 3 Einstein implies constant sectional curvature; compact simply connected positive-curvature S³ fixes spherical space form to round, up to scale. |
| 170 | `p1:thm:hamilton-ricci-flow-convergence` | 6848–6856 | REPRODUCED | Hamilton’s normalized-flow theorem source checked under compactness and initial Ric>0. No claim for Ric≤0. |
| 171 | `p1:cor:ricci-flow-round-stability` | 6863–6866 | REPRODUCED | Positive Ricci is C²-open, so Hamilton theorem applies to small round perturbations. |
| 172 | `p1:prop:infinitesimal-einstein-deformations` | 6877–6911 | VERIFIED | TT deformation Hessian, gap at 4/R² and gauge-Killing kernel checked; source Bianchi gauge solves and removes all fixed-λ TT kernel. |
| 173 | `p1:thm:lowest-dirac-pair-stability` | 6985–7003 | VERIFIED | Quaternionic C²=−I and [C,D]=0 force retained complex rank-two doublets; conformal covariance independently checks λ′=−λν/3. |
| 174 | `p1a:theorem:atlas-finite-subgroup-classification-b4f160f` | 7073–7093 | REPRODUCED | SO(3) finite rotation classification lifts to binary cyclic/dicyclic and T/O/I; subgroup orders and odd-order noncentral branch reviewed. |
| 175 | `p1:def:finite-support-atlases` | 7099–7122 | FORMALIZED | Finite epsilon-net atlas and finite subgroup-closed atlas are distinct; notation includes cyclic overlaps explicitly. |
| 176 | `p1:prop:2O-two-cosets-not-product` | 7174–7191 | VERIFIED | Index-two H=2T in 2O yields two cosets; no involution outside H in SU2 => extension does not split. |
| 177 | `UNLABELED:Paper1A:remark:v5_177:7201` | 7201–7206 | FORMALIZED | Left–right Spin(4) 2T×2T is a different ambient carrier than one-sided SU2 subgroup. |
| 178 | `p1:prop:exceptional-nesting` | 7243–7250 | VERIFIED | Displayed groups give H⊂2O and H⊂2I; 2O⊄2I since 24 does not divide 60 after central quotient. |
| 179 | `p1:thm:exceptional-normalizer-fork` | 7264–7290 | VERIFIED | Permutation-group normalizers computed: N_{S4}(A4)=S4, N_{A5}(A4)=A4; hence N_SU2(H)=2O and N_I(H)=H, intersection H. |

## Audit conclusion and release boundary

`FULLY_AUDITED_NO_CONFIRMED_OPEN_MATHEMATICAL_GAPS` applies **only to Paper I-A formal-object source coverage**, not the whole framework. One nonformal source-scope issue is open and recorded separately; imported literature theorems remain classified by their own evidence. Source .tex, macro, .bib and PDF files remain unchanged.

**Archive version discipline:** use newest incoming DAG v1.152 / Audit v1.65, not previous batch baseline v1.150/v1.64; successor ZIPs v1.153 and v1.66. The canonical graph is preserved semantically except for its active-layer routing metadata; one false material edge is quarantined. No new physical assumptions and no paper rewrites.
