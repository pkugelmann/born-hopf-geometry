#!/usr/bin/env python3
"""Independent E3 calculations and E4 boundary probes for Paper I-A v5_177,
formal objects #76--116. No imported global theorem is certified by finite tests.
Run: python Paper1A-IndependentChecksBatch4-v1_1.py PATH_TO_CURRENT_TEX_OR_ZIP
"""
from __future__ import annotations
import sys, math, json, hashlib, zipfile
from pathlib import Path
from collections import Counter
import numpy as np
import sympy as sp
import mpmath as mp

SOURCE_SHA256='0ddd521f70f237830ff4f018c8eebedb4bde43b62a0c9b92eb8c3ec3348f9f17'
HERE=Path(__file__).parent
inp=Path(sys.argv[1]) if len(sys.argv)>1 else HERE/'Paper1A-Geometry-v5_177.tex'
if inp.suffix == '.zip':
    with zipfile.ZipFile(inp) as z:
        cand=[s for s in z.namelist() if s.endswith('Paper1A-Geometry-v5_177.tex')]
        assert len(cand)==1,cand
        source=z.read(cand[0])
else: source=inp.read_bytes()
assert hashlib.sha256(source).hexdigest()==SOURCE_SHA256,'Incorrect authoritative source'
lines=source.decode('utf-8').splitlines()
checks=Counter(); failed=[]; certificates=[]
def ck(name,cond,detail=''):
    checks[name]+=1
    if not bool(cond): failed.append({'family':name,'detail':str(detail)[:400]})
def analytic(name,text): certificates.append({'family':name,'analytic_certificate':text})
rng=np.random.default_rng(16022026)

# Positive/negative real Clifford algebras: explicit generator constructions.
I=sp.I
sx=sp.Matrix([[0,1],[1,0]])
sy=sp.Matrix([[0,-I],[I,0]])
sz=sp.Matrix([[1,0],[0,-1]])
P=[sx,sy,sz]
for i in range(3):
    for j in range(3):
        ck('clifford_positive_pauli',sp.simplify(P[i]*P[j]+P[j]*P[i]) == (2*sp.eye(2) if i==j else sp.zeros(2)),(i,j))
pauli_words=[sp.eye(2),P[0],P[1],P[2],P[0]*P[1],P[0]*P[2],P[1]*P[2],P[0]*P[1]*P[2]]
def realmatcoords(M):
    return sp.Matrix([coord for e in M for coord in (sp.re(e),sp.im(e))])
ck('clifford_positive_pauli',sp.Matrix.hstack(*[realmatcoords(M) for M in pauli_words]).rank()==8, 'Full 8D real basis in M2(C)')
ck('clifford_positive_pauli',P[0]*P[1]*P[2]==I*sp.eye(2),'Central volume element ω²=-1')
for a in (P[0]*P[1],P[1]*P[2],P[2]*P[0]):
    ck('clifford_even_quaternion',a*a==-sp.eye(2),'Even Cl(3,0) quaternion generator squares -1')
# Negative algebra represented as H⊕H, explicitly separating volume eigenspaces.
# Quaternion product (scalar, 3D imaginary vector), rational or integer exact.
def qm(q,r):
    a,b,c,d=q; e,f,g,h=r
    return (a*e-b*f-c*g-d*h,
            a*f+b*e+c*h-d*g,
            a*g-b*h+c*e+d*f,
            a*h+b*g-c*f+d*e)
def conj(q): return (q[0],-q[1],-q[2],-q[3])
def norm2(q):return sum(x*x for x in q)
e0=(1,0,0,0); qi=(0,1,0,0);qj=(0,0,1,0);qk=(0,0,0,1)
def pair_mul(q,r): return (qm(q[0],r[0]),qm(q[1],r[1]))
negG=[(qi,qi),(qj,qj),(qk,tuple(-v for v in qk))]
neg_words=[(e0,e0)]
for mask in range(1,8):
    el=(e0,e0)
    for i in range(3):
        if mask&(1<<i): el=pair_mul(el,negG[i])
    neg_words.append(el)
ck('clifford_negative_hh',sp.Matrix.hstack(*[sp.Matrix(list(a)+list(b)) for a,b in neg_words]).rank()==8,'Cl(0,3) spans H⊕H')
for i in range(3):
    for j in range(3):
        ant=tuple(tuple(x+y for x,y in zip(left,right)) for left,right in zip(pair_mul(negG[i],negG[j]),pair_mul(negG[j],negG[i])))
        want=(-2*int(i==j),0,0,0)
        ck('clifford_negative_hh',ant==(want,want),(i,j))
vol=pair_mul(pair_mul(negG[0],negG[1]),negG[2])
ck('clifford_negative_hh',vol==((-1,0,0,0),(1,0,0,0)),'Central idempotent splitting H ⊕ H')
analytic('clifford','Cl3,0 positive Pauli matrices span M2(C) over R; Cl0,3 negative generators span H⊕H over R, and volume element splits +/−. Each even algebra is quaternionic. This does not prove full eightfold Bott periodicity.')

# Quaternion group and spin cover, exact rational controls.
from fractions import Fraction as F
for idx in range(420):
    vals=rng.integers(-6,7,size=(3,4))
    q,r,s=[tuple(int(v) for v in row) for row in vals]
    ck('quaternion_norm_associativity',norm2(qm(q,r))==norm2(q)*norm2(r),idx)
    ck('quaternion_norm_associativity',qm(qm(q,r),s)==qm(q,qm(r,s)),idx)
    ck('quaternion_norm_associativity',qm(q,conj(q))==(norm2(q),0,0,0),idx)
    cross=(q[2]*r[3]-q[3]*r[2],q[3]*r[1]-q[1]*r[3],q[1]*r[2]-q[2]*r[1])
    ck('quaternion_norm_associativity',(qm(q,r)==qm(r,q))==(cross==(0,0,0)),'commutation iff imaginary cross product zero')
for idx in range(240):
    rr=F(int(rng.integers(1,17)),int(rng.integers(1,17)))
    tt=F(int(rng.integers(-10,11)),int(rng.integers(11,31)))
    p=((1-tt*tt)/(1+tt*tt),2*tt/(1+tt*tt),F(0),F(0))
    q_int=rng.integers(-6,7,size=4)
    q0=tuple(F(int(x)) for x in q_int)
    if norm2(q0)==0:continue
    x=tuple(rr*v for v in q0)
    left=qm(p,x)
    # Hopf projection x^{-1} i x = bar{x} i x / |x|^2
    def hopf(z):
        out=qm(qm(conj(z),qi),z);n=norm2(z)
        return tuple(a/n for a in out)
    ck('hopf_quaternion_fiber',hopf(x)==hopf(left),idx)
    ck('hopf_quaternion_fiber',norm2(left)==norm2(x),idx)
    # transported product x◦y=(xy)/R and inverse of a radius-R quaternion =bar{x}.
    xx=tuple(rr*v for v in p)
    xx_inv=conj(xx)
    circ=tuple(v/rr for v in qm(xx,xx_inv))
    ck('hopf_quaternion_fiber',circ==(rr,0,0,0),idx)
# Conjugation by unit quaternions defines SO(3): rational Pythagorean quaternions.
for idx in range(80):
    q0=tuple(int(v) for v in rng.integers(-9,10,size=4))
    n=norm2(q0)
    if not n:continue
    # conjugation q v q^{-1} = q v conjugate(q)/norm2(q)
    columns=[]
    for e in (qi,qj,qk):
        v=qm(qm(q0,e),conj(q0))
        columns.append([F(x,n) for x in v[1:]])
    A=sp.Matrix.hstack(*[sp.Matrix(v) for v in columns]);
    ck('quaternion_so3',A.T*A==sp.eye(3),idx)
    ck('quaternion_so3',A.det()==1,idx)
    ck('quaternion_so3',A==sp.eye(3) if q0[1:]==(0,0,0) else True,'Scalar acts trivially')
analytic('quaternion','q↦q⁻¹ i q is constant on the left U(1) orbit, and unit quaternion conjugation acts orthogonally with determinant +1 on Im(H). Kernel = real unit quaternions {±1}, since centralizing all of i,j,k forces imaginary part zero.')

# Coherent-projector symbol injectivity: Fourier/radial Vandermonde proof and samples.
# For v_k(1,w), its matrix coefficients are nonzero rescalings of w^b conj(w)^a /(1+|w|²)^k.
# With 2k+1 angular positions, the Fourier mode d=b−a separates, and each mode's
# radial monomials have distinct powers (r²)^a. This proves full rank for each k.
for k in range(0,24):
    count=0
    for d in range(-k,k+1):
        exps=[a for a in range(k+1) if 0<=a+d<=k]
        count+=len(exps)
        n=len(exps)
        ck('coherent_symbol_fourier_vandermonde',n==k+1-abs(d),(k,d))
        # exact Vandermonde-type matrix: r_i²=t_i, column exponent a
        if n and k<=9:
            V=sp.Matrix([[sp.Integer(i+1)**a for a in exps] for i in range(n)])
            ck('coherent_symbol_fourier_vandermonde',V.det()!=0,(k,d))
    ck('coherent_symbol_fourier_vandermonde',count==(k+1)**2, k)
# Independent numerical full rank for small shells (choose angular × radii sampling)
for k in range(0,7):
    if k==0:continue
    radii=np.linspace(.55,1.4,k+1)
    angles=np.linspace(0,2*np.pi,2*k+1,endpoint=False)
    M=[]
    for r in radii:
        for th in angles:
            w=r*np.exp(1j*th)
            v=np.array([math.sqrt(math.comb(k,a))*w**a/(1+r*r)**(k/2) for a in range(k+1)])
            M.append(np.kron(v,np.conj(v)))
    M=np.array(M)
    ck('coherent_symbol_sample_rank',np.linalg.matrix_rank(M,tol=1e-10)==(k+1)**2,k)
analytic('coherent_symbol','Coherent-symbol matrix functions have independent Fourier angular modes d=b−a, and each mode has k+1−|d| distinct radial powers; Vandermonde nondegeneracy yields rank (k+1)² at every k. Clebsch–Gordan then gives V0⊕⋯⊕Vk.')

# Möbius/Cayley exact rational tests and unique positive normalized trace parameter.
for idx in range(300):
    t=F(int(rng.integers(1,15)),int(rng.integers(16,41)))
    s=F(int(rng.integers(1,15)),int(rng.integers(16,41)))
    H=lambda x,u:(x+u)/(u*x+1)
    z=F(int(rng.integers(-7,8)),int(rng.integers(1,9)))
    if t*z+1==0 or s*z+1==0:continue
    ck('mobius_hyperbolic',H(1,t)==1 and H(-1,t)==-1,idx)
    ck('mobius_hyperbolic',H(H(z,s),t)==H(z,(t+s)/(1+t*s)),idx)
    ck('mobius_hyperbolic',4/(1-t*t)>4,'normalized |trace|²>4')
    # Positive t uniquely recovered from normalized squared trace.
    tr2=4/(1-t*t)
    ck('mobius_hyperbolic',1-4/tr2==t*t,'positive t is unique')
for idx in range(260):
    s=F(int(rng.integers(1,21)),int(rng.integers(22,48)))
    z=(1+sp.I*sp.Rational(s.numerator,s.denominator))/(1-sp.I*sp.Rational(s.numerator,s.denominator))
    w=sp.simplify(sp.I*(1+z)/(1-z))
    ck('cayley_circle',sp.simplify(w+1/sp.Rational(s.numerator,s.denominator))==0,idx)
    u=w*w
    cos=(1-sp.Rational(s.numerator,s.denominator)**2)/(1+sp.Rational(s.numerator,s.denominator)**2)
    ck('cayley_circle',sp.simplify((u-1)/(u+1)-cos)==0,idx)
for n in range(2,81):
    # In PSL2(C), z -> e^(2πi/n)z has order exactly n, since primitive n-th root.
    z=np.exp(2j*np.pi/n)
    ck('projective_cyclic_orders',abs(z**n-1)<1e-12 and all(abs(z**j-1)>1e-8 for j in range(1,n)),n)

# Spin(4) counts, exact formulas, algebra distinctions.
a,b,m,n=sp.symbols('a b m n',integer=True,nonnegative=True)
D=sp.summation((a+1)*(b+1),(b,0,2*m-a),(a,0,2*m))
Dformula=sp.prod(2*m+i for i in range(1,5))/24
B=sp.summation((a+1)**2*(b+1)**2,(b,0,n-a),(a,0,n))
Bformula=sp.prod(n+i for i in range(1,5))*(2*n*n+10*n+15)/360
ck('spin4_symbolic_counts',sp.simplify(D-Dformula)==0,'Full H_m polynomial identity')
ck('spin4_symbolic_counts',sp.simplify(B-Bformula)==0,'Full A_m polynomial identity')
ck('spin4_symbolic_counts',sp.simplify(Dformula-sp.binomial(2*m+4,4))==0,'Combinatorial identity')
for mi in range(0,101):
    nn=2*mi
    dims=[(aa+1)*(bb+1) for aa in range(nn+1) for bb in range(nn-aa+1)]
    ck('spin4_finite_counts',sum(dims)==math.comb(nn+4,4),('H',mi))
    ck('spin4_finite_counts',sum(x*x for x in dims)==int(Bformula.subs(n,nn)),('A',mi))
    ck('spin4_finite_counts',len(dims)==math.comb(nn+2,2),('commutant',mi))
    ck('spin4_finite_counts',sum(dims)**2==math.comb(nn+4,4)**2,('End',mi))
level1=[(a,b,(a+1)*(b+1)) for a in range(3) for b in range(3-a)]
ck('spin4_H1_sector',len(level1)==6 and sum(d for _,_,d in level1)==15,'Six exact sectors, dim 15')
ck('spin4_H1_sector',sum(d*d for _,_,d in level1)==43,'A1 block algebra dim 43')
ck('spin4_H1_sector',len(level1)==6,'Schur commutant dim 6')
# The (1/2,0)⊕(0,1/2) direct sum is faithful on SU2xSU2.
for L in (1,-1):
    for R in (1,-1):
        # Central pair acts separately on S+ and S-, yielding faithful sum.
        direct=sp.diag(L,L,R,R)
        ck('spin4_chiral_faithful',(direct==sp.eye(4))==((L,R)==(1,1)),(L,R))
        ck('spin4_chiral_faithful',direct.det()==1,(L,R,'Spin4 center determinant'))
# Verify quadratic Casimir and the symmetric/antisymmetric tensor-square dimensions.
sectors=[(0,0,1,0),(1,0,2,sp.Rational(3,4)),(0,1,2,sp.Rational(3,4)),(1,1,4,sp.Rational(3,2)),(2,0,3,2),(0,2,3,2),(2,2,9,4)]
for A,B,dim,Cas in sectors:
    jL,jR=sp.Rational(A,2),sp.Rational(B,2)
    ck('spin4_low_degree_dictionary',(A+1)*(B+1)==dim,(A,B,'dimension'))
    ck('spin4_low_degree_dictionary',jL*(jL+1)+jR*(jR+1)==Cas,(A,B,'Casimir'))
ck('spin4_low_degree_dictionary',9+1==10 and 3+3==6 and 10+6==16,'vector square: 10 sym+6 antisym')

# Differential forms on flat cone: exact dω and pairwise wedge product.
r=sp.symbols('r',positive=True,real=True)
# basis indices [dr,theta1,theta2,theta3], each θ_i obeys dθ_i=-2 θ_j∧θ_k.
def wedge(A,B):
    out={}
    for inds,u in A.items():
        for jnds,v in B.items():
            if len(set(inds+jnds))!=len(inds+jnds):continue
            key=inds+jnds
            sign=(-1)**sum(key[i]>key[j] for i in range(len(key)) for j in range(i+1,len(key)))
            key=tuple(sorted(key));out[key]=sp.simplify(out.get(key,0)+sign*u*v)
    return {k:v for k,v in out.items() if v!=0}
def add(A,B,coef=1):
    out=dict(A)
    for k,v in B.items():out[k]=sp.simplify(out.get(k,0)+coef*v)
    return {k:v for k,v in out.items() if v!=0}
def dform(A):
    out={}
    for key,c in A.items():
        if c!=0:out=add(out,wedge({(0,):sp.diff(c,r)},{key:1}))
        for pos,j in enumerate(key):
            dtheta={1:{(2,3):-2},2:{(1,3):2},3:{(1,2):-2},0:{}}[j]
            if not dtheta:continue
            prefix={tuple(key[:pos]):1};suffix={tuple(key[pos+1:]):1}
            out=add(out,wedge(wedge(prefix,dtheta),suffix),(-1)**pos*c)
    return {k:sp.simplify(v) for k,v in out.items() if sp.simplify(v)!=0}
e=[{(0,):1},{(1,):r},{(2,):r},{(3,):r}]
w1=add(wedge(e[0],e[1]),wedge(e[2],e[3]),-1)
w2=add(wedge(e[0],e[2]),wedge(e[3],e[1]),-1)
w3=add(wedge(e[0],e[3]),wedge(e[1],e[2]),-1)
for i,w in enumerate((w1,w2,w3)):
    ck('flat_cone_forms',dform(w)=={},('closed',i))
for i,wi in enumerate((w1,w2,w3)):
    for j,wj in enumerate((w1,w2,w3)):
        vol=wedge(wedge(wedge(e[0],e[1]),e[2]),e[3])
        ck('flat_cone_forms',wedge(wi,wj)== ({(0,1,2,3):-2*r**3} if i==j else {}),(i,j,'orientation sign: physical orientation reverse'))
ck('flat_cone_forms',sp.simplify(sp.det(sp.diag(1,r,r,r))-r**3)==0,'Cone volume r³ dr∧θ123')
for ss in (sp.Rational(1,5),sp.Rational(3,2),sp.Rational(5,1)):
    ck('flat_cone_homothety',sp.prod([ss]*4)==ss**4,'4-density character')
analytic('flat_cone','Closed ω_a forms computed directly from dθ_i=-2θ_j∧θ_k; ω_a∧ω_b=-2 δ_ab vol for coordinate orientation (dr, θ1,θ2,θ3), and +2δ_ab with source opposite orientation. Cone polar metric is Euclidean dr²+r²g_unit, proving flatness independently of forms.')

# Beckner radius normalization: exact coefficient algebra; equality profiles by
# independent 1-D integration with correct 3-sphere angular measure 4πsin²θ.
V=2*sp.pi**2*r**3
Cgrad=sp.Rational(4,3)*r**2/V**(sp.Rational(2,3))
Czero=V**(-sp.Rational(2,3))
ck('beckner_coefficients',sp.simplify(Cgrad-4/(3*(2*sp.pi**2)**(sp.Rational(2,3))))==0,'gradient')
ck('beckner_coefficients',sp.simplify(Czero-1/((2*sp.pi**2)**(sp.Rational(2,3))*r**2))==0,'zeroth')
mp.mp.dps=40
for R in ('0.5','1.0','1.8','3.0'):
    for h in ('0','0.2','0.45','0.68','0.86'):
        R=mp.mpf(R);h=mp.mpf(h)
        def u(th):return mp.power(1-h*mp.cos(th),-mp.mpf('.5'))
        def du(th):return -(h/2)*mp.sin(th)*mp.power(1-h*mp.cos(th),-mp.mpf('1.5'))
        # integral on radius-R S3 = 4π R³ ∫ sin²θ f(θ) dθ
        measure=lambda fn:4*mp.pi*R**3*mp.quad(lambda th:mp.sin(th)**2*fn(th),[0,mp.pi])
        I6=measure(lambda th:u(th)**6)
        I2=measure(lambda th:u(th)**2)
        Ig=measure(lambda th:(du(th)/R)**2)
        left=I6**(mp.mpf(1)/3)
        right=(4/(3*(2*mp.pi**2)**(mp.mpf(2)/3)))*Ig+I2/((2*mp.pi**2)**(mp.mpf(2)/3)*R**2)
        ck('beckner_equality_quadrature',abs((left-right)/left)<mp.mpf('2e-27'),(R,h,left-right))
for R in ('0.5','1','2'):
    R=mp.mpf(R)
    measure=lambda fn:4*mp.pi*R**3*mp.quad(lambda th:mp.sin(th)**2*fn(th),[0,mp.pi])
    # Non-conformal smooth 1+α cos θ is strict by equality classification
    f=lambda th: 1+mp.mpf('.12')*mp.cos(th)
    fp=lambda th: -mp.mpf('.12')*mp.sin(th)
    left=measure(lambda th:f(th)**6)**(mp.mpf(1)/3)
    right=(4/(3*(2*mp.pi**2)**(mp.mpf(2)/3)))*measure(lambda th:(fp(th)/R)**2)+measure(lambda th:f(th)**2)/((2*mp.pi**2)**(mp.mpf(2)/3)*R**2)
    ck('beckner_strict_control',right>left,(R,float(right-left)))
analytic('beckner','Source radius rescaling is an exact algebraic identity. Independent zonal angular integration matches equality for conformal family. The all-W¹,² sharp inequality/equality classification remains imported Beckner/Yamabe theorem.')

# Heat kernel SU2 characters / Chebyshev U_k: normalized zonal projector.
for k in range(0,80):
    # ∫_{S3} U_k(cos θ) dμ = (2/π)∫_0^π sin θ sin((k+1)θ)dθ
    integral=mp.quad(lambda th:(2/mp.pi)*mp.sin(th)*mp.sin((k+1)*th),[0,mp.pi])
    ck('heat_kernel_zonal_integrals',abs(integral-(1 if k==0 else 0))<mp.mpf('1e-30'),(k,str(integral)))
    eps=mp.mpf('1e-13')
    antipodal=mp.sin((k+1)*(mp.pi-eps))/mp.sin(mp.pi-eps)
    ck('heat_kernel_antipodal',abs(antipodal-((-1)**k)*(k+1))<mp.mpf('1e-18'),k)
for RR in (.4,1,2.3):
    volume=2*np.pi*np.pi*RR**3
    for t in (.025,.05,.12,.6,1.5):
        levels=np.arange(0,125,dtype=np.float64)
        weights=(levels+1)*np.exp(-levels*(levels+2)*t/RR**2)/volume
        diag=float(np.sum(weights*(levels+1)))
        trace=volume*diag
        direct=float(np.sum((levels+1)**2*np.exp(-levels*(levels+2)*t/RR**2)))
        ck('heat_kernel_spectral_normalization',abs(trace-direct)<1e-10,(RR,t,'trace'))
        ck('heat_kernel_spectral_normalization',diag>0,(RR,t,'positive diagonal'))
        antipodal=float(np.sum(weights*((-1)**levels)*(levels+1)))
        ck('heat_kernel_spectral_normalization',np.isfinite(antipodal),(RR,t,'antipodal'))
        # All positive spectral modes are orthogonal to constants; integral K=1.
        ck('heat_kernel_spectral_normalization',abs(volume*weights[0]-1)<1e-12,(RR,t,'Markov norm'))
analytic('heat_kernel','S³ zonal addition coefficient (k+1)/Vol has diagonal value (k+1)²/Vol. Fourier/character orthogonality makes integral of each k>0 term zero, k=0 term one. Series converges absolutely for every t>0.')

# Assert source-line anchors for evidence and protect exact statements.
anchors={
'clifford3':('\\Cl_{3,0}\\cong M_2(\\CC)',3548,3579),
'h1':('\\dim \\mathcal H_1=15',4267,4282),
'coherent':('\\sigma_k(A)([z])',3868,3918),
'beckner':('\\frac{4}{3(2\\pi^2)^{2/3}}',4709,4730),
'heat':('\\sin((k+1)d(x,y)/\\Rmom)',4803,4824)
}
for label,(needle,start,end) in anchors.items():
    ck('source_exact_anchors',needle in '\n'.join(lines[start-1:end]),label)

result={
 'artifact':'Paper1A-IndependentChecksBatch4-v1_1.json',
 'source':'Paper1A-Geometry-v5_177.tex','source_sha256':SOURCE_SHA256,
 'formal_objects_inclusive':[76,116],'source_lines_inclusive':[3512,4865],
 'checks_passed':int(sum(checks.values())-len(failed)),'checks_failed':len(failed),
 'families':dict(sorted(checks.items())),
 'failures':failed[:50],
 'analytical_certificates':certificates,
 'restrictions':'Finite and symbolic controls do not prove imported Borel-Weil, Bott periodicity, 3-Sasakian rigidity, Beckner, or Fuglede-Ishihara theorems.',
 'implementation':'Python 3 sympy, numpy, mpmath; seeded RNG; exact source hash gate'
}
out=HERE/'Paper1A-IndependentChecksBatch4-v1_1.json'
out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'passes':result['checks_passed'],'failed':result['checks_failed'],'families':result['families'],'failures':result['failures']},indent=2))
if failed:sys.exit(1)
