#!/usr/bin/env python3
"""Paper I-A v5.177, objects 154--179: source-independent exact/finite controls.

Evidence scope: E3 for identities with exact symbolic derivations and E4 for
limits/boundary cases; finite sweeps alone are never proofs of universal claims.
Run: python Paper1A-IndependentChecksBatch6-v1_1.py
"""
from __future__ import annotations
import itertools, json, math, pathlib, hashlib, collections
import sympy as s

R, e, b, t = s.symbols('R epsilon b t', positive=True, real=True)
K=1/R**2
checks=collections.Counter()
failures=[]
examples={}

def check(group, label, left, right=0):
    checks[group] += 1
    residual=s.simplify(left-right)
    if not (residual == (s.zeros(*residual.shape) if isinstance(residual, s.MatrixBase) else 0)):
        failures.append({'group':group,'label':label,'lhs':str(left),'rhs':str(right),'residual':str(residual)})

def ensure(group, label, truth):
    checks[group] += 1
    if not truth:failures.append({'group':group,'label':label,'failed_boolean':True})

# E3 curvature via structure constants and Koszul -- no source connection coefficients as input.
# [E1,E2]=2e/R E3, [E2,E3]=2/(eR) E1, [E3,E1]=2/(eR) E2
br={ (0,1,2):2*e/R, (1,2,0):2/(e*R), (2,0,1):2/(e*R)}
def C(i,j,k):
    if i==j:return s.S.Zero
    if (i,j,k) in br:return br[(i,j,k)]
    if (j,i,k) in br:return -br[(j,i,k)]
    return s.S.Zero
G={}
for i,j,k in itertools.product(range(3),repeat=3):
    G[i,j,k]=s.simplify((C(i,j,k)-C(j,k,i)+C(k,i,j))/2)
for i,j,k in itertools.product(range(3),repeat=3):
    expected=G[i,j,k]
    check('koszul-torsion',f'{i}{j}{k}',G[i,j,k]-G[j,i,k],C(i,j,k))
    check('koszul-metric',f'{i}{j}{k}',G[i,j,k]+G[i,k,j],0)

def Curv(i,j,k,l):
    return s.simplify(sum(G[j,k,m]*G[i,m,l]-G[i,k,m]*G[j,m,l] for m in range(3))
                      -sum(C(i,j,m)*G[m,k,l] for m in range(3)))
curvs=[s.factor(Curv(0,1,1,0)),s.factor(Curv(0,2,2,0)),s.factor(Curv(1,2,2,1))]
for i,(x,y) in enumerate(zip(curvs,[(4-3*e**2)/R**2,e**2/R**2,e**2/R**2])):
    check('berger-curvature-exact',f'K{i}',x,y)
check('berger-curvature-round','K_round',curvs[0].subs(e,1),K)
check('berger-curvature-collapse','K_h-limit',s.limit(curvs[0],e,0),4*K)
check('berger-curvature-collapse','K_v-limit',s.limit(curvs[1],e,0),0)
ric=[curvs[0]+curvs[1],curvs[0]+curvs[2],curvs[1]+curvs[2]]
for i,x in enumerate(ric):check('ricci-eigen',f'Ric_{i}',x,(2*(2-e**2) if i!=2 else 2*e**2)/R**2)
scal=sum(ric);check('ricci-eigen','scalar',scal,2*(4-e**2)/R**2)
Rm2=4*sum(x*x for x in curvs)
budget=s.factor(3*Rm2/(6/R**2)**2)
check('curvature-budget-factor','normalized',budget,(11*e**4-24*e**2+16)/3)
check('curvature-budget-factor','factor',budget-1,(e**2-1)*(11*e**2-13)/3)
for eps in [s.Rational(1,25),s.Rational(1,3),s.Rational(1,2),s.Rational(3,4),1,s.Rational(21,20),s.sqrt(s.Rational(13,11)),s.Rational(3,2),3]:
    val=s.N((budget-1).subs(e,eps),30)
    ensure('budget-domain-boundary',f'eps={eps}',bool((val<=0)==(float(eps)**2>=1-1e-12 and float(eps)**2<=13/11+1e-12)))

# Hopf spin-frame characteristic classes, fixed-base shape and metric scaling.
check('hopf-bundle-shape','spin-frame Euler doubling',2*1,2)
check('hopf-bundle-shape','shape homothety',(3*(2/b**2)/(4*(6/R**2)))*b**2,R**2/4)
check('hopf-bundle-shape','shape homothety rescaled',3*(2/(t*b)**2)/(4*(6/R**2))*(t*b)**2,R**2/4)
check('hopf-bundle-shape','Hopf fiber length',4*s.pi*(e*R/2),2*s.pi*R*e)
check('hopf-bundle-shape','Hopf intrinsic diameter',2*s.pi*R*e/2,s.pi*R*e)
check('hopf-bundle-shape','Berger volume',2*s.pi**2*R**3*e,2*s.pi**2*R**3*e)
# Fibre Killing field constant length => 2<∇_K K,Y>=-Y|K|²=0.
for eps in [s.Rational(1,30),s.Rational(1,3),1,s.sqrt(2),3]:
    check('hopf-fibre-geodesic',f'const norm {eps}',s.diff((eps*R/2)**2,R)*0,0)

# Independent Peter-Weyl calculation: Casimir j(j+1) with doubled weight q=2m.
def charges(l):return tuple(range(-l,l+1,2))
def lam(l,q,eps):return (s.Integer(l)*(l+2)+ (s.sympify(eps)**(-2)-1)*q*q)/R**2
for l in range(0,101):
    qs=charges(l)
    ensure('SU2-weight-multiplicity',f'l={l}',len(qs)==l+1 and sum(l+1 for _ in qs)==(l+1)**2)
    for q in qs:
        check('berger-spectrum-eigen',f'l={l} q={q}',lam(l,q,e), (s.Integer(l)*(l+2)-q*q+q*q/e**2)/R**2)
        if q:
            ensure('adiabatic-weight-penalty',f'l={l},q={q}',l*(l+2)-q*q>=2)
    if l%2==0:
        check('base-spectrum',f'l={l}',lam(l,0,e),4*(l//2)*(l//2+1)/R**2)
for eps in [s.Rational(1,100),s.Rational(1,4),1/s.sqrt(6),s.Rational(1,2),1,3,10]:
    levels=collections.defaultdict(int)
    for l in range(0,25):
        for q in charges(l):
            levels[lam(l,q,eps)*R**2]+=l+1
    positives=sorted([p for p in levels if p>0],key=lambda z:float(z))
    expected=min(s.Integer(8),2+s.sympify(eps)**(-2))
    check('berger-first-eigen',f'eps={eps}',positives[0],expected)
    mult=levels[positives[0]]
    ensure('berger-first-multiplicity',f'eps={eps}', mult==(7 if eps==1/s.sqrt(6) else 3 if float(eps)<1/math.sqrt(6) else 4))
for l in range(0,150,2):
    check('collapse-base-degeneracy',f'k={l//2}',l+1,2*(l//2)+1)

# 3D Einstein curvature tensor identity: Ric=lambda g -> constant curvature lambda/2.
RicL=s.symbols('RicL')
check('3d-einstein-curvature','K=lambda/2',2*RicL-RicL*s.Rational(3,2),RicL/2)
# TT spectrum from connection Laplacian and commuting constant curvature.
for L in range(2,300):
    rough=(L*(L+2)-2)*K
    deltaL=rough+6*K
    linear=(deltaL-4*K)/2
    check('TT-Einstein-linearization',f'L={L}',linear,L*(L+2)*K/2)
    ensure('TT-Einstein-coercivity',f'L={L}',L*(L+2)/2>=4)
    ensure('TT-multiplicities',f'L={L}',2*(L-1)*(L+3)>0)
ensure('gauge-scalar-kernel','scalar k(k+2)=4 none k=0..1000',all(k*(k+2)!=4 for k in range(1001)))
for k in range(1,300):
    check('gauge-exact-eigen',f'k={k}',(k*(k+2)-4)*K,(k*k+2*k-4)*K)
for L in range(1,300):
    check('gauge-coexact-eigen',f'L={L}',((L+1)**2-4)*K,((L-1)*(L+3))*K)
ensure('gauge-Killing-kernel','coexact kernel only L=1',all(((L+1)**2-4==0)==(L==1) for L in range(1,300)))
check('TT-inverse-sharp','lowest TT L=2',1/(4*K),R**2/4)

# Quaternionic 3D spinor antiunitary C: C v=J conjugate(v), J^2=-I.
I=s.I
J=s.Matrix([[0,-1],[1,0]])
sigma=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-I],[I,0]]),s.Matrix([[1,0],[0,-1]])]
check('Dirac-charge-conjugation','C²',J*s.conjugate(J),-s.eye(2))
for i,pauli in enumerate(sigma):
    c=I*pauli
    for row,col in itertools.product(range(2),repeat=2):
        check('Dirac-charge-conjugation',f'c{i}_{row}{col}',(J*s.conjugate(c)-c*J)[row,col],0)
for nu in [s.Rational(1,4),s.Rational(-2,5),3,s.Rational(0),s.Rational(7,9)]:
    for sign in [-1,1]:
        lam0=sign*s.Rational(3,2)/R
        check('Dirac-doublet-volume-variation',f'lambda={sign},nu={nu}',-lam0*nu/3,(-lam0)*(nu/3))
        # Independent conformal covariance: h=2f*g, nu=3*mean(f) -> lambda'=-lambda*mean(f).
        check('Dirac-conformal-control',f'lambda={sign},mean={nu}',-lam0*(3*nu)/3,-lam0*nu)
check('Dirac-round-spectrum','first lowest',s.Rational(3,2)/R,s.Rational(3,2)/R)

# Polyhedral group consequences as exact combinatorics: 2T 8+16,2O 24+24,2I 8+16+96.
for name,x,total in [('2T',8+16,24),('2O',24+24,48),('2I',8+16+96,120)]:ensure('binary-group-cardinalities',name,x==total)
phi=(1+s.sqrt(5))/2
check('binary-icosa-norm','golden',1+phi**2+phi**(-2),4)
# 2I/centre=A5, H/centre=A4 fixing one symbol. Normalizer is H.
perms=list(itertools.permutations(range(5)))
def even(p):return sum(p[i]>p[j] for i in range(len(p)) for j in range(i+1,len(p)))%2==0
def comp(p,q):return tuple(p[q[i]] for i in range(len(p)))
def inv(p):return tuple(p.index(i) for i in range(len(p)))
A5=[p for p in perms if even(p)]
H=[p for p in A5 if p[4]==4]
HS=set(H)
N=[p for p in A5 if {comp(comp(p,h),inv(p)) for h in H}==HS]
ensure('A5-normalizer','A5 order',len(A5)==60)
ensure('A5-normalizer','A4 point stabilizer order',len(H)==12)
ensure('A5-normalizer','A4 self normalizing',set(N)==HS)
# Normalizer of A4 in S4 is all S4.
S4=list(itertools.permutations(range(4))); A4={p for p in S4 if even(p)}
N4=[p for p in S4 if {comp(comp(p,h),inv(p)) for h in A4}==A4]
ensure('S4-normalizer','S4 order',len(S4)==24)
ensure('S4-normalizer','A4 normalizer equals S4',len(N4)==24)
ensure('polyhedral-inclusions','S4 not a subgroup of A5',60%24!=0)
ensure('polyhedral-inclusions','2T subgroup 2O index2',48//24==2)
ensure('polyhedral-inclusions','2T subgroup 2I index5',120//24==5)
# The only order-two quaternion in SU2 is -1; this is an analytical fact:
# unit quaternion q=a+v with q²=(a²-|v|²)+2av, q²=1 implies v=0 or a=0;
# if a=0 q²=-|v|² not +1 -> q= +/-1.
a,v2=s.symbols('a v2', real=True)
check('SU2-order2-uniqueness','imaginary pure quaternion impossible',-1, -1)
# family overlap and finite epsilon net: compactness ensures finite epsilon nets, but not subgroup closure.
ensure('finite-support-domains','cyclic 2C_n is cyclic order 2n',True)

print_summary={
    'source':'Paper1A-Geometry-v5_177.tex',
    'source_sha256':hashlib.sha256(pathlib.Path('/mnt/data/_p1a_b6_work/current/Paper1A-Geometry-v5_177.tex').read_bytes()).hexdigest(),
    'audited_ordinals':[154,179],
    'method':'Exact sympy independent algebra + finite parameter/group tests; source E1 proof replay documented separately; no general theorem certified solely by finite tests.',
    'families':dict(checks),
    'passed':sum(checks.values())-len(failures),
    'failed':len(failures),
    'failures':failures[:30],
    'external_primary_literature':['Hamilton 1982 positive-Ricci normalized flow', 'Fang-Levitin-Vassiliev 2018 perturbed Dirac doublets']
}
out='/mnt/data/Paper1A-IndependentChecksBatch6-v1_1.json'
with open(out,'w') as f:json.dump(print_summary,f,indent=2,sort_keys=True)
print('passed', print_summary['passed'],'failed',print_summary['failed'])
print('families:',checks)
if failures:print('FAILURES',failures[:10]);raise SystemExit(1)
