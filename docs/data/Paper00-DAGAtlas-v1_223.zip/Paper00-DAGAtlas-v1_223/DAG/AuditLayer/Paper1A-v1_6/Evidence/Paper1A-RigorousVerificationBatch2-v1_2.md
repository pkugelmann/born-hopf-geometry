# Paper I-A — Rigorous Verification, Batch 2 (v1.2)

**Authoritative source:** `Paper1A-Geometry-v5_177.tex` in `Paper00-PapersMinimal-v3_017(1).zip`  
**Source SHA256:** `0ddd521f70f237830ff4f018c8eebedb4bde43b62a0c9b92eb8c3ec3348f9f17`  
**Rules:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4` and `Paper00-ProofChainAuditProtocol-v1_1`. E0 integrity, E1 source replay, E3 distinct analytical/primary-reference checks, and E4 adversarial normalization/domain tests were kept separate. No paper source or parent ZIP was edited.  
**Batch coverage:** formal objects **21–40** of 179, source lines **1390–2205**. **Cumulative coverage:** 40/179 (22.35%). Next source line: **2206** (`p1:lem:conformal-killing-exhaustion`). The classification remains `PARTIALLY_AUDITED` until remaining 139 formal objects are checked.

## Verdict and evidence counts

- **Batch 2:** **14 `VERIFIED`**, **4 `REPRODUCED`**, **2 `FORMALIZED`**. Historical atlas statuses of seven existing theorems/propositions have been *provisionally upgraded on an explicitly written all-index E3 certificate*, rather than on finite matrix agreement: claim #29, #30, #32, #34, #37, #38, #39. Those changes are recorded in the Batch 2 ledger and will be incorporated into the single global DAG only at the final release.
- **Across batches 1–2:** **25 `VERIFIED`**, **6 `REPRODUCED`**, **9 `FORMALIZED`**; the remaining 139 claims have not been examined in the present audit sequence.
- **Fresh independent/scoped controls:** **10,201 passed; zero failed**, with additional operator-level checks for Hodge Laplacian, orientation-correct curl, and the Lichnerowicz spin identity (`Paper1A-IndependentChecksBatch2-v1_2.py`, `.json`). These computations provide E2/E4 checks on finite blocks and samples. The analytical arguments below—not extrapolation from those samples—are the basis for any all-index E3 claim.
- **Confirmed new mathematical gaps:** **none in this batch**. One **existing, minor DAG-only documentation inconsistency** (`BH-IA-DAG-000001`, originating in Batch 1) remains queued for the final archive reconciliation. Absence of a confirmed gap within audited claims is not proof of entire-framework completeness.

## A. Sub-Riemannian geometry and analytic estimates (1390–1823)

### A1. Hopf marking, global CC geometry and the Heisenberg tangent cone

The definitions `H=ker(η)`, `g_H=g|H` are **relative to the already chosen** round metric, Hopf circle and orientation, not a newly derived unique physical selector (1393–1409). The signed right-invariant bracket `[E₁,E₂]=(2/R)ξ_η mod H` yields an equiregular, step-two contact distribution (1413–1424). The CC length minimization is over a subset of Riemannian admissible curves with identical integrands, so the exact comparison `d_CC≥d_g` is secure. For the primary *right*-invariant marking, the correct endpoint ordering is `d_CC(p,q)=d_CC(1,qp⁻¹)`. The opposite copy instead has left-invariant ordering. These cannot be interchanged without inversion (1434–1473).

For the global synthesis, the referenced theorem of **Boscain–Rossi (2008)** explicitly places the SU(2) cut locus at the vertical Cartan/Hopf circle minus the identity. The source identifies the actual horizontal vector norm as `R/2` in their metric and transports their *left*-invariant solution to the fixed *right*-invariant Hopf marking by inversion. Independent SU(2) matrix-exponential controls verify the normal geodesic endpoint at `s_cut=2π/sqrt(1+z²)` for sampled positive and negative `z`, the generator period `4π` versus quaternion angle period `2π`, and the exact vertical formula

\[
d_{CC}(1,e^{i\theta})=R\sqrt{\theta(2\pi-\theta)},\qquad0\le\theta\le2\pi .
\]

The primary theorem supplies the global optimality/whole conjugate-locus information; an isolated numerical trajectory is *not* taken to prove it. Claim #23 retains its inherited `VERIFIED` status, and the broader #22 is conservatively left `REPRODUCED` because it invokes that imported global synthesis rather than independently constructing all endpoints. Primary work: [Boscain–Rossi, SIAM JCO](https://epubs.siam.org/doi/abs/10.1137/070703727).

For the tangent cone (1549–1628), in source coordinates the vertical bracket is `[X_κ,Y_κ]=κ∂ₜ`; the **signed** coordinate change `z=t/κ`, including κ<0, gives `[X₀,Y₀]=∂_z` for `X₀=∂_x−(y/2)∂_z`, `Y₀=∂_y+(x/2)∂_z`. The anisotropic grading `(1,1,2)` is exact. Source distinguishes nilpotent frame convergence from **metric** blow-up convergence and expressly imports Mitchell's theorem for the latter. Hence #24 remains `REPRODUCED`; #25, the equiregular Hausdorff dimension `Q=1+1+2=4`, retains `VERIFIED`.

The small-ball Popp measure expansion and right-invariant equivalence to round volume give `V(r)~C r⁴`, independent of center. The source's separate large-ball estimate correctly extends `c r⁴≤V(r)≤C r⁴` through the finite CC diameter without asserting sphere-boundary measure zero. It yields a global doubling constant. This is an analytic fact about the **specific compact homogeneous contact** metric, not a claim about all three-dimensional Riemannian metrics (1646–1689).

### A2. Same-ball Poincaré and Sobolev estimates

The local **same-ball** `L²` Poincaré inequality is not being silently substituted for a merely enlarged-ball inequality: **Hajłasz–Koskela, Section 11 immediately after Theorem 11.20**, explicitly notes that Jerison proved `L²` on both sides and that the enlargement `2B` can be replaced by `B`. The source (1706–1768) then constructs an all-scale weak estimate by finite chains, invokes global 4-regular doubling, and applies the **John-domain** estimate in Hajłasz–Koskela Theorem 9.7 / Corollary 9.8 to recover the exact all-scale, same-ball `L²` conclusion. The theorem's published `p*=sp/(s−p)` gives `p*=4` at `s=4,p=2` and matches the source's intermediate `L⁴` estimate. Both #26 and #27 retain `VERIFIED`.

This audit checked the potential adversarial failure points: `r→0`, `r≥diam_CC`, center-independent constants, horizontal upper gradients and truncations, distinction between weak `2B` and strong `B`, and presence of the inhomogeneous `‖u‖₂` term needed to control constants in the global Sobolev embedding. Primary work: [Hajłasz–Koskela, *Sobolev Met Poincaré* (2000)](https://sites.pitt.edu/~hajlasz/OriginalPublications/HajlaszK-SobolevMetPoincare-test-MemoirsAMS-145-2000-no.688-101pp.pdf), §§9.1–9.2 and 11.4.

The Lévy–Gromov concentration statement (#28, 1807–1823) is explicitly **Riemannian**, uses probability-normalized volume, and scales neighborhoods by `ε/R`. The numerical hemisphere check is not a proof for arbitrary measurable sets. The source imports the all-sets isoperimetric theorem, so #28 remains `REPRODUCED` rather than being promoted on an unrelated CC estimate or a sample cap.

## B. Horizontal and Hopf-charge spectral resolution (1826–1974)

### B1. Independent all-index charge-spectrum proof — #29 and #32

A proof distinct from the manuscript's Peter–Weyl weight-counting route starts with bihomogeneous polynomials in `z=(z₁,z₂)∈ℂ²`. Let `P_(a,b)` be bidegree `(a,b)`, so `dim P_(a,b)=(a+1)(b+1)`. For `a,b>0`, the Euclidean Laplacian maps `P_(a,b)` onto `P_(a−1,b−1)`. Thus the bihomogeneous **harmonic** subspace has dimension `(a+1)(b+1)−ab=a+b+1` (and the same formula holds when `a=0` or `b=0`). Restricting to the 3-sphere gives round scalar eigenvalue `k(k+2)/R²` with

\[
k=a+b,\qquad q=a-b,\qquad |q|\le k,\quad q\equiv k\pmod 2,
\]

and **exactly `k+1` independent modes** in each `(k,q)` sector. All `a,b≥0` appear, establishing completeness and recovering total degree-k multiplicity `(k+1)²`. With the actual Hopf generator `Q_geom=−2i∂ψ`, the horizontal operator is the round Casimir minus vertical square. Consequently

\[
\lambda^H_{kq}=\frac{k(k+2)-q^2}{R^2};\quad
\operatorname{Spec}(\Delta\vert_{\mathcal V_q})
 =\left\{\frac{k(k+2)}{R^2}:k\ge|q|,\ k\equiv q\pmod2\right\}.
\]

This supplies `E3` for **all** k, not merely `k≤50`, and upgrades #29 (horizontal spectral resolution) and #32 (scalar spectrum by charge) to `VERIFIED`. For #33 the minimum `k=|q|` gives the positive charge gap for `q≠0`, preserving `VERIFIED`.

### B2. Independent zeta/counting calculation — #30

Writing `u=2a+1`, `v=2b+1`, the exact parent eigenvalue is `(uv−1)/R²` with multiplicity `(u+v)/2`. The exact dimensionless spectral Dirichlet series at `Re(z)>2` is

\[
\sum_{u,v\ge1\atop u,v\text{ odd}}
 \frac{u+v}{2}(uv)^{-z}
 =\bigl(1-2^{1-z}\bigr)\bigl(1-2^{-z}\bigr)
   \zeta(z-1)\zeta(z).
\]

Its leading positive pole at `z=2` has residue `(1/2)(3/4)ζ(2)=π²/16`. The positive spectral Tauberian theorem therefore gives the **independent** all-spectrum asymptotic `N_H(Λ)~π²R⁴Λ²/32`. This is a different route from the source's direct heat-trace Riemann sum. The latter exactly rewrites as

\[
H_H(t)=\frac{e^{s}}2\sum_{n>0\atop n\text{ odd}}\frac{n}{\sinh(sn)},\quad
s=t/R^2,\quad
H_H(t)\sim\frac{\pi^2R^4}{16t^2}.
\]

For a **fixed integer q**, `k=|q|+2ℓ` instead yields `H_q(t)~R²/(4t)` by a spacing-two Euler–Maclaurin comparison. The full **round** scalar parent has `t⁻³ᐟ²`, and a **fixed finite** spectral truncation tends to its finite rank, `t⁰`. Hence the respective dimensions are **4, 2, 3 and 0 only for their specified operators and limits**; none is a unique UV dimension of an unspecified physical object. The independent divisor/counting argument plus E4 cutoff tests upgrades #30 to `VERIFIED`. At dimensionless Λ=10,000 the exact count is **30,853,656**, just **1.00036×** the leading coefficient; this is a consistency check, not the proof.

### B3. Line bundles and normalization — #31, #34

The paper explicitly distinguishes **integer** `Q_geom` from the half-normalized spinorial bookkeeping `Qhat=Q_geom/2`. This is a convention (#31 `FORMALIZED`), not an empirical charge identification. For #34, the all-integer character-to-section equivalence is independently checked in overlap charts: if `s_j(x)=e^{iα_ij(x)}s_i(x)` are local Hopf sections, a function with `f(e^{iα}g)=e^{iqα}f(g)` has local coefficients `φ_j=e^{iqα_ij}φ_i`, precisely the `L^q` transition law **in the positive-degree convention declared by the source**. Conversely these coefficients glue uniquely to an equivariant function. The L² measures differ at most by the constant fiber-volume normalization. This is an analytic bundle equivalence, not a physical particle-state selector. #34 upgrades to `VERIFIED`.

## C. Hodge, vector, spinor and Weyl structure (1976–2205)

Hodge decomposition (#35) is correctly proved from the Green identity and elliptic Hodge theorem; the harmonic-to-de-Rham isomorphism remains an **imported** standard theorem, so this specific object remains `REPRODUCED`. The Betti numbers `(1,0,0,1)` and absence of harmonic one-/two-forms (#36) remain `VERIFIED`. The formal codifferential has the correct three-dimensional signs: on r-forms `d†=(−1)^r *d*`, and `*Δ=Δ*` identifies one- and two-form spectra (1992–2101).

### C1. Independent SU(2) one-form and curl compiler — #37 and vector part of #38

In a radius-R orthonormal frame satisfying `[E_i,E_j]=(2/R)ε_ijkE_k`, let `J_i` be spin-j Hermitian SU(2) matrices and `S_i` the **spin-one** matrices acting on form indices. The covariant derivative is

\[
\nabla_{E_i}=-(i/R)(2J_i+S_i).
\]

The Weitzenböck identity with `Ric=2/R²` gives the **operator identity for every j**

\[
\Delta_1=\frac4{R^2}\bigl(j(j+1)\mathbf1+\mathbf J\cdot\mathbf S+\mathbf1\bigr).
\]

The Clebsch–Gordan decomposition `j⊗1=(j+1)⊕j⊕(j−1)` yields eigenvalues `4(j+1)²/R²`, `4j(j+1)/R²`, and `4j²/R²`, in the valid respective branches. The middle subspace is exact; the outer subspaces are coexact. Accounting for the external `2j+1` coefficient multiplicity and relabeling the coexact level `L=2j±1` gives **both chiral multiplicities `L(L+2)`** at eigenvalue `(L+1)²/R²`. This is an all-j independent derivation of #37, not an appeal to finite eigenvalue matches.

The paper's chosen contact orientation `η∧dη>0` is **opposite** the positive orientation of the displayed cyclic frame, because `dη(E₁,E₂)=−2/R`. In precisely that orientation,

\[
\mathrm{curl}=\star d=\frac{2}{R}(\mathbf J\cdot\mathbf S+\mathbf1).
\]

On the `(j+1,j)` branch this has **positive** eigenvalue `2(j+1)/R`, whereas `(j−1,j)` has **negative** `−2j/R`; the exact `(j,j)` branch has eigenvalue zero. Thus the source's `((L+1)/2,(L−1)/2)` positive and mirrored negative Spin(4) modules are sign-correct. At `j=0` and `j=1/2` nonexistent branches are excluded. The matrix script independently compares the complete exterior-derivative Hodge operator against the Casimir identity and checks the actual orientation-dependent curl matrix for all sampled j and three radii. These all-index derivations upgrade #37 and the vector component of #38.

### C2. Signed spinor/Dirac and Lichnerowicz — spinor part of #38 and #39

With the source's Clifford convention `c_i=iσ_i`, the induced spin connection and Dirac operator in the same spin-j block satisfy

\[
\nabla_{E_i}^{\rm spin}=-(i/R)(2J_i+\sigma_i/2),\qquad
D=\frac2R\boldsymbol\sigma\cdot\mathbf J+\frac3{2R}.
\]

The Pauli identity `(σ·J)²=J²−σ·J` and `j⊗1/2=(j+1/2)⊕(j−1/2)` yield both signed eigenvalue branches `±(k+3/2)/R`, with exactly `(k+1)(k+2)` modes per sign and the source's `((k+1)/2,k/2)` / `(k/2,(k+1)/2)` modules. This certifies #38 on the entire representation ladder, including the `k=0` asymmetry prior to reindexing.

The same matrices give the **operator identity**

\[
D^2=\frac{4J^2+2\boldsymbol\sigma\cdot\mathbf J+9/4}{R^2},\qquad
\nabla^*\nabla=\frac{4J^2+2\boldsymbol\sigma\cdot\mathbf J+3/4}{R^2},
\]

hence `D²−∇*∇=3/(2R²)` for every spin j. It proves the stated Lichnerowicz constant; nonnegativity gives the weaker lower bound and the exact spectrum gives the sharper gap `3/(2R)`. This upgrades #39 to `VERIFIED`. No spinor zero mode appears.

### C3. Scalar Weyl law — #40

For `λ≥0`, `M=floor(sqrt(1+R²λ)−1)` exactly counts the allowed levels `k=0,...,M`. Therefore

\[
N_0(\lambda)=\frac{(M+1)(M+2)(2M+3)}6
=\frac{R^3}{3}\lambda^{3/2}+O(\lambda)
\]

for fixed `R>0`. Direct edge tests at eigenvalues, mid-gap thresholds, five large cutoffs and three radii confirm the floor convention and the constant `Vol(S³)/(6π²)=R³/3`. #40 retains `VERIFIED`.

## Exact claim disposition (source/ID matched)

| # | Source lines | Exact canonical claim ID | Current Batch 2 verdict |
|---:|---:|---|---|
| 21 | 1396–1409 | `UNLABELED:Paper1A:definition:v5_177:1396` | `FORMALIZED` |
| 22 | 1434–1455 | `p1:thm:marked-cc-distance` | `REPRODUCED` |
| 23 | 1479–1485 | `p1:thm:marked-cc-global` | `VERIFIED` |
| 24 | 1549–1562 | `p1:prop:nilpotent-approx` | `REPRODUCED` |
| 25 | 1631–1634 | `p1:cor:hausdorff-dim` | `VERIFIED` |
| 26 | 1696–1705 | `p1:thm:sr-poincare` | `VERIFIED` |
| 27 | 1771–1779 | `p1:thm:sr-sobolev` | `VERIFIED` |
| 28 | 1807–1819 | `p1a:theorem:atlas-l-evy-gromov-concentration-on-the-round-3-sphe-59aa4cc` | `REPRODUCED` |
| 29 | 1831–1841 | `p1a:theorem:atlas-spectral-resolution-8f48b6f` | **`VERIFIED` (E3 upgrade)** |
| 30 | 1848–1867 | `p1:thm:horizontal-spectral-dimensions` | **`VERIFIED` (E3 upgrade)** |
| 31 | 1894–1908 | `UNLABELED:Paper1A:remark:v5_177:1894` | `FORMALIZED` |
| 32 | 1910–1924 | `p1:thm:scalar-spectrum-by-hopf-charge` | **`VERIFIED` (E3 upgrade)** |
| 33 | 1936–1944 | `p1:cor:hopf-charge-gap` | `VERIFIED` |
| 34 | 1951–1961 | `p1:prop:hopf-charge-line-bundle` | **`VERIFIED` (E3 upgrade)** |
| 35 | 2003–2013 | `p1a:theorem:atlas-hodge-decomposition-a115d4d` | `REPRODUCED` |
| 36 | 2050–2060 | `p1a:corollary:atlas-cohomology-e382521` | `VERIFIED` |
| 37 | 2071–2080 | `p1:thm:hodge-one-form-spectrum` | **`VERIFIED` (E3 upgrade)** |
| 38 | 2109–2136 | `p1:thm:representation-harmonic-package` | **`VERIFIED` (E3 upgrade)** |
| 39 | 2145–2163 | `p1:thm:lichnerowicz-s3` | **`VERIFIED` (E3 upgrade)** |
| 40 | 2173–2197 | `p1:prop:scalar-weyl-law` | `VERIFIED` |

**Integrity:** All 20 SOURCE-AS-PRINTED statements match both the exact current manuscript span and the stored SHA256 statement hashes. All seven previously recorded, material, proof-use edges into these formal objects were verified against their exact source-use lines; no citation-only edge was promoted. No new canonical assumption was minted. The batch evidence ledger preserves these edges, proof spans, explicit E1/E3/E4 statements, carried issue and seven status updates separately from the inherited atlas.

## Issues and constitutional/observable boundaries

**New Batch 2 mathematical issues:** none confirmed. **Unresolved inherited issue:** `BH-IA-DAG-000001`, `DAG_ONLY_INTEGRITY`, **MINOR** — the current active `DAG/AuditLayer/Paper1A-v1_5/README.md` still has the previous-layer version/hash and reports formerly open gaps, whereas current source and active registries are synchronized. Exact origin: `Paper00-DAGAtlas-v1_150(1).zip`, active Paper I-A layer README, lines 1–8. **Affected scope:** documentation only; no proof or confirmed cross-paper/observable impact. **Final obligation:** update that README in the next versioned global DAG and read back source hash, index and active issue list. Preserve older resolved issues as history, not new failures.

**Reference versus physical realization:** a selected mathematical Hopf structure or integer Fourier charge is not by itself a chosen particle charge, decay rule, metric dynamical selector or physical finite cutoff. The audit does not require a general spectral calculation to generate a physical state that the source never asserts. The only claimed conclusions in these objects are the stated metric, measure, operator, representation and limit relations. This prevents unsupported observable inference in either direction.

**Next batch boundary:** begin at line **2206**, with conformal-Killing exhaustion, tensor harmonics and the ensuing spherical/geometric spectra. Neither the original manuscript nor any parent archive has changed. Per user instruction, **do not publish partial global DAG/audit ZIPs**. After the **last batch**, merge the complete claim/evidence/gap records, refresh only the latest active versions, and produce the one version-incremented DAG ZIP and one version-incremented proof-chain-audits ZIP, checking archive readback and preserving other papers' latest audit layers.

**Current batch artifacts:**

- `Paper1A-RigorousVerificationBatch2Ledger-v1_2.json` — full exact claim/evidence/edge ledger.
- `Paper1A-IndependentChecksBatch2-v1_2.py` — reproducible, self-contained numerical/exact finite-control source.
- `Paper1A-IndependentChecksBatch2-v1_2.json` — 10,201 passing E2/E4 controls with residuals and heat/count samples.
