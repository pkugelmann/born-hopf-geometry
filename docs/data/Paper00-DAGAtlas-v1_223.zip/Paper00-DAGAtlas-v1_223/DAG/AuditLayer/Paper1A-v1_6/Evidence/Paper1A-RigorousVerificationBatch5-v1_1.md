# Born–Hopf Geometry I-A — Rigorous Verification DAG, Batch 5

**Frozen current source:** `Paper1A-Geometry-v5_177.tex`, SHA-256 `0ddd521f70f237830ff4f018c8eebedb4bde43b62a0c9b92eb8c3ec3348f9f17` in `Paper00-PapersMinimal-v3_017(1).zip`.  
**Protocols:** RigorousVerificationDAG v2.4; ProofChainAudit v1.1.  
**Archives read without modification:** `Paper00-DAGAtlas-v1_150(1).zip` and `Paper00-ProofChainAudits-v1_64.zip`.

**Coverage:** **formal objects #117–153** (37 of 179), from **source lines 4867–6211**, plus proof details through line **6268** and every substantive adjacent table; next **#154**, Berger definition at **line 6293**. Cumulative **153/179 = 85.5%**. This is not the final atlas release.

## Verdict / independent control summary

| Status | Batch 5 #117–153 | Cumulative #1–153 |
|---|---:|---:|
| `VERIFIED` | 17 | 83 |
| `REPRODUCED` | 10 | 28 |
| `FORMALIZED` | 10 | 42 |
| `UNRESOLVED` among formal objects | 0 | 0 |

**7,982 independent E3/E4 algebraic and finite-quantifier controls passed, 0 failed**, across 43 separately recorded families. These include exact rational orthogonal-polynomial integrals for scalar harmonic band m=0,1,2, and analytic identities plus numerical Poisson-summation heat controls. Global cited results remain only `REPRODUCED` unless the exact claimed special case has an independent proof certificate; no finite computational sample certifies all smooth manifolds or full literature theorems. No new mathematically refuted *formal* claim was confirmed; one extra, nonformal table row has a material interpretation ambiguity (`BH-IA-SRC-000003`).

### A. Scalar band, full carrier distinction and scaling (#117–119)

The scalar band is \(\mathcal P_m^{\rm sc}=\bigoplus_{k=0}^m E_k^{\rm sc}\), not the full non-diagonal \(\mathcal H_m\) (the latter was checked in Batch 4). In the normalized Haar Hilbert space, let \(K_{m,x}\) reproduce evaluation at x. The positive rank-one measure is a POVM because the evaluation analysis map \(f\mapsto f(x)\) is an isometry of the retained scalar subspace into L²(Haar):

\[
  \int |K_{m,x}\rangle\langle K_{m,x}|\,d\mu_H(x)=I,
  \quad
  \int x_a |K_{m,x}\rangle\langle K_{m,x}|\,d\mu_H(x)
     =\Pi_m^{\rm sc}M_{x_a}\Pi_m^{\rm sc}.
\]

An independent exact sphere-moment integration constructs 1+4+9 scalar harmonic basis functions for m=2 and confirms the resolution, Toeplitz first moments, and Haar self-adjointness at four radii. For m=1 in a Haar-orthonormal basis \(\{1,2x_0/R,\ldots,2x_3/R\}\), the only nonzero coordinate matrix elements are \(\langle1,M_{x_a}2x_b/R\rangle=R\delta_{ab}/2\). This is not a localization-apparatus selection. The isotypic commutant uses multiplicity factors and never identifies all operator algebras with one another. Standard homothety checks include the heat-kernel t/λ² and λ^-3 factors; Reeb period belongs to the specified metric-scaled contact form.

### B. Exact contact, topology and Chern–Simons conventions (#120–139)

The Hopf-coordinate boundary restriction of \(\lambda_{\rm std}=\tfrac12\sum(x_ady_a-y_adx_a)\) is \(R²/4(d\psi+\cos\theta\,d\phi)=(R/2)\eta\). Consequently the rescaled Liouville form fills the specified contact form, and the imported tightness/positive-tight uniqueness results apply to the *standard* contact structure, not arbitrary forms. With T_a=-iσ_a/2, the antisymmetrized matrix trace of T_1T_2T_3 is -3/2; since the SU(2) Maurer–Cartan frame volume is 16π², the winding-normalized real CS generator integrates to +1 in the compatible orientation. The Chern–Simons **gauge-invariant** value is nevertheless 0 modulo Z for the Maurer–Cartan pure gauge. The gauge transgression sign was tested against A=0, A^g=g^-1dg, so it is not taken on faith from an unrelated convention.

The right/left and Chern orientation is marked. A fixed-handedness orthogonal complex-structure family is SO(4)/U(2)=S², but the two handedness components do not mix under SO(4); relative average weights on their union are free. The chosen Reeb generator X_H=2∂ψ=Rξ_η has principal period 2π and positive primitive 2πX_H. The metric-normalized Reeb action is 2πR; these values are compatible but not interchangeable. Under a chosen contact lift to the unit cotangent bundle of S²(R/2), the downstairs unit-speed geodesic period is πR. The Poincare theorem, Boothby–Wang and global contact classifications remain explicitly imported results, with their exact hypotheses retained.

### C. Linking, Whitehead, great circles, and Yamabe (#140–150)

For the positive orientation, distinct Hopf fibers have linking +1. The source uses two different helicity volume forms and consequently two different primitives. Their exact consequences are

\[
\int_{S^3}\eta\wedge d\eta=4\pi^2 R^2,\qquad
\operatorname{Hel}_{\eta\wedge d\eta}(\xi_\eta)=4\pi^2 R^2,\qquad
\operatorname{Hel}_{\mathrm{vol}}(\xi_\eta)=\pi^2R^4.
\]

Whitehead's normalization \(\Omega=\omega/(2\pi)\) gives \(\alpha=\eta/(2\pi R)\) and Hopf(f)=+1; raw helicity, Whitehead integer, and CS real representative must never be equated before normalizing. The positive (not negative) Hopf-link open book supports the standard tight contact structure. Every standard Hopf fiber is a complex-line great circle. The stronger statement about arbitrary smooth great-circle fibrations and deformation-to-Hopf is an imported Gluck/Gluck–Warner theorem, not a claim of literal metric/axis uniqueness. The round Yamabe equality family is imported from sharp conformal geometry; the radius-free numerical constant from the constant profile is consistent.

### D. Chirality, eta and Seeley–DeWitt (#147–153)

The sign conventions give \(\mathrm{curl}\,\xi_\eta=(2/R)\xi_\eta\). An orientation-reversing O(4) map exchanges self-dual and anti-self-dual bivectors and hence the Spin(4) SU(2) factors; this is not an inner SO(4) operation. The *untwisted round* Dirac spectrum \(\pm(k+3/2)/R\) has equal multiplicities \((k+1)(k+2)\), yielding η_D(s)=0 on a right half-plane and by continuation at zero. This does not say a Berger, twisted or otherwise asymmetric Dirac operator has zero eta.

The scalar heat coefficients were checked two independent ways: direct insertion of \(\mathrm{scal}=6/R²\), \(\|\mathrm{Ric}\|²=\|\mathrm{Rm}\|²=12/R⁴\), and Poisson summation from \(\mathrm{Tr}\,e^{-t\Delta}=e^{t/R²}\sum_{n\ge1}n²e^{-n²t/R²}\). Both give

\[
 a_0=2\pi²R³,\qquad a_2=2\pi²R,\qquad a_4=\pi²/R.
\]

They are **integrated small-time coefficients** of a closed-manifold positive Laplacian; they are not exact finite-t heat traces.

## Issues (all distinct IDs, source and graph)

**`BH-IA-DAG-000001` — inherited DAG documentation/index drift; minor metadata / moderate index-integration risk.** Active `DAG/AuditLayer/Paper1A-v1_5/README.md` and `Index.json` still contain a historical source hash/open-issue wording, non-existing v1_125 combined-layer references, and a stale Berger-decoupling line locator. The source manuscript and active combined graph are not thereby mathematically refuted. **Repair obligation for final archive:** make README, Index and source anchors match active names/hashes and preserve old provenance separately. No evidenced downstream cross-paper path.

**`BH-IA-DAG-000002` — inherited unsupported material-premise edge; moderate DAG-only error.** Existing `BH-IA-V176-EDGE-0030` makes the *particular round S³ 3-Sasakian example* the proof premise for universal compact 3D rigidity (`p1:cor:3sasakian-rigidity`, 4606–4614). The manuscript instead imports a general rigidity theorem. **Repair obligation for final archive:** quarantine or retype the material edge; retain source general imported-theorem route and its hypotheses. The theorem is not disproved; no proven cross-paper descendants.

**`BH-IA-SRC-000003` — new source scope/evidence ambiguity at summary table, moderate, not a refutation of H₁ or m_p=1.** Paper I-A line **6017**, `p1:tab:rigidity-theorems-complete`, reads *“Level-1 closure property”*, describing m=1 as retaining no Clebsch–Gordan exterior channels out of the protected block. Two readings differ:

- **Cutoff statement (true):** H₁ defined at 4175–4188 only *retains* irreducible types with j_L+j_R≤1. It does not require the unprojected tensor algebra to be closed.
- **Unprojected CG closure (false):** the precise allowed spinor and vector sectors have

  \[
  (\tfrac12,0)\otimes(\tfrac12,\tfrac12)
     =(0,\tfrac12)\oplus(1,\tfrac12).
  \]
  The latter summand has total spin 3/2 and lies outside H₁. Likewise, `(0,1/2)⊗(1/2,1/2)` has the exterior `(1/2,1)` branch. Positive control: `(1/2,0)⊗(1/2,0)=(0,0)⊕(1,0)` remains inside H₁. These are exact, not numerical, countertests.

The table does not specify a product operation, projection rule, or independent proof of physical CG-closure. The row's term **“closure” therefore must not become a proof-traversable physical selection/closure premise** until its exact scope is clarified. The GP2-based carrier-type construction and **m_p=1** derivation in Paper II-B are separate and not challenged by this finding. Proven cross-paper impact: **none**. Possible impact: interpretations that use this isolated table row to claim full unprojected tensor closure.


## Formal-object claim-by-claim adjudication

| # | Source lines | Label / formal object | Verdict | Source-bound result and scope |
|---:|---:|---|---|---|
| 117 | 4867–4896 | `p1:thm:scalar-band-evaluation-povm` | **VERIFIED** | Finite scalar RKHS evaluation frame gives an exact normalized positive operator-valued measure. Its coordinate moment equals the scalar Toeplitz compression. Explicit harmonic-polynomial model up to m=2; not a POVM on full H_m or an apparatus selector. |
| 118 | 4971–4986 | `p1:thm:isotypic-commutant` | **VERIFIED** | Evaluation of multiplicity intertwiners and Schur block diagonalization gives End_G(V)=⊕End(Mπ)⊗1, including nontrivial multiplicities. The decomposition is canonical up to irreducible representative equivalence, while bases on Mπ are not. |
| 119 | 4998–5061 | `p1:prop:homothetic-scaling-laws` | **VERIFIED** | Constant homothety: metric λ², volume λ³, Ricci (0,2) unchanged, sectional and scalar λ^-2, Laplace λ^-2, Dirac λ^-1, heat λ^-3 with t/λ², Reeb action λ. Fixed positive λ and round normalized Hopf form. |
| 120 | 5233–5260 | `p1:prop:standard-contact-fill-tight` | **REPRODUCED** | Direct Liouville pullback gives λ_std\|S³=R²/4(dψ+cosθdφ)=(R/2)η. Exact symplectic filling and transversality are local; tightness/uniqueness of positive tight structure are imported global Eliashberg/contact results. |
| 121 | 5283–5295 | `p1:def:cs-normalized` | **FORMALIZED** | Defines 1/(8π²) trace-normalized Chern-Simons 3-form and its real integral on trivialized SU(2) bundle; gauge-invariant output only modulo integer. |
| 122 | 5297–5312 | `p1:prop:cs-gauge-ambiguity` | **VERIFIED** | Under A^g=g^-1Ag+g^-1dg, transgression gives integer gauge shift with the stated winding sign. Pure gauge A=0 gives the sign check CS(g^-1dg)=deg g. |
| 123 | 5326–5338 | `p1:thm:mc-generator` | **VERIFIED** | Maurer-Cartan dθ+θ²=0 yields -1/(24π²)Tr θ³; independent Pauli/SU(2) wedge trace integral is ±1. Real representative ±1 is zero in R/Z. |
| 124 | 5351–5359 | `p1:cor:cs-volume-relation` | **VERIFIED** | Any bi-invariant 3-form is constant multiple of volume; SU(2) generator integral and Vol=2π²R³ enforce ±vol/(2π²R³), all positive radii. |
| 125 | 5366–5368 | `(unlabeled remark)` | **FORMALIZED** | Explicit guard: numeric real CS representative and its volume density are trace/orientation normalization dependent; modulo-Z gauge class is distinct. |
| 126 | 5374–5388 | `(unlabeled remark)` | **FORMALIZED** | Local section over a spanning surface gives holonomy exp(±i∫Σω); the sign depends on connection representation and parallel-transport convention, not Riemannian area scale. |
| 127 | 5393–5410 | `p1:thm:boothby-wang-hopf` | **REPRODUCED** | Fixed Hopf Reeb circle is free and regular; dη0 is horizontal, descends as symplectic ω of total area 2π in chosen orientation. Boothby-Wang interpretation imports standard prequantization theorem. |
| 128 | 5423–5426 | `(unlabeled remark)` | **FORMALIZED** | Nonzero Hopf Chern class is the obstruction to a continuous/smooth global principal-circle section; a trivial bundle would be needed. |
| 129 | 5431–5450 | `p1:thm:hopf-homotopy-exact-sequence` | **REPRODUCED** | Hopf-fibration homotopy exact sequence: π2(S²)→π1(S¹) is multiplication by the Chern generator ±1; π3(S³)→π3(S²) is an isomorphism. Global topology imported; no arbitrary S³→S² map asserted generator. |
| 130 | 5476–5493 | `p1:prop:hopf-ensemble-isotropy` | **VERIFIED** | Oriented compatible orthogonal complex structures form two S² components, each SO(4)/U(2). Invariant averaging is unique only per component; on their disjoint union relative probability weights remain free. |
| 131 | 5520–5536 | `p1:cor:hopf-class-no-axis` | **VERIFIED** | SO(4) transitivity and nontrivial S² orbit rule out an invariant marked axis. Conjugacy of maximal tori is a classification of equivalent Hopf representatives, not canonical selection of one. |
| 132 | 5549–5569 | `p1:thm:canonical-hopf-u1` | **VERIFIED** | Chosen principal generator X_H=2∂ψ=Rξ_η has η0(X_H)=1 and is uniquely selected by fiber tangency and normalization. Requires a fixed oriented Hopf bundle, not a distinguished axis on unmarked S³. |
| 133 | 5589–5599 | `(unlabeled remark)` | **FORMALIZED** | Periodic Reeb orbits belong to the selected form η0, not to all contact forms defining the same plane field. No stronger classification is inferred. |
| 134 | 5600–5632 | `p1:thm:hopf-normalization-package` | **VERIFIED** | Combines c1=+1 and ∫ω=2π, 2π dimensionless Reeb period and 2πR metric action, and integral SU(2) Cartan generator ±1. No independent adjustable normalization remains once bundle/radius/trace/orientation are fixed. |
| 135 | 5638–5660 | `p1:cor:positive-reeb-lattice` | **VERIFIED** | Period lattice of the circle exponential is 2π Z X_H. A selected positive orientation makes 2π X_H the unique positive primitive element, not a new physical selector. |
| 136 | 5673–5680 | `p1:prop:unit-cotangent-double-cover` | **REPRODUCED** | Antipodal quotient S³/{±1}=RP³≅S(T*S²), with a chosen contact identification matching Hopf and unit-geodesic flows. Base radius R/2 gives projected unit-speed geodesic period πR. Naturality is relative to marking; imported contact identification not free uniqueness. |
| 137 | 5686–5689 | `(unlabeled remark)` | **FORMALIZED** | A contextual cross-description of the quotient model; no standalone physical magnetic-flow inference. |
| 138 | 5693–5696 | `p1:thm:poincare-topological-uniqueness` | **REPRODUCED** | Poincare-Perelman theorem on closed simply connected 3-manifolds and constant-curvature spherical model is fully imported. Compact/simply connected and constant-positive-curvature conditions distinct. |
| 139 | 5804–5816 | `p1:thm:gysin-hopf-bundle` | **REPRODUCED** | Euler/Chern generator of Hopf U(1)-bundle: Gysin connecting map H⁰(S²;Z)→H²(S²;Z) must be multiplication by ±1 for H¹(S³)=H²(S³)=0. Imported general Gysin theorem, specific arithmetic checked. |
| 140 | 5827–5846 | `p1:prop:hopf-linking-helicity` | **VERIFIED** | Hopf distinct fibers have lk=+1 in fixed orientation; with μ=η∧dη the primitive is η, with μ=vol it is (R/2)η. Hence ∫η∧dη=4π²R² and Hel_vol=π²R⁴; no unqualified equality between helicity measures. |
| 141 | 5874–5879 | `p1:thm:positive-hopf-link-open-book` | **REPRODUCED** | Positive Hopf-link annulus open book supports standard tight contact S³; imported contact/open-book theorem. Positive versus negative stabilization matters. |
| 142 | 5889–5894 | `p1:thm:hopf-fibers-great-circles` | **VERIFIED** | Each fiber is intersection of the round sphere in C² with a complex line through the origin, hence a metric great circle; non-Hopf classifications remain imported. |
| 143 | 5902–5907 | `(unlabeled remark)` | **FORMALIZED** | Orthogonal plane field of any smooth great-circle fibration is contact as an imported global theorem, not simply an inference from the standard Hopf case. |
| 144 | 5909–5918 | `p1:rem:great-circle-contact-rigidity` | **REPRODUCED** | Gluck (2022) proves contact/tightness for all smooth great-circle fibrations; Gluck–Warner deformation retraction with Gray stability connects contact structures to standard Hopf. This is deformation/isotopy equivalence, not metric or marked-axis uniqueness. |
| 145 | 5924–5944 | `p1:thm:whitehead-integral-formula` | **REPRODUCED** | For smooth f:S³→S² and normalized ∫Ω=1, H²(S³)=0 gives dα=f*Ω; changes in primitive are exact by H¹(S³)=0. Full homotopy invariance and equality with Hopf invariant are imported from Whitehead. |
| 146 | 5953–5957 | `(unlabeled remark)` | **FORMALIZED** | Hopf generator +1 follows after Ω=ω/(2π), α=η/(2πR). Raw η∧dη, Whitehead integer, and CS real representative are distinct scalings. |
| 147 | 5959–5966 | `p1:prop:hopf-reeb-beltrami` | **VERIFIED** | With η=ξ_η^flat and dη=(2/R)*η, curl ξ_η=(2/R)ξ_η. Sign changes with orientation and is not a metric-independent eigenvalue. |
| 148 | 6040–6047 | `p1:prop:chirality-factor-exchange` | **VERIFIED** | Any determinant-negative O(4) element interchanges self-dual and anti-self-dual 2-forms and hence su(2)_L/R; not inner in SO(4). Spinor chiral labels exchange correspondingly. |
| 149 | 6125–6128 | `p1:thm:yamabe-round-sphere` | **REPRODUCED** | In the round conformal class, the constant-curvature profile minimizes Yamabe energy; complete equality family under conformal automorphisms and homotheties imported from sharp sphere/Obata/Aubin results. |
| 150 | 6134–6136 | `(unlabeled remark)` | **FORMALIZED** | Stereographic Sobolev bubbles are equality-case descriptions and blow-up models in the stated conformal setting; not an unrestricted compactness theorem for arbitrary PDEs. |
| 151 | 6143–6167 | `p1:prop:eta-round-zero` | **VERIFIED** | Untwisted round Dirac eigenvalues ±(k+3/2)/R have equal multiplicities (k+1)(k+2), so eta series vanishes identically on its convergence domain and by continuation at zero. |
| 152 | 6183–6185 | `(unlabeled remark)` | **FORMALIZED** | Restates only the untwisted round Dirac spectral-symmetry conclusion; twisted/asymmetric deformations not included. |
| 153 | 6203–6211 | `p1:prop:integrated-heat-coefficients-s3` | **VERIFIED** | Curvature polynomial gives a0=2π²R³,a2=2π²R,a4=π²/R; independently derive all three from Poisson resummation of ∑(k+1)² exp[-k(k+2)t/R²]. Heat trace is asymptotic as t→0. |


## DAG and lineage checkpoint

Previously registered source-associated material edges **3/3** replayed, specifically `BH-IA-V176-EDGE-0032, BH-IA-V176-EDGE-0033, BH-IA-V176-EDGE-0034`. **8** source-matched candidate material edges are logged in the ledger for final graph merger and must remain *non-traversable* until verified against global graph conditions, reachability and single-node assumption rules. None is promoted from a citation-only reference. No new foundation or physical axioms were introduced. The only new finding is the uncensused table-scope issue above, not a theorem overturning H₁ or m_p=1.

**External primary source spotchecks:** Herman Gluck, *Great circle fibrations and contact structures on the 3-sphere*, https://arxiv.org/abs/1802.03797; Goodman, *Overtwisted open books from sobering arcs*, https://msp.org/agt/2005/5-3/agt-v5-n3-p12-p.pdf (includes the positive Hopf band control); ICM proceedings on geodesic-flow lifts and the unit cotangent cover, https://www.mathunion.org/fileadmin/ICM/Proceedings/uploads/ICM-2018-vol2-ver1-eb.pdf. These are literature corroboration for explicitly imported facts, not new source-premise proofs.

**Next batch:** objects **154–179**, from line **6293** (Berger canonical variation) through exceptional Spin(4) normalizers. At completion, resolve scope/index issues, integrate all batches, and write/reopen the final cleaned latest-version-only DAG Atlas and proof-chain-audits ZIPs. Input archives and paper source remain untouched until that designated final release.
