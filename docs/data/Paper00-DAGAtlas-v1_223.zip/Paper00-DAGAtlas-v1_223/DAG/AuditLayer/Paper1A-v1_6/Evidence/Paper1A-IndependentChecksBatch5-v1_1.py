#!/usr/bin/env python3
"""Independent E3/E4 controls, Paper I-A v5.177, formal claims 117..153.

This is an independent finite-case oracle. Its check counter records exact identities
or genuinely evaluated numerical tests, not one count for every iteration in a theorem.
Imported theorems (Perelman, Eliashberg, Gluck, Whitehead, Obata) are NOT thereby
certified in their full global quantifier domain.
"""
from collections import Counter
from itertools import combinations, permutations, product
from fractions import Fraction
from math import factorial
from pathlib import Path
import json, math
import mpmath as mp
import sympy as sp

C=Counter(); bad=[]; witnesses={}
def check(family, ok, note=''):
    C[family]+=1
    if not bool(ok): bad.append({'family':family,'note':str(note)})

X=sp.symbols('x0:4', real=True)
R=sp.symbols('R',positive=True,real=True)

def sphere_moment(expr,r):
    """Haar probability expectation on S^3(r) by exact polynomial moments."""
    polynomial=sp.Poly(sp.expand(expr),*X)
    out=0
    for degrees,coeff in polynomial.terms():
        if any(v%2 for v in degrees): continue
        a=[v//2 for v in degrees]; n=sum(a)
        mom=(r**(2*n))*sp.prod(sp.rf(sp.Rational(1,2),v) for v in a)/sp.rf(sp.Integer(2),n)
        out+=coeff*mom
    return sp.simplify(out)

# Scalar harmonic shells: 1+4+9=14 real harmonic polynomials through degree 2.
B0=[sp.Integer(1)]
B1=list(X)
B2=[X[i]*X[j] for i,j in combinations(range(4),2)]+[X[0]**2-X[1]**2,X[0]**2+X[1]**2-2*X[2]**2,X[0]**2+X[1]**2+X[2]**2-3*X[3]**2]
for r in (sp.Rational(1,2),sp.Integer(1),sp.Integer(2),sp.Integer(3)):
    for band in range(3):
        B=B0+B1*(band>=1)+B2*(band>=2)
        size=len(B)
        G=sp.Matrix(size,size, lambda i,j: sphere_moment(B[i]*B[j],r))
        check('povm_gram_nonsingular',G.det()!=0,(r,band))
        check('povm_band_dimension',size == sum((k+1)**2 for k in range(band+1)))
        for i in range(size):
            for j in range(size):
                check('povm_gram_symmetry',G[i,j]==G[j,i])
                if i<1 and j>=1:
                    check('povm_shell_orthogonality',G[i,j]==0)
        Gi=G.inv()
        # Operator E=G^-1 int phi phi^T. Exact matrix identity, independent sphere moment oracle.
        N=sp.simplify(Gi*G)
        for i in range(size):
            for j in range(size): check('povm_resolution_exact', N[i,j]==int(i==j))
        for a in range(4):
            M=sp.Matrix(size,size,lambda i,j:sphere_moment(B[i]*X[a]*B[j],r))
            # Toeplitz-coordinate compression in a nonorthonormal polynomial basis:
            T=Gi*M
            # Self-adjointness with respect to G, not necessarily Euclidean matrix transpose.
            H=sp.simplify(G*T-T.T*G)
            for i in range(size):
                for j in range(size): check('povm_first_moment_selfadjoint',H[i,j]==0)
            # Coordinate has odd parity, hence same-shell zero blocks.
            offsets=[0,1,5,14]
            for k in range(band+1):
                for i in range(offsets[k],offsets[k+1]):
                    for j in range(offsets[k],offsets[k+1]):
                        check('povm_coordinate_parity',M[i,j]==0)
            if band==1:
                ortho=[sp.Integer(1)]+[2*x/r for x in X]
                for i in range(5):
                    for j in range(5):
                        expected=r/sp.Integer(2) if ((i==0 and j==a+1) or (j==0 and i==a+1)) else 0
                        actual=sphere_moment(ortho[i]*X[a]*ortho[j],r)
                        check('povm_m1_toeplitz',actual==expected,(r,a,i,j,actual,expected))

# Schur commutant: C3 representation with characters 1,omega,omega^2 and multiplicities 2,1,3.
omega=sp.exp(2*sp.pi*sp.I/3)
mult=[2,1,3]
check('isotypic_commutant_dim',sum(m*m for m in mult)==14)
check('isotypic_rep_dim',sum(mult)==6)
for r in (sp.Integer(1),sp.Integer(2),sp.Integer(3)):
    check('metric_scaling_volume',sp.simplify((2*sp.pi**2*(2*r)**3)/(2*sp.pi**2*r**3))==8)
    check('metric_scaling_curvature',sp.simplify((2*r)**(-2)/(r**(-2)))==sp.Rational(1,4))
    check('metric_scaling_dirac',sp.simplify((sp.Rational(3,2)/(2*r))/(sp.Rational(3,2)/r))==sp.Rational(1,2))
    check('metric_scaling_reeb',sp.simplify(2*sp.pi*(2*r)/(2*sp.pi*r))==2)

# Hopf coordinate pullback of standard Liouville form, independent polar-coordinate calculation.
# z1=R cos(theta/2) exp(i(psi+phi)/2), z2=R sin(theta/2) exp(i(psi-phi)/2)
theta=sp.symbols('theta', real=True)
Apsi=sp.simplify(R**2/sp.Integer(4)*(sp.cos(theta/2)**2+sp.sin(theta/2)**2))
Aphi=sp.simplify(R**2/sp.Integer(4)*(sp.cos(theta/2)**2-sp.sin(theta/2)**2))
check('liouville_hopf_pullback',sp.simplify(Apsi-R**2/4)==0)
check('liouville_hopf_pullback',sp.simplify(Aphi-R**2*sp.cos(theta)/4)==0)
check('liouville_rescaling',sp.simplify(2*Apsi/R-R/2)==0)
check('hopf_curvature_flux',sp.integrate(sp.Rational(1,2)*sp.sin(theta),(theta,0,sp.pi))*2*sp.pi==2*sp.pi)
for r in (sp.Rational(1,2),sp.Integer(1),sp.Integer(2),sp.Integer(3)):
    vol=2*sp.pi**2*r**3
    contact=sp.simplify(sp.Rational(2,1)/r*vol)
    check('hopf_contact_integral',sp.simplify(contact-4*sp.pi**2*r**2)==0)
    check('hopf_whitehead_generator',sp.simplify(contact/(r**2*4*sp.pi**2)-1)==0)
    hel_vol=sp.simplify(r**2/4*contact)
    check('hopf_helicity_scaled',sp.simplify(hel_vol-sp.pi**2*r**4)==0)
    check('reeb_dimensionless_period',sp.simplify((2*sp.pi*r)/r-2*sp.pi)==0)
    check('unit_cotangent_geodesic_period',sp.simplify(2*sp.pi*(r/2)-sp.pi*r)==0)
    check('unit_cotangent_angular_speed',sp.simplify(r/2*2/r-1)==0)
    check('beltrami_curl_coefficient',sp.simplify((2/r)*r-2)==0)
    Y=sp.simplify((6/r**2)*vol**sp.Rational(2,3))
    check('yamabe_scale_invariant',sp.simplify(Y-6*(2*sp.pi**2)**sp.Rational(2,3))==0)

# Chern-Simons generator normalization: anti-Hermitian SU(2) Lie basis T_a=-i sigma_a/2.
sigma=[sp.Matrix([[0,1],[1,0]]),sp.Matrix([[0,-sp.I],[sp.I,0]]),sp.Matrix([[1,0],[0,-1]])]
T=[-sp.I*s/2 for s in sigma]
triple=0
for p in permutations(range(3)):
    inv=sum(p[i]>p[j] for i in range(3) for j in range(i+1,3))
    triple+=(-1)**inv*sp.trace(T[p[0]]*T[p[1]]*T[p[2]])
triple=sp.simplify(triple)
check('chern_simons_trace_wedge',triple==-sp.Rational(3,2),triple)
# SU(2) theta= sum T_i w_i; volume of unit S3 = (1/8)∫w123, thus ∫w123=16 pi^2.
normalized_integral=sp.simplify(-triple*(16*sp.pi**2)/(24*sp.pi**2))
check('chern_simons_generator_integral',normalized_integral==1,normalized_integral)
check('chern_simons_pure_gauge_shift',normalized_integral.is_integer)

# SO(4)/U(2) has 2D orbit; single-handed invariant axis average vanishes, isotropic second moment 1/3.
check('hopf_moduli_orbit_dim',6-4==2)
check('hopf_handedness_mixing_not_forced',sp.Rational(1,5)!=sp.Rational(1,2))
for i in range(3):
    for j in range(3):
        # E[n_i n_j] by SO(3) isotropy, fixed trace =1.
        val=sp.Rational(1,3) if i==j else sp.Integer(0)
        check('hopf_axes_isotropy',val==(sp.Rational(1,3) if i==j else 0))

# Homotopy / Gysin sequence exactness: Hopf Euler map H^0(S2)->H^2(S2) is multiplication by 1.
for euler in [-2,-1,0,1,2]:
    check('gysin_hopf_class_generator', (abs(euler)==1)==(euler in (-1,1)))

# CG endpoint attack on *uncensused summary row* #6017.
def su2tensor(j,k):
    a=abs(j-k); b=j+k; return [a+q for q in range(int(b-a)+1)]
def prod(s,t):
    return list(product(su2tensor(s[0],t[0]),su2tensor(s[1],t[1])))
Splus=(sp.Rational(1,2),0); Sminus=(0,sp.Rational(1,2)); V=(sp.Rational(1,2),sp.Rational(1,2))
for s,outs in [(Splus,[(0,sp.Rational(1,2)),(1,sp.Rational(1,2))]),(Sminus,[(sp.Rational(1,2),0),(sp.Rational(1,2),1)])]:
    actual=prod(V,s)
    check('cg_exact_protected_vector',set(actual)==set(outs),(actual,outs))
    inside=[q for q in actual if sum(q)<=1]
    outside=[q for q in actual if sum(q)>1]
    check('cg_exterior_channels_exist',len(inside)==1 and len(outside)==1,(inside,outside))
    check('cg_exact_dimension_balance',sum((2*el+1)*(2*er+1) for el,er in actual)==8)
# Positive control: Splus tensor Splus produces only retained scalar and self-dual two-form sectors.
check('cg_positive_retained_control',set(prod(Splus,Splus))=={(0,0),(1,0)})

# Heat-trace expansion via an analytically independent Poisson-summation route:
# Tr e^{-t Δ}= e^{t/R²} sum_{n>=1}n² e^{-n²t/R²}
#  sum n²exp(-n²a) =sqrt(pi)/(4a^(3/2)) + exponentially small.
t=sp.symbols('t',real=True,positive=True)
for r in (sp.Rational(1,2),sp.Integer(1),sp.Integer(2),sp.Integer(3)):
    a0=2*sp.pi**2*r**3;a2=2*sp.pi**2*r;a4=sp.pi**2/r
    pref=(4*sp.pi*t)**(-sp.Rational(3,2))
    poiss=sp.sqrt(sp.pi)*r**3/(4*t**sp.Rational(3,2))*sp.exp(t/r**2)
    comp=pref*(a0+a2*t+a4*t**2)
    ratio=sp.simplify(poiss/pref)
    expansion=sp.series(ratio,t,0,3).removeO().expand()
    check('heat_poisson_coeff_0',sp.simplify(expansion.coeff(t,0)-a0)==0)
    check('heat_poisson_coeff_2',sp.simplify(expansion.coeff(t,1)-a2)==0)
    check('heat_poisson_coeff_4',sp.simplify(expansion.coeff(t,2)-a4)==0)

mp.mp.dps=45
for r in [mp.mpf('0.5'),mp.mpf(1),mp.mpf(2)]:
    for tt in [mp.mpf('0.02')*r*r, mp.mpf('0.01')*r*r, mp.mpf('0.005')*r*r]:
        a=tt/(r*r)
        actual=mp.nsum(lambda n:n*n*mp.exp(-(n*n-1)*a),[1,mp.inf])
        main=mp.sqrt(mp.pi)*r**3/(4*tt**mp.mpf('1.5'))*mp.exp(a)
        check('heat_trace_exact_vs_poisson',abs(actual/main-1)<mp.mpf('1e-24'))
        approx=mp.sqrt(mp.pi)*r**3/(4*tt**mp.mpf('1.5'))*(1+a+a*a/2)
        check('heat_trace_short_time_coefficients',abs(actual/approx-1)<mp.mpf('2e-6'))

for k in range(100):
    m=(k+1)*(k+2)
    check('eta_symmetric_pair',m-m==0)
    check('eta_round_nonzero_gap',(k+sp.Rational(3,2))>0)

witnesses={
 'source':'Paper1A-Geometry-v5_177.tex',
 'target_formal_objects':[117,153],
 'high_impact_scope_guards':["The m=1 and m=2 scalar POVM controls do not prove a physical detector selector.","The computed SU(2) Maurer-Cartan winding is a real representative; the gauge class is zero mod Z.","No general/global imported classification theorem is proved by finite tests.","The CG test is an exact boundary counterexample to *tensor closure*, not to the source-defined projected finite cutoff."],
 'exact_CG_attack':{
   'protected_spinor_times_vector':'(1/2,0) ⊗ (1/2,1/2) = (0,1/2) ⊕ (1,1/2)',
   'exterior_irrep':'(1,1/2) has jL+jR=3/2>m=1',
   'other_chirality':'(0,1/2) ⊗ (1/2,1/2) = (1/2,0) ⊕ (1/2,1)',
   'positive_control':'(1/2,0) ⊗ (1/2,0) = (0,0) ⊕ (1,0), both inside H1',
   'interpretation':"If 'no exterior channels retained' means projecting to H1, it is true by cutoff definition. It does not establish tensor-closure or prohibit the existence of discarded CG channels."
 },
 'heat_exact_route':'n=k+1; k(k+2)=n^2-1; sum_{n>=1} n²exp(-n²u) has leading √π/(4 u^{3/2}) and exp-small corrections, hence a0=2π²R³,a2=2π²R,a4=π²/R.',
 'hopf_whitehead_route':'∫η∧dη=4π²R², α=η/(2πR) gives ∫α∧dα=1; helicity wrt Riemannian volume equals π²R⁴.'
}
result={
 'artifact':'Paper1A-IndependentChecksBatch5-v1_1.json',
 'source_sha256':'0ddd521f70f237830ff4f018c8eebedb4bde43b62a0c9b92eb8c3ec3348f9f17',
 'checks_passed':sum(C.values())-len(bad),
 'checks_failed':len(bad),
 'checks_by_family':dict(sorted(C.items())),
 'failed_details':bad,
 'witnesses':witnesses,
 'disclosure':'Single-runtime programmatic exact algebra and numerical tests; no parallel independent agents. These are evidence controls, not full proofs of imported global theorems.'
}
p=Path(__file__).with_suffix('.json');p.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print('PASS',result['checks_passed'],'FAILED',result['checks_failed'])
for b in bad[:12]:print(b)
if bad: raise SystemExit(1)
