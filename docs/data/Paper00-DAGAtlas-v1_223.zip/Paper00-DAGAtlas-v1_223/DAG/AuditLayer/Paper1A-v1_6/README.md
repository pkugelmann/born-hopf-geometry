# Active Paper I-A audit layer v1.6

Authoritative source: `Paper1A-Geometry-v5_177.tex`, SHA-256 `0ddd521f70f237830ff4f018c8eebedb4bde43b62a0c9b92eb8c3ec3348f9f17`.
Full 179-claim six-batch audit, statuses: VERIFIED 100, REPRODUCED 31, FORMALIZED 48.
Findings: `BH-IA-DAG-000001` and `BH-IA-DAG-000002` resolved by active DAG repairs; `BH-IA-SRC-000003` remains open as source scope question.

Current graph: `DAG/CombinedGraphIndex-v1_153.json`. Material: `DAG/CombinedMaterialEdges-v1_152.json`. Routes: `DAG/CombinedProofRoutes-v1_152.json`.
Berger adiabatic proof is at source lines **6782–6815**; no outdated v5_176 locator is active.
Current report: `Paper00-ProofChainAudits-v1_66.zip::Paper1A-ProofChainAudit-v1_8.md`.
Evidence directory holds only the latest per-batch audit files (1–6) and prior independent repair witnesses retained as distinct historical evidence.

This layer does not assert that imported global theorems have all been independently proved, nor that mp=1 is invalidated by an unprojected tensor-product counterexample.
