# Paper I-A v5.177 — analytical repair / primary-theorem verification certificate

**Source:** `Paper1A-Geometry-v5_177.tex`; SHA256 `0ddd521f70f237830ff4f018c8eebedb4bde43b62a0c9b92eb8c3ec3348f9f17`. **Parent:** v5.176; identical mathematical statements (179/179); **8 modified proof environments**, no new axioms or physical selectors.

## Issue closures

- **BH-IA-G-000102** (`p1:thm:marked-cc-global`): SU(2) Cartan model Boscain–Rossi. Same structure constants, marked inversion isometry, horizontal norm factor R_mom/2. Reference cut locus exp(k) minus identity and transported vertical distance R_mom sqrt(theta(2pi-theta)). All off-circle and conjugate synthesis imported in the exact fixed-metric class; no independent proof of Boscain–Rossi original theorem asserted.
- **BH-IA-G-000103** (`p1:thm:sr-poincare`, `p1:thm:sr-sobolev`): Jerison local L² Hörmander Poincaré, compact homogeneous finite chains, ball 4-regularity/doubling, proper/geodesic John-domain criterion Hajłasz–Koskela 9.5, 9.7, 9.8 with p=2, s=4, same-ball energy and global L⁴ endpoint. Imported theorems used only with their hypotheses.
- **BH-IA-G-000104** (`p1:thm:rarita-schwinger-spectrum`): Bureš–Souček *Eigenvalues of conformally invariant operators on spheres*, Theorem 1 (1999), **signed** spin 3/2 n=3, ℓ=k+1, ±(k+5/2)/R and ±(k+5/2)/(3R); multiplicities per sign from Spin(4) modules (k+1)(k+4) and (k+2)(k+3). Correct distinct gaps.
- **BH-IA-G-000111** (four compiler theorem/proposition labels): universal Peter–Weyl spin tower; Casimir lower bounds; Chevalley–Eilenberg d²=0; Hodge/Pauli spin-matrix commutator bounds; strict all-j cutoff; fixed metric j² Gaussian majorization; scalar singular limits via H_j(c)≥u j and summable (2j+1)²exp(−tuj); dominated convergence in global trace norm. No finite-j truncation assumed for infinite theorem.

## Evidence boundaries

The four roots were **missing verification certificates**, not confirmed false claims. Closure means the original exact-scope results now have source-contained analytical steps and checked primary theorem transport. It does **not** claim fresh proofs of imported Boscain–Rossi/Jerison/Hajłasz–Koskela/Bureš–Souček papers, a new physical metric selector, or independent verification of other Born–Hopf papers. Forty-four remaining imported/specialist claims remain REPRODUCED and have not been auto-promoted.

**Independent E4:** prior 32,766 scoped controls (unmodified prior attestations) plus 1,903 additional new independent checks on SU2 spin blocks, anisotropic metrics, RS signed modules, and CC phases. Verified source compiled to 107-page PDF with resolved bibliography; one cross-paper I-B label undefined in stand-alone build.
