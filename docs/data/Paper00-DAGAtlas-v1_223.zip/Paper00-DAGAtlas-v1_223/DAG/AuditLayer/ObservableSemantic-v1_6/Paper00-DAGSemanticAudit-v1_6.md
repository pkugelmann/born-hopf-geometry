# Born–Hopf Geometry — DAG Semantic Audit v1_6

**Date:** 2026-11-16  
**Target:** `BH-G-000113` / `p6:thm:v591-owner-provenance-charged-grades` — source-to-polar-grade selection for nine charged roles.  
**Inputs:** `Paper00-PapersMinimal-v3_022.zip`, `Paper00-DAGAtlas-v1_161.zip`, `Paper00-DAGSemanticAudit-v1_5.zip`; rigorous verification protocol `v2_4` and proof-chain protocol `v1_1`.  
**Coverage:** bounded targeted five-paper interface audit (Paper I-C, III-F, V-A, V-B, V-D); **not** a full E3/E4 audit of a complete manuscript or global framework. **No paper rewritten.**

## Executive verdict

The source-grounded root comparison geometry, four finite scalar polar words, all nine *conditional* rank-one source/split transfers, and explicit nonselection examples pass **47/47 independently replayable exact SymPy checks** (E3 algebra and E4 boundary/information-loss checks). The existence and values of the four scalar classes are not disputed.

**`BH-G-000113` stays OPEN:** the actual generated mass-producing mixed action/source has not been independently shown to select the listed nine *physical* comparison ports and their normalization order. The source itself explicitly recognizes this: Paper V-A `p5:prop:v221-charged-comparison-source-scope` and Paper V-D `p6:cor:v5124-owner-selection-open`. Related upstream physical port issue **`BH-VA-G-0007` is inherited, not duplicated or closed**. Neither issue invalidates the rooted geometry or the conditional numerical charged finite coefficients.

The major scientific advance of this batch is to **isolate the exact missing implication** and its unavoidable operator-order tests, not to rename the mathematical availability of scalar classes as their physical selection.

## Frozen target and exact source anchors

| Source claim | Current source (v3_022) | Audit disposition |
|---|---|---|
| `p1b:cor:v221-hurwitz-principal-angle` | Paper1C-M8Geometry-v1_142.tex:21522–21545 | Exact two-frame geometry replayed |
| `p1b:prop:v221-exterior-comparison-character` | Paper1C:21547–21566 | Exact exterior characters replayed; no physical sort assignment |
| `p3f:prop:v221-relative-chiral-comparison-frame` | Paper3F-CompleteDynamics-v1_264.tex:6645–6689 | Two inequivalent conditional same-action chiral responses reproduced |
| `p5:thm:v398-charged-rooted-comparison-owner-consumption` | Paper5A-FiniteMatterGeometry-v3_211.tex:5599–5629 | Rooted 25-label owner and scalar 24/25 preserved |
| `p5:prop:v221-charged-comparison-source-scope` | Paper5A:5651–5688 | Source expressly withholds role-specific port/physical chiral placement |
| `p5:def:v228-hierarchy-origin` | Paper5A:3306–3315 | Existing generated-arrow antecedent retained |
| `p6:def:v588-owner-resolved-charged-packet` | Paper5B-TerminalSpectrum-v5_200.tex:3562–3583 | Typed owner data retained; not physical port selection |
| `p6:thm:v566-derived-charged-raw-compiler` | Paper5B:4896–4924 | Raw structural transfer table retained |
| `p6:def:v591-polar-comparison-classes` | Paper5B:3831–3855 | Four exact scalar amplitudes verified |
| `p6:thm:v591-owner-provenance-charged-grades` | Paper5B:3857–3902 | Nine conditional assignments algebraically replayed; independent source ownership not certified |
| `p6:cor:v591-derived-charged-comparison-character` | Paper5B:3904–3917 | Follows **given** owner-to-class assignments; not independent physical proof |
| `p6:cor:v591-additive-charged-comparison-cocycle` | Paper5B:3919–3932 | Restricted to licensed **reduced scalar-output** compositions |
| `p6:cor:v591-charged-comparison-closure-status` | Paper5B:3944–3953 | Retains dependent-on-rooted-branch guard |
| `p6:prop:v5124-constructive-preterminal-words` | Paper5D-TechnicalMaterial-v1_54.tex:2891–2940 | Nine assigned pre-inversion multipliers verified conditionally |
| `p6:rem:v5124-physical-owner-underdetermination` | Paper5D:2975–2991 | Explicit information-loss and cocycle scope independently reproduced |
| `p6:cor:v5124-owner-selection-open` | Paper5D:2993–3006 | Existing exact physical-source obligation confirmed |
| `p6:thm:comparison-factor-no-go` | Paper5D:4287–4303 | The no-go survives; no automatic factor count/word inference |

All **17** claim labels and hashes were checked against `DAG/CurrentSourceAnchorMap-v3_022.json` and the uploaded v3_022 source bytes.

## E3: exact rank-one polar geometry

With \(\eta_H=24/25\), \(t=\sqrt{\eta_H}=2\sqrt6/5\), \(\Omega_{25}=\frac15(1,\dots,1)^T\) and \(Q=I-|e_0\rangle\langle e_0|\), put

\[
A=Q|\Omega\rangle\langle\Omega|,\qquad
A^\dagger A=\eta_H |\Omega\rangle\langle\Omega|,
\qquad A^2=\eta_H A.
\]

On their active rank-one supports, the amplitudes of

\[
A,\qquad A^\dagger A,\qquad (A^\dagger A)^+,\qquad [A(A^\dagger A)]^+
\]

are exactly

\[
\boxed{t,\quad t^2,\quad t^{-2},\quad t^{-3}}.
\]

Independent exact Moore–Penrose identities, rank-one spectra and compression geometry passed. This verifies the scalar class algebra; it **does not** determine which word is inserted into which occurring charged source.

**Scope safeguard:** Because \(A^2=\eta_H A\), the nonzero singular value of **raw matrix** \(A^2\) is \(t^3\), not the \(t^2\) expected from adding the degrees of two abstract scalar-output `S` labels. Paper V-D explicitly restricts the additive cocycle to licensed reduced scalar-output compositions. No raw-matrix cocycle failure is alleged against the paper.

## E3: all nine charged roles, with required operation order

The original Paper V-B raw transfers and Paper V-D pre-inversion comparison multipliers yield the **source-stated** table below. For a direct row, \(\sigma(\rho F)=\rho\sigma(F)\); for a Moore–Penrose inverse row, \(\sigma((\rho F)^+)=\rho^{-1}\sigma(F^+)\), for positive \(\rho\).

| Role | Raw word | Readout | Pre-inversion \(\rho_p\) | Output factor | Polar class | \(n_{\eta_H}\) |
|---|---|---|---|---|---|---|
| \(u\) | \(N_2\) | direct | \(t\) | \(t\) | S | \(+1/2\) |
| \(d\) | \(P_{(2,3)}\) | direct | \(t^2\) | \(t^2\) | R | \(+1\) |
| \(e\) | \(P_{(1,5)}\) | inverse | \(t^3\) | \(t^{-3}\) | O∨ | \(-3/2\) |
| \(t\) | \(P_{(7,9)}\) | direct | \(t\) | \(t\) | S | \(+1/2\) |
| \(b\) | \(P_{(8,16,1)}\) | inverse | \(t^3\) | \(t^{-3}\) | O∨ | \(-3/2\) |
| \(\mu\) | \(N_4\) | inverse | \(t^{-2}\) | \(t^2\) | R | \(+1\) |
| \(s\) | \(N_6\) | inverse | \(t^{2}\) | \(t^{-2}\) | R∨ | \(-1\) |
| \(c\) | \(P_{(4,4,4)}\) | direct | \(t^2\) | \(t^2\) | R | \(+1\) |
| \(\tau\) | \(P_{(6,12,6)}\) | direct | \(t^2\) | \(t^2\) | R | \(+1\) |

The critical diagnostic is **\(\mu\) vs \(s\)**. Both raw \(N_4^+,N_6^+\) are inverse readouts, yet the final polar grades are opposite because the pre-inversion scalar multipliers are **opposite**. Their opposite grades cannot be deduced simply from the word “inverse” or from the raw singular values. A generated operator must choose their distinct comparison placements *before* inversion.

The current Paper V-D theorem expressly says these \(\rho_p\) assignments realize the terminal table constructively but **have not been derived from a variation of the unterminalized charged source**. Thus their exact algebraic reproduction is not independent source selection.

## E4: why source ownership is genuinely necessary

**Two-frame test:** Set \(G=\mathbb C^3\), \(\mathscr E=G\oplus G\), \(J_0=(I,0)^T\), \(J_1=(tI,\frac15I)^T\). The maps are both isometries and \(J_0^\dagger J_1=tI\). Under the specified port-augmented action of Paper III-F the common and relative chiral frames give, respectively,

\[
\widehat D_{00}=D_0,\qquad \widehat D_{01}=tD_0.
\]

For nonzero \(D_0\), the results differ, even with the same rooted comparison geometry. This is **not** a counterexample to a more restrictive actual generated action that independently fixes the port: it demonstrates why the physical source-port certificate cannot be inferred from the geometry alone.

**Hodge-order test:** For a vector-owner Gram \(H_V\), comparing the vector-return Gram first and *then* applying the stated \(H_{\Lambda^2}=\frac14H_V^{-1}\) gives \(t^{-2}H_{\Lambda^2}\); exterior-squaring the comparison first and then taking a Gram can instead produce \(t^4\) on the positive bivector return. These are not the same operation. The actual source must select the order used by the muon and strange rows.

**Idle loop test:** The closed rooted return \(L^\dagger L=\eta_H I\), \(L=tI\), preserves operator source/target sort when inserted as an extra scalar loop while changing the scalar magnitude. Restricting to the source-licensed words and excluding idle loops must therefore be separately certified, as Paper V-D already states.

## Issue certificates: all issues affecting this batch

### `BH-G-000113` — major, inherited OPEN (Paper V-B)

- **Target:** `p6:thm:v591-owner-provenance-charged-grades`, Paper5B:3857–3902.
- **Consumed:** raw role words and owner tuple, 25-label rooted comparison, four scalar classes, Hodge/exterior sorts.
- **Actual missing bridge:** independent derivation of a mapping from each generated owner/source role to the actual normalized quadratic comparison-port operation, chiral frame and exterior/Hodge/reciprocal sort inserted by its native mixed action *before terminal scalarization*.
- **Why required:** the theorem's proof uses qualitative descriptors (“one-endpoint,” “two-ended,” “reciprocal completion”) to assign `PolType`, but V-D shows the corresponding physical source-level sort assignments and loop exclusion have not been calculated.
- **Why open:** source statement of V-A `p5:prop:v221-charged-comparison-source-scope` and V-D `p6:cor:v5124-owner-selection-open`; E4 two-frame and operation-order nonselection; **no in-domain refutation** of any otherwise explicitly supplied physical action.
- **Mathematically unaffected:** rooted comparison factor \(24/25\), four scalar polar identities, terminal raw Clifford/split coefficients and conditionally instantiated output table.
- **Verified downstream dependence:** the two V-B corollaries `p6:cor:v591-derived-charged-comparison-character` and `p6:cor:v591-charged-comparison-closure-status` inherit the same branch-specific role table and source-port guards by their statements.
- **Physical readouts possibly affected:** charged mass-source and rest/pole claims, for which a complete certified material DAG path was *not* established in this batch.
- **Resolution:** source-native nine-role mixed derivative or independently generated parent contraction, with source-order proof, kinetic renormalization and pole/source comparison; no fitting or exponent readback.

### `BH-VA-G-0007` — major, inherited OPEN (Paper V-A)

- **Origin:** `p5:prop:v221-charged-comparison-source-scope`, Paper5A:5651–5688.
- **Condition:** physical same-action left/right chiral frame and exterior/reciprocal port insertion for the mass-producing source remain independently unselected.
- **Relationship:** upstream physical-port issue distinct from V-B's nine-role classification; preserve both source-based issue IDs, do **not** create another canonical assumption.

**No new issue IDs were created. No previously closed issue was reopened.** Structural source-proof incompleteness is distinguished from mathematical contradiction.

## Exact next evidence required to close rather than rephrase the gap

For each \(p\in\{u,d,e,t,b,\mu,s,c,\tau\}\), evaluate the *source-constructed* preterminal charged mixed block

\[
\mathcal D_{LR,p}^{\rm pre}=
\left.\frac{\delta^2 S_{\rm actual}}{\delta\bar\psi_{L,p}\,\delta\psi_{R,p}}\right|_{q_*},
\quad
\widehat{\mathcal D}_{p}=Z_{L,p}^{-1/2}\mathcal D_{LR,p}^{\rm pre}Z_{R,p}^{-1/2}.
\]

This expression is an **audit test definition**, not a claim that the current source has already supplied a particular value. One must identify the native \(S_{\rm actual}\) and its legal source ports; verify the right/left frame, exterior sort, operation order, and no idle loops; then calculate the comparison grade **without using the printed terminal grade or a fitted mass**. Lastly determine the stated physical rest/pole relation separately.

The current v5.90 synthesized source \(R_s^{\rm pre}=\sum_rm_{s,r}^{\rm fin}\iota_{s,r}\) cannot, by itself, prove the earlier grade selection: its coefficients already contain the comparison factors. That does not refute the linear assembly; it forbids backwards inference of their origin.

## DAG and replay integration

- **17** source-hash-verified claim records, **12** typed and explicitly **nontraversable** source/scope relations, **9** charged role certificate rows, **1** boundary gate and **2 inherited issue IDs** in the v1_6 layer.
- **47/47** exact replay checks (`Evidence/replay_v1_6.py`), including specific E4 information-loss tests. No mathematical/physical status promotions.
- **0** new canonical theorem nodes, **0** new material edges, **0** new proof-route promotions.
- The combined DAG's current material edges and proof routes are preserved; the global impact engine must not traverse the unpromoted source candidate edges.
- The preceding legacy isolated-claim queue (86 after v1_4) is **not audited in this batch** and its count is not advertised as reduced.

**Final classification:** `PARTIALLY_AUDITED` (targeted charged-grade semantic route), `WITH_OPEN_PHYSICAL_SELECTION_CONDITIONS`, `NO_NEW_MATHEMATICAL_REFUTATION`. The precise physical port certificate is the next necessary proof obligation.
