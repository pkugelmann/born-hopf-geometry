#!/usr/bin/env python3
"""Exact targeted semantic audit replay of Paper V-B charged comparison owner port.
Run: python Paper00-DAGSemanticAudit-v1_6/Evidence/replay_v1_6.py
Source texts: Paper1C-M8Geometry-v1_142.tex; Paper3F-CompleteDynamics-v1_264.tex;
Paper5A-FiniteMatterGeometry-v3_211.tex; Paper5B-TerminalSpectrum-v5_200.tex;
Paper5D-TechnicalMaterial-v1_54.tex, all PapersMinimal v3_022.
The script tests mathematics of explicitly defined or conditionally assigned mappings;
it does NOT certify independent physical owner/source selection.
"""
from __future__ import annotations
import json,sys
import sympy as s
from pathlib import Path

res=[]
def ck(id, assert_expr, evidence, category='E3 exact'):
    try:
        ok=bool(assert_expr)
    except Exception:
        ok=False
    res.append({'id':id,'status':'PASS' if ok else 'FAIL','evidence':evidence,'category':category})
    if not ok: print('FAIL',id,'::',evidence)

def eq(a,b):
    if isinstance(a,s.MatrixBase):return a.shape==b.shape and all(s.simplify(x-y)==0 for x,y in zip(a,b))
    return s.simplify(a-b)==0

eta=s.Rational(24,25); t=s.sqrt(eta); q=s.Rational(1,5)
ck('E3-01',eq(t,2*s.sqrt(6)/5),'t=2sqrt(6)/5')
ck('E3-02',eq(t*t+q*q,1),'cos^2 + sin^2=1')
ck('E3-03',eq(t*t,eta),'sqrt eta squared')
# 25-label exclusion operator, exact-rational
Omega=s.ones(25,1)/5; e0=s.eye(25)[:,0]; Q=s.eye(25)-e0*e0.T; v=Q*Omega
A=v*Omega.T; Aplus=Omega*v.T/eta; P=Omega*Omega.T; R=A.T*A
ck('E3-04',eq(Omega.T*Omega,s.ones(1,1)),'Omega is unit')
ck('E3-05',eq(Omega.T*Q*Omega,s.Matrix([[eta]])),'exclusion expectation eta=24/25')
ck('E3-06',eq(v.T*v,s.Matrix([[eta]])),'norm of excluded root amplitude')
ck('E3-07',eq(R,eta*P),'A†A=eta |Omega><Omega|')
ck('E3-08',eq(A*Aplus*A,A),'MP relation 1')
ck('E3-09',eq(Aplus*A*Aplus,Aplus),'MP relation 2')
ck('E3-10',eq(A*Aplus,(A*Aplus).T),'MP relation 3')
ck('E3-11',eq(Aplus*A,(Aplus*A).T),'MP relation 4')
ck('E3-12',eq(A*A,eta*A),'non-normal A²=eta A (not eta^1/2 A)')
ck('E3-13',eq(A*R,eta*A),'A(A†A)=eta A')
ck('E3-14',eq(Aplus*A,R/eta),'A+ A = P on active line')
# On rank-one active line, singular values computed from trace of B†B
for i,(name,M,target) in enumerate([
 ('S',A,t),('R',R,eta),('Rvee',R/eta**2,eta**-1),
 ('Ovee',(Aplus/eta),eta**s.Rational(-3,2))]):
    norm2=s.trace(M.T*M) # rank one
    ck(f'E3-{15+i:02}',eq(norm2,target**2),f'{name}: single nonzero singular value {target}')
ck('E4-19',not eq(eta*t,eta),'A² has t³ singular value vs t² scalar-output product; full matrix composition is not licensed', 'E4 scope boundary')
# Frame-based same-root explicit realization G=C^3 inside C^6. Same geometry, two actions.
I=s.eye(3); Z=s.zeros(3,3); J0=I.col_join(Z); J1=(t*I).col_join(q*I); D0=s.diag(2,3,5)
ck('E3-20',eq(J0.T*J0,I),'J0 isometric')
ck('E3-21',eq(J1.T*J1,I),'J1 isometric')
ck('E3-22',eq(J0.T*J1,t*I),'root overlap sqrt eta on all three modes')
ck('E3-23',eq(J0.T*J0*D0,D0),'same-frame effective mass D0')
ck('E3-24',eq(J0.T*J1*D0,t*D0),'relative-frame effective mass t D0')
ck('E4-25',not eq(D0,t*D0),'same inherited geometric frame pair permits nonidentical chiral responses; no physical selection inferred', 'E4 information-loss test')
# Source V-D v5.124 pre-comparison scalar insertion table. These rho are source-ASSIGNED candidates.
rows=[('u','N2','direct',t,t),('d','P(2,3)','direct',t**2,t**2),
      ('e','P(1,5)','inverse',t**3,t**-3),('t','P(7,9)','direct',t,t),
      ('b','P(8,16,1)','inverse',t**3,t**-3),('mu','N4','inverse',t**-2,t**2),
      ('s','N6','inverse',t**2,t**-2),('c','P(4,4,4)','direct',t**2,t**2),
      ('tau','P(6,12,6)','direct',t**2,t**2)]
for ix,(name,raw,kind,rho,w) in enumerate(rows,26):
    computed=rho if kind=='direct' else 1/rho
    ck(f'E3-{ix:02}',eq(computed,w),f'{name}: raw={raw}, {kind}, rho={rho}, output={w}; conditional assignment only')
ck('E3-35',eq(rows[5][3],1/rows[6][3]),'mu vs s preinversion comparison multipliers are inverse')
ck('E3-36',eq(rows[5][4],1/rows[6][4]),'mu vs s final comparison outputs are inverse')
# Hodge comparison order is noncommuting with normalization convention
HV=s.diag(2,3,5)
ck('E3-37',eq(s.Rational(1,4)*(t**2*HV).inv(),t**-2*s.Rational(1,4)*HV.inv()),'Hodge AFTER vector Gram comparison scales bivector by t^-2')
ck('E3-38',eq((t**2)**2,t**4),'exterior-square BEFORE Gram comparison scales positive Gram by t^4')
ck('E4-39',not eq(t**4,t**-2),'Hodge vs exterior positive Gram order differs; cannot import owner sort automatically','E4 scope boundary')
ck('E3-40',eq(s.det(t*I),t**3),'oriented three volume scale t^3')
ck('E3-41',eq(1/s.det(t*I),t**-3),'inverse volume scale t^-3')
# Closed scalar return: same operator type but nonidentical comparison result
L=t*I
ck('E3-42',eq(L.T*L,eta*I),'closed comparison loop = eta I')
ck('E4-43',not eq(L,(L.T*L)*L),'extra scalar comparison loop alters amplitude without altering role type; source must exclude idle loops','E4 information-loss test')
# Universal common scale cancellation in canonical kinetic normalization
c=s.Rational(37,11); DC=s.diag(2,3,5)
ck('E3-44',eq((c*I).inv()**0 if False else (c*DC)/c,DC),'common positive kinetic/odd scale cancels')
ck('E3-45',eq((t**2*DC)/(t**2),DC),'common exclusion applied to both kinetic and odd legs cancels')
# Differences among candidate physical output classes are genuinely nonzero
ck('E3-46',len(set([str(s.simplify(x)) for x in (t,eta,1/eta,eta**s.Rational(-3,2))]))==4,'four distinct polar scalar outputs')
# Conditional row-grade map: exactly reconstruct printed vector
exps=[s.Rational(1,2),1,s.Rational(-3,2),s.Rational(1,2),s.Rational(-3,2),1,-1,1,1]
ck('E3-47',all(eq(rows[i][4],eta**exps[i]) for i in range(9)),'all 9 source-assigned finite exponents reproduced')
# No bogus physical inference in any test
out={'target':'BH-G-000113','source_release':'Paper00-PapersMinimal-v3_022.zip',
     'checks':res,'checks_total':len(res),'checks_passed':sum(x['status']=='PASS' for x in res),
     'physical_owner_selection_certified':False,
     'note':'E4 examples test information loss of source premises and are not counterexamples to the full actual generated action if further independent source constraints exist.'}
p=Path(__file__).resolve().parent/'replay_results_v1_6.json';p.write_text(json.dumps(out,indent=2)+'\n')
print(f"{out['checks_passed']}/{out['checks_total']} targeted exact checks passed")
sys.exit(0 if out['checks_passed']==out['checks_total'] else 1)
