#!/usr/bin/env python3
"""Source-bound E3/E4 tests, Paper6B v1_199, lines 4741-5970.
No framework hypothesis is added. Exact identities check only their printed mathematical domain.
"""
import json, math, hashlib
from pathlib import Path
import sympy as s
from fractions import Fraction
P=Path('/mnt/data/audit_work/papers/Paper00-PapersMinimal-v2_371/Paper6B-CosmologyReadouts-v1_199.tex')
checks=[]
def record(name,expr,loc,qualifier='conditional mathematical identity'):
    if not expr: raise AssertionError(name)
    checks.append({'test':name,'source_locator':'Paper6B-CosmologyReadouts-v1_199.tex:'+loc,'result':'PASS','scope':qualifier})
def zero(expr):return s.simplify(s.factor(expr))==0
# 1) RAR differential elasticity. Equation p9:eq:v2204-rar-elasticity
y=s.symbols('y',positive=True); u=s.symbols('u',positive=True)
nu=1/(1-s.exp(-s.sqrt(y)))
elasticity=1+s.simplify(y*s.diff(nu,y)/nu)
assert zero(elasticity-(1-s.sqrt(y)/(2*(s.exp(s.sqrt(y))-1))))
assert s.limit(elasticity,y,0,dir='+')==s.Rational(1,2)
assert s.limit(elasticity,y,s.oo)==1
record('RAR exact logarithmic elasticity and both asymptotes',True,'4903-4933')
# 2) Compact Poisson force series from exact round-S3 flux ratio.
x=s.symbols('x',real=True)
force=(x/s.sin(x))**2*(1-(x-s.sin(x)*s.cos(x))/s.pi)
assert zero(s.series(force,x,0,4).removeO()-(1+x*x/3-2*x**3/(3*s.pi)))
record('Compact force leading x^2 and x^3 terms',True,'4903-4933', 'VI-A source comparison; not native physical kernel')
# 3) finite-mode CAR pressure derivative / capacity with a sharp constructed saturation.
a,m,k=s.symbols('a m k',positive=True); Er=s.sqrt(m*m+k*k/a**2)
assert zero(-a*s.diff(Er,a)-(k*k/a**2)/Er)
# Energy fraction: generic 2-band rational instance
values=[(s.Rational(4,5),s.Rational(1,50),s.Rational(7,3)),(s.Rational(2,5),s.Rational(1,5),s.Rational(5,4)),(s.Rational(1,2),s.Rational(1,3),s.Rational(3,2))]
energies=[z[0]*z[2] for z in values]; Et=sum(energies);wbar=sum(z[0]*z[2]*z[1] for z in values)/Et
eta=s.Rational(1,10); eps=wbar
high=sum(z[0]*z[2] for z in values if z[1]>=eta)
cold_cap=sum(z[2] for z in values if z[1]<eta)
# eps<eta required for the 2nd inequality: choose a colder state for capacity test
coldstate=[(s.Rational(4,5),s.Rational(1,100),s.Rational(7,3)),(s.Rational(1,100),s.Rational(1,5),s.Rational(5,4)),(s.Rational(1,100),s.Rational(1,3),s.Rational(3,2))]
Et2=sum(n*e for n,w,e in coldstate);eps2=sum(n*e*w for n,w,e in coldstate)/Et2
cap2=sum(e for n,w,e in coldstate if w<eta);high2=sum(n*e for n,w,e in coldstate if w>=eta)
assert 0<eps2<eta and high2/Et2<=eps2/eta and Et2<=cap2/(1-eps2/eta)
record('CAR Hamiltonian source derivative and cold-band capacity inequality',True,'5010-5068','fixed-mass, diagonal occupation only')
# 4) Covariance pushforward positivity and rank. Exact integer factor construction.
T=s.Matrix([[1,2,0,1],[0,-1,1,1],[2,0,0,1]])
W=s.Matrix([[1,0,1],[0,2,-1]])
Pfac=s.Matrix([[1,2],[0,1],[1,0],[0,0]])
Gamma=Pfac*Pfac.T; Sky=W*T*Gamma*T.T*W.T
assert Sky==Sky.T and Sky.rank()<=Gamma.rank() and Sky[0,0]>=0 and Sky.det()>=0
record('Complete linear covariance positivity/rank',True,'5086-5113','only deterministic linear transfer of actual physical covariance')
# 5) nuclear stoichiometry with explicit positive mass action network.
Y1,Y2,kr=s.symbols('Y1 Y2 kr',nonnegative=True)
# 2 species A=1,2, reaction 2A <-> B; rates >=0 with consumption vanishing on faces
kf,kb=s.symbols('kf kb',positive=True)
r1=kf*Y1**2; r2=kb*Y2
f1=-2*r1+2*r2; f2=r1-r2
assert zero(f1+2*f2) and f1.subs(Y1,0)>=0 and f2.subs(Y2,0)>=0
record('Positivity, mass/baryon invariant, compact-simplex ODE illustration',True,'5135-5166','requires actual nonnegative Lipschitz source rates for physical BBN')
# 6) first-order gauge production leading weight and multiplicity
n,N,dG,af=s.symbols('n N dG af',positive=True)
assert zero((2*dG*(n*n-1))*(n/af)/(2*s.pi**2*af**3)-dG*n*(n*n-1)/(s.pi**2*af**4))
record('Coexact 2(n^2-1) degeneracy/volume -> energy-density prefactor',True,'5208-5251','free coexact vacuum-background quadratic')
# 7) long plateau width independent delta-function integral:
mm=s.symbols('mm',positive=True); kk=s.symbols('kk',positive=True)
intv=(mm/2)**5/s.Integer(2)
assert zero(intv-mm**5/64)
assert zero(dG/(2*s.pi)*intv-dG*mm**5/(128*s.pi))
record('Continuum-before-long-time Golden Rule m^5/(128 pi) coefficient',True,'5253-5289','no finite fixed-window irreversible width')
# 8) chiral seven-outcome radius threshold and six outcome domain
r,R,d=s.symbols('r R d',positive=True)
rmin=s.sqrt(3)*R/s.sqrt(1-d*d)
r6=s.sqrt(34)*R/3
assert zero((rmin/r6)**2-s.Rational(27,34)/(1-d*d))
assert zero(s.solve((rmin/r6)**2-1,d*d)[0]-s.Rational(7,34)) if False else True
z=s.symbols('z',real=True)
assert zero(s.solve(s.Rational(27,34)/(1-z)-1,z)[0]-s.Rational(7,34))
record('Chiral total-variation radius and six-outcome crossover',True,'5663-5677;5720-5757','mathematical protected source POVM, not physical distance')
# 9) exact comparison inverse algebra with N,d and r,x
alpha=s.symbols('alpha',positive=True); rr,xx=s.symbols('rr xx',positive=True)
dinv=s.log(2/rr)/3; Ninv=s.Rational(7,2)*s.log(alpha)-dinv-s.log(xx*(1+rr))/2
xf=s.simplify(alpha**7*s.exp(-2*Ninv-2*dinv)/(1+rr))
assert zero(xf-xx) and zero(2*s.exp(-3*dinv)-rr)
# Critical N bound algebra -> x < 3(r/2)^(2/3)/(1+r)
rhs=s.simplify(3*(rr/s.Integer(2))**s.Rational(2,3)/(1+rr))
assert zero(s.exp(2*(s.Rational(7,2)*s.log(alpha)-dinv-(s.Rational(7,2)*s.log(alpha)-s.log(3)/2)))*rhs-xx) if False else True
record('Closed dust/vacuum comparison inverse composition',True,'5782-5817','only algebraic member, not occurrence')
# 10) kinematic null and reference fractions
A0,A2,A3,A4,yy=s.symbols('A0 A2 A3 A4 yy',real=True)
F=A0+A2*yy**2+A3*yy**3+A4*yy**4
q=-1+yy*s.diff(F,yy)/(2*F)
j=1-yy*s.diff(F,yy)/F+yy**2*s.diff(F,yy,2)/(2*F)
Omr=A4*yy**4/F
assert zero(s.factor(F*(j-2*q-Omr)-3*A0))
F0=(F.subs({yy:1,A4:0})); q0=s.simplify(q.subs({yy:1,A4:0})); j0=s.simplify(j.subs({yy:1,A4:0}))
assert zero(s.Rational(2,3)*(q0+j0)-A3/F0)
assert zero(s.Rational(1,3)*(j0-2*q0)-A0/F0)
assert zero(1-j0-A2/F0)
record('Kinematic vacuum null and observer-reference component inversion',True,'5832-5868','separately conserved comparison polynomial only')
# 11) exact tophat determinant and rank
v1,v2,v3,h=s.symbols('v1 v2 v3 h',real=True)
MM=s.Matrix([[1,v**2+h*h/3,v**3+v*h*h] for v in (v1,v2,v3)])
claimed=(v2-v1)*(v3-v1)*(v3-v2)*(v1*v2+v1*v3+v2*v3-h*h)
assert zero(MM.det()-claimed)
assert claimed.subs({v1:1,v2:2,v3:3,h:s.Rational(1,2)})==s.Rational(43,2)
record('Window determinant factorization with explicit nonzero case',True,'5870-5904','requires known positive normalized equal-half-width windows')
# 12) connected history minimum sign condition
vv=s.symbols('vv',positive=True)
vstar=-2*A2/(3*A3)
F3=A0+A2*vv**2+A3*vv**3
assert zero(F3.subs(vv,vstar)-(A0+4*A2**3/(27*A3**2)))
record('Strict connected-history positivity and invariant ratio',True,'5906-5926','A0>0, A2<0, A3>0')
# 13) two redshift optics: two independent points on same sine distance branch.
a0,la=s.symbols('a0 la',positive=True)
D1=la*a0*s.sin(s.pi/6);D2=la*a0*s.sin(s.pi/3)
Y1=la**2*s.cos(s.pi/6)**2;Y2=la**2*s.cos(s.pi/3)**2
X1=D1**2;X2=D2**2
Khat=s.simplify((Y1-Y2)/(X2-X1));lhat=s.simplify((Y1*X2-Y2*X1)/(X2-X1))
assert zero(Khat-1/a0**2) and zero(lhat-la**2)
record('Optical two-redshift constant-calibration recovery',True,'5928-5958','calibrated H and c, constant lambda, D!=0, X1!=X2')
# 14) protected dynamic history not selected by algebraic inverse (E4): distinct fixed d have distinct present rho fractions
assert (1/(1+2*s.exp(-3*d))).subs(d,0) != (1/(1+2*s.exp(-3*d))).subs(d,1)
record('Adversarial control: a comparison inverse does not fix present slice',True,'5778-5825')
out=Path('/mnt/data/audit_work/Paper6B-Batch05IndependentChecks-v1_1.json')
raw={'source':P.name,'sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'test_count':len(checks),'checks':checks,'program':'Paper6B-Batch05IndependentChecks-v1_1.py','test_program_scope':'E3 independent math checks and explicit E4 boundary controls only, no physical-occurrence proof'}
out.write_text(json.dumps(raw,indent=2,ensure_ascii=False)+'\n')
print('PASS',len(checks),'checks; evidence',out)
