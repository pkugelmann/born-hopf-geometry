# Current Paper VI-B rigorous audit layer (v1_1)

Source: Paper6B-CosmologyReadouts-v1_199.tex, SHA256 63cbea2cf69a30885d79f7199297b704345fa2d4ed66d3a1a4e201c4f3d8c30a. All 136 formal statements audited in five batches; 16 canonical issue origins (BH-G-000118 through BH-G-000133) with retained BH-VIB aliases. The local and global proof-route index distinguishes material source-supported edges from nonmaterial evidence/candidates. No source or historical theorem flags modified. Only Batch 5 has a bundled rerunnable machine test script; narrative proof/check certificates for earlier batches are retained without falsely claiming recovered independent scripts.

Query entry: `DAG/CombinedGraphIndex-v1_114.json` → this layer. The global canonical JSON points to this layer in `graph_layers`. Conditions are specialized source-first predicates, not newly introduced constitutional axioms. The paper's formal claims have per-claim source-as-printed text.
