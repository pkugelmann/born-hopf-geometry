# Paper IV-A — registered global DAG audit layer v1_1

Current source: `Paper4A-FiniteQuantumMechanics-v4_208.tex` (SHA256 `125220dcced44202b5bb91308afaaf3b7181ebf34b1d64a9d79ca69f8eca10da`).

Exactly 162 unique source claims from lines 1–7814, plus 84 substantive units, are indexed in `AuditClaimLedger.json`. Verified material imports/requirements in `TypedDependencyEdges.json` use premise/source → consumer orientation, with AND routes in `ProofRoutes.json`. Citations and unconfirmed candidates are never traversed as proofs.

`AssumptionRegistry.json` records only specialized first-known IV-A domain nodes; inherited earliest-established conditions are reused by ID and other source role guards remain on per-claim routes, not duplicated as new primitive assumptions.

`GapRegistry.json` records 3 source-precision items and 2 lower-verification-status obligations, no confirmed in-domain theorem counterexample. The impact index does not spread a provenance/evidence limitation as a mathematical refutation.

Query the **global** atlas with `python Paper00-DAGQuery-v1_107.py node <id>`, `conditions <label>`, `descendants <condition-id>`, or `issue <issue-id>`. The combined index merges the new typed layer with the existing global theorem graph while preserving inherited historical statuses.

Exact source, E3 script/result files and prior audit ledgers are included; original papers and prior global DAG core object contents were not mathematically re-proved.

Merged v1.107 note: The published source hash recorded above is the **original audit** SHA. See `DAG/SourceRebase/Paper4A-v2_370-to-v2_371.json` for an exact-text correspondence certificate; no new audit status is assigned.
