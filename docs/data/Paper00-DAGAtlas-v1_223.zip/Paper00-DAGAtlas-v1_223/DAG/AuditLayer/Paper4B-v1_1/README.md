# Paper IV-B — registered global DAG audit layer v1_1

**Current authoritative source:** `Paper4B-QuantumResponse-v1_42.tex`; SHA256 `11b93140dc5c53854a382763fde536862e8d979f65ba8e37c1af562b23bdab6f`; framework v2.371.

Exactly **227/227** original-source named claims and **176/176** proof environments (including two separately indexed unnamed proofs) were reviewed in four batches. **119/119** scoped finite algebra/matrix/adversarial checks passed. This does **not** claim universal E3 verification or physical occurrence of every conditional source.

`AuditClaimLedger.json` contains the full source-as-printed statements and proofs plus source-line controls. `TypedDependencyEdges.json` has **19** reviewed source material edges, **19** newly added to the global index and **14** candidate-use edges quarantined, plus separate condition/issue nonproof edges. `ProofRoutes.json` gives 227 source-bound AND routes. Literal `\ref` or `\eqref` alone is never proof.

`AssumptionRegistry.json` introduces two first-known **inferred unresolved premises** *only* at their earliest verified Paper IV-B origin; neither is treated as a new constitutional axiom. Existing G0/GP1–GP3, `m_p=1`, `H_1`, actual physical constructors and upstream quantum source roles are inherited, not recreated as new assumptions.

`GapRegistry.json` lists exactly two open **source implication** defects: `BH-G-000100` for global Euclidean exponential rigidity under restricted action composition, and `BH-G-000101` for Gibbs uniqueness from connected collision graph without invariant-completeness. The exact finite Euclidean supplied-weight and nonnegative kinetic entropy subclaims remain untouched. `ImpactIndex.json` is conservative: only material source-use paths count as certified; later citations are possible, not proven impacts.

**Unified atlas query:** from the release root run `python Paper00-DAGQuery-v1_108.py node <source-label>`, `conditions <source-label>`, `descendants <node-id>`, `prerequisites <node-id>`, `issue BH-G-000100`, or `checks`. All commands read the one global `DAG/CombinedGraphIndex-v1_108.json` plus registered audit layers. `DAG/CombinedMaterialEdges-v1_108.json` and `DAG/CombinedProofRoutes-v1_108.json` are active material layer and route store. Previous v1_107 filenames stay as **historical provenance**, not a second active atlas or recertified corpus.

**Completion:** `FULLY_AUDITED_WITH_OPEN_GAPS`, mathematical source as printed. No theory repair, source modifications, other-paper re-audit, new physical mechanism or arbitrary branch selection occurred. Full report `Audits/Paper4B-ProofChainAudit-v1_1.md`.
