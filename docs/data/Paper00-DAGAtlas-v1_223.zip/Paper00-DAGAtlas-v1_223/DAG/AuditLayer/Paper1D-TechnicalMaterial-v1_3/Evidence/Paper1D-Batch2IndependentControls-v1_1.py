#!/usr/bin/env python3
"""Paper I-D audit Batch 2, independent scoped controls for formal objects 51-117.
Checks exact finite algebra, small simplicial controls, coordinate identities and
sampled (not global) geometric formulas. Does not certify global gauge existence.
"""
import json, hashlib, itertools, math
from collections import defaultdict, Counter
from pathlib import Path
import numpy as np
import sympy as sy

D=Path(__file__).resolve().parent
SOURCE=D/'Paper1D-TechnicalMaterial-v1_67.tex'
RAW=SOURCE.read_bytes(); SHA=hashlib.sha256(RAW).hexdigest()
assert SHA=='3cd6ae8bb286536ef7bc871d359996309e53ac3a6aed89917a5a82c53b6dcb2a'
R=np.random.default_rng(260116)
cnt=defaultdict(int); max_error=defaultdict(float)
def ck(ok,name,context=None):
    if not bool(ok): raise AssertionError(f'{name}: {context}')
    cnt[name]+=1

def npclose(a,b,name,eps=4e-11):
    er=float(np.max(np.abs(np.asarray(a)-np.asarray(b))))
    max_error[name]=max(max_error[name],er)
    ck(er<=eps,name,er)

# RT.44-45: exact shear involution and bit-orbit transport across actual odd Chern charts.
for A in range(-80,81):
    zA=(5-2*A)%6
    ck(zA%2==1,'RT45_zA_odd')
    for h,w,sigma,tau,d,p in itertools.product((0,1),repeat=6):
        h2=(h+sigma)%2;w2=(w+sigma)%2
        ck((h2+w2)%2==(h+w)%2,'RT45_sum_frame_invariant')
        ck((tau+h+sigma)%2==(tau+sigma+h)%2,'RT45_D_transport')
        ck((tau+w+sigma)%2==(tau+sigma+w)%2,'RT45_S_transport')
        ck((p+h2+w2)%2==(p+h+w)%2,'RT45_matched_obstruction_invariant')
        ck((sigma==0 or (zA%2==1 and 3%2==1)),'RT45_odd_shear_scope')

# RT.46 mapping-torus twisted local cellular complexes.
I=sy.eye(2); P=sy.Matrix([[0,1],[1,0]])
for T in [I,P,-I]:
    ds=[T-I,I+T,T-I]
    ck(ds[1]*ds[0]==sy.zeros(2),'RT46_cw_chain_squared_zero')
    ck(ds[2]*ds[1]==sy.zeros(2),'RT46_cw_chain_squared_zero')
# Coker P-I has primitive free generator, Coker -2I = C2^2; exact MV cokernel in H^3 is C2.
ck(sy.matrices.normalforms is not None if hasattr(sy.matrices,'normalforms') else True,'RT46_modules_import')
from sympy.matrices.normalforms import smith_normal_form
from sympy.polys.domains import ZZ
for m,ex in [(sy.Matrix([[1,-1]]),1),(sy.Matrix([[2,-2]]),2)]:
    s=smith_normal_form(m,domain=ZZ)
    ck(abs(int(s[0,0]))==ex,'RT46_MV_smith_free_cokernel')
# Twisted row P-I image is primitive anti-diagonal, and 1+P image diagonal primitive.
ck(P-I==sy.Matrix([[-1,1],[1,-1]]),'RT46_swap_monodromy')
ck(I+P==sy.Matrix([[1,1],[1,1]]),'RT46_swap_monodromy')

# RT.48 group of components of Map(S1xS3,U2); central 2-cocycle and conjugation.
def grmul(a,b):
    k,n,e=a;l,m,f=b
    return (k+l,n+m,(e+f+l*n)%2)
def grinv(a):
    k,n,e=a;return (-k,-n,(e+k*n)%2)
def grconj(a,b):return grmul(grmul(a,b),grinv(a))
def grcomm(a,b):return grmul(grmul(grmul(a,b),grinv(a)),grinv(b))
identity=(0,0,0)
for i in range(2200):
    a=(int(R.integers(-30,31)),int(R.integers(-30,31)),int(R.integers(2)))
    b=(int(R.integers(-30,31)),int(R.integers(-30,31)),int(R.integers(2)))
    c=(int(R.integers(-30,31)),int(R.integers(-30,31)),int(R.integers(2)))
    ck(grmul(grmul(a,b),c)==grmul(a,grmul(b,c)),'RT48_associative_cocycle')
    ck(grmul(a,grinv(a))==identity,'RT48_inverse')
    k,n,e=a;l,m,f=b
    ck(grcomm(a,b)==(0,0,(k*m+l*n)%2),'RT48_commutator')
    ck(grconj(a,b)==(l,m,(f+k*m+l*n)%2),'RT48_clutch_conjugacy')
    ck(grconj(a,b)[2]==(f+k*m+l*n)%2,'RT48_matching_criterion')

# RT.52 exact twisted interchange automorphism of (p,q;r), central C12.
def gmul(a,b):
    p,q,r=a;x,y,z=b
    return (p+x,q+y,(r+z+p*y)%12)
def sigma(a):
    p,q,r=a;return(q,p,(p*q-r)%12)
def ginv(a):
    p,q,r=a;return(-p,-q,(-r+p*q)%12)
for i in range(6500):
    p,q,a,b=[int(x) for x in R.integers(-40,41,4)]
    r,z=[int(x) for x in R.integers(0,12,2)]
    v=(p,q,r);u=(a,-a,z)
    ck(sigma(gmul(v,u))==gmul(sigma(v),sigma(u)),'RT52_sigma_automorphism')
    cur=gmul(gmul(v,u),ginv(sigma(v)))
    want=(a+p-q,-a-p+q,(z+2*r-p*p-2*a*p)%12)
    ck(cur==want,'RT52_twisted_normal_component')
    t=(z+a*a)%2; rr=(t*t-z-a*a)//2
    ck(2*rr==t*t-z-a*a,'RT52_parity_integrality')
    v0=(t-a,t,rr%12)
    ck(gmul(gmul(v0,u),ginv(sigma(v0)))==identity,'RT52_component_normalization')

# RT.54 ordinary boundary frame shear: top bits stay unchanged on target subgroup.
for i in range(2000):
    N,M,m,c,eps,tau=[int(x) for x in R.integers(-20,21,6)]
    c%=6;eps%=2;tau%=2
    c1=(c+4*M*m)%6
    c2=(c1+4*N*m)%6
    ck(c2==(c+4*(M+N)*m)%6,'RT54_frame_group_action')
    ck((eps,tau)==(eps%2,tau%2),'RT54_bit_domain_stability')

# RT.56 exact cyclic groups for parity connecting map C24 -> C2, image 2*C12.
image={2*n%24 for n in range(12)}
kern={n for n in range(24) if n%2==0}
ck(image==kern and len(image)==12,'RT56_exact_parity_sequence')
for n in range(24):
    ck(((n+12)%2)==(n%2),'RT56_filling_even_ambiguity')

# RT.57 Steenrod cup-one for null wedge S5 v S9: exact 0 baseline.
def bd(simplex):
    return [simplex[:i]+simplex[i+1:] for i in range(len(simplex))]
def boundary_chain(simplices):
    v=Counter()
    for s in simplices:
        for f in bd(s):v[f]^=1
    return {s for s,c in v.items() if c%2}
base5=tuple(range(7))  # boundary of 6-simplex, an S5
base9=tuple([0]+list(range(7,17)))  # boundary of 10-simplex, an S9
S5=list(bd(base5));S9=list(bd(base9))
ck(not boundary_chain(S5),'RT57_wedge_bottom_cycle')
ck(not boundary_chain(S9),'RT57_wedge_top_cycle')
a_support={S5[0]}
ck(sum(f in a_support for f in S5)%2==1,'RT57_wedge_bottom_normalization')
val=0
for simplex in S9:
    for j in range(5):
        f1=tuple(simplex[:j+1]+simplex[j+5:])
        f2=tuple(simplex[j:j+6])
        val ^= int(f1 in a_support and f2 in a_support)
        ck(not (f1 in a_support and f2 in a_support),'RT57_wedge_cupone_terms_zero')
ck(val==0,'RT57_wedge_square_zero')

# RT.59 prism identity for simplicial maps with collisions, mod2 (independent small complexes).
def addchain(A,B):
    c=Counter(A)
    for s in B:c[s]+=1
    return {s for s,n in c.items() if n%2}
def chainbd(S):
    c=Counter()
    for s in S:
        for f in bd(s):c[f]+=1
    return {s for s,n in c.items() if n%2}
def prism(simplex, fmap):
    c=Counter()
    n=len(simplex)-1
    for j in range(n+1):
        v=[100+v for v in simplex[:j+1]]+[fmap[v] for v in simplex[j:]]
        if len(set(v))==len(v):c[tuple(sorted(v))]+=1
    return {s for s,n in c.items() if n%2}
for fmaptuple in itertools.product(range(4),repeat=4):
    fmap=dict(enumerate(fmaptuple))
    for d in (1,2,3):
        for ss in itertools.combinations(range(4),d+1):
            pp=prism(ss,fmap)
            # The second summand is P applied to the mod2 face chain, with symmetric differences.
            pc=set()
            for f in bd(ss): pc=addchain(pc,prism(f,fmap))
            lhs=addchain(chainbd(pp),pc)
            fimg=tuple(fmap[v] for v in ss)
            rhs={(100+v,) for v in ss} if False else {tuple(100+v for v in ss)}
            if len(set(fimg))==len(fimg):rhs.add(tuple(sorted(fimg)))
            ck(lhs==rhs,'RT59_prism_chain_identity', (fmap,ss,lhs,rhs))

# Coordinate independent controls: unit quaternions, exotic smash and SU3 transporter.
def randomq():
    q=R.normal(size=4);return q/np.linalg.norm(q)
def qmul(a,b):
    return np.r_[a[0]*b[0]-np.dot(a[1:],b[1:]),a[0]*b[1:]+b[0]*a[1:]+np.cross(a[1:],b[1:])]
def qexp(v):
    r=np.linalg.norm(v)
    if r<1e-13:return np.r_[1.,v]
    return np.r_[np.cos(r),np.sin(r)*v/r]
def exotic_section(x,p, with_u=False):
    ax=1-x[0];ap=1-p[0];K=2*ax+2*ap-ax*ap
    if K<1e-12:
        u0=1.;ua=np.zeros(3);ub=np.zeros(3)
    else:
        u0=1-2*ax*ap/K
        ux=2*ap*x[1:]/K;up=2*ax*p[1:]/K
        ua=(ux+up)/np.sqrt(2);ub=(ux-up)/np.sqrt(2)
    z0=u0+1j*ub[1];z1=ua[2]+1j*ub[2]
    r=math.sqrt(abs(z0)**2+abs(z1)**2)
    if r>1e-14:
        h1=2*np.real(z0*np.conj(z1))/r
        h2=2*np.imag(z0*np.conj(z1))/r
        h3=(abs(z0)**2-abs(z1)**2)/r
    else:h1=h2=h3=0.
    s=np.array([h3+1j*h1,ua[0]+1j*ua[1],ub[0]+1j*h2])
    return (s,(u0,ua,ub)) if with_u else s
I3=np.eye(3,dtype=complex);J=np.diag([1.,1.,-1.]);e1=I3[:,0];e2=I3[:,1];e3=I3[:,2]
def transport(a,b):
    c=np.vdot(a,b);w=b-c*a
    alpha=(1+c)/(1+np.conj(c));dd=(1+np.conj(c))/abs(1+c)
    U=I3+(c-1)*np.outer(a,np.conj(a))+np.outer(w,np.conj(a))-alpha*np.outer(a,np.conj(w))-np.outer(w,np.conj(w))/(1+np.conj(c))
    T=(np.outer(b,np.conj(b))+dd*(I3-np.outer(b,np.conj(b))))@U
    return T
for i in range(650):
    x=randomq();p=randomq()
    s,(u0,ua,ub)=exotic_section(x,p,True)
    npclose(np.vdot(s,s),1,'RT58_section_unit',1e-9)
    npclose(exotic_section(p,x),J@s,'RT58_exchange_equivariance',1e-9)
    npclose(u0*u0+np.dot(ua,ua)+np.dot(ub,ub),1,'RT58_smash_unit',1e-9)
    w=randomq();b,(uw,aw,bw)=exotic_section(w,-w,True)
    npclose(uw,(1+3*w[0]*w[0])/(3+w[0]*w[0]),'RT60_antipodal_u0',1e-10)
    npclose(aw,2*np.sqrt(2)*w[0]*w[1:]/(3+w[0]*w[0]),'RT60_antipodal_ua',1e-10)
    npclose(bw,2*np.sqrt(2)*w[1:]/(3+w[0]*w[0]),'RT60_antipodal_ub',1e-10)
    npclose(exotic_section(-w,w),J@b,'RT60_antipodal_exchange',1e-10)
    ck(float(np.real(np.vdot(e1,b)))>=-7/9-1e-11,'RT60_global_antipodal_lower_bound')
    ck(abs(1+np.vdot(e1,b))>=2/9-1e-11,'RT60_global_transport_denom')
    TT=transport(e1,b)
    npclose(TT.conj().T@TT,I3,'RT60_joining_T_unitary',1e-10)
    npclose(np.linalg.det(TT),1,'RT60_joining_T_su3',1e-10)
    npclose(TT@e1,b,'RT60_joining_T_last_column',1e-10)
    lam=np.exp(1j*R.uniform(-math.pi,math.pi))
    QZ=np.column_stack((e2,lam*e3,e1));QY=TT@QZ
    npclose(np.linalg.det(QZ),lam,'RT60_QZ_det',1e-10)
    npclose(np.linalg.det(QY),lam,'RT60_QY_det',1e-10)
    TT2=transport(e1,exotic_section(-w,w))
    npclose(TT2@np.column_stack((e2,-lam*e3,e1)),J@QY,'RT60_descended_frames',1e-10)
    # RT58 near-diagonal small normal control
    y=randomq();n=randomq();epsilon=float(R.uniform(1e-4,1/12))
    qx=qmul(y,qexp(epsilon*n[1:]));qp=qmul(y,qexp(-epsilon*n[1:]))
    a=exotic_section(y,y);nb=exotic_section(qx,qp)
    ck(np.linalg.norm(nb-a)<=3*np.sqrt(2)*epsilon*np.linalg.norm(n[1:])+2e-12,'RT58_small_normal_bound')
    ck(np.real(np.vdot(a,nb))>0,'RT58_frame_chart_in_domain')
    F0=np.column_stack((np.array([-np.conj(a[1]),np.conj(a[0]),0]),e3,a))
    FF=transport(a,nb)@F0
    npclose(FF.conj().T@FF,I3,'RT58_frame_unitary',1e-10)
    npclose(np.linalg.det(FF),1,'RT58_frame_det1',1e-10)
    npclose(FF[:,2],nb,'RT58_frame_stabilizer',1e-10)
    FF2=transport(a,exotic_section(qp,qx))@F0
    npclose(FF2,J@FF@np.diag([1,-1,1]),'RT58_frame_equivariance',1e-10)
    # RT62 cap randomly picks p, and x=exp(v) near basepoint.
    r0=float(R.uniform(0,1/12));rr=randomq()[1:];rr/=np.linalg.norm(rr)
    cap=exotic_section(qexp(r0*rr),p)
    ck(np.linalg.norm(cap-e1)<=3/12+2e-11,'RT62_cap_uniform_bound')
    ck(float(np.real(np.vdot(e1,cap)))>=31/32-2e-11,'RT62_cap_re_bound')
    ck(abs(1+np.vdot(e1,cap))>=63/32-2e-11,'RT62_cap_T_denom')

# RT.58 unitary interpolation in general C3 (separate from exotic chart).
for i in range(550):
    aa=R.normal(size=3)+1j*R.normal(size=3);aa/=np.linalg.norm(aa)
    bb=R.normal(size=3)+1j*R.normal(size=3);bb/=np.linalg.norm(bb)
    if abs(1+np.vdot(aa,bb))<0.1:continue
    TT=transport(aa,bb)
    npclose(TT.conj().T@TT,I3,'RT58_general_T_unitarity',1e-10)
    npclose(np.linalg.det(TT),1,'RT58_general_T_det1',1e-10)
    npclose(TT@aa,bb,'RT58_general_T_maps_a_b',1e-10)

# RT.61 rank-three determinant-preserving joining homotopy and last-column projection.
def su2(q):
    z0=q[0]+1j*q[1];z1=-q[2]+1j*q[3]
    return np.array([[z0,-np.conj(z1)],[z1,np.conj(z0)]])
def hvalue(s,q):
    z0=q[0]+1j*q[1];z1=-q[2]+1j*q[3]
    th=np.pi/2*(1-s)
    return np.array([np.sin(th)**2+np.cos(th)**2*z0,np.cos(th)*z1,np.sin(th)*np.cos(th)*(1-z0)])
def Kvalue(s,lam,q,k=1):
    h=hvalue(s,q)
    qk=np.diag([lam**k,1,1]);Ls=I3+(lam**k-1)*np.outer(h,np.conj(h))
    return Ls@np.linalg.inv(qk)
for i in range(950):
    u=randomq();lam=np.exp(1j*R.uniform(-math.pi,math.pi));s=float(R.random());k=int(R.integers(-3,4))
    h=hvalue(s,u)
    npclose(np.vdot(h,h),1,'RT61_homotopy_unit_sphere',2e-10)
    K=Kvalue(s,lam,u,k)
    npclose(K.conj().T@K,I3,'RT61_joining_K_unitary',3e-10)
    npclose(np.linalg.det(K),1,'RT61_joining_K_det1',3e-10)
    npclose(K@e3,e3+(lam**k-1)*np.conj(h[2])*h,'RT61_projected_column',3e-10)
    npclose(Kvalue(0,lam,u,k),I3,'RT61_K_initial_identity',3e-10)
    uu=su2(u);cd=I3.copy();cd[:2,:2]=uu
    qk=np.diag([lam**k,1,1]);endpoint=cd@qk@cd.conj().T@np.linalg.inv(qk)
    npclose(Kvalue(1,lam,u,k),endpoint,'RT61_K_final_commutator',3e-10)
    npclose(Kvalue(s,1,u,k),I3,'RT61_K_based_lambda',3e-10)
    npclose(Kvalue(s,lam,np.array([1.,0.,0.,0.]),k),I3,'RT61_K_based_quaternion',3e-10)
# RT.61 unit-degree Jacobian at the unique regular preimage, compared with printed RT.61.8.
def charts(vals):
    ds,phi,x1,x2,x3=vals
    uu=np.r_[-np.sqrt(1-x1*x1-x2*x2-x3*x3),x1,x2,x3]
    lam=-np.exp(1j*phi)
    return Kvalue(.5+ds,lam,uu)@e3
def chartcoords(vals):
    g=charts(vals)
    return np.array([g[0].real,g[0].imag,g[1].real,g[1].imag,g[2].imag])
hh=1e-6
Jnum=np.stack([(chartcoords(hh*np.eye(5)[j])-chartcoords(-hh*np.eye(5)[j]))/(2*hh) for j in range(5)],axis=1)
Jexpected=np.array([[2*np.pi,0,0,0,0],[0,0,-1,0,0],[0,0,0,np.sqrt(2),0],[0,0,0,0,-np.sqrt(2)],[0,-1,0,0,0]])
npclose(Jnum,Jexpected,'RT61_local_degree_printed_jacobian',2e-8)
ck(abs(np.linalg.det(Jnum)-4*np.pi)<1e-6,'RT61_local_degree_abs_one_control')

# RT.63 principal power path: absolute quaternion branch avoided, limit controlled.
def supower(q,t):
    a=np.arccos(float(np.clip(q[0],-1.,1.)))
    if abs(np.sin(a))<1e-12:return I3[:2,:2].copy() if q[0]>0 else None
    U=(su2(q)-q[0]*np.eye(2))/np.sin(a)
    return np.cos(t*a)*np.eye(2)+np.sin(t*a)*U
for i in range(850):
    q=randomq();X=su2(randomq());A=su2(q);B=X.conj().T@A@X;V=A@B
    t=float(R.random());at=supower(q,t)
    F=at.conj().T@V@at
    npclose(F.conj().T@F,np.eye(2),'RT63_closing_SU2',2e-10)
    npclose(np.linalg.det(F),1,'RT63_closing_det1',2e-10)
    npclose(su2(q).conj().T@V@su2(q),B@A,'RT63_closing_endpoint',2e-10)
    ck(np.linalg.norm(F-np.eye(2))<=2*np.linalg.norm(A+np.eye(2))+2e-11,'RT63_minus_I_removable_bound')
    # Topological domain test: no forced unique power AT -I, only unique F=I.
    eps=float(R.uniform(1e-6,1e-3));vec=randomq()[1:];vec/=np.linalg.norm(vec)
    qnear=np.r_[-np.cos(eps),np.sin(eps)*vec];Anear=su2(qnear);Bnear=X.conj().T@Anear@X
    anear=supower(qnear,t);Fnear=anear.conj().T@(Anear@Bnear)@anear
    ck(np.linalg.norm(Fnear-np.eye(2))<=2*np.linalg.norm(Anear+np.eye(2))+2e-10,'RT63_branch_near_minus_I')

# RT.63 supported suspended complex Hopf map has unit norm/continuous at z=0.
for i in range(600):
    r=R.normal(size=4);r/=np.linalg.norm(r);r*=R.uniform(1e-4,.999)
    g=1-np.dot(r,r);den=np.dot(r,r)+g*g
    tau=(np.dot(r,r)-g*g)/den;z=2*g*r/den
    zz0=z[0]+1j*z[1];zz1=z[2]+1j*z[3]
    H=np.array([abs(zz0)**2-abs(zz1)**2,2*np.real(zz0*np.conj(zz1)),2*np.imag(zz0*np.conj(zz1))])
    imag=H/np.linalg.norm(z) if np.linalg.norm(z)>1e-14 else np.zeros(3)
    ck(abs(tau*tau+np.dot(imag,imag)-1)<=1e-10,'RT63_toggle_suspension_unit')


# Additional finite verifications and adversarial mutation/guard checks.
for i in range(1600):
    ell,d,ep,r,x,y=[int(t) for t in R.integers(-7,8,6)]
    r,x,y=r,x%2,y%2
    # q^ell followed by p_d followed by T^ep in actual RT.49 table.
    def Taction(z): rr,xx,yy=z;return rr,xx,(yy+ep*rr)%2
    def paction(z): rr,xx,yy=z;return rr,(xx+d*rr)%2,yy
    def qaction(z): rr,xx,yy=z;return rr,xx,(yy+ell*xx)%2
    observed=qaction(paction(Taction((r,x,y))))
    expected=(r,(x+d*r)%2,(y+ell*x+(ep+ell*d)*r)%2)
    ck(observed==expected,'RT49_loop_clutch_action_composition')
    # RT.53 two alpha/beta components per fibre root that match each target.
    e0=int(R.integers(2));kind=int(R.integers(2))
    matching=[(a,b) for a,b in itertools.product((0,1),repeat=2)
              if (e0+a)%2 == (d%2 if kind==0 else 0)]
    ck(len(matching)==2,'RT53_affine_fibre_matching_count')
    # RT.55 cancellation of the source's common six-stage term.
    A=int(R.integers(-20,21)); zA=(5-2*A)%6
    ck((3-zA)%6 == (2*A-2)%6,'RT55_combined_six_stage_coefficient')
# Source RT.50 gives Sq2 and multiplication by chi2 both (0,1) on
# H3=<chi^3,chi*r>. This checks the exact stated linear consequence only.
for a,b in itertools.product((0,1),repeat=2):
    sq2=b; chi2=b
    ck((sq2+chi2)%2==0,'RT50_given_operation_vanishes')
# Adversarial E4: swapping a valid antecedent for an invalid stronger inference.
a=(1,0,0);b=(0,1,0)
ck(grcomm(a,b)==(0,0,1),'E4_RT48_nonabelian_joining_witness')
# Source explicitly only makes the rank-three commutator null. Its rank-two
# joining component in RT.48 is eta_3, nonzero, for k=d=1.
ck(grconj((0,1,0),(1,0,0))==(1,0,1),'E4_RT61_stabilization_not_rank2_null')
# A^t cannot be continuously extended at -I for t=1/2; the *conjugated F* can.
E=1e-3
qxa=np.array([-math.cos(E), math.sin(E),0.,0.])
qya=np.array([-math.cos(E),0.,math.sin(E),0.])
rot1=supower(qxa,0.5);rot2=supower(qya,0.5)
ck(np.linalg.norm(rot1-rot2)>1,'E4_RT63_principal_power_branch_nonunique')
for qq in (qxa,qya):
    XX=su2(np.array([.6,.8,0.,0.]));AA=su2(qq);BB=XX.conj().T@AA@XX
    AAhalf=supower(qq,0.5)
    FF=AAhalf.conj().T@(AA@BB)@AAhalf
    ck(np.linalg.norm(FF-np.eye(2))<=2*np.linalg.norm(AA+np.eye(2))+1e-9,
       'E4_RT63_true_family_removable_limit')

OUT=D/'Paper1D-Batch2IndependentControls-v1_1.json'
result={
 'id':'Paper1D-Batch2IndependentControls-v1_1',
 'source':SOURCE.name,'source_sha256':SHA,
 'target_formal_objects':[51,117],
 'checks_by_family':dict(sorted(cnt.items())),
 'total_scoped_checks':sum(cnt.values()),
 'numerical_max_abs_error':{k:v for k,v in sorted(max_error.items())},
 'result':'PASS - all scoped checks',
 'adversarial_evidence_scope':['RT.48 nonabelian joining commutator has valid witness; rejecting abelian simplification, not rejecting source theorem', 'RT.61 SU(3) nullhomotopy must not be mistaken for an SU(2) nullhomotopy', 'RT.63 principal A^t has a branch discontinuity at -I but the source F_s has a removable limit'],
 'explicit_limitations':[
  'Group and module controls certify the abstract presentations and their conditional consequences, not an actual global gauge realization.',
  'Coordinate checks use finite random samples and one local derivative; they are not exhaustive global existence or degree calculations.',
  'The RT.57/RT.59 490-simplex raw facets, cochain support and predecessor executable were not present in the supplied archives; only a null-wedge and a low-dimensional prism control were rerun.',
  'No independent rank-two whole-region gauge-completeness proof, matched natural-bit global certificate, or full secondary affine gauge-action proof is supplied by these tests.'
 ]
}
OUT.write_text(json.dumps(result,indent=2)+'\n')
print('PASS',sum(cnt.values()),'checks,',len(cnt),'families, MAX numerical error',max(max_error.values()),'source',SHA)
print('Results:',OUT)
