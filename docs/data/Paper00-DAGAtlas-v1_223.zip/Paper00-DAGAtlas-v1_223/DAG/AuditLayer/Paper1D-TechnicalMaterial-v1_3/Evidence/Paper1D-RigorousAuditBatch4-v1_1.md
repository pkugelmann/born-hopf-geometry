# Paper I-D — Rigorous Verification DAG Audit, Batch 4 (v1.1)

**Target source:** `Paper1D-TechnicalMaterial-v1_67.tex`, from the supplied current `Paper00-PapersMinimal-v3_019(1).zip`; exact SHA-256 `3cd6ae8bb286536ef7bc871d359996309e53ac3a6aed89917a5a82c53b6dcb2a`; 26,561 lines. **Protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md`. **Date:** 2026-11-16.

**Existing global archives, not modified by this batch:** `Paper00-DAGAtlas-v1_155(1).zip`, `Paper00-ProofChainAudits-v1_68(1).zip`. Older `Paper1D-ProofChainAudit-v1_4.md` is historical evidence, not source authority. No manuscript source changes, inferred postulates or new framework derivations are made. This is a correctness audit, not a theory-development pass.

**Disposition:** `PARTIALLY_AUDITED_WITH_OPEN_GAPS` — a bounded checkpoint, **not** a full-paper signoff or an updated global DAG release.

## 1. Coverage and mathematical evidence tiers

- **This batch:** source formal objects **152–200 inclusive (49 objects)**, statements beginning at current source lines **12501–20631**, last immediate proof ending **20682**. Formal objects 152–160 encompass an unusually long *intervening sequence* of source-printed, not formally named proofs in inline modules. Their boundaries are source indexed (44 inline modules), but they are **not claimed exhaustively independently certified** by this ledger.
- **Cumulative source-indexed formal coverage:** **200 / 279**, with contiguous earlier batches 1–50, 51–117 and 118–151. **79 formal objects remain** (#201–279), plus review of material unnamed arguments (both preceding and subsequent to #200). The 279 count includes the concluding source remark omitted from the older 278-item index.
- **Inherited 49-object dispositions:** **22 VERIFIED-CONDITIONAL, 10 REPRODUCED, 17 VERIFIED**. Cumulative 1–200 inherited: **91 VERIFIED-CONDITIONAL, 69 REPRODUCED, 40 VERIFIED**. These reflect earlier proof-chain audit lineage and are not reissued as 49 independent E3 theorem certificates. **Zero full theorem dispositions newly promoted** merely because a finite calculation passed.
- **Executable controls:** **6,456/6,456 passing scoped assertions across 71 named families**: 5,344 labelled `E2` (samples/numeric corroboration), 1,110 labelled `E3` (independent *scoped* exact calculations and finite structured enumerations), and 2 `E4` adversarial mutation tests. These are *assertion counts*, not independent theorem/proof counts. A family rated E3 only covers its explicitly checked subclaim, not necessarily a global topological claim that consumes it.
- **Source integrity:** each of the 49 objects has a full frozen `source_as_printed` TeX statement, source anchor and SHA-256. For 48, an immediate `proof` environment and hash is recorded; **#156 is a source-prose corollary without a separate proof environment**, not automatically a missing proof. **65 distinct / 72 occurring cross-reference navigation candidates** resolve in the current I-A/I-B/I-C/I-D/II-A corpus; these are not automatically validated proof dependencies. **Eight source-reviewed, guarded, typed local material dependency proposals** are retained as staged edges.
- The earlier Batch 1–3 ledger `source_as_printed` fields were shortened excerpts. **For global DAG release these must be reconstructed from the entire authoritative current TeX, not promoted as full source-as-printed quotations**. This is an E0 integrity correction under `BH-ID-DAG-0002`, not evidence of a mathematical contradiction. There are no missing source labels or duplicate formal claim labels detected in this 49-object index.

## 2. Source-matched examination of the main proof chain

### 2.1 Complete original natural rank-two joining (objects 152–160; OJ, OY, PF/PG, PC/V263, SC, PN/BG, AJ)

**What the source actually claims.** The object of the calculation is the original retained cap, its actual frame and deck cuts, the *original* corrected determinant/joining map, and the original odd exotic relative boundary. It is not a quotient of an unconstrained arbitrary ambient `SU(2)` word. The theorem at #160 (`p1b:thm:natural-rank-two-completion`, lines 18745–18789) claims

\[
[Z]=\nu'\eta_6=\mu,\qquad (h_t,w_t,r_J,\zeta_{\rm nat})=(1,1,0,0),
\]

with `j_h=a+t`, `j_η=t`, `r_A=2b+z_A z+t`, `z_A=5−2A (mod 6)`; it gives 14 natural extension tests **4 YES / 10 NO**, identifies `S_{0,1}`, `D_{0,1}`, `C_0`, `B_{0,0}` as the YES entries, and reports 32 inherited entries **4 YES / 28 NO**. The source **explicitly restricts these numbers to extension tests**, not full mixed-class realization counts. A nonzero degree-seven obstruction preempts testing degree eight. Preserve the source distinction between the actual coefficient `h_t` and the *rebased* top detector; equality of a mod-2 parity is not by itself equality of fully realized source maps.

**Independent checks and their actual reach.** Exact signed-word reduction of four PC.6 rectangles gives winding **−1**. The V263 bridge comparison gives `2k ≡ 6ε (mod 12)` with the stated parity and fibre classes, **when the actual bridge and cap are retained**; this is an exact arithmetic check of the bridge-controlled carry rather than a new construction of the bridge. The original coefficient relations (AJ.5) reduce consistently, and the finite fourteen-row natural test evaluates to the stated **four YES/ten NO**. OY.6 sweep, OJ.4 based circle contraction, the full SC.5 noncommutative cocycle and moving lower-division word have numerical pointwise controls with fixed base faces. The whole-cylinder/root gauges and source-dependent product homotopies are not replaced by pointwise matrix checks.

**Adversarial controls.** Dropping the necessary SC.5 lower commutator fails for generic noncommuting inputs (`E4`): the source **retains** that term, hence the mutation is not a counterexample to the paper. Conversely, treating a coincident formal Z12 parity as sufficient without identifying the specified actual NZ.20 cap bridge fails the source-domain precondition (`E4`), so that purported shortcut is rejected.

**The main independent-verification frontier.** In BG.3–BG.11 (approximately lines 18440–18595), the source prints a whole paired-seam null, uses actual northern/southern collars, a common based cap and the two *closed* radial bigons, and derives an odd total degree via `deg L_+−deg L_-=2deg L_+−deg D`. The **degree parity and endpoint algebra** pass independently. However, the present executable does **not** independently certify the full seven-dimensional global glued map, the homotopies of the original source with all boundary faces/deck conditions, and the resulting class identity `[Z]=μ` as a whole. This gap is an **unreproduced complete E3/global source-matching certificate**, not a source-matched disproof, and is provisionally tracked at `BH-ID-EV-0002`. The earlier `BH-IB-EV-0004` remains separately about whole-image rank-two gauge realization. The source proof is present and must be assessed on its own domain; it is not to be erased because our independent implementation is incomplete.

**Specific non-implications.** The original fixed-source 14-entry extension result cannot be promoted to a complete unstable fixed-Chern multiplicity theorem (`BH-IB-EV-0001`). It cannot fill the full eight-dimensional affine gauge-action frontier (`BH-IB-EV-0002`) or certify mixed/equivariant descent just from finite component algebra (`BH-IB-EV-0003`). The original 32-entry test total is **source-reported but was not independently re-enumerated** in this run.

### 2.2 Spectral/finite geometry and operator results (objects 161–172)

- **#161–162, Dirac and helicity:** the printed mixed coefficient
  `−R²(k−1)(k+3)/(4k(k+2)(k+1)²)` is exactly reproduced, including its `k=1` zero and nonzero subsequent integer modes. This is not an independent proof of complete transverse spectral surjectivity or entire helicity-balance geometry; the source’s scalar/one-form domains and twist sorts remain explicit.
- **#163 Feshbach:** independent finite-block calculations reproduce Schur determinant ratios and resolvent error bounds under their invertibility and gap assumptions. **#164 heat projector:** angular trace identity checked algebraically and differentiation checked numerically on the declared domain.
- **#165–168:** the real `KO`/symplectic and declared groupoid statements are anchored and replayed in their indicated source/qualifier. Twisted-K `gcd`/torsion arithmetic passes a scoped finite check, not an independent AHSS or whole-topological-bundle proof. A logical compatibility result between two supplied groupoid sorts is not an assertion that arbitrary groupoids coincide.
- **#169 Cartan link theorem:** the explicit triangle midpoint and quaternionic holonomy are independently reproduced for the printed quaternion triangle; zero/positive defect and unit normalization are sampled, not a universal operator theorem. **#170 overlap:** finite Ginsparg–Wilson and `γ5`-Hermiticity identities and an integer inertia index pass sampled finite-matrix tests; no global physical-action identification is added.
- **#171–172 cover-transfer/locality:** the printed mesh threshold `417/7000` has exact arithmetic provenance **conditional on the source gap/stencil input**. No executable raw entire parameter-grid spectral-gap certificate is bundled; this is not marked as a false theorem. The downstream locality conclusion retains its declared uniform-gap hypothesis.

### 2.3 Binary invariants and analysis (objects 173–188)

- **#173 Hurwitz/2T invariant pencil:** independent symbolic polynomial expansion reproduces the degree-24 syzygy `f₈³=g₁₂²+108 f₆⁴`, the stated symmetrized norm constants **8/231 and 32/5**, the affine Wronskian identity `−2f₆ f₈²`, and the first Molien degrees. These verify the explicitly normalized algebra, **not automatically** a unique physical 2T charge/readout map or all nonfree stabilizer identifications. Those are distinct candidate issue interfaces (`BH-IB-EV-0008`, `BH-IB-EV-0010`) and are **not promoted to newly proven material blockers** in this batch.
- **#174–176 opposite Hopf/axial characters, angular moments, theta:** pointwise first and second angular moments and Jensen heat inequality pass sampled controls, as do the printed theta shift phase and an exact termwise duality identity. Their global physical descent / exact Poisson proof is not silently inferred.
- **#177–179 finite coframe, kink and kinetic forms:** source exact domains, boundary, positivity and finite regularity conditions are preserved. No untested global PDE or continuum limit is certified by local algebra.
- **#180–184 stationary Schur, Legendre, rigidity, determinants and rank-three reconstruction:** the stationary linear lift and fourth-order Schur jet are reproduced symbolically in a distinct calculation. Finite spectral moment inversion, Heron/Jarlskog and commutator controls pass within simple-spectrum/positive-metric guard conditions; they do not certify rank-degenerate branches not in the theorem’s domain.
- **#185–188 chiral bundle charts and mass/compression:** source charts and local corollary are anchored; the proof lineages are guarded by their actual domain, transition functions and matrix chart data. A sample finite compression cannot certify every admitted chiral chart or an unconditional mass generation statement.

### 2.4 Exceptional-root and bounded-response calculations (objects 189–200)

- **#189–193 normalized root geometry:** an independent standard E8-root coordinate realization gives **240 E8 roots**, **126 in its E7 section**, **72 in its E6 section**, and second-moment operators `30I₈`, `18P₇`, `12P₆`. The projection-vs-retention calculation yields 180 versus 72 in its stated setting. Scalar and vector inverse responses are kept separate; repeated presentation preserves the normalized matrix response. **The check constructs the abstract standard-root algebra** and does not independently identify the source’s physical rooted carriers or assert a stronger E6/E7/E8 embedding than claimed.
- **#194–198 finite flow, invariant Legendre parity, blocking, heat and bounded complex sources:** finite positive-measure hypotheses matter. A total-variation blocking estimate bounded by `tanh(osc/4)` passes sampled probability tests. No arbitrary continuum field or unbounded source analyticity is inferred.
- **#199–200 dyadic trace and Laurent family:** independent series calculations return the printed rational Taylor coefficients `2^(r+1)/(2^r−1)²` and the `r=1` trace `4`. Exact logarithmic-derivative and Riccati relations hold in the specified Laurent scalar domain; numerical sign-window tests are explicitly only corroborative.

## 3. Batch 4 exact-source formal-object index (49 objects)

**Columns:** official current-source label suffix, current TeX statement/proof line spans, inherited disposition (`VC` = VERIFIED-CONDITIONAL, `R` = REPRODUCED, `V` = VERIFIED), and number of *scoped* E3/E4 families associated with the claim (not a theorem-verification count). Full source-as-printed statements are in the accompanying JSON ledger, not abbreviated as originals here.

| # | Current source label suffix | Statement lines | Proof lines | Prior | Scoped E3 / E4 families |
|---:|---|---|---|:---:|:---:|
| 152 | `natural-exterior-exchange` | 12501–12517 | 12518–12532 | VC | 0 / 0 |
| 153 | `natural-bridge-elimination` | 14888–14906 | 14907–14936 | R | 0 / 0 |
| 154 | `natural-sewn-annular-parity` | 15849–15863 | 15864–16018 | VC | 0 / 0 |
| 155 | `v263-bridge-controlled-carry` | 16555–16571 | 16572–16594 | VC | 4 / 1 |
| 156 | `v263-old-cap-cancellation` | 16596–16616 | source prose¹ | VC | 4 / 0 |
| 157 | `second-cut-phase-zero` | 17146–17161 | 17162–17226 | VC | 0 / 1 |
| 158 | `second-cut-conjugation-zero` | 17257–17270 | 17271–17351 | R | 0 / 1 |
| 159 | `paired-joining-null-independence` | 17860–17864 | 17865–17895 | VC | 2 / 0 |
| 160 | `natural-rank-two-completion` | 18745–18765 | 18766–18789 | R | 7 / 0 |
| 161 | `dirac-transverse-generation` | 18811–18856 | 18857–18911 | R | 2 / 0 |
| 162 | `dirac-helicity-balance` | 18914–18933 | 18934–18948 | VC | 0 / 0 |
| 163 | `feshbach` | 18960–18978 | 18979–18992 | V | 0 / 0 |
| 164 | `exact-heat-trace-and-parameter-evolution` | 19012–19043 | 19044–19057 | VC | 1 / 0 |
| 165 | `ko` | 19065–19078 | 19079–19092 | VC | 0 / 0 |
| 166 | `lcs` | 19096–19111 | 19112–19137 | R | 0 / 0 |
| 167 | `twisted-k` | 19141–19152 | 19153–19180 | R | 1 / 0 |
| 168 | `compatibility-test-for-the-two-declared-groupoids` | 19185–19192 | 19193–19198 | V | 0 / 0 |
| 169 | `cartan-links` | 19205–19226 | 19227–19252 | VC | 2 / 0 |
| 170 | `overlap` | 19273–19318 | 19319–19339 | V | 0 / 0 |
| 171 | `cover-transfer` | 19348–19364 | 19365–19384 | VC | 0 / 0 |
| 172 | `locality` | 19403–19425 | 19426–19455 | R | 0 / 0 |
| 173 | `invariant-pencil` | 19468–19499 | 19500–19531 | VC | 5 / 0 |
| 174 | `opposite-hopf-lines-and-lifted-axial-characters` | 19550–19571 | 19572–19584 | R | 0 / 0 |
| 175 | `angular-moments-and-comparison-heat` | 19589–19605 | 19606–19623 | V | 1 / 0 |
| 176 | `theta` | 19628–19644 | 19645–19665 | VC | 1 / 0 |
| 177 | `local-coframe` | 19671–19693 | 19694–19707 | VC | 0 / 0 |
| 178 | `kink` | 19712–19732 | 19733–19766 | R | 0 / 0 |
| 179 | `kinetic` | 19778–19799 | 19800–19810 | V | 0 / 0 |
| 180 | `schur-jets` | 19815–19841 | 19842–19858 | V | 3 / 0 |
| 181 | `partial-elimination-legendre-duality` | 19862–19884 | 19885–19898 | V | 3 / 0 |
| 182 | `matrix-rigidity` | 19925–19937 | 19938–19946 | V | 0 / 0 |
| 183 | `determinant-derivatives-and-relative-frame-stationarity` | 19958–19971 | 19972–19983 | V | 0 / 0 |
| 184 | `rank-three` | 19989–20023 | 20024–20049 | V | 0 / 0 |
| 185 | `explicit-chiral-bundle-charts` | 20054–20070 | 20071–20083 | V | 0 / 0 |
| 186 | `certified-chart` | 20088–20101 | 20102–20108 | VC | 0 / 0 |
| 187 | `compression-defect` | 20113–20122 | 20123–20128 | V | 0 / 0 |
| 188 | `positive-massive-branch` | 20133–20148 | 20149–20158 | V | 0 / 0 |
| 189 | `exroot-response-norms` | 20175–20207 | 20208–20224 | VC | 8 / 0 |
| 190 | `exroot-unit-hs-rows` | 20226–20233 | 20234–20238 | V | 1 / 0 |
| 191 | `exroot-native-240` | 20242–20254 | 20255–20261 | VC | 4 / 0 |
| 192 | `exroot-project-retain` | 20267–20278 | 20279–20286 | VC | 1 / 0 |
| 193 | `exroot-repeated-presentation` | 20288–20299 | 20300–20305 | V | 1 / 0 |
| 194 | `finite-flow` | 20323–20360 | 20361–20385 | VC | 0 / 0 |
| 195 | `invariant-legendre-vertex-parity` | 20389–20411 | 20412–20424 | VC | 0 / 0 |
| 196 | `blocking` | 20430–20453 | 20454–20476 | VC | 0 / 0 |
| 197 | `heat-block` | 20481–20507 | 20508–20536 | R | 0 / 0 |
| 198 | `bounded-complex-sources` | 20540–20552 | 20553–20563 | V | 0 / 0 |
| 199 | `dyadic-trace` | 20576–20605 | 20606–20626 | VC | 2 / 0 |
| 200 | `laurent-family` | 20631–20664 | 20665–20682 | V | 3 / 0 |

¹ #156 is explicitly printed as a corollary with source-prose derivation and adjoining predecessor; the absence of an isolated `proof` environment is an integrity locator, **not** itself evidence that no argument is supplied.

## 4. Guarded boundaries and issue/challenge adjudication

| First-root / boundary | Source anchor here | Current disposition and closure evidence needed |
|---|---|---|
| `BND-ID-B4-001` (local boundary, not a new global axiom) | OJ/OY/PF/PG, PC/V263, SC, BG/AJ | All homotopies and cap framings must be performed on the **same actual original source** with both deck/cut and based face constraints. Group arithmetic and a free stable `SU(3)` filler cannot substitute for original U(2) gauge realizability. |
| `BND-ID-B4-002` (local boundary) | #160, AJ.5–AJ.7 | The absolute original coefficient is not the rebased detector. The 14 natural tests and 32 inherited tests are extension-status tables; not full unstable mixed-class counts. |
| `BND-ID-B4-003` (local boundary) | #163–176 | Spectral results retain invertibility/gap, groupoid/representation sorts, and stated finite sampled operators; conditional physical identification stays conditional. |
| `BND-ID-B4-004` (local boundary) | #173–200 | Standard-root calculations and scalar/vector inverse responses are normalized mathematical interfaces, not a physical spectrum reconstruction merely because root counts match. |
| `BH-ID-EV-0002` (new *provisional* independent-verification requirement) | BG.3–BG.11, source ~18440–18595; consumed #159–160 | Reproduce the **whole original-source paired-bigon null and global glued S7 class** including all cap, collar, deck, orientation and boundary faces. The local degree parity has E3; the complete source-specific map has not received independent full-chain E3. This does **not** refute the source proof. Adjudicate against existing root before final canonical registration; do not clone an existing issue. |
| `BH-IB-EV-0001` (inherited) | #160 natural extension table | Need distinct exact whole unstable fixed-Chern realization/multiplicity chain; a natural YES/NO test is not that count. |
| `BH-IB-EV-0002` (inherited) | #154–160, secondary determinant action | Full 8D secondary affine determinant action/orbit image, beyond first restricted stage; currently no new closure certificate. |
| `BH-IB-EV-0003` (inherited) | #152–160 | Actual mixed/equivariant descent and lift comparison, not arbitrary rank-three stable clutch operation. |
| `BH-IB-EV-0004` (inherited) | #152–160 | Complete global **whole-image** source-realized rank-two gauge and join; not merely existence of the explicit displayed family. |
| `BH-IB-EV-0008` / `BH-IB-EV-0010` (candidates only) | #173–175 | Nonuniform invariant normalization and nonfree quotient/stabilizer interfaces were source-read; they are not asserted to block #173 without a validated material dependency path. |
| `BH-ID-DAG-0002` (E0 integrity) | full source and all four batches | Current canonical v1.155 global atlas still lacks complete current I-D E3/E4 ledger. Final integration must restore full source-as-printed for earlier 1–151 records, preserve issue-root identities and eliminate superseded versions. |
| `BH-ID-EV-0001` (inherited, not rechallenged) | earlier 490-facet calibration, upstream | Raw triangulation/cochain executable not recovered here; absence of a replay is not a demonstration that the published cup-product arithmetic is false. |
| `BH-IC-EV-0001` (inherited, not rechallenged) | earlier NZ.4 bound, upstream | Directed-rounded complete Hessian certificate was not reconstructed here; a separately sourced topological route is not identical evidence. |

**Two scoped attacks adjudicated:** dropping the SC.5 commutator changes the source expression, so the source correctly includes it; carrying parity between unrelated source bridges without the required actual cap identification violates the theorem’s hypotheses. No valid source-domain-matched counterexample, false equality, or contradictory physical output was established in Batch 4. **The absence of a refutation is not proof of an entire global theorem.**

## 5. DAG staging and cross-batch release boundaries

1. The 49 claim records retain full source-as-printed statement, SHA-256 and exact proof span or explicit source-prose alternative; typed domain guard, inherited status lineage, scoped new E2/E3/E4 controls, and linked issue candidates.
2. The ledger records eight source-reviewed, typed **local dependency proposals**, each with a consumer/source locator and a guard; they remain staged until schema-validated integration with the existing global DAG. The 65 resolved reference labels are **navigation evidence only**; they are not promoted wholesale into material `PREMISE_OF` edges.
3. The original mathematical statement remains untouched; no new material premise/axiom is introduced. Source labels with a `p1b:` prefix inside the *I-D* manuscript are not mistakenly assigned to an independently audited Paper I-B. The paper being audited is the actual `Paper1D-TechnicalMaterial-v1_67.tex` selected source.
4. This report, JSON ledger, runnable Python verification script and machine-readable results are *checkpoint artifacts*. **No DAG Atlas ZIP or ProofChain Audits ZIP is produced or changed in Batch 4.** In the final batch, merge all staged claims/evidence with the **latest supplied** archives, deduplicate versions, check archive integrity and preserve untouched historical materials and open first-root issue ancestry.
5. **Next bounded batch starts with formal object #201**. **79 objects** remain (#201–279), including the concluding formal remark, plus the required audit of material unnamed calculations. Full-paper status is explicitly withheld until that review is finished.

## 6. Evidence files and reproducibility

- `Paper1D-RigorousAuditBatch4Ledger-v1_1.json` — the complete 49-object source and proof ledger, SHA hashes, typed boundary, candidate first-root issues, 44 source-indexed unnamed inline modules and eight reviewed local dependency proposals.
- `Paper1D-Batch4IndependentControls-v1_1.py` — deterministic source-hash-checked executable with explicit exact, sampled and adversarial families; no original TeX edits.
- `Paper1D-Batch4IndependentControls-v1_1.json` — machine result: **6,456** scoped assertions in **71** families, stratified by E2/E3/E4, pass status; **zero new whole-theorem certification promotions**.
- `Paper1D-RigorousAuditBatch4-v1_1.md` — this report. All files share audit date **2026-11-16**, and the source SHA-256 is checked before using each mathematical assertion.

**No hidden evidence claim:** the presence of source proof text is `E1`; the 49 historical statuses are provenance; passing scripts give only their recorded scopes; the global original-source top-class argument and prior missing raw certificates remain distinctly identified. Audit work was conducted in sequential replay/independent/adversarial passes; no multi-agent human consensus is claimed.
