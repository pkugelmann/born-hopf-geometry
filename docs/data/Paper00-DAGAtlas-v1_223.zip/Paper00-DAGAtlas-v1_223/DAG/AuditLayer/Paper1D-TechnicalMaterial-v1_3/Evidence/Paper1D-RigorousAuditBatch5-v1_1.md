# Paper I-D — Rigorous Verification DAG Audit, Final Batch 5 (v1.1)

**Frozen source:** `Paper1D-TechnicalMaterial-v1_67.tex`, SHA-256 `3cd6ae8bb286536ef7bc871d359996309e53ac3a6aed89917a5a82c53b6dcb2a`, 26,561 lines in `Paper00-PapersMinimal-v3_019(1).zip`.
**Protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md`. **One-paper remit:** I-D only. No manuscript repair or new theory.
**Scope:** claim objects 201–279 inclusive (79); cumulative 279/279 formal environments, plus 39 source-indexed substantive unnamed paragraph modules. No global framework verification claim.

## Frozen target and status

The source contains 272 previously indexed formal objects, six IC19 propositions/theorem and a final unlabeled scope remark; the 279-object count is the directly extracted TeX environment count. Earlier reports sometimes counted the closing remark only as prose. **Current evidence statuses are inherited or source-guarded**, not promoted from finite calculations.

| Disposition | Number of current formal statements | Source of assessment |
|---|---:|---|
| `REPRODUCED` | 82 | historical source-matched disposition and guarded IC19 integration |
| `VERIFIED-CONDITIONAL` | 111 | historical source-matched disposition and guarded IC19 integration |
| `VERIFIED` | 72 | historical source-matched disposition and guarded IC19 integration |
| `FORMALIZED` | 11 | historical source-matched disposition and guarded IC19 integration |
| `UNRESOLVED-EVIDENCE` | 3 | historical source-matched disposition and guarded IC19 integration |

**Classification:** `FULLY_AUDITED_WITH_OPEN_GAPS`; no new source-matched mathematical counterexample established. The phrase **fully audited** means every source result has an explicit recorded disposition and evidence limit, not that all claims were independently E3/E4 certified.

## Batch 5 independent E2/E3/E4 checks

**1,507 successful scoped assertions** across 13 families from `Paper1D-Batch5IndependentControls-v1_1.py` and its machine-readable result. Family-level provenance distinguishes exact symbolic evidence from bounded examples and E2 corroboration; see JSON. Fresh source checks include:

- Weighted reciprocal involution and Euler anticommutation; exact conjugate pairs and quotient-type reductions under their stated regularity/domain.
- Schur-complement Gaussian return kernel and Dirichlet-to-Neumann matrix relations, with positivity/linear-invertibility guards retained.
- Independent 600-cell coordinate reconstruction over Q(√5): 120 vertices, 720 graph edges, 600 tetrahedral facets, degree 12; this is not a full executable chamber-transporter certificate.
- Hurwitz exact quadrature average 1/12 versus round 1/16; their discrepancy is 1/48 on the source-selected test polynomial, not a universal physical correction.
- F40 minimal-polynomial and formal reciprocal inverse, not the full source-specific gluings or every relevant eigenvector.
- Pauli–Dirac polynomial matrix controls for Fischer kernel dimensions at degrees 1–4, not an all-degree global spectral certificate.
- Additional reciprocal contact, convexity, zeta-formal and parity checks; numerical examples cannot prove a continuous-domain statement.

**Archived executables:** 4 independently rerun and passed: `HadronScaleTest-v1_10`, `PetersenBridges-v1_3`, `ReciprocalSignedCoupling-v1_1`, and `ThreeCycleReconstruction-v1_2`. `F40MirrorGluing-v1_1` did not replay because required `PetersenHodgePlucker-v1_10` is absent from the archive; record it as a *missing evidence dependency*, not a mathematical contradiction. Other chamber and NZ.4 certificate sources are likewise not present.

## Current source objects 201–279

| No. | Source label | TeX line(s) | Prior/source disposition | Scoped check families |
|---:|---|---:|---|---|
| 201 | `p1b:def:weighted-born-pullback` | 20692–20703 | `FORMALIZED` | Source/proof review; no fresh full-E3 |
| 202 | `p1b:thm:born-euler-anticommutation` | 20705–20736 | `VERIFIED` | E3_EULER_ |
| 203 | `p1b:prop:born-hessian-quotient-obstruction` | 20752–20764 | `VERIFIED` | E3_QUADRATIC_ |
| 204 | `p1b:thm:reciprocal-readout-refinement` | 20779–20790 | `VERIFIED` | Source/proof review; no fresh full-E3 |
| 205 | `p1b:thm:paired-hessian-euler` | 20805–20818 | `VERIFIED` | E3_EULER_, E3_QUADRATIC_ |
| 206 | `p1b:cor:born-euler-quadratic-reconstruction` | 20837–20855 | `VERIFIED` | E3_QUADRATIC_ |
| 207 | `p1b:prop:evaluation-legendre-contact-lift` | 20874–20889 | `VERIFIED` | E3_CONTACT_ |
| 208 | `p1b:prop:reciprocal-connection-lifts` | 20903–20912 | `VERIFIED` | Source/proof review; no fresh full-E3 |
| 209 | `p1b:prop:reciprocal-affine-contact-lifts` | 20924–20943 | `VERIFIED` | E3_CONTACT_ |
| 210 | `p1b:cor:eh-fixed-affine-reciprocity` | 20959–20970 | `VERIFIED` | E3_QUADRATIC_ |
| 211 | `p1b:thm:reciprocal-convexity-test` | 20988–21007 | `VERIFIED` | E3_LAURENT_ |
| 212 | `p1b:cor:reciprocal-cubic-window` | 21021–21033 | `VERIFIED` | E3_LAURENT_, E4_CONVEXITY_ |
| 213 | `p1b:thm:global-integer-laurent-rigidity` | 21046–21054 | `VERIFIED` | E3_LAURENT_, E4_CONVEXITY_ |
| 214 | `p1b:prop:euler-response-dressing-compatibility` | 21074–21090 | `VERIFIED` | E3_EULER_ |
| 215 | `p1b:thm:dressed-convexity` | 21108–21140 | `REPRODUCED` | Source/proof review; no fresh full-E3 |
| 216 | `p1b:thm:trace-calculus` | 21170–21212 | `VERIFIED` | Source/proof review; no fresh full-E3 |
| 217 | `p1b:thm:uniform-trace-bound` | 21233–21254 | `VERIFIED-CONDITIONAL` | Source/proof review; no fresh full-E3 |
| 218 | `p1b:cor:quadratic-response` | 21291–21306 | `VERIFIED` | Source/proof review; no fresh full-E3 |
| 219 | `p1b:thm:conformal-hessian` | 21329–21359 | `VERIFIED-CONDITIONAL` | Source/proof review; no fresh full-E3 |
| 220 | `p1b:thm:all-order-schur` | 21382–21405 | `VERIFIED` | Source/proof review; no fresh full-E3 |
| 221 | `p1b:thm:v124-boundary-tangent-groupoid` | 21433–21457 | `VERIFIED-CONDITIONAL` | Source/proof review; no fresh full-E3 |
| 222 | `p1b:def:v124-gaussian-return-kernel` | 21470–21490 | `FORMALIZED` | E3_GAUSSIAN_ |
| 223 | `p1b:thm:v124-return-coordinate-collar` | 21492–21517 | `VERIFIED` | E3_GAUSSIAN_, E4_GAUSSIAN_SCOPE_ |
| 224 | `p1b:thm:v124-return-gluing` | 21536–21547 | `VERIFIED` | E3_GAUSSIAN_ |
| 225 | `p1b:cor:v124-capped-dtn-cayley` | 21559–21573 | `VERIFIED` | E3_GAUSSIAN_ |
| 226 | `p1b:cor:v124-boundary-riccati` | 21587–21603 | `VERIFIED` | E3_GAUSSIAN_ |
| 227 | `p1b:def:v124-boundary-gluing-constructor` | 21614–21623 | `FORMALIZED` | E3_GAUSSIAN_ |
| 228 | `p1b:rem:v124-boundary-gluing-owner-firewall` | 21625–21628 | `FORMALIZED` | Source/proof review; no fresh full-E3 |
| 229 | `p1b:prop:heat-curvature` | 21683–21694 | `REPRODUCED` | Source/proof review; no fresh full-E3 |
| 230 | `p1b:prop:g11-transgression` | 22654–22671 | `VERIFIED-CONDITIONAL` | Source/proof review; no fresh full-E3 |
| 231 | `p1b:thm:g11-functional` | 22693–22714 | `VERIFIED-CONDITIONAL` | Source/proof review; no fresh full-E3 |
| 232 | `p1b:prop:g11-fluctuations` | 22735–22751 | `VERIFIED` | Source/proof review; no fresh full-E3 |
| 233 | `p1b:thm:full-kink-hessian` | 22788–22815 | `REPRODUCED` | Source/proof review; no fresh full-E3 |
| 234 | `p1b:thm:compactified-kink-kernel` | 22841–22858 | `REPRODUCED` | Source/proof review; no fresh full-E3 |
| 235 | `p1b:lem:g13-theta` | 23119–23144 | `REPRODUCED` | Source/proof review; no fresh full-E3 |
| 236 | `p1b:prop:g13-ladder` | 23175–23190 | `VERIFIED-CONDITIONAL` | Source/proof review; no fresh full-E3 |
| 237 | `p1b:prop:g13-magnetic` | 23219–23238 | `VERIFIED-CONDITIONAL` | Source/proof review; no fresh full-E3 |
| 238 | `p1b:prop:g18-dilations` | 23674–23689 | `VERIFIED` | Source/proof review; no fresh full-E3 |
| 239 | `p1b:prop:g18-second-fundamental` | 23695–23718 | `VERIFIED` | Source/proof review; no fresh full-E3 |
| 240 | `p1b:prop:cyclic-associator-closure` | 24226–24237 | `VERIFIED-CONDITIONAL` | Source/proof review; no fresh full-E3 |
| 241 | `p1b:prop:ordinary-born-component-translation` | 24265–24279 | `REPRODUCED` | Source/proof review; no fresh full-E3 |
| 242 | `p1b:prop:exotic-born-square-obstruction` | 24330–24343 | `REPRODUCED` | Source/proof review; no fresh full-E3 |
| 243 | `p1c:prop:v242-native-family-cubic` | 24662–24684 | `VERIFIED` | Source/proof review; no fresh full-E3 |
| 244 | `Paper1D:unlabeled:0244:L24734` | 24734–24742 | `FORMALIZED` | Source/proof review; no fresh full-E3 |
| 245 | `p1c:prop:v243-reynolds-character-replay` | 24752–24778 | `VERIFIED-CONDITIONAL` | Source/proof review; no fresh full-E3 |
| 246 | `p1c:prop:v243-four-atom-moment-proof` | 24804–24827 | `VERIFIED` | Source/proof review; no fresh full-E3 |
| 247 | `p1c:prop:v243-icosian-sextic-riesz-proof` | 24852–24862 | `VERIFIED` | Source/proof review; no fresh full-E3 |
| 248 | `p1c:prop:v243-neutral-boundary-source-proof` | 24882–24906 | `VERIFIED-CONDITIONAL` | Source/proof review; no fresh full-E3 |
| 249 | `p1c:thm:v340-hp2-edge-orbits` | 24993–25017 | `REPRODUCED` | E3_PETERSEN_ |
| 250 | `p1c:prop:v340-hp2-local-coeff-obstruction` | 25036–25059 | `VERIFIED` | E3_PETERSEN_ |
| 251 | `p1:prop:v203-quadratic-alias-witness` | 25143–25152 | `VERIFIED` | E3_2T_QUADRATURE_ |
| 252 | `p1:cor:v203-geometric-positive-polar` | 25162–25173 | `VERIFIED-CONDITIONAL` | Source/proof review; no fresh full-E3 |
| 253 | `p1:thm:HS-invariance` | 25242–25252 | `VERIFIED` | Source/proof review; no fresh full-E3 |
| 254 | `p1:thm:tensor-trace` | 25259–25269 | `VERIFIED` | Source/proof review; no fresh full-E3 |
| 255 | `p1:thm:commutant-trace-mult` | 25275–25283 | `VERIFIED-CONDITIONAL` | Source/proof review; no fresh full-E3 |
| 256 | `p1c:prop:v341-coefficient-rank-and-topology` | 25297–25320 | `REPRODUCED` | Source/proof review; no fresh full-E3 |
| 257 | `p1c:prop:v342-threecycle-exact-certificate` | 25339–25355 | `REPRODUCED` | Source/proof review; no fresh full-E3 |
| 258 | `p1c:prop:v343-signed-coupling-certificate` | 25375–25392 | `VERIFIED-CONDITIONAL` | Source/proof review; no fresh full-E3 |
| 259 | `p1c:prop:v344-hurwitz-petersen-verification` | 25414–25431 | `REPRODUCED` | Source/proof review; no fresh full-E3 |
| 260 | `p1c:prop:v345-f40-certificate` | 25449–25471 | `REPRODUCED` | Source/proof review; no fresh full-E3 |
| 261 | `p1c:thm:v349-f40-23-equations` | 25485–25516 | `REPRODUCED` | Source/proof review; no fresh full-E3 |
| 262 | `p1c:prop:v349-f40-rational-frame-inverse` | 25532–25549 | `VERIFIED` | E3_F40_POLYNOMIAL_ |
| 263 | `p1c:prop:v349-comparison-proof-register` | 25558–25567 | `FORMALIZED` | Source/proof review; no fresh full-E3 |
| 264 | `p1c:thm:v357-spinor-fischer` | 25575–25601 | `VERIFIED` | E3_FISCHER_ |
| 265 | `p1c:thm:v357-spinor-filtration` | 25615–25642 | `VERIFIED-CONDITIONAL` | E3_FISCHER_ |
| 266 | `p1c:rem:v357-spinor-filtration-scope` | 25658–25667 | `FORMALIZED` | Source/proof review; no fresh full-E3 |
| 267 | `p1c:rem:v365-hurwitz-candidate-quarantine` | 25697–25710 | `FORMALIZED` | Source/proof review; no fresh full-E3 |
| 268 | `p1c:prop:v366-exact-coordinate-chamber` | 25725–25761 | `UNRESOLVED-EVIDENCE` | E3_600CELL_ |
| 269 | `p1c:prop:v366-cumulative-hurwitz-certificates` | 25774–25799 | `UNRESOLVED-EVIDENCE` | Source/proof review; no fresh full-E3 |
| 270 | `p1c:rem:v366-hurwitz-source-corrections` | 25810–25823 | `FORMALIZED` | Source/proof review; no fresh full-E3 |
| 271 | `p1c:prop:v370-e8-finite-certificate` | 25837–25873 | `UNRESOLVED-EVIDENCE` | Source/proof review; no fresh full-E3 |
| 272 | `p1c:rem:v370-e8-provenance` | 25889–25897 | `FORMALIZED` | Source/proof review; no fresh full-E3 |
| 273 | `p1d:prop:ic19-stable-rank-three` | 26309–26321 | `VERIFIED-CONDITIONAL` | Source/proof review; no fresh full-E3 |
| 274 | `p1d:prop:ic19-compatible-seeds` | 26334–26350 | `VERIFIED-CONDITIONAL` | Source/proof review; no fresh full-E3 |
| 275 | `p1d:prop:ic19-first-postnikov-action` | 26377–26392 | `VERIFIED-CONDITIONAL` | E2_IC19_PARITY_ |
| 276 | `p1d:prop:ic19-lens-torsion` | 26402–26420 | `VERIFIED-CONDITIONAL` | Source/proof review; no fresh full-E3 |
| 277 | `p1d:prop:ic19-top-transgression` | 26444–26456 | `VERIFIED-CONDITIONAL` | E2_IC19_PARITY_ |
| 278 | `p1d:thm:ic19-natural-determinant-route` | 26467–26484 | `VERIFIED-CONDITIONAL` | E2_IC19_PARITY_ |
| 279 | `Paper1D:unlabeled:0279:L26533` | 26533–26554 | `FORMALIZED` | Source/proof review; no fresh full-E3 |

The complete, byte-source-extracted unabridged statements, proof spans and SHA-256 per object are in `AuditClaimLedger.json`. All 39 unnamed mathematical module anchors are recorded in `UnnamedMaterialDerivations.json` and are not falsely counted as extra formal theorem environments.

## Complete open issue root register (11)

| Issue | Class / severity | Source locus | Precise remaining obligation |
|---|---|---|---|
| `BH-IB-EV-0001` | `CONDITIONAL_FRONTIER` / major | 273; 26309–26332 | Fixed-stable-class rank-three realizability is source-proved; rank-two fixed-Chern unstable fibre multiplicities and complete equivariant classification are not. **Needed:** Complete source-matched unstable rank-two fibre enumeration, preserving fixed stable class and Chern coordinates. |
| `BH-IB-EV-0002` | `MISSING_EVIDENCE` / major | 275; 26377–26401 | Printed first Postnikov/retract determinant formula is limited to the first stage; full eight-dimensional secondary affine action is not certified. **Needed:** Construct/source-verify all higher-stage determinant orbit actions on full M8; do not extrapolate from retract. |
| `BH-IB-EV-0003` | `CONDITIONAL_FRONTIER` / major | 274,278; 26334–26375,26467–26531 | Principal SU(2) exotic lift no-go is checked in its domain, but complete mixed/equivariant lift and gauge comparison remains conditional. **Needed:** Exact global mixed and equivariant lift classification with matching isotropy and boundary frames. |
| `BH-IB-EV-0004` | `CONDITIONAL_FRONTIER` / major | 274–278; 26334–26531 | The local G20/G21 seeds and natural joining route have named premises; complete global image of every boundary gauge has not been shown. **Needed:** Full global boundary-gauge image/exhaustiveness certificate, not just explicit representatives. |
| `BH-IB-EV-0006` | `MISSING_EVIDENCE` / moderate | historical audit; closing scope remark 279 lines 26533–26554 | Declared Hermitian-family subresults do not establish an entire unrestricted global normal-form and generalized-Kähler classification. **Needed:** Independent full-domain global normal-form/classification check at original quantifiers. |
| `BH-IB-EV-0009` | `MISSING_EVIDENCE` / moderate | historical audit; scope remark 279 | Partial finite-mode checks do not certify the complete all-orbital TT/Rarita–Schwinger zeta/heat spectrum. **Needed:** Source-matched all-orbital spectral and heat/zeta completeness certificate. |
| `BH-IB-EV-0010` | `MISSING_EVIDENCE` / moderate | historical audit; scope remark 279 | Global quotient stabilizers and orbifold kernel structure have not been exhaustively reconstructed. **Needed:** Full stabilizer/kernel/orbit calculation with exact quotient domain and isotropy. |
| `BH-IC-EV-0001` | `MISSING_EVIDENCE` / moderate | NZ.4 source proof; historical batch 3 | NZ.4 Hessian 50-decimal directed-rounding interval certificate is absent; local inverse/cap alternative does not replay that certificate. **Needed:** Original directed-rounding all-domain boxes, round mode and executable certificate. |
| `BH-IC-EV-0002` | `MISSING_EVIDENCE` / major | 260–261, 268–271; historical audit | Original F40, Hurwitz chamber and E8 source-matched finite certificate suite is incomplete. Four available neighboring geometry scripts passed, but the F40 mirror replay stops at a missing predecessor. **Needed:** Complete original raw source-matched executables/data, including the missing Petersen Hodge-Plücker v1_10 predecessor and chamber/E8 certificates. |
| `BH-ID-EV-0001` | `MISSING_EVIDENCE` / moderate | RT.57/RT.59; historical batch 2 | 490-simplex/triangulation and cochain calibration original raw data are absent; finite group controls do not reproduce the calibrated cup-product test. **Needed:** Supply original simplicial facets, incidence/cochains and exact executable with checksums. |
| `BH-ID-EV-0002` | `CONDITIONAL_FRONTIER` / moderate | 278 lines 26467–26531 | A checked odd-degree/factor arithmetic and final 4/14 count do not on their own independently reproduce the original global paired-bigon homotopy and joining class. **Needed:** Independent source-exact original paired-bigon and based homotopy proof including both inverse K factors and entire noncommutative difference word. |

### Resolved or scope-closed roots — without stronger inference

- `BH-IB-EV-0005` — Marked 2I character, cubature and finite sample scope only.
- `BH-IB-EV-0007` — Declared pluriclosed Hermitian family only.
- `BH-IB-EV-0008` — Finite homogeneous and positive-sampling family only.
- `BH-IB-EV-0011` — Classical spatial midpoint YM Hessian only.
- `BH-ID-DAG-0001` — Previous I-D registration discrepancy resolved in inherited audit.
- `BH-ID-DAG-0002` — Current full 279-object DAG coverage and formal closure remark reconciled in v1.156.

## Dependency and propagation integrity

- 20 newly source-reviewed *local* material proof-use edges in Batch 5; 8 additional source-reviewed local links from Batch 4. Each is typed with use locator, AND-route and scope guard. Only cycle-free, ID-resolved edges are registered in the global combined material graph.
- 408 distinct current-corpus cross-references are **CANDIDATE_LINK/CITATION_ONLY** and quarantined, rather than being bulk promoted to proof ancestry; both source-reported and imported scopes remain attached.
- Existing global canonical assumption nodes are reused; this run adds no G0/GP1–GP3 or hypothetical new axiom. Named G15/G20/G21, exchange, framing, root-cap and relative Thom prerequisites are guarded use records, not newly assumed unconditional facts.
- Material downstream impacts are path-queried from actual direct edges. Citation resemblance is tagged `POSSIBLY_AFFECTED`; no remote-paper theorem or physical decay rate is refuted or certified by association.
- The initial `BH-ID-DAG-0002` census/integration gap is closed: registered 279 exact current I-D claims and 11 missing canonical formal-object nodes while preserving prior 268 canonical nodes and source statuses. Historical stage remains as provenance only.

## Final source-specific interpretation

The IC19 natural determinant theorem asserts `(h_t,w_t,r_J,ζ_nat)=(1,1,0,0)` **subject to its written G20/G21 and RT.53.4/NY–NZ/OB–OL geometric premises**. The independent finite parity, lens and determinant counts support only their scoped steps. An enumeration of four extending boundary configurations from fourteen possibilities does **not** determine the named h_t and w_t bits. No physical decay occurrence is concluded.

**Final archive action:** increment active DAG Atlas to `Paper00-DAGAtlas-v1_156.zip`, and current ProofChain Audits to `Paper00-ProofChainAudits-v1_69.zip` with one active I-D report `Paper1D-ProofChainAudit-v1_5.md`; do not include superseded active I-D audit in the current audits ZIP. Runtime validation details are in the resulting release sidecars.
