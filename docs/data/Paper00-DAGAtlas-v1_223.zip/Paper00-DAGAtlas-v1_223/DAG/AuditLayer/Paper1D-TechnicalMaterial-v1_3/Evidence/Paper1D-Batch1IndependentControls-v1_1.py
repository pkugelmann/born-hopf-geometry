#!/usr/bin/env python3
"""Paper I-D v1.67, batch 1, *scoped* source-matched independent controls.
This verifies finite abelian group presentations, exact sequence, gcd tables,
quaternion nullhomotopy and mod-2 characteristic class; it does NOT certify
actual geometric bundle/gauge existence or all imported homotopy claims.
"""
import json,math,hashlib,random
from pathlib import Path
from sympy import Matrix
from sympy.matrices.normalforms import smith_normal_form
from sympy.polys.domains import ZZ
p=Path(__file__).resolve().parent
source=(p/'Paper1D-TechnicalMaterial-v1_67.tex').read_bytes()
counts={}
witnesses=[]
def passed(name,detail=None):
 counts[name]=counts.get(name,0)+1
 if detail and len(witnesses)<22: witnesses.append({'control':name,**detail})

def cokernel(relations,n_gen):
 m=Matrix(relations)
 assert m.cols==n_gen
 d=smith_normal_form(m,domain=ZZ)
 diag=[abs(int(d[i,i])) for i in range(min(*d.shape)) if int(d[i,i])!=0]
 assert len(diag)==n_gen, ('nonfinite',relations,diag)
 inv=tuple(sorted(v for v in diag if v>1))
 return inv,math.prod(diag)
# generators (b,z,e,t), with 6z=2e=2t=0, sphere 2b+z_A z+w_e e+w_t t =0
base=[[0,6,0,0],[0,0,2,0],[0,0,0,2]]
# independent expected groups for all finite parity, sectors, all congruence representatives
for A in range(-240,241):
 h12=math.gcd(12,A);h6=math.gcd(6,A)
 zA=(5-2*A)%6
 for we in (0,1):
  for wt in (0,1):
   sphere=[2,zA,we,wt]
   for parity,sector,fs,rels,expected in [
    ('even',0,False,[[0,0,0,1]],(2,12)),
    ('even',1,False,[[0,0,0,1],[0,3,0,0]],(2,6)),
    ('odd',0,False,[],(2,2,12)),
    ('odd',1,True,[[0,0,0,1]],(2,12)),
   ]:
    if (A%2==0)!=(parity=='even'):continue
    if parity=='even' and (we or wt):continue # these are zero in source Chern-zero even chart
    v,order=cokernel(base+[sphere]+rels,4)
    assert v==expected,(A,parity,sector,v,expected)
    passed('finite_sphere_group_snf')
   if A%2:
    for he in (0,1):
     full=cokernel(base+[sphere,[0,0,0,1],[0,3,he,0]],4)[0]
     exp=(12,) if ((we+he)%2) else (2,6)
     assert full==exp,(A,we,wt,he,full,exp)
     passed('odd_exotic_full_snf')
  # do not use z_A odd as a claim that other natural coefficients are zero
 if A%2==0:
  even_rows=[(2*h12,12//h12),(2*h12,12//h12)] if A%4==2 else [(2*h12,12//h12),(h12,24//h12)]
  even_rows.extend([(2*h6,6//h6),(h6,12//h6)])
  assert sum(x*y for x,y in even_rows)==72
  assert all(0<x[1]<=6 for x in even_rows)
  passed('even_gcd_fibre_table')
  assert 2*(48//2+48//4)==72 and 2*(48//2+48//2)==96
  passed('even_count')
 else:
  assert (96//h12)*h12==96
  assert (12//h6)*h6==12
  assert (96//h12) in (96,32)
  assert (12//h6) in (12,4)
  passed('odd_gcd_fibre_table')
  assert 2*(48+12)==120 and 2*(48+24)==144
  passed('odd_count')
 # theorem33-sphere: normalized congruence, leading correction odd
 assert (2+2*zA+4*A)%12==0 and zA%2==1
 passed('sphere_congruence')
# RT.38.3 is exact: the C2 injection, boundary and quotient maps on C12 x C2
Z12=range(12);Z2=range(2)
alpha={(0,0),(6,0)}
delta=lambda r,s:((2*r)%12,s)
ker={(r,s) for r in Z12 for s in Z2 if delta(r,s)==(0,0)}
image={delta(r,s) for r in Z12 for s in Z2}
kerfinal={(r,s) for r in Z12 for s in Z2 if r%2==0}
assert alpha==ker and image==kerfinal and len(image)==12
passed('relative_coefficient_exactness',{'ker_size':len(ker),'im_size':len(image)})
# obstruction O7(z,e,t)=(2z,e), exactly two of 24 survive
survivors=[]
for z in range(6):
 for e in range(2):
  for t in range(2):
   if (2*z%12,e)==(0,0):survivors.append((z,e,t))
assert survivors==[(0,0,0),(0,0,1)]
passed('pure_boundary_stage7_enumeration',{'survivors':survivors})
for parity in [0,1]:
 n=sum(1 for z,e,t in survivors if parity==0 or t==0)
 assert n==(2 if parity==0 else 1)
 passed('pure_boundary_stage8_enumeration',{'A_parity':parity,'full_extensions':n})
# C12 map RT.31.9, RT.32.2, with v=0 (actual zero-sphere slice) and z in {0,3}
for epsilon in [0,1]:
 for k in range(-40,41):
  solutions=[z for z in [0,3] if (2*z-6*epsilon*k)%12==0 and (-2*z-6*epsilon*k)%12==0]
  assert solutions==[3*((epsilon*k)%2)]
  passed('actual_slice_zero_sphere_coordinate')
# mod 2 Whitney identity w(3 gamma)=(1+chi)^3, w1=chi, w2=chi^2
assert 3%2==1 and math.comb(3,2)%2==1
passed('normal_bundle_whitney')
# RT.32.7: unit quaternion norm, endpoints, periodicity, based condition
# Represent quaternions (1,i,j,k) as tuples.
def qmul(a,b):
 a0,a1,a2,a3=a;b0,b1,b2,b3=b
 return (a0*b0-a1*b1-a2*b2-a3*b3,a0*b1+a1*b0+a2*b3-a3*b2,a0*b2-a1*b3+a2*b0+a3*b1,a0*b3+a1*b2-a2*b1+a3*b0)
def conj(q):return (q[0],-q[1],-q[2],-q[3])
def qnorm(q):return sum(x*x for x in q)
def C(m,v):
 cv,sv=math.cos(v),math.sin(v)
 first=(cv*math.cos(m),cv*math.sin(m),sv,0.)
 second=(cv,0.,sv,0.)
 return qmul(first,conj(second))
def near(x,y,tol=2e-12):return max(abs(a-b) for a,b in zip(x,y))<tol
rng=random.Random(160112)
for _ in range(1024):
 m=rng.uniform(-50,50);v=rng.uniform(0,math.pi/2)
 assert abs(qnorm(C(m,v))-1)<2e-12
 assert near(C(m+2*math.pi,v),C(m,v))
 assert near(C(0,v),(1,0,0,0))
 assert near(C(m,math.pi/2),(1,0,0,0))
 assert near(C(m,0),(math.cos(m),math.sin(m),0,0))
 passed('quaternion_loop_control')
# Adversarial mutation: omitting v=0 in RT.32.3 changes allowable z when A odd.
A=1;eps=0;k=0
# N_c * (v1,v2)=(-A(v1+v2),A(v1+v2)), with z=3 -> (6,6), choose v1+v2=6 mod12.
assert ((2*3 - (-A*6))%12,( -2*3-(A*6))%12)==(0,0)
passed('adversarial_forbidden_slice_mutation', {'interpretation':'Arbitrary slice degree would falsely allow a=3z at k=0; actual theorem fixes v=0, so invalid counterexample.'})
result={
 'source':'Paper1D-TechnicalMaterial-v1_67.tex','source_sha256':hashlib.sha256(source).hexdigest(),
 'batch':1,'scope':'formal claims 1-50, lines 325-3160, finite controls only',
 'assertion_checks_by_kind':counts,'total_scoped_checks':sum(counts.values()),
 'witnesses':witnesses,
 'limitations':['Source-dependent bundle existence, global gauge realization, fifth-bit transfer, natural odd top bits, and relevant external homotopy facts are not independently certified by these finite checks.', 'No independence claim for historical scripts; these calculations are newly executable exact checks.'],
 'outcome':'all scoped checks passed'
}
(p/'Paper1D-Batch1IndependentControls-v1_1.json').write_text(json.dumps(result,indent=2))
print(json.dumps({'total_checks':result['total_scoped_checks'],'breakdown':counts,'result':result['outcome']},indent=2))
