# Paper I-D — Rigorous Verification DAG Audit, Batch 1 (v1.1)

**Target:** `Paper1D-TechnicalMaterial-v1_67.tex` in `Paper00-PapersMinimal-v3_018.zip`.  
**Source SHA-256:** `3cd6ae8bb286536ef7bc871d359996309e53ac3a6aed89917a5a82c53b6dcb2a`.  
**Protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md`; the original `Paper00-ProofChainAuditProtocol-v1_1.md` is secondary historical evidence.  
**Baseline archives:** `Paper00-DAGAtlas-v1_153.zip` and `Paper00-ProofChainAudits-v1_66.zip`.  
**Date:** 2026-11-16. **Run class:** `PARTIALLY_AUDITED_WITH_OPEN_GAPS` (1 of several intentionally bounded batches).  
**No changes** to any supplied paper, original atlas, TeX, or protocol. No PDF/visual audit. No new framework mechanisms or repairs.

## 1. Coverage and methodology

- Frozen target: 26,561 source lines. Exhaustive *formal-environment* census for the target: **279 objects** (including definitions and formally delimited remarks). The inherited report/closure registry counts **278 = 272 historical + 6 newly appended**; the current source additionally has a scope-and-issue-status `remark` at lines **26533–26554**. That remark is to be treated as a distinct audit object, not as a new mathematical theorem. Material *unnamed* calculations and physical-constructor statements are not exhausted by this 279-object census; they are included via their consuming theorem proof steps and must be separately checked before final completion.
- **Batch 1:** formal objects **1–50**, current source lines **325–3160**; 50/279 formal objects, 229 remaining for this fresh run. Every object in Batch 1 has a statement, a located local proof, a status-lineage record, and candidate proof-reference locators in `Paper1D-RigorousAuditBatch1Ledger-v1_1.json`. Source-use references are **candidates**, not automatically promoted to typed material DAG edges.
- Historical source-bound dispositions in the v1.4 audit: **22 `REPRODUCED`, 24 `VERIFIED-CONDITIONAL`, 4 `VERIFIED`**. These are the *inherited* classifications; they are **not** 50 newly independent proof certificates. The four inherited `VERIFIED` labels are `p1b:rt:lemma32-loop`, `p1b:rt:theorem37-generator`, `p1b:rt:corollary37-test`, `p1b:rt:theorem41-type`. Source inspection here preserves explicit geometric/imported conditions; no inherited global claim is promoted to unconditional verification solely on this audit's finite checks.
- The current proof references found in these 50 statement-plus-local-proof spans resolved against the available current I-A, I-B, I-C, I-D, II-A TeX corpus (no automatic unresolved textual reference in that bounded search). Reference resolution is `E0`, **not** proof validity or proof-use review.
- Separate evidence functions were performed in one runtime (source replay/locator, independent exact computational controls, adversarial domain test). **No independent agent or multiple-reviewer consensus is claimed.**

## 2. Independent `E3` checks: exact and reproducible, but scoped

The executable `Paper1D-Batch1IndependentControls-v1_1.py` independently checks finite statements and sample-based geometric identities appearing in this source interval. Run result `Paper1D-Batch1IndependentControls-v1_1.json`: **6,957 scoped assertions passed**, zero scoped failures, with deterministic source SHA binding. This is **not** a count of 6,957 proven theorems. `E3` coverage is limited to the clauses explicitly checked below; it does not certify the global existence of any actual gauge or bundle.

### 2.1 Sphere relations, image quotients, counts (RT.31–RT.37)

For the source group
\[
 \mathscr A=\mathbb Z\{b\}\oplus C_6\{z\}\oplus C_2\{e\}\oplus C_2\{t\},
 \quad 2b+(5-2A)z+w_e e+w_t t=0,
\]
we recomputed Smith normal forms across \(-240\le A\le240\), both allowable Chern-parity charts, image generators and torsion-bit assignments. In the even source chart the sector-0 and sector-1 quotient groups are, respectively, \(C_{12}\oplus C_2\) and \(C_6\oplus C_2\); in the odd source chart the sector-0 quotient is \(C_{12}\oplus C_2^2\), the odd exotic determinant-one quotient is \(C_{12}\oplus C_2\), and adding the odd exotic full determinant generator gives \(C_{12}\) precisely when \(w_e+h_e=1\), otherwise \(C_6\oplus C_2\). The *conditionality* of this last branch remains real until the matched natural coefficient is supplied by its separate geometric construction.

Independent integer/parity controls also confirm \(2+2(5-2A)\equiv -4A\pmod {12}\), the source's even 72 and odd 120 full-gauge orbit totals, its even 96 and odd 144 determinant-one auxiliary totals, and its corresponding gcd/fibre divisibilities. The finite checks cover relevant arithmetic of claims #4, 8, 12–13, 17, 19, 21–22, 26–28, 32–34 and 46–47. They **do not** independently supply the geometric realization of these generators, justify the list of all allowed images, or decide the natural top bits.

### 2.2 Pure boundary obstruction sequence (RT.38–RT.39)

Under the **source-declared** boundary cohomology groups and actual inclusion map (RT.38.1), the coefficient sequence
\[
 0\longrightarrow C_2 \overset{s\mapsto(6s,0)}\longrightarrow C_{12}\oplus C_2
 \overset{\delta_6:(r,s)\mapsto(2r,s)}\longrightarrow C_{12}\oplus C_2
 \overset{(r,s)\mapsto r\bmod2}\longrightarrow C_2\longrightarrow0
\]
is exact: the first image and second kernel have two elements; the second image and final kernel have twelve. The induced pure-skeleton obstruction \(O_7(z_0,e_0,t_0)=(2z_0,e_0)\) annihilates **exactly two** of 24 prescribed pure classes: \((0,0,0)\) and \((0,0,1)\). With source-stated fourth-stage top adjustment, both extend at even \(A\) and only the identity at odd \(A\).

This is an independent verification of the **finite complex with the declared source maps**; it does **not** independently establish the topology of \(W\), the natural class identifications \(U,B,\Gamma_h,\Gamma_\chi\), actual bundle-gauge extension, or \(\pi_7SU(2)=C_2\). Accordingly the current bounded verdict for the complete theorems remains source-relative/conditional, particularly claims #35–38.

### 2.3 Normal framing, based loop and adversarial control (RT.32, RT.42)

- The mod-two Whitney calculation from the declared capped bundle \(\widehat\nu=\mathbb R^3\oplus3\gamma\) checks \(w_1=\chi\), \(w_2=\chi^2\ne0\) on \(\mathbb{RP}^2\); independently of that arithmetic, the prescribed **relative boundary framing**, Thom-space attaching class \(i\eta_6\), and induced homotopy coefficient \(6\nu'\) require the source's geometric/homotopy proof steps.
- The quaternionic interpolation in RT.32 was checked at 1,024 fixed-seed numerical points for unit norm, basing, two endpoints and period. These are `E2/E3` finite-point consistency controls and **not** an exhaustive topological proof of the specified family or gauge source.
- `E4`: removing the actually stated zero-sphere restriction \(v=0\) from the normalized-coordinate equation produces a fabricated extra \(3z\) solution. That mutated example is **outside the theorem's domain**. It is recorded as a **rejected counterexample**, not as a refutation. The in-domain integer residue test succeeded for 162 values.

## 3. Persisting issues and conditions in this batch

The issue IDs below are deliberately de-duplicated. Four are **inherited open evidence/realization boundaries**, not new mathematical counterexamples; one is a **new atlas coverage issue**. Where an effect path is not evidenced as a verified material graph edge, the possible downstream impact is labeled *unconfirmed*.

| ID | Type / severity | Source locator | Status, exact remaining obligation |
|---|---|---|---|
| `BH-IB-EV-0001` | `CONDITIONAL_FRONTIER` / major | I-D lines 695–714, 1459–1515; new later closure lines 26310ff | Rank-three **fixed-stable-class** realizability is a separately discharged scope. The **rank-two** unstable fixed-Chern multiplicity and equivalence of actual bundle count to all formal finite presentations still require full source-matched proof; the finite order arithmetic cannot establish that bridge. **OPEN_WITH_PARTIAL_CLOSURE**. |
| `BH-IB-EV-0002` | `CONDITIONAL_FRONTIER` / major | I-D lines 1499–1515, 2191–2263, 2911–3042 | The complete eight-dimensional **secondary** affine determinant action and orbit structure are not independently certified by the stated first-Postnikov calculation. The conditional quotient types are mathematically precise; promoting them to the fully realized orbit classification awaits the declared global action. **OPEN_WITH_PARTIAL_CLOSURE**. |
| `BH-IB-EV-0003` | `CONDITIONAL_FRONTIER` / moderate | I-D lines 346–424, 2035–2055, 2515–2549 | Principal SU(2) exotic no-go and low-skeleton source results remain valid at named scope. The *mixed equivariant/global* lift comparison and natural paired boundary transport are not certified in all global cases by the finite controls. **OPEN_WITH_PARTIAL_CLOSURE**. |
| `BH-IB-EV-0004` | `EVIDENCE_MISSING / CONDITION_OPEN` / major | I-D lines 299–323, 346–424, 645–714, 1798–1924, 2388–2497, 2515–2549 | Global gauge-image completeness and actual G20/G21 coherent compatible-bundle source: demonstrate **actual**, not merely presentational, generators and all relevant boundary maps in the full domain, including natural matched bits, or give a verified route by which their assumption is inherited. Source-relative seeds, lens and low-image calculations exist but are not the missing whole-image certificate. **OPEN_WITH_PARTIAL_CLOSURE**. |
| `BH-ID-DAG-0002` | `DAG_COVERAGE / E0` / moderate | I-D 26533–26554; atlas `DAG/AuditLayer/` and `DAG/Paper00-TheoremDAG.json:graph_layers` | The v1.153 atlas contains the **six-claim source-closure layer** `DAG/AuditLayer/Paper1D-TechnicalMaterial-v1_1`, but **does not contain** the separately cited **272-claim** `DAG/AuditLayer/Paper1D-v1_1` and does not explicitly register the complete current 279-object target ledger as a queryable audited layer. Earlier v1.4 audit reports `BH-ID-DAG-0001` resolved; that earlier historical disposition is *not* changed. The new missing-current-artifact observation requires carrying these 50 inspected objects (and later remainder), preserving status lineage, and re-registering the combined layer in the final atlas. The trailing formal remark must be indexed, not misrepresented as an extra theorem. **NEW; OPEN pending final archive write.** |

**Impact classification:** The arithmetic results in §2 are independent *conditional consequences* of the named presentations. The four inherited open roots concern the evidentiary route from actual compatible source data / global gauge actions to those presentations and their physical geometric interpretation. The downstream Paper I-C classification references are **possible affected interfaces**; their complete material impact paths must be rechecked in the final combined graph. No source-matched refutation or sign error was established in these 50 objects. An E0 missing atlas layer is not itself an incorrect source theorem.

**Resolved-in-scope historical roots are retained without reopening:** `BH-IB-EV-0005`, `BH-IB-EV-0007`, `BH-IB-EV-0008`, `BH-IB-EV-0011`. Other historical open roots belong principally to later Paper I-D regions and will be addressed at their first material use rather than copied into every early claim.

## 4. Audit-layer staging (not yet a released DAG)

The batch includes a 50-claim machine-readable ledger with source-as-printed statements, local proof spans, reference-locator candidates, inherited status lineage, independent-control applicability, and unapplied issue-root references. **No material DAG edge is certified merely by a `\\ref` occurrence**, and no proof flag is globally promoted.

**This is not the terminal batch.** The protocol's two consolidated user-requested archive deliverables—updated **DAG Atlas ZIP** and updated **ProofChain Audits ZIP**, each with latest current active versions and no superseded active per-paper audits—are **reserved for the final batch**. These isolated v1.1 batch evidence files are staged inputs for that deterministic merge, not substitute ZIPs.

**Next contiguous batch:** source claim numbers **51–117**, beginning at line 3198 and ending about line 7195 (67 formal objects); the first themes are relative framed-band/obstruction completion and associated G20/G21, RT.43–RT.63 gauge, torsion and finite cochain controls. Continue source-verified evidence after #117 in further bounded batches until the 279-object plus unnamed-material coverage contract is satisfied.

## 5. Reproducible files for Batch 1

- `Paper1D-RigorousAuditBatch1Ledger-v1_1.json`: 50 source-indexed claims, exact theorem text, proof spans, inherited status lineage, scoped `E3` attribution; machine-readable first ledger for the final combined atlas.
- `Paper1D-Batch1IndependentControls-v1_1.py`: executable finite checks; no source writes.
- `Paper1D-Batch1IndependentControls-v1_1.json`: result, assertion breakdown, SHA, and negative witness.

Final classification now: **`PARTIALLY_AUDITED_WITH_OPEN_GAPS`**, because 229 formal objects plus the remaining unnamed proof obligations have not yet been reviewed in this *fresh* run. The historical 272-claim audit remains reusable source-matched evidence, not newly rerun E3 certificates.
