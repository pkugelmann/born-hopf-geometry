#!/usr/bin/env python3
"""Source-scoped independent / adversarial checks for Paper I-D 201--279.
These are narrow mathematical E3/E4 checks, never whole-theorem certifications.
No non-audited physical inference; no source modifications.
"""
from __future__ import annotations
import hashlib, itertools, json, math, re, collections, random
from pathlib import Path
from fractions import Fraction
import sympy as sp

ROOT=Path('/mnt/data/audit_paper1d_work')
SOURCE=ROOT/'Paper1D-TechnicalMaterial-v1_67.tex'
CENSUS=json.loads((ROOT/'claim_census.json').read_text())
counts=collections.Counter();fams={};comments={};tiers={};fail=[]

def ok(name, assertion, note=None):
    counts[name]+=1
    if not bool(assertion): fail.append({'family':name,'test':counts[name],'detail':note});raise AssertionError(f'{name}#{counts[name]}: {note}')

def family(name, tier, desc):
    fams[name]=desc;tiers[name]=tier

source=SOURCE.read_bytes();source_sha=hashlib.sha256(source).hexdigest()
assert len(CENSUS)==279 and source_sha=='3cd6ae8bb286536ef7bc871d359996309e53ac3a6aed89917a5a82c53b6dcb2a'

x,B=sp.symbols('R B',positive=True)
F=sp.Function('F')
E=lambda f: x*sp.diff(f,x)-f
T=lambda f: x**2/B*f.subs(x,B/x)
family('E3_EULER_','E3_SCOPED_EXACT','Theorem 202: exact reciprocal involution, anticommutation and paired-Hessian identity for general C2 function')
ok('E3_EULER_', sp.simplify(T(T(F(x)))-F(x))==0)
ok('E3_EULER_', sp.simplify(E(T(F(x)))+T(E(F(x))))==0)
T2=sp.diff(T(F(x)),x,2)
identity=(x**2*sp.diff(F(x),x,2)-B*T2.subs(x,B/x))/2
ok('E3_EULER_', sp.simplify(identity-E(F(x)))==0)
for t,expected in [(sp.Integer(1),x*x/B),(x,x),(x*x,B)]:
    ok('E3_EULER_', sp.simplify(T(t)-expected)==0)
for t,expected in [(sp.Integer(1),-sp.Integer(1)),(x,sp.Integer(0)),(x*x,x*x)]:
    ok('E3_EULER_', sp.simplify(E(t)-expected)==0)

family('E3_QUADRATIC_','E3_SCOPED_EXACT','Theorems 203/205/206 and 210: exact quadratic kernels and affine reconstruction')
a,b,c,U,C=sp.symbols('a b c U C',real=True)
f=a*x*x+b*x+c
ok('E3_QUADRATIC_',sp.simplify(E(f)-(a*x*x-c))==0)
ok('E3_QUADRATIC_',sp.simplify(T(f)-(a*B+b*x+c*x*x/B))==0)
ok('E3_QUADRATIC_',sp.simplify(sp.diff(f,x,2)-2*a)==0)
ok('E3_QUADRATIC_',sp.simplify(sp.diff(T(f),x,2)-2*c/B)==0)
ok('E3_QUADRATIC_',sp.simplify(E(-T(f)+2*b*x)-T(E(f)))==0)
ok('E3_QUADRATIC_',sp.simplify(((E(f)/x).subs(x,U)-(E(f)/x).subs(x,C))-(U-C)*(a+c/(C*U)))==0)

family('E3_CONTACT_','E3_SCOPED_EXACT','Propositions 207/209: contact/Legendre lifts and involution/form pullback on coordinate jets')
z,p,eps=sp.symbols('z p eps',real=True,nonzero=True)
y=sp.Symbol('y');h=sp.Function('h')
rprime=B/x;zprime=eps*B*z/x**2+h(B/x)
pprime=eps*(2*z/x-p)+sp.diff(h(y),y).subs(y,B/x)
# one-form pullback coefficients (dR,dz,dp)
for coord,expect in [(x,-eps*B*p/x**2),(z,eps*B/x**2),(p,sp.Integer(0))]:
    got=sp.diff(zprime,coord)-pprime*sp.diff(rprime,coord)
    ok('E3_CONTACT_',sp.simplify(got-expect)==0)
# Legendre exchange z'=p q - z+c has exact antiform
q,zz,pp,cc=sp.symbols('q zz pp cc',real=True)
zleg=pp*q-zz+cc
ok('E3_CONTACT_',sp.simplify(sp.diff(zleg,q)-pp)==0)
ok('E3_CONTACT_',sp.simplify(sp.diff(zleg,zz)+1)==0)
ok('E3_CONTACT_',sp.simplify(sp.diff(zleg,pp)-q)==0)

family('E3_LAURENT_','E3_SCOPED_EXACT','Theorems 211--213: reciprocal pairs, convex Hessian, endpoint cubic-window inequalities')
aa,bb=sp.symbols('aa bb',real=True)
fp=U*x+aa*(x*x-B)+bb*(x**3-B**2/x)
psi=3*x-B*B/x**3
ok('E3_LAURENT_',sp.simplify(sp.diff(fp,x,2)-2*(aa+bb*psi))==0)
ok('E3_LAURENT_',sp.simplify(psi.subs({x:C,B:U*C})-(-(U*U-3*C*C)/C))==0)
ok('E3_LAURENT_',sp.simplify(psi.subs({x:U,B:U*C})-((3*U*U-C*C)/U))==0)
for m in range(1,9):
    pair=x**(m+1)-B**m*x**(1-m)
    ok('E3_LAURENT_',sp.simplify(T(pair)+pair)==0)
    if m>1:
        ok('E3_LAURENT_',sp.diff(pair,x,2).expand().coeff(x,m-1)==m*(m+1))

family('E4_CONVEXITY_','E4_ADVERSARIAL_SCOPE','Attack the first higher-pair global-rigidity and finite-window boundary: finite valid nonzero cubic b cannot imply global positive Hessian')
for c0,u0 in [(sp.Integer(1),sp.Integer(2)),(sp.Rational(1,3),sp.Integer(1)),(sp.Integer(2),sp.Integer(5))]:
    lo=-u0/(3*u0*u0-c0*c0);hi=c0/(u0*u0-3*c0*c0)
    ok('E4_CONVEXITY_',lo<0<hi)
    b0=(lo+hi)/2
    g=2+2*b0*(3*x-(c0*u0)**2/x**3)
    ok('E4_CONVEXITY_',g.subs(x,c0)>0 and g.subs(x,u0)>0)
    # as x -> 0+, cubic partner dominates with opposite sign if b positive
    ok('E4_CONVEXITY_',sp.limit(g.subs(b0,sp.Rational(1,2)*hi),x,0,dir='+')==-sp.oo)

family('E3_GAUSSIAN_','E3_SCOPED_EXACT','221--227: positive Gaussian DtN matrix and exact stationary Schur-gluing law')
G,u,v=sp.symbols('G u v',positive=True)
def mat(t):return sp.Matrix([[1+t*t,-2*t],[-2*t,1+t*t]])*G/(1-t*t)
m1,m2=mat(u),mat(v)
cmm=m1[1,1]+m2[0,0]
glued=sp.Matrix([[m1[0,0]-m1[0,1]**2/cmm,-m1[0,1]*m2[0,1]/cmm],[-m1[0,1]*m2[0,1]/cmm,m2[1,1]-m2[0,1]**2/cmm]])
for i in range(2):
 for j in range(2):
    ok('E3_GAUSSIAN_',sp.factor(glued[i,j]-mat(u*v)[i,j])==0)
ok('E3_GAUSSIAN_',sp.factor(sp.det(mat(u))-G*G)==0)
KG=sp.factor(m1[0,0]-m1[0,1]**2/m1[1,1])
ok('E3_GAUSSIAN_',sp.factor(KG-G*(1-u*u)/(1+u*u))==0)
for rn in [Fraction(i,17) for i in range(0,17)]:
    r=sp.Rational(rn.numerator,rn.denominator)
    lo=G*(1-sp.sqrt(r))/(1+sp.sqrt(r))
    hi=G*(1+sp.sqrt(r))/(1-sp.sqrt(r))
    ok('E3_GAUSSIAN_',float(lo.subs(G,2))>0 and float(hi.subs(G,2))>0)

family('E4_GAUSSIAN_SCOPE_','E4_ADVERSARIAL_SCOPE','Test forbidden boundary: rho=1 is a singular zero-length collar not in source theorem')
ok('E4_GAUSSIAN_SCOPE_',sp.limit(mat(u)[0,0],u,1,dir='-')==sp.oo)

family('E3_600CELL_','E3_SCOPED_EXACT','268: exact Q(sqrt5) coordinate root count, 720 nearest edges, 600 tetrahedral cliques, degree 12')
def sign(p):
    inv=sum(p[i]>p[j] for i in range(len(p)) for j in range(i+1,len(p)))
    return (-1)**inv
roots=[]
zero=(0,0)
for ax in range(4):
 for sg in [-1,1]:
    r=[zero]*4;r[ax]=(4*sg,0);roots.append(tuple(r))
for sg in itertools.product([-1,1],repeat=4):
    roots.append(tuple((2*s,0) for s in sg))
base=(zero,(2,0),(1,1),(-1,1))
for perm in itertools.permutations(range(4)):
    if sign(perm)!=1:continue
    new=[base[i] for i in perm]
    nz=[i for i in range(4) if new[i]!=zero]
    for s in itertools.product([-1,1],repeat=3):
        r=list(new)
        for i,sg in zip(nz,s):r[i]=(r[i][0]*sg,r[i][1]*sg)
        roots.append(tuple(r))
assert len(roots)==120 and len(set(roots))==120

def prod(pair1,pair2):
    a,b=pair1;c,d=pair2;return (a*c+5*b*d,a*d+b*c)
def dot(a,b):
    res=[0,0]
    for i in range(4):
        t=prod(a[i],b[i]);res[0]+=t[0];res[1]+=t[1]
    return tuple(res) # denominator 16
for r in roots:ok('E3_600CELL_',dot(r,r)==(16,0))
adj=[set() for _ in roots]
for i in range(120):
    for j in range(i+1,120):
        if dot(roots[i],roots[j])==(4,4):
            adj[i].add(j);adj[j].add(i)
ok('E3_600CELL_',sum(map(len,adj))//2==720)
for nb in adj:ok('E3_600CELL_',len(nb)==12)
triangles=[]
for i in range(120):
 for j in sorted(j for j in adj[i] if j>i):
  for k in sorted(k for k in adj[i]&adj[j] if k>j):triangles.append((i,j,k))
facets=[]
for i,j,k in triangles:
 for l in sorted(h for h in adj[i]&adj[j]&adj[k] if h>k):facets.append((i,j,k,l))
ok('E3_600CELL_',len(facets)==600)
for facet in facets:
    ok('E3_600CELL_',all(j in adj[i] for i,j in itertools.combinations(facet,2)))

family('E3_2T_QUADRATURE_','E3_SCOPED_EXACT','251: rational quadratic-weight sixth-degree Hurwitz 2T sampling discrepancy 1/48')
hurwitz=roots[:24]
def val(r):return tuple(sp.Rational(a,4)+sp.Rational(b,4)*sp.sqrt(5) for a,b in r)
avg=sp.simplify(sum((val(r)[0]**2)*(val(r)[0]**2-val(r)[1]**2)**2 for r in hurwitz)/24)
roundavg=sp.Rational(1,16)
ok('E3_2T_QUADRATURE_',avg==sp.Rational(1,12))
ok('E3_2T_QUADRATURE_',avg-roundavg==sp.Rational(1,48))

family('E3_PETERSEN_','E3_SCOPED_EXACT','249--250: A5 transitive action on 15 Petersen edges, order 60 and stabilizer 4; no oriented 105 identification')
subsets=list(itertools.combinations(range(5),2))
edges={frozenset((a,b)) for a,b in itertools.combinations(subsets,2) if not(set(a)&set(b))}
ok('E3_PETERSEN_',len(subsets)==10 and len(edges)==15)
perms=[p for p in itertools.permutations(range(5)) if sign(p)==1]
ok('E3_PETERSEN_',len(perms)==60)
target=next(iter(edges));orbit=set()
for perm in perms:
    tr=frozenset(tuple(sorted(perm[i] for i in pair)) for pair in target)
    ok('E3_PETERSEN_',tr in edges)
    orbit.add(tr)
ok('E3_PETERSEN_',len(orbit)==15)
ok('E3_PETERSEN_',sum(frozenset(tuple(sorted(p[i] for i in pair)) for pair in target)==target for p in perms)==4)

family('E3_F40_POLYNOMIAL_','E3_SCOPED_EXACT','262: exact F40 frame factor/minimal polynomial and inverse in quotient algebra (not certification of actual frame spectrum)')
y=sp.symbols('y')
minpoly=(y-1)*(y*y-12*y+31)*(y*y-8*y+6)
expected=y**5-21*y**4+153*y**3-453*y**2+506*y-186
ok('E3_F40_POLYNOMIAL_',sp.expand(minpoly-expected)==0)
inv=(y**4-21*y**3+153*y*y-453*y+506)/186
ok('E3_F40_POLYNOMIAL_',sp.rem(y*inv-1,minpoly,y)==0)
for f in [y-1,y*y-12*y+31,y*y-8*y+6]:
    ok('E3_F40_POLYNOMIAL_',sp.polys.polytools.discriminant(f,y)>0 if sp.degree(f,y)>1 else True)

family('E3_FISCHER_','E3_SCOPED_EXACT','264--265: surjectivity and spinor-kernel dimension from explicit Pauli-Dirac polynomials for n<=4')
I=sp.I
paulis=[sp.Matrix([[0,1],[1,0]]),sp.Matrix([[0,-I],[I,0]]),sp.Matrix([[1,0],[0,-1]])]
def mons(n):return [(a,b,n-a-b) for a in range(n,-1,-1) for b in range(n-a,-1,-1)]
for n in range(1,5):
 cols=mons(n);rows=mons(n-1);rix={v:i for i,v in enumerate(rows)}
 M=sp.zeros(2*len(rows),2*len(cols))
 for k,pows in enumerate(cols):
  for spin in range(2):
   for coord,pw in enumerate(pows):
    if pw==0:continue
    tgt=tuple(v-1 if i==coord else v for i,v in enumerate(pows))
    ri=rix[tgt]
    for rs in range(2):M[2*ri+rs,2*k+spin]+=pw*paulis[coord][rs,spin]
 rank=M.rank()
 ok('E3_FISCHER_',rank==M.rows)
 ok('E3_FISCHER_',M.cols-rank==2*n+2)

family('E2_IC19_PARITY_','E2_FINITE_CORROBORATION','275/277/278: exact mod-two first-stage affine action and parity-invariant aggregated extension count under top-bit switching')
# This checks finite algebra only; Postnikov geometric identification is guarded by source.
for n in range(2):
 for vx,vp,r,s in itertools.product(range(2),repeat=4):
  for A,B0,C0,D0 in itertools.product(range(2),repeat=4):
   first=(n*vx+r*C0-s*A)%2
   second=(n*vp+r*D0-s*B0)%2
   ok('E2_IC19_PARITY_',first in (0,1) and second in (0,1))
# Each lower-stage configuration paired by the top bit has 1 extendible class,
# independent of the initial obstruction parity. This does not fix h_t,w_t.
for obstruction in (0,1):
    values=[obstruction^t for t in (0,1)]
    ok('E2_IC19_PARITY_',sorted(values)==[0,1])

out={
 'source_file':SOURCE.name,'source_sha256':source_sha,'batch':'Paper1D-201-279',
 'audit_scoping':'Finite/exact independent and explicit boundary attacks only. No global bundle, E8 comparison, complete F40 construction, or physical realization is certified by these controls.',
 'passed':not fail,'total_scoped_assertions':sum(counts.values()),'named_families':len(counts),
 'checks_by_family':dict(counts),'descriptions':fams,'evidence_tier_by_family':tiers,
 'tier_counts':dict(collections.Counter(tiers.values())),'failures':fail,
 '600cell':{'vertices':120,'edges':720,'tetrahedral_facets':600,'vertex_degree':12},
 'exact_hurwitz_quadrature':{'finite_mean':'1/12','round_mean':'1/16','difference':'1/48'},
 'f40_minimal_polynomial':str(sp.expand(minpoly)),
 'negative_control_note':'Rho=1 fails stated domain; global convexity does not follow from finite-interval positivity. These attacks are out-of-domain and DO NOT refute the source results.',
 'missing_original_certificate_note':'The checks do not reproduce the source-specific v366 chamber transporter/projector matrices or v370 full E8 sheet and 1840 triple certificate.'
}
fp=ROOT/'Paper1D-Batch5IndependentControls-v1_1.json'
fp.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print('SAVED',fp,'passed',out['passed'],'assertions',out['total_scoped_assertions'],'families',len(counts),'600cell',out['600cell'])
