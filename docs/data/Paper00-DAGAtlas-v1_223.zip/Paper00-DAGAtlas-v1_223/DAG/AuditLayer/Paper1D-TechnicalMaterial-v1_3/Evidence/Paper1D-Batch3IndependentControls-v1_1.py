#!/usr/bin/env python3
"""Born–Hopf Paper I-D, Batch 3 (formal objects 118–151): independent scoped checks.

These are exact finite/algebraic identities and numerical counterchecks with tolerances;
NOT independently certified global homotopy, bundle existence, top-bit determination,
or the absent NZ.4 outward-rounded interval Hessian certificate.
"""
from pathlib import Path
from collections import defaultdict
import json, hashlib, math
import numpy as np
import sympy as sp

WORK=Path(__file__).resolve().parent
SOURCE_NAME='Paper1D-TechnicalMaterial-v1_67.tex'
# Supports rerunning beside the source, beside the original supplied minimal ZIP,
# or in the provided /mnt/data audit working directory (without editing source).
source_candidates=[WORK/SOURCE_NAME, WORK/'audit_paper1d_work'/SOURCE_NAME]
source_path=next((f for f in source_candidates if f.is_file()),None)
if source_path is not None:
    source_bytes=source_path.read_bytes()
else:
    from zipfile import ZipFile
    archives=sorted(WORK.glob('Paper00-PapersMinimal-v3_018*.zip'))
    if not archives:
        raise FileNotFoundError('Place the source .tex or Paper00-PapersMinimal-v3_018.zip beside this verification script.')
    with ZipFile(archives[0]) as archive:
        source_members=[n for n in archive.namelist() if n==SOURCE_NAME or n.endswith('/'+SOURCE_NAME)]
        if len(source_members)!=1:raise RuntimeError('Could not uniquely locate the exact target source in the paper archive.')
        source_bytes=archive.read(source_members[0])
SHA=hashlib.sha256(source_bytes).hexdigest()
assert SHA=='3cd6ae8bb286536ef7bc871d359996309e53ac3a6aed89917a5a82c53b6dcb2a'
rng=np.random.default_rng(2026111603)
count=defaultdict(int)
maxerr=defaultdict(float)
notes=[]

def ck(ok, fam, detail=''):
    if not bool(ok):raise AssertionError(f'{fam}: {detail}')
    count[fam]+=1

def cl(a,b,fam,tol=2.e-10):
    er=float(np.max(np.abs(np.asarray(a)-np.asarray(b))))
    maxerr[fam]=max(maxerr[fam],er)
    ck(er<=tol,fam,er)

def nq(q):return np.asarray(q,dtype=float)/np.linalg.norm(q)
def rq():return nq(rng.normal(size=4))
def qmul(a,b):
    a=np.asarray(a,dtype=float);b=np.asarray(b,dtype=float)
    return np.r_[a[0]*b[0]-np.dot(a[1:],b[1:]),a[0]*b[1:]+b[0]*a[1:]+np.cross(a[1:],b[1:])]
def qinv(a):return np.r_[a[0],-a[1:]]/np.dot(a,a)
def qexp(v):
    v=np.asarray(v,dtype=float);r=np.linalg.norm(v)
    return np.r_[np.cos(r), (np.sin(r)/r if r>1e-14 else 1)*v]
def qpow(a,t):
    a=nq(a);r=np.linalg.norm(a[1:]);ang=math.atan2(r,a[0])
    if r<1e-13:
        if a[0]<0:return np.r_[math.cos(math.pi*t),math.sin(math.pi*t),0.,0.]
        return np.r_[1.,0.,0.,0.]
    return np.r_[math.cos(t*ang),math.sin(t*ang)*a[1:]/r]
def qconj(a,b):return qmul(qmul(a,b),qinv(a))
def qcomm(a,b):return qmul(qconj(a,b),qinv(b))
def qF(theta,A,B):
    if theta<=math.pi:
        u=theta/math.pi
        return qmul(qmul(qpow(A,-u),qmul(A,B)),qpow(A,u))
    u=theta/math.pi-1
    return qmul(qmul(qpow(B,-u),qmul(B,A)),qpow(B,u))
def L(s,A,X):
    B=qconj(qinv(X),A)
    return qmul(qF((math.pi/2+s)%(2*math.pi),A,B),qinv(qF(math.pi/2,A,B)))

def unitvec3():
    x=rng.normal(size=3);return x/np.linalg.norm(x)

def nclocus(s,phi,d,t,u,w):
    # NC.36, for arbitrary oriented imaginary pair (u,w).
    X=np.r_[math.sqrt((1+d)/2)*math.cos(t),math.sqrt((1+d)/2)*math.sin(t)*u + math.sqrt((1-d)/2)*w]
    A=np.r_[math.cos(phi),math.sin(phi)*u]
    wp=math.sin(t)*w+math.cos(t)*np.cross(u,w)
    return A,X,np.column_stack((u,wp,np.cross(u,wp)))

# NC.33–37: entire printed branch, not a one-point numerical diagnostic.
Mexp=np.array([[8/9,4/3,-math.sqrt(3)/2],
               [4*math.sqrt(2)/9,-4*math.sqrt(2)/3,math.sqrt(6)/2],
               [0,2*math.sqrt(6)/3,3*math.sqrt(2)/2]])
for it in range(140):
    u=unitvec3();w=unitvec3();w-=u*np.dot(u,w);w/=np.linalg.norm(w)
    t=float(rng.uniform(0,2*math.pi))
    A,X,R=nclocus(math.pi,2*math.pi/3,1/3,t,u,w)
    cl(L(math.pi,A,X),np.array([-1.,0.,0.,0.]),'NC34_full_branch_value',5e-11)
    cl(L(math.pi,A,-X),L(math.pi,A,X),'NC33_projective_sign_invariance',5e-11)
    cl(qconj(qinv(X),np.r_[0.,u])[1:]@u,1/3,'NC34_conjugacy_dot',1e-11)
    # Derivative in global normal coordinates, including rotating output frame.
    base=np.array([math.pi,2*math.pi/3,1/3])
    h=2e-6
    J=np.zeros((3,3))
    for k in range(3):
        lo=base.copy();hi=base.copy();lo[k]-=h;hi[k]+=h
        Aa,Xa,_=nclocus(*lo,t,u,w)
        Ab,Xb,_=nclocus(*hi,t,u,w)
        J[:,k]=(L(*[hi[0],Ab,Xb])[1:]-L(*[lo[0],Aa,Xa])[1:])/(2*h)
    cl(R.T@J,Mexp,'NC37_entire_branch_normal_matrix',2e-8)
    cl(np.linalg.det(J),-8,'NC37_branch_normal_determinant',4e-8)
    ck(abs(np.linalg.det(J))>7.99,'E4_NC37_global_normal_regular')

# NC.25 pair-chart reconstructs exactly the inner normal coordinates within its domain.
for it in range(240):
    y=rq();u=unitvec3();alpha=float(rng.uniform(0.02,1.3))
    x=qmul(y,qexp(alpha*u));p=qmul(y,qexp(-alpha*u))
    pp=qmul(qinv(p),x)
    th=math.atan2(np.linalg.norm(pp[1:]),pp[0]);uh=pp[1:]/np.linalg.norm(pp[1:])
    yy=qmul(x,qexp(-th*uh/2))
    cl(yy,y,'NC25_actual_pair_inverse_y',1e-11)
    cl(th,2*alpha,'NC25_actual_pair_inverse_theta',1e-11)
    cl(uh,u,'NC25_actual_pair_inverse_axis',1e-11)
    ck(th<math.pi,'NC25_excludes_antipodal_pairs')

# RT.62 cap and NC.41 exact inverse on the noncentral cap values.
delta=1/12
def qcap(v):
    r2=float(np.dot(v,v))
    if r2>=delta**2:return np.array([1.,0.,0.,0.])
    g=delta**2-r2
    return np.r_[(r2-g*g)/(r2+g*g),-2*g*v/(r2+g*g)]
def capinverse(Q):
    r=float(np.linalg.norm(Q[1:]))
    if r<1e-14:
        if Q[0]<0:return np.zeros(3)
        raise ValueError('based pole Q=+1 outside finite inverse chart')
    k=r/(1-Q[0]);rr=2*k*delta**2/(1+math.sqrt(1+4*k*k*delta**2))
    return -rr*Q[1:]/r
for it in range(250):
    v=delta*float(rng.uniform(0.01,0.99))*unitvec3();Q=qcap(v)
    cl(capinverse(Q),v,'NC41_actual_cap_inverse',1e-11)
    cl(qcap(capinverse(Q)),Q,'NC41_cap_forward_inverse',1e-11)
    cl(np.linalg.norm(Q),1,'RT62_cap_norm_for_B3',1e-11)
cl(qcap(capinverse(np.r_[-1.,0.,0.,0.])),np.r_[-1.,0.,0.,0.],'NC41_scalar_minus_one_branch',1e-12)

# NC.19–21, NC.28: exact noncommutative splitting/reduction, plus adversarial guard.
# SU2 2x2 embedding for unit quaternion, conventional Hamilton representation.
def su(q):
    q0,q1,q2,q3=q
    return np.array([[q0+1j*q1,q2+1j*q3],[-q2+1j*q3,q0-1j*q1]],complex)
def minu(U):return U.conj().T
counter_mutation=0
for it in range(300):
    f=su(rq());Q=su(rq());a=np.exp(1j*rng.uniform(-math.pi,math.pi))
    Da=np.diag([1.,a]);D0=np.diag([1.,1j]);
    fs=Da@f@minu(Da);f0=D0@f@minu(D0)
    Q2=Q@Q
    Cs=minu(fs)@Q2@fs@minu(Q2)
    C0=minu(f0)@Q2@f0@minu(Q2)
    red=Cs@minu(C0)
    chi=fs@minu(f0)
    rhs=minu(f0)@minu(chi)@Q2@chi@minu(Q2)@f0
    cl(red,rhs,'NC28_conjugation_entire_word',3e-12)
    # NC.19–20 identity for arbitrary actual R(s),G(s) first, then support-wise product.
    Gs=su(rq());Gbase=su(rq());Rs=su(rq());Rbase=su(rq())
    Phi=Gs@minu(Gbase)
    CRs=minu(Rs)@Gs@Rs@minu(Gs)
    CRbase=minu(Rbase)@Gbase@Rbase@minu(Gbase)
    PhiS=minu(Rs)@Gs@Rs@minu(minu(Rbase)@Gbase@Rbase)
    cl(PhiS,CRs@Phi@minu(CRbase),'NC20_general_conjugation_split',2e-12)
    if it%2==0:
        Gs=Gbase # clutch support: no circle-dependent part
    else:
        Rs=np.eye(2);Rbase=np.eye(2) # sphere support: no clutch
    Phi=Gs@minu(Gbase)
    CRs=minu(Rs)@Gs@Rs@minu(Gs)
    CRbase=minu(Rbase)@Gbase@Rbase@minu(Gbase)
    Psi=CRs@minu(CRbase)
    PhiS=minu(Rs)@Gs@Rs@minu(minu(Rbase)@Gbase@Rbase)
    cl(PhiS,Phi@Psi,'NC20_disjoint_support_matrix_identity',2e-12)
    mutant=minu(f0)@minu(chi)@Q2@chi@minu(Q2) # deliberately omit terminal f0
    if np.max(np.abs(mutant-rhs))>1e-5:counter_mutation+=1
ck(counter_mutation>290,'E4_NC28_omitted_frame_factor_is_invalid')

# ND.4 exact extremum of normal-chart singular denominator.
t=sp.symbols('t', real=True)
ff=8*t*(1-t)/(3+t)**2
ck(sp.simplify(sp.diff(ff,t).subs(t,sp.Rational(3,7)))==0,'ND4_stationary_t_3_over_7')
ck(sp.simplify(ff.subs(t,sp.Rational(3,7)))==sp.Rational(1,6),'ND4_maximum_exact_1_over_6')
ck(sp.simplify(sp.diff(ff,t)-8*(3-7*t)/(3+t)**3)==0,'ND4_rational_derivative_exact')
for it in range(1500):
    a=float(rng.random());val=float(ff.subs(t,a))
    ck(val<=1/6+1e-13,'ND4_range_global_sample')
    ck(1-val>=5/6-1e-13,'ND4_joining_line_lower_bound')

# NT.9 and NT.4 actual geometric cutoffs (distance estimates only).
val=2*math.sqrt(2)*math.atan(1/(32-1/math.sqrt(2)))
ck(val<1/6,'NT9_shifted_singular_circle_inside_ball')
ck(32-1/math.sqrt(2)>31,'NT9_no_spurious_intersection_with_joining')

# SU3 determinant-one closing block from projection decomposition.
I=np.eye(3,dtype=complex)
Jx=np.diag([1.,1.,-1.])
e2=np.array([0.,1.,0.],complex)
def exosection(x,p):
    ax=1-x[0];ap=1-p[0];k=2*ax+2*ap-ax*ap
    if k<1e-15:return np.array([1.,0.,0.],complex)
    u0=1-2*ax*ap/k
    ux=2*ap*x[1:]/k;up=2*ax*p[1:]/k
    ua=(ux+up)/math.sqrt(2);ub=(ux-up)/math.sqrt(2)
    z0=u0+1j*ub[1];z1=ua[2]+1j*ub[2];rr=math.hypot(abs(z0),abs(z1))
    h=(2*(z0*np.conj(z1)).real/rr,2*(z0*np.conj(z1)).imag/rr,(abs(z0)**2-abs(z1)**2)/rr) if rr>1e-13 else (0,0,0)
    return np.array([h[2]+1j*h[0],ua[0]+1j*ua[1],ub[0]+1j*h[1]])
for it in range(300):
    x=rq();p=rq();s=exosection(x,p)
    cl(np.vdot(s,s),1,'ND1_actual_section_unit',1e-10)
    Ps=I-np.outer(s,np.conj(s));v=Ps@e2
    if np.linalg.norm(v)<0.001:continue
    ell=np.outer(v,np.conj(v))/np.vdot(v,v)
    ss=np.outer(s,np.conj(s))
    K=ss+np.cos(math.pi*.37)*Ps+1j*np.sin(math.pi*.37)*(2*ell-Ps)
    cl(K.conj().T@K,I,'ND1_projected_K_plus_unitary',1e-9)
    cl(np.linalg.det(K),1,'ND1_K_plus_SU3',1e-9)
    cl(K@s,s,'ND1_stabilizing_column_fixed',1e-9)
    cl(ss+np.cos(math.pi)*Ps+1j*np.sin(math.pi)*(2*ell-Ps),ss-Ps,'ND1_endpoint_N',1e-10)
    a=np.exp(1j*rng.uniform(-math.pi,math.pi))
    D=ss+(a*a)*ell+(Ps-ell)
    cl(np.linalg.det(D),a*a,'ND2_det_a_squared',1e-9)
    cl(exosection(p,x),Jx@s,'ND2_exchange_section',1e-9)
    T=Jx@D@Jx
    spx=exosection(p,x);Pp=I-np.outer(spx,np.conj(spx));vp=Pp@e2
    ellp=np.outer(vp,np.conj(vp))/np.vdot(vp,vp)
    Dexchange=np.outer(spx,np.conj(spx))+(a*a)*ellp+Pp-ellp
    cl(T,Dexchange,'ND2_exchange_deck_matrix',1e-9)

# NU.1–4, side/top/bottom and uniform central bound in the cylinder construction.
for it in range(260):
    g=su(rq());tval=float(rng.random());r=float(rng.random())
    A=lambda tt:np.diag([np.exp(1j*math.pi*tt),np.exp(-1j*math.pi*tt)])
    Sg=lambda tt:g@A(tt)@minu(g)@minu(A(tt))
    cl(Sg(0),np.eye(2),'NU1_commutator_bottom_identity',1e-11)
    cl(Sg(1),np.eye(2),'NU1_commutator_top_identity',1e-11)
    cl(Sg(tval)@A(tval),g@A(tval)@minu(g),'NU2_side_seam_exact',1e-11)
    ck(np.linalg.norm(Sg(tval)-np.eye(2),2)<=2*math.pi*(1-tval)+1e-12,'NU4_uniform_central_upper_bound')
    G0=Sg(1-(1-tval)*r)
    cl(G0 if r>1e-12 else np.eye(2),Sg(1-(1-tval)*r),'NU3_radial_background_identity',1e-11)
    ck(np.linalg.norm(G0-np.eye(2),2)<=2*math.pi*(1-tval)*r+1e-12,'NU4_center_continuity_bound')
    cl(Sg(1-(1-tval)*1),Sg(tval),'NU3_side_match',1e-11)

# NU.6–8 normalized quaternionic bottom deformation: explicit endpoints.
for it in range(260):
    a=rq();b=rq()
    m=-b;vnorm=np.linalg.norm(m[1:]);ang=math.atan2(vnorm,m[0]);pd=ang/math.pi*m[1:]/vnorm
    ud=math.sqrt(max(0,1-np.dot(pd,pd)))*a
    Rreal=ud[0];Rmag=math.sqrt(1-Rreal*Rreal)
    def fl(lam):
        Rlam=min(1.,Rreal+lam*(1+Rreal))
        ratio=math.sqrt(max(0,1-Rlam*Rlam))/Rmag
        return ratio*pd, np.r_[Rlam,ratio*ud[1:]]
    p0,u0=fl(0);p1,u1=fl(1)
    cl(p0,pd,'NU6_start_disc_p',1e-10)
    cl(u0,ud,'NU6_start_disc_u',1e-10)
    cl(np.dot(p1,p1)+np.dot(u1,u1),1,'NU6_endpoint_six_sphere',1e-10)
    if Rreal>=0: ck(np.linalg.norm(u1[1:])<1e-10,'NU6_positive_disk_terminal_direction_collapse')
    for lam in (0.,.25,.5,.75,1.):
        pp,uu=fl(lam)
        cl(np.dot(pp,pp)+np.dot(uu,uu),1,'NU6_S6_norm_all_stages',1e-10)
    aD=ud/np.linalg.norm(ud)
    def Dfun():return qconj(aD,qexp(math.pi*pd))
    def Tfun(lam):
        return qmul(qmul(Dfun(),qexp(-(1-lam)*math.pi*pd+lam*math.pi*np.array([1.,0.,0.]))),qexp(-lam*math.pi*np.array([1.,0.,0.])))
    cl(Tfun(0),qcomm(aD,-qexp(math.pi*pd)),'NU7_T0_commutator',2e-10)
    cl(Tfun(1),Dfun(),'NU7_T1_Duran_map',2e-10)
    cl(np.linalg.norm(Dfun()),1,'NU7_D_unit',1e-11)

# NY.2 and NY.8–10: exact quaternionic frame/factor geometry.
iunit=np.array([0.,1.,0.,0.]);junit=np.array([0.,0.,1.,0.]);kunit=np.array([0.,0.,0.,1.])
for it in range(400):
    vv=nq(rng.normal(size=3));a,b,L=vv
    q=rq();e1=qconj(q,iunit)[1:];e2=qconj(q,junit)[1:]
    c=2*a*a-1;d=2*a*b;r=2*abs(a)*L
    theta=(math.pi*float(rng.random())) if a<0 else 0
    gamma=np.r_[c,d,r*(math.cos(theta)*e1+math.sin(theta)*e2)]
    dd=np.r_[d,-c,r*(-math.sin(theta)*e1+math.cos(theta)*e2)]
    cl(np.dot(gamma,gamma),1,'NY2_gamma_unit',2e-11)
    cl(np.dot(dd,dd),1,'NY2_delta_unit',2e-11)
    cl(np.dot(gamma,dd),0,'NY2_frame_orthogonal',2e-11)
    RR=math.hypot(a,b)
    if RR<1e-9:continue
    axis=(-b*iunit+a*junit)/RR
    cl(np.dot(axis[1:],kunit[1:]),0,'NY8_orthogonal_rotation_axes',1e-12)
    k0=np.r_[2*L*L-1,2*L*qconj(q,(-b*iunit+a*junit))[1:]]
    cl(np.linalg.norm(k0),1,'NY8_factor_k_unit',1e-11)
    for th in (0,math.pi/6,math.pi/3,math.pi/2):
        dd1=math.cos(th)*axis+math.sin(th)*kunit
        k= np.r_[2*L*L-1,2*L*RR*qconj(q,dd1)[1:]]
        cl(np.linalg.norm(k),1,'NY8_factor_rotation_unit',1e-10)
    for lam in (0,.25,.5,.75,1.):
        LL=(1-lam)*L
        kk=np.r_[2*LL*LL-1,2*LL*math.sqrt(1-LL*LL)*qconj(q,kunit)[1:]]
        cl(np.linalg.norm(kk),1,'NY9_radial_contraction_unit',1e-10)
        if lam==1:cl(kk,np.r_[-1.,0.,0.,0.],'NY9_terminal_minus_one',1e-10)


# NY.3 quaternionic 2x2 matrix unitary identity, checked without complex reduction.
for it in range(400):
    z=nq(rng.normal(size=8));r0=z[:4];U=z[4:]
    if r0[0]<0:r0=-r0
    one=np.r_[1.,0.,0.,0.]
    # Write bars and denominators literally, retaining multiplication order.
    conjr=np.r_[r0[0],-r0[1:]];conjU=np.r_[U[0],-U[1:]]
    upper=-qmul(qmul(one+r0,qinv(one+conjr)),conjU)
    lower=one-qmul(qmul(U,qinv(one+conjr)),conjU)
    dot=qmul(conjr,upper)+qmul(conjU,lower)
    cl(dot,np.zeros(4),'NY3_quaternionic_columns_perpendicular',3e-11)
    cl(np.dot(upper,upper)+np.dot(lower,lower),1,'NY3_quaternionic_second_column_norm',3e-11)
    cl(np.dot(r0,r0)+np.dot(U,U),1,'NY3_quaternionic_first_column_norm',3e-11)
    ck(1+r0[0]>=1,'NY3_chart_realpart_nonnegative')

# NZ.2–3 actual inverse source's first derivative and sampled Hessian bounds.
AA=np.zeros((6,6))
# A(zx,zp)=(-zp1,-zp3,zp2,zx1,zx2,-zx3)
AA[0,3]=-1;AA[1,5]=-1;AA[2,4]=1
AA[3,0]=1;AA[4,1]=1;AA[5,2]=-1
Eexpected=AA.T@np.diag([math.pi*delta*delta/(2*math.sqrt(2))]*3+[delta*delta/(2*math.sqrt(2))]*3)

def e_mu_inverse(y):
    th=float(np.linalg.norm(y));v=(math.sin(th)/th if th>1e-12 else 1-th*th/6)*y
    cc=math.cos(th/2);alpha=math.sqrt(1+cc*cc)/(2*cc)
    pd=alpha*np.array([-v[0],-v[2],v[1]])
    ud=np.r_[-cc*cc,alpha*np.array([-v[3],-v[4],v[5]])]
    qa=ud/math.sqrt(1-np.dot(pd,pd));qb=-qexp(math.pi*pd)
    qb=np.r_[qb[0],qb[1],-qb[2],-qb[3]]
    def capv(q):
        xx=-q[1:]/(1-q[0]);return 2*delta*delta*xx/(1+math.sqrt(1+4*delta*delta*np.dot(xx,xx)))
    return np.r_[capv(qa),capv(qb)]

cl(e_mu_inverse(np.zeros(6)),np.zeros(6),'NZ2_source_inverse_north_center',1e-13)
step=2e-6
Der=np.column_stack([(e_mu_inverse(step*np.eye(6)[i])-e_mu_inverse(-step*np.eye(6)[i]))/(2*step) for i in range(6)])
cl(Der,Eexpected,'NZ3_source_inverse_derivative',2e-8)
for it in range(40):
    y=rng.uniform(-1/128,1/128,size=6)
    ey=e_mu_inverse(y)
    ck(np.linalg.norm(ey)<1/6,'NZ2_inverse_box_image_in_ball_sample')
    hh=2e-4;eye=np.eye(6)
    H=np.zeros((6,6,6))
    for j in range(6):
        for k in range(6):
            H[:,j,k]=(e_mu_inverse(y+hh*eye[j]+hh*eye[k])-e_mu_inverse(y+hh*eye[j]-hh*eye[k])
                      -e_mu_inverse(y-hh*eye[j]+hh*eye[k])+e_mu_inverse(y-hh*eye[j]-hh*eye[k]))/(4*hh*hh)
    # This is a finite difference control, not the missing directed-rounded all-box certificate.
    ck(np.linalg.norm(H)<1/32,'NZ4_e_mu_sampled_Hessian_below_claimed_bound')

# NZ.14: connection generator trace/skew and exactly transported column.
for it in range(500):
    s=rng.normal(size=3)+1j*rng.normal(size=3);s/=np.linalg.norm(s)
    v=rng.normal(size=3)+1j*rng.normal(size=3)
    # unit-vector tangent, allowing a nontrivial imaginary phase component
    v=v-s*np.real(np.vdot(s,v))
    theta=np.vdot(s,v)
    AA=np.outer(v,np.conj(s))-np.outer(s,np.conj(v))-(theta/2)*(I+np.outer(s,np.conj(s)))
    cl(AA.conj().T,-AA,'NZ14_su3_skew',2e-10)
    cl(np.trace(AA),0,'NZ14_trace_zero',2e-10)
    cl(AA@s,v,'NZ14_connection_column_speed',2e-10)

# NZ.5 target compression: the two piece definitions join with zero slope at epsilon.
eps=2**-12
chi=lambda th:math.pi/2*(3*th/eps-(th/eps)**3) if th<=eps else math.pi
ck(abs(chi(eps)-math.pi)<1e-14,'NZ5_compression_seam_value')
ck(abs((3-3*(eps/eps)**2)*math.pi/(2*eps))<1e-14,'NZ5_compression_seam_slope')
for it in range(150):
    v=float(rng.uniform(0,eps))
    ck(0<=chi(v)<=math.pi,'NZ5_target_angle_in_range')

# Independent exact symbolic subclauses (E3 scoped): NC.38–40, NC.37 and NE.11.
# These algebraic consequences take the printed comparison equations as premises.
cc=sp.symbols('c', real=True)
dd=cc**2/(1-cc**2)
NCcond=sp.together(cc*(1+dd)+1-dd)
ck(sp.simplify(NCcond-(2*cc+1)/(cc+1))==0,'NC40_exact_scalar_reduction')
ck(sp.solve(sp.together(NCcond),cc)==[sp.Rational(-1,2)],'NC40_nontrivial_scalar_unique')
ck(sp.simplify(dd.subs(cc,sp.Rational(-1,2)))==sp.Rational(1,3),'NC38_40_unique_d_one_third')
Ms=sp.Matrix([[sp.Rational(8,9),sp.Rational(4,3),-sp.sqrt(3)/2],
               [4*sp.sqrt(2)/9,-4*sp.sqrt(2)/3,sp.sqrt(6)/2],
               [0,2*sp.sqrt(6)/3,3*sp.sqrt(2)/2]])
ck(sp.simplify(Ms.det())==-8,'NC37_full_matrix_exact_determinant')
zeta,chi=sp.symbols('zeta chi',real=True)
mob=(zeta-chi)/(1-chi*zeta)
inverse=(zeta+chi)/(1+chi*zeta)
ck(sp.simplify(mob.subs(zeta,inverse)-zeta)==0,'NE11_exact_mobius_inverse')
ck(sp.simplify(sp.diff(mob,zeta)-(1-chi**2)/(1-chi*zeta)**2)==0,'NE11_exact_mobius_positive_derivative')
ck(sp.simplify(mob.subs(zeta,1))==1 and sp.simplify(mob.subs(zeta,-1))==-1,'NE11_exact_polar_fixed_points')
k,nn=sp.symbols('k nn',integer=True)
ck(sp.Mod(2*nn+1+6*k,2)==1,'NE16_splitting_parity_is_invariant')

# E4 guard: nontrivial difference between stable and unstable and incomplete certificates.
notes.extend([
  'NC37 finite differences reproduce complete displayed normal matrix at 140 globally distributed SO(3) configurations; finite sampling does not prove uniqueness of the -1 locus.',
  'NY and NZ finite frame/connection controls do not independently replay the full Sp(2)/Spin(7)/G2 triality transport or its global based source homotopies.',
  'NZ.4 50-decimal directed-rounded full 36-entry Hessian certificate is absent; no interval checker or interval output was reproduced.',
  'NE.8 full Pontryagin framed complement and NE.15 source-top coefficient are not certified by arithmetic or finite samples alone.',
  'Implicit SU(2)->SU(3) block embeddings in OA.1/OA.2 are a source notation issue; preserve the stated embedded interpretation until type review.'
])
result={'target':'Paper1D-TechnicalMaterial-v1_67.tex','source_sha256':SHA,'batch':3,'formal_object_orders':[118,151],
 'passed':True,'total_scoped_assertions':sum(count.values()),'named_families':len(count),
 'checks_by_family':dict(sorted(count.items())),'max_absolute_error_by_family':dict(sorted(maxerr.items())),
 'evidence_tier':'E2_SAMPLED plus E3_EXACT_SUBCLAUSES plus E4_GUARDED','limitations':notes}
out=WORK/'Paper1D-Batch3IndependentControls-v1_1.json'
out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'passed':True,'total':result['total_scoped_assertions'],'families':len(count),'largest_deviation':max(maxerr.values()),'file':str(out)},indent=2))
