#!/usr/bin/env python3
"""Source-scoped independent controls Paper I-D statements #152-200.

Finitary equalities are exact only where marked E3. Sampled checks are E2;
E4 are attacks on strengthening/missing factors, not refutations of source.
No input source or archive is modified.
"""
from pathlib import Path
from zipfile import ZipFile
import hashlib, json, itertools, math, collections
import numpy as np
import sympy as sp
R=Path(__file__).resolve().parent
SRC_NAME='Paper1D-TechnicalMaterial-v1_67.tex'
# Reproduce when downloaded either beside the extracted TeX or beside the
# authoritative Paper00-PapersMinimal source archive, without modifying it.
source_locations=[R/SRC_NAME,R/'audit_paper1d_work'/SRC_NAME]
src=next((p.read_bytes() for p in source_locations if p.is_file()),None)
if src is None:
    archives=sorted(R.glob('Paper00-PapersMinimal-v*.zip'),reverse=True)
    for archive in archives:
        with ZipFile(archive) as z:
            filenames=[n for n in z.namelist() if n.endswith('/'+SRC_NAME) or n==SRC_NAME]
            if filenames:
                src=z.read(filenames[0]);break
if src is None:
    raise FileNotFoundError('Supply '+SRC_NAME+' or a Paper00-PapersMinimal-v*.zip alongside this verifier')
sha=hashlib.sha256(src).hexdigest()
assert sha=='3cd6ae8bb286536ef7bc871d359996309e53ac3a6aed89917a5a82c53b6dcb2a'
rng=np.random.default_rng(2026111604)
checks=collections.Counter(); labels={}
def ck(fam, expr, tier='E2'):
    if not bool(expr): raise AssertionError((fam,checks[fam]))
    checks[fam]+=1; labels[fam]=tier

def unitary_su2():
    u=rng.normal(size=4);u/=np.linalg.norm(u)
    a,b,c,d=u
    return np.array([[a+1j*b,c+1j*d],[-c+1j*d,a-1j*b]])
def close(A,B,tol=5e-10):return np.allclose(A,B,atol=tol,rtol=tol)
def comm(A,B):return A@B@np.linalg.inv(A)@np.linalg.inv(B)
I2=np.eye(2,dtype=complex)

# PC.6: actual four source-specified signed-word rectangles, not generic class assignment.
u,k,h=sp.symbols('u k h',real=True)
j1=2*u;j2=2*(1-u)
segments=[sp.integrate(sp.integrate(-4*j1,(k,0,sp.Rational(1,2))),(u,0,sp.Rational(1,2)))+sp.integrate(sp.integrate(-4*j2,(k,0,sp.Rational(1,2))),(u,sp.Rational(1,2),1)),
          sp.integrate(sp.integrate(4*j1,(k,sp.Rational(1,2),1)),(u,0,sp.Rational(1,2)))+sp.integrate(sp.integrate(4*j2,(k,sp.Rational(1,2),1)),(u,sp.Rational(1,2),1)),
          sp.integrate(-4*u,(u,0,sp.Rational(1,2))),sp.integrate(-4*(1-u),(u,sp.Rational(1,2),1))]
for got,expected in zip(segments,[-1,1,-sp.Rational(1,2),-sp.Rational(1,2)]):ck('PC6_signed_word_four_rectangles',got==expected,'E3')
ck('PC6_total_winding_minus_one',sum(segments)==-1,'E3')
# OY.6: square sweep has actual seam faces and endpoints.
for height in [0,0.1,0.35,0.7,1]:
 for x in np.linspace(0,1,41):
  if x<=1/3:r,lam=1,3*height*x
  elif x<=2/3:r,lam=2-3*x,height
  else:r,lam=0,3*height*(1-x)
  ck('OY6_sweep_stays_in_square',0<=r<=1 and -1e-12<=lam<=1+1e-12,'E2')
  if height==0:ck('OY6_bottom_reparam_exact',abs(lam)<1e-12,'E2')
  if height==1 and x<=1/3:ck('OY6_left_edge_at_one',r==1,'E2')
  if height==1 and x>=2/3:ck('OY6_right_edge_at_one',r==0,'E2')
# OJ.4 based two-block circle-contraction endpoints / basepoint.
J=np.array([[0,1],[-1,0]],dtype=complex)
for lam in np.linspace(0,1,21):
 c=np.cos(np.pi*lam/2);s=np.sin(np.pi*lam/2)
 for angle in np.linspace(0,2*np.pi,29):
  z=np.diag([np.exp(1j*angle),np.exp(-1j*angle)])
  b=(c*z+s*J)@(c*I2-s*J)
  ck('OJ4_contracted_circle_unitary',close(b.conj().T@b,I2,5e-10),'E2')
  if lam==1 or angle==0:ck('OJ4_based_collapse',close(b,I2),'E2')
# PF/SC: noncommutative difference identity, including lower division.
mutant_fail=0
for _ in range(400):
 q=unitary_su2();U=unitary_su2();V=unitary_su2()
 P=lambda g:q@g@q.conj().T@g.conj().T
 lhs=P(U@V)
 rhs=P(U)@U@P(V)@U.conj().T
 ck('SC5_noncommutative_cocycle',close(lhs,rhs),'E2')
 G=U;B=V
 lower=P(G@B)@np.linalg.inv(P(B))
 repaired=P(G)@comm(G,P(B))
 ck('SC5_lower_division_complete',close(lower,repaired),'E2')
 if not close(lower,P(G),1e-8):mutant_fail+=1
ck('E4_SC5_omitted_lower_commutator_fails',mutant_fail>330,'E4')
# PN.1/BG.9 C_2 cancellation and 2deg(L+) - deg(D) parity.
for d in (-1,1):
 for a in range(-80,81):
  ck('BG9_two_closed_axis_degree_odd',(2*a-d)%2==1,'E3')
  ck('BG8_degree_decomposition',a+(d-a)==d,'E3')
for eps in (0,1):
 opts=[k for k in range(12) if (2*k-6*eps)%12==0]
 ck('V263_root_bridge_fibre_classes',opts==([0,6] if eps==0 else [3,9]),'E3')
 for k in opts:ck('V263_root_carry_parity_is_bridge_parity',k%2==eps,'E3')
ck('E4_V263_formal_parity_not_bridge',2*1%12 != 6 and 1%2==1,'E4')
# AJ.5 AJ.6: conditional group arithmetic and 14 application rows.
for z in (0,1):
 h=z; r=(1+z)%2; check=r==(1+h)%2
 ck('AJ5_original_coeff_relation',check,'E3')
if True:
 families=[('D',e,t, e==0 and t==1) for e,t in itertools.product((0,1),repeat=2)] + [('S',e,t,e==0 and t==1) for e,t in itertools.product((0,1),repeat=2)] + [('C',tau,0,tau==0) for tau in (0,1)] + [('B',d,p,d==0 and p==0) for d,p in itertools.product((0,1),repeat=2)]
 ck('AJ6_natural_entries_14',len(families)==14,'E3')
 ck('AJ6_four_yes_ten_no',sum(y for *_,y in families)==4,'E3')
 ck('AJ6_exact_yes_labels',[(a,b,c) for a,b,c,y in families if y]==[('D',0,1),('S',0,1),('C',0,0),('B',0,0)],'E3')
# Dirac cross coefficient, independent inverse-eigenvalue simplification.
Rr,K=sp.symbols('R K',nonzero=True,positive=True)
calc=sp.factor(sp.Rational(3,4)/Rr**2 * Rr**2/(K+1)**2 * Rr**2*(1/(K*(K+2))-sp.Rational(1,3)))
pub=-Rr**2*(K-1)*(K+3)/(4*K*(K+2)*(K+1)**2)
ck('DIRAC_mixed_coefficient_exact',sp.simplify(calc-pub)==0,'E3')
for n in range(1,55):
 ck('DIRAC_k1_zero_others_nonzero',bool((pub.subs({K:n,Rr:2})==0)==(n==1)),'E3')
# Feshbach: matrix Schur algebra and source resolvent bound.
for _ in range(170):
 g=4.0
 D0=np.diag([0.,-g,g]); vtarget=rng.uniform(0.08,0.6)
 A=rng.normal(size=(3,3))+1j*rng.normal(size=(3,3));V=A+A.conj().T;V*=vtarget/np.linalg.norm(V,2)
 v=np.linalg.norm(V,2); z=rng.uniform(-v,v)
 C0=np.diag([-g,g]); C=C0+V[1:,1:]-z*np.eye(2)
 Kmat=V[0,0]-z-V[0,1:]@np.linalg.inv(C)@V[1:,0]
 schur_det=np.linalg.det(D0+V-z*np.eye(3))/np.linalg.det(C)
 ck('FESHBACH_schur_det_ratio',abs(Kmat-schur_det)<1e-9,'E2')
 delta=abs(V[0,1:]@(np.linalg.inv(C)-np.linalg.inv(C0))@V[1:,0])
 b=v*v*(v+abs(z))/(g*(g-v-abs(z)))
 ck('FESHBACH_resolvent_error_bound',delta<=b+1e-12,'E2')
# Heat trace 2x2 projector speed, exact angle expression and bounded numeric.
delta,prime,b=sp.symbols('delta prime b',positive=True)
ratio=sp.simplify(sp.sqrt(b)*sp.Abs(prime)/(b+4*delta**2))
ck('HEAT_projector_angular_formula',ratio==sp.sqrt(b)*prime/(b+4*delta**2),'E3')
for _ in range(150):
 bb=rng.uniform(1,100); d=rng.uniform(-3,3); dp=rng.uniform(-5,5); step=1e-6
 def proj(x):
  mat=np.array([[ -2*x,np.sqrt(bb)],[np.sqrt(bb),2*x]])
  vals,U=np.linalg.eigh(mat);return np.outer(U[:,1],U[:,1].conj())
 pd=(proj(d+step*dp)-proj(d-step*dp))/(2*step)
 exp=math.sqrt(bb)*abs(dp)/(bb+4*d*d)
 ck('HEAT_projector_derivative_sample',abs(np.linalg.norm(pd,2)-exp)<3e-7,'E2')
# Twisted K-theory: elementary torsion tensor/Tor arithmetic for nonzero twist.
for k1 in range(-7,8):
 for k2 in range(-7,8):
  if (k1,k2)==(0,0):continue
  gg=math.gcd(abs(k1),abs(k2))
  ck('TWISTED_K_gcd_torsion_consistency',gg>=1 and (k1%gg)==0 and k2%gg==0,'E3')
# Cartan face midpoint exact, edge defect bounded.
x=sp.pi/6
w=sp.cos(x)+4*sp.sin(x)**3/(3*sp.sqrt(3))
ck('CARTAN_face_minimum_midpoint',sp.simplify(w-5/(3*sp.sqrt(3)))==0,'E3')
ck('CARTAN_operator_defect_exact',sp.simplify((2-2*w)-(2-10/(3*sp.sqrt(3))))==0,'E3')
for t in np.linspace(0,1,101):
 x=math.pi*t/3
 w=math.cos(x)+(4/(3*math.sqrt(3)))*math.sin(x)**3
 y=math.pi*(1-t)/3
 w2=math.cos(y)+(4/(3*math.sqrt(3)))*math.sin(y)**3
 ck('CARTAN_face_symmetric_sample',abs(w-w2)<1e-12,'E2')
 ck('CARTAN_face_nonnegative_defect',0.95<=w<=1+1e-12,'E2')
# Cartan holonomy independently multiplied along all three 2T edges.
def qmul(p,q):
 a,b,c,d=p;e,f,g,h=q
 return np.array([a*e-b*f-c*g-d*h,a*f+b*e+c*h-d*g,a*g-b*h+c*e+d*f,a*h+b*g-c*f+d*e])
def qpow(q,s):
 ang=math.acos(float(np.clip(q[0],-1,1)))
 return np.array([math.cos(s*ang),*(q[1:]/math.sin(ang)*math.sin(s*ang))])
T=[np.array([1.,0.,0.,0.]),np.array([.5,.5,.5,.5]),np.array([.5,.5,.5,-.5])]
for s in np.linspace(0,1,101):
 Q=np.array([1.,0.,0.,0.])
 for i in range(3):
  q=qmul(T[i],T[(i+1)%3]*np.array([1,-1,-1,-1]))
  Q=qmul(Q,qpow(q,s))
 wsource=math.cos(math.pi*s/3)+4/(3*math.sqrt(3))*math.sin(math.pi*s/3)**3
 ck('CARTAN_whole_triangle_quaternion_holonomy',abs(Q[0]-wsource)<2e-12,'E2')
 ck('CARTAN_whole_triangle_unit_quaternion',abs(np.linalg.norm(Q)-1)<2e-12,'E2')
# GW finite overlap matrix and index quantization, without implying geometry of link array.
G=np.diag([1.,1.,-1.,-1.]);I4=np.eye(4)
for _ in range(125):
 A=rng.normal(size=(4,4))+1j*rng.normal(size=(4,4));H=(A+A.conj().T)/2+np.diag([1.2,1.4,-1.1,-1.3]);
 vals,U=np.linalg.eigh(H)
 if min(abs(vals))<1e-8: continue
 E=(U*np.sign(vals))@U.conj().T
 V=G@E;D=I4+V
 ck('OVERLAP_GW_exact_finite',close(G@D+D@G,D@G@D),'E2')
 ck('OVERLAP_gamma5_hermiticity',close(D.conj().T,G@D@G),'E2')
 ch=-np.trace(E)/2
 ck('OVERLAP_integer_index_inertia',abs(ch-round(ch.real))<1e-8 and abs(ch.imag)<1e-8,'E2')
# Invariant forms: exact 2T polynomial syzygy, Molien and norms.
x,y,t=sp.symbols('x y t')
f6=x*y*(x**4-y**4);f8=x**8+14*x**4*y**4+y**8;g12=x**12-33*x**8*y**4-33*x**4*y**8+y**12
ck('INVARIANT_syzygy_degree24',sp.expand(f8**3-g12**2-108*f6**4)==0,'E3')
ck('INVARIANT_sym_tensor_norm_u12',2/sp.binomial(12,2)+4/sp.binomial(12,6)==sp.Rational(8,231),'E3')
ck('INVARIANT_sym_tensor_norm_g12',2+2*33**2/sp.binomial(12,4)==sp.Rational(32,5),'E3')
W=sp.diff(f6**2,x)*g12-f6**2*sp.diff(g12,x)
# Wronskian is on affine x/y chart: use y=1 and derivative in x.
ck('INVARIANT_affine_wronskian',sp.expand(W.subs(y,1)+2*f6.subs(y,1)*f8.subs(y,1)**2)==0,'E3')
Mol=(1/(1-t)**2+1/(1+t)**2+6/(1+t*t)+8/(1-t+t*t)+8/(1+t+t*t))/24
coeff=[sp.expand(sp.series(Mol,t,0,13).removeO()).coeff(t,i) for i in range(13)]
ck('INVARIANT_Molien_coefficients_0_to_12',coeff==[1,0,0,0,0,0,1,0,1,0,0,0,2],'E3')
# Angular moment expansion, Jensen equality domain.
for _ in range(220):
 n=rng.normal(size=3);n/=np.linalg.norm(n)
 e=np.array(list(itertools.product([-1,1],repeat=3)),dtype=float)
 f=(3-(e@n)**2)/4
 ck('ANGULAR_first_moment',abs(sum(f)-4)<1e-12,'E2')
 ck('ANGULAR_second_moment',abs(sum(f**2)-(3-sum(n**4)))<1e-12,'E2')
 ck('ANGULAR_heat_Jensen',2*sum(np.exp(-0.7*f))>=16*np.exp(-0.35)-1e-12,'E2')
for n in np.eye(3):
 e=np.array(list(itertools.product([-1,1],repeat=3)),dtype=float);f=(3-(e@n)**2)/4
 ck('ANGULAR_axes_heat_equality',np.allclose(f,0.5),'E3')
# Theta fixed summand T, R dualities: exact integer identities.
for n,w in itertools.product(range(-5,6),repeat=2):
 ck('THETA_tau_translation_phase', (n*w)==round(n*w),'E3')
 for radius in (0.4,1.,2.3):
  pl=n/radius+w*radius;pr=n/radius-w*radius
  pl_dual=w/(1/radius)+n*(1/radius);pr_dual=w/(1/radius)-n*(1/radius)
  ck('THETA_R_duality_exact_terms',abs(pl-pl_dual)<1e-12 and abs(pr+pr_dual)<1e-12,'E2')
# Fourth-order Schur stationary jet exact in a 1D nontrivial polynomial.
wz,zz=sp.symbols('wz zz');S=3*zz**2/sp.Integer(2)+wz*zz+wz**3/3+wz**2*zz/4+wz*zz**2/5+zz**3/7+wz**4/12
Z=-sp.Rational(1,3)
C=sp.diff(S,zz,2).subs({wz:0,zz:0})
B=sp.diff(S,zz,wz).subs({wz:0,zz:0})
ck('SCHUR_stationary_linear_lift',Z==-B/C,'E3')
A=sp.diff(S,wz,2).subs({wz:0,zz:0})
zz2,zz3=sp.symbols('zz2 zz3');series_z=Z*wz+zz2*wz**2+zz3*wz**3
st_eq=sp.series(sp.diff(S,zz).subs(zz,series_z),wz,0,4).removeO().expand()
z2sol=sp.solve(st_eq.coeff(wz,2),zz2)[0]
z3sol=sp.solve(st_eq.subs(zz2,z2sol).coeff(wz,3),zz3)[0]
Phi=sp.series(S.subs(zz,series_z.subs({zz2:z2sol,zz3:z3sol})),wz,0,5).removeO()
T3I=sp.diff(S,zz,wz,2).subs({wz:0,zz:0})+2*Z*sp.diff(S,zz,wz,zz).subs({wz:0,zz:0})+Z**2*sp.diff(S,zz,3).subs({wz:0,zz:0})
# total derivative of quartic along L=(1,Z) without writing tensor indices.
T4=sp.diff(S.subs(zz,Z*wz),wz,4).subs(wz,0)
D4=sp.diff(Phi,wz,4).subs(wz,0)
ck('SCHUR_exact_fourth_stationary_jet',sp.simplify(D4-(T4-3*T3I**2/C))==0,'E3')
ck('SCHUR_exact_second_Schur',sp.diff(Phi,wz,2).subs(wz,0)==A-B**2/C,'E3')
# Rank-three mixed moment inversion and orientation discriminant.
for _ in range(120):
 aa=np.array([.7,2.,4.1]); bb=np.array([.9,2.2,4.8]);
 X=rng.normal(size=(3,3))+1j*rng.normal(size=(3,3));Q,_=np.linalg.qr(X)
 W=np.abs(Q)**2
 MA=np.array([[float(np.dot(aa**p,(W@(bb**q)))) for q in range(3)] for p in range(3)])
 SA=np.array([[u**p for u in aa] for p in range(3)]);SB=np.array([[u**q for u in bb] for q in range(3)])
 Wrec=np.linalg.solve(SA,MA)@np.linalg.inv(SB.T)
 ck('RANK3_moment_Vandermonde_inversion',close(W,Wrec,1e-8),'E2')
 r=W[0]*W[1];J2=(2*sum(r[i]*r[j] for i in range(3) for j in range(i+1,3))-sum(r*r))/4
 J=(Q[0,0]*Q[1,1]*np.conj(Q[0,1]*Q[1,0])).imag
 ck('RANK3_triangle_Heron_area',abs(J2-J*J)<1e-8,'E2')
 A=np.diag(aa);B=Q@np.diag(bb)@Q.conj().T;Comm=A@B-B@A
 chi=np.trace(Comm@Comm@Comm)/(6j)
 da=(aa[0]-aa[1])*(aa[1]-aa[2])*(aa[2]-aa[0]);db=(bb[0]-bb[1])*(bb[1]-bb[2])*(bb[2]-bb[0])
 ck('RANK3_Jarlskog_commutator',abs(chi*chi-(da*db)**2*J2)<1e-7,'E2')
# E8/E7/E6 exact frames, independently generated 240 roots in standard E8 coordinates.
roots=[]
for i in range(8):
 for j in range(i+1,8):
  for a1,a2 in itertools.product((-2,2),repeat=2):
   v=[0]*8;v[i]=a1;v[j]=a2;roots.append(v)
for signs in itertools.product((-1,1),repeat=8):
 if signs.count(-1)%2==0:roots.append(signs)
X=sp.Matrix(roots);ck('EXROOT_standard_E8_count_240',len(roots)==240,'E3')
F=X.T*X/sp.Integer(8) # each root scaled: coordinates /2sqrt2 => outer factor 1/8
ck('EXROOT_standard_E8_frame_30I',F==30*sp.eye(8),'E3')
ck('EXROOT_flat_antipodal_label_vector_null',all(sum(row[i] for row in roots)==0 for i in range(8)),'E3')
v1=sp.Matrix([1,1,0,0,0,0,0,0]);v2=sp.Matrix([0,-1,1,0,0,0,0,0]);
sets=[row for row in roots if sum(a*b for a,b in zip(row,v1))==0]
sets6=[row for row in sets if sum(a*b for a,b in zip(row,v2))==0]
ck('EXROOT_standard_E7_count_126',len(sets)==126,'E3')
ck('EXROOT_standard_E6_count_72',len(sets6)==72,'E3')
P7=sp.eye(8)-v1*v1.T/(v1.dot(v1))
N=sp.Matrix.hstack(v1,v2);P6=sp.eye(8)-N*(N.T*N).inv()*N.T
ck('EXROOT_E7_frame_18P',sp.Matrix(sets).T*sp.Matrix(sets)/8==18*P7,'E3')
ck('EXROOT_E6_frame_12P',sp.Matrix(sets6).T*sp.Matrix(sets6)/8==12*P6,'E3')
ck('EXROOT_projection_vs_retention_180_vs_72',sp.trace(F*P6)==180 and len(sets6)==72,'E3')
# Repeated polar presentations and distinct scalar Hilbert-Schmidt and vector Moore-Penrose inverse.
for nr,rank in ((72,6),(126,7),(240,8)):
 hh=nr/rank
 ck('EXROOT_scalar_vs_vector_inverse_scopes',abs(nr**-.5-hh**-.5)>1e-5,'E3')
 for krep in (1,2,5,10):
  ck('EXROOT_repetition_polar_G_preserved',(krep*hh)/(krep*hh)==1,'E3')
# Blocking sharp TV bound, and finite covariance positivity.
for _ in range(240):
 S=rng.normal(size=6); d=rng.normal(size=6)*rng.uniform(0,.8)
 p=np.exp(-S-max(-S));p/=sum(p)
 q=np.exp(-S-d-max(-S-d));q/=sum(q)
 tv=sum(abs(p-q))/2
 bd=np.tanh((max(d)-min(d))/4)
 ck('BLOCKING_tanh_oscillation_bound',tv<=bd+2e-12,'E2')
# Dyadic trace exact geometric sums, finite-tail samples.
for r in range(1,10):
 tr=sp.simplify(2*sp.Rational(1,2**r)/(1-sp.Rational(1,2**r))**2)
 publ=sp.Rational(2**(r+1),(2**r-1)**2)
 ck('DYADIC_Taylor_coefficients_exact',tr==publ,'E3')
ck('DYADIC_trace_D_equals_four',sp.Rational(2**2,(2**1-1)**2)==4,'E3')
# Laurent/Riccati response exact and adversarial branch guard.
Cr,Ur,Rv=sp.symbols('Cr Ur Rv',positive=True)
ht=(Rv**2+Cr*Ur)/((Cr+Ur)*Rv)
v=sp.simplify(Rv*sp.diff(sp.log(ht),Rv))
ck('LAURENT_log_derivative_exact',sp.simplify(v-(Rv**2-Cr*Ur)/(Rv**2+Cr*Ur))==0,'E3')
ck('LAURENT_Riccati_exact',sp.simplify(Rv*sp.diff(v,Rv)-(1-v*v))==0,'E3')
ck('LAURENT_reciprocal_ht_invariant',sp.simplify(ht.subs(Rv,Cr*Ur/Rv)-ht)==0,'E3')
for cc,uu in ((1.,2.),(.25,2.5),(1.2,10.)):
 for rr in np.geomspace(.01,200,120):
  H=(rr*rr+cc*uu)/((cc+uu)*rr)
  nn=(math.log(H)/math.log(rr/uu)) if abs(rr/uu-1)>1e-10 else (uu-cc)/(uu+cc)
  ck('LAURENT_n_sign_window', (nn>=-1e-11)==(rr>=cc),'E2')
  ck('LAURENT_n_strict_bound',-1.00000001<nn<1.00000001,'E2')

out={
 'target':'Paper1D-TechnicalMaterial-v1_67.tex','source_sha256':sha,'date':'2026-11-16','batch':4,
 'formal_object_orders':[152,200], 'passed':True,
 'total_scoped_assertions':sum(checks.values()),'named_families':len(checks),
 'checks_by_family':dict(checks),'evidence_tier_by_family':labels,
 'tier_counts':dict(collections.Counter({tier:sum(v for name,v in checks.items() if labels[name]==tier) for tier in ('E2','E3','E4')})),
 'limitations':['The complete OJ/PF/PG/SC/PN/BG frame/annulus/paired-bigon global homotopies were not independently certified.',
                'The 490-facet calibration, all-box NZ.4 certificate and original global gauge realizations remain outside this finite script.',
                'Numerical matrix and finite-axis samples are E2; exact rational/polynomial/finitely enumerated classes are E3 only for those subclaims.',
                'The E8 construction is an abstract standard root realization, not a physical identification of the native Hurwitz source or every presented root section.',
                'The 14 natural-row counts are conditional arithmetic from AJ.6, not the independently checked whole 32-entry global extension problem.',
                'No automated theorem status promotion follows from test passes.']}
path=R/'Paper1D-Batch4IndependentControls-v1_1.json'
path.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ('passed','total_scoped_assertions','named_families','tier_counts')},indent=2))
