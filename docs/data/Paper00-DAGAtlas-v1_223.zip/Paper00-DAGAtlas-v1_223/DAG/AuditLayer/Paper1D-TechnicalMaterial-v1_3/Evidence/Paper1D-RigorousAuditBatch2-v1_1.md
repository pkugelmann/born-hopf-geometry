# Paper I-D — Rigorous Verification DAG Audit, Batch 2 (v1.1)

**Target:** `Paper1D-TechnicalMaterial-v1_67.tex` inside `Paper00-PapersMinimal-v3_018.zip`.  
**Authoritative SHA-256:** `3cd6ae8bb286536ef7bc871d359996309e53ac3a6aed89917a5a82c53b6dcb2a`; **26,561 source lines**.  
**Protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md`.  
**Baseline:** `Paper00-DAGAtlas-v1_153.zip`, `Paper00-ProofChainAudits-v1_66.zip` (unchanged).  
**Previous checkpoint:** `Paper1D-RigorousAuditBatch1Ledger-v1_1.json` (formal objects 1–50).  
**Date:** 2026-11-16. **Classification:** `PARTIALLY_AUDITED_WITH_OPEN_GAPS`.

No input manuscript, atlas ZIP or audit ZIP is modified. No PDF rendering/compilation, framework revision, new physical mechanism or gap-repair theorem is part of this audit.

## 1. Coverage and disposition provenance

- **Batch 2:** formal objects **51–117 inclusive**, current source lines **3198–7196**, covering RT.42–RT.63. Exactly **67** source-as-printed statements and **67** immediate proof spans were re-located in current TeX and source-line aligned to the inherited Paper I-D v1.4 audit. The 183 distinct within-claim proof-reference candidates resolve in the loaded I-A/I-B/I-C/I-D/II-A source corpus; those reference occurrences are **not** automatically accepted as material dependency edges.
- **Cumulative current-run inventory:** 117 of the 279 formal source objects have a recorded source-matched checkpoint; 162 are still outside the fresh batch run. The **279** include the concluding source formal remark beyond the inherited **278** index entries. Material unnamed proof equations and constructor claims must still be independently accounted for; the count 117/279 is a formal-environment *checkpoint*, not evidence of exhaustive unnamed-material review.
- **Inherited claim dispositions for Batch 2:** **18 `REPRODUCED`, 35 `VERIFIED-CONDITIONAL`, 14 `VERIFIED`**. Cumulative inherited-source-lineage dispositions, 1–117: **40 `REPRODUCED`, 59 `VERIFIED-CONDITIONAL`, 18 `VERIFIED`**. This classification does **not** mean 14 complete theorems received fresh independent E3 certificates in this execution. The current-run ledger explicitly retains `current_full_proof_redischarge=false` on all 67, while linking new scoped evidence where applicable.
- Source/replay, finite/algebraic independent checks, and adversarial counterchecks were separate evidence passes within **one execution**, not multiple independent human agents. The historical v1.4 272-claim audit was used as evidence lineage rather than rebranded as a new independent mathematical proof.

## 2. Independent controls — `E3`, exactly scoped

`Paper1D-Batch2IndependentControls-v1_1.py` is reproducible against the frozen current TeX SHA. It ran **130,103 scoped assertions in 80 named families, all passing**; result file `Paper1D-Batch2IndependentControls-v1_1.json`. Most assertions check instances of identities or domain restrictions and must **not** be described as distinct proofs. The numerical maximum absolute error among checks with tracked deviations was about **4.45×10⁻¹⁰**, in the finite-difference local derivative calculation whose threshold was separately bounded.

### RT.44–RT.55: finite group, framing and bundle-profile arithmetic

1. **Boundary coordinate shear and bit invariance (RT.44–RT.45).** Under the **source-given** actual normal-framing shear `z→z+t`, the odd coefficients `3` and `z_A=5−2A (mod 6)` acquire one top `t` term. Exhaustive finite parity controls confirm `(h_t,w_t)→(h_t+σ,w_t+σ)` preserves `ζ_nat=h_t+w_t`. This proves the finite chart consequence; it does not reconstruct the underlying disc-action unstable J representative, nor extend the normal rotation over `W`.
2. **Configuration/pushout cohomology (RT.46).** Independent integer matrix checks reproduce the stated `H^1: (1,-1)`, `H^3:(2,-2)`, `H^4:(1,-1)` Smith invariants and the relevant chain-complex zero compositions for monodromies `1`, swap `P`, and `−1`. In particular the `H^3(J)` restriction image is `2Z`, leaving a `C_2` connecting quotient. This checks the abstract cellular/Mayer–Vietoris calculation **given** the source's equivariant homotopy-pushout identification; it does not independently prove that geometric identification.
3. **Nonabelian joining components (RT.48) and loop clutch action (RT.49).** Exact integer/mod-two checks of the multiplication `(k,n,ε)(l,m,δ)=(k+l,n+m,ε+δ+ln)` verify associativity, inverses, commutators, and the clutching conjugation `ε→ε+ℓn+kd`. Independent composition of the three RT.49 generator actions reproduces `(r,x,y)→(r,x+dr,y+ℓx+(ε_c+ℓd)r)`. The Samelson input and actual section-group identification remain topological premises, not consequences of associativity alone.
4. **Twisted monodromy normal form (RT.52).** Independent group multiplication and automorphism controls reproduce `u'=vuσ(v)^{-1}` with exact central coordinate `z_m+2r−p²−2ap`, and the integer choice `t_0=(z_m+a²) mod 2`, `r_0=(t_0²−z_m−a²)/2` sends the stated component to identity. The numerical controls do not build an actual geometric gauge representing every abstract component.
5. **Piece and frame consequences (RT.50, RT.53–RT.55).** Given the declared Steenrod operation matrices on `H^3(Z_s;F_2)`, `Sq²+χ²=0` follows mod two. The RT.53 affine joining-secondary test leaves exactly two path classes per permitted fibre component and hence four per target. The RT.54 ordinary frame action preserves the top `e,t` bits, while the RT.55 combined six-stage term is `3−z_A≡2A−2 (mod 6)`. These checks do not independently certify the preceding geometric bundle and gauge existence claims.

### RT.56–RT.59: homotopy parity and finite cochains

6. **Stabilization detector (RT.56).** Direct cyclic-group calculations confirm `C12 → C24 → C2` with first map `r→2r` and second map parity is exact. Source proof uses the actual fibration and the imported homotopy groups; the test does not independently prove those groups or the global relative `U(2)` obstruction comparison.
7. **Finite cup-one and cone (RT.57–RT.59).** The five-term cup-one formula gives zero on a separately constructed combinatorial `S^5∨S^9` control. A separate exact small-simplicial test verifies the source's mapping-cylinder prism identity, including simplicial maps that identify vertices. **Not independently rerun:** the positive suspension-of-`HP²₁₅` calibration, its face vector `(15,105,455,1365,3003,4515,4230,2205,490)`, the 490-facet raw list, the reported cochain supports/ranks, and the RT.59 positive-attaching map output. Those claimed historical numerical values are retained as *reported* and still fall under `BH-ID-EV-0001`.

### RT.58–RT.63: explicit coordinate and geometric identity checks

8. **Exotic section and normal frames (RT.58, RT.60).** Independently implemented the quaternion smash coordinates and equivariant suspended complex Hopf formula. Finite samples check unit norm, exchange `s(p,x)=Js(x,p)`, small-normal bounds, the general rank-three transporter `T(a,b)` (unitary, determinant one, `Ta=b`), the full normal-frame equivariance, the antipodal `w,-w` coordinates and denominator bound `|1+e₁*b|≥2/9`. These are algebraic and finite-point checks, not a global Chern/coherent-bundle classification certificate.
9. **Rank-three joining homotopy and local degree (RT.61).** Independently evaluated the unit vector `h_s`, rank-three `K_s` (unitary, determinant one, endpoint commutator, based wedge), and its last-column projection. Finite differences at the source's **unique asserted regular point** reproduce the full printed 5×5 local Jacobian and determinant `4π` to the tolerance stated in the executable. The uniqueness of the regular preimage, global degree, imported stabilized Hopf class and actual geometric bundle source remain justified by the source's separate proof, not by finite differences alone.
10. **Cap and removable branch (RT.62–RT.63).** Uniform sampled cap bounds, the removable `A=-I_E` limit of the *conjugated family* `F_s(t)=A^{-t}(AB)A^t`, endpoints `AB→BA`, and unit length of the supported suspended Hopf toggle pass. They do not independently establish all global seam-gluing homotopies nor the supported top class in the actual exotic bundle.

## 3. Adversarial checks (`E4`) and theorem-boundary distinctions

- **RT.48 countercheck:** a determinant winding generator and a sphere generator have commutator `(0,0,1)` in the *source's* nonabelian component law. A simplified abelian joining-group model would miss the clutching correction. The current source includes the correction; this is a **rejected false simplification**, not a source counterexample.
- **RT.61 scope check:** the explicit `SU(3)` homotopy nulls a stabilized joining commutator, while its rank-two endpoint has the nonzero `C_2` class when `k=d=1`. Stabilized nullhomotopy must not be promoted to an `SU(2)` nullhomotopy. Source states precisely this limitation.
- **RT.63 branch check:** `A^t` itself has inequivalent limits as `A→−I_E` along different axes at fixed `t=1/2`; the source asserts **only that the conjugated `F_s` extends**, and the norm bound supports that. A supposed discontinuity of `F_s` inferred from the principal-power branch alone is invalid.
- **Constitution/realization guard:** RT.44 base normal-frame operations, RT.54 ordinary bundle-frame conjugations, rank-three stabilizations and actual rank-two global `U(2)` gauge realization have **different sorts/domains**. None was substituted for the other. All retained derived group formulas are conditional on actual geometric representatives and named source comparison routes where required.

There is **no domain-matched counterexample to a source-as-printed statement** in the 67 reviewed objects. Missing independently replayable cochain data and global realization certificates are **evidence/condition frontiers**, not established mathematical falsifications.

## 4. All issue roots relevant to this batch

The following are **reused first-root issues** except `BH-ID-DAG-0002`, which was first detected in Batch 1. These descriptions preserve their historical status; no new independent proof closes them. Source lines refer to current v1.67 TeX.

| ID / type | Priority | Source use in this batch | Exact unresolved obligation |
|---|---|---|---|
| `BH-IB-EV-0001` — rank-two realizability/conditional frontier | major | RT.47.4–RT.47.8, RT.50–RT.53; lines 4047–4123, 4605–4716, 5003–5291 | Fixed-stable-class rank-three existence in the later closure is a distinct result. Full unstable **rank-two fixed-Chern** actual bundle count/realizability beyond the source-model computations still needs the matched certificate. The two classes on the five-dimensional `Z_s` piece alone do not settle it. |
| `BH-IB-EV-0002` — secondary gauge-orbit action | major | RT.45 and RT.54–RT.56; lines 3582–3708, 5398–5456, 5749–5815 | The full eight-dimensional **secondary affine determinant action** and global orbit ledger have not been independently established by this batch's parity and first-stage controls. The valid conditional formula cannot select global action coefficients. |
| `BH-IB-EV-0003` — mixed equivariant/global lift | moderate | RT.43, RT.58, RT.60–RT.63; lines 3265–3356, 5969–6016, 6472–6566, 6607–7211 | The actual equivariant/mixed lift and global boundary comparison require the source-matched realization inputs; local coordinates, stable frames and a principal-`SU(2)` exotic no-go do not independently furnish the whole lift. |
| `BH-IB-EV-0004` — actual global gauge-image and boundary-source completeness | major | RT.46–RT.55 and RT.62–RT.63; lines 3762–5639, 6858–7211 | Produce a scope-complete certificate for actual compatible-bundle `Y/Z_s` gauge sources, coherent joining/homotopy choices, boundary transport to `R` and their whole-image completeness, or a verified condition-use route to the existing later source proof. Finite matching of abstract components is not itself whole-image realization. |
| `BH-ID-EV-0001` — reproducibility | moderate | RT.57 and RT.59; lines 5840–5939, 6249–6406 | Supply the *actual* frozen 490-facet `HP²₁₅` complex, cochain representatives, exact elimination and 490-facet/980-suspension-simplex replay script, and positive attaching-cone result. A wedge control and general cup-one derivation are not that missing finite certificate. |
| `BH-ID-DAG-0002` — atlas coverage/integrity | moderate | Paper I-D claim census 1–279; last formal remark 26533–26554 | Current v1.153 atlas registers the six-claim I-D closure overlay, not a queryable source-matched complete current 279-object I-D audit layer. Carry current source dispositions/evidence into the final combined registered atlas, **without** equating citations to reviewed material edges or reopening resolved `BH-ID-DAG-0001`. |

**Issue-class separation:** 0 established contradictory mathematical claims in this batch; 4 pre-existing geometric/evidence frontiers (`BH-IB-EV-0001` through `0004`), 1 inherited missing finite reproducibility certificate, 1 carried DAG-only coverage issue. These are six unique issue roots, **not** six newly discovered mathematics errors. Verified material cross-paper impact paths have **not** been independently reconstructed in this batch; Paper I-B/I-C and later source uses remain **POSSIBLY_AFFECTED** pending typed-edge review, without promoting bare `\ref`/`\eqref` occurrences.

## 5. Audit-layer staging, release gate, next batch

The source-exact 67-claim machine ledger (`Paper1D-RigorousAuditBatch2Ledger-v1_1.json`) includes statements, current proof spans/hashes, guard scope, inherited dispositions, applicable new exact `E3`/guarded `E4` family labels, candidate proof-reference locators and de-duplicated issue-root **candidates**. It is a staging ledger, **not** yet a graph rewrite. The executable and results are supplied alongside for independent rerun. No non-existing canonical assumption IDs or verified cross-paper edges were invented.

**Batch 1 + Batch 2 combined:** formal objects **1–117 of 279**; **162 remain**, plus any unexhausted unnamed consumed proof calculations. The next contiguous batch begins with **object #118**, source near line **7240**; batching will remain as large as practicable while avoiding a stalled audit. The **final batch only** will merge latest active versions into the requested two validated ZIPs — **DAG Atlas** and **ProofChain Audits** — under successor version names. This batch does not ship placeholder or partial-graph ZIPs.

**Checkpoint artifacts:**

- `Paper1D-RigorousAuditBatch2Ledger-v1_1.json` — machine-readable 67-object source audit and controls lineage.
- `Paper1D-Batch2IndependentControls-v1_1.py` — exact finite algebra and executable coordinate/adversarial checks.
- `Paper1D-Batch2IndependentControls-v1_1.json` — complete scoped check counts, pass result and limitations.
- This report `Paper1D-RigorousAuditBatch2-v1_1.md`.
