# Paper I-D — Rigorous Verification DAG Audit, Batch 3 (v1.1)

**Target source:** `Paper1D-TechnicalMaterial-v1_67.tex`, from `Paper00-PapersMinimal-v3_018.zip`; exact SHA-256: `3cd6ae8bb286536ef7bc871d359996309e53ac3a6aed89917a5a82c53b6dcb2a`; 26,561 lines.
**Governing protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md` (source-as-printed, type/domain boundary, E0–E4, first-root issues, audited versus independently verified).
**Latest supplied baseline archives, deliberately unchanged:** `Paper00-DAGAtlas-v1_154.zip` and `Paper00-ProofChainAudits-v1_67.zip`.
**Historical source-matched disposition record:** `Paper1D-ProofChainAudit-v1_4.md`, reconciled line-for-line to current v1.67 source. **Date:** 2026-11-16. **Disposition:** `PARTIALLY_AUDITED_WITH_OPEN_GAPS`; no source manuscript revision.

## 1. Coverage, lineage and audit gates

- **This checkpoint:** objects **118–151 (34)**, from current TeX lines **7290–11182** (last immediate proof), covering the actual odd sphere, projected top-bit detector and natural determinant closing through the projective relative nullhomotopy. The source contains long intervening *unnamed* calculation blocks; the 34 rows do not claim fresh exhaustive independent review of all such blocks.
- **Cumulative current-run formal index:** **151 of 279**. Remaining objects **152–279 = 128**. The source count 279 includes one concluding formal remark after the historical 278-object index. Batch 1 covers 1–50 and Batch 2 covers 51–117 without duplicates or gaps.
- **Inherited claim-level dispositions in this block:** **10 VERIFIED-CONDITIONAL**, **5 VERIFIED**, **19 REPRODUCED**. Cumulative 1–151 inherited: 59 REPRODUCED, 69 VERIFIED-CONDITIONAL, 23 VERIFIED. These are provenance dispositions, **not newly independently verified theorems**.
- **Source anchoring:** 34 exact source-as-printed statements, 34 immediate proof spans, 123 distinct proof-reference/navigation candidates, **0 unresolved labels** within the loaded Paper I-A–I-D/II-A reference corpus. All references are candidate locators only, **not licensed material DAG edges**.
- **Independent executable:** 23,005 pass/fail assertions across **78 named families**, all passing with deterministic seed. Most are sampled coordinate identities or local edge controls (E2), *not* exact global theorem certificates. **11 exact symbolic subclaim checks** (scoped E3) and **2 recorded adversarial family tests** (E4) are differentiated in the ledger. No complete high-impact theorem is newly promoted to unqualified verified status by this batch.
- Independent verifier, source replay and adversarial reviews were separate review passes within a single execution; this report **does not claim multiple independent human agents** or consensus.

## 2. Source-exact proof-block review

### A. Actual sphere input and clutching (objects 118–125, NC.1–NC.31)

The source asserts a complete odd triple with cap-translated clutch `c_j`, coherent ordinary frame, actual sphere-restriction representatives, a supported split `\Phi_0\Psi_C`, and even clutch parity. Reconciliation confirms each precise statement and its immediate proof, rather than replacing the actual rank-two bundle by a free abstract `SU(2)` map. Independent tests reproduce noncommutative matrix/conjugation identities from NC.20/NC.28 and the cap-pair inverse formula in its stated chart. The omitted-conjugating-factor E4 mutation yields a different matrix: it is **not a counterexample to the printed source**, which retains that factor. Actual gauge/odd-clutch realizations and the stabilization-to-original comparison remain source-conditioned geometric steps (`BH-IB-EV-0003/0004`).

### B. Determinant and the entire antipodal branch (objects 126–131, ND/NC)

- **ND.1–2, source lines 7869–7924:** sampled `SU(3)` and rank-two fixed-column unitarity, determinant of `K_+` equal to one, `det D_+=a²`, exchange/deck relation, and the center/endpoint `N` checks pass. These require `v_s\neq0`; nothing in a local check proves a global gauge over all of `W`.
- **ND.4:** the rational function `8t(1-t)/(3+t)²` has the exact critical point `t=3/7`, value `1/6` and the printed derivative. This is an independent exact *subclaim*, alongside sampled nonnegativity/denominator bounds; it does not certify the entire global singular-set statement.
- **NC.33–NC.41:** source retains the *original-source* double cover rather than quotienting away a sign in the antipodal-locus manifold. SymPy independently reduces the source NC.38 and NC.40 equations to the nontrivial solution `c=-1/2`, `d=1/3`. The entire NC.37 printed 3×3 matrix has **exact determinant −8**, corroborated using numerical source-coordinate derivatives at 140 independent configurations. The cap inverse and branch sign invariance also pass sampled tests.
- **Limit of proof:** exact scalar elimination and local determinant do not prove the source equations were exhaustive at every singular branch, nor the global framed map homotopy on the complement. Those are separately asserted/proved in the actual source and require their own independent global E3/E4 route.

### C. Natural sphere bit and framed comparison (objects 132–136, NE.1–NE.16)

The source obtains the two-cell quotient `Q\simeq S²\cup_{\pm2\eta_2}e⁴`, a suspended splitting, and the *actual* comparison `GH` whose framed inverse-image locus is deformed to the commutator. The claimed `GH=\pm\nu'` in NE.8 uses the global ambient isotopy, its normal framing and the based complement. I reproduced the exact scalar Möbius inverse, fixed poles and positive derivative used for the NC/NE normal-coordinate isotopy; I have **not** independently reproduced a complete Pontryagin–Thom framed-complement certificate. In NE.16, shifting odd `n` by any multiple of six retains parity one (exact finite arithmetic), provided the cited homotopy laws and lower-cell cancellation hold.

**Source theorem NE.15:** `[L]=ν'η₆=μ, w_t=1`, explicitly **not** a determination of `h_t`. The present controls support component calculations but **do not create independent global certification of NE.8 or NE.15**. The v1.67 source subsequently points to the complete comparison elsewhere; such later references are not retroactively converted into current independent evidence.

### D. Exterior determinant and Stiefel transport (objects 137–144, NT/NU/NV)

The shifted section, exterior join, cap seam, supported side/top filling, normalized six-sphere bottom deformation and `V_{5,2}` to `V_{7,2}` transporter are read in their **actual bundle domains**. The tested finite formulas include the shifted singular-circle distance cutoff, side/top `SU(2)` commutator identities, center continuity bounds, the unit-sphere condition along the full five chosen deformation stages, and the source endpoint formula for the rank-two Duran map.

**Domain-sensitive countercheck:** an initial overstrong test would have required the NU.6 terminal direction to collapse for every starting real component. The source requires this only on the specified **positive disk** (`Re u_D ≥ 0`). The checked assertion is restricted accordingly; the rejected overstrong formulation is **not** a source counterexample. No independent whole-domain `Sp(2)/Spin(7)/G₂` horizontal lift or all seam-gluing certificate is claimed.

### E. Quaternionic frame, Hessian, intrinsic closing and relative projective null (objects 145–151, NY/NZ/OA/OB)

The independently implemented NY.2 orthonormal quaternionic columns, NY.3 unitary matrix chart, NY.8–10 rotated/radially contracted factors, NZ.2/3 inverse near north and NZ.14 `\mathfrak{su}(3)` connection (`\mathcal A s=\dot s`) pass their stated sampled checks. These establish pointwise consistency, **not** the source’s complete global path topology or existence of a smooth actual frame across every chart boundary.

**NZ.4 evidence frontier:** Claim #147, source 10425–10464, asserts **both** `‖D²e_μ‖≤1/32` and `‖D²e_κ‖≤32` uniformly on a specified six-real-variable box and describes a 50-decimal directed-rounded interval arithmetic checker, including all 36 second derivatives and positivity of every denominator. The **actual complete checker, its frozen directed-rounding output, and full e_κ verification are unavailable** in the supplied archives. Forty finite-difference Hessian samples for `e_μ` meet the numerical bound; they are only `E2`. The historical v1.4 audit notes a distinct small-cap inverse-function alternative supporting necessary topology, not a reproduction of the particular certificate. Preserve `BH-IC-EV-0001` as an open *specific reproducibility* issue; do not assert the printed bound is false.

In OA.1/OA.2, the source uses an intrinsic `SU(2)` product while printing the endpoint as a 3×3 block fixing the third cap column. It is naturally read via the **specified `SU(2)→SU(3)` block embedding**; this should be typed explicitly in the future graph. The existing source uses `g=k_B^{-1}g_can h_E` retaining both real frame factors. Nothing here independently certifies the whole ordinary-bundle gluing. OA.9 removes known lower terms but does **not** calculate the top coefficient `h_t` (claim #150 explicitly says so). OB.16 gives the asserted whole relative projective-plane nullhomotopy with deck/face conditions; no new independent entire-map E3 certificate was produced for it in this batch.

## 3. Complete Batch 3 claim index (all source-matched)

| # | Exact source claim label suffix | Current TeX statement | Immediate proof | Inherited status | Fresh exact E3 families / guarded E4 |
|---:|---|---:|---:|---|---|
| 118 | `natural-sphere-joining` | 7290–7305 | 7306–7338 | `VERIFIED-CONDITIONAL` | — |
| 119 | `natural-coherent-frame` | 7350–7373 | 7374–7395 | `VERIFIED` | — |
| 120 | `natural-odd-boundary-frame` | 7397–7444 | 7445–7477 | `REPRODUCED` | — |
| 121 | `natural-sphere-input` | 7479–7504 | 7505–7542 | `REPRODUCED` | — |
| 122 | `natural-sphere-split` | 7564–7575 | 7576–7589 | `VERIFIED-CONDITIONAL` | — |
| 123 | `natural-clutch-reduction` | 7591–7606 | 7607–7687 | `REPRODUCED` | —; 1 E4 |
| 124 | `natural-clutch-parity` | 7689–7700 | 7701–7755 | `REPRODUCED` | — |
| 125 | `natural-closing-input` | 7757–7775 | 7776–7798 | `REPRODUCED` | — |
| 126 | `natural-determinant-local` | 7869–7898 | 7899–7924 | `VERIFIED-CONDITIONAL` | 3 exact |
| 127 | `natural-determinant-toggle` | 7926–7939 | 7940–7969 | `VERIFIED-CONDITIONAL` | — |
| 128 | `natural-determinant-joining` | 7971–7983 | 7984–8049 | `REPRODUCED` | — |
| 129 | `natural-closing-projective` | 8101–8113 | 8114–8122 | `VERIFIED` | — |
| 130 | `natural-closing-full-branch` | 8124–8162 | 8163–8215 | `REPRODUCED` | 4 exact; 1 E4 |
| 131 | `natural-closing-branch-preimages` | 8217–8243 | 8244–8267 | `VERIFIED-CONDITIONAL` | — |
| 132 | `natural-sphere-factor` | 8310–8344 | 8345–8366 | `REPRODUCED` | — |
| 133 | `natural-sphere-two-cell` | 8368–8390 | 8391–8415 | `REPRODUCED` | — |
| 134 | `natural-sphere-top-comparison` | 8417–8435 | 8436–8512 | `REPRODUCED` | 3 exact |
| 135 | `natural-sphere-source-top` | 8514–8524 | 8525–8551 | `REPRODUCED` | — |
| 136 | `natural-sphere-bit` | 8553–8560 | 8561–8598 | `REPRODUCED` | 1 exact |
| 137 | `natural-determinant-shift` | 8631–8649 | 8650–8660 | `VERIFIED` | — |
| 138 | `natural-determinant-exterior` | 8683–8714 | 8715–8739 | `VERIFIED-CONDITIONAL` | — |
| 139 | `natural-determinant-patch-input` | 8741–8764 | 8765–8802 | `REPRODUCED` | — |
| 140 | `natural-determinant-side-fill` | 8867–8891 | 8892–8926 | `VERIFIED` | — |
| 141 | `natural-determinant-bottom-homotopy` | 8928–8978 | 8979–9016 | `REPRODUCED` | — |
| 142 | `natural-determinant-V5-lift` | 9133–9144 | 9145–9232 | `VERIFIED-CONDITIONAL` | — |
| 143 | `natural-determinant-V7-map` | 9334–9348 | 9349–9359 | `REPRODUCED` | — |
| 144 | `natural-determinant-transported-bottom` | 9446–9459 | 9460–9501 | `REPRODUCED` | — |
| 145 | `natural-quaternion-frame` | 10224–10267 | 10268–10288 | `VERIFIED-CONDITIONAL` | — |
| 146 | `natural-quaternion-factor` | 10290–10309 | 10310–10318 | `VERIFIED` | — |
| 147 | `natural-inverse-source` | 10425–10436 | 10437–10464 | `REPRODUCED` | — |
| 148 | `natural-exterior-factors` | 10568–10603 | 10604–10617 | `REPRODUCED` | — |
| 149 | `natural-intrinsic-closing` | 10677–10702 | 10703–10713 | `VERIFIED-CONDITIONAL` | — |
| 150 | `natural-parameter-lower` | 10795–10801 | 10802–10819 | `VERIFIED-CONDITIONAL` | — |
| 151 | `natural-projective-null` | 11158–11170 | 11171–11182 | `REPRODUCED` | — |

Each numbered ledger entry also contains the *full frozen statement*, line and proof SHA-256 hashes, type/quantifier boundary, historical status, new E2/E3/E4 subclaim family names, and source-resolved but **untyped navigation candidates**. The table is a navigational digest, **not** a substitute for the proof expressions.

## 4. Boundary records and inherited issue-root register

| Proposed scoped boundary key (this batch only) | First material source here | Sort, condition and non-implication |
|---|---|---|
| `BND-ID-B3-001` | NC.1–NC.31 / ND.1–2 | An **actual ordinary U(2) bundle/gauge** with fixed seam is not replaced by a pointwise `SU(2)` matrix, rank-three stabilized filler or ambient group component. This is source geometric realization, not a freely generated operation. |
| `BND-ID-B3-002` | NC.33–40 / NE.7–16 | Source *global framed map and complement* (`R/E`), not merely local regular-point Jacobian (`E2`). Framed inverse-image comparison is required for top-bit evaluation; sign/projective quotient not applied to the original-source locus. |
| `BND-ID-B3-003` | NZ.2–4 | A **uniform interval norm bound over both six-variable inverse charts** is not established by finitely many `e_μ` samples. A separately described topological alternative is not identical to replaying the stated numerical checker. |
| `BND-ID-B3-004` | NZ.17–OA.9 / OB.16 | Intrinsic `SU(2)` closure is embedded in the fixed-third-column `SU(3)` frame; actual deck descent, seam and bundle sources retained. Lower-term removal is not a value-selection rule for `h_t`. |

These boundary keys are **audit-workplace proposals**, not new global canonical assumption IDs. They have no unconditional graph-edge authority until merged against the existing single-node assumption registry.

| Canonical issue root | State in this batch | Condition on what must actually be certified |
|---|---|---|
| `BH-IB-EV-0002` | Inherited, open outside its verified first stage | Full secondary eight-dimensional affine determinant gauge action and orbit identifications; neither the local ND closure nor lower-term division computes those automatically. |
| `BH-IB-EV-0003` | Inherited, partially sourced | The entire actual mixed/equivariant lift, including source-grade odd clutch/ordering-line descent; local matrix checks and stable fillings do not imply full realized comparison. |
| `BH-IB-EV-0004` | Inherited, partially sourced | The **whole-image** compatible rank-two bundle/gauge-image and global joining completeness, not merely explicit constructed families, one source section or group-component arithmetic. |
| `BH-IC-EV-0001` | **Specific reproducibility gap remains** | Restore or independently certify the original 50-decimal directed-rounding NZ.4 full two-map box/36-Hessian arithmetic, or explicitly declare reliance on a separately source-proved alternative without misreporting certificate replay. |
| `BH-ID-DAG-0002` | Carried DAG-integrity work, not mathematics error | Current v1.154 atlas retains a six-claim I-D closure overlay; does not yet contain the full source-matched **279-object** I-D audit layer. Stage evidence until the final package. |

The earlier independent raw-cochain issue `BH-ID-EV-0001` (490-facet calibration) is inherited from Batch 2 and may be upstream of top detector provenance, **but is not a newly rechecked equation or newly generated issue in objects 118–151**. Likewise other Paper I-B and I-C issue roots not materially exercised here remain untouched. **Zero source-domain-matched contradictory mathematical witnesses** were found. No issue is marked closed by a sampled passing check; no same-root issue is cloned.

## 5. Machine artifact and release-integrity plan

1. `Paper1D-RigorousAuditBatch3Ledger-v1_1.json`: 34 fully source-anchored entries, SHA-256 source and proof spans, 123 resolved navigation labels and conditional issue candidates. **It is a staging ledger, not an integrated DAG rewrite.**
2. `Paper1D-Batch3IndependentControls-v1_1.py`: deterministic independent symbolic, matrix/quaternionic, finite-difference and adversarial checks; source SHA asserted before execution.
3. `Paper1D-Batch3IndependentControls-v1_1.json`: 23,005 passed controls, 78 family counts, numeric maximum deviations and known missing certificates.
4. This report `Paper1D-RigorousAuditBatch3-v1_1.md`, containing exact boundaries and explicit nonpromotions.

**Release gate:** Neither canonical atlas nor audit ZIP is changed or repackaged in Batch 3. Continue with #152–279 in bounded batches, including source material between named objects, then merge source-matched audits into the latest active DAG and audits ZIPs **only in the final batch**, eliminating superseded versions and verifying archive structure, manifests, exact content hashes and proof evidence after writing. The next contiguous formal object is **#152** (source around line 12501); **128 formal objects remain**.

