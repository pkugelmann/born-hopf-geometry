#!/usr/bin/env python3
"""Independent all-case rational verification of I-B v342/v343 source geometry.
No paper-specific precomputed projectors, orientations or numerical fitting.
"""
import itertools, json, sys
from collections import Counter, defaultdict
from pathlib import Path
import sympy as sp
c=Counter()
def ck(k,v):
 c[k]+=1
 if not bool(v):raise AssertionError(f'{k} #{c[k]}')
def sign(p):return (-1)**sum(p[i]>p[j] for i in range(5) for j in range(i+1,5))
def mul(p,q):return tuple(p[q[i]] for i in range(5))
def inv(p):return tuple(p.index(i) for i in range(5))
def order(p):
 q=p;n=1
 while q != tuple(range(5)):
  q=mul(p,q);n+=1
 return n
def mat(p):
 M=sp.zeros(5)
 for j,i in enumerate(p):M[i,j]=1
 return M
def inner(A,B):return (A.T*B).trace()
def bits(A):return sp.Matrix([int(i in A) for i in range(5)])
def vector(A):return sp.Matrix([int(i==A[0])-int(i==A[1]) for i in range(5)])
def asvec(M):return sp.Matrix(25,1,list(M))

def main():
 Q=sp.eye(5)-sp.ones(5)/5; one=sp.ones(5,1); I=sp.eye(15)
 pairs=list(itertools.combinations(range(5),2))
 edges=[(A,B) for A,B in itertools.combinations(pairs,2) if set(A).isdisjoint(B)]
 L=[]; Sd=[]
 for A,B in edges:
  va=bits(A)-sp.Rational(2,5)*one;vb=bits(B)-sp.Rational(2,5)*one
  L.append(va*vb.T-vb*va.T)
  da=vector(A);db=vector(B)
  Sd.append(da*da.T-db*db.T)
 GS=sp.Matrix(15,15,lambda i,j:inner(Sd[i],Sd[j]))
 GK=sp.Matrix(15,15,lambda i,j:inner(L[i],L[j]))
 P4=GS*(GS-4*I)/(25*21)
 P5=GS*(25*I-GS)/(4*21)
 P6=GK/4
 coeff=P4/5+P5/2+P6/2
 U=[sum((coeff[f,e]*(Sd[f]+L[f]) for f in range(15)),sp.zeros(5)) for e in range(15)]
 ck('U_orthonormal',sp.Matrix(15,15,lambda i,j:inner(U[i],U[j]))==I)
 ps=[p for p in itertools.permutations(range(5)) if sign(p)==1]
 ck('A5_60',len(ps)==60)
 def Z(g):return Q*mat(g)*Q-sp.Rational(sum(g[j]==j for j in range(5))-1,4)*Q
 def cycle(A):
  T=sorted(set(range(5))-set(A))
  q=list(range(5));q[T[0]]=T[1];q[T[1]]=T[2];q[T[2]]=T[0]
  return tuple(q)
 S=[];K=[]
 for A in pairs:
  g=cycle(A); z=Z(g);zin=Z(inv(g))
  s=(z+zin)/2;k=(z-zin)/2
  S.append(s);K.append(k)
  T=sorted(set(range(5))-set(A));ut=bits(T)
  PT=sp.diag(*[int(i in T) for i in range(5)])-ut*ut.T/3
  ck('S_A_formula',s==sp.Rational(3,4)*Q-sp.Rational(3,2)*PT)
  ck('S_A_quadratic_identity',s*s==sp.Rational(9,16)*Q)
  ck('K_A_skew',k.T==-k and k*one==sp.zeros(5,1))
 ck('S_A_sum_zero',sum(S,sp.zeros(5))==sp.zeros(5))
 gs=sp.Matrix(10,10,lambda i,j:inner(S[i],S[j]))
 for i,A in enumerate(pairs):
  for j,B in enumerate(pairs):
   expected=sp.Rational(9,4) if i==j else (sp.Rational(-5,4) if set(A).isdisjoint(B) else sp.Rational(1,4))
   ck('S_A_Gram_all_100',gs[i,j]==expected)
   com=S[i]*S[j]-S[j]*S[i]
   expectednorm=0 if i==j else (sp.Rational(5,2) if set(A).isdisjoint(B) else sp.Integer(1))
   ck('S_A_commutator_norm_all_100',inner(com,com)==expectednorm)
 ck('S_A_rank9',gs.rank()==9)
 ck('S_A_eigen_spectrum',gs*(gs-sp.Rational(1,2)*sp.eye(10))*(gs-5*sp.eye(10))==sp.zeros(10)
    and gs.trace()==sp.Rational(45,2))
 gk=sp.Matrix(10,10,lambda i,j:inner(K[i],K[j]))
 ck('triangle_frame_tight',gk*gk==sp.Rational(5,2)*gk and gk.rank()==6)
 for X in K+L:
  ck('triangle_frame_reconstruction',sp.Rational(2,5)*sum((inner(X,Ka)*Ka for Ka in K),sp.zeros(5))==X)
 J=sp.Matrix(10,15,lambda i,j:inner(K[i],L[j]))
 ck('J_integer_support',set(J).issubset({sp.Integer(-1),sp.Integer(0),sp.Integer(1)}))
 for i,A in enumerate(pairs):
  ck('J_row_nonzero_6',sum(J[i,e]!=0 for e in range(15))==6)
  for e,(B,C) in enumerate(edges):
   expected= len(set(A)&set(B))==1 and len(set(A)&set(C))==1
   ck('J_full_incidence_150',(J[i,e]!=0)==expected)
 for j in range(15):ck('J_col_nonzero_4',sum(J[i,j]!=0 for i in range(10))==4)
 ck('J_10_times_projector_triangle',J*J.T==4*gk)
 ck('J_10_times_projector_petersen',J.T*J==sp.Rational(5,2)*GK)
 ck('J_rank6',J.rank()==6)
 # A5-conjugacy class partition and finite full-sl4 operator-frame certificates.
 unseen=set(ps); classes=[]
 while unseen:
  x=sorted(unseen)[0]
  cl={mul(mul(g,x),inv(g)) for g in ps}
  unseen-=cl; classes.append(sorted(cl))
 dic=defaultdict(list)
 for cl in classes:dic[(order(cl[0]),len(cl))].append(cl)
 ck('A5_class_structure',sorted(map(len,classes))==[1,12,12,15,20])
 cls={name:dic[key][index] for name,key,index in [('id',(1,1),0),('2A',(2,15),0),('3A',(3,20),0),('5A',(5,12),0),('5B',(5,12),1)]}
 # Rational U-based coordinates and class frame (sqrt15 cancels in outer products)
 coords={g:sp.Matrix([inner(T,Z(g)) for T in U]) for g in ps}
 def frame(cl):return sum((coords[g]*coords[g].T/sp.Integer(15) for g in cl),sp.zeros(15))
 AA={name:frame(cl) for name,cl in cls.items()}
 ck('frame_all_A5_unity',sum(AA.values(),sp.zeros(15))==I)
 ck('frame_identity_zero',AA['id']==sp.zeros(15))
 ck('frame_order2_rank_trace',AA['2A'].rank()==9 and AA['2A'].trace()==4)
 ck('frame_order3_rank_trace',AA['3A'].rank()==15 and AA['3A'].trace()==5)
 ck('frame_order5_rank_trace',all(AA[k].rank()==11 and AA[k].trace()==3 for k in ['5A','5B']))
 ck('frame_order2_formula',AA['2A']==P4/3+sp.Rational(8,15)*P5)
 ck('frame_order3_formula',AA['3A']==sp.Rational(2,3)*P4+P5/15+P6/3)
 ck('frame_order5_sum',AA['5A']+AA['5B']==sp.Rational(2,5)*P5+sp.Rational(2,3)*P6)
 D=AA['5A']-AA['5B']
 ck('golden_polarization_projector',D*P4==sp.zeros(15) and D*P5==sp.zeros(15) and D*D==sp.Rational(16,45)*P6)
 ck('golden_polarization_trace',D.trace()==0 and D.rank()==6)
 ck('golden_ratio_algebra',sp.simplify((5+2*sp.sqrt(5))/(5-2*sp.sqrt(5))-(9+4*sp.sqrt(5)))==0)
 # For any X the three-cycle frame inversion is a 15x15 identity.
 inv3=sp.Rational(3,2)*P4+15*P5+3*P6
 ck('threecycle_inverse',AA['3A']*inv3==I)
 # Source v343 class-sum contrast on W (integer signed permutations)
 def action(g):
  ans=sp.zeros(15)
  for e,(A,B) in enumerate(edges):
   pa=tuple(sorted(g[i] for i in A));pb=tuple(sorted(g[i] for i in B))
   if (pa,pb) in edges:ans[edges.index((pa,pb)),e]=1
   else:ans[edges.index((pb,pa)),e]=-1
  return ans
 KW=sum((action(g) for g in cls['5A']),sp.zeros(15))-sum((action(g) for g in cls['5B']),sp.zeros(15))
 ck('K_W_minimal_polynomial',KW**3==80*KW and KW**2==80*P6)
 ck('K_W_orientation_and_frame_difference',KW==-15*D)
 t=(1,0,2,3,4)
 ck('K_W_outer_parity',action(t)*KW*action(t).T==-KW)
 # Exact Lie word closure for 4 shape representatives; enumerate S5-orbits of all triples.
 def shape(triple):
  deg=Counter(i for edge in triple for i in edge)
  return tuple(sorted([deg.get(i,0) for i in range(5)],reverse=True))
 shapes=defaultdict(list)
 for triple in itertools.combinations(pairs,3):shapes[shape(triple)].append(triple)
 ck('four_triangle_types',sorted(len(v) for v in shapes.values())==[10,20,30,60])
 def rankadd(vecs,mat):
  q=asvec(mat)
  if not any(mat):return False
  B=sp.Matrix.hstack(*vecs,q) if vecs else q
  if B.rank()>len(vecs):vecs.append(q);return True
  return False
 def lie_dims(generators,maxdepth=9):
  bas=[];fresh=[]
  for x in generators:
   if rankadd(bas,x):fresh.append(x)
  result=[len(bas)]
  for k in range(2,maxdepth+1):
   new=[]
   for a in fresh:
    for b in generators:
     comm=a*b-b*a
     if rankadd(bas,comm):new.append(comm)
   fresh=new;result.append(len(bas))
   if not fresh:break
  return result
 rep={}
 for sh,triples in shapes.items():
  seq=lie_dims([S[pairs.index(A)] for A in triples[0]])
  rep[str(sh)]={'count':len(triples),'dimensions_by_depth':seq, 'representative':list(triples[0])}
  exp=15 if len(triples)==60 else 9
  ck('Lie_triple_orbit_representative',seq[-1]==exp)
  if len(triples)==60:ck('Lie_path_depths_3_6_11_14_15',seq[:5]==[3,6,11,14,15])
  # Show S5 acts transitively inside the shape, so every source triple was checked.
  A=triples[0];orb=set()
  for p in itertools.permutations(range(5)):
   orb.add(tuple(sorted(tuple(sorted(p[j] for j in pair)) for pair in A)))
  ck('Lie_all_triples_orbit_coverage',set(triples)==orb)
 # both two-member orbits have Lie dimension four as printed.
 two_sh=defaultdict(list)
 for pair in itertools.combinations(pairs,2):two_sh[tuple(sorted(Counter(i for edge in pair for i in edge).values(),reverse=True))].append(pair)
 ck('Lie_two_pair_orbits',sorted(map(len,two_sh.values()))==[15,30])
 for rep2 in two_sh.values():ck('Lie_pair_max_four',lie_dims([S[pairs.index(A)] for A in rep2[0]])[-1]==4)
 result={'status':'PASS','exact_assertions':sum(c.values()),'checks':dict(c),'lie_orbits':rep,
  'class_sizes':{k:len(v) for k,v in cls.items()},'claim_labels':[
   'p1:thm:v342-three-cycle-petersen-overlap','p1:thm:v342-triangle-petersen-cycle-isometry',
   'p1:thm:v342-class-frame-three-cycle-tomography','p1:thm:v342-minimal-path-lie-generators',
   'p1:prop:v343-fivefold-signed-contrast'],
  'evidence_scope':'complete finite permutation domain; exact rational identities; S5-orbit reductions for Lie closure; no physical selection'}
 dest=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/mnt/data/p1_work/Paper1B-ThreeCycleExactProof-v1_1.json')
 dest.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
 print(json.dumps(result,indent=2,sort_keys=True))
if __name__=='__main__':main()
