#!/usr/bin/env python3
"""Independent all-case exact A5->Sylow5, Desargues parity and kernel readout.
Checks v341 two claim scopes, using group enumeration, integer incidence and
S5 generators/exhaustion.  No imported numerical group files.
"""
import itertools,json,sys
from collections import Counter
from pathlib import Path
import numpy as np
import networkx as nx
from sympy import Matrix
C=Counter()
def ck(n,v):
 C[n]+=1
 if not bool(v):raise AssertionError(f'{n} #{C[n]}')
identity=tuple(range(5))
def even(p):return sum(p[i]>p[j] for i in range(5) for j in range(i+1,5))%2==0
def mul(p,q):return tuple(p[q[i]] for i in range(5))
def inv(p):return tuple(p.index(i) for i in range(5))
def order(g):
 q=identity
 for n in range(1,6):
  q=mul(g,q)
  if q==identity:return n
 raise Exception('order>5')
def parity(p):return 1 if even(p) else -1

def main():
 S5=list(itertools.permutations(range(5)));G=[p for p in S5 if even(p)]
 pair=list(itertools.combinations(range(5),2))
 sub5=set()
 for g in G:
  if order(g)==5:
   h=identity;H=[]
   for n in range(5):H.append(h);h=mul(h,g)
   sub5.add(tuple(sorted(H)))
 axes=sorted(sub5); ck('six_Sylow5_subgroups',len(axes)==6)
 ix={a:i for i,a in enumerate(axes)}
 action={g:tuple(ix[tuple(sorted(mul(mul(g,h),inv(g)) for h in H))] for H in axes) for g in S5}
 ck('faithful_120_S5_sixaxis_actions',len(set(action.values()))==120)
 seed=(0,1,2)
 Fplus={tuple(sorted(action[g][i] for i in seed)) for g in G}
 Fminus={tuple(sorted(set(range(6))-set(t))) for t in Fplus}
 ck('two_ten_face_orbits',len(Fplus)==len(Fminus)==10 and not (Fplus&Fminus))
 fplus={};fminus={}
 for A in pair:
  stab=[g for g in G if {g[i] for i in A}==set(A)]
  ck('pair_stabilizer_order6',len(stab)==6)
  def fixed(F):return [t for t in F if all({action[g][i] for i in t}==set(t) for g in stab)]
  x=fixed(Fplus);y=fixed(Fminus)
  ck('unique_stabilized_face_each_orbit',len(x)==len(y)==1)
  fplus[A]=x[0];fminus[A]=y[0]
 for A in pair:
  for B in pair:
   n=len(set(fplus[A])&set(fminus[B]))
   expected=1 if set(A).isdisjoint(B) else (0 if A==B else 2)
   ck('cross_incidence_all100',n==expected)
 for g in S5:
  for A in pair:
   target=tuple(sorted(g[i] for i in A))
   im=tuple(sorted(action[g][i] for i in fplus[A]))
   expected=fplus[target] if even(g) else fminus[target]
   ck('all_S5_face_parity_1200',im==expected)
   im2=tuple(sorted(action[g][i] for i in fminus[A]))
   expected2=fminus[target] if even(g) else fplus[target]
   ck('all_S5_face_parity_minus_1200',im2==expected2)
 def seqsign(seq):return (-1)**sum(seq[i]>seq[j] for i in range(5) for j in range(i+1,5))
 A=np.array([[int(set(u).isdisjoint(v)) for v in pair] for u in pair],dtype=np.int64)
 H=np.array([[seqsign(list(u)+list(v)+list(set(range(5))-set(u)-set(v))) if set(u).isdisjoint(v) else 0 for v in pair] for u in pair],dtype=np.int64)
 ck('signed_Hodge_cubic',np.array_equal(H@H@H,5*H))
 for g in S5:
  T=np.zeros((10,10),dtype=np.int64)
  for j,u in enumerate(pair):
   x,y=g[u[0]],g[u[1]]
   T[pair.index(tuple(sorted((x,y)))),j]=1 if x<y else -1
  ck('Hodge_full_S5_parity',np.array_equal(T@H@T.T,parity(g)*H))
 def double(S):return np.block([[(A+S)//2,(A-S)//2],[(A-S)//2,(A+S)//2]])
 dodec=double(H);des=double(-A)
 ck('desargues_and_dodeca_cover_integer',np.all((A+H)%2==0) and np.all((A-H)%2==0))
 ck('Desargues_exact_GP_10_3',nx.is_isomorphic(nx.from_numpy_array(des),nx.desargues_graph()))
 ck('Dodeca_exact_GP_10_2',nx.is_isomorphic(nx.from_numpy_array(dodec),nx.dodecahedral_graph()))
 cycset=set()
 graph=nx.from_numpy_array(A)
 for u in nx.simple_cycles(nx.DiGraph(graph)):
  if len(u)!=5:continue
  variants=[tuple(t[i:]+t[:i]) for t in (u,list(reversed(u))) for i in range(5)]
  cycset.add(min(variants))
 ck('twelve_base_pentagons',len(cycset)==12)
 flux=Counter(int(np.prod([H[s[i],s[(i+1)%5]] for i in range(5)])) for s in cycset)
 ck('dodeca_flux_six_six',flux=={1:6,-1:6})
 ck('desargues_flux_all_minus',all(np.prod([(-A)[s[i],s[(i+1)%5]] for i in range(5)])==-1 for s in cycset))
 # Exhaustive subgroup restriction V5|A4=3 + 1' + 1'' via 6-axis character on 6-D permutation space.
 core={h for h in G if h[0]==0};ck('A4_core_size12',len(core)==12)
 sumsix=np.zeros((6,6),dtype=np.int64)
 for h in core:
  if order(h)==3:
   for j,i in enumerate(action[h]):sumsix[i,j]+=1
 ck('A4_8elements_order3',np.all(sumsix.sum(axis=0)==8))
 # Matrix spectrum exactly from minimal polynomial and traces (integral arithmetic).
 J6=np.ones((6,6),dtype=np.int64);E=np.eye(6,dtype=np.int64)
 # Project away invariant line: 6D module =1+5, K_6*1=8*1; on 5D 2*(-4) +3*0.
 K=np.array(sumsix,dtype=np.int64)
 ck('A4_shell_eigen_8_minus4_0',int(Matrix(K-8*E).nullspace().__len__())==1 and int(Matrix(K+4*E).nullspace().__len__())==2 and int(Matrix(K).nullspace().__len__())==3)
 ck('A4_shell_polynomial',(np.array_equal((K-8*E)@K@(K+4*E),np.zeros((6,6),dtype=np.int64))))
 ck('A4_shell_trace_rank',np.trace(K)==0 and int(Matrix(K).rank())==3)
 ck('A4_shell_5D_-4_twice',np.trace(K@K)==96) # 8^2+2*4^2=96
 # Full A5 5D irrep character via induced action on the six axes.
 chi5={g:sum(action[g][i]==i for i in range(6))-1 for g in G}
 for g in G:
  expected={1:5,2:1,3:-1,5:0}[order(g)]
  ck('A5_standard_5_char_all60',chi5[g]==expected)
 # 10D complement under commuting right regular action has chi=2 chi5;
 # 10-vertex Petersen module has character fixed unordered pair, unequal on 3-cycles.
 gc=next(g for g in G if order(g)==3)
 fixed_pairs=sum({gc[i] for i in u}==set(u) for u in pair)
 ck('10D_not_Petersen_on_3cycles',2*chi5[gc]==-2 and fixed_pairs==1)
 # 17-space transporter image = 1\oplus 4\boxtimes4: exactly orthogonal to central 5D coefficient projector.
 BB=np.array([[int(g[j]==i) for i in range(5) for j in range(5)] for g in G],dtype=np.int64)
 Kernel=np.array([[chi5[mul(inv(g),h)] for h in G] for g in G],dtype=np.int64)
 ck('A5_character_K5_matrix_idempotent_up_to12',np.array_equal(Kernel@Kernel,12*Kernel))
 ck('transporter_annihilation_by_5D_kernel',np.array_equal(Kernel@BB,np.zeros((60,25),dtype=np.int64)))
 result={'status':'PASS','exact_assertions':sum(C.values()),'check_families':dict(C),
 'cross_incidence_counts':dict(Counter(len(set(fplus[u])&set(fminus[v])) for u in pair for v in pair)),
 'claim_labels':['p1:thm:v341-desargues-rp2-parity','p1:prop:v341-walk-kernel-no-petersen-isomorphism'],
 'scope':'all six-axis group actions (60 A5, 120 S5), exact integer matrices, right-action character separation; twoI used as centre-even lift only'}
 dest=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/mnt/data/p1_work/Paper1B-DesarguesWalkExactProof-v1_1.json')
 dest.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
 print(json.dumps(result,indent=2,sort_keys=True))
if __name__=='__main__':main()
