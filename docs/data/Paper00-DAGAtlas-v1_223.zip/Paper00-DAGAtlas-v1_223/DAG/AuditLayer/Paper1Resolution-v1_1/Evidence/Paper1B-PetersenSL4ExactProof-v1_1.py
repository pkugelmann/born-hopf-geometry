#!/usr/bin/env python3
"""Exact, exhaustive certificate for Paper I-B v339 Petersen--sl(V) three claims.

Uses exact rational algebra only (SymPy), over all 15 unoriented graph edges
and generators of S5, all 60 even permutations of five letters and all 60^2
pairs in the centre-even rank-15 reproducing kernel.  Source input is purely
combinatorial KG(5,2), the standard R^5 representation and A5 five-label
permutation action.  No physical source/occurrence claim is made.
"""
import itertools, json, hashlib, sys
from collections import Counter
from fractions import Fraction
from pathlib import Path
import sympy as sp

checks=Counter(); details={}
def ck(name, cond):
    checks[name]+=1
    if not bool(cond):raise AssertionError(f"{name}: #{checks[name]}")

def tr(A,B): return (A.T*B).trace()
def vv(S):return sp.Matrix([sp.Integer(i in S) for i in range(5)])
def perm_sign(p): return (-1)**sum(p[i]>p[j] for i in range(5) for j in range(i+1,5))
def compose(p,q): return tuple(p[q[i]] for i in range(5))
def inv(p):return tuple(p.index(i) for i in range(5))
def ch4(p):return sum(p[i]==i for i in range(5))-1

def main():
    ones=sp.ones(5,1); Q=sp.eye(5)-sp.ones(5)/5
    verts=list(itertools.combinations(range(5),2))
    edges=[(a,b) for a,b in itertools.combinations(verts,2) if set(a).isdisjoint(b)]
    ck('petersen_vertex_edge_counts',(len(verts),len(edges))==(10,15))
    v={a:vv(a)-sp.Rational(2,5)*ones for a in verts}
    d={a:sp.Matrix([int(i==a[0])-int(i==a[1]) for i in range(5)]) for a in verts}
    S=[];K=[]
    for a,b in edges:
        sa=d[a]*d[a].T-d[b]*d[b].T
        ka=v[a]*v[b].T-v[b]*v[a].T
        S.append(sa); K.append(ka)
        ck('S_symmetric_tracefree_support',sa==sa.T and sa.trace()==0 and sa*ones==sp.zeros(5,1))
        ck('K_skew_support',ka==-ka.T and ka*ones==sp.zeros(5,1))
        ck('S_K_Hilbert_Schmidt_orthogonal',tr(sa,ka)==0)
        ck('K_HS_norm',tr(ka,ka)==sp.Rational(8,5))
    Gs=sp.Matrix(15,15,lambda i,j:tr(S[i],S[j]))
    Gk=sp.Matrix(15,15,lambda i,j:tr(K[i],K[j]))
    I=sp.eye(15)
    ck('S_polynomial_spectrum',Gs*(Gs-4*I)*(Gs-25*I)==sp.zeros(15))
    ck('K_polynomial_spectrum',Gk*(Gk-4*I)==sp.zeros(15))
    P4=Gs*(Gs-4*I)/sp.Integer(25*21)
    P5=Gs*(25*I-Gs)/sp.Integer(4*21)
    P6=Gk/4
    for n,P,r in [('4',P4,4),('5',P5,5),('6',P6,6)]:
        ck('spectral_projector_idempotent',P*P==P)
        ck('spectral_projector_rank',P.trace()==r and P.rank()==r)
    ck('three_projectors_complete',P4+P5+P6==I)
    ck('three_projectors_pairwise_orthogonal',P4*P5==sp.zeros(15) and P4*P6==sp.zeros(15) and P5*P6==sp.zeros(15))
    ck('Gram_S_formula',Gs==25*P4+4*P5)
    ck('Gram_K_formula',Gk==4*P6)
    # Direct graph Laplacian and Hodge verification, no irreducibility assumption
    boundary=sp.zeros(10,15)
    for e,(a,b) in enumerate(edges):
        boundary[verts.index(a),e]=1
        boundary[verts.index(b),e]=-1
    ck('graph_hodge_exact_inclusion',boundary*P6==sp.zeros(10,15) and boundary*P4==boundary*P4 and boundary*P5==boundary*P5)
    ck('graph_hodge_cycle_projector',boundary.nullspace().__len__()==6 and (I-boundary.T*(boundary*boundary.T).pinv()*boundary)==P6)
    C=P4/5+P5/2+P6/2
    U=[sum((C[f,e]*(S[f]+K[f]) for f in range(15)),sp.zeros(5)) for e in range(15)]
    GU=sp.Matrix(15,15,lambda i,j:tr(U[i],U[j]))
    ck('U_is_orthonormal_exact',GU==I)
    for T in U:
        ck('U_in_sl_of_standard_V',T*ones==sp.zeros(5,1) and T.T*ones==sp.zeros(5,1) and T.trace()==0)
    # Each 5x5 matrix on 1^perp has trace zero -> sl4 dimension 15, U spans
    # Check signed S5 equivariance on generators, and then all 120 permutations.
    def signed_edge_action(p,e):
        a,b=edges[e]
        pa=tuple(sorted(p[i] for i in a)); pb=tuple(sorted(p[i] for i in b))
        if (pa,pb) in edges:return edges.index((pa,pb)),1
        return edges.index((pb,pa)),-1
    for p in itertools.permutations(range(5)):
        P=sp.zeros(5,5)
        for j,i in enumerate(p):P[i,j]=1
        for e in range(15):
            target,sgn=signed_edge_action(p,e)
            ck('full_S5_signed_equivariance',P*U[e]*P.T==sgn*U[target])
    # Real coefficient bank of the A5-standard representation.
    group=[p for p in itertools.permutations(range(5)) if perm_sign(p)==1]
    ck('A5_count',len(group)==60)
    # Coefficient values b_e(g)=sum_j U_e[g(j),j] (per-lift raw)
    vals=sp.Matrix(60,15,lambda ig,e:sum(U[e][group[ig][j],j] for j in range(5)))
    ck('2I_lift_coeff_orthonormal',2*vals.T*vals==30*I)
    H=vals*vals.T
    class_count=Counter()
    for i,g in enumerate(group):
        ordg=1; gp=g
        while gp!=tuple(range(5)):
            gp=compose(gp,g);ordg+=1
        class_count[ordg]+=2
        for j,h in enumerate(group):
            numerator=4*ch4(compose(inv(g),h))-ch4(g)*ch4(h)
            ck('Pi15_every_A5_pair',H[i,j]==sp.Rational(numerator,4))
        c=ch4(g)
        diag=sp.Rational(16-c*c,120)
        ck('Pi15_exact_strata',H[i,i]/30==diag)
    ck('2I_lift_class_counts',class_count==Counter({1:2,2:30,3:40,5:48}))
    ck('rank15_trace',2*sum(H[i,i]/30 for i in range(60))==15)
    details['s2s_eigenmultiplicities']={'25':4,'4':5,'0':6}
    details['k2k_eigenmultiplicities']={'4':6,'0':9}
    details['twoI_lift_conjugacy_order_counts']=dict(class_count)
    details['Pi15_leverage']={'order1':'0','order2':'2/15','order3':'1/8','order5':'1/8'}
    details['matched_claims']=['p1:thm:v339-petersen-sl4-isometry','p1:cor:v339-petersen-matrix-symmetric-pair','p1:thm:v339-petersen-projector-strata']
    details['sign_action']='full S5 signed edge cochains (checked 120 permutations x 15 basis matrices)'
    details['normalization']='uncorrected sum over 120 lift elements; coefficient 1/sqrt(30)'
    result={'status':'PASS','check_families':dict(checks),'total_exact_assertions':sum(checks.values()),'details':details,'sympy_version':sp.__version__,'scope':'finite 15-edge 120-element 2I coefficient bank; no physical occurrence claim'}
    dest=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/mnt/data/p1_work/Paper1B-PetersenSL4ExactProof-v1_1.json')
    dest.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result,indent=2,sort_keys=True))

if __name__=='__main__':main()
