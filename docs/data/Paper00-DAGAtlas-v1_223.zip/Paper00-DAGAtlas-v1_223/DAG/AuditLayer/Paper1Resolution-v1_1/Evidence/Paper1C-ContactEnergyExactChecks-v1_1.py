#!/usr/bin/env python3
"""Independent exact contact-orientation and radius-scaled YM/Chern-Simons check.
Uses rational moments of a coordinate squared on a normalized S^3.
"""
import json,sys
from fractions import Fraction as F
from collections import Counter
from math import comb
from pathlib import Path
checks=Counter()
def check(b,n):
 checks[n]+=1
 if not b:raise AssertionError((n,checks[n]))
# q1 is a single coordinate of uniform S^3; beta(1/2,3/2) moment.
def q2moment(k):
 p=F(1)
 for i in range(k):p*=F(2*i+1,2*i+4)
 return p
def hmom(k):
 return sum(F(comb(k,j))*(-F(1,4))**(k-j)*q2moment(j) for j in range(k+1))
expect=[F(1),F(0),F(1,16),F(1,64),F(3,256)]
for k,z in enumerate(expect):check(hmom(k)==z,'S3_coordinate_moments')
# Laplace eigenvalue 8/R^2, with dimensionless u=epsilon h. For all positive radius R.
# An intrinsic angular gradient is g1 and R^2*|grad_gR h|^2=|grad_g1 h|^2.
check(8*hmom(2)==F(1,2),'radius_independent_integrated_gradient')
quadratic=F(1,6)*8*hmom(2)-F(1,2)*hmom(2)
quartic=F(1,4)*hmom(4)
cs_cubic=-F(1,4)*hmom(3)
check(quadratic==F(5,96),'YM_quadratic_5_over_96')
check(quartic==F(3,1024),'YM_quartic_3_over_1024')
check(cs_cubic==-F(1,256),'CS_cubic_minus_1_over_256')
# In H*(S^2xS^2;Z), x^2=y^2=0, int xy=orientation sign.
# For arbitrary integral a,b, c=b*x-a*y. Its square = -2ab x*y.
for a in range(-3,4):
 for b in range(-3,4):
  c2=-2*a*b
  c2_opposite=-2*(-a)*(-b)
  check(c2==c2_opposite,'fibre_orientation_Chern_square_invariance')
  check((c2!=0)==(a*b!=0),'contact_iff_ab_nonzero')
# Since orientation(T')=-orientation(T), eta'=-eta, d eta'=-d eta,
# integral_T' eta'(d eta')^2 = integral_T eta(d eta)^2.
for eps in [-1,1]:
 check((-1)*(-1)*(+1)*eps==eps, 'fibre_first_integral_orientation_invariance')
result={'status':'PASS','claim_labels':['p1b:thm:g17-contact','p1b:thm:v2217-nonconstant-cartan-dirac'],'exact_assertions':sum(checks.values()),'check_families':dict(sorted(checks.items())),'moments_h':list(map(str,expect)), 'energy':{'constant':'1/4','quadratic':'5/96','quartic':'3/1024'},'chern_simons':{'constant':'1/2','cubic':'-1/256'},'scope':'Exact cohomology orientation and unit-vs-radius metric normalizations; no independent reproof of Dirac perturbation formula or other downstream results.'}
out=Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).with_suffix('.json'))
out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(out,result['exact_assertions'],'PASS')
