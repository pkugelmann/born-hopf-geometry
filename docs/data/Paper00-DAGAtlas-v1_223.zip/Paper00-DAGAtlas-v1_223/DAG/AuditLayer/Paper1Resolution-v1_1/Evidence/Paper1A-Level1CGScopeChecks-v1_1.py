#!/usr/bin/env python3
"""Exact independent Spin(4) SU(2)xSU(2) finite-level fusion certificate.
Run: python Paper1A-Level1CGScopeChecks-v1_1.py [output_path]
Only tests mathematical support and a nonassociativity obstruction; no physical selector.
"""
import json, sys
from collections import Counter
from fractions import Fraction
from pathlib import Path
checks=Counter()
def check(test, name):
    checks[name]+=1
    if not test: raise AssertionError(f'{name} failed at {checks[name]}')
# Highest weights a=2jL, b=2jR, m=1 iff a+b<=2.
support=[(a,b) for a in range(3) for b in range(3-a)]
check(len(support)==6,'six_irreducible_types')
check(set(support)=={(0,0),(1,0),(0,1),(1,1),(2,0),(0,2)},'exact_sector_census')
check(sum((a+1)*(b+1) for a,b in support)==15,'level_one_dimension15')
check(sum(((a+1)*(b+1))**2 for a,b in support)==43,'block_algebra_dimension43')
def su2(a,b): return range(abs(a-b),a+b+1,2)
def tensor(A,B):
    return Counter((l,r) for l in su2(A[0],B[0]) for r in su2(A[1],B[1]))
def fusion(X,Y):
    out=Counter()
    for A,ca in X.items():
        for B,cb in Y.items():
            for C,m in tensor(A,B).items():
                if sum(C)<=2: out[C]+=ca*cb*m
    return out
X=Counter({(1,0):1}); Y=Counter({(1,1):1})
check(tensor((1,0),(1,1))==Counter({(0,1):1,(2,1):1}), 'exterior_CG_output')
check(fusion(X,Y)==Counter({(0,1):1}),'projected_interior_CG_output')
for A in support:
 for B in support:
    check(all(sum(C)<=2 for C in fusion(Counter({A:1}), Counter({B:1}))), 'all_36_projected_products_inside_support')
A=Counter({(2,0):1}); B=Counter({(1,0):1})
check(fusion(A,A)==Counter({(0,0):1,(2,0):1}),'AA_decomposition')
check(fusion(A,B)==B,'AB_decomposition')
left=fusion(fusion(A,A),B); right=fusion(A,fusion(A,B))
check(left==Counter({(1,0):2}),'left_parenthesization')
check(right==Counter({(1,0):1}),'right_parenthesization')
check(left!=right,'nonassociativity_adversarial_witness')
result={'status':'PASS','claim_labels':['p1:cor:H1-structure','p1:def:spin4-truncation'],'scope':'full level-one support census and targeted counterexample; mathematical representation ring, not physical composition','exact_assertions':sum(checks.values()),'check_families':dict(sorted(checks.items())),'witness':{'A_highest_weights':[2,0],'B_highest_weights':[1,0],'left':{'(1,0)':2},'right':{'(1,0)':1}},'sector_types':[list(x) for x in support]}
out=Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).with_suffix('.json'))
out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(out, result['exact_assertions'],'PASS')
