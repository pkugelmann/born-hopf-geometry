#!/usr/bin/env python3
"""Independent finite exact coset / Reye / signed Petersen audit of I-B v340.
Reconstructs all 200 C3 cosets in A5, the 36x70 and 36x80 matrices,
25x30 axis quotient, dodecahedral distance-two witness, Hodge polynomials.
"""
import itertools,json,sys
from collections import Counter
from pathlib import Path
import sympy as sp
import networkx as nx
C=Counter();m5=tuple(range(5))
def ck(k,v):
 C[k]+=1
 if not bool(v):raise AssertionError(f'{k} #{C[k]}')
def sign(p):return (-1)**sum(p[i]>p[j] for i in range(5) for j in range(i+1,5))
def mul(p,q):return tuple(p[q[i]] for i in range(5))
def inv(p):return tuple(p.index(i) for i in range(5))
def power(p,k):
 v=m5
 for i in range(k):v=mul(p,v)
 return v
def order(p):
 for k in range(1,6):
  if power(p,k)==m5:return k
 raise ValueError

def main():
 G=[p for p in itertools.permutations(range(5)) if sign(p)==1]
 ck('order_class_counts',Counter(order(p) for p in G)=={1:1,2:15,3:20,5:24})
 U=[p for p in G if order(p) in (1,2,3)]
 ck('U_cardinality',len(U)==36)
 # 10 C3 subgroups, 20 left cosets each.
 c3={tuple(sorted([m5,g,power(g,2)])) for g in G if order(g)==3}
 ck('subgroup_count',len(c3)==10)
 cosets={tuple(sorted(mul(x,h) for h in H)) for H in c3 for x in G}
 ck('200_cyclic_cosets',len(cosets)==200)
 patterns=Counter(tuple(sorted(order(p) for p in cos)) for cos in cosets)
 ck('all_coset_order_types',patterns=={(1,3,3):10,(2,3,3):60,(2,2,2):10,(2,5,5):60,(3,5,5):60})
 contained=[cos for cos in sorted(cosets) if set(cos).issubset(U)]
 ck('induced_80',len(contained)==80)
 cores=[{g for g in G if g[i]==i} for i in range(5)]
 ck('five_A4_cores',all(len(x)==12 for x in cores))
 core70=[cos for cos in contained if any(set(cos).issubset(H) for H in cores)]
 ck('core_reye_70',len(core70)==70 and Counter(tuple(sorted(order(p) for p in cos)) for cos in core70)=={(1,3,3):10,(2,3,3):60})
 extra=[cos for cos in contained if cos not in core70]
 ck('ten_extra_Klein',len(extra)==10 and all(tuple(sorted(order(p) for p in cos))==(2,2,2) for cos in extra))
 R70=sp.Matrix(36,70,lambda i,j:int(U[i] in core70[j]))
 R80=sp.Matrix(36,80,lambda i,j:int(U[i] in contained[j]))
 ck('reye_incidence_col3',all(sum(R70[i,j] for i in range(36))==3 for j in range(70)))
 ck('reye_rank35',R70.rank()==35)
 ck('reye_rank36',R80.rank()==36)
 weights=sp.Matrix([-2 if order(g) in(1,2) else 1 for g in U])
 ck('reye_signed_nullmode',weights.T*R70==sp.zeros(1,70))
 degrees=Counter((order(U[i]),int(sum(R70[i,j] for j in range(70)))) for i in range(36))
 ck('reye_degree_counts',degrees=={(1,10):1,(2,4):15,(3,7):20})
 # Explicit Petersen edge identification of involutions by their two 2-cycles.
 labels=list(itertools.combinations(range(5),2))
 p_edges=[(A,B) for A,B in itertools.combinations(labels,2) if set(A).isdisjoint(B)]
 inv2=[p for p in G if order(p)==2]
 def inv_edge(g):
  two=sorted(tuple(sorted((i,g[i]))) for i in range(5) if i<g[i])
  return tuple(two)
 ck('involutions_petersen_edges',set(map(inv_edge,inv2))==set(p_edges))
 # Klein fours are 3 incident edges at one of 10 Petersen vertices.
 for cos in extra:
  E=[set(inv_edge(g)) for g in cos]
  shared=set.intersection(*E)
  ck('ten_missing_petersen_stars',len(shared)==1)
 ck('10_distinct_star_centres',len({next(iter(set.intersection(*(set(inv_edge(g)) for g in cos)))) for cos in extra})==10)
 # Inversion identified axes: 20 three-cycles give 10 two-subset labels.
 cyc3=[g for g in U if order(g)==3]
 axes={tuple(sorted([g,inv(g)])) for g in cyc3}
 ck('ten_order3_axes',len(axes)==10)
 def axis(g):return tuple(i for i in range(5) if g[i]==i)
 ck('axis_pair_labels',set(axis(g) for g in cyc3)==set(labels))
 mixed=[cos for cos in core70 if tuple(sorted(order(g) for g in cos))==(2,3,3)]
 projected=[]
 for cos in mixed:
  a=next(x for x in cos if order(x)==2)
  cyc=[x for x in cos if order(x)==3]
  projected.append(tuple(sorted([('e',inv_edge(a)),('v',axis(cyc[0])),('v',axis(cyc[1]))])))
 pure=set(projected)
 ck('30_axis_quotient',len(pure)==30)
 ck('each_projected_double',Counter(projected)==Counter({x:2 for x in pure}))
 rowlabels=[('e',edge) for edge in p_edges]+[('v',a) for a in labels]
 cols=sorted(pure)
 R25=sp.Matrix(25,30,lambda i,j:int(rowlabels[i] in cols[j]))
 ck('axis_quotient_rank24',R25.rank()==24)
 wz=sp.Matrix([-2]*15+[1]*10)
 ck('axis_quotient_signed_null',wz.T*R25==sp.zeros(1,30))
 # 20 distinct cyc3 points and 60 mixed planes yield 20x60 distance-two graph.
 disttwo=nx.Graph();disttwo.add_nodes_from(cyc3)
 for cos in mixed:
  c=[g for g in cos if order(g)==3]
  disttwo.add_edge(*c)
 ck('reye_d2_simple_60',disttwo.number_of_edges()==60)
 ck('reye_d2_six_regular',all(d==6 for n,d in disttwo.degree()))
 # The actual SU(2) positive-real order-six lift of any order-three axis has
 # scalar part +1/2.  Its product is pure imaginary iff the projective
 # product has order two, giving 1/4-(3/4)<u_r,u_s>=0 and dot=1/3.
 involutive_pairs={frozenset((g,h)) for g,h in itertools.combinations(cyc3,2) if order(mul(g,h))==2}
 mixed_pairs={frozenset((g,h)) for g,h in disttwo.edges}
 ck('geometric_positive_real_lift_dot_third_all_pairs',involutive_pairs==mixed_pairs and len(mixed_pairs)==60)
 # Native graph GP(10,2), two ten-cycles sheet notation.
 gp=nx.Graph();gp.add_nodes_from(range(20))
 for i in range(10):gp.add_edge(i,(i+1)%10);gp.add_edge(i,10+i);gp.add_edge(10+i,10+(i+2)%10)
 ck('GP10_2_dodecahedral',nx.is_connected(gp) and gp.number_of_edges()==30 and all(d==3 for n,d in gp.degree()))
 d2=nx.Graph();d2.add_nodes_from(gp.nodes)
 for i in gp.nodes:
  for j in gp.nodes:
   if i<j and nx.shortest_path_length(gp,i,j)==2:d2.add_edge(i,j)
 ck('GP10_2_d2_has60',d2.number_of_edges()==60 and all(d==6 for n,d in d2.degree()))
 witness=next(nx.algorithms.isomorphism.GraphMatcher(disttwo,d2).isomorphisms_iter(),None)
 ck('explicit_isomorphism_reye_dist2',witness is not None and len(witness)==20)
 ck('all60_witness_edges',all(d2.has_edge(witness[u],witness[v]) for u,v in disttwo.edges))
 # Signed Petersen Hodge operator via epsilon determinant.
 def permpar(seq):return (-1)**sum(seq[i]>seq[j] for i in range(5) for j in range(i+1,5))
 A=sp.Matrix(10,10,lambda i,j:int(set(labels[i]).isdisjoint(labels[j])))
 H=sp.Matrix(10,10,lambda i,j:permpar(list(labels[i])+list(labels[j])+list(set(range(5))-set(labels[i])-set(labels[j]))) if set(labels[i]).isdisjoint(labels[j]) else 0)
 ck('Hodge_signed_petersen',all(H[i,j] in(-1,0,1) and abs(H[i,j])==A[i,j] for i in range(10) for j in range(10)) and H==H.T)
 ck('Hodge_cubic',H**3==5*H)
 ck('Hodge_spectrum',H.rank()==6 and H.trace()==0)
 T=H**2-3*sp.eye(10)
 ck('T_polynomial',T*T+T==6*sp.eye(10) and H*T==2*H and T*H==2*H)
 ck('T_eigen',T.trace()==0 and T.rank()==10)
 ck('T_even_under_sign',(-H)**2-3*sp.eye(10)==T)
 record={'status':'PASS','exact_assertions':sum(C.values()),'checks':dict(C),'pattern_counts':{str(k):v for k,v in patterns.items()},
         'reye_degree_counts':{str(k):v for k,v in degrees.items()},
         'witness_mapping':{str(tuple(g)):witness[g] for g in sorted(witness)},
         'claim_labels':['p1:thm:v340-reye-70-80','p1:cor:v340-reye-dodeca-second-neighbour'],
         'scope':'all 200 abstract A5 order-three cosets, exact rational incidence ranks; abstract GP10,2 graph isomorphism, not independently realized metric axes'}
 output=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/mnt/data/p1_work/Paper1B-ReyeExactProof-v1_1.json')
 output.write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
 print(json.dumps(record,sort_keys=True,indent=2))
if __name__=='__main__':main()
