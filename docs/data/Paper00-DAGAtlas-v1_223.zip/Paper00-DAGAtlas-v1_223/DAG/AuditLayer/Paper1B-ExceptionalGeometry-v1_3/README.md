# Paper I-B Exceptional Geometry — current audit layer v1_2

Authoritative source: `Paper1B-ExceptionalGeometry-v1_9.tex` (`c6f002bdda57c1879891b6b1995a8d78ccbed4e7ad035f42028527eedc084b7e`). 483 audited formal statements, with E3 statuses scoped by ledger. Historical v1.7 batch evidence is retained verbatim; source-level erratum in v1.8 repaired in v1.9.

Canonical live alias: `BH-IBX-EXG::<source-label>`; historical Paper I-B/M8 audit remains separate. `EV-0001`–`EV-0006` need portable certificate replays, and `EV-0009` retains unverified uniqueness/intertwiner scope. No physical decay/source realization licensed.
