# Paper I-B — Rigorous Verification DAG Audit, Batch 6 (v1_2)

**Authoritative source:** `Paper1B-ExceptionalGeometry-v1_7.tex`, SHA-256 `67ae02d9843853b6396f339eb4ec7184abd9258d5d6b8335bd757c929b5fa89b`. **Source lines:** 13349–16963 inclusive; 97 formal statements (79 substantive and 18 remarks). **Protocol:** RigorousVerificationDAGWorkProtocol v2.4. Original papers ZIP, canonical DAG ZIP, and audit ZIP are read-only in this batch.

## Result and cumulative status

| Measure | Batch 6 | Cumulative |
|---|---:|---:|
| Verified at the stated mathematical scope | 47 | 283 |
| Definitions/remarks formalized | 18 | 92 |
| Source proof reproduced, independent certification still pending | 32 | 38 |
| **Formal claims examined** | **97** | **413/480 (86.04%)** |
| Independent exact controls | **1120 pass; 0 fail** | — |
| Issues | 5 new evidence roots | 14 open total |

**Important standard:** `VERIFIED` is tied either to a claim-matched independent exact E3 certificate or an explicitly recorded independent analytic derivation. `REPRODUCED` means the source proof and its domain were examined but not upgraded on source authority alone. An unresolved E3 is not a demonstrated theorem failure. Remarks are formalized, not silently certified as independent theorems.

## Independent exact verification and scope

The separate executable rebuilds the finite inputs rather than merely replaying supplied proof output. It passes 1120 unique exact checks, including: four Clifford gamma anticommutators and covariance; degree-five Hurwitz cubature; 24-cell adjacency/harmonic Laplacian; exhaustive 23584-state no-dangling face search; cyclic A5 subgroup cosets, 722 projective polygons, signed Petersen Hodge, 70+80 Reye planes and rank 35/36; twisted quintet 25-coefficient Gram; the F40 40-vertex/60-directed-edge/21-cycle group and its exact triple-frame characteristic polynomial; 600-cell 600×120 incidence, TᵀT=20I+5A, rank T=120 mod101; 24-cell 96×96 face-edge Laplacian with mod101 rank 73; exact E8 240-root, orthogonal D4 pair, 3×64 triality orbits and 2240 root triples; 600-cell equitable 24+32+32+32 rows; and E6 27-weight/45-triple cubic support.

The checker also verifies the intrinsic native-word closure dimensions 136 through degree 5 and 137 through degree 6. The **five real Lie-closure dimensions** in `p1:thm:v226-control-lie` are a different assertion and remain pending a full independent commutator-elimination certificate; associative closure must not be substituted for Hamiltonian Lie closure.

**Formal limitation:** The earlier interrupted progress narrative claimed a 25-block chamber reconstruction, but no self-contained executable certificate for that reconstruction is present in the recovered work files. It cannot be carried forward as certified evidence. Source references to two 600-cell chamber partition/split exact scripts are missing from the supplied atlas ZIP. We independently proved the simpler 600-cell chamber–vertex incidence but **did not regenerate the full 25-block U partition, its 600×25 transition identities, or the signed/cubic chamber Fourier spectra**. Those specific claims stay `REPRODUCED`. Exact algebraic implications in their source proofs are distinguished from establishing their antecedent construction.

## Typed source constraints and observed-domain firewall

The 15D intrinsic carrier, 15D Petersen matrix coefficient sector, and 15D 24-cell Bose–Mesner sector are distinct. A mathematical rank of 25, 600 chamber adjacency, a finite register graph, a spinorial 5⊗2 decomposition, or 2240 E8 root-zero triples is not a realized hadronic decay, particle multiplicity or action-owned source. The manuscript generally states these limitations explicitly; they are enforced, not relabeled as failed predictions. The spin-Euler de Rham supertrace, scalar heat trace, tangent Hopf charge and ordinary spin-Dirac spectrum likewise have separate operator owners and normalizations.

## Newly registered evidence issues (not mathematical contradictions)

| Stable ID | First source origin | Exactly what remains unverified |
|---|---|---|
| `BH-IBX-EV-0007` | `Paper1B-ExceptionalGeometry-v1_7.tex:13727` · `p1:prop:v215-sextic-moments` | Regenerate the source H6/H8 exact integral, dual Gram and alias identities in rational arithmetic, or provide a source-matched independent symbolic proof. |
| `BH-IBX-EV-0008` | `Paper1B-ExceptionalGeometry-v1_7.tex:14358` · `p1:thm:v226-control-lie` | Independently reconstruct the five real Lie spans with an exact modular certificate, upper bounds, and source coefficient normalization. |
| `BH-IBX-EV-0009` | `Paper1B-ExceptionalGeometry-v1_7.tex:14636` · `p1:thm:v339-petersen-sl4-isometry` | Give claim-matched exact intertwiners, full finite adjacency and rank/character certificates for the pending source results. |
| `BH-IBX-EV-0010` | `Paper1B-ExceptionalGeometry-v1_7.tex:15780` · `p1:prop:v345-f40-balanced-mirror` | Provide the missing exact predecessor or a self-contained independent rational character/Plücker/rank certificate for each pending F40 comparison. |
| `BH-IBX-EV-0011` | `Paper1B-ExceptionalGeometry-v1_7.tex:16363` · `p1:thm:v366-chamber-transporter-complement` | Supply the two referenced exact scripts or independently reconstruct all 25 24-chamber orbits, verify TᵀU=J−B, TB=J−(I+A)U, UᵀAU=6R, and source-specific 600×120 Fourier/split ranks. |

All issues above are evidence/certificate shortfalls; none currently supplies an exact in-domain counterexample. No verified mathematical contradiction or source-licensed physical decay failure was established. The previous nine issue IDs remain unchanged and OPEN; these are not treated as newly found mathematical failures.

## Nine carried issue IDs

- `BH-IBX-DAG-0001` (DAG_COVERAGE): Distinct manuscript identities must have distinct audit provenance; past M8 Geometry coverage does not count toward current Exceptional Geometry coverage.
- `BH-IBX-DAG-0002` (DAG_COVERAGE): Every current exceptional-geometry claim must have a current-source owner/anchor and typed edge; current batch has 18 displaced Paper1A owners, 28 absent nodes.
- `BH-IBX-EV-0001` (MISSING_EVIDENCE): Independent exact cycle-frame projector diagonalization and orientation-resolved complementary-flux identities over the source coefficient field.
- `BH-IBX-EV-0002` (MISSING_EVIDENCE): Independent exact Q(sqrt5) finite-coordinate certificate of all 50-vertex induced adjacencies and midpoint/quotient identifications.
- `BH-IBX-EV-0003` (MISSING_EVIDENCE): Independent exact quaternion membership, Q8 incidence, and 15-channel angular/distance orbit partition, including label-parity distinction.
- `BH-IBX-EV-0004` (MISSING_EVIDENCE): Independent exact rank/orthogonality certificate for the 20-dimensional tangent F/M sequence and its D3-equivariance, not just full-rank floating-point tests.
- `BH-IBX-EV-0005` (MISSING_EVIDENCE): Independent exact Q(sqrt5) proof of both five-root operator sum identities, especially the source-side C_m^T C_m identity.
- `BH-IBX-EV-0006` (MISSING_EVIDENCE): Independent exact-field 15x15 tensor Gram identity and invertibility certificate.
- `BH-IBX-SRC-0001` (DAG_COVERAGE): The paper-specific attribution of the present trimer construction must match its owner in the authoritative current source.

## Canonical DAG source coverage

This batch matches `70` historical-owner source nodes, has `27` formal statements absent from the current canonical node list, and `0` nodes genuinely owned by the current source. Across batches 1–6 the canonical coverage mismatch totals **325 historical-owner** and **88 not-yet-canonical** matches, tracked under `BH-IBX-DAG-0002` rather than mistaken for source proof errors.

Every one of the 97 formal source statements is frozen with its exact printed text, proof locator (when supplied), claim ID, E0/E1/E3/E4 evidence, source-label references and historical-owner matches in the JSON ledger. The current batch has **19** conservatively selected material source proof-use witnesses and **18** retained candidates/citation links; neither is written into the canonical ZIP before the last batch. No source edits occurred.

## Source-by-source disposition (97 formal objects)

| Source lines | Formal claim ID | Result | E3 basis |
|---:|---|---|---|
| 13393–13407 | `p1:prop:protected-coordinate-covariance` | `VERIFIED` | 24 exact checks |
| 13433–13460 | `p1:prop:v2203-euler-spin-lift` | `VERIFIED` | independent analytic route |
| 13476–13490 | `p1:thm:v2203-projector-euler` | `VERIFIED` | independent analytic route |
| 13500–13513 | `p1:cor:v2203-euler-degree-transgression` | `VERIFIED` | independent analytic route |
| 13527–13549 | `p1:thm:v2203-weighted-euler-work` | `VERIFIED` | independent analytic route |
| 13572–13586 | `p1:cor:v2203-conformal-weight-leaf` | `VERIFIED` | independent analytic route |
| 13595–13616 | `p1:thm:v2203-lift-transgression` | `VERIFIED` | independent analytic route |
| 13627–13638 | `p1:cor:v2203-euler-homothety` | `VERIFIED` | independent analytic route |
| 13647–13657 | `p1:prop:v2203-euler-spectral-owner` | `VERIFIED` | independent analytic route |
| 13666–13687 | `p1:cor:v2203-tangent-charge-gap` | `VERIFIED` | independent analytic route |
| 13703–13713 | `p1:rem:v2203-euler-physical-scope` | `FORMALIZED` | source/scope only |
| 13727–13758 | `p1:prop:v215-sextic-moments` | `REPRODUCED` | source/scope only |
| 13801–13819 | `p1:prop:v215-degree-six-kernels` | `VERIFIED` | independent analytic route |
| 13831–13861 | `p1:prop:v215-eight-alias` | `REPRODUCED` | source/scope only |
| 13886–13906 | `p1:thm:v215-odd-profile-spectral-parity` | `VERIFIED` | independent analytic route |
| 13921–13971 | `p1:thm:v215-closure-return` | `VERIFIED` | 12 exact checks |
| 14017–14030 | `p1:cor:v215-projected-heat-trace` | `VERIFIED` | independent analytic route |
| 14038–14071 | `p1:prop:v215-higher-joint-dependencies` | `VERIFIED` | independent analytic route |
| 14089–14099 | `Paper1B-remark-14089` | `FORMALIZED` | source/scope only |
| 14129–14137 | `p1:thm:v226-coordinate-only` | `VERIFIED` | 2 exact checks |
| 14163–14179 | `p1:thm:v226-rotations` | `VERIFIED` | independent analytic route |
| 14205–14228 | `p1:thm:v226-chirality` | `VERIFIED` | 7 exact checks |
| 14282–14291 | `p1a:corollary:atlas-exact-scope-of-the-reconstruction-001f1a9` | `VERIFIED` | independent analytic route |
| 14295–14301 | `p1:thm:v226-tomography` | `VERIFIED` | independent analytic route |
| 14338–14349 | `Paper1B-remark-14338` | `FORMALIZED` | source/scope only |
| 14358–14375 | `p1:thm:v226-control-lie` | `REPRODUCED` | source/scope only |
| 14413–14421 | `Paper1B-remark-14413` | `FORMALIZED` | source/scope only |
| 14423–14432 | `p1:cor:v226-native-inner-controls` | `REPRODUCED` | source/scope only |
| 14448–14455 | `p1:cor:v229-common-frame-overlap` | `VERIFIED` | independent analytic route |
| 14475–14495 | `p1:thm:v338-petersen-tight-frame` | `VERIFIED` | 3 exact checks |
| 14506–14524 | `p1:thm:v338-petersen-120-strata` | `VERIFIED` | 4 exact checks |
| 14535–14568 | `p1:thm:v338-signed-petersen-hodge` | `VERIFIED` | 2 exact checks |
| 14579–14585 | `Paper1B-remark-14579` | `FORMALIZED` | source/scope only |
| 14599–14624 | `p1:prop:v339-incidence-rank15-contrast` | `VERIFIED` | 3 exact checks |
| 14636–14667 | `p1:thm:v339-petersen-sl4-isometry` | `REPRODUCED` | source/scope only |
| 14691–14709 | `p1:cor:v339-petersen-matrix-symmetric-pair` | `REPRODUCED` | source/scope only |
| 14711–14730 | `p1:thm:v339-petersen-projector-strata` | `REPRODUCED` | source/scope only |
| 14745–14759 | `p1:rem:v339-three-fifteens-firewall` | `FORMALIZED` | source/scope only |
| 14773–14795 | `p1:thm:v340-cyclic-coset-design` | `VERIFIED` | 12 exact checks |
| 14807–14835 | `p1:thm:v340-incidence-character-projectors` | `VERIFIED` | 4 exact checks |
| 14847–14869 | `p1:prop:v340-transporter-hexagon-intersection` | `VERIFIED` | 25 exact checks |
| 14889–14926 | `p1:thm:v340-reye-70-80` | `VERIFIED` | 45 exact checks |
| 14954–14980 | `p1:cor:v340-reye-dodeca-second-neighbour` | `REPRODUCED` | source/scope only |
| 14999–15008 | `p1:rem:v340-reye-angle-firewall` | `FORMALIZED` | source/scope only |
| 15027–15067 | `p1:thm:v341-coset-gram-hodge` | `VERIFIED` | 58 exact checks |
| 15091–15118 | `p1:cor:v341-coset-pi15` | `VERIFIED` | independent analytic route |
| 15140–15180 | `p1:thm:v341-desargues-rp2-parity` | `REPRODUCED` | source/scope only |
| 15207–15230 | `p1:prop:v341-walk-kernel-no-petersen-isomorphism` | `REPRODUCED` | source/scope only |
| 15246–15257 | `p1:rem:v341-reye-compatibility` | `FORMALIZED` | source/scope only |
| 15279–15321 | `p1:thm:v342-three-cycle-petersen-overlap` | `REPRODUCED` | source/scope only |
| 15338–15372 | `p1:thm:v342-triangle-petersen-cycle-isometry` | `REPRODUCED` | source/scope only |
| 15391–15433 | `p1:thm:v342-class-frame-three-cycle-tomography` | `REPRODUCED` | source/scope only |
| 15451–15468 | `p1:thm:v342-minimal-path-lie-generators` | `REPRODUCED` | source/scope only |
| 15485–15502 | `p1:rem:v342-class-frame-observable-firewall` | `FORMALIZED` | source/scope only |
| 15507–15533 | `p1:prop:v343-fivefold-signed-contrast` | `REPRODUCED` | source/scope only |
| 15547–15554 | `p1:rem:v343-fivefold-class-scope` | `FORMALIZED` | source/scope only |
| 15569–15578 | `p1:thm:v344-induced-hurwitz-quintet` | `VERIFIED` | 25 exact checks |
| 15593–15624 | `p1:thm:v344-twisted-25-gram` | `VERIFIED` | 54 exact checks |
| 15637–15657 | `p1:prop:v344-petersen-quintet-intertwiner` | `VERIFIED` | 12 exact checks |
| 15669–15676 | `p1:prop:v344-hurwitz-edge-eight-orbits` | `VERIFIED` | 1 exact checks |
| 15684–15692 | `p1:rem:v344-twisted-physical-scope` | `FORMALIZED` | source/scope only |
| 15709–15736 | `p1:thm:v345-f40-edge-regular` | `VERIFIED` | 151 exact checks |
| 15753–15771 | `p1:thm:v345-f40-triple-frame` | `VERIFIED` | 9 exact checks |
| 15780–15811 | `p1:prop:v345-f40-balanced-mirror` | `REPRODUCED` | 2 exact checks |
| 15821–15828 | `p1:rem:v345-f40-source-firewall` | `FORMALIZED` | source/scope only |
| 15842–15864 | `p1:thm:v349-f40-minimal-quintet` | `REPRODUCED` | source/scope only |
| 15879–15895 | `p1:prop:v349-f40-reduced-frame` | `REPRODUCED` | source/scope only |
| 15910–15929 | `p1:thm:v349-f40-mirror-gluing` | `REPRODUCED` | source/scope only |
| 15945–15972 | `p1:thm:v349-twisted25-spin2-lift` | `REPRODUCED` | source/scope only |
| 15989–16018 | `p1:thm:v349-twisted25-vertex-defect` | `REPRODUCED` | source/scope only |
| 16033–16043 | `p1:rem:v349-mathematical-physical-boundary` | `FORMALIZED` | source/scope only |
| 16056–16075 | `p1:thm:v350-hurwitz-five-design` | `VERIFIED` | 127 exact checks |
| 16088–16107 | `p1:thm:v350-hurwitz-scalar-laplacian` | `VERIFIED` | 101 exact checks |
| 16129–16138 | `p1:rem:v350-hurwitz-spectral-domain` | `FORMALIZED` | source/scope only |
| 16145–16156 | `p1:thm:v356-hurwitz-minimal-faces` | `VERIFIED` | 29 exact checks |
| 16184–16192 | `p1:prop:v356-hurwitz-dual-cuts` | `VERIFIED` | independent analytic route |
| 16212–16220 | `p1:rem:v356-no-face-action-selection` | `FORMALIZED` | source/scope only |
| 16235–16246 | `p1:thm:v365-600-cell-incidence` | `VERIFIED` | 246 exact checks |
| 16261–16277 | `p1:thm:v365-hurwitz-face-laplacian` | `VERIFIED` | 5 exact checks |
| 16298–16314 | `p1:prop:v365-cubic-algebra-color` | `VERIFIED` | independent analytic route |
| 16329–16346 | `p1:rem:v365-chamber-register-candidate` | `FORMALIZED` | source/scope only |
| 16363–16385 | `p1:thm:v366-chamber-transporter-complement` | `REPRODUCED` | source/scope only |
| 16409–16423 | `p1:thm:v366-face-register-identity` | `REPRODUCED` | source/scope only |
| 16437–16465 | `p1:thm:v366-petersen-face-walk` | `REPRODUCED` | source/scope only |
| 16479–16500 | `p1:thm:v366-dual-hurwitz-refinement` | `REPRODUCED` | source/scope only |
| 16514–16531 | `p1:prop:v366-hurwitz-fourier-filters` | `REPRODUCED` | source/scope only |
| 16545–16572 | `p1:thm:v366-signed-cubic-chamber` | `REPRODUCED` | source/scope only |
| 16587–16606 | `p1:thm:v366-600-chamber-representation-ledger` | `REPRODUCED` | source/scope only |
| 16617–16638 | `p1:prop:v366-cross-core-pentagonal-kernel` | `REPRODUCED` | source/scope only |
| 16652–16676 | `p1:prop:v366-twisted-quintet-spinorial-branch` | `REPRODUCED` | source/scope only |
| 16686–16698 | `p1:prop:v366-local-face-permutation` | `REPRODUCED` | source/scope only |
| 16709–16735 | `p1:prop:v366-register-mirror-contrast` | `REPRODUCED` | source/scope only |
| 16750–16763 | `p1:rem:v366-chamber-physical-firewall` | `FORMALIZED` | source/scope only |
| 16787–16808 | `p1:thm:v370-e8-d4-triality` | `VERIFIED` | 21 exact checks |
| 16834–16878 | `p1:thm:v370-e8-shell-chamber` | `VERIFIED` | 123 exact checks |
| 16902–16927 | `p1:prop:v370-e6-cubic-support` | `VERIFIED` | 13 exact checks |
| 16941–16963 | `p1:rem:v370-e8-readout-boundary` | `FORMALIZED` | source/scope only |

## Certificate honesty and next batch

* Independent 1120 tests use finite integer/Fraction/Q(φ) arithmetic and exact SymPy identities; reduction modulo 101 is used only as a nonzero-rank **lower** certificate, combined with a source upper bound where needed. A nonzero modular 120-pivot minor establishes full rank over characteristic zero. The 24-cell face rank 73 has the independent lower modular bound and the upper cellular S³ chain rank argument.
* The unsigned 96×96 edge-face incidence is **not** the 600×120 chamber–vertex incidence; no theorem status is transferred by coincident vocabulary.
* Source-named exact certificates absent from the atlas are recorded as unavailable; a script merely named by Paper I-D is not claimed executed. E8 main finite supports were instead independently reconstructed.
* `p1:rem:v370-e8-readout-boundary` also states that the 1840-triple two-point shadow belongs to Q[A600]. This remark is recorded at source scope but its complete 1840-object shadow has **not** been independently checked; the ledger does not promote it as a signed coefficient theorem.
* Rejected invalid tests: conflating E6 roots with six perpendicular A2 roots; replacing positive/negative F40 directed edges by unordered edges; asserting an occurrence of physical dynamics from finite dimensions; reusing stale Paper I-A source ownership.

**Next batch begins at source line 16964**, with the next formal statement at **16988**. The canonical DAG and consolidated ProofChainAudits ZIP archives are **not exported in Batch 6**; integration, cleanup and version increments are reserved for the final batch per user instruction.

**Machine artifacts:** `Paper1B-ExceptionalGeometryRigorousAuditBatch6Ledger-v1_2.json`; `Paper1B-Batch6-IndependentExactControls-v1_2.json`; `Paper1B-Batch6-IndependentChecks-v1_2.py`.
