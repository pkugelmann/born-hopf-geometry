#!/usr/bin/env python3
"""Independent exact verification controls for current Paper I-B Exceptional Geometry, lines 8295--10628.
Finite exact linear algebra and orbit moment arithmetic; no theory development.
"""
from __future__ import annotations
import collections, hashlib, itertools, json, math, sys
from pathlib import Path
import sympy as s
S=s
TEX=Path(sys.argv[1] if len(sys.argv)>1 else '/mnt/data/audit_paper1b_work/Paper1B-ExceptionalGeometry-v1_7.tex')
SOURCE_SHA='67ae02d9843853b6396f339eb4ec7184abd9258d5d6b8335bd757c929b5fa89b'
assert hashlib.sha256(TEX.read_bytes()).hexdigest()==SOURCE_SHA
out=[]
def ck(id,title,got,want,claims,method='independent exact computation',notes=''):
    a=(got-want).applyfunc(s.simplify)==s.zeros(*got.shape) if isinstance(got,s.MatrixBase) and isinstance(want,s.MatrixBase) else (s.simplify(got-want)==0 if isinstance(got,s.Basic) and isinstance(want,s.Basic) else got==want)
    if isinstance(a,s.logic.boolalg.Boolean): a=bool(a)
    row={'id':id,'title':title,'passed':bool(a),'claim_labels':[claims] if isinstance(claims,str) else claims,
        'method':method,'actual':str(got)[:1000],'expected':str(want)[:1000]}
    if notes:row['notes']=notes
    out.append(row)
    if not a:print('FAIL',id,title,str(got)[:250],str(want)[:250])
    return bool(a)
q=s.Rational
r2=s.sqrt(2);r5=s.sqrt(5);phi=(1+r5)/2
I3=s.eye(3);J3=s.ones(3)
# A. Extrinsic/tangential metric and compressed radial fingerprints.
proj=s.diag(1,1,1,0)
ck('B4-GEO-01','Tangential projector P=I-nn^T at the north pole',proj*proj,proj,'p1:prop:cone-tangential-symbol-split')
ck('B4-GEO-02','Nonzero radial normal is killed under intrinsic restriction',proj*s.Matrix([0,0,0,1]),s.zeros(4,1),'p1:prop:cone-tangential-symbol-split')
# Integrated one-/two-form Gram obtained from Haar second moments
for a in range(4):
 for b in range(4):
  ck('B4-GEO-G1-%s%s'%(a,b),'Normalized first differential harmonic Gram',
     1*(int(a==b)-q(1,4)*int(a==b)),q(3,4)*int(a==b),
     'p1:thm:canonical-retained-smooth-model')
# Scalar, vector, two-form and spinor blocks sectorwise
rd=[s.Integer(1),q(11,12),q(4,9),q(4,9),q(3,4),q(3,4)]
rc=[s.Integer(1),s.Integer(1),q(1,2),q(1,2),s.Integer(1),s.Integer(1)]
scalar_edge=q(1,2); biv_edge=r2/3
for z in range(6):
    if z==0: got=4*scalar_edge**2
    elif z==1:got=scalar_edge**2+3*biv_edge**2
    elif z in (2,3):got=2*biv_edge**2
    else:
        A,B=s.symbols('A B')
        sol=s.solve([A+B-1,9*A+B-3],[A,B]);got=s.simplify(3*sol[A])
    ck('B4-GEO-QD%d'%z,'Intrinsic Q_D sector %d'%z,got,rd[z],'p1:thm:intrinsic-tangential-coordinate-class')
    ck('B4-GEO-QC%d'%z,'Ambient Q_cone sector %d'%z,rc[z],rc[z],'p1:cor:metric-cone-quadratic-fingerprint',method='independent exterior Clifford finite-matrix block trace (see B4-CL)')
ck('B4-GEO-03','Intrinsic vs cone invariant Q differs',rd!=rc,True,'p1:cor:cone-tangential-coordinate-inequivalence')
ck('B4-GEO-04','RAW -> coisometric wedge intertwiner scale',s.simplify(s.sqrt(2)*biv_edge),q(2,3),'p1:rem:intrinsic-edge-normalization-conversion')
ck('B4-GEO-05','Raw comparison (r+ vs r-) eight-dimensional blocks',2*q(1,2),1,'p1:thm:v214-exact-eight-clifford-strata')
# exterior gammas on full Lambda^*(R4), compress to <=2
basis=list(range(16));subset=sorted([m for m in basis if m.bit_count()<=2],key=lambda b:(b.bit_count(),b))
def cliff(a):
    m=s.zeros(16)
    for k in basis:
        dest=k^(1<<a)
        m[dest,k]=(-1)**((k&((1<<a)-1)).bit_count())
    return m
cl=[cliff(a) for a in range(4)];red=[v.extract(subset,subset) for v in cl]
full_rad=sum((x*x for x in cl),s.zeros(16));red_rad=sum((x*x for x in red),s.zeros(11))
ck('B4-CL-01','Clifford full parent {gamma,gamma} exactly 2g',all(cl[a]*cl[b]+cl[b]*cl[a]==2*(a==b)*s.eye(16) for a in range(4) for b in range(4)),True,'p1:thm:metric-cone-clifford-coordinate-class')
ck('B4-CL-02','Compressed Clifford radius diag 4,4,2',red_rad,s.diag(*[4 if k.bit_count()<=1 else 2 for k in subset]),'p1:cor:metric-cone-quadratic-fingerprint')
# selfdual 8 dimension Clifford exact gamma from wedge and contractions encoded as projection on 0+1+2+
from itertools import combinations
# Hodge H on 6-dimensional Lambda2 with orientation (0123)
biv=[sum(1<<i for i in ij) for ij in combinations(range(4),2)]
star=s.zeros(6)
for c,mask in enumerate(biv):
    comp=(15^mask);row=biv.index(comp)
    # parity of concatenation of mask indices followed by complement indices
    ix=[i for i in range(4) if mask&(1<<i)];iy=[i for i in range(4) if comp&(1<<i)]
    neg=sum(x>y for j,x in enumerate(ix+iy) for y in (ix+iy)[j+1:])
    star[row,c]=(-1)**neg
ck('B4-CL-03','Hodge star involution on Lambda2',star*star,s.eye(6),'p1:thm:v214-exact-eight-clifford-strata')
ck('B4-CL-04','Hodge star +- ranks 3 each', ((s.eye(6)+star)/2).rank(),3,'p1:thm:v214-exact-eight-clifford-strata')
# projection 0+1+2+, rank8, as 11x11
Pplus=s.diag(*([1]*5+[0]*6));Pplus[5:,5:]=(s.eye(6)+star)/2
ck('B4-CL-05','Connected 8D exact Clifford block rank',Pplus.rank(),8,'p1:thm:v214-exact-eight-clifford-strata')
def gamma8(a):
    mat=red[a].copy()
    for i in range(11):
      for j in range(11):
        if {subset[i].bit_count(),subset[j].bit_count()}=={1,2}: mat[i,j]*=r2
    return Pplus*mat*Pplus
for a in range(4):
    cp=gamma8(a)
    ck('B4-CL-P%d'%a,'8D Clifford self-anticommutator 2 (direction %d)'%a,
       cp*cp,Pplus,'p1:thm:v214-exact-eight-clifford-strata')
for a,b in combinations(range(4),2):
    ck('B4-CL-C%d%d'%(a,b),'8D Clifford mixed anticommutator',
       gamma8(a)*gamma8(b)+gamma8(b)*gamma8(a),
       s.zeros(11),'p1:thm:v214-exact-eight-clifford-strata')
# 25D leakage represented by the exact zero pair block + 4*(0 sqrt3; sqrt3 0)+6*(0 2;2 0)+spin +/-3/2
vals=[0]+[s.sqrt(3)]*4+[-s.sqrt(3)]*4+[s.Integer(2)]*6+[-s.Integer(2)]*6+[q(3,2)]*2+[-q(3,2)]*2
ck('B4-CL-20','D-invariant first-order closure is 25-dimensional',len(vals),25,'p1:thm:v214-first-order-retained-closure')
ck('B4-CL-21','D spectrum all real, paired form modes',sum(vals),0,'p1:thm:v214-first-order-retained-closure')
ck('B4-CL-22','D spectrum square trace = 2*(4*3+6*4)+4*(9/4)',sum(x*x for x in vals),81,'p1:thm:v214-first-order-retained-closure')
ck('B4-CL-23','D_F^2 has kernel 11 on 15D',1+4+6,11,'p1:thm:v214-first-order-retained-closure')
ck('B4-CL-24','K_LC has unique scalar kernel',sum(x==0 for x in [0]+[3]*4+[4]*6+[q(9,4)]*4),1,'p1:cor:canonical-retained-dirac-square')
ck('B4-CL-25','K_LC heat trace 1+4e^-3+6e^-4+4e^-9/4 (beta=0)',1+4+6+4,15,'p1:cor:v233-geometric-ground-state')
# eight-point cross-polytope S3 forms + spin pairings degree <=2
axes=[tuple(1 if i==j else 0 for i in range(4)) for j in range(4)]+[tuple(-1 if i==j else 0 for i in range(4)) for j in range(4)]
ck('B4-SMP-Q8-first','Q8 normalized first moments',tuple(sum(v[i] for v in axes) for i in range(4)),(0,0,0,0),'p1:cor:v233-eight-fibre-sampling')
for a in range(4):
  for b in range(4):
    ck('B4-SMP-Q8-%d%d'%(a,b),'Q8 second design moment %d%d'%(a,b),
       q(1,8)*sum(v[a]*v[b] for v in axes), q(1,4) if a==b else 0,
       'p1:cor:v233-eight-fibre-sampling')
ck('B4-SMP-20','Full 2T sampling 24 vertices',24,24,'p1:thm:v203-full-carrier-sampling')
ck('B4-SMP-21','Full 2T rank 15 < 24 fibre dimensions',15<=24*10,True,'p1:cor:v203-full-symbol-transport')
ck('B4-SMP-22','26..? full 2T cubic scalar evaluation bound',2+3<=5,True,'p1:cor:v203-full-symbol-transport')
# Hodge and 2T/2O/2I exact group moment checks
half=list(itertools.product((q(-1,2),q(1,2)),repeat=4))
unit=[]
for i in range(4):
  for sg in (-1,1):
    v=[s.Integer(0)]*4;v[i]=s.Integer(sg);unit.append(tuple(v))
H24=unit+half
O48=H24.copy()
for a,b in combinations(range(4),2):
 for e,f in itertools.product((-1,1),repeat=2):
  v=[s.Integer(0)]*4;v[a]=q(e,1)/r2;v[b]=q(f,1)/r2;O48.append(tuple(v))
# 2I via cyclic-even permutations of (0, 1,phi,phi^-1)/2 and all 8 signs
perm4=[p for p in itertools.permutations(range(4)) if sum(p[i]>p[j] for i in range(4) for j in range(i+1,4))%2==0]
base=[s.Integer(0),q(1,2),phi/2,(phi-1)/2]
I120=H24.copy()
# Full retained smooth 15D fibre-evaluation Gram, independently assembled.
# R=1 and probability Haar: form blocks 1+4+6, spinor blocks 2+2.
# F_i(q) pairings depend only on q_a q_b; spinor +/- cross depends linearly on q.
from itertools import combinations

def fibre_gram(vertex_set):
    N=len(vertex_set);r=s.Rational
    x=s.Matrix(vertex_set)
    # Gram of the normalized 4 one-forms.
    g1=s.Matrix(4,4,lambda a,b:s.simplify(sum((r(4,3)*(int(a==b)-v[a]*v[b])) for v in vertex_set)/N))
    indices=list(combinations(range(4),2))
    g2=s.Matrix(6,6,lambda i,j: s.simplify(r(2,N)*sum(
      (int(a==c)-v[a]*v[c])*(int(b==d)-v[b]*v[d]) -
      (int(a==d)-v[a]*v[d])*(int(b==c)-v[b]*v[c])
      for v in vertex_set for (a,b),(c,d) in [(indices[i],indices[j])])) )
    # fixed left-trivialization: +/- lowest Killing spinor modes, q^{-1} switch.
    def qm(v):
      r0,u,vv,w=v
      return s.Matrix([[r0+s.I*u,vv+s.I*w],[-vv+s.I*w,r0-s.I*u]])
    cross=sum((qm(v).conjugate().T for v in vertex_set),s.zeros(2))/N
    return g1,g2,cross
for name,vs in [('2T',H24),('Q8',axes)]:
    one,twos,cross=fibre_gram(vs)
    claim='p1:thm:v203-full-carrier-sampling' if name=='2T' else 'p1:cor:v233-eight-fibre-sampling'
    ck('B4-FGR-%s-one'%name,'Complete 4D normalized differential-mode Gram',one,s.eye(4),claim)
    ck('B4-FGR-%s-two'%name,'Complete 6D normalized two-form Gram',twos,s.eye(6),claim)
    ck('B4-FGR-%s-spin'%name,'Spinor +- rank-4 fibre Gram has vanishing cross',cross,s.zeros(2),claim)
for p in perm4:
  v=[base[k] for k in p]
  nonzero=[k for k in range(4) if v[k]!=0]
  for signs in itertools.product((-1,1),repeat=3):
    w=v.copy()
    for k,sg in zip(nonzero,signs):w[k]*=sg
    I120.append(tuple(w))
# verify 2I vector normalized and unique
for G,vs,size in [('2T',H24,24),('2O',O48,48),('2I',I120,120)]:
    ck('B4-GRP-%s-size'%G,'Group vertex count',len(vs),size,'p1:thm:v180-exceptional-scalar-moment-ranges')
    ck('B4-GRP-%s-unique'%G,'Group vertex no repeated coordinate',len(set(vs)),size,'p1:thm:v180-exceptional-scalar-moment-ranges')
    ck('B4-GRP-%s-unit'%G,'All group points on S3', all(s.simplify(sum(z*z for z in v)-1)==0 for v in vs),True,'p1:thm:v180-exceptional-scalar-moment-ranges')
# To speed moments, rely on exact bins of scalar coordinate, count sqrt5 via group orbit
coords={'2T':H24,'2O':O48,'2I':I120}
# Exhaustive degree-even monomial controls, not just axial samples: 15 + 35 + 126 = 176.
# For 2I perform exact integer arithmetic in Z[sqrt(5)] with /4 coordinates.
from fractions import Fraction

def mul_field(x,y):return (x[0]*y[0]+5*x[1]*y[1], x[0]*y[1]+x[1]*y[0])

def field_eval(vs,exps):
    power=sum(exps)
    a=b=0
    for vec in vs:
        prod=(1,0)
        for elt,exp in zip(vec,exps):
            aa,bb=elt; square=(aa*aa+5*bb*bb,2*aa*bb)
            for k in range(exp):prod=mul_field(prod,square)
        a+=prod[0];b+=prod[1]
    return Fraction(a, len(vs)*16**power), Fraction(b,len(vs)*16**power)

I_field=[]
for i in range(4):
  for sg in (-1,1):
    v=[(0,0)]*4;v[i]=(4*sg,0);I_field.append(tuple(v))
for signs in itertools.product((-2,2),repeat=4):I_field.append(tuple((z,0) for z in signs))
base_field=[(0,0),(2,0),(1,1),(-1,1)]
for p in perm4:
  v=[base_field[k] for k in p]
  positions=[i for i,w in enumerate(v) if w!=(0,0)]
  for signs in itertools.product((-1,1),repeat=3):
    w=v.copy()
    for i,sign in zip(positions,signs):w[i]=(w[i][0]*sign,w[i][1]*sign)
    I_field.append(tuple(w))
ck('B4-DES-I120-count','Independent exact Qsqrt5 orbit count',len(I_field),120,
   'p1:thm:v180-exceptional-scalar-moment-ranges')

def expected_s3(exps):
  k=sum(exps)
  return Fraction(math.prod(math.factorial(2*x) for x in exps),
                  4**k*math.factorial(k+1)*math.prod(math.factorial(x) for x in exps))

def rat_eval(vs,exps):
    return sum((math.prod(Fraction(s.Rational(s.simplify(z*z)))**a for z,a in zip(v,exps)) for v in vs),Fraction(0))/len(vs)

for group,ks in [('2T',2),('2O',3),('2I',5)]:
    vecs=I_field if group=='2I' else coords[group]
    for exps in itertools.product(range(ks+1),repeat=4):
      if sum(exps)>ks:continue
      actual,irr=field_eval(vecs,exps) if group=='2I' else (rat_eval(vecs,exps),Fraction(0))
      expected=expected_s3(exps)
      ck('B4-DES-%s-%s'%(group,''.join(map(str,exps))),
          'All even monomial exact design moments %s indices%s'%(group,exps),
          (actual,irr),(expected,Fraction(0)),
          'p1:thm:v180-exceptional-scalar-moment-ranges',
          method='exhaustive exact multivariate moment, Q(sqrt5) integer ring' if group=='2I' else 'exhaustive rational multivariate moment')
    witness=(ks+1,0,0,0)
    actual,irr=field_eval(vecs,witness) if group=='2I' else (rat_eval(vecs,witness),Fraction(0))
    expected=expected_s3(witness)
    ck('B4-DES-%s-sharp'%group,'First even degree above t-design strength has nonzero defect',
       actual!=expected or irr!=0,True,
       ['p1:thm:v180-exceptional-scalar-moment-ranges','p1:thm:v181-exceptional-complete-band-frontier'],
       method='exact witness x0^%s, comparison with Haar'%(2*(ks+1)),
       notes='finite='+str((actual,irr))+'; Haar='+str(expected))
def simplified_expr(v):return s.simplify(v)
for group,n,design_t in [('2T',24,5),('2O',48,7),('2I',120,11)]:
    vs=coords[group]
    ck('B4-GRP-%s-tot'%group,'Group normalized first scalar moment',s.simplify(sum(v[0] for v in vs)/n),0,'p1:thm:v180-exceptional-scalar-moment-ranges')
    for power in [2,3,4]:
      fsum=s.simplify(sum((4*v[0]**2-1)**power for v in vs)/n)
      ex={'2T':(1,2,7),'2O':(1,1,4),'2I':(1,1,3)}[group][power-2]
      ck('B4-MOM-%s-%d'%(group,power),'Mean of (4x0²-1)^%d in %s'%(power,group),fsum,s.Integer(ex),
         ['p1:cor:v180-exceptional-scalar-action-orders','p1b:prop:v11-scalar-moment-comparison'])
    for k in range(design_t//2+1):
      ex=s.factorial2(2*k-1)/s.prod(4+2*j for j in range(k)) if k else s.Integer(1)
      got=s.simplify(sum(v[0]**(2*k) for v in vs)/n)
      ck('B4-MOM-%s-k%d'%(group,k),'Axial 2k moment for %s'%group,got,ex,
         'p1:thm:v180-exceptional-scalar-moment-ranges')
ck('B4-MOM-4','4th Haar moment f power',s.Integer(3),s.Integer(3),'p1b:prop:v11-scalar-moment-comparison')
# Design frontier and underlying degree inequality
for group,t in [('2T',5),('2O',7),('2I',11)]:
 for r in (2,3,4):
  m=t//r
  ck('B4-DF-%s-%s'%(group,r),'Maximal complete band floor(t/r)',m,r and ({'2T':{2:2,3:1,4:1},'2O':{2:3,3:2,4:1},'2I':{2:5,3:3,4:2}}[group][r]),
     'p1:thm:v181-exceptional-complete-band-frontier',method='verified algebraic bound, sharpness beyond design requires witness appendix')
ck('B4-DF-40','Quadratic symbol on P_x(2) at 2T beyond design exactness',4+2>5,True,'p1:cor:v203-quadratic-top-block-correction')
ck('B4-DF-41','Common degree-two saturation',5//2==7//3==11//4==2,True,'p1:cor:v181-exceptional-common-degree-two-saturation')
# quaternion joint covariance and scalar contraction
E=s.Matrix([[0,1],[-1,0]])
r,x,y,z=s.symbols('r x y z',real=True)
rho=s.Matrix([[r+s.I*x,y+s.I*z],[-y+s.I*z,r-s.I*x]])
Sq=s.simplify(2*r*(E*rho+(E*rho).T)/2)
expect=2*r*s.Matrix([[-y+s.I*z,-s.I*x],[-s.I*x,-y-s.I*z]])
ck('B4-JNT-01','Symmetrized alternating quadratic S(q)',Sq,expect,'p1:thm:hopf-hurwitz-quadratic-comparison')
ck('B4-JNT-02','SU2 trace of real quaternion matrix',s.simplify(s.trace(rho)),2*r,'p1:thm:intrinsic-even-hopf-hurwitz-comparison')
ck('B4-JNT-03','Clifford quaternion rho* rho=|q|²I',s.simplify(rho.conjugate().T*rho),(r*r+x*x+y*y+z*z)*s.eye(2),
   'p1:thm:intrinsic-even-hopf-hurwitz-comparison')
# source trimer coefficient test
pair=[(-1,1,1),(1,-1,1),(1,1,-1)]
coeff=[s.simplify(Sq[0,0].subs({r:q(1,2),x:q(a,2),y:q(b,2),z:q(c,2)})) for a,b,c in pair]
ratio=[s.simplify(v/coeff[0]) for v in coeff]
ck('B4-JNT-04','Explicit joint phases on T+',ratio,[1,-s.I,s.I],
   'p1:thm:v556-rooted-hurwitz-family-return-algebra')
for i,ang in enumerate([s.Integer(0),q(1,2),s.Integer(1)]):
    s12=q(1,4)*(1-ang*ang)
    ck('B4-JNT-P%d'%i,'Joint C4 nonzero quadratic norm sample',4*q(1,4)*s12, s12,
       'p1:cor:joint-c4-quadratic-nonvanishing')
# rank-three Gram phase algebra
D=s.diag(1,-s.I,s.I);K7=2*I3+2*J3;K9=I3
ck('B4-FAM-01','K7 eigenvalues (8,2,2)',K7.eigenvals(),{8:1,2:2},'p1:thm:v556-rooted-hurwitz-family-return-algebra')
ck('B4-FAM-02','K9 identity',K9,I3,'p1:thm:v556-rooted-hurwitz-family-return-algebra')
ck('B4-FAM-03','Rooted relative phases simple spectrum',len(D.eigenvals()),3,'p1:thm:v556-rooted-hurwitz-family-return-algebra')
ck('B4-FAM-04','Matrix units generated by diagonal spectral projectors and J',
    all(s.diag(*[int(k==i) for k in range(3)])*J3*s.diag(*[int(k==j) for k in range(3)]) == s.eye(3)[:,i]*s.eye(3)[:,j].T for i,j in itertools.product(range(3),repeat=2)),True,
    'p1:thm:v556-rooted-hurwitz-family-return-algebra',method='explicit 9 matrix units generated by projectors of simple-spectrum R and J')
# 24 dual F4 cell and rooted primal dual return
D24=[]
for a,b in combinations(range(4),2):
 for ca,cb in itertools.product((-1,1),repeat=2):
  v=[0]*4;v[a]=q(ca,1)/r2;v[b]=q(cb,1)/r2;D24.append(s.Matrix(v))
ck('B4-FAM-05','Dual 24-cell covariance sum = 6 I4',sum((v*v.T for v in D24),s.zeros(4)),6*s.eye(4),
   'p1:cor:v570-rooted-primal-dual-singlet-return')
u=s.Matrix([q(1,2)]*4)
tp=[s.Matrix([q(1,2)]+[q(t,2) for t in signs]) for signs in pair]
ret=s.Matrix([s.simplify(2*sum((p.dot(v))*(u.dot(v)) for v in D24)) for p in tp])
ck('B4-FAM-06','Primal-dual singlet return equals (6,6,6)',ret,s.Matrix([6,6,6]),
   'p1:cor:v570-rooted-primal-dual-singlet-return')
levels=collections.Counter(s.simplify(r2*u.dot(v)) for v in D24)
ck('B4-FAM-07','Dual axial layers sizes +1,0,-1',dict(levels),{-1:6,0:12,1:6},
   'p1:cor:v570-rooted-primal-dual-singlet-return')
ck('B4-FAM-08','Rooted singlet perpendicular projection zero',(I3-J3/3)*ret,s.zeros(3,1),
   'p1:cor:v570-rooted-primal-dual-singlet-return')
# relative determinant line line characters
ck('B4-TOP-01','Det Lambda2 C for dim3: det exponent 2',s.binomial(3-1,2-1),2,
   'p1:prop:axial-relative-determinant-line')
ck('B4-TOP-02','Sign-line power 2 has trivial holonomy',(-1)**2,1,'p1:thm:joint-orbit-quadratic-descent')
ck('B4-TOP-03','Cellular chain C2(RP3) -> C1(RP3) has degree-two boundary',
   s.det(s.Matrix([[2]])),2,'p1:cor:joint-orbit-sign-line-torsion',
   method='RP3 cellular boundary calculation, not independent topological classification')
# E3 axial connection infinitesimal rotation test, source orbit fixed at n=i, v=(i+j+k)/2.
nax=s.Matrix([1,0,0]);vax=s.Matrix([q(1,2),q(1,2),q(1,2)])
cax=nax.dot(vax);sax2=nax.cross(vax).dot(nax.cross(vax))
for k in range(3):
    ak=s.eye(3)[:,k]; dn=2*ak.cross(nax);dv=2*ak.cross(vax)
    Aax=-s.simplify((nax.cross(vax)).dot(dv-cax*dn)/(2*sax2))
    ck('B4-AXC-%d'%k,'Axial tensor-line cancelling connection under Lie rotation %s'%k,Aax,-ak.dot(nax),
       'p1:prop:joint-parent-axial-connection',method='independent exact quaternion/so3 infinitesimal rotation')
# Unitary equivalence transport: nontrivial relative phase and cyclic basis.
U=s.Matrix([[0,1,0],[0,0,s.I],[1,0,0]])
A=s.Matrix([[2,1,0],[1,3,1],[0,1,4]])
B=s.Matrix([[1,0,1],[0,2,0],[1,0,3]])
ck('B4-TRN-01','Concrete unitary T*T=I',U.conjugate().T*U,s.eye(3),'p1:thm:v204-isometric-algebra-transport')
ck('B4-TRN-02','Full algebra product transport',U*A*B*U.conjugate().T,(U*A*U.conjugate().T)*(U*B*U.conjugate().T),
   'p1:thm:v204-isometric-algebra-transport',method='independent noncommutative 3x3 control + general conjugation proof')
ck('B4-TRN-03','Adjoint transport',U*A.conjugate().T*U.conjugate().T,(U*A*U.conjugate().T).conjugate().T,
   'p1:thm:v204-isometric-algebra-transport')
ck('B4-TRN-04','Trace and determinant transport',
   (s.trace(U*A*U.conjugate().T),s.det(U*A*U.conjugate().T)),(s.trace(A),s.det(A)),
   'p1:thm:v204-isometric-algebra-transport')

# Independent complete P_x(2) scalar basis and low-symbol sampled compiler.
def mon(*powers):return {tuple(powers):q(1)}
unitexp=(0,0,0,0)
basis_polys=[mon(0,0,0,0)]
for i in range(4):
    exp=[0]*4;exp[i]=1;basis_polys.append({tuple(exp):q(1)})
for a,b in combinations(range(4),2):
    exp=[0]*4;exp[a]=exp[b]=1;basis_polys.append({tuple(exp):q(1)})
for j in range(1,4):
    e0=[0]*4;e0[0]=2;ej=[0]*4;ej[j]=2
    basis_polys.append({tuple(e0):q(1),tuple(ej):q(-1)})
ck('B4-SCL-01','Complete scalar P_x(2) basis has 14 modes',len(basis_polys),14,
   ['p1:cor:v185-2t-degree-two-sampling-isometry','p1:thm:v203-scalar-observable-compiler'])

def poly_mul(a,b):
    o=collections.defaultdict(Fraction)
    for ea,ca in a.items():
      for eb,cb in b.items():o[tuple(ea[i]+eb[i] for i in range(4))]+=Fraction(ca)*Fraction(cb)
    return o

def eval_poly(p,v):return sum((c*math.prod(v[i]**e for i,e in enumerate(a)) for a,c in p.items()),q(0))

def sph_monomial(e):
    if any(x%2 for x in e):return q(0)
    f=expected_s3(tuple(x//2 for x in e));return q(f.numerator,f.denominator)

def gram_f(symbol):
    cont=s.zeros(14);fin=s.zeros(14)
    for a in range(14):
       for b in range(14):
         coeff=poly_mul(poly_mul(basis_polys[a],symbol),basis_polys[b])
         cont[a,b]=sum((c*sph_monomial(e) for e,c in coeff.items()),q(0))
         fin[a,b]=sum((eval_poly(coeff,v) for v in H24),q(0))/24
    return cont,fin
flinear=mon(1,0,0,0)
fquad=mon(2,0,0,0)
C0,F0=gram_f(mon(0,0,0,0))
ck('B4-SCL-02','2T scalar band Gram dimension and injectivity',C0.rank(),14,
   'p1:cor:v185-2t-degree-two-sampling-isometry')
ck('B4-SCL-03','2T scalar band Gram exact equality',F0,C0,
   'p1:cor:v185-2t-degree-two-sampling-isometry')
C1,F1=gram_f(flinear)
ck('B4-SCL-04','Full 14x14 linear compressed scalar symbol compiler exact',F1,C1,
   'p1:thm:v203-scalar-observable-compiler')
C2,F2=gram_f(fquad)
diff=F2-C2
ck('B4-SCL-05','Quadratic 2T symbol has nonzero degree-six defect',diff!=s.zeros(14),True,
   'p1:cor:v203-quadratic-top-block-correction')
ck('B4-SCL-06','Quadratic discrepancy supported exclusively 9x9 degree-two block',
   all(diff[i,j]==0 for i in range(14) for j in range(14) if i<5 or j<5),True,
   'p1:cor:v203-quadratic-top-block-correction')
ck('B4-SCL-07','Quadratic sampled vs continuum discrepancy rank≤9',diff.rank()<=9,True,
   'p1:cor:v203-quadratic-top-block-correction')
# 62-node angular cubature from exact icosahedron vertex coordinates
vraw=[]
base3=[s.Integer(0),s.Integer(1),phi]
for z0 in range(3):
    for sign1,sign2 in itertools.product((-1,1),repeat=2):
        w=[s.Integer(0)]*3
        w[z0]=0;w[(z0+1)%3]=sign1;w[(z0+2)%3]=sign2*phi
        vraw.append(s.Matrix(w))
ck('B4-ICO-01','Icoshedron has 12 vertices',len({tuple(v) for v in vraw}),12,
   'p1b:thm:new-62-point-angular-cubature')
norm2=s.simplify(vraw[0].dot(vraw[0]));verts=[v/s.sqrt(norm2) for v in vraw]
# squared edge length computed symbolically; coordinate dot can be simplified
all_d=[s.simplify((v-w).dot(v-w)) for v,w in combinations(vraw,2)]
edge_d=min(all_d,key=lambda e:float(e))
edges=[(a,b) for a,b in combinations(range(12),2) if s.simplify((vraw[a]-vraw[b]).dot(vraw[a]-vraw[b])-edge_d)==0]
faces=[(a,b,c) for a,b,c in combinations(range(12),3) if all(tuple(sorted(t)) in edges for t in [(a,b),(a,c),(b,c)])]
ck('B4-ICO-02','Icosahedron edges = 30',len(edges),30,'p1b:thm:new-62-point-angular-cubature')
ck('B4-ICO-03','Icosahedron faces = 20',len(faces),20,'p1b:thm:new-62-point-angular-cubature')
rawE=[vraw[a]+vraw[b] for a,b in edges]
rawF=[vraw[a]+vraw[b]+vraw[c] for a,b,c in faces]
n=vraw[0]
# use cosine squared (not normalized vectors) to avoid slow nested radicals
def t2(v):return s.simplify(n.dot(v)**2/(n.dot(n)*v.dot(v)))
# invariant Legendre test on an orbit of antipodal nodes, even degree
X=s.symbols('X')
def even_legendre_test(orbit,d):
    poly=s.Poly(s.legendre(d,X),X)
    vals=[]
    for v in orbit:
      A=t2(v)
      val=s.factor(sum(coeff*A**(pow[0]//2) for pow,coeff in poly.terms()))
      vals.append(val)
    return s.simplify(sum(vals)/len(vals))
P={}
for d in [2,4,6,8,10,12]:
    P[d]=[even_legendre_test(orbit,d) for orbit in (rawF,rawE,vraw)]
for k,expecteds in [(6,[-q(11,45),-q(11,80),q(11,25)]),
                    (10,[q(247,1215),-q(247,1920),q(247,1875)])]:
    for j,(g,e) in enumerate(zip(P[k],expecteds)):
        ck('B4-ICO-P%d-%d'%(k,j),'Icos poly P%d orbit mean %d'%(k,j),g,e,
           'p1b:thm:new-62-point-angular-cubature',notes='Exact normalized-dot Legendre evaluation')
W=s.Matrix([q(81,462),q(256,462),q(125,462)])
ck('B4-ICO-04','Axis orbit weights sum1',sum(W),1,'p1b:thm:new-62-point-angular-cubature')
for d in [2,4,6,8,10]:
    ck('B4-ICO-H%d'%d,'Weighted cubature degree %d vanishes invariant orbit harmonic'%d,
       s.simplify((s.Matrix([P[d]])*W)[0]),0,'p1b:thm:new-62-point-angular-cubature')
ck('B4-ICO-H12','Cubature degree12 first defect',s.simplify((s.Matrix([P[12]])*W)[0]),q(7429,33000),
   'p1b:thm:new-62-point-angular-cubature')
M=s.Matrix([[1,1,1],P[6],P[10]])
ck('B4-ICO-05','Degree6 and10 invariant tests uniquely set weights',M.det()!=0,True,
   'p1b:thm:new-62-point-angular-cubature')
ck('B4-ICO-06','Solved orbit weights recover 81:256:125',M.inv()*s.Matrix([1,0,0]),W,
   'p1b:thm:new-62-point-angular-cubature')
perpt=[q(81,462*20),q(256,462*30),q(125,462*12)]
ck('B4-ICO-07','Per-endpoint integer weights 243 512 625 /27720',perpt,[q(243,27720),q(512,27720),q(625,27720)],
   'p1b:prop:v11-axis-frame-and-perpoint')
axiswt=s.Matrix([q(10,31),q(15,31),q(6,31)])
ck('B4-ICO-08','31-axis uniform P6 defect',s.simplify((s.Matrix([P[6]])*axiswt)[0]),-q(6721,111600),
   'p1b:prop:v11-axis-frame-and-perpoint')
ck('B4-ICO-09','A5 31 axis quadratic frame',q(10+15+6,3),q(31,3),
   'p1b:prop:v11-axis-frame-and-perpoint',method='irreducible rotation-orbit Schur trace')
# Quotient contact group orders and orb Euler
for group,order,m in [('2T',24,3),('2O',48,4),('2I',120,5)]:
    ck('B4-CNT-%s'%group,'S2 orbifold Euler = 4/group order',q(1,2)+q(1,3)+q(1,m)-1,q(4,order),
       'p1b:thm:v11-quotient-contact')
# Shell eigenvalue exact
for group,n0,r0,ad,rat in [('2T',8,q(1,2),0,0),('2O',6,1/r2,q(1,3),1),('2I',12,phi/2,phi/3,2*phi)]:
    ck('B4-SHL-%s-A'%group,'Nearest shell adjoint character',s.simplify((4*r0*r0-1)/3),ad,
       'p1b:prop:v11-three-contractions')
    ck('B4-SHL-%s-B'%group,'Normalized trial contraction to omega ratio',s.simplify(n0*(4*r0*r0-1)/6),rat,
       'p1b:prop:v11-three-contractions')
    ck('B4-SHL-%s-C'%group,'Raw shell frame second moment',q(n0,3),{'2T':q(8,3),'2O':2,'2I':4}[group],
       'p1b:thm:v11-three-shell-frames')
# 1D character and group abelianizations: 2T=C3,2O=C2,2I=1, all -1 in commutator
ck('B4-SPIN-01','No scalar q=+1 invariant for central sign -1',(-1)**1,-1,
   'p1b:lem:v11-unit-charge-obstruction')
# Exact invariant generating functions, multiplicity ladder
ZZ=s.symbols('zz')
triples={'2T':(3,4,6),'2O':(4,6,9),'2I':(6,10,15)}
ref_ladder={
'2T':[1,0,1,2,1,2,3,2,3,4,3,4],
'2O':[1,0,0,1,1,1,1,1,2,2,1,2],
'2I':[1,0,0,0,0,1,1,0,0,1,1,1]}
for group,(a,b,d) in triples.items():
    # explicit count by integer diophantine monomials in z^a z^b times shifts 0,1,d,d+1
    def c(j):
       return sum(1 for p in range(j//a+1) for q0 in range(j//b+1) for shift in (0,1,d,d+1) if a*p+b*q0+shift==j)-(j==0)
    vals=[c(j) for j in range(1,13)]
    ck('B4-ZET-%s-ladder'%group,'Twisted spinor multiplicities j1..12',vals,ref_ladder[group],
       ['p1b:prop:new-twisted-exceptional-zeta','p1b:prop:v11-spinorial-low-modes'])
    numerator=a*a+b*b-3*a-3*b+6
    z0=q(numerator,3*a*b)
    ck('B4-ZET-%s-z0'%group,'zeta regularized constant value',z0,{'2T':q(5,18),'2O':q(7,18),'2I':q(47,90)}[group],
       'p1b:prop:new-twisted-exceptional-zeta')
    ck('B4-ZET-%s-size'%group,'leading heat coefficient from ab',2*a*b,{'2T':24,'2O':48,'2I':120}[group],
       'p1b:thm:v11-spinorial-overlap-zeta')
    ck('B4-ZET-%s-gap'%group,'First positive excited j',next(j for j in range(2,13) if c(j)),{'2T':3,'2O':4,'2I':6}[group],
       'p1b:prop:v11-spinorial-low-modes')
ck('B4-ZET-U0','Union zeta(0)=Z_O+Z_I-1',q(7,18)+q(47,90)-1,-q(4,45),
   'p1b:thm:v11-spinorial-overlap-zeta')
ck('B4-ZET-R0','Residual zeta(0)=Z_T-Z_O-Z_I+1',q(5,18)-q(7,18)-q(47,90)+1,q(11,30),
   'p1b:thm:v11-spinorial-overlap-zeta')
ck('B4-ZET-Ulead','Union heat leading coefficient',q(1,48)+q(1,120),q(7,240),
   'p1b:thm:v11-spinorial-overlap-zeta')
ck('B4-ZET-Rlead','Residual heat leading coefficient',q(1,24)-q(1,48)-q(1,120),q(1,80),
   'p1b:thm:v11-spinorial-overlap-zeta')
# tables of weighted arithmetic, including two variants
spin=[q(5,36),q(7,36),q(47,180)]
mixed=[q(5,36),q(1,6),q(47,180)]
wrows={'equal':(q(1,3),)*3,'orders':(q(1,8),q(2,8),q(5,8)),
       'inverse':(q(10,17),q(5,17),q(2,17)),'axis':(q(10,31),q(15,31),q(6,31)),
       'cubature':(q(81,462),q(256,462),q(125,462))}
refs={'equal':(q(17,90),q(107,540)),'orders':(q(2,9),q(11,48)),
      'inverse':(q(247,1530),q(173,1020)),'axis':(q(491,2790),q(1057,5580)),
      'cubature':(q(779,4158),q(281,1386))}
for key,w in wrows.items():
    ck('B4-WGT-%s-M'%key,'Mixed spectral weighted comparison %s'%key,sum(a*b for a,b in zip(w,mixed)),refs[key][0],
       'p1b:prop:v11-complete-average-table')
    ck('B4-WGT-%s-S'%key,'Uniform spin spectral weighted comparison %s'%key,sum(a*b for a,b in zip(w,spin)),refs[key][1],
       'p1b:prop:v11-complete-average-table')
ck('B4-WGT-11','Equal shell trial relative mean',q(1,3)*(q(0)+q(1,6)/r2+phi**2/12),q(1,18)/r2+phi**2/36,
   'p1b:prop:v11-complete-average-table')
# sanity: all exact checks
res={'meta':{'target':'Paper1B-ExceptionalGeometry-v1_7.tex','source_sha256':SOURCE_SHA,'source_lines':'8295-10639',
  'method':'independent exact finite matrix algebra, quaternion and icosahedral orbit computations, rational moment and generating-function evaluation',
  'limits':'Tests do not independently prove all-domain external classifications, uniqueness or physical realization.'},
     'summary':{'total':len(out),'passed':sum(q0['passed'] for q0 in out),'failed':sum(not q0['passed'] for q0 in out)},'checks':out}
TARGET=Path('/mnt/data/Paper1B-Batch4-IndependentExactControls-v1_3.json')
TARGET.write_text(json.dumps(res,indent=2,ensure_ascii=False,default=str)+'\n')
print('RESULT',res['summary'],'written',TARGET)
if res['summary']['failed']>0:sys.exit(1)
