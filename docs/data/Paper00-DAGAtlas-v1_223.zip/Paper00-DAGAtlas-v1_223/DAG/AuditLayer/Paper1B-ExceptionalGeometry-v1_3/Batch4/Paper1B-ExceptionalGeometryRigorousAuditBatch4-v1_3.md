# Paper I-B — Rigorous Verification DAG Audit, Batch 4 (v1_3)

**Frozen target:** `Paper1B-ExceptionalGeometry-v1_7.tex`, sha256 `67ae02d9843853b6396f339eb4ec7184abd9258d5d6b8335bd757c929b5fa89b`; **source lines 8295–10639 inclusive**; line 10628 begins a remark ending at 10639. Current source has **480 formal environments**, and this batch checks **66** (48 substantive; 18 definitions/scope remarks). Source paper and pre-existing archives remain read-only.

**Protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4(1).md`; evidence layers E0/E1/E3/E4; independent tests are not proof of an unspecified physical mechanism. **Interim audit only, no consolidated ZIP release.**

## Verdict and numerical coverage

| Measure | Batch 4 | Cumulative Batches 1–4 |
|---|---:|---:|
| Substantive source claims independently verified under printed scope | **48** | **181** |
| Formalized definitions, cautions and remarks | **18** | **59** |
| Reproduced, stronger independent certificates outstanding | **0** | **6** |
| Total formal source claims examined | **66** | **246/480 (51.25%)** |
| New issue roots | **0** | **9 open from Batches 1–2** |
| Exact independent controls | **399/399 pass** | B2 115/115, B3 90/90, B4 399/399 (B1 separate) |

The Batch 4 independent suite covers **41 substantive claims through direct executable controls**, and **7 further substantive claims** through separately articulated exact reasoning. Definitions/remarks receive `FORMALIZED`, not theorem verification. Claims including imported classification retain that external premise explicitly.

**No source-matched mathematical contradiction is established.** The already-open audit graph/missing-evidence findings remain open and are not silently closed by unrelated checks. No physical mass/action/gauge coefficient, dynamical constructor or group-to-observable selection is asserted.

## Detailed verified blocks

**8295–8695 — Intrinsic versus ambient Clifford and first-order closure.** Separates radial kernel from intrinsic cotangent symbol; the form-plus-spinor 15-dimensional model and six irrep phase uniqueness; normalized Haar density; intrinsic Q_D/R²=(1,11/12,4/9,4/9,3/4,3/4) versus ambient Q_cone/R²=(1,1,1/2,1/2,1,1); exterior wedge/contraction √2 factors; Clifford strata; canonical retained LC square; 25-dimensional first-order closure and noncommuting compression square. These are distinct constructions, not one assumed universal point. Independent evidence: `B4-GEO, B4-CL; normalized matrix products and independent representation rules`.

**8714–8871 — Full-carrier fibre sampling and exact transport.** The full 15D sampled representation includes vector-valued fibres (forms plus spinors), not just 8 or 24 scalar amplitudes. Both 2T and Q8 exact sampling modes give isometric transport of their actual image; normalized heat ground projection is source-specific. Independent evidence: `B4-SMP, B4-HUR, B4-GEO fibre Gram tests`.

**8893–9543 — Joint rooted Hopf–Hurwitz orbit and two coordinate branches.** Quadratic invariant and trimer C4 nonvanishing, rooted family matrix algebra, primal–dual singlet, SO(3) free orbit with sign-line torsion, unique dual-square tensor-line connection, axial factor allocation, ambient cone export; intrinsic/ambient quadratic spectra prove inequivalence. Rooted parents and connection bases are mandatory. Independent evidence: `B4-JNT, B4-AX, B4-GEO and independent connection/orbit argument`.

**9557–9907 — Frozen ancestry grammar and exceptional design frontiers.** Two and only two coordinate classes follow **relative** to the explicitly restricted two-word grammar. On chosen uniform finite group supports, direct exact multivariate monomial moments through degrees 5/7/11 and first failing witnesses verify the 2T/2O/2I designs and all nine complete-band maxima. Quartet on degree2 selects 2I only as same-owner support conditional on rooted 2T; not physical group selection. 2T scalar sampling at degree2 and nine-dimensional top-block discrepancy are proved on stated bands. Independent evidence: `B4-DES (176 exhaustive even-monomial moments, plus sharpness), B4-DF, B4-OBS`.

**9937–9994 — 62-point icosahedral angular cubature.** Constructs the 12+20+30 antipodal point set, assigns positive orbit weights in the 81:256:125 ratio, checks icosahedral harmonic vanishing through degree11 and nonzero degree12 defect 7429/33000. Hopf pushforward gives the declared 4π² multiple only for pullback observables. Independent evidence: `B4-ICO and independent Hopf measure reasoning`.

**10018–10639 — Twisted spectra, quotient contact and comparison arithmetic.** Exact spinorial multiplicity Molien series, low-mode ladder and overlap, zeta(0) values and heat leading terms; quotient contact is 4π²/|Γ|. Three shell contractions, unique raw octahedral positive frame among the three, f=4x₀²−1 test moments, 31-axis identities and arithmetic weight rows are reproducible. Distinct group-to-orbit pairings and zeta determinants are **not selected** by these values. Independent evidence: `B4-ZET, B4-QOT, B4-FRM, B4-WGT`.

## Independent check evidence and validity

The runnable exact script `Paper1B-Batch4-IndependentChecks-v1_3.py` reproduced **399 independent exact controls** using SymPy rational/surd arithmetic, exact finite Clifford matrices, 120-element icosahedral quaternion samples, quaternion group closure where needed, complete finite scalar moment sweeps, Molien/generating-function expansions, and explicit orbit weights. Re-executing yields `399 pass / 0 fail`. The companion JSON stores each check, its exact actual/expected values, and claim labels.

**Adversarial history (rejected false alarm):** an initial verifier without the source’s √2 exterior-degree wedge/contraction normalization produced ten Clifford test failures. Reinstating the correct finite representation makes every affected exact identity hold. The attempted refutation was invalid; it is preserved as `B4-E4-CL-NORM-01`, not logged as a manuscript error. A separate apparent mismatch arose from an unsimplified symbolic matrix form and vanished under exact simplification. Additional negative attacks on the grammar, selected supports, and scalar→physical inferences are explicitly outside the manuscript’s stated domains.

The 7 substantive claims without direct claim-linked executable checks have independent written justifications frozen in the ledger: normalized Haar from e0, free SO(3) orbit of a nonparallel pair, unique flat sign-line connection, SO(3)/SO(4) stabilizer/Schur exhaustion under the two-word grammar, quartic-support selection via design strength and the classical finite subgroup classification, conditional tetrahedral-frame mobility, and Hopf pullback measure. These are E3 mathematical checks, not merely re-use of the earlier status flag.

## Imported proof dependencies and condition ownership

- The sharp-frontier negative witness is sourced from `Paper1D-TechnicalMaterial-v1_65.tex`, appendix `p1:app:v181-exceptional-frontier-witnesses`, beginning line 25183; the displayed first-failing moment computations were independently checked. This imported appendix is not an entirely missing proof.
- The classical classification of finite binary subgroups containing a rooted `2T` is an **imported mathematical theorem**. The finite enumerations check the actual `2T`, `2O`, `2I` branches but do not independently redo all of finite subgroup classification. Its restricted use is a premise of the conditional quartic-support claim.
- The first appearance of the intrinsic tangential symbol, cone parallel anchor, full-valued fibre sampling, rooted nonparallel joint parent, frozen two-word grammar, uniform group design, angular 31-axis cubature, fixed-charge spectral twist, and arithmetic weighting choice is recorded once. Earlier H₁, 2T, protected-scale and coordinate-completion conditions are **aliases of upstream conditions**, not reintroduced axioms.

## DAG provenance and canonical graph status

- Current canonical ownership for these 66 claims: **40 historical/stale**, **26 absent**, **0 current**. Through 246 examined claims, the mismatch roots cover **187** historical owner matches and **59** absent nodes; these remain under existing issue `BH-IBX-DAG-0002`, not newly invented mathematical errors.
- Proof-internal cross-reference witnesses: **24**; **16** tagged source-witnessed material proof-use candidates, **0** definition/scope consumption, **8** navigational/citation-only pending proof role. Directed links are premise → consumer. Nothing was written into the global canonical DAG this interim batch.
- All source reference owners resolve uniquely across the current PapersMinimal ZIP (see explicit per-claim `resolved_ref_owners`); historical labels remain separate from current-source theorem identity. Source term conclusions lines 10640–10703 are reserved for the next batch.

## Full carried issue register — nine open roots, zero new

| Stable issue ID | Category | Still-open obligation |
|---|---|---|
| `BH-IBX-DAG-0001` | DAG coverage mismatch | Legacy Paper I-B M8 audit cannot verify present Exceptional Geometry; preserve separate manuscript histories and current claim identities. |
| `BH-IBX-DAG-0002` | DAG ownership/provenance | Canonical graph still attributes source claims to historical I-A nodes or lacks them; this is a graph migration/coverage issue. |
| `BH-IBX-EV-0001` | Independent certificate pending | Exact independent pentagon holonomy and reciprocal flux at source line 500 in Batch 1. |
| `BH-IBX-EV-0002` | Independent certificate pending | Exact 600-cell induced adjacency/quotient at source line 723 in Batch 1. |
| `BH-IBX-EV-0003` | Independent certificate pending | Exact quaternionic angular-orbit proof at source line 769 in Batch 1. |
| `BH-IBX-EV-0004` | Independent certificate pending | Exact tangent-sequence equivariance at source line 811 in Batch 1. |
| `BH-IBX-EV-0005` | Independent certificate pending | Exact five-root leakage sum at source line 919 in Batch 1. |
| `BH-IBX-EV-0006` | Independent certificate pending | Exact tensor/quadrupole Gram at source line 975 in Batch 1. |
| `BH-IBX-SRC-0001` | Historical source attribution | Trimer-pair result around source line 3992 is described as Paper I-A-owned although its current label and statement reside in Paper I-B. |

No proven cross-paper mathematical break or downstream observable refutation was established by the above historical/coverage findings. Possible unconfirmed impacts remain tracked under the earlier issues; new status flags are not inherited from the old M8 audit.

## Per-claim source and evidence census

| Printed source lines | Claim ID | Evidence-backed status | Source proof lines | Exact E3 controls |
|---:|---|---|---:|---:|
| 8295–8309 | `p1:prop:cone-tangential-symbol-split` | `VERIFIED` | 8311–8321 | 2 |
| 8325–8354 | `p1:thm:canonical-retained-smooth-model` | `VERIFIED` | 8356–8374 | 16 |
| 8376–8387 | `p1:cor:normalized-constant-haar-density` | `VERIFIED` | 8389–8393 | 0 |
| 8395–8443 | `p1:thm:intrinsic-tangential-coordinate-class` | `VERIFIED` | 8445–8509 | 6 |
| 8511–8520 | `p1:rem:intrinsic-edge-normalization-conversion` | `FORMALIZED` | — | 1 |
| 8522–8553 | `p1:thm:v214-exact-eight-clifford-strata` | `VERIFIED` | 8554–8582 | 14 |
| 8584–8604 | `p1:cor:canonical-retained-dirac-square` | `VERIFIED` | 8606–8615 | 1 |
| 8620–8666 | `p1:thm:v214-first-order-retained-closure` | `VERIFIED` | 8667–8695 | 4 |
| 8696–8703 | `Paper1B-remark-8696` | `FORMALIZED` | — | 0 |
| 8714–8729 | `p1:thm:v203-full-carrier-sampling` | `VERIFIED` | 8730–8743 | 4 |
| 8745–8765 | `p1:cor:v203-full-symbol-transport` | `VERIFIED` | 8766–8775 | 2 |
| 8786–8798 | `p1:cor:v233-eight-fibre-sampling` | `VERIFIED` | 8799–8808 | 20 |
| 8819–8839 | `p1:cor:v233-geometric-ground-state` | `VERIFIED` | 8840–8849 | 1 |
| 8854–8871 | `p1:thm:v204-isometric-algebra-transport` | `VERIFIED` | 8872–8880 | 4 |
| 8893–8918 | `p1:thm:intrinsic-even-hopf-hurwitz-comparison` | `VERIFIED` | 8920–8932 | 2 |
| 8934–8952 | `p1:rem:joint-comparison-unit-transport` | `FORMALIZED` | — | 0 |
| 8959–8988 | `p1:thm:hopf-hurwitz-quadratic-comparison` | `VERIFIED` | 8990–9007 | 1 |
| 9009–9039 | `p1:cor:joint-c4-quadratic-nonvanishing` | `VERIFIED` | 9041–9052 | 3 |
| 9054–9127 | `p1:thm:v556-rooted-hurwitz-family-return-algebra` | `VERIFIED` | 9129–9170 | 5 |
| 9183–9223 | `p1:cor:v570-rooted-primal-dual-singlet-return` | `VERIFIED` | 9224–9240 | 4 |
| 9249–9262 | `p1:prop:axial-relative-determinant-line` | `VERIFIED` | 9264–9278 | 1 |
| 9291–9307 | `p1:thm:joint-hopf-axial-orbit` | `VERIFIED` | 9309–9319 | 0 |
| 9321–9339 | `p1:thm:joint-orbit-quadratic-descent` | `VERIFIED` | 9341–9354 | 1 |
| 9356–9369 | `p1:cor:joint-orbit-sign-line-torsion` | `VERIFIED` | 9371–9385 | 1 |
| 9400–9406 | `p1:thm:joint-comparison-unitary-connection` | `VERIFIED` | 9408–9416 | 0 |
| 9418–9434 | `p1:prop:joint-parent-axial-connection` | `VERIFIED` | 9436–9458 | 3 |
| 9469–9490 | `p1:thm:metric-cone-clifford-coordinate-class` | `VERIFIED` | 9492–9504 | 1 |
| 9506–9523 | `p1:cor:metric-cone-quadratic-fingerprint` | `VERIFIED` | 9525–9533 | 7 |
| 9535–9543 | `p1:cor:cone-tangential-coordinate-inequivalence` | `VERIFIED` | 9545–9553 | 1 |
| 9557–9581 | `p1:def:primitive-round-symbol-ancestry-grammar` | `FORMALIZED` | — | 0 |
| 9583–9606 | `p1:thm:primitive-round-symbol-ancestry-exhaustion` | `VERIFIED` | 9608–9638 | 0 |
| 9640–9654 | `p1:rem:ancestry-exhaustion-sharpness` | `FORMALIZED` | — | 0 |
| 9656–9660 | `Paper1B-remark-9656` | `FORMALIZED` | — | 0 |
| 9662–9667 | `Paper1B-remark-9662` | `FORMALIZED` | — | 0 |
| 9679–9692 | `p1:thm:v180-exceptional-scalar-moment-ranges` | `VERIFIED` | 9693–9699 | 205 |
| 9701–9722 | `p1:cor:v180-exceptional-scalar-action-orders` | `VERIFIED` | direct corollary | 9 |
| 9725–9748 | `p1:thm:v181-exceptional-complete-band-frontier` | `VERIFIED` | 9749–9756 | 12 |
| 9758–9772 | `p1:cor:v181-exceptional-common-degree-two-saturation` | `VERIFIED` | direct corollary | 1 |
| 9775–9793 | `p1:cor:v569-unique-quartic-comparison-support` | `VERIFIED` | 9794–9801 | 0 |
| 9803–9810 | `p1:cor:v569-comparison-support-mobility` | `VERIFIED` | 9811–9816 | 0 |
| 9820–9850 | `p1:cor:v185-2t-degree-two-sampling-isometry` | `VERIFIED` | 9851–9859 | 3 |
| 9863–9883 | `p1:thm:v203-scalar-observable-compiler` | `VERIFIED` | 9884–9892 | 2 |
| 9894–9907 | `p1:cor:v203-quadratic-top-block-correction` | `VERIFIED` | 9908–9913 | 4 |
| 9937–9951 | `p1b:thm:new-62-point-angular-cubature` | `VERIFIED` | 9952–9977 | 18 |
| 9979–9994 | `p1b:cor:new-hopf-pullback-11-cubature` | `VERIFIED` | 9995–9999 | 0 |
| 10018–10037 | `p1b:prop:new-twisted-exceptional-zeta` | `VERIFIED` | 10038–10051 | 6 |
| 10053–10062 | `Paper1B-remark-10053` | `FORMALIZED` | — | 0 |
| 10080–10112 | `p1b:thm:v11-quotient-contact` | `VERIFIED` | 10113–10124 | 3 |
| 10126–10138 | `p1b:rem:v11-embedding-quotient-sampling` | `FORMALIZED` | — | 0 |
| 10143–10176 | `p1b:prop:v11-three-contractions` | `VERIFIED` | 10177–10186 | 6 |
| 10188–10201 | `Paper1B-remark-10188` | `FORMALIZED` | — | 0 |
| 10203–10210 | `Paper1B-remark-10203` | `FORMALIZED` | — | 0 |
| 10215–10247 | `p1b:thm:v11-three-shell-frames` | `VERIFIED` | 10248–10265 | 3 |
| 10267–10273 | `Paper1B-remark-10267` | `FORMALIZED` | — | 0 |
| 10278–10301 | `p1b:prop:v11-scalar-moment-comparison` | `VERIFIED` | 10302–10316 | 10 |
| 10318–10324 | `Paper1B-remark-10318` | `FORMALIZED` | — | 0 |
| 10329–10360 | `p1b:prop:v11-axis-frame-and-perpoint` | `VERIFIED` | 10361–10372 | 3 |
| 10374–10384 | `Paper1B-remark-10374` | `FORMALIZED` | — | 0 |
| 10389–10399 | `p1b:lem:v11-unit-charge-obstruction` | `VERIFIED` | 10400–10410 | 1 |
| 10412–10443 | `p1b:prop:v11-spinorial-low-modes` | `VERIFIED` | 10444–10451 | 6 |
| 10453–10485 | `p1b:thm:v11-spinorial-overlap-zeta` | `VERIFIED` | 10486–10506 | 7 |
| 10508–10520 | `p1b:rem:v11-zeta-scaling` | `FORMALIZED` | — | 0 |
| 10525–10550 | `p1b:def:v11-comparison-triples` | `FORMALIZED` | — | 0 |
| 10552–10586 | `p1b:prop:v11-complete-average-table` | `VERIFIED` | 10587–10608 | 11 |
| 10610–10626 | `p1b:rem:v11-no-canonical-three-determinant-weight` | `FORMALIZED` | — | 0 |
| 10628–10639 | `Paper1B-remark-10628` | `FORMALIZED` | — | 0 |

## Reproducibility and next batch

- Audit report: `Paper1B-ExceptionalGeometryRigorousAuditBatch4-v1_3.md`; source-frozen claim and proof ledger: `Paper1B-ExceptionalGeometryRigorousAuditBatch4Ledger-v1_3.json`; exact test record: `Paper1B-Batch4-IndependentExactControls-v1_3.json`; independent executable: `Paper1B-Batch4-IndependentChecks-v1_3.py`.
- Source line **10628** starts the final included remark and ends line **10639**. **Next batch starts line 10640**, with next formal statement at **10704** (`p1:prop:v189-tracefree-quadratic-harmonics`).
- **Only final batch**: incorporate the current-source DAG layer and audit history, preserve old manuscript audit identity, maintain all actual open issues, package incremented archives containing only most-recent version of each required artifact; validate ZIP readback. Input baselines remain DAG v1_136 and ProofChainAudits v1_52.

**No TeX changed. No merged DAG ZIP or proof-chain audit ZIP exported in Batch 4. Full-paper verified status is not claimed.**
