# Paper I-B — Exceptional Geometry, rigorous verification DAG audit — Batch 3

**Protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md`; single current manuscript. **Interim checkpoint only**: not a full-paper audit, not a reconstructed physical model, no source changes, no final DAG ZIP or audit ZIP.

**Authoritative target:** `Paper1B-ExceptionalGeometry-v1_7.tex` from `Paper00-PapersMinimal-v3_012(1).zip`, SHA-256 `67ae02d9843853b6396f339eb4ec7184abd9258d5d6b8335bd757c929b5fa89b`. Source length 19,479 lines; Batch 3 spans **4600–8294**. Next formal claim starts at **8295**.

**Coverage:** **68/480** formal environments in this batch (**47 `VERIFIED`, 21 `FORMALIZED`**); cumulative **180/480 = 37.50%** (**133 verified, 6 reproduced pending prior exact E3 evidence, 41 formalized**). All **90/90** independent exact checks passed. **Zero** newly established mathematical counterexamples, proof gaps or normalization errors. **Zero** new distinct issues; **nine** previously opened issues remain open.

## Correctness scope and source-versus-physical boundary

- **E0:** froze every listed formal source environment (verbatim theorem statement and proof when present), mapped current unique label owners from the **current** papers ZIP, and compared the canonical DAG node owners. Historical status flags are not correctness evidence.

- **E1:** reviewed the Spin(4) representation/Casimir multiplicity chain, the distinction between intrinsic level-one carrier and chosen finite coordinate-completion family, the finite trimer embedding and Bose–Mesner projections, Clifford and Fierz claims, and the large 24-cell numerical/structural omnibus claims. When proofs are deferred to appendices the exact later proof location is stored.

- **E3:** independent exact rational/symbolic and 24-vertex matrix arithmetic in `Paper1B-Batch3-IndependentChecks-v1_1.py`, yielding 90/90 passes. These are checks of displayed identities and applicable small finite cases—not a proof of all-domain statements or the 2024 SDP uniqueness theorem.

- **E4:** checked false-positive counterexamples: a choice-dependent coordinate realization is not uniquely selected by the 15D sector bank; the degreewise boundary reduction is not automatically an algebra; finite matrix compression does not preserve the uncompressed sphere radius; 3D trimer compression is not a 24D adjacency-invariant subspace; 2T left-action no-go cannot be silently broadened to other actions; and an independent positive protected scale cannot be imposed at zero. These distinguish source-approved limitations from mathematical defects.

The framework’s nonstandard constitutional and physical vocabulary is preserved. None of the finite carrier, Hurwitz cell, `15=7+8`, `24=15+9`, `9=3^2`, or `1⊕3` identities by itself forces a physical occurrence, mass spectrum, interaction, or an operator/coordinate completion. These restrictions are explicit in the current manuscript and are **not** deficiencies to be repaired by importing a conventional model.

## Reviewed mathematical blocks

**4603–5337 · Level-one module and coordinate-degree filtration.** Six irreducible sectors give 15 dimensions; sector-preserving algebra 43, total End space 225; four retained coordinate channels, excluded first exterior-spinor channels, exact 1/4/10/14/25/41/63 boundary support counts. Nonideal counterexample checks that a degreewise quotient is not an inherited algebra. Independent evidence: `B3-REP-09, REP-10, REP-14, REP-15, REP-17, REP-18`.

**5338–6299 · S³₁ skeleton, completion cone, protected Clifford.** Intrinsic carrier and chosen coordinate-family separated. Independent protected scale; anticommutator and symmetry-commutant derived with gamma normalization only on positive branch; finite exterior-plus-spinor Clifford model shows terminal radius defect and no unital complex Cl₄ module on all 15 dimensions. Independent evidence: `B3-CL-01…11, B3-REP-16`.

**6300–6620 · Hurwitz trimer operators and finite-cell interface.** Exact P₉/P₁₅ kernels, 9+15 orthogonal split, isometric trimer injections, positive Gram spectra, two of eight nearest neighbors retained, 3/24 trimer corner trace normalization. Independent evidence: `B3-TRI-01…08, B3-EVAL-05`.

**6621–7707 · 24-cell numerical data and structural invariants.** Exact 24-vertex relation algebra, shells and stabilizers, moments, projector ranks, graph eigenvalues and trimer/cube checks. Omnibus theorem also cites classical finite-group and root-system facts; partial exact checks are not elevated to new proofs of all imported classification. Independent evidence: `B3-HUR-01…36, B3-TRI-09…18`.

**7708–7902 · Primitive Hurwitz angular scalarizer and classical completions.** Correctly choice-typed theta_H=pi/3, rho_H=3/pi; external D₄ kissing/24-point spherical-code uniqueness traced to primary SDP theorem. No mathematical argument here reidentifies this scalarizer as physical volume or length. Independent evidence: `B3-HUR-29` (16 great hexagons), `B3-HUR-30` (unique edge hexagon); 2024 SDP theorem remains an explicit external import.

**7903–8294 · Bose–Mesner, natural left-2T no-go, scalar evaluation bridge, Fierz and exact finite package.** Five nearest-shell eigenvalues; left-2T fixed vectors dimension 6 in H₁ but 1 in the regular target imply no injection; the 5D scalar evaluation nevertheless intertwines exactly. The physical selection/protected-zero branch survives. Independent evidence: `B3-EVAL-01…05; B3-CL; B3-REP-10`.

## Canonical DAG and historical audit provenance

- All **68** formal source claims and all **69** source-referenced label targets in this batch resolve uniquely within the current ZIP (source references occur **126** times in 4600–8294). The seven cross-paper label owners belong to `Paper1A-Geometry-v5_177.tex`. This is a locator check; it does not imply seven separately re-audited I-A theorems.

- **67** current claims match existing **historical Paper I-A ownership**; **1** lacks a canonical node. Their theorem formulas are assessed using **current Paper I-B**, not by copying old Paper I-A validation status. Cumulatively across Batches 1–3, the existing `BH-IBX-DAG-0002` issue therefore represents **147 stale owner matches and 33 missing nodes**. The older historical Paper I-B M8 Geometry audit remains a distinct manuscript history (`BH-IBX-DAG-0001`).

- This ledger freezes **62** proof-internal reference witnesses; **12** have source-backed proof-use witnesses for later global adjudication, while **50** are candidate/navigational/scope-only links. Direction is prerequisite `→` consumer. The canonical DAG ZIP has **not** been edited.

- Typed conditions are aliased to the earliest source; I-A’s established H₁ carrier is not reintroduced as an unproved premise. New choices (completion cone, protected magnitude, rooted finite support, left-action scope and scalar evaluation) retain their first B3 locator in the condition registry, without creating duplicate global assumptions.

## External theorem / cross-paper scope

Theorem `p1:thm:s3one-classical-completions` imports the exact **D₄ kissing/24-cell uniqueness and optimal 24-point spherical-code** assertion from [2024 primary arXiv literature](https://arxiv.org/abs/2404.18794). This primary result supports the imported assertion; the manuscript’s finite 24-cell enumeration and the 90 exact tests do **not** reconstruct the external semidefinite-programming proof. The import is **verified as an applicable external theorem**, not a new derived uniqueness result of the Born–Hopf finite algebra. Other cited classical facts carry their literature scope.

## Full issue register after Batch 3 (zero new)

| Issue | Type | Outcome / evidence obligation |
|---|---|---|
| `BH-IBX-DAG-0001` | `DAG_COVERAGE` | Current Exceptional Geometry source not represented by the older M8 Geometry Paper1B audit; histories must stay separate. |
| `BH-IBX-DAG-0002` | `DAG_COVERAGE` | Current-source ownership and graph-node coverage: 147 displaced Paper I-A historical owners, 33 missing canonical nodes among the first 180 audited claims. |
| `BH-IBX-EV-0001` | `MISSING_EVIDENCE` | Exact independent pentagon holonomy/reciprocal-flux certificate still pending from Batch 1. |
| `BH-IBX-EV-0002` | `MISSING_EVIDENCE` | Exact independent 600-cell induced graph and quotient certificate still pending from Batch 1. |
| `BH-IBX-EV-0003` | `MISSING_EVIDENCE` | Exact quaternionic angular-orbit certificate still pending from Batch 1. |
| `BH-IBX-EV-0004` | `MISSING_EVIDENCE` | Exact tangent-sequence and equivariance certificate still pending from Batch 1. |
| `BH-IBX-EV-0005` | `MISSING_EVIDENCE` | Exact five-root leakage-sum certificate still pending from Batch 1. |
| `BH-IBX-EV-0006` | `MISSING_EVIDENCE` | Exact tensor/quadrupole Gram certificate still pending from Batch 1. |
| `BH-IBX-SRC-0001` | `DAG_COVERAGE` | Paper I-A trimer attribution at present Paper1B line 3992 is stale; the 9D carrier identity itself remains correct. |

The six outstanding E3 obligations concern **Batch 1** only; the present 90 exact checks do not silently resolve those separate statements. None of the nine issues is a demonstrated counterexample to a Paper I-B theorem, and no verified cross-paper mathematical-impact path has been established from the provenance findings. Possible graph consumers remain **POSSIBLE / UNCONFIRMED** pending the final DAG integration.

## Per-claim source census and evidence

| Source lines | Formal claim ID | Status | Proof locator | E3 exact checks |
|---:|---|---|---:|---:|
| 4603–4624 | `p1:cor:level-one-shear-tt-operators` | `VERIFIED` | 4625–4639 | 2 |
| 4658–4696 | `p1:prop:h1-symmetric-exterior-form` | `VERIFIED` | 4698–4706 | 1 |
| 4708–4738 | `p1:prop:box-simplex-antichain` | `VERIFIED` | 4740–4750 | 2 |
| 4752–4765 | `p1:def:total-weight-shell-filtration` | `FORMALIZED` | — | 0 |
| 4767–4808 | `p1:prop:shell-dimensions-parity` | `VERIFIED` | 4810–4827 | 9 |
| 4829–4853 | `p1:cor:m1-shell-counts` | `VERIFIED` | 4855–4863 | 0 |
| 4865–4907 | `p1:thm:s3one-casimir-scale-space` | `VERIFIED` | 4909–4932 | 1 |
| 4937–4948 | `p1:prop:minimal-exceptional-shell-H1` | `VERIFIED` | 4950–4952 | 0 |
| 4954–4962 | `p1:cor:exceptional-refinements` | `VERIFIED` | 4964–4966 | 0 |
| 4969–4989 | `p1:def:coordinate-sector-action` | `FORMALIZED` | — | 0 |
| 4991–5004 | `p1:prop:closure-m1` | `VERIFIED` | 5006–5011 | 1 |
| 5013–5020 | `p1:prop:closure-failure` | `VERIFIED` | 5022–5028 | 0 |
| 5030–5048 | `p1:thm:minimal-coordinate-closed-truncation` | `VERIFIED` | 5050–5052 | 1 |
| 5054–5057 | `Paper1B-remark-5054` | `FORMALIZED` | — | 0 |
| 5066–5077 | `p1:def:raw-symmetric-coordinate-degree` | `FORMALIZED` | — | 1 |
| 5079–5106 | `p1:prop:shell-boundary-count-guard` | `VERIFIED` | 5108–5123 | 1 |
| 5125–5143 | `p1:prop:first-excluded-chiral-boundary` | `VERIFIED` | 5145–5148 | 1 |
| 5150–5193 | `p1:def:compact-coordinate-closure-defect` | `FORMALIZED` | — | 0 |
| 5195–5207 | `p1:prop:compact-coordinate-defect-status` | `VERIFIED` | 5209–5224 | 0 |
| 5226–5253 | `p1:def:oriented-boundary-face` | `FORMALIZED` | — | 0 |
| 5255–5284 | `p1:thm:boundary-reduced-ranks` | `VERIFIED` | 5286–5296 | 1 |
| 5298–5310 | `p1:prop:boundary-quotient-not-algebra` | `VERIFIED` | 11286–11303 | 1 |
| 5338–5417 | `p1:def:s3one-finite-geometry-datum` | `FORMALIZED` | — | 0 |
| 5421–5433 | `p1:prop:s3one-carrier` | `VERIFIED` | 5435–5437 | 0 |
| 5439–5462 | `p1:cor:s3one-sector-content` | `VERIFIED` | 5464–5466 | 0 |
| 5468–5488 | `p1:cor:s3one-shell-filtration` | `VERIFIED` | 5490–5492 | 0 |
| 5499–5509 | `p1:def:s3one-protected-block` | `FORMALIZED` | — | 0 |
| 5511–5520 | `p1:cor:s3one-protected-block` | `VERIFIED` | 5522–5524 | 0 |
| 5526–5535 | `p1:thm:s3one-coordinate-closure` | `VERIFIED` | 5537–5539 | 0 |
| 5556–5572 | `p1:def:s3one-toeplitz-coordinates` | `FORMALIZED` | — | 0 |
| 5574–5608 | `p1:rem:s3one-coordinate-implementation-status` | `FORMALIZED` | — | 0 |
| 5610–5632 | `p1:prop:protected-coordinate-multiplicity-one` | `VERIFIED` | 5634–5646 | 1 |
| 5648–5663 | `p1:cor:level-one-coordinate-completion-moduli` | `VERIFIED` | 5665–5673 | 1 |
| 5675–5705 | `p1:prop:general-protected-clifford-relation` | `VERIFIED` | 5707–5738 | 1 |
| 5740–5780 | `p1:def:clifford-coordinate-representative` | `FORMALIZED` | — | 1 |
| 5789–5825 | `p1:cor:clifford-level-one-values` | `VERIFIED` | Direct/appendix computation | 3 |
| 5842–5862 | `p1:rem:clifford-representative-scope` | `FORMALIZED` | — | 0 |
| 5864–5877 | `p1:def:protected-parent-scale-ratio` | `FORMALIZED` | — | 0 |
| 5880–5907 | `p1:rem:symmetric-vs-clifford-quadratic` | `FORMALIZED` | 11102–11133 | 2 |
| 5910–5920 | `p1:cor:s3one-coordinate-uniqueness` | `VERIFIED` | 5922–5929 | 0 |
| 5931–5945 | `p1:prop:finite-coordinate-compression-defect` | `VERIFIED` | 11087–11096 | 0 |
| 5952–6008 | `p1:thm:s3one-cliffordization` | `VERIFIED` | 6010–6017 | 1 |
| 6019–6052 | `p1:prop:s3one-even-clifford-sign-transport` | `VERIFIED` | 6054–6065 | 1 |
| 6067–6086 | `p1:rem:s3one-exceptional-action-contract` | `FORMALIZED` | — | 0 |
| 6090–6115 | `p1:thm:s3one-commutant-line` | `VERIFIED` | 6117–6124 | 0 |
| 6126–6148 | `p1:cor:level-one-operator-algebra-dimensions` | `VERIFIED` | 6150–6166 | 2 |
| 6176–6223 | `p1:rem:s3one-two-fifteens` | `FORMALIZED` | — | 0 |
| 6225–6256 | `p1:prop:scalar-shell-visibility-lift` | `VERIFIED` | 6258–6266 | 0 |
| 6268–6288 | `p1:cor:s3one-finite-carrier-atlas` | `VERIFIED` | 6290–6296 | 0 |
| 6300–6331 | `p1:def:s3one-rank-three-support` | `FORMALIZED` | — | 0 |
| 6337–6362 | `p1:def:s3one-trimer-zero-extension` | `FORMALIZED` | — | 0 |
| 6364–6385 | `p1:prop:s3one-trimer-adjacency-compression` | `VERIFIED` | 6387–6394 | 2 |
| 6396–6468 | `p1:thm:s3one-trimer-bose-mesner-interface` | `VERIFIED` | 6470–6502 | 8 |
| 6504–6529 | `p1:cor:s3one-trimer-operator-corner` | `VERIFIED` | 6531–6536 | 1 |
| 6542–6572 | `p1:def:s3one-finite-cell` | `FORMALIZED` | — | 0 |
| 6574–6593 | `p1:thm:s3one-finite-cell-structure` | `VERIFIED` | 6595–6619 | 0 |
| 6621–7068 | `p1:thm:s3one-numerical-data` | `VERIFIED` | 7070–7172 | 34 |
| 7175–7606 | `p1:thm:s3one-structural-invariants` | `VERIFIED` | 7608–7706 | 14 |
| 7708–7727 | `p1:def:primitive-hurwitz-cell-scalarizer` | `FORMALIZED` | — | 0 |
| 7729–7735 | `p1:rem:primitive-hurwitz-cell-scalarizer-scope` | `FORMALIZED` | — | 0 |
| 7737–7841 | `p1:thm:s3one-classical-completions` | `VERIFIED` | 7843–7884 | 5 |
| 7903–7926 | `p1:prop:math-twentyfourcell-bose-mesner` | `VERIFIED` | 7928–7933 | 14 |
| 7943–7965 | `p1:prop:h1-e15-left-2t-obstruction` | `VERIFIED` | 11318–11340 | 1 |
| 7973–8010 | `p1:prop:h1-scalar-hurwitz-evaluation-bridge` | `VERIFIED` | 8012–8030 | 3 |
| 8032–8065 | `p1:prop:math-protected-clifford-fierz` | `VERIFIED` | 8067–8083 | 2 |
| 8085–8103 | `p1:prop:math-trimer-weyl-a2` | `VERIFIED` | 8105–8128 | 1 |
| 8130–8150 | `p1:prop:math-h1-coordinate-coupling-graph` | `VERIFIED` | 8152–8154 | 1 |
| 8169–8242 | `p1:cor:s3one-finite-package` | `VERIFIED` | 8244–8258 | 0 |

## Evidence qualification and reproducibility

Of the **47 substantive theorem/proposition/corollary statements**, **30** have direct claim-linked executable exact controls, while **17** carry individual independent algebraic or representation-theoretic proof checks rather than claim-linked executable tests. Three definitions/remarks also have related executable illustrative controls without being counted as new theorems. The claim ledger records these evidence modes separately. The externally imported SDP result is not independently reconstructed.

## Reproducibility and next batch

Batch 3 deliverables: `Paper1B-ExceptionalGeometryRigorousAuditBatch3-v1_2.md`; `Paper1B-ExceptionalGeometryRigorousAuditBatch3Ledger-v1_2.json` (68 statements, proof locators, role scopes, source-reference ownership, issue carry); `Paper1B-Batch3-IndependentExactControls-v1_1.json` (90 checks); `Paper1B-Batch3-IndependentChecks-v1_1.py` (runnable checker; exact source SHA guard).

**Next batch:** commence source line **8295** with `p1:prop:cone-tangential-symbol-split`, proceed as far as rigorous evidence allows. **Only after the last batch** integrate current-source nodes/condition aliases/material graph edges and carry all nine issues into the existing archives, preserving historical data and using the latest-version-only packaging. Current upstream archive names are `Paper00-DAGAtlas-v1_136(1).zip` and `Paper00-ProofChainAudits-v1_52(1).zip`; the final outputs should increment the suffix from **these** latest inputs, not follow older speculative filenames.

**No paper TeX edited, no DAG ZIP exported, no proof-chain audit ZIP exported, no full-paper verification status assigned.**

