# Paper I-B — Exceptional Geometry, rigorous DAG correctness audit — Batch 2

**Audit unit:** `Paper1B-ExceptionalGeometry-v1_7.tex` (19,479 lines; SHA-256 `67ae02d9843853b6396f339eb4ec7184abd9258d5d6b8335bd757c929b5fa89b`). **Protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md`, no theory development or source rewrites. **Source interval:** lines **1914–4599**, inclusive, continuing precisely after the Batch 1 boundary. **Last audited proof:** corollary `p1:cor:carrier-q0`, lines 4583–4598. **Next:** line 4600, formal claim line 4603.

## Coverage verdict

- **Batch 2:** **66 formal environments** (18 theorems, 16 propositions, 18 corollaries, 1 lemma, 6 definitions, 7 remarks); 52 explicit proof environments and one direct corollary without separate proof. **53 VERIFIED**, **13 FORMALIZED**. None refuted; no newly established incorrect mathematical step or logical gap.
- **Cumulative:** **112/480** formal source claims assessed (**23.33%**). **86 VERIFIED**, **6 REPRODUCED**, **20 FORMALIZED** across Batches 1–2. This remains a **partial audit**, not a blanket verification of Paper I-B.
- **Independent reproduction:** **115/115 controls pass**, exact integer, rational, Q(sqrt 5), finite-permutation and quaternionic group tests, plus one precision cross-check against a documented exact Coxeter formula. The controls are **claim-matched**; independent finite tests do not certify unstated physical dynamics.
- **New root finding:** `BH-IBX-SRC-0001` (minor source ownership/provenance mismatch). **Eight earlier Batch 1 issue IDs remain carried**, including six missing independent exact E3 certificates that are *not automatically closed* by unrelated Batch 2 tests. **Total tracked issues: 9.**

## Proof checks and guards

**Homogeneous fork and induced representations (1914–2411).** The rank `1,2,5` carriers, the 5-cell `1 ⊕ 4` decomposition, H-fixed two-plane, transported N/H parity, overlap `9/10`, the outer C3 3-cycle's `1+1+1+2` resolution, and central sign retained under induction are algebraically correct. The map `Θ` transports the N/H action; it is **not** an inclusion N⊂I. Checked group actions/permutation characters and matrices independently.

**Exceptional group, invariant ring and 600-cell (2412–3205).** Directly enumerated the 120 unit 600-cell quaternions over **Q(sqrt5)**; all **14,400** products remain in the group; each is norm-one, inverse closed, the 12-element highest positive shell forms one full conjugacy orbit, and exact commutators generate all 120 elements. Independently evaluated the SU(2) Molien class-trace formula for 2T,2O,2I and matched all three rational expressions **identically**. Verified the Hurwitz→D4 orthogonal map, 24-cell distance shells `1,8,6,8,1`, and eight nearest neighbors. The 2I degree-12 claim relies on projective orbit products and the absence of characters; **it does not assert an independent physical selection**.

**Cube link, Clifford algebra and trimer (3206–4169).** Exhaustively checked the signed Walsh cocycle for all 512 triples in `(Z2)^3`, generator squares and anticommutation, the 56-entry evaluation support, and GL(3,2) transitivity (order 168). Exact quaternionic calculations reproduce all rooted trimer Gram, `C_Δ=J−I`, inverse `K_V=J/2−I`, exterior-square `K_Λ²=(J−I)/2`, reciprocal positive return, six-cycle and two nearest perfect matchings. E4 distinction: the natural root involution pairs **opposite** hexagon vertices; it does not choose either nearest-neighbor transport. The trimer Hermitian slice has real dimension **five**, while `End(C³)` has complex dimension **nine**; the paper correctly keeps these separate. The `1/8,1/7,1/9` weights are declared inverse dimensions, **not dynamically derived couplings**. A rank-one factor has normalized log readout `X^(1/8)`; an all-octet scalar action gives `X`.

**Coxeter/space forms/Hopf–Clifford (4170–4599).** Cross-checked cell dihedral angles (24-cell 120°, 120-cell 144°, 600-cell approximately 164.478°) against an exact independent Coxeter formula, keeping them separate from orthoscheme angles. The Hurwitz maximal-order and elliptization results are **correctly scoped imports from established mathematics**—not self-contained reconstructed proofs of the source references. The finite free quotient is compatible with Laplace spectral projection via degree-normalized pullback; the source correctly excludes arbitrary non-equivariant truncations and unconstrained spinor bundles. The Hopf group action has **diagonal central Z2 kernel**, giving the effective U(2) quotient, while 7×8=56 is a finite linear-data count rather than a canonical intermediate flag or physical excitation.

**Nonformal statements also reviewed:** the exceptional group/ADE and invariant-ring tables at lines 2414–2429 and 2844–2921, unit 24-cell polytope table at 3000–3017, and the lens-space and Seifert/Hopf convention qualifications at 4363–4388. The E6/E7/E8 root counts 72/126/240 are not identified with dimension-product observables.

## Precise issues (all found in this batch and carried forward)

### `BH-IBX-SRC-0001` — DAG_COVERAGE / minor / OPEN (new)

- **First origin:** `Paper1B-ExceptionalGeometry-v1_7.tex:3992`, within `p1:cor:finite-trimer-pair-supports` (lines 3976–3998).
- **Source-as-printed:** “This trimer-pair construction is the primary Paper-I-A geometric source of the nine-dimensional carrier.”
- **Issue:** In the current supplied paper corpus the named trimer-pair construction and its label are in **Paper I-B**; current `Paper1A-Geometry-v5_176.tex` does not contain that claim/label. This is a manuscript-attribution issue after migration, not a challenge to the identity `dim End(C³)=9`.
- **Required resolution:** Repair the in-text paper attribution and associated current-owner mapping when source updates are separately authorized; **no `.tex` edited in this audit**.
- **Downstream:** no verified material chain to another paper found. Possible misdirected source attribution only; the 9-dimensional carrier has an independent correct construction.

### `BH-IBX-DAG-0001` and `BH-IBX-DAG-0002` — earlier DAG coverage findings (carried, not duplicated)

The historical DAG Paper1B audit still refers to M8 Geometry; the **current** target is Exceptional Geometry. This batch adds **62 historically Paper1A-owned claim IDs** and **4 not-yet-canonical remarks** to the 18/28 counts already frozen in Batch 1; across the audited 112 current claims the mismatch is **80 stale owner IDs plus 32 missing current nodes**. The source anchor map is a locator, not a verification certificate. No historical graph status has been overwritten or globally downgraded.

### `BH-IBX-EV-0001`–`BH-IBX-EV-0006` — earlier missing exact E3 evidence (carried)

Six Batch 1 source-specific exact independent certificates are still needed, respectively for pentagon holonomy/flux (`500–526`), 600-cell induced Petersen graph (`723–751`), quaternionic angular-orbit classification (`769–796`), tangent exact sequence and D3-equivariance (`811–860`), rooted five-core leakage sum identities (`919–955`), and quadrupole Gram identity (`975–994`). Those claims remain **REPRODUCED**, not refuted, and are **not** retroactively promoted by this batch's separate controls.

## Per-claim disposition and evidence pointers

| Lines | Claim | Disposition | Independent evidence |
|---:|---|---|---|
| 1942–1968 | `p1:def:homogeneous-core-readout` | `FORMALIZED` | Definition/qualified scope |
| 1970–2133 | `p1:thm:exceptional-core-visibility` | `VERIFIED` | 12 exact checks |
| 2183–2207 | `p1:cor:exceptional-aggregation-order` | `VERIFIED` | 11 exact checks |
| 2223–2296 | `p1:thm:five-cell-trimer-resolution` | `VERIFIED` | 6 exact checks |
| 2327–2376 | `p1:prop:center-sensitive-induced-exceptional-fork` | `VERIFIED` | Independent theorem-level reasoning |
| 2431–2451 | `p1:rem:dynkin-not-subgroup` | `FORMALIZED` | Definition/qualified scope |
| 2468–2488 | `p1:prop:exceptional-abelianizations` | `VERIFIED` | 6 exact checks |
| 2510–2528 | `p1:lem:projective-orbit-product-character` | `VERIFIED` | Independent theorem-level reasoning |
| 2538–2552 | `p1:thm:2I-shell-degree-twelve` | `VERIFIED` | 20 exact checks |
| 2572–2585 | `p1:cor:2I-one-shell-datum` | `VERIFIED` | 3 exact checks |
| 2587–2591 | `p1:cor:character-free-exceptional` | `VERIFIED` | 4 exact checks |
| 2598–2610 | `p1:thm:axis-character-free-selector` | `VERIFIED` | 4 exact checks |
| 2621–2638 | `p1:cor:conditional-exceptional-role-order` | `VERIFIED` | 4 exact checks |
| 2651–2668 | `p1:def:exceptional-support-role-atlas` | `FORMALIZED` | Definition/qualified scope |
| 2670–2704 | `p1:thm:trimer-axis-binary-support-range` | `VERIFIED` | 2 exact checks |
| 2723–2730 | `p1:rem:trimer-axis-range-not-occurrence` | `FORMALIZED` | Definition/qualified scope |
| 2732–2744 | `p1:prop:element-orders` | `VERIFIED` | Independent theorem-level reasoning |
| 2759–2764 | `p1:cor:common-order3-core` | `VERIFIED` | 2 exact checks |
| 2813–2830 | `p1:prop:exceptional-space-forms` | `VERIFIED` | 4 exact checks |
| 2931–2936 | `p1:prop:exceptional-lattice` | `VERIFIED` | 1 exact checks |
| 2960–2964 | `Paper1B-remark-2960` | `FORMALIZED` | Definition/qualified scope |
| 2966–2984 | `p1:cor:exported-exceptional-carrier-skeleton` | `VERIFIED` | 1 exact checks |
| 3020–3032 | `p1:prop:24cell-adjacency` | `VERIFIED` | 3 exact checks |
| 3050–3076 | `p1:prop:hurwitz-d4-coordinate-map` | `VERIFIED` | 2 exact checks |
| 3099–3103 | `p1:prop:24cell-vertex-figure` | `VERIFIED` | 2 exact checks |
| 3110–3165 | `p1:thm:hurwitz-radial-shells` | `VERIFIED` | 2 exact checks |
| 3181–3197 | `p1:cor:2T-shell-complement-counting-atom` | `VERIFIED` | 1 exact checks |
| 3213–3225 | `p1:def:hurwitz-cube-link` | `FORMALIZED` | Definition/qualified scope |
| 3227–3235 | `p1:prop:hurwitz-link-cube` | `VERIFIED` | 2 exact checks |
| 3245–3271 | `p1:thm:hurwitz-walsh-clifford` | `VERIFIED` | 4 exact checks |
| 3326–3360 | `p1:cor:walsh-evaluation-support-56` | `VERIFIED` | 2 exact checks |
| 3369–3381 | `p1:rem:walsh-flag-noncanonical` | `FORMALIZED` | 2 exact checks |
| 3393–3420 | `p1:thm:hurwitz-diagonal-trimer` | `VERIFIED` | 3 exact checks |
| 3432–3485 | `p1:thm:axial-opposite-trimer-quaternionic-frame` | `VERIFIED` | 2 exact checks |
| 3512–3578 | `p1:thm:rooted-trimer-vector-overlap` | `VERIFIED` | 7 exact checks |
| 3607–3641 | `p1:cor:rooted-trimer-bivector-overlap` | `VERIFIED` | 4 exact checks |
| 3675–3697 | `p1:prop:projected-trimer-metric` | `VERIFIED` | 2 exact checks |
| 3714–3730 | `p1:prop:antiprism-transport-matchings` | `VERIFIED` | 2 exact checks |
| 3744–3752 | `p1:prop:diagonal-equivalence` | `VERIFIED` | 5 exact checks |
| 3764–3795 | `p1:thm:binary-dihedral-diagonal-lift` | `VERIFIED` | 7 exact checks |
| 3809–3833 | `p1:cor:generated-c6-stabilizer-link-bridge` | `VERIFIED` | 6 exact checks |
| 3847–3871 | `p1:thm:binary-dihedral-a2-weyl` | `VERIFIED` | 7 exact checks |
| 3886–3899 | `p1:prop:two-oriented-2T-presentations` | `VERIFIED` | Independent theorem-level reasoning |
| 3909–3946 | `p1:thm:cyclic-trimer-operator-grammar` | `VERIFIED` | 2 exact checks |
| 3968–3974 | `Paper1B-remark-3968` | `FORMALIZED` | Definition/qualified scope |
| 3976–3998 | `p1:cor:finite-trimer-pair-supports` | `VERIFIED` | 1 exact checks |
| 4011–4040 | `p1:cor:opposite-trimer-defects` | `VERIFIED` | 6 exact checks |
| 4069–4082 | `p1:cor:specific-finite-carrier-weights` | `VERIFIED` | 2 exact checks |
| 4091–4102 | `p1:def:normalized-octet-boundary-model` | `FORMALIZED` | Definition/qualified scope |
| 4104–4123 | `p1:prop:octet-resolved-multiplicative-substep` | `VERIFIED` | 3 exact checks |
| 4139–4156 | `p1:cor:two-octet-descendants` | `VERIFIED` | 2 exact checks |
| 4177–4202 | `p1:prop:coxeter-angle-data` | `VERIFIED` | 3 exact checks |
| 4219–4232 | `p1:def:hurwitz-integers` | `FORMALIZED` | Definition/qualified scope |
| 4234–4239 | `p1:thm:hurwitz-maximal-order` | `VERIFIED` | Established imported theorem |
| 4253–4262 | `p1:thm:hurwitz-units-maximal-order` | `VERIFIED` | 1 exact checks |
| 4275–4280 | `p1:cor:hurwitz-units-24cell-vertices` | `VERIFIED` | 1 exact checks |
| 4293–4298 | `p1:thm:elliptization-spherical-space-form` | `VERIFIED` | Established imported theorem |
| 4304–4312 | `p1:cor:left-quotient-spherical-space-forms` | `VERIFIED` | Independent theorem-level reasoning |
| 4319–4349 | `p1:prop:quotient-invariant-restriction` | `VERIFIED` | 3 exact checks |
| 4386–4388 | `Paper1B-remark-4386` | `FORMALIZED` | Definition/qualified scope |
| 4390–4394 | `p1:cor:simply-connected-positive-curvature-model` | `VERIFIED` | Independent theorem-level reasoning |
| 4412–4468 | `p1:thm:hopf-clifford-finite-carrier` | `VERIFIED` | 2 exact checks |
| 4485–4493 | `Paper1B-remark-4485` | `FORMALIZED` | Definition/qualified scope |
| 4495–4519 | `p1:def:finite-carrier-weight` | `FORMALIZED` | Definition/qualified scope |
| 4522–4568 | `p1:thm:septet-octet-resolution-module` | `VERIFIED` | 2 exact checks |
| 4583–4591 | `p1:cor:carrier-q0` | `VERIFIED` | 1 exact checks |

## Typed dependencies, source ownership, and release boundary

- **All source references in this batch resolve in the current papers ZIP**; four cross-paper prerequisite labels resolve in current Paper I-A (`p1:thm:exceptional-normalizer-fork`, `p1:prop:exceptional-nesting`, `p1:prop:contact-normalization`, `p1:prop:unit-quaternion-left-right-actions`). The Paper I-D trimer-spectra appendix is reference context, not a re-audited Paper I-D theorem.
- The JSON ledger records explicit proof-reference candidates, source witnesses, imported theorem ownership and condition-first-appearance pointers. A bare reference does not become a verified material edge. This batch **does not modify** the historical DAG or create duplicate global assumption nodes.
- **No final ZIPs in Batch 2.** The final batch must integrate all Batch 1…N claims, typed conditions, gaps, impact routes and verification provenance into the preserved existing global DAG, and then export and read back exactly the latest `Paper00-DAGAtlas-v1_135.zip` and `Paper00-ProofChainAudits-v1_51.zip`, with only the required latest-version members. These are **future release obligations**, not files promised as already created.

## Batch 2 artifacts

- `Paper1B-ExceptionalGeometryRigorousAuditBatch2Ledger-v1_1.json`: 66 source statements/proofs, statuses, source refs, canonical-owner checks, typed proof-link candidates and new issue.
- `Paper1B-Batch2-IndependentExactControls-v1_1.json`: 115 exact/independent tests and specifications.
- `Paper1B-Batch2-IndependentChecks-v1_1.py`: executable independent tests (source fingerprinted).
- `Paper1B-ExceptionalGeometryRigorousAuditBatch1Ledger-v1_1.json`: preserved preceding batch, not superseded.

**Scope:** This is source-proof correctness only, not a physical theory extension, paper rewrite, or PDF/appearance audit.
