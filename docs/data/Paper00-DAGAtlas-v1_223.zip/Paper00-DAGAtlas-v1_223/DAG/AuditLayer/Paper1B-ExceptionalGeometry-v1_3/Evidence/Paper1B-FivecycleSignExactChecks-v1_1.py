#!/usr/bin/env python3
"""Independent exact finite A5 character/frame contrast certificate for current Paper I-B."""
import itertools, json, numpy as np
from pathlib import Path

def inverse(p):
    q=[0]*5
    for j,k in enumerate(p): q[k]=j
    return tuple(q)
def compose(p,q):return tuple(p[q[k]] for k in range(5))
def even(p):return sum(p[i]>p[j] for i in range(5) for j in range(i+1,5))%2==0
def perm_mat(p):
    x=np.zeros((5,5),dtype=np.int64)
    for j,k in enumerate(p):x[k,j]=1
    return x

G=tuple(p for p in itertools.permutations(range(5)) if even(p))
assert len(G)==60
cycle=(1,2,3,4,0)
C_A={compose(compose(h,cycle),inverse(h)) for h in G}
assert len(C_A)==12
C5={p for p in G if len({p,compose(p,p),compose(compose(p,p),p),compose(compose(compose(p,p),p),p)})==4 and p!=tuple(range(5))}
# A 5-cycle has order five; nonidentity powers form four distinct elements.
assert len(C5)==24
C_B=C5-C_A
assert len(C_B)==12
J=np.ones((5,5),dtype=np.int64)
I=np.eye(5,dtype=np.int64)
K=np.zeros((25,25),dtype=np.int64)
N=np.zeros((25,25),dtype=np.int64)
for p in G:
    if p not in C5:continue
    sign=1 if p in C_A else -1
    P=perm_mat(p)
    chi=np.trace(P)-1
    Z20=20*P+(chi-4)*J-5*chi*I
    # f_g = Z20/(20 sqrt(15)); D_5 = N/6000.
    N+=sign*np.outer(Z20.ravel(),Z20.ravel())
    # rho(g) X = P_g X P_g^{-1} on full matrix space.
    K+=sign*np.kron(P,P)
checks={
 'A5_group_size':int(len(G)),
 'each_fivecycle_class_size':int(len(C_A)),
 'K_plus_15D_exact':bool(np.array_equal(400*K+N,np.zeros((25,25),dtype=np.int64))),
 'K_cubed_80K_exact':bool(np.array_equal(K@K@K,80*K)),
 'trace_K2':int(np.trace(K@K)),
 'trace_KD':int(np.trace(K@N)//6000),
 'trace_D2_numer_over_6000_squared':int(np.trace(N@N)),
 'rank_K':int(np.linalg.matrix_rank(K.astype(float))),
 'rank_N':int(np.linalg.matrix_rank(N.astype(float))),
 'v1_8_positive_sign_proposal_holds':bool(np.array_equal(400*K-N,np.zeros((25,25),dtype=np.int64))),
}
assert checks['K_plus_15D_exact']
assert checks['K_cubed_80K_exact']
assert checks['trace_K2']==480
assert checks['trace_KD']==-32
assert checks['rank_K']==6
assert checks['rank_N']==6
assert not checks['v1_8_positive_sign_proposal_holds']
# D^2 norm = 32/15 => N^2 trace = (32/15)*6000^2 = 76,800,000.
assert checks['trace_D2_numer_over_6000_squared']==76800000
out=Path('/mnt/data/Paper1B-FivecycleSignExactControls-v1_1.json')
out.write_text(json.dumps({'source':'Paper1B-ExceptionalGeometry-v1_8.tex', 'target_label':'p1:prop:v343-fivefold-signed-contrast', 'integer_matrix_convention':'D5=N/6000, K=sum_{5A}P_g x P_g^T - sum_{5B}P_g x P_g^T','checks':checks},indent=2)+'\n')
print(json.dumps(checks,indent=2))
