#!/usr/bin/env python3
"""Independent exact certificate for Paper I-B v1.8 F40 representation, minimal quintet,
Petersen quintet and spin-two invariant defects. Runs with Python+SymPy only.
No framework/DAG/archive writes. Claims strictly conditional on native F40 orbit identification.
"""
import itertools, json
from pathlib import Path
from collections import Counter
from sympy import Matrix, eye, zeros, Rational, sqrt, simplify, factor, kronecker_product

OUT = Path('/mnt/data/Paper1B-F40Spin2VertexExactControls-v1_1.json')
checks=[]
def ck(name, got, want=True):
    ok = (got == want)
    checks.append({'id':name,'passed':bool(ok)})
    if not ok: raise AssertionError(f'{name}: got {got!r}, expected {want!r}')
def compose(p,q): return tuple(p[q[i]] for i in range(5))
def inv(p): return tuple(p.index(i) for i in range(5))
def perm_sign(p):
    return (-1) ** sum(p[i]>p[j] for i in range(5) for j in range(i+1,5))
def order(p):
    q=p; n=1
    while q != ID: q=compose(p,q); n+=1
    return n

ID=tuple(range(5))
G=tuple(p for p in itertools.permutations(range(5)) if perm_sign(p)==1)
ck('A5-group-size',len(G),60)
Gset=set(G)
ck('A5-closure',all(compose(a,b) in Gset for a in G for b in G))
classes=[]; unseen=set(G)
while unseen:
    g=min(unseen)
    cc={compose(compose(h,g),inv(h)) for h in G}
    classes.append((g,cc));unseen -= cc
classes.sort(key=lambda x:(order(x[0]),x[0]))
ck('A5-class-sizes',sorted(len(x[1]) for x in classes),[1,12,12,15,20])
classes_by_order={}
for g,c in classes: classes_by_order.setdefault(order(g),[]).append((g,c))
cls=[classes_by_order[1][0],classes_by_order[2][0],classes_by_order[3][0]]+classes_by_order[5]
ck('A5-class-order',[order(x[0]) for x in cls],[1,2,3,5,5])
sizes=[len(x[1]) for x in cls]
ck('A5-class-size-ordered',sizes,[1,15,20,12,12])

# The native F40 edge model identifies the 60 edges with C_5 x 5 labels.
# This calculation checks that the induced G action is regular, independently
# of trusting a character table or a claimed rank.
shell=tuple(cls[3][1]); edge_labels=[(g,i) for g in shell for i in range(5)]
ck('shell-12-vertex-class',len(shell),12)
ck('edge-label-60',len(edge_labels),60)
fixedE={}
for a in G:
    fx=sum(compose(compose(a,g),inv(a))==g and a[i]==i for g,i in edge_labels)
    fixedE[a]=fx
    ck('edge-regular-'+''.join(map(str,a)),fx,60 if a==ID else 0)

# Two vertex orbits with stabilizer C3; each orbit has 20 points.
g3=cls[2][0]
H={ID,g3,compose(g3,g3)}
ck('threefold-stabilizer-order',len(H),3)
cosets=sorted({frozenset(compose(g,h) for h in H) for g in G},key=lambda c:sorted(c)[0])
ck('each-C3-coset-size',set(len(c) for c in cosets),{3})
ck('number-C3-cosets',len(cosets),20)
fxV={}
for a in G:
    fx=2*sum(frozenset(compose(a,x) for x in c)==c for c in cosets)
    fxV[a]=fx
    ck('vertex-fixed-'+''.join(map(str,a)),fx,40 if a==ID else (4 if order(a)==3 else 0))
chiZ=[]
for g,c in cls:
    vals={fixedE[a]-fxV[a]+1 for a in c}
    ck('cycle-character-class-'+str(order(g))+str(g),len(vals),1)
    chiZ.append(vals.pop())
ck('cycle-character-F40',chiZ,[21,1,-3,1,1])

# Exact character ring of real A5 irreps.
phi=(1+sqrt(5))/2; phibar=(1-sqrt(5))/2
irr={
 '1': [1,1,1,1,1],
 '3': [3,-1,0,phi,phibar],
 "3'": [3,-1,0,phibar,phi],
 '4': [4,0,1,-1,-1],
 '5': [5,1,-1,0,0],
}
def ip(a,b): return simplify(Rational(1,60)*sum(s*x*y for s,x,y in zip(sizes,a,b)))
for n,v in irr.items():
    for m,w in irr.items(): ck('character-orthogonality-'+n+'-'+m,ip(v,w),int(n==m))
chiEnd=[x*x for x in irr['5']]
ck('twisted-end25-character',chiEnd,[25,1,1,0,0])
multEnd={n:ip(chiEnd,v) for n,v in irr.items()}
multZ={n:ip(chiZ,v) for n,v in irr.items()}
ck('end25-irrep-decomposition',multEnd,{'1':1,'3':1,"3'":1,'4':2,'5':2})
ck('F40-cycle-irrep-decomposition',multZ,{'1':0,'3':1,"3'":1,'4':0,'5':3})
maxrank=sum(int(irr[n][0])*min(int(multZ[n]),int(multEnd[n])) for n in irr)
missing={n:int(multZ[n]-min(multZ[n],multEnd[n])) for n in irr}
ck('maximal-equivariant-rank',maxrank,16)
ck('unique-minimal-module-isotype',missing,{'1':0,'3':0,"3'":0,'4':0,'5':1})
ck('minimal-repair-dim',sum(int(irr[n][0])*v for n,v in missing.items()),5)
ck('comparison-space-complement',{
    n:int(multEnd[n]+missing[n]-multZ[n]) for n in irr},
    {'1':1,'3':0,"3'":0,'4':2,'5':0})
ck('symmetric-invariant-quadratic-dim',sum(int(v)*(int(v)+1)//2 for v in multZ.values()),8)

# Petersen Kneser graph KG(5,2): the five-dimensional isotypic repair
# already occurs in its 10-edge/pair module, no ambient invented irrep.
pairs=list(itertools.combinations(range(5),2)); A=Matrix(10,10,lambda i,j: int(set(pairs[i]).isdisjoint(pairs[j])))
ck('Petersen-charpoly',factor(A.charpoly().as_expr()),factor((A.charpoly().gen-3)*(A.charpoly().gen-1)**5*(A.charpoly().gen+2)**4))
P5=-(A-3*eye(10))*(A+2*eye(10))/6
ck('Petersen-projector-idempotence',P5*P5,P5)
ck('Petersen-projector-rank',P5.rank(),5)
ck('Petersen-projector-A-eigen',A*P5,P5)
ck('Petersen-projector-orthogonal',P5.T,P5)
for g in G:
    R=Matrix(10,10,lambda i,j: int(set(pairs[i])=={g[x] for x in pairs[j]}))
    ck('P5-A5-intertwining-'+''.join(map(str,g)),R*P5,P5*R)

# Full matrix-coefficient Schur orthogonality from an explicitly constructed
# rational 5-dimensional Petersen realization of A5.  The two central lifts
# give the coefficient Gram on 2I.  This does not assume a given numerical Gram.
B=Matrix.hstack(*P5.columnspace())
ck('quintet-rational-basis-rank',B.rank(),5)
metric=B.T*B
metric_inv=metric.inv()
G25=zeros(25,25)
for g in G:
    Pg=Matrix(10,10,lambda i,j: int(set(pairs[i])=={g[x] for x in pairs[j]}))
    Rg=metric_inv*B.T*Pg*B
    ck('quintet-exact-intertwiner-'+''.join(map(str,g)),B*Rg,Pg*B)
    ck('quintet-metric-preserved-'+''.join(map(str,g)),Rg.T*metric*Rg,metric)
    v=Matrix(25,1,list(Rg))
    G25 += v*v.T
ck('A5-25-matrix-coefficient-Gram',G25,12*kronecker_product(metric_inv,metric))
ck('2I-25-matrix-coefficient-Gram',2*G25,24*kronecker_product(metric_inv,metric))

# Scalar harmonic host checks for the degree-four and degree-two comparison spaces.
# The source's sqrt(12) v^T Q v isometry is a S^3 Haar-moment identity,
# not a proposed physical spinor occurrence.
from sympy import binomial
ck('S3-harmonic-degree4-dimension',binomial(7,3)-binomial(5,3),25)
ck('S3-harmonic-degree4-Laplacian-eigenvalue',4*(4+2),24)
ck('S3-harmonic-degree2-Laplacian-eigenvalue',2*(2+2),8)
qbasis=[Matrix([[1,0,0],[0,-1,0],[0,0,0]]),
        Matrix([[1,0,0],[0,1,0],[0,0,-2]]),
        Matrix([[0,1,0],[1,0,0],[0,0,0]]),
        Matrix([[0,0,1],[0,0,0],[1,0,0]]),
        Matrix([[0,0,0],[0,0,1],[0,1,0]])]
for i,Q in enumerate(qbasis):
    ck('trace-free-quad-'+str(i),Q.trace(),0)
    for j,R in enumerate(qbasis):
        # E[(v^T Q v)(v^T R v)] = (trQ trR + 2 trQR)/(4*6).
        sphere_moment=Rational(1,24)*(Q.trace()*R.trace()+2*(Q*R).trace())
        ck('sqrt12-quintet-isometry-'+str(i)+'-'+str(j),12*sphere_moment,(Q*R).trace())

# Restrict SU2 integer-spin j reps to A5; compute exact fixed-line counts.
# For rotation by 2*pi*a/n, chi_j=1+2 sum_{m=1}^j cos(2*pi*m*a/n).
cos5={0:1,1:(sqrt(5)-1)/4,2:-(sqrt(5)+1)/4,3:-(sqrt(5)+1)/4,4:(sqrt(5)-1)/4}
def spin_char(j):
    c2=1+2*sum((-1)**k for k in range(1,j+1))
    c3=1+2*sum(1 if k%3==0 else Rational(-1,2) for k in range(1,j+1))
    c51=simplify(1+2*sum(cos5[k%5] for k in range(1,j+1)))
    c52=simplify(1+2*sum(cos5[(2*k)%5] for k in range(1,j+1)))
    return [2*j+1,c2,c3,c51,c52]
spinfixed={}
for j in range(9):
    v=spin_char(j)
    f=ip(v,irr['1'])
    spinfixed[j]=f
    ck('SO3-spin-'+str(j)+'-A5-fixed',f,1 if j in (0,6) else 0)
ck('spin2-is-the-A5-quintet',spin_char(2),irr['5'])

# Exact SU2 spin fusion rules (no prefixed continuum multiplicities).
d={0:1}
summary={}
for k in range(1,5):
    nd=Counter()
    for j,m in d.items():
        for t in range(abs(j-2),j+3): nd[t]+=m
    d=dict(nd)
    cont=d.get(0,0)
    finite=ip([x**k for x in irr['5']],irr['1'])
    extra=finite-cont
    spin6=d.get(6,0)
    ck('SU2-tensor-invariant-rank-k'+str(k),cont,[0,0,1,1,5][k])
    ck('binary-icosa-tensor-invariant-rank-k'+str(k),finite,[0,0,1,2,11][k])
    ck('spin6-saturated-defect-k'+str(k),extra,spin6)
    ck('source-defect-k'+str(k),extra,[0,0,0,1,6][k])
    ck('isotypic-dimension-k'+str(k),sum((2*j+1)*m for j,m in d.items()),5**k)
    summary[k]={'su2_invariants':int(cont),'2I_invariants':int(finite),
                'defect_rank':int(extra),'spin6_multiplicity':int(spin6),
                'su2_spin_decomposition':{str(j):int(m) for j,m in sorted(d.items())}}

record={'batch':'Paper1B-ClosureDerivationsBatch4-v1_1',
        'target_source':'Paper1B-ExceptionalGeometry-v1_8.tex',
        'scope':'Representation-level F40/A5 minimal quintet and SU2-vs-2I tensor invariant defects; conditional on upstream F40 orbit identification; no physical realization',
        'checks_total':len(checks),'checks_passed':sum(c['passed'] for c in checks),
        'checks':checks,'derived':{'F40_cycle_character':chiZ,
              'End5_decomposition':{k:int(v) for k,v in multEnd.items()},
              'F40_cycle_decomposition':{k:int(v) for k,v in multZ.items()},
              'max_equivariant_map_rank':maxrank,'minimal_repair':missing,
              'spin_fixed_j_le8':{str(j):int(v) for j,v in spinfixed.items()},
              'tensor_invariants':summary,
              'remaining_source_issue':'p1:prop:v343-fivefold-signed-contrast prints +15D5; independently corrected to -15D5 in Batch1'}}
OUT.write_text(json.dumps(record,indent=2),encoding='utf-8')
print('PASS',record['checks_passed'],'/',record['checks_total'],'exact checks')
print('character Z',chiZ,'maxrank',maxrank,'defect',[(k,v['defect_rank']) for k,v in summary.items()])
print('Wrote',OUT)
