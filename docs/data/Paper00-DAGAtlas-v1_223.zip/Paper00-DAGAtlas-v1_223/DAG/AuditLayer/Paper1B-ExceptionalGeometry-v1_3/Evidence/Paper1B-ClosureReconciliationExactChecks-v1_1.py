#!/usr/bin/env python3
"""Final read-only closure reconciliation for Paper I-B v1.8.

Independent source-matched exact certificates for EV-0007 (Hurwitz sextic Haar
moments) and EV-0008 (five coordinate-control Lie dimensions). Includes an
integer recheck of the adversarial five-cycle sign and a source drift census.
No manuscript, framework, DAG or ZIP archive is changed.
"""
from __future__ import annotations
from collections import Counter
from fractions import Fraction
from itertools import permutations, combinations
from pathlib import Path
from zipfile import ZipFile
from math import factorial, prod
import hashlib,json,re
import numpy as np
import sympy as S

ROOT=Path('/mnt/data')
SRC=ROOT/'paper1b_closure_batched/Paper1B-ExceptionalGeometry-v1_8.tex'
OLD=ROOT/'paper1b_closure_batched/Paper1B-ExceptionalGeometry-v1_7.tex'
PAPERS=ROOT/'Paper00-PapersMinimal-v3_014(1).zip'
OUT=ROOT/'Paper1B-ClosureReconciliationExactControls-v1_1.json'
checks=[]
def ck(key,got,want=True,detail=None):
    ok=bool(got==want)
    checks.append({'id':key,'passed':ok,'actual':str(got),'expected':str(want),'detail':detail})
    if not ok:raise AssertionError(f'{key}: {got!r} != {want!r}')

# Freeze the paper source, checking it actually matches the supplied ZIP.
current=SRC.read_bytes();old=OLD.read_bytes();
with ZipFile(PAPERS) as z:
    ck('freeze-source-zip-identity',hashlib.sha256(current).hexdigest(), hashlib.sha256(z.read('Paper1B-ExceptionalGeometry-v1_8.tex')).hexdigest())
    pp1c=z.read('Paper1C-M8Geometry-v1_138.tex').decode('utf8')
    pp1a=z.read('Paper1A-Geometry-v5_177.tex').decode('utf8')
    names=z.namelist()
sha=hashlib.sha256(current).hexdigest()
ck('freeze-source-sha256',sha,'a03b4db5014afb21824ef58bd5931d1d943eee6f8defc24b77017ebd8dd4f4d5')

def counts(text):
    return {typ:len(re.findall(r'\\begin\{'+typ+r'\}',text)) for typ in ('theorem','proposition','corollary','definition','remark','lemma')}
current_types=counts(current.decode('utf8'));old_types=counts(old.decode('utf8'))
ck('source-new-formal-types', {k:current_types[k]-old_types[k] for k in current_types},
    {'theorem':1,'proposition':1,'corollary':0,'definition':0,'remark':1,'lemma':0})
ck('source-current-formal-count',sum(current_types.values()),483)

# Exact source-to-source five-cycle correction and double-odd coefficient.
p=97; aa=np.eye(5,dtype=np.int64)
def even(t):return sum(t[i]>t[j] for i in range(5) for j in range(i+1,5))%2==0
def comp(a,b):return tuple(a[b[k]] for k in range(5))
def inv_perm(t):
    out=[0]*5
    for i,x in enumerate(t):out[x]=i
    return tuple(out)
def Pmat(t):
    P=np.zeros((5,5),dtype=np.int64)
    for j,k in enumerate(t):P[k,j]=1
    return P
perms=[t for t in permutations(range(5)) if even(t)]
ck('A5-size',len(perms),60)
cycles=[t for t in perms if len({t[(i+1)%5] for i in range(5)})==5 and all(t[i]!=i for i in range(5)) and all(t[t[i]]!=i for i in range(5))]
# Determine the two 12-element conjugacy classes by exact conjugation.
chosen=cycles[0]; C1={comp(comp(g,chosen),inv_perm(g)) for g in perms}
C2=set(cycles)-C1
ck('two-5cycle-classes',(len(C1),len(C2)),(12,12))
K=np.zeros((25,25),dtype=np.int64);N=np.zeros((25,25),dtype=np.int64)
I5=np.eye(5,dtype=np.int64);J5=np.ones((5,5),dtype=np.int64)
for sign,cls in [(1,C1),(-1,C2)]:
    for t in cls:
        P=Pmat(t);chi=int(np.trace(P))-1
        # R=20 Z on full 5x5 matrix space.
        R=20*P+(chi-4)*J5-5*chi*I5
        K+=sign*np.kron(P,P)
        N+=sign*np.outer(R.reshape(25),R.reshape(25))
ck('fivecycle-exact-negative-sign',np.array_equal(400*K+N,np.zeros((25,25),dtype=np.int64)),True)
ck('fivecycle-printed-positive-sign-refuted',np.array_equal(400*K-N,np.zeros((25,25),dtype=np.int64)),False)
ck('fivecycle-trace-mixed',int(np.trace(K@N)//6000),-32)
ck('fivecycle-cubic',np.array_equal(K@K@K,80*K))
ck('doubleodd-cancellation', S.simplify((-15/(4*S.sqrt(5)))**2),S.Rational(45,16))
ck('paper1c-doubleodd-source-present', '\\label{p1b:thm:v343-doubleodd-contrast}' in pp1c)
ck('paper1a-delegates-trimer-to-paper1b', 'trimer pair $T_+\\sqcup T_-$' in pp1a and '& Paper~I-B' in pp1a)

# EV-0007: derive all required moments independently from polynomial sphere moments.
y=S.symbols('y0:4'); x=S.symbols('x0:4');
r2=sum(y);e2=sum(y[a]*y[b] for a,b in combinations(range(4),2));
e3=sum(y[a]*y[b]*y[c] for a,b,c in combinations(range(4),3));
H6=S.expand(r2**3-8*r2*e2+48*e3)
# In dimension four, Delta_x f(y) = sum_i (2 partial_y_i + 4 y_i partial_y_i^2).
lap=S.expand(sum(2*S.diff(H6,t)+4*t*S.diff(H6,t,2) for t in y))
ck('H6-harmonic',lap,0)


def sphere_expect(poly):
    result=S.Rational(0)
    for (a,b,c,d),coeff in S.Poly(S.expand(poly),*y).terms():
        aa=[a,b,c,d];n=sum(aa)
        weight=S.Rational(prod([factorial(2*k) for k in aa]),
              4**n*factorial(n+1)*prod([factorial(k) for k in aa]))
        result+=coeff*weight
    return S.factor(result)
ck('H6-mean',sphere_expect(H6),0)
ck('H6-square-Haar',sphere_expect(H6**2),S.Rational(1,7))
ck('H6-cube-Haar',sphere_expect(H6**3),0)
ck('H6-fourth-Haar',sphere_expect(H6**4),S.Rational(61,1001))
ck('Y6-fourth-Haar',S.factor(49*sphere_expect(H6**4)),S.Rational(427,143))
# Source's O acts by two orientation-preserving pi/4 rotations. Avoid
# denominators using the source's equivalent unnormalized -8 relation.
rot_x=(x[0]-x[1],x[0]+x[1],x[2]-x[3],x[2]+x[3]);Hx=S.expand(H6.subs(dict(zip(y,[v*v for v in x])),simultaneous=True))
rotated=S.expand(Hx.subs(dict(zip(x,rot_x)),simultaneous=True))
ck('H6-anti-invariant-exact',S.expand(rotated+8*Hx),0)
# Verified H6-harmonic implies Laplace eigenvalue l(l+2) = 48 on S^3.
ck('Y6-sphere-eigenvalue',6*(6+2),48)

# EV-0008: independent F_97 generator reconstruction, exact lower bounds.
q=97;omega=22

def invn(x):return pow(int(x)%q,-1,q)
def arr(a):return np.asarray(a,dtype=np.int64)%q
def mm(a,b):return (a@b)%q
def kr(a,b):return np.kron(a,b)%q
s1=arr([[0,1],[1,0]]);s2=arr([[0,-omega],[omega,0]]);s3=arr([[1,0],[0,-1]])
I2=np.eye(2,dtype=np.int64);Gam=[kr(s1,I2),kr(s2,I2),kr(s3,s1),kr(s3,s2)]
for a in range(4):
    for b in range(4):
        ck(f'Cl4-F97-anticommutator-{a}{b}',np.array_equal((mm(Gam[a],Gam[b])+mm(Gam[b],Gam[a]))%q,(2*(a==b)*np.eye(4,dtype=np.int64))%q))
# Native 15-dimensional chart = C e0 + V4 + Lambda2(V4) + S4.
wedges=list(combinations(range(4),2));Y=[]
for a in range(4):
    M=np.zeros((15,15),dtype=np.int64)
    M[0,1+a]=invn(2);M[1+a,0]=invn(2)
    for k,(b,c) in enumerate(wedges):
        sign=(a==b)-(a==c)
        if sign:
            other=c if a==b else b
            M[5+k,1+other]=M[1+other,5+k]=14*invn(3)*sign%q
    M[11:15,11:15]=10*invn(4)*Gam[a]
    Y.append(M%q)
I=np.eye(15,dtype=np.int64)
Q=sum(mm(M,M) for M in Y)%q
Qexpected=np.diag([1]+[11*invn(12)]*4+[4*invn(9)]*6+[3*invn(4)]*4)%q
ck('native-coordinate-Q-fingerprint',np.array_equal(Q,Qexpected))
Q0=(Q-31*invn(45)*I)%q
Omega=np.zeros((15,15),dtype=np.int64)
for perm in permutations(range(4)):
    sign=(-1)**sum(perm[i]>perm[j] for i in range(4) for j in range(i+1,4))
    T=I
    for a in perm:T=mm(T,Y[a])
    Omega=(Omega+sign*T)%q
Bstar=np.zeros((15,15),dtype=np.int64)
for a,(u,v) in enumerate(wedges):
    co=[t for t in range(4) if t not in (u,v)]
    full=[u,v,*co]
    sign=(-1)**sum(full[i]>full[j] for i in range(4) for j in range(i+1,4))
    Bstar[5+wedges.index(tuple(co)),5+a]=sign
chi=np.eye(4,dtype=np.int64)
for G in Gam:chi=mm(chi,G)
ClaimedOmega=(-34*invn(81)*Bstar)%q
ClaimedOmega[11:15,11:15]=27*invn(32)*chi%q
ck('source-Omega4-block-identity',np.array_equal(Omega,ClaimedOmega))

def lie_dimension(gens):
    pivots=[];reduced=[];matrices=[];pos=0
    def add(m):
        v=np.asarray(m,dtype=np.int64).reshape(225)%q
        for pivot,b in zip(pivots,reduced):
            c=int(v[pivot]);
            if c:v=(v-c*b)%q
        nz=np.flatnonzero(v)
        if len(nz)==0:return False
        ix=int(nz[0]);v=v*invn(v[ix])%q
        pivots.append(ix);reduced.append(v);matrices.append(v.reshape(15,15));return True
    for G in gens:add(G)
    while pos<len(matrices):
        A=matrices[pos];pos+=1
        for G in gens:add(omega*(mm(G,A)-mm(A,G)))
    return len(matrices)
lie_dimensions=[lie_dimension(z) for z in [Y,Y+[Q0],Y+[Omega],Y+[Q0,Omega],Y+[Q0,Omega,I]]]
ck('all-five-coordinate-control-lie-ranks',lie_dimensions,[65,131,135,136,137])

# Source metadata discrepancy is a typing/provenance flag, not a mathematical failure.
legacy_header=bool(re.search(r'\\date\{Version 1\.7\b',current.decode('utf8')))
ck('legacy-version-string-observed',legacy_header,True)
record={'meta':{'source':'Paper1B-ExceptionalGeometry-v1_8.tex','source_sha256':sha,
        'protocol':'Paper00-RigorousVerificationDAGWorkProtocol-v2_4(1).md',
        'name':'Final closure reconciliation E3/E4',
        'no_archive_or_paper_changes':True},
        'claim_scope':['BH-IBX-EV-0007','BH-IBX-EV-0008','five-cycle-sign-refutation','v1.8-source-drift'],
        'source_formal_count':sum(current_types.values()),
        'source_formal_kind_counts':current_types,
        'added_formal_kind_counts':{k:current_types[k]-old_types[k] for k in current_types},
        'lie_ranks_F97':lie_dimensions,
        'hurwitz_moments':{'H6_2':'1/7','H6_4':'61/1001','Y6_4':'427/143'},
        'fivecycle_relation':'K=-15D5; source prints K=+15D5',
        'fivecycle_product_relation':'(15/(4sqrt5))^2=45/16',
        'source_provenance':{'paper1a_delegates_hurwitz_link_to':'Paper I-B','v1.8_date_header':'Version 1.7'},
        'checks_total':len(checks),'checks_passed':sum(a['passed'] for a in checks),
        'checks_failed':sum(not a['passed'] for a in checks), 'checks':checks}
OUT.write_text(json.dumps(record,indent=2,ensure_ascii=False,default=str)+'\n')
print('PASS',record['checks_passed'],'/',record['checks_total'])
print('EV-0007 exact moments:',record['hurwitz_moments'])
print('EV-0008 Lie ranks:',lie_dimensions)
print('five-cycle source sign REFUTED, corrected -15D5; double-odd unchanged')
print('source kinds:',record['source_formal_kind_counts'])
print('Wrote',OUT)
