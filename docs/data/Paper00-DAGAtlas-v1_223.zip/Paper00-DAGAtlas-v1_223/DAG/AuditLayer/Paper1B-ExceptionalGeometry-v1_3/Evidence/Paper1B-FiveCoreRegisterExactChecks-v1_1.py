#!/usr/bin/env python3
"""Paper I-B v1.8 closure Batch 3. Exact 25-register compression in Petersen 5x3 chart.
Derives all operators from 120 exact 2I quaternions, 600 tetrahedra, 25
Hurwitz orbits, 15 Petersen edges and the source's 4+5+6 edge isometry.
No paper or archive edits; no physical selection is asserted.
"""
from itertools import permutations,product,combinations
from collections import Counter,defaultdict
from pathlib import Path
from math import lcm
import json, hashlib
import numpy as np
import sympy as s

F=s.Rational
Z=(0,0); ONE=(2,0); PHI=(0,2); IPHI=(-2,2)
# All q coordinates are (a+b*phi)/2 where phi^2=phi+1.
def add(a,b): return a[0]+b[0],a[1]+b[1]
def neg(a): return -a[0],-a[1]
def mul(a,b): return a[0]*b[0]+a[1]*b[1],a[0]*b[1]+a[1]*b[0]+a[1]*b[1]
def times(a,b):
    x,y=mul(a,b)
    assert x%2==y%2==0,(a,b,x,y)
    return x//2,y//2
def prodq(q,r):
    a,b,c,d=q;e,f,g,h=r
    o=(add(add(add(mul(a,e),neg(mul(b,f))),neg(mul(c,g))),neg(mul(d,h))),
       add(add(add(mul(a,f),mul(b,e)),mul(c,h)),neg(mul(d,g))),
       add(add(add(mul(a,g),neg(mul(b,h))),mul(c,e)),mul(d,f)),
       add(add(add(mul(a,h),mul(b,g)),neg(mul(c,f))),mul(d,e)))
    assert all(x%2==y%2==0 for x,y in o)
    return tuple((x//2,y//2) for x,y in o)
def conj(q):return (q[0],neg(q[1]),neg(q[2]),neg(q[3]))
def dot4(q,r):
    a=(0,0)
    for x,y in zip(q,r):a=add(a,mul(x,y))
    return a

def parity(p):return (-1)**sum(p[i]>p[j] for i in range(len(p)) for j in range(i+1,len(p)))
V=set()
for i in range(4):
 for sign in [-1,1]:
  x=[Z]*4;x[i]=(2*sign,0);V.add(tuple(x))
for signs in product((-1,1),repeat=4):V.add(tuple((a,0) for a in signs))
for p in permutations(range(4)):
 if parity(p)<0:continue
 for signs in product((-1,1),repeat=3):
  x=[Z]*4;vals=[Z,(1,0),(0,1),(-1,1)]
  for k,j in enumerate(p):
   if k:x[j]=tuple(signs[k-1]*t for t in vals[k])
  V.add(tuple(x))
V=sorted(V);ix={v:i for i,v in enumerate(V)}
H=sorted(v for v in V if all(x[1]==0 for x in v))
assert len(V)==120 and len(H)==24
allids=set(range(120))
for a in V:
 for b in H: assert prodq(a,b) in ix
N=[{j for j,b in enumerate(V) if i!=j and dot4(a,b)==(0,2)} for i,a in enumerate(V)]
assert set(map(len,N))=={12}
facets=set()
for a in range(120):
 for b in (j for j in N[a] if j>a):
  for c in (j for j in N[a]&N[b] if j>b):
   for d in (j for j in N[a]&N[b]&N[c] if j>c):facets.add((a,b,c,d))
assert len(facets)==600

# Construct one H_L x H_R orbit (24 tetrahedra), then verify it is aligned.
LH={h:tuple(ix[prodq(h,v)] for v in V) for h in H}
RH={h:tuple(ix[prodq(v,conj(h))] for v in V) for h in H}
f0=None;ref=None
remaining=set(facets)
while remaining:
 candidate=min(remaining)
 orb={tuple(sorted(LH[h1][RH[h2][k]] for k in candidate)) for h1 in H for h2 in H}
 remaining-=orb
 if len(orb)==24: f0=candidate;ref=orb
assert f0 is not None and ref<=facets
# Matched coset representatives g_i H
unused=set(V); reps=[]; cosets=[]
while unused:
 g=min(unused);C={prodq(g,h) for h in H}
 reps.append(g);cosets.append(C);unused-=C
assert len(reps)==5 and not unused
cos_id={g:i for i,C in enumerate(cosets) for g in C}
# Left coset action, and its 5x5 permutation bank (2I -> A5)
perms={g:tuple(cos_id[prodq(g,r)] for r in reps) for g in V}
assert len(set(perms.values()))==60
# Independent 25 cells by double translated HxH orbit
blocks={};owner={}
for i,a in enumerate(reps):
 for j,b in enumerate(reps):
  cells={tuple(sorted(ix[prodq(prodq(a,V[k]),conj(b))] for k in f)) for f in ref}
  assert len(cells)==24
  blocks[(i,j)]=cells
  for f in cells:
   assert f not in owner,(i,j,f,owner.get(f));owner[f]=(i,j)
assert len(owner)==600 and set(owner)==facets
# All chamber 4-root sums in the 5 coset representation (exact integer 5x5 matrix)
flist=sorted(facets)
B=np.zeros((120,25),dtype='int64')
rho=np.zeros((120,25),dtype='int64')
for g in V:
 p=perms[g];k=ix[g]
 for j,i in enumerate(p):
  rho[k,5*i+j]=1;B[k,5*i+j]=1
assert set(map(int,B.sum(axis=0)))=={24}
chamber_rho=np.zeros((600,25),dtype='int64')
block_indices=defaultdict(list)
for fi,f in enumerate(flist):
 chamber_rho[fi]=rho[list(f)].sum(axis=0)
 block_indices[owner[f]].append(fi)
for i in range(5):
 for j in range(5):
  vertices=Counter(k for fi in block_indices[(i,j)] for k in flist[fi])
  assert all(vertices[k]==1-B[k,i*5+j] for k in range(120))
assert len(block_indices)==25

# Native Petersen edge basis grouped as 5 x 3, missing core m.
pairs=list(combinations(range(5),2)); petedges=[];missing=[]
for a,A in enumerate(pairs):
 for b,Bp in enumerate(pairs):
  if a<b and set(A).isdisjoint(Bp):
   petedges.append((a,b));missing.append(next(iter(set(range(5))-set(A)-set(Bp))))
assert len(petedges)==15 and Counter(missing)=={i:3 for i in range(5)}
Apet=s.Matrix(10,10,lambda i,j:int(i!=j and set(pairs[i]).isdisjoint(pairs[j])))
inc=s.zeros(10,15);S=s.zeros(25,15);KK=s.zeros(25,15)
eye5=s.eye(5);J5=s.ones(5)
for e,(aa,bb) in enumerate(petedges):
 inc[aa,e]=1;inc[bb,e]=-1
 def vv(t):return s.Matrix([int(k in pairs[t])-F(2,5) for k in range(5)])
 def dd(t):
  a,b=pairs[t];return s.Matrix([int(k==a)-int(k==b) for k in range(5)])
 va,vb=vv(aa),vv(bb); da,db=dd(aa),dd(bb)
 sym=da*da.T-db*db.T
 skew=va*vb.T-vb*va.T
 S[:,e]=s.Matrix(sym).reshape(25,1)
 KK[:,e]=s.Matrix(skew).reshape(25,1)
# Spectral projectors onto Petersen vertex 4 and 5 dimensions
I10=s.eye(10)
PV4=(Apet-3*I10)*(Apet-I10)/15
PV5=-(Apet-3*I10)*(Apet+2*I10)/6
PE4=inc.T*PV4*inc/5
PE5=inc.T*PV5*inc/2
PE6=s.eye(15)-PE4-PE5
assert PE4.rank()==4 and PE5.rank()==5 and PE6.rank()==6
assert S.T*S==25*PE4+4*PE5 and KK.T*KK==4*PE6 and S.T*KK==s.zeros(15)
UU=(S+KK)*(PE4/5+(PE5+PE6)/2)
assert UU.T*UU==s.eye(15)
den=lcm(*(int(x.q) for x in UU))
Uinteger=np.array((den*UU).tolist(),dtype='int64')
# Lift the 15 graph edge coefficients to chamber functions.
# E_e(g) = <U_e,rho_g>/sqrt(30); Psi_e(f)=sum_g in f E_e(g)/sqrt(5).
W=chamber_rho@Uinteger
Ngram=W.T@W
assert (Ngram==(150*den*den)*np.eye(15,dtype=np.int64)).all(), ('normalization',np.diag(Ngram)[:5],150*den*den)
Knum={p:W[inds].T@W[inds] for p,inds in block_indices.items()}
assert (sum(Knum.values(),np.zeros((15,15),dtype='int64'))==Ngram).all()
# Off-core rank, and exact equality to double centered 5x5 register weights.
rows_off=[(a,b) for a in range(15) for b in range(a+1,15) if missing[a]!=missing[b]]
O=s.Matrix(len(rows_off),25,lambda r,c: int(Knum[(c//5,c%5)][rows_off[r][0],rows_off[r][1]]))
rank_off=O.rank()
# Additive kernel M_ij=a_i+b_j has dimension 9.
addbasis=[]
for i in range(5):addbasis.append(s.Matrix([int(k//5==i) for k in range(25)]))
for j in range(4):addbasis.append(s.Matrix([int(k%5==j) for k in range(25)]))
addmat=s.Matrix.hstack(*addbasis)
assert addmat.rank()==9
add_zero=O*addmat==s.zeros(O.rows,9)

# Independent class-operator mirror contrast on all 60 even five-letter permutations.
a5=sorted(set(perms.values()))
cycs=[p for p in a5 if sorted([sum(p[j]!=j for j in range(5))])==[5]]
assert len(cycs)==24
inv=lambda p:tuple(p.index(i) for i in range(5))
def compose(p,q):return tuple(p[q[i]] for i in range(5))
g0=cycs[0]
ca={compose(compose(p,g0),inv(p)) for p in a5}
cb=set(cycs)-ca
assert len(ca)==len(cb)==12
Eidx={e:i for i,e in enumerate(petedges)}
Pidx={p:i for i,p in enumerate(pairs)}
def rhoedge(g):
 out=np.zeros((15,15),dtype='int64')
 for src,(a,b) in enumerate(petedges):
  ap=Pidx[tuple(sorted(g[k] for k in pairs[a]))];bp=Pidx[tuple(sorted(g[k] for k in pairs[b]))]
  if ap<bp:out[Eidx[(ap,bp)],src]=1
  else:out[Eidx[(bp,ap)],src]=-1
 return out
Dnum=sum((rhoedge(p) for p in ca),np.zeros((15,15),dtype='int64'))-sum((rhoedge(p) for p in cb),np.zeros((15,15),dtype='int64'))
assert np.array_equal(Dnum@Dnum@Dnum,80*Dnum)
assert s.Matrix(Dnum.tolist()).rank()==6
comm={p:K@Dnum-Dnum@K for p,K in Knum.items()}
C=s.Matrix(225,25,lambda r,c:int(comm[(c//5,c%5)][r//15,r%15]))
rank_com=C.rank()
# Exact scalar centered Q; Q=I-J/5.
q=s.eye(5)-s.ones(5)/5
qvec=s.Matrix(q).reshape(25,1)
KQ=s.zeros(15)
for i in range(5):
 for j in range(5):KQ += q[i,j]*s.Matrix(Knum[(i,j)].tolist())
KQ=KQ/F(150*den*den)
PQ4=PE4
KQexpected=-s.eye(15)/15+PQ4/5

# Stronger all-register decomposition: additive row/column weights have only
# one visible scalar (their total mean); eight additive contrasts vanish.
unit=150*den*den
I15=np.eye(15,dtype='int64')
row_sums=[sum((Knum[(i,j)] for j in range(5)),np.zeros((15,15),dtype='int64')) for i in range(5)]
col_sums=[sum((Knum[(i,j)] for i in range(5)),np.zeros((15,15),dtype='int64')) for j in range(5)]
assert all(np.array_equal(v,unit//5*I15) for v in row_sums+col_sums)
# Off-core direct witness: sixteen distinct centered basis matrices Q E_ij Q
# (i,j<4), and sixteen independent off-core entries provide a nonzero minor.
cols16=[5*i+j for i in range(4) for j in range(4)]
Off16=O[:,cols16]
assert Off16.rank()==16
rows16=list(Off16.T.rref()[1]);W16=Off16[rows16,:]
assert len(rows16)==16 and W16.det()!=0
# A similar 15x15 minor witnesses the full commutator rank.
Com16=C[:,cols16]
pivots15=list(Com16.rref()[1]);assert len(pivots15)==15
Com15=Com16[:,pivots15]
rows15=list(Com15.T.rref()[1]);W15=Com15[rows15,:]
assert len(rows15)==15 and W15.det()!=0

def det_mod(mat,p):
 a=[[int(mat[i,j])%p for j in range(mat.cols)] for i in range(mat.rows)]
 n=len(a);out=1
 for k in range(n):
  pivot=next((i for i in range(k,n) if a[i][k]),None)
  if pivot is None:return 0
  if pivot!=k:a[k],a[pivot]=a[pivot],a[k];out=-out
  x=a[k][k];out=out*x%p;inv=pow(x,-1,p)
  for i in range(k+1,n):
   ratio=a[i][k]*inv%p
   if ratio:
    for j in range(k,n):a[i][j]=(a[i][j]-ratio*a[k][j])%p
 return out%p
# A concrete off-core matrix-entry functional for a pair with nonzero Q coupling
candidates=[(a,b) for a,b in rows_off if KQ[a,b]!=0]
assert candidates
example_pair=candidates[0]
example_coeff=s.Matrix(5,5,lambda i,j:F(int(Knum[(i,j)][example_pair[0],example_pair[1]]),unit))
source_path=Path('/mnt/data/paper1b_closure_batched/Paper1B-ExceptionalGeometry-v1_8.tex')
source_sha256=hashlib.sha256(source_path.read_bytes()).hexdigest()
# All 25 matrices compressed, and their full block/mirror visible ranks
result={
 'f0_vertex_indices':f0,'reference_block_facets':len(ref), 'chambers':len(flist),
 'block_count':len(blocks),'per_block':{str(k):len(v) for k,v in blocks.items()},
 'petersen_edges':len(petedges),'missing_core_counts':dict(Counter(missing)),
 'petersen_isometry_denominator':den,
 'rank_off_core':rank_off,'off_core_additive_is_kernel':add_zero,
 'rank_commutator':rank_com,'commutator_additive_is_kernel':C*addmat==s.zeros(C.rows,9),
 'K_Q_claimed_identity': KQ==KQexpected,
 'K_Q_difference_rank': (KQ-KQexpected).rank(),
 'K_Q_eigenvalues':{str(k):int(v) for k,v in KQ.eigenvals().items()},
 'K_Q_interblock_zero': all(KQ[i,j]==0 for i,j in rows_off),
 'K_Q_commutator_zero':KQ*s.Matrix(Dnum.tolist())==s.Matrix(Dnum.tolist())*KQ,
 'rank_K_coordinate_map': s.Matrix(225,25,lambda r,c:int(Knum[(c//5,c%5)][r//15,r%15])).rank(),
 'rank_Q_map':16,
 'all_row_and_column_register_sums_equal_I_over_5':True,
 'exact_minor_off_core_rows':rows16,'exact_minor_off_core_cols':cols16,
 'exact_minor_off_core_det_mod_101':det_mod(W16,101),
 'exact_minor_commutator_rows':rows15,'exact_minor_commutator_cols':[cols16[i] for i in pivots15],
 'exact_minor_commutator_det_mod_101':det_mod(W15,101),
 'representative_off_core_edge_pair':list(example_pair),
 'representative_off_core_matrix_coefficient':str(example_coeff),
 'representative_Q_coupling':str(KQ[example_pair[0],example_pair[1]]),
 'source_sha256':source_sha256,
 'source':'Paper1B-ExceptionalGeometry-v1_8.tex','claim':'p1:prop:v366-register-mirror-contrast',
 'scope':'abstract trial chamber register compression to rank-15 Petersen coefficient space; no physical decay channel'}
# Standard linear algebra test of centered scalar line, plus additive kernel.
qcol=s.Matrix([q[i,j] for i in range(5) for j in range(5)])
kerCandidate=addmat.row_join(qcol)
result['rank_additive_plus_centered_scalar']=kerCandidate.rank()
result['commutator_annihilates_scalar_center']= C*qcol==s.zeros(C.rows,1)
result['off_core_annihilates_scalar_center']=O*qcol==s.zeros(O.rows,1)
result['off_core_kernel_exactly_additive']=rank_off==16 and add_zero
result['commutator_kernel_exactly_additive_plus_scalar']=rank_com==15 and C*kerCandidate==s.zeros(C.rows,10)
result['K_Q_deviation_summary']={"first_rows":str((KQ-KQexpected)[:3,:3])}
# This is a verdicted certificate, not a collection of unchecked observations.
for name in ('off_core_additive_is_kernel','commutator_additive_is_kernel','K_Q_claimed_identity',
             'K_Q_commutator_zero','off_core_kernel_exactly_additive',
             'commutator_kernel_exactly_additive_plus_scalar'):
    assert result[name],name
assert result['rank_off_core']==16 and result['rank_commutator']==15
assert result['rank_K_coordinate_map']==17
assert result['K_Q_difference_rank']==0
# Save both status and enough reproducible integer spectral witnesses.
path=Path('/mnt/data/Paper1B-FiveCoreRegisterExactControls-v1_1.json')
path.write_text(json.dumps(result,indent=2,default=str)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('per_block','K_Q_deviation_summary')}, indent=2,default=str),flush=True)
