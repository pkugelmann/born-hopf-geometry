#!/usr/bin/env python3
"""Independent source-matched exact F40 geometric certificate for Paper I-B v1.8.
Rebuilds 2I from Q(sqrt5) and derives F40, readouts, inverse, mirror map,
24 Plucker controls. Does not import a historical F40 verification script.
No physical source Hamiltonian, mass, or framework updates asserted.
"""
from __future__ import annotations
import itertools as it, collections as co, hashlib, json, time
from fractions import Fraction as F
from pathlib import Path
import sympy as S

SRC=Path('/mnt/data/paper1b_closure_batched/Paper1B-ExceptionalGeometry-v1_8.tex')
checks=[]; start=time.monotonic()
def check(name, proposition, condition, detail=''):
    ok=bool(condition)
    checks.append({'id':f'F40-B5-{len(checks)+1:04d}', 'claim':proposition,'name':name, 'passed':ok,'detail':detail})
    if not ok: raise AssertionError(f'{name}: {detail}')
def say(message):print('CHECKPOINT',round(time.monotonic()-start,2),message,flush=True)
# Exact x=a+b*sqrt(5); paired rationals.
def add(x,y):return x[0]+y[0],x[1]+y[1]
def neg(x):return -x[0],-x[1]
def mul(x,y):return x[0]*y[0]+5*x[1]*y[1], x[0]*y[1]+x[1]*y[0]
def sums(*z):
    a=(F(0),F(0))
    for b in z:a=add(a,b)
    return a
zero=(F(0),F(0));one=(F(1),F(0));half=(F(1,2),F(0));phih=(F(1,4),F(1,4));invphih=(F(-1,4),F(1,4))
def signed(q,s):return q if s==1 else neg(q)
def qmul(a,b):
    w,x,y,z=a;v,p,t,r=b
    return (sums(mul(w,v),neg(mul(x,p)),neg(mul(y,t)),neg(mul(z,r))),
            sums(mul(w,p),mul(x,v),mul(y,r),neg(mul(z,t))),
            sums(mul(w,t),neg(mul(x,r)),mul(y,v),mul(z,p)),
            sums(mul(w,r),mul(x,t),neg(mul(y,p)),mul(z,v)))
def qconj(a):return a[0],neg(a[1]),neg(a[2]),neg(a[3])
def qdot(a,b):return sums(*(mul(x,y) for x,y in zip(a,b)))

G=[]
for i in range(4):
    for sgn in (1,-1):
        p=[zero]*4;p[i]=signed(one,sgn);G.append(tuple(p))
G += [tuple(signed(half,v) for v in ss) for ss in it.product((1,-1),repeat=4)]
for perm in it.permutations(range(4)):
    if sum(perm[i]>perm[j] for i in range(4) for j in range(i+1,4))%2:continue
    for signs in it.product((1,-1),repeat=3):
        p=[zero]+[signed(v,sgn) for v,sgn in zip((half,phih,invphih),signs)]
        G.append(tuple(p[i] for i in perm))
G=sorted(G);group=set(G)
check('120 distinct exact binary icosahedral vertices','p1:thm:v345-f40-edge-regular',len(group)==120)
check('unit quaternion norms','p1:thm:v345-f40-edge-regular',all(qdot(g,g)==one for g in G))
# Canonical 2T: coordinates +/-1 and all sixteen four-half-tuples.
H={g for g in G if (sum(x!=zero for x in g)==1 or all(abs(x[0])==F(1,2) and x[1]==0 for x in g))}
check('2T subgroup has 24 elements','p1:thm:v345-f40-edge-regular',len(H)==24)
check('2T closed in 2I','p1:thm:v345-f40-edge-regular',all(qmul(a,b) in H for a in H for b in H))
cores=[]
for g in G:
    h=frozenset(qmul(qmul(g,x),qconj(g)) for x in H)
    if h not in cores:cores.append(h)
check('five conjugate binary tetrahedral cores','p1:thm:v345-f40-edge-regular',len(cores)==5 and all(len(h)==24 for h in cores))
plus=[g for g in G if g[0]==half];minus=[g for g in G if g[0]==neg(half)]
check('forty F40 vertices','p1:thm:v345-f40-edge-regular',len(plus)==len(minus)==20)
verts=plus+minus;vid={q:i for i,q in enumerate(verts)}
shellscalar=(F(-1,4),F(1,4))
edges=[]
for u in plus:
    for v in minus:
        right=qmul(qconj(u),v)
        if right[0]==shellscalar:edges.append((u,v,right,qmul(v,qconj(u))))
check('sixty oriented F40 edges','p1:thm:v345-f40-edge-regular',len(edges)==60)
shell=sorted({e[2] for e in edges});shellindex={g:i for i,g in enumerate(shell)}
check('right and left 12 shell elements','p1:thm:v345-f40-edge-regular',len(shell)==12 and {e[3] for e in edges}==set(shell))
perms={}
for g in shell:
    perm=[]
    for h in cores:
        conjugated=frozenset(qmul(qmul(g,x),qconj(g)) for x in h)
        perm.append(cores.index(conjugated))
    perms[g]=perm
check('shell acts by twelve 5-cycles','p1:thm:v345-f40-edge-regular',all(len(set(perms[g]))==5 and len({tuple(perms[g]) for g in shell})==12 for g in shell))
arcs=[(a,b) for a in range(5) for b in range(5) if a!=b]; arcindex={e:i for i,e in enumerate(arcs)}
B=S.zeros(40,60);TR=S.zeros(12,60);TL=S.zeros(12,60);A=S.zeros(20,60)
labels=[]
for e,(u,v,r,l) in enumerate(edges):
    B[vid[u],e]=-1; B[vid[v],e]=1
    TR[shellindex[r],e]=1; TL[shellindex[l],e]=1
    in_u={i for i,h in enumerate(cores) if u in h};in_v={i for i,h in enumerate(cores) if v in h}
    omitted=set(range(5))-in_u-in_v
    assert len(in_u)==len(in_v)==2 and len(omitted)==1
    m=next(iter(omitted));n=perms[r][m];A[arcindex[(m,n)],e]=1
    labels.append((r,m,n))
check('edge-shell-core bijection','p1:thm:v345-f40-edge-regular',len({(g,m) for g,m,n in labels})==60)
check('directed 20 core arrows three-to-one','p1:thm:v345-f40-edge-regular',set(co.Counter((m,n) for g,m,n in labels).values())=={3})
check('undirected F40 cubic degrees','p1:thm:v345-f40-edge-regular',all(sum(1 for u,v,r,l in edges if q==u or q==v)==3 for q in verts))
# Adversarial and equivariance gate: action of all sixty projective 2I elements.
edge_index={(u,v):i for i,(u,v,rr,ll) in enumerate(edges)}
projective={}
for h in G:
    perm=tuple(cores.index(frozenset(qmul(qmul(h,x),qconj(h)) for x in c)) for c in cores)
    projective.setdefault(perm,h)
check('exact A5 quotient gives sixty core permutations','p1:thm:v345-f40-edge-regular',len(projective)==60)
identity=tuple(range(5))
for perm,h in projective.items():
    h_inv=qconj(h);fixed=0
    for k,(u,v,rr,ll) in enumerate(edges):
        uu=qmul(qmul(h,u),h_inv);vv=qmul(qmul(h,v),h_inv)
        assert (uu,vv) in edge_index
        k2=edge_index[uu,vv]
        fixed += (k==k2)
        rr2,ll2=edges[k2][2:]
        assert rr2==qmul(qmul(h,rr),h_inv)
        assert ll2==qmul(qmul(h,ll),h_inv)
        g,m,n=labels[k];g2,m2,n2=labels[k2]
        assert (g2,m2,n2)==(rr2,perm[m],perm[n])
    assert fixed==(60 if perm==identity else 0)
check('regular 60-edge A5 action and equivariant native labels','p1:thm:v345-f40-edge-regular',True)

say('geometry constructed')
# Define independent icosahedral shell adjacency from actual imaginary quaternion dot products,
# NOT reverse-engineered from the desired operator identity.
Aico=S.zeros(12);Ant=S.zeros(12);positive=(F(1,8),F(1,8))
for i,g in enumerate(shell):
    Ant[i,shellindex[qconj(g)]]=1
    for j,h in enumerate(shell):
        if i!=j and sums(*(mul(a,b) for a,b in zip(g[1:],h[1:])))==positive:
            Aico[i,j]=1
check('icosahedral shell adjacency degree five','p1:prop:v345-f40-balanced-mirror',Aico==Aico.T and Aico*S.ones(12,1)==5*S.ones(12,1))
check('six antipodal pairs and involution','p1:thm:v349-f40-mirror-gluing',Ant==Ant.T and Ant**2==S.eye(12) and S.trace(Ant)==0)
check('icosahedral antipodal odd projector rank six','p1:thm:v349-f40-mirror-gluing',((S.eye(12)-Ant)/2).rank()==6)
# Fundamental cycle basis via nullspace of integer incidence. No historical certificate imports.
N=S.Matrix.hstack(*B.nullspace()); assert N.shape==(60,21)
Gmetric=N.T*N;PZ=N*Gmetric.inv()*N.T
check('incidence rank 39, cycle rank 21','p1:thm:v345-f40-triple-frame',B.rank()==39 and N.rank()==21 and B*N==S.zeros(40,21))
check('Euclidean cycle projection idempotent selfadjoint','p1:thm:v345-f40-triple-frame',PZ**2==PZ and PZ==PZ.T)
T=TR-TL;sumread=TR+TL; raw=S.Matrix.vstack(TR,TL,A);R=raw*N
for nm,op in [('right',TR),('left',TL),('arrow',A)]:
    check(f'{nm} rank eleven','p1:thm:v345-f40-triple-frame',(op*N).rank()==11)
for nm,op in [('right+left',S.Matrix.vstack(TR,TL)),('right+arrow',S.Matrix.vstack(TR,A)),('left+arrow',S.Matrix.vstack(TL,A))]:
    check(f'{nm} pair rank sixteen','p1:thm:v345-f40-triple-frame',(op*N).rank()==16)
check('triple rank 21','p1:thm:v345-f40-triple-frame',R.rank()==21)
check('shell means vanish','p1c:thm:v349-f40-23-equations',S.ones(1,12)*TR*N==S.zeros(1,21) and S.ones(1,12)*TL*N==S.zeros(1,21))
check('right/left shell five preimages','p1:thm:v345-f40-triple-frame',TR*TR.T==5*S.eye(12) and TL*TL.T==5*S.eye(12))
check('arrow twenty shell three preimages','p1:prop:v345-f40-balanced-mirror',A*A.T==3*S.eye(20))
say('cycle projections and readout ranks')
# Balanced skew/symmetric arrow projection derived from 9 independent row/column conditions.
Hbal=S.zeros(10,20);flip=S.zeros(20)
for j,(a,b) in enumerate(arcs):
    Hbal[a,j]=1;Hbal[5+b,j]=1;flip[arcindex[b,a],j]=1
Cb=S.Matrix.hstack(*Hbal.nullspace());Pbal=Cb*(Cb.T*Cb).inv()*Cb.T
Psym=(Pbal+flip*Pbal)/2; Pskew=(Pbal-flip*Pbal)/2
check('nine independent arrow balance constraints','p1:prop:v345-f40-balanced-mirror',Hbal.rank()==9 and Hbal*A*N==S.zeros(10,21))
check('balanced arrow 5+6 Hodge decomposition','p1:prop:v345-f40-balanced-mirror',Psym.rank()==5 and Pskew.rank()==6 and Pbal==Psym+Pskew)
check('arrow response gains 2 and 1','p1:prop:v345-f40-balanced-mirror',A*PZ*A.T==2*Psym+Pskew)
check('source mixed right-left shell Gram','p1:prop:v345-f40-balanced-mirror',TR*PZ*TL.T==-S.Rational(9,4)*S.eye(12)+Aico/2+Ant/4-S.ones(12)/24)
check('source even shell Gram','p1:prop:v345-f40-balanced-mirror',sumread*PZ*sumread.T==S.eye(12)+Ant-S.ones(12)/6)
check('source odd shell Gram','p1:prop:v345-f40-balanced-mirror',T*PZ*T.T==10*S.eye(12)-2*Aico)
check('even and odd shell gains/ranks','p1:prop:v345-f40-balanced-mirror',(sumread*N).rank()==5 and (T*N).rank()==11)
check('odd antipodal adjacency square identity','p1:thm:v349-f40-mirror-gluing',Aico**2*(S.eye(12)-Ant)/2==5*(S.eye(12)-Ant)/2)
say('balanced arrows, shell Grams')
# Independent cyclic-distance mirror kernel, 240 entries.
K=S.zeros(20,12);hist=co.Counter()
for a,(i,j) in enumerate(arcs):
    for c,g in enumerate(shell):
        q=i;d=0
        while q!=j:
            q=perms[g][q];d+=1
            assert d<=4
        K[a,c]=S.Rational(5-2*d,40);hist[d]+=1
check('all cyclic-distance classes equal sixty','p1:thm:v349-f40-mirror-gluing',hist=={1:60,2:60,3:60,4:60})
Odd=(S.eye(12)-Ant)/2
check('mirror K image and domain constraints','p1:thm:v349-f40-mirror-gluing',Pskew*K==K and K*Odd==K)
check('mirror gluing exact on 21 cycles','p1:thm:v349-f40-mirror-gluing',(Pskew*A-K*T)*N==S.zeros(20,21))
check('mirror K Gram','p1:thm:v349-f40-mirror-gluing',K.T*K==(5*S.eye(12)+Aico)*Odd/40)
Ki=2*(5*S.eye(12)-Aico)*K.T
check('mirror K two-sided inverse','p1:thm:v349-f40-mirror-gluing',Ki*K==Odd and K*Ki==Pskew)
check('mirror K rank six','p1:thm:v349-f40-mirror-gluing',K.rank()==6)
check('mirror condition number is golden ratio','p1:thm:v349-f40-mirror-gluing',S.simplify((5+S.sqrt(5))/(5-S.sqrt(5))-((1+S.sqrt(5))/2)**2)==0)
# Check K is an A5 intertwiner on all 60 group elements, not only on generators.
for perm,h in projective.items():
    h_inv=qconj(h)
    for k,g in enumerate(shell):
        k2=shellindex[qmul(qmul(h,g),h_inv)]
        for a,(i,j) in enumerate(arcs):
            assert K[arcindex[perm[i],perm[j]],k2]==K[a,k]
check('K intertwines all 60 A5 conjugation/permutation actions','p1:thm:v349-f40-mirror-gluing',True)
# E4: mutate one rational sign and one global normalization. Both must be detected.
Kbad=K.copy();Kbad[0,0]=-Kbad[0,0]
check('E4 one-entry mirror sign mutation breaks exact Gram','p1:thm:v349-f40-mirror-gluing',Kbad.T*Kbad!=(5*S.eye(12)+Aico)*Odd/40)
check('E4 wrong 1/20 vs 1/40 normalization breaks inverse','p1:thm:v349-f40-mirror-gluing',(2*K).T*(2*K)!=(5*S.eye(12)+Aico)*Odd/40)

say('mirror kernel and two-sided inverse')
# Native reduced 5+5+5+6 frame.
Pshell=(S.eye(12)+Ant)/2-S.ones(12)/12
pairs=list(it.combinations(range(5),2));Ap=S.zeros(10)
for i,p in enumerate(pairs):
    for j,q in enumerate(pairs):
        if not set(p)&set(q):Ap[i,j]=1
Pp5=-((Ap-3*S.eye(10))*(Ap+2*S.eye(10)))/6
Jpair=S.zeros(10,20)
for i,(a,b) in enumerate(pairs):
    Jpair[i,arcindex[(a,b)]]=S.Rational(1,2)
    Jpair[i,arcindex[(b,a)]]=S.Rational(1,2)
reduced=[Pshell*sumread,Pshell*T,Jpair*A,Pskew*A]
ranks=[(X*N).rank() for X in reduced]
check('reduced F40 sector ranks 5+5+5+6','p1:prop:v349-f40-reduced-frame',ranks==[5,5,5,6])
check('reduced F40 rank21','p1:prop:v349-f40-reduced-frame',(S.Matrix.vstack(*reduced)*N).rank()==21)
check('arrow symmetric lies in Petersen P5','p1:prop:v349-f40-reduced-frame',(S.eye(10)-Pp5)*Jpair*A*N==S.zeros(10,21))
check('symmetric shell lies in rank5 even subspace','p1:prop:v349-f40-reduced-frame',(S.eye(12)-Pshell)*sumread*N==S.zeros(12,21))
say('reduced F40 native frame')
# 23 necessary/sufficient exact packet constraints. C full rank, vanishes on all realizations.
C=S.zeros(23,44)
for a in range(12):C[0,a]=1;C[1,12+a]=1
for i in range(5):
    for a,(u,v) in enumerate(arcs):
        if u==i:C[2+i,24+a]=1
for j in range(4):
    for a,(u,v) in enumerate(arcs):
        if v==j:C[7+j,24+a]=1
visited=set();pairs_ant=[]
for k,g in enumerate(shell):
    h=shellindex[qconj(g)]
    if k in visited:continue
    assert k!=h
    visited|={k,h};pairs_ant.append((k,h))
assert len(pairs_ant)==6
for t,(k,h) in enumerate(pairs_ant):
    C[11+t,k]=1;C[11+t,h]=-1;C[11+t,12+k]=1;C[11+t,12+h]=-1
chords=list(it.combinations(range(1,5),2))
for c,(i,j) in enumerate(chords):
    a=arcindex[i,j];b=arcindex[j,i]
    C[17+c,24+a]=S.Rational(1,2); C[17+c,24+b]=-S.Rational(1,2)
    for k in range(12):C[17+c,k]-=K[a,k];C[17+c,12+k]+=K[a,k]
check('23 geometric constraints independently ranked','p1c:thm:v349-f40-23-equations',C.rank()==23)
check('all constraints annihilate native 21 frame','p1c:thm:v349-f40-23-equations',C*R==S.zeros(23,21))
check('necessity+sufficiency via 44=23+21','p1c:thm:v349-f40-23-equations',R.rank()==44-C.rank()==21)
check('adversarial single shell sample rejected','p1c:thm:v349-f40-23-equations',C*S.eye(44)[:,0]!=S.zeros(23,1))
check('adversarial arrow-row violation rejected','p1c:thm:v349-f40-23-equations',C*S.eye(44)[:,24]!=S.zeros(23,1))
# E4 hard packet: each isolated readout obeys its conservation law, and the
# right+left inversion parity is fine, but Hodge gluing is violated.
first=0; inverse_first=shellindex[qconj(shell[first])]
u=S.zeros(12,1);u[first]=1;u[inverse_first]=-1
fake=S.Matrix.vstack(u,-u,S.zeros(20,1))
residual=C*fake
check('E4 standalone-conserved but mutually incompatible packet','p1c:thm:v349-f40-23-equations',
      residual[:17,:]==S.zeros(17,1) and residual[17:,:]!=S.zeros(6,1))

say('23 complete compatibility equations')
# Exact rational frame identity and inverse, orthogonal projector.
Fframe=Gmetric.inv()*(R.T*R)
z=S.Symbol('z');poly=Fframe.charpoly(z).as_expr();expected=(z-1)**5*(z*z-12*z+31)**3*(z*z-8*z+6)**5
check('full F40 frame characteristic polynomial','p1:thm:v345-f40-triple-frame',S.expand(poly-expected)==0)
# Obtain polynomial inverse by reducing minimal polynomial; very cheap compared with matrix powers.
check('frame determinant nonzero','p1:thm:v345-f40-triple-frame',S.simplify(Fframe.det())==31**3*6**5)
# Eigenvalue polynomial from source, verify exact inverse on an unnormalized cycle basis.
Fmin=(Fframe**4-21*Fframe**3+153*Fframe**2-453*Fframe+506*S.eye(21))/186
check('frame rational left inverse','p1c:prop:v349-f40-rational-frame-inverse',Fmin*Fframe==S.eye(21))
check('frame rational right inverse','p1c:prop:v349-f40-rational-frame-inverse',Fframe*Fmin==S.eye(21))
check('cycle reconstruction gram normalization','p1c:prop:v349-f40-rational-frame-inverse',Fmin*Gmetric.inv()*R.T*R==S.eye(21))
# Full 44-channel orthogonal projector, not merely a factorization.
P44=R*Fmin*Gmetric.inv()*R.T
check('44-channel compatibility orthogonal projector','p1c:prop:v349-f40-rational-frame-inverse',P44==P44.T and P44*P44==P44)
check('orthogonal projector reproduces all 21 native cycles','p1c:prop:v349-f40-rational-frame-inverse',P44*R==R)
check('orthogonal projector annihilated by all 23 constraints','p1c:thm:v349-f40-23-equations',C*P44==S.zeros(23,44))
check('E4 incompatible one-shell spike not fixed by projector','p1c:thm:v349-f40-23-equations',P44*S.eye(44)[:,0]!=S.eye(44)[:,0])

say('frame inverse')
# Algebraic Plucker side control on balanced skew arrow space: rank6 corresponds to Lambda2 of U=1^perp in R5.
U=[S.eye(5)[:,i]-S.eye(5)[:,4] for i in range(4)]
wedge=[]
for i,j in it.combinations(range(4),2):
    p=U[i]*U[j].T-U[j]*U[i].T
    wedge.append(S.Matrix([p[a,b] for a,b in arcs]))
W=S.Matrix.hstack(*wedge)
check('Plucker wedge basis rank6 of balanced skew arrows','p1:thm:v349-f40-mirror-gluing',W.rank()==6 and Hbal*W==S.zeros(10,6))
check('Plucker wedge basis spans Pskew','p1:thm:v349-f40-mirror-gluing',Pskew*W==W)
# Plucker quadric in 4-dimensional U: p01*p23-p02*p13+p03*p12=0 for decomposable forms.
p,q=S.symbols('p q');w1=S.Matrix([1,p,q,0]);w2=S.Matrix([0,1,p,q])
coeff={t:S.det(S.Matrix([[w1[a],w1[b]],[w2[a],w2[b]]])) for t,(a,b) in enumerate(it.combinations(range(4),2))}
check('Plucker relation for decomposable two-forms','p1:thm:v349-f40-mirror-gluing',S.expand(coeff[0]*coeff[5]-coeff[1]*coeff[4]+coeff[2]*coeff[3])==0)
check('adversarial nondecomposable two-form has nonzero Plucker quadric','p1:thm:v349-f40-mirror-gluing', (1*1-0*0+0*0)!=0)
# No premise that arbitrary F40 skew readout must be decomposable. The above is a side algebraic control.
check('E4 not every F40 skew-output is a decomposable Plucker point','p1:thm:v349-f40-mirror-gluing',
      (Pskew*A*N).rank()==6 and W.rank()==6 and (1*1-0*0+0*0)==1)

say('Plucker side control')
res={'metadata':{'source':str(SRC.name),'source_sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),
 'evidence_level':'E3 independent exact reconstruction, E4 mutated-data attacks',
 'method':'120 Q(sqrt5) quaternions -> 5 conjugate 2T cores -> exact 40/60 F40 -> native matrices -> E3 identities',
 'no_source_or_archive_update':True,'missing_historical_predecessor':'Paper00-PetersenHodgePlucker-v1_10-verify.py not in supplied DAG ZIP',
 'physical_scope':'Finite geometric comparison only; no physical source, action, mass or decay claims'},
 'results':{'quaternions':120,'cores':5,'vertices':40,'edges':60,'cycle_dimension':21,'native_frame_rank':21,
 'single_ranks':[11]*3,'pair_ranks':[16]*3,'mirror_rank':6,'mirror_kernel_distance_counts':dict(hist),
 'channel_constraint_rank':23,'reduced_ranks':ranks,'plucker_wedge_rank':6,
 'native_frame_polynomial':str(S.factor(expected))},
 'checks':checks,'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks)}
path=Path('/mnt/data/Paper1B-F40NativeMirrorExactControls-v1_1.json')
path.write_text(json.dumps(res,indent=2)+'\n')
print('PASS SUMMARY',len(checks), 'EXACT CHECKS; results saved',path, flush=True)
