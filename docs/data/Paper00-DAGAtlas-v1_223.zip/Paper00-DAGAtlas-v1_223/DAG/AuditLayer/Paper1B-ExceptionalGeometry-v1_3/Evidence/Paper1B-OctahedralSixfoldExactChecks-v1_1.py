#!/usr/bin/env python3
"""Independent exact certificate for Paper I-B v1.8 octahedral quartic and sixfold normalizer.

Source: Paper1B-ExceptionalGeometry-v1_8.tex lines 19477--19575.
No source or archive is modified. Ring arithmetic is exact in Q(sqrt(2)).
Requires Python standard library and sympy for the symbolic quartic checks.
"""
from __future__ import annotations
from collections import Counter, defaultdict
from fractions import Fraction as F
from itertools import combinations, permutations, product
from pathlib import Path
from hashlib import sha256
import json

ZERO=(F(0),F(0)); ONE=(F(1),F(0)); NEGONE=(F(-1),F(0)); HALF=(F(1,2),F(0))
def el(a=0,b=0): return F(a),F(b)  # a + b*sqrt(2)
def add(x,y): return (x[0]+y[0], x[1]+y[1])
def neg(x): return -x[0],-x[1]
def sub(x,y): return add(x,neg(y))
def mul(x,y): return (x[0]*y[0]+2*x[1]*y[1], x[0]*y[1]+x[1]*y[0])
def eq(x,y): return x==y

def quat(*cs):
    assert len(cs)==4
    return tuple(x if isinstance(x,tuple) else el(x) for x in cs)

def qm(p,q):
    a,b,c,d=p; w,x,y,z=q
    return (sub(sub(sub(mul(a,w),mul(b,x)),mul(c,y)),mul(d,z)),
            add(add(sub(mul(a,x),mul(d,y)),mul(b,w)),mul(c,z)),
            add(add(add(mul(a,y),mul(d,x)),mul(c,w)),neg(mul(b,z))),
            add(add(sub(mul(a,z),mul(c,x)),mul(d,w)),mul(b,y)))

def qc(p): return (p[0],neg(p[1]),neg(p[2]),neg(p[3]))
def qp(p,n):
    v=unit
    for _ in range(n): v=qm(v,p)
    return v

def dot(p,q):
    v=ZERO
    for a,b in zip(p,q): v=add(v,mul(a,b))
    return v

def conj(p,q): return qm(qm(p,q),qc(p))
def imaginary(v): return v[1:]
def record(name,condition,detail=None):
    global TESTS
    TESTS.append({'test':name,'passed':bool(condition),'detail':detail})
    if not condition: raise AssertionError(name+(' '+str(detail) if detail else ''))

TESTS=[]
unit=quat(1,0,0,0); minus_unit=quat(-1,0,0,0)
ei=[unit,quat(0,1,0,0),quat(0,0,1,0),quat(0,0,0,1)]
Q8=set()
for e in ei:
    Q8.add(e);Q8.add(tuple(neg(x) for x in e))
H=set(Q8)
for signs in product((-1,1),repeat=4):
    H.add(tuple(el(F(sign,2)) for sign in signs))
X=set()
for i,j in combinations(range(4),2):
    for a,b in product((-1,1),repeat=2):
        arr=[ZERO]*4
        arr[i]=el(0,F(a,2))
        arr[j]=el(0,F(b,2))
        X.add(tuple(arr))
O=H|X
record('2T has 24 elements',len(H)==24,len(H))
record('Q8 has 8 elements',len(Q8)==8,len(Q8))
record('2O complement has 24 elements',len(X)==24,len(X))
record('2O has 48 elements, disjoint cosets',len(O)==48 and len(H&X)==0,len(O))
record('all displayed quaternions unit norm',all(dot(q,q)==ONE for q in O))
record('2O group closure (all ordered products)',all(qm(a,b) in O for a in O for b in O))
record('2T group closure (all ordered products)',all(qm(a,b) in H for a in H for b in H))
record('2O exact inverse closure',all(qc(a) in O for a in O))
record('2O normalizes 2T entrywise',all(conj(g,h) in H for g in O for h in H))
record('2T commutator subgroup equals Q8',
       {qm(qm(qm(g,h),qc(g)),qc(h)) for g in H for h in H}==Q8)
record('all 2O elements normalize characteristic Q8',
       all(conj(g,h) in Q8 for g in O for h in Q8))
# Conjugation action: all 24 proper signed coordinate permutations; each has 2 lifts.
rotation_lifts=defaultdict(list)
for q in O:
    mat=[]
    for axis in ei[1:]:
        v=conj(q,axis)
        record('real coordinate zero in axis conjugation',v[0]==ZERO)
        record('axis conjugation has one unit imaginary coordinate',
               sorted(v[1:]) in [sorted((ONE,ZERO,ZERO)),sorted((NEGONE,ZERO,ZERO))])
        mat.append(tuple(v[1:]))
    rotation_lifts[tuple(mat)].append(q)
record('exactly 24 octahedral rotations',len(rotation_lifts)==24,len(rotation_lifts))
record('each octahedral rotation has exactly two lifts',all(len(a)==2 for a in rotation_lifts.values()))
# Four unoriented body diagonal axes, represented by integer sign triples.
axes={(1,1,1),(1,-1,-1),(-1,1,-1),(-1,-1,1)}
def projective_axis(v):
    return v if v in axes else tuple(-a for a in v)

def apply_rot(columns,axis):
    result=[]
    for row in range(3):
        value=sum(axis[col]*int(columns[col][row][0]) for col in range(3))
        result.append(value)
    return tuple(result)

p4=set()
for mat in rotation_lifts:
    per=[]
    for a in sorted(axes):
        transformed=projective_axis(apply_rot(mat,a))
        record('octahedral rotation preserves unordered four axes',transformed in axes)
        per.append(sorted(axes).index(transformed))
    record('body-diagonal map bijective',set(per)==set(range(4)))
    p4.add(tuple(per))
record('all 24 permutations of the four axes realized',len(p4)==24)
Hprojective=set()
for q in H:
    mat=tuple(tuple(conj(q,e)[1:]) for e in ei[1:])
    per=[]
    for a in sorted(axes): per.append(sorted(axes).index(projective_axis(apply_rot(mat,a))))
    Hprojective.add(tuple(per))
def parity(p): return sum(p[i]>p[j] for i in range(len(p)) for j in range(i+1,len(p)))%2
record('Hurwitz 2T projects to tetrahedral A4',len(Hprojective)==12 and all(parity(p)==0 for p in Hprojective))

# Partition X by real coordinate: exact 6,12,6.
rt=el(0,F(1,2)); rn=neg(rt)
Xpos={q for q in X if q[0]==rt}
Xzero={q for q in X if q[0]==ZERO}
Xneg={q for q in X if q[0]==rn}
record('2O coset 6+12+6 partition',len(Xpos)==6 and len(Xzero)==12 and len(Xneg)==6 and Xpos|Xzero|Xneg==X,
       {'positive':len(Xpos),'zero':len(Xzero),'negative':len(Xneg)})
record('Q8 and 2T remainder 8+16 partition',len(H-Q8)==16 and len(Q8&(H-Q8))==0)

# Sixfold normalizer around u=(i+j+k)/sqrt(3), c=(1+i+j+k)/2.
c=quat(F(1,2),F(1,2),F(1,2),F(1,2))
C6={qp(c,n) for n in range(6)}
record('C6 generated by c has six distinct elements',len(C6)==6 and qp(c,6)==unit)
record('c^3=-1',qp(c,3)==minus_unit)
record('C6 contained in 2T',C6<=H)
B=set()
for i,j in ((1,2),(2,3),(3,1)):
    for s in (-1,1):
        v=[ZERO]*4
        v[i]=el(0,F(s,2))
        v[j]=el(0,F(-s,2))
        B.add(tuple(v))
record('six transverse B6 elements',len(B)==6)
record('B6 subset Xzero',B<=Xzero)
record('B6 perpendicular to u=(1,1,1)',all(sum(v[k][1] for k in (1,2,3))==0 for v in B))
record('B6 real linear span is 2D u-perp',
       any([v[1][1]*w[2][1]-v[2][1]*w[1][1] != 0 for v in B for w in B]))
record('B6 elements square to c^3',all(qm(b,b)==minus_unit for b in B))
record('B6 inverts c by conjugation',all(conj(b,c)==qc(c) for b in B))
actualN={g for g in O if conj(g,c) in C6}
record('normalizer in 2O has 12 elements',len(actualN)==12,len(actualN))
record('normalizer equals C6 disjoint union B6',actualN==C6|B and C6.isdisjoint(B))
b0=next(iter(B))
record('B6 is a single nontrivial C6 coset', {qm(a,b0) for a in C6}==B)
record('normalizer realizes binary dihedral 2D3',
       qm(b0,b0)==qp(c,3) and conj(b0,c)==qc(c) and len(actualN)==12)
record('C6 and B6 are existing elements of H and X',C6<=H and B<=Xzero)
record('conjugating by c permutes B6', {conj(c,b) for b in B}==B)

# Symbolic polynomial and invariant-sector derivation.
import sympy as sp
x,y,z=sp.symbols('x y z',real=True)
r2=x*x+y*y+z*z
U=((1,1,1),(1,-1,-1),(-1,1,-1),(-1,-1,1))
Rs=[sp.Rational(1,4)*(r2-sp.Rational(1,3)*(s[0]*x+s[1]*y+s[2]*z)**2) for s in U]
Rbar=sp.expand(sum(Rs)/4)
V=sp.expand(sum((R-Rbar)**2 for R in Rs))
Vexpected=sp.Rational(1,9)*(x*x*y*y+y*y*z*z+z*z*x*x)
H4=x**4+y**4+z**4-sp.Rational(3,5)*r2**2
record('four-axis tight frame sum u uT =4I/3',
       all(sum(U[t][i]*U[t][j] for t in range(4))==(4 if i==j else 0) for i in range(3) for j in range(3)))
record('mean response exactly r2/6',sp.expand(Rbar-r2/6)==0)
record('Born variance quartic exact',sp.expand(V-Vexpected)==0)
record('Born parity V(-v)=V(v)',sp.expand(V.subs({x:-x,y:-y,z:-z}, simultaneous=True)-V)==0)
record('degree-four harmonic decomposition V=r4/45-H4/18',
       sp.expand(V-r2**2/45+H4/18)==0)
record('H4 is harmonic in R3',sp.expand(sum(sp.diff(H4,w,2) for w in (x,y,z)))==0)
record('full variance is not harmonic: Laplacian = 4r2/9',
       sp.expand(sum(sp.diff(V,w,2) for w in (x,y,z))-sp.Rational(4,9)*r2)==0)
record('H4 not radial: sphere-sample witness',V.subs({x:1,y:0,z:0})==0 and V.subs({x:sp.Rational(3,5),y:sp.Rational(4,5),z:0})==sp.Rational(16,625))
record('degree-3 tetrahedral invariant xyz harmonic',sum(sp.diff(x*y*z,w,2) for w in (x,y,z))==0)

def inv_dim(n):
    # Invariance under the three diagonal half-turns forces all exponents
    # (a,b,c) to share parity; a cyclic x->y->z rotation permutes triples.
    monomials={(a,b,n-a-b) for a in range(n+1) for b in range(n-a+1)}
    subset={m for m in monomials if m[0]%2==m[1]%2==m[2]%2}
    orbits=[]
    while subset:
        a,b,c=next(iter(subset));orbit={(a,b,c),(b,c,a),(c,a,b)}
        record(f'degree {n} invariant orbit well-formed',orbit<=subset)
        subset-=orbit
        orbits.append(sorted(orbit))
    return len(orbits),orbits
invdims={}
for n in range(5): invdims[n],_=inv_dim(n)
record('tetrahedral invariant polynomial dimensions degree 0-4',invdims=={0:1,1:0,2:1,3:1,4:2},invdims)
hdims={n:invdims[n]-(invdims[n-2] if n>=2 else 0) for n in invdims}
record('harmonic tetrahedral dimensions degree 0-4',hdims=={0:1,1:0,2:0,3:1,4:1},hdims)
record('degree-four harmonic is Born-even first nonradial even class',hdims[2]==0 and hdims[4]==1 and sp.expand(H4.subs({x:-x,y:-y,z:-z},simultaneous=True)-H4)==0)
record('degree-three invariant xyz is Born-odd',sp.expand((x*y*z).subs({x:-x,y:-y,z:-z},simultaneous=True)+x*y*z)==0)
# Verify exact invariance under all 24 orientation-preserving signed permutations.
for perm in permutations(range(3)):
    for signs in product((-1,1),repeat=3):
        args=[signs[i]*(x,y,z)[perm[i]] for i in range(3)]
        record('V invariant under signed permutation',sp.expand(V.subs({x:args[0],y:args[1],z:args[2]},simultaneous=True)-V)==0)

# Adversarial boundary checks: the quartic is not invariant under all of Sp(1),
# and the finite normalizer inside 2O is smaller than the continuous Pin(2).
qbad=quat(F(3,5),0,0,F(4,5))
image_i=conj(qbad,ei[1])
record('explicit unit SU2 element outside 2O',dot(qbad,qbad)==ONE and qbad not in O)
record('conjugated e1 under non-octahedral unit quaternion',
       image_i==quat(0,F(-7,25),F(24,25),0))
record('generic SU2 rotation does not preserve quartic',
       V.subs({x:1,y:0,z:0})==0 and
       V.subs({x:sp.Rational(-7,25),y:sp.Rational(24,25),z:0})==sp.Rational(3136,390625))
qaxis=quat(F(1,7),F(4,7),F(4,7),F(4,7))
record('explicit axial circle element is unit and outside 2O',
       dot(qaxis,qaxis)==ONE and qaxis not in O)
record('axial circle element commutes with c outside finite normalizer',
       conj(qaxis,c)==c and qaxis not in actualN)

# Common historical/parent dependencies are checked as data, not edited.
source=Path('/mnt/data/paper1b_closure_batched/Paper1B-ExceptionalGeometry-v1_8.tex')
source_hash=sha256(source.read_bytes()).hexdigest() if source.exists() else None
summary={
 'source':'Paper1B-ExceptionalGeometry-v1_8.tex',
 'source_sha256':source_hash,
 'target_lines':'19477-19575',
 'theorem_label':'p1b:thm:v18-born-even-octahedral-response',
 'proposition_label':'p1b:prop:v18-octahedral-sixfold-attachment',
 'scope_remark_label':'p1b:rem:v18-particle-response-frontier',
 'checks_total':len(TESTS),
 'checks_passed':sum(t['passed'] for t in TESTS),
 'checks_failed':sum(not t['passed'] for t in TESTS),
 'counts':{'Q8':len(Q8),'2T':len(H),'2O':len(O),'X_positive':len(Xpos),'X_zero':len(Xzero),'X_negative':len(Xneg),'C6':len(C6),'B6':len(B),'N_2O_C6':len(actualN), 'octahedral_rotations':len(rotation_lifts)},
 'invariant_polynomial_dimensions_0_to_4':invdims,
 'invariant_harmonic_dimensions_0_to_4':hdims,
 'outcome':'all mathematical formulae in the two newly added v1.8 claims verified in aligned standard Hurwitz embedding',
 'limits':['a quartic stabilizer is not physical occurrence','the given coordinate axes must be co-rotated for a conjugated Hurwitz embedding', 'infinite SU(2) stabilizer follows zero-locus rigidity and the double cover argument, not from finite closure alone'],
 'tests':TESTS,
}
out=Path('/mnt/data/Paper1B-OctahedralSixfoldExactControls-v1_1.json')
out.write_text(json.dumps(summary,indent=2,default=str)+'\n')
print('PASS',summary['checks_passed'],'/',summary['checks_total'])
print('COUNTS',summary['counts'])
print('POLYNOMIAL',invdims,'HARMONIC',hdims)
print('RESULTS',out)
