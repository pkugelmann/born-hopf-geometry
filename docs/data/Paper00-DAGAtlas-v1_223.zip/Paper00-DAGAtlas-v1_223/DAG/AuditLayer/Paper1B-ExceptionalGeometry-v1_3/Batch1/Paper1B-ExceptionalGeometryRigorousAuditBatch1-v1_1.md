# Paper I-B — Exceptional Geometry, rigorous verification DAG audit — Batch 1

**Audit contract:** Single selected paper; source-only verification; no theory extensions, source edits, assumptions invented or physical identifications promoted. This is an interim checkpoint, **not** a fully audited paper or final artifact release.

**Source of authority:** `Paper1B-ExceptionalGeometry-v1_7.tex` (SHA-256 `67ae02d9843853b6396f339eb4ec7184abd9258d5d6b8335bd757c929b5fa89b`), from `Paper00-PapersMinimal-v3_011`; 19,479 TeX lines. **Checked:** formal statements with source starts at lines 114–1830, proofs through line 1912, batch boundary line 1913.

**Coverage:** 46/480 formal theorem-like environments (**9.58%**). Dispositions: 33 `VERIFIED` (complete E1 plus applicable independent exact mathematics or theorem proof and challenge check), 6 `REPRODUCED` (E1 plus independent numerical/partial evidence; exact independent E3 outstanding), 7 `FORMALIZED` (five remarks and two definitions). **0** `REFUTED`, **0** established incorrect mathematical steps in this batch. **8 audit/DAG issues** (2 DAG coverage; 6 unresolved exact E3 obligations).

## Method and provenance boundary

- `E0`: frozen source census, label identity and cross-join against canonical DAG; hash checks are **not** correctness evidence.
- `E1`: replayed the source proof, matching theorem domain, quantifiers, algebraic coefficients and dependence on the specified marked `2I`/`2T` packet. Claims about group/graph modules are not read as physical state/interaction claims.
- `E3`: independently programmed finite-quaternion and number-field controls, Hodge/Clifford matrices, projective-plane incidence and exact integer nearest-shell polynomial and moment identities. The evidence scripts were built independently of DAG status flags.
- `E4`: adversarial orientation changes, sign gauges, branch interchange, opposite cross sectors, group coset counts, 600-cell projective quotient, and same-operator vs different-carrier boundaries. No in-domain counterexample found on tested claims. Several checks are finite numerical rather than fully algebraic (logged below).
- Import: I-A theorem `p1:thm:exceptional-normalizer-fork` (present current Paper1A) provides a material normalizer/classification interface; I-D `p1c:sec:v371-petersen-600cell-certificate` is a cited mathematical certificate, **not** recursively audited here. No G0/GP1–GP3 open premise is invented from these finite-domain identities.

## Reproducible evidence and level

| Evidence file (same checkpoint work folder) | Independent test | Level | Outcome |
|---|---|---|---|
| `Paper1B-Batch1-ExactQsqrt5-v1_1.json` | Quadrupole determinants, signed Hodge, axis/core maps, mirror and 15-edge projections using field `Q(√5)` | E3 exact | 50 checks pass |
| `Paper1B-Batch1-ExactSignedHodge-v1_1.json` | Integer/±1 projective-plane face incidence, twisted cycle, gauge and Hodge identities | E3 exact | 10 checks pass |
| `Paper1B-Batch1-ExactIntegerShellSpectra-v1_1.json` | For 24/48/120 convolution matrices, exact integer annihilating polynomials and matching trace moments (distinct roots/multiplicities) | E3 exact | 3 group certificates pass |
| `Paper1B-Batch1-IndependentConvolutions-v1_1.json` | Explicit quaternion group elements, spectrum, 2T/2O/2I cosets, 15-dimensional joint kernel | E3 numerical + finite combinatorics | 11 checks pass |
| `Paper1B-Batch1-IndependentExtendedControls-v1_1.json` | Full 15-edge Hodge, 20-dimensional tangent complex, root leakage, mirror and odd Kneser instances | E2/E3 depending identity | 95 checks pass; includes earlier 45 |
| `Paper1B-Batch1-IndependentAdversarialControls-v1_1.json` | Exhaustive group/orbit counts, 600-cell inverse quotient, bisectors and tensor Gram mutation | E4 + partial E3 | 16 checks pass |

The test counts are **not** treated as 185 independent proofs: some overlap in data or premises, and floating-point tests do not supply exact E3 for the six named results.

## Per-claim census and current dispositions

| Source lines | Claim ID | Claimed result (abridged) | Audit status |
|---:|---|---|---|
| 114–133 | `p1:thm:v273-two-icosahedral-completions` | Two icosahedral completions of one tetrahedral core | `VERIFIED` |
| 157–168 | `p1:cor:v273-twins-sharp-common-invariants` | Simultaneous exceptional invariance and its no-go | `VERIFIED` |
| 178–197 | `p1:thm:v237-mobile-tetrahedral-completion` | Finite mobile tetrahedral completion inside the quaternionic spin group | `VERIFIED` |
| 208–228 | `p1:cor:v237-five-core-ten-axis-packet` | Generated five-core, ten-axis and local-normalizer packet | `VERIFIED` |
| 241–258 | `p1:cor:v237-exceptional-stabilizer-characterization` | Stabilizer characterization of the exceptional resolution roles | `VERIFIED` |
| 260–301 | `p1:thm:v285-ten-axis-quadrupole-exact-sequence` | Ten-axis incidence--quadrupole exact sequence | `VERIFIED` |
| 336–341 | `Paper1B-remark-336` | Quadrupole quotient | `FORMALIZED` |
| 343–348 | `p1:rem:v237-forty-packet-clock-firewall` | Cardinality and orbit data | `FORMALIZED` |
| 370–399 | `p1:thm:petersen-angular-quadrupole` | Intrinsic Petersen graph and quadrupole spectrum | `VERIFIED` |
| 413–450 | `p1:thm:petersen-signed-and-flux` | Signed ten-axis module and order-four edge flux | `VERIFIED` |
| 467–490 | `p1:thm:petersen-fifteen-resolution` | Full fifteen-edge Hodge--Clifford resolution | `VERIFIED` |
| 500–526 | `p1:thm:petersen-pentagon-reciprocity` | Pentagon holonomy and reciprocal cycle-frame spectrum | `REPRODUCED` |
| 539–550 | `p1:prop:petersen-binary-and-snark` | Real binary edge holonomy and coloring obstruction | `VERIFIED` |
| 562–588 | `p1:thm:petersen-bisector-simplex` | Two-parent transverse bisector and core-local mirror simplex | `VERIFIED` |
| 604–626 | `p1:thm:petersen-subset-polar` | All core subsets and their axial polar response | `VERIFIED` |
| 636–662 | `p1:thm:petersen-mirror-envelope` | The nine-dimensional mirror-operator envelope | `VERIFIED` |
| 676–703 | `p1:prop:petersen-cubic-gradient-interface` | Harmonic-cubic portal and the complete edge-space interface | `VERIFIED` |
| 723–751 | `p1:thm:v371-petersen-600cell-total-cover` | Dodecahedral lift and the induced fifty-vertex total graph | `REPRODUCED` |
| 769–796 | `p1:prop:v371-petersen-q8-angular` | Quaternionic edge frames and four angular channel orbits | `REPRODUCED` |
| 811–860 | `p1:thm:v371-petersen-tangent-exact-sequence` | Projective trimer uniqueness and exact ten-axis tangent sequence | `REPRODUCED` |
| 882–903 | `p1:thm:v371-petersen-source-reconstruction` | Canonical recovery and minimal two-axis support | `VERIFIED` |
| 919–955 | `p1:thm:v371-petersen-rooted-leakage` | Marked $2T$ root leakage and five-root sum rules | `REPRODUCED` |
| 975–994 | `p1:prop:v371-petersen-quadrupole-flux` | Quadrupole--flux tensor contraction | `REPRODUCED` |
| 1005–1030 | `p1:prop:petersen-120-strata` | The marked-core 120-element strata | `VERIFIED` |
| 1042–1059 | `Paper1B-remark-1042` | Exact extent and physical firewall | `FORMALIZED` |
| 1072–1098 | `p1:thm:v327-pair-mirror-projector` | Exact two-core mirror-active projection and transport | `VERIFIED` |
| 1127–1136 | `p1:cor:v327-pair-eligibility-not-coherence` | Eligibility is not coherence | `VERIFIED` |
| 1159–1175 | `p1:thm:kneser-six-axis-triangle-systems` | Dual six-axis triangle systems and the second Petersen graph | `VERIFIED` |
| 1198–1238 | `p1:thm:kneser-five-six-hodge-duality` | Equivariant Petersen duality and signed-Hodge orientation | `VERIFIED` |
| 1258–1279 | `p1:cor:kneser-twisted-cycle-root-bridge` | Twisted-cycle roots and the complete quintet bridge | `VERIFIED` |
| 1297–1320 | `p1:thm:kneser-universal-odd-hodge` | Universal signed odd-Kneser Hodge operator | `VERIFIED` |
| 1335–1354 | `p1:cor:kneser-universal-dirac` | Universal incidence--Hodge Dirac square | `VERIFIED` |
| 1365–1378 | `p1:prop:kneser-five-six-native-limit` | No forced higher odd-graph tower from one $2I$ | `VERIFIED` |
| 1393–1409 | `p1:thm:2O-2I-generate-SU2` | Exceptional sibling generation is dense in SU(2) | `VERIFIED` |
| 1422–1428 | `Paper1B-remark-1422` | Same carrier and same operator are essential | `FORMALIZED` |
| 1432–1451 | `p1:thm:v285-shared-axis-pin2` | Shared-axis octahedral--icosahedral completion is dense in \operatorname{Pin}(2) | `VERIFIED` |
| 1484–1490 | `Paper1B-remark-1484` | Local/global continuous completions | `FORMALIZED` |
| 1492–1508 | `p1:def:nearest-shell-walk` | Nearest-shell walk | `FORMALIZED` |
| 1510–1586 | `p1:thm:exceptional-nearest-shell-spectra` | Nearest-shell spectra of the exceptional binary groups | `VERIFIED` |
| 1644–1662 | `p1:def:exceptional-shell-scalar-atom` | Uniform exceptional nearest-shell scalar atom | `FORMALIZED` |
| 1664–1694 | `p1:thm:exceptional-345-shell-table` | Exceptional 3,4,5 shell-angle, atom, and chord table | `VERIFIED` |
| 1706–1722 | `p1:cor:exceptional-defining-trace-fields` | Defining trace-field fork | `VERIFIED` |
| 1733–1746 | `p1:prop:exceptional-shell-mckay-eigenvalues` | Nearest-shell traces as McKay adjacency eigenvalues | `VERIFIED` |
| 1760–1796 | `p1:thm:2O-nearest-shell-tangent-frame` | Octahedral nearest-shell tangent frame | `VERIFIED` |
| 1810–1828 | `p1:cor:2O-shell-E6-reconstruction` | Exact E_6 rank--Coxeter numerical compatibility | `VERIFIED` |
| 1830–1861 | `p1:cor:nearest-shell-inclusion-consequences` | Pure inclusion consequences of the nearest-shell walks | `VERIFIED` |

## Root issues: all eight IDs

### `BH-IBX-DAG-0001` — DAG_COVERAGE / moderate / OPEN

- **Earliest location:** `DAG/AuditLayer/Paper1B-v1_1, DAG/Paper00-TheoremDAG.json Paper1B objects; current source line 114`; target `p1:thm:v273-two-icosahedral-completions`.
- **Exact unresolved observation:** Distinct manuscript identities must have distinct audit provenance; past M8 Geometry coverage does not count toward current Exceptional Geometry coverage.
- **Finding:** False audit completeness or wrong source attribution, not a refutation of a theorem.
- **Required closure:** Add separately named ExceptionalGeometry current source audit layer and link it to the global DAG, while retaining old M8 historical records unchanged.
- **Proven forward impact:** no independently reviewed material cross-paper path established in this batch; do **not** globally downgrade historical physics results from this item. Potential downstream owner/trace consumers are unconfirmed.

### `BH-IBX-DAG-0002` — DAG_COVERAGE / moderate / OPEN

- **Earliest location:** `Paper1B-ExceptionalGeometry-v1_7.tex:114; DAG/Paper00-TheoremDAG.json source_file/paper fields`; target `p1:thm:v273-two-icosahedral-completions`.
- **Exact unresolved observation:** Every current exceptional-geometry claim must have a current-source owner/anchor and typed edge; current batch has 18 displaced Paper1A owners, 28 absent nodes.
- **Finding:** Current owner mismatch, missing target nodes and potential unsupported inherited status promotion; not mathematical inconsistency.
- **Required closure:** Use current source anchor map, namespaced current audit layer, reviewed alias/status mapping and typed proof edges. Preserve historical source_file as provenance.
- **Proven forward impact:** no independently reviewed material cross-paper path established in this batch; do **not** globally downgrade historical physics results from this item. Potential downstream owner/trace consumers are unconfirmed.
- **Current owner mismatch:** 18 claim IDs currently attributed to a historical Paper1A revision; **missing canonical nodes:** 28. Exact IDs frozen in the JSON companion.

### `BH-IBX-EV-0001` — MISSING_EVIDENCE / minor / OPEN

- **Earliest location:** `Paper1B-ExceptionalGeometry-v1_7.tex:500-526`; target `p1:thm:petersen-pentagon-reciprocity`.
- **Exact unresolved observation:** Independent exact cycle-frame projector diagonalization and orientation-resolved complementary-flux identities over the source coefficient field.
- **Finding:** Current E1 replay and independent numerical/reduced checks are supportive but not an independent exact E3 certificate; theorem is retained as REPRODUCED pending the stated check, not refuted.
- **Required closure:** Independent exact cycle-frame projector diagonalization and orientation-resolved complementary-flux identities over the source coefficient field.
- **Proven forward impact:** no independently reviewed material cross-paper path established in this batch; do **not** globally downgrade historical physics results from this item. The currently audited claim remains REPRODUCED pending exact E3, not logically refuted.

### `BH-IBX-EV-0002` — MISSING_EVIDENCE / minor / OPEN

- **Earliest location:** `Paper1B-ExceptionalGeometry-v1_7.tex:723-751`; target `p1:thm:v371-petersen-600cell-total-cover`.
- **Exact unresolved observation:** Independent exact Q(sqrt5) finite-coordinate certificate of all 50-vertex induced adjacencies and midpoint/quotient identifications.
- **Finding:** Current E1 replay and independent numerical/reduced checks are supportive but not an independent exact E3 certificate; theorem is retained as REPRODUCED pending the stated check, not refuted.
- **Required closure:** Independent exact Q(sqrt5) finite-coordinate certificate of all 50-vertex induced adjacencies and midpoint/quotient identifications.
- **Proven forward impact:** no independently reviewed material cross-paper path established in this batch; do **not** globally downgrade historical physics results from this item. The currently audited claim remains REPRODUCED pending exact E3, not logically refuted.

### `BH-IBX-EV-0003` — MISSING_EVIDENCE / minor / OPEN

- **Earliest location:** `Paper1B-ExceptionalGeometry-v1_7.tex:769-796`; target `p1:prop:v371-petersen-q8-angular`.
- **Exact unresolved observation:** Independent exact quaternion membership, Q8 incidence, and 15-channel angular/distance orbit partition, including label-parity distinction.
- **Finding:** Current E1 replay and independent numerical/reduced checks are supportive but not an independent exact E3 certificate; theorem is retained as REPRODUCED pending the stated check, not refuted.
- **Required closure:** Independent exact quaternion membership, Q8 incidence, and 15-channel angular/distance orbit partition, including label-parity distinction.
- **Proven forward impact:** no independently reviewed material cross-paper path established in this batch; do **not** globally downgrade historical physics results from this item. The currently audited claim remains REPRODUCED pending exact E3, not logically refuted.

### `BH-IBX-EV-0004` — MISSING_EVIDENCE / minor / OPEN

- **Earliest location:** `Paper1B-ExceptionalGeometry-v1_7.tex:811-860`; target `p1:thm:v371-petersen-tangent-exact-sequence`.
- **Exact unresolved observation:** Independent exact rank/orthogonality certificate for the 20-dimensional tangent F/M sequence and its D3-equivariance, not just full-rank floating-point tests.
- **Finding:** Current E1 replay and independent numerical/reduced checks are supportive but not an independent exact E3 certificate; theorem is retained as REPRODUCED pending the stated check, not refuted.
- **Required closure:** Independent exact rank/orthogonality certificate for the 20-dimensional tangent F/M sequence and its D3-equivariance, not just full-rank floating-point tests.
- **Proven forward impact:** no independently reviewed material cross-paper path established in this batch; do **not** globally downgrade historical physics results from this item. The currently audited claim remains REPRODUCED pending exact E3, not logically refuted.

### `BH-IBX-EV-0005` — MISSING_EVIDENCE / minor / OPEN

- **Earliest location:** `Paper1B-ExceptionalGeometry-v1_7.tex:919-955`; target `p1:thm:v371-petersen-rooted-leakage`.
- **Exact unresolved observation:** Independent exact Q(sqrt5) proof of both five-root operator sum identities, especially the source-side C_m^T C_m identity.
- **Finding:** Current E1 replay and independent numerical/reduced checks are supportive but not an independent exact E3 certificate; theorem is retained as REPRODUCED pending the stated check, not refuted.
- **Required closure:** Independent exact Q(sqrt5) proof of both five-root operator sum identities, especially the source-side C_m^T C_m identity.
- **Proven forward impact:** no independently reviewed material cross-paper path established in this batch; do **not** globally downgrade historical physics results from this item. The currently audited claim remains REPRODUCED pending exact E3, not logically refuted.

### `BH-IBX-EV-0006` — MISSING_EVIDENCE / minor / OPEN

- **Earliest location:** `Paper1B-ExceptionalGeometry-v1_7.tex:975-994`; target `p1:prop:v371-petersen-quadrupole-flux`.
- **Exact unresolved observation:** Independent exact-field 15x15 tensor Gram identity and invertibility certificate.
- **Finding:** Current E1 replay and independent numerical/reduced checks are supportive but not an independent exact E3 certificate; theorem is retained as REPRODUCED pending the stated check, not refuted.
- **Required closure:** Independent exact-field 15x15 tensor Gram identity and invertibility certificate.
- **Proven forward impact:** no independently reviewed material cross-paper path established in this batch; do **not** globally downgrade historical physics results from this item. The currently audited claim remains REPRODUCED pending exact E3, not logically refuted.

## Source/DAG provenance collision, clarified

The older `DAG/AuditLayer/Paper1B-v1_1` material is for `Paper1B-M8Geometry-v1_131.tex`, and global `Paper1B` nodes refer to an earlier M8 Geometry incarnation. **The current target is instead `Paper1B-ExceptionalGeometry-v1_7.tex`.** Those audit layers must coexist with explicit source identity and revised current-owner mapping. The `DAG/CurrentSourceAnchorMap-v3_011.json` resolves current Exceptional Geometry but does not verify its proofs. Do not overwrite the old evidence or count it toward coverage here.

## Conditional interpretation and negative evidence

The theorem packets are conditional on fixed, source-licensed finite subgroup/axis choices; theorems carefully distinguish `2T` local geometry, `2O` normalizer, the `2I` mobile completion, projective/oriented channels, and same-operator invariance. The finite six-axis/odd-Kneser Hodge constructions are not physical embedding theorems. Neither a 600-cell nearest-edge quotient nor a numerical rank/Coxeter coincidence supplies a mass, decay law, Hamiltonian coupling or selection of a physical channel. No fresh independent physical-action or observables claim was added.

## Handoff and final-release restriction

- **State:** `PARTIALLY_AUDITED`; 46 of 480 formal source claims examined, 434 remain. The two DAG coverage issues and six exact E3 issues are open; they are not mathematical refutations.
- **Next batch:** resume at source line 1914, with next formal definition at 1942; preserve label and issue IDs and do not re-audit this prefix without new evidence.
- **No ZIPs exported in Batch 1.** Last batch must produce updated `Paper00-DAGAtlas-v1_135.zip` and `Paper00-ProofChainAudits-v1_51.zip`, each retaining one latest version of the required members with original historical records preserved where necessary; post-write readback/schema validation required.

