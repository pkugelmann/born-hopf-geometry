# Paper I-B — Rigorous Verification DAG Audit, Batch 5 (v1_1)

**Frozen current source:** `Paper1B-ExceptionalGeometry-v1_7.tex`, sha256 `67ae02d9843853b6396f339eb4ec7184abd9258d5d6b8335bd757c929b5fa89b`. **Audited source lines:** **10640–13348 inclusive**. 70 formal claims (55 substantive, 15 definitions/remarks); 480 total formal objects in the full paper. The appendix portions and source as printed control all dispositions. Neither the TeX nor the supplied ZIP baselines were changed.

**Protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4(1).md` and its E0/E1/E3/E4 gates; SOURCE-AS-PRINTED, true proof dependencies, explicit constructor/physical scope, and no invented corrections.

## Adjudication and cumulative coverage

| Measure | Batch 5 | Cumulative |
|---|---:|---:|
| VERIFIED (substantive, source-scoped) | 55 | 236 |
| FORMALIZED (definitions/remarks) | 15 | 74 |
| REPRODUCED pending independent exact certificate | 0 | 6 |
| **All formal claims examined** | **70** | **316 / 480 (65.83%)** |
| Independent exact controls | **564 pass / 0 fail** | — |
| New mathematical/presentation issues | **0** | **9 carried open** |

An E3 check is a distinct finite/symbolic representation or analytic proof at the source stated scope, not a claim that a physical particle, mass, action, chirality source or observable has been generated. The 480 denominator is formal environments and does not, by itself, replace additional material unnamed equation checks.

## Source proof families and independent verification

**10704–10824 — Quadratic carrier and complement.** Nine trace-free harmonic quadratics, Sym² E1=E0⊕E2 and the 2T⊂2I 96/48 complement are checked; exact multiplication closure of 120 icosians, all 14,400 products, and four free 2T cosets. No E2 shear sector is silently added to H1.

**10828–10994 — Exceptional roots.** The unique specified F golden field action satisfies F²=F+I, self-adjointness and even-quaternion commutation. The exact 240-root E8 lift matches RM(1,3) halfplane coordinates; all 57,600 reflections and E7/E6 126/72-root sections close; independent Cartan determinants and E6/E7/E8 Dynkin arms match.

**10995–11479 — Clifford truncation and finite Hurwitz harmonics.** All terminal degree projectors for m=0..4 satisfy the stated Clifford-sphere leakage identities. The global complex 15D Clifford module obstruction is exact. The full 24-point Hurwitz 5-design has the specified degree-six defect 3/8 and H6 polynomial identity; BM projectors give 15+9. The first nonradial full-cell invariant is sextic.

**11480–11775 — Triality octets and critical boundary.** Exact 24-cell counts 24–96–96–24; the oriented face boundary is a chain and has rank73, independent via modular rank + vertex boundary bound. Dual cells form three octets. The Euclidean ball/axial hemisphere constants are DtN zero modes; determinant scalarization on a positive 2D tangent map gives exp(-ell), not an inverse DtN generator.

**11787–12198 — Invariant pencils, Hopf/axial alternatives and fixed-axis comparisons.** Tetrahedral invariants f6,f8,g12, norm/polar readouts and the 12th-degree Wronskian have exact field/symbolic certificates. Opposite Hopf complex isotropic projections preserve bilinear duality, while a generic real-axis rotation moves its real line. Joint eight-axis sign moments, fixed-axis discriminant, and sqrt17 positive two-plane pencil are distinct source claims.

**12199–12758 — Primitive owners and metric-normalized Spin8 triality.** Three D4 tetrads are orthogonal, the six bivector pairs are functorial, the antipodal pair spaces have distinct A4 types. The 192 oriented incidence count, rank3 central lift, 32 unsigned triality supports, 64 normalized signed tensor norm and 1/2 spectator extraction keep coefficient ownership explicit.

**12770–13348 — Rooted determinant, trimer transport, signed channels and phase returns.** The commutant of X_G and R_G is scalar, so determinant192 gives a unique positive equivariant lift. Four axial support weights pair as stated. All C3 affine reflections invert X_G, and the exact generator exponent equals X_G. Fock occupation channels recover signed D_eta W D_eta; three-channel Grams and the complete quarter-turn 1,5,5 return agree. No physical mass-source insertion follows.

## Evidence-gate qualifications

Claim-linked executable controls cover **50** of the 55 substantive claims. The remaining five have separately recorded independent analytic/representation-theoretic E3 arguments in the ledger: invariant Q scalarity does not select m=1; full W(F4) first nonradial sextic degree; the zero-mode inverse-DtN exclusion; 2T polar/axial naturality; and ±6 ranks of a twelve-point fixed-point-free involution. Other high-impact proofs include supplementary written independent analyses even when exact checks are linked.

The classical full F4 reflection-group generator degrees 2,6,8,12 remain an imported classification beyond the independently checked first nonradial degree6; the exceptional root auxiliary ZIP mentioned at 10970 is not part of the current supplied papers archive, but the explicit 240/126/72-root reflection and Cartan certificates were independently regenerated here. These are transparent provenance boundaries, not proven mathematical defects.

**Rejected adversarial attacks preserved, not manuscript issues:** (1) missing |n|=1 reduction in a joint-moment test, (2) symbolic matrix exponential not simplifying until spectral interpolation, (3) unsimplified complex isotropic pairing, (4) a noncentral R violating the explicit commutant conditions, and (5) attempting to identify unsigned triality support with its signed invariant or a physical interaction. None is a valid in-domain counterexample. Normalizations, phase frames, root inclusion and optional physical bridge are retained precisely.

## DAG coverage and source-reference review

Canonical current-source ownership for this batch: **68 historical owner**, **2 not yet canonical**, **0 current**. Through Batch 5 the global owner mismatch covers **255 historical matches and 61 absent current-source nodes**, under existing `BH-IBX-DAG-0002`. This is DAG traceability, not a false mathematical gap.

All **25** distinct referenced current-source labels within formal statements/proofs resolve uniquely in the authoritative PapersMinimal archive. This batch proposes **15** bounded source-witnessed/candidate links: 13 material imports, 0 definition/condition imports, and 2 references retained only as unpromoted candidates. All directions are premise→consumer and the graph was not rewritten in an interim batch.

Nine first-appearance condition candidates are recorded at their earliest presently known source occurrence in this target: golden field module; E8 rooted lift; oriented axial boundary; positive tangent determinant map; invariant base-point-free degree12 pencil; metric-normalized Fock triality; unmarked family determinant lift; fixed-owner full return; and rooted occupation/phase frames. Repeated upstream conditions are aliases, not duplicated axioms.

## Full carried nine-issue register — zero new roots

| Stable issue ID | Category | Exact remaining obligation |
|---|---|---|
| `BH-IBX-DAG-0001` | Historical/current manuscript identity | Separate the old M8 Paper I-B audit from current Exceptional Geometry; do not inherit old verified flags. |
| `BH-IBX-DAG-0002` | Current-source canonical DAG ownership | Create current-source claim nodes/typed proof paths while retaining historical I-A owners and source locators. |
| `BH-IBX-EV-0001` | Prior evidence | Independent exact pentagon holonomy/reciprocal flux certificate, source line500. |
| `BH-IBX-EV-0002` | Prior evidence | Exact 600-cell 50-vertex induced adjacency/quotient certificate, source line723. |
| `BH-IBX-EV-0003` | Prior evidence | Exact Q8 angular-orbit and channel partition certificate, source line769. |
| `BH-IBX-EV-0004` | Prior evidence | Exact D3-equivariant 20D tangent sequence certificate, source line811. |
| `BH-IBX-EV-0005` | Prior evidence | Exact five-root leakage sum, including source-side Gram, source line919. |
| `BH-IBX-EV-0006` | Prior evidence | Exact 15×15 quadrupole tensor Gram/invertibility, source line975. |
| `BH-IBX-SRC-0001` | Current-source attribution | Correct historical I-A attribution for the trimer claim now owned by current Paper I-B, source line3992. |

No established mathematical defect, physical prediction failure or proven downstream observable impact was found in this batch. The evidence, source/DAG provenance and potential cross-paper effects remain separate. The nine carried issues have not been falsely closed.

## Per-claim frozen source and E3 census

| Source lines | Current claim label | Status | Proof location | Independent E3 checks |
|---:|---|---|---:|---:|
| 10704–10717 | `p1:prop:v189-tracefree-quadratic-harmonics` | `VERIFIED` | display/direct/imported | 10 |
| 10720–10737 | `p1:cor:v191-sym2-e1-e0e2` | `VERIFIED` | 10739–10747 | 1 |
| 10750–10755 | `p1:cor:v189-level-one-shear-exclusion` | `VERIFIED` | display/direct/imported | 1 |
| 10760–10775 | `p1:prop:v224-icosian-complement` | `VERIFIED` | 10776–10783 | 11 |
| 10828–10852 | `p1:prop:exroot-golden-action` | `VERIFIED` | 10853–10866 | 7 |
| 10875–10887 | `p1:thm:exroot-explicit-e876` | `VERIFIED` | 10888–10968 | 19 |
| 10970–10982 | `p1:rem:exroot-construction-scope` | `FORMALIZED` | — | 0 |
| 10995–11018 | `p1:prop:terminal-degree-leakage` | `VERIFIED` | 11020–11034 | 175 |
| 11036–11051 | `p1:prop:quadratic-coordinate-scalarity-no-selector` | `VERIFIED` | 11053–11061 | 0 |
| 11063–11077 | `p1:prop:global-clifford-divisibility-obstruction` | `VERIFIED` | 11079–11085 | 1 |
| 11344–11373 | `p1:prop:math-hurwitz-cubature-six-defect` | `VERIFIED` | 11375–11417 | 129 |
| 11419–11442 | `p1:cor:math-twentyfourcell-explicit-projectors` | `VERIFIED` | 11444–11456 | 5 |
| 11458–11470 | `p1:prop:math-f4-sextic-obstruction` | `VERIFIED` | 11472–11478 | 0 |
| 11480–11498 | `p1:prop:math-triality-octets-k444` | `VERIFIED` | 11500–11507 | 1 |
| 11510–11538 | `p1:thm:v235-hurwitz-chain-complex` | `VERIFIED` | 11539–11552 | 7 |
| 11554–11566 | `p1:cor:v235-dual-cell-triality` | `VERIFIED` | 11567–11573 | 1 |
| 11579–11599 | `p1:thm:v167-hardy-constant-dtn-zero` | `VERIFIED` | 11601–11609 | 1 |
| 11611–11617 | `p1:cor:v167-critical-mode-owner-firewall` | `VERIFIED` | 11618–11621 | 0 |
| 11633–11648 | `p1:def:v557-axial-great-sphere-boundary` | `FORMALIZED` | — | 0 |
| 11650–11665 | `p1:thm:v557-axial-boundary-normal` | `VERIFIED` | 11667–11679 | 4 |
| 11681–11691 | `p1:thm:v557-axial-hemisphere-dtn-zero` | `VERIFIED` | 11693–11696 | 1 |
| 11698–11715 | `p1:def:v557-boundary-determinant-scalarization` | `FORMALIZED` | — | 0 |
| 11717–11739 | `p1:thm:v557-determinant-scalar-descent` | `VERIFIED` | 11741–11747 | 1 |
| 11749–11766 | `p1:cor:v557-boundary-scalar-semigroup` | `VERIFIED` | display/direct/imported | 1 |
| 11768–11775 | `p1:rem:v557-boundary-process-owner-firewall` | `FORMALIZED` | — | 0 |
| 11787–11814 | `p1:prop:higher-invariant-pencil` | `VERIFIED` | 11815–11836 | 13 |
| 11838–11859 | `p1:prop:invariant-compression-connection` | `VERIFIED` | 11860–11879 | 3 |
| 11899–11914 | `p1:prop:axial-invariant-transport` | `VERIFIED` | 11915–11921 | 0 |
| 11923–11955 | `p1:prop:opposite-hopf-moving-axis` | `VERIFIED` | 11956–11964 | 5 |
| 11966–11981 | `Paper1B-remark-11966` | `FORMALIZED` | — | 0 |
| 11991–12001 | `p1:prop:finite-quadratic-covariant-space` | `VERIFIED` | 12002–12011 | 16 |
| 12013–12035 | `p1:thm:joint-axis-moments-heat` | `VERIFIED` | 12036–12049 | 5 |
| 12056–12065 | `p1:prop:fixed-axis-quadratic-zeros` | `VERIFIED` | 12066–12074 | 2 |
| 12085–12110 | `p1:prop:v179-exceptional-quadratic-pencil` | `VERIFIED` | 12111–12116 | 3 |
| 12135–12148 | `p1:prop:v191-noncentral-maximal-torus-axis` | `VERIFIED` | display/direct/imported | 3 |
| 12150–12171 | `p1:prop:v191-bw-extremal-pair` | `VERIFIED` | 12173–12181 | 7 |
| 12183–12186 | `Paper1B-remark-12183` | `FORMALIZED` | — | 0 |
| 12199–12216 | `p1:thm:v558-triality-tetrad-vector-owner` | `VERIFIED` | 12217–12223 | 3 |
| 12225–12243 | `p1:thm:v558-coordinate-pair-bivector-owner` | `VERIFIED` | 12244–12248 | 1 |
| 12250–12269 | `p1:prop:v558-antipodal-twelve-six-six` | `VERIFIED` | 12270–12274 | 0 |
| 12276–12303 | `p1:prop:v214-antipodal-six-representation-distinction` | `VERIFIED` | 12304–12319 | 13 |
| 12330–12364 | `p1:thm:v559-d4-oriented-frame-determinant-return` | `VERIFIED` | 12366–12380 | 2 |
| 12382–12396 | `p1:cor:v559-positive-central-rank3-lift` | `VERIFIED` | 12398–12402 | 1 |
| 12416–12439 | `p1:cor:v560-frame-independent-family-lift` | `VERIFIED` | 12441–12451 | 1 |
| 12453–12458 | `p1:rem:v560-cross-role-boundary` | `FORMALIZED` | — | 0 |
| 12483–12506 | `p1:thm:v561-oriented-edge-triality-support` | `VERIFIED` | 12508–12520 | 2 |
| 12522–12549 | `p1:def:v561-d4-triality-incidence-tensor` | `FORMALIZED` | — | 0 |
| 12551–12565 | `p1:cor:v561-triality-parent-norm-192` | `VERIFIED` | 12567–12574 | 1 |
| 12576–12651 | `p1:thm:v214-normalized-spin8-triality` | `VERIFIED` | 12652–12689 | 47 |
| 12691–12712 | `p1:cor:v214-tagged-signed-triality-projection` | `VERIFIED` | 12713–12720 | 1 |
| 12722–12729 | `p1:rem:v561-triality-physical-firewall` | `FORMALIZED` | — | 0 |
| 12770–12793 | `p1:thm:v562-natural-rooted-determinant-lift` | `VERIFIED` | 12795–12803 | 1 |
| 12805–12837 | `p1:thm:v562-axial-triality-trimer-identity` | `VERIFIED` | 12839–12844 | 4 |
| 12854–12861 | `p1:rem:v562-half-step-firewall` | `FORMALIZED` | — | 0 |
| 12874–12892 | `p1:thm:v563-affine-reflection-inversion` | `VERIFIED` | 12894–12904 | 3 |
| 12906–12928 | `p1:cor:v563-signline-parity-generator` | `VERIFIED` | 12930–12936 | 5 |
| 12938–12945 | `p1:rem:v563-halfstep-source-firewall` | `FORMALIZED` | — | 0 |
| 12957–12970 | `p1:def:v566-rooted-return` | `FORMALIZED` | — | 0 |
| 12972–12983 | `p1:thm:v566-rooted-return-full-family-algebra` | `VERIFIED` | 12985–12995 | 10 |
| 12997–13004 | `p1:cor:v566-return-before-scalar-readout` | `VERIFIED` | display/direct/imported | 1 |
| 13016–13029 | `p1:rem:v567-v561-support-scope` | `FORMALIZED` | — | 0 |
| 13031–13100 | `p1:thm:v567-signed-triality-channel-family` | `VERIFIED` | 13102–13151 | 12 |
| 13153–13160 | `p1:cor:v567-no-independent-channel-family-map` | `VERIFIED` | display/direct/imported | 1 |
| 13162–13167 | `p1:rem:v567-signed-triality-source-firewall` | `FORMALIZED` | — | 0 |
| 13177–13189 | `p1:lem:v242-seed-real-isometry` | `VERIFIED` | 13190–13198 | 6 |
| 13200–13224 | `p1:cor:v242-joint-phase-vector-lift` | `VERIFIED` | 13225–13233 | 4 |
| 13235–13247 | `p1:lem:v242-one-leg-nonabsorption` | `VERIFIED` | 13248–13256 | 1 |
| 13258–13279 | `p1:prop:v242-complete-transverse-return` | `VERIFIED` | 13280–13291 | 9 |
| 13294–13316 | `p1:cor:v244-quarter-turn-full-gram` | `VERIFIED` | 13317–13325 | 2 |
| 13331–13348 | `p1:rem:v242-phase-lift-scope` | `FORMALIZED` | — | 0 |

## Artifacts and next batch

- `Paper1B-ExceptionalGeometryRigorousAuditBatch5-v1_1.md` (all issues and claims), `Paper1B-ExceptionalGeometryRigorousAuditBatch5Ledger-v1_1.json` (complete source statements, proof spans, typed edge proposals and condition origins), `Paper1B-Batch5-IndependentExactControls-v1_1.json` (564 checks), `Paper1B-Batch5-IndependentChecks-v1_1.py` (reproducible exact checks).

- Next batch starts at **line 13349** with an unlabelled sharp protected total-variance theorem; the next formal claim is `p1:prop:protected-coordinate-covariance` at **line 13393**.

- The updated DAG Atlas and consolidated ProofChainAudits ZIPs remain deferred to the **final** batch. Both will be integrated from their actual supplied archives, version-incremented and validated with only required latest versions. No source TeX was edited.
