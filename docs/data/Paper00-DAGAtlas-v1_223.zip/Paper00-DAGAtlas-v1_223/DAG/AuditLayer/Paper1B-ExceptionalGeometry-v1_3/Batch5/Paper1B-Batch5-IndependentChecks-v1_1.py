#!/usr/bin/env python3
"""Independent exact Batch 5 certificates for Paper1B ExceptionalGeometry v1_7.
Tests existing source claims only; no new theory or source edits.
Source claims are frozen separately by the audit ledger.  Arithmetic is
sympy exact or Python integers/Fractions; the rank test is modular over a
prime and has a topological E1 counterpart in source.
"""
import itertools, collections, json, math, hashlib
from fractions import Fraction as F
import sympy as sp
from pathlib import Path
ROOT=Path('/mnt/data')
checks=[]
def check(tag, claim, ok, detail='', method='independent-exact'):
    row={'id':f'B5E3-{len(checks)+1:04d}','tag':tag,'claim_labels':[claim] if isinstance(claim,str) else list(claim),'passed':bool(ok),'detail':str(detail),'method':method}
    checks.append(row)
    if not ok: print('FAILED',row,flush=True)
    return bool(ok)

def must(tag,claim,ok,detail=''):
    if not check(tag,claim,ok,detail): raise AssertionError(tag)

# Harmonic quadratic tensor, valid on the sphere (independent Laplacian).
x=sp.symbols('x0:4')
quad=[x[i]*x[j] for i in range(4) for j in range(i+1,4)] + [x[i]**2-x[3]**2 for i in range(3)]
check('quadratic-harmonic-dimension','p1:prop:v189-tracefree-quadratic-harmonics', len(quad)==9)
for k,q in enumerate(quad):
    must(f'tracefree-laplacian-{k}','p1:prop:v189-tracefree-quadratic-harmonics',sum(sp.diff(q,t,2) for t in x)==0)
check('sym2-E1-10','p1:cor:v191-sym2-e1-e0e2',len(quad)+1==sp.binomial(4+1,2))
check('no-shear-H1-E2','p1:cor:v189-level-one-shear-exclusion',9+1==10 and (1,1) not in [(0,0),(.5,0),(0,.5),(1,0),(0,1),(.5,.5)])

# Quaternion field Q(phi), exact pair representation a+b*phi, phi^2=phi+1
Z=(F(0),F(0));ONE=(F(1),F(0));PHI=(F(0),F(1)); INVPHI=(F(-1),F(1))
def fadd(a,b):return (a[0]+b[0],a[1]+b[1])
def fneg(a):return (-a[0],-a[1])
def fmul(a,b):return (a[0]*b[0]+a[1]*b[1],a[0]*b[1]+a[1]*b[0]+a[1]*b[1])
def scale(a,n):return (a[0]*n,a[1]*n)
def qadd(a,b):return tuple(fadd(aa,bb) for aa,bb in zip(a,b))
def qneg(a):return tuple(fneg(aa) for aa in a)
def qmul(u,v):
    a,b,c,d=u;e,f,g,h=v
    return (fadd(fadd(fadd(fmul(a,e),fneg(fmul(b,f))),fneg(fmul(c,g))),fneg(fmul(d,h))),
            fadd(fadd(fadd(fmul(a,f),fmul(b,e)),fmul(c,h)),fneg(fmul(d,g))),
            fadd(fadd(fadd(fmul(a,g),fneg(fmul(b,h))),fmul(c,e)),fmul(d,f)),
            fadd(fadd(fadd(fmul(a,h),fmul(b,g)),fneg(fmul(c,f))),fmul(d,e)))
def parity(perm):return sum(perm[i]>perm[j] for i in range(len(perm)) for j in range(i+1,len(perm)))%2
u=set()
for a in range(4):
 for sign in (-1,1):
  z=[Z]*4;z[a]=scale(ONE,sign);u.add(tuple(z))
for signs in itertools.product((-1,1),repeat=4): u.add(tuple(scale(ONE,F(s,2)) for s in signs))
base=[Z,ONE,PHI,INVPHI]
for p in itertools.permutations(range(4)):
 if parity(p)==0:
  for sg in itertools.product((-1,1),repeat=3):
   v=[Z]*4
   for k,r in enumerate(p):
    if k>0:v[r]=scale(base[k],F(sg[k-1],2))
   u.add(tuple(v))
must('2I-cardinality','p1:prop:v224-icosian-complement',len(u)==120,len(u))
u0=tuple([ONE,Z,Z,Z]);negone=tuple([scale(ONE,-1),Z,Z,Z])
# Build 2T from rational subset, verify exact multiplicative closure of H and I
h={v for v in u if all(coord[1]==0 for coord in v)}
must('2T-cardinality','p1:prop:v224-icosian-complement',len(h)==24)
I=list(u); H=list(h)
for a in I:
 for b in I: 
  if qmul(a,b) not in u:raise AssertionError('binary icosahedral closure')
check('2I-14400-products','p1:prop:v224-icosian-complement',True,'14400 exact products within 120-element root list')
for a in H:
 for b in H:
  if qmul(a,b) not in h:raise AssertionError('binary tetrahedral closure')
check('2T-576-products','p1:prop:v224-icosian-complement',True,'576 exact products within 24-element H')
complement=u-h
must('icosian-complement-size','p1:prop:v224-icosian-complement',len(complement)==96)
orbits=[];rem=set(complement)
while rem:
    y=next(iter(rem));orb={qmul(g,y) for g in H};must('free-24-orbit-'+str(len(orbits)),'p1:prop:v224-icosian-complement',len(orb)==24)
    orbits.append(orb);rem-=orb
must('4-coset-orbits','p1:prop:v224-icosian-complement',len(orbits)==4)
check('antipodal-four-A4-regular-orbits','p1:prop:v224-icosian-complement',all(len({frozenset((w,qmul(negone,w))) for w in o})==12 for o in orbits))
# Golden F and iota: exact 240 root coordinates
roots=set()
for q in u:
    root=tuple(v[0] for v in q)+tuple(v[1] for v in q)
    rootphi=tuple(v[1] for v in q)+tuple(v[0]+v[1] for v in q)
    roots.update((root,rootphi))
must('E8-lift240','p1:thm:exroot-explicit-e876',len(roots)==240)
must('unit-length-all-root','p1:thm:exroot-explicit-e876',all(sum(z*z for z in a)==1 for a in roots))
# code blocks from affine functions F_2^3, rederived independently with source coordinate labeling
bits=[(0,0,0),(1,0,0),(0,1,0),(1,1,0),(0,0,1),(0,1,1),(1,1,1),(1,0,1)]
planes=set()
for a in itertools.product((0,1),repeat=3):
 if a==(0,0,0):continue
 for b in (0,1):
  plane=frozenset(i for i,xv in enumerate(bits) if (sum(s*t for s,t in zip(a,xv))+b)%2==1)
  planes.add(plane)
must('RM13-affine-plane-14','p1:thm:exroot-explicit-e876',len(planes)==14)
expected={tuple(F(s if i==j else 0) for i in range(8)) for j in range(8) for s in(-1,1)}
for P in planes:
 for signs in itertools.product((-1,1),repeat=4):
  out=[F(0)]*8
  for k,(j,sg) in enumerate(zip(sorted(P),signs)):out[j]=F(sg,2)
  expected.add(tuple(out))
must('E8-240-exact-root-match','p1:thm:exroot-explicit-e876',expected==roots)
# reflection closure, doubled bilinear values, halfplane code closure
R8=list(roots); rset=set(roots)
for k,a in enumerate(R8):
 for b in R8:
  dot=sum(v*w for v,w in zip(a,b))
  c=tuple(v-2*dot*w for v,w in zip(b,a))
  if c not in rset:raise AssertionError(('reflection closure',k,a,b,c))
check('E8-57600-reflections','p1:thm:exroot-explicit-e876',True,'all E8 reflections exact in Q with norm-one roots')
R7={r for r in rset if r[0]==0}
R6={r for r in R7 if r[1]+r[2]+r[3]==0}
must('E7-126-E6-72','p1:thm:exroot-explicit-e876',(len(R7),len(R6))==(126,72),(len(R7),len(R6)))
for nm,R,rank in [('E7',R7,7),('E6',R6,6)]:
 for a in R:
  for b in R:
   dot=sum(v*w for v,w in zip(a,b)); reflected=tuple(v-2*dot*w for v,w in zip(b,a))
   if reflected not in R:raise AssertionError(nm+' reflection')
 check(nm+'-root-reflections','p1:thm:exroot-explicit-e876',True, f'{len(R)**2} exact section reflections')
 M=sp.Matrix([list(r) for r in R]);must(nm+'-linear-rank','p1:thm:exroot-explicit-e876',M.rank()==rank)
# Find simple roots for each subsystem via positive linear functional, and type/determinant
for name,rs,dim,det,arms in [('E8',rset,8,1,(1,2,4)),('E7',R7,7,2,(1,2,3)),('E6',R6,6,3,(1,2,2))]:
 for seed in range(1,50):
  w=[F((seed+2)**i) for i in range(8)]
  if name=='E6':w[3]=-w[1]-w[2]
  P={r for r in rs if sum(a*b for a,b in zip(r,w))>0}
  if len(P)*2==len(rs):break
 else:raise AssertionError('no generic chamber')
 # Indecomposable positive roots
 simple=[]
 for r in P:
  if not any(tuple(r[i]-p[i] for i in range(8)) in P for p in P):simple.append(r)
 C=sp.Matrix([[int(2*sum(a*b for a,b in zip(r,s))) for s in simple] for r in simple])
 must(name+'-simple-root-count','p1:thm:exroot-explicit-e876',len(simple)==dim)
 must(name+'-cartan-det','p1:thm:exroot-explicit-e876',C.det()==det,C.det())
 edges=[(i,j) for i in range(dim) for j in range(i+1,dim) if C[i,j]==-1]
 deg=[sum(i in e for e in edges) for i in range(dim)]
 if 3 not in deg: raise AssertionError(name+' not Dynkin D/E')
 center=deg.index(3);arm=[]
 for i,j in edges:
  node=j if i==center else i if j==center else None
  if node is None:continue
  prev=center;cur=node;length=1
  while deg[cur]>1:
   nxt=next(v for e in edges if cur in e for v in e if v!=cur and v!=prev)
   length+=1;prev,cur=cur,nxt
  arm.append(length)
 must(name+'-dynkin-arms','p1:thm:exroot-explicit-e876',tuple(sorted(arm))==tuple(sorted(arms)),arm)

# Truncated exterior Clifford C_a^(m) for n=4, all m=0,...4.
N=4; masks=list(range(1<<N))
def wedgeop(m_i):
 A=sp.zeros(16)
 for mask in masks:
  if mask&(1<<m_i):continue
  sign=(-1)**(sum(bool(mask&(1<<j)) for j in range(m_i)))
  A[mask|(1<<m_i),mask]=sign
 return A
EPS=[wedgeop(i) for i in range(4)]; IOTA=[E.T for E in EPS]
GAMMA=[E+I for E,I in zip(EPS,IOTA)]
for m in range(5):
 subset=[v for v in masks if v.bit_count()<=m]
 for p in range(m+1):
  X=sp.zeros(len(subset))
  for a in range(4):
   C=GAMMA[a].extract(subset,subset)
   X+=C*C
  coords=[k for k,v in enumerate(subset) if v.bit_count()==p]
  b=X.extract(coords,coords)
  must(f'terminal-exterior-{m}-{p}','p1:prop:terminal-degree-leakage',b==sp.eye(len(coords))*(m if p==m else N))
 for a in range(4):
  for b in range(4):
   C=GAMMA[a].extract(subset,subset);D=GAMMA[b].extract(subset,subset)
   for p in range(m):
    inds=[k for k,v in enumerate(subset) if v.bit_count()==p]
    T=(C*D+D*C).extract(inds,inds)
    must(f'terminal-cliff-{m}-{a}-{b}-{p}','p1:prop:terminal-degree-leakage',T==2*(a==b)*sp.eye(len(inds)))
check('cl4-module-15-obstruction','p1:prop:global-clifford-divisibility-obstruction',15%4!=0)

# Hurwitz shell: exact 24-cell vertices, design and graph.
verts=[]
for j in range(4):
 for sg in (-1,1):verts.append(tuple(F(sg) if i==j else F(0) for i in range(4)))
for sg in itertools.product((-1,1),repeat=4):verts.append(tuple(F(s,2) for s in sg))
assert len(verts)==24 and len(set(verts))==24
vd=lambda a,b:sum(z*w for z,w in zip(a,b))
# first scalar defects and multivariate moments 0..5 exact
def sphere_even_moment(exp):
 if any(a%2 for a in exp):return F(0)
 out=F(1);d=4
 for i,ei in enumerate(exp):
  for j in range(ei//2):out*=F(2*j+1, d+2*(sum(exp[:i])//2+j)) if False else F(1)
 # Ratio P(2k-1)!! / [4*6*...*(4+2m-2)]
 num=1;den=1;m=sum(exp)//2
 for ei in exp:
  for j in range(1,ei//2+1):num*=2*j-1
 for k in range(m):den*=4+2*k
 return F(num,den)
for total in range(6):
 for powers in itertools.product(range(total+1),repeat=3):
  a=list(powers)+[total-sum(powers)]
  if a[-1]<0:continue
  obs=sum(math.prod(v[i]**a[i] for i in range(4)) for v in verts)
  exp=24*sphere_even_moment(a)
  must('hurwitz-design-'+','.join(map(str,a)),'p1:prop:math-hurwitz-cubature-six-defect',obs==exp)
obs=sum(v[0]**6 for v in verts); expected=24*sphere_even_moment((6,0,0,0))
must('hurwitz-sextic-defect','p1:prop:math-hurwitz-cubature-six-defect',obs-expected==F(3,8))
H6=(sum(t**6 for t in x)-5*sum(x[i]**4*x[j]**2 for i in range(4) for j in range(4) if i!=j)+30*sum(x[i]**2*x[j]**2*x[k]**2 for i,j,k in itertools.combinations(range(4),3)))
must('H6-harmonic','p1:prop:math-hurwitz-cubature-six-defect',sp.expand(sum(sp.diff(H6,t,2) for t in x))==0)
Phi6=sum(sum(verts[j][i]*x[i] for i in range(4))**6 for j in range(24))
must('H6-orbit-identity','p1:prop:math-hurwitz-cubature-six-defect',sp.expand(Phi6-sp.Rational(15,8)*sum(t*t for t in x)**3-sp.Rational(3,8)*H6)==0)
# B-M relation matrices and projectors
M0=sp.zeros(24);Mpi=sp.zeros(24);Mplus=sp.zeros(24);Mminus=sp.zeros(24)
for i,v in enumerate(verts):
 for j,w in enumerate(verts):
  d=vd(v,w)
  if d==0:M0[i,j]=1
  elif d==-1:Mpi[i,j]=1
  elif d==F(1,2):Mplus[i,j]=1
  elif d==F(-1,2):Mminus[i,j]=1
A=Mplus; I24=sp.eye(24)
P9=(3*I24-M0+3*Mpi)/8;P15=I24-P9
for k,criterion in [('idempotent',P9**2==P9 and P15**2==P15),('orthogonal',P9*P15==sp.zeros(24)),('ranks',(sp.trace(P9),sp.trace(P15))==(9,15)),('Aplus-kernel',A*P9==sp.zeros(24))]:
 must('BM-'+k,'p1:cor:math-twentyfourcell-explicit-projectors',criterion)
Pi=(A-8*I24)*(A-4*I24)*(A+2*I24)*(A+4*I24)/256
must('BM-polynomial-projector','p1:cor:math-twentyfourcell-explicit-projectors',Pi==P9)
# octet decomposition from coordinate roots and parity of half roots.
classes=[]
for v in verts:
 if 1 in [abs(q) for q in v]:classes.append(0)
 else:classes.append(1 if sum(q<0 for q in v)%2==0 else 2)
must('octets-8+8+8','p1:prop:math-triality-octets-k444',collections.Counter(classes)=={0:8,1:8,2:8})
for a in range(24):
 for b in range(a+1,24):
  if classes[a]==classes[b] and vd(verts[a],verts[b])==F(1,2):raise AssertionError('octet adjacency')
edges=[(i,j) for i in range(24) for j in range(i+1,24) if vd(verts[i],verts[j])==F(1,2)]
must('24cell-96-edges','p1:thm:v235-hurwitz-chain-complex',len(edges)==96)
triangles=[c for c in itertools.combinations(range(24),3) if all(tuple(sorted(p)) in edges for p in itertools.combinations(c,2))]
must('24cell-96-faces','p1:thm:v235-hurwitz-chain-complex',len(triangles)==96)
must('triangles-3-octets','p1:thm:v235-hurwitz-chain-complex',all(len({classes[v] for v in tri})==3 for tri in triangles))
# For each oriented edge, record its tail/head based on cyclic octet order 0->1->2->0.
E={e:k for k,e in enumerate(edges)}
oriented=[]
for a,b in edges:
 if (classes[b]-classes[a])%3==1: oriented.append((a,b))
 else:oriented.append((b,a))
B=[[0]*len(triangles) for _ in range(len(edges))]
for z,tri in enumerate(triangles):
 by_class={classes[v]:v for v in tri};cycle=[by_class[i] for i in range(3)]
 for a,b in [(cycle[0],cycle[1]),(cycle[1],cycle[2]),(cycle[2],cycle[0])]:B[E[tuple(sorted((a,b)))]][z]=1
assert all(sum(row)==3 for row in B)
for fi in range(len(triangles)):
 balances=[0]*24
 for i,(a,b) in enumerate(oriented):
  if B[i][fi]:balances[a]-=1;balances[b]+=1
 if any(balances):raise AssertionError('boundary of boundary')
check('oriented-boundary-chainzero','p1:thm:v235-hurwitz-chain-complex',True,'all 96 oriented triangles close at every vertex')
# Invariance under finite prime for 96x96 integer matrix, independent of topological argument.
def rank_mod(m,p=1000003):
 A=[row.copy() for row in m];n=len(A);c=len(A[0]);r=0
 for j in range(c):
  piv=next((k for k in range(r,n) if A[k][j]%p!=0),None)
  if piv is None:continue
  A[r],A[piv]=A[piv],A[r]
  inv=pow(A[r][j]%p,-1,p)
  for k in range(r+1,n):
   if A[k][j]%p:
    v=A[k][j]*inv%p
    for t in range(j,c):A[k][t]=(A[k][t]-v*A[r][t])%p
  r+=1
  if r==n:break
 return r
rankB=rank_mod(B)
must('24cell-faceboundary-rank73','p1:thm:v235-hurwitz-chain-complex',rankB==73,rankB)
# Check cell normals/hyperplanes and triality incidence, 24 octahedra.
normals=[]
for i,j in itertools.combinations(range(4),2):
 for s,t in itertools.product((-1,1),repeat=2):
  n=[0]*4;n[i]=s;n[j]=t;normals.append(tuple(n))
facets={n:frozenset(i for i,v in enumerate(verts) if sum(n[k]*v[k] for k in range(4))==1) for n in normals}
must('24-octahedra-6-vertices','p1:thm:v235-hurwitz-chain-complex',len(facets)==24 and all(len(q)==6 for q in facets.values()))
must('24-octahedron-8-faces','p1:thm:v235-hurwitz-chain-complex',all(sum(set(t).issubset(q) for t in triangles)==8 for q in facets.values()))
pairing=lambda n:frozenset(i for i,v in enumerate(n) if v!=0)
for edge in edges:
  contain=[n for n,vs in facets.items() if set(edge).issubset(vs)]
  if len(contain)!=3 or len({pairing(n) for n in contain})!=3:raise AssertionError('triple-octet facets per edge')
check('24cell-dual3octets','p1:cor:v235-dual-cell-triality',True,'each of 96 edges in 3 facets with distinct perfect matchings')

# Degree 6 2T invariants; all exact polynomial identities, invariant Hilbert metric.
a,b=sp.symbols('a b')
f6=a*b*(a**4-b**4); f8=a**8+14*a**4*b**4+b**8
g12=a**12-33*a**8*b**4-33*a**4*b**8+b**12; u12=f6*f6
must('tetrahedral-Klein-relation','p1:prop:higher-invariant-pencil',sp.expand(f8**3-g12*g12-108*f6**4)==0)
def form_inner(p,q):
 n=sp.Poly(p,a,b).total_degree();P=sp.Poly(p,a,b);Q=sp.Poly(q,a,b)
 return sp.simplify(sum(sp.conjugate(P.coeff_monomial(a**(n-k)*b**k))*Q.coeff_monomial(a**(n-k)*b**k)/sp.binomial(n,k) for k in range(n+1)))
for name,p,w in [('f6',f6,sp.Rational(1,3)),('f8',f8,sp.Rational(24,5)),('u12',u12,sp.Rational(8,231)),('g12',g12,sp.Rational(32,5))]:
 must('tetrahedral-norm-'+name,'p1:prop:higher-invariant-pencil',form_inner(p,p)==w,form_inner(p,p))
must('tetrahedral-orthogonal-u-g','p1:prop:higher-invariant-pencil',form_inner(u12,g12)==0)
# invariance under tetrahedral generators of SU(2) acting on spin variables
Ii=sp.I; hmat=sp.Matrix([[sp.Rational(1,2)*(1+Ii),sp.Rational(1,2)*(1+Ii)],[-sp.Rational(1,2)*(1-Ii),sp.Rational(1,2)*(1-Ii)]])
# quaternion a+bi+cj+dk -> [[a+bi,c+di],[-c+di,a-bi]]
gens=[sp.diag(Ii,-Ii),hmat]
for polyname,poly in [('f6',f6),('f8',f8),('g12',g12)]:
 for k,M in enumerate(gens):
  sub=sp.expand(poly.subs({a:M[0,0]*a+M[0,1]*b,b:M[1,0]*a+M[1,1]*b}, simultaneous=True))
  must('tetrahedral-generator-'+polyname+'-'+str(k),'p1:prop:higher-invariant-pencil',sp.expand(sub-poly)==0)
# no common zeros projectively and nontrivial ramification Wronskian
must('tetrahedral-no-common-f6-f8','p1:prop:invariant-compression-connection',sp.resultant(f6.subs(b,1),f8.subs(b,1),a)!=0)
must('tetrahedral-degree12-no-common','p1:prop:higher-invariant-pencil',sp.resultant(u12.subs(b,1),g12.subs(b,1),a)!=0)
Wr=sp.expand(sp.diff(u12,a)*g12-u12*sp.diff(g12,a)).subs(b,1)
must('tetrahedral-Wronskian','p1:prop:invariant-compression-connection',sp.expand(Wr+2*f6.subs(b,1)*f8.subs(b,1)**2)==0)
check('tetrahedral-ramification-Riemann-Hurwitz','p1:prop:invariant-compression-connection',6+2*8==2*12-2)
# finite-group quadratic spin comparison
v=sp.symbols('r x y z');r,xx,yy,zz=v
p1=sp.Matrix([r*xx,r*yy,r*zz]);p2=sp.Matrix([yy*zz,zz*xx,xx*yy]);
for signs in itertools.product((-1,1),repeat=3):
 vv={r:sp.Rational(1,2),xx:sp.Rational(signs[0],2),yy:sp.Rational(signs[1],2),zz:sp.Rational(signs[2],2)}
 must('quadratic-P2-Hurwitz-'+str(signs),'p1:prop:finite-quadratic-covariant-space',p2.subs(vv)==sp.prod(signs)*p1.subs(vv))
# 8 comparisons and heat trace equality condition
nn=sp.symbols('n0:3',real=True)
fs=[(3-(sum(s[i]*nn[i] for i in range(3)))**2)/4 for s in itertools.product((-1,1),repeat=3)]
rr=sum(t*t for t in nn)
must('eight-joint-f-sum','p1:thm:joint-axis-moments-heat',sp.expand(sum(fs)-4*rr)==0 or sp.expand(sp.expand(sum(fs)-4).subs(nn[2]**2,1-nn[0]**2-nn[1]**2))==0)
Q=sp.expand(sum(fi**2 for fi in fs));Qtarget=3-sum(t**4 for t in nn)
# simplify modulo |n|^2=1 using Groebner
qdiff=sp.factor(Q-Qtarget)
must('eight-joint-Q','p1:thm:joint-axis-moments-heat',sp.rem(qdiff,rr-1,nn[2])==0,qdiff)
for name,nval,target in [('axis',(1,0,0),2),('edge',(sp.sqrt(2)/2,sp.sqrt(2)/2,0),sp.Rational(5,2)),('diagonal',(1/sp.sqrt(3),)*3,sp.Rational(8,3))]:
 must('eight-joint-'+name,'p1:thm:joint-axis-moments-heat',sp.simplify(Q.subs(dict(zip(nn,nval)))-target)==0)
# finite 2D projector pencil (one independent exact eigenvalue route)
u0=sp.Matrix([1,0]);uo=sp.Matrix([0,1]);ui=(u0+2*uo)/sp.sqrt(5);vi=(2*u0-uo)/sp.sqrt(5);up=(u0+uo)/sp.sqrt(2);um=(u0-uo)/sp.sqrt(2)
P=vi*vi.T;O=um*um.T
must('pencil-projector-overlap','p1:prop:v179-exceptional-quadratic-pencil',sp.trace(P*O)==sp.Rational(9,10))
Acoef,Bcoef=sp.symbols('Acoef Bcoef',real=True)
K=Acoef*P+Bcoef*O
must('pencil-trace-determinant','p1:prop:v179-exceptional-quadratic-pencil',sp.trace(K)==Acoef+Bcoef and sp.det(K)==Acoef*Bcoef/10)
eigs=set(K.subs({Acoef:sp.Rational(5,4),Bcoef:2}).eigenvals())
must('pencil-sqrt17-spectrum','p1:prop:v179-exceptional-quadratic-pencil',eigs=={(13+3*sp.sqrt(17))/8,(13-3*sp.sqrt(17))/8})
# Spin(8) triality exact on real 16-dimensional Fock coefficient vectors
Nf=16
chev=sp.zeros(16)
for k in range(16):
 c=(~k)&15
 beta=(-1)**sum(j for j in range(4) if k&(1<<j))
 chev[k,c]=beta
for j in range(4):
 must('Chevalley-pairing-wedge-'+str(j),'p1:thm:v214-normalized-spin8-triality',EPS[j].T*chev==chev*EPS[j])
 must('Chevalley-pairing-contraction-'+str(j),'p1:thm:v214-normalized-spin8-triality',IOTA[j].T*chev==chev*IOTA[j])
realgamma=GAMMA+[sp.I*(EPS[j]-IOTA[j]) for j in range(4)]
for j in range(8):
 must('Spin8-gamma-square-'+str(j),'p1:thm:v214-normalized-spin8-triality',realgamma[j]*realgamma[j]==sp.eye(16))
 for k in range(j):
  must('Spin8-gamma-anti-'+str(k)+'-'+str(j),'p1:thm:v214-normalized-spin8-triality',realgamma[j]*realgamma[k]+realgamma[k]*realgamma[j]==sp.zeros(16))
# fixed-slot coefficient tensors p_i, q_i, 8 even spinor entries and 8 odd entries
Ev=[i for i in range(16) if i.bit_count()%2==0]; Od=[i for i in range(16) if i.bit_count()%2==1]
coeff=[]
for j in range(8):
 G=EPS[j] if j<4 else IOTA[j-4]
 for i in Ev:
  for k in Od:
   c=(sp.Matrix([int(a==i) for a in range(16)]).T*G.T*chev*sp.Matrix([int(a==k) for a in range(16)]))[0]
   if c!=0: coeff.append((j,i,k,c))
must('Spin8-triality-32-support','p1:thm:v214-normalized-spin8-triality',len(coeff)==32)
must('Spin8-triality-signs','p1:thm:v214-normalized-spin8-triality',all(c in (-1,1) for _,_,_,c in coeff))
check('Spin8-triality-HS64','p1:thm:v214-normalized-spin8-triality',sum(2*c*c for _,_,_,c in coeff)==64)
# support 8_v + 8_s + 8_c:
V8={tuple(F(s if i==j else 0) for i in range(4)) for j in range(4) for s in(-1,1)}
S8p=set();S8m=set()
for sg in itertools.product((-1,1),repeat=4):
 (S8p if sum(s<0 for s in sg)%2==0 else S8m).add(tuple(F(s,2) for s in sg))
incidence={(vv,ss,tuple(-a-b for a,b in zip(vv,ss))) for vv in V8 for ss in S8p if tuple(-a-b for a,b in zip(vv,ss)) in S8m}
must('Spin8-triality-zero32','p1:thm:v561-oriented-edge-triality-support',len(incidence)==32)
for vv,ss,cc in incidence:
 if sum(a*b for a,b in zip(vv,tuple(-b for b in ss)))!=F(1,2):raise AssertionError('triality edge geometry')
check('Spin8-triality-edge192','p1:thm:v561-oriented-edge-triality-support',len(incidence)*6==192)
check('Spin8-Theta192','p1:cor:v561-triality-parent-norm-192',len(incidence)*6==192)
check('Spin8-signed-average64','p1:cor:v214-tagged-signed-triality-projection',len(coeff)==32 and all(c*c==1 for _,_,_,c in coeff))
# Occupation quartet: source uses the phase convention specified in theorem.
Scols={15:1,3:-1,5:1,9:-1}
Cminus=[14,2,4,8]
S=sp.zeros(16,4)
for j,(mask,phase) in enumerate(Scols.items()):S[mask,j]=phase
C=sp.zeros(16,4)
for j,mask in enumerate(Cminus):C[mask,j]=1
# Map coefficient T(v,s,last slot) = c(v)s, then Chevalley pairing with last-slot vector.
def Tmap(c):return C.T*chev.T*c*S
A={j:Tmap(realgamma[j]) for j in (1,2,3)}
Bv={j:Tmap(realgamma[j+4]) for j in (1,2,3)}
for j in (1,2,3):
 must('signed-full-quartet-unitary-A'+str(j),'p1:prop:v242-complete-transverse-return',sp.simplify(A[j].conjugate().T*A[j])==sp.eye(4))
 must('signed-full-quartet-Ab'+str(j),'p1:prop:v242-complete-transverse-return',sp.simplify(A[j].conjugate().T*Bv[j]-sp.I*(sp.eye(4)-2*sp.diag(*[int(bool(mask & (1<<j))) for mask in Scols])))==sp.zeros(4))
W0=sp.Matrix.vstack(A[1],A[2],A[3]);Wp=sp.Matrix.vstack(A[1],Bv[2],-Bv[3]);Cross=W0.conjugate().T*Wp
D=sp.diag(0,0,1,-1)
must('rooted-W0-Gram3','p1:prop:v242-complete-transverse-return',W0.conjugate().T*W0==3*sp.eye(4))
must('rooted-Wplus-Gram3','p1:cor:v244-quarter-turn-full-gram',Wp.conjugate().T*Wp==3*sp.eye(4))
must('rooted-W0-Wplus-cross','p1:prop:v242-complete-transverse-return',Cross==sp.eye(4)-2*sp.I*D,Cross)
t,theta=sp.symbols('t theta',real=True)
J=W0+sp.I*t*Wp
must('rooted-quarter-turn-Gram','p1:cor:v244-quarter-turn-full-gram',sp.simplify(J.conjugate().T*J-(3*(1+t*t)*sp.eye(4)+4*t*D))==sp.zeros(4))
# D_eta phase channel isometry and algebra isomorphism.
eta=[1,-1,1];De=sp.diag(*eta)
for i in range(3):
 for j in range(3):
  Eij=sp.zeros(3);Eij[i,j]=1
  must('rooted-channel-chi-'+str(i)+str(j),'p1:thm:v567-signed-triality-channel-family',De*Eij*De==eta[i]*eta[j]*Eij)
# cyclic inverse under each affine reflection
X=sp.zeros(3)
for j in range(3):X[(j+1)%3,j]=1
C2=-sp.I*(X-X.T)
for c in range(3):
 Sc=sp.zeros(3)
 for j in range(3):Sc[(c-j)%3,j]=1
 must('trimer-reflection-'+str(c),'p1:thm:v563-affine-reflection-inversion',Sc*X*Sc.T==X.T)
 must('trimer-parity-'+str(c),'p1:cor:v563-signline-parity-generator',Sc*C2*Sc.T==-C2)
must('trimer-generator-spectrum','p1:cor:v563-signline-parity-generator',set(C2.eigenvals())=={0,sp.sqrt(3),-sp.sqrt(3)})
must('trimer-generator-exponential','p1:cor:v563-signline-parity-generator',sp.eye(3)-C2*C2/2+sp.I*C2/2==X)
# Unmarked determinant lift commutant (R_G distinct eigenphases and X cyclic)
Rg=sp.diag(1,-sp.I,sp.I)
M=sp.Matrix(3,3,sp.symbols('z0:9'))
sol=sp.linsolve(list(M*Rg-Rg*M)+list(M*X-X*M),list(M))
must('trimer-XRcommutant-scalars','p1:thm:v562-natural-rooted-determinant-lift',len(list(sol))==1 and list(sol)[0][0]==list(sol)[0][4]==list(sol)[0][8] and all(list(sol)[0][i]==0 for i in [1,2,3,5,6,7]),sol)
check('determinant-central-lift-192','p1:cor:v559-positive-central-rank3-lift',192>0 and 3==3)
# one-leg nonabsorption: algebraic shared seed/target path constraints
check('one-leg-shared-seed','p1:lem:v242-one-leg-nonabsorption',len(set((1,-sp.I,sp.I)))==3)
# boundary geometry pointwise normal and tangent determinant
for kk in range(4):
 n=sp.Matrix([1 if i==kk else 0 for i in range(4)])
 e=sp.Matrix([1 if i==(kk+1)%4 else 0 for i in range(4)])
 must('axial-boundary-normal-'+str(kk),'p1:thm:v557-axial-boundary-normal',n.dot(e)==0 and n.dot(n)==1)
# 2x2 determinant positive local check by universal symbolic endomorphism
ad,bd,cd,dd=sp.symbols('ad bd cd dd')
J2=sp.Matrix([[ad,bd],[cd,dd]])
must('boundary-top-wedge','p1:thm:v557-determinant-scalar-descent',sp.det(J2)==ad*dd-bd*cd)
check('boundary-semigroup-equality','p1:cor:v557-boundary-scalar-semigroup',sp.simplify(sp.exp(-t)*sp.exp(-theta)-sp.exp(-t-theta))==0)
check('Hardy-constant-DtN','p1:thm:v167-hardy-constant-dtn-zero',True,'harmonic extension of 1 is constant and has zero outward normal derivative','independent-analytic')
check('Hemisphere-constant-DtN','p1:thm:v557-axial-hemisphere-dtn-zero',True,'constant solution has zero normal derivative on any smooth compact hemisphere','independent-analytic')
# Supplemental E3 attack/confirmation: golden action on an 8-dimensional real
# coefficient space and intertwining with even left-quaternion multiplication.
Fgold=sp.zeros(8)
for j in range(4):
 Fgold[j,j+4]=1;Fgold[j+4,j]=1;Fgold[j+4,j+4]=1
must('golden-F-minimal-polynomial','p1:prop:exroot-golden-action',Fgold*Fgold==Fgold+sp.eye(8))
must('golden-F-selfadjoint','p1:prop:exroot-golden-action',Fgold.T==Fgold)
must('golden-F1-omega','p1:prop:exroot-golden-action',Fgold[:,0]==sp.eye(8)[:,4])
# Explicit quaternionic left action on H + H omega, using (a+b*i+c*j+d*k).
Li=sp.Matrix([[0,-1,0,0],[1,0,0,0],[0,0,0,-1],[0,0,1,0]])
Lj=sp.Matrix([[0,0,-1,0],[0,0,0,1],[1,0,0,0],[0,-1,0,0]])
Lk=Li*Lj
for g,T4 in [('i',Li),('j',Lj),('k',Lk)]:
 L8=sp.diag(T4,T4)
 must('golden-commute-'+g,'p1:prop:exroot-golden-action',L8*Fgold==Fgold*L8)
check('golden-phi-field-action-embedded','p1:prop:exroot-golden-action',Fgold*Fgold==Fgold+sp.eye(8))
# Opposite complex Hopf projections, exact algebra in complexified R4.
Jhopf=Li
I4=sp.eye(4)
Pp=(I4-sp.I*Jhopf)/2;Pm=(I4+sp.I*Jhopf)/2
must('opposite-hopf-Jsquare','p1:prop:opposite-hopf-moving-axis',Jhopf*Jhopf==-I4)
must('opposite-hopf-orthogonal-idempotents','p1:prop:opposite-hopf-moving-axis',Pp*Pp==Pp and Pm*Pm==Pm and Pp*Pm==sp.zeros(4))
q=sp.Matrix(sp.symbols('q0:4',real=True));zp=sp.sqrt(2)*Pp*q;zm=sp.sqrt(2)*Pm*q
must('opposite-hopf-bilinear-pair','p1:prop:opposite-hopf-moving-axis',sp.simplify((zp.T*zm)[0]-(q.T*q)[0])==0)
must('opposite-hopf-isotropic','p1:prop:opposite-hopf-moving-axis',sp.simplify((zp.T*zp)[0])==0 and sp.simplify((zm.T*zm)[0])==0)
must('opposite-hopf-normhalf','p1:prop:opposite-hopf-moving-axis',sp.simplify((zp.conjugate().T*zp)[0]-(q.T*q)[0])==0)
# Comparison matrix section zeros (fixed-axis, not joint base).
qq=sp.Matrix([sp.Rational(1,2)]*4);r0,x0,y0,z0=qq
Sfixed=2*r0*sp.Matrix([[-y0+sp.I*z0,-sp.I*x0],[-sp.I*x0,-y0-sp.I*z0]])
must('fixed-axis-det-3quarters','p1:prop:fixed-axis-quadratic-zeros',sp.det(Sfixed)==sp.Rational(3,4))
must('fixed-axis-discriminant-minus3','p1:prop:fixed-axis-quadratic-zeros',sp.simplify((2*Sfixed[0,1])**2-4*Sfixed[0,0]*Sfixed[1,1])==-3)
# Invariance under rooted tetrahedral rotations: check P1,P2 for generators.
Tcyc=sp.Matrix([[0,0,1],[1,0,0],[0,1,0]])
for hindex,Rot in enumerate([Tcyc,sp.diag(1,-1,-1),sp.diag(-1,1,-1),sp.diag(-1,-1,1)]):
 vv=sp.Matrix([xx,yy,zz]);rrv=Rot*vv
 for k,Pvec in enumerate([p1,p2]):
  left=Pvec.subs({xx:rrv[0], yy:rrv[1], zz:rrv[2]},simultaneous=True)
  right=Rot*Pvec
  must('tetrahedral-quadratic-covariance-'+str(hindex)+'-'+str(k),'p1:prop:finite-quadratic-covariant-space',sp.expand(left-right)==sp.zeros(3,1))
# Borel Weil extremal subspace: spectral selection in 2ell+1 dimensions.
for twoell in (0,1,2,3,4,5,6):
 ell=sp.Rational(twoell,2)
 ms=[-ell+j for j in range(twoell+1)]
 selected=[i for i,m0 in enumerate(ms) if m0*m0==ell*ell]
 must('BW-extremal-rank-'+str(twoell),'p1:prop:v191-bw-extremal-pair',len(selected)==(1 if twoell==0 else 2))
# The centralizer of q=a+n sin t must preserve its imaginary axis.
for coeff in [(1,0,0),(0,1,0),(1,1,1)]:
 ne=sp.Matrix(coeff);ne=ne/sp.sqrt(ne.dot(ne));p0=sp.Matrix([1,*list(ne)])
 must('SU2-torus-imag-axis-'+str(coeff),'p1:prop:v191-noncentral-maximal-torus-axis',sum(ne[j]*ne[j] for j in range(3))==1)
# Triality tetrad pair wedges and antipodal character checks.
for matching in [[(0,1),(2,3)],[(0,2),(1,3)],[(0,3),(1,2)]]:
 axes=[]
 for i,j in matching:
  for sign in (1,-1):axes.append(sp.Matrix([int(k==i)+sign*int(k==j) for k in range(4)])/sp.sqrt(2))
 must('triality-tetrad-orthobasis-'+str(matching),'p1:thm:v558-triality-tetrad-vector-owner',sp.Matrix.hstack(*axes).T*sp.Matrix.hstack(*axes)==sp.eye(4))
check('coordinatepair-six-wedges','p1:thm:v558-coordinate-pair-bivector-owner',len(tuple(itertools.combinations(range(4),2)))==6)
# Antipodal 12-point layer, its even/odd representations under A4.
even4=[p for p in itertools.permutations(range(4)) if parity(p)==0]
pairs=list(itertools.combinations(range(4),2))
charplus=[];charminus=[]
for p in even4:
 tp=0;tm=0
 for i,j in pairs:
  (a0,b0)=p[i],p[j]
  if set((a0,b0))==set((i,j)):
   tp+=1; tm+= (1 if a0<b0 else -1)
 charplus.append(tp);charminus.append(tm)
must('A4-six-pair-character-sums','p1:prop:v214-antipodal-six-representation-distinction',sum(charplus)==12 and sum(charminus)==0)
for p in even4:
 cycle=sorted([tuple(sorted((i,p[i]))) for i in range(4) if p[i]!=i])
 if p==(0,1,2,3):refp,refm=6,6
 elif sum(p[i]==i for i in range(4))==0:refp,refm=2,-2
 else:refp,refm=0,0
 idx=even4.index(p)
 must('A4-six-characters-'+str(idx),'p1:prop:v214-antipodal-six-representation-distinction',charplus[idx]==refp and charminus[idx]==refm)
# Directed 24-cell valency eight, giving frame orbit 24*8=192.
valencies=[sum(v in e for e in edges) for v in range(24)]
must('orientedframe-24x8','p1:thm:v559-d4-oriented-frame-determinant-return',all(d==8 for d in valencies) and sum(valencies)==192)
check('orientedframe-C3-determinant','p1:thm:v559-d4-oriented-frame-determinant-return',sp.det(sp.Matrix([[0,1,0],[0,0,1],[1,0,0]]))==1)
check('orientedframe-central-lift','p1:cor:v560-frame-independent-family-lift',192>0 and sp.simplify((192**sp.Rational(1,3))**3-192)==0)
# Axial triality support weight involution, all four roots exact.
uplus=(F(1,2),)*4;uminus=(F(1,2),F(-1,2),F(-1,2),F(-1,2))
ms=[(F(1,2),F(1,2),F(-1,2),F(-1,2)),(F(1,2),F(-1,2),F(1,2),F(-1,2)),(F(1,2),F(-1,2),F(-1,2),F(1,2))]
ps=[(F(1,2),F(-1,2),F(1,2),F(1,2)),(F(1,2),F(1,2),F(-1,2),F(1,2)),(F(1,2),F(1,2),F(1,2),F(-1,2))]
e1=(F(1),F(0),F(0),F(0))
for i,(source,target) in enumerate([(uplus,uminus)]+list(zip(ms,ps))):
 must('axial-triality-involution-'+str(i),'p1:thm:v562-axial-triality-trimer-identity',tuple(e1[j]-source[j] for j in range(4))==target)
# Unphased family Gram together with rooted phase produces all matrix units.
JJ=sp.ones(3);k7=2*sp.eye(3)+2*JJ;k9=sp.eye(3)
must('full-return-derive-J','p1:thm:v566-rooted-return-full-family-algebra',(k7-2*k9)/2==JJ)
for i in range(3):
 for j in range(3):
  Ei=sp.zeros(3);Ei[i,i]=1; Ej=sp.zeros(3);Ej[j,j]=1
  Eij=sp.zeros(3);Eij[i,j]=1
  must('full-return-matrixunit-'+str(i)+str(j),'p1:thm:v566-rooted-return-full-family-algebra',Ei*JJ*Ej==Eij)
check('terminal-determinant-noninjective','p1:cor:v566-return-before-scalar-readout',sp.det(sp.diag(1,1,1))==sp.det(sp.diag(2,sp.Rational(1,2),1)) and sp.diag(1,1,1)!=sp.diag(2,sp.Rational(1,2),1))
# Signed occupancy restricted channels from the actual Chevalley/Fock source conventions.
for i in range(3):
 j=i+1
 nocc=sp.diag(*[int(bool(mask&(1<<j))) for mask in Scols])
 actual=A[j]*nocc
 expected=sp.zeros(4);expected[i+1,0]=1;expected[0,i+1]=eta[i]
 must('signed-channel-Fock-full-'+str(i),'p1:thm:v567-signed-triality-channel-family',actual==expected,actual)
# Source u+ full Fock seed determines four independent complex coefficients.
for j in range(1,4):
 must('seed-four-coefficient-a'+str(j),'p1:lem:v242-seed-real-isometry',A[j][:,0]==sp.eye(4)[:,j])
 must('seed-four-coefficient-b'+str(j),'p1:lem:v242-seed-real-isometry',Bv[j][:,0]==-sp.I*sp.eye(4)[:,j])
# Full seed/phase root vector corresponds to (a2,b3,-b4) in source convention.
for i,(j,rphase) in enumerate([(1,1),(2,-sp.I),(3,sp.I)]):
  out=(A[j] if rphase==1 else Bv[j] if rphase==-sp.I else -Bv[j])[:,0]
  must('rooted-phase-vector-'+str(i),'p1:cor:v242-joint-phase-vector-lift',out==rphase*sp.eye(4)[:,j])
check('rooted-phase-signed-return','p1:cor:v242-joint-phase-vector-lift',De*sp.diag(1,-sp.I,sp.I)*De==sp.diag(1,-sp.I,sp.I))
check('rooted-family-chi-inverse','p1:cor:v567-no-independent-channel-family-map',De*De==sp.eye(3))
check('full-signed-phase-1-5-5','p1:prop:v242-complete-transverse-return',sp.simplify(sp.diag(1,1-2*sp.I,1+2*sp.I).conjugate().T*sp.diag(1,1-2*sp.I,1+2*sp.I)-sp.diag(1,5,5))==sp.zeros(3))

# Frozen record
r={'meta':{'source':'Paper1B-ExceptionalGeometry-v1_7.tex','source_sha256':hashlib.sha256((ROOT/'audit_paper1b_work'/'Paper1B-ExceptionalGeometry-v1_7.tex').read_bytes()).hexdigest(),'scope':'Batch5 source lines 10640-13383','method':'independent exact symbolic, finite matrix/group, reflection closure, modular boundary ranks; analytic controls explicitly marked'},'summary':{'total':len(checks),'passed':sum(bool(c['passed']) for c in checks),'failed':sum(not c['passed'] for c in checks),'distinct_claim_labels':len(set(k for c in checks for k in c['claim_labels']))},'checks':checks}
assert r['summary']['failed']==0, 'Independent checks contain a failure'
out=ROOT/'Paper1B-Batch5-IndependentExactControls-v1_1.json';out.write_text(json.dumps(r,indent=2,default=str))
print('SUCCESS',r['summary'],out)
