# Paper I-B — Closure derivations, Batch 1 (standalone; no framework update)

**Source freeze.** The newest provided authoritative source is `Paper1B-ExceptionalGeometry-v1_8.tex` in `Paper00-PapersMinimal-v3_014(1).zip`, 19,581 lines. The previous completed proof-chain audit addressed v1.7 (19,479 lines). The new v1.8 section adds a Born-even octahedral-response theorem, a sixfold-normalizer proposition, and a scope remark; these are **not** certified by the previous v1.7 audit. This batch focuses exclusively on the pre-existing fivefold contrast and its direct downstream reference, not on the new section.

## Target and source chain

- **Target:** `p1:prop:v343-fivefold-signed-contrast`, source v1.8 around lines 15507–15550, currently prints `\Phi L_W\Phi^{-1}=+\frac{15}{4\sqrt5}D_5` with `L_W=K_W/(4\sqrt5)`.
- **Input:** `p1:thm:v342-class-frame-three-cycle-tomography`, lines 15392–15451, defines `Z_g`, class frame `\mathcal A_C=\sum |Z_g/\sqrt{15}\rangle\langle Z_g/\sqrt{15}|`, and `D_5=\mathcal A_{5A}-\mathcal A_{5B}`.
- **Representation bridge:** `p1:thm:v339-petersen-sl4-isometry` identifies the signed-edge 15-module and real traceless 4x4 matrix carrier under conjugation.
- **Direct consumer:** Paper I-C `p1b:thm:v343-doubleodd-contrast`, lines 24959–25009 in `Paper1C-M8Geometry-v1_138.tex`, imports the contrast in **both** reciprocal factors.

## Independent all-integer calculation

Work in the 5-permutation model of `A_5` and let `P_g` be its 5x5 permutation matrix, `J` the all-ones matrix, `Q=I-J/5`, and `\chi_4(g)=\operatorname{tr}P_g-1`. The source-defined trace-free coefficient is

\[
Z_g=QP_gQ-\frac{\chi_4(g)}4Q
=\frac1{20}\bigl(20P_g+(\chi_4(g)-4)J-5\chi_4(g)I\bigr)=R_g/20.
\]

Enumerate all 60 even permutations. One 5-cycle conjugacy orbit under `A_5` contains 12 elements, and the other 12 five-cycles form the opposite orbit. Define integer 25x25 matrices on the row-vectorized 5x5 endomorphism space:

\[
K=\sum_{g\in5A}(P_g\otimes P_g)-\sum_{g\in5B}(P_g\otimes P_g),\qquad
N=\sum_{g\in5A}\operatorname{vec}(R_g)\operatorname{vec}(R_g)^T-\sum_{g\in5B}\operatorname{vec}(R_g)\operatorname{vec}(R_g)^T.
\]

Here `K` is the class-sum **conjugation** operator, and `D_5=N/6000`. Entrywise integer comparison gives

\[
\boxed{400K+N=0}\qquad\Longrightarrow\qquad
\boxed{K=-15D_5},\quad
\boxed{\Phi L_W\Phi^{-1}=-\frac{15}{4\sqrt5}D_5}.
\]

Further exact controls: `K^3=80K`, `rank(K)=rank(N)=6`, `tr(K²)=480`, `tr(KD_5)=-32`, and `tr(D_5²)=32/15`. The positive-sign formula requires `tr(KD_5)=+32` and therefore **fails**. This conclusion is unchanged by interchanging the two class names globally (both operators change sign). The matrix calculation uses *the actual source definitions*, not a sign convention inferred from representation names.

## Verdict and impact

**GENUINE SOURCE-LEVEL SIGN ERROR — exact correction derived.** The existing theorem's underlying support, ranks, cubics and projector squares survive; only the relative sign connecting the fixed class sum and the fixed class frame must change. This is a mathematical formula correction, not a new axiom or a physical claim. Until an authorized source edit, the printed identity in v1.8 remains incorrect.

Paper I-C's double-odd theorem writes `\mathcal C_{xp}=L_x\otimes L_p=(45/16)(\Phi_x^{-1}D_{5,x}\Phi_x)\otimes(\Phi_p^{-1}D_{5,p}\Phi_p)`; **both** single-factor changes contribute minus signs, so the displayed *two-factor* positive coefficient remains valid. Any proposed *single-factor* `L\leftrightarrow D_5` identification requires correction; do not broadly downgrade unrelated spectral or physical claims.

## Batch reproducibility

- Executable self-contained certificate: `Paper1B-FivecycleSignExactChecks-v1_1.py`.
- Machine-readable exact controls: `Paper1B-FivecycleSignExactControls-v1_1.json`.
- The exact equality `400K+N=0` was tested over integers, without floating-point tolerance.

## Pending subsequent closure batches

1. Verify the three **new v1.8** formal statements (octahedral quartic response, `2O` coset, sixfold normalizer) against exact group and harmonic algebra.
2. Independently certify the **specific five-core off-diagonal decomposition** in `p1:prop:v366-register-mirror-contrast` rather than only the aggregate `K(Q)` identity and mirror commutator ranks previously reported.
3. Reconcile other previously reported chamber and spinorial certificates with the newest v1.8 source and produce a fully certified closure ledger **before** any framework/DAG/audit archive update.

**Archive edit status:** none. No paper, DAG, proof-chain audit, or ZIP has been modified in this batch.
