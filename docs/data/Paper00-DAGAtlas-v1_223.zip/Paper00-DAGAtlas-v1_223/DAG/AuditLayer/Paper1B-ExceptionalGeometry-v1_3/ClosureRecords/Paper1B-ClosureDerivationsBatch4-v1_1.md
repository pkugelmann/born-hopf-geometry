# Paper I-B — Closure derivations, Batch 4 (standalone, before integration)

**Authoritative source (READ ONLY):** `Paper1B-ExceptionalGeometry-v1_8.tex` in `Paper00-PapersMinimal-v3_014(1).zip`, SHA-256 `a03b4db5014afb21824ef58bd5931d1d943eee6f8defc24b77017ebd8dd4f4d5`.

**Protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4(1).md`, specifically its E1/E3/E4 and exact source-condition rules. **Target claims:** `p1:thm:v345-f40-edge-regular` (at line 15711, *conditional input to this batch*), `p1:thm:v349-f40-minimal-quintet` (at line 15844), `p1:prop:v349-f40-reduced-frame` (representation/invariant-form clauses), `p1:thm:v349-twisted25-spin2-lift` (at line 15947), and `p1:thm:v349-twisted25-vertex-defect` (at line 15991). Relevant existing issue root: `BH-IBX-EV-0010`, originally a mixed missing-evidence root for several F40 representation/mirror/vertex calculations.

**Status:** **REPRESENTATION-LEVEL SUBCLAIMS CLOSED**, **F40 geometric edge-label bijection remains a separately typed antecedent**, **no source/framework/DAG/archive updates**. The cubic/quartic continuum integrals follow from standard normalized `SU(2)` matrix-coefficient identities; this batch independently derives their spectral *defect ranks*, the specific new target. It does not certify a physical tensor coupling.

## 1. Reconstruct the real 21-dimensional F40 cycle character

The source's finite construction identifies its 60 oriented edges as the `A_5`-set `C_{5A} \times {1,...,5}`, with action `a:(g,i)\mapsto(aga^{-1},a i)`; its 40 vertices form **two 20-point `A_5/C_3` orbits**. These identifications are the **stated hypotheses/earlier geometric construction**, *not* consequences of bare character theory. The independent certificate constructs all 60 even permutations, all five conjugacy classes, a 12-member five-cycle class, its 60 edge-label pairs, and all 20 `C_3` cosets, without importing source character counts.

- Every nonidentity group element fixes **zero** of the 60 edge labels; identity fixes 60. Thus `\chi_E=(60,0,0,0,0)`.
- The two 20-point vertex orbits together have character `\chi_V=(40,0,4,0,0)`: a three-cycle fixes two cosets per orbit, other nonidentity classes fix none.
- For a connected oriented graph, the exact sequence `0 -> Z_40 -> R^E -> R^V -> R -> 0` gives

\[
\boxed{\chi_{\mathcal Z}=\chi_E-\chi_V+\mathbf1=(21,1,-3,1,1)}
\]

on `A_5` classes `(1,2A,3A,5A,5B)` of sizes `(1,15,20,12,12)`. The 21-dimensional cycle count and connectedness were also checked geometrically in the previous source audit, but this calculation independently reproduces their **equivariant character**. It is **conditional on the exact source F40-to-edge-label identification**, and must not be misdescribed as an independent geometric proof of that bijection.

## 2. Character-theoretic obstruction and sharp minimal repair

The exact real irreducible character table, with `\varphi=(1+\sqrt5)/2` and `\bar\varphi=(1-\sqrt5)/2`, is

| `A_5` irrep | `1` | `2A` | `3A` | `5A` | `5B` |
|---|---:|---:|---:|---:|---:|
| `1` | 1 | 1 | 1 | 1 | 1 |
| `3` | 3 | −1 | 0 | `\varphi` | `\bar\varphi` |
| `3'` | 3 | −1 | 0 | `\bar\varphi` | `\varphi` |
| `4` | 4 | 0 | 1 | −1 | −1 |
| `5` | 5 | 1 | −1 | 0 | 0 |

All 25 orthogonality pairings of these rows are checked exactly over `Q(\sqrt5)`. For the center-even quintet `V_5`, the diagonal action on the endomorphism space has character `\chi_{\mathrm{End}(V_5)}=\chi_5^2=(25,1,1,0,0)`. Character inner products give

\[
\boxed{\operatorname{End}(V_5)=\mathbf1\oplus\mathbf3\oplus\mathbf3'\oplus2\mathbf4\oplus2\mathbf5},
\qquad
\boxed{\mathcal Z_{40}=\mathbf3\oplus\mathbf3'\oplus3\mathbf5}.
\]

By real Maschke complete reducibility and Schur's lemma, the maximal rank of an equivariant linear map is the sum of the dimensions of the shared isotypic multiplicities:

\[
\max\mathrm{rank}_{A_5}(\mathcal Z_{40}\to\operatorname{End}(V_5))
=3+3+2\cdot5=\boxed{16}.
\]

The unique minimal **representation type** needed to inject all of `\mathcal Z_{40}` is one more `\mathbf5`, of dimension 5. With this addition, the 30-dimensional comparison space has nine-dimensional complement of type `\mathbf1\oplus2\mathbf4`. The invariant scalar linear functionals on the F40 cycle space vanish; the space of invariant symmetric bilinear forms has dimension `1+1+3(3+1)/2=8`.

The additional quintet does not need to be invented. On unordered core pairs, the Petersen/Kneser adjacency `A_P` (pairs adjacent when disjoint) has exactly

\[
\mathrm{Spec}(A_P)=\{3^{(1)},1^{(5)},(-2)^{(4)}\},\qquad
\boxed{P_{P,5}=-\frac{(A_P-3I)(A_P+2I)}6}.
\]

An independent 10-by-10 rational matrix reconstruction verifies idempotence, rank 5, and commutation with each of the 60 even five-label permutation matrices. **The isotype is sharp; there is no canonical choice of an injection merely from multiplicities.** The repair is a mathematical comparison-space embedding, not a new constituted physical momentum carrier.

## 3. Full rational 25-coefficient Gram without a cited executable

Pick five linearly independent rational columns of `P_{P,5}` as a `10\times5` basis `B`, and put `G=B^TB`. For each of all 60 `a\in A_5`, construct the rational quintet matrix `R_a=G^{-1}B^TP_{10}(a)B`. Verify both `B R_a=P_{10}(a)B` and `R_a^T G R_a=G`. Directly summing all 60 outer products of the **25** entries gives the exact coefficient orthogonality identity

\[
\boxed{\sum_{a\in A_5}(R_a)_{ij}(R_a)_{kl}
=12\,(G^{-1})_{ik}G_{jl}}.
\]

In the `G`-orthonormal basis and after doubling to `2I` (the quintet has trivial center), the right-hand coefficient becomes `24\delta_{ik}\delta_{jl}`. Thus `F^\dagger F=24I_{25}` is recovered directly from explicit matrices, rather than inferred only from a dimension count. The `\mathrm{SU}(2)` coefficient normalization is `U(X)=\sqrt5\operatorname{tr}(X\rho_2(q))`, and `\dim\mathcal H_4(S^3)=25`, `\Delta_+|_{\mathcal H_4}=24/R^2`.

The separate degree-two quintet uses imaginary coordinates `v\in\mathbb R^3` on `S^3\subset\mathbb R^4`. For traceless symmetric `Q,R`, exact spherical fourth moments give

\[
\int_{S^3}(v^TQv)(v^TRv)\,d\sigma
=\frac{\mathrm{tr}(QR)}{12}.
\]

Therefore `Q\mapsto\sqrt{12}\,v^TQv` is isometric for the Frobenius metric, with Laplacian `8/R^2` and real dimension five. This calculation checks all 25 Gram entries of a concrete rational basis of `\operatorname{Sym}^2_0(\mathbb R^3)`.

## 4. Independent cubic and quartic invariant defect ranks

The integer-spin `SU(2)` character on an `SO(3)` rotation by `\theta` is

\[
\chi_j(\theta)=1+2\sum_{m=1}^{j}\cos(m\theta).
\]

For the five `A_5` classes, use rotation angles `0,\pi,2\pi/3,2\pi/5,4\pi/5`. Exact evaluation (not sampled floating-point angles) yields **for spins `0\le j\le8` only**

\[
\boxed{\dim\operatorname{Fix}_{2I}(j)=1\;\text{for }j=0,6,\quad0\;\text{otherwise}.}
\]

The `SU(2)` spin-two Clebsch–Gordan rule is `j\otimes2=\bigoplus_{s=|j-2|}^{j+2}s`. Starting from spin zero and applying it four times gives the following complete invariant calculation. The finite ranks are independently computed from `\chi_5^k` by exact `A_5` character averaging, *not* from the difference table in the paper.

| Tensor power `k` | `SU(2)` invariant rank | `2I` invariant rank | difference | spin-six multiplicity |
|---:|---:|---:|---:|---:|
| 1 | 0 | 0 | 0 | 0 |
| 2 | 1 | 1 | 0 | 0 |
| 3 | 1 | 2 | **1** | 1 |
| 4 | 5 | 11 | **6** | 6 |

The inclusion `2I\subset SU(2)` implies `\operatorname{Fix}_{SU(2)}\subset\operatorname{Fix}_{2I}`. Their Haar-average operators are **commuting orthogonal projectors with nested ranges**; hence the difference is an orthogonal projector onto the missing six-spin fixed summands, not merely a formal difference of ranks. Since `j\le6` for `k=3` and `j\le8` for `k=4`, and the only new fixed line below spin nine occurs at spin six, the defect is **exactly one and six copies** of its fixed line in the two tensor powers.

The source's continuum cubic Wigner `3j` formula follows by the normalized `SU(2)` triple-matrix-coefficient integral; its mixed holomorphic/antiholomorphic quartic formula follows by the `j=0,...,4` Clebsch–Gordan decomposition of `2\otimes2` and Peter–Weyl orthogonality with factor `1/(2j+1)`. These are **continuum** formulas. The source's finite `2I` averaging adds the just-derived spin-six projector defects; this batch independently certifies **the complete defect ranks and representation ownership**, without constructing all individual 625^2 tensor-projector entries.

## 5. Independent tests, adversarial checks and exact boundaries

**Self-contained executable:** `Paper1B-F40Spin2VertexExactChecks-v1_1.py`; **output:** `Paper1B-F40Spin2VertexExactControls-v1_1.json`.

- **420 of 420 exact checks passed.** All 60 group elements and all five conjugacy classes are actually enumerated. No floating-point comparisons are used.
- Fixed-point counts of the 60 edge labels and 40 vertex labels are established from actual group actions, instead of assuming the F40 cycle character from the paper.
- All 25 real character orthogonality checks and all real isotypic multiplicities are exact in `Q(\sqrt5)`.
- All 60 native Petersen equivariance checks, all 60 rational quintet basis intertwiners, all 60 exact invariant metrics, and the full 25-by-25 coefficient Gram are checked.
- `k=1,..,4` spin fusion, continuous and finite invariant dimensions, spin-six multiplicities, and total tensor dimensions are separately checked. The first finite-only invariant is **cubic**, not quadratic.
- Adversarial scope control: the F40 edge-to-`C_{5A}\times5` identification, its quaternionic construction, and the graph's connectedness are **upstream mathematical premises**. Character theory alone does not rederive them. These checks must not be used to assert a physical field, a measured mass, a hadronic decay path, a selected interaction tensor, or the uniqueness of a particular intertwiner.

## 6. Bounded issue register; no premature global closure

| Item | New evidence in this batch | Disposition |
|---|---|---|
| `p1:thm:v349-f40-minimal-quintet` | Exact F40 cycle character, 25-operator character, maximal-rank bound, minimal one-quintet repair, Petersen projector | **CLOSED, conditional on the native F40 orbit construction** |
| `p1:prop:v349-f40-reduced-frame` | Isotypic splitting, zero invariant linear functionals, eight invariant symmetric quadratics | **Representation portion CLOSED**; source's specific four readout maps are a separate exact-matrix obligation |
| `p1:thm:v349-twisted25-spin2-lift` | Exact rational quintet coefficient Gram, harmonic dimension/eigenvalues, quadratic-moment normalization, comparison-space complement | **CLOSED within mathematical representation/sampling scope** |
| `p1:thm:v349-twisted25-vertex-defect` | Entire k=1..4 rank table and spin-six origin, exact character / Clebsch–Gordan derivations | **CLOSED for tensor-invariant ranks and spin-six origin** |
| `BH-IBX-EV-0010` | F40 representation/vertex-defect subbranch certified independently | **PARTIALLY DISCHARGED**: still reconcile full native F40 mirror/Plücker/specific readout certificates and their source locators before marking the whole root closed |
| `p1:prop:v343-fivefold-signed-contrast` | Source sign error already proved in Closure Batch 1; no attempted reinterpretation here | **OPEN SOURCE CORRECTION**: printed `+15D_5` must become `-15D_5` (single-factor statement) |
| `BH-IBX-SRC-0001` | Current source v1.8 still contains trimer attribution to Paper I-A around line 3992 | **OPEN PROVENANCE EDIT** (not a mathematical contradiction) |
| Other historic `EV` obligations | Prior closure reports and working certificates must be reconciled against the authoritative v1.8 objects | **NOT PROMOTED** by this unrelated batch |

**Modification log:** No paper, framework, source ZIP, canonical DAG, ProofChainAudits ZIP, or audit registry was modified. This Markdown report and the two self-contained proof artifacts are new standalone closure-batch output only. Next evidence batch should target the **full F40 native readout and mirror/Plücker identities** (not the now-reproduced character decomposition), and then reconcile the still-open source corrections and total closure ledger before updating.
