# Paper I-B — Closure derivations, Batch 5: F40 native readouts, mirror gluing and Plücker boundary

**Disposition:** the source-anchored native F40 mathematical claims below are **CLOSED (finite, conditional geometry)** by independent exact reconstruction. The separate historical v1_10 file is absent from the supplied DAG archive; its unlocated contents are **not** silently declared certified. There is **no** physical source, action, spectral mass or decay-model closure.

**Frozen source:** `Paper1B-ExceptionalGeometry-v1_8.tex`, SHA-256 `a03b4db5014afb21824ef58bd5931d1d943eee6f8defc24b77017ebd8dd4f4d5`, from `Paper00-PapersMinimal-v3_014(1).zip`. Its F40 section occupies lines 15697–15943, with companion Paper I-D v1.66 theorem labels `p1c:prop:v345-f40-certificate`, `p1c:thm:v349-f40-23-equations`, `p1c:prop:v349-f40-rational-frame-inverse` (lines 25444–25553). **Protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4(1).md`, using its E1 source replay, E3 independent exact derivations, E4 mutated-data/quantifier checks and theorem-boundary gate. **Proof artifacts (new, standalone):** `Paper1B-F40NativeMirrorExactChecks-v1_1.py`, `Paper1B-F40NativeMirrorExactControls-v1_1.json`. The Python program runs from the exact quaternion construction; it does not invoke historical scripts, import their matrices, read stored PASS statuses, or change canonical files. Final run: **71/71 source-matched or adversarial exact check groups passed**, including 3,600 original-edge group-action incidences, 14,400 mirror-kernel group-equivariance entries, all 240 exact cyclic-distance coefficients, all 23 source compatibility equations, and exact rational matrix identities.

## 1. Claim-boundary inventory (BND-F40-05)

- **[CONST/FROZEN]** The input is the *finite* group of 120 unit quaternions `2I` in `Q(sqrt(5))^4`, its 24-element Hurwitz `2T` subgroup, the five conjugate core subgroups, and the explicitly defined F40 graph whose oriented edges go from real-part `+1/2` vertices to real-part `−1/2` vertices with relative quaternion scalar part `(sqrt(5)-1)/4`.
- **[DER]** `p1:thm:v345-f40-edge-regular`: exactly 40 vertices, 60 edges, the 12-shell and the edge-label bijection to `S×{1,…,5}`, equivariant under the **60-element projective** `A5` group; this is not a gauge or physical state declaration.
- **[DER]** `p1:thm:v345-f40-triple-frame`, `p1:prop:v345-f40-balanced-mirror`, `p1:prop:v349-f40-reduced-frame`, `p1:thm:v349-f40-mirror-gluing`: all maps act on the real 21-dimensional graph cycle space with its Euclidean *edge-chain* metric. They do not automatically act on a physical Hilbert space.
- **[DER]** The companion Paper I-D `23` constraints and rational inverse are comparisons of *raw 44-channel triples* with a common graph-cycle origin.
- **[HOST]** The elementary Plücker quadric is an exterior-algebra identity for a **four-dimensional** zero-sum core space. The current Paper I-B v1.8 source contains **no separately labelled F40 Plücker theorem**. The title of an older proof script is not a new source theorem.
- **[REAL/I]** No F40-to-QCD singlet embedding, same-action coupling, detector, mass or decay amplitude has been supplied by these finite identities. The observable condition that would be meaningful *if the channel triple is physically supplied* is the exact necessary-and-sufficient test `C23 d=0`.

## 2. Independent reconstruction of all finite F40 objects

Represent each scalar coordinate by an exact rational pair `(a,b)` meaning `a+b sqrt(5)`. Construct the 120 unit quaternions as: eight signed coordinate vectors; sixteen vectors with all coordinates `±1/2`; and ninety-six even permutations of `(0,±1/2,±φ/2,±1/(2φ))`, `φ=(1+sqrt(5))/2`. Quaternion multiplication is exact in this quadratic field. Define `H=2T` from the first two types, and compute the five *distinct conjugates* `gHg^{-1}`.

There are 20 vertices of real part `+1/2`, 20 of `−1/2`. Put an oriented edge `e=(q,q')` precisely when `Re(q^{-1}q')=(sqrt(5)-1)/4`. Direct enumeration gives **60 edges**, every vertex degree three, and each of the two quotients `g_R=q^{-1}q'`, `g_L=q'q^{-1}` belongs to a common 12-element shell `S`. A vertex belongs to two of the five conjugate cores; the two endpoint memberships omit exactly one common label `m_e`, and its transport is `n_e=p_{g_R}(m_e)`. Every pair `(g_R,m_e)∈S×{1,…,5}` occurs once, and every ordered distinct core arrow `(m,n)` occurs three times.

Conjugation by `2I` acts through **exactly 60** permutations of the five core labels. On all sixty edges it acts freely away from identity and transitively, and it carries all three source labels equivariantly. This directly discharges the finite antecedent of the native readout statements; no older F40 v1_10 script is used.

## 3. Native three-readout identities and exact finite frame

Let `B` be the `40×60` signed vertex–edge incidence matrix, `N` any full-rank `60×21` rational matrix spanning `ker B`, and `P_Z=N(N^T N)^{-1}N^T`. Let `T_R,T_L` be the `12×60` incidence maps of `g_R,g_L`, and `A` the `20×60` directed core-arrow incidence map. The source-specified `44×21` native frame is

\[
R=\begin{pmatrix}T_R\\T_L\\A\end{pmatrix}N.
\]

Exact independent rank computations give

\[
\operatorname{rank}(T_R N)=\operatorname{rank}(T_L N)=\operatorname{rank}(AN)=11,
\quad \operatorname{rank}(T_R,T_L)|_Z=\operatorname{rank}(T_R,A)|_Z
=\operatorname{rank}(T_L,A)|_Z=16,
\quad \boxed{\operatorname{rank}R=21}.
\]

The coordinate-free Euclidean frame matrix is `F=(N^TN)^{-1}R^TR`. Its exact characteristic polynomial is

\[
\boxed{\chi_F(x)=(x-1)^5(x^2-12x+31)^3(x^2-8x+6)^5}.
\]

The eigenvalues are `1` (five), `6±sqrt(5)` (three each) and `4±sqrt(10)` (five each), so the sharp lower frame bound is `4−sqrt(10)>0`. The independent checks also reproduce the rational inverse

\[
\boxed{F^{-1}=\frac{F^4-21F^3+153F^2-453F+506I}{186}},
\quad P_{44}=R F^{-1}(N^TN)^{-1}R^T.
\]

`P44` is exactly symmetric/idempotent; it fixes `R` and is annihilated by the 23-constraint matrix below. The matrix `F` is expressed in a not-necessarily-orthonormal cycle basis; using `F^{-1}R^T` **without** the `N^TN` factor would be an incorrect reconstruction formula. This normalization was explicitly tested.

## 4. The 5+6 balanced-arrow splitting and native shell Grams

The matrix `A z` is zero on its diagonal and is row/column balanced. The ten balance equations have **rank nine**, leaving an 11-dimensional output. Its transpose-even and transpose-odd orthogonal projectors `P_sym` and `P_skew` have ranks 5 and 6, and

\[
\boxed{AP_ZA^T=2P_{\rm sym}+P_{\rm skew}}.
\]

Form the **icosahedral** `12×12` adjacency `A_ico` directly from the positive-nearest imaginary-part inner products of the quaternion shell, *not* by solving the desired Gram identity. Let `Ant` map `g↔g^{-1}` and `J=J12`. Entrywise exact computations then yield

\[
\begin{aligned}
T_RP_ZT_L^T&=-\frac94 I+\frac12 A_{\rm ico}+\frac14\mathrm{Ant}-\frac1{24}J,\\
(T_R+T_L)P_Z(T_R+T_L)^T&=I+\mathrm{Ant}-\frac16J,\\
(T_R-T_L)P_Z(T_R-T_L)^T&=10I-2A_{\rm ico}.
\end{aligned}
\]

The first combined map has rank 5 (no mirror response). The second has rank 11 (including mirror response). The independent reduced native map into the four existing output sectors—shell sum quintet, shell difference quintet, Petersen symmetric arrows, and balanced skew arrows—has ranks `5+5+5+6=21` jointly, and its Petersen component lies in the rank-5 graph spectral projector. No extra physical carrier is created by this change of coordinates.

## 5. Hodge mirror kernel: exact matrix and complete inverse

For each shell five-cycle `p_g`, each ordered arrow `(i,j)` has a unique distance `d_g(i,j)∈{1,2,3,4}`. Define the 20×12 rational matrix

\[
\boxed{K_{(i,j),g}=\frac{5-2d_g(i,j)}{40}}.
\]

The 240 entries contain **exactly 60 of each** `3/40, 1/40, −1/40, −3/40`. The new verification program checks all 60 `A5` conjugation/permutation actions on the whole 20×12 kernel. On every one of the 21 independent cycle vectors it gives

\[
\boxed{(P_{\rm skew} A-K(T_R-T_L))N=0}.
\]

Put `P_odd=(I−Ant)/2`. From the exact shell adjacency `A_ico²P_odd=5P_odd` and the independently reconstructed Gram,

\[
\boxed{K^TK=\frac{5I+A_{\rm ico}}{40}P_{\rm odd}}.
\]

The exact two-sided inverse on the six-dimensional domain and codomain is `K^{-1}=2(5I−A_ico)K^T`, with `K^{-1}K=P_odd` and `KK^{-1}=P_skew`. The two nonzero eigenvalues of `K^TK` are `(5±sqrt(5))/40` (each threefold), giving

\[
\boxed{\kappa(K)=\sqrt{\frac{5+\sqrt5}{5-\sqrt5}}=\varphi}.
\]

This is mathematical conditioning of a finite source **comparison**. It is not an energy ratio or a coupling constant.

## 6. Exact 23-equation compatibility theorem and an adversarial packet

For arbitrary raw data `d=(u,v,w)∈R12⊕R12⊕R20`, the following independent constraint classes are necessary and sufficient for the **unique** existence of an F40 cycle whose three native readouts equal `d`:

1. Two shell sums `sum u=sum v=0`.
2. Five arrow row sums and four arrow column sums `=0` (nine independent relations).
3. Six inversion-parity equations `u_g+v_g=u_{g^{-1}}+v_{g^{-1}}`.
4. Six chord Hodge-gluing equations `\frac12(w_{ij}-w_{ji})=\sum_g K_{(i,j),g}(u_g-v_g)` for `2≤i<j≤5`.

The constructed rational `23×44` matrix `C23` has **rank 23**, satisfies `C23 R=0`, and `R` has rank 21. Hence `ker C23=im R` by rank-nullity, proving necessity, sufficiency and uniqueness; this is not just a dimension coincidence without an inclusion proof.

**E4 witness.** Choose any antipodal pair `g,g^{-1}`, set `u=e_g−e_{g^{-1}}`, `v=−u`, `w=0`. Both shell means, every arrow balance and all six shell inversion-parity conditions hold, yet the six Hodge chord residuals in the actual source ordering are

\[
(3/10,\,-3/10,\,-1/10,\,-1/10,\,1/10,\,-3/10).
\]

This packet passes the **eleven intra-channel** controls and the six parity relations but **fails all six Hodge gluing equations**. Thus the cross-channel consistency is a mathematically substantive restriction, not a restatement of individual channel conservation. Other adversarial tests flip a single sign in `K` or replace `/40` by `/20`; both destroy the exact Gram/inverse identity.

## 7. The Plücker boundary is precise but not an extra physical selector

Let `U={x∈R5:sum_i x_i=0}`, `dim U=4`, and map

\[
u\wedge v\mapsto (u_i v_j-u_j v_i)_{i\ne j}.
\]

Its six elementary wedges span exactly the balanced **skew** arrow six-plane: the independent integer wedge matrix has rank 6 and is fixed by `P_skew`. In the basis `e_i−e_5`, the Plücker equation for a *decomposable* bivector is

\[
\boxed{p_{12}p_{34}-p_{13}p_{24}+p_{14}p_{23}=0}.
\]

The independent check verifies this for arbitrary decomposable sample bivectors. **Crucial nonimplication:** the full F40 skew-arrow image equals `Λ²U`, not merely the quadratic Grassmannian of decomposable bivectors. For example `p12=p34=1` with the other four coefficients zero has Plücker value 1 and is realized by *some* F40 skew readout, because that readout is onto the six-plane. Therefore it would be false to impose the Plücker quadric on *every* native cycle. The historical script title `PetersenHodgePlucker` cannot be used as evidence of such a stronger claim. The current v1.8 Paper I-B source does not state a separately labelled F40 Plücker theorem; any other v1_10-specific claim requires its own located source and cannot be promoted here.

## 8. Reproduction, provenance, and closure disposition

The supplied DAG ZIP `Paper00-DAGAtlas-v1_139(1).zip` contains `Proofs/Paper00-F40MirrorGluing-v1_1-verify.py` and `Proofs/Paper00-PetersenHodgePlucker-v1_11-verify.py` **but not their required** `Proofs/Paper00-PetersenHodgePlucker-v1_10-verify.py`. Thus the original scripts' dependency chain is not replayable as packaged. This is an **archive-level provenance limitation**, not a counterexample to any F40 identity. The new Python script bypasses the missing historical script and independently reconstructs every *current-source claim* listed above from `Q(sqrt(5))` data.

| Source claim | Result | Evidence classification |
|---|---|---|
| `p1:thm:v345-f40-edge-regular` | Native 40/60 graph, five conjugate cores, 12-shell, regular 60-edge action | **E3 VERIFIED**; E4 group-action gate |
| `p1:thm:v345-f40-triple-frame` | Ranks 11/16/21 and complete polynomial | **E3 VERIFIED** |
| `p1:prop:v345-f40-balanced-mirror` | Full arrow and two-sided shell Grams | **E3 VERIFIED** |
| `p1:prop:v349-f40-reduced-frame` | Native reduced 5+5+5+6 map, injective and Petersen-aligned | **E3 VERIFIED** |
| `p1:thm:v349-f40-mirror-gluing` | Exact 240-entry K, equivariance, Gram, inverse and golden conditioning | **E3 VERIFIED; E4 sign/normalization attacks** |
| `p1c:thm:v349-f40-23-equations` | Exact 23 independent constraints; `ker C23=im R` | **E3 VERIFIED; E4 incompatible-packet witness** |
| `p1c:prop:v349-f40-rational-frame-inverse` | Rational polynomial inverse and orthogonal data projector | **E3 VERIFIED** |
| Unlabelled historical Plücker-script material | Source-compatible `Λ²U` and decomposable quadric controls checked | **LIMITED**: no separate v1.8 Plücker theorem located; do not assign status to missing v1_10 contents |

**Effect on `BH-IBX-EV-0010`:** its *source-anchored F40 native-readout, mirror-gluing, representation and frame* mathematical evidence is independently discharged when combined with Closure Batch 4's module proof. Preserve the missing v1_10 predecessor as a separate **archival reproducibility** note; do not conflate that with failure of the new self-contained certificate. The previously established **five-cycle class-operator sign defect** in `p1:prop:v343-fivefold-signed-contrast` remains an outstanding *source correction*; this batch does not change or mask it. Neither the theorem nor the source grants a physical F40 realization or a hadronic decay observable.

**Modification log:** This batch created **only** the standalone Markdown report, self-contained Python verification program and its JSON results. No Paper I-B TeX, framework version, live DAG node, ProofChainAudits ledger, source archive or ZIP was modified. Further integration must wait for the full closure/errata reconciliation.
