# Paper I-B — Closure derivations, Batch 3 (standalone; no framework update)

**Target source:** `Paper1B-ExceptionalGeometry-v1_8.tex`, SHA-256 `a03b4db5014afb21824ef58bd5931d1d943eee6f8defc24b77017ebd8dd4f4d5`, supplied in `Paper00-PapersMinimal-v3_014(1).zip`. **Claim:** `p1:prop:v366-register-mirror-contrast` (v1.8 source lines 16709–16748). **Prerequisites actually used:** `p1:prop:v339-incidence-rank15-contrast`, `p1:thm:v339-petersen-sl4-isometry`, `p1:thm:v339-petersen-projector-strata`, `p1:thm:v365-600-cell-incidence`, `p1:thm:v366-chamber-transporter-complement`, and the five-cycle class-operator definition. The old v1.7 proof-chain audit and the claimed cumulative `HadronChamberSplitCertificate` are **not** used as correctness substitutes.

**Verdict: CLOSED WITHIN CLAIMED SCOPE.** All three published compression statements hold for the explicitly defined trial register potential and normalized 15-dimensional Petersen **coefficient** lift. This does not select a physical potential, hadron state, decay width, mass, or a full leakage-corrected effective Hamiltonian.

## 1. Explicit source-matched lift

Use 120 exact unit quaternions in `2I`, encoded by pairs of integers `(a,b)` for `(a+b φ)/2`, `φ²=φ+1`. The exact nearest-neighbor condition `⟨g,h⟩=φ/2` has 720 undirected edges and 600 four-clique tetrahedra. With the original `2T` subgroup `H` of order 24, the `H_L×H_R` action on tetrahedra has exactly one orbit of length 24; the other orbit sizes are 288, 96, 96, 96. Translate the 24-orbit by the five left/right `G/H` representatives to obtain 25 **disjoint** sets `\mathscr F_{ij}` of 24 tetrahedra each. For each `(i,j)` their union of vertices is exactly the complement of the corresponding 24-element transporter `a_i H b_j^{-1}`, with each complementary vertex appearing once.

Let `π(g)` act on the five cosets. The native Petersen 15-space has orthonormal oriented-edge basis `e` and a *canonical five-by-three chart*: edge `e=(A→B)` is assigned to the unique **omitted** core label `m(e)∈{1,…,5}` outside the disjoint pairs `A,B`. Exactly three edges omit each label. From the source's symmetric edge matrices `S_e=d_Ad_A^T-d_Bd_B^T` and antisymmetric `K_e=v_Av_B^T-v_Bv_A^T`, form its **original** isometry

\[
U=(S+K)\left(\tfrac15P_{E,4}+\tfrac12P_{E,5}+\tfrac12P_{E,6}\right),\qquad U^TU=I_{15}.
\]

All 25×15 entries of `U` are rational with common denominator 10. The source's vertex coefficient functions and their chamber lift are

\[
F_e(g)=\frac1{\sqrt{30}}\sum_{j=1}^5 (U_e)_{\pi(g)(j),j},\qquad
\Psi_e(f)=\frac1{\sqrt5}\sum_{g\in f}F_e(g)
=\frac1{\sqrt{150}}\sum_{g\in f}\sum_{j=1}^5 (U_e)_{\pi(g)(j),j}.
\]

Entrywise integer multiplication on the reconstructed 600 tetrahedra verifies `Ψ^T Ψ=I_15`. Define the 25 exact rational matrices `C_{ij}=Ψ^T P_{\mathscr F_{ij}} Ψ`. Then

\[
\boxed{K(M)=\sum_{i,j=1}^5 M_{ij}C_{ij}},\qquad \sum_{i,j}C_{ij}=I_{15},\qquad
\boxed{\sum_j C_{ij}=\sum_i C_{ij}=\tfrac15 I_{15}}.
\]

These formulas specify **every** local-three-dimensional/off-core matrix entry; no dimensional inference is substituted for an actual compression.

## 2. Exact 16-dimensional off-core result

Write `Q=I_5-J_5/5`. Form the 90 distinct real off-core entries of `K(M)` between Petersen edges with `m(e)≠m(e')`, and assemble their 90×25 coefficient matrix `\mathscr O`. The exact rational/integer calculation gives

\[
\operatorname{rank}\mathscr O=16,\qquad
\ker\mathscr O=\{M:QMQ=0\}
=\{M_{ij}=a_i+b_j\},\quad \dim\ker=9.
\]

The claimed kernel is annihilated **entrywise**, not merely by a norm. For a non-circular lower-rank witness, select the 16 register coordinates `(i,j)` with `0≤i,j<4`; the first 16 independent off-core coefficient rows give a 16×16 integer minor with determinant `50 (mod 101)`, hence nonzero over `\mathbb Q`.

A concrete cross-core edge-pair entry is

\[
(K(M))_{e_0e_1}=\sum_{i,j}W_{ij}M_{ij},\quad
\boxed{W=\frac1{300}\begin{pmatrix}
0&5&1&-3&-3\\ 5&0&1&-3&-3\\
-3&-3&4&1&1\\ -1&-1&-3&4&1\\ -1&-1&-3&1&4
\end{pmatrix}}.
\]

Here `m(e_0)≠m(e_1)`; every row and column of `W` sums to zero, exhibiting its dependence only on `QMQ`. In particular `(K(Q))_{e_0e_1}=1/25≠0`.

## 3. Exact 15-dimensional mirror-active result

Compute the signed difference of the two 12-member five-cycle class sums on the Petersen signed-edge representation: `\widetilde D=\sum_{5A}\rho_W(g)-\sum_{5B}\rho_W(g)`. The independently checked identities are `\widetilde D^3=80\widetilde D` and `rank \widetilde D=6`. By the prior **source-corrected** five-cycle comparison, `\widetilde D` is a nonzero scalar multiple of the existing mirror contrast `D=\Pi_3-\Pi_{3'}`; its sign does not affect commutation.

For the 25 rational operators `C_{ij}`, form `[C_{ij},\widetilde D]` entrywise. The resulting 225×25 coefficient map has **exact rank 15**. It annihilates the 9-dimensional additive kernel **and** the independent centered scalar matrix `Q`, giving exactly

\[
\boxed{[K(M),D]=0\iff QMQ=\alpha Q},\qquad
\alpha=\tfrac14\operatorname{tr}(QMQ).
\]

For a second independent nonzero-minor witness, a 15×15 commutator minor, using centered basis coordinates, has determinant `32 (mod 101)`.

The published scalar-centered identity also holds **entrywise**:

\[
\boxed{K(Q)=-\frac1{15}I_{15}+\frac15P_{E,4}},\qquad
\operatorname{spec}K(Q)=\{(2/15)^{(4)},(-1/15)^{(11)}\}.
\]

This centered scalar **commutes** with `D` but has **nonzero off-core entries**. Thus the two claimed kernels are properly distinct.

## 4. Stronger complete decomposition (deduced, not a physical postulate)

Let `\overline M=\frac1{25}\sum_{ij}M_{ij}` and `T(M)=QMQ-\frac14\operatorname{tr}(QMQ)Q`. The source-specified 25-dimensional trial weight space admits the orthogonal direct sum

\[
\boxed{\mathbb R^{5\times5}=\underbrace{\mathcal A_0}_{8}\oplus
\underbrace{\mathbb RJ_5}_{1}\oplus
\underbrace{\mathbb RQ}_{1}\oplus
\underbrace{\operatorname{im}T}_{15}},
\]

where `\mathcal A_0` consists of zero-mean additive matrices `a_i+b_j`. The verified row/column register sums yield

\[
\boxed{K(M)=\overline M I_{15}+\alpha K(Q)+K(T(M))},
\qquad \alpha=\tfrac14\operatorname{tr}(QMQ).
\]

Consequences: (i) `\mathcal A_0` (dimension 8) is **completely invisible** to direct compression, not just to its off-core component; (ii) the uniform mode gives the scalar identity; (iii) the centered scalar `Q` supplies **mirror-preserving but nonzero off-core** coupling; (iv) all 15 traceless centered directions are mirror-active, and the commutator is injective on them. The complete matrix map `M↦K(M)` therefore has rank **17**, while its off-core and mirror-commutator maps have ranks **16** and **15** respectively. This decomposition concerns only direct trial-potential compression; second-order virtual chamber-partner transitions require separate Feshbach data.

## 5. Adjudication and remaining independent work

| Verified item | Result | Verdict |
|---|---|---|
| 120 exact vertices, 600 tetrahedra, 25 translated blocks | 25×24 complete and disjoint; transporter complement entrywise | VERIFIED |
| Native oriented Petersen five-by-three chart | 15 edges, three per omitted core; `U^TU=I` | VERIFIED |
| Source-normalized 600×15 chamber lift | `Ψ^TΨ=I` | VERIFIED |
| Entire 25-register coordinate family | `\sum_j C_{ij}=\sum_i C_{ij}=I/5` | VERIFIED |
| Off-core compression / additive kernel | Rank 16; kernel dimension 9 | VERIFIED |
| Mirror commutator / centered scalar kernel | Rank 15; kernel dimension 10 | VERIFIED |
| Scalar centered identity | `K(Q)=-I/15+P_{E,4}/5` | VERIFIED |
| The reconstructed 25=8+1+1+15 contrast | Full compressed-map rank 17 | DERIVED AND VERIFIED |

**Separate outstanding matter:** `p1:prop:v343-fivefold-signed-contrast` still prints the wrong **positive** sign in v1.8; its source-corrected operator has the negative sign derived in Closure Batch 1. The commutator-kernel proof above uses only a proportionality and is unaffected by that sign. No new mathematical problem was found in the target v366 proposition.

**Reproduction:** `Paper1B-FiveCoreRegisterExactChecks-v1_1.py` (Python, SymPy, NumPy), with verdicts and nonzero modular determinant witnesses in `Paper1B-FiveCoreRegisterExactControls-v1_1.json`. The calculation starts from the named current source's actual group and edge definitions, builds the entire 600×15 lift, and asserts every conclusion using exact rational or integer arithmetic. The two mod-101 minors are supplementary independent *nonvanishing* rank witnesses, not substitutes for exact rational kernel containment.

**Modification log:** no source file, paper, framework, DAG, ZIP, global audit or archive was changed. This standalone derivation and its evidence are the only new artifacts.
