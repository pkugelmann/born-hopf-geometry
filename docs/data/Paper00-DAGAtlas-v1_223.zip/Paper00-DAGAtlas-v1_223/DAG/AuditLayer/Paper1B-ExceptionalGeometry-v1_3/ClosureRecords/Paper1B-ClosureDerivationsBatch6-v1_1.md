# Born–Hopf Geometry — Paper I-B, closure derivations: final reconciliation batch 6

**Disposition:** `FINAL_CLOSURE_RECONCILED_WITH_SOURCE_ERRATUM_AND_EVIDENCE_PROVENANCE_REMAINDERS`. **No source, manuscript, framework, canonical DAG, proof-chain audit archive, or ZIP was changed.** This is a standalone evidence package for a subsequent, explicitly authorized integration.

**Current controlling source:** `Paper1B-ExceptionalGeometry-v1_8.tex`, SHA-256 `a03b4db5014afb21824ef58bd5931d1d943eee6f8defc24b77017ebd8dd4f4d5`, exactly matching the file in the supplied `Paper00-PapersMinimal-v3_014(1).zip`. **Previous canonical audit:** `Paper1B-ExceptionalGeometry-v1_7.tex`, 480 formal statements. **Current v1.8 source:** 483 statements (165 theorems, 108 propositions, 97 corollaries, 31 definitions, 78 remarks and 4 lemmas). Exactly one theorem, one proposition and one scoped remark were added. Protocol reviewed: `Paper00-RigorousVerificationDAGWorkProtocol-v2_4(1).md`, applying its source-first E1/E3/E4 and status/assumption distinctions; this user-authorized closure study, unlike a protocol-only audit, derives exact alternative proofs and recommended corrections but **does not apply them**.

## 1. Results that survive the adversarial final replay

### New v1.8 results

1. `p1b:thm:v18-born-even-octahedral-response`: in the explicitly aligned standard Hurwitz embedding, the Born-even quartic is
   \[\mathcal V_H(x,y,z)=\frac{x^2y^2+y^2z^2+z^2x^2}{9},\quad \overline R=\frac{r^2}{6}.\]
   Its six unit-sphere zeros are precisely the coordinate axes. Consequently its proper rotation stabilizer is octahedral (order 24), with spin lift `2O` (order 48). The exact harmonic decomposition is
   \[\mathcal V_H=\frac{r^4}{45}-\frac1{18}(x^4+y^4+z^4-3r^4/5).\]
   The *full quartic is not harmonic*; its degree-four nonradial even harmonic component is the first such tetrahedrally invariant class. The degree-three invariant `xyz` is odd and therefore excluded only by the **stated** even-response condition. Source claims the symmetry of a finite response, **not** automatic physical particle occurrence.
2. `p1b:prop:v18-octahedral-sixfold-attachment`: the exact disjoint counts are `2T=8+16=24`, `2O\setminus2T=6+12+6=24`. For the specified axis `u=(i+j+k)/sqrt(3)`, `N_{2O}(C6)=C6 ⨿ B6 ≅ 2D3`, order 12, with its six-element coset **already inside** the existing 48-element `2O`. Do not confuse this finite normalizer with the continuous normalizer in all `Sp(1)`.
3. The new `p1b:rem:v18-particle-response-frontier` is a scope remark, not a separate physical construction.

**Replayed executable:** `Paper1B-OctahedralSixfoldExactChecks-v1_1.py`; `511/511` exact checks pass.

### Five-core trial-register compression

`p1:prop:v366-register-mirror-contrast` now has a directly runnable, current-source-matched chamber and Petersen reconstruction. Starting from 120 exact `2I` quaternions, enumerate 600 tetrahedra and partition them into 25 disjoint 24-chamber blocks. The 600×15 rank-fifteen coefficient lift is isometric. Every one of the 25 compressed matrices is constructed, *not inferred* from a total rank. For `Q=I5−J5/5` and trial weights `M`, the exact finite linear maps obey

\[
\begin{aligned}
\ker K_{\mathrm{offcore}}&=\{M:QMQ=0\},& \operatorname{rank}K_{\mathrm{offcore}}&=16,\\
\ker[K(M),D]&=\{M:QMQ=\alpha Q\},&\operatorname{rank}\bigl(M\mapsto[K(M),D]\bigr)&=15,\\
K(Q)&=-\tfrac1{15}I_{15}+\tfrac15P_{E,4},& \operatorname{rank}(M\mapsto K(M))&=17.
\end{aligned}
\]

In particular the **25** trial weights decompose into an **eight-dimensional entirely invisible additive sector**, one uniform scalar, one centered mirror-preserving scalar and 15 mirror-active contrasts: `25=8+1+1+15`. The centered scalar may have *nonzero off-core entries while commuting with the mirror*. Thus off-core mixing and mirror mixing are distinct mathematical tests. The partition reconstructs the formerly missing geometry needed by `BH-IBX-EV-0011`; the mathematical register-resolvent claims must still retain their physical-actualization condition. **Replayed executable:** `Paper1B-FiveCoreRegisterExactChecks-v1_1.py` (exact ranks 16/15/17, 25×24 chamber partition, entrywise transporter complements, nonzero modular minors 50 and 32 modulo 101).

### F40 representation, mirror and 23-constraint frame

The F40 cycle module has `dim=21` and character `(21,1,−3,1,1)` on the five `A5` classes. The exact representations are

\[\mathcal Z_{40}=\mathbf3\oplus\mathbf3'\oplus3\mathbf5,\qquad \operatorname{End}(V_5)=\mathbf1\oplus\mathbf3\oplus\mathbf3'\oplus2\mathbf4\oplus2\mathbf5.\]

Any equivariant map between these carriers has rank at most **16**, and **one additional quintet** is the minimal representation-type repair. This alone does *not* select a unique intertwiner or physical particle carrier. For the spin-two comparison, the finite/continuous invariant-rank differences in tensor orders 1–4 are `0,0,1,6`, entirely from spin-six. **Replayed executable:** `Paper1B-F40Spin2VertexExactChecks-v1_1.py` (`420/420` checks).

The current-source-native 40-vertex/60-edge reconstruction independently gives readout ranks `11` individually, `16` in each pair and `21` jointly; the frame characteristic polynomial is

\[\chi_{\mathcal R^*\mathcal R}(x)=(x-1)^5(x^2-12x+31)^3(x^2-8x+6)^5.\]

The mirror kernel `K_(i,j),g=(5−2d_g(i,j))/40` satisfies `P_skew Az=K(T_R−T_L)z` on the complete cycle space, has the specified two-sided inverse and golden-ratio condition number, and its 23 independent compatibility relations are **necessary and sufficient** (`ker C23=im R`). An explicitly constructed adversarial packet satisfies intra-channel balances yet violates the gluing relation. The skew-arrow image is `Λ²R⁴` (dimension six); **not every vector in this image is decomposable**, so the Plücker quadric is not a universal F40 cycle restriction. **Replayed executable:** `Paper1B-F40NativeMirrorExactChecks-v1_1.py` (`71/71` checks). This independently discharges the *current-source F40 mathematics* of `BH-IBX-EV-0010`; the older cited `PetersenHodgePlucker-v1_10` executable is still absent from the historical archive, a separate reproducibility defect.

## 2. An actual source error: signed five-cycle comparison

The current `p1:prop:v343-fivefold-signed-contrast` (v1.8 lines 15507–15547) defines

\[K_W=\sum_{5A}\rho_W(g)-\sum_{5B}\rho_W(g),\qquad L_W=\frac{K_W}{4\sqrt5},\qquad D_5=\mathcal A_{5A}-\mathcal A_{5B}.\]

It prints `Φ L_W Φ⁻¹=+15 D5/(4√5)`. Directly evaluate all 60 permutation matrices of `A5` in the standard four-dimensional contrast representation and the exact class-frame vectors. With `R_g=20Z_g`, let `N` be the *integer* difference of outer-product sums `vec(R_g)vec(R_g)^T`. Then `D5=N/6000` and the 25×25 integer matrices obey **entry by entry**:

\[\boxed{400K_W+N=0}\quad\Longleftrightarrow\quad\boxed{\Phi K_W\Phi^{-1}=-15D_5}.\]

The independent scalar witness is `tr(K_W D5)=−32`; the source positive identity would give `+32`. Moreover `tr(K_W²)=480`, `tr(D5²)=32/15`, and the equality case of Cauchy–Schwarz fixes the negative proportionality uniquely. Swapping the names `5A` and `5B` *on both sides* flips both operators and does not repair their relative sign. **Therefore the source formula is REFUTED AS PRINTED**, and the exact local correction is

\[\boxed{\Phi L_W\Phi^{-1}=-\frac{15}{4\sqrt5}D_5}.\]

The squared/cubic projector identities and rank-six support survive. The label ordering in `L_W=Π3−Π3'` may remain consistent with its own definition; do not flip unrelated definitions casually. The original proof paragraph's appeal to “consistent class ordering” must be corrected to acknowledge the **opposite** frame/class-sum eigenvalue ordering.

**Downstream propagation is bounded and proved, not guessed.** Paper I-C v1.138, theorem `p1b:thm:v343-doubleodd-contrast`, contains *two* such single-factor conversions. The two negative signs cancel:

\[L_x\otimes L_p=\frac{K_x\otimes K_p}{80}=\frac{45}{16}(\Phi_x^{-1}D_{5,x}\Phi_x)\otimes(\Phi_p^{-1}D_{5,p}\Phi_p).\]

Thus its displayed **positive** `45/16` coefficient and tensor spectra do not require a sign correction. Paper II-E's conditional three-outcome projectors and Paper II-F's one-dimensional odd *line* use the tensor/square or a line only and remain source-compatible; a numerical sign in a *single-factor* comparison must not be transferred without the correction. Paper I-D references the class-sum cubic and `D5²`, neither of which depends on that relative sign. Other unrelated `K_W` notations in later papers are **not** the signed five-cycle operator and must not be swept into this erratum.

**Replay:** `Paper1B-FivecycleSignExactChecks-v1_1.py` and `Paper1B-ClosureReconciliationExactChecks-v1_1.py` both reproduce the integer refutation.

## 3. Newly packaged E3 closures for the sextic and Lie-rank evidence

The earlier continuation reported complete mathematics for `EV-0007` and `EV-0008`; this final batch now supplies a **fresh, executable, independently constructed** certificate for both.

**Hurwitz sextic (`BH-IBX-EV-0007`).** In the source's variables `y_i=x_i²` and `r²=Σy_i`, form the homogeneous polynomial

\[H_6=r^6-8r^2e_2(y)+48e_3(y).\]

Direct symbolic differentiation confirms `Δ_{R⁴}H6=0`, and the two independent quarter-rotations in the source give `H6∘O=−H6`. On the unit sphere use the exact Haar monomial rule

\[E\prod_i x_i^{2a_i}=\frac{\prod_i(2a_i)!}{4^{|a|}(|a|+1)!\prod_i a_i!}.\]

The newly computed **complete** polynomial sums (not selected sampled points) yield `E H6²=1/7`, `E H6³=0`, `E H6⁴=61/1001`. For `Y6=√7 H6`, `E Y6⁴=427/143` and the degree-six positive spherical Laplacian eigenvalue is 48. The source's `a`-radius normalization then follows by rescaling. **Verdict:** mathematical claim `p1:prop:v215-sextic-moments` independently closed.

**Five Lie dimensions (`BH-IBX-EV-0008`).** Reconstruct the **entire original 15×15 matrix tuple** from `p1:eq:v226-matrix` on `Ce0⊕R⁴⊕Λ²R⁴⊕S⁴`; use exactly the four source gamma matrices and the combinations `Q0=ΣYa²−(31/45)I`, and the fully antisymmetrized `Ω4`. Independently check the source's diagonal `Q` fingerprint and the exact `Ω4=−34 Bstar/81+27 χ/32` identity. Reduce the number field at the good prime `97` via `sqrt(2)→14`, `sqrt(3)→10`, `i→22`, verifying all Clifford anticommutators. Iteratively adjoin the brackets `i[A,B]` and perform full finite-field elimination on flattened 225-entry matrices. Its five closure ranks, from the actual reconstructed generators, are

\[\boxed{65,131,135,136,137}.\]

Because a nonzero minor survives the good reduction, each is a **characteristic-zero lower bound**. Coupled to the blockwise upper bounds *proved in the exact source*, each rank gives equality, and the source's block-preservation arguments identify the Lie types. **Verdict:** the five asserted dimensions of `p1:thm:v226-control-lie` are independently closed. No claim is made that all mathematical coordinate Hamiltonians are physically independently available.

**New executable:** `Paper1B-ClosureReconciliationExactChecks-v1_1.py`. It passes **41/41 exact checks** (including source freeze, all-group signed contrast, the complete fourth moment, Clifford specialization and all five Lie ranks). The separate `Paper1B-ClosureReconciliationExactControls-v1_1.json` contains the individual dispositions.

## 4. Remaining proof-chain conditions — do not inflate verification status

| Existing root | Reconciliation | What still blocks an unconditional *archived* VERIFIED status |
|---|---|---|
| `BH-IBX-EV-0001` | Exact Petersen holonomy/flux was reproduced in the earlier interrupted closure work | Its standalone current-source verifier was **not saved in the provided current files**; freeze/replay an E3 witness before global promotion |
| `BH-IBX-EV-0002` | 50-vertex total / 25-vertex quotient calculations were reported passing | Same portable E3 evidence limitation |
| `BH-IBX-EV-0003` | `Q8` angular/parity analysis reported passing | Same portable E3 evidence limitation |
| `BH-IBX-EV-0004` | 20D tangent exact sequence and intertwiners reported passing | Same portable E3 evidence limitation |
| `BH-IBX-EV-0005` | Five-root leakage spectra and source-side sums reported passing | Same portable E3 evidence limitation |
| `BH-IBX-EV-0006` | Quadrupole–flux tensor Gram and contraction reported passing | Same portable E3 evidence limitation |
| `BH-IBX-EV-0007` | **Closed by new self-contained exact script** | None within the stated sextic Haar scope |
| `BH-IBX-EV-0008` | **Closed by new self-contained exact script** | None within the stated coordinate-only Lie-algebra scope |
| `BH-IBX-EV-0009` | Several Petersen isometry parts covered by exact five-core and signed-contrast certificates | The printed five-cycle contrast is **wrong**; no declaration that every earlier Petersen/Desargues uniqueness claim now has independent E3 evidence |
| `BH-IBX-EV-0010` | **Current-source F40 claims closed** by Batches 4+5 | Missing historic `v1_10` predecessor remains a provenance note, not a failure of the new proof |
| `BH-IBX-EV-0011` | **Finite 25×24 chamber partition and direct register compression closed** by Batch 3 | Physical action/particle/decay identification remains separately conditional |

The first six entries were **reported closed mathematically during the interrupted work**, and no contradiction to those results has emerged. But the original audit explicitly required **independent exact certificates**. Since their fresh standalone executables are not among the supplied files, this final reconciliation refuses to *pretend they were archived*. Their remaining requirement is **evidence portability**, not a newly discovered mathematical counterexample. Likewise, a self-consistent test of a trial register is not proof of a physical decay source.

## 5. Source text and metadata corrections still required

1. **Mathematical erratum `BH-IBX-MATH-0001`:** in `p1:prop:v343-fivefold-signed-contrast` at source line 15525, replace the class-sum/frame comparison's `+` by `−`, and correct its corresponding proof justification. The exact replacement is proved above. The identity is *currently still incorrect in the source*.
2. **Attribution issue `BH-IBX-SRC-0001`:** Paper I-B v1.8 line 3993 calls its trimer-pair construction a “primary Paper-I-A geometric source”; however the current Paper I-A v5.177 table around lines 414–417 explicitly lists the Hurwitz-link carrier's mathematical owner as **Paper I-B** and summarizes the dimension separately at 5112. Recommend correcting this self-reference in Paper I-B while preserving Paper I-A's legitimate summary table. The mathematical identity `dim_C End(C³)=9` is unchanged.
3. **Metadata `BH-IBX-META-0001`:** the current v1.8 source still carries `\date{Version 1.7 — 14 November 2026 ...}`. Synchronize its document-version label at the later authorized source update; this is not a proof issue.

Suggested exact wording for the second correction (not applied): “This trimer-pair construction, developed in Paper I-B and summarized in Paper I-A, supplies the nine-dimensional geometric carrier.”

## 6. Critical divergent-ZIP branch finding

The archives supplied in the current project are **not a superset** of the previous Paper I-B audit output, despite their higher version numbers:

| Artifact branch | Current Paper I-B evidence present? |
|---|---|
| `Paper00-DAGAtlas-v1_137.zip` (prior I-B output) | Yes: **37** entries in the current I-B audit layer |
| `Paper00-DAGAtlas-v1_139(1).zip` (newer supplied atlas) | **No current I-B audit-layer entries**; it does include the v1.8 source |
| `Paper00-ProofChainAudits-v1_53.zip` (prior I-B output) | Yes: `Paper1B-ExceptionalGeometryProofChainAudit-v1_1.md` |
| `Paper00-ProofChainAudits-v1_54(1).zip` (newer supplied audit archive) | **No current I-B proof-chain audit** |

All four archives opened successfully, and the two newer supplied ZIPs passed full CRC tests. **Branch reconciliation is therefore mandatory**: take the non-I-B current changes from the newer `v1_139`/`v1_54` archives, reconcile and preserve the earlier Paper I-B current-source audit layer and proof-chain document, extend that layer to v1.8's three new objects and this mathematical correction, and validate the resulting claim owners and DAG edges. Merely choosing the numerically highest ZIP would silently drop Paper I-B's audited work. The earlier `BH-IBX-DAG-0001/0002` statuses “resolved in atlas” are true of the **v1_137 branch**, not yet of the supplied **v1_139 branch**.

This final batch **does not perform the merge**. It also does not modify the previous audit statuses (313 verified, 2 conditional, 57 reproduced, 108 formalized for v1.7). In particular the five-cycle proposition was `REPRODUCED` in that ledger; it must be *refuted as printed*, not quietly upgraded along with its neighbors. When authorized to integrate, a new 483-object current-source ledger should record the source sign correction separately from its valid spectral consequences and preserve the three v1.8 additions as two verified mathematical claims plus one scoped remark.

## 7. Read-only reproduction and delivery

Files produced in this **final closure** batch:

- `Paper1B-ClosureDerivationsBatch6-v1_1.md` — this report.
- `Paper1B-ClosureFinalLedger-v1_1.json` — machine-readable per-root adjudications, archive branch checks and source errata.
- `Paper1B-ClosureReconciliationExactChecks-v1_1.py` — self-contained E3/E4 exact checks for the newly certified sextic moments/Lie ranks and source-sign conflict.
- `Paper1B-ClosureReconciliationExactControls-v1_1.json` — `41/41` passing controls with frozen source SHA-256.

Prior **already-produced** exact certificates were replayed successfully during the final reconciliation: octahedral 511/511; F40 spin-two 420/420; F40 native 71/71; chamber/five-core (25×24 plus ranks 16/15/17); five-cycle integer refutation. No verification count is interpreted as a count of independent full theorem proofs.

**Future integration gates (not performed here):** repair the source sign, trimer attribution and version metadata with user authorization; retain the conditional physical scope; record or regenerate portable E3 evidence for earlier findings EV-0001–EV-0006 if strict global VERIFIED statuses are desired; reconcile divergent archive branches; update current-source status ownership; and only then increment versioned manuscripts/DAG/ProofChainAudits archives, checking ZIP contents for latest versions without historical duplicates.

**Bottom line:** the v1.8 additions, 25-register decomposition, F40 mathematical readouts, Hurwitz sextic and all five coordinate Lie dimensions have independent closure certificates. The signed five-cycle *source formula* has an exact counterexample and an exact correction. The remaining problems are source edits and **proof-provenance/integration obligations**, not a demonstrated failure of the surviving finite-geometric constructions. No claim of actualized particle decay physics has been added.
