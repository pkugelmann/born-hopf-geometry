#!/usr/bin/env python3
"""Independent exact quaternionic enumerator: 600-cell D20/Z30 shells, Q8 channels, A5 angular and 61 orbit distance. Current Paper I-B v1.10 EV-0002/0003."""
import importlib.util,contextlib,io,collections,itertools,json,hashlib,pathlib
import networkx as nx
lib=str(pathlib.Path(__file__).with_name('Paper1B-RigorousVerificationBatch1Exact-v1_1.py'))
sp=importlib.util.spec_from_file_location('bh_prev_quat_bank',lib);e=importlib.util.module_from_spec(sp)
with contextlib.redirect_stdout(io.StringIO()):sp.loader.exec_module(e)
Z=e.Z; ONE=e.ONE; R=e.R; add=e.a; sub=e.sub; neg=e.neg; mul=e.mul; scale=e.scale; dot=e.dot; I=e.I; H=e.H; qmul=e.qmul; PHI=e.PHI; invphi=e.INVPHI
Qset=set(I)
assert len(Qset)==120
checks={}
def verify(name,expr,actual=None):
 checks[name]={'passed':bool(expr)}
 if actual is not None:checks[name]['observed']=actual
 if not expr:print('FAIL',name,actual)
 return bool(expr)
def inverse(q):return (q[0], *[neg(x) for x in q[1:]])
def cross(a,b):
 return (sub(mul(a[1],b[2]),mul(a[2],b[1])),sub(mul(a[2],b[0]),mul(a[0],b[2])),sub(mul(a[0],b[1]),mul(a[1],b[0])))
def qscalar(a,b):return dot(a,b) # for full quaternions dot = Re(q^{-1}r)
D=sorted(q for q in I if q[0]==R(1,2)); Zsh=sorted(q for q in I if q[0]==Z)
verify('EV0002_shell_counts', len(D)==20 and len(Zsh)==30,{'D':len(D),'Z':len(Zsh)})
all_graph=nx.Graph();all_graph.add_nodes_from(I)
for q,r in itertools.combinations(I,2):
 if qscalar(q,r)==e.phi_half: all_graph.add_edge(q,r)
verify('EV0002_600_cell_degree12', all(d==12 for _,d in all_graph.degree()),{'vertices':all_graph.number_of_nodes(),'edges':all_graph.number_of_edges(),'degrees':sorted(set(dict(all_graph.degree()).values()))})
GD=all_graph.subgraph(D).copy();GZ=all_graph.subgraph(Zsh).copy();G50=all_graph.subgraph(D+Zsh).copy()
verify('EV0002_dodecahedron', GD.number_of_edges()==30 and all(d==3 for _,d in GD.degree()) and nx.is_isomorphic(GD,nx.dodecahedral_graph()), {'vertices':len(D),'edges':GD.number_of_edges()})
# Total-graph map: every D edge -> midpoint in Z
mid={};mdata={}; Zset=set(Zsh)
for a,b in GD.edges():
 w=a[1:];z=b[1:];mm=tuple(mul(invphi,add(x,y)) for x,y in zip(w,z));md=(Z,*mm)
 dd=tuple(mul(PHI,sub(x,y)) for x,y in zip(w,z));kk=tuple(scale(2,x) for x in cross(w,z))
 dquat=(Z,*dd);kquat=(Z,*kk)
 mid[frozenset((a,b))]=md
 mdata[frozenset((a,b))]=(md,dquat,kquat)
verify('EV0002_edge_to_midpoint_bijection',len(mid)==30 and set(mid.values())==Zset,{'midpoints':len(mid),'unique':len(set(mid.values()))})
verify('EV0003_midpoint_Q8_membership', all(all(x in Zset for x in data) for data in mdata.values()))
verify('EV0003_midpoint_Q8_product',all(qmul(m,d)==(Z,*[neg(x) for x in k[1:]]) and qmul(d,m)==k and qmul(m,m)==(R(-1),Z,Z,Z) for m,d,k in mdata.values()))
# Source total graph: D-D, Z-Z line graph of D, D-Z incidence
idx_by_mid={v:k for k,v in mid.items()}
expected=nx.Graph();expected.add_nodes_from(D+Zsh)
expected.add_edges_from(GD.edges())
for a,b in itertools.combinations(Zsh,2):
 if idx_by_mid[a]&idx_by_mid[b]:expected.add_edge(a,b)
for edge,m in mid.items():
 for vertex in edge:expected.add_edge(vertex,m)
verify('EV0002_induced_total_graph',nx.utils.graphs_equal(expected,G50), {'induced_edges':G50.number_of_edges(),'expected_edges':expected.number_of_edges(),'regular_degree_set':sorted({d for _,d in G50.degree()})})
# inversion quotient, 61 orbits globally, 25 in D/Z
classkey=lambda q:min(q,inverse(q))
orb={classkey(q) for q in I}
verify('EV0003_full_61_orbit_quotient',len(orb)==61,len(orb))
Q=nx.Graph(); Q.add_nodes_from(orb)
for a,b in all_graph.edges():
 if classkey(a)!=classkey(b):Q.add_edge(classkey(a),classkey(b))
Q25=G50.copy();verts25={classkey(q) for q in D+Zsh}; CQ=nx.Graph();CQ.add_nodes_from(verts25)
for a,b in G50.edges():
 if classkey(a)!=classkey(b):CQ.add_edge(classkey(a),classkey(b))
verify('EV0002_quotient_total_graph_25_75',CQ.number_of_nodes()==25 and CQ.number_of_edges()==75,{'nodes':CQ.number_of_nodes(),'edges':CQ.number_of_edges()})
P10=nx.Graph();P10.add_nodes_from({classkey(q) for q in D});P10.add_edges_from((classkey(a),classkey(b)) for a,b in GD.edges())
verify('EV0002_dodecahedron_to_Petersen_10_15',nx.is_isomorphic(P10,nx.petersen_graph()),{'nodes':P10.number_of_nodes(),'edges':P10.number_of_edges()})
# exact 4 angular bins / quotient shortest distances, per 10 C6 projective axes against 15 Z projective order4 channels.
# square 3|u dot m|^2=4 (w dot m)^2; equals phi^2,1,(phi-1)^2,0.
expected_angles={'incident':mul(PHI,PHI),'near':R(1),'cross_B':mul(invphi,invphi),'cross_A':Z}
target_dist={'incident':1,'near':2,'cross_B':2,'cross_A':3}
seen_counts=[];dist_controls=[]
for src in sorted({classkey(q) for q in D}):
 w=src[1:]
 hist=collections.Counter(); detailed={}
 distances=nx.single_source_shortest_path_length(Q,src)
 for tgt in sorted({classkey(q) for q in Zsh}):
  m=tgt[1:];val=scale(4,mul(dot(w,m),dot(w,m)))
  cats=[name for name,x in expected_angles.items() if val==x]
  if len(cats)!=1:print('FAIL ANGLE',val);raise SystemExit(1)
  hist[cats[0]]+=1
  detailed[cats[0]]=distances[tgt]
  dist_controls.append((cats[0],distances[tgt]))
 seen_counts.append(hist)
verify('EV0003_four_angular_classes',all(h=={'incident':3,'near':6,'cross_B':3,'cross_A':3} for h in seen_counts),{'per_axis':dict(seen_counts[0])})
verify('EV0003_angular_orbit_distances',all(d==target_dist[t] for t,d in dist_controls),{'angle_distance_sets':{k:sorted(set(d for t,d in dist_controls if t==k)) for k in target_dist}})
# Full realized binary-icosahedral conjugation action: group orbits on the 150 axis-channel pairs.
# This checks the A5-transitivity claim, not merely the four angular histograms.
axis_orbits=sorted({classkey(q) for q in D})
channel_orbits=sorted({classkey(q) for q in Zsh})
all_pairs=set(itertools.product(axis_orbits,channel_orbits))
classifications={}
for a,c in all_pairs:
 val=scale(4,mul(dot(a[1:],c[1:]),dot(a[1:],c[1:])))
 classifications[(a,c)]=next(n for n,v in expected_angles.items() if val==v)
actions={}
for g in I:
 gi=inverse(g)
 actions[g]={u:classkey(qmul(qmul(g,u),gi)) for u in axis_orbits+channel_orbits}
remaining=set(all_pairs); orbit_sizes=[]; orbit_angles=[]
while remaining:
 seed=min(remaining)
 part={(actions[g][seed[0]],actions[g][seed[1]]) for g in I}
 assert part<=remaining and all(classifications[x]==classifications[seed] for x in part)
 orbit_sizes.append(len(part));orbit_angles.append(classifications[seed]);remaining-=part
verify('EV0003_exact_A5_four_pair_orbits',sorted(orbit_sizes)==[30,30,30,60] and collections.Counter(orbit_angles)=={'incident':1,'near':1,'cross_B':1,'cross_A':1}, {'orbits':dict(zip(orbit_angles,orbit_sizes))})
# every Q8 triple from a dodecahedral edge sits in one of five H conjugates.
subgroups={frozenset(qmul(qmul(g,h),inverse(g)) for h in H) for g in I}
verify('EV0003_five_tetrahedral_cores',len(subgroups)==5,len(subgroups))
projective_channels={classkey(q) for q in Zsh}
channel_parts=[{classkey(q) for q in G if q[0]==Z} for G in subgroups]
verify('EV0003_3x5_core_Q8_channels',len(projective_channels)==15 and all(len(g)==3 for g in channel_parts) and len(set.union(*channel_parts))==15 and sum(len(g) for g in channel_parts)==15, {'core_axes':[len(g) for g in channel_parts]})
verify('EV0003_all_edge_Q8_subgroup_owner', all(any({m,d,k}.issubset(g) for g in subgroups) for m,d,k in mdata.values()), {'edges':len(mdata)})
# 20 dodecahedral edge-star K4 tetrahedra have pairwise 600 edge adjacency.
tetra=[]
for v in D:
 Q4=[v,*[mid[frozenset((v,w))] for w in GD.neighbors(v)]]
 if len(Q4)!=4:raise AssertionError('degree error')
 tetra.append(all(all_graph.has_edge(a,b) for a,b in itertools.combinations(Q4,2)))
verify('EV0002_20_regular_tetrahedra',all(tetra),{'tetrahedra':len(tetra)})
fail=[k for k,v in checks.items() if not v['passed']]
out={'source':'Paper1B-ExceptionalGeometry-v1_10.tex', 'issues':['BH-IBX-EV-0002','BH-IBX-EV-0003'],'independence':'Reconstructed from exact raw 2I quaternion group, not prior 600-shell result','checks':checks,'failed':fail,'source_script_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()}
p=pathlib.Path(__file__).with_name('Paper1B-RigorousVerificationBatch2QuaternionResults-v1_1.json');p.write_text(json.dumps(out,indent=2))
print(json.dumps({'failed':fail,'pass_count':len(checks)-len(fail),'highlights':{'D':len(D),'Z':len(Zsh),'600_edges':all_graph.number_of_edges(),'50_edges':G50.number_of_edges(),'25_edges':CQ.number_of_edges(),'angular':checks['EV0003_four_angular_classes']}},indent=2))
if fail:raise SystemExit(1)
