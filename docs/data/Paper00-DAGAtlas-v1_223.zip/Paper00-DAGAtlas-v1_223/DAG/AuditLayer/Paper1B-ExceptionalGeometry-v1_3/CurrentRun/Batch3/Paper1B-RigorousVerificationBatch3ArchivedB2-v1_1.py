#!/usr/bin/env python3
"""Independent exact controls for Born--Hopf Paper I-B Exceptional Geometry v1.7,
source lines 1914--4599. Pure verification, not framework modification.
"""
import itertools, json, hashlib, collections, math, os
import sympy as S
from fractions import Fraction
from pathlib import Path
root=Path(__file__).parent
src=root/'Paper1B-ExceptionalGeometry-v1_10.tex'
source_hash=hashlib.sha256(src.read_bytes()).hexdigest()
checks=[]
def ck(tag,actual,expected,domain='',method='exact algebra'):
    good=bool(actual==expected)
    checks.append(dict(id=tag,passed=good,actual=str(actual)[:700],expected=str(expected)[:700],domain=domain,method=method))
    if not good:print('FAIL',tag, actual,expected)
    return good
I=S.eye(3);J=S.ones(3);z=S.Rational(1,2)
# Exact A5 permutation action, icosahedral readout plane and five-cell projectors.
x0=S.Matrix([1,0,0,0,0]); outer=S.Matrix([0,z,z,z,z]); ug=(x0+2*outer)/S.sqrt(5); vc=(2*x0-outer)/S.sqrt(5)
ck('P2-ICO-01',S.simplify(ug.dot(ug)),1,'1950--2176')
ck('P2-ICO-02',S.simplify(vc.dot(vc)),1,'1970--2176')
ck('P2-ICO-03',S.simplify(ug.dot(vc)),0,'1970--2176')
T5=(S.ones(5)-S.eye(5))/4
Pg=S.ones(5)/5; Pc=S.eye(5)-Pg
ck('P2-ICO-04',T5.eigenvals(),{S.Integer(1):1,-S.Rational(1,4):4},'2017--2176')
ck('P2-ICO-05',Pg**2,Pg,'2024--2176')
ck('P2-ICO-06',Pc**2,Pc,'2024--2176')
ck('P2-ICO-07',Pg*vc,S.zeros(5,1),'2024--2176')
up=(x0+outer)/S.sqrt(2); um=(x0-outer)/S.sqrt(2)
ck('P2-ICO-08',S.simplify((3*ug+vc)/S.sqrt(10)-up),S.zeros(5,1),'2120--2176')
ck('P2-ICO-09',S.simplify((-ug+3*vc)/S.sqrt(10)-um),S.zeros(5,1),'2120--2176')
ck('P2-ICO-10',S.simplify((up.dot(ug))**2),S.Rational(9,10),'2178--2180')
# Explicit real projection onto one fixed outer cell and its three-cycle.
uc=S.Matrix([0,3,-1,-1,-1])/(2*S.sqrt(3))
ck('P2-TRI5-01',S.simplify(uc.dot(uc)),1,'2223--2325')
ck('P2-TRI5-02',S.simplify(uc.dot(outer)),0,'2223--2325')
projected=S.eye(5)-up*up.T-um*um.T-uc*uc.T
ck('P2-TRI5-03',(projected**2).applyfunc(S.simplify),projected.applyfunc(S.simplify),'2223--2325')
ck('P2-TRI5-04',projected.rank(),2,'2223--2325')
# Exceptional group conjugacy height distributions. Source 2T,2O groups and 600-cell exact shell.
t=S.symbols('t')
s2=S.sqrt(2);s5=S.sqrt(5);phi=(1+s5)/2
Tcounts={S.Integer(1):1,S.Integer(-1):1,S.Integer(0):6,S.Rational(1,2):8,S.Rational(-1,2):8}
Ocounts={S.Integer(1):1,S.Integer(-1):1,S.Integer(0):18,S.Rational(1,2):8,S.Rational(-1,2):8,s2/2:6,-s2/2:6}
# Coordinates of 600-cell as integer a+b sqrt(5), unit = /4. Valid even permutations.
axis=[]
for j in range(4):
 for sg in (1,-1):
  v=[(0,0)]*4;v[j]=(4*sg,0);axis.append(tuple(v))
half=list(itertools.product([-2,2],repeat=4))
centers=[tuple((x,0) for x in v) for v in half]
perm4=[p for p in itertools.permutations(range(4)) if sum(p[i]>p[j] for i in range(4) for j in range(i+1,4))%2==0]
base=((0,0),(2,0),(1,1),(-1,1))
golden=[]
for p in perm4:
 v=[base[p[i]] for i in range(4)]
 for sg in itertools.product([-1,1],repeat=3):
  w=iter(sg)
  golden.append(tuple((a*(sgn:=next(w)),b*sgn) if (a,b)!=(0,0) else (0,0) for a,b in v))
verts=axis+centers+golden
ck('P2-I600-01',len(verts),120,'2538--2585')
ck('P2-I600-02',len(set(verts)),120,'2538--2585')
def fieldadd(x,y):return (x[0]+y[0],x[1]+y[1])
def fieldmul(x,y):return (x[0]*y[0]+5*x[1]*y[1],x[0]*y[1]+x[1]*y[0])
def normnum(v):
 out=(0,0)
 for x in v:out=fieldadd(out,fieldmul(x,x))
 return out
ck('P2-I600-03',set(map(normnum,verts)),{(16,0)},'2538--2585')
# real part = a/4+b/4 sqrt5 exact
height_counts=collections.Counter((v[0][0],v[0][1]) for v in verts)
ck('P2-I600-04',height_counts[(4,0)],1,'2538--2585')
ck('P2-I600-05',height_counts[(-4,0)],1,'2538--2585')
ck('P2-I600-06',height_counts[(0,0)],30,'2538--2585')
ck('P2-I600-07',height_counts[(2,0)],20,'2538--2585')
ck('P2-I600-08',height_counts[(-2,0)],20,'2538--2585')
ck('P2-I600-09',height_counts[(1,1)],12,'2538--2585')
ck('P2-I600-10',height_counts[(-1,-1)],12,'2538--2585')
ck('P2-I600-11',height_counts[(-1,1)],12,'2538--2585')
ck('P2-I600-12',height_counts[(1,-1)],12,'2538--2585')
Ic={S.simplify((S.Integer(a)+b*s5)/4):c for (a,b),c in height_counts.items()}
ck('P2-I600-13',sum(Ic.values()),120,'2538--2585')
# Chord squared at top positive height (1+sqrt5)/4 = phi/2
ck('P2-I600-14',S.simplify(2-2*phi/2-phi**(-2)),0,'2572--2585')
# Invariant ring Molien series calculated independently from finite SU2 trace-angle bins.
for group,counts,n,den in [
 ('2T',Tcounts,24,(1-t**24)/((1-t**6)*(1-t**8)*(1-t**12))),
 ('2O',Ocounts,48,(1-t**36)/((1-t**8)*(1-t**12)*(1-t**18))),
 ('2I',Ic,120,(1-t**60)/((1-t**12)*(1-t**20)*(1-t**30)))]:
 ck(f'P2-MOL-{group}-SIZE',sum(counts.values()),n,'2844--2879')
 mol=sum(S.Integer(k)/(1-2*h*t+t*t) for h,k in counts.items())/n
 eq=S.cancel(S.together(mol-den),extension=True)
 ck(f'P2-MOL-{group}-FORMULA',eq,0,'2844--2879','exact SU2 trace-class Molien formula')
# D4 orthogonal map, Hurwitz vertices graph, exact shell counts.
root_h=[]
for j in range(4):
 for sign in [-1,1]:
  v=[0]*4;v[j]=sign;root_h.append(tuple(map(S.Rational,v)))
for signs in itertools.product([-1,1],repeat=4):root_h.append(tuple(S.Rational(x,2) for x in signs))
ck('P2-H24-01',len(set(root_h)),24,'3000--3180')
B=S.Matrix([[1,1,0,0],[1,-1,0,0],[0,0,1,1],[0,0,1,-1]])
ck('P2-H24-02',B.T*B,2*S.eye(4),'3050--3097')
actual_roots={tuple(B*S.Matrix(v)) for v in root_h}
expected_roots=set()
for i,j in itertools.combinations(range(4),2):
 for a,b in itertools.product([-1,1],repeat=2):
  v=[0]*4;v[i]=a;v[j]=b; expected_roots.add(tuple(v))
ck('P2-H24-03',actual_roots,expected_roots,'3050--3097')
base4=S.Matrix([1,0,0,0]);ndist=collections.Counter([S.simplify((S.Matrix(v)-base4).dot(S.Matrix(v)-base4)) for v in root_h]);
ck('P2-H24-04',ndist,{0:1,1:8,2:6,3:8,4:1},'3110--3180')
ck('P2-H24-05',sum(1 for v in root_h if S.simplify((S.Matrix(v)-base4).dot(S.Matrix(v)-base4))==1),8,'3020--3048')
# Each link triple adjacency and induced cycle of length 6
signs=list(itertools.product([-1,1], repeat=3))
def hamming(a,b):return sum(x!=y for x,y in zip(a,b))
ck('P2-CUBE-01',len(signs),8,'3213--3243')
ck('P2-CUBE-02',len([(a,b) for a,b in itertools.combinations(signs,2) if hamming(a,b)==1]),12,'3213--3243')
rem=[v for v in signs if v not in [(1,1,1),(-1,-1,-1)]]
ck('P2-CUBE-03',len(rem),6,'3393--3431')
ck('P2-CUBE-04',len([(a,b) for a,b in itertools.combinations(rem,2) if hamming(a,b)==1]),6,'3393--3431')
ck('P2-CUBE-05',sorted([sum(hamming(a,b)==1 for b in rem) for a in rem]),[2]*6,'3809--3845')
# signed twisted group algebra: associative cocycle, squares, anti-commutators
bits=list(itertools.product([0,1],repeat=3))
def plus(a,b):return tuple((x+y)%2 for x,y in zip(a,b))
def sig(a,b):return (-1)**(sum(a[i]*b[i] for i in range(3))+sum(a[i]*b[j] for i in range(3) for j in range(i)))
ck('P2-CL03-01',all(sig(a,b)*sig(plus(a,b),c)==sig(b,c)*sig(a,plus(b,c)) for a,b,c in itertools.product(bits,repeat=3)),True,'3245--3324','exact exhaustive F2 cocycle check, 512 triples')
ck('P2-CL03-02',all(sig(e,e)==-1 for e in [(1,0,0),(0,1,0),(0,0,1)]),True,'3245--3324')
ck('P2-CL03-03',all(sig(e,f)==-sig(f,e) for e,f in itertools.permutations([(1,0,0),(0,1,0),(0,0,1)],2)),True,'3245--3324')
ck('P2-CL03-04',2**3,8,'3245--3324')
ck('P2-CL03-05',2**3*(2**3-1),56,'3326--3368')
# exact trimer vectors and quaternionic orthogonality in real R4.
vec=lambda signs:S.Matrix([S.Rational(1,2)]+[S.Rational(x,2) for x in signs])
Tplus=[(-1,1,1),(1,-1,1),(1,1,-1)];Tminus=[(1,-1,-1),(-1,1,-1),(-1,-1,1)]
frames=[vec((1,1,1))]+[vec(t) for t in Tminus]
F=S.Matrix.hstack(*frames)
ck('P2-QFR-01',F.T*F,S.eye(4),'3432--3510')
ck('P2-QFR-02',all((a.dot(b)==S.Rational(1,2)) for a,b in zip(map(vec,Tplus),map(vec,Tminus))),False,'3432--3510','adversarial: root-involution pairs are not closest')
Lplus=S.Matrix.hstack(*map(vec,Tplus));Lminus=S.Matrix.hstack(*map(vec,Tminus))
a_plus=vec((1,1,1));a_minus=vec((-1,-1,-1));
ck('P2-OVL-01',Lplus.T*Lplus,S.eye(3),'3512--3599')
ck('P2-OVL-02',Lminus.T*Lminus,S.eye(3),'3512--3599')
ck('P2-OVL-03',Lplus.T*Lminus,J/2-I,'3512--3599')
ck('P2-OVL-04',Lplus*Lplus.T,S.eye(4)-a_minus*a_minus.T,'3512--3599')
ck('P2-OVL-05',Lminus*Lminus.T,S.eye(4)-a_plus*a_plus.T,'3512--3599')
ck('P2-OVL-06',(J-I)*(J/2-I),S.eye(3),'3512--3599')
ck('P2-OVL-07', (S.diag(1,-1,-1,-1)*Lplus),Lminus,'3512--3599')
# Exact 2x2 minors compute induced exterior Gram (cofactor matrix) of K_V.
K=J/2-I
idx=[(1,2),(2,0),(0,1)]
K2=S.Matrix(3,3,lambda a,b:S.det(S.Matrix([[K[idx[a][0],idx[b][0]],K[idx[a][0],idx[b][1]]],[K[idx[a][1],idx[b][0]],K[idx[a][1],idx[b][1]]]])))
ck('P2-EXT-01',K2,(J-I)/2,'3607--3659')
ck('P2-EXT-02',K*K2,S.eye(3)/2,'3607--3659')
q0=J/3;qp=S.eye(3)-q0
ck('P2-EXT-03',K.T*K,q0/4+qp,'3607--3659')
ck('P2-EXT-04',K2.T*K2,q0+qp/4,'3607--3659')
# 3D project geometry, 24-cell dot, prism matching cycle, D3.
u=S.Matrix([1,1,1])/S.sqrt(3)
P3=S.eye(3)-u*u.T
vec3=lambda x:S.Matrix(x)/S.sqrt(3)
projected6=[P3*vec3(x) for x in rem]
ck('P2-HEX-01',set(S.simplify(v.dot(v)) for v in projected6),{S.Rational(8,9)},'3675--3713')
ck('P2-HEX-02',set(S.simplify(abs(vec3(x).dot(u))) for x in rem),{S.Rational(1,3)},'3675--3713')
# sign cube nearest perfect matchings between trimer sets
bipart=[[(a,b) for b in Tminus if hamming(a,b)==1] for a in Tplus]
matchings=[p for p in itertools.permutations(Tminus) if all(hamming(a,b)==1 for a,b in zip(Tplus,p))]
ck('P2-PRISM-01',len(matchings),2,'3714--3742')
ck('P2-PRISM-02',all(hamming(a,b)==3 for a,b in zip(Tplus,Tminus)),True,'3714--3742','adversarial: root involution pairs opposite, not nearest')
# Hermitian trimer transport, exact 5D real independence and trace weights.
X=S.Matrix([[0,0,1],[1,0,0],[0,1,0]]);D1=S.diag(S.Rational(2,3),-S.Rational(1,3),-S.Rational(1,3)); D2=S.diag(0,1,-1)
C1=X+X.T;C2=-S.I*(X-X.T)
vec9=lambda M: S.Matrix([M[i,j] for i in range(3) for j in range(3)])
Q=S.Matrix.hstack(*map(vec9,[S.eye(3),D1,D2,C1,C2]))
ck('P2-HER-01',Q.rank(),5,'3909--3964')
ck('P2-HER-02',X**3,S.eye(3),'3909--3964')
ck('P2-HER-03',D1.trace(),0,'4011--4067')
ck('P2-HER-04',(D1*D1).trace(),S.Rational(2,3),'4011--4067')
ck('P2-HER-05',(D2*D2).trace(),2,'4011--4067')
ck('P2-HER-06',(D1*D2).trace(),0,'4011--4067')
ck('P2-HER-07',((D1+D2)**2).trace(),S.Rational(8,3),'4011--4067')
ck('P2-HER-08',(S.eye(3)/3)**2 * 3,S.eye(3)/3,'4011--4067')
ck('P2-HER-09',S.Rational(1,8)*S.Rational(1,7),S.Rational(1,56),'4139--4165')
ck('P2-HER-10',S.Rational(1,8)*S.Rational(1,9),S.Rational(1,72),'4139--4165')
# Exact rank-one determinant/tracial exponent model
xx=S.symbols('x',positive=True);proj=S.diag(1,*[0]*7);DX=S.eye(8)+(xx-1)*proj
ck('P2-DET8-01',DX.det(),xx,'4104--4135')
ck('P2-DET8-02',DX.eigenvals(),{xx:1,S.Integer(1):7},'4104--4135')
ck('P2-DET8-03',S.simplify(S.exp(S.log(xx)/8)-xx**S.Rational(1,8)),0,'4104--4135')
# common two-quaternion twist action onto U(2): kernel must be diagonal signs, not full direct product.
ck('P2-HOPF-01',8-1,7,'4412--4483')
ck('P2-HOPF-02',2*2-2,2,'4412--4483','kernel sign order and dimension of U2 quotient')
ck('P2-HOPF-03',8*7,56,'4522--4582')
ck('P2-HOPF-04',list(range(0,57,8)),[0,8,16,24,32,40,48,56],'4522--4582')
# Coxeter dihedral independent exact expressions, from Coxeter-Schlafli vertex figure cosine formula.
ck('P2-COX-01',S.cos(2*S.pi/3),-S.Rational(1,2),'4177--4206')
ck('P2-COX-02',S.cos(4*S.pi/5),-(1+s5)/4,'4177--4206')
# note 600-cell cosine of 164.478... degrees approximates -(1+3 sqrt5)/8
ang600=S.acos(-(1+3*s5)/8)*180/S.pi
ck('P2-COX-03',abs(float(ang600)-164.478)<0.001,True,'4177--4206','high precision against exact Coxeter formula')
# normalization of covering q*S3 -> S3/Gamma: pullback squared norm multiplies degree
for d in (24,48,120):ck(f'P2-COV-{d}',S.simplify(S.Rational(1,d)*d),1,'4319--4360')
# Difference between left and right Hopf fiber preservation for nonnormal left deck groups.
ck('P2-HOPF-05',len([x for x in root_h if x[0] in (1,-1)]),2,'4386--4388','left circle intersection with 2T not entire group')

# Independent permutation-group / stabilizer certificates rather than only invoking known names.
def comp(p,q):return tuple(p[q[i]] for i in range(len(p)))
def inv(p):return tuple(p.index(i) for i in range(len(p)))
def parity(p):return (-1)**sum(p[i]>p[j] for i in range(len(p)) for j in range(i+1,len(p)))
def perm_group(n,even=False):return [p for p in itertools.permutations(range(n)) if not even or parity(p)==1]
def closure(generators,n):
 e=tuple(range(n));seen={e};todo=[e]
 while todo:
  a=todo.pop()
  for b in generators:
   c=comp(a,b)
   if c not in seen:seen.add(c);todo.append(c)
 return seen
G4=perm_group(4,True);G24=perm_group(4);G5=perm_group(5,True)
ck('P2-PERM-01',(len(G4),len(G24),len(G5)),(12,24,60),'2468--2508')
for name,g in [('A4',G4),('S4',G24),('A5',G5)]:
 n=len(g[0]);cs={comp(comp(comp(p,q),inv(p)),inv(q)) for p,q in itertools.product(g,repeat=2)}
 cg=closure(cs,n)
 ck(f'P2-PERM-COMM-{name}',len(cg),{'A4':4,'S4':12,'A5':60}[name],'2468--2508')
# 3-cycles act on four outer cells (of A5) with one fixed + one orbit of three.
H5=[p for p in G5 if p[0]==0]
ck('P2-PERM-05',len(H5),12,'1970--2163')
ck('P2-PERM-06', {len({p[x] for p in H5}) for x in [1,2,3,4]}, {4},'1970--2163')
# There are six elements of projective order 3 in A4, fixing a unique of the four outer cells.
three=[p for p in H5 if p!=tuple(range(5)) and comp(comp(p,p),p)==tuple(range(5))]
ck('P2-PERM-07',len(three),8,'2223--2325')
ck('P2-PERM-08',set(sum(p[x]==x for x in range(1,5)) for p in three),{1},'2223--2325')
# Every order-3 element of A5 has two fixed points, so belongs to some A4 point stabilizer.
A5triple=[p for p in G5 if p!=tuple(range(5)) and comp(comp(p,p),p)==tuple(range(5))]
ck('P2-PERM-09',len(A5triple),20,'2759--2801')
ck('P2-PERM-10',set(sum(p[x]==x for x in range(5)) for p in A5triple),{2},'2759--2801')
# 24 rotational symmetries of cube are signed permutations with determinant +1.
signed_rot=[]
for p in itertools.permutations(range(3)):
 for sgn in itertools.product([-1,1],repeat=3):
  if parity(p)*math.prod(sgn)==1:
   signed_rot.append((p,sgn))
def act(rot,v):
 p,sgn=rot;return tuple(sgn[i]*v[p[i]] for i in range(3))
diags={tuple(sorted((v,tuple(-x for x in v)))) for v in signs}
rep_axis=tuple(sorted(((1,1,1),(-1,-1,-1))))
stab=[r for r in signed_rot if tuple(sorted((act(r,(1,1,1)),act(r,(-1,-1,-1)))))==rep_axis]
orient=[r for r in signed_rot if act(r,(1,1,1))==(1,1,1)]
ck('P2-CUBESYM-01',len(signed_rot),24,'3744--3807')
ck('P2-CUBESYM-02',len(diags),4,'3744--3807')
ck('P2-CUBESYM-03',len(stab),6,'3744--3807')
ck('P2-CUBESYM-04',len(orient),3,'3744--3807')
ck('P2-CUBESYM-05',len({act(r,(1,1,1)) for r in signed_rot}),8,'3744--3807')
# Stabilizer of a projective three-cycle in S4 has order six and index four.
p3=(1,2,0,3);c3=closure([p3],4)
normalizer=[g for g in G24 if {comp(comp(g,h),inv(g)) for h in c3}==c3]
ck('P2-S4NORMAL-01',len(c3),3,'3764--3807')
ck('P2-S4NORMAL-02',len(normalizer),6,'3764--3807')
# Full automorphism of elementary rank-three F2 has no invariant proper nonempty character subset.
nonzero=[v for v in bits if v!=(0,0,0)]
def det_mod2(m):return int(S.Matrix(m).det())%2
GL3=[rows for rows in itertools.product(bits,repeat=3) if det_mod2(rows)==1]
def act2(mat,v):return tuple(sum(mat[i][j]*v[j] for j in range(3))%2 for i in range(3))
ck('P2-GL3-01',len(GL3),168,'3369--3381')
ck('P2-GL3-02',len({act2(m,(1,0,0)) for m in GL3}),7,'3369--3381')


# Full multiplication closure and conjugacy on 600-cell coordinates in Q(sqrt 5).
# Coordinates stored as (a+b sqrt5)/4; exact integer-pair arithmetic, no float tolerance.
def fneg(x):return (-x[0],-x[1])
def fsub(x,y):return (x[0]-y[0],x[1]-y[1])
def qmul(a,b):
 t00=fieldmul(a[0],b[0]);t11=fieldmul(a[1],b[1]);t22=fieldmul(a[2],b[2]);t33=fieldmul(a[3],b[3])
 res=(fsub(fsub(fsub(t00,t11),t22),t33),
      fieldadd(fsub(fieldadd(fieldmul(a[0],b[1]),fieldmul(a[1],b[0])),fieldmul(a[3],b[2])),fieldmul(a[2],b[3])),
      fieldadd(fsub(fieldadd(fieldmul(a[0],b[2]),fieldmul(a[2],b[0])),fieldmul(a[1],b[3])),fieldmul(a[3],b[1])),
      fieldadd(fsub(fieldadd(fieldmul(a[0],b[3]),fieldmul(a[3],b[0])),fieldmul(a[2],b[1])),fieldmul(a[1],b[2])))
 if any(x%4 or y%4 for x,y in res):raise ValueError('nonintegral quaternion group coordinate')
 return tuple((x//4,y//4) for x,y in res)
def qinv(a):return (a[0],)+tuple(fneg(x) for x in a[1:])
V=set(verts);e=((4,0),(0,0),(0,0),(0,0));neg_e=((-4,0),(0,0),(0,0),(0,0))
ck('P2-GRP600-01',all(qmul(a,b) in V for a in V for b in V),True,'2538--2704','exhaustive exact 14400 2I products')
ck('P2-GRP600-02',all(qmul(a,qinv(a))==e for a in V),True,'2538--2704')
shell={v for v in V if v[0]==(1,1)}
chosen=next(iter(shell))
orbit={qmul(qmul(g,chosen),qinv(g)) for g in V}
ck('P2-GRP600-03',len(shell),12,'2538--2570','exact quaternion nearest shell set')
ck('P2-GRP600-04',orbit,shell,'2538--2570','full conjugacy orbit, not only eigenheight counts')
# For 2I commutator subgroup, enough to obtain all elements from explicit commutators.
comm={qmul(qmul(qmul(a,b),qinv(a)),qinv(b)) for a,b in itertools.product(V,repeat=2)}
ck('P2-GRP600-05',all(x in V for x in comm),True,'2468--2508')
# closure on all available commutators; a handful of generators are sufficient when breadth-first growth reaches 120.
comm_generators=[];gen_sub={e}
for x in sorted(comm):
 if x in gen_sub:continue
 comm_generators.append(x)
 gspan={e};stack=[e]
 while stack:
  q=stack.pop()
  for c in comm_generators:
   prod=qmul(q,c)
   if prod not in gspan:gspan.add(prod);stack.append(prod)
 gen_sub=gspan
 if len(gspan)==120:break
ck('P2-GRP600-06',len(gen_sub),120,'2468--2508','exact 2I perfectness from commutators')

result={
 'meta':{'source_file':src.name,'source_sha256':source_hash,'batch_source_lines':[1914,4599],
 'verification_scope':'exact local E3/E4 controls of explicitly claimed finite and algebraic identities; imported geometry/classification results require source-specific qualifications',
 'not_a_physical_selector':True,'framework_source_modified':False,
 'script':Path(__file__).name,
 'CAVEAT':'Passing finite tests proves the tested identities, not all logical and physical conclusions or imported literature claims.'},
 'totals':{'checks':len(checks),'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks)},'checks':checks,
 'external_crosschecks':[
  {'claim':'Coxeter cell dihedral angles','url':'https://gregegan.net/SCIENCE/Dihedral/Dihedral.html','role':'independent formula and tabulation; no PDF parsed'},
  {'claim':'maximal Hurwitz quaternion order unique up to conjugation','url':'https://www.math.mcgill.ca/darmon/pub/Articles/Research/36.NSF-CBMS/chapter.pdf','role':'Theorem 6.12 reference; no PDF required for identity controls'}]
}
out=root/'Batch3ReplayArchivedB2Results-v1_1.json'
out.write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf8')
print('RESULT',result['totals'],'output',out)
if result['totals']['failed']:exit(1)
