# Paper I-B rigorous verification — Batch 6 (final inherited block)

- **Protocol:** Paper00-RigorousVerificationDAGWorkProtocol-v2_4 (source-first, E0/E1/E3/E4)
- **Frozen current source:** `Paper1B-ExceptionalGeometry-v1_10.tex` (SHA-256 `e02e868b02dc3e22bbfae8b4563d7586646f2dc0f215145674dff5fea10854d5`), from the supplied Papers Minimal v3.018 ZIP.
- **Selected target:** exactly Paper I-B; no modifications to original source or proof statements.
- **Coverage:** original inherited claims 401–483; 83 of 83 source-bound, final cumulative 506 of 506 formal claims after inclusion of 23 new v1.10 statements.

## Adjudicated status counts

| Status | Claims | Scope |
|---|---:|---|
| VERIFIED (historical certificate retained) | 36 | Source-identical proofs; no automatic wider claim |
| REPRODUCED (not promoted) | 26 | Exact checks support finite subclaims; imported theorem or broad uniqueness obligation remains |
| FORMALIZED | 19 | Definitions, remarks and scope/owner distinctions |
| VERIFIED-CONDITIONAL | 2 | The 600-chamber register resolvent and resistance results retain their hypothesis/evidence restrictions |
| **Total** | **83** | **No newly established counterexample** |

## Tests and source reconciliation

- **83/83** inherited claims exactly match prior statements and proofs after established normalization; no proof text changes in current v1.10.
- The earlier self-contained certificate replay records contain **19,687 claim-linked controls** from the historical Batch 6/7 suites; they passed in Batch 4's archived-replay execution. Those are inherited evidence, not a newly independent source of proof.
- **2145/2145 new independently implemented finite exact controls passed**, covering **21** distinct source claims. The audit script avoids trivial checks that merely repeat the asserted count as the expected count.
- All 52 of 54 distinct source-internal references resolve; **2** labels require a cross-paper/import owner check: p1:thm:general-left-invariant-hodge-dirac-compiler, p1c:prop:v370-e8-finite-certificate.

## High-dependency results independently tested

1. **Dual-Hurwitz incidence and Fourier decomposition** (401–402). Independent 24-cell vertices and 24 dual normals; all 576 signed incidences, 8-neighbor profiles, the singular rank 1+4+9 decomposition and complementary 10 dimensions.
2. **Cross-core pentagonal incidence** (405). Independent even-permutation A5 enumeration, distinct A4 stabilizers, rank-three cross-core kernel and lifted 24×24 spectral data.
3. **Kleinian, Seifert and McKay** (414, 418, 437). Exact ADE weighted degrees and Milnor counts, Seifert Euler/first-homology/spin counts, affine-Cartan eigen/Green controls. These do not independently establish the imported derived McKay equivalence.
4. **Spectral eta and modular arithmetic** (436, 464, 475). Exact binary-polyhedral height sums, defining-flat-doublet rho arithmetic, finite-double T trace sequences. Do not promote the general all-twist or nontrivial global torsion statements from these tests.
5. **600-chamber register and source-resistance** (469–470). Exact finite register symmetric-resistance identities tested where specified; the previously certified conditional 600×25 chamber partition/eigen-decomposition remains a distinct proof obligation.
6. **Anisotropic and quartic response boundaries** (479, 481–482). Exact source-defined symmetry/eigenvalue and octahedral signed permutation identities; no actual particle mass, physical source coefficient or decay realization inferred.

## Inherited issues and final integration decisions

- `BH-IBX-EV-0001` through `BH-IBX-EV-0006`: Batch 2 established the previously missing self-contained finite exact evidence, subject to the claim-specific finite scope.
- `BH-IBX-EV-0009`: Batch 5 added claim-matched Petersen finite certificates; the remaining broader uniqueness / geometric intertwiner assertion is not thereby proven and remains open.
- `BH-IBX-DAG-0003`: current new 23 statements require full graph registration and manifest update.
- `BH-IBX-DAG-0004`: historical 600-chamber issue closures and claim-level conditional statuses must be jointly represented without blanket promotion.
- No new source-domain counterexample found. Errors arising while coding an independent verifier were corrected in the verifier, not imputed to the manuscript.

## Mathematical versus physical scope

Exact finite geometry, quotient spectra, torsion and response symmetry do not on their own realize physical particle carriers, select an unmarked GP3 alternative, supply Hamiltonian/source terms, or establish measured decay channels. Existing imported finite-group topology and category theorems remain external unless independently demonstrated with their full hypotheses.

## Machine-readable evidence

- `Paper1B-RigorousVerificationBatch6Ledger-v1_1.json` — each of 83 source as-printed statements, inherited status, evidence/control links and reference disposition.
- `Paper1B-RigorousVerificationBatch6Independent-v1_1.py` / `...IndependentResults-v1_1.json` — separate finite exact checks.
- Full six-batch coverage and original audit histories are reconciled in the final `Paper1B-ExceptionalGeometryProofChainAudit-v1_3.md` and latest DAG release.
