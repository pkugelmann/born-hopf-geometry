#!/usr/bin/env python3
"""Independent exact checks of Paper I-B Exceptional Geometry v1.7, Batch 3.

Checks SOURCE-AS-PRINTED claims, NOT physical selection.  Arithmetic is exact
(SymPy rational/integer/symbolic) except that no SDP optimality is re-proved.
Usage: python Paper1B-Batch3-IndependentChecks-v1_1.py [source.tex]
"""
import itertools, json, hashlib, math, collections, sys, os
import sympy as s
from functools import reduce

SOURCE = sys.argv[1] if len(sys.argv)>1 else '/mnt/data/audit1b_work/Paper1B-ExceptionalGeometry-v1_10.tex'
SOURCE_SHA='e02e868b02dc3e22bbfae8b4563d7586646f2dc0f215145674dff5fea10854d5'
assert hashlib.sha256(open(SOURCE,'rb').read()).hexdigest() == SOURCE_SHA
rows=[]
def check(code, title, predicate, claims, method='independent exact arithmetic', witness=None):
    passed = bool(predicate)
    row={'id':code,'title':title,'passed':passed,'claim_labels':claims if isinstance(claims,list) else [claims], 'method':method}
    if witness is not None: row['witness']=str(witness)
    rows.append(row)
    if not passed: raise AssertionError('%s: %s'% (code,title))
    return True

# R1: Integer-spin sector enumerations, highest weights, Clebsch--Gordan.
claims='p1:prop:shell-dimensions-parity'
for m in range(9):
    shells=[sum((a+1)*(r-a+1) for a in range(r+1)) for r in range(2*m+1)]
    even=sum(shells[::2]); odd=sum(shells[1::2]);total=sum(shells)
    ev=int(s.Rational((m+1)*(m+2)*(2*m*m+6*m+3),6))
    od=int(s.Rational(m*(m+1)**2*(m+2),3))
    check('B3-REP-%02d'%m,'H_m total/shell/parity at m=%s'%m,
        total==int(s.binomial(2*m+4,4)) and even==ev and odd==od and
        all(x==int(s.binomial(r+3,3)) for r,x in enumerate(shells)),claims,
        witness={'m':m,'dim':total,'even':even,'odd':odd})
# Six H1 labels as doubled-spin pairs, each retained once
labels=[(a,b) for a in range(3) for b in range(3) if a+b<=2]
dims={(a,b):(a+1)*(b+1) for a,b in labels}
check('B3-REP-09','H1 labels, dim15; E9 box; terminal antichain',
      len(labels)==6 and sum(dims.values())==15 and
      sum(dims[x] for x in [(0,0),(1,0),(0,1),(1,1)])==9 and
      {(2,0),(1,1),(0,2)}.issubset(labels),
      ['p1:prop:h1-symmetric-exterior-form','p1:prop:box-simplex-antichain'],witness=dims)
# SU2_CG repeated for all sectors. Vertex channels from coordinate tensor (1/2,1/2).
def cg_coord(ab):
 a,b=ab
 return {(aa,bb) for aa in (a-1,a+1) for bb in (b-1,b+1) if aa>=0 and bb>=0}
edges=set()
for a in labels:
 for b in cg_coord(a)&set(labels):
  edges.add(tuple(sorted((a,b))))
expected={tuple(sorted(x)) for x in [((0,0),(1,1)),((1,1),(2,0)),((1,1),(0,2)),((1,0),(0,1))]}
check('B3-REP-10','Only four retained coordinate coupling channels',edges==expected,
      ['p1:prop:closure-m1','p1:thm:minimal-coordinate-closed-truncation','p1:prop:math-h1-coordinate-coupling-graph'],witness=sorted(edges))
check('B3-REP-11','First exterior spinor channels: weights3/2, dim6 each',
      cg_coord((1,0))=={(0,1),(2,1)} and cg_coord((0,1))=={(1,0),(1,2)} and
      dims[(1,0)]==2 and 3*2==6,
      'p1:prop:first-excluded-chiral-boundary')
check('B3-REP-12','Casimir thresholds and traces',
      [sum(v for k,v in dims.items() if s.Rational(k[0]*(k[0]+2)+k[1]*(k[1]+2),4)<=t)
       for t in [0,s.Rational(3,4),s.Rational(3,2),2]]==[1,5,9,15] and
      sum(s.Rational(a*(a+2)+b*(b+2),4)*v for (a,b),v in dims.items())==21 and
      sum(s.Rational(a*(a+2)+b*(b+2),4)**2*v for (a,b),v in dims.items())==s.Rational(141,4),
      ['p1:thm:s3one-casimir-scale-space','p1:thm:s3one-structural-invariants'])
check('B3-REP-13','Symmetric/exterior dimension 4: 1,4,10,20,35,56,84',
      [s.binomial(n+3,3) for n in range(7)]==[1,4,10,20,35,56,84],
      ['p1:def:raw-symmetric-coordinate-degree','p1:prop:shell-boundary-count-guard'])
check('B3-REP-14','Rank-3 boundary quotient dims 1,4,10,14,25,41,63',
      [int(s.binomial(n+3,3) -(s.binomial(n+1,2) if n>=3 else 0)) for n in range(7)]==[1,4,10,14,25,41,63],
      'p1:thm:boundary-reduced-ranks')
eta,e=s.symbols('eta e')
L3=(eta*e**2,)
L4=(eta*e**3,)
check('B3-REP-15','Degree-3 onset boundary subspace is not a homogeneous ideal',
      s.Poly(eta**2*e**2,eta,e).monoms()[0] not in [s.Poly(x,eta,e).monoms()[0] for x in L4],
      'p1:prop:boundary-quotient-not-algebra',
      method='degree-4 polynomial multigrading counterexample', witness='eta*e^2 is in L3; eta^2*e^2 is not in L4')
# End(V) Spin4 characters for H1 six-block sector-preserving algebra.
from collections import Counter
end_types=collections.Counter()
for (a,b) in labels:
 for aa in range(0,a+1):
  for bb in range(0,b+1):
   end_types[(aa,bb)]+=1  # spin (aa,bb), since j index increments by 1
expected_end={(0,0):6,(1,0):3,(0,1):3,(1,1):1,(2,0):1,(0,2):1}
# For doubled-spin a=1 corresponds j=1/2; End's output j=0,1,
# so above index aa=0 or 1 is the correct integer spin.
check('B3-REP-17','Sector-preserving A1 Spin4 decomposition = 43',
      dict(end_types)==expected_end and sum((2*a+1)*(2*b+1)*c for (a,b),c in end_types.items())==43,
      ['p1:cor:level-one-shear-tt-operators','p1:cor:level-one-operator-algebra-dimensions'])
check('B3-REP-18','Full End H1=225, Spin4 commutant=6 and protected End K=16',
      15**2==225 and len(labels)==6 and 4**2==16,
      ['p1:cor:level-one-shear-tt-operators','p1:cor:level-one-operator-algebra-dimensions'])
check('B3-REP-19','Casimir C<=3/2 box E9; C<=2 full simplex',
      {p for p in labels if s.Rational(p[0]*(p[0]+2)+p[1]*(p[1]+2),4)<=s.Rational(3,2)}
        =={(0,0),(1,0),(0,1),(1,1)} and
      all(s.Rational(a*(a+2)+b*(b+2),4)<=2 for a,b in labels),
      'p1:prop:box-simplex-antichain')

check('B3-REP-16','Projector Hom multiplicities and edge forest: 3 moduli',
      len(edges)==4 and len({x for edge in edges for x in edge})==6 and
      len(edges)==6-2,
      ['p1:prop:protected-coordinate-multiplicity-one','p1:cor:level-one-coordinate-completion-moduli'],
      method='Clebsch--Gordan and graph-cycle test')

# R2: Exact exterior Clifford compression and independent 4x4 gamma matrices.
full_basis=list(range(16))
low_basis=[b for b in full_basis if b.bit_count()<=2]
idx={b:i for i,b in enumerate(full_basis)}
def sign_preceding(bits, a):return (-1)**((bits & ((1<<a)-1)).bit_count())
def cliff(a):
 M=s.zeros(16)
 for bits in full_basis:
  if bits&(1<<a): out=bits^(1<<a)
  else:out=bits|(1<<a)
  M[idx[out],idx[bits]]=sign_preceding(bits,a)
 return M
cf=[cliff(a) for a in range(4)]
C=[M.extract(low_basis,low_basis) for M in cf]
graded=[i for i,mask in enumerate(low_basis) if mask.bit_count()<2]
terminal=[i for i,mask in enumerate(low_basis) if mask.bit_count()==2]
Csum=sum((M*M for M in C),s.zeros(11))
check('B3-CL-01','Full four-generator exterior Clifford relations',
      all(cf[a]*cf[b]+cf[b]*cf[a] == 2*(1 if a==b else 0)*s.eye(16)
          for a in range(4) for b in range(4)),
      'p1:def:clifford-coordinate-representative')
check('B3-CL-02','Truncation radius exact eigenvalues: 4,4,2 on Lambda0,1,2',
      Csum==s.diag(*[4 if z in graded else 2 for z in range(11)]),
      ['p1:cor:clifford-level-one-values','p1:prop:terminal-degree-leakage'])
check('B3-CL-03','Clifford anticommutators remain exact below terminal degree',
      all(all((C[a]*C[b]+C[b]*C[a])[i,j] == (2 if a==b else 0)*(i==j)
          for i in graded for j in range(11)) for a in range(4) for b in range(4)),
      'p1:cor:clifford-level-one-values')
N=[M.extract(graded,graded) for M in C]
Nsum=sum((M*M for M in N),s.zeros(len(graded)))
check('B3-CL-04','After removing bivectors, vector radius 1 vs former 4 (R^2/4 vs R^2)',
      all(Nsum[i,i]==1 for i in range(len(graded)) if low_basis[graded[i]].bit_count()==1),
      'p1:cor:clifford-level-one-values')
# 4x4 Euclidean Hermitian gamma blocks
I=s.I
sigma=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-I],[I,0]]),s.Matrix([[1,0],[0,-1]])]
zeros=s.zeros(2); id2=s.eye(2)
gammas=[]
for v in sigma:
 gammas.append(s.BlockMatrix([[zeros,-I*v],[I*v,zeros]]).as_explicit())
gammas.append(s.BlockMatrix([[zeros,id2],[id2,zeros]]).as_explicit())
check('B3-CL-05','Explicit 4x4 protected gamma, Hermitian and Euclidean Clifford',
      all(G.conjugate().T==G for G in gammas) and
      all(gammas[a]*gammas[b]+gammas[b]*gammas[a]==2*(a==b)*s.eye(4)
          for a in range(4) for b in range(4)),
      ['p1:prop:general-protected-clifford-relation','p1:thm:s3one-cliffordization'])
G5=reduce(lambda a,b:a*b,gammas)
Es=[gammas[a]*gammas[3] for a in range(3)]
check('B3-CL-11','Positive real Clifford even transport has 3 negative generators',
      all(E*E==-s.eye(4) for E in Es) and
      all(Es[a]*Es[b]+Es[b]*Es[a]==s.zeros(4) for a in range(3) for b in range(a+1,3)),
      'p1:prop:s3one-even-clifford-sign-transport')

check('B3-CL-06','Gamma volume, ± two-dimensional chiral projectors',
      G5*G5==s.eye(4) and s.trace(G5)==0 and
      (s.eye(4)+G5).rank()==2 and (s.eye(4)-G5).rank()==2,
      ['p1:thm:s3one-numerical-data','p1:prop:math-protected-clifford-fierz'])
grad=[s.eye(4)]+gammas+[gammas[a]*gammas[b] for a in range(4) for b in range(a+1,4)]+[G5*G for G in gammas]+[G5]
check('B3-CL-07','Full 16-matrix Fierz basis exact orthogonality',
      len(grad)==16 and all(s.trace(g.conjugate().T*h)==(4 if i==j else 0)
             for i,g in enumerate(grad) for j,h in enumerate(grad)),
      ['p1:thm:s3one-structural-invariants','p1:prop:math-protected-clifford-fierz'])
check('B3-CL-08','Hilbert-Schmidt Clifford bivector norm rho²/2',
      all(s.trace((gammas[a]*gammas[b]).conjugate().T*(gammas[a]*gammas[b]))==4
          for a in range(4) for b in range(a+1,4)),
      'p1:thm:s3one-numerical-data',method='exact Clifford trace with X_a=rho*Gamma_a/2')
check('B3-CL-09','Truncated Clifford terminal symmetric (1,1) witness nonzero',
      (C[0]*C[1]+C[1]*C[0])[low_basis.index(0b0101),low_basis.index(0b0110)] != 0,
      'p1:rem:symmetric-vs-clifford-quadratic',
      witness='degree-two e2 wedge e3 mapped to e1 wedge e3 by off-diagonal anticommutator')
quad=[s.diag(C[a],gammas[a])*s.diag(C[b],gammas[b]) for a in range(4) for b in range(4)]
# Rational+i scalar Gram makes an exact full-rank certificate for the 16 quadratic products.
prodgram=s.Matrix(16,16,lambda i,j: sum(s.conjugate(x)*y for x,y in zip(quad[i],quad[j])))
check('B3-CL-10','Quadratic product map full 15-dim carrier has exact rank 16',
      prodgram.det()!=0,'p1:rem:symmetric-vs-clifford-quadratic',
      method='exact 16x16 Hermitian Gram determinant',witness='det='+str(prodgram.det()))

# R3: 24 unit Hurwitz quaternions; all exact rational, all 576 products.
V=[]
for a in range(4):
 for sg in (2,-2):
  v=[0]*4;v[a]=sg;V.append(tuple(v))
V+=list(itertools.product((-1,1),repeat=4))
V=sorted(set(V)); assert len(V)==24
Vset=set(V)
qcoords=[s.Matrix(v)/2 for v in V]
def qmul(v,w):
 a,b,c,d=v;e,f,g,h=w
 num=(a*e-b*f-c*g-d*h,a*f+b*e+c*h-d*g,a*g-b*h+c*e+d*f,a*h+b*g-c*f+d*e)
 assert all(n%2==0 for n in num)
 return tuple(n//2 for n in num)
check('B3-HUR-01','Hurwitz set 24 normalized points, quaternion closure 576/576',
      all(sum(x*x for x in v)==4 for v in V) and
      all(qmul(v,w) in Vset for v in V for w in V),
      ['p1:thm:s3one-structural-invariants','p1:thm:s3one-classical-completions'])
dot=lambda v,w:sum(x*y for x,y in zip(v,w)) # dot of q vectors is dot(v,w)/4
A={d:s.Matrix(24,24,lambda i,j:int(dot(V[i],V[j])==d)) for d in (4,2,0,-2,-4)}
Id,Ap,A0,Am,J=[A[k] for k in (4,2,0,-2,-4)]
zeros24=s.zeros(24)
check('B3-HUR-36','Full 24-cell and oriented-frame stabilizer chain order ratios',
      1152//24==48 and 576//24==24 and 48//8==6 and 24//8==3 and 24*8==192,
      'p1:thm:s3one-structural-invariants')

check('B3-HUR-02','Relation matrices partition all vertex pairs and are symmetric',
      sum((A[d] for d in A),zeros24)==s.ones(24) and
      all(mat.T==mat for mat in A.values()),
      'p1:thm:s3one-numerical-data')
check('B3-HUR-03','Hurwitz 24-cell valencies 1,8,6,8,1',
      [sum(mat[0,j] for j in range(24)) for mat in [Id,Ap,A0,Am,J]]==[1,8,6,8,1] and
      all([sum(mat[i,j] for j in range(24)) for i in range(24)]==[k]*24 for k,mat in [(1,Id),(8,Ap),(6,A0),(8,Am),(1,J)]),
      'p1:thm:s3one-numerical-data')
rels=[('B3-HUR-%02d'%(4+n),name,L==R) for n,(name,L,R) in enumerate([
 ('Ap^2',Ap*Ap,8*Id+3*Ap+4*A0+Am),
 ('Ap*A0',Ap*A0,3*Ap+3*Am),
 ('Ap*Am',Ap*Am,Ap+4*A0+3*Am+8*J),
 ('Ap*J',Ap*J,Am),
 ('A0^2',A0*A0,6*Id+4*A0+6*J),
 ('A0*Am',A0*Am,3*Ap+3*Am),
 ('A0*J',A0*J,A0),
 ('Am^2',Am*Am,8*Id+3*Ap+4*A0+Am),
 ('Am*J',Am*J,Ap),
 ('J^2',J*J,Id)])]
for code,name,ok in rels:check(code,'Bose-Mesner multiplication '+name,ok,
     ['p1:thm:s3one-numerical-data','p1:prop:math-twentyfourcell-bose-mesner'])
spec=[(Ap,{8:1,4:4,0:9,-2:8,-4:2}),
      (A0,{6:3,0:12,-2:9}),
      (Am,{8:1,2:8,0:9,-4:6}),
      (J,{1:12,-1:12})]
for n,(mat,dic) in enumerate(spec,14):
 check('B3-HUR-%02d'%n,'Joint nearest/orthogonal/far/antipodal spectra '+str(n),
    mat.eigenvals()==dic, ['p1:thm:s3one-numerical-data','p1:prop:math-twentyfourcell-bose-mesner'])
P9=(3*Id-A0+3*J)/8;P15=(5*Id+A0-3*J)/8
check('B3-HUR-18','Exact BM projectors: idempotent, orthogonal, ranks 9,15',
      P9*P9==P9 and P15*P15==P15 and P9*P15==zeros24 and
      P9+P15==Id and int(s.trace(P9))==9 and int(s.trace(P15))==15 and Ap*P9==zeros24,
      ['p1:thm:s3one-trimer-bose-mesner-interface','p1:thm:s3one-numerical-data'])
check('B3-HUR-19','Unordered pair-distance distribution 96,72,96,12',
      [int(s.ones(1,24).dot(mat*s.ones(24,1))/2) for mat in [Ap,A0,Am,J]]==[96,72,96,12],
      'p1:thm:s3one-numerical-data')
G=s.Matrix(24,24,lambda i,j:s.Rational(dot(V[i],V[j]),4))
check('B3-HUR-20','24-cell Gram spectrum: 6^4 and 0^20',G.eigenvals()=={6:4,0:20},
      'p1:thm:s3one-numerical-data')
check('B3-HUR-21','Hurwitz tight frame first and second moments',
      sum(qcoords,s.zeros(4,1))==s.zeros(4,1) and
      sum((q*q.T for q in qcoords),s.zeros(4))==6*s.eye(4),
      'p1:thm:s3one-numerical-data')
check('B3-HUR-22','All 256 fourth-order isotropic tensor entries exactly',
      all(sum(q[i]*q[j]*q[k]*q[l] for q in qcoords)==
             (i==j)*(k==l)+(i==k)*(j==l)+(i==l)*(j==k)
             for i,j,k,l in itertools.product(range(4),repeat=4)),
      ['p1:thm:s3one-numerical-data','p1:thm:s3one-structural-invariants'])
check('B3-HUR-23','First degree-six design defect = 3/8',
      sum(q[0]**6 for q in qcoords)-s.Rational(15,8)==s.Rational(3,8),
      ['p1:thm:s3one-structural-invariants','p1:thm:s3one-classical-completions'])
# full symbolic sextic check, cross-check invariant harmonic and orbit formula
xx=s.symbols('x0:4')
phis=s.expand(sum((sum(q[i]*xx[i] for i in range(4)))**6 for q in qcoords))
rad2=sum(x*x for x in xx)
H6=sum(x**6 for x in xx)-5*sum(xx[i]**4*xx[j]**2 for i in range(4) for j in range(4) if i!=j)+30*sum(xx[i]**2*xx[j]**2*xx[k]**2 for i,j,k in itertools.combinations(range(4),3))
check('B3-HUR-24','Full degree-six moment identity as polynomial on R4',
      s.expand(phis-s.Rational(15,8)*rad2**3-s.Rational(3,8)*H6)==0,
      'p1:thm:s3one-classical-completions',method='symbolic expansion of 24 sextic orbit terms')
check('B3-HUR-25','H6 harmonic exact symbolic Laplacian',
      s.expand(sum(s.diff(H6,x,2) for x in xx))==0,
      'p1:thm:s3one-structural-invariants',method='symbolic differentiation (appendix proof)')
# D4 antipodal axes quotient/three tetrads.
axes=sorted({min(v,tuple(-a for a in v)) for v in V}); assert len(axes)==12
adj_axes=lambda a,b:abs(dot(a,b))==2
quartets=[]
for combo in itertools.combinations(axes,4):
 if all(dot(a,b)==0 for a,b in itertools.combinations(combo,2)):
  quartets.append(combo)
check('B3-HUR-26','D4 12 axes split into 3 complete pairwise-orthogonal tetrads',
      len(quartets)==3 and len({a for c in quartets for a in c})==12,
      'p1:thm:s3one-structural-invariants',witness={'tetrad_count':len(quartets)})
check('B3-HUR-27','Antipodal quotient graph has K4,4,4 pattern',
      all((dot(a,b)==0)==(any(a in q and b in q for q in quartets)) for a,b in itertools.combinations(axes,2)),
      'p1:thm:s3one-structural-invariants')
check('B3-HUR-28','D4 has 18 great squares (orthogonal root-axis planes)',
      sum(dot(a,b)==0 for a,b in itertools.combinations(axes,2))==18,
      'p1:thm:s3one-structural-invariants')
# For each edge, check its A2 plane has exactly six vertices and all six edges.
edgepairs=[(i,j) for i in range(24) for j in range(i+1,24) if dot(V[i],V[j])==2]
hexes=set()
for i,j in edgepairs:
 v,w=V[i],V[j]
 plane=[u for u in V if s.Matrix.hstack(s.Matrix(v),s.Matrix(w),s.Matrix(u)).rank()==2]
 assert len(plane)==6
 hexes.add(frozenset(plane))
check('B3-HUR-29','Exactly 16 distinct great A2 hexagon planes',len(hexes)==16,
      ['p1:thm:s3one-structural-invariants','p1:thm:s3one-classical-completions'])
check('B3-HUR-30','Each of 96 edges has exactly one A2 hexagon',
      len(edgepairs)==96 and all(sum(V[i] in H and V[j] in H for H in hexes)==1 for i,j in edgepairs),
      'p1:thm:s3one-structural-invariants')
check('B3-HUR-31','Reye 12_4 16_3 incidence (axes in hexagon planes)',
      all(sum(a in H or tuple(-z for z in a) in H for H in hexes)==4 for a in axes) and
      all(sum(a in H or tuple(-z for z in a) in H for a in axes)==3 for H in hexes),
      'p1:thm:s3one-classical-completions')
# adjacent graph distances
D=[[[int(Ap[i,j]) for j in range(24)] for i in range(24)]]
origin=V.index((2,0,0,0))
seen={origin}; frontier={origin}; bfs=[1]
while len(seen)<24:
 nex={j for i in frontier for j in range(24) if Ap[i,j] and j not in seen}
 assert nex
 bfs.append(len(nex));seen|=nex;frontier=nex
check('B3-HUR-32','24-cell adjacency diameter 3 and layers [1,8,14,1]',
      bfs==[1,8,14,1], 'p1:thm:s3one-numerical-data')
# Geometric facet hyperplanes, normals and incidence
unit_normals=[]
for a,b in itertools.combinations(range(4),2):
 for signs in itertools.product((-1,1),repeat=2):
  v=[0]*4;v[a]=signs[0];v[b]=signs[1];unit_normals.append(tuple(v))
check('B3-HUR-33','Each of 24 facet normals supports 6 unit vertices',
      len(unit_normals)==24 and all(sum(dot(n,q)==2 for q in V)==6 for n in unit_normals),
      'p1:thm:s3one-numerical-data',method='support hyperplanes ±x_a±x_b=1')
check('B3-HUR-34','Primal/dual dot shells at ±1/sqrt2,0 counts 6,12,6',
      all([sum(dot(v,n)==c for n in unit_normals) for c in [2,0,-2]]==[6,12,6] for v in V),
      'p1:thm:s3one-structural-invariants')
check('B3-HUR-35','24-cell volume and boundary hypervolume',
      24*s.sqrt(2)/3 == 8*s.sqrt(2) and (8*s.sqrt(2))/s.sqrt(2)/4==2 and
      s.sqrt(2)/3==s.Rational(4,3)*s.sqrt(2)*s.Rational(1,4),
      'p1:thm:s3one-numerical-data')
# R4 root group order and polynomial invariant degrees are independent literature imports, not computed here.

# R4: Hurwitz link/trimer matrices and cubic transport.
h=lambda eps:(1,)+tuple(eps)
plus=[h(e) for e in [(-1,1,1),(1,-1,1),(1,1,-1)]]
minus=[h(e) for e in [(1,-1,-1),(-1,1,-1),(-1,-1,1)]]
W=plus+minus
Widx=[V.index(v) for v in W]
CW=Ap.extract(Widx,Widx)
Cs=s.ones(3)-s.eye(3)
ideal=s.BlockMatrix([[s.zeros(3),Cs],[Cs,s.zeros(3)]]).as_explicit()
check('B3-TRI-01','Six trimer support induces C6 with cross-block J3-I3',CW==ideal,
      'p1:prop:s3one-trimer-adjacency-compression')
check('B3-TRI-02','Trimer compression not invariant: 2 of 8 neighbors retained',
      all(sum(Ap[i,j] for j in Widx)==2 for i in Widx),
      'p1:prop:s3one-trimer-adjacency-compression')
check('B3-TRI-03','Compressed P9 BM Gram blocks (4I3-J3)/8',
      P9.extract(Widx,Widx)==s.BlockMatrix([[(4*s.eye(3)-s.ones(3))/8,s.zeros(3)],
          [s.zeros(3),(4*s.eye(3)-s.ones(3))/8]]).as_explicit(),
      'p1:thm:s3one-trimer-bose-mesner-interface')
check('B3-TRI-04','Compressed P15 BM Gram blocks (4I3+J3)/8',
      P15.extract(Widx,Widx)==s.BlockMatrix([[(4*s.eye(3)+s.ones(3))/8,s.zeros(3)],
          [s.zeros(3),(4*s.eye(3)+s.ones(3))/8]]).as_explicit(),
      'p1:thm:s3one-trimer-bose-mesner-interface')
check('B3-TRI-05','Trimer Gram spectra positive: (1/8,1/2,1/2) and (7/8,1/2,1/2)',
      ((4*s.eye(3)-s.ones(3))/8).eigenvals()=={s.Rational(1,8):1,s.Rational(1,2):2} and
      ((4*s.eye(3)+s.ones(3))/8).eigenvals()=={s.Rational(7,8):1,s.Rational(1,2):2},
      'p1:thm:s3one-trimer-bose-mesner-interface')
# exact polar normalization, s.sqrt factors
Q0=s.ones(3)/3;Qperp=s.eye(3)-Q0
for num,P,factors in [(9,P9,(s.sqrt(8),s.sqrt(2))),(15,P15,(s.sqrt(s.Rational(8,7)),s.sqrt(2)))]:
 T=factors[0]*Q0+factors[1]*Qperp
 projection=s.Matrix(24,3,lambda i,j:int(i==Widx[j]))
 U=P*projection*T
 check('B3-TRI-%02d'%(6 if num==9 else 7),'Polar BM isometric trimer injection '+str(num),
       s.simplify(U.conjugate().T*U)==s.eye(3),
       'p1:thm:s3one-trimer-bose-mesner-interface')
# exact C3 trace decomposition via sign permutation of imaginary coordinates
perm=lambda v:(v[0],v[3],v[1],v[2])
perm_matrix=s.Matrix(24,24,lambda i,j:int(V[i]==perm(V[j])))
check('B3-TRI-08','C3 traces on 24D, rank9 and rank15 sectors',
      [s.trace(x*perm_matrix) for x in [Id,P9,P15]]==[6,0,6],
      'p1:thm:s3one-trimer-bose-mesner-interface')
# trimer exact projector and cyclic Weyl
Ps=[]
for j in range(3):
 p=s.zeros(3);p[j,j]=1;Ps.append(p)
D1=Ps[0]-s.eye(3)/3;D2=Ps[1]-Ps[2]
check('B3-TRI-09','Two trimer defect spectra and trace Gram',
      D1.eigenvals()=={s.Rational(2,3):1,s.Rational(-1,3):2} and
      D2.eigenvals()=={0:1,1:1,-1:1} and
      s.trace(D1*D1)==s.Rational(2,3) and s.trace(D2*D2)==2 and s.trace(D1*D2)==0,
      'p1:thm:s3one-numerical-data')
check('B3-TRI-10','Opposite trimer ± defect combo spectra 2/3,2/3,-4/3',
      all((D1+sg*D2).eigenvals()=={s.Rational(2,3):2,s.Rational(-4,3):1} for sg in [1,-1]),
      'p1:thm:s3one-numerical-data')
X=s.zeros(3)
for j in range(3):X[(j+1)%3,j]=1
om=s.exp(2*s.pi*s.I/3)
Z=s.diag(1,om,om**2)
C1=X+X.T; C2=-s.I*(X-X.T)
check('B3-TRI-11','Trimer shift and clock satisfy Weyl ZX=omega XZ',
      all(s.simplify(a)==0 for a in Z*X-om*X*Z),
      'p1:prop:math-trimer-weyl-a2')
check('B3-TRI-12','Trimer transport C1/C2 exact Gram 6,6,0',
      s.trace(C1*C1)==6 and s.trace(C2*C2)==6 and s.trace(C1*C2)==0 and
      s.trace(D1*C1)==0 and s.trace(D1*C2)==0 and s.trace(D2*C1)==0 and s.trace(D2*C2)==0,
      'p1:thm:s3one-numerical-data')
check('B3-TRI-13','Trimer primitive five-element Gram determinant 16',
      s.prod([s.Rational(1,3),s.Rational(2,3),2,6,6])==16,
      'p1:thm:s3one-numerical-data')
check('B3-TRI-14','A2 defect root Gram 2,-1; inverse 1/3(2,1;1,2)',
      s.Matrix([[s.trace((Ps[i]-Ps[i+1])*(Ps[j]-Ps[j+1])) for j in range(2)] for i in range(2)])==
      s.Matrix([[2,-1],[-1,2]]),
      'p1:thm:s3one-structural-invariants')
cc,ss=s.symbols('c s', real=True)
lam=s.Symbol('lam')  # match charpoly's assumption-free generator
family=cc*C1+ss*C2
charpoly=s.expand(family.charpoly(lam).as_expr())
check('B3-TRI-17','General cyclic trimer transport cubic on cos²+sin²=1',
      s.expand(charpoly-(lam**3-3*(cc**2+ss**2)*lam-2*(cc**3-3*cc*ss**2)))==0,
      'p1:thm:s3one-numerical-data',method='symbolic characteristic polynomial before angle parametrization')
check('B3-TRI-18','C3 class characters yield exactly 3 regular and 6 trivial+3 regular',
      all(s.trace(M*perm_matrix)==v for M,v in [(P9,0),(P15,6)]) and
      9==3*3 and 15==6+3*3,
      'p1:thm:s3one-trimer-bose-mesner-interface',method='equivariant projection character calculation')

check('B3-TRI-15','Coordinate angular sign-cube trimer distance sqrt2 ratio',
      s.simplify(s.sqrt(s.Rational(8,3))/s.sqrt(s.Rational(4,3)))==s.sqrt(2),
      'p1:thm:s3one-numerical-data')
# Trimer six-cycle from Hamming signs
link=list(itertools.product((-1,1),repeat=3))
check('B3-TRI-16','Hamming cube H1,H2,H3 eigenvalue multisets',
      [s.Matrix(8,8,lambda i,j:int(sum(x!=y for x,y in zip(link[i],link[j]))==k)).eigenvals() for k in (1,2,3)]==
      [{3:1,1:3,-1:3,-3:1},{3:2,-1:6},{1:4,-1:4}],
      'p1:thm:s3one-numerical-data')
# R5: scalar subcarrier sampling exact isometry and intertwiner.
# For unnormalized coord functions u_a, Gram normalized by 24 is 1/4 delta.
Eval=s.Matrix(24,5,lambda i,j: 1 if j==0 else s.Rational(V[i][j-1],2))
check('B3-EVAL-01','Isometric scalar evaluation Gram diag(1,1/4,1/4,1/4,1/4)',
      Eval.T*Eval/24==s.diag(1,s.Rational(1,4),s.Rational(1,4),s.Rational(1,4),s.Rational(1,4)),
      'p1:prop:h1-scalar-hurwitz-evaluation-bridge')
check('B3-EVAL-02','A+ on constant+coordinate evaluation has eigen 8 and 4',
      Ap*Eval==Eval*s.diag(8,4,4,4,4),
      'p1:prop:h1-scalar-hurwitz-evaluation-bridge')
check('B3-EVAL-03','K1 intertwining factor 3/8 and scalar Δ factor 3/4',
      s.Rational(3,8)*(8*Id-Ap)*Eval==Eval*s.diag(0,s.Rational(3,2),s.Rational(3,2),s.Rational(3,2),s.Rational(3,2)),
      'p1:prop:h1-scalar-hurwitz-evaluation-bridge')
check('B3-EVAL-04','No full H1 natural left 2T-injection: fixed dims 6>1',
      1+2+3==6 and s.ones(1,24).dot(P15*s.ones(24,1))==24,
      'p1:prop:h1-e15-left-2t-obstruction',method='SU2 spin content and invariant fixed spaces')
check('B3-EVAL-05','Trimer 3/24 and BM 15/24 normalized trace factors',
      s.Rational(3,24)==s.Rational(1,8) and s.Rational(15,24)==s.Rational(5,8),
      ['p1:cor:s3one-trimer-operator-corner','p1:thm:s3one-numerical-data'])

out='/mnt/data/audit1b_work/Batch3ReplayArchivedB3Results-v1_1.json'
doc={'audit_target':'Paper1B-ExceptionalGeometry-v1_7.tex','sha256':SOURCE_SHA,
     'batch_line_start':4600,'batch_line_stop':8294,
     'test_count':len(rows),'passed':sum(x['passed'] for x in rows),'failed':sum(not x['passed'] for x in rows),
     'qualification':'Exact identity and selected hypothesis checks only. No SDP proof, external physical model selection or all-domain proof is claimed.',
     'tests':rows}
with open(out,'w') as f:json.dump(doc,f,indent=2,ensure_ascii=False)
print('PASS',len(rows),'/',len(rows),'exact independent controls; output',out)
