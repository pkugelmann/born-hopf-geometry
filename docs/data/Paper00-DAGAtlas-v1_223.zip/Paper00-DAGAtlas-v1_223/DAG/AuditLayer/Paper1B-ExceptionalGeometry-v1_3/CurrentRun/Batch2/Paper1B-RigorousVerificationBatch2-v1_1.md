# Paper I-B — Rigorous Verification DAG Audit, Batch 2

**Artifact:** `Paper1B-RigorousVerificationBatch2-v1_1.md`  
**Protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md` (technical scope) and `Paper00-ProofChainAuditProtocol-v1_1.md` (historical proof-chain guard, overridden where its theory-repair remit differs)  
**Authoritative manuscript:** `Paper1B-ExceptionalGeometry-v1_10.tex`, from `Paper00-PapersMinimal-v3_017(1).zip`  
**SHA-256 of manuscript:** `e02e868b02dc3e22bbfae8b4563d7586646f2dc0f215145674dff5fea10854d5`  
**Incoming historical atlas:** `Paper00-DAGAtlas-v1_150(1).zip`, Paper I-B audit layer `DAG/AuditLayer/Paper1B-ExceptionalGeometry-v1_2/` (source v1.9)  
**Checkpoint:** `PARTIALLY_AUDITED` (cumulative 123/506 formal source statements; this batch audited current ordinals 1–100). **No new in-domain mathematical contradiction was established.** Original sources and ZIPs are untouched. No physical-realization status is promoted.

## 1. Batch scope and source-continuity evidence

This batch revisited inherited formal environments **1–100** (the first theorem `p1:thm:v273-two-icosahedral-completions` through `p1:thm:hurwitz-maximal-order`). These span the current source's opening exceptional completion, signed Petersen and 600-cell bridge, Kneser, shell-spectral, finite-subgroup, and Hurwitz-unit constructions, ending immediately before `p1:thm:hurwitz-units-maximal-order`.

**Strong source continuity:** The entire 158,229-byte current source slice beginning at the first theorem and ending immediately before formal environment 101 is **byte-for-byte identical** to the same slice in Paper I-B v1.9, including every line of intervening non-formal definitions, scope remarks, displayed equations, cross-references and proofs. Its SHA-256 is `64b7bb699a0c9ee81235037b197b804b9903ff7d7810ba3c572eda9cce3713e9`. In addition, all 100 claim statements and their immediately attached proofs match the archived older v1.7 record after whitespace normalization. No E1 certificate is invalidated by a source change on this segment. This continuity is **E0 source-lineage evidence**, not by itself an independent proof of a theorem.

The current-source label scan finds **49 distinct referenced labels** in the first 100 formal claim statements and proofs, all resolved. The only labels in another paper are `p1:thm:exceptional-normalizer-fork` and `p1:prop:exceptional-nesting` (current Paper I-A v5.177) and `p1c:sec:v371-petersen-600cell-certificate` (current Paper I-D v1.66). These import locations were directly reopened and checked for their actual finite-group/coordinate scopes. The 49 **citation occurrences are not all upgraded into material proof edges**; claim-matched proof-use edges are identified below.

### Dispositions

| Status and evidence lineage | Batch 2 (1–100) | Cumulative (Batch 1 + Batch 2) |
|---|---:|---:|
| VERIFIED — prior mathematically certified verdict retained for unchanged source | 77 | 77 |
| VERIFIED — **new independent, portable exact E3** plus E1 and applicable E4 scope checks | 6 | 6 |
| VERIFIED — Batch 1 newly introduced results | — | 12 |
| VERIFIED-CONDITIONAL — Batch 1 comparison results | — | 5 |
| FORMALIZED — definitions and boundary remarks | 17 | 23 |
| **Total source-bound reviewed** | **100** | **123/506** |

Thus the cumulative aggregate is **95 VERIFIED**, **5 VERIFIED-CONDITIONAL** and **23 FORMALIZED**, with **383 inherited current-source statements still awaiting this run's revalidation**. The 77 carried-forward `VERIFIED` statuses are *not* misdescribed as 77 freshly executed independent E3 certificates: their earlier proof/evidence lineage is individually anchored in the claim ledger, and the complete controlling source prefix is unchanged. The new independent E3 claims are exactly the six listed below.

## 2. Six exact E3 evidence obligations discharged

All six IDs were open in the incoming v1.9 audit due to unavailable portable claim-matched certificates, not established source errors. The current batch reconstructs them from source-fixed finite mathematical objects, using three runnable scripts and three paired result JSON files. All checks are exact, except finite numerical sign choices used only to select a sign of an algebraic dot product that is thereafter checked in exact field arithmetic. The mathematical outputs below are about **selected finite comparison geometry**, not physical state actualization.

### `BH-IBX-EV-0001` — Pentagon holonomy and reciprocal cycle frame

- **Target/locator:** `p1:thm:petersen-pentagon-reciprocity`, v1.10 lines **505–542**.
- **Actually consumed:** `p1:thm:petersen-signed-and-flux` and `p1:thm:petersen-fifteen-resolution` on the same selected, oriented Petersen module. No physical half-turn Hamiltonian or separate carrier is imported.
- **Independent computation:** Rebuild the ten projective axes in `Q(√5)`, fifteen signed edges, twelve simple five-cycles and their oriented cycle columns. The holonomies split **6 positive / 6 negative**. The exact 15×15 matrices reproduce `H_+ + H_- = 10P_C`, `H_+H_- = 20P_C`, `(H_+-H_-)²=20P_C`, and the four `5±√5` projector coefficients. All six complementary pentagon pairs yield parallel `K` and conjugate `K^σ` fluxes with squared ratios `φ²` and `φ^{-2}`.
- **Verdict:** `E3 EXACT PASS`; historic `REPRODUCED → VERIFIED` is supported **within the stated cycle/flux scope**. No new physical readout is asserted.
- **Evidence:** `Paper1B-RigorousVerificationBatch2Exact-v1_1.py` / `...ExactResults-v1_1.json`.

### `BH-IBX-EV-0002` — 600-cell dodecahedral total-graph cover

- **Target/locator:** `p1:thm:v371-petersen-600cell-total-cover`, lines **728–772**.
- **Imported mathematical input:** Explicit 120-quaternion `2I` set from Paper I-A, nearest-edge rule `Re(q^{-1}r)=φ/2`, Paper I-D's technical certificate (`p1c:sec:v371-petersen-600cell-certificate`).
- **Independent computation:** Exactly reconstruct all **120** vertices and **720** nearest edges, the `D` shell (**20** vertices, **30** edges, dodecahedral graph) and `Z` shell (**30** vertices), each of the **30** distinct edge midpoints as a real-zero quaternion, and the complete induced **50-vertex, 150-edge, 6-regular** total graph. Its inversion quotient has **25 vertices and 75 edges** and the `D`-vertex quotient is Petersen (**10 vertices, 15 edges**). All **20** local tetrahedral four-cliques pass the nearest-edge test.
- **Verdict:** `E3 EXACT PASS`; historic `REPRODUCED → VERIFIED` within the nearest-edge and quotient claims. This is not a ten-particle realization.
- **Evidence:** `Paper1B-RigorousVerificationBatch2Quaternion-v1_1.py` / `...QuaternionResults-v1_1.json` (portable dependency: Batch 1 exact raw 2I enumerator).

### `BH-IBX-EV-0003` — Q8 frames and four angular channel orbits

- **Target/locator:** `p1:prop:v371-petersen-q8-angular`, lines **774–811**.
- **Consumed:** The same exact `D`–`Z` shells and projective `2I` group. Quaternionic multiplication and the **61-node inversion quotient of the full 120-vertex 600-cell**, rather than a postulated interaction graph.
- **Independent computation:** Each dodecahedral edge gives exact pure imaginary unit `m_e,d_e,k_e∈2I`, `m_ed_e=-k_e`, `d_em_e=k_e`, and an actual `Q8`. The **30** oriented edge nodes give **15** projective channels partitioned as **3 each in five** tetrahedral `Q8` cores. Every projective `C6` axis has the source angular multiplicities **(3,6,3,3)**; distances by angular class are exactly **(1,2,2,3)**. Group conjugation independently establishes **four genuine rotational `A5` pair orbits** of sizes **30, 60, 30, 30**, not merely four observed absolute-dot values.
- **Verdict:** `E3 EXACT PASS`; historic `REPRODUCED → VERIFIED` for the marked group action. Odd abstract relabelings are not promoted to actual orientation-preserving rotations or physical chirality.
- **Evidence:** same quaternionic script and results as `EV-0002`.

### `BH-IBX-EV-0004` — 20-dimensional tangent exact sequence

- **Target/locator:** `p1:thm:v371-petersen-tangent-exact-sequence`, lines **816–885**.
- **Consumed:** The signed Petersen trimer and the five `J_m` mirror intertwiners, with **scalar/unoriented input** and **projective `D3` axis stabilizer**. Do not replace this by the oriented-edge Hodge module.
- **Independent computation:** In exact `Q(√5)` pair arithmetic, construct ten rank-two tangent-fibre projectors, `F : R^15 → R^20`, and `M : R^20 → R^6`. Verify `F†F=3I−B†B/2`, spectrum `0×1,1×5,(5/2)×4,3×5`, `MF=0`, `MM†=diag((20/3)I3,(5/3)I3)`, and projector ranks **14+6=20**, establishing exactness. The explicit `D3` character inner product is **1**; reducing to oriented `C3` gives **2**, confirming the source's stated nonuniqueness boundary.
- **Verdict:** `E3 EXACT PASS` with a scope-matched `E4` character boundary; historic `REPRODUCED → VERIFIED`.
- **Evidence:** `Paper1B-RigorousVerificationBatch2Tangent-v1_1.py` / `...TangentResults-v1_1.json`.

### `BH-IBX-EV-0005` — Five-root C_m leakage and both sum rules

- **Target/locator:** `p1:thm:v371-petersen-rooted-leakage`, lines **924–978**.
- **Consumed:** The **same** tangent `F`, receiver `M`, rooted `R_m` masks and core `J_m`, with `P_rec` and `P_loc` defined in the source.
- **Independent computation:** Construct all five exact `30×30` ambient tangent projections and six-dimensional normalized receiver compressions. For each core check `A_m=[[2/5 I, J_m^T/10],[J_m/10,2/5 I]]`, leakage eigenvalues **1/4×3** and **21/100×3**, plus `Σ_m C_m=0`. Independently, entry-by-entry in `Q(√5)` reproduce **both** `Σ_m C_m C_m† = (23/20)P_rec` and the previously unarchived source-side identity `Σ_m C_m† C_m = (3/10) FF† − (3/20)P_loc`. The latter's fourteen positive eigenvalues are **3/20×5, 3/5×4, 3/4×5**.
- **Verdict:** `E3 EXACT PASS`; historical independent-evidence requirement is met; `REPRODUCED → VERIFIED` in geometric-root scope. No physical decay vertex is derived.
- **Evidence:** same tangent script and results as `EV-0004`.

### `BH-IBX-EV-0006` — Quadrupole–flux tensor Gram

- **Target/locator:** `p1:prop:v371-petersen-quadrupole-flux`, lines **980–1007**.
- **Consumed:** Source `Q_v`, `K`, `Π4`, `Π5`, `Π3`, `Π3′` in the **15-dimensional oriented edge module**, not the distinct 15-dimensional level-one finite carrier.
- **Independent computation:** Form all exact `15×15` Gram entries for `Φ(e)=(Q_v+Q_w)⊗k_e`, and verify `Φ†Φ=(2/9)Π4+(20/9)Π5+(4/3)Π3+(32/9)Π3′` with positive multiplicities **4,5,3,3**, hence invertibility. All fifteen contraction columns satisfy `cΦ=−(2/3)K` exactly.
- **Verdict:** `E3 EXACT PASS`; historic `REPRODUCED → VERIFIED` for this tensor map, not an action-generated physical source.
- **Evidence:** same exact Petersen script and results as `EV-0001`.

## 3. Issue ledger and graph effects

**Existing root issues proposed for evidence closure (six, no new IDs):**

| Existing root ID | Previous status | Batch-2 evidence conclusion | Proposed lifecycle after final integration |
|---|---|---|---|
| `BH-IBX-EV-0001` | OPEN, unavailable portable exact pentagon certificate | Complete exact cycle/projection certificate | RESOLVED — evidence portability |
| `BH-IBX-EV-0002` | OPEN, unavailable exact D20/Z30 total graph certificate | Complete 120-quaternion and 50-vertex exhaustive certificate | RESOLVED — evidence portability |
| `BH-IBX-EV-0003` | OPEN, unavailable exact Q8 angular/orbit certificate | Complete `Q8`, `A5` and quotient-distance certificate | RESOLVED — evidence portability |
| `BH-IBX-EV-0004` | OPEN, unavailable exact tangent-sequence certificate | Exact spectral, rank, receiver and character checks | RESOLVED — evidence portability |
| `BH-IBX-EV-0005` | OPEN, unavailable exact five-root source-side certificate | Exact **both-sided** five-root matrix checks | RESOLVED — evidence portability |
| `BH-IBX-EV-0006` | OPEN, unavailable exact 15×15 tensor certificate | Exact positive Gram and contraction identity | RESOLVED — evidence portability |

These are **evidence-status closures only**, with original historical issue IDs and provenance preserved. The **incoming Atlas ZIP is not modified in this interim batch**, so the formal registry transitions are staged for the final requested ZIP creation. There is no new theorem, no repaired proof, no constitutional assumption, and no source change. Their verified downstream paths are only the finite Petersen and root-operator comparisons in the paper; no new cross-paper physical observable edge has been justified.

**Still open, not falsely resolved here:** `BH-IBX-EV-0009` (later source section, exact oriented-edge isometry/intertwiner uniqueness); `BH-IBX-DAG-0003` (Batch-1's 23 new v1.10 claim objects awaiting merged DAG indexing); and `BH-IBX-DAG-0004` (inherited chamber-evidence/conditional-claim status reconciliation). These three are not evidence of a counterexample in the audited prefix. No additional distinct issue was discovered in Batch 2.

## 4. Boundary, provenance and independent-challenge controls

1. The selected marked `2I` quaternionic representation and its local five `2T` cores are **given by the established group-geometric packet**. The batch does not treat their multiple overlapping subgroup members as independent physical particles or mass terms.
2. The signed **oriented** 15-edge Hodge/flux module, **unoriented scalar** 15-edge source module, 20-dimensional tangent receiver, nine-dimensional mirror map, and physical level-one 15-dimensional carrier are kept separate. Equal dimensions do not authorize an identification.
3. The `D3` versus `C3` intertwiner calculation acts as an explicit `E4` boundary test on claimed uniqueness. The source restricts the theorem to projective axes and declares failure of the stronger oriented-only uniqueness.
4. Shell/normalizer and dense-generation results in the 100-claim block are statements about **selected group actions on one owner**. They do not realize simultaneous sharp projector constraints on an actual scalar state without an additional action constructor.
5. Only the six new calculations are **fresh independent E3** in this batch. The other 77 verified-status results are source-stable carryovers with earlier evidence lineages. Any future independent challenge must target the exact claim; their prior statuses were not blindly re-promoted by SHA equality.
6. This execution used **separately recorded extraction, source-replay lineage, independent exact arithmetic, and adversarial boundary passes**, not actual simultaneous separate agents. No external evidence, PDF rendering, or new theory was used.

## 5. Batch-2 artifact validation and handoff

- Exact script runs: **15 checks passed (Petersen/cycle/tensor)**, **17 checks passed (quaternion/600-cell/Q8)**, **34 checks passed (tangent/five-root)**, zero reported failed checks.
- The current-source first-100 complete control slice matches v1.9 byte-for-byte; individual normalized statements and proofs match the historical ledger 100/100.
- All 49 current label references resolve; three distinct labels import current I-A or I-D material; no unresolved label was found in these statements/proofs.
- The claim-ledger JSON lists exactly 100 current source objects, full statement/proof text, hashes, inherited evidence lineage, source referenced labels, six new issue/evidence matches, and explicit evidence limitations.
- **No original paper or supplied ZIP changed. No DAG or audit archive is issued in this interim batch**, consistent with the user's last-batch-only archive instruction.

**Next batch:** current legacy statements **101–200**, beginning with `p1:thm:hurwitz-units-maximal-order`; use the existing full source and historical certificate lineage, and independently attack any claim whose source proof or evidence requires fresh verification. **Final batch only:** integrate all target records, reconcile the open issue statuses and provenance, produce the next `Paper00-DAGAtlas-v1_151.zip` and `Paper00-ProofChainAudits-v1_65.zip` retaining only latest active audit versions in their designated locations, and validate post-write readback.
