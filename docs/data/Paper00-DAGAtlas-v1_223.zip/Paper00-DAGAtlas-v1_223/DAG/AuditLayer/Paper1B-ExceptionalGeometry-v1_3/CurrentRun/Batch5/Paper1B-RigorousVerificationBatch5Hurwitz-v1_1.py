"""Additional source-independent E3 controls for Paper I-B v1.10.
Finite A5 pairwise design, binary Hurwitz 24-cell low-band Laplacian,
spin-2/twisted quintet invariant ranks and cubic comparison.
"""
from __future__ import annotations
from itertools import product, combinations, permutations
from collections import defaultdict,Counter
from pathlib import Path
from fractions import Fraction as F
import hashlib, json, math
import sympy as s
SRC=Path('/mnt/data/audit1b_work/Paper1B-ExceptionalGeometry-v1_10.tex')
SHA=hashlib.sha256(SRC.read_bytes()).hexdigest()
assert SHA=='e02e868b02dc3e22bbfae8b4563d7586646f2dc0f215145674dff5fea10854d5'
checks=[]
def ck(name,labels,cond,datum=''):
 passed=bool(cond);checks.append({'id':f'B5H-{len(checks)+1:04d}','topic':name,'claim_labels':labels if isinstance(labels,list) else [labels],'passed':passed,'datum':str(datum)[:250]})
 if not passed:raise AssertionError(f'{name} FAILED {datum}')
L355='p1:thm:v340-cyclic-coset-design';L385='p1:thm:v349-twisted25-spin2-lift';L386='p1:thm:v349-twisted25-vertex-defect';L388='p1:thm:v350-hurwitz-five-design';L389='p1:thm:v350-hurwitz-scalar-laplacian'; L396='p1:prop:v365-cubic-algebra-color'
# Build full even-permutation group, without hardcoded class table.
G=[p for p in permutations(range(5)) if sum(p[i]>p[j] for i in range(5) for j in range(i+1,5))%2==0]
unit=(0,1,2,3,4)
compose=lambda p,q:tuple(p[q[i]] for i in range(5))

def subgroup(p):
 elements=[unit];q=p
 while q!=unit:
  elements.append(q);q=compose(p,q)
 return frozenset(elements)
subgroups=defaultdict(set)
for p in G:
 S=subgroup(p)
 if len(S) in (2,3,5):subgroups[len(S)].add(S)
ck('A5-nontrivial-cyclic-subgroups',L355,{k:len(v) for k,v in subgroups.items()}=={2:15,3:10,5:6})
cosets=defaultdict(set)
for k,group_set in subgroups.items():
 for H in group_set:
  for p in G:
   cosets[k].add(frozenset(compose(p,h) for h in H))
ck('A5-cyclic-coset-counts',L355,{k:len(v) for k,v in cosets.items()}=={2:450,3:200,5:72})
index={g:i for i,g in enumerate(G)}
pairs=Counter();rowcounts=Counter()
for k,sets in cosets.items():
 for S in sets:
  els=sorted(index[p] for p in S)
  for i in els:rowcounts[i]+=1
  for a,b in combinations(els,2):pairs[(a,b)]+=1
ck('pairwise-balanced-60-vertices',L355,len(pairs)==math.comb(60,2) and all(n==1 for n in pairs.values()))
ck('722-design-row-valencies',L355,len(cosets[2])+len(cosets[3])+len(cosets[5])==722 and set(rowcounts.values())=={31})
ck('722-design-double-count',L355,450+200*3+72*10==math.comb(60,2))

# Quaternion Hurwitz shell, exact rational coordinates.
points=[]
for j in range(4):
 for v in [-1,1]:
  p=[F(0)]*4;p[j]=F(v);points.append(tuple(p))
points+=list(product([F(-1,2),F(1,2)],repeat=4))
assert len(points)==24 and len(set(points))==24
ck('Hurwitz-unit-radius',L388,all(sum(t*t for t in p)==1 for p in points))

def sphere_moment(exp):
 if any(k%2 for k in exp):return F(0)
 K=sum(exp)//2;numer=1;denom=1
 for k in exp:
  for odd in range(1,k,2):numer*=odd
 for n in range(K):denom*=4+2*n
 return F(numer,denom)
for exps in product(range(6),repeat=4):
 if sum(exps)>5:continue
 avg=sum((math.prod(p[i]**exps[i] for i in range(4)) for p in points),F())/24
 ck('Hurwitz-monomial-exact-design',L388,avg==sphere_moment(exps),exps)
ck('Hurwitz-degree6-sharp-defect',L388,(sum(p[0]**6 for p in points)/24)-sphere_moment((6,0,0,0))==F(1,64))

A=s.zeros(24)
for i,p in enumerate(points):
 for j,q in enumerate(points):
  if i!=j and sum(p[k]*q[k] for k in range(4))==F(1,2):A[i,j]=1
ck('Hurwitz-24cell-nearest-valency',L389,all(sum(A[i,j] for j in range(24))==8 for i in range(24)))
ck('Hurwitz-24cell-96-edges',L389,sum(A)==192)
X=s.Matrix(24,4,lambda i,j:s.Rational(points[i][j].numerator,points[i][j].denominator))
c0=s.ones(24,1)
ck('Hurwitz-adjacency-constant',L389,A*c0==8*c0)
ck('Hurwitz-adjacency-coordinate',L389,A*X==4*X)
quadratic=[]
for a,b in combinations(range(4),2):quadratic.append(X[:,a].multiply_elementwise(X[:,b]))
for j in (1,2,3):quadratic.append(X[:,0].multiply_elementwise(X[:,0])-X[:,j].multiply_elementwise(X[:,j]))
H2=s.Matrix.hstack(*quadratic)
ck('Hurwitz-sampled-lowband-rank14',L389,s.Matrix.hstack(c0,X,H2).rank()==14)
ck('Hurwitz-adjacency-quadratic',L389,A*H2==s.zeros(24,9))
# Exact sampled band isometry from the degree-4 cubature checked above:
# constant has norm one, linears 1/4, and each quadratic moment is identical.
L=A*A/16-s.Rational(3,2)*A+8*s.eye(24)
ck('Hurwitz-Laplace-polynomial-spectrum',L389,L*c0==s.zeros(24,1) and L*X==3*X and L*H2==8*H2)

# Twisted A5 quintet on angular spin-2; compare finite and SU(2) invariant ranks.
char5=[]
for p in G:
 k=len(subgroup(p));char5.append({1:5,2:1,3:-1,5:0}[k])
for k,fin,continu in [(1,0,0),(2,1,1),(3,2,1),(4,11,5)]:
 ck('twisted5-finite-invariant-rank',L386,sum(v**k for v in char5)//60==fin,(k,fin))
# Rational SU(2) tensor-product spins for j=2, fourfold.
mult={2:1}
for k in range(1,5):
 ck('SU2-spin2-fixed-rank',L386,mult.get(0,0)=={1:0,2:1,3:1,4:5}[k],k)
 ck('spin6-tensor-multiplicity',[L385,L386],mult.get(6,0)=={1:0,2:0,3:1,4:6}[k],k)
 new=Counter()
 for j,n in mult.items():
  for JJ in range(abs(j-2),j+3):new[JJ]+=n
 mult=dict(new)
phi=(1+s.sqrt(5))/2
cos72=(s.sqrt(5)-1)/4;cos144=-(s.sqrt(5)+1)/4

def char_spin(j,cos_theta):return s.expand(1+2*sum(s.chebyshevt(m,cos_theta) for m in range(1,j+1)))
for j in range(9):
 tr=(2*j+1+15*char_spin(j,-1)+20*char_spin(j,s.Rational(-1,2))+12*char_spin(j,cos72)+12*char_spin(j,cos144))/60
 ck('A5-invariant-spin-up-to8',[L385,L386],s.simplify(tr)==int(j in (0,6)),(j,tr))

# Cubic invariant comparison of A4 (12), S4 (24), A5 (60) rotational 3-space.
# Rotational character χ3 is 1+2 cos(rotation angle): identity=3, involution=-1,
# 3-cycle=0; A5 five-cycles φ and 1-φ. Centre-even 2T/2O/2I lifts retain these.
# A4 classes: e, three π rotations, eight 2π/3; S4: e, nine π,
# eight 2π/3, six π/2 with χ3=1 for the proper octahedral rotations.
rank3_A4=(3**3+3*(-1)**3+8*0)/12
rank3_S4=(3**3+9*(-1)**3+8*0+6*1**3)/24
rank3_A5=s.simplify((3**3+15*(-1)**3+20*0+12*phi**3+12*(1-phi)**3)/60)
ck('cubic-A4-S4-A5-3space-invariants',L396,(rank3_A4,rank3_S4,rank3_A5)==(2,1,1),(rank3_A4,rank3_S4,rank3_A5))

out={'metadata':{'source_sha256':SHA,'source_file':SRC.name,'title':'New independent finite exact A5/Hurwitz controls','limits':'Exact group finite and sampled low-band identities; not GP3 selection, physical dynamics or generic heat calculation','claim_labels':sorted({x for row in checks for x in row['claim_labels']})},'totals':{'checks':len(checks),'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks)},'checks':checks}
p=Path('/mnt/data/Paper1B-RigorousVerificationBatch5HurwitzResults-v1_1.json');p.write_text(json.dumps(out,indent=2)+'\n')
print(out['totals']);print({k:len(v) for k,v in cosets.items()});print('FILE',p)
