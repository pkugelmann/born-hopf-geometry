"""New independent exact A5 six-axis Desargues / signed-Hodge / Reye checks.
Paper I-B v1.10 source-matched, no physical interpretation.
"""
from __future__ import annotations
from itertools import permutations,combinations
from collections import defaultdict,Counter
from pathlib import Path
import sympy as s,hashlib,json,networkx as nx
src=Path('/mnt/data/audit1b_work/Paper1B-ExceptionalGeometry-v1_10.tex')
sha=hashlib.sha256(src.read_bytes()).hexdigest()
assert sha=='e02e868b02dc3e22bbfae8b4563d7586646f2dc0f215145674dff5fea10854d5'
checks=[]
def ck(name,labels,cond,detail=''):
 good=bool(cond);checks.append({'id':f'B5B-{len(checks)+1:04d}','topic':name,'claim_labels':labels if isinstance(labels,list) else [labels],'passed':good,'detail':str(detail)[:250]});
 if not good: raise AssertionError(f'{name}: {detail}')
L348='p1:thm:v338-signed-petersen-hodge';L359='p1:cor:v340-reye-dodeca-second-neighbour';L363='p1:thm:v341-desargues-rp2-parity';L365='p1:rem:v341-reye-compatibility'
perms=list(permutations(range(5)));ident=(0,1,2,3,4); G=[p for p in perms if sum(p[i]>p[j] for i in range(5) for j in range(i+1,5))%2==0]
compose=lambda p,q:tuple(p[q[i]] for i in range(5))
invert=lambda p:tuple(p.index(j) for j in range(5))

def subgrp(p):
 S=[ident];r=p
 while r!=ident:S.append(r);r=compose(p,r)
 return frozenset(S)
H5=sorted({subgrp(g) for g in G if len(subgrp(g))==5},key=lambda q:sorted(q))
ck('A5-six-Sylow5',L363,len(H5)==6)
axes={H:i for i,H in enumerate(H5)}
def p6(g):
 return tuple(axes[frozenset(compose(compose(g,h),invert(g)) for h in H)] for H in H5)
actions={g:p6(g) for g in perms}
ck('sixaxis-faithful-action',L363,len(set(actions[g] for g in G))==60)
triples=list(combinations(range(6),3))
def act(g,subset):return tuple(sorted(actions[g][i] for i in subset))
orbplus={act(g,triples[0]) for g in G};orbminus=set(triples)-orbplus
ck('two-A5-ten-face-orbits',L363,len(orbplus)==len(orbminus)==10)
ck('sixaxis-complement-orbits',L363,{tuple(i for i in range(6) if i not in t) for t in orbplus}==orbminus)
pairs=list(combinations(range(5),2));pairset={p:set(p) for p in pairs}
def pi5(g,a):return tuple(sorted(g[i] for i in a))
def stabilizer(a):return [g for g in G if pi5(g,a)==a]
facesp={};facesm={}
for a in pairs:
 stab=stabilizer(a)
 fixed=[t for t in orbplus if all(act(g,t)==t for g in stab)]
 ck('unique-stabilizer-fixed-face',L363,len(stab)==6 and len(fixed)==1,(a, fixed))
 facesp[a]=fixed[0];facesm[a]=tuple(i for i in range(6) if i not in fixed[0])
ck('equivariant-sixaxis-faces',L363,all(act(g,facesp[a])==facesp[pi5(g,a)] for g in G for a in pairs))
ck('sixaxis-cross-incidence',L363,all((len(set(facesp[a])&set(facesm[b]))==1)==(not pairset[a]&pairset[b]) for a in pairs for b in pairs))
ck('sixaxis-sameorbit-Petersen',L363,all((len(set(facesp[a])&set(facesp[b]))==2)==(a!=b and not pairset[a]&pairset[b]) for a in pairs for b in pairs))
for g in perms:
 if g in G:continue
 ck('odd-class-exchange-two-face-orbits',L363,all(act(g,facesp[a])==facesm[pi5(g,a)] for a in pairs),g)

n=len(pairs);P=s.zeros(n)
for i,a in enumerate(pairs):
 for j,b in enumerate(pairs):
  if not pairset[a]&pairset[b]:P[i,j]=1
ck('Petersen-graph-spectrum',L363,P.eigenvals()=={s.Integer(3):1,s.Integer(1):5,s.Integer(-2):4})
# Exterior Hodge signed Kneser matrix. Orient ordered 5-letter basis (0,1,2,3,4).
def sign(seq):return (-1)**sum(seq[i]>seq[j] for i in range(len(seq)) for j in range(i+1,len(seq)))
S=s.zeros(n)
for i,a in enumerate(pairs):
 for j,b in enumerate(pairs):
  if P[i,j]:
   m=next(k for k in range(5) if k not in a and k not in b)
   S[i,j]=sign((m,)+a+b)
ck('signed-Petersen-support',[L348,L363],all(abs(S[i,j])==P[i,j] for i in range(n) for j in range(n)))
ck('signed-Hodge-cubic',[L348,L359],S**3==5*S and S.T==S)
ck('signed-Hodge-spectral',[L348,L359],S.eigenvals()=={s.sqrt(5):3,-s.sqrt(5):3,s.Integer(0):4})
T=S*S-3*s.eye(n)
ck('signed-two-step-identities',L359,T*T+T==6*s.eye(n) and S*T==2*S and T*S==2*S)
ck('signed-two-step-spectrum',L359,T.eigenvals()=={s.Integer(2):6,s.Integer(-3):4})

# Signed Petersen L(S), and Desargues L(-A): both 20x20 cubic graphs.
def cover(signing):
 return s.Matrix.vstack(s.Matrix.hstack((P+signing)/2,(P-signing)/2),s.Matrix.hstack((P-signing)/2,(P+signing)/2))
D=cover(S);Des=cover(-P)
ck('dodecahedral-combinatorial-cover',L363,all(x in (0,1) for x in D) and all(sum(D[i,j] for j in range(20))==3 for i in range(20)))
ck('Desargues-bipartite-cover',L363,Des==s.Matrix.vstack(s.Matrix.hstack(s.zeros(10),P),s.Matrix.hstack(P,s.zeros(10))))
ck('Desargues-exact-spectrum',L363,Des.eigenvals()=={s.Integer(3):1,s.Integer(2):4,s.Integer(1):5,s.Integer(-1):5,s.Integer(-2):4,s.Integer(-3):1})
ck('dodecahedral-exact-spectrum',L363,D.eigenvals()=={s.Integer(3):1,s.Integer(1):5,s.Integer(-2):4,s.sqrt(5):3,s.Integer(0):4,-s.sqrt(5):3})
G_D=nx.from_numpy_array(__import__('numpy').array(D.tolist(),dtype=int))
G_des=nx.from_numpy_array(__import__('numpy').array(Des.tolist(),dtype=int))
ck('dodecahedron-20-vertex-isomorphism',[L359,L363],nx.is_isomorphic(G_D,nx.dodecahedral_graph()))
ck('Desargues-20-vertex-isomorphism',L363,nx.is_isomorphic(G_des,nx.desargues_graph()))
D2=D*D-3*s.eye(20)
ck('dodecahedron-dist2-walk',L359,all((D2[i,j] in (0,1)) and (D2[i,j]==1)==(nx.shortest_path_length(G_D,i,j)==2) for i in range(20) for j in range(20)))
# Twelve 5-cycles and their voltage products distinguish two signed covers.
G_P=nx.from_numpy_array(__import__('numpy').array(P.tolist(),dtype=int))
cycles=set()
for x in range(n):
 for a in G_P.neighbors(x):
  for b in G_P.neighbors(a):
   if b in (x,a):continue
   for c in G_P.neighbors(b):
    if c in (x,a,b):continue
    for d in G_P.neighbors(c):
     if d in (x,a,b,c) or not P[d,x]:continue
     seq=[x,a,b,c,d]
     ways=[tuple(seq[i:]+seq[:i]) for i in range(5)]
     rev=list(reversed(seq));ways +=[tuple(rev[i:]+rev[:i]) for i in range(5)]
     cycles.add(min(ways))
ck('Petersen-pentagon-count',L363,len(cycles)==12)
volts=Counter()
for cy in cycles:
 v=1
 for z in range(5):v*=int(S[cy[z],cy[(z+1)%5]])
 volts[v]+=1
ck('dodecahedron-six-plus-six-pentagon-voltage',L363,volts=={1:6,-1:6},dict(volts))
ck('Desargues-negative-pentagons',L363,all((-1)**5==-1 for _ in cycles))
# Exact five-label orientation sign under every S5 permutation.
def wedge_rep(g):
 L=s.zeros(n)
 for j,(a,b) in enumerate(pairs):
  aa,bb=g[a],g[b];ordered=tuple(sorted((aa,bb)))
  L[pairs.index(ordered),j] = 1 if aa<bb else -1
 return L
for g in perms:
 L=wedge_rep(g)
 chi=1 if g in G else -1
 ck('signed-Hodge-S5-pseudoscalar',[L348,L363],L*S*L.T==chi*S,g)

# 25x30 axis-quotient of Reye mixed planes: a mixed (2,3,3) plane becomes
# one Petersen edge from the two unused disjoint pairs and two nonadjacent
# Petersen vertices sharing a singleton.
pet_edges=[(a,b) for i,a in enumerate(pairs) for b in pairs[i+1:] if not pairset[a]&pairset[b]]
pet_nonedges=[(a,b) for i,a in enumerate(pairs) for b in pairs[i+1:] if bool(pairset[a]&pairset[b])]
M=s.zeros(25,30)
for j,(a,b) in enumerate(pet_nonedges):
 delta=tuple(sorted(pairset[a]^pairset[b]));remaining=tuple(sorted(set(range(5))-(pairset[a]|pairset[b])))
 edge=(delta,remaining) if pairs.index(delta)<pairs.index(remaining) else (remaining,delta)
 M[pet_edges.index(edge),j]=1
 M[15+pairs.index(a),j]=M[15+pairs.index(b),j]=1
ck('Reye-25x30-incidence-rank',L359,M.rank()==24)
ck('Reye-25x30-left-null',L359,s.Matrix([[-2]*15+[1]*10])*M==s.zeros(1,30))
ck('Reye-25x30-incidence-degrees',L359,all(sum(M[:,i])==3 for i in range(30)) and all(sum(M[i,:])==2 for i in range(15)) and all(sum(M[i,:])==6 for i in range(15,25)))

out={'metadata':{'source_sha256':sha,'source_file':src.name,'nature':'independent exact A5/Sylow five, RP2 face, Hodge and Reye incidence calculations','limitation':'does not prove continuous geometry, physical realization or the 70/80 embedded binary Reye plane coordinate list','claim_labels':sorted({l for c in checks for l in c['claim_labels']})},'totals':{'checks':len(checks),'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks)},'checks':checks}
p=Path('/mnt/data/Paper1B-RigorousVerificationBatch5BridgesResults-v1_1.json');p.write_text(json.dumps(out,indent=2)+'\n');print(out['totals'],'FILE',p)
