"""Independent exact check of Paper I-B's left-walk/right-regular 5⊗5 orientation.
Source claim p1:prop:v341-walk-kernel-no-petersen-isomorphism.
"""
from pathlib import Path
from itertools import permutations,combinations
import sympy as s,hashlib,json
src=Path('/mnt/data/audit1b_work/Paper1B-ExceptionalGeometry-v1_10.tex')
sha=hashlib.sha256(src.read_bytes()).hexdigest();assert sha=='e02e868b02dc3e22bbfae8b4563d7586646f2dc0f215145674dff5fea10854d5'
checks=[];L='p1:prop:v341-walk-kernel-no-petersen-isomorphism';
def ck(tag,cond,detail=''):
 ok=bool(cond);checks.append({'id':f'B5W-{len(checks)+1:03d}','topic':tag,'claim_labels':[L],'passed':ok,'detail':str(detail)});
 if not ok:raise AssertionError(f'{tag}: {detail}')
G=[p for p in permutations(range(5)) if sum(p[i]>p[j] for i in range(5) for j in range(i+1,5))%2==0];A4=[g for g in G if g[0]==0];pairs=list(combinations(range(5),2));

def perm10(g):return s.SparseMatrix(10,10,{(pairs.index(tuple(sorted((g[a],g[b])))),j):1 for j,(a,b) in enumerate(pairs)})
D=s.Matrix(5,10,lambda i,j:int(i in pairs[j])); P5=s.eye(10)-D.T*(3*s.eye(5)+s.ones(5)).inv()*D
ck('5-irrep-projector-rank',P5.rank()==5 and P5*P5==P5)
ck('A4-order12',len(A4)==12)
# A4 nearest octet: all eight 3-cycles (traces of 2T q with real +1/2).
def order(g):
 e=tuple(range(5));p=e
 for i in range(1,7):
  p=tuple(g[p[k]] for k in range(5))
  if p==e:return i
 raise AssertionError
A4three=[g for g in A4 if order(g)==3]
ck('A4-nearest-octet-eight-3cycles',len(A4three)==8)
Avg=sum((perm10(g) for g in A4three),s.zeros(10))/8
W=P5*Avg*P5
ck('5-irrep-nearest-eigenvalues',W*W==-W/2 and W.rank()==2 and s.trace(W)==-1)
ck('5-irrep-3dim-zero-kernel', (P5+2*W).rank()==3 and W*(P5+2*W)==s.zeros(10))
ck('left-walk-multiplicity-15+10',W.rank()*5==10 and (5-W.rank())*5==15)
# Right regular factor untouched, its 10-dimensional complement is 2 copies of V5.
chi5=lambda g: (5 if order(g)==1 else 1 if order(g)==2 else -1 if order(g)==3 else 0)
def pairchar(g):return sum(tuple(sorted((g[a],g[b])))==(a,b) for a,b in pairs)
ck('two-V5-is-not-Petersen-vertex-representation', 2*chi5(next(g for g in G if order(g)==3)) != pairchar(next(g for g in G if order(g)==3)))
# Moving the selected tetrahedral core changes the left-convolution spectral kernel.
for g in G:
 if g[0]==0:continue
 rg=perm10(g)
 ck('fixed-core-conjugation-changes-left-operator',rg*W*rg.T!=W, g)
# Untwisted transporter coefficient block is 1⊕4 and has no V5 overlap:
# pair-space P5 is orthogonal to the column span of D^T, the permutation 1⊕4.
ck('quintet-orthogonal-to-untwisted-1plus4',P5*D.T==s.zeros(10,5))
res={'metadata':{'source_sha256':sha,'nature':'exact A4 core-averaged 5D representation, not new physical nearest-shell data','source_file':src.name,'scope':'finite left-convolution decomposition and commuting right-regular representation'},'totals':{'checks':len(checks),'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks)},'checks':checks}
p=Path('/mnt/data/Paper1B-RigorousVerificationBatch5WalkResults-v1_1.json');p.write_text(json.dumps(res,indent=2)+'\n');print(res['totals'],'FILE',p)
