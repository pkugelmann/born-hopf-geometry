# Born–Hopf Geometry — Paper I-B Rigorous DAG Audit, Batch 4

**Artifact:** `Paper1B-RigorousVerificationBatch4-v1_1.md`  
**Current source:** `Paper1B-ExceptionalGeometry-v1_10.tex` in `Paper00-PapersMinimal-v3_017(1).zip`  
**Current SHA-256:** `e02e868b02dc3e22bbfae8b4563d7586646f2dc0f215145674dff5fea10854d5`  
**Protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md` with earlier proof-chain verification as lineage, not automatic theorem upgrade  
**Incoming canonical atlas:** `Paper00-DAGAtlas-v1_150(1).zip` (read-only until final batch)  
**Disposition:** `PARTIALLY_AUDITED`; inherited formal claim ordinals **201–300**, inclusive, source-statement and proof revalidation; **323/506** total current formal claims covered across four batches, **183** unreviewed.

## 1. Claim census and source identity

| Status | This batch | Cumulative |
|---|---:|---:|
| `VERIFIED`, inherited under matched printed source and evidence | 75 | 243 |
| `VERIFIED-CONDITIONAL`, earlier Batch 1 | 0 | 5 |
| `FORMALIZED`, definitions or scope remarks | 25 | 75 |
| **Total reviewed** | **100** | **323/506 = 63.83%** |

The current complete **147,528-character** manuscript block beginning at `p1:prop:axial-relative-determinant-line` (line **9254**) and ending before `p1:thm:v563-affine-reflection-inversion` is **byte-identical** in Paper I-B v1.9 and v1.10. Its SHA-256 is `80d47898bb03bf16b454b22ecd23f8a978130b079bb5f7c80ef3f816a7fa768e`. All 100 claim statements and corresponding proof fields also match the earlier v1.7 audited source under normalized comparison. The 75 substantive claims retained `VERIFIED` status only after this identity check, replay of applicable archived mathematical evidence, source-proof examination and scoped adversarial checks. This does **not** mean every theorem has been independently reproved in entirety.

Six substantive statements have no adjacent `proof` environment, but their support is displayed directly, elementary or already imported: `p1:cor:v180-exceptional-scalar-action-orders` (216), `p1:cor:v181-exceptional-common-degree-two-saturation` (218), `p1:prop:v189-tracefree-quadratic-harmonics` (247), `p1:cor:v189-level-one-shear-exclusion` (249), `p1:cor:v557-boundary-scalar-semigroup` (270) and `p1:prop:v191-noncentral-maximal-torus-axis` (281). Lack of a separate adjacent proof is not itself recorded as a missing mathematical premise; their actual formulas and imported scope were checked.

**Reference integrity:** All **37 distinct references** occurring within the statement/proof environments resolve in the current papers corpus (31 local, three to Paper I-A v5.177, three to Paper I-D v1.66); no unresolved/duplicate referenced label. **18 proof-context source citations** are retained as *typed E1 candidate links*, not automatically promoted to verified material E2 dependencies. Cross-paper references are not counted as audits of other manuscripts.

## 2. Evidence: replay versus fresh independent checks

| Mathematical evidence source | Executable controls | Passed | Failed | Scope |
|---|---:|---:|---:|---|
| Historical B4 suite rerun on v1.10 | 399 | 399 | 0 | Main predecessor of claims 201–246 |
| Historical B5 suite rerun on v1.10 | 564 | 564 | 0 | Main predecessor of claims 247–300 |
| Other historical B2/B3/B6/B7 suites rerun on v1.10 | 20,855 | 20,855 | 0 | Mainly other source sectors, **not** 20,855 B4 verifications |
| **Claim-linked IDs in historical B4 and B5** | **819 unique** | **819** | **0** | **309** from B4, **510** from B5; exact old claim-ledger E3 links |
| **New, independently written current-source B4 controls** | **387** | **387** | **0** | **23** material claim IDs; new E3/E4 evidence |

The 819 old claim-linked IDs are a subset of the 963 B4/B5 suite controls, not an additional 819 tests. In total the six replayed historical packages contain **21,818** checks; these are *not* presented as 21,818 new or claim-201–300-specific checks. **64 of 75** substantive claims have historical executable evidence IDs. The remaining **11** have exact/source analytic derivations in the inherited ledger, not executable historical tests. Fresh evidence now directly supplements some of those claims. No previously failed test was suppressed.

### New independent exact results

1. **Joint Hopf–axial signs and connection, and natural determinant line (201–206).** Relative determinant exponents match; the nonparallel quaternionic parents have trivial SO(3) stabilizer and sign descent. For each of three independent quaternionic rotations, the displayed axial connection gives the stated half-spin compensation. The topological Chern/Bockstein statement remains a **separate exact analytic argument**, not falsely replaced by these finite checks.
2. **Ambient cone Clifford fingerprint and restricted symbol grammar (207–214).** A separately generated compressed `Λ^{≤2} R⁴` Clifford model yields eleven exterior dimensions, degree-0/1 radius `R_mom²` and degree-2 radius `R_mom²/2`, while the Pauli spinor block gives `R_mom²`. The source's two-class result is **only** the stated primitive two-word ancestry grammar, not the entire unrestricted natural-symbol universe.
3. **Exceptional uniform designs and sharp frontiers (215–223).** Exact arithmetic in `Q(φ)` checks **every even-coordinate monomial** within total degrees 5, 7 and 11 for `2T, 2O, 2I`, respectively; sign symmetry handles odd-coordinate monomials. Sharp next-degree coordinate defects for `x₀⁶, x₀⁸, x₀¹²` are **`1/64`, `1/256`, `1/4096`**, respectively, in the normalized round-moment difference. The quartic-support uniqueness corollary additionally invokes **external finite-subgroup classification** under its rooted same-owner hypothesis; finite moments alone cannot prove that classification.
4. **Positive 62-node icosahedral rule and Hopf pullbacks (224–225, 237).** Rebuilt the 20 face, 30 edge and 12 vertex orbits directly from golden icosahedron coordinates. Exact Legendre moments `P₂,P₄,P₆,P₈,P₁₀` vanish at the designated invariant test; `P₁₂` is **`7429/33000 ≠ 0`**. Orbit weights `(81,256,125)/462` are positive and sum to one. The 31 uniformly weighted axes instead have `P₆=-6721/111600`; per-endpoint integer coefficients `243,512,625` divided by `27720` agree with the source. These are spherical quadrature identities; the `4π²` Hopf coefficient is the separately normalized pullback measure, not a new contact volume.
5. **Spectral ladders and zeta overlap (226–246).** Independently expanded the three Molien-type rational series through twelve eigenlevels, reproduced `Z_Γ(0)=(5/18,7/18,47/90)`, union `-4/45`, residual `11/30`, and heat coefficients `7/240` and `1/80`. The shared singlet is subtracted exactly once. The overlap proof uses the imported *dense subgroup generated by the aligned* `2O` and `2I` and must not be mistaken for a universal claim about arbitrary embeddings.
6. **Hurwitz exceptional roots, boundary and axis claims (247–283).** The old B5 exact suite reproduced the 96-element icosian complement, E8/E7/E6 root counts, terminal Clifford leakage, 24-cell sextic obstruction and sampling, boundary determinant descent, finite covariant pencils and Q moments. Fresh checks directly recover the unit-axis identity `Q(n)=3−Σnᵢ⁴`, extrema `2` and `8/3`, and note the source's explicit zero-mode restriction on inverse Dirichlet-to-Neumann operators. The Hardy zero-mode statement is an analytic/source scope result; exact finite controls are not a substitute for a full functional-analytic proof.
7. **Triality weights and family return (284–300).** Independently enumerated `V₈,S₈⁺,S₈⁻`, eight neighbors of every 24-cell weight, **32 edges per ordered distinct sector pair**, **192 tagged incidences**, and **32 fixed-slot support triples**. Separately reconstructed the **32 nonzero Spin(8) Fock coefficients** from exterior creation/contraction and wedge-order parity, with modulus `√2` and total Hilbert–Schmidt norm squared **64**. The *unsigned tagged* norm squared **192** and *signed fixed-slot* norm **64** are different objects, with an explicit map between them. The generated `X_G,R_G` commutant is one-dimensional, so positive determinant 192 gives `192^(1/3) I₃` under the **unmarked, fully equivariant** constructor; no noncentral family-direction selector was smuggled in. The four axial support mappings are exact, and the identity trimer map is not an orientation-odd half-step operator.

The reproducible script and all 387 individual current-source checks are included separately, with claim IDs and source SHA. Historical scripts have been source-path/hash adapted for replay; that adaptation is expressly not claimed to be independent authoring.

## 3. Adversarial limits and source-matched verdict

- **Mathematical defects:** **0 new established in-domain counterexamples** for the 100 claims. Exact tests, preserved proof words, source-typed conditions and known boundary exclusions were checked; no stronger claim was silently substituted.
- **Conditional/constitutional:** One must not equate mathematical orbit/frame support with physical occurrence. The primitive-symbol classification is *grammar-relative*. The quartic comparison-support claim assumes a rooted `2T` and a finite same-owner support. Tensor sign-line holonomy, scalar Hopf pullback and spinorial quotient modes have different typed domains. The boundary DtN constant mode is zero and cannot be inverted without a spectral-domain restriction. These are source-scoped conditions, **not** new gaps.
- **External proof lineage:** The classifications of exceptional finite SU(2) subgroups and F4 reflection invariants, as well as continuum spectral/Dirac facts, retain their imported statuses. The independently rebuilt finite objects do not reprove every external theorem.
- **DAG integrity:** Existing canonical issue roots remain; this interim batch creates no unreviewed assumption duplicates, does not promote bare citations to proof edges, and does not edit the source or global graph.

## 4. Full outstanding inherited issue register

| Stable issue ID | Type | Status/precise remaining obligation |
|---|---|---|
| `BH-IBX-EV-0001` | E3 evidence | Batch 2 pentagon/reciprocal exact certificate **passed**; reconcile existing archived `OPEN` flag and source-current proof-route evidence at final ZIP. |
| `BH-IBX-EV-0002` | E3 evidence | Batch 2 600-cell 50-vertex adjacency/quotient certificate **passed**; final provenance/status reconciliation. |
| `BH-IBX-EV-0003` | E3 evidence | Batch 2 `Q₈` channels exact certificate **passed**; final provenance/status reconciliation. |
| `BH-IBX-EV-0004` | E3 evidence | Batch 2 20-dimensional tangent sequence check **passed**; final provenance/status reconciliation. |
| `BH-IBX-EV-0005` | E3 evidence | Batch 2 five-root leakage and source-side Gram check **passed**; final provenance/status reconciliation. |
| `BH-IBX-EV-0006` | E3 evidence | Batch 2 15×15 quadrupole tensor certificate **passed**; final provenance/status reconciliation. |
| `BH-IBX-EV-0009` | Mathematical/E3 | Source theorem `p1:thm:v339-petersen-sl4-isometry`, archived origin around source v1.7 line 14636, lies **after** the present range; needs its own source-matched in-domain adjudication. |
| `BH-IBX-DAG-0003` | Graph coverage | Source v1.10's 23 appended claims from Batch 1 await full integration into the global Atlas graph. |
| `BH-IBX-DAG-0004` | Graph/evidence scope | The archive's resolved 600-chamber evidence record and more conservatively conditional claim statuses must be reconciled **claim by claim**, not globally upgraded. |

`BH-IBX-DAG-0001/0002` are **resolved** in the supplied atlas and are not reopened. The earlier issue `BH-IBX-SRC-0001` is also inherited as resolved. No newly verified material dependency impact reaches a physical observable merely from the finite identities in this batch.

## 5. Machine records, provenance, and handoff

The companion `Paper1B-RigorousVerificationBatch4Ledger-v1_1.json` freezes all **100 SOURCE-AS-PRINTED statements** and proofs, source line ranges/hashes, historical evidence IDs, fresh exact test IDs, 37 current reference owners, 18 unpromoted proof-context candidate edges, source-scope exclusions and the inherited issue register. `...EvidenceSummary-v1_1.json` lists detailed evidence coverage with replay/new-test distinction. All checks are portable Python/SymPy controls using the frozen current `.tex` SHA.

**Next batch:** inherited claims **301–400**; remaining after it would be **401–483** (83 inherited) with final DAG and audit ZIP consolidation. No ZIP is issued in Batch 4. The only final-batch archive write will preserve the whole canonical graph and audit ancestry, integrate new current-source claims and typed reviewed dependencies, prune superseded file versions, and verify archive read-back. This run did not modify the PapersMinimal ZIP, source manuscript, upstream proofs, or axioms.
