# Paper I-B — Rigorous Verification DAG Audit, Batch 3

**Artifact:** `Paper1B-RigorousVerificationBatch3-v1_1.md`  
**Protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md` (source-first, independent E3 and adversarial E4 evidence; no theory repairs). The historical proof-chain protocol is applied only to protect previously proven dependencies.  
**Current source:** `Paper1B-ExceptionalGeometry-v1_10.tex` inside `Paper00-PapersMinimal-v3_017(1).zip`.  
**Source SHA-256:** `e02e868b02dc3e22bbfae8b4563d7586646f2dc0f215145674dff5fea10854d5`.  
**Incoming atlas:** `Paper00-DAGAtlas-v1_150(1).zip` (preserved, not modified).  
**Classification:** `PARTIALLY_AUDITED`: inherited formal claims 101–200 revalidated; **223/506** current formal statements covered cumulatively. No new in-domain mathematical contradiction established. This report does **not** purport to re-prove the imported elliptization theorem or external exact semidefinite-programming certificate.

## 1. Coverage and source integrity

Current formal-environment ordinals **101–200**, inclusive, begin at `p1:thm:hurwitz-units-maximal-order` and end at `p1:cor:v570-rooted-primal-dual-singlet-return`; the comparison ends immediately before ordinal 201 `p1:prop:axial-relative-determinant-line`. Source sectors are the maximal Hurwitz order, spherical space-form quotients, the 15-dimensional level-one representation module, protected completion / Clifford algebra, 24-cell shells, the Bose–Mesner 9+15 vertex-function split, rooted trimers, finite transport and primal–dual 24-cell overlap.

- The **entire 197,085-character current-source slice** for claims 101–200 — including all intervening equations, definitions, proof text and informal scope statements — is **byte-identical** between Paper I-B v1.9 and v1.10. Compare hash `3a3c8467cb823c91920457ab83292bbe62838c5eb04c1bbfe54bca81c2775d6d`.
- All **100** formal statements match their v1.7 historical audit source record after whitespace normalization; **96** historical proof fields (including intentionally empty definition/remark fields) likewise match. The other **four** are deferred appendix proofs, each present and checked in current v1.10. This is *not* a mismatch in the current manuscript. A separately source-noted fifth corollary is a **direct displayed computation** with an explicit earlier appendix reference; no following `proof` environment is asserted for it.
- All **76** distinct referenced labels in these claim statements and attached proofs resolve. **Nine** have current owner in Paper I-A v5.177, including the level-one representation package and spectral identities; these imports are preserved as cross-paper imports rather than counting Paper I-A as audited in this run.
- **57** potential proof-use citations have been source-indexed as **candidates**. A text citation is not automatically an E2 material edge, and no newly inferred material edge is promoted by string matching.
- No manuscript, original archive, G0/GP1–GP3 axiom, physical-actualization constructor, or source equation has been changed.

### Claim status

| Status | This batch (101–200) | Cumulative through Batch 3 |
|---|---:|---:|
| VERIFIED (historical verdict source-revalidated; see evidence modes below) | 73 | 168 |
| VERIFIED-CONDITIONAL | 0 | 5 |
| FORMALIZED (defined or source scope/boundary recorded) | 27 | 50 |
| **Total audited statements** | **100** | **223 / 506** |
| **Remaining, not yet independently revalidated by this run** | — | **283** |

The 27 FORMALIZED objects comprise **15 definitions and 12 explicit remarks**. The 73 VERIFIED objects comprise **24 theorems, 25 propositions and 24 corollaries**. Previously verified verdicts are maintained only with source match, archived E1/E3 evidence lineage and appropriately typed E4 exclusions; this is **not** an assertion that 73 full theorems were newly reproved from scratch in this batch.

## 2. Exact evidence replay: 604 historical checks and 50 fresh checks

All three archived independent test packages have been rerun against the **current source hash**. Mathematical checking code is retained; only the current source-path/hash assertion has been updated. Results:

| Evidence suite | Replayed exact controls | Passed | Failed |
|---|---:|---:|---:|
| Archived Paper I-B batch 2 | 115 | 115 | 0 |
| Archived Paper I-B batch 3 | 90 | 90 | 0 |
| Archived Paper I-B batch 4 | 399 | 399 | 0 |
| **Historical replay total** | **604** | **604** | **0** |
| New, independently written current-source batch 3 checks | **50** | **50** | **0** |

The **604** are *suite-level replay coverage*, not 604 fresh or necessarily claim-101–200 controls. Exactly **188 distinct archived test IDs** are claim-linked to the 100 audited statements. **52 of 73** previously VERIFIED claims have explicit archived executable E3 IDs in this batch. **21** retain independently reviewed **written/source mathematical evidence rather than executable historic E3 IDs** (full IDs in the claim ledger). The new 50 controls supplement but do not silently replace those different evidence modes. A failing historical test would have prevented blind retention.

### Independent source-matched results

**(a) Hurwitz quaternion units and the 24-cell.** Independently enumerated all **24 norm-one Hurwitz units** with rational arithmetic and tested closure/multiplication. Reconstructed the 24-cell nearest-neighbor adjacency with characteristic eigenvalues **8 (multiplicity 1), 4 (4), 0 (9), −2 (8), −4 (2)**, antipodal involution, exact dot-product/common-neighbor counts, first-moment cancellation and tight frame `QᵀQ=6I₄`. The fourth moment of the 24-cell matches the required degree-four spherical invariant at a nontrivial test direction.

**(b) Bose–Mesner and trimer interface.** Recomputed the symmetric 24×24 adjacency algebra and exact idempotent orthogonal projectors **P₉** and **P₁₅** (ranks **9** and **15**, respectively), plus source-defined trimer compressions. Important type boundary: **`E_{15}^{BM}` is a 15-dimensional 24-vertex-function submodule, whereas `H_1` is a 15-dimensional representation-theoretic level-one carrier. Equal dimension does not identify them.**

**(c) The left-`2T` no-injection theorem and scalar bridge.** From exact quaternionic character averages, the selected `H_1` under restricted left `2T` has **six invariant directions**, while the regular 24-vertex-function representation has **one**, excluding the claimed *full* equivariant injection by invariants. The paper instead gives a correctly narrower **five-dimensional scalar evaluation bridge**, whose isometry and adjacency eigenspaces were independently checked. No canonical `H_1 ≅ E_{15}^{BM}` map is asserted.

**(d) Rooted family / return algebra and dual support.** Reconstructed every displayed source-shell trimer Gram pattern for the **M6, G7, G9, N8, G16 and full 2T** supports. Nine noncommuting words `R^a J R^b` span **`M₃(C)`** with rank nine. Verified the primal–dual 24-cell rooted return **(6,6,6)** and the dual layer counts **(6,12,6)** by a separate coordinate construction; these are finite-geometric, not selected physical flavor/decay amplitudes.

**(e) Protected Clifford completion and E4 exclusions.** An independent Pauli-tensor Euclidean Clifford model reproduces the four gamma anticommutators, the positive-scale quadratic radius and chirality ranks. It also exhibits the **zero protected-magnitude stratum**, where the inverse-normalized gamma formula is undefined; the paper explicitly restricts it. Replayed archived compressed-exterior checks cover the terminal-degree loss. `rho_C` need not equal `R_mom` outside the optionally matched cone representative.

**(f) Quotient and finite algebra boundary.** Finite antipodal deck action and nearest-graph symmetry agree with the source's general scalar quotient theorem **as examples, not complete substitutes for functional-calculus proof**. Independently verified a quaternionic example where left `2T` does not preserve a chosen *left* Hopf-axis circle; this must not be confused with the commuting *right* Hopf action. Deferred appendix counterproducts demonstrate that degreewise boundary quotient is generally **not an algebra**; an independent finite Haar-moment toy compression demonstrates coordinate-radius leakage.

**(g) External theorem lineage.** Source claim `p1:thm:elliptization-spherical-space-form` is explicitly an **imported geometrization/elliptization theorem**, with its standard closed/connected/orientable and curvature hypotheses. No new source proof or computational verification of Perelman's theorem is fabricated. Within `p1:thm:s3one-classical-completions`, the **uniqueness** of the optimal dimension-four 24-point kissing configuration is properly attributed to David de Laat, Nando Leijenhorst and Willem de Muinck Keizer, *Optimality and uniqueness of the D₄ root system*, arXiv:2404.18794 (2024). Its external exact SDP proof is not recreated; source internal exact checks verify the local 24-cell object and its properties. The source explicitly does **not** claim universal optimality.

## 3. Four deferred proofs and one direct-display formula

| Claim | Present controlling source proof | Verdict |
|---|---|---|
| `p1:prop:boundary-quotient-not-algebra` | Appendix `p1:app:boundary-quotient-obstruction` (from line 11291) | Deferred appendix present; algebra-ideal failure sound |
| `p1:rem:symmetric-vs-clifford-quadratic` | Appendix `p1:app:truncated-quadratic-content` (from line 11107) | Source-scope reminder matched to actual algebraic content |
| `p1:prop:finite-coordinate-compression-defect` | Appendix `p1:app:coordinate-clifford-obstructions` (from line 11092; earlier leakage proposition at 11000) | Source proof present and consistent with independent compression check |
| `p1:prop:h1-e15-left-2t-obstruction` | Appendix `p1:app:left-2t-carrier-obstruction` (from line 11323) | Exact character and invariants obstruction independently reproduced |
| `p1:cor:clifford-level-one-values` | Current main-text formulas at line 5790 and referenced terminal-degree proof at `p1:prop:terminal-degree-leakage` (11000–11039) | Direct displayed computation; no falsely invented adjacent `proof` block |

This separates **missing attached proof syntax** from **missing proof**; no new formal gap is opened where the existing source supplies the derivation elsewhere.

## 4. Adversarial review and issue ledger

1. **Invalid stronger identification:** `dim H₁=dim E₁₅ᴮᴹ=15` does **not** imply equivariant isomorphism. Indeed the actual left-2T invariants contradict the stronger full injection; the source's scalar five-channel bridge is logically separate.
2. **Invalid positive branch upgrade:** Protected `Γ` needs `rho_C>0`; the mathematically allowed zero stratum is not to be divided by `rho_C`.
3. **Invalid truncated-algebra upgrade:** The finite-degree quotient does not inherit ordinary multiplication by default; compression can and demonstrably does change coordinate quadratic radius.
4. **Invalid quotient-spinor upgrade:** The scalar Laplacian quotient argument may pass through functional calculus, but spinor assertions require an appropriate chosen lift/spin structure. Finite graph examples are not a proof of all quotient operator domains.
5. **Invalid external-optimality upgrade:** 24-cell internal Gram and adjacency arithmetic does not re-prove the external spherical-code uniqueness SDP theorem, nor establish universal optimality.
6. **Invalid physical realization:** `2T`, the 24-cell shell and `M₃(C)` are finite mathematical structures here, not by themselves actual particles, masses, physical flavor transitions or decay couplings.

These are **source-stated boundaries or invalid potential challenges**, not new source contradictions.

### Open inherited items (not silently closed)

| Issue ID | Current audit treatment |
|---|---|
| `BH-IBX-EV-0001` through `EV-0006` | Batch 2 mathematical certificates passed; **formal registry status reconciliation deferred to final ZIP** |
| `BH-IBX-EV-0009` | **OPEN** in a later source section, not adjudicated by batch 3 |
| `BH-IBX-DAG-0003` | New 23 statements from batch 1 awaiting full atlas integration |
| `BH-IBX-DAG-0004` | Pre-existing 600-chamber evidence versus conditional-claim status reconciliation, awaiting final DAG adjudication |
| Historical `BH-IBX-DAG-0001` and `0002` | Resolved in incoming atlas; **not reopened** |

**New issues found in this batch: zero.** The existence of inherited open coverage/evidence issues does not establish an in-domain counterexample. No new assumptions are introduced, no paper repaired, and no one-off physical model is created.

## 5. DAG and artifact integrity, handoff

The companion `Paper1B-RigorousVerificationBatch3Ledger-v1_1.json` records all 100 claims with full **current SOURCE-AS-PRINTED** statements, source line spans, proof material/appendix locators, current source and individual statement hashes, legacy statuses and E1/E3/E4 evidence, exact historical test IDs and new checks, 76 resolved citations and quarantined proof-use candidates. `...EvidenceSummary-v1_1.json` records executable suite counts and the imported optimality limitation.

**Portable controls:** one newly written independent test script/result pair; three **source-hash-adapted** archived suite script/result pairs. Scripts need Python and SymPy and the current `Paper1B-ExceptionalGeometry-v1_10.tex` in the documented working folder. The preserved original archive material is unchanged. This single coordinated run did not use simultaneous subagents; complementary source/E1, algebraic E3, adversarial E4 and graph-lineage checks were carried out sequentially.

**Coverage:** **223/506 = 44.07%**. Next batch is inherited **201–300**. The remaining 283 inherited claims are not given this run's revalidation status. **No updated DAG Atlas ZIP or ProofChain Audits ZIP is produced in batch 3**: both are reserved for the **final batch**, when source-backed issue reconciliation, full atlas integration, version pruning, manifest verification and archive read-back will be performed.
