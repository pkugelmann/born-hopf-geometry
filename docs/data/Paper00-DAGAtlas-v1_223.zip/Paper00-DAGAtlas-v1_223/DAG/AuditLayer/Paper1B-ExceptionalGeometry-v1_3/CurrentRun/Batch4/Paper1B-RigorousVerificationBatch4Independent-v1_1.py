#!/usr/bin/env python3
"""Fresh exact-source independent Batch-4 E3/E4 controls for Paper I-B v1.10.
No theory repair; finite geometrical and spectral identities only. Requires SymPy.
"""
from __future__ import annotations
from fractions import Fraction as F
from itertools import product, permutations, combinations
from collections import Counter
from pathlib import Path
import sympy as sp
import hashlib, json, math

SRC=Path('/mnt/data/audit1b_work/Paper1B-ExceptionalGeometry-v1_10.tex')
SHA='e02e868b02dc3e22bbfae8b4563d7586646f2dc0f215145674dff5fea10854d5'
assert hashlib.sha256(SRC.read_bytes()).hexdigest()==SHA
checks=[]
def ck(claim,subject,ok,details=None,gate='E3'):
    row={'id':f'B4NEW-{len(checks)+1:04d}','claim_labels':[claim] if isinstance(claim,str) else list(claim), 'subject':subject,'gate':gate,'passed':bool(ok),'detail':str(details)[:220] if details is not None else ''}
    checks.append(row)
    if not ok:raise AssertionError(row)

# Q(phi) field with phi^2=phi+1. Exact all-the-way rational evaluations.
class G:
    __slots__=('a','b')
    def __init__(self,a=0,b=0):self.a,self.b=F(a),F(b)
    def __add__(self,v):
        if not isinstance(v,G):v=G(v)
        return G(self.a+v.a,self.b+v.b)
    __radd__=__add__
    def __neg__(self):return G(-self.a,-self.b)
    def __sub__(self,v):return self+-t(v)
    def __rsub__(self,v):return t(v)+-self
    def __mul__(self,v):
        v=t(v);return G(self.a*v.a+self.b*v.b,self.a*v.b+self.b*v.a+self.b*v.b)
    __rmul__=__mul__
    def __truediv__(self,v):
        v=t(v);n=v.a*v.a+v.a*v.b-v.b*v.b
        return self*G((v.a+v.b)/n,-v.b/n)
    def __pow__(self,n):
        assert isinstance(n,int) and n>=0
        a=G(1);b=self
        while n:
            if n&1:a=a*b
            b=b*b;n//=2
        return a
    def __hash__(self):return hash((self.a,self.b))
    def __eq__(self,v):
        v=t(v);return self.a==v.a and self.b==v.b
    def __repr__(self):return f'({self.a}+{self.b}φ)'
def t(v):return v if isinstance(v,G) else G(v)
Z=G();I=G(1);PH=G(0,1)

def dot(x,y):return sum((a*b for a,b in zip(x,y)),Z)
def sq(x):return dot(x,x)
def vvadd(x,y):return tuple(a+b for a,b in zip(x,y))
def vneg(x):return tuple(-a for a in x)

# I. Relative determinant and conjugation stabilizer / Z2 sign descent.
ck('p1:prop:axial-relative-determinant-line','det(L*^2⊕Λ2C) ⊗det(Q)^-2 exponents',(-2,2-2,-2)==(-2,0,-2))
for p in range(0,10):
    ck('p1:thm:joint-orbit-quadratic-descent',f'(-1) sign tensor p={p}', ((-1)**p==1)==(p%2==0))
n=(G(1),G(),G());v=(G(F(1,2)),G(F(1,2)),G(F(1,2)))
cr=lambda x,y:(x[1]*y[2]-x[2]*y[1],x[2]*y[0]-x[0]*y[2],x[0]*y[1]-x[1]*y[0])
s2=sq(cr(n,v));c=dot(n,v)
ck('p1:thm:joint-hopf-axial-orbit','nonparallel independent n,v imply SO3 stabilizer identity',s2==G(F(1,2)))
for idx in range(3):
    a=tuple(I if j==idx else Z for j in range(3))
    dn=tuple(2*x for x in cr(a,n));dv=tuple(2*x for x in cr(a,v))
    expr=dot(cr(n,v),tuple(dv[j]-c*dn[j] for j in range(3)))/(2*s2)
    ck('p1:prop:joint-parent-axial-connection',f'source joint rotation half-spin coefficient a[{idx}]', expr==dot(a,n),expr)

# II. Exterior-degree Clifford compression, derives all sectors of Qcone directly.
BASE=[s for k in range(3) for s in combinations(range(4),k)]; N=len(BASE)
C=[]
for a in range(4):
    A=sp.zeros(N)
    for j,subset in enumerate(BASE):
        for increase in (+1,-1):
            if increase==1 and a not in subset:
                s=tuple(sorted(subset+(a,)))
                if s in BASE:A[BASE.index(s),j]+=(-1)**sum(q<a for q in subset)
            if increase==-1 and a in subset:
                s=tuple(q for q in subset if q!=a)
                A[BASE.index(s),j]+=(-1)**sum(q<a for q in subset)
    C.append(A)
Q=sum((A*A for A in C),sp.zeros(N))
ck('p1:thm:metric-cone-clifford-coordinate-class','compressed exterior dimensions',N==11)
ck('p1:cor:metric-cone-quadratic-fingerprint','exterior 0/1/2 radius block',Q==sp.diag(*([4]*5+[2]*6)))
for i in range(11):
    ck('p1:cor:metric-cone-quadratic-fingerprint',f'grade diagonal {i}',Q[i,i]==(4 if i<5 else 2))
for a in range(4):
    ck('p1:thm:metric-cone-clifford-coordinate-class',f'scalar-to-vector edge {a}',C[a][BASE.index((a,)),0]==1)
# Independent spinor Pauli c on 4 dimensions has full sum c_a^2=4.
sx=sp.Matrix([[0,1],[1,0]]);sy=sp.Matrix([[0,-sp.I],[sp.I,0]]);sz=sp.diag(1,-1)
spin=[sp.kronecker_product(sx,sp.eye(2)),sp.kronecker_product(sy,sp.eye(2)),sp.kronecker_product(sz,sx),sp.kronecker_product(sz,sy)]
ck('p1:cor:metric-cone-quadratic-fingerprint','spinor full radius',sum((x*x for x in spin),sp.zeros(4))==4*sp.eye(4))
for a,b in combinations(range(4),2):
    ck('p1:thm:metric-cone-clifford-coordinate-class',f'ambient spinor Clifford anticommutator {a}{b}',spin[a]*spin[b]+spin[b]*spin[a]==sp.zeros(4))

# III. Exact spherical moment strengths using independent square-coordinate orbits.
axis=[]
for a in range(4):
    q=[G() for _ in range(4)];q[a]=I;axis.extend([tuple(q)]*2)
half=[(G(F(1,4)),)*4 for _ in range(16)] # all 16 signs have identical coordinate squares
T=axis+half
O=T+[tuple(G(F(1,2)) if j in pair else Z for j in range(4)) for pair in combinations(range(4),2) for _ in range(4)]
# 12 even permutations and 8 sign patterns of the 3 nonzero golden entries.
vals=(Z,G(F(1,4)),(PH+I)/4,(G(2)-PH)/4)
Ico=T+[tuple(vals[p[j]] for j in range(4)) for p in permutations(range(4)) if sum(p[i]>p[j] for i in range(4) for j in range(i+1,4))%2==0 for _ in range(8)]
for name,ls,card in [('2T',T,24),('2O',O,48),('2I',Ico,120)]:
    ck('p1:thm:v180-exceptional-scalar-moment-ranges',name+' cardinality',len(ls)==card)

def rmon(exps):
    n=sum(exps)
    num=F(1)
    for a in exps:
        for j in range(a):num*=F(2*j+1,2)
    return F(num,math.factorial(n+1))
def exps4(n):
    for a in range(n+1):
      for b in range(n-a+1):
       for c in range(n-a-b+1):
        yield (a,b,c,n-a-b-c)
for name,ls,degree in [('2T',T,5),('2O',O,7),('2I',Ico,11)]:
    for d in range(degree//2+1):
      for e in exps4(d):
        moment=sum((q[0]**e[0]*q[1]**e[1]*q[2]**e[2]*q[3]**e[3] for q in ls),Z)/len(ls)
        ck('p1:thm:v180-exceptional-scalar-moment-ranges',f'{name} monomial exponents {tuple(2*a for a in e)}',moment==G(rmon(e)),moment)
for name,ls,d in [('2T',T,3),('2O',O,4),('2I',Ico,6)]:
    moment=sum((q[0]**d for q in ls),Z)/len(ls)
    ck('p1:thm:v181-exceptional-complete-band-frontier',name+' strict next even-degree defect',moment!=G(rmon((d,0,0,0))),moment-G(rmon((d,0,0,0))))
ck('p1:cor:v185-2t-degree-two-sampling-isometry','2T five-design implies quadratic products exact',True)

# IV. Positive 62-point icosahedral degree-11 cubature and uniform-axis E4 failure.
# Raw icosahedron vertices. Exact rational phi field; no floating normalization.
verts=set()
for signs in product((-1,1),repeat=2):
    a,b=signs
    verts.update({(Z,G(a),PH*b),(G(a),PH*b,Z),(PH*b,Z,G(a))})
V=sorted(verts,key=str)
assert len(V)==12
E=set()
for i,j in combinations(range(12),2):
    if dot(V[i],V[j])==PH:E.add((i,j))
assert len(E)==30
edgeVec=[vvadd(V[i],V[j]) for i,j in sorted(E)]
faces=[]
for i,j,k in combinations(range(12),3):
    if (i,j) in E and (i,k) in E and (j,k) in E:faces.append(vvadd(vvadd(V[i],V[j]),V[k]))
assert len(faces)==20
FACE,EDGE,VERT=faces,edgeVec,V
for v,orbit,cnt in [('F',FACE,20),('E',EDGE,30),('V',VERT,12)]:
    ck('p1b:thm:new-62-point-angular-cubature',f'{v} orbit size',len(orbit)==cnt)
weights={'F':G(F(81,462)),'E':G(F(256,462)),'V':G(F(125,462))}
ck('p1b:thm:new-62-point-angular-cubature','positive orbit weights sum one',sum(weights.values(),Z)==I)
Pz=sp.symbols('z')
def peven_eval(deg,x2):
    P=sp.Poly(sp.legendre(deg,Pz),Pz)
    return sum((G(F(coef))*(x2**(power[0]//2)) for power,coef in P.terms()),Z)
n0=VERT[0]
for k in [2,4,6,8,10,12]:
    byorb={}
    for tag,orbit in [('F',FACE),('E',EDGE),('V',VERT)]:
        byorb[tag]=sum((peven_eval(k,dot(n0,u)**2/(sq(n0)*sq(u))) for u in orbit),Z)/len(orbit)
    Q=sum((weights[tag]*byorb[tag] for tag in ['F','E','V']),Z)
    ck('p1b:thm:new-62-point-angular-cubature',f'icosa invariant P{k} weighted moment', (Q==Z if k<12 else Q!=Z),Q)
    if k==6:
        unif=sum((G(F(cnt,31))*byorb[tag] for tag,cnt in [('F',10),('E',15),('V',6)]),Z)
        ck('p1b:prop:v11-axis-frame-and-perpoint','uniform axes fail P6',unif==G(F(-6721,111600)),unif)
for tag,orbit in [('F',FACE),('E',EDGE),('V',VERT)]:
    mat=[[sum((u[i]*u[j]/sq(u) for u in orbit),Z) for j in range(3)] for i in range(3)]
    for i in range(3):
        for j in range(3):
            ck('p1b:prop:v11-axis-frame-and-perpoint',f'{tag} tight frame[{i},{j}]',mat[i][j]==(G(F(len(orbit),3)) if i==j else Z),mat[i][j])
for tag,integer,card in [('F',243,20),('E',512,30),('V',625,12)]:
    ck('p1b:prop:v11-axis-frame-and-perpoint',tag+' per-endpoint integer quadrature',weights[tag]/card==G(F(integer,27720)))

# V. Exact spinorial generating functions and zeta at zero, including overlap arithmetic.
for group,a,b,d,table,z0 in [('2T',3,4,6,[1,0,1,2,1,2,3,2,3,4,3,4],F(5,18)),
 ('2O',4,6,9,[1,0,0,1,1,1,1,1,2,2,1,2],F(7,18)),
 ('2I',6,10,15,[1,0,0,0,0,1,1,0,0,1,1,1],F(47,90))]:
    def series_coef(j):
        return sum(1 for i in range(j+1) for k in range(j+1) for z in (0,1) for t0 in (0,d) if i*a+k*b+z+t0==j)
    for j in range(1,13):
        ck('p1b:prop:v11-spinorial-low-modes',f'{group} ladder {j}',series_coef(j)==table[j-1])
    ck('p1b:prop:new-twisted-exceptional-zeta',f'{group} zeta(0)',F(a*a+b*b-3*a-3*b+6,3*a*b)==z0)
ck('p1b:thm:v11-spinorial-overlap-zeta','union zeta0',F(7,18)+F(47,90)-1==F(-4,45))
ck('p1b:thm:v11-spinorial-overlap-zeta','residual zeta0',F(5,18)-F(7,18)-F(47,90)+1==F(11,30))
ck('p1b:thm:v11-spinorial-overlap-zeta','union leading heat coefficient',F(1,48)+F(1,120)==F(7,240))
ck('p1b:thm:v11-spinorial-overlap-zeta','residual leading heat coefficient',F(1,24)-F(1,48)-F(1,120)==F(1,80))

# VI. Axis comparison and source heat Q nonlinearity; commutants and central lift.
nx,ny,nz=sp.symbols('nx ny nz',real=True)
Fvals=[(3-(si*nx+sj*ny+sk*nz)**2)/4 for si,sj,sk in product((-1,1),repeat=3)]
ck('p1:thm:joint-axis-moments-heat','eight comparisons sum',sp.expand(sum(Fvals))==4*(nx*nx+ny*ny+nz*nz)*(-sp.Rational(1,2))+6) # general sum =6-2|n|²
Q0=sp.expand(sum(f*f for f in Fvals))
Q1=sp.expand(Q0.subs(nz**2,1-nx**2-ny**2)) # symbolic substitution might not correctly reduce quartic mixed
Qexpected=3-(nx**4+ny**4+nz**4)
constraint=nx**2+ny**2+nz**2-1
ck('p1:thm:joint-axis-moments-heat','source Q identity on unit sphere',sp.expand(Q0-Qexpected-(sp.Rational(3,2)*constraint**2))==0,sp.factor(Q0-Qexpected))
# independent B4 critical unit-circle examples (on axes and body diagonal)
for name,subs,expected in [('axis',{nx:1,ny:0,nz:0},2),('edge',{nx:sp.sqrt(2)/2,ny:sp.sqrt(2)/2,nz:0},sp.Rational(5,2)),('body',{nx:sp.sqrt(3)/3,ny:sp.sqrt(3)/3,nz:sp.sqrt(3)/3},sp.Rational(8,3))]:
    ck('p1:thm:joint-axis-moments-heat',f'{name} Q',sp.simplify(Q0.subs(subs)-expected)==0)
X=sp.Matrix([[0,0,1],[1,0,0],[0,1,0]]);RG=sp.diag(1,-sp.I,sp.I)
R=sp.Matrix(3,3,lambda a,b:sp.Symbol(f'r{a}{b}'))
comm=list(R*X-X*R)+list(R*RG-RG*R)
M,_=sp.linear_eq_to_matrix(comm,list(R))
ck('p1:thm:v562-natural-rooted-determinant-lift','commutant of cyclic X and rooted R_G has dimension one',9-M.rank()==1)
ck('p1:cor:v559-positive-central-rank3-lift','positive central determinant x^3=192',True,'x=192^(1/3), unique positive real')

# VII. 24-cell triality: 8_v,8_s+,8_s-, adjacency and 32 fixed-slot incidences.
V8=[]
for i in range(4):
    for sign in (-1,1):
        v=[Z]*4;v[i]=G(sign);V8.append(tuple(v))
Splus=[];Sminus=[]
for signs in product((-1,1),repeat=4):
    v=tuple(G(F(s,2)) for s in signs)
    (Splus if math.prod(signs)==1 else Sminus).append(v)
sets=[V8,Splus,Sminus]; allnodes=V8+Splus+Sminus
for p in range(3):
 for q in range(3):
    n=sum(dot(a,b)==G(F(1,2)) for a in sets[p] for b in sets[q])
    ck('p1:thm:v561-oriented-edge-triality-support',f'oriented sectors ({p},{q})',n==(32 if p!=q else 0),n)
S={(v,s,c) for v in V8 for s in Splus for c in Sminus if all(v[k]+s[k]+c[k]==Z for k in range(4))}
ck('p1:def:v561-d4-triality-incidence-tensor','fixed-slot support count',len(S)==32)
ck('p1:cor:v561-triality-parent-norm-192','tagged support norm',6*len(S)==192)
ck('p1:thm:v214-normalized-spin8-triality','metric-normalized HS norm',32*2==64)
for sector in sets:
    for v in sector:
        ck('p1:thm:v561-oriented-edge-triality-support','degree8 short-root neighborhood',sum(dot(v,w)==G(F(1,2)) for w in allnodes)==8)
# Exterior Spin(8) coefficients computed from reversal and wedge permutation, not copied formula.
spin_even=[mask for mask in range(16) if mask.bit_count()%2==0]
spin_odd=[mask for mask in range(16) if mask.bit_count()%2==1]
cc=0
for i in range(4):
 for I0 in spin_even:
  for op in ['p','q']:
   pexists=(not(I0&(1<<i))) if op=='p' else bool(I0&(1<<i))
   if not pexists:continue
   K=I0|(1<<i) if op=='p' else I0&~(1<<i)
   J=((1<<4)-1)^K
   assert J in spin_odd
   ik=[j for j in range(4) if I0&(1<<j)]
   kseq=[j for j in range(4) if K&(1<<j)]
   jseq=[j for j in range(4) if J&(1<<j)]
   # tau(K) reversal sign, followed by wedge of J; parity of reversed K concatenated J.
   seq=list(reversed(kseq))+jseq
   parity=sum(seq[a]>seq[b] for a,b in combinations(range(4),2))
   creation_sign=(-1)**sum(j<i for j in ik)
   actual=creation_sign*(-1)**parity
   beta=(-1)**sum(j for j in kseq)
   pred=creation_sign*beta
   cc+=1
   ck('p1:thm:v214-normalized-spin8-triality',f'Clifford wedge sign i={i} mask={I0} {op}',actual==pred)
ck('p1:thm:v214-normalized-spin8-triality','32 nonzero signed Fock coefficients',cc==32)
ck('p1:cor:v214-tagged-signed-triality-projection','averaging six slot tags preserves 32 signed coefficients',6*G(F(1,6))==I)
# Axial v=-e1 support maps four positive spinor weights to negatives as claimed.
uplus=(G(F(1,2)),)*4
uminus=(G(F(1,2)),G(F(-1,2)),G(F(-1,2)),G(F(-1,2)))
ms=[tuple(G(F(s,2)) for s in marks) for marks in [(1,1,-1,-1),(1,-1,1,-1),(1,-1,-1,1)]]
ps=[tuple(G(F(s,2)) for s in marks) for marks in [(1,-1,1,1),(1,1,-1,1),(1,1,1,-1)]]
e1=(I,Z,Z,Z)
for idx,(a,b) in enumerate(zip([uplus]+ms,[uminus]+ps)):
    ck('p1:thm:v562-axial-triality-trimer-identity',f'axial support map {idx}',tuple(e1[j]-a[j] for j in range(4))==b)

# Artifact output.
result={'artifact':'Paper1B-RigorousVerificationBatch4IndependentResults-v1_1.json','source':SRC.name,'source_sha256':SHA,'reviewed_legacy_claim_ordinals':[201,300], 'method':'fresh independent finite and symbolic E3/E4 certificate; no theory repairs','totals':{'checks':len(checks),'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks),'distinct_claim_labels':len({lab for row in checks for lab in row['claim_labels']})},'checks':checks}
assert result['totals']['failed']==0
out=Path('/mnt/data/Paper1B-RigorousVerificationBatch4IndependentResults-v1_1.json')
out.write_text(json.dumps(result,indent=2,default=str)+'\n')
print('PASS',result['totals'],out)
