"""Paper I-B v1.10 independent exact audit, claims 346--353,361--362,366--369,371 and 375.
Source-frozen validation. This is not a new framework result or an imported test replay.
"""
from __future__ import annotations
from itertools import combinations, permutations
from pathlib import Path
import sympy as s, json, hashlib, collections

SOURCE=Path('/mnt/data/audit1b_work/Paper1B-ExceptionalGeometry-v1_10.tex')
SHA=hashlib.sha256(SOURCE.read_bytes()).hexdigest()
assert SHA=='e02e868b02dc3e22bbfae8b4563d7586646f2dc0f215145674dff5fea10854d5'
R=s.Rational
I5=s.eye(5); one=s.ones(5,1); Q=I5-one*one.T/5
nodes=list(combinations(range(5),2)); N=len(nodes); idx={node:i for i,node in enumerate(nodes)}
edges=[(a,b) for i,a in enumerate(nodes) for b in nodes[i+1:] if not set(a)&set(b)]
assert len(edges)==15
adj=s.zeros(10);bdry=s.zeros(10,15)
for e,(a,b) in enumerate(edges):
 ai=idx[a];bi=idx[b]; adj[ai,bi]=adj[bi,ai]=1; bdry[ai,e]=1;bdry[bi,e]=-1
J10=s.ones(10); I10=s.eye(10); I15=s.eye(15)
E4=((adj-3*I10)*(adj-I10))/15
E5= -((adj-3*I10)*(adj+2*I10))/6
E1=((adj-I10)*(adj+2*I10))/10
P4=(bdry.T*E4*bdry)/5
P5=(bdry.T*E5*bdry)/2
P6=I15-P4-P5
H=P4/5+P5/2+P6/2

def outer(x,y):return x*y.T
def inner(x,y):return sum(a*b for a,b in zip(x,y))
def skew(x,y):return outer(x,y)-outer(y,x)
def vec(v):
 out=s.zeros(5,1)
 for i in v:out[i]=1
 return out
D={a:vec(a)*(1) for a in nodes}
for a in nodes:
 d=s.zeros(5,1);d[a[0]]=1;d[a[1]]=-1;D[a]=d
V={a:vec(a)-R(2,5)*one for a in nodes}
Smats=[outer(D[a],D[a])-outer(D[b],D[b]) for a,b in edges]
Kmats=[skew(V[a],V[b]) for a,b in edges]
Umat=[sum(((Smats[f]+Kmats[f])*H[f,e] for f in range(15)), s.zeros(5)) for e in range(15)]

checks=[]
def ck(tag,labels,condition,detail=None):
 ok=bool(condition); checks.append({'id':f'B5P-{len(checks)+1:04d}', 'topic':tag,'claim_labels':labels if isinstance(labels,list) else [labels], 'passed':ok, 'detail':str(detail)[:250] if detail is not None else ''});
 if not ok:raise AssertionError(f'{tag}: {detail}')

L351='p1:thm:v339-petersen-sl4-isometry'; L352='p1:cor:v339-petersen-matrix-symmetric-pair';L353='p1:thm:v339-petersen-projector-strata'; L361='p1:thm:v341-coset-gram-hodge';L362='p1:cor:v341-coset-pi15'
L366='p1:thm:v342-three-cycle-petersen-overlap';L367='p1:thm:v342-triangle-petersen-cycle-isometry';L368='p1:thm:v342-class-frame-three-cycle-tomography';L369='p1:thm:v342-minimal-path-lie-generators';L371='p1:prop:v343-fivefold-signed-contrast';L375='p1:prop:v344-petersen-quintet-intertwiner'
ck('petersen-degree',L351,adj*one[:10,:] == 3*s.ones(10,1)) if False else None
ck('petersen-spectrum',L351,adj.eigenvals()=={s.Integer(3):1,s.Integer(1):5,s.Integer(-2):4})
for e,p in enumerate((P4,P5,P6)):
 rank=(4,5,6)[e]
 ck(f'edge-projector-{rank}-symmetric',L351,p==p.T)
 ck(f'edge-projector-{rank}-idempotent',L351,p*p==p)
 ck(f'edge-projector-{rank}-rank',L351,p.rank()==rank)
ck('projector-sum',L351,P4+P5+P6==I15)
ck('hodge-cycles',L351,bdry*P6==s.zeros(10,15))
G_S=s.Matrix(15,15,lambda i,j:inner(Smats[i],Smats[j]))
G_K=s.Matrix(15,15,lambda i,j:inner(Kmats[i],Kmats[j]))
ck('symmetric-edge-gram',L351,G_S==25*P4+4*P5)
ck('skew-edge-gram',L351,G_K==4*P6)
ck('S-K-matrix-orthogonality',L351,all(inner(Smats[i],Kmats[j])==0 for i in range(15) for j in range(15)))
ck('isometry-U',L351,s.Matrix(15,15,lambda i,j:inner(Umat[i],Umat[j]))==I15)
ck('U-on-V-traceless',L351,all(M*one==s.zeros(5,1) and one.T*M==s.zeros(1,5) and s.trace(M)==0 for M in Umat))
ck('symmetric-pair-brackets',L352,all((X*Y-Y*X).T == -(X*Y-Y*X) for X in Smats for Y in Smats))

perms=list(permutations(range(5)))
def compose(p,q):return tuple(p[q[i]] for i in range(5))
def inv(p):return tuple(p.index(i) for i in range(5))
def even(p):return sum(p[i]>p[j] for i in range(5) for j in range(i+1,5))%2==0
def rep5(p):return s.SparseMatrix(5,5,{(p[j],j):1 for j in range(5)})
A5=[p for p in perms if even(p)];assert len(A5)==60
assert compose(A5[0],inv(A5[0]))==tuple(range(5))

def edge_image(p,e):
 a,b=edges[e]; pa=tuple(sorted(p[i] for i in a));pb=tuple(sorted(p[i] for i in b));
 if idx[pa]<idx[pb]:return edges.index((pa,pb)),1
 return edges.index((pb,pa)),-1
# Full S5 covariance, not merely the A5 inner subgroup.
for p in perms:
 r=rep5(p)
 for e in range(15):
  ee,sgn=edge_image(p,e)
  ck('S5-equivariant-edge-isometry',L351,r*Umat[e]*r.T==sgn*Umat[ee],f'{p}, edge {e}')

# Source's rank-15 coefficient projector on 120 binary lifts is reconstructed on
# 60 A5 cosets; every row/column occurs twice, so the /120 normalization is retained.
chi=lambda p: sum(p[i]==i for i in range(5))-1
C=s.Matrix(15,60,lambda e,g:sum(Umat[e][A5[g][j],j] for j in range(5)))
CoeffGram=C.T*C/30
Pi_char=s.Matrix(60,60,lambda i,j:R(4,120)*(sum(A5[i][k]==A5[j][k] for k in range(5))-1) - R(1,120)*chi(A5[i])*chi(A5[j]))
ck('A5-120lift-projector-kernel',L353,CoeffGram==Pi_char)
ck('A5-rank-15-with-lifts',L353,(2*CoeffGram).trace()==15)
class_counts=collections.Counter(); diagonal=collections.defaultdict(set)
for i,p in enumerate(A5):
 ty=tuple(sorted(len(c) for c in [])) # bypass, explicit order classifications below
 def order(p):
  z=tuple(range(5));q=z
  for k in range(1,7):
   q=compose(p,q)
   if q==z:return k
  raise AssertionError
 o=order(p);class_counts[o]+=2;diagonal[o].add(Pi_char[i,i])
ck('binary-class-counts',L353,dict(class_counts)=={1:2,2:30,3:40,5:48},dict(class_counts))
ck('leverage-per-class',L353,{k:tuple(v)[0] for k,v in diagonal.items()}=={1:R(0),2:R(2,15),3:R(1,8),5:R(1,8)})

# Full incidence Gram identities in the next source section.
B=s.zeros(60,25)
for g,p in enumerate(A5):
 for j in range(5):B[g,5*p[j]+j]=1
Bgram=2*B.T*B
PP=s.ones(5)/5; QQ=s.eye(5)-PP
R25=s.kronecker_product(s.ones(5)-s.eye(5),s.ones(5)-s.eye(5))
ck('transporter-25-Gram',L361,Bgram==24*s.eye(25)+6*R25)
colsV=[];colsW=[]
for a,b in nodes:
 v=s.zeros(25,1);w=s.zeros(25,1);v[5*a+b]=v[5*b+a]=1;w[5*a+b]=1;w[5*b+a]=-1
 colsV.append(v);colsW.append(w)
matV=s.Matrix.hstack(*colsV);matW=s.Matrix.hstack(*colsW)
# W^T W = 12(5I - C^T C), C is contraction by c=(1,...,1).
Contraction=s.zeros(5,10)
for z,(a,b) in enumerate(nodes):Contraction[a,z]=-1;Contraction[b,z]=1
S_H_square=5*s.eye(10)-Contraction.T*Contraction
Gv=matV.T*Bgram*matV;Gw=matW.T*Bgram*matW
ck('coset-symmetric-Gram',L361,Gv==48*s.eye(10)+12*adj+12*s.ones(10))
ck('coset-skew-Gram',L361,Gw==12*S_H_square)
ck('coset-orthogonal-cross',L361,matV.T*Bgram*matW==s.zeros(10))
ck('coset-ranks',L361,(Gv.rank(),Gw.rank())==(10,6))
ck('coset-eigenvalues',L361,(Gv.eigenvals(),Gw.eigenvals())==({s.Integer(204):1,s.Integer(60):5,s.Integer(24):4},{s.Integer(60):6,s.Integer(0):4}))
Pi_25cell= B*s.kronecker_product(Q,Q)*B.T/30 -s.Matrix([chi(p) for p in A5])*s.Matrix([[chi(p) for p in A5]])/120
ck('incidence-projector-from-cosets',L362,Pi_25cell==Pi_char)
ck('incidence-Pi-trace',L362,(2*Pi_25cell).trace()==15)

# The irreducible Petersen pair quintet is the orthogonal complement
# to the 5 rank-incidence rows in the 10-dimensional pair permutation.
D=s.Matrix(5,10,lambda i,j:int(i in nodes[j]));PPet=s.eye(10)-D.T*(3*s.eye(5)+s.ones(5)).inv()*D
ck('Petersen-quintet-incidence-DDt',L375,D*D.T==3*s.eye(5)+s.ones(5))
ck('Petersen-quintet-explicit-entries',L375,all(PPet[i,j] == int(i==j)-R(len(set(nodes[i])&set(nodes[j])),3)+R(1,6) for i in range(10) for j in range(10)))
ck('Petersen-quintet-rank5',L375,PPet*PPet==PPet and PPet.rank()==5)

# Three-cycles: all data generated independently from permutation matrices.
Z={p:Q*rep5(p)*Q -R(chi(p),4)*Q for p in A5}
S3=[];K3=[]
for A in nodes:
 T=tuple(i for i in range(5) if i not in A)
 g=list(range(5));g[T[0]]=T[1];g[T[1]]=T[2];g[T[2]]=T[0];g=tuple(g)
 ginv=inv(g)
 Sa=(Z[g]+Z[ginv])/2;Ka=(Z[g]-Z[ginv])/2
 Tvec=vec(T)
 PT=s.diag(*[int(i in T) for i in range(5)])-Tvec*Tvec.T/3
 ck('three-cycle-S-explicit',L366,Sa==R(3,4)*Q-R(3,2)*PT)
 ck('three-cycle-S-involution',L366,Sa*Sa==R(9,16)*Q)
 S3.append(Sa);K3.append(Ka)
ck('three-cycle-S-sum',L366,sum(S3,s.zeros(5))==s.zeros(5))
A_P=adj; G3s=s.Matrix(10,10,lambda i,j:inner(S3[i],S3[j]));G3k=s.Matrix(10,10,lambda i,j:inner(K3[i],K3[j]))
ck('three-cycle-Petersen-Gram',L366,G3s==2*s.eye(10)-R(3,2)*A_P+R(1,4)*s.ones(10))
ck('three-cycle-Petersen-spectrum',L366,G3s.eigenvals()=={s.Integer(5):4,R(1,2):5,s.Integer(0):1})
for a in range(10):
 for b in range(a,10):
  c=S3[a]*S3[b]-S3[b]*S3[a]
  expected=0 if a==b else R(5,2) if adj[a,b] else s.Integer(1)
  ck('three-cycle-commutator-square',L366,inner(c,c)==expected,f'{nodes[a]}, {nodes[b]}')
ck('triangle-tight-frame',L367,G3k*G3k==R(5,2)*G3k and G3k.rank()==6)
Jl=s.Matrix(10,15,lambda a,e:inner(K3[a],Kmats[e]))
ck('triangle-edge-J-integrality',L367,all(x in (-1,0,1) for x in Jl))
ck('triangle-edge-J-support',L367,all((Jl[i,e]!=0)==(len(set(nodes[i])&set(edges[e][0]))==1 and len(set(nodes[i])&set(edges[e][1]))==1) for i in range(10) for e in range(15)))
ck('triangle-edge-J-degrees',L367,all(sum(Jl[i,e]!=0 for e in range(15))==6 for i in range(10)) and all(sum(Jl[i,e]!=0 for i in range(10))==4 for e in range(15)))
ck('triangle-edge-tight-frame',L367,Jl*Jl.T==4*G3k and Jl.T*Jl==10*P6)

# Five-cycle conjugacy split under the inner A5 group.
def orbit_conj(f):return {compose(compose(h,f),inv(h)) for h in A5}
f=(1,2,3,4,0)
class5A=orbit_conj(f); class5B={p for p in A5 if order(p)==5}-class5A
assert len(class5A)==len(class5B)==12

def rho_edge(p):
 return s.SparseMatrix(15,15,{(edge_image(p,e)[0],e):edge_image(p,e)[1] for e in range(15)})
Kw=sum((rho_edge(g) for g in class5A),s.zeros(15))-sum((rho_edge(g) for g in class5B),s.zeros(15))
ck('fivefold-class-contrast-cubic',L371,Kw**3==80*Kw)
ck('fivefold-class-contrast-rank',L371,Kw.rank()==6 and s.trace(Kw)==0 and s.trace(Kw**2)==480)
ck('fivefold-class-contrast-sixspace',L371,Kw**2==80*P6)
t=(1,0,2,3,4)
ck('outer-class-interchange-sign',L371,rho_edge(t)*Kw*rho_edge(t).T==-Kw)

# Source-furnished class tomography - compute on the U_e orthonormal basis.
# Z_g in 5x5 real traceless matrices, f_g=Z_g/sqrt15.
coef=s.Matrix(15,60,lambda i,j:inner(Umat[i],Z[A5[j]]))
classids={1:[],2:[],3:[], '5A':[], '5B':[]}
for j,g in enumerate(A5):
 k=order(g)
 classids['5A' if g in class5A else '5B' if g in class5B else k].append(j)
AC={c:sum((coef[:,j]*coef[:,j].T/15 for j in ids),s.zeros(15)) for c,ids in classids.items()}
ck('full-15dim-group-frame',L368,sum(AC.values(),s.zeros(15))==I15)
ck('2A-frame-eigenvalues',L368,AC[2]==P4/3+R(8,15)*P5)
ck('3A-frame-eigenvalues',L368,AC[3]==R(2,3)*P4+P5/15+P6/3)
ck('5A-plus-5B-frame-eigenvalues',L368,AC['5A']+AC['5B']==R(2,5)*P5+R(2,3)*P6)
ck('5A-5B-normalized-contrast', [L368,L371], AC['5A']-AC['5B']== -Kw/15)
ck('class-frame-D-square',L368,(AC['5A']-AC['5B'])**2==R(16,45)*P6)
ck('class-frame-ranks',L368,[AC[x].rank() for x in [1,2,3,'5A','5B']]==[0,9,15,11,11])
ck('class-frame-traces',L368,[s.trace(AC[x]) for x in [1,2,3,'5A','5B']]==[0,4,5,3,3])
# direct actual inverse identity on every one of 15 U basis vectors via matrix inverse of AC3.
A3inv=R(3,2)*P4+15*P5+3*P6
ck('three-cycle-tomography-inverse',L368,A3inv*AC[3]==I15)

# Lie generated by the ten symmetric three-cycle operators.
# All calculations rational using the 5x5 S_A matrices from the original group.
# Exact layer ranks of 4 orbit representatives, and S5 symmetry fixes all 120 triples.
def flatten(M):return s.Matrix(1,25,list(M))
def lie_layers(labels,depth=7):
 gs=[S3[i] for i in labels]
 words=gs[:]
 past=[]; lens=[]; prev=[]
 for d in range(1,depth+1):
  fresh=gs if d==1 else [g*w-w*g for g in gs for w in prev]
  words.extend(fresh) if d!=1 else None
  rank=s.Matrix.vstack(*[flatten(x) for x in words]).rank()
  lens.append(rank);prev=fresh
  if d>1 and rank==lens[-2]:break
  if rank==15:break
 return lens
shapes=collections.defaultdict(list)
def shape(t):
 deg=collections.Counter(i for a in t for i in nodes[a]);vals=sorted(deg.values())
 return { (1,1,2,2):'path',(1,1,1,3):'star',(2,2,2):'triangle',(1,1,1,1,2):'disjoint-wedge'}.get(tuple(vals),'other')
for t in combinations(range(10),3):shapes[shape(t)].append(t)
ck('Lie-triple-shape-counts',L369,{k:len(v) for k,v in shapes.items()}=={'path':60,'star':20,'triangle':10,'disjoint-wedge':30})
for key, triples in sorted(shapes.items()):
 ranks=lie_layers(triples[0],7)
 expect=[3,6,11,14,15] if key=='path' else None
 ck('Lie-triple-'+key,L369,(ranks[:5]==expect if key=='path' else ranks[-1]==9),f'{key} representative {triples[0]}: {ranks}')
# Need inspect both S5 orbits for pairs, not all 45.
for a,b in [(0,1),(0,7)]:
 ranks=lie_layers((a,b),7)
 ck('Lie-two-generator-dimension',L369,ranks[-1]<=4 and ranks[-1]==4,f'pair {(a,b)} ranks={ranks}')

out={'metadata':{'title':'Paper1B Batch5 independently generated exact finite Petersen/three-cycle controls','source_sha256':SHA,'source':SOURCE.name,'nature':'E3 new independent current-source checks, no physical occurrence claim','distinct_claims_tested':sorted({label for c in checks for label in c['claim_labels']})},'totals':{'checks':len(checks),'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks)},'checks':checks}
path=Path('/mnt/data/Paper1B-RigorousVerificationBatch5PetersenResults-v1_1.json');path.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(out['totals']));print('LIE SHAPES',{k:(len(v),lie_layers(v[0])) for k,v in shapes.items()})
print('FILES',path)
