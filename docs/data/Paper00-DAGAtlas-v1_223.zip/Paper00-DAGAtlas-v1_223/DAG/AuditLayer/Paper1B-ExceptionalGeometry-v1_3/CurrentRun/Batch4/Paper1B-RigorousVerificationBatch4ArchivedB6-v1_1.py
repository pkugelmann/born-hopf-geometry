#!/usr/bin/env python3
"""Paper I-B Exceptional Geometry v1.7, Batch 6: independent finite exact checks.

All source mathematical claims are used with their original conditional scope.
This script independently reconstructs explicit finite/group/linear-algebra data;
it does not establish a physical mass, decay law, hadron source, or interaction.
Run: python Paper1B-Batch6-IndependentChecks-v1_2.py [current .tex path]
"""
from __future__ import annotations
import itertools as it, collections as C, math, json, hashlib, sys
from fractions import Fraction as F
from pathlib import Path
import sympy as sp

src=Path(sys.argv[1] if len(sys.argv)>1 else '/mnt/data/audit1b_work/Paper1B-ExceptionalGeometry-v1_10.tex')
SOURCE_SHA='e02e868b02dc3e22bbfae8b4563d7586646f2dc0f215145674dff5fea10854d5'
assert hashlib.sha256(src.read_bytes()).hexdigest()==SOURCE_SHA
rows=[]
def ck(topic,claim,got,expected,notes=''):
    if isinstance(got, sp.MatrixBase): ok=got.shape==expected.shape and (got-expected).applyfunc(sp.simplify)==sp.zeros(*got.shape)
    else:ok= (sp.simplify(got-expected)==0 if isinstance(got,sp.Expr) and isinstance(expected,sp.Expr) else got==expected)
    r={'id':f'B6E3-{len(rows)+1:04d}','topic':topic, 'claim_labels': [claim] if isinstance(claim,str) else claim,
       'passed':bool(ok),'method':'independent exact construction', 'note':notes}
    rows.append(r)
    if not ok: raise AssertionError((topic,got,expected))

# I. Clifford protected 4x4 operators, covariance, sharp total variance.
I2=sp.eye(2); sx=sp.Matrix([[0,1],[1,0]]); sy=sp.Matrix([[0,-sp.I],[sp.I,0]]); sz=sp.diag(1,-1)
G=[sp.kronecker_product(sx,I2),sp.kronecker_product(sy,I2),sp.kronecker_product(sz,sx),sp.kronecker_product(sz,sy)]
assert all(x.shape==(4,4) for x in G)
for a in range(4):
    for b in range(a,4):
        ck('clifford-anticommutator-%d-%d'%(a,b),'p1:prop:protected-coordinate-covariance',
            G[a]*G[b]+G[b]*G[a],2*(a==b)*sp.eye(4))
for v in [(1,0,0,0),(0,1,0,0),(0,0,1,0),(0,0,0,1),
          (F(1,2),F(1,3),F(1,4),0),(F(1,2),0,F(1,2),0),
          (F(1,3),F(1,3),F(1,3),F(1,3))]:
    r=sp.Matrix(v); K=sum((r[a]*G[a] for a in range(4)),sp.zeros(4));sigma=(sp.eye(4)+K)/4
    mu=sp.Matrix([sp.trace(sigma*G[a]) for a in range(4)])
    cov=sp.Matrix(4,4,lambda a,b:sp.trace(sigma*(G[a]*G[b]+G[b]*G[a]))/2-mu[a]*mu[b]);
    ck('covariance-dir-%s'%len(rows),'p1:prop:protected-coordinate-covariance',cov,sp.eye(4)-r*r.T)
    ck('mean-dir-%s'%len(rows),'p1:prop:protected-coordinate-covariance',mu,r)

# Coordinate-only intrinsic native operator envelope; independent F97 elimination.
# The 15x15 blocks use the source-normalized scalar/vector/bivector/spinor tuple.
# 14^2=2, 10^2=3, 22^2=-1 modulo 97. All denominators are invertible.
import numpy as np
prime=97
pairs4=list(it.combinations(range(4),2))
def sqrtmap(expr):
    # Evaluating the 4x4 gamma entries in Q(i) at i=22 in F97.
    expr=sp.expand(expr)
    return int((sp.re(expr)+22*sp.im(expr))%prime)
Y=[]
for a in range(4):
  mat=np.zeros((15,15),dtype=np.int64)
  mat[0,1+a]=mat[1+a,0]=pow(2,-1,prime)
  for b in range(4):
    if b==a:continue
    key=tuple(sorted((a,b)));ki=pairs4.index(key)
    coefficient=(1 if a<b else -1)*14*pow(3,-1,prime)%prime
    mat[5+ki,1+b]=mat[1+b,5+ki]=coefficient
  for i in range(4):
    for j in range(4):
      g=sqrtmap(G[a][i,j]); mat[11+i,11+j]=10*pow(4,-1,prime)*g%prime
  Y.append(mat)
QQ=sum((v@v%prime for v in Y),np.zeros((15,15),dtype=np.int64))%prime
qdiag=[1]+[11*pow(12,-1,prime)%prime]*4+[4*pow(9,-1,prime)%prime]*6+[3*pow(4,-1,prime)%prime]*4
ck('native-Q-four-square-fingerprints','p1:thm:v226-coordinate-only',bool(np.array_equal(QQ,np.diag(qdiag))),True)
# Flat row elimination of word matrices, extending only independent previous-degree words.
def insert_mod(vec,pivots):
 v=vec.copy()%prime
 for p,b in pivots.items():
   if v[p]:v=(v-v[p]*b)%prime
 inds=np.flatnonzero(v)
 if len(inds)==0:return False
 k=int(inds[0]);v=v*pow(int(v[k]),-1,prime)%prime
 pivots[k]=v
 # Sort pivot order to maintain the leading-index invariant.
 items=sorted(pivots.items());pivots.clear();pivots.update(items)
 return True
pivots={};front=[np.eye(15,dtype=np.int64)]
insert_mod(front[0].reshape(-1),pivots)
for degree in range(1,7):
  new=[]
  for old in front:
    for y in Y:
      v=(old@y)%prime
      if insert_mod(v.reshape(-1),pivots):new.append(v)
  front=new
  expected={1:5,2:21,5:136,6:137}.get(degree)
  if expected is not None:ck('native-word-span-degree%d'%degree,'p1:thm:v226-chirality',len(pivots),expected)
  else:print('native modular span degree',degree,len(pivots),flush=True)
ck('native-envelope-End11-plus-End4','p1:thm:v226-coordinate-only',len(pivots),11**2+4**2)
# Antisymmetrized degree-four coordinate word and exact distinct Hodge/chirality
# projectors: independent F97 matrix check of manuscript coefficients.
def modq(x):return int(sp.Rational(x).p*pow(int(sp.Rational(x).q),-1,prime)%prime)
om=np.zeros((15,15),dtype=np.int64)
for perm in it.permutations(range(4)):
 mat=np.eye(15,dtype=np.int64)
 for a in perm:mat=(mat@Y[a])%prime
 om=(om+(1 if sum(perm[i]>perm[j] for i in range(4) for j in range(i+1,4))%2==0 else -1)*mat)%prime
Bstar=np.zeros((15,15),dtype=np.int64)
for col,ab in enumerate(pairs4):
 remaining=tuple(a for a in range(4) if a not in ab)
 row=pairs4.index(remaining)
 sign=(-1)**sum((ab+remaining)[i]>(ab+remaining)[j] for i in range(4) for j in range(i+1,4))
 Bstar[5+row,5+col]=sign%prime
Chi=G[0]*G[1]*G[2]*G[3]
Chimod=np.zeros((15,15),dtype=np.int64)
for i in range(4):
 for j in range(4):Chimod[11+i,11+j]=sqrtmap(Chi[i,j])
expected=(modq(-sp.Rational(34,81))*Bstar+modq(sp.Rational(27,32))*Chimod)%prime
ck('native-antisym-omega4-coefficients','p1:thm:v226-chirality',bool(np.array_equal(om,expected)),True)
ck('native-Hodge-recovery-degree6','p1:thm:v226-chirality',bool(np.array_equal((modq(sp.Rational(1458,187))*((QQ-modq(sp.Rational(3,4))*np.eye(15,dtype=np.int64))@om))%prime,Bstar)),True)
ck('native-chirality-recovery-degree6','p1:thm:v226-chirality',bool(np.array_equal((modq(sp.Rational(128,33))*((QQ-modq(sp.Rational(4,9))*np.eye(15,dtype=np.int64))@om))%prime,Chimod)),True)

# Canonical 25-dimensional first-order return comparison at R=1.
Bd=sp.zeros(15,10)
for i in range(4):Bd[1+i,i]=sp.sqrt(3)
for i in range(6):Bd[5+i,4+i]=2
DF=sp.diag(*([0]*11+[1,-1,1,-1]))
Dt=DF.row_join(Bd).col_join(Bd.T.row_join(sp.zeros(10)))
K=DF*DF+Bd*Bd.T
ck('closure-DFB-vanish','p1:thm:v215-closure-return',DF*Bd,sp.zeros(15,10))
ck('closure-square-block-splitting','p1:thm:v215-closure-return',Dt*Dt,K.row_join(sp.zeros(15,10)).col_join(sp.zeros(10,15).row_join(Bd.T*Bd)))
for power in range(5):
 lhs=(Dt*Dt)**power
 ck('closure-F-moment-%d'%power,'p1:thm:v215-closure-return',lhs[:15,:15],K**power)
 ck('closure-trace-difference-%d'%power,'p1:thm:v215-closure-return',sp.trace(lhs)-sp.trace(K**power),4*3**power+6*4**power)
# Retained 15d square and full 25d square are explicitly different readouts.

# II. Uniform Hurwitz 24-cell and exact all-monomial spherical 5-design.
H=[]
for a in range(4):
 for sign in (-1,1):
  p=[F(0)]*4;p[a]=F(sign);H.append(tuple(p))
H.extend(tuple(F(v,2) for v in sg) for sg in it.product((-1,1),repeat=4))
H=sorted(H)
ck('hurwitz-24','p1:thm:v350-hurwitz-five-design',len(H),24)
def haar_s3(exp):
 if any(e%2 for e in exp):return F(0)
 aa=[e//2 for e in exp]; t=sum(aa)
 return F(math.prod(math.factorial(2*a) for a in aa),4**t*math.factorial(t+1)*math.prod(math.factorial(a) for a in aa))
for exp in it.product(range(6),repeat=4):
 if sum(exp)>5:continue
 av=sum((math.prod(v[i]**exp[i] for i in range(4)) for v in H), F(0))/24
 ck('hurwitz-spherical-monomial-%s'%(''.join(map(str,exp))),'p1:thm:v350-hurwitz-five-design',av,haar_s3(exp))

# Graph Laplacian on 0+1+2 scalar harmonic spaces; source EXACT dot adjacency.
dot=lambda a,b: sum((x*y for x,y in zip(a,b)),F(0))
N=24; A=sp.Matrix(N,N,lambda i,j:int(i!=j and dot(H[i],H[j])==F(1,2)))
for i,q in enumerate(H):
 neighbors=[H[j] for j in range(N) if A[i,j]]
 ck('hurwitz-valency-%d'%i,'p1:thm:v350-hurwitz-scalar-laplacian',len(neighbors),8)
 m1=sp.Matrix([sum((v[k] for v in neighbors),F(0)) for k in range(4)])
 ck('hurwitz-linear-neighbor-sum-%d'%i,'p1:thm:v350-hurwitz-scalar-laplacian',m1,sp.Matrix([4*e for e in q]))
 m2=sp.Matrix(4,4,lambda a,b:sum((v[a]*v[b] for v in neighbors),F(0)))
 ck('hurwitz-quadratic-neighbor-sum-%d'%i,'p1:thm:v350-hurwitz-scalar-laplacian',m2,2*sp.eye(4))
ck('hurwitz-edges-96','p1:prop:v344-hurwitz-edge-eight-orbits',sum(A)/2,96)
# 14-dimensional sampled harmonic band, 1+4+9 independent polynomial columns.
monomials=[lambda q:F(1)] + [lambda q,i=i:q[i] for i in range(4)]
monomials += [lambda q,i=i,j=j:q[i]*q[j] for i in range(4) for j in range(i+1,4)]
monomials += [lambda q,i=i:q[i]**2-q[3]**2 for i in range(3)]
assert len(monomials)==14
M=sp.Matrix(N,14,lambda i,j:monomials[j](H[i])); rank=M.rank()
ck('hurwitz-harmonic-sampling-rank14','p1:thm:v350-hurwitz-scalar-laplacian',rank,14)
for j,ev in enumerate([8]+[4]*4+[0]*9):
 ck('hurwitz-harmonic-A-eigen-%d'%j,'p1:thm:v350-hurwitz-scalar-laplacian',A*M[:,j],ev*M[:,j])
L= A*A/sp.Integer(16)-3*A/2+8*sp.eye(24)
for j,ev in enumerate([0]+[3]*4+[8]*9):
 ck('hurwitz-harmonic-graph-L-%d'%j,'p1:thm:v350-hurwitz-scalar-laplacian',L*M[:,j],ev*M[:,j])

# Exact no-dangling search, indexed by actual triangular 24-cell faces.
# This independently implements the finite source recurrence, no shape picture.
faces=[(i,j,k) for i in range(24) for j in range(i+1,24) for k in range(j+1,24) if A[i,j] and A[i,k] and A[j,k]]
ck('Hurwitz-96-triangles','p1:thm:v356-hurwitz-minimal-faces',len(faces),96)
edges=[(i,j) for i in range(24) for j in range(i+1,24) if A[i,j]]
ef={e:[] for e in edges}
fe=[]
for fi,t in enumerate(faces):
 ee=list(it.combinations(t,2)); fe.append(ee)
 for e in ee:ef[e].append(fi)
ck('Hurwitz-edge-face-incidence-three','p1:thm:v356-hurwitz-minimal-faces',set(map(len,ef.values())),{3})
completed=set();total_states=0
for seed in range(96):
 seen=set();stack=[1<<seed]
 while stack:
  mask=stack.pop()
  if mask in seen:continue
  seen.add(mask)
  if mask.bit_count()>8:continue
  ec=C.Counter(e for i,t in enumerate(fe) if mask>>i&1 for e in t)
  dangling=next((e for e in edges if ec[e]==1),None)
  if dangling is None:completed.add(mask);continue
  if mask.bit_count()==8:continue
  for fi in ef[dangling]:
   if not mask>>fi&1:stack.append(mask|(1<<fi))
 total_states+=len(seen)
ck('Hurwitz-no-dangling-total-search-states','p1:thm:v356-hurwitz-minimal-faces',total_states,23584)
ck('Hurwitz-no-dangling-24-completions','p1:thm:v356-hurwitz-minimal-faces',len(completed),24)
ck('Hurwitz-no-dangling-all-minimal-eight','p1:thm:v356-hurwitz-minimal-faces',set(x.bit_count() for x in completed),{8})
for j,mask in enumerate(sorted(completed)):
 fids=[i for i in range(96) if mask>>i&1]
 vs=set(x for i in fids for x in faces[i]); es=C.Counter(e for i in fids for e in fe[i])
 ck('Hurwitz-octahedral-boundary-%d'%j,'p1:thm:v356-hurwitz-minimal-faces',(len(vs),len(es),len(fids),set(es.values())),(6,12,8,{2}))

# III. Five-marked labels.  The 120 binary lifts of even five-letter permutations
# have precisely the same transporter incidence Gram as 2I action on five cores.
perms=[p for p in it.permutations(range(5)) if sum(p[i]>p[j] for i in range(5) for j in range(i+1,5))%2==0]
ck('a5-even-60','p1:thm:v340-incidence-character-projectors',len(perms),60)
B=sp.Matrix(120,25,lambda r,c:int(perms[r//2][c%5]==c//5))
R=sp.kronecker_product(sp.ones(5)-sp.eye(5),sp.ones(5)-sp.eye(5))
BG=24*sp.eye(25)+6*R
for i in range(25):ck('binary-transporter-gram-row-%d'%i,'p1:thm:v341-coset-gram-hodge', (B.T*B)[i,:],BG[i,:])
ck('transporter-gram-spectrum','p1:thm:v341-coset-gram-hodge',BG.eigenvals(),{120:1,30:16,0:8})
pairs=list(it.combinations(range(5),2));Apet=sp.Matrix(10,10,lambda a,b:int(not set(pairs[a])&set(pairs[b])))
J=sp.ones(10);V=sp.Matrix.hstack(*[B[:,i*5+j]+B[:,j*5+i] for i,j in pairs]);W=sp.Matrix.hstack(*[B[:,i*5+j]-B[:,j*5+i] for i,j in pairs]);
# Separate 5x10 Petersen tight frame. Do not confuse with 120x10 coefficient V.
Q5=sp.eye(5)-sp.ones(5)/5
Vpair=sp.Matrix(5,10,lambda i,k:int(i in pairs[k])-sp.Rational(2,5))
ck('Petersen-5x10-tight-frame','p1:thm:v338-petersen-tight-frame',Vpair*Vpair.T,3*Q5)
ck('Petersen-10x10-contrast-Gram','p1:thm:v338-petersen-tight-frame',Vpair.T*Vpair,sp.eye(10)-Apet+sp.ones(10)/5)
ck('Petersen-rank-four-contrast','p1:thm:v338-petersen-tight-frame',Vpair.rank(),4)
# Rooted full 25-register Gram and rank-15 traceless projected packet.
ck('transport-rank17','p1:prop:v339-incidence-rank15-contrast',BG.eigenvals(),{120:1,30:16,0:8})
Q=lambda M:Q5*M*Q5
basis25=[sp.Matrix(5,5,lambda i,j:int((i,j)==(k//5,k%5))) for k in range(25)]
Tmat=sp.Matrix.hstack(*[sp.Matrix(Q(b)-sp.trace(Q(b))*Q5/4).reshape(25,1) for b in basis25])
ck('transporter-traceless-15-rank','p1:prop:v339-incidence-rank15-contrast',Tmat.rank(),15)
ck('transporter-T-projector-square','p1:prop:v339-incidence-rank15-contrast',Tmat*Tmat,Tmat)
# Every transporter intersection is 24 or 6 or 0 depending on the two pair indices.
for i in range(25):
 ck('binary-transporter-projective-intersections-row-%d'%i,'p1:prop:v340-transporter-hexagon-intersection',BG[i,:],sp.Matrix(1,25,lambda r,j:24 if i==j else 0 if i//5==j//5 or i%5==j%5 else 6))

for i in range(10):
 ck('petersen-symmetric-gram-row-%d'%i,'p1:thm:v341-coset-gram-hodge',(V.T*V)[i,:],(48*sp.eye(10)+12*Apet+12*J)[i,:])
 ck('petersen-symmetric-skew-orthog-row-%d'%i,'p1:thm:v341-coset-gram-hodge',(V.T*W)[i,:],sp.zeros(1,10))
ck('petersen-eigen-spectrum','p1:thm:v338-signed-petersen-hodge',Apet.eigenvals(),{3:1,1:5,-2:4})
ck('v-gram-spectrum','p1:thm:v341-coset-gram-hodge',(V.T*V).eigenvals(),{204:1,60:5,24:4})
ck('w-gram-spectrum','p1:thm:v341-coset-gram-hodge',(W.T*W).eigenvals(),{60:6,0:4})
D=sp.Matrix(5,10,lambda i,k:int(i in pairs[k]))
Ppet=sp.eye(10)-D.T*(3*sp.eye(5)+sp.ones(5)).inv()*D
for a in range(10):
 ck('petersen-quintet-proj-row-%d'%a,'p1:prop:v344-petersen-quintet-intertwiner',Ppet[a,:],sp.Matrix(1,10,lambda z,b:int(a==b)-sp.Rational(len(set(pairs[a])&set(pairs[b])),3)+sp.Rational(1,6)))
ck('petersen-quintet-rank','p1:prop:v344-petersen-quintet-intertwiner',Ppet.rank(),5)
ck('petersen-quintet-square','p1:prop:v344-petersen-quintet-intertwiner',Ppet*Ppet,Ppet)
# 5D Hodge operator * (c wedge -); exact Levi-Civita sign.
def sgperm(xs):return (-1)**sum(xs[i]>xs[j] for i in range(len(xs)) for j in range(i+1,len(xs)))
S=sp.zeros(10)
for col,(a,b) in enumerate(pairs):
 for k in range(5):
  if k in (a,b):continue
  others=[x for x in range(5) if x not in (k,a,b)]
  row=pairs.index(tuple(others))
  S[row,col]+=sgperm([k,a,b]+others)
ck('signed-hodge-cubic','p1:thm:v338-signed-petersen-hodge',S*S*S,5*S)
for i in range(10):
 ck('hodge-w-skew-gram-row-%d'%i,'p1:thm:v341-coset-gram-hodge',(W.T*W)[i,:],(12*S*S)[i,:])

# Complete projective A5 cyclic-coset polygon design and core Reye census.
identity=tuple(range(5));pidx={v:i for i,v in enumerate(perms)}
def compose(p,q):return tuple(p[q[i]] for i in range(5))
def order(p):
 q=identity
 for n in range(1,7):
  q=compose(q,p)
  if q==identity:return n
 raise ValueError('A5 element order')
ord_g={g:order(g) for g in perms}
ck('A5-class-orders-1-2-3-5','p1:thm:v340-cyclic-coset-design',C.Counter(ord_g.values()),C.Counter({1:1,2:15,3:20,5:24}))
poly={};gram={}
for k in (2,3,5):
 cyc=set()
 for g in perms:
  if ord_g[g]!=k:continue
  h=identity;sub=[]
  for n in range(k):sub.append(h);h=compose(h,g)
  cyc.add(frozenset(sub))
 ck('A5-order-%d-cyclic-subgroups'%k,'p1:thm:v340-cyclic-coset-design',len(cyc),{2:15,3:10,5:6}[k])
 lines={frozenset(compose(g,h) for h in sg) for g in perms for sg in cyc}
 poly[k]=lines
 ck('A5-projective-k%d-polygon-count'%k,'p1:thm:v340-cyclic-coset-design',len(lines),{2:450,3:200,5:72}[k])
 ck('A5-projective-k%d-polygon-size'%k,'p1:thm:v340-cyclic-coset-design',{len(x) for x in lines},{k})
 gram[k]=sp.zeros(60)
 for line in lines:
  inds=[pidx[x] for x in line]
  for i in inds:
   for j in inds:gram[k][i,j]+=1
M2,M3,M5=gram[2],gram[3],gram[5]
ck('A5-722-cyclic-coset-design-total','p1:thm:v340-cyclic-coset-design',sum(map(len,poly.values())),722)
ck('A5-cyclic-pairwise-balance','p1:thm:v340-cyclic-coset-design',M2+M3+M5,30*sp.eye(60)+sp.ones(60))
ck('A5-order-character-rank25','p1:thm:v340-incidence-character-projectors',sp.trace((M2-M3)/12),25)
ck('A5-order-character-rank16','p1:thm:v340-incidence-character-projectors',sp.trace((M3-M5)/15),16)
ck('A5-order-character-idempotents','p1:thm:v340-incidence-character-projectors',
    (((M2-M3)/12)**2==(M2-M3)/12 and ((M3-M5)/15)**2==(M3-M5)/15 and (M2-M3)*(M3-M5)==sp.zeros(60)),True)
coresA=[set(p for p in perms if p[i]==i) for i in range(5)]
U=set().union(*coresA)
# Three Petersen A5 double-coset strata and their two-core refinement,
# independently counted over all 60 even permutations and their 120 lifts.
S2={0,1}
def ss(p):return ('same' if len({p[j] for j in S2}&S2)==2 else 'disjoint' if not ({p[j] for j in S2}&S2) else 'overlap')
row_groups=[coresA[0],set().union(*coresA)-coresA[0],set(perms)-set().union(*coresA)]
expected=[(6,0,18),(6,12,30),(0,24,24)]
for j,(rg,counts) in enumerate(zip(row_groups,expected)):
 ck('Petersen-120-two-core-stratum-row-%d'%j,'p1:thm:v338-petersen-120-strata',tuple(2*sum(ss(p)==c for p in rg) for c in ('same','disjoint','overlap')),counts)
ck('Petersen-120-two-core-stratum-totals','p1:thm:v338-petersen-120-strata',tuple(2*sum(ss(p)==c for p in perms) for c in ('same','disjoint','overlap')),(12,36,72))

ck('A5-core-union-36','p1:thm:v340-reye-70-80',len(U),36)
ck('A5-core-union-order-decomposition','p1:thm:v340-reye-70-80',C.Counter(ord_g[p] for p in U),C.Counter({1:1,2:15,3:20}))
reye70={line for line in poly[3] if any(line<=h for h in coresA)}
reye80={line for line in poly[3] if line<=U}
ck('A5-core-contained-70-hexagons','p1:thm:v340-reye-70-80',len(reye70),70)
ck('A5-full-induced-80-hexagons','p1:thm:v340-reye-70-80',len(reye80),80)
ordcomp=lambda lines:C.Counter(tuple(sorted(ord_g[x] for x in ln)) for ln in lines)
ck('A5-reye70-order-compositions','p1:thm:v340-reye-70-80',ordcomp(reye70),C.Counter({(1,3,3):10,(2,3,3):60}))
ck('A5-reye80-order-compositions','p1:thm:v340-reye-70-80',ordcomp(reye80),C.Counter({(1,3,3):10,(2,3,3):60,(2,2,2):10}))
Un=sorted(U);ordered70=list(sorted(reye70,key=lambda x:tuple(sorted(x))));ordered80=list(sorted(reye80,key=lambda x:tuple(sorted(x))))
r70=sp.Matrix(len(Un),70,lambda i,j:int(Un[i] in ordered70[j]))
r80=sp.Matrix(len(Un),80,lambda i,j:int(Un[i] in ordered80[j]))
def rank_modp(mat,p=101):
 A=np.array(mat.tolist(),dtype=np.int64)%p
 m,n=A.shape;rank=0
 for c in range(n):
  k=next((i for i in range(rank,m) if A[i,c]),None)
  if k is None:continue
  A[[rank,k]]=A[[k,rank]]
  A[rank]=(A[rank]*pow(int(A[rank,c]),-1,p))%p
  for i in range(rank+1,m):
   if A[i,c]:A[i]=(A[i]-A[i,c]*A[rank])%p
  rank+=1
  if rank==m:break
 return rank
# Independently certify full 24-cell face-edge incidence and kernel rank.
Mf=sp.Matrix(96,96,lambda i,j:int(edges[i] in fe[j]))
AF=Mf.T*Mf-3*sp.eye(96)
ck('Hurwitz-face-edge-diagonal','p1:thm:v365-hurwitz-face-laplacian',all(Mf.col(j).dot(Mf.col(j))==3 for j in range(96)),True)
ck('Hurwitz-face-edge-adjacency','p1:thm:v365-hurwitz-face-laplacian',all(AF[i,j] in (0,1) and (i!=j or AF[i,j]==0) for i in range(96) for j in range(96)),True)
ck('Hurwitz-face-edge-facevalency','p1:thm:v365-hurwitz-face-laplacian',set(sum(AF[i,:]) for i in range(96)),{6})
ck('Hurwitz-face-edge-rank-mod101','p1:thm:v365-hurwitz-face-laplacian',rank_modp(Mf),73)
ck('Hurwitz-face-laplacian-identity','p1:thm:v365-hurwitz-face-laplacian',Mf.T*Mf + (6*sp.eye(96)-AF),9*sp.eye(96))
ck('A5-reye70-rank35-mod101-with-nullupper','p1:thm:v340-reye-70-80',rank_modp(r70),35)
ck('A5-reye80-rank36-mod101-fullrowrank','p1:thm:v340-reye-70-80',rank_modp(r80),36)
z0=sp.Matrix([-2 if ord_g[p] in (1,2) else 1 for p in Un])
ck('A5-reye70-nullweight','p1:thm:v340-reye-70-80',z0.T*r70,sp.zeros(1,70))
for i,p in enumerate(Un):
 ck('A5-reye70-point-degree-%d'%i,'p1:thm:v340-reye-70-80',sum(r70[i,:]),{1:10,2:4,3:7}[ord_g[p]])

# IV. Independently reconstruct golden 2I vertices using exact Q(phi) arithmetic.
Z=(F(0),F(0));ONE=(F(1),F(0));PHI=(F(0),F(1)); IPHI=(F(-1),F(1))
def ad(a,b):return(a[0]+b[0],a[1]+b[1])
def ne(a):return(-a[0],-a[1])
def mul(a,b):return(a[0]*b[0]+a[1]*b[1],a[0]*b[1]+a[1]*b[0]+a[1]*b[1])
def sc(a,x):return(a[0]*x,a[1]*x)
def qmul(q,r):
 a,b,c,d=q;e,f,g,h=r
 return (ad(ad(ad(mul(a,e),ne(mul(b,f))),ne(mul(c,g))),ne(mul(d,h))),
         ad(ad(ad(mul(a,f),mul(b,e)),mul(c,h)),ne(mul(d,g))),
         ad(ad(ad(mul(a,g),ne(mul(b,h))),mul(c,e)),mul(d,f)),
         ad(ad(ad(mul(a,h),mul(b,g)),ne(mul(c,f))),mul(d,e)))
def qconj(q):return(q[0],ne(q[1]),ne(q[2]),ne(q[3]))
def fdot(q,r):
 ans=Z
 for a,b in zip(q,r):ans=ad(ans,mul(a,b))
 return ans
verts=set()
for k in range(4):
 for sign in (-1,1):
  p=[Z]*4;p[k]=sc(ONE,sign);verts.add(tuple(p))
for signs in it.product((-1,1),repeat=4):verts.add(tuple(sc(ONE,F(a,2)) for a in signs))
base=[Z,ONE,PHI,IPHI]
for p in it.permutations(range(4)):
 if sgperm(p)==-1: continue
 for sg in it.product((-1,1),repeat=3):
  v=[Z]*4
  for k,j in enumerate(p):
   if k>0:v[j]=sc(base[k],F(sg[k-1],2))
  verts.add(tuple(v))
Q=sorted(verts);idx={v:i for i,v in enumerate(Q)};Hset={v for v in Q if all(coord[1]==0 for coord in v)}
ck('binary-icosahedral-root-count','p1:thm:v370-e8-d4-triality',len(Q),120)
ck('hurwitz-marked-subgroup-size','p1:thm:v370-e8-d4-triality',len(Hset),24)
for i,v in enumerate(Q):
 ck('golden-unit-norm-%d'%i,'p1:thm:v365-600-cell-incidence',fdot(v,v),ONE)
adj=[{j for j,b in enumerate(Q) if i!=j and fdot(v,b)==sc(PHI,F(1,2))} for i,v in enumerate(Q)]
for i,nbs in enumerate(adj):ck('golden-600-cell-valency-%d'%i,'p1:thm:v365-600-cell-incidence',len(nbs),12)
ck('golden-600-cell-edges','p1:thm:v365-600-cell-incidence',sum(map(len,adj))//2,720)
# 600 tetrahedra: all four-cliques of the graph, without numerical tolerances.
facets=set()
for a in range(120):
 for b in sorted(x for x in adj[a] if x>a):
  for c in sorted(x for x in adj[a]&adj[b] if x>b):
   for d in sorted(x for x in adj[a]&adj[b]&adj[c] if x>c):facets.add((a,b,c,d))
ck('golden-600-cell-tetrahedral-facets','p1:thm:v365-600-cell-incidence',len(facets),600)
facecount=C.Counter(tuple(sorted(t)) for f in facets for t in it.combinations(f,3))
ck('golden-600-cell-triangle-count','p1:thm:v365-600-cell-incidence',len(facecount),1200)
ck('golden-600-cell-face-two-facets','p1:thm:v365-600-cell-incidence',set(facecount.values()),{2})
# Independent 600x120 integer incidence and exact Gram, with certified full-rank minor mod 101.
ordered_facets=sorted(facets)
T600=sp.MutableSparseMatrix(600,120,{(i,v):1 for i,f in enumerate(ordered_facets) for v in f})
ck('golden-600-cell-TtT-gram','p1:thm:v365-600-cell-incidence',T600.T*T600,20*sp.eye(120)+5*sp.Matrix(120,120,lambda i,j:int(j in adj[i])))
ck('golden-600-cell-T-mod101-rank','p1:thm:v365-600-cell-incidence',rank_modp(T600),120)


# Source-defined centre-even nontrivial C3 character of H/Q8 and the
# induced 5x5 twisted coefficient packet, reconstructed in Z[omega].
Q8={q for q in Hset if sum(int(c!=Z) for c in q)==1}
ck('twisted-H-Q8-eight','p1:thm:v344-twisted-25-gram',len(Q8),8)
h0=tuple(sc(ONE,F(1,2)) for _ in range(4))
Hcos=[Q8,{qmul(k,h0) for k in Q8},{qmul(k,qmul(h0,h0)) for k in Q8}]
ck('twisted-H-Q8-three-cosets','p1:thm:v344-twisted-25-gram',sorted(map(len,Hcos)),[8,8,8])
ck('twisted-H-Q8-cosets-partition','p1:thm:v344-twisted-25-gram',len(set().union(*Hcos)),24)
chi={h:phase for phase,cos in enumerate(Hcos) for h in cos}
ck('twisted-H-Q8-character-defined','p1:thm:v344-twisted-25-gram',len(chi),24)
# Multiplicativity of chi verifies that it is an actual A4 character.
for k,a in enumerate(Hset):
 ck('twisted-character-homomorphism-%d'%k,'p1:thm:v344-induced-hurwitz-quintet',
   all(chi[qmul(a,b)]==(chi[a]+chi[b])%3 for b in Hset),True)
# Determine left G/H coset representatives; avoid selecting an independent
# five-label physical realization.
coset_reps=[];unused=set(Q)
while unused:
 g=next(iter(unused));coset={qmul(g,h) for h in Hset}
 coset_reps.append(g);unused-=coset
ck('twisted-G/H-five-cosets','p1:thm:v344-induced-hurwitz-quintet',len(coset_reps),5)
# Columns of F are exponent tags k in Z/3, or -1 outside the coset.
Ft=[[] for _ in range(25)];F0=[[] for _ in range(25)]
for g in Q:
 for i,gi in enumerate(coset_reps):
  for j,gj in enumerate(coset_reps):
   h=qmul(qmul(qconj(gi),g),gj)
   x=chi.get(h,-1)
   Ft[i*5+j].append(x);F0[i*5+j].append(int(x>=0))
def omega_gram(a,b):
 # Input columns are integer exponents; conjugate first factor.
 counts=[0,0,0]
 for x,y in zip(a,b):
  if x>=0 and y>=0:counts[(y-x)%3]+=1
 return (counts[0]-counts[2],counts[1]-counts[2])
for i in range(25):
 ck('twisted-25-exact-schur-row-%d'%i,'p1:thm:v344-twisted-25-gram',
    [omega_gram(Ft[i],Ft[j]) for j in range(25)],[(24 if i==j else 0,0) for j in range(25)])
 ck('twisted-25-orthogonal-untwisted-row-%d'%i,'p1:thm:v344-twisted-25-gram',
    [omega_gram(Ft[i],F0[j]) for j in range(25)],[(0,0)]*25)

# F40 direct product class: 20 positive +20 negative scalar-half vertices.
plus=[v for v in Q if v[0]==sc(ONE,F(1,2))];minus=[v for v in Q if v[0]==sc(ONE,F(-1,2))]
ck('F40-positive-20','p1:thm:v345-f40-edge-regular',len(plus),20)
ck('F40-negative-20','p1:thm:v345-f40-edge-regular',len(minus),20)
shell=sc(IPHI,F(1,2))
fe=[(q,r) for q in plus for r in minus if fdot(q,r)==shell]
ck('F40-60-directed-edges','p1:thm:v345-f40-edge-regular',len(fe),60)
Fverts=plus+minus;vid={v:i for i,v in enumerate(Fverts)}
inc=sp.zeros(40,60)
for i,(q,r) in enumerate(fe):inc[vid[q],i]=-1;inc[vid[r],i]=1
ck('F40-incidence-rank-39','p1:thm:v345-f40-edge-regular',inc.rank(),39)
ck('F40-cycle-dimension-21','p1:thm:v345-f40-edge-regular',60-inc.rank(),21)
right=[];left=[]
for q,r in fe:
 a=qmul(qconj(q),r);b=qmul(r,qconj(q));right.append(a);left.append(b)
 ck('F40-right-left-shell-%d'%len(right),'p1:thm:v345-f40-edge-regular',a[0]==shell and b[0]==shell,True)
ck('F40-12-right-shell-points','p1:thm:v345-f40-edge-regular',len(set(right)),12)
ck('F40-12-left-shell-points','p1:thm:v345-f40-edge-regular',len(set(left)),12)
ck('F40-right-5-regular','p1:thm:v345-f40-edge-regular',set(C.Counter(right).values()),{5})
ck('F40-left-5-regular','p1:thm:v345-f40-edge-regular',set(C.Counter(left).values()),{5})

# Exact five tetrahedral cores and all three F40 cycle readout ranks.
# No imported PetersenHodgePlucker predecessor scripts are used here.
cores={frozenset(qmul(qmul(g,h),qconj(g)) for h in Hset) for g in Q}
cores=sorted(cores,key=lambda c:tuple(sorted(c)))
ck('F40-five-conjugate-core-subgroups','p1:thm:v345-f40-edge-regular',len(cores),5)
corenum={c:i for i,c in enumerate(cores)}
vertexmark={q:frozenset(i for i,c in enumerate(cores) if q in c) for q in Fverts}
ck('F40-axes-two-core-incidences','p1:thm:v345-f40-edge-regular',set(map(len,vertexmark.values())),{2})
right_set=sorted(set(right));left_set=sorted(set(left));sid={g:i for i,g in enumerate(right_set)}
permaction={}
for g in right_set:
 p=[]
 for c in cores:
  target=frozenset(qmul(qmul(g,h),qconj(g)) for h in c)
  p.append(corenum[target])
 permaction[g]=tuple(p)
 ck('F40-core-5cycle-%d'%len(permaction),'p1:thm:v345-f40-edge-regular',len(set(p))==5 and all(p[j]!=j for j in range(5)),True)
miss=[];arcs=list(it.permutations(range(5),2));aid={pair:j for j,pair in enumerate(arcs)}
AR=sp.zeros(20,60);TR=sp.zeros(12,60);TL=sp.zeros(12,60)
for i,(q,r) in enumerate(fe):
 tags=vertexmark[q]|vertexmark[r]
 ck('F40-Petersen-edge-two-disjoint-core-pairs-%d'%i,'p1:thm:v345-f40-edge-regular',len(tags),4)
 m=next(iter(set(range(5))-tags));miss.append(m)
 g=right[i];j=permaction[g][m]
 AR[aid[(m,j)],i]=1;TR[sid[g],i]=1;TL[left_set.index(left[i]),i]=1
ck('F40-shell-omitted-label-bijection','p1:thm:v345-f40-edge-regular',len(set(zip(right,miss))),60)
ck('F40-arrow-all-20-core-transitions','p1:thm:v345-f40-edge-regular',len(set((m,permaction[g][m]) for g,m in zip(right,miss))),20)
ck('F40-arrow-ordered-pair-count3','p1:thm:v345-f40-edge-regular',set(C.Counter((m,permaction[g][m]) for g,m in zip(right,miss)).values()),{3})
for j in range(5):
 ck('F40-shell-transition-off-diagonal3-%d'%j,'p1:thm:v345-f40-edge-regular',
    [sum(int(permaction[g][j]==k) for g in right_set) for k in range(5)], [0 if k==j else 3 for k in range(5)])
Nnull=sp.Matrix.hstack(*inc.nullspace())
ck('F40-rational-cycle-basis-21','p1:thm:v345-f40-triple-frame',Nnull.shape,(60,21))
for label,mat in [('R',TR),('L',TL),('A',AR),('RL',TR.col_join(TL)),('RA',TR.col_join(AR)),('LA',TL.col_join(AR)),('RLA',TR.col_join(TL).col_join(AR))]:
 ck('F40-cycle-readout-rank-%s'%label,'p1:thm:v345-f40-triple-frame',(mat*Nnull).rank(),{'R':11,'L':11,'A':11,'RL':16,'RA':16,'LA':16,'RLA':21}[label])
Rfull=TR.col_join(TL).col_join(AR)
metric=Nnull.T*Nnull
frame=metric.inv()*Nnull.T*Rfull.T*Rfull*Nnull
z=sp.Symbol('z')
expected=sp.expand((z-1)**5*(z*z-12*z+31)**3*(z*z-8*z+6)**5)
ck('F40-21-frame-exact-charpoly','p1:thm:v345-f40-triple-frame',sp.expand(frame.charpoly(z).as_expr()),expected)
PZ=Nnull*metric.inv()*Nnull.T
ck('F40-cycle-projector-square','p1:prop:v345-f40-balanced-mirror',PZ*PZ,PZ)
ck('F40-cycle-projector-incidence-annihilator','p1:prop:v345-f40-balanced-mirror',inc*PZ,sp.zeros(40,60))

# V. E8 two orthogonal D4 root banks and 192-root triality partitions.
def emb(q):return tuple(c[0] for c in q)+tuple(c[1] for c in q)
def embphi(q):return tuple(c[1] for c in q)+tuple(c[0]+c[1] for c in q)
D0={emb(q) for q in Hset};D1={embphi(q) for q in Hset}
rootset={emb(q) for q in Q}|{embphi(q) for q in Q}
ck('E8-240-roots','p1:thm:v370-e8-d4-triality',len(rootset),240)
ck('E8-D4-orthogonal','p1:thm:v370-e8-d4-triality',all(sum(a*b for a,b in zip(x,y))==0 for x in D0 for y in D1),True)
X=rootset-D0-D1
ck('E8-complement-192','p1:thm:v370-e8-d4-triality',len(X),192)
# Reflection orbit closure; each reflection is in the pre-specified D4 banks.
def refl(x,a):
 dot=sum(t*v for t,v in zip(x,a))
 return tuple(t-2*dot*v for t,v in zip(x,a))
parts=[];remain=set(X)
while remain:
 st=next(iter(remain));orbit={st};stack=[st]
 while stack:
  x=stack.pop()
  for a in D0|D1:
   y=refl(x,a)
   if y not in X:raise AssertionError('reflection left E8 complement')
   if y not in orbit:orbit.add(y);stack.append(y)
 parts.append(orbit);remain-=orbit
ck('E8-triality-orbit-sizes','p1:thm:v370-e8-d4-triality',sorted(map(len,parts)),[64,64,64])
# Each complement orbit is a full Cartesian product of its 8x8 projections.
for i,orb in enumerate(parts):
 p0={t[:4] for t in orb};p1={t[4:] for t in orb}
 ck('E8-orbit-cartesian-projections-%d'%i,'p1:thm:v370-e8-d4-triality',(len(p0),len(p1),len(orb)),(8,8,64))
 ck('E8-orbit-cartesian-surjectivity-%d'%i,'p1:thm:v370-e8-d4-triality',orb=={a+b for a in p0 for b in p1},True)
# Count root-zero-sum triple supports using exact Q-rational 8D coordinates.
rootlist=list(rootset)
zero=C.Counter()
region={r:'D0' for r in D0};region.update({r:'D1' for r in D1})
for i,orb in enumerate(parts):region.update({r:'X%d'%i for r in orb})
triples=set()
for a in rootlist:
 for b in rootlist:
  c=tuple(-x-y for x,y in zip(a,b))
  if c in rootset and len({a,b,c})==3:triples.add(tuple(sorted((a,b,c))))
for t in triples:zero[tuple(sorted(region[x] for x in t))]+=1
ck('E8-root-zero-triples-total','p1:thm:v370-e8-d4-triality',len(triples),2240)
ck('E8-D4-zero-triples','p1:thm:v370-e8-d4-triality',(zero[('D0',)*3],zero[('D1',)*3]),(32,32))
ck('E8-all-triality-support','p1:thm:v370-e8-d4-triality',zero[('X0','X1','X2')],1024)
for d in ('D0','D1'):
 for i in range(3):
  ck('E8-mixed-triplet-%s-X%d'%(d,i),'p1:thm:v370-e8-d4-triality',zero[tuple(sorted([d,'X%d'%i,'X%d'%i]))],192)
# E8 golden-sheet 24+32+32+32 equitable quotient.
ordinary={emb(q):q for q in Q}
classV=[Hset]+[{ordinary[r] for r in orb if r in ordinary} for orb in parts]
ck('E8-ordinary-sheet-equitable-class-sizes','p1:thm:v370-e8-shell-chamber',[len(c) for c in classV],[24,32,32,32])
classnum={q:i for i,c in enumerate(classV) for q in c}
ck('E8-class-partition-complete','p1:thm:v370-e8-shell-chamber',len(classnum),120)
qmat=[[0,4,4,4],[3,3,3,3],[3,3,3,3],[3,3,3,3]]
for i,ns in enumerate(adj):
 cn=classnum[Q[i]]
 ck('E8-600cell-equitable-vertex-%d'%i,'p1:thm:v370-e8-shell-chamber',
    [sum(classnum[Q[j]]==k for j in ns) for k in range(4)],qmat[cn])
ck('E8-equitable-quotient-spectrum','p1:thm:v370-e8-shell-chamber',sp.Matrix(qmat).eigenvals(),{12:1,-3:1,0:2})
# A2 x E6 projection: the 72 orthogonal E6 roots, 6 A2 normal roots and
# six 27-root nonzero normal classes, all in exact rational coordinates.
def normal(r):return (r[0],r[1]+r[2]+r[3])
R6={r for r in rootset if normal(r)==(0,0)}
ck('E8-E6-section-72','p1:prop:v370-e6-cubic-support',len(R6),72)
A2={r for r in rootset if all(r[i]==0 for i in (4,5,6,7)) and r[1]==r[2]==r[3]}
ck('E8-A2-normal-roots-6','p1:prop:v370-e6-cubic-support',len(A2),6)
normalfib=C.defaultdict(list)
for r in rootset-R6-A2:normalfib[normal(r)].append(r)
ck('E8-six-27-weight-fibers','p1:prop:v370-e6-cubic-support',sorted(map(len,normalfib.values())),[27]*6)
def projection(r):
 v=sum(r[1:4])/3
 return (F(0),r[1]-v,r[2]-v,r[3]-v)+r[4:]
weightsets={norm:{projection(r) for r in vs} for norm,vs in normalfib.items()}
for i,(norm,weights) in enumerate(weightsets.items()):
 ck('E6-projected-27-weight-unique-%d'%i,'p1:prop:v370-e6-cubic-support',len(weights),27)
# Choose one 27-weight orbit and reflect by D1 (orthogonal to E6 normal).
weights=next(iter(weightsets.values()));remain=set(weights);orbits=[]
while remain:
 w=next(iter(remain));orbit={w};todo=[w]
 while todo:
  u=todo.pop()
  for a in D1:
   z=refl(u,a)
   if z not in weights:raise AssertionError('D1 reflection left 27 weights')
   if z not in orbit:orbit.add(z);todo.append(z)
 orbits.append(orbit);remain-=orbit
ck('E6-27-D4-triality-weight-classes','p1:prop:v370-e6-cubic-support',sorted(map(len,orbits)),[1,1,1,8,8,8])
weightslist=sorted(weights);weightsset=set(weightslist);wit={w:i for i,orb in enumerate(orbits) for w in orb}
trip=set()
for a in weightslist:
 for b in weightslist:
  c=tuple(-x-y for x,y in zip(a,b))
  if c in weightsset and len({a,b,c})==3:trip.add(tuple(sorted((a,b,c))))
ck('E6-27-cubic-zero-triples-45','p1:prop:v370-e6-cubic-support',len(trip),45)
ck('E6-27-each-weight-five-triples','p1:prop:v370-e6-cubic-support',set(C.Counter(w for ts in trip for w in ts).values()),{5})
ct=C.Counter(tuple(sorted(len(orbits[wit[w]]) for w in ts)) for ts in trip)
ck('E6-27-cubic-class-counts-1+12+32','p1:prop:v370-e6-cubic-support',ct,{(1,1,1):1,(1,8,8):12,(8,8,8):32})

# Typed claim-specific tests do not imply signed E8 structure constants.

out=Path('/mnt/data/Paper1B-RigorousVerificationBatch4ArchivedB6Results-v1_1.json')
result={'metadata':{'source':str(src.name),'source_sha256':SOURCE_SHA,'batch':6,'protocol':'Paper00-RigorousVerificationDAGWorkProtocol-v2_4','evidence_level':'E3','arithmetic':'exact integers/Fractions/Q(phi)/SymPy','run_status':'PASS','test_count':len(rows),'failed':sum(not r['passed'] for r in rows),'limitations':'Selected finite claims only; remainder require independent case-by-case E3 and E4. No action/physical bridge.'},'checks':rows}
out.write_text(json.dumps(result,indent=2)+'\n')
print('FINISHED',len(rows),'independent exact checks; all pass; output',out)
