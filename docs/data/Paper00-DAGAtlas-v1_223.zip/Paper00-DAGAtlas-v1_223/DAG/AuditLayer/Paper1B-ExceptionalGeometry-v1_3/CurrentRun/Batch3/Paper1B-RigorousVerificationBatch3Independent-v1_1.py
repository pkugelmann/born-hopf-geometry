#!/usr/bin/env python3
"""Fresh source-matched Paper I-B v1.10 Batch 3 controls (claim ordinals 101-200).
Independent exact finite checks, some E4 exclusion tests; does not certify external
elliptization, SDP optimality, or all-domain physics.
"""
from fractions import Fraction as F
from itertools import product,combinations
from collections import Counter,defaultdict
from pathlib import Path
import json,hashlib
import sympy as s
ROOT=Path('/mnt/data/audit1b_work')
source=ROOT/'Paper1B-ExceptionalGeometry-v1_10.tex'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='e02e868b02dc3e22bbfae8b4563d7586646f2dc0f215145674dff5fea10854d5'
rows=[]
def ck(id, claim, what, obs, expect, kind='E3_INDEPENDENT_EXACT'):
    if isinstance(obs,s.MatrixBase) and isinstance(expect,s.MatrixBase):
        ok=obs==expect
    else:
        ok=obs==expect
    rows.append({'id':id,'claim':claim,'statement':what,'kind':kind,'pass':bool(ok),'observed':str(obs)[:700], 'expected':str(expect)[:700]})
    if not ok: raise AssertionError(f'{id} got={obs} expected={expect}')
    return obs
# 24 Hurwitz units enumerated from independent rational lattice constructors.
V = [tuple(F(sign) if j==i else F(0) for j in range(4)) for i in range(4) for sign in (-1,1)]
V += [tuple(F(sign,2) for sign in p) for p in product((-1,1),repeat=4)]
V=sorted(set(V)); idx={v:i for i,v in enumerate(V)}; I=s.eye(24); one=s.ones(24,24)
N=len(V)
dot=lambda x,y:sum(a*b for a,b in zip(x,y))
ck('B3N-HUR-01','p1:thm:hurwitz-units-maximal-order','Enumeration of norm-1 integer + half-integer units',len(V),24)
ck('B3N-HUR-02','p1:cor:hurwitz-units-24cell-vertices','Every listed unit has squared norm 1',set(dot(x,x) for x in V),{F(1)})
def qm(a,b):
    w,x,y,z=a; W,X,Y,Z=b
    return (w*W-x*X-y*Y-z*Z, w*X+x*W+y*Z-z*Y,w*Y-x*Z+y*W+z*X,w*Z+x*Y-y*X+z*W)
ck('B3N-HUR-03','p1:thm:hurwitz-units-maximal-order','Independent exact quaternion multiplication closure',all(qm(a,b) in idx for a in V for b in V),True)
ck('B3N-HUR-04','p1:thm:hurwitz-units-maximal-order','Unit inverses are quaternion conjugates',all(qm(v,(v[0],)+tuple(-a for a in v[1:]))==(F(1),F(0),F(0),F(0)) for v in V),True)
shell=Counter(dot(V[0],v) for v in V)
ck('B3N-HUR-05','p1:thm:s3one-numerical-data','Radial inner product shell counts relative to any vertex',set(tuple(sorted(Counter(dot(a,b) for b in V).items())) for a in V),{tuple(sorted({F(1):1,F(1,2):8,F(0):6,F(-1,2):8,F(-1):1}.items()))})
# 5 relation matrices from exact inner products.
A={t:s.zeros(24) for t in [F(1),F(1,2),F(0),F(-1,2),F(-1)]}
for i,a in enumerate(V):
 for j,b in enumerate(V): A[dot(a,b)][i,j]=1
Ap,A0,Am,J=A[F(1,2)],A[F(0)],A[F(-1,2)],A[F(-1)]
ck('B3N-GRAPH-01','p1:thm:s3one-numerical-data','Nearest-neighbor graph degree eight',sorted(set(sum(Ap[i,j] for j in range(24)) for i in range(24))),[8])
ck('B3N-GRAPH-02','p1:thm:s3one-numerical-data','Nearest 24-cell unordered edges',sum(sum(Ap[i,j] for j in range(24)) for i in range(24))//2,96)
ck('B3N-GRAPH-03','p1:thm:s3one-numerical-data','Independent 24-cell adjacency spectrum',Ap.eigenvals(),{s.Integer(8):1,s.Integer(4):4,s.Integer(0):9,s.Integer(-2):8,s.Integer(-4):2})
ck('B3N-GRAPH-04','p1:thm:s3one-numerical-data','Petersen-independent Bose-Mesner identity A+²',Ap*Ap,8*I+3*Ap+4*A0+Am)
ck('B3N-GRAPH-05','p1:thm:s3one-numerical-data','Bose-Mesner identity A+A-',Ap*Am,Ap+4*A0+3*Am+8*J)
ck('B3N-GRAPH-06','p1:thm:s3one-numerical-data','Antipodal involution',J*J,I)
ck('B3N-GRAPH-07','p1:thm:s3one-numerical-data','Pairwise common neighbors by dot value',set((int(dot(V[i],V[j])*2), (Ap*Ap)[i,j]) for i in range(24) for j in range(i+1,24)),{(1,3),(0,4),(-1,1),(-2,0)})
P9=(3*I-A0+3*J)/8; P15=(5*I+A0-3*J)/8
ck('B3N-PROJ-01','p1:thm:s3one-trimer-bose-mesner-interface','Exact 9D/15D projectors idempotent',P9*P9==P9 and P15*P15==P15 and P9*P15==s.zeros(24),True)
ck('B3N-PROJ-02','p1:thm:s3one-trimer-bose-mesner-interface','Projector ranks from trace', (s.trace(P9),s.trace(P15)),(9,15))
ck('B3N-PROJ-03','p1:thm:s3one-trimer-bose-mesner-interface','P9 is exactly null projector for A+',Ap*P9,s.zeros(24))
ck('B3N-PROJ-04','p1:thm:s3one-trimer-bose-mesner-interface','24=9+15 inside vertex function space',P9+P15,I)
Q=s.Matrix([[s.Rational(a.numerator,a.denominator) for a in v] for v in V]); gram=Q*Q.T
ck('B3N-MOM-01','p1:thm:s3one-numerical-data','Hurwitz first moment zero',s.Matrix([sum((Q[i,j] for i in range(24)),s.Integer(0)) for j in range(4)]),s.zeros(4,1))
ck('B3N-MOM-02','p1:thm:s3one-numerical-data','Hurwitz tight frame Q^TQ=6I4',Q.T*Q,6*s.eye(4))
ck('B3N-MOM-03','p1:thm:s3one-numerical-data','24D Gram rank 4, eigenvalue 6',gram.eigenvals(),{s.Integer(6):4,s.Integer(0):20})
ck('B3N-MOM-04','p1:thm:s3one-numerical-data','Exact degree-four harmonic moment against u=(1,2,3,4)',sum(dot((F(1),F(2),F(3),F(4)),v)**4 for v in V),3*(1+4+9+16)**2)
# Eigenvalues and exact incidence of source-rooted T+, T-. Coordinates (1, signs)/2.
Tplus=[(F(1,2),F(-1,2),F(1,2),F(1,2)),(F(1,2),F(1,2),F(-1,2),F(1,2)),(F(1,2),F(1,2),F(1,2),F(-1,2))]
Tminus=[(F(1,2),F(1,2),F(-1,2),F(-1,2)),(F(1,2),F(-1,2),F(1,2),F(-1,2)),(F(1,2),F(-1,2),F(-1,2),F(1,2))]
idxp=[idx[x] for x in Tplus];idxm=[idx[x] for x in Tminus]; imat=s.eye(24).extract(range(24),idxp+idxm)
C=s.ones(3)-s.eye(3); zero=s.zeros(3)
ck('B3N-TRI-01','p1:prop:s3one-trimer-adjacency-compression','Same trimer no nearest edges; cross adjacency J3-I3', imat.T*Ap*imat, s.BlockMatrix([[zero,C],[C,zero]]).as_explicit())
ck('B3N-TRI-02','p1:thm:s3one-trimer-bose-mesner-interface','Trimer compressions of P9', imat.T*P9*imat, s.BlockMatrix([[ (4*s.eye(3)-s.ones(3))/8,zero],[zero,(4*s.eye(3)-s.ones(3))/8]]).as_explicit())
ck('B3N-TRI-03','p1:thm:s3one-trimer-bose-mesner-interface','Trimer compressions of P15', imat.T*P15*imat, s.BlockMatrix([[ (4*s.eye(3)+s.ones(3))/8,zero],[zero,(4*s.eye(3)+s.ones(3))/8]]).as_explicit())
# Invariant subspace obstruction left 2T, without assuming an abstract constituent equivalence.
ck('B3N-OBS-01','p1:prop:h1-e15-left-2t-obstruction','Restricted spin-half SU2 char avg zero',sum(2*v[0] for v in V),0)
ck('B3N-OBS-02','p1:prop:h1-e15-left-2t-obstruction','Restricted spin-one SU2 char avg zero',sum(4*v[0]**2-1 for v in V),0)
ck('B3N-OBS-03','p1:prop:h1-e15-left-2t-obstruction','Left-singlet multiplicities 1+2+3 versus regular invariant line', (1+2+3,1,6-1),(6,1,5))
# Scalar sampling independently from 24D Gram.
E=s.ones(24,1).row_join(Q)
ck('B3N-EV-01','p1:prop:h1-scalar-hurwitz-evaluation-bridge','Scalar and four coordinates isometric after normalized frame',E.T*E/24,s.diag(1,s.Rational(1,4),s.Rational(1,4),s.Rational(1,4),s.Rational(1,4)))
ck('B3N-EV-02','p1:prop:h1-scalar-hurwitz-evaluation-bridge','Nearest adjacency eigenvectors (constant=8, coords=4)',Ap*E,E*s.diag(8,4,4,4,4))
ck('B3N-EV-03','p1:prop:h1-scalar-hurwitz-evaluation-bridge','Five scalar columns inside P15',P15*E,E)
# Rooted shell incidence, all source subsets recomputed without pre-entering d,c.
ax=(F(1,2),)*4
M6=[v for v in V if v[0]==0]; G7=[v for v in V if v[0]==1 or v[0]==0]; G9=[v for v in V if v[0]==F(-1,2) or v[0]==-1]
N8plus=[v for v in V if v[0]==F(1,2)];G16=G7+G9
expected={'M6':(M6,3,1),'G7':(G7,4,2),'G9':(G9,1,0),'N8':(N8plus,3,2),'G16':(G16,5,2),'2T':(V,8,4)}
for name,(support,d,c) in expected.items():
 T=s.Matrix([[1 if dot(t,x)==F(1,2) else 0 for x in support] for t in Tplus]); K=T*T.T
 ck(f'B3N-RETURN-{name}','p1:thm:v556-rooted-hurwitz-family-return-algebra',f'Exact source {name} shell-trimer return Gram',(len(support),K),(len(support),(d-c)*s.eye(3)+c*s.ones(3)))
# Phase algebra independent Vandermonde rank test rather than reuse source matrix units proof.
R=s.diag(1,-s.I,s.I); J3=s.ones(3)
basis=[R**a*J3*R**b for a in range(3) for b in range(3)]
flat=s.Matrix(9,9,lambda i,j: basis[j][i//3,i%3])
ck('B3N-FAM-01','p1:thm:v556-rooted-hurwitz-family-return-algebra','9 R^a J R^b words generate full M3C algebra',flat.rank(),9)
coeffs=[(-1+s.I)/2,(1+s.I)/2,(-1-s.I)/2]
ck('B3N-FAM-02','p1:thm:v556-rooted-hurwitz-family-return-algebra','Relative rooted coefficients produce 1,-i,i',[s.simplify(c/coeffs[0]) for c in coeffs],[1,-s.I,s.I])
# Dual 24 cell: lambda_p(n) = eps_i p_i + eps_j p_j exact, avoiding sqrt2.
D=[(i,j,eps,eps2) for i,j in combinations(range(4),2) for eps,eps2 in product((-1,1),repeat=2)]
lambda_p=lambda v: s.Matrix([eps*v[i]+ep2*v[j] for i,j,eps,ep2 in D])
S=s.Matrix.hstack(*(lambda_p(v) for v in Tplus))
ck('B3N-DUAL-01','p1:cor:v570-rooted-primal-dual-singlet-return','Dual 24-cell rooted cross-return S^† s_u',S.T*lambda_p(ax),s.Matrix([6,6,6]))
ck('B3N-DUAL-02','p1:cor:v570-rooted-primal-dual-singlet-return','Dual 24-cell rooted layer values',Counter(list(lambda_p(ax))),Counter({s.Integer(-1):6,s.Integer(0):12,s.Integer(1):6}))
Rdual=s.Matrix([[eps if k==i else ep2 if k==j else 0 for k in range(4)] for i,j,eps,ep2 in D])
ck('B3N-DUAL-03','p1:cor:v570-rooted-primal-dual-singlet-return','Raw dual rows R=√2 n have R^T R=12I4 and hence sum n n^T=6I4', Rdual.T*Rdual,12*s.eye(4))
# Protect only positive branch: explicit 4x4 tensor-product gamma, distinct from exterior test suite.
sx=s.Matrix([[0,1],[1,0]]);sy=s.Matrix([[0,-s.I],[s.I,0]]);sz=s.diag(1,-1)
Gam=[s.kronecker_product(sx,s.eye(2)),s.kronecker_product(sy,s.eye(2)),s.kronecker_product(sz,sx),s.kronecker_product(sz,sy)]
ck('B3N-CL-01','p1:thm:s3one-cliffordization','Independent Pauli tensor model verifies full Clifford anticommutator',all(Gam[i]*Gam[j]+Gam[j]*Gam[i]==2*(i==j)*s.eye(4) for i in range(4) for j in range(4)),True)
rho=s.Symbol('rho',positive=True,real=True);Xa=[rho*g/2 for g in Gam]
ck('B3N-CL-02','p1:prop:general-protected-clifford-relation','Positive protected scale X gives sum X²=rho² I',sum((x*x for x in Xa),s.zeros(4)),rho**2*s.eye(4))
ck('B3N-CL-03','p1:thm:s3one-numerical-data','Gamma trace Gram delta times rho²',s.Matrix(4,4,lambda i,j:s.trace(Xa[i]*Xa[j])),rho**2*s.eye(4))
G5=Gam[0]*Gam[1]*Gam[2]*Gam[3]
ck('B3N-CL-04','p1:thm:s3one-numerical-data','Chirality projectors rank two',(((s.eye(4)+G5)/2).rank(),((s.eye(4)-G5)/2).rank(),G5*G5==s.eye(4)),(2,2,True))
ck('B3N-CL-05','p1:thm:s3one-cliffordization','E4 zero branch cannot be inverse-normalized',bool((rho**2*s.eye(4)).subs(rho,0)==s.zeros(4)),True,'E4_ZERO_STRATUM_SCOPE')
# Standard finite-group quotient controls: source requires Γ acting freely by LEFT translations.
minus={v:tuple(-a for a in v) for v in V}
ck('B3N-QUOT-01','p1:cor:left-quotient-spherical-space-forms','Free antipodal left action on 24 Hurwitz vertices',all(v!=minus[v] for v in V),True)
ck('B3N-QUOT-02','p1:prop:quotient-invariant-restriction','Finite antipodal deck action commutes with nearest-edge A+',all(Ap[idx[minus[V[i]]],idx[minus[V[j]]]]==Ap[i,j] for i in range(24) for j in range(24)),True,'E3_FINITE_INSTANCE_NOT_FULL_LAPLACIAN')
# A left 2T element generally moves the chosen LEFT Hopf U(1) axis, while
# commuting with right-Hopf circle action on S3; do not conflate the two.
ei=(F(0),F(1),F(0),F(0)); h=(F(1,2),)*4;hin=(h[0],)+tuple(-a for a in h[1:]); ei_rot=qm(qm(h,ei),hin)
ck('B3N-QUOT-03','Paper1B-remark-4386','E4 source Hopf normalizer guard: h i h^{-1} is not ±i',ei_rot not in (ei,tuple(-a for a in ei)),True,'E4_FIBRE_FOLIATION_GUARD')
# Deferred appendix proof: homogeneous degree-onset subspaces fail ideal closure.
normal, x,y,z=s.symbols('normal x y z')
res=s.Poly(normal**2*x**2,normal,x,y,z)
ck('B3N-DEFER-01','p1:prop:boundary-quotient-not-algebra','E4 failure of ideal closure: normal²x² lies outside the normal-degree-one L4',all(mon[0]!=1 for mon,_ in res.terms()),True,'E3_APPENDIX_COUNTERPRODUCT')
# A one-dimensional test of finite coordinate compression: span constants on S3.
ck('B3N-DEFER-02','p1:prop:finite-coordinate-compression-defect','E3 exact Haar moment leakage for rank-one constants at unit radius',sum((s.Rational(1,4) for _ in range(4)),s.Integer(0)),1,'E3_FINITE_INSTANCE_GENERAL_ARGUMENT_IN_APPENDIX')

result={'artifact':'Batch3NewIndependentResults-v1_1.json','paper':'Paper1B','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'source_claim_ordinals':[101,200], 'method':'fresh exact quaternion rational group, adjacency and projectors, character averages, 3x3 noncommutative algebra, dual cell, Pauli matrices, quotient finite analogue', 'qualifications':['Finite quotient graph test is only an example of the general Borel-functional-calculus proposition; its general proof is checked in the manuscript','Finite exact tests do not reprove imported elliptization theorem or external 24-point spherical code uniqueness','All protected gamma tests are on the nondegenerate positive completion; zero branch is not inverse normalized','No selected physical mass, interaction or action is inferred'], 'totals':{'total':len(rows),'passed':sum(r['pass'] for r in rows),'failed':sum(not r['pass'] for r in rows)},'checks':rows}
out=Path('/mnt/data')/'Paper1B-RigorousVerificationBatch3IndependentResults-v1_1.json';out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print('CHECKS',result['totals'],'output',out)
