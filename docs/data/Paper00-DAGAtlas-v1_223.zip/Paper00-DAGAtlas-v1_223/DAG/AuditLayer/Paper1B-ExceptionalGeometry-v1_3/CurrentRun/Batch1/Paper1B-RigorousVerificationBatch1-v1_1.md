# Paper I-B — Rigorous Verification DAG, Batch 1

**Release artifact**: `Paper1B-RigorousVerificationBatch1-v1_1.md`  
**Protocol**: `Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md`  
**Target**: `Paper1B-ExceptionalGeometry-v1_10.tex` from `Paper00-PapersMinimal-v3_017(1).zip`  
**Source SHA-256**: `e02e868b02dc3e22bbfae8b4563d7586646f2dc0f215145674dff5fea10854d5`  
**Incoming atlas**: `Paper00-DAGAtlas-v1_150(1).zip`, Paper1B audit layer `v1_2` targeting source `v1_9`  
**Checkpoint classification**: `PARTIALLY_AUDITED` — no full-paper certification. `WITH_INHERITED_OPEN_GAPS` is a provenance status; this batch establishes no new mathematical refutation.

## 1. Coverage freeze and noninterference

A source-first parser enumerated **506** formal theorem/lemma/proposition/corollary/definition/remark environments, with a one-to-one matching first **483** entries against the existing v1_9 Paper I-B `AuditClaimLedger.json` (kind, order, and all printed source labels). The new v1_10 insert adds **23** formal statements (10 theorems, 7 corollaries, 6 remarks) in lines 19600–20351. This batch individually examined **all 23 new environments**, including their six explicit limitations; **17 mathematical results** received independent claim-matched checks. No paper or existing ZIP was modified. The 483 inherited claims remain historically categorized but are **not claimed to have been fully revalidated under this new run**.

| Batch-1 current-source status | Count |
|---|---:|
| VERIFIED within stated comparison scope | 12 |
| VERIFIED-CONDITIONAL, inherited A/U evidence/status reconciliation pending | 5 |
| FORMALIZED boundary remarks | 6 |
| **New current-source statements reviewed** | **23** |
| Historical inherited claims awaiting new-run revalidation | 483 |

Historical v1_9 carryover statuses only: **323 VERIFIED, 2 VERIFIED-CONDITIONAL, 49 REPRODUCED, 109 FORMALIZED**. Those are not fresh Batch-1 verdicts.

## 2. Claim-level disposition of the 17 results

| Current source claim | Line | Batch-1 status | Principal independent controls |
|---|---:|---|---|
| `p1:thm:cc12-directed-coherent-gram` | 19600 | VERIFIED (bounded) | E3-EXACT-NONET-A5, E3-FLOAT-NONET-OPERATOR |
| `p1:cor:cc12-nonet-projector-polynomial` | 19663 | VERIFIED (bounded) | E3-EXACT-NONET-A5, E3-FLOAT-NONET-OPERATOR |
| `p1b:thm:cc13-register-memory` | 19700 | VERIFIED-CONDITIONAL | E3-EXACT-CHAMBER-BLOCKS, E3-FLOAT-MEMORY-SPECTRUM |
| `p1b:cor:cc13-relaxation` | 19750 | VERIFIED-CONDITIONAL | E3-FLOAT-MEMORY-SPECTRUM, E4-MARKOV-SLOWDOWN |
| `p1b:thm:cc14-no-time-local-markov` | 19792 | VERIFIED-CONDITIONAL | E3-FLOAT-MEMORY-SPECTRUM, E4-INTERMEDIATE-NEGATIVITY |
| `p1b:cor:cc15-no-quadratic-backflow` | 19854 | VERIFIED-CONDITIONAL | E3-FLOAT-MEMORY-SPECTRUM, E4-INTERMEDIATE-NEGATIVITY |
| `p1b:thm:cc16-minimal-41state-memory` | 19893 | VERIFIED-CONDITIONAL | E3-REALIZATION-CONT-OBS, E4-MINIMALITY-SCOPE |
| `p1b:thm:cc13-band-frame` | 19955 | VERIFIED (bounded) | E3-SPHERE-62-MONOMIALS, E3-SHARP-FRAME |
| `p1b:cor:cc13-hopf-basic-frame` | 20011 | VERIFIED (bounded) | E3-SPHERE-62-MONOMIALS, E4-HOPF-BASIC-ONLY |
| `p1b:thm:cc15-alternating-haar` | 20037 | VERIFIED (bounded) | E3-EXACT-GROUP-OVERLAPS, E4-FINITE-BAND-ONLY |
| `p1b:thm:cc15-exceptional-character-overlap` | 20069 | VERIFIED (bounded) | E3-EXACT-GROUP-OVERLAPS, E4-FINITE-BAND-ONLY |
| `p1b:thm:cc16-heat-cubature-error` | 20135 | VERIFIED (bounded) | E3-EXACT-MOLIEN-RANKS, E3-HEAT-PW-REPLAY |
| `p1b:cor:cc16-heat-source-bound` | 20186 | VERIFIED (bounded) | E3-HEAT-PW-REPLAY, E4-EXACT-OPERATOR-ONLY |
| `p1b:thm:cc17-facet-double-coset` | 20215 | VERIFIED (bounded) | E3-EXACT-600-CENTERS, E3-EXACT-CHAMBER-BLOCKS |
| `p1b:thm:cc17-positive-vertex-facet-19` | 20251 | VERIFIED (bounded) | E3-EXACT-GROUP-OVERLAPS, E3-EXACT-720-CHARACTERS |
| `p1b:cor:cc17-720-heat-error` | 20290 | VERIFIED (bounded) | E3-EXACT-720-CHARACTERS, E3-HEAT-PW-REPLAY |
| `p1b:cor:cc17-register-lowband-blindness` | 20321 | VERIFIED (bounded) | E3-EXACT-HURWITZ-5DESIGN, E3-EXACT-CHAMBER-BLOCKS |

### Formal scope boundaries, reviewed (6)

- **19781** — Epistemic and dynamical boundary: Comparison walk is not a physically owned clock/process; kernel PSD not entrywise positivity.
- **19843** — Time-local negativity is not physical negative probability: Full 600-chamber M is Markov; negative intermediate register-only entries not CP-divisibility.
- **19883** — No assertion about trace norm, entropy, or physical decoherence: Norm claim only L2 for classical registered probabilities.
- **19940** — Compression does not imply a positive hidden-state model: 41 is finite-dimensional real linear time-invariant I/O minimum only.
- **20122** — No physical smoothing or infinitesimal spectral gap inferred: Per fixed finite representation band, not uniform whole L2 or cosmological selection.
- **20341** — Strongly limited physical scope: Marked 720-node scalar quadrature does not imply physical carrier, GP selector, state, or interacting effect.

## 3. Exact and adversarial checks (E3/E4)

**Directed axes and coherent nonet:** The source's ten explicit axes with directed pair signs satisfy the five tetrahedral frames exactly. In the exact field `Q(sqrt(2),sqrt(5))`, the paired-axis decomposition gives `G_+ = 2(J+P5)/3` and `G_- = U^T U`, the source spectrum `20/3 x1, 10/3 x3, 2/3 x5, 0 x11`, and rank-9 polynomial projector `P9`. The oriented binary-icosahedral action produces all 60 even pair-label permutations. Independent floating-point Hermitian checks agree to roughly `6e-15`. This is exact polarisation geometry, **not a proved meson Hamiltonian**.

**600-chamber register memory:** A freshly reconstructed 600-tetrahedral-facet census produces 25 disjoint 24-chamber blocks, 1200 triangular faces, and the source-matched exact identities `T^T U=J-B`, `B^T B=24I+6R`, `TB=J-(I+A)U`, and `U^T A U=6R`; the direct spectral projectors have ranks 1,8,16. The source 600-generator compression gives the 25-component convolution kernel `(75/256) exp(-21(t-s)/16) P_c`. Independent matrix tests find two distinct negative register-only *intermediate* entries at positive times while every `M(t)` itself is a valid stochastic matrix. `f_c(1)=0.4436445422`, strictly greater than `exp(-15/16)≈0.3916056267`. The smallest real LTI realization is 41 by McMillan residues `1+8+16+16`, with independent controllability and observability ranks 41. **Only** this comparison walk and real LTI I/O model is covered; inherited `v16-register-resolvent` stays `VERIFIED-CONDITIONAL` pending ledger reconciliation. No physical clock is supplied by this result.

**62-point spherical sampling:** The weighted 12+20+30 point rule exactly reproduces all **364** monomial moments of total degree ≤11. The 36-dimensional harmonic band `Y_0⊕...⊕Y_5` has numerical sample Gram `S*S=I_36` to `1.3e-15`, with 26-dimensional complement. Degree-6 cross coefficients into ≤5 cancel but the degree-12 diagonal moment differs: at a vertex, `P12=7429/33000`. Thus no isometry on the full degree-6 space; the Hopf statement is for normalized **basic scalar** functions only.

**Alternating `2O,2I` symmetrizers:** The aligned groups have cardinalities 48 and 120 and common `2T` cardinality 24. The exact ring computation enumerates 5760 pair contributions in 23 exact scalar classes. It independently yields `Tr(P_O^(12)P_I^(12))=11/32`, degree20 `95/128`, degree24 `761/2048`, and reproduces the Molien invariant ranks. The band-norm contraction follows from finite-dimensional two-projection singular values; **uniform operator-norm convergence over all L²** is expressly not claimed.

**Heat-smoothed scalar average:** The source Peter–Weyl orthonormality and round-Laplacian eigenvalues yield `Σ_(n≥1) (n+1)m_Γ(n) exp(-2tn(n+2)/R²)`. Exact Molien coefficients give first nonconstant degrees 6,8,12 and asymptotic amplitudes `sqrt(7), 3, sqrt(13)` for `2T,2O,2I`. Sharpness is the operator dual norm on the **stated** Haar-normalized scalar L² space, not an unlicensed Dirac/QCD comparison.

**600 facet centres / positive 720-rule:** The exactly reconstructed 600 tetrahedral facet centers agree with the double coset `IuI` (`u=(1+i)/sqrt(2)`) in five 120-point left `I` cosets; disjoint union with the 120 vertices gives 720 nodes. In exact quaternionic character sums the degree12 twisted factor is `−5/16`; weights `5/21` and `16/21` cancel it. Every nonconstant spherical harmonic degree 1–19 vanishes. Numerical controls independently tested **8,855 four-variable monomials** through degree 19; maximum absolute residual about `2.8e-13`. The degree20 witness is **nonzero** `17/28`, so 19 is sharp. The heat defect is first supported at degree20 with leading amplitude `17 sqrt(21)/28`; each of the 25 individual Hurwitz blocks is an exact degree-5 rule (126 exact monomial checks), making degree≤5 centered register readouts vanish.

**E4 claim-boundary tests:** Verified distinctions include comparison time versus physical process; nonnegative coarse return versus negative nondivisible intermediate map; minimal linear versus positive hidden Markov realization; degree-5 frame versus degree-6 failure; same representation versus unrelated owners; bandwise versus uniform L²; and mathematical scalar quadrature versus realized 720-state matter structure. None creates a new GP axiom or establishes an unclaimed physical observable.

## 4. All distinct issues found or carried forward

### Newly identified DAG-only issues

**BH-IBX-DAG-0003 — current-source claims not registered in incoming atlas (moderate, OPEN pending integration).** First source origin: `p1:thm:cc12-directed-coherent-gram`, line 19600; entire 23-statement insertion at 19581–20351. The supplied v1_150 atlas Paper I-B audit layer is scoped to v1_9 and thus omits these 23 current source objects and typed material routes. This is **not** a false theorem. **Impact:** all 23 new-source claim-query paths, with no proved physical cross-paper observable implication. **Obligation:** integrate exact IDs, claims, source anchors, proof routes, evidence, statuses and indexes in final DAG archive, with post-write validation.

**BH-IBX-DAG-0004 — inherited EV-0011 scope/status reconciliation (moderate, OPEN pending reconciliation).** First ledger origin: `BH-IBX-EV-0011`, old `p1:thm:v366-chamber-transporter-complement`, about line 16369. The historical issue has `lifecycle=RESOLVED`, `closure_status_v1_9=RESOLVED_WITH_SCOPED_EVIDENCE`, and simultaneously `issue_status=unresolved`, with a lingering certificate request covering all signed/cubic/Fourier structures; associated source claims remain `REPRODUCED` or `VERIFIED-CONDITIONAL`. The **geometric partition and the A/U identities specifically required for this batch** have now been reconstructed independently; this **does not** certify all untested Fourier/signed/cubic source claims. **Impact:** previous 600-chamber audit statuses and the five new memory results conditionally inheriting the source; no physical prediction path proved. **Obligation:** reconcile fields and separate verified geometric scope from remaining E3 obligations, without blanket promotion.

### Inherited open issue IDs (not newly established counterexamples)

- `BH-IBX-EV-0001`: p1:thm:petersen-pentagon-reciprocity — **inherited OPEN**, not re-adjudicated in this batch.
- `BH-IBX-EV-0002`: p1:thm:v371-petersen-600cell-total-cover — **inherited OPEN**, not re-adjudicated in this batch.
- `BH-IBX-EV-0003`: p1:prop:v371-petersen-q8-angular — **inherited OPEN**, not re-adjudicated in this batch.
- `BH-IBX-EV-0004`: p1:thm:v371-petersen-tangent-exact-sequence — **inherited OPEN**, not re-adjudicated in this batch.
- `BH-IBX-EV-0005`: p1:thm:v371-petersen-rooted-leakage — **inherited OPEN**, not re-adjudicated in this batch.
- `BH-IBX-EV-0006`: p1:prop:v371-petersen-quadrupole-flux — **inherited OPEN**, not re-adjudicated in this batch.
- `BH-IBX-EV-0009`: p1:thm:v339-petersen-sl4-isometry — **inherited OPEN**, not re-adjudicated in this batch.

The seven inherited open issues are maintained **once at their existing origins**, not copied as seven new failures of the new 17 mathematical results. Other previously resolved issue IDs are preserved in the source atlas. No new wrong constant, broken equation or theorem-level counterexample was certified in this batch.

## 5. Type-preserving dependency and release rules

The machine-readable ledger attaches **explicit MATERIAL_PROOF_USE** arrows only when the current proof actually consumes an imported object, keeping marked subgroup alignments and fixed operators as scope conditions. It records 17 new result nodes plus six named scope remarks, current source locators, E3/E4 evidence IDs, 483 historical records (individually marked `PENDING_REVALIDATION`), inherited open issue IDs and two new DAG issues. The specific `p2f:thm:v273-twin-projector-spectral-identity` material interface is read only as the degree12 twisted overlap dependency; **Paper II-F is not separately audited**.

The reproducible computational scripts are attached as four standalone files. The chamber script imports the versioned exact-ring script from its own directory. Save both `.py` files side by side and run the chamber script; other scripts run directly with available `numpy/scipy`.

**No DAG ZIP or ProofChain Audit ZIP is released at this intermediate batch**. On the user's requested *last batch*, build the next versioned global DAG Atlas ZIP and the audit ZIP, remove superseded active-version duplicates, reopen both files, and verify their manifests and all latest-only entries. Do not mark `FULLY_AUDITED` until all inherited 483 claims and meaningful equations/interfaces are rechecked or explicitly correctly classified.

## 6. Next batch

Revalidate the first approximately 100 historically indexed original statements (ordinal 1 onward) against v1_10 source, reusing prior E3/E4 certificates **only after** matching exact source and scope. Continue in substantial bounded batches, avoiding the misleading shortcut `historical VERIFIED ⇒ freshly audited`.
