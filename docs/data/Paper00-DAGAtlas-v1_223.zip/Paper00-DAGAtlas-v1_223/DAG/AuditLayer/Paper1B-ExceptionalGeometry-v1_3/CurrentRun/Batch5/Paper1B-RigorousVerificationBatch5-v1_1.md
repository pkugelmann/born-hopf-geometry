# Born–Hopf Geometry — Paper I-B rigorous source/DAG audit, Batch 5

**Artifact:** `Paper1B-RigorousVerificationBatch5-v1_1.md`  
**Audit protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md`  
**Frozen target:** `Paper1B-ExceptionalGeometry-v1_10.tex` in current `Paper00-PapersMinimal-v3_018.zip`  
**Audit intake:** `Paper00-DAGAtlas-v1_150(1).zip`; `Paper00-ProofChainAudits-v1_65.zip`  
**Target SHA-256:** `e02e868b02dc3e22bbfae8b4563d7586646f2dc0f215145674dff5fea10854d5`  
**Scope:** inherited formal claims **301–400** of **483**, current complete formal inventory **506** including 23 later additions; no source modification. 

## 1. Executive disposition

This batch audited exactly **100 inherited formal statements**. Source-backed inherited statuses remain **62 `VERIFIED`**, **17 `REPRODUCED`**, **21 `FORMALIZED`**. No inherited claim was bulk-promoted or downgraded and **no new in-domain mathematical counterexample** was found. Historical `REPRODUCED` is not equivalent to completed independent correctness proof. The 21 `FORMALIZED` objects are definitions, scope clauses, or similar typed formal statements, not theorem proofs.

Cumulative unique formal claims reviewed: **423/506 (83.60%)**; **83 inherited claims** remain to be audited (ordinals 401–483). The prior batch reviewed the 23 new v1.10 claims. Count by inherited/retained disposition across completed batches: **305 `VERIFIED`, 5 `VERIFIED-CONDITIONAL`, 17 `REPRODUCED`, 96 `FORMALIZED` = 423**. All numbers denote audit coverage, not a global physical validation result.

## 2. Source E0 and source-proof E1

- Whole current intervening text spanning claims 301–400 has **157,892 characters**, SHA-256 `aa0fad1fd3c4fabe3a52bb95d0eca58a8fab0010bc5b6298ae6771d6de7a9adc`, **byte-identical** with the source block from I-B v1.9 preserved in the atlas; the v1.10 bytes in current release v3_018 equal the previously inspected source bytes.
- All 100 source statements and associated following proof segments match the historical claim corpus under normalized whitespace; this protects certificate continuity but is **not a mathematical proof**.
- **44 unique explicit labels** used in local statements/proofs resolve: 37 local I-B, five Paper I-A, one Paper I-C and one Paper I-D. None is missing or ambiguously owned. There are 16 source-adjacent, heuristically detected proof-use **candidates**. These were recorded as `NO_AUTOMATIC_E2_EDGE`; they were **not added as verified material edges** on the strength of reference syntax alone.
- Four corollaries have no *separate following* proof environment: ordinals 306, 309, 339 and 352. Their statements are framed as consequences of immediately preceding results/source derivations. This observation alone is not a logical-gap finding; the ledger preserves the exact associated source and trace. The first 3 have historical analytic or dependent proof support; 352 also has a new exact commutator check.
- All prior source-level mathematical/physical scope firewalls have been preserved. In particular, finite Petersen, Hurwitz and chamber statements are not silently reinterpreted as particle, Hamiltonian, physical state-selection, action, or observable claims.

## 3. Historical E3 replay

Previous batches replayed the archived claim-linked controls against the present source freeze. Of archived Batch-5's 564 passed controls, **54 unique IDs** are linked to claims 301–400; of archived Batch-6's 1,120 passed controls, **961 unique IDs** are linked to this batch. Hence **1,015 claim-linked controls**, all passed. An additional archived Batch-7 suite of 19,530 passed controls was replayed in Batch 4, but contributes **zero direct claim-linked controls to this batch**; it is not conflated with coverage here.

Executable exact-check IDs are not the only valid E3 certificates: the historical atlas also contains **independent analytic arguments and scoped closure scripts** without control-ID listings. There are 29 mathematically substantive records with no executable ID linked either in this batch or the two historical suites: **24 `VERIFIED`** records supported by existing independent analytic/other source-specified certificates, and **five `REPRODUCED`** records still awaiting or retaining source-scoped certification. They are explicitly identified below, not promoted by source identity. Existing analytically supported statuses were retained only at their recorded scopes.

## 4. Fresh independent exact controls

Four new independent, source-targeted verifiers were run, with **2,370/2,370 controls passed**, linked to **21 distinct claim IDs** (including all eleven originally specified by EV-0009). Large per-group counts often represent symmetry-case sweeps, not thousands of unrelated theorem proofs.

| Area | Fresh controls passed | Reproducible Python script | Exact result JSON |
|---|---:|---|---|
| Petersen | 1936 | `Paper1B-RigorousVerificationBatch5Petersen-v1_1.py` | `Paper1B-RigorousVerificationBatch5PetersenResults-v1_1.json` |
| Hurwitz | 162 | `Paper1B-RigorousVerificationBatch5Hurwitz-v1_1.py` | `Paper1B-RigorousVerificationBatch5HurwitzResults-v1_1.json` |
| Bridges | 216 | `Paper1B-RigorousVerificationBatch5Bridges-v1_1.py` | `Paper1B-RigorousVerificationBatch5BridgesResults-v1_1.json` |
| Walk | 56 | `Paper1B-RigorousVerificationBatch5Walk-v1_1.py` | `Paper1B-RigorousVerificationBatch5WalkResults-v1_1.json` |

**Petersen/projector and Lie checks:** reconstructed Petersen edge complex and boundary, rank-(4,5,6) edge projectors, Gram eigenblocks, explicit orthonormal 15-operator map to traceless 4-dimensional endomorphisms, exact symmetric-versus-skew brackets, full 120-element S5 equivariance times 15 oriented edges, rank-15 coefficient projector and cycle-frame identities, five-cycle sign and golden-ratio sectors, and path-generated Lie ranks **(3,6,11,14,15)**. These tests do not establish an independently selected quantum dynamics.

**Hurwitz/A5 checks:** reconstructed **722 coset polygons** with counts **450+200+72** and exact pairwise block incidence; exact 24 Hurwitz-unit moment averages up through degree five, degree-six defect **1/64**; 24-cell coordinate/quadric sampled eigenspaces with ranks **1+4+9 = 14** and scalar Laplace eigenvalues **0,3,8**; finite A5 quintet invariant-rank comparison and twisted-vertex defect character tests.

**Six-axis Hodge/REYE checks:** independent 60-element A5 permutation realization on six Sylow-five axes; two ten-face orbit triangulations of projective space, stabilizer and complement incidence, signed Petersen Hodge matrix (eigenvalues `√5`, `−√5`, `0` with multiplicities **3,3,4**), 20-vertex Desargues/dodecahedron covers, exact distance-two operator, six positive/six negative Petersen pentagon voltages, and 25×30 Reye quotient incidence rank **24**. These verify finite incidence representation, not every upstream geometric 600-cell embedding without its own witness.

**Fixed-core walk tests:** independent A4 eight 3-cycle average acting on the Petersen quintet, rank-2 eigenvalue **−1/2** and rank-3 kernel, the **15+10** left-convolution split, non-isomorphism with the untwisted Petersen vertex representation, and change of the walk under moving the fixed tetrahedral core.

## 5. EV-0009: eleven specifically inherited claims now have fresh E3

| Source claim | New exact controls | Previous ledger status |
|---|---:|---|
| `p1:thm:v339-petersen-sl4-isometry` | 1817 | REPRODUCED |
| `p1:cor:v339-petersen-matrix-symmetric-pair` | 1 | REPRODUCED |
| `p1:thm:v339-petersen-projector-strata` | 4 | REPRODUCED |
| `p1:cor:v340-reye-dodeca-second-neighbour` | 9 | REPRODUCED |
| `p1:thm:v341-desargues-rp2-parity` | 208 | REPRODUCED |
| `p1:prop:v341-walk-kernel-no-petersen-isomorphism` | 56 | REPRODUCED |
| `p1:thm:v342-three-cycle-petersen-overlap` | 78 | REPRODUCED |
| `p1:thm:v342-triangle-petersen-cycle-isometry` | 5 | REPRODUCED |
| `p1:thm:v342-class-frame-three-cycle-tomography` | 9 | REPRODUCED |
| `p1:thm:v342-minimal-path-lie-generators` | 7 | REPRODUCED |
| `p1:prop:v343-fivefold-signed-contrast` | 5 | VERIFIED |

All **11/11** claims implicated by `BH-IBX-EV-0009` have at least one new finite exact check, some with full symmetry sweeps. This changes the **available E3 evidence**, but does **not** automatically change either the canonical history of this issue or the statuses of its `REPRODUCED` claim nodes. In particular, the exact six-axis quotient representation is not a standalone independent check of every specific dodecahedral/600-chamber embedding; a physical particle interpretation would require separate source-licensed constructors. Final integration must adjudicate precisely which issue subclauses are closed and retain all surviving limitations.

## 6. Other incomplete independent certificates retained

Five `REPRODUCED` claims in this interval have **no new individual independent E3 script/check ID**:

- `p1:prop:v215-eight-alias`
- `p1:cor:v226-native-inner-controls`
- `p1:thm:v366-chamber-transporter-complement`
- `p1:thm:v366-face-register-identity`
- `p1:thm:v366-petersen-face-walk`

- `p1:prop:v215-eight-alias` (degree-eight harmonic/power aliases) and `p1:cor:v226-native-inner-controls` (native control algebra scope) remain `REPRODUCED`; the present batch does not silently use source proof as E3.
- The three `v366` chamber/transporter/face-walk claims (ordinals 398–400) depend on the exact 600-chamber **25-block geometric partition**, not merely on the 600-cell graph numbers or on a dimension count. The older atlas has a scoped EV-0011 resolution; it is **not reopened** simply because the standalone exact-check files were not newly re-executed for these three statements. Historical status/closure records are retained and will be reconciled with verified source-bound obligations in the final DAG release.
- As a cross-check, the archived 600-cell/Hurwitz finite verifier reproduces **120 vertices, 600 tetrahedra, 24 Hurwitz units, 96 edges, face incidence rank 73 and 23 kernel modes**; it explicitly does **not** independently establish the entire 25-column chamber complement `U` and therefore is not used to mark the three `v366` claims verified.

## 7. Dependency E2 / adversarial E4 status

- Local/cross-source labels are resolved, but syntactic references do **not** imply proof dependencies or physical construction edges; the 16 reviewed candidates remain typed `CANDIDATE_LINK` with no cycle/condition propagation.
- Mathematical scope guards preserved: group/coset exact statements, sampled cubature, operator identity, external representation inputs, and optional trial readouts are separate theorem layers. In particular the **41-dimensional register cyclic span** and the 30-dimensional chamber/Petersen cyclic span are *not* measurements of masses, widths or channel counts.
- All fresh adversarial exact comparisons passed: full S5 covariance, stabilizer-equivariant incidence, exact normalization, eigenvalue multiplicities, parity and twisted-versus-untwisted representation distinctions, and no-dependence of right regularity on left core selection.
- No new logical-failure, counterexample or missing imported-source locator was established. This absence does **not** certify every global physical inference or imported embedding.

## 8. All inherited pending issues (status as of Batch 5)

| Canonical issue ID | Batch-5 handling |
|---|---|
| `BH-IBX-EV-0001` | BATCH2 EXACT E3 PASSED ATLAS RECONCILIATION FINAL BATCH |
| `BH-IBX-EV-0002` | BATCH2 EXACT E3 PASSED ATLAS RECONCILIATION FINAL BATCH |
| `BH-IBX-EV-0003` | BATCH2 EXACT E3 PASSED ATLAS RECONCILIATION FINAL BATCH |
| `BH-IBX-EV-0004` | BATCH2 EXACT E3 PASSED ATLAS RECONCILIATION FINAL BATCH |
| `BH-IBX-EV-0005` | BATCH2 EXACT E3 PASSED ATLAS RECONCILIATION FINAL BATCH |
| `BH-IBX-EV-0006` | BATCH2 EXACT E3 PASSED ATLAS RECONCILIATION FINAL BATCH |
| `BH-IBX-EV-0009` | ALL 11 LISTED SOURCE CLAIMS HAVE NEW INDEPENDENT FINITE E3; GLOBAL STATUS RECONCILIATION PENDING |
| `BH-IBX-DAG-0003` | v1 10 new 23 formal claims pending final DAG integration |
| `BH-IBX-DAG-0004` | 600-chamber graph claim/status scope reconciliation pending |

**Issue-count meaning:** nine historical pending objects are carried: six Batch-2 E3 evidence issues pending global archive reconciliation, one EV-0009 now with all claim-specific finite E3 but pending scoped adjudication, and two DAG integration/reconciliation tasks. The original records and issue ancestry must not be erased; no new issue ID is created for a mere source identity check.

## 9. Immutable deliverables and final-batch handoff

- Detailed claim-by-claim **100-statement ledger**: `Paper1B-RigorousVerificationBatch5Ledger-v1_1.json`, with SOURCE-AS-PRINTED, source SHA and line ranges, inherited scope/status, E0/E1/E3/E4, source reference owners, potential rather than automatic proof-use links, and exact control IDs.
- Evidence status/index summary: `Paper1B-RigorousVerificationBatch5EvidenceSummary-v1_1.json`.
- Four new independent E3 scripts and four machine-readable exact-result JSON files named in §4.
- The **original source manuscript, original papers ZIP, original DAG ZIP and original ProofChain Audits ZIP have not been modified**. The comprehensive successor DAG Atlas ZIP and latest-only ProofChain Audits ZIP remain **reserved for final Batch 6**, once inherited claims 401–483 are audited. Integration must preserve schema, historical issue lineage, global assumption nodes and supported material proof edges, update current source anchors, include all five batch certificates, and retain only the latest active version of each archived artifact.

**Current run state:** `PARTIALLY_AUDITED` — 423 of 506 formal statements covered and 83 inherited statements remain; no full-paper completion certification in this report.
