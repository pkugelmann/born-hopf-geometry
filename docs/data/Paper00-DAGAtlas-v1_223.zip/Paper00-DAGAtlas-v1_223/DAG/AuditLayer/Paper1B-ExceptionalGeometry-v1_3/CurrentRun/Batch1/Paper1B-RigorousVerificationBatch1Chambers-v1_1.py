#!/usr/bin/env python3
"""Independent E3 full 600-facet/25-block and A/U/T/B exact incidence witness.
Uses 2I exact quaternions Q(sqrt2,sqrt5), no archived graph certificates.
"""
import contextlib,io,sys,collections, itertools, numpy as np,json, pathlib, importlib.util
_evidence_path=pathlib.Path(__file__).with_name('Paper1B-RigorousVerificationBatch1Exact-v1_1.py')
_spec=importlib.util.spec_from_file_location('born_hopf_p1b_exact',_evidence_path)
E=importlib.util.module_from_spec(_spec)
with contextlib.redirect_stdout(io.StringIO()):
 _spec.loader.exec_module(E)
from fractions import Fraction as F
Z,H,I,LR,RR,qmul,PHI,phi_half,invphi_half=E.Z,E.H,E.I,E.LR,E.RR,E.qmul,E.PHI,E.phi_half,E.invphi_half
R=E.R
F0=[(R(1,2),phi_half,Z,invphi_half),
    (R(1,2),phi_half,Z,E.neg(invphi_half)),
    (phi_half,R(1,2),invphi_half,Z),
    (phi_half,R(1,2),E.neg(invphi_half),Z)]
assert all(v in set(I) for v in F0)
centers=[];facets=[];which=[]
vertex_lookup={v:k for k,v in enumerate(I)}
# source facet is left/right isometric orbit of F0
for i,aa in enumerate(LR):
 for j,bb in enumerate(RR):
  for hh in H:
   cf=qmul(qmul(qmul(aa,hh),E.Uquat),bb)
   fac=frozenset(vertex_lookup[qmul(qmul(qmul(aa,hh),v),bb)] for v in F0)
   assert len(fac)==4
   centers.append(cf);facets.append(fac);which.append(i*5+j)
assert len(set(centers))==len(set(facets))==600
assert set(centers)==E.F_exact
# Exact pairwise dot for all 4-simplex tetrahedral facets
for facet in facets:
 ids=list(facet)
 for m,n in itertools.combinations(ids,2):assert E.dot(I[m],I[n])==E.scale(F(1,2),PHI)
# A's 4 neighbours from unique paired triangular faces.
face_occ=collections.defaultdict(list)
for k,facet in enumerate(facets):
 for face in itertools.combinations(sorted(facet),3):face_occ[face].append(k)
assert len(face_occ)==1200 and all(len(v)==2 for v in face_occ.values())
A=np.zeros((600,600),dtype=np.int64)
for hits in face_occ.values():
 x,y=hits;A[x,y]=A[y,x]=1
assert np.all(np.sum(A,axis=1)==4)
T=np.zeros((600,120),dtype=np.int64)
for k,f in enumerate(facets):T[k,list(f)]=1
U=np.zeros((600,25),dtype=np.int64)
for k,w in enumerate(which):U[k,w]=1
assert np.array_equal(U.T@U,24*np.eye(25,dtype=np.int64))
B=np.zeros((120,25),dtype=np.int64)
for i,aa in enumerate(LR):
 for j,bb in enumerate(RR):
  for hh in H:
   vertex=qmul(qmul(aa,hh),bb)
   B[vertex_lookup[vertex],i*5+j]=1
J12025=np.ones((120,25),dtype=np.int64)
J60025=np.ones((600,25),dtype=np.int64)
J5=np.ones((5,5),dtype=np.int64);I5=np.eye(5,dtype=np.int64)
Rrook=np.kron(J5-I5,J5-I5)
checks={
 'Tt_U_eq_J_minus_B':np.array_equal(T.T@U,J12025-B),
 'BtB_eq_24I_plus_6R':np.array_equal(B.T@B,24*np.eye(25,dtype=np.int64)+6*Rrook),
 'TB_eq_J_minus_IplusA_U':np.array_equal(T@B,J60025-U-A@U),
 'UtAU_eq_6R':np.array_equal(U.T@A@U,6*Rrook),
 'U_source_centered_polynomial':np.array_equal((A@(A@U)+A@U-5*U)@np.kron(5*I5-J5,5*I5-J5),np.zeros((600,25),dtype=np.int64)),
 'AS_P0':np.array_equal((A@U)@np.kron(J5,J5),4*U@np.kron(J5,J5)),
 'AS_Pa':np.array_equal((A@U)@(np.kron(J5,5*I5-J5)+np.kron(5*I5-J5,J5)),-U@(np.kron(J5,5*I5-J5)+np.kron(5*I5-J5,J5))),
 'four_neighbor_regular':np.array_equal(A@np.ones(600,dtype=np.int64),4*np.ones(600,dtype=np.int64)),
 'facets_600':len(facets)==600,
 'face_triangles_1200':len(face_occ)==1200,
 'blocks_25x24':set(U.sum(0))=={24}
}
print('EXACT_CHAMBER_PARTITION_CHECKS',json.dumps(checks));assert all(checks.values())
# serial invariant: A has 600 vertices and 1200 edges
print('EXACT_CHAMBER_COUNTS',json.dumps({'vertices':len(I),'tetrahedral_chambers':len(facets),'triangular_faces':len(face_occ),'dual_face_graph_edges':int(A.sum()//2),'registers':25,'per_register':24,'source_hash_source_current':'v1_10'}))
