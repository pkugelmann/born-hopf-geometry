#!/usr/bin/env python3
"""Exact independent rational/radical checks in Q(sqrt2,sqrt5).
Uses a four-coordinate field basis (1,sqrt2,sqrt5,sqrt10),
not symbolic-float approximations or historical framework scripts.
"""
from fractions import Fraction as F
from itertools import product, permutations,combinations
from collections import Counter
from math import factorial
import json
import math
Z=(F(0),)*4
ONE=(F(1),F(0),F(0),F(0))
TWO=(F(2),F(0),F(0),F(0))
def a(x,y):return tuple(u+v for u,v in zip(x,y))
def neg(x):return tuple(-v for v in x)
def sub(x,y):return a(x,neg(y))
def scale(k,x):return tuple(F(k)*v for v in x)
def mul(x,y):
 out=[F(0)]*4
 for i,b in enumerate(x):
  if not b:continue
  for j,c in enumerate(y):
   if not c:continue
   k=i^j
   factor=(2 if (i&j&1) else 1)*(5 if (i&j&2) else 1)
   out[k]+=factor*b*c
 return tuple(out)
R=lambda n,d=1: (F(n,d),F(0),F(0),F(0))
sqrt2=(F(0),F(1),F(0),F(0))
sqrt5=(F(0),F(0),F(1),F(0))
phi_half=(F(1,4),F(0),F(1,4),F(0))
invphi_half=(F(-1,4),F(0),F(1,4),F(0))
cos45=scale(F(1,2),sqrt2)
H=[]
for i in range(4):
 for sign in [-1,1]:
  arr=[Z]*4;arr[i]=R(sign);H.append(tuple(arr))
for signs in product((-1,1), repeat=4):H.append(tuple(R(v,2) for v in signs))
I=H.copy()
for perm in permutations(range(4)):
 if sum(perm[i]>perm[j] for i in range(4) for j in range(i+1,4))%2:continue
 for signs in product((-1,1),repeat=3):
  vals=[Z,*[scale(s,v) for s,v in zip(signs,[R(1,2),phi_half,invphi_half])]]
  arr=[Z]*4
  for j,k in enumerate(perm):arr[k]=vals[j]
  I.append(tuple(arr))
O=H.copy()
for i,j in combinations(range(4),2):
 for s,t in product((-1,1),repeat=2):
  arr=[Z]*4;arr[i]=scale(s,cos45);arr[j]=scale(t,cos45);O.append(tuple(arr))
assert len(I)==len(set(I))==120 and len(O)==len(set(O))==48 and len(set(I)&set(O))==24

def dot(x,y):
 out=Z
 for u,v in zip(x,y):out=a(out,mul(u,v))
 return out

def ChebU(n,x):
 if n==0:return ONE
 p=ONE;q=scale(2,x)
 if n==1:return q
 for k in range(2,n+1):p,q=q,sub(mul(scale(2,x),q),p)
 return q

def average(hist,n,denom):
 total=Z
 for x,c in hist.items():total=a(total,scale(c,ChebU(n,x)))
 return scale(F(1,denom),total)

pairs=Counter(dot(g,h) for g in O for h in I)
print('EXACT_PAIR_SCALAR_CLASSES',len(pairs),'count',sum(pairs.values()))
assert sum(pairs.values())==5760 and len(pairs)==23
out={}
for n,want in [(12,F(11,32)),(20,F(95,128)),(24,F(761,2048))]:
 v=average(pairs,n,48*120)
 out[f'c{n}_sq_or_trace']=[str(t) for t in v]
 assert v==R(want), (n,v,want)
print('EXACT_GROUP_OVERLAPS',json.dumps(out))

# real quaternion part of h*(1+i)/sqrt(2), equal (h0-h1)/sqrt(2)
twist=Counter(mul(sub(h[0],h[1]),cos45) for h in I)
print('EXACT_TWIST_SCALAR_CLASSES',len(twist),'count',sum(twist.values()))
twistout={}
for n,want in [(12,F(-5,16)),(20,F(31,64))]:
 v=average(twist,n,120)
 twistout[f'twist_n{n}']=[str(t) for t in v]
 assert v==R(want),(n,v,want)
print('EXACT_TWIST_OVERLAPS',json.dumps(twistout))

# Direct Molien rank values from raw group characters
for group_name,G in [('2T',H),('2O',O),('2I',I)]:
 hist=Counter(v[0] for v in G)
 rank={n:average(hist,n,len(G)) for n in range(25)}
 assert all(v[1:]==(F(0),F(0),F(0)) and v[0].denominator==1 for v in rank.values())
 print('EXACT_MOLIEN_RANKS',group_name,{str(n):int(v[0]) for n,v in rank.items() if v[0]})

# 720 node design Fourier representation: only I-invariant n=12 for 1..19,
# on that one-dimensional line 5/21 + 16/21*(-5/16)=0
assert a(scale(F(5,21),ONE),scale(F(16,21),R(-5,16)))==Z
r20=a(scale(F(5,21),ONE),scale(F(16,21),R(31,64)))
assert r20==R(F(17,28))
print('EXACT_720_CHARACTER',{'n12':0,'n20':str(r20[0]),'norm20_squared':str(F(21)*r20[0]**2)})

def qmul(v,w):
 p,q,r,s=v; x,y,z,t=w
 return (sub(sub(sub(mul(p,x),mul(q,y)),mul(r,z)),mul(s,t)),
         a(a(sub(mul(p,y),mul(s,z)),mul(q,x)),mul(r,t)),
         a(a(a(mul(p,z),mul(s,y)),mul(r,x)),neg(mul(q,t))),
         a(a(sub(mul(p,t),mul(r,y)),mul(q,z)),mul(s,x)))
Uquat=(cos45,cos45,Z,Z)
# u H u^{-1} = H in actual exact quaternion group
Uinv=(cos45,neg(cos45),Z,Z)
assert {qmul(qmul(Uquat,h),Uinv) for h in H}==set(H)

def coset_reps(left=True):
 remaining=set(I);reps=[]
 while remaining:
  v=min(remaining)
  orbit={qmul(v,h) if left else qmul(h,v) for h in H}
  assert len(orbit)==24
  reps.append(v);remaining-=orbit
 return reps
LR=coset_reps(True);RR=coset_reps(False)
assert len(LR)==len(RR)==5
blocks=[]
for x in LR:
 for y in RR:
  block={qmul(qmul(qmul(x,h),Uquat),y) for h in H}
  assert len(block)==24
  blocks.append(block)
assert len(set.union(*blocks))==600 and sum(map(len,blocks))==600
F_exact=set.union(*blocks)
IuI={qmul(qmul(x,Uquat),y) for x in I for y in I}
assert F_exact==IuI and len(IuI)==600 and len(IuI&set(I))==0
print('EXACT_600_CHAMBER_COSSETS',json.dumps({'I_left_cosets':len(LR),'I_right_cosets':len(RR),'blocks':len(blocks),'elements_per_block':sorted(set(map(len,blocks))),'union':len(F_exact),'disjoint_from_vertices':len(IuI&set(I))==0}))
# check direct fifth-degree moments of H subset R^4 exactly
from itertools import product
from math import gamma
err=[];total=0
for i in range(6):
 for j in range(6-i):
  for k in range(6-i-j):
   for l in range(6-i-j-k):
    p=(i,j,k,l)
    if any(x%2 for x in p):ref=F(0)
    else:
     # 4D sphere moment = product (p_i-1)!! / product (1,3,...,(sum(p)+2))
     def odd(n):
      v=1
      for t in range(1,n+1,2):v*=t
      return v
     ref=F(math.prod(odd(x-1) for x in p),math.prod(4+2*j for j in range(sum(p)//2)))
    obs=sum((math.prod([x[t][0]**p[t] for t in range(4)]) for x in H),F(0))/24
    total+=1
    if obs!=ref:err.append((p,str(obs),str(ref)))
print('EXACT_HURWITZ_5DESIGN',{'moments':total,'failures':err[:4],'pass':len(err)==0})
assert not err
# Exact directed-axis and nonet Gram verification, in Q(sqrt5) subfield
PHI=a(scale(F(1,2),ONE),scale(F(1,2),sqrt5))
INVPHI=sub(PHI,ONE)
vectors=[
(R(1),R(1),R(1)),(R(1),R(1),R(-1)),(R(1),R(-1),R(1)),(R(1),R(-1),R(-1)),
(INVPHI,neg(PHI),Z),(PHI,Z,neg(INVPHI)),(Z,INVPHI,neg(PHI)),
(Z,INVPHI,PHI),(PHI,Z,INVPHI),(INVPHI,PHI,Z)]
EPS=[-1,1,1,-1,1,-1,1,-1,1,-1]
pairs=list(combinations(range(5),2))
V={key:tuple(scale(EPS[k],v) for v in vectors[k]) for k,key in enumerate(pairs)}
V.update({(j,i):tuple(neg(v) for v in V[i,j]) for i,j in pairs})
def tripdot(v,w):
 z=Z
 for x,y in zip(v,w):z=a(z,mul(x,y))
 return scale(F(1,3),z)
from functools import reduce
sumfield=lambda items:reduce(a,items,Z)
for i in range(5):
 for c in range(3):assert sumfield(V[i,j][c] for j in range(5) if j!=i)==Z
 for j in range(5):
  if j==i:continue
  for k in range(5):
   if k not in (i,j): assert tripdot(V[i,j],V[i,k])==R(F(-1,3))
assert all(tripdot(v,v)==ONE for v in V.values())
# 10x10 exact orthogonal P5 and U^T U block, deduced independently from direct H(n) Gram
N=[V[k] for k in pairs]
Ds=[[tripdot(x,y) for y in N] for x in N]
P5=[[scale(F(1,4),sub(scale(3,mul(Ds[i][j],Ds[i][j])),ONE)) for j in range(10)] for i in range(10)]
for i in range(10):
 assert sumfield(P5[i])==Z
 for j in range(10):
  v=sumfield(mul(P5[i][k],P5[k][j]) for k in range(10))
  assert v==P5[i][j]
for i in range(3):
 for j in range(3):
  d=scale(F(1,3),sumfield(mul(N[k][i],N[k][j]) for k in range(10)))
  assert d== (R(F(10,3)) if i==j else Z)
assert sumfield(P5[i][i] for i in range(10))==R(5)
# exact A5 equivariance, no ambient sign-selector assumption
arrow_keys=list(V)
vector_lookup={V[key]:key for key in arrow_keys}
perms=set()
for g in I:
 inv=(g[0],neg(g[1]),neg(g[2]),neg(g[3]))
 image={}
 for key,v in V.items():
  out=qmul(qmul(g,(Z,*v)),inv)
  assert out[0]==Z
  assert out[1:] in vector_lookup
  image[key]=vector_lookup[out[1:]]
 p=[]
 for i in range(5):
  dest={image[(i,j)][0] for j in range(5) if j!=i}
  assert len(dest)==1
  p.append(next(iter(dest)))
 assert len(set(p))==5
 assert all(image[(i,j)]==(p[i],p[j]) for i in range(5) for j in range(5) if i!=j)
 perms.add(tuple(p))
assert len(perms)==60
print('EXACT_NONET_GRAM_A5',{'exact_projector_P5_rank':5,'exact_odd_eigs':('10/3 x3','0 x7'),'exact_even_eigs':('20/3 x1','2/3 x5','0 x4'),'A5_even_permutations':len(perms),'corollary_P9_rank':9})
