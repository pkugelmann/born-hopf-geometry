#!/usr/bin/env python3
"""Portable exact Q(sqrt5) audit of 20D Petersen tangent and five-root leakage.
Source-as-printed: Paper1B-ExceptionalGeometry-v1_10.tex 816--978.
No historical verifier artifacts imported.  The only input is the source's
explicit ten axis vectors and the graph rule on disjoint pair labels.
"""
from fractions import Fraction as F
from dataclasses import dataclass
from itertools import combinations
import numpy as np,json,pathlib,hashlib,collections
@dataclass(frozen=True, slots=True)
class Q5:
 a:F=F(0);b:F=F(0)
 def __post_init__(self):
  if type(self.a)!=F:object.__setattr__(self,'a',F(self.a))
  if type(self.b)!=F:object.__setattr__(self,'b',F(self.b))
 def __add__(self,x):
  if not isinstance(x,Q5):x=Q5(x)
  return Q5(self.a+x.a,self.b+x.b)
 __radd__=__add__
 def __neg__(self):return Q5(-self.a,-self.b)
 def __sub__(self,x):return self+-x if isinstance(x,Q5) else self+Q5(-x)
 def __rsub__(self,x):return -self+x
 def __mul__(self,x):
  if not isinstance(x,Q5):return Q5(self.a*x,self.b*x)
  return Q5(self.a*x.a+5*self.b*x.b,self.a*x.b+self.b*x.a)
 __rmul__=__mul__
 def __truediv__(self,x):
  if isinstance(x,(int,F)):return Q5(self.a/x,self.b/x)
  raise TypeError('integer/rational only')
 def __float__(self):return float(self.a)+float(self.b)*5**.5
 def __str__(self):return f'{self.a}+({self.b})sqrt5'
Z=Q5();ONE=Q5(1);ph=Q5(F(1,2),F(1,2));iv=Q5(F(-1,2),F(1,2))
def mat(n,m):return np.full((n,m),Z,dtype=object)
def eye(n):
 x=mat(n,n)
 for i in range(n):x[i,i]=ONE
 return x
def tr(m):return sum((m[i,i] for i in range(min(m.shape))),Z)
def zero(m):
 for el in np.nditer(m,flags=['refs_ok']):
  if el.item()!=Z:return False,repr(el.item())
 return True,None
checks={}
def check(name, expression):
 p,bad=zero(expression);checks[name]={'passed':p,'first_nonzero':bad}
 if not p:print('FAIL',name,bad)
 return p
A=mat(3,10)
raw=[(1,1,1),(1,1,-1),(1,-1,1),(1,-1,-1),(iv,-ph,0),(ph,0,-iv),(0,iv,-ph),(0,iv,ph),(ph,0,iv),(iv,ph,0)]
for i,abc in enumerate(raw):
 for k,a in enumerate(abc):A[k,i]=a if isinstance(a,Q5) else Q5(a)
As=mat(3,10)
for idx,x in np.ndenumerate(A):As[idx]=Q5(x.a,-x.b)
labels=list(combinations(range(5),2))
edges=[(i,j) for i,j in combinations(range(10),2) if not (set(labels[i])&set(labels[j]))]
assert len(edges)==15
# 3x3 core intertwiners as J_m = (A_m^sigma A_m^T)/4
J=[]
for m in range(5):
 cols=[i for i,label in enumerate(labels) if m in label]
 assert len(cols)==4
 J.append((As[:,cols]@A[:,cols].T)/4)
for i in range(5): check(f'J{i}T_J{i}_I',J[i].T@J[i]-eye(3))
check('five_core_J_sum',sum(J[1:],J[0])-mat(3,3))
# each P_i is orthogonal projection onto two-dimensional tangent fibre, though stored in 3 ambient coordinates
P=[]
for v in range(10):P.append(eye(3)-np.outer(A[:,v],A[:,v])/3)
PV=mat(30,30)
for v in range(10):PV[3*v:3*v+3,3*v:3*v+3]=P[v]
check('PV_idempotent',PV@PV-PV)
# from source graph signed trimer, K edges are +/- (a_v cross a_w)/2 (normalization of unit u=a/sqrt3).
BB=mat(10,15);Fmat=mat(30,15)
for e,(u,v) in enumerate(edges):
 dot=sum((A[k,u]*A[k,v] for k in range(3)),Z)
 s=1 if float(dot)>0 else -1
 cross=np.array([A[1,u]*A[2,v]-A[2,u]*A[1,v],A[2,u]*A[0,v]-A[0,u]*A[2,v],A[0,u]*A[1,v]-A[1,u]*A[0,v]],dtype=object)
 kv=(s/2 if False else F(s,2))*cross
 Fmat[3*u:3*u+3,e]=kv
 Fmat[3*v:3*v+3,e]=-kv
 BB[u,e]=ONE;BB[v,e]=ONE
# projective trimer maps: 1 represented by the three outward half turn vectors.
check('E3-EV0004_tangent_F_Gram',Fmat.T@Fmat-(3*eye(15)-BB.T@BB/2))
check('F_in_tangent_PV',PV@Fmat-Fmat)
check('F_annihilates_constant',Fmat@np.full((15,1),ONE,dtype=object))
# source M=(M_3,M_{3prime}), acting on tangent fibres
M=mat(6,30)
for v,(i,j) in enumerate(labels):
 M[0:3,3*v:3*v+3]=P[v]
 M[3:6,3*v:3*v+3]=(J[i]+J[j])@P[v]
L=mat(6,6)
for j in range(3):L[j,j]=Q5(F(20,3));L[j+3,j+3]=Q5(F(5,3))
check('E3-EV0004_MF_zero',M@Fmat)
check('E3-EV0004_MMdagger_receiver',M@M.T-L)
# normalized receiver orthogonal projector, local projector inside tangent 20-space
Linv=mat(6,6)
for j in range(3):Linv[j,j]=Q5(F(3,20));Linv[j+3,j+3]=Q5(F(3,5))
Prec=M.T@Linv@M
Ploc=PV-Prec
check('P_rec_proj',Prec@Prec-Prec)
check('P_loc_proj',Ploc@Ploc-Ploc)
check('P_rec_orth_P_loc',Prec@Ploc)
check('im_F_eq_local',Ploc@Fmat-Fmat)
assert tr(PV)==Q5(20) and tr(Prec)==Q5(6) and tr(Ploc)==Q5(14)
# exact F^T F polynomial has claimed distinct eigenvalues (0,1,5/2,3).
G=Fmat.T@Fmat
poly=G@(G-eye(15))@(G-eye(15)*Q5(F(5,2)))@(G-3*eye(15))
check('E3-EV0004_F_Gram_annihilating_poly',poly)
# show multiplicities with traces of spectral projectors, no numerical diagonalisation.
eigenvalues=[Q5(0),Q5(1),Q5(F(5,2)),Q5(3)]; mult={}
for l in eigenvalues:
 proj=eye(15)
 for s in eigenvalues:
  if l!=s:
   denom=l.a-s.a;proj=(proj@(G-eye(15)*s))/denom
 mult[str(l.a)]=str(tr(proj))
checks['E3-EV0004_spectrum_multiplicities']={'passed':mult=={'0':'1+(0)sqrt5','1':'5+(0)sqrt5','5/2':'4+(0)sqrt5','3':'5+(0)sqrt5'}, 'multiplicities':mult}
# root masks R_m : four axis tangent fibres of H_m
Rms=[];Amats=[];C=[]
for m in range(5):
 Rm=mat(30,30)
 for v,ij in enumerate(labels):
  if m in ij:Rm[3*v:3*v+3,3*v:3*v+3]=P[v]
 Rms.append(Rm)
 # A_m block 6x6 normalized without radicals: (sqrt(3/20),sqrt(3/5)) conjugations.
 X=M@Rm@M.T
 Am=mat(6,6); Am[:3,:3]=F(3,20)*X[:3,:3];Am[3:,3:]=F(3,5)*X[3:,3:]
 Am[:3,3:]=F(3,10)*X[:3,3:];Am[3:,:3]=F(3,10)*X[3:,:3]
 target=mat(6,6)
 target[:3,:3]=F(2,5)*eye(3);target[3:,3:]=F(2,5)*eye(3)
 target[:3,3:]=J[m].T/10;target[3:,:3]=J[m]/10
 check(f'E3-EV0005_A_core_{m}',Am-target)
 Amats.append(Am)
 C.append(Prec@Rm@Ploc)
check('E3-EV0005_sum_R_2PV',sum(Rms[1:],Rms[0])-2*PV)
check('E3-EV0005_sum_C_zero',sum(C[1:],C[0]))
check('E3-EV0005_receiver_CCt',sum([Cm@Cm.T for Cm in C[1:]], C[0]@C[0].T)-Prec*Q5(F(23,20)))
check('E3-EV0005_source_CtC',sum([Cm.T@Cm for Cm in C[1:]], C[0].T@C[0])-(Fmat@Fmat.T)*Q5(F(3,10))+Ploc*Q5(F(3,20)))
# A_m gives 1/4 and 21/100 leakage eigenvalues each triple (because A_m has 1/2 and 3/10 blocks)
for m,Am in enumerate(Amats):
 X=Am-Am@Am
 check(f'E3-EV0005_leak_spectral_poly_{m}', (X-eye(6)*Q5(F(1,4)))@(X-eye(6)*Q5(F(21,100))))
# Source LTI operator spectrum for Sigma_m C_m^T C_m via claimed FF^T on rank 14:
# eigenvalues on image F: source identity says lambda(F F^T)=(1 x5,5/2 x4,3 x5), and map to (3/20,3/5,3/4).
source_readout={'1':'3/20','5/2':'3/5','3':'3/4'}
checks['projective_D3_intertwiner_character']={'passed':(3*2+2*0*(-1)+3*1*0)//6==1,'Hom_D3_dimension':1,'comparison_Hom_C3_dimension':(3*2+2*0*(-1))//3}
checks['source_side_eigen_map']={'passed':bool(checks['E3-EV0005_source_CtC']['passed']), 'source_lambda_to_sumCtsC':source_readout,'multiplicities':{'3/20':5,'3/5':4,'3/4':5}}
fail=[k for k,v in checks.items() if not v['passed']]
p=pathlib.Path(__file__)
out={'source':'Paper1B-ExceptionalGeometry-v1_10.tex','source_statement_spans':['816--885','924--978'],'issue_ids':['BH-IBX-EV-0004','BH-IBX-EV-0005'],'field':'Q(sqrt5), exact Fraction pair arithmetic, embedded tangent-frame projections', 'checks':checks, 'failed':fail,'script_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
p.with_name('Paper1B-RigorousVerificationBatch2TangentResults-v1_1.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'passes':len(checks)-len(fail),'failed':fail,'spectral_multiplicities':mult, 'traces':{'PV':str(tr(PV)),'Prec':str(tr(Prec)),'Ploc':str(tr(Ploc))}},indent=2))
if fail:raise SystemExit(1)
