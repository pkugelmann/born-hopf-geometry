#!/usr/bin/env python3
"""Independent exact Q(sqrt5) replay of Paper I-B finite Petersen claims.

Current source: Paper1B-ExceptionalGeometry-v1_10.tex, claims
  p1:thm:petersen-pentagon-reciprocity
  p1:prop:v371-petersen-quadrupole-flux
Exact algebraic operations and exhaustive ten-vertex finite graph counts;
never changes theorem statement, physical interpretation or source files.
"""
import sympy as sp
import itertools, collections, json, pathlib, hashlib
rt=sp.sqrt(5); ph=(1+rt)/2; iv=(rt-1)/2; sq3=sp.sqrt(3)
labels=list(itertools.combinations(range(1,6),2))
raw=[(1,1,1),(1,1,-1),(1,-1,1),(1,-1,-1),(iv,-ph,0),(ph,0,-iv),(0,iv,-ph),(0,iv,ph),(ph,0,iv),(iv,ph,0)]
A=sp.Matrix.hstack(*[sp.Matrix(v) for v in raw]); U=A/sq3
assert len(labels)==10
edges=list((i,j) for i,j in itertools.combinations(range(10),2) if not set(labels[i])&set(labels[j]))
assert len(edges)==15
nd={i:[] for i in range(10)}
for i,j in edges:nd[i].append(j);nd[j].append(i)
Eindex={e:i for i,e in enumerate(edges)}
signed={e:sp.sign(sp.simplify((A[:,e[0]].dot(A[:,e[1]])).evalf())) for e in edges}
assert set(signed.values())=={-1,1}
def cross(a,b):return sp.Matrix([a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]])
K=sp.Matrix.hstack(*[signed[e]*cross(A[:,e[0]],A[:,e[1]])/2 for e in edges]); Ks=K.applyfunc(lambda x:sp.simplify(x).subs(rt,-rt))
def zero(m):
 for x in m:
  # minimal polynomial normal form over sqrt(5)
  y=sp.simplify(sp.expand(x));
  if y!=0:return False,str(y)
 return True,None
Pi3=K.T*K/5; Pi3s=Ks.T*Ks/5
checks={}
def check(label,expr):
 passed,bad=zero(expr);checks[label]={'passed':passed,'nonzero_witness':bad};
 if not passed:print('FAIL',label,bad)
 return passed
check('K_Kt_5I',K*K.T-5*sp.eye(3));check('Ksig_Ksigt_5I',Ks*Ks.T-5*sp.eye(3));check('K_Ksigt_0',K*Ks.T)
check('Pi3Pi3s_0',Pi3*Pi3s)

def canon_cycle(seq):
 seq=list(seq);ss=[]
 for arr in (seq,seq[::-1]):
  for k in range(len(seq)):ss.append(tuple(arr[k:]+arr[:k]))
 return min(ss)
cycles=set()
for start in range(10):
 def extend(seq):
  if len(seq)==5:
   if start in nd[seq[-1]]:cycles.add(canon_cycle(seq))
   return
  for v in nd[seq[-1]]:
   if v not in seq:extend(seq+[v])
 extend([start])
assert len(cycles)==12,len(cycles)
Bcols={1:[], -1:[]};Cvolts={}
for cyc in sorted(cycles):
 col=sp.zeros(15,1); v=1
 for k in range(5):
  a=cyc[k];b=cyc[(k+1)%5];e=tuple(sorted((a,b))); v*=signed[e]; col[Eindex[e],0]=1 if a<b else -1
 Bcols[int(v)].append(col); Cvolts[cyc]=int(v)
assert len(Bcols[1])==len(Bcols[-1])==6
Bp=sp.Matrix.hstack(*Bcols[1]); Bm=sp.Matrix.hstack(*Bcols[-1]); Hp=Bp*Bp.T;Hm=Bm*Bm.T;Pc=Pi3+Pi3s
check('EV0001_sum_H',Hp+Hm-10*Pc)
check('EV0001_product_H',Hp*Hm-20*Pc)
check('EV0001_sq_diff',(Hp-Hm)*(Hp-Hm)-20*Pc)
check('EV0001_Hplus_3_3prime', Hp-(5-rt)*Pi3-(5+rt)*Pi3s)
check('EV0001_Hminus_3_3prime', Hm-(5+rt)*Pi3-(5-rt)*Pi3s)
# Complementary pair of disjoint pentagons: one perfect matching connects them.
# For pairs, check signed flux norms and proportionality ratios at both 9f receivers.
phi2=ph*ph
complement_pairs=[]
for c,d in itertools.combinations(sorted(cycles),2):
 if not set(c)&set(d):
  # complementary voltagse opposite; K columns project to collinear vectors
  assert Cvolts[c]==-Cvolts[d]
  def col_cycle(c):
   col=sp.zeros(15,1)
   for k in range(5):
    a,b=c[k],c[(k+1)%5];e=tuple(sorted((a,b)))
    col[Eindex[e]]=1 if a<b else -1
   return col
  a,b=col_cycle(c),col_cycle(d)
  ga,gb=K*a,K*b;ra,rb=Ks*a,Ks*b
  # current source uses c_plus and c_minus orientation; magnitudes reciprocal
  plus,minus=(a,b) if Cvolts[c]>0 else (b,a)
  gp,gm=K*plus,K*minus; gsp,gsm=Ks*plus,Ks*minus
  # either Kc_minus /Kc_plus has phi, or reciprocal depending flux gauge label
  chk1=zero(cross(gp,gm))[0];chk2=zero(cross(gsp,gsm))[0]
  rat1=sp.simplify((gm.dot(gm))/(gp.dot(gp)));rat2=sp.simplify((gsm.dot(gsm))/(gsp.dot(gsp)))
  complement_pairs.append((chk1,chk2,rat1,rat2))
checks['EV0001_matching_flux_ratios']={'passed':len(complement_pairs)==6 and all(x[0] and x[1] for x in complement_pairs), 'pairs':len(complement_pairs),'ratio_values':sorted(set((str(a[2]),str(a[3])) for a in complement_pairs))}
# Q_v=(u_v u_v^T-I/3). edge vector flux k_e, Phi_e=(Q_v+Q_w) 97 k_e.
Q=[U[:,i]*U[:,i].T-sp.eye(3)/3 for i in range(10)]
# tensor symmetric tracefree basis with nonorthogonal components (11,22,12,13,23)
def sym_coords(X):return sp.Matrix([X[0,0],X[1,1],X[0,1],X[0,2],X[1,2]])
def symtrace(X,Y):return sp.trace(X*Y)
flux=[Q[i]+Q[j] for i,j in edges]
Gram=sp.Matrix(15,15,lambda a,b:symtrace(flux[a],flux[b])*(K[:,a].dot(K[:,b])))
# projectors Pi4, Pi5 from graph oriented boundary (chosen left/right indexing convention)
partial=sp.zeros(10,15)
for ix,(i,j) in enumerate(edges):partial[i,ix]=-1;partial[j,ix]=1
P=sp.Matrix(10,10,lambda i,j: 1 if not (set(labels[i])&set(labels[j])) and i!=j else 0)
D=sp.Matrix(10,5,lambda i,j:1 if j+1 in labels[i] else 0)
Pc0=D*(D.T*D).inv()*D.T;P4=Pc0-sp.ones(10)/10;P5=sp.eye(10)-Pc0
Pi4=partial.T*P4*partial/5;Pi5=partial.T*P5*partial/2
check('EV0006_Pi_resolution',Pi4+Pi5+Pi3+Pi3s-sp.eye(15))
check('EV0006_tens_Gram',Gram-2*Pi4/9-20*Pi5/9-4*Pi3/3-32*Pi3s/9)
# contracted output Q*k = -2k/3 for all 15 edges
check('EV0006_contraction',sp.Matrix.hstack(*[F*K[:,c] for c,F in enumerate(flux)])+2*K/3)

# Capture exact eigen spectrum from projector ranks independent of inherited label.
checks['EV0006_positive_eigenvalues']={'passed':all(checks[n]['passed'] for n in ('EV0006_Pi_resolution','EV0006_tens_Gram')), 'rank_Pis':[int(sp.simplify(sp.trace(m))) for m in [Pi4,Pi5,Pi3,Pi3s]],'gram_eigensystem':{'2/9':4,'20/9':5,'4/3':3,'32/9':3}}
checks['graph_cardinalities']={'passed':len(edges)==15 and len(cycles)==12,'vertices':10,'edges':15,'cycles_length5':len(cycles),'positive_voltage':len(Bcols[1]),'negative_voltage':len(Bcols[-1])}
# Distinct E3 computer certificate; not based on historic verifier artifacts.
fail=[k for k,v in checks.items() if not v['passed']]
out={'target':'Paper1B-ExceptionalGeometry-v1_10.tex','claim_ids':['p1:thm:petersen-pentagon-reciprocity','p1:prop:v371-petersen-quadrupole-flux'], 'method':'Exact SymPy Q(sqrt5) finite coordinates, exhaustive Petersen cycles; geometry only', 'checks':checks,'failed':fail,'script_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()}
fn=pathlib.Path(__file__).with_name('Paper1B-RigorousVerificationBatch2ExactResults-v1_1.json');fn.write_text(json.dumps(out,indent=2))
print(json.dumps({'failed':fail,'passed':len(checks)-len(fail),'counts':checks['graph_cardinalities'],'matching':checks['EV0001_matching_flux_ratios']},indent=2))
if fail: raise SystemExit(1)
