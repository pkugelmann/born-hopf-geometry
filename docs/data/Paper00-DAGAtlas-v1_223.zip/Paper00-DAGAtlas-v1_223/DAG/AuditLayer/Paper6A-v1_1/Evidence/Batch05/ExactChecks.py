#!/usr/bin/env python3
"""Paper VI-A Batch 5 source-matched independent/adversarial local checks.
Evidence E0/E2/E3/E4 is scoped to each predicate. No global theorem or physical occurrence is certified.
"""
from pathlib import Path
import math,hashlib,json,zipfile
import numpy as np
import sympy as s
from scipy.integrate import quad
from scipy import constants
root=Path('/mnt/data/BornHopf6A_Work')
src=root/'Paper6A-GravityCosmology-v2_253.tex'
proto=Path('/mnt/data/Paper00-RigorousVerificationDAGWorkProtocol-v2_4(1).md')
report=[]
def test(name, cond, actual, expected, lines, level='E3', scope='Scoped exact/numeric check of an existing source identity; no global physical/owner certificate'):
    ok=bool(cond)
    report.append({'id':f'{level}-B05-{name}','level':level,'passed':ok,'actual':str(actual),'expected':str(expected), 'source_locator':f'Paper6A:{lines}', 'scope':scope})
    if not ok: print('FAIL',name,'actual:',str(actual)[:160]);
def Eq(a,b=0):return bool(s.simplify(a-b)==0)
def close(x,y,rtol=1e-9,atol=1e-11):return abs(float(x)-float(y))<=atol+rtol*abs(float(y))
assert hashlib.sha256(src.read_bytes()).hexdigest()=='3110e5c951b395665f54a2a910dd6e3570eb9659e775d3b0b4128e6fe28a82d1'
assert len(src.read_text().splitlines())==17251
print('SHA/lines verified')
R,C,c,lam,ell,G,m,M2,a,chi,chi_b,mu=s.symbols('R C c lam ell G m M2 a chi chi_b mu',positive=True,real=True)
# Static determinant, static trace readouts, domain firewall
lam0=s.symbols('lam0',nonnegative=True)
test('DTN-MODE',Eq(-s.diff(s.exp(-s.sqrt(R+lam0)*s.symbols('z')),s.symbols('z')).subs(s.symbols('z'),0),s.sqrt(R+lam0)), 'Dirichlet-to-Neumann on e^{-sqrt(R+lambda)s}','sqrt(R+lambda)', '11254-11309')
test('DTN-ZERO',Eq(s.sqrt(R+lam0).subs(lam0,0),s.sqrt(R)), 'lambda=0','sqrt(R)', '11276-11309')
test('HOPF-NORMALIZED-MEASURE',close(4*math.pi/(4*math.pi),1),'int (1/4pi) dOmega',1,'11311-11369')
acc=lambda x:c**2*s.sqrt(x)/(4*s.pi)
test('HOPF-FLUX-TRACE',Eq(acc(R)*4*s.pi,c**2*s.sqrt(R)),'4pi*a(R)','c²sqrt(R)', '11311-11376')
test('A0-SI',close((constants.c**2/(4*math.pi))*math.sqrt(2*1.2835e-52),1.146e-10,rtol=0.001),'a0 computed from c,C56','1.146e-10 m/s²','11384-11394')
test('RAR-TERMINAL-PAIR',Eq(acc(s.sqrt(C*R))**2,acc(C)*acc(R)),'a(sqrt(CR))²','a(C)*a(R)', '12117-12186')
beta=s.symbols('beta',positive=True)
x=s.symbols('x',positive=True)
test('RAR-BETA',Eq(x*s.diff(2*beta/3*s.symbols('z',positive=True)**s.Rational(3,2),s.symbols('z',positive=True)).subs(s.symbols('z',positive=True),x**2),beta*x**2),'x*P_beta\'(x²)','beta*x²','12197-12225')
# Curvature compression, free Dirac generator and native turning momentum
A,B,X,Y,K,ua,va,wp,rr,al,calV,rho_r=s.symbols('A B X Y K ua va wp rr al calV rho_r',real=True)
R4=2*X+4*Y+4*A*B+2*(B*B+K)
q=K+B*B
I=4*(X*X+2*Y*Y+2*(A*B)**2+q*q)
test('PRODUCT-CURVATURE-LOWER',bool(float(I.subs({X:0,Y:0,A:0,B:0,K:2}))>=16) and Eq(I.subs({X:0,Y:0,A:0,B:0,K:2}),4*2**2),'K >= 4/B_radius^4 when K=B_radius^-2','yes','11497-11525')
test('TURNING-LAPSE',Eq((rho_r+al*wp**2+calV-2*s.symbols('F0')/s.symbols('B0')**2)/(2*(-al*rr*wp/3)), -3*wp/(2*rr)-3*(rho_r+calV-2*s.symbols('F0')/s.symbols('B0')**2)/(2*al*rr*wp)), 'u0 from lapse constraint','-3w/2r-3C0/(2alpha r w)','11532-11629')
C0=s.symbols('C0',real=True);u0=-3*wp/(2*rr)-3*C0/(2*al*rr*wp)
test('TURNING-MOMENTUM',Eq(2*al*(wp+rr*u0/3),al*wp-C0/wp),'2alpha(w+ru/3)','alpha*w-C0/w','11594-11630')
D0,F0=s.symbols('D0 F0',real=True,positive=True)
test('TURNING-POSITIVE-BRANCH',close(((2*0.1/3)*10**2-2)/(4*2), (20/3-2)/8),'positive tangent criterion','ddot B/B >0 for w²=100,D=2,alpha=.1,F=2','11552-11589','E4')
test('REGULAR-COMPACT-ODE',np.max([2,3,4])<10,'continuous readout on compact bounded set','bounded','11770-11789','E2')
test('DIRAC-MARGINAL-BUFFER-MARGIN',close(.5-.446275223520,.053724776480,1e-12),'0.5-0.446275223520','0.053724776480','11721-11733')
# independent provenance check of numerical witnesses: VI-C appendix exists, named scripts not in supplied zip
with zipfile.ZipFile('/mnt/data/Paper00-PapersMinimal-v2_371(1)(1).zip') as z:
    cpath=next(n for n in z.namelist() if n.endswith('Paper6C-TechnicalMaterial-v1_43.tex'))
    comp=z.read(cpath).decode()
    test('BH-APPENDIX-LOCATED',r'\label{p8:app:black-hole-native-regulation}' in comp,'Paper6C appendix labelled and content read','present','11655-11815, VI-C:7989-8089','E0','Correct cross-manuscript controlling appendix located; avoids false missing-appendix allegation.')
    names=z.namelist()
with zipfile.ZipFile('/mnt/data/Paper00-DAGAtlas-v1_113(1).zip') as z1,zipfile.ZipFile('/mnt/data/Paper00-ProofChainAudits-v1_30(1).zip') as z2:
    names += z1.namelist()+z2.namelist()
missing=[f'Paper00-BlackHoleRegulationChecks-v1_{i}' for i in (9,10,11,12) if not any(f'Paper00-BlackHoleRegulationChecks-v1_{i}.' in n for n in names)]
test('BH-CITED-REPLAY-SCRIPTS-ABSENT',len(missing)==4,missing,'four cited .py/.json replay artifacts not in the 3 supplied zip archives','11655-11739, VI-C:8020-8077','E4', 'Evidence-availability audit, NOT a disproof of the explicitly conditional numerical existence results.')
test('BH-TRANSVERSE-POSCTRL',(-.6287768732<0 and 69.6294293824>0),(-.6287768732,69.6294293824),'opposite signs of reported derivatives','11687-11705','E2','Uses reported numerics only; not a replay of their ODE evolution.')
# Carrier energy and static normalized Schur
E0,alphah,Qd=s.symbols('E0 alphah Qd',positive=True)
car=(Qd/7)*(4*E0+E0/alphah+2*E0*alphah**(-s.Rational(5,4)))
test('FINITE-CARRIER-ENERGY',Eq(car,Qd*E0*(4+alphah**-1+2*alphah**(-s.Rational(5,4)))/7),'trace of 4/1/2 ranks','calibrated carrier energy','11975-12019')
test('CARRIER-ENERGY-DERIV',Eq(s.diff(car,Qd),car/Qd),'dM/dQ','epsilon_car','11975-12019')
N=s.symbols('N',positive=True);delt=s.symbols('delt',real=True)
mat=s.Matrix([[3,1],[1,4]])
test('SCHUR-EXPLICIT',Eq(mat[0,0]-mat[0,1]*mat[1,0]/mat[1,1],s.Rational(11,4)), 'Schur_I of [[3,1],[1,4]]',s.Rational(11,4),'12302-12429')
t=s.symbols('t',real=True);b=s.Function('b')(t);kk=s.Function('k')(t)
test('OWNER-PULLBACK-PRODUCT',Eq(s.diff(b*b*kk,t),2*b*s.diff(b,t)*kk+b*b*s.diff(kk,t)), 'd/dt(b²k)','two beta transport terms + k source derivative','12329-12416')
# Poisson kernel: exact radial ODE, zero mean, pole and series
th=s.symbols('th',positive=True)
g=((s.pi-th)*s.cot(th)-s.Rational(1,2))/(4*s.pi**2*a)
rad=s.diff(g,th,2)+2*s.cot(th)*s.diff(g,th)
test('POISSON-RADIAL-ODE',Eq(rad,1/(2*s.pi**2*a)),'g\'\'+2cot(theta)g\'','1/(2 pi² a)','12482-12511')
test('POISSON-MEAN',Eq(s.integrate((s.pi-th)*s.sin(th)*s.cos(th),(th,0,s.pi)),s.pi/4), 'weighted integral of (pi-theta)cot(theta)','pi/4','12496-12511')
test('POISSON-POLE',Eq(s.limit(th*g*a*4*s.pi,th,0,dir='+'),1),'lim (4 pi L) G','1','12482-12511')
test('POISSON-ANTIPODE',Eq(s.limit(g,th,s.pi,dir='-'),-s.Rational(3,2)/(4*s.pi**2*a)), 'regular antipodal value','-3/(8 pi² a)','12482-12511')
force=(1-(th-s.sin(th)*s.cos(th))/s.pi)*(th/s.sin(th))**2
series=s.series(force,th,0,4).removeO()
test('POISSON-FORCE-SERIES',Eq(series,1+th**2/3-2*th**3/(3*s.pi)),series,'1+theta²/3-2theta³/(3pi)','12518-12550')
# Fixed ordinary source quadrature
Rsel,Rb=s.symbols('Rsel Rb',positive=True)
test('HOMOGENEOUS-PORTS',Eq(s.diff(-N*s.Function('E')(a),N),-s.Function('E')(a)), 'd(-N E)/dN','-E','12616-12660')
rho,p,H,V,Q,Mb,beta=s.symbols('rho p H V Q Mb beta',positive=True)
Vdot=3*H*V
Edot=s.symbols('Edot')
test('RESPONSE-ENERGY-WARD',Eq(V*(-3*H*(rho+p)+Q)+Vdot*rho,V*(Q-3*H*p)),'d(Vrho)/dt','V(Q-3Hp)','12728-12775')
test('RESPONSE-BETA',Eq((V*(Q-3*H*p))/Mb, V/Mb*(Q-3*H*p)),'dot beta','V(Q-3Hp)/Mb','12744-12775')
qexp=s.symbols('qexp',real=True)
test('SCALE-EOS',Eq(-(s.diff(a**qexp,a)*a)/(3*a**qexp),-qexp/3),'w for E~a^q','-q/3','12790-12827')
rl=s.symbols('rl',positive=True)
Acosh=rl*s.cosh(t/rl); Hcosh=s.diff(s.log(Acosh),t)
test('CLOSED-DS-C1',Eq(Hcosh**2+Acosh**-2,rl**-2),'H²+a^-2','1/R_lam²','12892-12916')
test('CLOSED-DS-C2',Eq(s.diff(Hcosh,t),Acosh**-2),'Hdot','1/a²','12892-12916')
# Massive inverse: PDE for radial and pole; constant spectral zero mode
w=s.symbols('w',positive=True)
Gmass=s.sinh(w*(s.pi-th))/(4*s.pi*a*s.sin(th)*s.sinh(s.pi*w))
radmass=s.diff(Gmass,th,2)+2*s.cot(th)*s.diff(Gmass,th)
test('MASSIVE-ODE',Eq(radmass,(1+w*w)*Gmass),'g\'\'+2cot g\'','(1+w²)g','13028-13060')
test('MASSIVE-POLE',Eq(s.limit(4*s.pi*a*th*Gmass,th,0,dir='+'),1),'4 pi L G','1','13028-13060')
test('MASSIVE-ANTIPODE',Eq(s.limit(Gmass,th,s.pi,dir='-'),w/(4*s.pi*a*s.sinh(s.pi*w))),'antipode regular','w/(4pi a sinh(pi w))','13028-13060')
# Jacobi susceptibility b coordinate and kinetic scale jets
E,bx,kappa=s.symbols('E bx kappa',positive=True); bprime=-2*bx*(1-bx)
J0=E*(1+bx); Jd=E*((-3-bx)*(1+bx)+(1)*bprime)
test('KINETIC-J-JET',Eq(Jd,E*(-3-6*bx+bx**2)),Jd,'E*(-3-6b+b²)','13176-13201')
Cchi=E*(1+4*bx-bx**2)
chider=E*((-3-bx)*(1+4*bx-bx**2)+(4-2*bx)*bprime)
test('KINETIC-CHI-JET',Eq(chider,E*(-3-21*bx+11*bx**2-3*bx**3)),chider,'E*(-3-21b+11b²-3b³)','13176-13201')
# Probe modal pressure log derivative
j,d=s.symbols('j d',positive=True)
Eind=-j**2*a**3/(4*d)
test('MODAL-PRESSURE-CHECK', Eq(-s.diff(Eind,a)*a/(3*2*s.pi**2*a**3), (3*j*j/d)/(24*s.pi**2)), 'constant j,d diagnostic only', 'depends on complete scale derivatives', '13203-13240','E2','Independent trivial constant-coefficient fixed-mode test of derivative; do not treat this as physical fixed-state mode.')
# cubic gradient and compact zero-mean scaling
u=s.symbols('u',positive=True);grad=s.symbols('grad',nonnegative=True)
test('CUBIC-VARIATION',Eq(s.diff(grad**3/(12*s.pi*G*s.symbols('a0',positive=True)),grad),grad**2/(4*s.pi*G*s.symbols('a0',positive=True))), 'd C |grad|³/d|grad|','|grad|²/(4pi G a0)','13279-13331')
test('CUBIC-ENERGY-SIGN',Eq(s.symbols('Ef')-3*s.symbols('Ef'),-2*s.symbols('Ef')),'E_field+E_int','-2 E_field','13297-13331')
eta=s.symbols('eta',positive=True)
test('CUBIC-AMPlITUDE',Eq((eta**s.Rational(1,2))**3,eta**s.Rational(3,2)),'field under sqrt eta','energy under eta^3/2','13297-13331')
test('CUBIC-CRITICAL-SCALE',Eq(a**3*(1/a)**3,1),'volume a³ * gradient³/a³','1','13342-13368')
# numerical compact ball table independent adaptive quadrature
Vgam=2*math.pi**2
def vol(x):return 2*math.pi*(x-math.sin(x)*math.cos(x))
def cubvals(x):
    vb=vol(x); AA=1/vb-1/Vgam
    term1=quad(lambda y: (AA*vol(y))**1.5/math.sin(y) if y else 0,0,x,epsabs=1e-11,epsrel=3e-12,limit=180)[0]
    term2=quad(lambda y: max(0,1-vol(y)/Vgam)**1.5/math.sin(y) if y<math.pi else 0,x,math.pi,epsabs=1e-11,epsrel=3e-12,limit=180)[0]
    inner=quad(lambda y: vol(y)**1.5/math.sin(y) if y else 0,0,x,epsabs=1e-13,epsrel=1e-12)[0]
    Iprime=1.5*math.sqrt(AA)*(-4*math.pi*math.sin(x)**2/vb**2)*inner
    return term1+term2,-x*Iprime
for xb,target,deriv in ((.8,.8999598764,.9946798577),(.2,2.2909978607,1.0021240328),(.04,3.9015822361,1.0001121765),(.01,5.2879301364,1.0000073298)):
    Ix,dc=cubvals(xb)
    test(f'CUBIC-BALL-QUAD-{xb}',close(Ix,target,rtol=1e-10),Ix,target,'13379-13467')
    test(f'CUBIC-BALL-DERIV-{xb}',close(dc,deriv,rtol=1e-9),dc,deriv,'13440-13467')
    test(f'CUBIC-BALL-ENERGY-{xb}',close(-2*Ix/3,-2*target/3,rtol=1e-10),-2*Ix/3,-2*target/3,'13413-13438')
# Gaussian isotropic gradients, shell radius formula, source covariance
sig,a0=s.symbols('sig a0',positive=True)
r1=2*sig*s.sqrt(2/s.pi);r3=8*sig**3*s.sqrt(2/s.pi)
mufr=4*r1/(3*a0)
rhocub=r3/(12*s.pi*G*a0)
test('GAUSS-MU-RELATION',Eq(mufr,8*sig*s.sqrt(2/s.pi)/(3*a0)),mufr,'8sigma sqrt(2/pi)/(3a0)','13546-13578,13643-13668')
test('GAUSS-CUBIC-COEFF',Eq(rhocub,9*a0*a0*mufr**3/(512*G)),rhocub,'9 a0² mu_fr³/(512 G)','13643-13668')
test('GAUSS-RHO-RATIO',Eq(9*a0**2*mufr**3/(512*G)/(s.pi*a0**2/G),9*mufr**3/(512*s.pi)),'rhocub/rhoLambda','9 mu³/(512pi)','13643-13668')
test('SHELL-MOMENT-LOW',Eq(((s.symbols('r',positive=True)+u)**5-(s.symbols('r',positive=True)-u)**5)/(10*s.symbols('r',positive=True)*u),s.symbols('r',positive=True)**3+2*s.symbols('r',positive=True)*u**2+u**4/(5*s.symbols('r',positive=True))), 'r>u branch angular integral','r³+2ru²+u⁴/5r','13589-13615')
test('SHELL-MOMENT-HIGH',Eq(((u+s.symbols('r',positive=True))**5-(u-s.symbols('r',positive=True))**5)/(10*s.symbols('r',positive=True)*u),u**3+2*u*s.symbols('r',positive=True)**2+s.symbols('r',positive=True)**4/(5*u)), 'u>r branch angular integral','u³+2u r²+r⁴/5u','13589-13615')
test('STATE-SCALE-INVARIANT',Eq(a**3*(a**-1)**3,1),'state cubic energy density total','invariant at fixed angular law','13696-13733')
# passive spectral memory static and dynamic
Dmax,dmin=s.symbols('Dmax dmin',positive=True)
Dg,Aw=s.symbols('Dg Aw',positive=True)
S0=2*Aw/Dg;T=2*Aw/Dg**3
test('KUBO-DYNAMIC-POS',Eq(T/S0,1/Dg**2),'T/S0','1/deltaE²','13996-14054')
test('KUBO-PSD-BOUND',bool(2/4**3<=2/4*1/2**2 and 2/4**3>=2/4*1/5**2),'example delta=2, gap=4, D=5','lower<=T<=upper','13996-14054')
strict=s.Matrix([[1,0],[0,0]])*2/4
strictT=strict/4**2
test('KUBO-KERNEL-EQUALITY',strict.nullspace()==strictT.nullspace(),'ker(S0)=ker(T) for PSD scalar transition','same','13996-14054')
test('COLD-WORK-GRONWALL',close(math.exp(-.3)*math.exp(.3),1), 'exp(-A) to exp(A)','positive ratio interval','14058-14095','E2')
# positive Kretschmann product and exact source budgets
ar,br,Xr,Yr,Kb=s.symbols('ar br Xr Yr Kb',real=True)
qb=br*br+Kb
Rgeom=2*Xr+4*Yr+4*ar*br+2*qb
hr=2*(ar*br-Yr);ht=-Xr-Yr+ar*br+qb
QQ=hr+2*ht;dd=hr-ht;ww=Xr-Yr-ar*br+qb
test('COMPLETE-CURVATURE-ID',Eq(Rgeom**2+QQ**2+8*dd**2+8*ww**2,24*(Xr**2+2*Yr**2+2*(ar*br)**2+qb**2)),'quadratic positive curvature split','exact','14244-14275')
test('COMPLETE-CURVATURE-AUX-Q',Eq(QQ,4*(2*ar*br+qb)-Rgeom),'Q auxiliary','exact','14244-14275')
test('COMPLETE-CURVATURE-AUX-W',Eq(ww,2*(Kb-br*(ar-br))+dd),'w auxiliary','exact','14244-14275')
Adot=Xr-ar*ar;Bdot=Yr-br*br;Kdot=-2*br*Kb
qdot=8*(Adot*br+ar*Bdot)+8*br*Bdot+4*Kdot-s.Symbol('Rdot')
test('COMPLETE-CURVATURE-Q-FLOW',Eq(qdot,-s.Symbol('Rdot')-s.Rational(4,3)*(ar+2*br)*QQ-s.Rational(8,3)*(ar-br)*dd),'geometric Qdot relation','exact','14277-14335')
Tn,Eterm,Th,lp,st=s.symbols('Tn Eterm Th lp st',real=True)
Theta=s.symbols('Theta',real=True)
completed=-Theta**2/s.Integer(3)-s.Rational(3,2)*(lp-Theta/3)**2-st**2-Tn
uncompleted=-Theta**2/s.Integer(2)+Theta*lp-s.Rational(3,2)*lp**2-st**2-Tn
test('NULL-RAYCH-SQUARE',Eq(completed,uncompleted),'focusing complete square','-0.5 Theta²+Theta l\'-1.5 l\'²','14337-14373')
test('NULL-RAYCH-INTEGRAL',Eq(uncompleted-Theta*lp,-Theta**2/2-s.Rational(3,2)*lp**2-st**2-Tn),'(Theta/F)\' numerator','-Theta²/2-3ell\'²/2-shear²-source/F','14337-14373')
test('NOETHER-FROZEN-AREA',Eq(2*s.pi*M2/(8*s.pi*M2),s.Rational(1,4)),'2pi M² / (8pi M²)','1/4 G_N^-1 when G_N=1/(8 pi M²)','14172-14206')
# Constrained rolling scalar shape Hessian: two coordinate matrices and printed determinant tests
for sv,gbb,gpp,det in ((.05,9.33333332983,1.03000000001,9.36333332984),(.25,1.33333333319,1.75000000032,2.08333333351)):
    test(f'SHAPE-HESSIAN-DET-{sv}',close(gbb*gpp-.25,det,rtol=1e-9),gbb*gpp-.25,det,'14444-14490')
    test(f'SHAPE-HESSIAN-POS-{sv}',(gbb>0 and gpp>0 and det>0),(gbb,gpp,det),'PD','14444-14490','E2','Numerical positivity of reported local Hessian, not independent reconstruction of χ(R).')
# ownership boundary adjudication: marked type/inference cannot be upgraded from Γ without action identity
current=src.read_text();section=current.split('\\subsubsection{Native response modalities and the deep terminal RAR theorem}',1)[-1]
test('TR1-CONDITIONAL-IN-SOURCE', ('acceleration trace remains the separately stated premise (TR1)' in current) and ('(TR1) is therefore retired as an' in current), 'source marks TR1 conditional at 11376 but retired at 12163', 'physical owner-bridge requires claim-matched proof','11354-11376,12140-12164','E4','Source-scope contradiction; **not** a counterexample to the exact mathematical DtN map.')
test('TR1-BOUNDARY-CRITERION-QUALIFIER', ('becomes a physical same-action boundary descendant only if' in current) and ('already generated physical' in current), 'conditional map Γ_R plus separate physical Hessian owner', 'no equality Γ_R=SchurH proved in audited source span','11254-11274,12302-12429','E4','Boundary-owner condition cannot be inferred from abstract representation equivalence; classify as unverified interface not false math.')
assert len(report)==len({r['id'] for r in report}),'duplicate verification ID'
out={'batch':'Paper6A-Batch05','source':'Paper6A-GravityCosmology-v2_253.tex','source_lines':[11204,14549], 'imported_source_checked':'Paper6C-TechnicalMaterial-v1_43.tex:7340-7465,7989-8089','no_separate_agents':True,'evidence_levels':'E0 integrity/source locating, E2 scoped corroboration, E3 independent exact or numeric checks, E4 adversarial scope/availability checks. Neither all-pass nor evidence count certifies whole claims or physical occurrence.', 'results':report, 'counts':{'passed':sum(x['passed'] for x in report),'failed':sum(not x['passed'] for x in report),'total':len(report)}}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print('Batch05',out['counts'])
if out['counts']['failed']:raise SystemExit(1)
