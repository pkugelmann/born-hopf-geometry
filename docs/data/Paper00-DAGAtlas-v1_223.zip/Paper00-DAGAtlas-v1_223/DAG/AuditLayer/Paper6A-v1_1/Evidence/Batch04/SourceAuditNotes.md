# Paper VI-A — RigorousVerificationDAG correctness audit, Batch 04 (source-first)

**Audit file:** `Paper6A-RigorousAuditBatch04-v1_4.md`  
**Target:** `Paper6A-GravityCosmology-v2_253.tex`  
**Authoritative source:** `Paper00-PapersMinimal-v2_371(1)(1).zip`  
**Verification protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4(1).md`  
**Current target SHA256:** `3110e5c951b395665f54a2a910dd6e3570eb9659e775d3b0b4128e6fe28a82d1`  
**Batched line range:** 9,031–11,203 inclusive; next input line **11,204**.  
**Completed local passes:** source/claim inventory, E1 line-by-line source proof replay, independent algebra/numerics E2/E3 controls, E4 source-domain adversarial checks, issue adjudication, typed DAG/condition and archive-provenance checkpoint. **No separate agents available**; no independent-agent credit claimed.

## 1. Executive coverage and proof-status ledger

| Audit metric | Batch 4 | Cumulative |
|---|---:|---:|
| Source text covered | 2,173 lines | 11,203 / 17,251 (64.94%) |
| Source-named formal objects reviewed | 71 | 249 / 357 |
| Formal objects not yet audited | — | 108 |
| Source-linked E2/E3/E4 local control predicates | 70 passed / 70 | 234 passed / 234 |
| Confirmed new local source issues | 2 (1 moderate, 1 minor) | 12 open (8 moderate, 4 minor) |
| First-known conditional-guard nodes | 2 inferred | 15 local nodes |
| Typed source-bound dependency records | 53 new | 137 checkpoint records |

Cumulative dispositions: **FORMALIZED=97, REPRODUCED=73, VERIFIED-CONDITIONAL=74, UNRESOLVED=5**. A `VERIFIED-CONDITIONAL` disposition certifies only the indicated local theorem branch with its premises; `REPRODUCED` records a source proof replay; `FORMALIZED` records scope and proof role rather than an independent full theorem certificate. `UNRESOLVED` denotes a challenged substatement, and its valid subclauses are explicitly preserved. No unexamined object is labeled `VERIFIED`.

The source is not modified. Baseline ProofChainAudits/DAGAtlas ZIPs remain untouched: release of their **latest-version-only** updated successors is intentionally deferred until the final paper batch.

## 2. New findings — source-anchored proof obligations

### BH-VIA-G-0011 — INCORRECT_STEP / TYPE_OR_DOMAIN (moderate)
**First-source span:** `Paper6A-GravityCosmology-v2_253.tex:11083–11108`; root `p8:sec:tensor-frame-ledger`. **Disposition:** OPEN / UNRESOLVED.

**Source-matched challenged transition.** From a_E=sqrt(F)a_J and dt_E=sqrt(F)dt_J the source prints H_E dt_E=H_J dt_J for F=f_R>0. The exact logarithmic derivative is H_E dt_E=H_J dt_J+(1/2)d ln F, with no source assumption dF=0 on the time-dependent frame branch.

**E4 in-domain witness.** Let F(t_J)=exp(2 b t_J)>0, a_J(t_J)=exp(h t_J) with b!=0. Then H_E dt_E=(h+b)dt_J, while H_J dt_J=h dt_J; difference b dt_J.

**Positive control and safe boundary.** For constant F the source Hubble identity holds. Independently, P_h^E=P_h^J and A_L^J=sqrt(F) A_L^E are confirmed.

**Valid unaffected consequences:** Canonical tensor momenta P_h^E=P_h^J; The tensor frame generator A_L^J=sqrt(F)A_L^E; Frame-related mass identity m_E=m_J/sqrt(F); The tensor covariance transport when treated via the correct generator and clock.

**Exact evidence:** `E4-B04-HUBBLE-CONFORMAL-COUNTEREXAMPLE`, `E3-B04-HUBBLE-CONFORMAL-SYMBOLIC`, `E3-B04-HUBBLE-CONFORMAL-POSCTRL`, `E3-B04-TENSOR-FRAME-MOMENTUM`, `E3-B04-TENSOR-FRAME-GENERATOR`. **Condition node:** `BH-VIA-A-0014`.

**Resolution obligation (audit only; no repair):** Correct or branch-qualify the conformal Hubble identity in a subsequent source revision; keep other correct frame transformations intact.

**Impact route:** local target use `p8:sec:tensor-frame-ledger (Hubble one-form identity only)`. No certified cross-paper consequence follows; No claim of tensor-oscillator or phenomenological error from this isolated identity; no source edit performed.

### BH-VIA-G-0012 — INCORRECT_STEP / MISSING_CONDITION (minor)
**First-source span:** `Paper6A-GravityCosmology-v2_253.tex:9851–9884`; root `p8:prop:shell-algebra-nonterminal-rar`. **Disposition:** OPEN / UNRESOLVED.

**Source-matched challenged transition.** The full stated spectrum of the normalized T=A_+/8 contains invariant eigenvalue 1 with multiplicity 1, yet the ensuing unqualified ``can contain only list of nonzero n-step factors omits 1^n; T^n 1=1.

**E4 in-domain witness.** Construct all 24 normalized Hurwitz vertices (8 coordinate basis signs and 16 half-sign vertices), connect nearest neighbours by inner product 1/2, and normalize the adjacency A_+/8. The all-ones eigenvector survives every n>=1 and the exact spectrum has 1 with multiplicity 1.

**Positive control and safe boundary.** On the nontrivial mean-zero shell subspace, listed nonzero factors 2^-n,(-1/4)^n,(-1/2)^n are exhaustive; T^n E_2=0 for the nine-dimensional zero sector, n>=1.

**Valid unaffected consequences:** Full normalized walk spectrum and multiplicities as printed; Nine-dimensional null-channel result T^n E_2=0; Nontrivial mean-zero n-step channel factor list; Conditional shell projection is not a whole-galaxy rotation-curve fit.

**Exact evidence:** `E4-B04-HURWITZ-CONSTANT-WITNESS`, `E4-B04-HURWITZ-OMITTED-CONSTANT`, `E3-B04-HURWITZ-GEOMETRIC-EIGENSPECTRUM`, `E3-B04-HURWITZ-ZERO-SECTOR`, `E3-B04-HURWITZ-POSCTRL-MEAN-ZERO`. **Condition node:** `BH-VIA-A-0015`.

**Resolution obligation (audit only; no repair):** Include the invariant 1^n channel or make the mean-zero/orthogonal-to-constant restriction explicit in the original proposition.

**Impact route:** local target use `p8:prop:shell-algebra-nonterminal-rar (only the exhaustive nonzero factor list)`. No certified cross-paper consequence follows; The 24-cell geometry, positive eigenspectrum, and nine-dimensional null-channel conclusion are independently confirmed, not rejected.

## 3. Explicit evidence summary, theorem boundaries and retained negative results

### K8–K16 reheating and retained scalaron, source 9,031–9,300
- Replayed the finite Cayley response law `rho_reh=(16-K)/8`, `eta_reh=(K-8)/(24-K)` and `Q_partial=I_16 (1+eta)^2 dot K / 16`; endpoint transfer integrates to `I_16` on the specified K8-to-K16 cell. The primary owner equation `I_16=C_1²=U C_2=E_16^4` passes local algebra controls. These are precise mathematical identities under the declared cell, not evidence that the event happened physically.
- `Xi_{8→16}` bounds and radiation thermal readouts are source-conditioned on the retained scalaron, the visible heat degree count and the allocated energy fraction. The independently recalculated printed illustrative temperature and stationary Hubble diagnostic are numerical consequences of those inputs, not same-action proof of instantaneous thermalization or a universal reheating temperature.
- Retained scalaron Schur split: local differentiation checks the source `dar F/ds=1/(3m_s²)`, the exact slow/oscillatory decomposition and the explicitly bounded source jet. The B2C exclusion is checked only against the source-declared physical post16 selection; we do not restore that discarded branch by mechanism substitution.

### K16 particle ownership, post-K24 response and K32 native length, 9,301–9,783
- `p8:thm:v2136-k16-direct-particle-owner` is the **later controlling** direct-owner assertion for the one-step immediate successor cell. The earlier `p8:rem:v2135-k16-status` had an open PB16 owner frontier, but `p8:rem:v2136-supersede-v2135-owner-frontier` explicitly supersedes it. This is a source lifecycle update, not two contradictory simultaneously-live statuses. The imported Paper II-A and III-F supports were checked for the cited labeled statements at their current source loci, not re-certified as whole papers.
- The source differentiates the **structural PB16 owner** from **complete numerical/physical stress** requiring the D19 complete-action jets; the latter remains conditional. It also excludes inference that the initial retained neutral six-dimensional block is a directly created pair sector.
- The charge-two neutral K16–K24 response and baryogenesis hypotheses remain separately typed: endpoint transport is not proof of a produced baryon asymmetry. The native K32 curvature length is `L_32=α²/sqrt(U)` with SI comparison approximately one metre; the metre match is validation/metrology, not an extra scale-free geometric axiom.

### Scalaron core, 24-cell RAR channel and Born continuation, 9,784–10,104
- The source-selected Hurwitz 24-cell normalized nearest-neighbour adjacency has complete spectrum `(1,1/2,0,-1/4,-1/2)` with multiplicities `(1,4,9,8,2)` and exact nine-dimensional one-step null channel. These checks were independently recomputed from the actual 24-vertex D4 geometry, not assumed from the printed eigenvalue list.
- **G-0012** is strictly the omission of the invariant `1^n` from an apparently exhaustive list of nonzero factors; the three printed values are sufficient only for the nontrivial mean-zero sector. The root shell projection itself and the paper’s explicit warning not to equate this finite shell constraint with a galaxy rotation curve are preserved.
- On the fixed product leaf `XY=C`, the paper’s `star_C` group is isomorphic to one-dimensional addition in the log imbalance coordinate; a continuous endomorphism semigroup is exponential in that coordinate. Local group and composition checks pass. The *physical realization* of this continuation is explicitly conditional; the O(W) no-unmarked-equivariant-linear-functional statement passes its elementary algebraic test.

### Environment-conditioned RAR and K48 H-owned terminal hierarchy, 10,105–10,748
- Reproduced source-local environment parametrization, one-variable universality counterargument, Schur response normalization and the running-mass derivative. The local well is a conditional residence certificate: no claim that a galaxy meets its inequalities is inferred.
- **Important current-source precedence:** later `p8:thm:v2142-k48-zero-order-schur-exhaustion` and `p8:cor:v2142-k48-gamma-unit` set the H-owned endpoint `gamma_48=1` on the stated K48 Schur branch. The later `p8:thm:v2145-k48-dust-constructor-nogo` explicitly reports **no native exact conserved dust first integral in the current grammar**. An older proposed same-owner `a^-3` continuation is *not* upgraded to an unconditionally realized dark-matter sector. Endpoint normalization and true physical dust continuation are different observables.
- The first-order homogeneous boundary propagator and closed S³ spatial constraint `d_n=(n−1)(n+3)>0` with the source’s retarded Green kernel satisfy local coefficient checks. Source-defined collisionless kinetic response and causal sectorial square root have sign/functional-domain prerequisites; those operators were not independently solved across the physical environmental class.

### Finite parity, cyclic scalar/tensor covariance and same-history TT/Dirac source, 10,749–11,203
- Checked the complementarity of the protected projectors, the `tanh` form of the helicity amplitude ratio, and the state-conditioned zero-transfer case. Nonzero geometric orientation alone is **not** claimed to generate parity asymmetry without a state/source witness. Imported finite free vacuum covariance and protected projector statements are source-matched.
- The covariance equation and symplectic Wronskian/projection rank trace fractions pass local controls: exact complete-shell cyclic factors are `(rank on E_k)/(k+1)²`. The paper explicitly rejects assigning independent observed-sky fractions to unmarked exceptional subspace dimensions. No CMB sky fit is certified.
- The native tensor-frame kinetic generator and canonical momentum preserve their expected Jordan/Einstein relations under conformal rescaling. **G-0011** concerns only the separate unqualified `H_Edt_E=H_Jdt_J` identity; it does not invalidate the correctly verified tensor-generator relation. The same-history Dirac/TT source inheritance remains conditional on the fully specified source terms and boundary restrictions.

### E4 negative controls / rejected challenges
- The D4/Hurwitz constant vector is a **within-source-domain** adversarial case: it is a genuine eigenchannel of the displayed normalized walk; the mean-zero projection is a positive control. Neither changes the correct nine-dimensional zero sector.
- The conformal factor `F=e^{2 b t_J}` is permitted by the paper’s time-dependent `F>0` frame grammar; it makes the Hubble one-form difference nonzero, whereas constant F is a positive control. A redefinition of the Dirac half density does not justify the equality for `H=d(ln a)/dt` without an explicit distinct definition.
- **Rejected false escalation:** v2.135 PB16 `OPEN` and older K48 `a^-3` tentative statements are superseded/retyped by later source results, not additional simultaneously-open mathematical proof gaps. A mathematically derived gamma endpoint alone never implies a kinetic dust realization.

### Exact-control list and scoped interpretation

Each listed E2/E3/E4 predicate in the executable script returned the expected result; passing an **adversarial** predicate is affirmative evidence for a defect, *not* verification of the attacked theorem. Primary controls are source-matched local identities; imported global same-action routes and physical occurrence were not re-executed. The evidence file gives, for each predicate, the exact source locator and actual/expected values.

| Evidence ID | Level | Source line(s) | Outcome |
|---|---|---|---|
| `E3-B04-REH-CAYLEY` | E3 | `6A:9064-9079` | PASS: expected witness/control |
| `E3-B04-REH-ENDPOINTS` | E3 | `6A:9069-9088` | PASS: expected witness/control |
| `E3-B04-REH-RESIDUAL-ENDPOINTS` | E3 | `6A:9064-9073` | PASS: expected witness/control |
| `E3-B04-REH-DERIVATIVE` | E3 | `6A:9074-9085` | PASS: expected witness/control |
| `E3-B04-REH-CELL-FLUX` | E3 | `6A:9081-9088` | PASS: expected witness/control |
| `E3-B04-REH-OWNER-C1` | E3 | `6A:9045-9062` | PASS: expected witness/control |
| `E3-B04-REH-OWNER-SCALE` | E3 | `6A:9045-9062` | PASS: expected witness/control |
| `E3-B04-REH-CONDITIONED-CAYLEY` | E3 | `6A:9592-9623` | PASS: expected witness/control |
| `E3-B04-REH-CONDITIONED-ENDPOINT` | E3 | `6A:9592-9623` | PASS: expected witness/control |
| `E3-B04-REH-CONDITIONED-DERIV` | E3 | `6A:9625-9641` | PASS: expected witness/control |
| `E3-B04-REH-CAYLEY-COMPOSE` | E3 | `6A:9625-9640` | PASS: expected witness/control |
| `E2-B04-K24-CANDIDATE-ENDPOINTS` | E2 | `6A:9280-9297` | PASS: expected witness/control |
| `E3-B04-REH-TEMP-SI` | E3 | `6A:9242-9260,3308` | PASS: expected witness/control |
| `E3-B04-REH-HUBBLE-BOUND-SI` | E3 | `6A:9221-9240,3059-3069` | PASS: expected witness/control |
| `E3-B04-REH-KINETIC-THRESHOLD` | E3 | `6A:9242-9265` | PASS: expected witness/control |
| `E2-B04-REH-XI-UPPER-BOUND` | E2 | `6A:9093-9112` | PASS: expected witness/control |
| `E3-B04-K32-CURVATURE-LENGTH` | E3 | `6A:9700-9722` | PASS: expected witness/control |
| `E3-B04-K32-UNIT-SCALE` | E3 | `6A:9700-9722` | PASS: expected witness/control |
| `E3-B04-K32-METROLOGY` | E3 | `6A:9724-9732` | PASS: expected witness/control |
| `E3-B04-SCALARON-BPRIME` | E3 | `6A:9114-9159,3942-3955` | PASS: expected witness/control |
| `E3-B04-SCALARON-SLOW-DS` | E3 | `6A:9162-9187` | PASS: expected witness/control |
| `E3-B04-SCALARON-B2C-NEGATIVE` | E3 | `6A:9114-9159` | PASS: expected witness/control |
| `E3-B04-SCALARON-B-BOUND` | E3 | `6A:9129-9150` | PASS: expected witness/control |
| `E3-B04-SCALARON-SPLIT-DRIVE` | E3 | `6A:9162-9187` | PASS: expected witness/control |
| `E3-B04-K48-SCHUR-BLOCK` | E3 | `6A:10185-10215` | PASS: expected witness/control |
| `E3-B04-K48-SCHUR-ZERO` | E3 | `6A:10454-10479` | PASS: expected witness/control |
| `E3-B04-HURWITZ-SPECTRUM-COUNT` | E3 | `6A:9851-9884` | PASS: expected witness/control |
| `E3-B04-HURWITZ-SPECTRUM-TRACE` | E3 | `6A:9851-9884` | PASS: expected witness/control |
| `E3-B04-HURWITZ-ZERO-SECTOR` | E3 | `6A:9879-9883` | PASS: expected witness/control |
| `E4-B04-HURWITZ-OMITTED-CONSTANT` | E4 | `6A:9873-9883` | PASS: expected witness/control |
| `E3-B04-HURWITZ-POSCTRL-MEAN-ZERO` | E3 | `6A:9873-9883` | PASS: expected witness/control |
| `E3-B04-HURWITZ-NEIGHBOUR-COUNTS` | E3 | `6A:9851-9884` | PASS: expected witness/control |
| `E3-B04-HURWITZ-GEOMETRIC-EIGENSPECTRUM` | E3 | `6A:9851-9884` | PASS: expected witness/control |
| `E4-B04-HURWITZ-CONSTANT-WITNESS` | E4 | `6A:9873-9883` | PASS: expected witness/control |
| `E3-B04-BORN-STAR-CLOSURE` | E3 | `6A:9949-9970` | PASS: expected witness/control |
| `E3-B04-BORN-INVERSE` | E3 | `6A:9960-9968` | PASS: expected witness/control |
| `E3-B04-BORN-V-ADD` | E3 | `6A:9949-9983` | PASS: expected witness/control |
| `E3-B04-BORN-SEMIGROUP` | E3 | `6A:9985-10039` | PASS: expected witness/control |
| `E3-B04-BORN-GROUP-ENDO` | E3 | `6A:9985-10039` | PASS: expected witness/control |
| `E3-B04-BORN-CUBIC-NONGROUP` | E3 | `6A:10077-10089` | PASS: expected witness/control |
| `E2-B04-BORN-NO-O7-VECTOR` | E2 | `6A:10056-10075` | PASS: expected witness/control |
| `E3-B04-RAR-TERMINAL-PAIR` | E3 | `6A:10105-10159` | PASS: expected witness/control |
| `E3-B04-RAR-ENV-SCALING` | E3 | `6A:10105-10159` | PASS: expected witness/control |
| `E3-B04-RAR-C6-CROSS-SORT-DIAGNOSTIC` | E3 | `6A:10217-10239` | PASS: expected witness/control |
| `E3-B04-RAR-NONUNIVERSAL-WITNESS` | E3 | `6A:10161-10183` | PASS: expected witness/control |
| `E3-B04-SCALARON-RUNNING-MASS-DERIV` | E3 | `6A:10241-10275` | PASS: expected witness/control |
| `E2-B04-WELL-DISSIPATION` | E2 | `6A:10288-10330` | PASS: expected witness/control |
| `E3-B04-HOMOG-RETARDED-RATIO` | E3 | `6A:10589-10622` | PASS: expected witness/control |
| `E3-B04-S3-COLD-LAMBDA` | E3 | `6A:10624-10660` | PASS: expected witness/control |
| `E3-B04-S3-COLD-GREEN-LAPLACE` | E3 | `6A:10624-10660` | PASS: expected witness/control |
| `E3-B04-S3-COLD-RETARDED-RATE` | E3 | `6A:10624-10660` | PASS: expected witness/control |
| `E3-B04-HELICITY-PROJECTOR-FRAMES` | E3 | `6A:10797-10829` | PASS: expected witness/control |
| `E3-B04-HELICITY-MIDPOINT-EQUAL` | E3 | `6A:10797-10829` | PASS: expected witness/control |
| `E3-B04-HELICITY-TANH` | E3 | `6A:10831-10877` | PASS: expected witness/control |
| `E3-B04-HELICITY-EQUAL-STATE-ZERO` | E3 | `6A:10841-10893` | PASS: expected witness/control |
| `E4-B04-HELICITY-ASYM-WITNESS` | E4 | `6A:10879-10893` | PASS: expected witness/control |
| `E3-B04-SCALAR-SYMPLECTIC-S` | E3 | `6A:10901-10977` | PASS: expected witness/control |
| `E3-B04-SCALAR-GROUND-COVARIANCE` | E3 | `6A:10901-10977` | PASS: expected witness/control |
| `E3-B04-SCALAR-ROOT-PRIVILEGED-POS` | E3 | `6A:10901-10977` | PASS: expected witness/control |
| `E3-B04-SHELL-RANK-FRAC-9` | E3 | `6A:10901-10951,10993-11009` | PASS: expected witness/control |
| `E3-B04-SHELL-RANK-FRAC-25` | E3 | `6A:10901-10951,10993-11009` | PASS: expected witness/control |
| `E3-B04-SHELL-RANK-FRAC-169` | E3 | `6A:10901-10951,10993-11009` | PASS: expected witness/control |
| `E3-B04-TENSOR-SHELL-RANK` | E3 | `6A:11021-11053` | PASS: expected witness/control |
| `E3-B04-TENSOR-FRAME-GENERATOR` | E3 | `6A:11083-11103` | PASS: expected witness/control |
| `E3-B04-TENSOR-FRAME-MOMENTUM` | E3 | `6A:11083-11095` | PASS: expected witness/control |
| `E4-B04-HUBBLE-CONFORMAL-COUNTEREXAMPLE` | E4 | `6A:11083-11108` | PASS: expected witness/control |
| `E3-B04-HUBBLE-CONFORMAL-POSCTRL` | E3 | `6A:11083-11108` | PASS: expected witness/control |
| `E3-B04-HUBBLE-CONFORMAL-SYMBOLIC` | E3 | `6A:11083-11108` | PASS: expected witness/control |
| `E3-B04-DIRAC-TT-CANONICAL` | E3 | `6A:11116-11155` | PASS: expected witness/control |
| `E2-B04-DIRAC-MASS-WORK-CONST` | E2 | `6A:11156-11168` | PASS: expected witness/control |

## 4. Source-anchored assumption/condition first-occurrence register

Earlier A-0001…A-0013 are retained with their previous original source locators and epistemic status. Exactly two newly inferred, as-yet-undischarged conditions are registered in this batch (they are **not** new GP axioms, physical mechanisms or repairs):

- `BH-VIA-A-0014` at source line 11105: To have H_E dt_E = H_J dt_J under a_E = sqrt(F)a_J and dt_E = sqrt(F)dt_J, the conformal factor must satisfy d ln F=0 along the relevant time-direction. **Role:** GUARD_FOR_BH-VIA-G-0011; **epistemic status:** NOT-YET-LOCATED.
- `BH-VIA-A-0015` at source line 9873: To make the three printed nonzero 24-cell n-step factors exhaustive, restrict the shell response to the constant-orthogonal (mean-zero) subspace, otherwise include the invariant eigenchannel 1^n. **Role:** GUARD_FOR_BH-VIA-G-0012; **epistemic status:** NOT-YET-LOCATED.

Where hypotheses were already source-stated—post16 nonzero stiffness, K16 retained scalaron, full jet stress, K48 selected H owner, finite kinetic Schur regularity, cyclic root state—they remain ordinary typed premises. This audit does not pretend that a premise is an independently proved physical occurrence, nor does it duplicate global canonical assumption IDs from a merely similar name.

## 5. Typed DAG source use, provenance and impact limits

Previously recorded 84 edges remain byte-for-byte unchanged in the loaded records. **53** source-witnessed edges/guards are appended (total 137). Edges have a concrete `Paper6A-GravityCosmology-v2_253.tex:<line>` witness and a provenance type `IMPORTED_PROOF`, `PREMISE_OF`, `CITATION_ONLY`, or `BLOCKS_ROUTE`. Every new source-material edge is explicitly quarantined pending a full upstream route certification; publication of the edges is **not** publication of a proved global DAG path.

Important source-matched material uses include:

- `p8:thm:v2111-cyclic-k16-finite-arrival` → `p8:thm:v2134-post16-stationary-schur` (`PREMISE_OF`, source 9120, quarantined).
- `p8:thm:v251-constrained-scalaron-generator` → `p8:thm:v2134-post16-stationary-schur` (`PREMISE_OF`, source 9129, quarantined).
- `p3f:cor:v1136-fixed-datum-support` → `p8:thm:v2136-k16-direct-particle-owner` (`IMPORTED_PROOF`, source 9494, quarantined).
- `p2a:cor:v3108-fixed-owner-successor-cell` → `p8:thm:v2136-k16-direct-particle-owner` (`IMPORTED_PROOF`, source 9495, quarantined).
- `p8:prop:canonical-born-imbalance-group` → `p8:thm:born-balance-universal-continuation` (`PREMISE_OF`, source 10029, quarantined).
- `p8:thm:born-balance-universal-continuation` → `p8:cor:born-balance-universal-instance` (`PREMISE_OF`, source 10043, quarantined).
- `p3f:thm:v1142-k48-h-t5-schur-zero` → `p8:thm:v2142-k48-zero-order-schur-exhaustion` (`IMPORTED_PROOF`, source 10469, quarantined).
- `p8:thm:v2142-k48-zero-order-schur-exhaustion` → `p8:cor:v2142-k48-gamma-unit` (`PREMISE_OF`, source 10483, quarantined).
- `p2c:thm:protected-projector-midpoint` → `p8:prop:v2213-projector-sign-midpoint` (`IMPORTED_PROOF`, source 10800, quarantined).
- `p4:thm:v245-finite-free-vacuum-covariance` → `p8:thm:parity-odd-coefficient` (`IMPORTED_PROOF`, source 10864, quarantined).
- `p8:thm:v2114-fresh-root-neutral-qroot` → `p8:cor:native-cyclic-shell-covariance` (`PREMISE_OF`, source 10904, quarantined).
- `p8:cor:v2109-positive-root-oscillators` → `p8:cor:native-cyclic-shell-covariance` (`PREMISE_OF`, source 10908, quarantined).
- `p4:cor:finite-tt-source-response` → `p8:cor:causal-tt-dirac-system` (`IMPORTED_PROOF`, source 11120, quarantined).
- `p3f:thm:tt-dirac-vertex-contact` → `p8:cor:causal-tt-dirac-system` (`IMPORTED_PROOF`, source 11121, quarantined).
- `BH-VIA-A-0014` → `p8:sec:tensor-frame-ledger` (`BLOCKS_ROUTE`, source 11105, quarantined).
- `BH-VIA-A-0015` → `p8:prop:shell-algebra-nonterminal-rar` (`BLOCKS_ROUTE`, source 9873, quarantined).

New root issue guards are the direct, first-used edge `BH-VIA-A-0014` → `p8:sec:tensor-frame-ledger` and `BH-VIA-A-0015` → `p8:prop:shell-algebra-nonterminal-rar`. Their *possible* later local consumers are not marked as proven broken without a source-verified material path. Neither issue is promoted into a claim that Paper II, III, IV or any other sibling paper has failed.

## 6. Named formal objects — exhaustive Batch 4 disposition table

| ID | Source lines | Exact source label | Disposition | Linked issues | Linked local checks |
|---:|---:|---|---|---|---:|
| 0179 | 9045–9062 | `p8:thm:v2134-reheating-cell` | VERIFIED-CONDITIONAL | — | 2 |
| 0180 | 9064–9091 | `p8:cor:v2134-reheating-response-law` | VERIFIED-CONDITIONAL | — | 5 |
| 0181 | 9093–9112 | `p8:def:v2134-reheating-dilution` | FORMALIZED | — | 1 |
| 0182 | 9114–9159 | `p8:thm:v2134-post16-stationary-schur` | VERIFIED-CONDITIONAL | — | 3 |
| 0183 | 9162–9187 | `p8:cor:v2175-post16-slow-fast-decomposition` | VERIFIED-CONDITIONAL | — | 2 |
| 0184 | 9189–9206 | `p8:cor:v2175-k48-trace-conditioned-crossing` | REPRODUCED | — | 0 |
| 0185 | 9208–9219 | `p8:cor:v2175-c06-execution-frontier` | FORMALIZED | — | 0 |
| 0186 | 9221–9240 | `p8:cor:v2134-post16-hubble-bound` | VERIFIED-CONDITIONAL | — | 1 |
| 0187 | 9242–9265 | `p8:cor:v2134-visible-thermalization` | VERIFIED-CONDITIONAL | — | 2 |
| 0188 | 9267–9277 | `p8:rem:v2134-retained-scalar` | FORMALIZED | — | 0 |
| 0189 | 9316–9334 | `p8:def:v2135-typed-k16-boundary-packet` | FORMALIZED | — | 0 |
| 0190 | 9336–9363 | `p8:def:v2135-pb16-owner` | FORMALIZED | — | 0 |
| 0191 | 9365–9381 | `p8:prop:v2135-k16-saturation-criterion` | VERIFIED-CONDITIONAL | — | 0 |
| 0192 | 9383–9404 | `p8:cor:v2135-ordinary-normalization-pb16` | VERIFIED-CONDITIONAL | — | 0 |
| 0193 | 9406–9428 | `p8:rem:v2135-k16-status` | FORMALIZED | — | 0 |
| 0194 | 9436–9499 | `p8:thm:v2136-k16-direct-particle-owner` | REPRODUCED | — | 0 |
| 0195 | 9501–9531 | `p8:cor:v2136-pb16-closed` | REPRODUCED | — | 0 |
| 0196 | 9534–9544 | `p8:rem:v2201-pb16-action-jets` | FORMALIZED | — | 0 |
| 0197 | 9547–9567 | `p8:rem:v2136-visible-heavy-neutral-scope` | FORMALIZED | — | 0 |
| 0198 | 9569–9584 | `p8:rem:v2136-supersede-v2135-owner-frontier` | FORMALIZED | — | 0 |
| 0199 | 9592–9623 | `p8:def:v2137-inflation-end-conditioned-response` | FORMALIZED | — | 2 |
| 0200 | 9625–9641 | `p8:cor:v2137-conditioned-response-flow` | VERIFIED-CONDITIONAL | — | 2 |
| 0201 | 9643–9663 | `p8:def:v2137-bl2-boundary-owner` | FORMALIZED | — | 0 |
| 0202 | 9665–9681 | `p8:prop:v2137-native-boundary-baryogenesis-status` | REPRODUCED | — | 0 |
| 0203 | 9683–9691 | `p8:rem:v2137-k24-bridge-scope` | FORMALIZED | — | 0 |
| 0204 | 9700–9722 | `p8:cor:v2138-k32-native-length` | VERIFIED-CONDITIONAL | — | 2 |
| 0205 | 9724–9732 | `p8:rem:v2138-k32-metre-firewall` | FORMALIZED | — | 1 |
| 0206 | 9744–9771 | `p8:prop:v2140-corrected-baryogenesis-roles` | REPRODUCED | — | 0 |
| 0207 | 9773–9781 | `p8:rem:v2140-k24-not-yield` | FORMALIZED | — | 0 |
| 0208 | 9820–9843 | `p8:thm:scalaron-core-closed` | FORMALIZED | — | 0 |
| 0209 | 9851–9888 | `p8:prop:shell-algebra-nonterminal-rar` | UNRESOLVED | G-0012 | 8 |
| 0210 | 9949–9983 | `p8:prop:canonical-born-imbalance-group` | VERIFIED-CONDITIONAL | — | 3 |
| 0211 | 9985–10039 | `p8:thm:born-balance-universal-continuation` | VERIFIED-CONDITIONAL | — | 2 |
| 0212 | 10041–10054 | `p8:cor:born-balance-universal-instance` | VERIFIED-CONDITIONAL | — | 0 |
| 0213 | 10056–10075 | `p8:prop:no-visibility-balance-linear-bridge` | VERIFIED-CONDITIONAL | — | 1 |
| 0214 | 10077–10089 | `p8:rem:born-balance-continuation-scope` | FORMALIZED | — | 1 |
| 0215 | 10105–10159 | `p8:cor:v2119-environment-conditioned-terminal-rar` | VERIFIED-CONDITIONAL | — | 2 |
| 0216 | 10161–10183 | `p8:cor:v2119-no-global-one-variable-rar` | VERIFIED-CONDITIONAL | — | 1 |
| 0217 | 10185–10215 | `p8:cor:v2119-hs-same-action-schur` | REPRODUCED | — | 1 |
| 0218 | 10217–10239 | `p8:cor:v2119-c6-not-static-floor` | VERIFIED-CONDITIONAL | — | 1 |
| 0219 | 10241–10286 | `p8:cor:v2119-running-mass-diagnostic` | VERIFIED-CONDITIONAL | — | 1 |
| 0220 | 10288–10330 | `p8:cor:v2119-local-well-residence` | VERIFIED-CONDITIONAL | — | 1 |
| 0221 | 10333–10342 | `p8:rem:v2201-residence-first-pass` | FORMALIZED | — | 0 |
| 0222 | 10353–10366 | `p8:thm:v2141-k48-h-terminal-consumption` | VERIFIED-CONDITIONAL | — | 0 |
| 0223 | 10368–10384 | `p8:def:v2141-k48-response-jet` | FORMALIZED | — | 0 |
| 0224 | 10386–10404 | `p8:cor:v2141-k48-dust-continuation` | REPRODUCED | — | 0 |
| 0225 | 10406–10419 | `p8:prop:v2141-homogeneous-inhomogeneous-response-split` | VERIFIED-CONDITIONAL | — | 0 |
| 0226 | 10421–10430 | `p8:rem:v2141-k48-no-double-counting` | FORMALIZED | — | 0 |
| 0227 | 10432–10446 | `p8:rem:v2141-k48-false-shortcuts` | FORMALIZED | — | 0 |
| 0228 | 10454–10479 | `p8:thm:v2142-k48-zero-order-schur-exhaustion` | VERIFIED-CONDITIONAL | — | 1 |
| 0229 | 10481–10506 | `p8:cor:v2142-k48-gamma-unit` | VERIFIED-CONDITIONAL | — | 0 |
| 0230 | 10508–10520 | `p8:cor:v2142-k48-unit-dust-continuation` | VERIFIED-CONDITIONAL | — | 0 |
| 0231 | 10522–10532 | `p8:rem:v2142-k48-normalization-retirements` | FORMALIZED | — | 0 |
| 0232 | 10540–10567 | `p8:thm:v2145-k48-dust-constructor-nogo` | VERIFIED-CONDITIONAL | — | 0 |
| 0233 | 10569–10587 | `p8:cor:v2145-k48-endpoint-versus-dust` | FORMALIZED | — | 0 |
| 0234 | 10589–10622 | `p8:thm:v2145-k48-n0-propagator` | VERIFIED-CONDITIONAL | — | 1 |
| 0235 | 10624–10660 | `p8:thm:v2145-closed-s3-cold-propagator` | VERIFIED-CONDITIONAL | — | 3 |
| 0236 | 10662–10694 | `p8:cor:v2145-collisionless-dynamic-source` | REPRODUCED | — | 0 |
| 0237 | 10696–10711 | `p8:cor:v2145-causal-sectorial-dtn` | VERIFIED-CONDITIONAL | — | 0 |
| 0238 | 10713–10747 | `p8:rem:v2145-k48-rar-frontier` | FORMALIZED | — | 0 |
| 0239 | 10769–10772 | `p8:rem:eta-zero-helicity-source-boundary` | FORMALIZED | — | 0 |
| 0240 | 10774–10777 | `p8:rem:beltrami-helicity-contact-only` | FORMALIZED | — | 0 |
| 0241 | 10779–10794 | `p8:rem:v261-protected-response-helicity-firewall` | FORMALIZED | — | 0 |
| 0242 | 10797–10823 | `p8:prop:v2213-projector-sign-midpoint` | VERIFIED-CONDITIONAL | — | 2 |
| 0243 | 10831–10839 | `p8:def:deferred-hopf-cs-transfer` | FORMALIZED | — | 1 |
| 0244 | 10841–10893 | `p8:thm:parity-odd-coefficient` | VERIFIED-CONDITIONAL | — | 3 |
| 0245 | 10901–10977 | `p8:cor:native-cyclic-shell-covariance` | VERIFIED-CONDITIONAL | — | 6 |
| 0246 | 10993–11009 | `p8:rem:v273-shell-twirl-projector-firewall` | FORMALIZED | — | 3 |
| 0247 | 11021–11073 | `p8:cor:native-cyclic-tensor-covariance` | VERIFIED-CONDITIONAL | — | 1 |
| 0248 | 11116–11155 | `p8:cor:causal-tt-dirac-system` | REPRODUCED | — | 1 |
| 0249 | 11169–11186 | `p8:cor:regular-tt-source-inheritance` | REPRODUCED | — | 0 |

The source has **unnamed** material claims not captured as LaTeX theorem environments; they are separately indexed in `Paper6A-Batch04-Coverage-v1_4.json`. In particular, the Hubble conformal-frame identity is a deliberately distinct *unnamed* issue root, not incorrectly attached to a different named tensor theorem.

## 7. Batch continuation, artifact integrity and final release gate

- **Next original manuscript line:** **11,204**; the 71 named formal objects in this batch are `BH-VIA-C-0179` through `BH-VIA-C-0249`, leaving 108 named objects and source lines 11,204–17,251. The next section begins the spherical/outer-gravity and later observable-response analysis.
- Every source unit is located in the current file `Paper6A-GravityCosmology-v2_253.tex`; the original corpus SHA256 remains unchanged. Original DAG and audit ZIPs remain read-only and are not overwritten or reserialized by this intermediate pass.
- The complete checkpoint includes all 357 indexed claims with only 249 reviewed, all 12 cumulative issues (previous 10 retained), 15 first-known local conditions, and 137 typed source-witnessed edges, as well as the 70-check executable script and its result JSON. Claims numbered 0250–0357 remain `NOT_AUDITED`.
- **No final deliverable ZIP is issued in this nonterminal batch.** Upon the final batch, merge source-verified dispositions into the supplied DAG Atlas and ProofChainAudits archives, package each with only its newest applicable versions, verify ZIP integrity/contents and deliver both links. No theory changes or missing-gap repairs are inferred during this audit.

### Machine-readable checkpoint files
- `Paper6A-Batch04-ClaimLedger-v1_4.json`
- `Paper6A-Batch04-GapRegistry-v1_4.json`
- `Paper6A-Batch04-Assumptions-v1_4.json`
- `Paper6A-Batch04-TypedDependencies-v1_4.json`
- `Paper6A-Batch04-Coverage-v1_4.json`
- `Paper6A-Batch04-ExactChecks-v1_4.json`
- `Paper6A-Batch04-ExactChecks-v1_4.py`
- `Paper6A-AuditProgress-v1_4.json` (work-root continuation marker)

