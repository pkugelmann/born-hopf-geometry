# Paper VI-A — RigorousVerificationDAG correctness audit, Batch 05 (source-first)

**Target:** `Paper6A-GravityCosmology-v2_253.tex` (SHA256 `3110e5c951b395665f54a2a910dd6e3570eb9659e775d3b0b4128e6fe28a82d1`; 17,251 source lines)  
**Authoritative corpus:** `Paper00-PapersMinimal-v2_371(1)(1).zip`  
**Verification protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4(1).md`  
**Lines reviewed this batch:** **11,204–14,549** inclusive (3,346 lines). **Next line 14,550.**  
**Evidence mode:** Actual local source replay, sourced imported-premise boundary check, independent exact/symbolic and numerical checks, adversarial source-domain challenges; **no separate agents**.

## 1. Coverage and adjudication summary

| Checkpoint metric | Batch 5 | Cumulative |
|---|---:|---:|
| Source coverage | 3,346 lines | **14,549 / 17,251 (84.34%)** |
| Source-labeled formal objects dispositioned | 63 | **312 / 357 (87.39%)** |
| Remaining named claims | — | **45** |
| Material unnamed clauses indexed | 13 | maintained separately, not counted as formal claims |
| Scoped exact/numeric/adversarial checks | **76 / 76 pass** | **310 / 310 pass** |
| New findings | 2 moderate | **14 open: 10 moderate, 4 minor** |
| First-known local condition nodes | +2 | **17** (canonical global equivalence not presumed) |
| Typed source-literal DAG records | +50 | **187** |

**Current named-object statuses:** FORMALIZED=108, REPRODUCED=96, VERIFIED-CONDITIONAL=98, UNRESOLVED=10. The 76 passing predicates include a successful E4 challenge that establishes an unresolved **interface**; passing controls are not an assertion that every named result is verified. No auto-promotion from citation to proof-use. Peer VI-C read only for imported statements; VI-C was *not* audited as a separate target. Original TeX files and source archives are untouched.

## 2. Findings and mandatory theorem-boundary adjudication

### BH-VIA-G-0013 — EVIDENCE_MISSING / NUMERICAL_REPLAY (MODERATE)

**First source:** VI-A **11655–11739**; roots `p8:prop:v2184-native-source-memory-regulator`, `p8:cor:v2184-native-regulating-basin`, `p8:prop:v2184-spherical-constraint-buffer-matching`. **Controlling peer:** VI-C `p8:app:black-hole-native-regulation`, **7989–8089**. **Boundary gate:** `BH-VIA-BND-B05-001`.

The numerical witness asserts a licensed constrained first-jet finite source trajectory with outer/inner marginal radii **1.003875886570…**, **0.533282796858…** in units of r_s, lapse residual <1e-12, Raychaudhuri balance <2e-13, simple-zero derivatives **-0.628776873258…**, **69.629429382407…** and sixth-degree constraint matching. The main source explicitly imports a VI-C reproducibility appendix. **The appendix exists in the supplied corpus** and reproduces equations plus reported output values; however, it names concrete `Paper00-BlackHoleRegulationChecks-v1_9.py`, `v1_10.py`, `v1_11.py`, `v1_12.py` and `v1_12.json`, none of which exists in the supplied ZIPs. Full initial Bloch/source-strength and buffer polynomial coefficients are not in the appendix. The reported numerical E3 result cannot be independently replayed from the supplied artifacts.

**Adversarial evidence:** `E0-B05-BH-APPENDIX-LOCATED`, `E4-B05-BH-CITED-REPLAY-SCRIPTS-ABSENT`; analytic conditional control `E2-B05-BH-TRANSVERSE-POSCTRL`. **Status:** UNRESOLVED-E3, not REFUTED. The stated finite-source ODE/regularity arguments and general constraints remain available; no claim about actual collapse-selected physical histories follows. **Discharge:** provide exact cited executable versions, numeric Cauchy/source seeds, action/source strength, buffer coefficients, residual scripts and the JSON data for independent replay.

### BH-VIA-G-0014 — PHYSICAL_OWNER_BRIDGE / UNDISCHARGED_CONDITIONAL (MODERATE)

**First source:** VI-A **11254–11376**, with later unqualified TR1 retirement at **12140–12164**, terminal physical law at **12172–12186**, and same-action Schur equation at **12302–12429**. **Peer source:** VI-C **7369–7457**. **Boundary gate:** `BH-VIA-BND-B05-002`. **Inferred missing same-action physical bridge node:** `BH-VIA-A-0016` (first-known local identity only).

The abstract comparison boundary action `Γ_R[u]=1/2 ∫[(∂_s u)^2+|∇_H u|²+Ru²]` is well-posed with a zero eigenmode. Its exact decaying solution gives `N_R 1=√R`. The `SU(2)`-invariant Hopf probability normalization gives a correct *conditional* local trace density `c²√R/(4π)`; confirmed independently (`E3-B05-DTN-MODE`, `E3-B05-DTN-ZERO`, `E3-B05-HOPF-FLUX-TRACE`, `E3-B05-HOPF-NORMALIZED-MEASURE`). But VI-A:11270–11273 explicitly says this determinant is a separate comparison until the boundary-owner criterion is discharged, and VI-A:11375–11376 says physical acceleration trace identification is still TR1. VI-C:7386–7388 likewise expressly disclaims that `Γ_R` was descended from the actual action. The later VI-A:12163–12164 statement that TR1 is retired from the native physical law does not follow from the abstract DtN or generic Schur Hessian identity alone. Physical `K_{∂,Y}=Schur_I(D²S_star)` is source-generated but its equality to this specific scalar collar determinant and absolute normal-flux observable has not been established in the reviewed source/imported premise.

**Positive controls:** Exact Γ_R DtN eigenvalue; 4π invariant probability; algebra of `g_obs²=a_0 g_b` **if** product-leaf terminal contraction and TR1 physical readout are given; Schur product/derivative identities on an occurring regular stationary branch. **Adversarial provenance:** `E4-B05-TR1-CONDITIONAL-IN-SOURCE`, `E4-B05-TR1-BOUNDARY-CRITERION-QUALIFIER`. **Status:** UNRESOLVED physical observable interface, *not* a refutation of the comparison determinant, Hopf normalization, or abstract Schur theorem. **Discharge:** source-matched same-action conormal scalar zero-mode Hessian equality and acceleration trace identity; alternatively retain TR1 as a transparently conditional physical identification. Do not substitute a conventional MOND/f(R) mechanism.

No downstream *cross-paper* failure has been independently proven. Possible (not certified) impacts are physical normalization and observable RAR transfer to VI-B. `BH-VIA-A-0017` records the different, explicitly assumed regular-branch stationary Schur/invertible-interior domain; it must **not** be confused with the missing Γ_R equality.

## 3. Positive evidence, branch distinctions and remaining obligations

### Scalar static determinant and finite-source areal dynamics (11,204–11,654)
- The ambient floor `R >= C_56`, and `R_sel=max(C_56,R_env)`, are *static response curvature* coordinates, not de-Sitter spacetime Ricci curvature. `C_56=2Λ` and `R_dS=4Λ` remain typed distinctly.
- Exact DtN eigenmode `sqrt(R+lambda_l)` and full zero-mode `sqrt(R)` are reproduced from the decaying half-cell ODE. Haar trace density `1/(4π)` independently checked; **physical source-to-acceleration identification remains G-0014**.
- The turning principal relation, spherical curvature compression and canonical momenta have independent local sign/normalization controls. A valid **conditional** local areal reversal or bounded normal form cannot imply a full physically selected black-hole collapse trajectory.

### Native first-jet regulation, H-owned K48 and terminal static law (11,655–12,470)
- VI-C has the black-hole appendix and the correct precession and constraint formulae, but no executable witness seed/outputs; see G-0013. The `p8:prop:regular-finite-continuation-criterion` ODE theorem is a standard correct **if** locally Lipschitz + forward invariant compact regular chart; it is not itself an exhibited complete source history.
- K48 H-modality co-realization and finite carrier energy are algebraic, and the measured source cold ratio is not inferred. The source keeps the full stress/physical occupation distinct from a modal Hilbert carrier.
- Product-leaf scalar imbalance `v=(1/2)log(X/Y)` contracts via a claimed generated process `v_l=exp(-l)v_0`; this gives `R_resp=sqrt(R_sel R_b)` **conditionally on that process being realized**. The deep pair `g_obs²=a_0 g_b` checks algebraically with fixed normalization, not as an unconditional observation.
- Fixed-environment Schur `K48=β*Schur(D²S_star)β` and `C¹` source variation/product rule are exact if physical stationary branch/split/invertibility are supplied. The Schur identity does not generate a universal closed elementary interpolation or certify the separate Γ_R determinant.

### Closed spatial response and source/energy exchange (12,471–13,240)
- The mean-zero Poisson inverse on `S³` contains the necessary subtraction of the global constant mode; separately the massive inverse has an **invertible** constant mode, a finite antipodal limit and the retained global regular part. The exact radial Green equation, pole normalization, and local-force correction passed separate checks.
- Homogeneous two-port Ward identity and pressure/scale work were replayed on their declared source/measure quotient. They do not force a cosmic cold abundance or an `a^-3` law unless physical energy/pressure conditions are added.
- The source-derived static negative induced quadratic energy follows from the source-loaded variational functional with its susceptibility and physical mode domain. Normalized source energy and optional kinetic jets were kept separate.

### Cubic/static-to-cosmological limits and finite memory (13,241–14,054)
- The cubic field equation’s negative on-shell energy and the source’s critical scale weight are independently consistent. **All four printed source-ball radial integral samples at 0.8, 0.2, 0.04 and 0.01, including their derivative and induced-energy values, were independently recalculated by numerical quadrature** in the executable Batch 05 controls. The sign is not promoted to complete positive physical dark-matter stress.
- The state-conditioned radial Gaussian moments, nonzero finite cubic response and its energy allocation are distinct from a same-action state selection. The finite-source state-conditioning is preserved.
- For the positive spectral measure, the even dynamic response obeys the given static upper bound. Static susceptibility alone does not construct a full retarded source trajectory, kinetic or thermal state.

### Complete-curvature and null budgets (14,055–14,549)
- The cold-work bound, local Noether Wald entropy, positive invariant curvature coordinate identity, `Q` flow and signed Raychaudhuri squares passed source-specific algebraic tests; no exact full physical trapped-state solution inferred from them.
- The constrained scalaron–shape Hessian determinant and sample positive branches at two printed test points were independently checked. **The final source remark explicitly leaves actual full-source/tidal action, collapse packet, matching, absolute exceptional-curvature range and complete regular continuation OPEN**. No earlier narrow first-jet result overrides this explicit current-source boundary.

## 4. Typed DAG / assumptions / source provenance

- Previous **137** source-bound typed edges retained unchanged; **50** new source-checked exact-use/citation/guard edges in `Paper6A-Batch05-TypedDependencies-v1_5.json`. Imported references without complete proof certificate are **quarantined**; inherited edge flags are preserved. No global theorem status was bulk promoted.
- **17** cumulative local first-known condition records, including `BH-VIA-A-0016` (same-action Γ_R/physical acceleration owner interface) and `BH-VIA-A-0017` (explicit regular stationary Hessian domain). Neither is asserted to be a newly invented physical axiom or globally unique absent canonical atlas alias reconciliation.
- Two auditable `BND` records separate abstract mathematical host data, stated representation/intertwiner ownership, physical occurrence, and observable interpretation; downstream transfer remains guarded.
- The full source `SOURCE-AS-PRINTED` claim inventory of **357** entries is carried unchanged. Exactly the first **312** have source-disposition, including unresolved numerical/physical routes; all later 45 retain `NOT_AUDITED`.
- All source/archive hashes and protocol identities are retained; previous four batches' issue records, source claims and dependency records remain unchanged.

## 5. Next batch / final-archive gate

**Continue at line 14,550; 2,702 source lines and 45 formal objects remain.** The user-requested updated **DAG Atlas ZIP** and **ProofChainAudits ZIP**, containing only applicable latest versions, are reserved for the final batch. Do not bundle older audit files/duplicate versions or claim current input ZIPs were modified. Save only versioned audit checkpoints at Batch 05. The next audit must independently check all terminal spectral-freeze, complete-energy/observables export and consistency-limit claims and only then trigger verified ZIP merge.

**Executable evidence:** `Paper6A-Batch05-ExactChecks-v1_5.py`; `Paper6A-Batch05-ExactChecks-v1_5.json`.  
**Formal claim and unnamed coverage:** `Paper6A-Batch05-ClaimLedger-v1_5.json`, `Paper6A-Batch05-Coverage-v1_5.json`.  
**Open issues and boundary audits:** `Paper6A-Batch05-GapRegistry-v1_5.json`, `Paper6A-Batch05-BoundaryRecords-v1_5.json`.  
**Canonical first-known conditions and typed routes:** `Paper6A-Batch05-Assumptions-v1_5.json`, `Paper6A-Batch05-TypedDependencies-v1_5.json`.  
**Continuation:** `Paper6A-AuditProgress-v1_5.json`.
