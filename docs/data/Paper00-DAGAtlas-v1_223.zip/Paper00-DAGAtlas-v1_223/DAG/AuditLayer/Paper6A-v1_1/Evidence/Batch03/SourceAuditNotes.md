# Born–Hopf Geometry VI-A — rigorous source/DAG correctness audit, Batch 3

**Audit version:** `Paper6A-RigorousAuditBatch03-v1_3`  
**Source authority:** `Paper00-PapersMinimal-v2_371(1)(1).zip` / `Paper6A-GravityCosmology-v2_253.tex` (SHA-256 3110e5c951b395665f54a2a910dd6e3570eb9659e775d3b0b4128e6fe28a82d1)  
**Exact audited source interval:** lines **5,534–9,030** inclusive; the manuscript contains 17,251 lines. The interval starts with D11-D19 and A5-A7 source calculations and ends with the completed optimized-axis Gaussian joint-law block, including its proof and physical sky scope. Next starts at 9,031 with the K8–K16 Born-boundary reheating closure.  
**Protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4(1).md`; original corpus, inherited `DAGAtlas-v1_113` and `ProofChainAudits-v1_30` remain unmodified. All final ZIP exports are deferred to the last batch as directed.  
**Evidence architecture:** coordinator performed distinct E0 inventory, E1 source proof replay, E2 formal guards, E3 independent symbolic/numeric checks and E4 adversarial challenges. No separate agents were available; independence denotes distinct methods rather than separately staffed agent certificates.

## 1. Coverage and checkpoint

| Item | This batch | Cumulative |
|---|---:|---:|
| Source lines reviewed | 3,497 (5,534–9,030) | 9,030 / 17,251 (52.34%) |
| Named formal objects | 61 | 178 / 357 (49.86%) |
| Material unnamed source slices | 20 | 47 |
| Executable exact control predicates | 57 passed / 57 | 164 passed / 164 |
| Open issues | 4 new | 10 cumulative (3 minor, 7 moderate) |
| Cumulative typed graph edge records | 46 new | 84 |
| First-known local conditions | 6 new | 13 |

Status counts cumulative: **FORMALIZED 69, REPRODUCED 63, VERIFIED-CONDITIONAL 42, UNRESOLVED 4**. All unexamined objects remain `NOT_AUDITED`; there is no full-paper certification yet. `VERIFIED-CONDITIONAL` is a scoped algebraic/proof conclusion under the source hypotheses and does not certify an occurring physical realization; `REPRODUCED` means source proof replay, not all-imports E3; `FORMALIZED` records exact scope/form; `UNRESOLVED` marks an actual challenged substep.

## 2. New first-origin issues — full dispositions

### BH-VIA-G-0007 — MISSING_EVIDENCE (minor)
**First source locus:** `Paper6A-GravityCosmology-v2_253.tex:5629–5634`; root `p8:sec:v2201-derived-d11`. **Lifecycle:** `OPEN / UNRESOLVED`.

**Exact challenged step.** Text says numerical covariance replays agree to errors recorded in an attached JSON, but the supplied authoritative Paper00-PapersMinimal-v2_371 archive has no JSON attachments; the D11 full high-precision ODE/60k/120k tolerance evidence is not reproducible from its claimed attachment.

**Adversarial / source evidence.** Exact original papers ZIP inventory: no *.json members. D11 source explicitly cites an attached JSON at lines 5629-5634. No matching standalone D11 execution JSON was found in the supplied baseline DAG/ProofChainAudit archive inventories.

**Positive control and claim boundary.** Source itself says the numerics are numerical replays, not interval-certified decimals. Analytic D12 local tensor expansion is independently checked; none of the printed D11 numbers is refuted by absence of its claimed JSON.

**Unaffected source claims:** Displayed D11 numbers are not disproved; D12 tensor t^6 and t^4 local coefficients survive exact controls; No numerical certificate is upgraded to E3.

**Recorded proof IDs:** `E0-B03-NUMERICAL-ATTACHMENT-INVENTORY`. **Local condition IDs:** none; execution evidence is the missing artifact.

**Audit obligation (no repair implemented).** Locate/provide original executed JSON and replay specification or retain D11 readouts explicitly as unreplicated reported numerical outputs.

**Propagation:** No verified cross-paper route is asserted blocked; only the directly identified source subclaim is unresolved. Availability gap in supplied corpus, not a logical disproof of the D11 background or tensor calculations.

### BH-VIA-G-0008 — NORMALIZATION_OR_READOUT / TYPE_OR_DOMAIN (moderate)
**First source locus:** `Paper6A-GravityCosmology-v2_253.tex:7187–7192`; root `p8:eq:hs-lambda-infty`. **Lifecycle:** `OPEN / UNRESOLVED`.

**Exact challenged step.** Printed horizon endpoint rho_infty=C_56/(2 kappa^2) conflicts with the same paper defining kappa=M^-2 and rho_Lambda=M^2 C/2=C/(2 kappa) at lines 6220 and 6456 (and kappa=8piG/c^4 at 6721). No intervening horizon-branched redefinition to kappa^2 is supplied at this use.

**Adversarial / source evidence.** For a single fixed non-unit kappa, the horizon ratio to the earlier native vacuum normalization is [C/(2kappa²)]/[C/(2kappa)]=1/kappa, not 1; the two conventions cannot be identified without another definition.

**Positive control and claim boundary.** The polynomial horizon response G_A, cubic branch Y, implicit derivative and conditional EOS can be checked algebraically independently of this overall density factor.

**Unaffected source claims:** Dimensionless normalized horizon polynomial/cubic and the conditional shape of w_DE remain algebraically consistent; The native terminal rho_Lambda=M² C/2 remains unchanged.

**Recorded proof IDs:** `E4-B03-HORIZON-KAPPA-POWER`. **Local condition IDs:** `BH-VIA-A-0011`.

**Audit obligation (no repair implemented).** Resolve whether the horizon subsection introduces a different conventional coupling kappa_h satisfying kappa_h²=kappa_native, or reconcile rho_infty using the existing defined symbol.

**Propagation:** No verified cross-paper route is asserted blocked; only the directly identified source subclaim is unresolved. Conventions/normalization in the conditional horizon branch; not evidence against an identified nonstandard horizon physical mechanism.

### BH-VIA-G-0009 — MISSING_CONDITION / COUNTEREXAMPLE (minor)
**First source locus:** `Paper6A-GravityCosmology-v2_253.tex:7353–7362`; root `p8:eq:hs-crossing-geometric`. **Lifecycle:** `OPEN / UNRESOLVED`.

**Exact challenged step.** The unqualified iff w_DE=-1 iff Theta_A=1/3 suppresses the allowed zero-matter endpoint M(a)=0. In the source physical-horizon-branch lemma M(a)=mu_m a^-3>=0 (not strictly positive). The printed EOS gives w_DE+1=-M G_theta/(G_A(Y²+G_theta)).

**Adversarial / source evidence.** Set M=0, Y=1 (unique physical solution of Y=G_A(1/Y)), Theta_A=1, G_A=1. Then rho_DE=rho_infty constant and w_DE=-1, but Theta_A!=1/3.

**Positive control and claim boundary.** When M>0 on the declared regular finite-a branch, the factor M is nonzero and w_DE=-1 iff G_theta=0 iff Y=3 iff Theta_A=1/3.

**Unaffected source claims:** Physical-branch uniqueness and monotonicity for M>=0 survive; Positive-matter phantom crossing and conditional EOS remain valid.

**Recorded proof IDs:** `E4-B03-HORIZON-IFO-VOID`, `E3-B03-HORIZON-IFO-POSCTRL`. **Local condition IDs:** `BH-VIA-A-0012`.

**Audit obligation (no repair implemented).** Scope the equivalence to M(a)>0 or explicitly account for the vacuum endpoint exception without changing the source during audit.

**Propagation:** No verified cross-paper route is asserted blocked; only the directly identified source subclaim is unresolved. A pointwise boundary/domain defect in the printed iff; not an allegation of phantom-field dynamics.

### BH-VIA-G-0010 — INCORRECT_STEP / NORMALIZATION_OR_READOUT (moderate)
**First source locus:** `Paper6A-GravityCosmology-v2_253.tex:8531–8559`; root `p8:prop:v2188-trace-coefficient-certificate`. **Lifecycle:** `OPEN / UNRESOLVED`.

**Exact challenged step.** B_a is defined as sup maximum absolute ROW SUM of insertion matrices, but the purported alternative B_a<=sup sum |c| b assumes only operator-norm certificates ||W||<=b. Operator norm does not upper bound row sum, even for finite Hermitian matrices.

**Adversarial / source evidence.** Single normalized Hermitian word W=(1/sqrt(2))*[[1,1],[1,-1]], coefficient c=1, norm ||W||_2=1, maximum absolute row sum sqrt(2)>1. Compact chart a singleton, N,V positive, so all relevant side conditions hold.

**Positive control and claim boundary.** For a Hermitian matrix, operator norm <= maximum row sum remains correct. A direct coefficient bound on the operator norm is a separate conceivable route but is NOT substituted as proof of the displayed B_a inequality.

**Unaffected source claims:** The primary row-sum bound on the source trace remains correct; Finite CAR monomials are contractions in operator norm; No actual first-K48 numerical threshold certificate was claimed in this proposition.

**Recorded proof IDs:** `E4-B03-ROW-WORD-SPECTRAL-NOT-ROWSUM`, `E4-B03-ROW-CAR-PROJECTION-ROTATED`, `E3-B03-ROW-WORD-POSCTRL`. **Local condition IDs:** `BH-VIA-A-0013`.

**Audit obligation (no repair implemented).** Supply a genuine row-sum bound on each finite word or state a distinct operator-norm sufficient route with its own proof; audit does not repair the manuscript.

**Propagation:** No verified cross-paper route is asserted blocked; only the directly identified source subclaim is unresolved. Only the alternative B_a coefficient bound is contradicted; compact chart/source state and physical K48 reach remain conditional.

## 3. Exact proof replays, negative controls and conditional firewalls

### E1/E3 local reproductions

- **Root tensor/cap D12–D13:** expand the canonical coefficient difference to obtain `n_root,L=L(L+2)(t_J/a_J0)^6/9+O(t^8)` and `Gamma_QQ/Gamma_QQ(0)=1−L(L+2)(t_J/a_J0)^4/3+O(t^6)`; check finite squeezed-vacuum projection for several `(N,n)` against its cap bound. This does not re-execute the large D11 ODE readouts or source backreaction.
- **Scalaron D15–D19, A5–A7:** independent differentiation of `(F−R chi)/(3chi)` yields `−F chi_R/(3chi²)`; compute lower-well `A≈0.1933989203`, `m_*²/U≈0.443333`, the tiny confinement scale and Yukawa force cap; confirm finite endpoint jets, WKB regime failure at the singular end and conserved-residual dust logarithmic inequality. Source exclusions of actual cold DM occurrence are retained.
- **Regular scalar atlas/local cold bound:** check a time-dependent canonical squeeze `T J T^T=J`, its generator connection, the positive `k≥3` minimum test, interval e-fold inequality and the integrated exactly-cold bound with its explicit Ricci/Hubble/source assumptions. These algebraic estimates do not assert that the required positive remnant actually occurs.
- **Conditional horizon H1/H2:** derive marginal-sphere radius from *stipulated* H1 and the support polynomial from *stipulated* H2. Verify the cubic, unique root for `M≥0`, algebraic EOS on its branch, maximum `1+4 beta_A/3`, and positive-matter crossing. H1 is not claimed to follow from causality alone and H2 is not claimed to be a unique polynomial consequence of endpoint values. Normalize the overall rho floor only after resolving G-0008.
- **Exceptional curvature, K16 and finite quantum sources:** check `I_curv=R²+36(A_H−B_H)²`, the flat curvature circles, the scale-weight `k=-1` cancellation, K16 Cayley composition and direct cell integral, exact finite CAR-pair characteristic polynomial with `E²=p²+m²`, and the sharp first-hit integral. Conditions on full trace/contact insertion, compact trajectory chart and finite occupations are NOT automatically discharged by the checks.
- **Sky optimized axes:** test harmonic planar quadratic positive/negative controls and a non-isotropic two-dimensional Gaussian angular normalization. Source proves the conditional rotational law at an exact isotropic Gaussian observer; no observed-sky alignment significance, post-visibility transfer or survey-selected window has been certified.

### E4 challenges / negative-claim adjudication

- **E4-7 numerical replication:** papers ZIP contains no D11 claimed JSON. Classify as missing supplied evidence, not a false numerical equality.
- **E4-8 coupling type:** prior `kappa=M^-2` plus terminal `rho_Lambda=M²C/2` is not the same literal formula as horizon `C/(2kappa²)` without a new convention. This is a convention problem; H1/H2 polynomial structure is independent of overall density scale.
- **E4-9 zero-matter boundary:** exact in-domain `M=0,Y=1,Theta=1,w=-1` violates the unqualified iff; positive-matter case remains valid.
- **E4-10 norm types:** a Hermitian 2×2 Hadamard word has spectral norm one but row norm sqrt(2); moreover a rotated, genuine CAR projection word a†a has norm 1 and row sum (1/2+1/sqrt(2))>1. Both violate the proposed implication; correct primary row-sum inequality survives. No claim that the complete production numerics have been computed.
- **Rejected false attack:** the Hessian-zero lemma uses the standard mathematical term *domain*, conventionally connected. A disconnected-host counterexample does not automatically defeat its affine conclusion under the actual connected-domain scope; no speculative gap was opened there.

**Total controls:** `57/57` predicates returned the expected outcomes, including the four negative/error findings. A passing *adversarial* predicate is evidence of a defect, not evidence that the attacked step is correct. E0 file inventory is not mathematical evidence for the original numeric values.

## 4. Local first-known assumption/condition registry

Original A-0001…A-0007 remain unchanged. The added nodes are source-traceable and deduplicated within the cumulative local register. They do **not** claim globally earliest origin or physical realization:

- `BH-VIA-A-0008` at source line 6230 — The continued source-free one-scalar bare regular FLRW interface has u!=0 in the momentum chart, D_k!=0 in the original q,p chart, with finite-radius regular background and fixed source-content restriction. **Role:** EXPLICIT_SOURCE_SCOPE; epistemic status `STIPULATED`.
- `BH-VIA-A-0009` at source line 7115 — H1: On the connected late FLRW branch, the scalar-phase support boundary is a homogeneous quasilocal marginal sphere satisfying h^{ab}d_a R d_b R=0. **Role:** EXPLICIT_CONDITIONAL_SELECTOR_NOT_PROVED_BY_CAUSALITY; epistemic status `STIPULATED`.
- `BH-VIA-A-0010` at source line 7162 — H2: The horizon scalar support interface weight is I(Theta)=Theta(1-Theta), with no higher-polynomial contribution or additional coefficient. **Role:** EXPLICIT_MINIMAL_INTERFACE_PREMISE_NOT_UNIQUENESS_THEOREM; epistemic status `STIPULATED`.
- `BH-VIA-A-0011` at source line 7187 — The symbol kappa^2 in rho_infty=C_56/(2 kappa²) denotes the same dimensionful native coupling kappa=1/M² used to define rho_Lambda=C/(2 kappa), or the alternate convention is explicitly retyped. **Role:** MISSING_NORMALIZATION_ALIAS_FOR_BH-VIA-G-0008; epistemic status `NOT-YET-LOCATED`.
- `BH-VIA-A-0012` at source line 7353 — M(a)=mu_m a^-3>0 (not only >=0) when inferring w_DE=-1 iff Theta_A=1/3 from the horizon EOS formula. **Role:** MISSING_GUARD_FOR_BH-VIA-G-0009; epistemic status `NOT-YET-LOCATED`.
- `BH-VIA-A-0013` at source line 8531 — Each normalized word has b_{a,alpha} that bounds its MAXIMUM ABSOLUTE ROW SUM rather than merely its spectral norm, to justify B_a<=sup sum |c| b for the original row-sum quantity. **Role:** MISSING_NORM_TYPE_FOR_BH-VIA-G-0010; epistemic status `NOT-YET-LOCATED`.

**Important guard:** H1 and H2 are legitimate conditional premises; their explicit presence is not counted as a proof gap. The missing normalization/strict-positivity/norm-type predicates are a different epistemic class and are linked only to their specific unresolved steps.

## 5. Typed dependency checkpoint and impact boundary

All prior **38** edge records are retained, and **46** source-traceable reference/use/condition records have been added. Each has a source line and original citation witness. Only semantically checked local guards are marked `SCOPE_GUARD` or `BLOCKS_ROUTE`; unverified upstream proof-use candidates remain *quarantined* and cannot promote a theorem or establish a cross-paper break. Additional label references are navigation (`CITATION_ONLY`) unless an independently checked proof route validates their consumption. The source corpus and baseline DAG are not altered in this intermediate checkpoint.

No reported issue currently has a **certified cross-paper impact path**. The local output map includes (i) unreplicated D11 numeric readouts, (ii) horizon density normalization, (iii) the vacuum-endpoint EOS iff readout, and (iv) the K48 finite-word sufficient-bound alternative. Certified unaffected routes and possible later dependents are kept separate.

## 6. Named source objects — exact Batch 3 coverage table

| ID | Lines | Source label | Disposition | Issues | Linked E0/E3/E4 controls |
|---:|---:|---|---|---|---:|
| 118 | 6068–6100 | `p8:cor:v2202-hierarchy-canonical-scalar-map` | REPRODUCED | — | 1 |
| 119 | 6116–6128 | `p8:cor:v2202-strict-trace-stiffness` | VERIFIED-CONDITIONAL | — | 0 |
| 120 | 6152–6172 | `p8:cor:v2202-lower-window-coefficient-range` | REPRODUCED | — | 1 |
| 121 | 6190–6207 | `p8:cor:v2202-terminal-floor-acceleration-relation` | FORMALIZED | — | 1 |
| 122 | 6247–6267 | `p8:thm:v2203-continued-scalar-atlas` | REPRODUCED | — | 0 |
| 123 | 6287–6300 | `p8:cor:v2203-chart-work-firewall` | VERIFIED-CONDITIONAL | — | 2 |
| 124 | 6310–6321 | `p8:cor:v2203-root-minimum-criterion` | VERIFIED-CONDITIONAL | — | 1 |
| 125 | 6330–6343 | `p8:prop:v2203-euler-root-excitation-obstruction` | REPRODUCED | — | 0 |
| 126 | 6388–6404 | `p8:thm:v2203-local-duration` | VERIFIED-CONDITIONAL | — | 1 |
| 127 | 6424–6434 | `p8:cor:v2203-integrated-local-cold-budget` | VERIFIED-CONDITIONAL | — | 1 |
| 128 | 6464–6487 | `p8:cor:v2203-terminal-boundary-amplitude` | REPRODUCED | — | 1 |
| 129 | 6504–6527 | `p8:cor:v2203-terminal-cold-charge-trace` | REPRODUCED | — | 0 |
| 130 | 6591–6613 | `p8:rem:v2203-finite-epoch-cold-target` | FORMALIZED | — | 0 |
| 131 | 6615–6642 | `p8:rem:v2203-native-low-mode-scope` | FORMALIZED | — | 0 |
| 132 | 6754–6777 | `p8:cor:v2139-h-response-exchange` | REPRODUCED | — | 0 |
| 133 | 6787–6818 | `p8:cor:v2139-post16-schur-h-response` | REPRODUCED | — | 0 |
| 134 | 6970–6979 | `p8:thm:imported-one-sided-trace-72` | REPRODUCED | — | 0 |
| 135 | 6988–7008 | `p8:lem:signed-active-trace-pairing` | VERIFIED-CONDITIONAL | — | 1 |
| 136 | 7017–7026 | `p8:cor:active-depth-competitor-exclusion` | FORMALIZED | — | 1 |
| 137 | 7036–7077 | `p8:thm:q0-active-trace-depth` | REPRODUCED | — | 1 |
| 138 | 7092–7094 | `Paper6A:unnamed:remark:7092` | FORMALIZED | — | 0 |
| 139 | 7115–7124 | `p8:def:horizon-supported-scalar-phase-response` | FORMALIZED | — | 0 |
| 140 | 7126–7134 | `p8:prop:causal-flrw-support-selector` | VERIFIED-CONDITIONAL | — | 0 |
| 141 | 7153–7177 | `p8:prop:horizon-transport-scalar-trace-kernel` | VERIFIED-CONDITIONAL | — | 0 |
| 142 | 7267–7289 | `p8:lem:physical-horizon-branch` | VERIFIED-CONDITIONAL | — | 3 |
| 143 | 7478–7503 | `p8:thm:v2109-regular-root-scalar` | REPRODUCED | — | 1 |
| 144 | 7527–7572 | `p8:cor:v2109-positive-root-oscillators` | REPRODUCED | — | 1 |
| 145 | 7651–7687 | `p8:thm:v2114-fresh-root-neutral-qroot` | FORMALIZED | — | 1 |
| 146 | 7705–7720 | `p8:thm:v2109-fixed-root-budget` | FORMALIZED | — | 1 |
| 147 | 7735–7749 | `p8:thm:v2109-subcritical-trace-reach` | FORMALIZED | — | 0 |
| 148 | 7776–7816 | `p8:thm:v2185-flrw-e6-curvature-response` | VERIFIED-CONDITIONAL | — | 1 |
| 149 | 7818–7834 | `p8:cor:v2185-flrw-e6-lines-circles` | VERIFIED-CONDITIONAL | — | 1 |
| 150 | 7836–7861 | `p8:cor:v2185-flrw-e6-stress-coordinates` | REPRODUCED | — | 0 |
| 151 | 7863–7883 | `p8:cor:v2185-flrw-e6-turning-sheets` | REPRODUCED | — | 0 |
| 152 | 7885–7913 | `p8:prop:v2185-c06-e6-functional-ports` | REPRODUCED | — | 0 |
| 153 | 7915–7931 | `p8:cor:v2185-c06-scale-weight-trace` | VERIFIED-CONDITIONAL | — | 1 |
| 154 | 7933–7947 | `p8:cor:v2185-k16-midpoint-trace-depth` | FORMALIZED | — | 0 |
| 155 | 7966–8015 | `p8:thm:v2122-native-cyclic-g28-closure` | FORMALIZED | — | 0 |
| 156 | 8051–8070 | `p8:cor:v2122-g28-full-locus-firewall` | FORMALIZED | — | 0 |
| 157 | 8152–8183 | `p8:v2171:prop:conditioning` | VERIFIED-CONDITIONAL | — | 2 |
| 158 | 8206–8217 | `p8:thm:v2178-scalaron-native-precedence` | FORMALIZED | — | 0 |
| 159 | 8219–8244 | `p8:thm:v2178-intrinsic-scalaron-decoupling` | FORMALIZED | — | 0 |
| 160 | 8246–8270 | `p8:cor:v2178-scalaron-coherent-envelope` | REPRODUCED | — | 0 |
| 161 | 8272–8304 | `p8:thm:v2178-k16-finite-production-owner` | FORMALIZED | — | 0 |
| 162 | 8306–8321 | `p8:cor:v2178-scalaron-modulation-shutoff` | FORMALIZED | — | 0 |
| 163 | 8323–8351 | `p8:cor:v2178-c06-finite-frontier` | FORMALIZED | — | 0 |
| 164 | 8358–8369 | `p8:cor:v2185-c06-e6-output-contract` | FORMALIZED | — | 0 |
| 165 | 8371–8395 | `p8:cor:v2185-c06-first-k48-split` | FORMALIZED | — | 0 |
| 166 | 8402–8421 | `p8:cor:v2186-c06-direct-energy-occupation-split` | FORMALIZED | — | 0 |
| 167 | 8431–8459 | `p8:prop:v2186-c06-finite-trace-norm-route` | REPRODUCED | — | 0 |
| 168 | 8477–8488 | `p8:cor:v2186-c06-incoming-source-comparison` | FORMALIZED | — | 0 |
| 169 | 8510–8549 | `p8:prop:v2188-trace-coefficient-certificate` | UNRESOLVED | 0010 | 3 |
| 170 | 8600–8624 | `p8:prop:v2189-c06-one-sided-first-hit` | VERIFIED-CONDITIONAL | — | 0 |
| 171 | 8641–8675 | `p8:cor:v2189-c06-sharp-chart` | VERIFIED-CONDITIONAL | — | 1 |
| 172 | 8693–8716 | `p8:prop:v2189-c06-classical-scalar-sign` | FORMALIZED | — | 0 |
| 173 | 8768–8802 | `p8:prop:v2189-c06-CAR-upper` | VERIFIED-CONDITIONAL | — | 2 |
| 174 | 8861–8871 | `p8:thm:v2189-sky-axis-unique` | REPRODUCED | — | 2 |
| 175 | 8901–8909 | `p8:cor:v2189-sky-haar-shape` | REPRODUCED | — | 0 |
| 176 | 8921–8927 | `p8:prop:v2189-sky-k3-observer` | FORMALIZED | — | 0 |
| 177 | 8946–8965 | `p8:thm:v2189-sky-gaussian-alignment` | REPRODUCED | — | 1 |
| 178 | 8984–9006 | `p8:prop:v2189-sky-window-pushforward` | REPRODUCED | — | 1 |

The complete SOURCE-AS-PRINTED text, available named proof spans, interpreted conditions, statuses and evidence IDs for *all 357 indexed named results* are in the JSON ledger. The remaining 179 are explicitly `NOT_AUDITED`.

## 7. Material unnamed source intervals

| Source lines | Subject | Issues |
|---:|---|---|
| 5534–5635 | D11 full nonlinear cyclic background and L=2-4 tensor covariance numerical execution | 0007 |
| 5636–5701 | D12 T^6 root particle excitation; D13 finite squeezed vacuum cutoff | — |
| 5702–5850 | D14 scalaron susceptibility; D15 bounded well; D16 source-free first passage; D17 trapped well ratio | — |
| 5851–6051 | D18 Yukawa force/lensing, D19 affine interaction, A5 endpoint jet, A6 adiabatic envelope, A7 conserved residual dust bound | — |
| 6052–6210 | normalized scalar map, stiffness, lower-window and static acceleration handoff | — |
| 6211–6352 | regular scalar two-chart Hamiltonian, symplectic chart generator, root positivity | — |
| 6353–6660 | exact local effective-density correction, cold amplitude interval and terminal source-subtracted pressure/charge | — |
| 6661–6918 | f(R) Einstein-form decomposition, homogeneous geometric response and late-vacuum branch | — |
| 6919–7114 | finite-denominator REG0, acceleration integration constant and curvature handoff | — |
| 7115–7182 | H1 marginal-sphere support selector and explicit H2 bilinear transport premise | — |
| 7183–7266 | horizon endpoint density normalization, exact polynomial, Y cubic | 0008 |
| 7267–7477 | horizon unique physical root, flat/closed q and EOS crossing, M=0 boundary | 0009 |
| 7478–7754 | root scalar reduction, positivity, native QROOT, fixed-root budgets and exact stopping conditions | — |
| 7755–7950 | exceptional E6 curvature restrictions, scale trace, K16 depth | — |
| 7951–8151 | G28 conditional native closure and finite K16 response cell | — |
| 8152–8354 | Cayley K16 conditioning, scalaron versus K16 occupation, C06 open finite coupled history | — |
| 8355–8509 | first-K48 trace/contact sufficient certificate, complete state owner, not numeric closure | — |
| 8510–8577 | trace coefficient row-sum and normalized-word type mismatch | 0010 |
| 8578–8850 | signed first-hit stopping, local scalar sign and exact finite CAR pair spectrum | — |
| 8851–9030 | optimized planar axes, rotational Gaussian law, testable window covariance and physical-sky scope | — |

## 8. Replay files, next boundary, and final-archive rule

- `Paper6A-Batch03-ClaimLedger-v1_3.json` — all 357 named objects, 178 cumulative reviewed.
- `Paper6A-Batch03-GapRegistry-v1_3.json` — ten persistent first-origin issues.
- `Paper6A-Batch03-Assumptions-v1_3.json` — 13 local canonical condition/guard records.
- `Paper6A-Batch03-TypedDependencies-v1_3.json` — 84 cumulative typed edge records.
- `Paper6A-Batch03-Coverage-v1_3.json` — source intervals and dispositions.
- `Paper6A-Batch03-ExactChecks-v1_3.json` — 57/57 runnable local controls.
- `Paper6A-Batch03-ExactChecks-v1_3.py` — executable E0/E3/E4 checks; source hash invariant.
- `Paper6A-Batch03-BuildLedger-v1_3.py` and `Paper6A-Batch03-BuildReport-v1_3.py` — reproducible audit checkpoint construction; not part of original theory.
- `Paper6A-AuditProgress-v1_3.json` — three completed batches, next line 9,031, four new issue IDs.

**Next audit interval starts at 9,031.** Final updated DAG Atlas and ProofChainAudits **ZIP archives, with only latest applicable file versions**, are generated exclusively after the final batch. No paper source, proof-chain origin, or input ZIP has been modified by this audit.
