# Paper VI-A rigorous verification DAG audit — Batch 02 (v1.2)

**Frozen target:** `Paper6A-GravityCosmology-v2_253.tex` in authoritative supplied corpus `Paper00-PapersMinimal-v2_371(1)(1).zip`, manuscript SHA256 `3110e5c951b395665f54a2a910dd6e3570eb9659e775d3b0b4128e6fe28a82d1`.

**Protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4(1).md`, with the first-origin/condition/physical-claim rules of the supplied proof-chain protocol. Source is authoritative; this is a correctness audit, not a proposed theory repair. The original paper, original archive, audit archive and DAG archive are unchanged. Agents were not independently available; source replay, symbolic/spherical controls and adversarial tests were recorded as distinct *evidence functions*, not as a multi-agent consensus.

**New source segment:** lines **2515–5533**, 3,019 lines, **65** newly source-bound formal objects (IDs `BH-VIA-C-0053` through `BH-VIA-C-0117`). Cumulative: **117/357** reviewed, **240** not yet audited. The rest of VI-A must not be represented as certified. Batch 2: **59** independent E3/E4 control predicates passed, **0** harness failures; cumulative 107/107 from both batches. A passed E4 test means a *challenge was validly identified*, not that the challenged manuscript proposition passed. There are **four new open issues**, six cumulative. The only end-of-audit deliverables (updated full DAG ZIP and latest-only audit ZIP) are intentionally deferred to the final batch.

## Exact source scope and guardrails

1. **Structural visibility and finite landmarks, 2515–2720.** The unresolved trace is nonincreasing because its positive-projector overlap is nonnegative; a later transient maximum pertains to the crossover `x_G`, not to unresolved `u_G`. The six finite landmarks and terminal completion stay on the same positive semigroup; the regularity/2I/2O role handoff is imported, not a physical time evolution. The optional smooth-MRESP terminal freeze is not silently identified with the current capped action. For positive smooth cutoff moments, the `a_4` compact-vacuum no-go discriminant is negative by Cauchy–Schwarz; the positive smooth heat tower cannot be repaired by dropping positivity while retaining the same theorem.
2. **Readout hierarchy and role tables, 2726–3422.** A correct source definition distinguishes the root `mathcal R_{8j}` in inverse metres, raw curvature `C_{8j}` in inverse square metres, midpoint `C^B_{8j}` in inverse square metres and action density `mathcal I_{8j}` in inverse fourth metres. Numerical figure and table entries accidentally attach midpoint values to root labels (G-0003). Rank/role comparisons do not constitute subgroup inclusions or physical realization. Historical Laurent/copying diagnostics remain historical.
3. **Lapse/Legendre and branch split, 3433–3730.** The FLRW lapse derivative, exact nondegenerate two-velocity Hessian, Hamiltonian constraint and regular Born–Legendre identities passed symbolic checks; the historical `sharp` member differs by an exact affine displacement. These are stated *separated-action* or *comparison* results; they do not supersede the current capped working action. The capped Einstein vacuum location and positive scalaron sign use their exact Paper III-E import and a source-free stationary-metric branch; physical occurrence is not established.
4. **Trace scalaron, 3783–4514.** `ddot F+3H dot F+(c²/3)(2f-RF)=S_T` and the exact force potential keep their existing action. Constant-curvature roots, constrained quadratic Friedmann generator, local lower-branch inverse, terminal susceptibility expansion, cubic/quartic vertices and positive-restoring chart were source replayed; symbolic controls used soluble `f=R+beta R²` and arbitrary quartic jets only as independently checkable subclaims. The positive uniform mass margin asserted using a high-precision monotonicity computation was *not* re-certified by replaying its full 80-digit numerical validation; it remains reproduced at E1/source level. The WKB formula has a physical-time frequency/units issue G-0004, not a refutation of the exact scalaron equation. The structural semigroup parameter `tau` is **not** equated with a generic physical solution `t`.
5. **Active thin shell and local PPN, 4454–4620.** On solved stable positive-coupling backgrounds, the local universal beta=1/sqrt(6) coupling is a conditional field-theory statement. The potentials' Newton and curvature terms do not have consistent SI dimensions (G-0005), and their shell-width to effective-charge transition lacks the standard spherical factor three in the screened regime (G-0006). The gamma fraction is an algebraically valid fraction *of an effective charge once correctly identified*; the weaker bound displayed for it is not independently an error. Solar-System occurrence, matching, ephemeris bounds and laboratory limits remain downstream rather than observed successes of the theorem.
6. **Scalar Einstein bulk and finite-source Schur, 4622–5025.** Unit-round-S3 scalar harmonic Gram factors, constraint projection and the 2×3 source/contact interface were independently controlled algebraically. A complete finite action realization, guarded Dirac Ward source and physical source-metric Schur inverse remain scoped to their stated finite Hilbert source, same-action, regularity, energy-completeness and gauge/Ward hypotheses; these are not universal arbitrary-source theorems.
7. **Curvature response and terminal optical observables, 5054–5533.** Four-dimensional Riemann algebra has 20 independent components, traced Ricci 1 + traceless Ricci 9 + Weyl 10. The traceless-Ricci eigenvalues on exact closed FLRW independently imply the displayed all-orders trace identities; this is geometry, not a second propagating scalaron. Conditional `a_6` Dirac heat pressure on the *specified radiation reference* is not dust, as an independent lapse-pressure control shows. The residual trace/enthalpy decomposition and Bianchi conservation were replayed without importing a new fluid component. The ideal terminal vacuum's de-Sitter static null optical delay and global `q_E=0` pass exact controls. Neither is a proof of an ambient parent cone or an optical propagation medium.

## New first-origin issue registry

### BH-VIA-G-0003 — READOUT NORMALIZATION / moderate / OPEN

**Source origins:** correctly typed hierarchy definition 2730–2742; figure 2780–2783; numerical readout table 3087–3105. The figure and table use `mathcal R_8`, `mathcal R_16` labels (m^-1 by the definition), yet print midpoint-sized values with m^-2 units. With source `U=6.09e68 m^-2`, `alpha=1.571958279122504e17`, independent evaluation yields `mathcal R_8=6.2243e25 m^-1`, `mathcal R_16=1.5699e17 m^-1` versus midpoint `C^B_8=1.5360e60 m^-2`, `C^B_16=3.8741e51 m^-2`. **Checks:** `E4-B02-ROOT-8-NUMERIC-READOUT-MISMATCH`, `E4-B02-ROOT-16-NUMERIC-READOUT-MISMATCH`. **Scope:** affects two numeric readout occurrences, not the correct root definition, midpoint construction or seven-step hierarchy. **Obligation:** make displayed label, value and units consistent; do not change source inside this audit.

### BH-VIA-G-0004 — PHYSICAL-TIME SCALARON NORMALIZATION / moderate / OPEN

**Source:** exact trace restoring equation 4068–4073, WKB corollary 4100–4116. The mass `m_s²=(F-RF_R)/(3F_R)` is formed from curvature derivatives and has units m^-2; the exact linearized `t`-equation includes `c²m_s²`. In the H=0 constant-mass test, `ddot phi+c²m_s² phi=0` requires physical angular frequency `c m_s`, whereas the printed `dot Theta=m_s`, `epsilon_H=H/m_s` and `epsilon_m=|dot m_s|/m_s²` are not typed as SI physical-time relations unless a coherent `c=1` convention is stated. **E4:** `E4-B02-WKB-MISSING-C` (nonzero formal local-equation residual); **positive control:** `E3-B02-WKB-POSITIVE-CONTROL` (`omega=c m_s`). **Scope:** local adiabatic representation and error parameter normalization only. The exact scalaron trace, terminal susceptibility and conditionality of matter-like averaging survive. **Obligation:** demonstrate the units/physical-time convention or derive WKB frequency/small parameters directly from the printed equation; no new damping or mechanism is introduced.

### BH-VIA-G-0005 — WEAK-FIELD POTENTIAL DIMENSIONS / moderate / OPEN

**Source:** PPN theorem 4538–4588, specifically explicit dimensionless `Phi_B=GM_B/(c²r_B)` at 4540–4544 and potential expressions 4564–4573. The terms `GM_B/(F_env r)` and `varrho_env*r²/24` respectively have SI dimensions `L²T^-2` and `1`; their sum cannot define a single potential without a common convention. **E4:** `E4-B02-PPN-DIMENSIONAL-CONFLICT`. **Positive control:** `E3-B02-PPN-GAMMA-ALGEBRA` confirms the separate fractional gamma identity and shows no algebraic error there. **Scope:** potential definition/normalization, not evidence that the framework's coupling function is numerically wrong. **Obligation:** source-state which metric-potential convention is used and reconcile Newton and curvature terms with the explicit `c` in the theorem.

### BH-VIA-G-0006 — THIN-SHELL CHARGE INTEGRATION / moderate / OPEN

**Source:** thin-shell charge definition 4557–4564; proof's `integrating ... through a screened body gives ... charge bounded by the prefactor` at 4590–4602. The source puts the **shell-width proxy** `q=|F_env-F_in|/(2Phi_B)` directly into a charge factor `epsilon_B` that multiplies the universal force strength `2beta²=1/3`. For a standard screened approximately homogeneous sphere with a shell of fractional thickness `q=Delta r/r`, the integrated active mass fraction is `1-(1-q)^3≈3q`, so relative potential coupling is `~q`, not the printed `~q/3`. At `q=0.01` the two are `0.009900333...` and `0.003333333...`; the limiting mismatch factor is three. **E4:** `E4-B02-PPN-THINSHELL-CHARGE-FACTOR3` and `E4-B02-PPN-THINSHELL-CONCRETE`. **Positive control:** at unscreened effective charge 1, universal metric-f(R) relative coupling 1/3 remains consistent. **Scope:** quantitative thin-shell/PPN scalar-charge normalization; not an allegation that a different nonstandard field profile is *forbidden*, only that the fixed-action integration or distinct charge convention needed to justify the source's specific formula is absent. **Obligation:** furnish an existing, source-checkable same-action integrated charge identity at this body/environment domain; do not invent one during audit.

**Earlier issues retained unchanged:** `BH-VIA-G-0001` additive dust response positivity (moderate), `BH-VIA-G-0002` degenerate zero-density sound-speed derivative (minor). No verified cross-paper dependency path has yet been found by which any of the four new first-origin issues defeats a separate manuscript theorem; later interfaces are *possible*, not certified, impacts.

## Conditions, dependency provenance, and independent checks

- The assumption checkpoint retains prior `BH-VIA-A-0001` through `A-0004`. Three further **inferred, not introduced** local normalization/justification conditions were source-anchored as `BH-VIA-A-0005` (WKB physical-time convention), `A-0006` (uniform SI PPN potential convention) and `A-0007` (shell-width to integrated effective charge proof). A globally earliest earlier discharge is not certified; all are recorded `FIRST-KNOWN` rather than creating repeat upstream axioms. No new physical assumption or theory change was approved.
- The typed edge file retains the preceding 21 edges and records 17 additional proposed/reviewed proof-use paths, separating actual local proof uses from source citations, imported proofs, and unresolved physical/normalization paths. A named theorem import, an assumed conditional source-Hamiltonian, and a cited formula do not by themselves furnish full E3 evidence. Paths that fail the explicit label/proof-consumption gate remain quarantined.
- Independent E3 controls include full symbolic lapse/canonical Hessian, Legendre potential difference, terminal curvature relation, scalar force quadratic response, arbitrary quartic jet vertices, closed de-Sitter FLRW, unit-S3 Gram, Schur algebra, FLRW traceless-Ricci traces to degree eight, radiation pressure, and terminal optical time. E4 includes a numeric root-vs-midpoint readout attack, nonzero WKB residual, potential-dimension check, integrated thin-shell factor three and a negative ordinary `a6`-dust claim test. **59/59** executed control predicates pass. This is not a substitute for independent certification of every complex mixed Einstein/Ward/Spectral result.

## Source-level coverage table

The table below includes all 65 named results and their source dispositions. `FORMALIZED` includes correctly scoped readouts and definitions; `REPRODUCED` is a source-proof replay without a complete independent same-domain certificate; `VERIFIED-CONDITIONAL` denotes a fully checked algebraic consequence **under its stated hypotheses**; `UNRESOLVED` isolates a challenged claim substep and does not refute every consequence of that result.

| # | Source lines | Formal object | Disposition | Issue(s) | E3/E4 tests linked |
|---:|---:|---|---|---|---:|
| 53 | 2523–2543 | `p8:def:nR-paper6-resolution-meaning` | FORMALIZED | — | 1 |
| 54 | 2545–2557 | `p8:lem:visibility-monotonicity-band` | VERIFIED-CONDITIONAL | — | 1 |
| 55 | 2563–2586 | `p8:thm:nR-resolution-backed-by-2I-2O` | FORMALIZED | — | 0 |
| 56 | 2597–2611 | `Paper6A:unnamed:remark:2597` | FORMALIZED | — | 1 |
| 57 | 2613–2622 | `p8:rem:v188-octahedral-defect-residue` | FORMALIZED | — | 0 |
| 58 | 2624–2648 | `p8:thm:global-convexity-terminal-freeze` | REPRODUCED | — | 0 |
| 59 | 2660–2670 | `Paper6A:unnamed:remark:2660` | FORMALIZED | — | 0 |
| 60 | 2672–2690 | `p8:thm:positive-heat-tower-a4-nogo` | VERIFIED-CONDITIONAL | — | 3 |
| 61 | 2726–2743 | `p8:rem:v2211-hierarchy-units` | FORMALIZED | — | 3 |
| 62 | 2850–2868 | `p8:prop:global-2I-local-particle-core` | FORMALIZED | — | 0 |
| 63 | 2885–2918 | `p8:cor:paper-vi-platonic-readout-rank-handoff` | FORMALIZED | — | 1 |
| 64 | 2925–2965 | `p8:thm:protected-curvature-squared-shell-clock` | FORMALIZED | — | 2 |
| 65 | 2977–2984 | `Paper6A:unnamed:remark:2977` | FORMALIZED | — | 0 |
| 66 | 2987–3002 | `p8:cor:protected-noncarrier-rungs-K24-K48` | FORMALIZED | — | 0 |
| 67 | 3433–3455 | `p8:prop:bare-legendre-lapse-potential` | VERIFIED-CONDITIONAL | — | 1 |
| 68 | 3478–3495 | `p8:prop:complete-flrw-canonical-constraint` | VERIFIED-CONDITIONAL | — | 2 |
| 69 | 3535–3562 | `p8:cor:conditional-bare-born-legendre` | VERIFIED-CONDITIONAL | — | 2 |
| 70 | 3580–3612 | `p8:cor:sharp-regular-terminal-affine-displacement` | VERIFIED-CONDITIONAL | — | 2 |
| 71 | 3631–3641 | `p8:rem:bare-legendre-terminal-not-active-freeze` | FORMALIZED | — | 0 |
| 72 | 3666–3680 | `p8:rem:v223-cap-status` | FORMALIZED | — | 0 |
| 73 | 3683–3710 | `p8:cor:v288-cap-vacuum-target` | REPRODUCED | — | 1 |
| 74 | 3783–3837 | `p8:thm:v251-exact-nonlinear-scalaron-potential` | REPRODUCED | — | 2 |
| 75 | 3852–3872 | `p8:cor:v251-common-force-numerator` | REPRODUCED | — | 0 |
| 76 | 3874–3917 | `p8:thm:v251-constrained-scalaron-generator` | REPRODUCED | — | 1 |
| 77 | 3934–3960 | `p8:thm:laur27-lower-desitter-root` | REPRODUCED | — | 0 |
| 78 | 3978–4015 | `p8:thm:v2139-lower-stationary-source-response` | REPRODUCED | — | 1 |
| 79 | 4032–4046 | `p8:cor:v2139-terminal-source-susceptibility` | REPRODUCED | — | 0 |
| 80 | 4054–4064 | `p8:rem:v2139-stationary-source-domain` | FORMALIZED | — | 0 |
| 81 | 4066–4091 | `p8:thm:exact-lower-branch-scalaron-oscillator` | REPRODUCED | — | 3 |
| 82 | 4100–4116 | `p8:cor:lower-scalaron-matter-like-average` | UNRESOLVED | 0004 | 2 |
| 83 | 4118–4128 | `p8:cor:v251-positive-trace-downward-work` | REPRODUCED | — | 0 |
| 84 | 4130–4159 | `p8:thm:v251-structural-physical-time-firewall` | FORMALIZED | — | 0 |
| 85 | 4168–4174 | `Paper6A:unnamed:remark:4168` | FORMALIZED | — | 0 |
| 86 | 4176–4218 | `p8:thm:absorbing-spectral-handoff` | REPRODUCED | — | 0 |
| 87 | 4248–4253 | `p8:cor:p3_ir_realized` | FORMALIZED | — | 0 |
| 88 | 4292–4310 | `p8:thm:v199-trace-force-vertices` | VERIFIED-CONDITIONAL | — | 2 |
| 89 | 4323–4342 | `p8:thm:v199-uniform-scalar-mass` | REPRODUCED | — | 1 |
| 90 | 4356–4361 | `p8:cor:v199-hierarchy-vacuum` | FORMALIZED | — | 0 |
| 91 | 4382–4396 | `p8:thm:v202-trace-inverse` | REPRODUCED | — | 0 |
| 92 | 4454–4514 | `p8:prop:smooth-active-positive-coupling-convexity` | REPRODUCED | — | 0 |
| 93 | 4529–4536 | `Paper6A:unnamed:remark:4529` | FORMALIZED | — | 0 |
| 94 | 4538–4588 | `p8:thm:smooth-solar-system-screening-ppn` | UNRESOLVED | 0005, 0006 | 4 |
| 95 | 4605–4620 | `p8:rem:three-scalaron-readouts` | FORMALIZED | — | 0 |
| 96 | 4645–4663 | `p8:lem:v2147-s3-full-scalar-stress-grams` | VERIFIED-CONDITIONAL | — | 1 |
| 97 | 4689–4715 | `p8:thm:v2147-full-scalar-einstein-bulk` | REPRODUCED | — | 0 |
| 98 | 4744–4794 | `p8:thm:v2147-finite-full-metric-source-schur` | REPRODUCED | — | 1 |
| 99 | 4862–4900 | `p8:cor:v2149-functional-source-metric` | REPRODUCED | — | 0 |
| 100 | 4921–4970 | `p8:thm:v2149-guarded-free-metric-ward` | REPRODUCED | — | 2 |
| 101 | 5054–5074 | `p8:thm:v2166-geometry-response-owner` | FORMALIZED | — | 1 |
| 102 | 5085–5104 | `p8:prop:v2166-signed-positive-firewall` | FORMALIZED | — | 0 |
| 103 | 5106–5128 | `p8:thm:v2166-flrw-constraint-rank` | REPRODUCED | — | 0 |
| 104 | 5138–5174 | `p8:prop:v2170-flrw-traceless-ricci-all-orders` | VERIFIED-CONDITIONAL | — | 10 |
| 105 | 5184–5193 | `p8:rem:v2170-flrw-curvature-parity` | FORMALIZED | — | 0 |
| 106 | 5197–5250 | `p8:prop:v2166-six-derivative-scope` | REPRODUCED | — | 2 |
| 107 | 5252–5272 | `p8:prop:v2166-scalaron-schur-port` | REPRODUCED | — | 1 |
| 108 | 5274–5292 | `p8:cor:v2166-k48-terminal-preservation` | FORMALIZED | — | 0 |
| 109 | 5294–5306 | `p8:rem:v2166-generalized-response-frontier` | FORMALIZED | — | 0 |
| 110 | 5315–5347 | `p8:thm:v2167-trace-enthalpy-complete-curvature` | REPRODUCED | — | 2 |
| 111 | 5358–5385 | `p8:cor:v2167-residual-noether-integrability` | REPRODUCED | — | 0 |
| 112 | 5397–5422 | `p8:prop:v2167-a6-no-dust-test` | VERIFIED-CONDITIONAL | — | 3 |
| 113 | 5447–5455 | `Paper6A:unnamed:remark:5447` | FORMALIZED | — | 0 |
| 114 | 5463–5485 | `p8:prop:v2168-terminal-static-optical-delay` | VERIFIED-CONDITIONAL | — | 3 |
| 115 | 5492–5506 | `p8:prop:v2168-de-sitter-qe-zero` | VERIFIED-CONDITIONAL | — | 1 |
| 116 | 5514–5523 | `Paper6A:unnamed:remark:5514` | FORMALIZED | — | 0 |
| 117 | 5524–5532 | `Paper6A:unnamed:remark:5524` | FORMALIZED | — | 0 |

**Nonformal row:** `BH-VIA-U-0001` is the figure/output-table root-coordinate numerical readout and carries G-0003; no correct formal definition was mislabelled as false.

## Machine-readable checkpoint and continuation

`Paper6A-Batch02-ClaimLedger-v1_2.json`: all 357 source claim objects and 117 cumulative reviewed dispositions; `Paper6A-Batch02-GapRegistry-v1_2.json`: six cumulative first-origin issue records; `Paper6A-Batch02-Assumptions-v1_2.json`: local first-known guards; `Paper6A-Batch02-TypedDependencies-v1_2.json`: 38 cumulative typed uses, with quarantines; `Paper6A-Batch02-Coverage-v1_2.json`: named/unnamed scope and status; `Paper6A-Batch02-ExactChecks-v1_2.py/.json`: executable E3/E4 controls and recorded outputs; `Paper6A-AuditProgress-v1_2.json`: durable next-batch pointer.

**Next unread source line: 5534.** After 2 batches, 240/357 named formal source objects and the remaining material unnamed body are not audited. The supplied DAG Atlas v1.113 and ProofChainAudits v1.30 archives remain unchanged; updated latest-only deliverable ZIPs are reserved for the final batch, exactly as requested.
