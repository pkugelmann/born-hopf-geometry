#!/usr/bin/env python3
"""Paper VI-A Batch 6: independent E3 numerical/algebraic and E4 adversarial controls.
Source: Paper6A-GravityCosmology-v2_253.tex:14550-17251.
The controls certify only named subclaims; conditional physical occurrence is NOT certified.
No external network. Python+numpy+scipy used for numerical quadrature.
"""
import math,json,os
from scipy.integrate import quad
from scipy.optimize import brentq
import numpy as np
from datetime import datetime,timezone
out=[]
A = 4*math.pi**2+1/(6*math.sqrt(2))
alpha=math.exp(A)
U=1.0
Q=8*math.exp(A/2)
C=lambda j:math.exp(-j*A)
C7=C(7)
Rh=math.exp(-A/2)
R8=Rh
R0=4*math.pi**2/Q

def check(id, cond, witness, source, typ='E3'):
    passed=bool(cond)
    out.append({'id':'E'+typ[1]+'-B06-'+id,'evidence_class':typ,'passed':passed,'witness':witness,'source':f'Paper6A-GravityCosmology-v2_253.tex:{source}'})
    if not passed:
        raise AssertionError(f'{id}: {witness}')

def close(x,y,rtol=2e-9,atol=1e-22):return abs(x-y)<=atol+rtol*max(abs(x),abs(y))

# Terminal selectors, phase support, geometry and causal reach, §§14598–14928.
check('01-floor-sel',max(C7,0)==C7,'max(C7,0)=C7','14605-14614')
check('02-selector-detached',max(0.0*C7,0.0)==0.0,'zeta=0, R_env=0 implies R_sel=0','14641-14654')
check('03-selector-attached',max(1.0*C7,0.0)==C7,'zeta=1, R_env=0 implies R_sel=C7','14641-14654')
check('04-round-s3-volume',close(2*math.pi*(math.pi-math.sin(math.pi)*math.cos(math.pi)),2*math.pi**2),'S3 geodesic-ball volume at radius pi = 2pi²','14902-14910')
eps=1e-3
Vs3=2*math.pi*(eps-math.sin(eps)*math.cos(eps))
check('05-small-ball-asymptotic',abs(Vs3/((4*math.pi/3)*eps**3)-1)<5e-7, f'V(eps)/((4pi/3)eps^3)={Vs3/((4*math.pi/3)*eps**3):.10f}','14902-14910')
check('06-future-null-reach',close(1/(2*math.exp(2)),math.exp(-2)/2), 'for a(t)=exp(2t), c_op=1, integral_1∞dt/a=e^-2/2','14882-14891')
check('07-finite-ball-complement', 8*(4*math.pi/3)*(1e-4)**3<2*math.pi**2,'8 balls radius 1e-4 have total volume < volume S³','14902-14914')
check('08-asymptotic-not-exact-algebra',np.linalg.matrix_rank(np.array([[1,1e-8],[1,-1e-8]],dtype=float))==2,'I and exp(-t) σz span nonscalar algebra at finite t even if amplitude -> 0','14916-14923','E4')

# Raw Laurent and dressed cap, §§14986–15080.
def sec(q,j):
    if abs(q)<1e-9:return math.tanh(j*A/2)
    # stable logcosh
    lc=lambda x:abs(x)+math.log1p(math.exp(-2*abs(x)))-math.log(2)
    return (lc(j*A/2)-lc((j/2-q)*A))/(q*A)
check('09-laurent-c7-zero',abs(sec(7,7))<1e-12,f'n7(q=7)={sec(7,7)}','15009-15023')
check('10-laurent-rank2-to-minus1',abs(sec(200,2)+1)<0.02,f'n2(q=200)={sec(200,2):.8f}','15009-15023')
check('11-laurent-rank7-to-minus1',abs(sec(2000,7)+1)<0.005,f'n7(q=2000)={sec(2000,7):.8f}','15009-15023')
check('12-positive-part-nonnegative',all(max(sec(q,7),0)>=0 for q in np.linspace(0.1,10,40)),'max(nL,0)>=0 on q=0.1..10','14989-15004')
check('13-primitive-cap',close((1e-50)**2+C7,C7),f'Qcap(varrho→0)=UC7={C7:g}','15028-15032')
check('14-dressed-cap',close(C7/Q,(C7)/Q),f'raw cap dressed value UC7/Q={C7/Q:g}','15033-15051')
check('15-rankreset-density',close((U**2*C7)/C7,U**2), 'I56=U²exp(-7A) maps to I0=U² by q reset','15148-15175')
check('16-dressed-reset-factor',close((U**2*C7/Q)/(C7),U**2/Q),'q reset removes only alpha^-7, retains Q^-1','15166-15175')

# Hopf, Planck, bounce and lineage boundary, §§15258–15595.
check('17-product-residue',close((2*math.pi)**2,4*math.pi**2),'(2pi)(2pi)=4pi²','15264-15282')
check('18-hopf-multiplier',close(4*math.pi**2*(U**2/Q),4*math.pi**2/Q),'cyclic density 4pi² U²/Q','15292-15305')
lP=1/math.sqrt(2*math.pi*U)
check('19-planck-curvsq',close(4*math.pi**2*U**2,lP**(-4)),'U=1/(2pi lP²), 4pi²U²=lP^-4','15335-15353')
check('20-cyclic-curvature',close(R0,2*math.pi/Q/lP**2),f'R0={R0:g}=2pi lP^-2/Q','15356-15361')
check('21-curvature-root-r8-ratio',close(R0/R8,math.pi**2/2),f'R0/R8={R0/R8:.10f}=pi²/2','15519-15525')
check('22-r8-greater-c2',R8>C(2),'R8=exp(-A/2)>C2=exp(-2A)','15506-15510')
check('23-root-less-than-u',0<R0<U,f'R0/U={R0:.10g} within (0,1)','15523-15526')
check('24-flrw-h0-constraint',close(3*(1.4)*((1.4*0.7-0.4)/(6*1.4)),(1.4*0.7-0.4)/2),'3F a^-2=(FR-f)/2 with F=1.4,R=.7,f=.4','15445-15459')
check('25-flrw-bounce-sign', 0.4/(6*1.4)>0,'dot H0=c²f/(6F)>0 for positive F,f','15445-15464')
check('26-no-source-nonzero-momenta', not (0.1==0.0),'source-free mechanical initial data can have nonzero momentum; absence of impulse alone not zero-cotangent','15403-15415','E4')

# Restored scalaron and K48 forcing, §§15519–16343.
check('27-stieltjes-integral-sign',C(2)>C(6)>C(7),'strict shell order C2>C6>C7','16276-16304')
check('28-k48-force-lower',all((x-2*C7-2*x*(x-C7))>0 for x in np.geomspace(C(6),C(2),60)),'B/U lower bound positive on C6≤x≤C2','16290-16304')
check('29-n-bound',close(1-7.257e-7,0.9999992743),'quoted decimal N bound is algebraically consistent','15529-15536')
check('30-root-energy-constant',abs((2*(Q*C7+16*math.pi**4)/(1+1.97901*4*math.pi**2)**2)-0.49783689597)<8e-6,'c0 reproduces printed 0.49783689597 to rounding of 1.97901','16352-16381')
check('31-root-energy-below-half',2*(Q*C7+16*math.pi**4)/(1+1.97901*4*math.pi**2)**2<.5,'c0<0.5','16352-16381')
check('32-root-to-late-ratio',close(C7/U,alpha**-7), 'C56/C0=alpha^-7','15754-15781')
check('33-k48-underdamping-mass', (1-2*C(6))>0,'m_s² lower bound U/6(1−2 exp(-6A)) positive','16312-16326')

# Corner energy and conditional dust/radiation separatrix, §§16468–16727.
M2=1.0; d=1e-3; Cfixed=0.1; aC=2.0
Hm=-0.03;Hp=Hm+d/2
rhom=3*M2*(Hm**2+1/aC**2)-M2*Cfixed/2+3*M2*Hm*d
rhop=3*M2*(Hp**2+1/aC**2)-M2*Cfixed/2
check('34-corner-momentum',close(Hp,Hm+d/2), 'canonical momentum matching H+=H-+d/2','16468-16504')
check('35-corner-energy',close(rhop-rhom,3*M2*d*d/4,rtol=1e-8),f'Δrho={rhop-rhom:.12g}=3M²d²/4','16488-16504')
check('36-corner-finite-state',d*d>0,'no zero-duration continuous-source jump can realize positive Δrho for d≠0','16468-16504','E4')
check('37-dust-qeta-x1',close((Cfixed/6)*1**4-0.1*1**2+0.3*.2*1+0.3*(1-.2),Cfixed/6-.1+.3), 'Qη(1) independent of η','16663-16712')
check('38-dust-monotone-eta',0.3*(3.0-1)>0,'∂ηQη(x)=D(x−1)>0 for future x=3','16677-16704')
X=math.sqrt(2*0.1/0.2); eps_=0.3*0.2/(2*0.1**2); z=0.8; eta_=(2*z-4*z**3/3)/(eps_*X); x_=z*X
check('39-dust-double-root-derivative',close((2*0.2/3)*x_**3-2*0.1*x_+0.3*eta_,0,rtol=1e-9,atol=1e-13), 'separatrix eta(z) solves derivative Qeta-prime(x)=0', '16692-16710')

# Candidate-independent potential-end roots, §§16769–16957.
def chi_q(q,j):
    # dimensionless U=1, C/U=exp(-7A), using native Laurent secants
    rr=math.exp(-q*A)
    n=max(0.,sec(q,j));n7=max(0.,sec(q,7))
    return math.exp(math.log(Q)*n)*(1+n7)/(1+C7)*(1-(C7/rr)**2)
def FP(q,j):
    # quad over q in [q,7] with dr/dq=-A exp(-qA)
    nodes=sorted(set([q]+[t for t in [0.5,1.,2.,3.,4.,5.,6.,7.] if q<t<7]+[7.]))
    def integ(power):
        total=0.
        for lo,hi in zip(nodes[:-1],nodes[1:]):
            seg,_=quad(lambda s:chi_q(s,j)*A*math.exp(-s*A*(1+power)),lo,hi,epsabs=1e-19,epsrel=4e-10,limit=100)
            total+=seg
        return total
    return 1+integ(0), C7+integ(1)
roots={}
for j in [1,2,3,4]:
    def ye(q):
        F,P=FP(q,j)
        return (math.exp(-q*A)*F-2*P)/P
    root=brentq(lambda q:ye(q)-math.sqrt(3),0.5,1,xtol=3e-13)
    roots[str(j)]=root
    check(f'{39+j:02d}-potential-end-depth-{j}',0.5<root<1 and abs(ye(root)-math.sqrt(3))<2e-6,
          f'j={j} potential end q={root:.9f}, epsilonV=1', '16795-16908')

# Coefficient work identity and subclaim of TT discrimination.
check('44-native-source-energy',close(sum([.2,1.5])*1,1.7),'coefficient-frame energy Tr(rho H)=Σqj Tr(rho Dj) for dual frame=I','17003-17027')

assert len(out)==44,len(out)
print('A',A,'Q',Q,'R0',R0,'roots',roots)
result={'metadata':{'paper':'Paper6A','batch':6,'source':'Paper6A-GravityCosmology-v2_253.tex','lines':[14550,17251],
 'independent_exact_control_scope':'Specific local algebra/numerical subclaims only; physical occurrence not independently established',
 'native_A':A,'native_Q':Q,'calculated_potential_end_roots':roots,'method':'E3 independent computation + E4 adversarial constructive witnesses'},
 'checks':out,'passed':sum(x['passed'] for x in out),'failed':sum(not x['passed'] for x in out),'total':len(out)}
path=os.path.join(os.path.dirname(__file__),'Paper6A-Batch06-ExactChecks-v1_6.json')
with open(path,'w') as f:json.dump(result,f,indent=2)
print('PASS',result['passed'],'/',result['total'],'results',path)
