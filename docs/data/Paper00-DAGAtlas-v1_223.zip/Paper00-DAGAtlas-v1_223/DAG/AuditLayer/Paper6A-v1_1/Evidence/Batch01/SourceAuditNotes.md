# Born–Hopf Geometry VI-A — rigorous verification DAG audit, Batch 1

**Manuscript:** `Paper6A-GravityCosmology-v2_253.tex` — authoritative corpus `Paper00-PapersMinimal-v2_371`.  
**Source SHA-256:** `3110e5c951b395665f54a2a910dd6e3570eb9659e775d3b0b4128e6fe28a82d1`.  
**Protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4`.  
**Baseline:** `Paper00-DAGAtlas-v1_113`; `Paper00-ProofChainAudits-v1_30`.  
**Audit state:** **PARTIALLY_AUDITED, WITH OPEN GAPS**, first batch only, not a full Paper VI-A certificate.  
**Batch:** source lines **1–2514** of **17251**, **52/357** formal results/remarks inventoried and assigned source-bound dispositions (**305** remain in future batches).  
**Formal status counts:** {'FORMALIZED': 18, 'REPRODUCED': 19, 'VERIFIED-CONDITIONAL': 14, 'UNRESOLVED': 1}.  
**Proof environments directly paired with these 52 objects:** 25.  
**Independent symbolic/numerical E3 and adversarial E4 control predicates:** **48/48 passed**, including two positive counterexample detections; these are *subclaim controls*, not 48 independent complete-theorem certifications.  
**Independent agents:** none; distinct analytic/symbolic/adversarial methods were used but not represented as independent agents.

## Findings — all batch-1 new root issues

### BH-VIA-G-0001 — MISSING_CONDITION / moderate / open
**Root:** `p8:thm:k48-conditional-exact-dust`, Paper6A-GravityCosmology-v2_253.tex:2142–2149, proof:2183–2186.  
**Claimed:** from continuous additive `F:[0,∞)→ℝ` and `F(0)=0` infer `F(ζ)=μζ` with **μ≥0**.  
**Valid:** the Cauchy equation gives `μ∈ℝ`.  
**E4 counterexample:** `F(ζ)=-ζ` is continuous, additive and vanishes at zero but has `μ=-1`. The same theorem's `λ_D≥0` does *not* constrain the sign of `F`.  
**E4 positive control:** `F(ζ)=+ζ` satisfies the premises with `μ=+1`.  
**Missing condition candidate:** `BH-VIA-A-0003` represents the unproved positivity premise, not a newly introduced physical axiom.  
**Impact:** only the sign conclusion is defeated; pressure `p=0`, terminal `a^-3` dilution and the neutral geometric-current normalization remain algebraically valid. No verified failure path to Paper VI-B's optional dust theorem: its current source formulation does not claim nonnegative μ.  
**Obligation:** locate prior exact positivity discharge, or qualify the printed sign claim; **no repair is made**.

### BH-VIA-G-0002 — TYPE_OR_DOMAIN / MISSING_CONDITION / minor / open
**Root:** the same theorem, Paper6A-GravityCosmology-v2_253.tex:2149–2157, proof:2184–2186.  
**Claimed:** `c_s²=dp/dF=0` for every admitted linear additive `F(ζ)=μζ`, with `μ≥0`.  
**E4 degenerate witness:** `F(ζ)≡0`, `μ=0`, `λ_D=1`; then `dp/dζ=dF/dζ=0`, and `dp/dF=0/0` is undefined as a derivative on the identically zero energy-density response. The limiting assignment from `μ>0` is zero but is an extra convention.  
**Positive control:** for `μ>0` the adiabatic zero-sound-speed law is well defined.  
**Missing branch guard:** `BH-VIA-A-0004`; no new physical hypothesis is inserted.  
**Impact:** only the degenerate sound-speed subclaim; it does not invalidate the neutral current, current conservation, pressure identity, or positive-μ nondegenerate dust response. No verified remote failed consumer.

## Independently checked source results, and what is **not** proved

* **Positive-chart comparison, lines 259–388:** exact grade-four ratio `D₄(C₂)/Q=0.825729956674…` at `REG₀`; one-sided `C₄` derivative-jump identity and grade-four threshold; conditional quadratic scalaron trace and potential. The grade-four historical `n₄|n₇` and depth-two `n₂|n₇` curves are *not* the current capped working action. The older III-D coefficient-owner certification issue is inherited, not duplicated.
* **Action/source variation, lines 389–979:** independent lapse derivative for closed FLRW, finite-source continuity and the scalar-coordinate Einstein coefficient `ħcU/8`; no automatic physical `CELL`, `PQTI`, `MASS_UV`, `MATCH_J/scal`, or equality `P=U` was claimed. The numerical `N=56` inflation replay is not E3-certified in this batch and is correctly restricted to the historical comparison branch.
* **Geometric scalar harmonics, lines 1590–1671:** `H₆` harmonic/axis nonzero check, horizontal conformality of Hopf lift and S³ eigenvalues 168, 440, 960 for degrees 12, 20, 30. These do not imply occupied physical fluctuation modes.
* **Hierarchy and K48 structure, lines 1690–2190:** independently checked six finite semigroup crossing times, seventh limit, `j↔8−j` reflection, trace-versus-projector distinction, scheme-uniform final-octet complement, Hopf-fiber integration and neutral Hodge dilution. Physical curvature-source stress, actual crossing/history, conversion `μλ_D` and observed dark-matter normalization remain **explicitly conditional**, not audit errors.
* **Event predicates and reciprocal position, lines 2205–2514:** the typed event criterion, Born midpoint `K_R=8j`, exact `K16` coefficient derivative and fixed harmonic-band stabilization. Physical event labels, time-to-resolution history and radius calibration are not silently identified with scalar structural depth.

## Imported proof/use interfaces checked

Cross-paper proof-use checks include current Paper III-C `p3c:thm:protected-octet-trace-reflection` and `p3c:thm:active-depth-six-obstruction`, III-F's sharp harmonic-band activation, III-A's unique-solution-history **conditional** descent, Paper I-A's Hopf normalization, and Paper I-B's finite scalar-unit/unital-map providers. All are stage-scope imports only, not re-audits of those manuscripts. Some parent-action and full metric-source claims remain earlier registered conditional obligations. A citation is not a material proof edge; the checkpoint typed-edge ledger marks explicit source-use witnesses and quarantines unstated positivity/nondegeneracy guards.

## Machine-readable checkpoint and continuation boundary

`Paper6A-Batch01-ClaimLedger-v1_1.json`: full 357-formal-object source census, exact claims/proofs and 52 batch dispositions.  
`Paper6A-Batch01-Assumptions-v1_1.json`: first-known assumptions and source-missing inferred guards, no duplicated upstream constitutional nodes.  
`Paper6A-Batch01-GapRegistry-v1_1.json`: two first-origin issue records with same-domain counterexamples, controls, scoped impacts.  
`Paper6A-Batch01-TypedDependencies-v1_1.json`: reviewed typed source-use edges and guarded nonpromoting candidates.  
`Paper6A-Batch01-ExactChecks-v1_1.py/.json`: executable exact-control reproducibility.  
`Paper6A-Batch01-Coverage-v1_1.json`: complete formal inventory, calculation slices, status/gate limitations.  
`Paper6A-AuditProgress-v1_1.json`: persistent batch continuation.  
**Next batch starts at line 2515**, before the `n_R` scalar resolution-readout section at line 2523.  
**Archive release:** the user designated the **last batch** for the updated full DAG ZIP and ProofChainAudits ZIP. Neither final archive is produced or claimed complete in Batch 1. The supplied archives and all `.tex` sources are unchanged.

## Batch-1 per-result disposition ledger

| # | Source lines | Result/remark | Status | E3/E4 control count |
|---:|---|---|---|---:|
| 1 | 108–131 | `p8:rem:v2211-cell-pqti-scope` | FORMALIZED | 0 |
| 2 | 224–240 | `p8:cor:v273-structural-boundary-interface-status` | REPRODUCED | 0 |
| 3 | 273–296 | `p8:thm:v2219-active-dressing` | REPRODUCED | 3 |
| 4 | 299–340 | `p8:cor:v287-grade-four-same-action-onset` | VERIFIED-CONDITIONAL | 3 |
| 5 | 363–388 | `p8:thm:v2219-closed-uv-oscillator` | REPRODUCED | 2 |
| 6 | 389–408 | `p8:prop:v2219-particle-work` | REPRODUCED | 1 |
| 7 | 409–418 | `Paper6A:unnamed:remark:409` | FORMALIZED | 0 |
| 8 | 419–442 | `p8:thm:v2219-n4-inflation-replay` | FORMALIZED | 0 |
| 9 | 443–451 | `Paper6A:unnamed:remark:443` | FORMALIZED | 0 |
| 10 | 452–465 | `Paper6A:unnamed:remark:452` | FORMALIZED | 0 |
| 11 | 526–588 | `p8:rem:compressed-residual-status-through-ix` | FORMALIZED | 0 |
| 12 | 600–631 | `p8:cor:v2171-inherited-variational-closure` | REPRODUCED | 1 |
| 13 | 727–746 | `p8:cor:v2124-native-cyclic-ren0-retirement` | REPRODUCED | 0 |
| 14 | 780–806 | `p8:lem:compact-boundary-source-separation` | REPRODUCED | 0 |
| 15 | 818–861 | `p8:thm:reciprocal-position-source-normalization` | REPRODUCED | 2 |
| 16 | 919–932 | `p8:cor:reciprocal-position-source-conservation` | REPRODUCED | 0 |
| 17 | 944–968 | `p8:cor:sector-source-status-paper3-import` | REPRODUCED | 0 |
| 18 | 981–991 | `p8:rem:low-curvature-levi-civita-channel` | FORMALIZED | 0 |
| 19 | 993–1000 | `p8:rem:no-downstream-shell-count-use` | FORMALIZED | 0 |
| 20 | 1031–1148 | `p8:thm:complementary-laurent-action` | REPRODUCED | 1 |
| 21 | 1150–1186 | `p8:cor:rank-one-exit-k16-density` | REPRODUCED | 1 |
| 22 | 1197–1210 | `p8:rem:n7-rar-owner` | FORMALIZED | 0 |
| 23 | 1212–1241 | `p8:thm:linear-trace-susceptibility` | REPRODUCED | 1 |
| 24 | 1255–1262 | `p8:rem:smooth-mresp-comparison-status` | FORMALIZED | 0 |
| 25 | 1334–1359 | `p8:rem:p3-contact-residue-interface` | FORMALIZED | 0 |
| 26 | 1361–1371 | `p8:rem:q4-flat-cone-cosmology-scope` | FORMALIZED | 0 |
| 27 | 1398–1401 | `p8:thm:first-gravitational-closure-boundary` | REPRODUCED | 0 |
| 28 | 1601–1623 | `p6a:prop:v322-petersen-k12` | VERIFIED-CONDITIONAL | 3 |
| 29 | 1636–1645 | `p6a:cor:v322-primitive-tower` | REPRODUCED | 1 |
| 30 | 1647–1657 | `p6a:cor:v322-reciprocal-sextic` | REPRODUCED | 0 |
| 31 | 1659–1671 | `p6a:rem:v322-action-firewall` | FORMALIZED | 0 |
| 32 | 1715–1746 | `p8:thm:homogeneous-seven-resolution-landmarks` | VERIFIED-CONDITIONAL | 7 |
| 33 | 1759–1804 | `p8:cor:closed-flrw-octet-reflection` | VERIFIED-CONDITIONAL | 2 |
| 34 | 1822–1875 | `p8:thm:k48-final-octet-curvature-complement` | VERIFIED-CONDITIONAL | 1 |
| 35 | 1892–1936 | `p8:cor:final-octet-primitive-remnant-depletion` | VERIFIED-CONDITIONAL | 2 |
| 36 | 1956–2003 | `p8:thm:final-octet-canonical-hopf-descent` | VERIFIED-CONDITIONAL | 1 |
| 37 | 2026–2073 | `p8:thm:final-octet-flrw-hodge-dilution` | VERIFIED-CONDITIONAL | 2 |
| 38 | 2084–2104 | `p8:cor:k48-transverse-curvature-crossing` | VERIFIED-CONDITIONAL | 1 |
| 39 | 2113–2124 | `p8:cor:k48-crossing-history-descendant` | REPRODUCED | 0 |
| 40 | 2126–2178 | `p8:thm:k48-conditional-exact-dust` | UNRESOLVED | 4 |
| 41 | 2192–2203 | `p8:rem:k48-isocurvature-scope` | FORMALIZED | 0 |
| 42 | 2205–2222 | `p8:def:typed-hierarchy-event-predicate` | FORMALIZED | 0 |
| 43 | 2224–2241 | `p8:thm:typed-hierarchy-event-identification` | VERIFIED-CONDITIONAL | 7 |
| 44 | 2254–2266 | `p8:cor:typed-event-born-midpoint-curvature` | VERIFIED-CONDITIONAL | 6 |
| 45 | 2268–2287 | `p8:cor:derived-k16-coefficient-freeze-event` | VERIFIED-CONDITIONAL | 1 |
| 46 | 2289–2304 | `p8:rem:typed-seven-event-ledger` | FORMALIZED | 0 |
| 47 | 2306–2329 | `p8:thm:cosmological-dm-depth-firewall` | REPRODUCED | 0 |
| 48 | 2338–2348 | `p8:rem:71456` | FORMALIZED | 0 |
| 49 | 2350–2373 | `p8:def:cosmological-position-unfolding` | FORMALIZED | 0 |
| 50 | 2375–2412 | `p8:prop:large-mx-smooth-limit` | VERIFIED-CONDITIONAL | 4 |
| 51 | 2436–2478 | `p8:thm:unique-position-remnant-line` | VERIFIED-CONDITIONAL | 1 |
| 52 | 2494–2504 | `p8:cor:v233-stage-history-specialization` | REPRODUCED | 0 |

Only the listed source scope has been checked. The pending 305 formal objects and material unnamed equations remain **not audited** until subsequent batches.
