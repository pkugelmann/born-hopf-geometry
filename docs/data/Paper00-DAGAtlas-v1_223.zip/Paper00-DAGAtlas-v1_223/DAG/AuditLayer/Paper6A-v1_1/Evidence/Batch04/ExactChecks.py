#!/usr/bin/env python3
"""VI-A Batch 4: source-matched local independent controls; includes adversarial predicates.
No paper modifications, new physical laws, or full-theorem verification claims.
"""
from pathlib import Path
import math, json, hashlib
import sympy as s
import numpy as np
from scipy import constants as const

root=Path('/mnt/data/BornHopf6A_Work')
source=root/'current/Paper00-PapersMinimal-v2_371/Paper6A-GravityCosmology-v2_253.tex'
assert len(source.read_text().splitlines())==17251
assert hashlib.sha256(source.read_bytes()).hexdigest()=='3110e5c951b395665f54a2a910dd6e3570eb9659e775d3b0b4128e6fe28a82d1'
rows=[]
def verify(tag, condition, actual, expected, locator, level='E3', scope='Local scoped mathematical/numerical control, not global theorem certification'):
    yes=bool(condition)
    rows.append({'id':f'{level}-B04-{tag}', 'level':level, 'passed':yes, 'actual':str(actual), 'expected':str(expected), 'source_locator':f'6A:{locator}', 'scope':scope})
    if not yes: print('FAILED',tag,'actual=',actual,'expected=',expected)
    return yes

def eq(x,y=0): return s.simplify(x-y)==0
K, U, alpha, C, R, I = s.symbols('K U alpha C R I', positive=True, real=True)
rho=(16-K)/8
eta=(K-8)/(24-K)
verify('REH-CAYLEY',eq((1-rho)/(1+rho),eta), (1-rho)/(1+rho), eta, '9064-9079')
verify('REH-ENDPOINTS',eta.subs(K,8)==0 and eta.subs(K,16)==1,(eta.subs(K,8),eta.subs(K,16)),'(0,1)', '9069-9088')
verify('REH-RESIDUAL-ENDPOINTS',rho.subs(K,8)==1 and rho.subs(K,16)==0,(rho.subs(K,8),rho.subs(K,16)),'(1,0)','9064-9073')
verify('REH-DERIVATIVE',eq(s.diff(eta,K),(1+eta)**2/16),s.diff(eta,K),'(1+eta)^2/16','9074-9085')
verify('REH-CELL-FLUX',eq(s.integrate(s.diff(eta,K),(K,8,16)),1),'int_8^16 d eta/dK dK',1,'9081-9088')
C1=U/alpha;C2=U/alpha**2
verify('REH-OWNER-C1',eq(C1**2,U*C2),C1**2,U*C2,'9045-9062')
verify('REH-OWNER-SCALE',eq(s.sqrt(U*C2),U/alpha),s.sqrt(U*C2),U/alpha,'9045-9062')
Ke=s.symbols('Ke',positive=True)
rho_cond=(16-K)/(16-Ke)
eta_cond=(K-Ke)/(32-K-Ke)
verify('REH-CONDITIONED-CAYLEY',eq((1-rho_cond)/(1+rho_cond),eta_cond),(1-rho_cond)/(1+rho_cond),eta_cond,'9592-9623')
verify('REH-CONDITIONED-ENDPOINT',eq(eta_cond.subs(K,Ke)) and eq(eta_cond.subs(K,16),1),eta_cond.subs(K,Ke),'0 at Ke,1 at 16','9592-9623')
verify('REH-CONDITIONED-DERIV',eq(s.diff(eta_cond,K),(1+eta_cond)**2/(2*(16-Ke))),s.diff(eta_cond,K),'(1+eta)^2/[2(16-Ke)]','9625-9641')
verify('REH-CAYLEY-COMPOSE',eq((eta-eta.subs(K,Ke))/(1-eta*eta.subs(K,Ke)),eta_cond),(eta-eta.subs(K,Ke))/(1-eta*eta.subs(K,Ke)),eta_cond,'9625-9640')
verify('K24-CANDIDATE-ENDPOINTS',eq(((K-16)/(32-K)).subs(K,16)) and eq(((K-16)/(32-K)).subs(K,24),1),'K16:0,K24:1','(0,1)','9280-9297',level='E2')
# K8-K16 physical metric conversions are independent of arbitrary source-sector state.
alpha_si=math.exp((2*math.pi)**2+1/(6*math.sqrt(2)))
U_si=const.c**3/(2*math.pi*const.hbar*const.G)
GeV_per_inv_m=const.hbar*const.c/(1e9*const.e)
gstar=427/4
E16=math.sqrt(U_si/alpha_si)*GeV_per_inv_m
T16=(30/(math.pi**2*gstar))**.25*E16
Hstat=math.sqrt(4*U_si/(3*alpha_si**2))*GeV_per_inv_m
verify('REH-TEMP-SI',abs(T16/5.045705e9-1)<.001,T16,5.045705e9,'9242-9260,3308')
verify('REH-HUBBLE-BOUND-SI',abs(Hstat/35.7732-1)<.001,Hstat,35.7732,'9221-9240,3059-3069')
verify('REH-KINETIC-THRESHOLD',abs(Hstat/T16-7.09e-9)<1e-11,Hstat/T16,7.09e-9,'9242-9265')
verify('REH-XI-UPPER-BOUND',all(0<math.exp(-4*x)<=1 for x in (0,1e-9,1e-5,1e-1,1)),'exp[-4DeltaN] for DeltaN>=0','in (0,1]','9093-9112',level='E2',scope='Conditional upper bound only; not an independent proof of the quoted first-descent numerical lower bound.')
verify('K32-CURVATURE-LENGTH',eq((U/alpha**4)*(alpha**2/s.sqrt(U))**2,1),'C4*L32²',1,'9700-9722')
verify('K32-UNIT-SCALE',eq(U*(alpha**2/s.sqrt(U))**2,alpha**4),'U*L32²','alpha^4','9700-9722')
verify('K32-METROLOGY',abs(alpha_si**2/math.sqrt(U_si)-1)<.01,alpha_si**2/math.sqrt(U_si),'about 1m','9724-9732')
# Retained scalaron same-action slow component and stationary shape; no assumption of occurrence from these identities.
chi=s.Function('chi')(R)
F=s.Function('F')(R)
f=s.Function('f')(R)
# Derivative only on source-defined relation F_R=chi and f_R=F.
B=2*f-R*F
Bprime=s.diff(B,R).subs(s.diff(f,R),F).subs(s.diff(F,R),chi)
verify('SCALARON-BPRIME',eq(Bprime,F-R*chi),Bprime,F-R*chi,'9114-9159,3942-3955')
m2=(F-R*chi)/(3*chi)
verify('SCALARON-SLOW-DS',eq(chi/Bprime,1/(3*m2)),chi/Bprime,1/(3*m2),'9162-9187')
chiv=s.symbols('chi0',positive=True)
Bref=R-2*C-chiv*C*(R-C)
verify('SCALARON-B2C-NEGATIVE',eq(Bref.subs(R,2*C),-chiv*C*C),Bref.subs(R,2*C),'-chi*C²<0','9114-9159',level='E3',scope='Independent admissible constant-positive-chi toy on a bounded branch; sign proof is general by the integral kernel.')
verify('SCALARON-B-BOUND',eq(s.integrate(R-2*s.Symbol('u'),(s.Symbol('u'),C,R)),C*(C-R)),s.integrate(R-2*s.Symbol('u'),(s.Symbol('u'),C,R)), 'C(C-R)','9129-9150')
Fbar=s.Function('Fbar')(s.symbols('t',real=True));dF=s.Function('dF')(s.symbols('t',real=True));tt=s.symbols('t',real=True)
HH=s.Function('H')(tt);W=s.Function('W');Ftotal=Fbar+dF
verify('SCALARON-SPLIT-DRIVE',eq(s.diff(Ftotal,tt,2)+3*HH*s.diff(Ftotal,tt)+W(Ftotal)-W(Fbar)-(s.diff(dF,tt,2)+3*HH*s.diff(dF,tt)+W(Ftotal)-W(Fbar)+s.diff(Fbar,tt,2)+3*HH*s.diff(Fbar,tt))), 'F=Fbar+dF residual', 'exact forced oscillator','9162-9187')
# Clean nontrivial stationary Schur identity
A,Bmat,D,Cmat=s.symbols('A B D Cmat',real=True,nonzero=True)
Q=s.Matrix([[A,Bmat],[D,Cmat]])
verify('K48-SCHUR-BLOCK',eq(Q[0,0]-Q[0,1]*Q[1,0]/Q[1,1],A-Bmat*D/Cmat),'Schur complement','A-BCD^-1','10185-10215')
verify('K48-SCHUR-ZERO',eq((Bmat*D/Cmat).subs(Bmat,0),0),'B=0 => Schur decrement=0',0,'10454-10479')
# 24-cell eigenchannel, including E4 test of omitted unit-channel factor.
spectrum=[s.Integer(1),s.Rational(1,2),s.Integer(0),-s.Rational(1,4),-s.Rational(1,2)]
mult=[1,4,9,8,2]
verify('HURWITZ-SPECTRUM-COUNT',sum(mult)==24,sum(mult),24,'9851-9884')
verify('HURWITZ-SPECTRUM-TRACE',sum(x*n for x,n in zip(spectrum,mult))==0,sum(x*n for x,n in zip(spectrum,mult)),0,'9851-9884')
verify('HURWITZ-ZERO-SECTOR',all((spectrum[2]**n)==0 for n in range(1,5)),[spectrum[2]**n for n in range(1,5)],'zero for all n>=1','9879-9883')
verify('HURWITZ-OMITTED-CONSTANT',all(spectrum[0]**n==1 and 1 not in [float(spectrum[i]**n) for i in (1,3,4)] for n in range(1,5)),
       'T^n e_const=e_const; missing 1^n invariant channel','only factors {2^-n,(-1/4)^n,(-1/2)^n} printed','9873-9883','E4',scope='The printed only-factor list omits the invariant sector for an unqualified shell component; if a mean-zero projection was intended, it must be stated. The full spectrum and null-channel claim are correct.')
verify('HURWITZ-POSCTRL-MEAN-ZERO',all(spectrum[i] in (s.Rational(1,2),-s.Rational(1,4),-s.Rational(1,2)) for i in (1,3,4)), 'nontrivial nonzero eigenchannels', 'printed three factors','9873-9883')
# Independent D4/Hurwitz 24-cell adjacency replay: test against actual geometry, not source-reported eigenvalue text alone.
from itertools import product
roots=[]
for i in range(4):
    for sign in (-1.,1.):
        q=[0.]*4;q[i]=sign;roots.append(q)
roots += [list(q) for q in product((-.5,.5), repeat=4)]
roots=np.array(roots,float); assert roots.shape==(24,4)
A24=np.isclose(roots@roots.T,.5,atol=1e-12).astype(float)
T24=A24/8.
verify('HURWITZ-NEIGHBOUR-COUNTS', np.all(np.sum(A24,axis=1)==8),np.unique(np.sum(A24,axis=1)), '8 nearest neighbours per vertex','9851-9884')
vals=np.linalg.eigvalsh(T24)
clusters=[int(np.sum(np.isclose(vals,float(e),atol=1e-10))) for e in spectrum]
verify('HURWITZ-GEOMETRIC-EIGENSPECTRUM',clusters==mult,clusters,mult,'9851-9884')
unit=np.ones((24,),float)
verify('HURWITZ-CONSTANT-WITNESS',np.max(np.abs(np.linalg.matrix_power(T24,3)@unit-unit))<1e-12,
       'actual D4 24-cell: T^3 1=1', 'undamped channel 1^n is present on admitted full shell','9873-9883','E4',
       scope='In-domain source 24-cell adjacency A+/8. Explicit constant shell sector exists and was not excluded in the unqualified only-factor sentence.')
# Born product leaf group and semigroup without inventing new physical history.
x,y,xp,yp=s.symbols('x y xp yp',positive=True)
starx=x*xp/s.sqrt(C); stary=y*yp/s.sqrt(C)
verify('BORN-STAR-CLOSURE',eq((starx*stary).subs({y:C/x,yp:C/xp}),C),starx*stary,'C if xy=xp yp=C','9949-9970')
verify('BORN-INVERSE',eq((x*y/s.sqrt(C)).subs(y,C/x),s.sqrt(C)),'star((x,y),(y,x))','(sqrtC,sqrtC)','9960-9968')
verify('BORN-V-ADD',eq((s.log(starx/stary)/2-s.log(x/y)/2-s.log(xp/yp)/2).expand(log=True),0),'v(star)=v+v','zero','9949-9983')
v,w,kappa,t=s.symbols('v w kappa t',positive=True)
verify('BORN-SEMIGROUP',eq(s.exp(-kappa*(t+w)),s.exp(-kappa*t)*s.exp(-kappa*w)), 'b(t+w)=b(t)b(w)','exponential','9985-10039')
verify('BORN-GROUP-ENDO',eq(s.exp(-kappa*t)*(v+w),s.exp(-kappa*t)*v+s.exp(-kappa*t)*w), 'b(t)(v+w)=bv+bw','additivity','9985-10039')
verify('BORN-CUBIC-NONGROUP',s.simplify((v+w)**3-v**3-w**3)!=0, 'cubic odd contraction fails additivity','nonzero mixed terms','10077-10089')
verify('BORN-NO-O7-VECTOR',np.linalg.norm(-np.array([1.,-2.,3.])-np.array([1.,-2.,3.]))>1, 'reflection sends v to -v; invariant covector must vanish','0 map','10056-10075',level='E2')
# Terminal RAR environment simple readout and non-universal comparison.
Rb,Rsel,C56,c=s.symbols('Rb Rsel C56 c',positive=True)
aR=lambda z:c**2*s.sqrt(z)/(4*s.pi)
Rresp=s.sqrt(Rsel*Rb)
verify('RAR-TERMINAL-PAIR',eq(aR(Rresp)**2,aR(Rsel)*aR(Rb)),aR(Rresp)**2,aR(Rsel)*aR(Rb),'10105-10159')
verify('RAR-ENV-SCALING',eq(aR(Rsel)/aR(C56),s.sqrt(Rsel/C56)),aR(Rsel)/aR(C56),'sqrt(Rsel/C56)','10105-10159')
verify('RAR-C6-CROSS-SORT-DIAGNOSTIC',eq((aR(alpha*C56)/aR(C56))**s.Rational(1,2),alpha**s.Rational(1,4)), 'relative g when Rsel=C6', 'alpha^1/4', '10217-10239')
verify('RAR-NONUNIVERSAL-WITNESS', (1*2*3)!= (1*4*3), 'same gb, two distinct environments => distinct gobs²','different', '10161-10183')
# Running mass exact source derivative, requires F_R=chi.
M2=(F-R*chi)/(3*chi)
dM2=s.diff(M2,R).subs(s.diff(F,R),chi)
verify('SCALARON-RUNNING-MASS-DERIV',eq(dM2,-F*s.diff(chi,R)/(3*chi**2)),dM2,'-F chi_R/(3chi²)','10241-10275')
# Residence certificate: work identity and barrier crossing inequality, local and conditional.
Hpos,energy,sourcework=s.symbols('Hpos energy sourcework',positive=True)
verify('WELL-DISSIPATION',(-3*Hpos*energy+sourcework)<=sourcework,'-3H dotF² + positive work ≤ work','true','10288-10330',level='E2')
# Constraint-reduced propagators.
a=s.Function('a')(t);V=s.Function('V');z=s.symbols('z',real=True)
vfunc=s.Function('V')(a)
dot=s.diff(a,t)
s0,rate=s.symbols('s0 rate',real=True,positive=True)
a_hom=s.exp(rate*t)
G_hom=s.diff(a_hom,t)/(rate*s.exp(rate*s0))
verify('HOMOG-RETARDED-RATIO',eq(s.diff(G_hom,t),rate*G_hom),
       G_hom,'retarded homogeneous solution exp(rate*(t-s))','10589-10622',level='E3',scope='Independent nontrivial expanding example on Hamiltonian branch dot a=rate*a; checks ratio is Green homogeneous solution.')
n=s.symbols('n',integer=True,positive=True)
lam=n*(n+2);d=lam-3
verify('S3-COLD-LAMBDA',eq(d,(n-1)*(n+3)),d,'(n-1)(n+3)','10624-10660')
Hp,ap,cp,omega=s.symbols('Hp ap cp omega',positive=True, real=True)
Gamma=Hp+cp**2*d/(3*Hp*ap**2)
verify('S3-COLD-GREEN-LAPLACE',eq((cp**2/(3*Hp))/(Gamma-s.I*omega),1/(d/ap**2+3*Hp**2/cp**2-s.I*3*Hp*omega/cp**2)),
       '(c²/3H)/(Gamma-iω)','1/(d/a²+3H²/c²-i3Hω/c²)','10624-10660')
verify('S3-COLD-RETARDED-RATE',float(Gamma.subs({n:3,Hp:1,ap:1,cp:1}))>0,Gamma,'positive for n>2,H>0','10624-10660')
# Berry midpoint projectors and tensor covariance, two signs.
from sympy.physics.matrices import msigma
th,ph=s.symbols('th ph',real=True)
su=s.Matrix([[s.exp(s.I*th),0],[0,s.exp(-s.I*th)]])
zero=s.zeros(2)
Gam=s.BlockMatrix([[zero,su],[su.conjugate().T,zero]]).as_explicit()
Vplus=s.Matrix.vstack(su,s.eye(2))/s.sqrt(2)
Vminus=s.Matrix.vstack(-su,s.eye(2))/s.sqrt(2)
verify('HELICITY-PROJECTOR-FRAMES',s.simplify(Vplus.conjugate().T*Vplus-s.eye(2))==s.zeros(2) and s.simplify(Vminus.conjugate().T*Vminus-s.eye(2))==s.zeros(2) and s.simplify(Gam*Vplus-Vplus)==s.zeros(4,2) and s.simplify(Gam*Vminus+Vminus)==s.zeros(4,2),
       'Gamma V±=±V±, V±†V±=I','true','10797-10829')
Ap=s.simplify(Vplus.conjugate().T*s.diff(Vplus,th));Am=s.simplify(Vminus.conjugate().T*s.diff(Vminus,th))
verify('HELICITY-MIDPOINT-EQUAL',s.simplify(Ap-Am)==s.zeros(2),'Aplus=Aminus','same half Maurer-Cartan','10797-10829')
Pl,Pr=s.symbols('Pl Pr',positive=True)
xi=s.log(Pl/Pr)/2
pi=(Pl-Pr)/(Pl+Pr)
verify('HELICITY-TANH',eq(s.tanh(xi).rewrite(s.exp),pi),'tanh[.5log(Pl/Pr)]','(Pl-Pr)/(Pl+Pr)','10831-10877')
verify('HELICITY-EQUAL-STATE-ZERO',eq(xi.subs(Pl,Pr),0),'Pl=Pr => Xi=0','zero','10841-10893')
verify('HELICITY-ASYM-WITNESS',xi.subs({Pl:4,Pr:1})!=0,'unequal covariances can give nonzero Xi even for same equations','nonzero','10879-10893','E4',scope='Negative control for invalid inference equal bulk equations=>equal physical powers without matched state/source. Source explicitly states the state condition, so not a reported gap.')
S=s.Matrix([[2,1],[1,1]]) # symplectic det1
mu,om,hbar=s.symbols('mu om hbar',positive=True)
gamma=hbar*s.diag(1/(mu*om),mu*om)/2
Sig=S*gamma*S.T
verify('SCALAR-SYMPLECTIC-S',S.det()==1,S.det(),1,'10901-10977')
verify('SCALAR-GROUND-COVARIANCE',eq(Sig[0,0],hbar*(S[0,0]**2/(mu*om)+mu*om*S[0,1]**2)/2),Sig[0,0],'root qq covariance','10901-10977')
verify('SCALAR-ROOT-PRIVILEGED-POS',float(Sig[0,0].subs({mu:3,om:5,hbar:1}))>0,Sig[0,0],'>0','10901-10977')
for dim,rank in [(9,3),(25,5),(169,13)]:
   cov=np.eye(dim)*2.74
   P=np.diag([1]*rank+[0]*(dim-rank))
   verify(f'SHELL-RANK-FRAC-{dim}',abs(np.trace(P@cov@P)/np.trace(cov)-rank/dim)<1e-12,
      np.trace(P@cov@P)/np.trace(cov),rank/dim,'10901-10951,10993-11009')
verify('TENSOR-SHELL-RANK',all(2*(l-1)*(l+3)==2*((l+3)*(l-1)) for l in range(2,11)), 'two SO4 chiral sectors dims (L-1)(L+3) each', '2(L-1)(L+3)', '11021-11053')
L=s.symbols('L',integer=True,positive=True);aJ,Fconf,MM=s.symbols('aJ Fconf MM',positive=True)
aE=s.sqrt(Fconf)*aJ
AE=s.Matrix([[0,aE**(-3)],[-aE*L*(L+2),0]])
AJ=s.Matrix([[0,1/(aJ**3*Fconf)],[-aJ*Fconf*L*(L+2),0]])
verify('TENSOR-FRAME-GENERATOR',s.simplify(AJ-s.sqrt(Fconf)*AE)==s.zeros(2),'A_J=√F A_E','true','11083-11103')
PhE=MM**2*aE**3/(4*s.sqrt(Fconf));PhJ=MM**2*aJ**3*Fconf/4
verify('TENSOR-FRAME-MOMENTUM',eq(PhE,PhJ),PhE,PhJ,'11083-11095')
# E4 EXACT-SOURCE counterexample to printed H_E dt_E=H_J dt_J in variable-F branch.
a0,slope,b=s.symbols('a0 slope b',positive=True)
Ftime=s.exp(2*b*t);aJtime=a0*s.exp(slope*t)
Hj=s.diff(s.log(aJtime),t)
He_dtE=s.diff(s.log(s.sqrt(Ftime)*aJtime),t) # H_E dt_E expressed as differential w.r.t. tJ
verify('HUBBLE-CONFORMAL-COUNTEREXAMPLE',eq(He_dtE-Hj,b) and b!=0,He_dtE-Hj,
       'b dtJ, not zero for F=exp(2btJ)','11083-11108','E4',scope='In-domain regular positive variable-F conformal branch; no change to tensor momentum or generator identities.')
verify('HUBBLE-CONFORMAL-POSCTRL',eq((He_dtE-Hj).subs(b,0),0),'F constant => equal Hdt','true','11083-11108')
Ffun=s.Function('F')(t);afun=s.Function('aJ')(t)
logdiff=s.diff(s.log(s.sqrt(Ffun)*afun),t)-s.diff(s.log(afun),t)
verify('HUBBLE-CONFORMAL-SYMBOLIC',eq(logdiff,s.diff(Ffun,t)/(2*Ffun)),logdiff,'Fdot/(2F)','11083-11108')
# Tensor Dirac source: canonical first-order equivalence.
ah,FF,pD,P_h,h,ind,lamt,mt=s.symbols('ah FF pD Ph h ind lamt mt',real=True,positive=True)
first=-(ah*MM**2*FF*lamt/4+ah**3*pD/4)*h-ind
verify('DIRAC-TT-CANONICAL',eq(4*first,-(ah*MM**2*FF*lamt+ah**3*pD)*h-4*ind),first,'second line follows from P_h momentum','11116-11155')
mdot,occ,Vvol=s.symbols('mdot occ Vvol',real=True)
verify('DIRAC-MASS-WORK-CONST',eq((mdot*occ/Vvol).subs(mdot,0)), 'mass-work RHS at mdot=0',0,'11156-11168',level='E2',scope='Source work vanishes for constant mass, no independent Ward certification.')
# End-of-batch evidence report
assert len({r['id'] for r in rows})==len(rows)
report={'batch':'Paper6A-Batch04','source':'Paper6A-GravityCosmology-v2_253.tex','source_lines':[9031,11203],
        'no_separate_agents':True,'evidence_levels':'E0 source/anchor; local E2 replay, independent E3 controls and adversarial E4; no blanket whole-claim certificate',
        'results':rows,'counts':{'passed':sum(x['passed'] for x in rows),'failed':sum(not x['passed'] for x in rows),'total':len(rows)}}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('VI-A B04 exact checks:',report['counts'])
if report['counts']['failed']: raise SystemExit(1)
