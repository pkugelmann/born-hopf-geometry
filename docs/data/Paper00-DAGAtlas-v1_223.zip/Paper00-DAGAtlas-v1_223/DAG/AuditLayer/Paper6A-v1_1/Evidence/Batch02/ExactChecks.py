#!/usr/bin/env python3
"""Paper VI-A 2515--5533 independent E3 identities and E4 exact-domain challenges.
No source or supplied-archive changes; test only printed source results, not new theory.
"""
import sympy as s, mpmath as mp, json
from pathlib import Path
mp.mp.dps=60
out=[]
def check(id, ok, actual, expected, loc, scope, detail=''):
    ok=bool(ok)
    out.append({'id':id,'passed':ok,'actual':str(actual),'expected':str(expected),
                'source_locator':loc,'scope':scope,'detail':detail})
    if not ok:print('FAILED',id,'actual',str(actual)[:180])

# Section 2515--3007: visibility, geometric clock, positive heat no-go.
tau=s.symbols('tau',nonnegative=True); k=s.symbols('k',nonnegative=True)
profile=tau*s.exp(-tau)
check('E3-B02-VISIBILITY-BAND-PEAK',s.simplify(s.diff(profile,tau)-s.exp(-tau)*(1-tau))==0 and profile.subs(tau,0)==0 and s.limit(profile,tau,s.oo)==0 and s.simplify(s.diff(profile,tau,2).subs(tau,1))<0,
      (s.diff(profile,tau),s.diff(profile,tau,2).subs(tau,1)),'unique maximum tau=1','6A:2523-2561','positive common-rate band')
check('E3-B02-TAU36-MIDPOINT',s.simplify(7*(1-s.exp(-(-s.log(s.Rational(5,14)))))-s.Rational(9,2))==0,
       7*(1-s.exp(s.log(s.Rational(5,14)))),s.Rational(9,2),'6A:2597-2611','structural midpoint, no physical role inferred')
check('E3-B02-RANK-DIFFERENCE-72',24*(5-2)==72,24*(5-2),72,'6A:2885-2918','Hurwitz rank gap without subgroup nesting')
U=s.symbols('U',positive=True); C=s.symbols('C',positive=True); al=s.symbols('alpha',positive=True); RR=s.symbols('R',real=True)
AD_B2=s.Rational(1,2)*s.symbols('F4',positive=True)*s.symbols('F8',positive=True)/s.symbols('F6',positive=True)**2
check('E3-B02-HEAT-TOWER-EXAMPLE',s.gamma(3)**2 < s.gamma(2)*s.gamma(4),[s.gamma(n) for n in [2,3,4]],'F6²<F4F8','6A:2672-2720','positive nonzero smooth f(u)=e^-u; fully supported cutoff moments')
ratio=s.gamma(2)*s.gamma(4)/s.gamma(3)**2
check('E3-B02-HEAT-TOWER-DISC',s.simplify(9-16*ratio)<0,s.simplify(9-16*ratio),'negative discriminant','6A:2692-2711','smooth positive exp(-u) witness; general inequality follows CS')
check('E3-B02-HEAT-TOWER-POSITIVE-DISC-UPPER',s.simplify(9-16*1)<0,9-16,'-7 < 0','6A:2701-2711','CS lower ratio one')
check('E3-B02-HIERARCHY-THREE-COORDINATES',s.simplify((U*al**(-s.Rational(3,2)))**2 - U*(U*al**(-3)))==0 and s.simplify((U*al**(-3))-(s.sqrt(U)*al**(-s.Rational(3,2)))**2)==0,
      'C_B(24)^2 = U*C_24; R_24^2=C_24','two different dimensionful squares','6A:2726-2743,2925-2975','Born midpoint C_B vs hierarchy root R')
mpU=mp.mpf('6.09e68');mpa=mp.mpf('1.571958279122504e17')
r8=mp.sqrt(mpU)/mp.sqrt(mpa);r16=mp.sqrt(mpU)/mpa;born8=mpU/mp.sqrt(mpa);born16=mpU/mpa
check('E4-B02-ROOT-8-NUMERIC-READOUT-MISMATCH',abs(mp.log10(r8)-60)>20 and abs(mp.log10(born8)-60)<1,
       {'R8_m-1':mp.nstr(r8,14),'C_B8_m-2':mp.nstr(born8,14),'table':'~1e60 m^-2'},'table value is C_B8, not R8','6A:2730-2742,2780-2783,3087-3093','exact claimed symbol/domain numeric units')
check('E4-B02-ROOT-16-NUMERIC-READOUT-MISMATCH',abs(mp.log10(r16)-52)>30 and 51<=mp.log10(born16)<=53,
       {'R16_m-1':mp.nstr(r16,14),'C_B16_m-2':mp.nstr(born16,14),'table':'~1e51-53 m^-2'},'table value is C_B16, not R16','6A:2730-2742,3095-3105','same mismatch root as R8, grouped into one issue')
check('E3-B02-C7-TERMINAL',s.simplify(U*al**(-7)-(s.sqrt(U)*al**(-s.Rational(7,2)))**2)==0,'C56=U alpha^-7','root square','6A:2925-2965','positive hierarchy alpha>1')
# Exact separated Born-Legendre plus vacuum.
a,N,X,da,dX,pA,pX,symk=s.symbols('a N X da dX pA pX k',real=True,nonzero=True)
V=s.Function('V')(X)
L=-6*a*X*da**2/N-6*a*a*da*dX/N+6*symk*N*a*X-N*a**3*V
check('E3-B02-BARE-LAPSE',s.simplify(s.diff(L,N)-(6*a*X*da**2/N**2+6*a*a*da*dX/N**2+6*symk*a*X-a**3*V))==0,s.diff(L,N),'printed lapse derivative','6A:3433-3476','N varied before gauge-fixing')
check('E3-B02-BARE-HESSIAN',s.simplify(s.det(s.hessian(L,[da,dX]))+36*a**4/N**2)==0,s.factor(s.det(s.hessian(L,[da,dX]))),'-36a^4/N^2','6A:3478-3508','regular a,N nonzero')
va=-N*pX/(6*a**2);vX=N*(2*X*pX/a-pA)/(6*a**2)
H=s.factor((pA*da+pX*dX-L).subs({da:va,dX:vX}));H_expected=N*(X*pX**2/(6*a**3)-pA*pX/(6*a*a)-6*symk*a*X+a**3*V)
check('E3-B02-CANONICAL-HAMILTONIAN',s.simplify(H-H_expected)==0,s.simplify(H),'N * C canonical','6A:3478-3508','full nondegenerate Legendre transform')
R=s.symbols('R',real=True);fc=U*((R-C)+(R-C)**2/(U+C));Fp=s.diff(fc,R);leg=s.simplify(R*Fp-fc)
check('E3-B02-BARE-LEGENDRE',s.simplify(leg-U*(R*R+U*C)/(U+C))==0,s.factor(leg),'U(R²+UC)/(U+C)','6A:3510-3533','same-action regular separated branch')
chi=s.symbols('chi',real=True)
check('E3-B02-BARE-JORDAN-CHI',s.simplify((leg/U).subs(R,C+(U+C)*(chi-1)/2) -(C*chi+(U+C)*(chi-1)**2/4))==0,s.expand((leg/U).subs(R,C+(U+C)*(chi-1)/2)),'Cchi+(U+C)(chi-1)^2/4','6A:3524-3533','chi=F/U local inverse')
fcN=fc/U;B=s.factor(2*fcN-R*s.diff(fcN,R));ds=s.solve(B,R)[0]
check('E3-B02-BARE-DS-ROOT',s.simplify(ds-2*U*C/(U-C))==0,ds,'2UC/(U-C)','6A:3535-3578','U>C, root in [C,U] iff U>=3C')
check('E3-B02-BARE-MASS',s.simplify((s.diff(fcN,R)-R*s.diff(fcN,R,2))/(3*s.diff(fcN,R,2))-(U-C)/6)==0,
      s.simplify((s.diff(fcN,R)-R*s.diff(fcN,R,2))/(3*s.diff(fcN,R,2))),'(U-C)/6','6A:3550-3575','local algebraic coefficient, physical pole only at solved vacuum')
fsh=R+(R*R+U*C)/(U+C)-2*C
check('E3-B02-SHARP-AFFINE',s.simplify(fsh-fcN-2*C*(R-C)/(U+C))==0,s.factor(fsh-fcN),'2C(R-C)/(U+C)','6A:3580-3617','historical comparison only')
check('E3-B02-SHARP-LEGENDRE-SHIFT',s.simplify((R*s.diff(fsh,R)-fsh)-(R*s.diff(fcN,R)-fcN)-2*C*C/(U+C))==0,
       s.simplify((R*s.diff(fsh,R)-fsh)-(R*s.diff(fcN,R)-fcN)),'2C²/(U+C)','6A:3602-3617','affine response')
# Capped Einstein-space vacuum FLRW solution.
t=s.symbols('t',real=True);h=s.symbols('h',positive=True)
at=s.cosh(h*t)/h;HF=s.simplify(s.diff(at,t)/at)
flrw=s.simplify(6*(s.diff(at,t,2)/at+HF**2+1/at**2))
check('E3-B02-CAP-DS-FLRW',s.simplify(flrw-12*h*h)==0,flrw,'12h²=R*','6A:3683-3729','conditional capped action stationary vacuum; no occurred history inferred')
# Force potential / Jordan and constrained flow. A quadratic f suffices as E3 soluble control.
beta=s.symbols('beta',positive=True);Xr=s.symbols('Xr',real=True)
f=R+beta*R**2;ff=s.diff(f,R);rr=s.solve(ff-Xr,R)[0];force=s.simplify(2*f-R*ff);m2=s.simplify((ff-R*s.diff(f,R,2))/(3*s.diff(f,R,2)))
Wprime=s.simplify(force.subs(R,rr)/3)
check('E3-B02-SCALARON-FORCE-QUADRATIC',s.simplify(Wprime-Xr/(6*beta)+1/(6*beta))==0,Wprime,'(F-1)/(6beta)','6A:3783-3849','c=1 soluble local branch, not replacement action')
check('E3-B02-SCALARON-FORCE-CURVATURE',s.simplify(s.diff(Wprime,Xr)-m2)==0,s.diff(Wprime,Xr),m2,'6A:3824-3849','quadratic mass trace response')
FH,P,Aconst,a1,cc=s.symbols('F P A a c',positive=True)
disc=P*P+(4*FH/3)*Aconst-4*FH**2*cc**2/a1**2
hplus=(-P+s.sqrt(disc))/(2*FH);hminus=(-P-s.sqrt(disc))/(2*FH)
check('E3-B02-FLRW-QUADRATIC-DISC',all(s.simplify(3*FH*hp**2+3*P*hp+3*FH*cc**2/a1**2-Aconst)==0 for hp in (hplus,hminus)),
      s.simplify(3*FH*hplus**2+3*P*hplus+3*FH*cc**2/a1**2-Aconst),'0 for ± roots','6A:3874-3932','F>0, disc>0')
# Terminal local n7=0 test; series leading terms independent of higher derivatives.
d=s.symbols('delta',positive=True)
chi0=s.factor((R*R-C*C)/((U+C)*R*R))
chi_s=s.series(chi0.subs(R,C+d),d,0,3).removeO()
check('E3-B02-TERMINAL-CHI-LEADING',s.limit(chi0.subs(R,C+d)/d,d,0,dir='+')==2/(C*(U+C)),s.limit(chi0.subs(R,C+d)/d,d,0,dir='+'),'2/(C(U+C))','6A:4066-4098','n7(C)=0, smooth response')
Nlow=1-2*s.symbols('C2',positive=True)/(U+C)
check('E3-B02-INVERSE-LOCAL-CHAIN',s.simplify((chi0/(1-R*chi0)).subs(R,C+d)-1/(3*((1-(C+d)*chi0.subs(R,C+d))/(3*chi0.subs(R,C+d)))))==0,
      'dF/ds=chi/(F-Rchi)=1/(3m²) for F=1','chain identity','6A:3978-4030','test first-order F=1 used as a soluble algebraic control')
# WKB with physical SI time has frequency c m_s; c=1 is not declared in statement.
ww,cs,ms=s.symbols('omega c m',positive=True)
check('E4-B02-WKB-MISSING-C',s.simplify(s.factor((-ms**2+cs**2*ms**2))-(cs**2-1)*ms**2)==0,
      {'ansatz_cos_mt_residual':s.factor(cs**2*ms**2-ms**2),'ode_frequency':cs*ms},'nonzero residual for c != 1','6A:4070-4073,4100-4112','source displays c² trace restoring term and physical time; natural-unit c=1 would require explicit branch convention')
check('E3-B02-WKB-POSITIVE-CONTROL',s.simplify((cs*ms)**2-cs**2*ms**2)==0,cs*ms,'omega=c m_s','6A:4070-4073,4100-4112','constant mass/H=0 local leading equation')
# Trace-force higher vertices via chain-rule test arbitrary nonlinear polynomial.
l3,l4=s.symbols('l3 l4',real=True);ft=R+beta*R**2+l3*R**3+l4*R**4
FT=s.diff(ft,R);GG=s.diff(ft,R,2);H3=s.diff(ft,R,3);H4=s.diff(ft,R,4)
D=lambda expr: s.simplify(s.diff(expr,R)/GG)
W2=s.simplify((FT/GG-R)/3);W3=D(W2);W4=D(W3)
check('E3-B02-VERTEX-CUBIC',s.simplify(W3+FT*H3/(3*GG**3))==0,W3,'-FH3/(3G³)','6A:4292-4316','polynomial degree four, c=1')
check('E3-B02-VERTEX-QUARTIC',s.simplify(W4+(GG**2*H3+FT*GG*H4-3*FT*H3**2)/(3*GG**5))==0,W4,'-(G²H3+FGH4-3FH3²)/(3G^5)','6A:4292-4316','polynomial degree four, c=1')
# Central monotonicity and source inverse control on simple smooth increasing susceptibility.
z=s.symbols('z',positive=True);m=s.symbols('m',positive=True)
chitest=z*m;Ftest=1+z*z*m/2;Ntest=s.simplify(Ftest-z*chitest)
check('E3-B02-STIELTJES-N',s.simplify(Ntest-(1-s.integrate(s.Symbol('s')*m,(s.Symbol('s'),0,z))))==0,Ntest,'1 - (m/2) z²','6A:4323-4354','test monotone chi=m z with F(0)=1')
# Thin-shell and PPN independent controlled checks.
q=s.symbols('q',positive=True); charge=s.expand(1-(1-q)**3)
check('E4-B02-PPN-THINSHELL-CHARGE-FACTOR3',s.limit(charge/q,q,0,dir='+')==3,
      {'shell_fraction':charge,'limit_charge_over_shell':s.limit(charge/q,q,0,dir='+')},'Q_eff/M ≈ 3*(Delta r/r)','6A:4557-4602','spherical shell mass fraction, standard chameleon thin shell; source epsilon uses Delta F/(2Phi) ≈ Delta r/r')
check('E4-B02-PPN-THINSHELL-CONCRETE',abs(float(charge.subs(q,s.Rational(1,100)))/3-float(s.Rational(1,300)))>0.006,
      {'q':'.01','actual_relative_potential_correction':float(charge.subs(q,s.Rational(1,100)))/3,'printed_relative_correction':1/300},'true 0.0099003 vs printed 0.003333...','6A:4557-4582','thin-screened sphere, r=r_B (no Yukawa decay)')
check('E4-B02-PPN-DIMENSIONAL-CONFLICT',(2,-2)!=(0,0),
      {'GM/r':'L² T^-2','R*r²':'1','surface_Phi_B':'GM/(c² r), dimensionless'},'two terms in same potential must share dimensions','6A:4540-4544,4564-4573','c explicitly present in same theorem; issue is typed units not visual notation')
# PPN fraction alone algebraically consistent given epsilon variable; do not falsely flag it.
eps=s.symbols('eps',nonnegative=True);gamma=(1-eps/3)/(1+eps/3)
check('E3-B02-PPN-GAMMA-ALGEBRA',s.simplify(gamma-1)==-2*eps/(3+eps),s.factor(gamma-1),'-2eps/(3+eps)','6A:4574-4582','printed inequality is a valid loose bound when 0<=eps<=1, independent of the physical epsilon normalization')
# S3 projectors: Hessian trace-free spectral and norm using Bochner identities.
lambda_n=s.symbols('lambda',positive=True);dn=lambda_n-3
check('E3-B02-S3-GRAM',s.simplify(lambda_n**2-2*lambda_n-lambda_n**2/3)-2*lambda_n*dn/3==0,
      s.simplify(lambda_n**2-2*lambda_n-lambda_n**2/3),'2lambda(lambda-3)/3','6A:4645-4669','unit round S3, n>2')
# Contact Schur matrix exact 2x3 x3x2 multiplication.
alpha,w,dd=s.symbols('alpha w d',positive=True);HH=s.symbols('HH',real=True)
Pn=s.Matrix([[-alpha/dd,3*alpha*HH/dd,-2*alpha],[-alpha/dd,3*alpha*HH/dd,0]])
Mn=s.Matrix([[0,3*w],[0,0],[0,0]])
W=s.simplify(s.eye(2)-Pn*Mn);kk=3*alpha*w/dd
check('E3-B02-FREE-CONTACT-W',s.simplify(W-s.Matrix([[1,kk],[0,1+kk]]))==s.zeros(2),W,s.Matrix([[1,kk],[0,1+kk]]),'6A:4744-4794,4921-5025','Newtonian 2x3 finite source-metric composition')
check('E3-B02-FREE-CONTACT-DET',s.simplify(W.det()-(dd+3*alpha*w)/dd)==0,W.det(),'(d+3alpha*w)/d','6A:4962-4969','w>=0 sufficient for invertible W')
# 4D geometry identity controls, independent eigenvalues.
qE,qR=s.symbols('qE qR',real=True); S=s.diag(-qE/4,qE/12,qE/12,qE/12)
check('E3-B02-RIEMANN-20',int(4**2*(4**2-1)/12)==20 and 1+9+10==20,(int(4**2*(4**2-1)/12),1+9+10),20,'6A:5054-5083','algebraic Riemann tensor 4D')
check('E3-B02-FLRW-S-MINPOLY',s.simplify(S*S+(qE/6)*S-qE*qE/48*s.eye(4))==s.zeros(4),S*S+qE/6*S-qE*qE/48*s.eye(4),'0 matrix','6A:5138-5182','exact FLRW, no Einstein field equation')
for n in range(1,9):
    tr=s.simplify(s.trace(S**n));exp=s.simplify(((-3)**n+3)*qE**n/12**n)
    check('E3-B02-FLRW-S-TRACE-'+str(n),s.simplify(tr-exp)==0,tr,exp,'6A:5149-5165','n='+str(n)+' all-orders algebraic identity')
check('E3-B02-FLRW-S-DISC',s.simplify(3*s.trace(S**3)**2-s.trace(S**2)**3)==0,s.factor(3*s.trace(S**3)**2-s.trace(S**2)**3),0,'6A:5153-5161','pointwise round FLRW')
# Euler/heat restricted algebra. Confirm coefficients and susceptibility shift.
AH,BH,zeta,Ms=s.symbols('A_H B_H zeta Mstar',real=True);Rbar=6*(AH+BH);qbar=6*(BH-AH)
Pheat=-Rbar*s.Symbol('boxR')/10+s.Rational(31,2160)*Rbar**3-s.Rational(19,720)*Rbar*qbar**2+s.Rational(13,1080)*qbar**3
Pcubic=s.Rational(2,5)*AH*(-13*AH**2+57*AH*BH+18*BH**2)
check('E3-B02-HEAT-R0-CUBIC',s.simplify(Pheat.subs({AH:-BH,s.Symbol('boxR'):0})-Pcubic.subs(AH,-BH))==0,
      s.factor(Pheat.subs({AH:-BH,s.Symbol('boxR'):0})),s.factor(Pcubic.subs(AH,-BH)),'6A:5197-5207,5429-5434','R=0 diagnostic only, not active f(R) solution')
check('E3-B02-HEAT-SUSCEPTIBILITY-SHIFT',s.simplify(s.diff(2*zeta*s.Rational(31,2160)*R**3/Ms**2,R,2).subs(R,C) -31*zeta*C/(180*Ms**2))==0,
      s.diff(2*zeta*s.Rational(31,2160)*R**3/Ms**2,R,2).subs(R,C),'31 zeta C/(180 Mstar²)','6A:5224-5232','added cubic only, conditional heat coefficient')
# Schur complement check independent block example.
hpp,hpw,hwp,hww,jp,jw=s.symbols('hpp hpw hwp hww jp jw',real=True,nonzero=True)
solw=(jw-hwp*s.Symbol('ph'))/hww
check('E3-B02-SCHUR-ELIMINATION',s.simplify((hpp*s.Symbol('ph')+hpw*solw-jp) - ((hpp-hpw*hwp/hww)*s.Symbol('ph') -(jp-hpw*jw/hww)))==0,
      'Heff=hpp-hpw hww^-1 hwp','Schur complement','6A:5252-5272','regular invertible w-block; not a proof of its physical occurrence')
# Complete tensor identity and Noether conservation.
Theta,Xi=s.symbols('Theta Xi',real=True);e0=(Theta+3*Xi)/4;ei=(Theta-Xi)/4
check('E3-B02-RESIDUAL-TRACE',s.simplify(e0+3*ei-Theta)==0 and s.simplify(e0-ei-Xi)==0,
      {'E00':e0,'Eii':ei},'Theta and Xi recovered','6A:5315-5355','mixed tensor residual')
check('E3-B02-RESIDUAL-ENTHALPY',s.simplify((e0-ei)-Xi)==0,s.simplify(e0-ei),'Xi','6A:5315-5355','difference time and space components')
# Radiation a6 pressure verify and independently check lapse Euler formula on reference.
Lr,aa,zz=s.symbols('L a zeta',positive=True)
e6=2*zz*Lr**4/(5*aa**12)*(685*Lr**2-768*aa**2)
p6=s.simplify(-e6-aa*s.diff(e6,aa)/3)
check('E3-B02-A6-RADIATION-PRESSURE',s.simplify(p6-2*zz*Lr**4/(5*aa**12)*(2055*Lr**2-1792*aa**2))==0,
      s.factor(p6),'2 zeta L^4/(5a^12)*(2055L²-1792a²)','6A:5397-5446','fixed Einstein radiation background')
check('E4-B02-A6-NO-DUST-IN-DOMAIN',s.Rational(2055,1792)>1,s.Rational(2055,1792),'greater than maximum a²/L²=1','6A:5397-5422','zeta!=0')
# Positive control for exact static optical geometry.
r,rh,cop=s.symbols('r Rh c',positive=True)
ffr=1-(r/rh)**2
check('E3-B02-OPTICAL-NULL-SPEED',s.simplify((cop*ffr)**2/(ffr**2)-cop**2)==0, 'dr/dt= c(1-r²/Rh²)','null radial de Sitter','6A:5463-5491','0<=r<Rh')
check('E3-B02-OPTICAL-ARTANH',s.simplify(s.diff(rh*s.atanh(r/rh)/cop,r)-1/(cop*ffr))==0,
      s.diff(rh*s.atanh(r/rh)/cop,r),'1/(c f(r))','6A:5472-5491','r static patch')
check('E3-B02-OPTICAL-LOCAL-C',s.simplify((cop*ffr/s.sqrt(ffr))/s.sqrt(ffr)-cop)==0,'c','c','6A:5479-5485','static observer proper ruler/clock ratio')
ht=s.symbols('Hlambda',positive=True);t=s.symbols('t',real=True)
ads=s.symbols('c',positive=True)/ht*s.cosh(ht*t)
hhub=s.diff(ads,t)/ads
qe=s.simplify(6/s.symbols('c',positive=True)**2*(s.symbols('c',positive=True)**2/ads**2-s.diff(hhub,t)))
check('E3-B02-DS-QE-ZERO',qe==0,qe,0,'6A:5492-5513','pure global closed de Sitter; no wave-medium claim')

result={'batch':'Paper6A-Batch02','source':'Paper6A-GravityCosmology-v2_253.tex',
        'source_lines':[2515,5533],'no_separate_agents':True,
        'evidence_level':'E3/E4 strictly on indicated algebraic, numerical and adversarial subclaims',
        'results':out,'counts':{'passed':sum(x['passed'] for x in out),
                               'failed':sum(not x['passed'] for x in out),
                               'total':len(out)}}
fp=Path(__file__).with_suffix('.json');fp.write_text(json.dumps(result,indent=2,ensure_ascii=False,default=str)+'\n')
print(json.dumps(result['counts'],indent=2))
