# Paper VI-A — rigorous verification DAG audit (full source; six bounded batches)

**Target:** `Paper6A-GravityCosmology-v2_253.tex` (`Paper00-PapersMinimal-v2_371`), SHA256 `3110e5c951b395665f54a2a910dd6e3570eb9659e775d3b0b4128e6fe28a82d1`, 17,251 lines.
**Protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md`; no theory development and no source edits.
**Rebased onto:** `Paper00-DAGAtlas-v1_116.zip` / `Paper00-ProofChainAudits-v1_33.zip`; earlier Batch1–5 checkpoint ledgers remain preserved, but only latest cumulative VI-A records are active.
**Disposition:** `FULLY_AUDITED_WITH_OPEN_GAPS` as SOURCE-COVERAGE classification; this does **not** mean complete E3 certification of every theorem.
**Formal census:** 357/357 named source results inspected; 14 additional final-batch unnamed material/interface blocks recorded; earlier batches include additional unnamed claims.
**Final status:** FORMALIZED 121, REPRODUCED 109, UNRESOLVED 13, VERIFIED-CONDITIONAL 114.
**Exact subclaim controls:** 354/354 cumulatively (310 from Batches 1–5 plus 44 from Batch 6); passing E4 challenges deliberately expose defects. Independent agents unavailable; no multi-agent claim is made.
**Open issue roots:** 17 (14 inherited from earlier batches, 3 new in Batch 6). Physical occurrence, same-action owner, and observational calibration are never inferred from algebra alone.

## Batch source coverage

| Batch | Line interval | New named claims | Cumulative named claims | Exact subclaim controls |
|---:|:---|---:|---:|---:|
| 1 | 1–2,514 | 52 | 52 | 48 |
| 2 | 2,515–5,533 | 65 | 117 | 59 |
| 3 | 5,534–9,030 | 61 | 178 | 57 |
| 4 | 9,031–11,203 | 71 | 249 | 70 |
| 5 | 11,204–14,549 | 63 | 312 | 76 |
| 6 | 14,550–17,251 | 45 | 357 | 44 |

## Complete open issue register (all 17)

### BH-VIA-G-0001 — MODERATE — MISSING_CONDITION
**First origin:** `p8:thm:k48-conditional-exact-dust`; VI-A lines 2142–2149.
Cauchy additivity only yields μ∈R, not μ≥0; F(ζ)=−ζ is an exact counterexample.

**Precise obligation:** Locate and source-type a nonnegative effective-energy premise or qualify the μ sign; no paper/source edits performed.

**Retained:** F is linear with real slope; pressure p=0 for linear F; terminal current dilutes as a^-3

**Conditions:** As shown in source-bound gap record; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0002 — MINOR — TYPE_OR_DOMAIN / MISSING_CONDITION
**First origin:** `p8:thm:k48-conditional-exact-dust`; VI-A lines 2149–2157.
At μ=0 the equation of state is F=p=0 and dp/dF is undefined without a limiting convention.

**Precise obligation:** Restrict the sound-speed derivative statement to a nondegenerate effective-density branch, or explicitly define a limiting convention; no theory repair inserted.

**Retained:** The zero-energy case has zero stress and pressure; On μ>0 nondegenerate branch, c_s²=0; Neutral Hodge current balance unaffected

**Conditions:** As shown in source-bound gap record; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0003 — MODERATE — NORMALIZATION_OR_READOUT
**First origin:** `p8:tab:geometric-outputs`; VI-A lines 2730–3105.
Figure/table numbers and m−2 units represent Born midpoint curvatures C8^B/C16^B, not root scales ℛ8/ℛ16 in m−1.

**Precise obligation:** Make numerical readout labels, values and units consistent with the source-defined coordinate; source unchanged.

**Retained:** Neutral seven-shell hierarchy identities survive; The correctly defined root and midpoint coordinates survive

**Conditions:** As shown in source-bound gap record; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0004 — MODERATE — NORMALIZATION_OR_READOUT / TYPE_OR_DOMAIN
**First origin:** `p8:cor:lower-scalaron-matter-like-average`; VI-A lines 4068–4112.
WKB phase uses m_s as physical frequency although the exact physical-time scalaron equation contains c²m_s²; dotΘ=cm_s for m_s in m−1.

**Precise obligation:** Specify a consistent physical-time/natural-unit convention or source-derive the frequency and dimensionless adiabatic parameters from the displayed trace equation.

**Retained:** Exact c² trace and scalaron force law remain valid; Conditional local-well requirement and no-global-matter-like conclusion remain intact

**Conditions:** BH-VIA-A-0005; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0005 — MODERATE — NORMALIZATION_OR_READOUT / TYPE_OR_DOMAIN
**First origin:** `p8:thm:smooth-solar-system-screening-ppn`; VI-A lines 4540–4573.
SI weak-field potential terms GM/(Fr) and R_env r²/24 have inconsistent dimensions under the printed dimensionless Φ convention.

**Precise obligation:** Source-type the potential normalization/gauge: dimensionless potentials need GM/(F c²r), while physical potentials need curvature terms with c²; do not silently choose one.

**Retained:** Stated assumptions F>0, f_RR>0, m²>0 remain unchallenged; Formal gamma fraction identity survives after a consistent normalization

**Conditions:** BH-VIA-A-0006; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0006 — MODERATE — UNPROVED_IMPORTED_NORMALIZATION / MISSING_PROOF_STEP
**First origin:** `p8:thm:smooth-solar-system-screening-ppn`; VI-A lines 4548–4602.
Thin-shell thickness q=Δr/r_B is substituted for an integrated scalar charge without showing the usual active fraction ≃3q in the same action.

**Precise obligation:** Provide a same-action charge integral in the asserted thin-shell domain and demonstrate why printed eps_B is the effective integrated scalar charge, or qualify its normalization and PPN quantitative response.

**Retained:** Qualitative limit eps_B->0 remains sufficient for a screened branch as a limit, subject to solved source backgrounds; The algebraic gamma relation in terms of a correctly defined exterior charge survives

**Conditions:** BH-VIA-A-0007; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0007 — MINOR — SCOPE
**First origin:** `p8:sec:v2201-derived-d11`; VI-A lines 5629–5634.
The D11 numerical quadrature/covariance JSON replay attachment is not present, so reported tolerances lack an independently runnable witness.

**Precise obligation:** Locate/provide original executed JSON and replay specification or retain D11 readouts explicitly as unreplicated reported numerical outputs.

**Retained:** Displayed D11 numbers are not disproved; D12 tensor t^6 and t^4 local coefficients survive exact controls; No numerical certificate is upgraded to E3

**Conditions:** As shown in source-bound gap record; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0008 — MODERATE — SCOPE
**First origin:** `p8:eq:hs-lambda-infty`; VI-A lines 7187–7192.
Horizon vacuum density C56/(2κ²) conflicts with earlier κ=M−2 convention implying C56/(2κ); distinguish alternate coupling or normalize.

**Precise obligation:** Resolve whether the horizon subsection introduces a different conventional coupling kappa_h satisfying kappa_h²=kappa_native, or reconcile rho_infty using the existing defined symbol.

**Retained:** Dimensionless normalized horizon polynomial/cubic and the conditional shape of w_DE remain algebraically consistent; The native terminal rho_Lambda=M² C/2 remains unchanged

**Conditions:** BH-VIA-A-0011; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0009 — MINOR — SCOPE
**First origin:** `p8:eq:hs-crossing-geometric`; VI-A lines 7353–7362.
w_DE=−1 ⇔ Θ_A=1/3 fails at allowed M=0 endpoint (w_DE=−1, Θ_A=1); requires positive matter.

**Precise obligation:** Scope the equivalence to M(a)>0 or explicitly account for the vacuum endpoint exception without changing the source during audit.

**Retained:** Physical-branch uniqueness and monotonicity for M>=0 survive; Positive-matter phantom crossing and conditional EOS remain valid

**Conditions:** BH-VIA-A-0012; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0010 — MODERATE — SCOPE
**First origin:** `p8:prop:v2188-trace-coefficient-certificate`; VI-A lines 8531–8559.
Operator 2-norm does not generally upper bound maximum absolute row sum B_a; normalized 2×2 Hadamard matrix witnesses sqrt2>1.

**Precise obligation:** Supply a genuine row-sum bound on each finite word or state a distinct operator-norm sufficient route with its own proof; audit does not repair the manuscript.

**Retained:** The primary row-sum bound on the source trace remains correct; Finite CAR monomials are contractions in operator norm; No actual first-K48 numerical threshold certificate was claimed in this proposition

**Conditions:** BH-VIA-A-0013; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0011 — MODERATE — INCORRECT_STEP / TYPE_OR_DOMAIN
**First origin:** `p8:sec:tensor-frame-ledger`; VI-A lines 11083–11108.
Conformal Hubble 1-forms satisfy H_Edt_E=H_Jdt_J+(1/2)dlnF; omitting the extra term fails when F varies.

**Precise obligation:** Correct or branch-qualify the conformal Hubble identity in a subsequent source revision; keep other correct frame transformations intact.

**Retained:** Canonical tensor momenta P_h^E=P_h^J; The tensor frame generator A_L^J=sqrt(F)A_L^E; Frame-related mass identity m_E=m_J/sqrt(F)

**Conditions:** BH-VIA-A-0014; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0012 — MINOR — INCORRECT_STEP / MISSING_CONDITION
**First origin:** `p8:prop:shell-algebra-nonterminal-rar`; VI-A lines 9851–9884.
24-cell walk spectrum includes invariant eigenvalue 1 and hence factor 1^n, omitted from displayed exhaustive-looking surviving factors.

**Precise obligation:** Include the invariant 1^n channel or make the mean-zero/orthogonal-to-constant restriction explicit in the original proposition.

**Retained:** Full normalized walk spectrum and multiplicities as printed; Nine-dimensional null-channel result T^n E_2=0; Nontrivial mean-zero n-step channel factor list

**Conditions:** BH-VIA-A-0015; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0013 — MODERATE — EVIDENCE_MISSING / NUMERICAL_REPLAY
**First origin:** `p8:prop:v2184-native-source-memory-regulator`; VI-A lines 11655–11739.
D11/VI-C black-hole numerical history reports small residuals but executable inputs/scripts and JSON are absent in supplied archives.

**Precise obligation:** Supply versioned VI-C-cited v1_9-v1_12 Python executables, v1_12 JSON and full Cauchy/source-strength/buffer data; replay signed marginal radii, lapse/Raychaudhuri residuals, perturbation derivatives, and constraint buffers independently. No paper change at this audit stage.

**Retained:** Analytic finite Cauchy/source and conditional ODE framework as stated; Transversality entails an open zero-survival basin assuming the quoted regular base witness and smooth dependence; Conditional spherical constraint matching equations and locally Lipschitz compact-invariant continuation criterion

**Conditions:** As shown in source-bound gap record; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0014 — MODERATE — PHYSICAL_OWNER_BRIDGE / UNDISCHARGED_CONDITIONAL
**First origin:** `p8:prop:static-acceleration-readout`; VI-A lines 11254–12399.
Scalar collar DtN sqrtR is exact, but a generic same-action Schur Hessian has not been identified with that particular physical acceleration determinant.

**Precise obligation:** Exhibit the actual occurring stationary S_star boundary/interior Schur Hessian on the physically generated scalar zero mode, including β_48 conormal normalization, and prove it equals the proposed Γ_R comparison scalar DtN with physical acceleration observable. Alternatively retain TR1 as explicit conditional physical-identification premise. Do not alter valid abstract DtN/Hopf algebra.

**Retained:** Exact abstract comparison collar DtN spectrum and zero mode; Unique Haar probability normalization on Hopf S² and its 1/(4π) trace-to-density factor; Generic physical boundary Schur reduction and its exact source derivative, under physical stationary-split hypotheses

**Conditions:** BH-VIA-A-0016; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0015 — MODERATE — LOGICAL_GAP / UNDISCHARGED_GENERATOR_EXHAUSTION
**First origin:** `p8:thm:v2112-terminal-causal-cap-occurrence`; VI-A lines 14846–14927.
Finite causal exclusion and redshift do not alone eliminate all exactly nontrivial operational readout generators or certify discrete detachment occurrence.

**Precise obligation:** Establish from the actual finite operator-system/readout constructors a defined notion of asymptotic quotient/triviality and show full exhaustion on the located cap (or explicitly condition occurrence on that additional premise). Do not infer non-scalar-generator disappearance from redshift alone.

**Retained:** Finite causal reach/volume complement on the stipulated finite bound-source domain; Asymptotic material dilution and conditional cap-algebra theorem assuming full generator exhaustion; Definition and selector identities for ζ_D

**Conditions:** BH-VIA-A-0018, BH-VIA-A-0019; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0016 — MODERATE — UNDISCHARGED_IMPORTED_BOUNDARY_CONDITION
**First origin:** `p8:thm:complete-cap-zero-cotangent`; VI-A lines 15372–15426.
Zero intrinsic daughter momentum consumes upstream locally constant inherited boundary functional BH-IIIA-A-0042, not discharged merely by no parent readout.

**Precise obligation:** Provide a source-bound proof that the specific inherited complete boundary functional is locally constant on the daughter homogeneous boundary role, or retain BH-IIIA-A-0042 as an explicit unresolved antecedent. Do not equate absence of external impulse with zero intrinsic momentum.

**Retained:** Paper III-A boundary-trivial lemma under its explicit two hypotheses; Conditional zero-cotangent to H0=dot X0=0 algebra; Conditional closed-FLRW bounce radius/sign algebra

**Conditions:** BH-IIIA-A-0042, BH-IIIA-A-0043; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0017 — MODERATE — MISSING_PHYSICAL_CONSTRUCTOR_CERTIFICATE
**First origin:** `p8:cor:v2112-no-duplicate-lineage-occurrence`; VI-A lines 15104–15644.
Conditional II-A no-idle/co-realization needs a frozen licensed cap→daughter dynamical/occurrence constructor; structural reset alone is not its certificate.

**Precise obligation:** Locate and certify the existing pre-frozen typed cap-to-daughter dynamical/occurrence constructor, exact full inputs, nonredundant output sort, and R≼ΣP relation, or scope the daughter history as conditional on that constructor. No new constructor is to be invented in this audit.

**Retained:** Structural I8/q=0 reset on a complete cap; Primitive Hopf residue and daughter root normalization; Conditional K8/K16/K48 crossings for a supplied regular daughter history

**Conditions:** BH-VIA-A-0020, BH-IIA-A-B37-GEN-ROLE-001; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

## Final batch exact checks

Native constant `A=4π²+1/(6√2)≈39.596268734555` and `Q≈3.17183e+09`. Independent quadrature gives:

| Candidate j | Potential-end q | Printed approximate q |
|---:|---:|---:|
| 1 | 0.516686676 | 0.516687 |
| 2 | 0.566388774 | 0.566389 |
| 3 | 0.566388773 | 0.566389 |
| 4 | 0.566388773 | 0.566389 |

The terminal selector, S³ causal-ball volume, positive mass/force subclaims, full Hopf residue, Planck-square rewrite, cyclic-root ratio, FLRW constraint, source corner energy, conditional radiation/dust separatrix, and exact coefficient work readout passed their specific controls. E4 controls also confirm that norm-decay does not automatically trivialize an exact algebra, absence of source impulse does not force zero bulk momentum, and nonzero corner energy cannot disappear under continuous finite-state evolution.

## Imported theorem boundary firewall

- II-A no-idle: licensed frozen constructor + all generated inputs + required nonredundant typed output. Its source warns mathematical availability alone is insufficient.
- II-A generated-role co-realization: a separately established role relation inside an occurring parent, not physical occurrence of every possible state or process.
- III-A boundary-trivial: both (i) locally constant inherited boundary functional (existing canonical `BH-IIIA-A-0042`) AND (ii) no new independent varying boundary functional (`BH-IIIA-A-0043`). No duplicate assumptions introduced.
- VI-A complete-cap definition implies compact operator-system triviality by definition; an actual time-dependent complete-cap history is a separate assertion.

## Named claim source index and dispositions

| Claim | Source lines | Source title | Status |
|---|---:|---|---|
| `BH-VIA-C-0001` | 108–131 | Global scope of the distinct normalization tests | `FORMALIZED` |
| `BH-VIA-C-0002` | 224–240 | Structural boundary/interface status after parent-collar descent | `REPRODUCED` |
| `BH-VIA-C-0003` | 273–296 | Grade-four comparison coefficient and exact carrier-four $K16$ midpoint | `REPRODUCED` |
| `BH-VIA-C-0004` | 299–340 | Exact grade-four onset in same-action curvature coefficients | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0005` | 363–388 | Conditional Starobinsky UV scalaron in closed FLRW | `REPRODUCED` |
| `BH-VIA-C-0006` | 389–408 | Closed particle work and finite-source matching | `REPRODUCED` |
| `BH-VIA-C-0007` | 409–418 | Structural versus physical clocks and infrared reduction | `FORMALIZED` |
| `BH-VIA-C-0008` | 419–442 | Recomputed rank-four inflation comparison, $N=56$ | `FORMALIZED` |
| `BH-VIA-C-0009` | 443–451 | K48 independent of the ultraviolet dress rank | `FORMALIZED` |
| `BH-VIA-C-0010` | 452–465 | Historical D15/D16 and decay benchmark correction | `FORMALIZED` |
| `BH-VIA-C-0011` | 526–588 | Compressed residual status through Paper VI-B | `FORMALIZED` |
| `BH-VIA-C-0012` | 600–631 | Complete action on the declared cosmological domain | `REPRODUCED` |
| `BH-VIA-C-0013` | 727–746 | Native cyclic \(\mathrm{REN}_0\) retirement and terminal higher-order extinction | `REPRODUCED` |
| `BH-VIA-C-0014` | 780–806 | Compact boundary exclusion is not a source channel | `REPRODUCED` |
| `BH-VIA-C-0015` | 818–861 | Common-action reciprocal-position source normalization | `REPRODUCED` |
| `BH-VIA-C-0016` | 919–932 | Source conservation and internal equivalence relation | `REPRODUCED` |
| `BH-VIA-C-0017` | 944–968 | Reciprocal-position source dependency chain | `REPRODUCED` |
| `BH-VIA-C-0018` | 981–991 | Low-curvature Levi--Civita channel | `FORMALIZED` |
| `BH-VIA-C-0019` | 993–1000 | No downstream shell-count source premise | `FORMALIZED` |
| `BH-VIA-C-0020` | 1031–1148 | Positive-part Laurent clocks and restored local-jet Laurent--Legendre action | `REPRODUCED` |
| `BH-VIA-C-0021` | 1150–1186 | Depth-two dressing selects the exact \(K=16\) density scale | `REPRODUCED` |
| `BH-VIA-C-0022` | 1197–1210 | Persistent \(n_7^+\) owner and the RAR branch | `FORMALIZED` |
| `BH-VIA-C-0023` | 1212–1241 | Optional smooth-MRESP susceptibility comparison | `REPRODUCED` |
| `BH-VIA-C-0024` | 1255–1262 | Comparison status of the entropy-Hessian graph | `FORMALIZED` |
| `BH-VIA-C-0025` | 1334–1359 | Paper~III contact-residue interface imported here | `FORMALIZED` |
| `BH-VIA-C-0026` | 1361–1371 | Contact dimension and flat-cone scope | `FORMALIZED` |
| `BH-VIA-C-0027` | 1398–1401 | Paper--VI-A gravitational closure boundary | `REPRODUCED` |
| `BH-VIA-C-0028` | 1601–1623 | A constructive first right-$2I$ scalar harmonic | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0029` | 1636–1645 | Three constructive primitive angular-to-$S^3$ channels | `REPRODUCED` |
| `BH-VIA-C-0030` | 1647–1657 | Reciprocal factorwise comparison; not an extra $M_8$ action | `REPRODUCED` |
| `BH-VIA-C-0031` | 1659–1671 | Gravitational scope and first anisotropy order | `FORMALIZED` |
| `BH-VIA-C-0032` | 1715–1746 | Six finite protected crossovers and one terminal endpoint | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0033` | 1759–1804 | Closed-FLRW octet reflection and self-dual midpoint | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0034` | 1822–1875 | Scheme-uniform final-octet complement and covariant K=48 pullback | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0035` | 1892–1936 | Primitive-remnant depletion across the final octet | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0036` | 1956–2003 | Canonical Hopf representative and exact final-octet descent | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0037` | 2026–2073 | Closed-FLRW Hodge realization fixes the neutral \(a^{-3}\) shape | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0038` | 2084–2104 | Chronology requires an actual transverse curvature crossing | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0039` | 2113–2124 | Crossing event as a unique-history descendant | `REPRODUCED` |
| `BH-VIA-C-0040` | 2126–2178 | Exact effective-dust law conditional on same-action geometric occurrence | `UNRESOLVED` |
| `BH-VIA-C-0041` | 2192–2203 | Topological and isocurvature scope | `FORMALIZED` |
| `BH-VIA-C-0042` | 2205–2222 | Typed hierarchy-event predicate | `FORMALIZED` |
| `BH-VIA-C-0043` | 2224–2241 | Typed hierarchy-event identification | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0044` | 2254–2266 | Born-midpoint curvature realization of a typed hierarchy rung | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0045` | 2268–2287 | Derived \(K=16\) coefficient-freeze event predicate | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0046` | 2289–2304 | Status of the seven familiar labels | `FORMALIZED` |
| `BH-VIA-C-0047` | 2306–2329 | Historical rank-two reflection and no-particle firewall | `REPRODUCED` |
| `BH-VIA-C-0048` | 2338–2348 | Meaning of the protected number fifty-six | `FORMALIZED` |
| `BH-VIA-C-0049` | 2350–2373 | Position unfolding level | `FORMALIZED` |
| `BH-VIA-C-0050` | 2375–2412 | Conditional fixed-band spatial stabilization and sharp-frontier discharge | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0051` | 2436–2478 | Finite position-side scalar remnant and the typed export boundary | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0052` | 2494–2504 | A sufficient history for complete-band spatial stabilization | `REPRODUCED` |
| `BH-VIA-C-0053` | 2523–2543 | Unresolved, resolved, and crossover visibility | `FORMALIZED` |
| `BH-VIA-C-0054` | 2545–2557 | Visibility monotonicity and band localization | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0055` | 2563–2586 | Typed readout ledger on six finite landmarks and the terminal completion | `FORMALIZED` |
| `BH-VIA-C-0056` | 2597–2611 | Octahedral carrier readout near the \(E_{36}\) interface | `FORMALIZED` |
| `BH-VIA-C-0057` | 2613–2622 | Dynamic meaning of the octahedral quotient readout | `FORMALIZED` |
| `BH-VIA-C-0058` | 2624–2648 | Optional smooth-MRESP convexity and algebraic terminal freeze | `REPRODUCED` |
| `BH-VIA-C-0059` | 2660–2670 | Active Laurent indices and comparison exponent | `FORMALIZED` |
| `BH-VIA-C-0060` | 2672–2690 | No compact vacuum from the positive smooth Born heat tower through \(a_4\) | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0061` | 2726–2743 | Three distinct dimensional hierarchy exports | `FORMALIZED` |
| `BH-VIA-C-0062` | 2850–2868 | Global \(2I\) perturbation endpoint and local particle core | `FORMALIZED` |
| `BH-VIA-C-0063` | 2885–2918 | Paper-I-A exceptional ranks with Paper-V-B readout chronology | `FORMALIZED` |
| `BH-VIA-C-0064` | 2925–2965 | Imported protected structural resolution clock | `FORMALIZED` |
| `BH-VIA-C-0065` | 2977–2984 | Structural clock without a shell-source phase selector | `FORMALIZED` |
| `BH-VIA-C-0066` | 2987–3002 | Protected non-carrier rungs in the cosmological clock | `FORMALIZED` |
| `BH-VIA-C-0067` | 3433–3455 | Lapse extraction of the same-action potential | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0068` | 3478–3495 | Complete homogeneous canonical constraint | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0069` | 3535–3562 | Regular separated Born--Legendre consequences | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0070` | 3580–3612 | Historical copied-response endpoint as an affine displacement | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0071` | 3631–3641 | Terminal quotient and active sharp branch remain distinct | `FORMALIZED` |
| `BH-VIA-C-0072` | 3666–3680 | Current working action retains its native-identification obligations | `FORMALIZED` |
| `BH-VIA-C-0073` | 3683–3710 | Capped working-action vacuum location and positive scalaron sign | `REPRODUCED` |
| `BH-VIA-C-0074` | 3783–3837 | Exact nonlinear scalaron force potential and work identity | `REPRODUCED` |
| `BH-VIA-C-0075` | 3852–3872 | One force numerator controls Jordan evolution and Einstein-frame slope | `REPRODUCED` |
| `BH-VIA-C-0076` | 3874–3917 | Closed-FLRW constrained scalaron generator and flow boundary | `REPRODUCED` |
| `BH-VIA-C-0077` | 3934–3960 | Unique lower stationary curvature and running positive scalaron mass | `REPRODUCED` |
| `BH-VIA-C-0078` | 3978–4015 | Exact lower stationary source interval and susceptibility | `REPRODUCED` |
| `BH-VIA-C-0079` | 4032–4046 | Regular terminal stationary source limit | `REPRODUCED` |
| `BH-VIA-C-0080` | 4054–4064 | Stationary source domain and dynamical scope | `FORMALIZED` |
| `BH-VIA-C-0081` | 4066–4091 | Variable-susceptibility scalaron law and terminal susceptibility decoupling | `REPRODUCED` |
| `BH-VIA-C-0082` | 4100–4116 | Adiabatic local-oscillation statement | `UNRESOLVED` |
| `BH-VIA-C-0083` | 4118–4128 | Trace-source work remains same-action | `REPRODUCED` |
| `BH-VIA-C-0084` | 4130–4159 | Structural resolution parameter is not generic physical scalaron time | `FORMALIZED` |
| `BH-VIA-C-0085` | 4168–4174 | Cold behavior is not a dark-matter normalization | `FORMALIZED` |
| `BH-VIA-C-0086` | 4176–4218 | Terminal endpoint spectral handoff | `REPRODUCED` |
| `BH-VIA-C-0087` | 4248–4253 | Deferred Paper~III infrared realization is covered on the cosmological branch | `FORMALIZED` |
| `BH-VIA-C-0088` | 4292–4310 | Trace-force cubic and quartic vertices | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0089` | 4323–4342 | Uniform restoring-mass positivity for the restored action | `REPRODUCED` |
| `BH-VIA-C-0090` | 4356–4361 | One regular vacuum root in the hierarchy window | `FORMALIZED` |
| `BH-VIA-C-0091` | 4382–4396 | Unique restored trace response and controlled inverse | `REPRODUCED` |
| `BH-VIA-C-0092` | 4454–4514 | Active Laurent coupling, convexity, and physical scalaron-mass domain | `REPRODUCED` |
| `BH-VIA-C-0093` | 4529–4536 | Optional smooth-MRESP local comparison | `FORMALIZED` |
| `BH-VIA-C-0094` | 4538–4588 | Sufficient thin-shell and PPN recovery criterion | `UNRESOLVED` |
| `BH-VIA-C-0095` | 4605–4620 | Distinct scalaron and dark-sector projections | `FORMALIZED` |
| `BH-VIA-C-0096` | 4645–4663 | Round-$S^3$ scalar stress projections | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0097` | 4689–4715 | Full resolved scalar Einstein bulk reconstruction | `REPRODUCED` |
| `BH-VIA-C-0098` | 4744–4794 | Dependent finite causal scalar source--metric composition | `REPRODUCED` |
| `BH-VIA-C-0099` | 4862–4900 | Complete functional scalar source--metric composition | `REPRODUCED` |
| `BH-VIA-C-0100` | 4921–4970 | Guarded free Dirac stress Ward and scalar contact closure | `REPRODUCED` |
| `BH-VIA-C-0101` | 5054–5074 | One exceptional curvature owner, one scalaron root, multiple response projections | `FORMALIZED` |
| `BH-VIA-C-0102` | 5085–5104 | Positive frame norm must not be replaced by a signed curvature invariant | `FORMALIZED` |
| `BH-VIA-C-0103` | 5106–5128 | FLRW enthalpy complement does not constitute a second scalaron | `REPRODUCED` |
| `BH-VIA-C-0104` | 5138–5174 | All-orders traceless-Ricci identities on exact closed FLRW | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0105` | 5184–5193 | Parity-odd pure-metric background scalars | `FORMALIZED` |
| `BH-VIA-C-0106` | 5197–5250 | The six-derivative radiation/tidal term is a conditional heat diagnostic | `REPRODUCED` |
| `BH-VIA-C-0107` | 5252–5272 | Exact same-action scalaron matching with non-scalar forcing | `REPRODUCED` |
| `BH-VIA-C-0108` | 5274–5292 | Preservation of the established K48 and terminal scope | `FORMALIZED` |
| `BH-VIA-C-0109` | 5294–5306 | Scope of the achieved consistency and remaining exact task | `FORMALIZED` |
| `BH-VIA-C-0110` | 5315–5347 | Exact complete FLRW curvature reconstruction from the scalaron and residual | `REPRODUCED` |
| `BH-VIA-C-0111` | 5358–5385 | Noether integrability and exact effective-fluid criteria | `REPRODUCED` |
| `BH-VIA-C-0112` | 5397–5422 | Ordinary Dirac local six-derivative radiation test is not dust | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0113` | 5447–5455 | Status of generalized curvature--matter closure | `FORMALIZED` |
| `BH-VIA-C-0114` | 5463–5485 | Exact static-patch optical delay of the terminal floor | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0115` | 5492–5506 | The exceptional curvature coordinate vanishes on pure closed de Sitter | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0116` | 5514–5523 | Observable tests and no parent-cone conclusion | `FORMALIZED` |
| `BH-VIA-C-0117` | 5524–5532 | Structural curvature versus physical Ricci curvature | `FORMALIZED` |
| `BH-VIA-C-0118` | 6068–6100 | Hierarchy comparison and canonical scalar normalization | `REPRODUCED` |
| `BH-VIA-C-0119` | 6116–6128 | Strict Laurent susceptibility on the active strata | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0120` | 6152–6172 | Conservative lower-window coefficient and local-range bounds | `REPRODUCED` |
| `BH-VIA-C-0121` | 6190–6207 | Terminal floor and static acceleration share one scale | `FORMALIZED` |
| `BH-VIA-C-0122` | 6247–6267 | Canonical continuation through the $D_k=0$ chart locus | `REPRODUCED` |
| `BH-VIA-C-0123` | 6287–6300 | Chart connection is not physical source work | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0124` | 6310–6321 | Exact minimum criterion for the physical scalar root | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0125` | 6330–6343 | Persistent positive Euler energy is not empty root excitation | `REPRODUCED` |
| `BH-VIA-C-0126` | 6388–6404 | Final local interval duration for a positive amplitude | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0127` | 6424–6434 | Integrated budget for an exactly cold local trajectory | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0128` | 6464–6487 | Source-subtracted terminal amplitude and pressure test | `REPRODUCED` |
| `BH-VIA-C-0129` | 6504–6527 | Conserved cold charge and terminal Ricci test | `REPRODUCED` |
| `BH-VIA-C-0130` | 6591–6613 | A finite observation slice is not the asymptotic limit | `FORMALIZED` |
| `BH-VIA-C-0131` | 6615–6642 | Retained native-scalar low modes are a separate restriction | `FORMALIZED` |
| `BH-VIA-C-0132` | 6754–6777 | Same-action homogeneous curvature-response exchange | `REPRODUCED` |
| `BH-VIA-C-0133` | 6787–6818 | Homogeneous Schur response of the retained scalaron | `REPRODUCED` |
| `BH-VIA-C-0134` | 6970–6979 | REG0 finite-denominator compatibility | `REPRODUCED` |
| `BH-VIA-C-0135` | 6988–7008 | Exact dust--vacuum reacceleration scale | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0136` | 7017–7026 | Non-derivability of a fixed reacceleration depth from \(\delta\) | `FORMALIZED` |
| `BH-VIA-C-0137` | 7036–7077 | Closed-FLRW reacceleration depth with its unavoidable integration constant | `REPRODUCED` |
| `BH-VIA-C-0138` | 7092–7094 | Curvature magnitude handoff | `FORMALIZED` |
| `BH-VIA-C-0139` | 7115–7124 | Quasilocal causal scalar phase support | `FORMALIZED` |
| `BH-VIA-C-0140` | 7126–7134 | FLRW apparent-horizon radius from the quasilocal support premise | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0141` | 7153–7177 | Horizon scalar trace kernel under the minimal bilinear interface premise | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0142` | 7267–7289 | Physical horizon branch | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0143` | 7478–7503 | Regular scalar reduction through the simultaneous turning root | `REPRODUCED` |
| `BH-VIA-C-0144` | 7527–7572 | Positive oscillators at the generated cyclic birth root | `REPRODUCED` |
| `BH-VIA-C-0145` | 7651–7687 | Fresh-root neutral state and QROOT closure | `FORMALIZED` |
| `BH-VIA-C-0146` | 7705–7720 | Ground-support selection on a completed fixed-root source branch | `FORMALIZED` |
| `BH-VIA-C-0147` | 7735–7749 | K48 reach with a subcritical adverse trace | `FORMALIZED` |
| `BH-VIA-C-0148` | 7776–7816 | Exact FLRW restriction of the rooted exceptional curvature map | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0149` | 7818–7834 | Scalar hierarchy lines and complete-curvature circles | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0150` | 7836–7861 | Einstein-form stress coordinates | `REPRODUCED` |
| `BH-VIA-C-0151` | 7863–7883 | Exceptional form of the lower-branch turnaround/bounce sheets | `REPRODUCED` |
| `BH-VIA-C-0152` | 7885–7913 | Homogeneous functional source ports in the exceptional plane | `REPRODUCED` |
| `BH-VIA-C-0153` | 7915–7931 | Scale-weight trace cancellation | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0154` | 7933–7947 | K16 later-rung midpoint trace-depth bound | `FORMALIZED` |
| `BH-VIA-C-0155` | 7966–8015 | Native cyclic G28 handoff closure as a generated parent image | `FORMALIZED` |
| `BH-VIA-C-0156` | 8051–8070 | Abstract full-locus G28 strengthening is not a core physical residual | `FORMALIZED` |
| `BH-VIA-C-0157` | 8152–8183 | Conditioning preserves the response already present | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0158` | 8206–8217 | Framework-native scalaron precedence | `FORMALIZED` |
| `BH-VIA-C-0159` | 8219–8244 | Intrinsic susceptibility decoupling is not a decay width | `FORMALIZED` |
| `BH-VIA-C-0160` | 8246–8270 | Adiabatic coherent-envelope suppression | `REPRODUCED` |
| `BH-VIA-C-0161` | 8272–8304 | Finite ordered-kernel realization of K16 occupations | `FORMALIZED` |
| `BH-VIA-C-0162` | 8306–8321 | Scalaron-driven K16 modulation switches off at the regular terminal limit | `FORMALIZED` |
| `BH-VIA-C-0163` | 8323–8351 | Corrected C06/A22.1 finite frontier | `FORMALIZED` |
| `BH-VIA-C-0164` | 8358–8369 | C06 exceptional-curvature output contract | `FORMALIZED` |
| `BH-VIA-C-0165` | 8371–8395 | First-K48 reach versus complete production history | `FORMALIZED` |
| `BH-VIA-C-0166` | 8402–8421 | Fixed direct-packet energy and resolved occupations | `FORMALIZED` |
| `BH-VIA-C-0167` | 8431–8459 | State-uniform sufficient first-K48 trace certificate | `REPRODUCED` |
| `BH-VIA-C-0168` | 8477–8488 | Incoming sourced-history comparison has no new seed | `FORMALIZED` |
| `BH-VIA-C-0169` | 8510–8549 | Finite row-sum and normalized-word bounds | `UNRESOLVED` |
| `BH-VIA-C-0170` | 8600–8624 | One-sided first-K48 comparison | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0171` | 8641–8675 | Sharper comparison and geometric Hubble bootstrap | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0172` | 8693–8716 | Local matter breaking sign with the native boundary handoff | `FORMALIZED` |
| `BH-VIA-C-0173` | 8768–8802 | Exact CAR upper trace and sharp affine pair bound | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0174` | 8861–8871 | Almost-sure unique optimized planar axis | `REPRODUCED` |
| `BH-VIA-C-0175` | 8901–8909 | Haar axis independent of invariant shape and power | `REPRODUCED` |
| `BH-VIA-C-0176` | 8921–8927 | Nonempty same-shell observer branch | `FORMALIZED` |
| `BH-VIA-C-0177` | 8946–8965 | Gaussian Schur descent and optimized relative-axis law | `REPRODUCED` |
| `BH-VIA-C-0178` | 8984–9006 | Fixed-window covariance test and Gaussian angular pushforward | `REPRODUCED` |
| `BH-VIA-C-0179` | 9045–9062 | First post-inflation Born-boundary response cell | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0180` | 9064–9091 | Exact reheating response law | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0181` | 9093–9112 | In-cell dilution functional | `FORMALIZED` |
| `BH-VIA-C-0182` | 9114–9159 | Physical post-K16 retained-scalaron branch and Schur reductions | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0183` | 9162–9187 | Exact slow-manifold plus coherent-mode decomposition | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0184` | 9189–9206 | K48 as a trace-conditioned crossing | `REPRODUCED` |
| `BH-VIA-C-0185` | 9208–9219 | C06 execution frontier after scalaron-retention correction | `FORMALIZED` |
| `BH-VIA-C-0186` | 9221–9240 | Stationary-tangent Hubble diagnostic | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0187` | 9242–9265 | Visible thermalization and numerical reheating temperature | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0188` | 9267–9277 | Retained scalaron and particle production are one coupled history | `FORMALIZED` |
| `BH-VIA-C-0189` | 9316–9334 | Typed direct K16 structural packet | `FORMALIZED` |
| `BH-VIA-C-0190` | 9336–9363 | K16 particle-boundary owner condition | `FORMALIZED` |
| `BH-VIA-C-0191` | 9365–9381 | K16 state-level saturation criterion | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0192` | 9383–9404 | Ordinary-radiation normalization conditional on PB16 | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0193` | 9406–9428 | Current K16 status | `FORMALIZED` |
| `BH-VIA-C-0194` | 9436–9480 | K16 direct particle-boundary owner | `REPRODUCED` |
| `BH-VIA-C-0195` | 9501–9531 | PB16 owner closure and conditional physical stress normalization | `REPRODUCED` |
| `BH-VIA-C-0196` | 9534–9544 | Support and complete stress use | `FORMALIZED` |
| `BH-VIA-C-0197` | 9547–9567 | Particle-sector closure versus visible-only exhaustion | `FORMALIZED` |
| `BH-VIA-C-0198` | 9569–9584 | Supersession of the v2.135 owner frontier | `FORMALIZED` |
| `BH-VIA-C-0199` | 9592–9623 | Inflation-end conditioned remainder of the K8--K16 cell | `FORMALIZED` |
| `BH-VIA-C-0200` | 9625–9641 | Exact conditioned flow | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0201` | 9643–9663 | Neutral charge-two boundary owner target | `FORMALIZED` |
| `BH-VIA-C-0202` | 9665–9681 | Native inflation-exit baryogenesis status | `REPRODUCED` |
| `BH-VIA-C-0203` | 9683–9691 | K24 bridge scope without a source-phase postulate | `FORMALIZED` |
| `BH-VIA-C-0204` | 9700–9722 | Native $K=32$ hierarchy curvature length | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0205` | 9724–9732 | Metre comparison is validation/metrology | `FORMALIZED` |
| `BH-VIA-C-0206` | 9744–9771 | Baryogenesis roles after the incidence correction | `REPRODUCED` |
| `BH-VIA-C-0207` | 9773–9781 | K16--K24 response is not the asymmetry | `FORMALIZED` |
| `BH-VIA-C-0208` | 9820–9839 | Gravitational scalaron core and static ownership boundary | `FORMALIZED` |
| `BH-VIA-C-0209` | 9851–9884 | Finite shell algebra constraint on decompositions of the exact RAR response | `UNRESOLVED` |
| `BH-VIA-C-0210` | 9949–9970 | Canonical multiplicative imbalance group | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0211` | 9985–10026 | Born-balance continuation rigidity on a fixed product leaf | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0212` | 10041–10054 | Sector-specific instance of universal continuation | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0213` | 10056–10068 | No unmarked linear visibility-to-balance bridge | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0214` | 10077–10089 | Exact scope of the Born-balance law | `FORMALIZED` |
| `BH-VIA-C-0215` | 10105–10144 | Environment-conditioned terminal $S+T$ response | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0216` | 10161–10183 | No universal one-variable baryons-only RAR on the full environmental class | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0217` | 10185–10215 | Same-action $H/S$ source-conditioned response; no additive cDM force | `REPRODUCED` |
| `BH-VIA-C-0218` | 10217–10239 | Homogeneous $C_6$ is not the static selected floor | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0219` | 10241–10275 | Exact running-mass adiabaticity diagnostic | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0220` | 10288–10317 | Sufficient local-well residence certificate | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0221` | 10333–10342 | Residence and first-passage scope | `FORMALIZED` |
| `BH-VIA-C-0222` | 10353–10366 | K48 H-owned terminal relation consumption | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0223` | 10368–10384 | K48 H-response normalization jet | `FORMALIZED` |
| `BH-VIA-C-0224` | 10386–10404 | Same-owner post-K48 matter-like continuation | `REPRODUCED` |
| `BH-VIA-C-0225` | 10406–10419 | Homogeneous/inhomogeneous response split | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0226` | 10421–10430 | No-double-counting firewall | `FORMALIZED` |
| `BH-VIA-C-0227` | 10432–10446 | K48 normalization shortcut firewall | `FORMALIZED` |
| `BH-VIA-C-0228` | 10454–10479 | K48 zero-order and quadratic-response exhaustion | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0229` | 10481–10506 | Unit K48 H-response normalization | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0230` | 10508–10520 | Unit-normalized same-owner post-K48 dust branch | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0231` | 10522–10532 | Retired K48 normalization routes and surviving frontiers | `FORMALIZED` |
| `BH-VIA-C-0232` | 10540–10567 | No native K48-to-dust first-integral constructor in the current grammar | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0233` | 10569–10587 | Endpoint normalization versus optional exact dust | `FORMALIZED` |
| `BH-VIA-C-0234` | 10589–10622 | Constraint-reduced homogeneous boundary propagator | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0235` | 10624–10660 | Resolved closed-$S^3$ cold scalar constraint propagator | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0236` | 10662–10694 | Collisionless environmental dynamic source block | `REPRODUCED` |
| `BH-VIA-C-0237` | 10696–10711 | Conditional causal boundary impedance | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0238` | 10713–10747 | Revised K48/RAR frontier | `FORMALIZED` |
| `BH-VIA-C-0239` | 10769–10772 | Round-Dirac eta source boundary for tensor helicity | `FORMALIZED` |
| `BH-VIA-C-0240` | 10774–10777 | Beltrami helicity is the orientation datum | `FORMALIZED` |
| `BH-VIA-C-0241` | 10779–10794 | Protected reciprocal transverse response is not the parity-odd Hopf source | `FORMALIZED` |
| `BH-VIA-C-0242` | 10797–10816 | Complementary protected sign projectors have the same connection | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0243` | 10831–10839 | Canonical Hopf--Chern--Simons tensor transfer | `FORMALIZED` |
| `BH-VIA-C-0244` | 10841–10877 | Parity-odd density and the state-conditioned zero-transfer branch | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0245` | 10901–10951 | Native cyclic complete-shell covariance | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0246` | 10993–11009 | Unmarked exceptional shell fractions are not selected finite projectors | `FORMALIZED` |
| `BH-VIA-C-0247` | 11021–11053 | Native cyclic tensor covariance | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0248` | 11116–11144 | Regular causal tensor and Dirac source system | `REPRODUCED` |
| `BH-VIA-C-0249` | 11169–11178 | Regular tensor source inheritance | `REPRODUCED` |
| `BH-VIA-C-0250` | 11215–11233 | Infrared action dominance and the ambient floor | `REPRODUCED` |
| `BH-VIA-C-0251` | 11238–11251 | Static response curvature and selected ambient floor | `FORMALIZED` |
| `BH-VIA-C-0252` | 11254–11274 | Static scalaron-lapse boundary-value comparison | `FORMALIZED` |
| `BH-VIA-C-0253` | 11276–11292 | Dirichlet-to-Neumann eigenvalue of the terminal branch | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0254` | 11311–11347 | Static determinant trace and local acceleration readouts | `UNRESOLVED` |
| `BH-VIA-C-0255` | 11379–11382 | Static determinant readout versus other scalaron projections | `FORMALIZED` |
| `BH-VIA-C-0256` | 11411–11420 | Bounded faithful metric/action realization | `REPRODUCED` |
| `BH-VIA-C-0257` | 11437–11452 | Attained fixed-source density maximum | `REPRODUCED` |
| `BH-VIA-C-0258` | 11465–11484 | Free-generator bounds on physical radii | `REPRODUCED` |
| `BH-VIA-C-0259` | 11497–11517 | Spherical curvature compression and turning test | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0260` | 11532–11572 | Local areal reversal from the native first-jet action | `REPRODUCED` |
| `BH-VIA-C-0261` | 11594–11614 | Native scalar momentum at the admitted turning point | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0262` | 11655–11685 | Numerically certified native source-memory regulation member | `UNRESOLVED` |
| `BH-VIA-C-0263` | 11687–11705 | Open regulating basin around the certified member | `UNRESOLVED` |
| `BH-VIA-C-0264` | 11707–11739 | Explicit spherical constraint-buffer matching | `UNRESOLVED` |
| `BH-VIA-C-0265` | 11741–11759 | Nonzero axial product-band horizon representation firewall | `FORMALIZED` |
| `BH-VIA-C-0266` | 11770–11781 | Sufficient regular finite continuation criterion | `REPRODUCED` |
| `BH-VIA-C-0267` | 11866–11923 | Final-octet homogeneous $H$-modality co-realization | `REPRODUCED` |
| `BH-VIA-C-0268` | 11975–12010 | Finite final-octet carrier energy | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0269` | 12197–12218 | Uniqueness of the native terminal deep coefficient | `REPRODUCED` |
| `BH-VIA-C-0270` | 12302–12399 | Exact fixed-environment same-action response operator | `UNRESOLVED` |
| `BH-VIA-C-0271` | 12431–12465 | Scalar reduction, optional Reeb branch and remaining instance-level work | `FORMALIZED` |
| `BH-VIA-C-0272` | 12482–12495 | Exact mean-zero compact Poisson inverse | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0273` | 12518–12539 | Exact radial flux and local curvature correction | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0274` | 12552–12571 | Spectral realization and operator-specific extensions | `REPRODUCED` |
| `BH-VIA-C-0275` | 12580–12596 | Physical operator and readout scope | `FORMALIZED` |
| `BH-VIA-C-0276` | 12616–12646 | Isotropic response stress and the two homogeneous ports | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0277` | 12662–12684 | Compact Poisson projection does not erase a nonlinear mean | `REPRODUCED` |
| `BH-VIA-C-0278` | 12728–12768 | Exact response energy and ratio evolution | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0279` | 12777–12786 | Closed geometry does not force a changing abundance ratio | `FORMALIZED` |
| `BH-VIA-C-0280` | 12790–12821 | Local adiabatic energy reduction and geometric pressure | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0281` | 12829–12847 | Conditional matter-attached boundary dressing | `REPRODUCED` |
| `BH-VIA-C-0282` | 12859–12883 | Curvature-corrected response reconstruction | `REPRODUCED` |
| `BH-VIA-C-0283` | 12892–12911 | Closed vacuum changes Hubble rate without changing the floor | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0284` | 12944–12987 | Source-loaded scalar restriction of the physical static action | `REPRODUCED` |
| `BH-VIA-C-0285` | 13011–13024 | What the sign test does and does not exclude | `FORMALIZED` |
| `BH-VIA-C-0286` | 13028–13052 | Exact compact static response spectrum and radial kernel | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0287` | 13062–13075 | The global regular part is retained in energy | `FORMALIZED` |
| `BH-VIA-C-0288` | 13079–13095 | Compact modal mean and its homogeneous component | `REPRODUCED` |
| `BH-VIA-C-0289` | 13103–13130 | Uniform geodesic ball: explicit compact energy | `REPRODUCED` |
| `BH-VIA-C-0290` | 13139–13161 | Small-source sphere and disk energy coefficients | `REPRODUCED` |
| `BH-VIA-C-0291` | 13176–13195 | Canonical source and susceptibility scale derivatives | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0292` | 13203–13230 | Scale work of the compact quadratic energy | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0293` | 13297–13320 | Compact cubic solvability, amplitude and induced-energy sign | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0294` | 13342–13358 | Critical spatial scale weight and conditional coldness | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0295` | 13471–13486 | Static and temporal tests have different closure obligations | `FORMALIZED` |
| `BH-VIA-C-0296` | 13546–13566 | Direct state-conditioned cubic polarization | `REPRODUCED` |
| `BH-VIA-C-0297` | 13589–13608 | Radial law and a state-defined crossover | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0298` | 13643–13662 | Gaussian moment relation and energy-allocation scope | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0299` | 13696–13714 | Full state-conditioned cubic scale law | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0300` | 13762–13768 | A cancellation witness and the physical-port distinction | `REPRODUCED` |
| `BH-VIA-C-0301` | 13804–13830 | Invariant preparation and homogeneous physical ports | `REPRODUCED` |
| `BH-VIA-C-0302` | 13870–13915 | Closed-S3 local mode and endpoint pump certificate | `REPRODUCED` |
| `BH-VIA-C-0303` | 13959–13981 | A sufficient static contact--memory margin | `REPRODUCED` |
| `BH-VIA-C-0304` | 13996–14032 | Same-source static softening bounds the even dynamic response | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0305` | 14058–14089 | Quantitative cold mean on a common-action allocation | `REPRODUCED` |
| `BH-VIA-C-0306` | 14127–14151 | A sufficient computable complete-source continuation barrier | `REPRODUCED` |
| `BH-VIA-C-0307` | 14172–14194 | Local native Noether-charge entropy, with its scalar coefficient | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0308` | 14244–14268 | Positive complete-curvature coordinates on the product frame | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0309` | 14277–14326 | Same-action residual scalar, shear and curvature-flow budget | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0310` | 14337–14364 | Exact generalized-area focusing and the signed source budget | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0311` | 14375–14421 | Constrained rolling scalaron--shape Hessian | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0312` | 14514–14549 | Active strong-field obligations after the evaluated feedback | `FORMALIZED` |
| `BH-VIA-C-0313` | 14598–14615 | Connected-floor no-go for ordinary voids | `REPRODUCED` |
| `BH-VIA-C-0314` | 14621–14656 | Scalar phase support and detached-cap selector | `FORMALIZED` |
| `BH-VIA-C-0315` | 14658–14685 | Scalar phase decoupling | `REPRODUCED` |
| `BH-VIA-C-0316` | 14691–14710 | Complete parent-relative empty cap | `FORMALIZED` |
| `BH-VIA-C-0317` | 14712–14736 | Compact-side parent-relative readout object | `FORMALIZED` |
| `BH-VIA-C-0318` | 14738–14755 | Complete-empty compact-readout no-go | `REPRODUCED` |
| `BH-VIA-C-0319` | 14804–14828 | Asymptotic complete-cap criterion | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0320` | 14846–14874 | Terminal causal-cap occurrence on the native finite-readout branch | `UNRESOLVED` |
| `BH-VIA-C-0321` | 14931–14964 | Operational complete-cap vacuum closure and ambient-state firewall | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0322` | 14986–15055 | Active-index freeze and complete raw \(n_2\mid n_7\) cap valuation | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0323` | 15083–15101 | The terminal reciprocal transition actually occurs | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0324` | 15104–15129 | Complete-cap structural fresh-root reclosure | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0325` | 15148–15189 | Typed structural and dressed root reset | `REPRODUCED` |
| `BH-VIA-C-0326` | 15191–15244 | Complete-cap dressed seed to daughter curvature-square handoff | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0327` | 15258–15309 | Primitive Hopf-residue cyclic reclosure | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0328` | 15330–15370 | Planck-curvature-square normalization of cyclic reclosure | `REPRODUCED` |
| `BH-VIA-C-0329` | 15372–15401 | Complete-cap intrinsic zero-cotangent reclosure | `UNRESOLVED` |
| `BH-VIA-C-0330` | 15429–15465 | Hopf-residue-selected same-action root Cauchy datum and outgoing bounce | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0331` | 15497–15518 | Finite regular K16 arrival on the restored source-free cyclic lineage | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0332` | 15556–15564 | Cyclic K16 reach status | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0333` | 15567–15595 | Unique transverse first-cell Born boundary on the cyclic daughter | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0334` | 15614–15621 | Boundary, not slow-roll endpoint | `FORMALIZED` |
| `BH-VIA-C-0335` | 15623–15645 | No duplicate cap-lineage or homogeneous occurrence | `UNRESOLVED` |
| `BH-VIA-C-0336` | 15648–15697 | Cyclic-lineage downstream homogeneous-history propagation | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0337` | 15699–15736 | Complete-cap terminal freeze and same-action carrier renewal | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0338` | 15754–15782 | Root-to-terminal curvature hierarchy and fresh-root reaccessibility | `REPRODUCED` |
| `BH-VIA-C-0339` | 15795–15822 | Vacuum-curvature interpretation firewall | `FORMALIZED` |
| `BH-VIA-C-0340` | 15824–15839 | Scope of the cyclic-lineage theorem | `FORMALIZED` |
| `BH-VIA-C-0341` | 15849–15870 | Cosmological position unfolding preserves the $m_p=1$/$m_{\rm cmp}=2$ distinction | `FORMALIZED` |
| `BH-VIA-C-0342` | 16196–16207 | Structural endpoint interface after parent-collar descent | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0343` | 16276–16310 | Finite source-free/traceless K48 reach on the restored lower branch | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0344` | 16312–16327 | K48 underdamping is not the remaining scale problem | `VERIFIED-CONDITIONAL` |
| `BH-VIA-C-0345` | 16329–16343 | Scalaron part of the terminal G28 Schur obligation | `FORMALIZED` |
| `BH-VIA-C-0346` | 16352–16371 | Root energy and its expanding-branch transport | `REPRODUCED` |
| `BH-VIA-C-0347` | 16468–16486 | A canonical corner cannot delete incoming scalaron energy | `REPRODUCED` |
| `BH-VIA-C-0348` | 16516–16528 | Restricted free loading and retained population | `FORMALIZED` |
| `BH-VIA-C-0349` | 16599–16611 | Executed gauge work in the coupled budget | `FORMALIZED` |
| `BH-VIA-C-0350` | 16612–16619 | Statistics and the source-to-target map | `FORMALIZED` |
| `BH-VIA-C-0351` | 16658–16675 | Radiation/dust continuation threshold | `REPRODUCED` |
| `BH-VIA-C-0352` | 16795–16811 | Candidate-independent potential end range | `REPRODUCED` |
| `BH-VIA-C-0353` | 16910–16926 | The end-range antecedent need not be read from the selected depth | `REPRODUCED` |
| `BH-VIA-C-0354` | 17003–17020 | Finite native energy variation in an exact coefficient frame | `REPRODUCED` |
| `BH-VIA-C-0355` | 17066–17091 | Identification of energy currents requires their actual same-action equality | `FORMALIZED` |
| `BH-VIA-C-0356` | 17161–17183 | Scalar vacuum agreement does not certify the tensor action | `REPRODUCED` |
| `BH-VIA-C-0357` | 17233–17248 | Claim-specific native gravitational action certificate | `FORMALIZED` |

## Dependency and evidence release notes

- Cumulative source-traced typed edges: 289. Batch 6 introduces 102 source-exact uses/guards; citation-only and missing-premise links are explicitly quarantined.
- Conditions are introduced exactly once in the VI-A local layer; imported III-A boundary-constancy conditions are reused from the existing global DAG.
- `FULLY_AUDITED_WITH_OPEN_GAPS` is source-census coverage. `FORMALIZED` does not denote an independent theorem proof, and checked `VERIFIED-CONDITIONAL` outcomes do not imply their antecedent occurs.
- Complete Paper VI-C and Paper II/III independent re-audits were outside the one-paper scope; only material imports were traced.
- Original paper, TeX, PDFs and baseline ZIPs were not altered.
