# Paper VI-A audit layer v1_1

Source: Paper6A-GravityCosmology-v2_253.tex (SHA256 `3110e5c951b395665f54a2a910dd6e3570eb9659e775d3b0b4128e6fe28a82d1`), v2.371 paper corpus.

All 17,251 lines and 357 named result objects have a source-bound audit disposition; 17 independent gap roots remain open. All six batches yielded 354/354 passing *scoped controls*, including adversarial counterexamples. These are not 357 complete independent proof certificates.

The `AuditClaimLedger.json` is the authoritative source-as-printed census. `GapRegistry.json` contains 17 root issues; `AssumptionRegistry.json` introduces 20 first-known local guards and reuses upstream III-A canonical identifiers; `TypedDependencyEdges.json` preserves 289 typed links. Only 49 source-matched material links are eligible for proof-traversal in the combined DAG. All other 240 links remain non-traversable, even when a citation is syntactically valid.

`ProofRoutes.json` records AND-material inputs and undischarged branch guards; neither inherited status nor the existence of a route certifies physical occurrence. `ImpactIndex.json` separates verified traversal from possible-but-unverified impact.

`Evidence/BatchXX/` contains independent checks and batch-local narrative, not additional active versions of the cumulative audit. The entire current paper corpus and pre-existing DAG history are preserved byte-for-byte except for new release integration registries.

Active audit: `Audits/Paper6A-ProofChainAudit-v1_1.md`; successor global atlas: `Paper00-DAGAtlas-v1_117`.
