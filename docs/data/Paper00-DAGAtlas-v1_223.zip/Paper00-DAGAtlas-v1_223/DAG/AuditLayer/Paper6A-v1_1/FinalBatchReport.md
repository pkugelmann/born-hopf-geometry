# Paper VI-A — rigorous verification DAG audit (full source; six bounded batches)

**Target:** `Paper6A-GravityCosmology-v2_253.tex` (`Paper00-PapersMinimal-v2_371`), SHA256 `3110e5c951b395665f54a2a910dd6e3570eb9659e775d3b0b4128e6fe28a82d1`, 17,251 lines.
**Protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md`; no theory development and no source edits.
**Rebased onto:** `Paper00-DAGAtlas-v1_116.zip` / `Paper00-ProofChainAudits-v1_33.zip`; earlier Batch1–5 checkpoint ledgers remain preserved, but only latest cumulative VI-A records are active.
**Disposition:** `FULLY_AUDITED_WITH_OPEN_GAPS` as SOURCE-COVERAGE classification; this does **not** mean complete E3 certification of every theorem.
**Formal census:** 357/357 named source results inspected; 14 additional final-batch unnamed material/interface blocks recorded; earlier batches include additional unnamed claims.
**Final status:** FORMALIZED 121, REPRODUCED 109, UNRESOLVED 13, VERIFIED-CONDITIONAL 114.
**Exact subclaim controls:** 354/354 cumulatively (310 from Batches 1–5 plus 44 from Batch 6); passing E4 challenges deliberately expose defects. Independent agents unavailable; no multi-agent claim is made.
**Open issue roots:** 17 (14 inherited from earlier batches, 3 new in Batch 6). Physical occurrence, same-action owner, and observational calibration are never inferred from algebra alone.

## Batch source coverage

| Batch | Line interval | New named claims | Cumulative named claims | Exact subclaim controls |
|---:|:---|---:|---:|---:|
| 1 | 1–2,514 | 52 | 52 | 48 |
| 2 | 2,515–5,533 | 65 | 117 | 59 |
| 3 | 5,534–9,030 | 61 | 178 | 57 |
| 4 | 9,031–11,203 | 71 | 249 | 70 |
| 5 | 11,204–14,549 | 63 | 312 | 76 |
| 6 | 14,550–17,251 | 45 | 357 | 44 |

## Complete open issue register (all 17)

### BH-VIA-G-0001 — MODERATE — MISSING_CONDITION
**First origin:** `p8:thm:k48-conditional-exact-dust`; VI-A lines 2142–2149.
Cauchy additivity only yields μ∈R, not μ≥0; F(ζ)=−ζ is an exact counterexample.

**Precise obligation:** Locate and source-type a nonnegative effective-energy premise or qualify the μ sign; no paper/source edits performed.

**Retained:** F is linear with real slope; pressure p=0 for linear F; terminal current dilutes as a^-3

**Conditions:** As shown in source-bound gap record; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0002 — MINOR — TYPE_OR_DOMAIN / MISSING_CONDITION
**First origin:** `p8:thm:k48-conditional-exact-dust`; VI-A lines 2149–2157.
At μ=0 the equation of state is F=p=0 and dp/dF is undefined without a limiting convention.

**Precise obligation:** Restrict the sound-speed derivative statement to a nondegenerate effective-density branch, or explicitly define a limiting convention; no theory repair inserted.

**Retained:** The zero-energy case has zero stress and pressure; On μ>0 nondegenerate branch, c_s²=0; Neutral Hodge current balance unaffected

**Conditions:** As shown in source-bound gap record; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0003 — MODERATE — NORMALIZATION_OR_READOUT
**First origin:** `p8:tab:geometric-outputs`; VI-A lines 2730–3105.
Figure/table numbers and m−2 units represent Born midpoint curvatures C8^B/C16^B, not root scales ℛ8/ℛ16 in m−1.

**Precise obligation:** Make numerical readout labels, values and units consistent with the source-defined coordinate; source unchanged.

**Retained:** Neutral seven-shell hierarchy identities survive; The correctly defined root and midpoint coordinates survive

**Conditions:** As shown in source-bound gap record; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0004 — MODERATE — NORMALIZATION_OR_READOUT / TYPE_OR_DOMAIN
**First origin:** `p8:cor:lower-scalaron-matter-like-average`; VI-A lines 4068–4112.
WKB phase uses m_s as physical frequency although the exact physical-time scalaron equation contains c²m_s²; dotΘ=cm_s for m_s in m−1.

**Precise obligation:** Specify a consistent physical-time/natural-unit convention or source-derive the frequency and dimensionless adiabatic parameters from the displayed trace equation.

**Retained:** Exact c² trace and scalaron force law remain valid; Conditional local-well requirement and no-global-matter-like conclusion remain intact

**Conditions:** BH-VIA-A-0005; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0005 — MODERATE — NORMALIZATION_OR_READOUT / TYPE_OR_DOMAIN
**First origin:** `p8:thm:smooth-solar-system-screening-ppn`; VI-A lines 4540–4573.
SI weak-field potential terms GM/(Fr) and R_env r²/24 have inconsistent dimensions under the printed dimensionless Φ convention.

**Precise obligation:** Source-type the potential normalization/gauge: dimensionless potentials need GM/(F c²r), while physical potentials need curvature terms with c²; do not silently choose one.

**Retained:** Stated assumptions F>0, f_RR>0, m²>0 remain unchallenged; Formal gamma fraction identity survives after a consistent normalization

**Conditions:** BH-VIA-A-0006; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0006 — MODERATE — UNPROVED_IMPORTED_NORMALIZATION / MISSING_PROOF_STEP
**First origin:** `p8:thm:smooth-solar-system-screening-ppn`; VI-A lines 4548–4602.
Thin-shell thickness q=Δr/r_B is substituted for an integrated scalar charge without showing the usual active fraction ≃3q in the same action.

**Precise obligation:** Provide a same-action charge integral in the asserted thin-shell domain and demonstrate why printed eps_B is the effective integrated scalar charge, or qualify its normalization and PPN quantitative response.

**Retained:** Qualitative limit eps_B->0 remains sufficient for a screened branch as a limit, subject to solved source backgrounds; The algebraic gamma relation in terms of a correctly defined exterior charge survives

**Conditions:** BH-VIA-A-0007; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0007 — MINOR — SCOPE
**First origin:** `p8:sec:v2201-derived-d11`; VI-A lines 5629–5634.
The D11 numerical quadrature/covariance JSON replay attachment is not present, so reported tolerances lack an independently runnable witness.

**Precise obligation:** Locate/provide original executed JSON and replay specification or retain D11 readouts explicitly as unreplicated reported numerical outputs.

**Retained:** Displayed D11 numbers are not disproved; D12 tensor t^6 and t^4 local coefficients survive exact controls; No numerical certificate is upgraded to E3

**Conditions:** As shown in source-bound gap record; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0008 — MODERATE — SCOPE
**First origin:** `p8:eq:hs-lambda-infty`; VI-A lines 7187–7192.
Horizon vacuum density C56/(2κ²) conflicts with earlier κ=M−2 convention implying C56/(2κ); distinguish alternate coupling or normalize.

**Precise obligation:** Resolve whether the horizon subsection introduces a different conventional coupling kappa_h satisfying kappa_h²=kappa_native, or reconcile rho_infty using the existing defined symbol.

**Retained:** Dimensionless normalized horizon polynomial/cubic and the conditional shape of w_DE remain algebraically consistent; The native terminal rho_Lambda=M² C/2 remains unchanged

**Conditions:** BH-VIA-A-0011; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0009 — MINOR — SCOPE
**First origin:** `p8:eq:hs-crossing-geometric`; VI-A lines 7353–7362.
w_DE=−1 ⇔ Θ_A=1/3 fails at allowed M=0 endpoint (w_DE=−1, Θ_A=1); requires positive matter.

**Precise obligation:** Scope the equivalence to M(a)>0 or explicitly account for the vacuum endpoint exception without changing the source during audit.

**Retained:** Physical-branch uniqueness and monotonicity for M>=0 survive; Positive-matter phantom crossing and conditional EOS remain valid

**Conditions:** BH-VIA-A-0012; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0010 — MODERATE — SCOPE
**First origin:** `p8:prop:v2188-trace-coefficient-certificate`; VI-A lines 8531–8559.
Operator 2-norm does not generally upper bound maximum absolute row sum B_a; normalized 2×2 Hadamard matrix witnesses sqrt2>1.

**Precise obligation:** Supply a genuine row-sum bound on each finite word or state a distinct operator-norm sufficient route with its own proof; audit does not repair the manuscript.

**Retained:** The primary row-sum bound on the source trace remains correct; Finite CAR monomials are contractions in operator norm; No actual first-K48 numerical threshold certificate was claimed in this proposition

**Conditions:** BH-VIA-A-0013; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0011 — MODERATE — INCORRECT_STEP / TYPE_OR_DOMAIN
**First origin:** `p8:sec:tensor-frame-ledger`; VI-A lines 11083–11108.
Conformal Hubble 1-forms satisfy H_Edt_E=H_Jdt_J+(1/2)dlnF; omitting the extra term fails when F varies.

**Precise obligation:** Correct or branch-qualify the conformal Hubble identity in a subsequent source revision; keep other correct frame transformations intact.

**Retained:** Canonical tensor momenta P_h^E=P_h^J; The tensor frame generator A_L^J=sqrt(F)A_L^E; Frame-related mass identity m_E=m_J/sqrt(F)

**Conditions:** BH-VIA-A-0014; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0012 — MINOR — INCORRECT_STEP / MISSING_CONDITION
**First origin:** `p8:prop:shell-algebra-nonterminal-rar`; VI-A lines 9851–9884.
24-cell walk spectrum includes invariant eigenvalue 1 and hence factor 1^n, omitted from displayed exhaustive-looking surviving factors.

**Precise obligation:** Include the invariant 1^n channel or make the mean-zero/orthogonal-to-constant restriction explicit in the original proposition.

**Retained:** Full normalized walk spectrum and multiplicities as printed; Nine-dimensional null-channel result T^n E_2=0; Nontrivial mean-zero n-step channel factor list

**Conditions:** BH-VIA-A-0015; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0013 — MODERATE — EVIDENCE_MISSING / NUMERICAL_REPLAY
**First origin:** `p8:prop:v2184-native-source-memory-regulator`; VI-A lines 11655–11739.
D11/VI-C black-hole numerical history reports small residuals but executable inputs/scripts and JSON are absent in supplied archives.

**Precise obligation:** Supply versioned VI-C-cited v1_9-v1_12 Python executables, v1_12 JSON and full Cauchy/source-strength/buffer data; replay signed marginal radii, lapse/Raychaudhuri residuals, perturbation derivatives, and constraint buffers independently. No paper change at this audit stage.

**Retained:** Analytic finite Cauchy/source and conditional ODE framework as stated; Transversality entails an open zero-survival basin assuming the quoted regular base witness and smooth dependence; Conditional spherical constraint matching equations and locally Lipschitz compact-invariant continuation criterion

**Conditions:** As shown in source-bound gap record; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0014 — MODERATE — PHYSICAL_OWNER_BRIDGE / UNDISCHARGED_CONDITIONAL
**First origin:** `p8:prop:static-acceleration-readout`; VI-A lines 11254–12399.
Scalar collar DtN sqrtR is exact, but a generic same-action Schur Hessian has not been identified with that particular physical acceleration determinant.

**Precise obligation:** Exhibit the actual occurring stationary S_star boundary/interior Schur Hessian on the physically generated scalar zero mode, including β_48 conormal normalization, and prove it equals the proposed Γ_R comparison scalar DtN with physical acceleration observable. Alternatively retain TR1 as explicit conditional physical-identification premise. Do not alter valid abstract DtN/Hopf algebra.

**Retained:** Exact abstract comparison collar DtN spectrum and zero mode; Unique Haar probability normalization on Hopf S² and its 1/(4π) trace-to-density factor; Generic physical boundary Schur reduction and its exact source derivative, under physical stationary-split hypotheses

**Conditions:** BH-VIA-A-0016; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0015 — MODERATE — LOGICAL_GAP / UNDISCHARGED_GENERATOR_EXHAUSTION
**First origin:** `p8:thm:v2112-terminal-causal-cap-occurrence`; VI-A lines 14846–14927.
Finite causal exclusion and redshift do not alone eliminate all exactly nontrivial operational readout generators or certify discrete detachment occurrence.

**Precise obligation:** Establish from the actual finite operator-system/readout constructors a defined notion of asymptotic quotient/triviality and show full exhaustion on the located cap (or explicitly condition occurrence on that additional premise). Do not infer non-scalar-generator disappearance from redshift alone.

**Retained:** Finite causal reach/volume complement on the stipulated finite bound-source domain; Asymptotic material dilution and conditional cap-algebra theorem assuming full generator exhaustion; Definition and selector identities for ζ_D

**Conditions:** BH-VIA-A-0018, BH-VIA-A-0019; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0016 — MODERATE — UNDISCHARGED_IMPORTED_BOUNDARY_CONDITION
**First origin:** `p8:thm:complete-cap-zero-cotangent`; VI-A lines 15372–15426.
Zero intrinsic daughter momentum consumes upstream locally constant inherited boundary functional BH-IIIA-A-0042, not discharged merely by no parent readout.

**Precise obligation:** Provide a source-bound proof that the specific inherited complete boundary functional is locally constant on the daughter homogeneous boundary role, or retain BH-IIIA-A-0042 as an explicit unresolved antecedent. Do not equate absence of external impulse with zero intrinsic momentum.

**Retained:** Paper III-A boundary-trivial lemma under its explicit two hypotheses; Conditional zero-cotangent to H0=dot X0=0 algebra; Conditional closed-FLRW bounce radius/sign algebra

**Conditions:** BH-IIIA-A-0042, BH-IIIA-A-0043; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

### BH-VIA-G-0017 — MODERATE — MISSING_PHYSICAL_CONSTRUCTOR_CERTIFICATE
**First origin:** `p8:cor:v2112-no-duplicate-lineage-occurrence`; VI-A lines 15104–15644.
Conditional II-A no-idle/co-realization needs a frozen licensed cap→daughter dynamical/occurrence constructor; structural reset alone is not its certificate.

**Precise obligation:** Locate and certify the existing pre-frozen typed cap-to-daughter dynamical/occurrence constructor, exact full inputs, nonredundant output sort, and R≼ΣP relation, or scope the daughter history as conditional on that constructor. No new constructor is to be invented in this audit.

**Retained:** Structural I8/q=0 reset on a complete cap; Primitive Hopf residue and daughter root normalization; Conditional K8/K16/K48 crossings for a supplied regular daughter history

**Conditions:** BH-VIA-A-0020, BH-IIA-A-B37-GEN-ROLE-001; **confirmed cross-paper impacts:** 0; all other possible impacts remain unconfirmed.

## Final batch exact checks

Native constant `A=4π²+1/(6√2)≈39.596268734555` and `Q≈3.17183e+09`. Independent quadrature gives:

| Candidate j | Potential-end q | Printed approximate q |
|---:|---:|---:|
| 1 | 0.516686676 | 0.516687 |
| 2 | 0.566388774 | 0.566389 |
| 3 | 0.566388773 | 0.566389 |
| 4 | 0.566388773 | 0.566389 |

The terminal selector, S³ causal-ball volume, positive mass/force subclaims, full Hopf residue, Planck-square rewrite, cyclic-root ratio, FLRW constraint, source corner energy, conditional radiation/dust separatrix, and exact coefficient work readout passed their specific controls. E4 controls also confirm that norm-decay does not automatically trivialize an exact algebra, absence of source impulse does not force zero bulk momentum, and nonzero corner energy cannot disappear under continuous finite-state evolution.

## Imported theorem boundary firewall

- II-A no-idle: licensed frozen constructor + all generated inputs + required nonredundant typed output. Its source warns mathematical availability alone is insufficient.
- II-A generated-role co-realization: a separately established role relation inside an occurring parent, not physical occurrence of every possible state or process.
- III-A boundary-trivial: both (i) locally constant inherited boundary functional (existing canonical `BH-IIIA-A-0042`) AND (ii) no new independent varying boundary functional (`BH-IIIA-A-0043`). No duplicate assumptions introduced.
- VI-A complete-cap definition implies compact operator-system triviality by definition; an actual time-dependent complete-cap history is a separate assertion.


Complete named census is in `Paper6A-Batch06-ClaimLedger-v1_6.json`.
