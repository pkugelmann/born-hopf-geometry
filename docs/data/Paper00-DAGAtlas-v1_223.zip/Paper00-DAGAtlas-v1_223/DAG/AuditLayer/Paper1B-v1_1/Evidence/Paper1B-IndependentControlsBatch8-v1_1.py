#!/usr/bin/env python3
"""Paper I-B, batch 8 (census 353--400). Source-independent finite checks.
These controls test explicitly named identities and domains, not global
unstable-bundle classifications or imported proofs. Reproducible deterministic.
"""
import json, math, cmath, itertools, collections
from fractions import Fraction as F
from pathlib import Path
import numpy as np
import scipy.linalg as sla
from scipy.integrate import quad, solve_ivp
import sympy as s

OUT=[]
RNG=np.random.default_rng(198764)
def check(family, name, actual, expected=True, atol=1e-9, detail=''):
    if isinstance(actual, (s.Basic,s.MatrixBase)) or isinstance(expected, (s.Basic,s.MatrixBase)):
        d=s.simplify(actual-expected) if not isinstance(actual,s.MatrixBase) else actual-expected
        passed=all(s.simplify(v)==0 for v in d) if isinstance(d,s.MatrixBase) else d==0
        error=str(d) if not passed else '0'
    elif isinstance(actual,(bool,np.bool_)) and expected is True:
        passed=bool(actual);error=0 if passed else 1
    elif actual is None or expected is None:
        passed=(actual==expected);error=0 if passed else 1
    elif isinstance(actual,(set,dict,str)) or isinstance(expected,(set,dict,str)) or (isinstance(actual,tuple) and isinstance(expected,tuple) and all(isinstance(z,F) for z in actual+expected)) or (isinstance(actual,tuple) and isinstance(expected,tuple) and all(isinstance(z,tuple) for z in actual+expected)):
        passed=(actual==expected);error=0 if passed else 1
    else:
        x=np.asarray(actual,dtype=np.complex128);y=np.asarray(expected,dtype=np.complex128)
        error=float(np.max(np.abs(x-y))) if x.size else 0
        passed=(error<=atol)
    OUT.append(dict(family=family,name=name,passed=bool(passed),error=str(error),tolerance=atol,detail=detail))
    if not passed:raise AssertionError(f'{family}/{name}: {error} actual={str(actual)[:220]} expected={str(expected)[:220]}')

# A: Projectors, round spin connection and Clifford contraction.
P0=np.array([[0,1],[1,0]],complex);P1=np.array([[0,-1j],[1j,0]],complex);P2=np.diag([1,-1]).astype(complex)
Z=np.diag([1,-1]).astype(complex);I=np.eye(2,dtype=complex)
def kronall(xs):
    r=np.array([[1]],complex)
    for x in xs:r=np.kron(r,x)
    return r
G=[]
for k in range(4):
    for v in [P0,P1]:G.append(1j*kronall([Z]*k+[v]+[I]*(3-k)))
for a in range(8):
    check('DIRAC',f'gamma anti-selfadjoint {a}',G[a].conj().T,-G[a])
    for b in range(a,8):check('DIRAC',f'Clifford pair {a},{b}',G[a]@G[b]+G[b]@G[a],-2*(a==b)*np.eye(16))
check('DIRAC','metric connection parameters',8*math.comb(8,2),224)
check('DIRAC','three-form image',math.comb(8,3),56)
check('DIRAC','Cartan kernel',224-56-8,160)
check('DIRAC','traceless selfadjoint family',224-8,216)
check('DIRAC','exchange splitting',112,(28+4+80))
check('DIRAC','exchange selfadjoint',112-4,108)
for trial in range(3):
    K=RNG.integers(-2,3,(8,8,8));K=K-K.transpose(0,2,1)
    T=K-K.transpose(1,0,2)
    t=np.array([sum(T[a,b,b] for b in range(8)) for a in range(8)])
    Talt=np.zeros((8,8,8))
    for a,b,c in itertools.product(range(8),repeat=3):Talt[a,b,c]=(T[a,b,c]+T[b,c,a]+T[c,a,b])/3
    basis={(a,b,c):G[a]@G[b]@G[c] for a,b,c in itertools.product(range(8),repeat=3)}
    lhs=sum((K[a,b,c]/4)*basis[a,b,c] for a,b,c in itertools.product(range(8),repeat=3))
    rhs=sum((3/4/6)*Talt[a,b,c]*basis[a,b,c] for a,b,c in itertools.product(range(8),repeat=3))-sum((t[a]/2)*G[a] for a in range(8))
    check('DIRAC',f'full K-to-(three-form,one-form) trial{trial}',lhs,rhs)
    check('DIRAC',f'totally skew 3-form trial{trial}',np.linalg.norm(Talt+Talt.transpose(1,0,2)),0.0)
# Complementary profile frames with arbitrary nonzero SU2 and f.
U=np.array([[.8,.6],[-.6,.8]],complex)
for f in [0.02,.2,.5,.88,.98]:
    Vp=np.vstack((math.sqrt(f)*U,math.sqrt(1-f)*np.eye(2)))
    Vm=np.vstack((-math.sqrt(1-f)*U,math.sqrt(f)*np.eye(2)))
    Pp=Vp@Vp.conj().T;Pm=Vm@Vm.conj().T
    check('PROVIDERS',f'V+ isometric f{f}',Vp.conj().T@Vp,np.eye(2))
    check('PROVIDERS',f'V- isometric f{f}',Vm.conj().T@Vm,np.eye(2))
    check('PROVIDERS',f'complementary f{f}',Pp@Pm,np.zeros((4,4)))
    check('PROVIDERS',f'projection completeness f{f}',Pp+Pm,np.eye(4))
    check('PROVIDERS',f'profile upper f{f}',Vp.conj().T@np.vstack((math.sqrt(f)*U,np.zeros((2,2)))),f*np.eye(2))
    check('PROVIDERS',f'df cancellation f{f}',math.sqrt(f)/(2*math.sqrt(f))-math.sqrt(1-f)/(2*math.sqrt(1-f)),0.)
# Exact Berry curvature of a rank-one projected flat connection on S2.
th,ph=s.symbols('th ph',real=True)
v=s.Matrix([s.cos(th),s.exp(s.I*ph)*s.sin(th)]);A_th=s.simplify((v.conjugate().T* v.diff(th))[0]);A_ph=s.simplify((v.conjugate().T*v.diff(ph))[0]);F_thph=s.simplify(s.diff(A_ph,th)-s.diff(A_th,ph))
check('PROVIDERS','Berry A_th',A_th,s.S(0))
check('PROVIDERS','Berry A_phi',A_ph,s.I*s.sin(th)**2)
check('PROVIDERS','projected flat nonzero curvature',F_thph,s.I*s.sin(2*th))
# Tangent flat-normal projection: D_X(Y+a n) = ambient derivative.
for scale in (1,2,5):
    x=RNG.normal(size=4);x=x/np.linalg.norm(x); n=x
    y=RNG.normal(size=4);y=y-n*np.dot(n,y)
    X=RNG.normal(size=4);X=X-n*np.dot(n,X)
    R=float(scale)
    derivative_normal=-np.dot(X,y)/R
    lifted=np.r_[y,0.]
    check('PROVIDERS',f'Euclidean normal derivative {scale}',derivative_normal,-np.dot(X,y)/R)
# SU2 curvature at s: flat endpoints, midpoint nonzero; two contractions distinct.
for f in [0.,.18,.5,.76,1.]:
    check('PROVIDERS',f'Cartan curvature constant profile {f}',f*(f-1),(-.25 if f==.5 else f*(f-1)))
check('PROVIDERS','singlet/triplet spin-twist',np.linalg.eigvalsh(sum(np.kron(P,P) for P in (P0,P1,P2))),[-3,1,1,1])
check('PROVIDERS','flat dilation sphere scalar',.5*(.5-1),-.25)

# B: finite Hermitian reduction and parametric rank change.
for trial in range(12):
    X=2;Y=3
    R=RNG.normal(size=(Y,Y));e=R@R.T
    e[:,2]=0;e[2,:]=0 # PSD rank 2
    e[:2,:2]+=np.eye(2)
    B=RNG.normal(size=(X,Y));B[:,2]=0
    S=RNG.normal(size=(X,X));S=S@S.T+np.eye(X)
    A=S+B@np.linalg.pinv(e)@B.T
    H=np.block([[A,B],[B.T,e]])
    check('SCHUR',f'PSD Hermitian trial {trial}',np.linalg.eigvalsh(H).min()>=-1e-9)
    check('SCHUR',f'kernel dimension trial {trial}',np.linalg.matrix_rank(H),4)
    check('SCHUR',f'schur positive trial {trial}',A-B@np.linalg.pinv(e)@B.T,S)
    L=np.zeros((1,5));L[0,0]=1
    check('SCHUR',f'input-output trial {trial}',L@np.linalg.pinv(H)@L.T,L[:,:2]@np.linalg.inv(S)@L[:,:2].T)
# Crucial subtlety: H+ projection to X generally is NOT S^-1 when C singular?
# The identity above may fail if nonzero B produces a null vector with x=0 (holds), hence yes.
for p in (1,2,3):
    for t in (.2,.05,.01):
        H=np.array([[2.,t**p],[t**p,t*t]])
        check('SCHUR',f'rank-change positive p{p} t{t}',np.linalg.eigvalsh(H).min()>-1e-12)
        check('SCHUR',f'Schur p{p} t{t}',2-t**(2*p-2),H[0,0]-H[0,1]**2/H[1,1])
check('SCHUR','counterexample S(t)=1',2-1,1)
check('SCHUR','counterexample S(0)=2',2.,2.)
# Explicit Laurent inverse including uncoupled interior zero direction.
z=s.symbols('z');m=s.Rational(3,2);C=s.diag(2,-z*m);Bb=s.Matrix([[s.Integer(2),s.Integer(5)]])
check('SCHUR','Laurent interior residue',s.limit(z*C.inv()[1,1],z,0),-1/m)
check('SCHUR','Laurent Schur residue',s.limit(z*(-Bb*C.inv()*Bb.T)[0],z,0),s.Rational(25,1)/m)
check('SCHUR','Laurent source residue',s.limit(z*(-Bb*C.inv()*s.Matrix([0,3]))[0],z,0),s.Rational(15,1)/m)
# Positive rational response pole weights and scaling.
for trial in range(6):
    As=[]; ds=[]
    for j in range(5):
        Z=RNG.normal(size=(3,2));As.append(Z@Z.T);ds.append(float(RNG.uniform(.5,4)))
    S0=sum(2*A/d for A,d in zip(As,ds));T=sum(2*A/d**3 for A,d in zip(As,ds))
    check('SCHUR',f'gap lower Loewner {trial}',np.linalg.eigvalsh(T-S0/max(ds)**2).min()>=-1e-9)
    check('SCHUR',f'gap upper Loewner {trial}',np.linalg.eigvalsh(S0/min(ds)**2-T).min()>=-1e-9)
# Bipartite 2x2 exact resolvent: poles with half weights.
for sv in [s.Rational(1,2),s.Integer(1),s.Integer(3)]:
    zz=s.symbols('zz');D=s.Matrix([[0,sv],[sv,0]]);R=s.simplify((D-zz*s.eye(2)).inv()[0,0]);tar=zz/(sv*sv-zz**2)
    check('SCHUR',f'bipartite XX resolvent s{sv}',R,tar)
    check('SCHUR',f'bipartite residues at +s{sv}',s.limit((sv-zz)*R,zz,sv),s.Rational(1,2))
    check('SCHUR',f'bipartite residues at -s{sv}',s.limit((-sv-zz)*R,zz,-sv),s.Rational(1,2))
# Legendre logarithmic-coordinate independent symbolic chain rule.
r,a,b=s.symbols('r a b',positive=True)
f=r+r**3/s.Integer(3);Ffun=s.diff(f,r);chi=s.diff(Ffun,r);Bexp=2*f-r*Ffun;Pexp=r*Ffun-f
W=b*Pexp/Ffun**2; phip=a*s.log(Ffun)
W1=s.simplify(s.diff(W,r)/s.diff(phip,r));W2=s.simplify(s.diff(W1,r)/s.diff(phip,r))
expect1=b/a*Bexp/Ffun**2
expect2=b/a**2*(1/chi-r/Ffun-2*Bexp/Ffun**2)
expect3=b/a**2*(-s.diff(chi,r)/chi**2-3*(Ffun-r*chi)/Ffun**2+4*Bexp*chi/Ffun**3)
check('LEGENDRE','first log derivative',W1,expect1)
check('LEGENDRE','second log Hessian',W2,expect2)
check('LEGENDRE','third R derivative',s.diff(W2,r),expect3)
check('LEGENDRE','difference from truncated Hessian',s.simplify(W2-b/a**2*(Ffun-r*chi)/(chi*Ffun)),-2*b*Bexp/(a*a*Ffun*Ffun))
# Constant weighted-profile condition and nonconstant logistic.
for t in [-2.,-.5,0.,.5,2.]:
    ff=1/(1+math.exp(-2*t));fp=2*ff*(1-ff)
    check('WEIGHT',f'logistic first derivative t{t}',fp,2*ff*(1-ff))
    check('WEIGHT',f'logistic unweighted equation t{t}',(4*ff*(1-ff)*(1-2*ff)),-(4*ff**2*(1-ff)**2)*0+4*ff*(1-ff)*(1-2*ff))
# C: one-dimensional exact Volterra remainder, no spectral-sum interchange.
def bump(t):
    if abs(t)>=1:return (0.,0.,0.)
    d=1-t*t;e=math.exp(-1/d);p=-2*t/d**2; pp=-2/d**2-8*t*t/d**3
    return e,e*p,e*(pp+p*p)
lam=.12
hmax=math.exp(-1)
delta=abs(lam)*hmax
Ahalf=quad(lambda t:abs(bump(t)[2]),-1,1,epsabs=1e-10,limit=100)[0]/2
Bdel=quad(lambda t:abs(bump(t)[0]*bump(t)[2]),-1,1,epsabs=1e-10,limit=100)[0]/(2*(1-delta)) + quad(lambda t:bump(t)[1]**2,-1,1,epsabs=1e-10,limit=100)[0]/(4*(1-delta)**2)
Lbound=abs(lam)*Ahalf+lam*lam*Bdel
for omega in (.7,1.7,3.4):
    def deriv(t,v):
        h,hp,hpp=bump(t)
        Z0=1+lam*h;Vl=lam*hpp/(2*Z0)-lam**2*hp*hp/(4*Z0*Z0)
        return [v[1],(Vl-omega**2)*v[0]]
    yi=np.array([np.exp(1j*omega),-1j*omega*np.exp(1j*omega)],complex)
    sol=solve_ivp(deriv,(-1,1),yi,rtol=1e-10,atol=1e-11,max_step=.01)
    y,dy=sol.y[:,-1]
    beta=np.exp(-1j*omega)*(dy+1j*omega*y)/(2j*omega)
    alpha=np.exp(1j*omega)*(1j*omega*y-dy)/(2j*omega)
    hhat=quad(lambda t:bump(t)[0]*math.cos(2*omega*t),-1,1,epsabs=1e-12)[0]
    first=1j*lam*omega*hhat
    eb=lam*lam*Bdel/(2*omega)+.5*(math.exp(Lbound/omega)-1-Lbound/omega)
    check('PULSE',f'Wronskian alpha beta omega{omega}',abs(alpha)**2-abs(beta)**2,1.,atol=2e-8)
    check('PULSE',f'Volterra remainder bound omega{omega}',abs(beta-first)<=eb+1e-8)
    check('PULSE',f'squared response bound omega{omega}',abs(abs(beta)**2-abs(first)**2)<=2*abs(first)*eb+eb**2+1e-8)
    check('PULSE',f'compact potential normalizer omega{omega}',Lbound>0)

# D: seven-dimensional F7 central level-12 Heisenberg arithmetic.
def mult(x,y):
    a,b,z=x; aa,bb,zz=y; return (a+aa,b+bb,(z+zz+a*bb)%12)
def lpow(r,z0):return (4*r,4*r,(r*z0+8*r*(r-1))%12)
def Rmap(x):a,b,z=x;return (-b,-a,z)
for z0 in (2,8):
    ell=(4,4,z0)
    for k in range(-5,6):
        e=(0,0,0)
        if k>=0:
            for i in range(k):e=mult(e,ell)
        else:
            inv=(-4,-4,(-z0+16)%12)
            for i in range(-k):e=mult(e,inv)
        check('F7',f'level12 power {z0} {k}',e,lpow(k,z0))
    for d in range(-16,17):
        h=math.gcd(12,4*d)
        check('F7',f'central modulus d{d}',h,4*math.gcd(3,d))
        check('F7',f'F7 class count d{d}',4*h,16*math.gcd(3,d))
        fixed=[]
        for u in range(4):
            for zz in range(h):
                upr=(d-u)%4;k=(upr+u-d)//4
                zn=(zz+k*z0+8*k*(k-1)+4*k*(d-u))%h
                if u==upr and zz==zn:fixed.append((u,zz))
        goal=0 if d%2 else (8 if z0==8 else 4)*math.gcd(3,d)
        check('F7',f'invariant row count z0{z0} d{d}',len(fixed),goal)
        # Double-coset source action preserves the normalized residue.
        for r0,s0 in ((1,0),(-1,1),(2,-3)):
            a=4*2+1;b=a-d; z=5
            g=(a,b,z);gp=mult(mult(lpow(r0,z0),g),lpow(s0,z0))
            def canon(g):
                aa,bb,zz=g;dd=aa-bb;uu=aa%4;kk=(uu-aa)//4
                return (dd,uu,(zz+kk*z0+8*kk*(kk-1)+4*kk*aa)%math.gcd(12,4*dd))
            check('F7',f'double-coset invariant z0{z0} d{d} r{r0}s{s0}',canon(g),canon(gp))
        # Monodromy is an involution on components, preserving d and correct z.
        for u in range(4):
            up=(d-u)%4;k=(up+u-d)//4
            for zz in (0,h-1):
                zp=(zz+k*z0+8*k*(k-1)+4*k*(d-u))%h
                up2=(d-up)%4;k2=(up2+up-d)//4
                zp2=(zp+k2*z0+8*k2*(k2-1)+4*k2*(d-up))%h
                check('F7',f'monodromy involution z0{z0} d{d} u{u} z{zz}',(up2,zp2),(u,zz))
# Smith-modulus stabilization: explicit subgroup of Z_m^2 (not just formula).
def mod_subgroup(m,cols):
    reached={(0,0)}; frontier=[(0,0)]
    while frontier:
        a,b=frontier.pop()
        for x,y in cols:
            p=((a+x)%m,(b+y)%m)
            if p not in reached:reached.add(p);frontier.append(p)
    return len(reached)
for trial in range(48):
    A0,B0,C0,D0=map(int,RNG.integers(-24,25,size=4))
    Delta=B0*C0-A0*D0
    if Delta%12:continue
    cols=((B0,D0),(-A0,-C0))
    orders=[m*m//mod_subgroup(m,cols) for m in (6,12)]
    check('STABILIZATION',f'Smith quotient divisibility trial{trial}',orders[1]%orders[0],0)
    check('STABILIZATION',f'Smith target size trial{trial}',orders[0]>=1)
check('STABILIZATION','zero Chern T_6',6**2,36)
check('STABILIZATION','zero Chern T_12',12**2,144)
check('STABILIZATION','zero Chern nu_pr',4+2**0,5)
check('STABILIZATION','zero Chern per-sector count',5*144//36,20)
check('STABILIZATION','zero Chern both sectors count',2*5*144//36,40)
for d in [1,2,4,6,9,12,24]:
    N=np.array([[d,0],[0,0]])
    q12=144//mod_subgroup(12,[(d,0),(0,0)])
    check('STABILIZATION',f'rank1 Smith q12 d{d}',q12,12*math.gcd(12,d))
    if d%2:nu=4
    elif d%4:nu=6
    else:nu=5
    check('STABILIZATION',f'rank1 nu-pr d{d}',nu,{1:4,2:6,4:5,6:6,9:4,12:5,24:5}[d])
# E: exact 2T, 2O and 2I support, spherical moments, all 25 Hurwitz registers.
zero=(F(0),F(0));one=(F(1),F(0))
def fldadd(x,y):return (x[0]+y[0],x[1]+y[1])
def fldneg(x):return (-x[0],-x[1])
def fldsub(x,y):return fldadd(x,fldneg(y))
def fldmul(x,y):return (x[0]*y[0]+5*x[1]*y[1],x[0]*y[1]+x[1]*y[0])
def fldscale(x,c):return (x[0]*c,x[1]*c)
def fldpow(x,n):
    a=one
    for i in range(n):a=fldmul(a,x)
    return a
def ffloat(x):return float(x[0])+math.sqrt(5)*float(x[1])
def qfloat(q):return np.array([ffloat(x) for x in q],float)
T=[];Ic=[]
for i in range(4):
    for sg in (-1,1):
        v=[zero]*4;v[i]=fldscale(one,sg);T.append(tuple(v))
for ss in itertools.product((-1,1),repeat=4):T.append(tuple((F(x,2),F(0)) for x in ss))
Ic=list(T)
base=(zero,(F(1,2),F(0)),(F(1,4),F(1,4)),(F(-1,4),F(1,4)))
for perm in itertools.permutations(range(4)):
    parity=sum(perm[i]>perm[j] for i in range(4) for j in range(i+1,4))%2
    if parity:continue
    vec=[base[k] for k in perm]; support=[i for i,z in enumerate(vec) if z!=zero]
    for ss in itertools.product((-1,1),repeat=3):
        row=vec[:]
        for j,sg in zip(support,ss):row[j]=fldscale(row[j],sg)
        Ic.append(tuple(row))
check('ROOTS','Hurwitz24 cardinality',len(set(T)),24)
check('ROOTS','Icosian120 cardinality',len(set(Ic)),120)
check('ROOTS','Hurwitz embedded in Icosian',set(T)<=set(Ic))
for j,q in enumerate(Ic):
    norm=zero
    for v in q:norm=fldadd(norm,fldmul(v,v))
    check('ROOTS',f'unit Icosian vertex {j}',norm,one)
# finite O=2T plus 24 separate 1/sqrt2 double-slot vertices, enough for squared-coordinate moments.
O_sq=[]
for i in range(4):
    sq=[F(0)]*4;sq[i]=F(1);O_sq.extend([tuple(sq)]*2)
O_sq.extend([tuple([F(1,4)]*4)]*16)
for ij in itertools.combinations(range(4),2):
    sq=[F(0)]*4
    for i in ij:sq[i]=F(1,2)
    O_sq.extend([tuple(sq)]*4)
check('ROOTS','binary octahedral cardinality',len(O_sq),48)
# Exact Haar spherical even moments on S3.
def haar(exp):
    if any(t%2 for t in exp):return F(0)
    ex=[t//2 for t in exp]; n=sum(ex)
    num=F(1)
    for a in ex:
        for k in range(a):num*=F(2*k+1,2)
    den=F(1)
    for k in range(n):den*=F(k+2)
    return num/den
for order in (0,2,4):
    for ex in itertools.product(range(order+1),repeat=4):
        if sum(ex)!=order:continue
        avg=sum((math.prod(ffloat(q[i])**ex[i] for i in range(4)) for q in T),0.)/24
        check('HURWITZ',f'5-design monomial {ex}',avg,float(haar(ex)),atol=1e-12)
# Full harmonic 0,1,2 band using independent Haar normalization.
As=[]
for i,j in itertools.combinations(range(4),2):
    A=np.zeros((4,4));A[i,j]=A[j,i]=1/math.sqrt(2);As.append(A)
for diag in [np.array([1,-1,0,0])/math.sqrt(2),np.array([1,1,-2,0])/math.sqrt(6),np.array([1,1,1,-3])/math.sqrt(12)]:As.append(np.diag(diag))
check('HURWITZ','degree-2 trace-free matrix count',len(As),9)
for i,A0 in enumerate(As):
    check('HURWITZ',f'trace free basis {i}',np.trace(A0),0.0)
    for j,B0 in enumerate(As):check('HURWITZ',f'Haar quadratic Gram {i},{j}',np.trace(A0@B0),float(i==j))
def harmonic(q):
    q=np.asarray(q,float)
    return np.r_[1.,2*q,np.array([math.sqrt(12)*q@A@q for A in As])]
E=np.array([harmonic(qfloat(q)) for q in T])/math.sqrt(24)
check('HURWITZ','14-dimensional orthonormal 5-design frame',E.T@E,np.eye(14),atol=1e-10)
# Quaternion multiplication on coefficients for all ordered 25 group cells.
def qprod(a,b):
    u=np.asarray(a,float);v=np.asarray(b,float)
    return np.r_[u[0]*v[0]-u[1:]@v[1:],u[0]*v[1:]+v[0]*u[1:]+np.cross(u[1:],v[1:])]
def qconj(a):return np.r_[a[0],-a[1:]]
def keyq(a):return tuple(round(float(z),9) for z in a)
Ifloats=np.array([qfloat(q) for q in Ic]);Hfloats=np.array([qfloat(q) for q in T]); Ukeys={keyq(q) for q in Ifloats}
reps=[];covered=set()
for g in Ifloats:
    if keyq(g) in covered:continue
    reps.append(g)
    covered|={keyq(qprod(g,h)) for h in Hfloats}
check('HURWITZ','five right cosets',len(reps),5)
check('HURWITZ','coset coverage',covered,Ukeys)
counts=collections.Counter()
frames=[]
for i,gi in enumerate(reps):
    for j,gj in enumerate(reps):
        cell=[qprod(qprod(gi,h),qconj(gj)) for h in Hfloats]
        ck=[keyq(q) for q in cell]
        check('HURWITZ',f'cell size {i},{j}',len(set(ck)),24)
        check('HURWITZ',f'cell lies in I {i},{j}',set(ck)<=Ukeys)
        counts.update(ck)
        Fcell=np.array([harmonic(q) for q in cell])/math.sqrt(24)
        check('HURWITZ',f'cell scalar frame Gram {i},{j}',Fcell.T@Fcell,np.eye(14),atol=1e-10)
        frames.append(Fcell/5)
check('HURWITZ','600 labelled register occurrences',sum(counts.values()),600)
check('HURWITZ','five occurrences of each icosian vertex',sorted(counts.values()),[5]*120)
F600=np.vstack(frames)
check('HURWITZ','25 register isometry',F600.T@F600,np.eye(14),atol=1e-10)
for k in [0,12,24]:
    mask=np.ones(600,bool);mask[k*24:(k+1)*24]=False
    check('HURWITZ',f'one cell deletion metric {k}',F600[mask].T@F600[mask],(24/25)*np.eye(14),atol=1e-10)
check('HURWITZ','comparison cosine',math.sqrt(24/25),2*math.sqrt(6)/5)
check('HURWITZ','comparison sine',math.sqrt(1-24/25),1/5)
# icosian group invariant rank through n=12 by independent character averaging.
def U_n(x,n):
    if n==0:return one
    u0=one;u1=fldscale(x,2)
    for k in range(2,n+1):u0,u1=u1,fldsub(fldmul(fldscale(x,2),u1),u0)
    return u1
ranks={}
for n in range(0,13):
    vals=[]
    for grp in (T,Ic):
        total=zero
        for q in grp:total=fldadd(total,U_n(q[0],n))
        vals.append(fldscale(total,F(1,len(grp))))
    ranks[n]=vals
    check('REYNOLDS',f'2T invariant rank n{n}',vals[0][1],F(0))
    check('REYNOLDS',f'2I invariant rank n{n}',vals[1][1],F(0))
    check('REYNOLDS',f'2I <= 2T rank n{n}',vals[1][0]<=vals[0][0])
for n,got in {0:(1,1),6:(1,0),8:(1,0),12:(2,1)}.items():
    check('REYNOLDS',f'Reynolds decomposition n{n}',tuple(x[0] for x in ranks[n]),got)
for n in range(1,6):check('REYNOLDS',f'rooted functional vanishes n{n}',tuple(x[0] for x in ranks[n]),(0,0))
# Cubic family embedding, exact Haar/24-atom moments and 2I/H discrimination.
rr=[np.array([-2,1,1])/math.sqrt(6),np.array([1,-2,1])/math.sqrt(6),np.array([1,1,-2])/math.sqrt(6)]
def fam_eval(q,aa):
    v=np.asarray(q,dtype=float)[1:]
    return float(4*sum(aa[j]*(rr[j]@v)**2 for j in range(3)))
for aa in [np.array([1.,-1.,0.]),np.array([2.,-3.,1.]),np.array([-1.,-.5,1.5])]:
    hv=[fam_eval(qfloat(q),aa) for q in T]
    values=sorted([(float(2*a),6) for a in aa]+[(0.,6)])
    for u in [0.,*list(2*aa)]:check('FAMILY',f'four-atom multiplicity a{tuple(aa)} at {u}',sum(abs(v-u)<1e-9 for v in hv),6*((abs(u)<1e-10)+sum(abs(2*t-u)<1e-10 for t in aa)))
    for k in range(1,7):
        expected=sum((2*aa[j])**k for j in range(3))/4
        check('FAMILY',f'four atom moment a{tuple(aa)} k{k}',np.mean(np.array(hv)**k),expected,atol=1e-8)
    iv=np.array([fam_eval(qfloat(q),aa) for q in Ic])
    r2=float(aa@aa);c=float(np.prod(aa))
    check('FAMILY',f'Icosian cubic zero a{tuple(aa)}',np.mean(iv**3),0.,atol=1e-9)
    check('FAMILY',f'rooted 2nd moment a{tuple(aa)}',np.mean(iv**2)-np.mean(np.array(hv)**2)/25,24*r2/25,atol=1e-9)
    check('FAMILY',f'rooted 3rd moment a{tuple(aa)}',np.mean(iv**3)-np.mean(np.array(hv)**3)/25,-6*c/25,atol=1e-9)
    check('FAMILY',f'rooted 4th moment a{tuple(aa)}',np.mean(iv**4)-np.mean(np.array(hv)**4)/25,131*r2*r2/50,atol=1e-8)
    check('FAMILY',f'rooted 5th moment a{tuple(aa)}',np.mean(iv**5)-np.mean(np.array(hv)**5)/25,-4*r2*c/5,atol=1e-8)
# Exact sextic difference, in Q(sqrt5), independent of decimal quaternion averages.
res=zero
for q in Ic:
    x,y,z=q[1:]
    a=fldadd(fldadd(fldscale(x,-2),y),z)
    b=fldadd(fldsub(x,fldscale(y,2)),z)
    val=fldscale(fldsub(fldmul(a,a),fldmul(b,b)),F(2,3))
    res=fldadd(res,fldpow(val,6))
res=fldscale(res,F(1,120))
check('FAMILY','exact Icosian sextic rational value',res,(F(1241,16),F(0)))
x,y,z=s.symbols('x y z',real=True)
pol=s.Poly((s.Rational(2,3)*((-2*x+y+z)**2-(x-2*y+z)**2))**6,x,y,z)
ha=F(0)
for (aa,bb,cc),co in pol.terms():
    cf=F(int(s.numer(co)),int(s.denom(co)))
    ha+=cf*haar((0,aa,bb,cc))
check('FAMILY','exact Haar sextic from Dirichlet monomials',ha,F(540,7))
check('FAMILY','exact sextic defect',res[0]-ha,F(47,112))
check('FAMILY','canonical quartic coefficient',s.simplify(s.Rational(131,50)*(s.Rational(25,24))**2),s.Rational(3275,1152))
# Six-port augmentation isometry and 13/3 singlet norm.
Tp=[(-1,1,1),(1,-1,1),(1,1,-1)]; eps=Tp+[tuple(-v for v in e) for e in Tp]
Omega=np.array([[.5,*[v/2 for v in e]] for e in eps])
V=Omega[:,1:];mat=V.T@V;J=np.ones((3,3))
check('BOUNDARY','six-port imaginary Gram',mat,2*np.eye(3)-.5*J)
u=np.ones(3)/math.sqrt(3);Pu=np.outer(u,u);invm=.7071067811865476*(np.eye(3)-Pu)+math.sqrt(2)*Pu
check('BOUNDARY','analytic inverse sqrt',invm@mat@invm,np.eye(3))
for trial in range(12):
    aa=RNG.normal(size=3);aa-=np.mean(aa);w=RNG.normal(size=3)
    even=np.array([fam_eval(q,aa) for q in Omega])/math.sqrt(8)
    odd=V@invm@w
    check('BOUNDARY',f'augmentation even norm trial{trial}',even@even,aa@aa,atol=1e-9)
    check('BOUNDARY',f'augmentation odd norm trial{trial}',odd@odd,w@w,atol=1e-9)
    check('BOUNDARY',f'augmentation orthogonality trial{trial}',even@odd,0.,atol=1e-9)
check('BOUNDARY','unrooted H12 constant port projection',6*13**2/234,F(13,3))
check('BOUNDARY','complementary harmonic norm',13-F(13,3),F(26,3))
# Complete quartic subgroup obstruction at explicit moment.
q0q1=lambda q:fldsub(fldmul(q[0],q[0]),fldmul(q[1],q[1]))
for name,qs,expect in [('2T',T,F(1,6)),('2I',Ic,F(3,40))]:
    tot=zero
    for q in qs:tot=fldadd(tot,fldpow(q0q1(q),4))
    check('SUBGROUP',f'{name} quartic subgroup discriminator',fldscale(tot,F(1,len(qs))),(expect,F(0)))
check('SUBGROUP','2O quartic subgroup discriminator',sum((v[0]-v[1])**4 for v in O_sq)/48,F(5,48))
check('SUBGROUP','Haar quartic (q0^2-q1^2)^4',sum(F(math.comb(4,k))*(-1)**k*haar((8-2*k,2*k,0,0)) for k in range(5)),F(3,40))

# F. Additional E4 controls: forbidden identifications, source-specific exact edges.
# Source-matched full-pencil matrix weights versus singular *interior* Schur pole.
for trial in range(8):
    Mm=np.diag([1.2,2.,3.5]);Am=np.array([[1.,.4,-.1],[.4,3.,.3],[-.1,.3,5.]])
    Li=RNG.normal(size=(2,3));Ts=sla.inv(sla.sqrtm(Mm))@Am@sla.inv(sla.sqrtm(Mm))
    ww,Vv=sla.eigh(Ts)
    for j in range(3):
        rr=Li@sla.inv(sla.sqrtm(Mm))@Vv[:,j:j+1]
        weight=rr@rr.T
        check('FULLPENCIL',f'weighted residue PSD trial{trial} j{j}',np.linalg.eigvalsh(weight).min()>=-1e-10)
        zv=ww[j]+1j*1e-6
        Rp=Li@np.linalg.inv(Am-zv*Mm)@Li.T
        # Nonpole analytic tails cause O(epsilon) residue error.
        check('FULLPENCIL',f'finite pole residue trial{trial} j{j}',(-1j*1e-6)*Rp,weight,atol=5e-5)
# Verify unitary equivariant origin (noncommuting SU2 matrices; no mere scalar proof).
for trial in range(12):
    a=RNG.normal(size=(2,2))+1j*RNG.normal(size=(2,2));a,_=np.linalg.qr(a);a/=np.sqrt(np.linalg.det(a))
    b=RNG.normal(size=(2,2))+1j*RNG.normal(size=(2,2));b,_=np.linalg.qr(b);b/=np.sqrt(np.linalg.det(b))
    u_ba=np.linalg.inv(a);cocycle=a@np.linalg.inv(b);ua_inv=b
    check('F7',f'global equivariant identity cocycle trial{trial}',u_ba@cocycle@ua_inv,np.eye(2),atol=1e-10)
# Full-plane exterior Gram identities and Hodge determinant powers.
tval=math.sqrt(24/25)
for trial in range(8):
    Qr,_=np.linalg.qr(RNG.normal(size=(14,3)))
    JA=F600@Qr
    Jb=np.vstack([f/ math.sqrt(24/25) if i!=0 else np.zeros_like(f) for i,f in enumerate(frames)])@Qr
    check('EXTERIOR',f'comparison 1-form trial{trial}',JA.T@Jb,tval*np.eye(3),atol=1e-10)
    Gcmp=JA.T@Jb
    for k in (1,2,3):
        minors=[np.linalg.det(Gcmp[np.ix_(row,col)]) for row in itertools.combinations(range(3),k) for col in itertools.combinations(range(3),k)]
        check('EXTERIOR',f'exterior comparison block trial{trial} k{k}',np.array(minors).reshape(math.comb(3,k),-1),(tval**k)*np.eye(math.comb(3,k)),atol=1e-10)
# Nonlinear exactness vs quadratic exactness: the finite 2T fourth-moment obstruction.
check('E4','24-cell fourth moment of quadratic differs from Haar',(F(1,6)!=F(3,40)))
# One cubic singular branch: first derivative compatible, second derivative impossible.
qq,eta=s.symbols('qq eta',real=True)
fjet=qq**3/s.Integer(3)+eta**2*qq
check('E4','singular stationary Hessian at 0',s.diff(fjet,qq,2).subs({qq:0,eta:0}),s.S(0))
check('E4','singular stationary mixed derivative at 0',s.diff(fjet,qq,eta).subs({qq:0,eta:0}),s.S(0))
check('E4','second jet obstruction has positive constant',s.diff(fjet,qq,eta,2).subs({qq:0,eta:0}),s.S(2))
# Connected logistic f with Z(t)=exp(t) is not a stationary profile.
tt=s.symbols('tt',real=True)
fl=1/(1+s.exp(-2*tt));Zw=s.exp(tt)
Vw=4*fl**2*(1-fl)**2
weighted=s.simplify(s.diff(Zw*s.diff(fl,tt),tt)-Zw*s.diff(Vw,tt)/s.diff(fl,tt)/2)
check('WEIGHT','nonconstant weight ruins logistic stationarity at t=0',weighted.subs(tt,0),s.Rational(1,2))
# Machine-readable output and explicit coverage/scope disclaimer.
summary={'artifact':'Paper1B-IndependentControlsBatch8Results-v1_1.json','batch':8,'scope_census':[353,400],'date':'2026-11-13','method':'One executor; independent algebraic/finite symbolic and numerical control families, not independent agents or complete external topological proofs','total':len(OUT),'passed':sum(x['passed'] for x in OUT),'failed':sum(not x['passed'] for x in OUT),'counts':dict(collections.Counter(x['family'] for x in OUT)),'checks':OUT,'limitations':['Global equivariant mapping-space and unstable gauge existence theorems not independently reconstructed','Selected finite profile/Schur/Clifford controls are not proof of every quantified global statement','No physical occurrence inferred from abstract geometry or group design']}
output=Path('/mnt/data/Paper1B-IndependentControlsBatch8Results-v1_1.json')
output.write_text(json.dumps(summary,indent=2,ensure_ascii=False,default=str))
print('RESULTS',summary['total'],summary['passed'],summary['failed'])
print('FAMILIES',summary['counts'])
if summary['failed']:raise SystemExit(1)
