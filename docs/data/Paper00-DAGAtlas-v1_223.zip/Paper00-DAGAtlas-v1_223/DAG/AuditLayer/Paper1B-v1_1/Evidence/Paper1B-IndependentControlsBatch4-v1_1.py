#!/usr/bin/env python3
"""Paper I-B Batch 4 independent scoped mathematical checks (census 176..219).
Single-model E3 computation, not a proof of imported global classification.
Outputs literal JSON results beside this script; no DAG/audit ZIP mutation.
"""
from collections import Counter, defaultdict
from fractions import Fraction as F
from itertools import product,combinations
from math import comb,pi,sqrt,exp
from pathlib import Path
import json, numpy as np, sympy as sp, networkx as nx
R=Path('/mnt/data')
checks=[]
def ck(family, name, observed, expected=True, tol=None):
    if isinstance(observed,np.generic): observed=observed.item()
    if tol is None:
        passed=(observed==expected)
    else: passed=abs(complex(observed)-complex(expected))<=tol
    idx=1+sum(z['family']==family for z in checks)
    checks.append({'id':f'{family}-{idx:03d}','family':family,'check':name,'passed':bool(passed),'observed':str(observed),'expected':str(expected),'tolerance':tol})
    if not passed: raise AssertionError(checks[-1])

def h(m):return comb(2*m+4,4)
def d(l):return (l+1)*(l+2)*(2*l+3)//6
def v(m):return comb(2*m+2,2)
def b(m,a):return comb(2*m-a+2,2)
def hm(m,q):return sum(b(m,a) for a in range(abs(q),2*m+1,2))
def pweight(l,q):
    if abs(q)>l:return 0
    L=(l-abs(q))//2
    return (L+1)*(L+abs(q)+1)
def gH(m):
    g=nx.Graph();g.add_nodes_from((a,b_) for a in range(2*m+1) for b_ in range(2*m+1-a))
    for x,y in g.nodes:
        for da,db in product((-1,1),repeat=2):
            q=(x+da,y+db)
            if q in g:g.add_edge((x,y),q)
    return g
def gP(l):return nx.path_graph(l+1)

# 1: Complex SKT form algebra, K triviality is tested only on algebraic and fiber-descent scope.
x,y,t,h12=sp.symbols('x y t h12',real=True)
# Even-degree x,y commute and x²=y²=0; identify coefficient of xy in the curvature wedge.
for a in range(-5,6):
    tval=sp.I*sp.Rational(3,4)+a
    coeff=sp.expand((x+tval*y)*(x+sp.conjugate(tval)*y)).coeff(x*y)
    ck('SKT',f'rank-one curvature coefficient Re(tau)={a}',sp.simplify(coeff),sp.Integer(2*a))
for a in range(-5,6):
    coeff=sp.expand((h12+sp.I*sp.Rational(2,3))+(h12-sp.I*sp.Rational(2,3)))
    ck('SKT',f'rank-two mixed positive-form condition h12.real={a}',coeff.subs(h12,a),2*a)
# Betti polynomial and vanishing negative-base-line holomorphic section dimensions.
z=sp.symbols('z')
betti=sp.Poly((1+z)**2*(1+z**3)**2,z)
ck('CANONICAL','harmonic basis total rank',sum(betti.all_coeffs()),16)
ck('CANONICAL','M8 top degree',betti.degree(),8)
for power in range(1,9):
    h0=max(0,-2*power+1)**2
    ck('CANONICAL',f'O(-2m,-2m) section dimension m={power}',h0,0)

# 2: Flat exchange holonomy and Lie invariant torsion/curvature.
roots=[1,-1,1j,-1j]
for aa,bb in product(range(4),repeat=2):
    z0,w0=roots[aa],roots[bb]
    Ut=np.diag([z0,w0]); UE=np.diag([w0,z0]); J=np.array([[0,1],[1,0]])
    ck('EXCHANGE',f'exchange intertwines holonomy ({aa},{bb})',bool(np.allclose(J@Ut@J,UE)))
    ck('EXCHANGE',f'exchange square ({aa},{bb})',bool(np.allclose(J@J,np.eye(2))))
ck('EXCHANGE','SU(2) torus Weyl inversion fixed points',sum((a==(-a)%4 and b==(-b)%4) for a,b in product(range(4),repeat=2)),4)
# su(2) cross product structure C(x,y)=2 cross(x,y). Basis structure and Jacobi.
e=np.eye(3,dtype=int)
def bracket(a,b):return 2*np.cross(a,b)
for s in [0,F(1,4),F(1,2),F(3,4),1]:
    for i,j,k in product(range(3),repeat=3):
        X=e[i];Y=e[j];Z=e[k]
        # curvature R(X,Y)Z = s²([X,[Y,Z]]-[Y,[X,Z]]) - s[[X,Y],Z]
        cur=float(s)**2*(bracket(X,bracket(Y,Z))-bracket(Y,bracket(X,Z)))-float(s)*bracket(bracket(X,Y),Z)
        rhs=float(s*(s-1))*bracket(bracket(X,Y),Z)
        ck('CONNECTION',f'curvature formula s={s} indices {i}{j}{k}',bool(np.array_equal(cur,rhs)))
    ck('CONNECTION',f'torsion factor s={s}',2*float(s)-1,float(2*s-1))

# 3: Covariant Casimir spectral coupling and adjoint gap sample, incl large-spin challenge.
for iota in [F(0),F(1,2),F(1)]:
 for f in [F(1,5),F(1,3),F(1,2),F(3,4),F(9,10)]:
    terms=[]
    for j2 in range(0,13):
      j=F(j2,2)
      for k2 in range(abs(j2-int(2*iota)),j2+int(2*iota)+1,2):
        k=F(k2,2)
        cas=4*((1-f)*j*(j+1)+f*k*(k+1)+(f*f-f)*iota*(iota+1))
        alt=4*(j*(j+1)+f*(k*(k+1)-j*(j+1)-iota*(iota+1))+f*f*iota*(iota+1))
        ck('CASIMIR',f'coupled Casimir j={j} k={k} i={iota} f={f}',cas,alt)
        terms.append(cas)
    if iota==0:ck('CASIMIR',f'trivial sector minimum f={f}',min(terms),0)
    else:
       floor=3*min(f*f,(1-f)*(1-f))
       ck('CASIMIR',f'adjoint lower bound i={iota},f={f}',min(terms)>=floor)
       if iota==F(1,2):ck('CASIMIR',f'doublet minimum exact f={f}',min(terms),floor)

# 4: Flat torus Landau tower and twisted product Dirac count/heat.
for q in [-5,-3,-1,1,2,5]:
 for A in [sp.pi,4*sp.pi**2]:
    beta=2*sp.pi*abs(q)/A
    for r in range(0,8):
      ck('LANDAU',f'Bochner energy q{q} r{r} A{A}',sp.simplify(beta*(2*r+1)-2*beta*(r+sp.Rational(1,2))),0)
      if r>0:ck('LANDAU',f'Dirac square q{q} r{r} A{A}',sp.simplify(2*beta*r),2*beta*r)
    num=float(abs(q)/(2*np.sinh(float(beta)*.3)))
    hs=abs(q)*sum(np.exp(-float(beta)*(2*r+1)*.3) for r in range(1500))
    ck('LANDAU',f'geometric heat trace q{q} A{A}',hs,num,1e-8)
for j,k in product(range(4),repeat=2):
    mj=(j+1)*(j+2);mk=(k+1)*(k+2)
    ck('DIRAC',f'product twisted zero-torus sign multiplicity j{j}k{k}',int(8*mj*mk/2),4*mj*mk)
    ck('DIRAC',f'product twisted excited sign multiplicity j{j}k{k}',int(8*mj*mk*2/2),8*mj*mk)

# 5: Hodge product, exchange and harmonic trace via independent exterior algebra.
full=sp.expand((1+z)**2*(1+z**3)**2)
exch=sp.expand((1-z**2)*(1-z**6))
for p in range(9):
    mult=full.coeff(z,p);tr=exch.coeff(z,p)
    ck('HODGE',f'Betti b{p}',int(mult)>=0)
    ck('HODGE',f'exchange p{p} parity',(int(mult)+int(tr))%2,0)
    ck('HODGE',f'exchange p{p} bound',abs(int(tr))<=int(mult))
    ck('HODGE',f'plus/minus p{p}',(int(mult)+int(tr))//2+(int(mult)-int(tr))//2,int(mult))
ck('HODGE','sum harmonic dimensions',sum(int(full.coeff(z,p)) for p in range(9)),16)
ck('HODGE','exchange harmonic trace',sum(int(exch.coeff(z,p)) for p in range(9)),0)

# 6: Finite carriers, graph edges, components, cycle space including exchange quotient.
for m in range(0,8):
    g=gH(m);vs=g.number_of_nodes();ee=g.number_of_edges();cc=nx.number_connected_components(g)
    ck('GRAPH',f'H{m} vertices',vs,v(m))
    ck('GRAPH',f'H{m} edges',ee,4*m*m)
    ck('GRAPH',f'H{m} components',cc,1 if m==0 else 2)
    ck('GRAPH',f'H{m} cycles',ee-vs+cc,0 if m==0 else (2*m-1)*(m-1))
    ck('GRAPH',f'H{m} module dimension',sum((a+1)*(b_+1) for a,b_ in g),h(m))
for l in range(0,10):
 g=gP(l); ck('GRAPH',f'P{l} graph edges',g.number_of_edges(),l)
 ck('GRAPH',f'P{l} scalar-band dimension',sum((k+1)**2 for k in range(l+1)),d(l))
for ma,mb in [(1,1),(2,1),(2,2),(3,1)]:
 g=nx.cartesian_product(gH(ma),gH(mb))
 vc=g.number_of_nodes();ec=g.number_of_edges();cc=nx.number_connected_components(g)
 ck('GRAPH',f'H{ma}xH{mb} vertices',vc,v(ma)*v(mb))
 ck('GRAPH',f'H{ma}xH{mb} edges',ec,4*ma*ma*v(mb)+4*mb*mb*v(ma))
 ck('GRAPH',f'H{ma}xH{mb} components',cc,4)
 ck('GRAPH',f'H{ma}xH{mb} cycles',ec-vc+cc,ec-vc+4)
for l in range(1,6):
 gp=nx.cartesian_product(gP(l),gH(1))
 ck('GRAPH',f'P{l}xH1 edges',gp.number_of_edges(),10*l+4)
 ck('GRAPH',f'P{l}xH1 cycles',gp.number_of_edges()-gp.number_of_nodes()+nx.number_connected_components(gp),4*l)
# exchange orbit counts independently for G1 and P_l, including quotient loops/multi-edges
for g,label in [(gH(1),'H1')]+[(gP(l),f'P{l}') for l in range(1,6)]:
    nd=list(g.nodes());ed=list(g.edges())
    canon=lambda uv:tuple(sorted(uv,key=str))
    vertex_orbits={min((str(a),str(b)),(str(b),str(a))) for a,b in product(nd,repeat=2)}
    product_edges=[]
    for s,t in product(nd,repeat=2):
      for ss in g.neighbors(s):product_edges.append(((s,t),(ss,t)))
      for tt in g.neighbors(t):product_edges.append(((s,t),(s,tt)))
    # edges set as undirected; swap map x/p
    edset={frozenset(e) for e in product_edges}
    swap=lambda e:frozenset((b,a) for a,b in e)
    eorbs={min(tuple(sorted(map(str,e))),tuple(sorted(map(str,swap(e))))) for e in edset}
    c=nx.number_connected_components(g)
    nvox=len(vertex_orbits);neox=len(eorbs);cvox=c*(c+1)//2
    ck('GRAPH',f'{label} swap vertex orbits',nvox,len(nd)*(len(nd)+1)//2)
    ck('GRAPH',f'{label} swap edge orbits',neox,g.number_of_edges()*len(nd))
    ck('GRAPH',f'{label} swap cycle rank',neox-nvox+cvox,(6 if label=='H1' else (len(nd)-1)*(len(nd)-2)//2))

# 7: Rectangles as the only cross commutator blocks, gauge covariance of zero condition.
for x0,x1,p0,p1 in [(1,1,1,1),(1,2,1,1),(1,1,1,3),(1,2,3,6),(1+2j,1-2j,3-1j,3+1j)]:
  Mx=np.zeros((4,4),complex); Mp=np.zeros((4,4),complex)
  ix=lambda s,t:2*s+t
  for t,coef in [(0,x0),(1,x1)]:
    Mx[ix(1,t),ix(0,t)]=coef;Mx[ix(0,t),ix(1,t)]=np.conj(coef)
  for s,coef in [(0,p0),(1,p1)]:
    Mp[ix(s,1),ix(s,0)]=coef;Mp[ix(s,0),ix(s,1)]=np.conj(coef)
  lhs=Mx@Mp-Mp@Mx
  fwd=x1*p0-p1*x0
  ck('RECTANGLE',f'forward rectangle ({x0},{x1},{p0},{p1})',lhs[ix(1,1),ix(0,0)],fwd,1e-10)
  ck('RECTANGLE',f'forward+reverse zero criterion ({x0},{x1},{p0},{p1})',np.linalg.norm(lhs)<1e-9,(abs(fwd)<1e-9 and abs(x1*np.conj(p1)-np.conj(p0)*x0)<1e-9))

# 8: All-level representation multiplicities, exchange completion, right diagonal and Hopf.
for m in range(0,7):
 ck('REP',f'H_m dim m{m}',sum((a+1)*(bb+1) for a in range(2*m+1) for bb in range(2*m+1-a)),h(m))
 ck('REP',f'one-handed decomposition m{m}',sum((a+1)*b(m,a) for a in range(2*m+1)),h(m))
 ck('REP',f'one-handed corner first-three m{m}',sum((a+1)*b(m,a) for a in range(min(2,2*m)+1)),(12*m*m+2*m+1) if m>=1 else 1)
 for q in range(-2*m-1,2*m+2):
   direct=sum((bb+1) for a in range(2*m+1) for bb in range(2*m+1-a) if abs(q)<=a and (a-q)%2==0)
   ck('REP',f'Hm chiral q={q},m{m}',direct,hm(m,q))
for l in range(0,9):
 ck('REP',f'P_l dimension l{l}',sum((k+1)**2 for k in range(l+1)),d(l))
 for q in range(-l-1,l+2):
   w=sum(k+1 for k in range(l+1) if abs(q)<=k and (k-q)%2==0)
   ck('REP',f'P_l weight l{l},q{q}',w,pweight(l,q))
for m in range(1,7):
    for l in range(0,9):
      intdim=sum((a+1)*b(m,a) for a in range(min(2*m,l)+1))
      maxrank=sum((a+1)*min(a+1,b(m,a)) for a in range(min(2*m,l)+1))
      ck('INTERTWINER',f'one-handed Hom upper bound m{m}l{l}',maxrank<=min(h(m),d(l)))
      ck('INTERTWINER',f'one-handed Hom dim m{m}l{l}',intdim>=maxrank)
for l in range(1,9):
 c=5;dim=d(l)*15;comp=2*dim-c*c
 ck('EXCHANGE',f'P{l}H1 completion dimension',comp,30*d(l)-25)
 ck('EXCHANGE',f'P{l}H1 completion even',(comp+c)//2,15*d(l)-10)
 ck('EXCHANGE',f'P{l}H1 completion odd',(comp-c)//2,15*d(l)-15)
 ck('EXCHANGE',f'P{l}H1 compressed exchange kernel',dim-c*c,15*d(l)-25)
for M in range(1,8):
 inv=sum(comb(2*M-bb+2,2)*comb(2-bb+2,2) for bb in range(3))
 ck('DIAGONAL',f'H_M H1 right SU2 singlets M{M}',inv,20*M*M+20*M+6)
for l in range(0,10):
  right=sum((k+1)*comb(4-k,2) for k in range(min(l,2)+1))
  ck('DIAGONAL',f'P{l} H1 right SU2 singlets',right,6 if l==0 else 12 if l==1 else 15)
  dim=7*pweight(l,0)+6*pweight(l,1)+2*pweight(l,2)
  rr=l//2
  target=15*rr*rr+24*rr+7 if l%2==0 else 15*rr*rr+36*rr+19
  ck('DIAGONAL',f'P{l} H1 Hopf U1 invariant rank',dim,target)
for q in [-2,-1,0,1,2]:ck('DIAGONAL',f'H1 chiral q{q}',hm(1,q),{0:7,1:3,-1:3,2:1,-2:1}[q])

# Parity and natural action-algebra sizes derived from irreducible dimensions.
for m in range(0,8):
    even=sum((a+1)*(bb+1) for a in range(2*m+1) for bb in range(2*m+1-a) if (a+bb)%2==0)
    odd=h(m)-even
    ee=(m+1)*(m+2)*(2*m*m+6*m+3)//6
    oo=m*(m+1)**2*(m+2)//3
    ck('REP',f'H{m} central-even dimension',even,ee)
    ck('REP',f'H{m} central-odd dimension',odd,oo)
    n=2*m
    alg=sum(((a+1)*(bb+1))**2 for a in range(n+1) for bb in range(n+1-a))
    alg_formula=sp.Rational((n+1)*(n+2)*(n+3)*(n+4)*(2*n*n+10*n+15),360)
    ck('REP',f'H{m} action algebra dimension',alg,alg_formula)
for ell in range(0,9):
    alg=sum((k+1)**4 for k in range(ell+1))
    formula=sp.Rational((ell+1)*(ell+2)*(2*ell+3)*(3*ell**2+9*ell+5),30)
    ck('REP',f'P{ell} action algebra dimension',alg,formula)
for m in range(0,7):
    for l in range(0,9):
        common=sum((k+1)**2 for k in range(min(l,m)+1))
        ck('INTERTWINER',f'full Spin4 P{l} ∩ H{m} rank',common,d(min(l,m)))
# Matrix-level complex Cl(8,0) with two commuting tensor factors and graded lift.
s1=sp.Matrix([[0,1],[1,0]]);s2=sp.Matrix([[0,-sp.I],[sp.I,0]]);s3=sp.diag(1,-1)
pauli=[sp.kronecker_product(s1,sp.eye(2)),sp.kronecker_product(s2,sp.eye(2)),sp.kronecker_product(s3,s1),sp.kronecker_product(s3,s2)]
vol=pauli[0]*pauli[1]*pauli[2]*pauli[3]
gammas=[sp.kronecker_product(g,sp.eye(4)) for g in pauli]+[sp.kronecker_product(vol,g) for g in pauli]
for i in range(8):
    for j in range(i,8):
        antic=gammas[i]*gammas[j]+gammas[j]*gammas[i]
        ck('CLIFFORD',f'Cl8 anticommutator gamma{i+1},gamma{j+1}',antic==((2 if i==j else 0)*sp.eye(16)))
ck('CLIFFORD','four-generator volume element squares +I',vol**2,sp.eye(4))

# 9: 2I Molien first roots and finite-subgroup exact rank onsets.
from functools import lru_cache
@lru_cache(None)
def mu_icosa(a):
  count=0
  for i in range(a//12+1):
   for j in range(a//20+1):
    rem=a-12*i-20*j
    if rem>=0 and rem%30==0:count+=1
  # (1-t^60)*series
  if a>=60:
    old=0
    for i in range((a-60)//12+1):
     for j in range((a-60)//20+1):
      rem=a-60-12*i-20*j
      if rem>=0 and rem%30==0:old+=1
    count-=old
  return count
for a in range(0,80):
 ck('FINITE',f'2I Molien mu_{a} nonnegative',mu_icosa(a)>=0)
 if a<=11:ck('FINITE',f'2I Molien vanishing a{a}',mu_icosa(a),int(a==0))
ck('FINITE','first nonconstant 2I invariant spin a',next(a for a in range(1,80) if mu_icosa(a)),12)
for l in range(0,17):
 rank=sum((a+1)*mu_icosa(a) for a in range(l+1))
 if l<12:ck('FINITE',f'P{l} 2I invariants',rank,1)
 if l==12:ck('FINITE','P12 2I adds 13 invariant dimensions',rank,14)
for m in range(0,8):
 rank=sum(b(m,a)*mu_icosa(a) for a in range(2*m+1))
 if m<6:ck('FINITE',f'H{m} 2I invariant rank',rank,v(m))
 if m==6:ck('FINITE',f'H6 2I first additional invariant',rank,v(m)+1)
# 2I uniform design strength 11. r-fold exact tests and quotient on one-handed action.
for subgroup,L2,L3,L4 in [('2T',2,1,1),('2O',3,2,1),('2I',5,3,2)]:
 for rr,L in [(2,L2),(3,L3),(4,L4)]:
   ck('FINITE',f'{subgroup} max m at r={rr}',L//2, {'2T':{2:1,3:0,4:0},'2O':{2:1,3:1,4:0},'2I':{2:2,3:1,4:1}}[subgroup][rr])

# 10: Scalar radius/commutator exact harmonic projection on P1 and P2 by monomial Gram matrices.
xs=sp.symbols('x0 x1 x2 x3')
@lru_cache(None)
def moment(exp):
 if any(a%2 for a in exp):return sp.Rational(0)
 ns=[a//2 for a in exp];t=sum(ns)
 def exact_product(vals):
  out=sp.Integer(1)
  for val in vals:out*=val
  return out
 def poch_half(k):return exact_product((sp.Rational(1,2)+i) for i in range(k))
 return exact_product(poch_half(n) for n in ns)/exact_product((sp.Integer(2)+i) for i in range(t))
@lru_cache(None)
def sphere_inner(f,g):
 f=sp.Poly(sp.expand(f*g),*xs)
 return sp.expand(sum(coeff*moment(mon) for mon,coeff in f.terms()))
for ell in [1,2]:
 bas=[sp.Integer(1)]+list(xs)
 if ell>=2:
   bas +=[xs[i]*xs[j] for i,j in combinations(range(4),2)]
   bas += [xs[i]**2-xs[3]**2 for i in range(3)]
 dim=len(bas)
 ck('RADIUS',f'P{ell} constructed harmonic rank',dim,d(ell))
 Gram=sp.Matrix(dim,dim,lambda i,j:sphere_inner(bas[i],bas[j]));Gi=Gram.inv()
 C=[]
 for a in range(4):
   M=sp.Matrix(dim,dim,lambda i,j:sphere_inner(bas[i],xs[a]*bas[j]))
   C.append(Gi*M)
 # top block coordinates since basis sorted by homogeneous harmonic degree
 top_low=1 if ell==1 else 5
 Proj=sp.diag(*([0]*top_low+[1]*(dim-top_low)))
 rhs=sp.eye(dim)-sp.Rational(ell+2,2*(ell+1))*Proj
 norm=sum((aa*aa for aa in C),sp.zeros(dim))
 ck('RADIUS',f'P{ell} radius operator identity exact',norm==rhs)
 for a,bb in combinations(range(4),2):
   grad=sp.Matrix(dim,dim,lambda i,j:sphere_inner(bas[i],xs[a]*sp.diff(bas[j],xs[bb])-xs[bb]*sp.diff(bas[j],xs[a])))
   L=Gi*grad
   comm=C[a]*C[bb]-C[bb]*C[a]
   ck('RADIUS',f'P{ell} commutator a{a}b{bb} exact',comm==sp.Rational(1,2*(ell+1))*L*Proj)
 def adj(A):return Gi*A.T*Gram
 tau=sp.trace(sp.eye(dim)-norm)/dim
 ck('RADIUS',f'P{ell} normalized radius defect trace',tau,sp.Rational(3,2*ell+3))
 sigma=sum((adj(C[a]*C[bb]-C[bb]*C[a])*(C[a]*C[bb]-C[bb]*C[a]) for a,bb in combinations(range(4),2)),sp.zeros(dim))
 ck('RADIUS',f'P{ell} normalized commutator squared trace',sp.trace(sigma)/dim,sp.Rational(ell*(ell+2),4*d(ell)))

# 11: Parent-compression correction and heat-limit leading coefficients.
P=np.diag([1,1,0,0]);Q=np.eye(4)-P
A=np.array([[1,2,3,0],[2,0,1,1],[3,1,0,2],[0,1,2,1]],dtype=int)
B=np.array([[0,1,2,3],[1,2,0,2],[2,0,3,1],[3,2,1,0]],dtype=int)
ck('BOUNDARY','PAP PBP - PABP',bool(np.array_equal(P@A@P@B@P-P@A@B@P,-P@A@Q@B@P)))
ck('BOUNDARY','compression commutator defect',bool(np.array_equal((P@A@P@B@P-P@B@P@A@P)-P@(A@B-B@A)@P,-P@A@Q@B@P+P@B@Q@A@P)))
for t in [.2,.1,.04]:
  R_s=2.4;gam=1.8
  S=sum((k+1)**2*exp(-t*k*(k+2)/R_s**2) for k in range(0,250))
  approx=(sqrt(pi)*R_s**3/4)*t**(-1.5)
  ck('HEAT',f'S3 leading heat asymptotic t={t}',abs(S/approx-1)<.25)
  HH=sum((aa+1)*exp(-t*gam*aa*(aa+2)/4) for aa in range(0,250))**2
  approx_h=4/(gam*gam*t*t)
  ck('HEAT',f'enriched leading heat asymptotic t={t}',abs(HH/approx_h-1)<.35)
for L in [1,2,5]:
 for ell in [100,1000]:
  radius=float(L)*ell
  last=ell*(ell+2)/radius**2
  density=d(ell)/(2*pi**2*radius**3)
  ck('HEAT',f'level-scaled spectral ceiling ell{ell}, L{L}',abs(last-L**-2)<2.1*L**-2/ell)
  ck('HEAT',f'level-scaled DOS ell{ell}, L{L}',abs(density-1/(6*pi*pi*L**3))<5/(6*pi*pi*L**3*ell))

# 12: Exact isometric image operator and finite conditional blocking transport.
T=sp.Matrix([[sp.sqrt(2)/2,0],[0,sp.sqrt(2)/2],[sp.sqrt(2)/2,0],[0,sp.sqrt(2)/2]])
I=sp.eye(2);A=sp.Matrix([[2,1+sp.I],[1-sp.I,4]]);B=sp.Matrix([[1,2],[2,3]])
ck('TRANSPORT','T*T identity',T.conjugate().T*T,I)
TA=T*A*T.conjugate().T;TB=T*B*T.conjugate().T
ck('TRANSPORT','isometric product',TA*TB,T*(A*B)*T.conjugate().T)
ck('TRANSPORT','adjoints',TA.conjugate().T,TA)
ck('TRANSPORT','square polynomial',TA**2,T*(A**2)*T.conjugate().T)
ck('TRANSPORT','trace',sp.trace(TA),sp.trace(A))
ck('TRANSPORT','rank',TA.rank(),A.rank())
ck('TRANSPORT','characteristic on image',sp.expand(TA.charpoly().as_expr()),sp.expand(TA.charpoly().gen**2*A.charpoly().as_expr().subs(A.charpoly().gen,TA.charpoly().gen)))
ck('TRANSPORT','two-dimensional characteristic invariant',A.det(),(T.conjugate().T*TA*T).det())
# finite standard Borel counterexample/challenge: exact conditional averaging under label permutations.
X=[0,1,2,3];nu=[F(1,10),F(2,10),F(3,10),F(4,10)];w=[F(1,2),F(3,2),F(2),F(4)]
coarse=[0,0,1,1];perm=[2,0,3,1];inv={perm[i]:i for i in X}
for target in [0,1]:
  base=sum(nu[i]*w[i] for i in X if coarse[i]==target)/sum(nu[i] for i in X if coarse[i]==target)
  moved=sum(nu[inv[j]]*w[inv[j]] for j in X if coarse[inv[j]]==target)/sum(nu[inv[j]] for j in X if coarse[inv[j]]==target)
  ck('BLOCKING',f'conditional pushforward target {target}',base,moved)
ck('BLOCKING','probability normalization',sum(nu),1)

# Build receipt, store all individually replayable test results.
counts=dict(sorted(Counter(x['family'] for x in checks).items()))
result={'artifact':'Paper1B-IndependentControlsBatch4Results-v1_1.json','source':'Paper1B-M8Geometry-v1_131.tex','census_range_zero_based':[176,219],
        'method':'independent finite symbolic/numeric scoped tests, one model; not a full imported theorem proof',
        'checks':checks,'families':counts,'total':len(checks),'passed':sum(bool(x['passed']) for x in checks),'failed':sum(not x['passed'] for x in checks)}
assert result['total'] == result['passed']
(R/'Paper1B-IndependentControlsBatch4Results-v1_1.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
print('PASSED',result['passed'],'SCOPED_CONTROLS',counts)
