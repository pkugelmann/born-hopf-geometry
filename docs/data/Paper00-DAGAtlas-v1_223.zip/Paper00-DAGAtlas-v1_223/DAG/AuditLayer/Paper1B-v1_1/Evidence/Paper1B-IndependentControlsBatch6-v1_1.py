#!/usr/bin/env python3
"""Scope-limited, reproducible exact/symbolic controls, Paper I-B batch 6.
Checks are not exhaustive proofs or evidence for physical occurrence.
Requires sympy and standard library; reads only the immutable supplied TeX ZIP.
"""
import hashlib,itertools,math,json,zipfile,re,collections
from fractions import Fraction
import sympy as s
from sympy.matrices.normalforms import smith_normal_form
from sympy.polys.domains import ZZ
from pathlib import Path

ROOT=Path('/mnt/data')
ARCH=ROOT/'Paper00-PapersMinimal-v2_371(1)(1).zip'
SRC='Paper1B-M8Geometry-v1_131.tex'
OUT=ROOT/'Paper1B-IndependentControlsBatch6Results-v1_1.json'
records=[]
def check(group,name,condition,observed=None,method='EXACT'):
    if isinstance(condition,s.Basic): condition=bool(s.simplify(condition))
    passed=bool(condition)
    r={'id':f'{group}-{1+sum(x["family"]==group for x in records):03d}','family':group,'test':name,'passed':passed,'method':method}
    if observed is not None: r['observed']=str(observed)[:400]
    records.append(r)
    if not passed: print('FAIL:',r)

def eq(g,name,x,y):
    d=s.simplify(x-y)
    check(g,name,d==0, d)

with zipfile.ZipFile(ARCH) as z:
    srcpath=next(n for n in z.namelist() if n.endswith(SRC))
    text=z.read(srcpath).decode('utf-8')
    all_tex='\n'.join(z.read(n).decode('utf-8',errors='replace') for n in z.namelist() if n.endswith('.tex'))
    tex_sha=hashlib.sha256(text.encode()).hexdigest()

# 1. Cartan midpoint spectral branches and protected-gap boundary.
R=s.symbols('R',positive=True); d=s.symbols('d',real=True)
for n in range(1,17):
    b=n*(n+2)
    P=s.Matrix([[-3*d,s.sqrt(b)],[s.sqrt(b),d]])
    tr=s.trace(P); deter=P.det()
    eq('DIRAC',f'exact-vector block trace n={n}',tr,-2*d)
    eq('DIRAC',f'exact-vector block det n={n}',d*(-3*d)-b,deter)
    ev=[-d-s.sqrt(b+4*d*d),-d+s.sqrt(b+4*d*d)]
    eq('DIRAC',f'exact-vector eigenpair sum n={n}',sum(ev),tr)
    eq('DIRAC',f'exact-vector eigenpair product n={n}',ev[0]*ev[1],deter)
    eq('DIRAC',f'harmonic scalar multiplicity n={n}',s.binomial(n+3,3)-s.binomial(n+1,3),(n+1)**2)
    eq('DIRAC',f'coexact spin size n={n}', (n+2)*n,n*(n+2))
    # Minimal positive coexact = n+1; exact roots nonzero when |d|<=1/2
    check('DIRAC',f'nonzero roots remain nonzero n={n}', b>0 and n+1>=2)
check('DIRAC','midpoint first nonzero shell is sqrt3',s.sqrt(3)<2)
for v in [s.Rational(-1,2),0,s.Rational(1,2)]:
    eq('DIRAC',f'protected branch at delta={v}', -3*v, s.Rational(3,2)-3*(v+s.Rational(1,2)))

# 2. Feshbach oddness, cubic cancellation, Neumann and scalar-weight.
# Toy exact odd Fredholm matrix with 1-dimensional positive zero kernel.
U=s.diag(1,1,-1)
B=s.Matrix([[0,0,0],[0,0,2],[0,2,0]])
M=s.Matrix([[3,1,0],[1,-1,0],[0,0,2]])
check('FESHBACH','odd unperturbed operator',U*B*U==-B)
check('FESHBACH','even perturbation',U*M*U==M)
P=s.diag(1,0,0); Q=s.eye(3)-P
G=s.Matrix([[0,0,0],[0,0,s.Rational(1,2)],[0,s.Rational(1,2),0]])
check('FESHBACH','reduced inverse', B*G==Q and G*B==Q)
check('FESHBACH','second order cancellation', P*M*G*M*P==s.zeros(3))
eta,z=s.symbols('eta z')
D=B+eta*M
check('FESHBACH','full graded operator symmetry',U*D*U==-(B-eta*M))
for v in [s.Rational(1,20),s.Rational(1,10),s.Rational(1,5)]:
    sch=D[0,0]-z-(s.Matrix([[D[0,1],D[0,2]]])*(D[1:3,1:3]-z*s.eye(2)).inv()*s.Matrix([D[1,0],D[2,0]]))[0]
    eq('FESHBACH',f'Schur oddness v={v}',sch+sch.subs({eta:-eta,z:-z}),0)
    check('FESHBACH',f'nontrivial retained/complement coupling at eta={v}',v*M[0,1]!=0)
    normM=1+s.sqrt(5) # top 2x2  [3,1;1,-1] has eigens 1+-sqrt5; plus 2
    vm=v*normM
    # the exact Schur remainder must lie inside the stated v³/(g(g-2v)) envelope
    residual=s.Abs(s.simplify(sch.subs({eta:v,z:0})-v*M[0,0]))
    bound=2*vm**3/(2*(2-2*vm))
    check('FESHBACH',f'cubic Feshbach remainder bound eta={v}',bool(s.N(residual-bound)<0),{'remainder':residual,'bound':bound})
for Uval in [0,s.Rational(1,4),s.Rational(1,2),s.Rational(3,4),1]:
    F=(12-Uval*Uval)/(12+8*Uval*Uval)
    check('FESHBACH',f'scalar weight bound U={Uval}',F>=s.Rational(11,20),F)
    k=(1-4*F)/2
    check('FESHBACH',f'native-slope k< -3/5 U={Uval}',k<=-s.Rational(3,5),k)

# 3. Explicit reciprocal zero mode via power series ODE.
a,y=s.symbols('a y')
F=sum(a**(2*m)*y**m/s.factorial(2*m+1) for m in range(10))
res=s.expand(4*y*s.diff(F,y,2)+6*s.diff(F,y)-a*a*F)
check('ZERO','sinh series recurrence through order8',s.simplify(res.subs(y,0))==0)
for m in range(9):
    eq('ZERO',f'ODE coefficient y^{m}',s.expand(res).coeff(y,m),0)
check('ZERO','sinh limit a->0',s.simplify(F.subs(a,0))==1)

# 4. Exact nonconstant Cartan sphere moments and cubic coefficients.
qmom=lambda k:s.rf(s.Rational(1,2),k)/s.rf(2,k)
hmom=lambda k: s.factor(sum(s.binomial(k,j)*(-s.Rational(1,4))**(k-j)*qmom(j) for j in range(k+1)))
for k,expected in [(1,0),(2,s.Rational(1,16)),(3,s.Rational(1,64)),(4,s.Rational(3,256))]:
    eq('CARTAN',f'h moment {k}',hmom(k),expected)
e=s.symbols('e',real=True)
energy=s.factor(s.Rational(1,6)*e*e*8*hmom(2)+s.Rational(1,4)*(1-2*e*e*hmom(2)+e**4*hmom(4)))
cs=s.Rational(1,2)-e**3*hmom(3)/4
# gradient of degree 2 eigenfunction: <|grad h|²>=8<h²>=1/2 on unit sphere
eq('CARTAN','nonconstant YM quartic',energy,s.Rational(1,4)+s.Rational(5,96)*e**2+s.Rational(3,1024)*e**4)
eq('CARTAN','nonconstant CS cubic',cs,s.Rational(1,2)-e**3/256)
eq('CARTAN','Dirac signed cubic normalized source',s.Rational(9,8)*(s.Rational(1,1024)),s.Rational(9,8192))
for t in [s.Rational(-1,2),s.Rational(-1,4),0,s.Rational(1,4),s.Rational(1,2)]:
    lam=-3*t # R*lambda
    ncs=3*(s.Rational(1,2)+t)**2-2*(s.Rational(1,2)+t)**3
    ey=4*(s.Rational(1,2)+t)**2*(s.Rational(1,2)-t)**2
    eq('CARTAN',f'CS(lambda) delta={t}',ncs,s.Rational(1,2)-lam/2+2*lam**3/27)
    eq('CARTAN',f'YM(lambda) delta={t}',ey,s.Rational(1,4)*(1-4*lam**2/9)**2)

# 5. Half-integer orbital Morse spectral enumeration.
from collections import Counter
for j2 in range(0,13):
    j=s.Rational(j2,2)
    # allowed J from (S=1)⊗(T=1): 0,1,2 then ⊗j
    choices=Counter()
    for c in (0,1,2):
        J2_min=int(2*abs(j-c)); J2_max=int(2*(j+c))
        for J2 in range(J2_min,J2_max+1,2): choices[J2]+=1
    for J2,mult in choices.items():
        J=s.Rational(J2,2)
        val=2*J*(J+1)+2*j*(j+1)-2
        check('MORSE',f'YM Hessian j={j} J={J}',val>=0 if j2>0 else val in (-2,2,10),val)
        if j2>0: check('MORSE',f'no additional negative j={j} J={J}',val>=1 if j2==1 else val>=2,val)
    if j2==0:
        eq('MORSE','single homogeneous negative mode',2*0*(0+1)+2*0*(0+1)-2,-2)
    if j2==1:
        eq('MORSE','first low positive j=1/2',2*s.Rational(1,2)*s.Rational(3,2)+2*s.Rational(1,2)*s.Rational(3,2)-2,1)

# 6. All-shell pair reps from exact SU2 Clebsch rules and symmetric-square parity.
targets=((0,0),(1,0),(0,1),(1,1),(2,0),(0,2)) # twice-spins

def su2_range(ja2,jb2): return range(abs(ja2-jb2),ja2+jb2+1,2)
def sym_same(rep,tar):
    a,b=rep; x,y=tar
    if x not in su2_range(a,a) or y not in su2_range(b,b): return 0
    # each square self swap sign (-1)^(2j - J) for each SU2 factor
    return int( (-1)**(a-x//2+b-y//2)==1 )
def prod(rep1,rep2,tar):
    return int(tar[0] in su2_range(rep1[0],rep2[0]) and tar[1] in su2_range(rep1[1],rep2[1]))
for K in range(1,13):
    reps=[]
    for k in range(1,K+1):
        reps.extend([(k+1,k-1),(k-1,k+1)])
    counts=[]
    for tar in targets:
        c=0
        for i,ra in enumerate(reps):
            c+=sym_same(ra,tar)
            for rb in reps[i+1:]: c+=prod(ra,rb,tar)
        counts.append(c)
    expected=[2*K,0,0,2*(K-1),0,0]
    check('SHELL',f'symmetric pair multiplicity K={K}',counts==expected,counts)
check('SHELL','lowest shell Sym2 dim 21',2+5+5+9==6*7//2)
# Spinor tensor mixed target S=(1/2,0)+(0,1/2): 2 scalars + (1,0)+(0,1)+2 vectors
check('SHELL','spinor mixed dimension 16',2+3+3+2*4==16)

# 7. Exact regular/singular Schur and pseudoinverse controls.
A=s.Matrix([[7,2],[2,6]]); B=s.Matrix([[1,2],[0,1]])
C=s.Matrix([[5,1],[1,4]])
H=A.row_join(B).col_join(B.T.row_join(C))
S=A-B*C.inv()*B.T
for x in [s.Matrix([1,0]),s.Matrix([0,1]),s.Matrix([2,-1])]:
    y=-C.inv()*B.T*x
    eq('SCHUR',f'Schur quadratic x={list(x)}',(x.col_join(y)).dot(H*(x.col_join(y))),x.dot(S*x))
check('SCHUR','block determinant identity', H.det()==C.det()*S.det())
# singular pivot C=diag(3,0), coupling to range only
Cs=s.diag(3,0); Bs=s.Matrix([[2,0],[1,0]])
As=s.diag(6,7); Hs=As.row_join(Bs).col_join(Bs.T.row_join(Cs))
Cp=s.diag(s.Rational(1,3),0)
Ss=As-Bs*Cp*Bs.T
check('SCHUR','positive singular pivot is PSD',Cs[0,0]>0 and Ss[0,0]>0 and Ss.det()>0)
check('SCHUR','singular pivot kernel',Hs.nullspace()==[s.Matrix([0,0,0,1])])
check('SCHUR','singular positive determinant',Hs[:3,:3].det()==Ss.det()*3)
# generic singular pivot requiring a null multiplier
Bc=s.Matrix([[1,1],[1,2]]); Ac=s.eye(2)
Sc=Ac-Bc*Cp*Bc.T
for x in [s.Matrix([1,2]),s.Matrix([-1,3])]:
    n=s.Matrix([0,5]); y=Cp*(-Bc.T*x)+n
    Hc=Ac.row_join(Bc).col_join(Bc.T.row_join(Cs))
    lhs=Hc*(x.col_join(y))
    system=Sc*x+Bc*n
    check('SCHUR',f'singular multiplier first-row x={list(x)}',lhs[:2,0]==system)
    check('SCHUR',f'singular multiplier constraint x={list(x)}',(s.eye(2)-Cs*Cp)*Bc.T*x==lhs[2:,0]-(s.eye(2)-Cs*Cp)*Bc.T*x+ (s.eye(2)-Cs*Cp)*Bc.T*x if False else (s.eye(2)-Cs*Cp)*(Bc.T*x+Cs*y)==(s.eye(2)-Cs*Cp)*lhs[2:,0])
# constant-rank pseudoinverse derivative C(t)=rotation diag(4,0) rotation^-1 at t=0
t=s.symbols('t',real=True); Rot=s.Matrix([[s.cos(t),-s.sin(t)],[s.sin(t),s.cos(t)]])
Ct=Rot*s.diag(4,0)*Rot.T
Cpt=Rot*s.diag(s.Rational(1,4),0)*Rot.T
P0t=Rot*s.diag(0,1)*Rot.T
C0=Ct.subs(t,0); C0p=Cpt.subs(t,0); P00=P0t.subs(t,0); Cdot=s.diff(Ct,t).subs(t,0)
Cp_formula=-C0p*Cdot*C0p+(C0p**2)*Cdot*P00+P00*Cdot*(C0p**2)
P0_formula=-C0p*Cdot*P00-P00*Cdot*C0p
check('SCHUR','constant rank d(C+) exact',s.simplify(s.diff(Cpt,t).subs(t,0)-Cp_formula)==s.zeros(2))
check('SCHUR','constant rank d(P0) exact',s.simplify(s.diff(P0t,t).subs(t,0)-P0_formula)==s.zeros(2))
# common positive parent with 1D support
Dp=s.diag(3,4); BP=s.Matrix([1,2]); Z=s.Matrix([[5]])
Sp=BP*BP.T; Mp=BP*Z.inv()*BP.T
Ip=(Dp-Mp).inv(); Gp=Dp*Dp+Sp
Parent=Dp.row_join(BP).col_join(BP.T.row_join(Z))
check('SCHUR','reconstruction parent positive',all(e>0 for e in Parent.eigenvals()))
check('SCHUR','reconstructed inverse compression',Parent.inv()[:2,:2]==Ip)
check('SCHUR','reconstructed direct compression',Parent[:2,:2]==Dp)
check('SCHUR','reconstructed square compression',(Parent*Parent)[:2,:2]==Gp)
check('SCHUR','minimal parent rank 1',Sp.rank()==Mp.rank()==1 and Sp.nullspace()==Mp.nullspace())
check('SCHUR','parent determinant formula',Parent.det()==Sp.trace()/Mp.trace()/Ip.det())

# 8. Topology/quotient and Spin^c branch.
for weights in [s.Matrix([[0,0],[0,0]]),s.Matrix([[1,0],[0,1]]),s.Matrix([[2,0],[0,0]]),s.Matrix([[2,1],[3,2]]),s.Matrix([[1,2],[2,4]])]:
    diag=smith_normal_form(weights,domain=ZZ)
    check('TOPOLOGY',f'Smith rank {weights.tolist()}',diag.rank()==weights.rank(),diag)
    if abs(weights.det())==1: check('TOPOLOGY',f'unimodular rank2 {weights.tolist()}',diag.det() in (-1,1))
# Spinc4 block / exterior square dimensions, 2×2 SU2 example
Q=s.Matrix([[0,1],[-1,0]]); Zs=-s.eye(2)
check('TOPOLOGY','Spinc4 center kernel order 2',Zs.det()==1 and (-Zs)==s.eye(2))
check('TOPOLOGY','vector 6 branches 4+1+1',4+1+1==6)
# Fibre Heegaard: cos²ρ-sin²ρ=cos2ρ
rho=s.symbols('rho', real=True)
eq('TOPOLOGY','Hopf-Heegaard latitude',s.cos(rho)**2-s.sin(rho)**2,s.cos(2*rho))

# 9. Full finite 72-point Hopf design: exact moments for degree <= 5.
rt3=s.sqrt(3)
uplus=(1+1/rt3)/2; uminus=(1-1/rt3)/2
angles=[(s.cos(s.pi*j/3),s.sin(s.pi*j/3)) for j in range(6)]
def angular(p,q): return s.simplify(sum(xx**p*yy**q for xx,yy in angles)/6)
def sphere_moment(powers):
    if any(p%2 for p in powers): return s.Integer(0)
    kk=[p//2 for p in powers]
    return s.simplify(s.prod(s.rf(s.Rational(1,2),k) for k in kk)/s.rf(2,sum(kk)))
for degree in range(6):
    for p in itertools.product(range(degree+1), repeat=3):
        p4=degree-sum(p)
        if p4<0: continue
        pw=(*p,p4)
        am=angular(pw[0],pw[1])*angular(pw[2],pw[3])
        if am==0: actual=s.Integer(0)
        else:
            ix=sum(pw[:2]); iy=sum(pw[2:])
            assert ix%2==0 and iy%2==0
            actual=s.simplify(am*(uplus**(ix//2)*(1-uplus)**(iy//2)+uminus**(ix//2)*(1-uminus)**(iy//2))/2)
        eq('DESIGN72',f'degree{degree} powers{pw}',actual,sphere_moment(pw))
# No same-sheet perpendicular pair: cos angle differences in {±1,±1/2}; irrational u±
cos_set=[s.Integer(1),s.Rational(1,2),-s.Rational(1,2),s.Integer(-1)]
for ua in [uplus,uminus]:
    for a0 in cos_set:
        for b0 in cos_set:
            check('DESIGN72',f'same layer nonperpendicular u={ua} a={a0} b={b0}',s.simplify(ua*a0+(1-ua)*b0)!=0)
check('DESIGN72','72 = 2×6×6 distinct nodes',2*6*6==72)

# 10. Exceptional 3-torsion Q8⋊C3 matrices.
mod=lambda A:A.applyfunc(lambda x:int(x)%3)
A0=s.Matrix([[1,1],[1,2]]);A1=s.Matrix([[2,1],[1,1]]);UX=s.Matrix([[1,1],[0,1]])
A2=mod(A0*A1); negI=mod(-s.eye(2))
check('TORSION','A0²=-I',mod(A0*A0)==negI)
check('TORSION','A1²=-I',mod(A1*A1)==negI)
check('TORSION','anticommute',mod(A0*A1+A1*A0)==s.zeros(2))
check('TORSION','U³=I',mod(UX**3)==s.eye(2))
UXinv=mod(UX**2)
check('TORSION','U cycles A0 to A1',mod(UX*A0*UXinv)==A1)
check('TORSION','U cycles A1 to A2',mod(UX*A1*UXinv)==A2)
check('TORSION','U cycles A2 to A0',mod(UX*A2*UXinv)==A0)
q8={tuple(mod(P).reshape(4,1)) for P in [s.eye(2),-s.eye(2),A0,-A0,A1,-A1,A2,-A2]}
check('TORSION','exact eight Q8 elements',len(q8)==8)
group={tuple(mod(P*UX**k).reshape(4,1)) for k in range(3) for P in [s.eye(2),-s.eye(2),A0,-A0,A1,-A1,A2,-A2]}
check('TORSION','exact 24 SL2(3) group elements',len(group)==24)

# 11. Triality SU2 branching, spectator ε extraction factor.
eps=s.Matrix([[0,1],[-1,0]])
check('TRIALITY','spectator epsilon HS²=2',sum(x*x for x in eps)==2)
check('TRIALITY','epsilon extraction coefficient unity',s.Rational(1,2)*sum(x*x for x in eps)==1)
check('TRIALITY','unscaled contraction yields factor 2',sum(x*x for x in eps)==2)
check('TRIALITY','vector+spinor branch 4+4',4+4==8)
# A-space: (2,2)⊗(2,1)->(1,2) has one SU2 invariant
check('TRIALITY','A-space intertwiner multiplicity one', 0 in su2_range(1,1) and 1 in su2_range(1,0))
check('TRIALITY','rank vector 4 wedge2 rank6',s.binomial(4,2)==6)

# 12. Rooted q5 projections, isometry, cyclic and odd operators.
X=s.Matrix([[0,0,1],[1,0,0],[0,1,0]]) # 3-cycle
I3=s.eye(3); J6=s.zeros(6)
for i in range(6): J6[i,(i+3)%6]=1
R6=s.zeros(6)
for i in range(6): R6[i,(i+1)%6]=1
P1=sum([R6**k for k in range(6)],s.zeros(6))/6
P3=(s.eye(6)-J6)/2; P2=(s.eye(6)+J6)/2-P1
for i,P in enumerate([P1,P2,P3],1):
    check('Q5',f'projector P{i} idempotent',P*P==P)
    check('Q5',f'projector P{i} symmetric',P.T==P)
check('Q5','rank tuple P1 P2 P3',[P1.rank(),P2.rank(),P3.rank()]==[1,2,3],[P1.rank(),P2.rank(),P3.rank()])
check('Q5','J kills negative owner',J6*P3==-P3)
check('Q5','q5 positive projectors',J6*P1==P1 and J6*P2==P2)
check('Q5','projector sum 6',P1+P2+P3==s.eye(6))
u=s.Matrix([1,1,1])/s.sqrt(3)
yvec=s.Matrix([[-1,1,1],[1,-1,1],[1,1,-1]])/2
check('Q5','Y matrix equals 1-2I ? ',yvec==s.ones(3,3)/2-s.eye(3))
Z0=s.eye(3)-u*u.T
check('Q5','Psi=-identity on augmentation',s.simplify(yvec*Z0+Z0)==s.zeros(3))
check('Q5','Psi isometry restriction',s.simplify(Z0*yvec.T*yvec*Z0-Z0)==s.zeros(3))
check('Q5','Psi C3 intertwines',X*yvec==yvec*X)
Ju=(X-X.T)/s.sqrt(3)
check('Q5','J²=-1 on augmentation',s.simplify(Ju*Ju+Z0)==s.zeros(3))
C1=X+X.T; C2=-s.I*(X-X.T)
check('Q5','reconstruct X from ports',s.simplify((C1+s.I*C2)/2-X)==s.zeros(3))
check('Q5','reconstruct X^-1 from ports',s.simplify((C1-s.I*C2)/2-X.T)==s.zeros(3))
check('Q5','C2 Hermitian',C2.conjugate().T==C2)
Dp=s.zeros(6); Dm=s.zeros(6); Gm=s.diag(1,1,1,-1,-1,-1)
Dp[:3,3:]=X;Dp[3:,:3]=X.T
Dm[:3,3:]=X.T;Dm[3:,:3]=X
check('Q5','D+ square identity',Dp**2==s.eye(6))
check('Q5','D- square identity',Dm**2==s.eye(6))
check('Q5','D+ odd grading',Gm*Dp==-Dp*Gm)
check('Q5','D- odd grading',Gm*Dm==-Dm*Gm)
check('Q5','Coxeter product',Dm*Dp==s.diag(X,X.T))
check('Q5','Coxeter order3',(Dm*Dp)**3==s.eye(6))
# covering C6 link to B2 edge types: every a_k has exactly one plus/minus edge
edges={(k, (k+1)%3, '+') for k in range(3)}|{(k,(k-1)%3,'-') for k in range(3)}
check('Q5','cover has six distinct edges',len(edges)==6)
for k in range(3):
    check('Q5',f'a{k} plus/minus local bijection',{e[2] for e in edges if e[0]==k}=={'+','-'})
    check('Q5',f'b{k} plus/minus local bijection',{e[2] for e in edges if e[1]==k}=={'+','-'})
check('Q5','deck shift preserves edge labels',all(((a+1)%3,(b+1)%3,t) in edges for a,b,t in edges))
# unique normalized trace retraction including amplification
A=s.Matrix([[1,2],[3,4]])
for m in range(1,9):
    AA=s.kronecker_product(A,s.eye(m))
    eq('Q5',f'amplified normalized trace rank m={m}',s.trace(AA)/AA.rows,s.trace(A)/2)
    eq('Q5',f'amplified raw trace rank m={m}',s.trace(AA),m*s.trace(A))

report={
 'artifact':'Paper1B-IndependentControlsBatch6Results-v1_1.json',
 'source':SRC,'source_sha256':tex_sha,
 'archive':ARCH.name,'archive_sha256':hashlib.sha256(ARCH.read_bytes()).hexdigest(),
 'scope':'Exact finite and symbolic controls for Paper I-B census #245 through #293; does not independently re-prove global spectral/analytic/group-classification theorems',
 'claims_census_zero_based':[245,293],
 'total_controls':len(records),'passed':sum(r['passed'] for r in records),'failed':sum(not r['passed'] for r in records),
 'families':dict(collections.Counter(r['family'] for r in records)),
 'individual_controls':records,
 'agent_note':'Single model wrote and executed all checks; mathematical independence only by computational method, not human peer review.'
}
OUT.write_text(json.dumps(report,indent=2,ensure_ascii=False))
print(json.dumps({k:v for k,v in report.items() if k not in ('individual_controls',)},indent=2))
if report['failed']>0: raise SystemExit(f'{report["failed"]} test failures; do not promote')
