#!/usr/bin/env python3
"""Paper I-B Batch 7 scoped independent controls (claims 294--352).
Uses exact SymPy arithmetic when suitable; otherwise deterministic finite
matrix tests with declared numerical tolerances.  Not a global proof.
"""
import json, math, cmath, itertools, random
from collections import Counter
from pathlib import Path
import numpy as np
import scipy.linalg as la
from scipy.integrate import quad
import sympy as sp

RESULTS=[]
RNG=np.random.default_rng(220713)

def chk(group, name, got, want=True, atol=1e-9, label=None, detail=''):
    try:
        if want is True and isinstance(got, (bool,np.bool_)):ok=bool(got); err=0 if ok else 1
        elif isinstance(got, sp.MatrixBase) or isinstance(want, sp.MatrixBase):
            err=sp.simplify(got-want); ok=all(sp.simplify(x)==0 for x in err)
        elif isinstance(got, sp.Basic) or isinstance(want, sp.Basic):
            err=sp.simplify(got-want); ok=err==0
        else:
            a=np.asarray(got);b=np.asarray(want)
            err=float(np.max(np.abs(a-b))) if a.size else 0.0
            ok=bool(err<=atol)
        RESULTS.append({'family':group,'check':name,'passed':ok,'max_error':str(err) if isinstance(err,(sp.Basic,sp.MatrixBase)) else float(err),'tolerance':atol,'source_label':label,'detail':detail})
        if not ok:raise AssertionError(f'{group}: {name}: {err!r}')
    except Exception as exc:
        print('FAILED',group,name,type(exc).__name__,exc)
        raise

def rank(x,eps=1e-9):return np.linalg.matrix_rank(np.asarray(x,dtype=complex),tol=eps)

def E(M):return np.asarray(M,dtype=complex)

def projectors():
    Q0=np.ones((3,3))/3
    return Q0,np.eye(3)-Q0

# 1. protected coordinate-zero face: conditional algebra only, no physical selection.
for r1,r2 in [(0,0),(1,0),(0,3),(1,2)]:
    x=np.array([0.,0.,0.,0.]) # unnormalized protected quadruple at rho=0
    chk('ZERO','rho=0 protected quadruple r1=%s r2=%s'%(r1,r2),np.linalg.norm(x),0.,label='p1b:cor:v132-protected-chiral-zero-face')

# 2. canonical six-channel antiprism, quadratures and polar realization.
i=sp.I
C=sp.ones(3)-sp.eye(3)
RG=sp.diag(1,-i,i)
QA=sp.simplify(C*RG+RG.conjugate().T*C)
F=i*QA
FAplus=-C*RG+RG.conjugate().T*C
chk('ANTIPRISM','Q_A Hermitian',QA==QA.conjugate().T,label='p1b:thm:v133-antiprism-odd-primitive')
chk('ANTIPRISM','Q_A printed matrix',QA==sp.Matrix([[0,1-i,1+i],[1+i,0,2*i],[1-i,-2*i,0]]))
l=sp.symbols('l')
chk('ANTIPRISM','Q_A characteristic',QA.charpoly(l).as_expr(),(l+2)*(l**2-2*l-4))
chk('ANTIPRISM','F determinant absolute',sp.simplify(F.det()*sp.conjugate(F.det())),64)
chk('ANTIPRISM','competing squared singular char',(FAplus.conjugate().T*FAplus).charpoly(l).as_expr(),l*(l-4)**2)
chk('ANTIPRISM','competing quadrature rank',FAplus.rank(),2)
A6=sp.BlockMatrix([[sp.zeros(3),C],[C,sp.zeros(3)]]).as_explicit()
P=sp.diag(*list(RG.diagonal()),*list(-RG.diagonal()))
DA=sp.simplify(-i*(A6*P-P.conjugate().T*A6))
G6=sp.diag(1,1,1,-1,-1,-1)
chk('ANTIPRISM','odd with gamma',DA*G6+G6*DA,sp.zeros(6))
chk('ANTIPRISM','Hermitian DA',DA,DA.conjugate().T)
chk('ANTIPRISM','chiral block F',DA[:3,3:],F)
# Numerical canonical polar factor & 2x2 Schur realization.
Fn=E(F); absF=la.sqrtm(Fn.conj().T@Fn); Un=Fn@la.inv(absF);root=la.sqrtm(absF)
chk('ANTIPRISM','polar block U absF',Un@absF,Fn)
chk('ANTIPRISM','polar U unitary',Un.conj().T@Un,np.eye(3))
chk('ANTIPRISM','paired-Feshbach chiral',root@Un@root.conj().T,Fn)
chk('ANTIPRISM','paired-Feshbach full block',np.block([[np.zeros((3,3)),root@Un@root.conj().T],[root@Un.conj().T@root.conj().T,np.zeros((3,3))]]),E(DA))

# 3. associated owner transfers and partial-isometry support.
for n in (1,2,3,4,6):
    I=np.eye(n);inv=np.eye(n*n);v=I.reshape(-1,order='F');om=np.ones(n)/np.sqrt(n);s=v/np.sqrt(n)
    ins=v.reshape(-1,1); eps=ins.conj().T/n
    chk('OWNER',f'owner {n} retraction',eps@ins,np.ones((1,1)))
    chk('OWNER',f'owner {n} inclusion singular',np.linalg.norm(ins),np.sqrt(n))
    chk('OWNER',f'owner {n} epsilon singular',np.linalg.norm(eps),1/np.sqrt(n))
    Lam=np.outer(s,om.conj());N=np.ones((n,1))
    chk('OWNER',f'owner {n} lift N',Lam@N,ins)
    chk('OWNER',f'owner {n} lift pseudo inverse',eps@Lam,np.ones((1,n))/n)
    chk('OWNER',f'owner {n} reverse pseudo inverse',(np.ones((1,n))/n)@Lam.conj().T,eps)
    chk('OWNER',f'owner {n} active source projector',Lam.conj().T@Lam,np.outer(om,om.conj()))
    chk('OWNER',f'owner {n} active target projector',Lam@Lam.conj().T,np.outer(s,s.conj()))

# 4. q5 projective trimer and normalized family operator isometry.
root3=sp.sqrt(3)
RAYS=[sp.Matrix([1,0]),sp.Matrix([-sp.Rational(1,2),root3/2]),sp.Matrix([-sp.Rational(1,2),-root3/2])]
Ps=[v*v.T for v in RAYS]
vec=lambda A:sp.Matrix([A[0,0],sp.sqrt(2)*A[0,1],A[1,1]])
Fsym=sp.Matrix.hstack(*[vec(P) for P in Ps]);Gram=sp.simplify(Fsym.T*Fsym)
M=sp.Rational(3,4)*sp.eye(3)+sp.Rational(1,4)*sp.ones(3)
chk('TRIMER','operator trimer Gram',Gram,M)
chk('TRIMER','trimer Gram eigenvalues',sorted([float(e) for e,m in Gram.eigenvals().items() for _ in range(m)]),[.75,.75,1.5])
chk('TRIMER','sum rays scalar',sum(Ps,sp.zeros(2)),sp.Rational(3,2)*sp.eye(2))
chk('TRIMER','projective trimer full rank',Fsym.rank(),3)
chk('TRIMER','trace on augmentation vectors',sp.Matrix([[sp.trace(P) for P in Ps]])*sp.Matrix([1,-1,0]),sp.zeros(1,1))
chk('TRIMER','trace on augmentation vectors 2',sp.Matrix([[sp.trace(P) for P in Ps]])*sp.Matrix([1,1,-2]),sp.zeros(1,1))
U=E(Fsym)@la.inv(la.sqrtm(E(M)))
chk('TRIMER','isometric normalized operator trimer',U.conj().T@U,np.eye(3))
chk('TRIMER','normalized constant to scalar',U@(np.ones(3)/np.sqrt(3)),np.array([1/np.sqrt(2),0,1/np.sqrt(2)]))
# 5. C3 endomorphisms and character idempotents.
X=np.roll(np.eye(3),1,axis=0);X2=X@X
for n in range(3):chk('C3',f'C3 power {n} commutes',X@np.linalg.matrix_power(X,n),np.linalg.matrix_power(X,n)@X)
chk('C3','C3 cube identity',np.linalg.matrix_power(X,3),np.eye(3))
comm=np.kron(np.eye(3),X)-np.kron(X.T,np.eye(3))
chk('C3','dimension circulant intertwiner',9-rank(comm),3)
om3=np.exp(2j*np.pi/3)
pr=[(np.eye(3)+X+X2)/3,(np.eye(3)+om3.conjugate()*X+om3*X2)/3,(np.eye(3)+om3*X+om3.conjugate()*X2)/3]
for idx,p in enumerate(pr):
    chk('C3',f'character projector {idx} idempotent',p@p,p)
    chk('C3',f'character projector {idx} rank',rank(p),1)
for j,k in itertools.combinations(range(3),2):chk('C3',f'orthog {j}-{k}',pr[j]@pr[k],np.zeros((3,3)))
chk('C3','three Fourier idempotents sum',sum(pr),np.eye(3))
# 6. line/plane isometry and hierarchy operator dimensions.
c=np.ones(3)/np.sqrt(3);Q0=np.outer(c,c);Qp=np.eye(3)-Q0
chk('HIERARCHY','1+2 decomposition rank one',rank(Q0),1)
chk('HIERARCHY','1+2 decomposition rank two',rank(Qp),2)
chk('HIERARCHY','corner block dimensions',(rank(Q0)**2,2*rank(Q0)*rank(Qp),rank(Qp)**2),(1,4,4))
v1=np.array([1.,-1.,0.])/np.sqrt(2); v2=np.cross(c,v1); J=np.column_stack((c,v1,v2))
chk('HIERARCHY','J orthogonal',J.T@J,np.eye(3))
chk('HIERARCHY','projector conjugation 1',J@np.diag([1,0,0])@J.T,Q0)
chk('HIERARCHY','projector conjugation 2',J@np.diag([0,1,1])@J.T,Qp)
# 7. S3 regular action on 6 nonaxial cube sign rows and 6-point Gram.
signs=[(-1,1,1),(1,-1,1),(1,1,-1),(1,-1,-1),(-1,1,-1),(-1,-1,1)]
S=set(signs); perms=list(itertools.permutations(range(3)))
def parity(p):return (-1)**sum(p[i]>p[j] for i in range(3) for j in range(i+1,3))
for p in perms:
    images=[tuple(parity(p)*e[p[j]] for j in range(3)) for e in signs]
    chk('S3',f'permutation {p} preserves support',set(images)==S)
    chk('S3',f'permutation {p} acts freely',all(y!=x for y,x in zip(images,signs)) if p!=(0,1,2) else all(y==x for y,x in zip(images,signs)))
h=np.array([[1,*e] for e in signs],dtype=float)/2
G=np.zeros((6,6));u12=sp.chebyshevu(12,sp.symbols('t'));t=sp.symbols('t')
for j in range(6):
 for k in range(6):
    dot=float(h[j]@h[k]); G[j,k]=13*float(u12.subs(t,sp.Rational(int(round(dot*2)),2)))
chk('BOUNDARY','all six Hopf points unit vectors',np.sum(h*h,axis=1),np.ones(6))
chk('BOUNDARY','six-point Gram 156I+13J',G,156*np.eye(6)+13*np.ones((6,6)))
chk('BOUNDARY','Gram eigenvalue list',sorted(np.linalg.eigvalsh(G)),[156]*5+[234])
chk('BOUNDARY','Gram full rank',rank(G),6)
chk('BOUNDARY','U12(1)=13',sp.expand(u12.subs(t,1)),13)
for t0 in [sp.Rational(-1,2),0,sp.Rational(1,2)]:chk('BOUNDARY',f'U12({t0})=1',u12.subs(t,t0),1)
Pc=np.ones((6,6))/6;Pa=np.eye(6)-Pc
Gmi=Pa/156+Pc/234;Gminushalf=Pa/np.sqrt(156)+Pc/np.sqrt(234)
chk('BOUNDARY','Gram inverse',G@Gmi,np.eye(6))
chk('BOUNDARY','Gram inverse square root',Gminushalf@G@Gminushalf,np.eye(6))
# Embed 6x169 E via Cholesky: E E* = G, prove projector identities finite.
EE=np.zeros((6,169));EE[:,:6]=la.sqrtm(G)
B=Gminushalf@EE;Psing=B.conj().T@Pc@B;Paug=B.conj().T@Pa@B;Q=np.eye(169)-Psing-Paug
for name,Pv,r in [('sing',Psing,1),('aug',Paug,5),('kernel',Q,163)]:
    chk('BOUNDARY',f'{name} projector',Pv@Pv,Pv,atol=5e-9)
    chk('BOUNDARY',f'{name} rank',rank(Pv),r)
chk('BOUNDARY','kernel and aug orthogonal',Q@Paug,np.zeros((169,169)))
chk('BOUNDARY','kernel and sing orthogonal',Q@Psing,np.zeros((169,169)))
chk('BOUNDARY','B coisometric',B@B.conj().T,np.eye(6))
# 8. S3 character decomposition, Schur return and harmonic scalar sample.
chk('HARMONIC','S3 char triv mult',(169+3*1+2*1)/6,29)
chk('HARMONIC','S3 char sign mult',(169-3*1+2*1)/6,28)
chk('HARMONIC','S3 char std mult',(2*169-2*1)/6,56)
chk('HARMONIC','S3 kernel type dimension',28+27+54*2,163)
chk('HARMONIC','S3 Hom kernel-augmentation',27+54*2,135)
chk('HARMONIC','round nonsinglet Green Gram',np.array([[168,5],[5,5]])/168,np.array([[1,5/168],[5/168,5/168]]))
chk('HARMONIC','round residual',1-(5/168)**2/(5/168),163/168)
# Gegenbauer integration under 3-sphere probability Haar (exact rationals).
U12=sp.expand(u12)
poly=sp.Poly(U12,t)
def moment(power):return 0 if power%2 else sp.binomial(power,power//2)/(4**(power//2)*(power//2+1))
def haar_expect(P):return sp.simplify(sum(a*moment(k[0]) for k,a in sp.Poly(P,t).terms()))
chk('HARMONIC','radial scalar mean U12',haar_expect(U12),0)
chk('HARMONIC','radial scalar norm U12²',haar_expect(U12**2),1)
chk('HARMONIC','six support evaluations U12(1/2)',U12.subs(t,sp.Rational(1,2)),1)
chk('HARMONIC','rotational scalar singlet projection weight',sp.Rational(6,234),sp.Rational(1,39))
chk('HARMONIC','rotational scalar kernel projection weight',1-sp.Rational(1,39),sp.Rational(38,39))
chk('HARMONIC','radial projector commutator norm²',2*sp.Rational(1,39)*sp.Rational(38,39),sp.Rational(76,1521))

# 9. compatible positive Born triple, concrete symplectic product model.
H4=np.array([[2.0,.4,0,0],[.4,1.7,.3,0],[0,.3,2.4,.2],[0,0,.2,1.8]])
Hi=np.linalg.inv(H4);K=np.diag([1.]*4+[-1.]*4);Om=np.block([[np.zeros((4,4)),np.eye(4)],[-np.eye(4),np.zeros((4,4))]])
eta=K@Om;HH=la.block_diag(H4,Hi)
chk('BORN','eta symmetric',eta,eta.T)
chk('BORN','eta signature',np.linalg.eigvalsh(eta).round(9),np.array([-1.]*4+[1.]*4))
chk('BORN','eta reciprocal compatibility',la.solve(eta,HH),la.solve(HH,eta))
chk('BORN','Omega reciprocal compatibility',la.solve(Om,HH),-la.solve(HH,Om))
chk('BORN','para Hermitian K',K.T@eta@K,-eta)

# 10. finite response full Schur, Nevanlinna positivity, minimal response.
A=np.array([[0.3,0.1],[0.1,-0.2]],dtype=complex)
Cresp=np.diag([4.,6.,6.]);BR=np.array([[.7+.2j,.1,.2],[-.25j,.4,.3]],dtype=complex)
H=np.block([[A,BR],[BR.conj().T,Cresp]]);Id2=np.eye(2)
for z in [0.7+0.4j,-0.2+1.3j,3.0+.02j]:
 M=z*Id2-A+BR@la.inv(Cresp-z*np.eye(3))@BR.conj().T
 R=la.inv(z*np.eye(5)-H)[:2,:2]
 chk('WEYL',f'complete Schur resolvent at {z}',la.inv(M),R,atol=5e-10)
 imM=(M-M.conj().T)/(2j)
 predicted=z.imag*(Id2+BR@la.inv(Cresp-z.conjugate()*np.eye(3))@la.inv(Cresp-z*np.eye(3))@BR.conj().T)
 chk('WEYL',f'Nevanlinna Im identity {z}',imM,predicted,atol=5e-10)
 chk('WEYL',f'Nevanlinna Im positive {z}',bool(np.min(np.linalg.eigvalsh(imM))>0))
# Rank residues and explicit minimal realization
for val in (4,6):
 Pval=np.diag([float(x==val) for x in np.diag(Cresp)])
 Rv=BR@Pval@BR.conj().T
 chk('WEYL',f'visible residue at C={val} positive',np.linalg.eigvalsh(Rv).min()>-1e-11)
 chk('WEYL',f'residue rank {val}',rank(Rv),1 if val==4 else 2)
# response exact memory rational derivatives
for x in (-1.,.2,2.5):
 R=la.inv(Cresp-x*np.eye(3));D=BR@(R@R)@BR.conj().T
 chk('WEYL',f'response nonconstant energy={x}',np.linalg.norm(D)>1e-8)
 chk('WEYL',f'response derivative positive={x}',np.linalg.eigvalsh(D).min()>-1e-11)
# positive complementary gap gives nontrivial simple visible zero
E0=0;Cs=np.diag([3.,5.]);Bs=np.array([[1.2,.8]])
Rs=la.inv(Cs);ss=float((Bs@Rs@Bs.T)[0,0]);As=np.array([[ss]])
Hs=np.block([[As,Bs],[Bs.T,Cs]])
re=np.array([1.,*( -Rs@Bs.T).reshape(-1)])
chk('GAP','full Hermitian zero mode',Hs@re,np.zeros(3))
tt=float((Bs@(Rs@Rs)@Bs.T)[0,0]);w=1/(1+tt)
chk('GAP','lower retained-weight bound',w>=3/(3+ss)-1e-10)
chk('GAP','upper retained-weight bound',w<=5/(5+ss)+1e-10)
chk('GAP','zero-mode retained projector',w,(re[0]/np.linalg.norm(re))**2)

# 11. unitary coordinate transport and source jets (finite-difference E3).
D1=np.diag([1.,2.,3.]); W1=np.array([[0,.8,0],[-.8,0,0],[0,0,0]])
for s in (.1,.4):
 Us=la.expm(s*W1); A0=D1+s*np.array([[0,1,0],[1,0,0],[0,0,0]])
 Ap=np.array([[0,1,0],[1,0,0],[0,0,0]])
 Atil=Us@A0@Us.conj().T
 Qder=W1@Atil-Atil@W1+Us@Ap@Us.conj().T
 chk('TRANSPORT',f'covariant jet at s={s}',Qder-(W1@Atil-Atil@W1),Us@Ap@Us.conj().T)
 chk('TRANSPORT',f'trace invariant at s={s}',np.trace(Atil@Atil),np.trace(A0@A0))

# 12. Born affine pencil and inverse reciprocity, positive flux, metric transport.
J=np.block([[np.zeros((4,4)),np.eye(4)],[np.eye(4),np.zeros((4,4))]])
KK=K;Uc=(J+KK)/np.sqrt(2)
chk('PENCIL','J squared identity',J@J,np.eye(8))
chk('PENCIL','K squared identity',KK@KK,np.eye(8))
chk('PENCIL','JK+KJ',J@KK+KK@J,np.zeros((8,8)))
chk('PENCIL','central involution',Uc@Uc,np.eye(8))
for x in (.2,.5,1,2,10):
 AX=J+x*KK;Gx=np.sqrt(1+x*x);tx=x/(1+Gx)
 chk('PENCIL',f'weighted pencil square x={x}',AX@AX,(1+x*x)*np.eye(8))
 chk('PENCIL',f'reciprocal conjugation x={x}',Uc@AX@Uc,x*(J+KK/x))
 chk('PENCIL',f't reciprocal x={x}',1/(x*(1+np.sqrt(1+1/x**2))), (1-tx)/(1+tx))
 w=2*np.sqrt(3.)*1.3;a=w/(1+Gx);b=Gx*w/(1+Gx)
 chk('FLUX',f'constraint x={x}',a+b,w)
 chk('FLUX',f'flux minimum x={x}',.5*(a*a+b*b/Gx),2*3*1.3**2/(1+Gx))
# positive metric comparisons and Gaussian density
Tref=np.array([[3.,.7],[.7,2.]]);Atrans=np.array([[1.5,.2],[-.3,1.2]]);Ttar=Atrans.T@Tref@Atrans
Ytar=np.array([[1.,2.],[-.4,.1]]);jtar=np.array([[.2,-1.],[-.3,.6]])
Yref=Atrans@Ytar;jref=la.solve(Atrans.T,jtar)
qword=lambda T,Y,j:np.trace(Y.T@T@Y)+2*np.trace(j.T@Y)
chk('METRIC','full source quadratic identity',qword(Tref,Yref,jref),qword(Ttar,Ytar,jtar))
chk('METRIC','stationary value transport',-np.trace(jref.T@la.inv(Tref)@jref),-np.trace(jtar.T@la.inv(Ttar)@jtar))
chk('METRIC','Gaussian relative volume',(np.linalg.det(Tref)**(Ytar.shape[1]/2))*(abs(np.linalg.det(Atrans))**Ytar.shape[1]),np.linalg.det(Ttar)**(Ytar.shape[1]/2))
chk('METRIC','positive metric congruence formula', (lambda P,Q: (lambda C: C@Q@C)(la.inv(la.sqrtm(Q))@la.sqrtm(la.sqrtm(Q)@P@la.sqrtm(Q))@la.inv(la.sqrtm(Q))))(Tref,Ttar), Tref,atol=5e-10)
# noncommuting root perturbation bounds
A0=np.diag([4.,9.,16.]);V=np.array([[.5,.2,.0],[.2,.3,.15],[.0,.15,.4]])
chk('ROOT','V positive',np.min(np.linalg.eigvalsh(V))>0)
S0=la.sqrtm(A0);S1=la.sqrtm(A0+V);nu=la.norm(V,2);g0=2
chk('ROOT','noncommuting perturbation norm',la.norm(S1-S0,2)<=nu/(2*g0)+1e-12)
chk('ROOT','noncommuting inverse cap norm',2*la.norm(la.inv(np.eye(3)+S1)-la.inv(np.eye(3)+S0),2)<=nu/(g0*(1+g0)**2)+1e-12)
chk('ROOT','noncommutation actually tested',la.norm(A0@V-V@A0,2)>0)

# 13. reference Poisson defect on noncommuting data; stationary energy, Sylvester.
K0=la.sqrtm(A0);Kr=la.sqrtm(A0+V);B0=np.array([[.8,.1],[-.2,.4],[.2,.6]])
Srs=la.solve_sylvester(K0,K0,A0+(A0+V))
chk('POISSON','reference Sylvester',K0@Srs+Srs@K0,2*A0+V)
# Stationary value is checked separately against a direct y-integral below.
def energy(Qfunc,Qprime,Ar):
    return .5*quad(lambda y: np.trace(Qprime(y).T@Qprime(y)+Qfunc(y).T@Ar@Qfunc(y)),0,np.inf,epsabs=1e-9)[0]
Qfunc=lambda y:la.expm(-y*K0)@B0
Qprime=lambda y:-K0@Qfunc(y)
chk('POISSON','reference energy Sylvester integral',energy(Qfunc,Qprime,A0+V),.5*np.trace(B0.T@Srs@B0),atol=1e-7)
Qst=lambda y:la.expm(-y*Kr)@B0
Qstp=lambda y:-Kr@Qst(y)
chk('POISSON','stationary true energy integral',energy(Qst,Qstp,A0+V),.5*np.trace(B0.T@Kr@B0),atol=1e-7)
chk('POISSON','source vanishes at identical operators',la.norm((A0-A0)@B0),0.)
# Sylvester derivatives and finite directional check
for q in (.05,.2):
    Aq=A0+q*V;Kq=la.sqrtm(Aq);Dq=la.solve_sylvester(Kq,Kq,V)
    ep=1e-5;fd=(la.sqrtm(Aq+ep*V)-la.sqrtm(Aq-ep*V))/(2*ep)
    chk('POISSON',f'noncommuting root derivative q={q}',Dq,fd,atol=1e-7)

# 14. auxiliary source Schur and marked operator retraction.
T=np.array([[3.,.4,.2],[.4,2.,.5],[.2,.5,4.]])
Alog=sp.Matrix(T).log() if False else None
src=np.array([[1.,0.],[.3,.8],[-.4,.1]])
Xstat=la.solve(T,src)
chk('AUX','trace stationary maximum',2*np.trace(src.T@Xstat)-np.trace(Xstat.T@T@Xstat),np.trace(src.T@la.inv(T)@src))
pp=slice(None,2);qq=slice(2,3)
Cq=T[qq,qq];bq=T[pp,qq];Te=T[pp,pp]-bq@la.inv(Cq)@bq.T
Je=src[pp,:]-bq@la.inv(Cq)@src[qq,:]
val=np.trace(Je.T@la.inv(Te)@Je)+np.trace(src[qq,:].T@la.inv(Cq)@src[qq,:])
chk('AUX','full source Schur retention',val,np.trace(src.T@la.inv(T)@src))
# graded 4x48 retained trace
Sp=np.diag([1,-1,1,-1]);Gw=np.diag([1]*24+[-1]*24)
Rel=np.kron(Sp,Gw);Pplus=(np.eye(192)+Rel)/2;Qmet=np.diag([1.,2.,3.,4.])
chk('TRACE','relative + projector rank',rank(Pplus),96)
chk('TRACE','retained retracted trace',np.trace(Pplus/48),2)
chk('TRACE','retained gravitational scalar trace',np.trace((Pplus@np.kron(Qmet,np.eye(48)))/48),.5*np.trace(Qmet))
chk('TRACE','relative to ordinary pure-metric',np.trace(Pplus@np.kron(Qmet,np.eye(48)))/48/np.trace(np.kron(Qmet,np.eye(48))),1/96)
# 15. cap spectral and Laplace representation including first 3 moments.
def hfun(s):return 2/(1+np.sqrt(1+s))
def rho(t):return 2*np.exp(-t)/np.sqrt(np.pi*t)-2*math.erfc(np.sqrt(t)) if t>0 else np.inf
for s in (0,.1,.5,2,6):
    val,_=quad(lambda z: rho(z)*np.exp(-s*z),0,np.inf,points=None,epsabs=3e-11)
    chk('HEAT',f'positive heat cap Laplace s={s}',val,hfun(s),atol=1e-8)
for m,target in [(0,1.),(1,.25),(2,.25)]:
    chk('HEAT',f'cap moment {m}',quad(lambda t:t**m*rho(t),0,np.inf,epsabs=3e-11)[0],target,atol=1e-8)
for x in (.1,1,2):
    gx=np.sqrt(1+x*x)
    M=lambda z:z-1-x*x/(1+z)
    chk('HEAT',f'cap pole root x={x}',M(gx),0.,atol=2e-15)
    chk('HEAT',f'cap pole residue factor x={x}',(1+x*x/(1+gx)**2)/gx,2/(1+gx))
# 16. relative odd affine completion
for x in (0,.4,1,2,5):
    Da=np.sqrt(2*x)*J+(x-1)*KK
    chk('ODD',f'odd completion square x={x}',Da@Da,(1+x*x)*np.eye(8))

# 17. unitary 3x3 root corner, exact character defect, positive constant return.
for kk in range(6):
    W=la.qr(RNG.normal(size=(3,3))+1j*RNG.normal(size=(3,3)))[0]
    cL=np.ones(3)/np.sqrt(3); cR=np.array([1.,0,0])
    QL=np.eye(3)-np.outer(cL,cL.conj()); QR=np.eye(3)-np.outer(cR,cR.conj())
    F0=QL@W@QR;rho0=np.vdot(cL,W@cR);v=QL@W@cR
    chk('UNITARY',f'root corner FF* {kk}',F0@F0.conj().T,QL-np.outer(v,v.conj()))
    sl=np.sort(la.svdvals(F0))
    chk('UNITARY',f'root corner singular values {kk}',sl,np.array([0,abs(rho0),1]),atol=1e-8)
# rooted family arrow matrices
rootc=np.ones(3,dtype=complex)/np.sqrt(3)
rootQ0=np.outer(rootc,rootc.conj()); rootQ=np.eye(3)-rootQ0
Rdiag=np.diag([1,1j,-1j]);X=np.roll(np.eye(3,dtype=complex),1,axis=0)
ge=np.array([-1-1j,1j,1],dtype=complex)/2
gmu=np.array([2,-1+3j,-1-3j],dtype=complex)/(2*np.sqrt(6))
he=Rdiag.conj().T@ge;htau=np.conj(gmu)
Be=np.outer(ge,he.conj());Bmu=np.outer(gmu,rootc.conj());Btau=np.outer(rootc,htau.conj())
chk('CHARACTER','left rooted arrows unitary basis',np.column_stack((ge,gmu,rootc)).conj().T@np.column_stack((ge,gmu,rootc)),np.eye(3))
chk('CHARACTER','right rooted arrows unitary basis',np.column_stack((he,rootc,htau)).conj().T@np.column_stack((he,rootc,htau)),np.eye(3))
Fgamma=Be+(-1/3)*np.outer(gmu,htau.conj())
chk('CHARACTER','rooted F(-1/3)=QRQ',Fgamma,rootQ@Rdiag@rootQ)
om=np.exp(2j*np.pi/3)
Ep=(np.eye(3)+om.conjugate()*X+om*X@X)/3
Em=(np.eye(3)+om*X+om.conjugate()*X@X)/3
wp=(2-np.sqrt(3))/4;wm=(2+np.sqrt(3))/4
chk('CHARACTER','h_e character weight +',np.vdot(he,Ep@he),wp)
chk('CHARACTER','h_e character weight -',np.vdot(he,Em@he),wm)
chk('CHARACTER','h_tau paired off diagonal',abs(np.vdot(htau,Ep@he))**2,1/16)
chk('CHARACTER','h_tau paired off diagonal sign',np.vdot(htau,(Ep+Em)@he),0.,atol=1e-12)
for a1,a2,d1,d2 in [(1,1,1,1),(.8,1.2,1,2),(1j,1.,-1j,1),(2,1,3,1)]:
    Ce=rootQ0+a1*Ep+a2*Em;Ct=rootQ0+d1*Ep+d2*Em
    ee,mm,tt=1.2,.8,.5
    Tr=ee*Fgamma@Ce+mm*Bmu+tt*Btau@Ct
    defect=la.norm((Tr@Tr.conj().T-ee*ee*np.eye(3))@ge)**2
    n1=abs(a1)**2;n2=abs(a2)**2;q1=d1*np.conjugate(a1);q2=d2*np.conjugate(a2)
    formula=ee**4*(wp*n1+wm*n2-1)**2+ee**4*(1/9)/16*(n1-n2)**2+ee**2*tt**2/16*abs(q1-q2)**2
    chk('CHARACTER',f'finite scalar defect {(a1,a2,d1,d2)}',defect,formula,atol=3e-10)
# independent outer-coefficient identity via actual Kronecker products
qK=2
AA1=np.array([[1,.1],[.1,1.2]]); AA2=np.array([[.8,0],[.05,1.1]])
DD1=np.array([[1.,.2],[.3,1.5]]);DD2=np.array([[.5,0],[.1,1.2]])
Ce=np.kron(np.eye(2),rootQ0)+np.kron(AA1,Ep)+np.kron(AA2,Em)
Ct=np.kron(np.eye(2),rootQ0)+np.kron(DD1,Ep)+np.kron(DD2,Em)
TM=1.3*np.kron(np.eye(2),Fgamma)@Ce+.7*np.kron(np.eye(2),Bmu)+.9*np.kron(np.eye(2),Btau)@Ct
JL=np.kron(np.eye(2),ge.reshape(-1,1));res=JL.conj().T@np.linalg.matrix_power(TM@TM.conj().T-1.3**2*np.eye(6),2)@JL
Np=AA1@AA1.conj().T;Nm=AA2@AA2.conj().T;SS=wp*Np+wm*Nm;delta=Np-Nm
LL=DD1@AA1.conj().T-DD2@AA2.conj().T
rhs=1.3**4*(SS-np.eye(2))@(SS-np.eye(2))+1.3**4*(1/9)/16*delta@delta+1.3**2*.9**2/16*LL.conj().T@LL
chk('CHARACTER','outer noncommuting defect',res,rhs,atol=1e-9)

# 18. compression defect and mode/family current comparison
for j in range(5):
 Z=la.qr(RNG.normal(size=(5,3))+1j*RNG.normal(size=(5,3)))[0];Pz=Z@Z.conj().T
 Af=RNG.normal(size=(5,5))+1j*RNG.normal(size=(5,5)); Bf=RNG.normal(size=(5,5))+1j*RNG.normal(size=(5,5))
 pi=lambda X:Z.conj().T@X@Z
 chk('COMPRESS',f'compression multiplication defect {j}',pi(Af)@pi(Bf)-pi(Af@Bf),-Z.conj().T@Af@(np.eye(5)-Pz)@Bf@Z)
 chk('COMPRESS',f'compression commutator defect {j}',pi(Af)@pi(Bf)-pi(Bf)@pi(Af),pi(Af@Bf-Bf@Af)+Z.conj().T@(Bf@(np.eye(5)-Pz)@Af-Af@(np.eye(5)-Pz)@Bf)@Z)
Qm=np.ones((3,3))/3;Um=np.eye(3)+(1j-1)*Qm
chk('COMPRESS','comparison mode U unitary',Um.conj().T@Um,np.eye(3))
for a in (0,1,2):
 for b in (0,1,2):
    val=np.vdot(Um[:,a],Um[:,b])
    chk('COMPRESS',f'comparison current matrix unit {a},{b}',val,1. if a==b else 0.,atol=1e-12)
chk('COMPRESS','pair symmetric coefficient matrix',Um.conj().T@np.conj(Um),np.eye(3)-2*Qm)
for a in (0,1,2):
 for b in (0,1,2):chk('COMPRESS',f'pair coefficient nonzero {a},{b}',abs((np.eye(3)-2*Qm)[a,b])>1e-8)


# 19. Additional source-specific adversarial checks: constant-return fibre,
#     full resolvent-mode compression and unobserved environment.
Ctwo=-1j*(X-X.conj().T)
Aa=np.sqrt(3.);Bb=1/np.sqrt(3.)
Ce_pos=rootQ0+Aa*rootQ+Bb*Ctwo;Ct_pos=rootQ0+Aa*rootQ-Bb*Ctwo
chk('CHARACTER','positive fibre defining ellipse',Aa**2-3*Aa*Bb+3*Bb**2,1.)
chk('CHARACTER','positive fibre first dressing',np.linalg.eigvalsh(Ce_pos).min()>0)
chk('CHARACTER','positive fibre second dressing',np.linalg.eigvalsh(Ct_pos).min()>0)
iot=[Be@Ce_pos,Bmu,Btau@Ct_pos]
Pleft=[np.outer(ge,ge.conj()),np.outer(gmu,gmu.conj()),rootQ0]
for r in range(3):
 for k in range(3):
    chk('CHARACTER',f'constant-return arrow {r},{k}',iot[r]@iot[k].conj().T,Pleft[r] if r==k else np.zeros((3,3)),atol=5e-10)
# Counterexample to the claim "C3 symmetry forces equal two character amplitudes".
Ce_1=rootQ0+Ep+Em;Ct_12=rootQ0+2*Ep+1*Em
Tbad=1.2*Fgamma@Ce_1+.8*Bmu+.5*Btau@Ct_12
bad=la.norm((Tbad@Tbad.conj().T-1.2**2*np.eye(3))@ge)**2
chk('CHARACTER','C3 equivariant coefficient counterexample exact',bad,1.2**2*.5**2/16)
chk('CHARACTER','C3 example defect strictly positive',bad>0)
# Source independent finite root-avoiding subspace check.
W0=np.eye(3,dtype=complex);W1=np.diag([1j,-1j,1]);rightroot=np.array([1.,0,0]);leftroot=np.array([0.,1,0]);droot=np.array([0.,0,1.])
for Wm in [W0,W1]:
    chk('UNITARY','root-avoiding unit invariant',Wm@droot,Wm[2,2]*droot)
    chk('UNITARY','root-avoiding root annihilation',np.vdot(leftroot,Wm@droot),0.,atol=1e-12)
    chk('UNITARY','root-avoiding right project annihilation',np.vdot(rightroot,droot),0.,atol=1e-12)
# Independent degree-12 conjugation character using Chebyshev SU(2) formula.
for rot,cos_half in [('transposition',sp.Integer(0)),('threecycle',sp.Rational(1,2))]:
    z=sp.chebyshevu(12,cos_half)
    chk('HARMONIC',f'complete H12 S3 {rot} character',z*sp.conjugate(z),1)
# Add visible + dark environment and test response invariance at complex z.
Cdark=np.diag([-3.,9.]);Call=la.block_diag(Cresp,Cdark);Ball=np.hstack([BR,np.zeros((2,2))])
for z in [.5+.3j,2.+1j]:
    Ma=z*Id2-A+Ball@la.inv(Call-z*np.eye(5))@Ball.conj().T
    Mb=z*Id2-A+BR@la.inv(Cresp-z*np.eye(3))@BR.conj().T
    chk('WEYL',f'dark environment invisible at {z}',Ma,Mb)
# An explicit 9->3 comparison isometry for the lossy normal current.
Zm=np.column_stack([np.kron(Um[:,j],np.eye(3)[:,j]) for j in range(3)])
chk('COMPRESS','full chart 9->3 isometric',Zm.conj().T@Zm,np.eye(3))
Ef=np.diag([.1,.8,2.]);Ef[0,1]=.2;Ef[1,0]=.2
for z in [.3+.7j,1.2+.3j]:
    Rpar=np.kron(np.eye(3),la.inv(z*np.eye(3)-Ef))
    Rret=Zm.conj().T@Rpar@Zm
    target=np.diag(np.diag(la.inv(z*np.eye(3)-Ef)))
    chk('COMPRESS',f'complete resolvent diagonal owner at {z}',Rret,target)

# Output full reproducible results and summary. All conditions above pass or script aborts.
out=Path('/mnt/data/Paper1B-IndependentControlsBatch7Results-v1_1.json')
summary={'paper':'Paper I-B','batch':7,'claim_indices_zero_based':[294,352],'manuscript':'Paper1B-M8Geometry-v1_131.tex',
         'method':'Exact symbolic identities, deterministic finite matrices, analytic Schur/Sylvester calculus and scoped quadrature',
         'counts':dict(Counter(r['family'] for r in RESULTS)), 'total':len(RESULTS), 'passed':sum(r['passed'] for r in RESULTS),
         'failed':sum(not r['passed'] for r in RESULTS), 'tolerance_notice':'Numerical controls are scoped examples, not independent global proofs.',
         'results':RESULTS}
out.write_text(json.dumps(summary,indent=2,ensure_ascii=False,default=str))
print('COMPLETED',summary['passed'],'/',summary['total'],'controls; groups:',summary['counts'])
print('OUTPUT',out)
