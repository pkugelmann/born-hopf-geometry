"""Paper I-B Batch 10: scoped independent mathematical controls, not full theorem proofs.
Source: Paper1B-M8Geometry-v1_131.tex, formal census 447..482 (0-based).
No external resources or modifications to source manuscript.
"""
import json, math, hashlib
from fractions import Fraction
import numpy as np
import sympy as sp
from pathlib import Path

out=[]
def ck(group, claim, assertion, predicate, kind='exact'):
    passed=bool(predicate)
    out.append({'group':group,'claim_index':claim,'control':assertion,'kind':kind,'pass':passed})
    if not passed: raise AssertionError(f'{group} #{claim} {assertion}')

def close(a,b,tol=1e-9): return bool(np.allclose(a,b,atol=tol,rtol=tol))
I=np.eye(2,dtype=complex); sx=np.array([[0,1],[1,0]],complex); sy=np.array([[0,-1j],[1j,0]],complex); sz=np.diag([1.,-1.]); cn=1j*sy; gamma=sz; Gamma=sz; Phi=2*sx; Pplus=(I+gamma)/2; Pminus=(I-gamma)/2
U=np.kron(Pplus,I)+np.kron(Pminus,Gamma)
D1=np.kron(sx,I)+np.kron(gamma,Phi)
D2=np.kron(sx,Gamma)+np.kron(I,Phi)
chiA=np.kron(cn@gamma,I);chiB=np.kron(cn@gamma,Gamma)
for name,l,r in [ ('U unitary',U.conj().T@U,np.eye(4)),('U involutive',U@U,np.eye(4)),('D presentation transport',U@D1@U,D2),('conormal symbol transport',U@np.kron(cn,I)@U,np.kron(cn,Gamma)),('chi a-to-b',U@chiA@U,chiB),('chi b-to-a',U@chiB@U,chiA)]: ck('BOUNDARY_TRANSPORT',447,name,close(l,r))
J=np.kron(cn@gamma,Phi)
V=J/2
projM=(np.eye(4)-chiB)/2;projP=(np.eye(4)+chiB)/2
for name,a,b in [('J Hermitian',J.conj().T,J),('J square',J@J,4*np.eye(4)),('J chi-anticommutator',J@chiB+chiB@J,np.zeros((4,4))),('V initial P',projP@V.conj().T@V@projP,projP),('V final M',V@projP@V.conj().T,projM)]:ck('CONORMAL_ISOMETRY',448,name,close(a,b))
# Robin mass blocks: for chiA projected diagonal, for chiB off diagonal
ck('ROBIN_ZERO',449,'chi_b mass block vanishes',close(projP@J@projP,np.zeros((4,4))))
ck('ROBIN_ZERO',449,'chi_a mass equals -Phi',close(((np.eye(4)+chiA)/2)@np.kron(cn@gamma,Phi)@((np.eye(4)+chiA)/2), np.kron((I+cn@gamma)/2,Phi)))
# Quaternionic complex 2x2 matrix realization and exact overlap for numeric controls
def cq(q):return q[0]*I+1j*(q[1]*sx+q[2]*sy+q[3]*sz)
u=np.array([.5,.5,.5,.5]);h=np.array([0.,-1.,0.,0.]);
ck('QUATERNION_SOURCE',450,'overlap -1/2',np.isclose(np.trace(cq(u).conj().T@cq(h)).real/2,-.5))
ck('QUATERNION_SOURCE',450,'complement 3/4',np.isclose(1-(u@h)**2,.75))
rng=np.random.default_rng(120); 
for k in range(12):
 q=rng.normal(size=4);q/=np.linalg.norm(q);v=rng.normal(size=4);v/=np.linalg.norm(v)
 ck('QUATERNION_SOURCE',450,f'Clifford quaternion overlap {k}',close(np.trace(cq(q).conj().T@cq(v))/2,np.dot(q,v)))
# Anticommuting square and gap under common-domain finite model
for a in [0.,.5,2.,5.,10.]:
 for m in [.2,1.,2.,5.]:
  Ds=a*sx-(m/2)*sz
  ck('ROOTED_GAP',451,f'gap m={m} a={a}',close(Ds@Ds,(a*a+m*m/4)*I))
# Singlet-triplet square root via eigensystem and Cayley-Hamilton
for m,g in [(1.,1.),(2.,3.),(.4,8.),(5.,1.),(2.,100.)]:
 A=np.array([[m*m,np.sqrt(3)*g*m/2],[np.sqrt(3)*g*m/2,m*m+g*g]])
 la=m*m+g*g/2-g/2*np.sqrt(g*g+3*m*m)
 lb=m*m+g*g/2+g/2*np.sqrt(g*g+3*m*m)
 ck('ROOTED_RETURN',452,f'eigenvalues {m},{g}',close(np.linalg.eigvalsh(A),[la,lb]))
 sq=(A+np.sqrt(np.linalg.det(A))*I)/np.sqrt(np.trace(A)+2*np.sqrt(np.linalg.det(A)))
 ck('ROOTED_RETURN',452,f'sqrt square {m},{g}',close(sq@sq,A))
 ck('ROOTED_RETURN',452,f'singlet formula {m},{g}',np.isclose(sq[0,0],(m*m+np.sqrt(m**4+g*g*m*m/4))/np.sqrt(g*g+2*m*m+2*np.sqrt(m**4+g*g*m*m/4))))
ck('ROOTED_RETURN',452,'special m=2 g=3 sqrt3',np.isclose(((np.array([[4.,3*np.sqrt(3)],[3*np.sqrt(3),13.]])+np.sqrt(16+9)*I)/np.sqrt(9+8+2*5))[0,0],np.sqrt(3)))
# conormal response test for diagonal Dirac and c normal
for m in [0.5,1,3.]:
 D=m*sz; A=D@D; K=np.sqrt(m*m)*np.tanh(1.2*m)*I; KD=m/np.tanh(1.2*m)*I
 P=(I+sz)/2; S=sz; J0=sx@S@P
 ck('CONORMAL_RESPONSE',453,f'functional inverse {m}',close(J0.conj().T@np.linalg.inv(K)@J0, P@KD@P/(m*m)))
 ck('CONORMAL_RESPONSE',453,f'spectral f A {m}',close(J0.conj().T@A@J0,P@A@A@P/(m*m)))
# Robin impedance from far Robin coefficient; scaling test
for zeta in [0,0.2,1,4]:
 for ell in [.3,1.2,3]:
  k=2;L=ell/k
  kappa=k*(zeta+np.tanh(ell))/(1+zeta*np.tanh(ell))
  # q(0)=1, q'(0)=-kappa: far q'+kzeta q=0
  qL=np.cosh(k*L)-kappa/k*np.sinh(k*L)
  qpL=k*np.sinh(k*L)-kappa*np.cosh(k*L)
  ck('ROBIN_HOMOTHETY',454,f'Robin bc {zeta},{ell}',abs(qpL+k*zeta*qL)<1e-10)
  G=2.4
  k2=G*k;L2=L/G;kappa2=k2*(zeta+np.tanh(ell))/(1+zeta*np.tanh(ell))
  ck('ROBIN_HOMOTHETY',454,f'Robin homothety {zeta},{ell}',np.isclose(kappa2,G*kappa))
# Tangential support criterion: verified strict inequality; fixed spectral diagonal
L0=1.2; mu=1.7;G=2.5; eig=np.array([0.,.5,2.,9.]);f=lambda s:np.sqrt(s)*np.tanh(L0*np.sqrt(s))
lam=f(mu*mu+eig/G**2)*G/f(mu*mu+eig)
ck('TANGENTIAL_SUPPORT',455,'unique equality space at zero eig',np.all(lam[1:]<G) and np.isclose(lam[0],G))
ck('TANGENTIAL_SUPPORT',455,'nonzero tangential increases E',np.all(1/(1+lam[1:])>1/(1+G)))
for m,g,G in [(1.,2.,2.),(2.,3.,1.5),(5.,.3,3.)]:
 aa=lambda m,g:np.array([[m*m,np.sqrt(3)*g*m/2],[np.sqrt(3)*g*m/2,m*m+g*g]])
 ck('COUPLED_SCALING',456,f'full coupled square {m},{g}',close(aa(m*G,g*G),G*G*aa(m,g)))
 ck('COUPLED_SCALING',456,f'wrong g scaling fails {m},{g}',not close(aa(m*G,g),G*G*aa(m,g)))
# affine rotation of source basis and J supports
GammaW=sz;S0=sx;J0=S0; S1=1j*GammaW@S0; J1=S1
for t in [.1,.5,2.]:
 theta=np.arctan(t);UR=np.cos(theta/2)*I+1j*np.sin(theta/2)*GammaW; Psi=S0+t*S1; GG=np.sqrt(1+t*t)
 for name,a,b in [('rotated source',Psi,GG*UR@S0@UR.conj().T),('JJ equal',J0@J0.conj().T,J1@J1.conj().T),('JJ skew',J0@J1.conj().T+J1@J0.conj().T,np.zeros((2,2))),('source defect',Psi-S0,t*J1)]:ck('AFFINE_CONORMAL',457,f'{name} t={t}',close(a,b))
# Heat tails and cap moments
for eig in [[1.5,3.,9.],[.1,1.,4.,10.]]:
 for s in [.01,.2,1.,2.,8.]:
  wt=np.arange(1,len(eig)+1,dtype=float);F=sum(w*np.exp(-(1+s)*l) for w,l in zip(wt,eig))/sum(w*np.exp(-l) for w,l in zip(wt,eig))
  ck('HEAT_CAP',458,f'heat bound {eig[0]} {s}',F<=np.exp(-s*min(eig))+1e-14)
for n in range(9):
 expected=sp.gamma(sp.Rational(2*n+1,2))/(sp.sqrt(sp.pi)*(n+1))
 ck('HEAT_CAP',459,f'exact gamma moment {n}',sp.simplify(expected-sp.factorial2(2*n-1)/(2**n*(n+1)))==0)
mat=sp.Matrix([[1,sp.Rational(1,4),sp.Rational(1,4)],[sp.Rational(1,4),sp.Rational(1,4),sp.Rational(15,32)],[sp.Rational(1,4),sp.Rational(15,32),sp.Rational(21,16)]])
ck('HEAT_CAP',459,'Hankel determinant 71/1024',mat.det()==sp.Rational(71,1024))
# Balanced relative odd heat and insertion no-go
for matA in [np.eye(2), np.array([[1.,2.],[3.,4.]]), np.array([[0.,0.],[0.,3.]])]:
 D=np.block([[np.zeros((2,2)),matA.T],[matA,np.zeros((2,2))]])
 P=np.diag([1.,1.,0.,0.]); Q=np.eye(4)-P; Gr=P-Q
 w,vec=np.linalg.eigh(D@D); heat=vec@np.diag(np.exp(-w))@vec.T
 ck('RELATIVE_ODD_TRACE',460,'supertrace vanishes',abs(np.trace(Gr@heat))<1e-11)
 ck('RELATIVE_ODD_TRACE',460,'marked heat equals half',np.isclose(np.trace(P@heat)/48,np.trace(heat)/96))
 ck('MARKED_PORT_DIFFERENCE',461,'P+ twofold',np.isclose(np.trace(P@heat)/48,2*np.trace(P@heat)/96))
 ck('MARKED_PORT_DIFFERENCE',461,'P- zero marked',np.isclose(np.trace(P@Q@heat),0.))
 ck('MARKED_DIRAC',462,'Hermitian ZD',close((P@D+D@P)/96,D/96))
# Rooted matrix units
R=np.diag([1.,1j,-1j]); c=np.ones(3,dtype=complex)/np.sqrt(3);P=np.outer(c,c.conj());Pi=[np.diag([int(i==k) for i in range(3)]) for k in range(3)]
E={(i,j):3*Pi[i]@P@Pi[j] for i in range(3) for j in range(3)}
for i in range(3):
 for j in range(3):
  ck('ROOTED_MATRIX_UNITS',463,f'unit adjoint {i},{j}',close(E[i,j].conj().T,E[j,i]))
  for k in range(3):
   for l in range(3):
    ck('ROOTED_MATRIX_UNITS',463,f'unit multiplication {i}{j}{k}{l}',close(E[i,j]@E[k,l],E[i,l] if j==k else np.zeros((3,3))))
ck('ROOTED_MATRIX_UNITS',463,'sum diagonal=I',close(sum((E[i,i] for i in range(3)),np.zeros((3,3))),np.eye(3)))
Q=np.eye(3)-P;s2=8/9
Pm=(Q@R@P@R.conj().T@Q)/s2; Pe=Q-Pm
A0=Pe@R@Q+Q@R@P+P@R@Q
A02=A0@A0.conj().T
ck('ROOTED_POLAR',464,'Pmu is rank1 projector',close(Pm@Pm,Pm) and np.isclose(np.trace(Pm).real,1))
ck('ROOTED_POLAR',464,'Pe is rank1 projector',close(Pe@Pe,Pe) and np.isclose(np.trace(Pe).real,1))
ck('ROOTED_POLAR',464,'A0 squared positive factor',close(A02,Pe+s2*(Pm+P)))
root=Pe+np.sqrt(s2)*(Pm+P);V=np.linalg.solve(root,A0)
ck('ROOTED_POLAR',464,'V unitarity',close(V@V.conj().T,np.eye(3)))
ck('ROOTED_POLAR',464,'polar word components',close(V,Pe@R@Q+Q@R@P/np.sqrt(s2)+P@R@Q/np.sqrt(s2)))
for aa,bb,cc in [(1,2,3),(.4,.5,4)]:
 M=(aa*Pe+bb*Pm+cc*P)@V
 ck('ROOTED_POLAR',464,f'weighted projector return {aa}',close(M@M.conj().T,aa*aa*Pe+bb*bb*Pm+cc*cc*P))
# 13-source Gram and response using abstract orthonormal directions e_s e_b, five-vector and derivative triples
Gm=np.eye(13);Gm[0,1]=Gm[1,0]=1/np.sqrt(3)
vals=np.linalg.eigvalsh(Gm)
ck('NEUTRAL_PACKET',466,'rank13',np.all(vals>0))
ck('NEUTRAL_PACKET',466,'Gram eigenvalues',close(vals,np.sort([1-1/np.sqrt(3),1+1/np.sqrt(3)]+[1.]*11)))
ck('NEUTRAL_PACKET',466,'visible counts',1+5+1+3+3==13 and 163-7==156)
invroot=np.linalg.inv(np.linalg.cholesky(Gm))
ck('NEUTRAL_PACKET',467,'round Green after Gram normalization',close(invroot@Gm@invroot.T,np.eye(13)))
# Mixed operator packet, from exact identities P_I T_i P_I=0, derivative Gram 728
ck('DERIVATIVE_PACKET',465,'Casimir 12*14 and 13 norm',12*14*13//3==728)
ck('DERIVATIVE_PACKET',468,'mixed source normalization constant',sp.Rational(13,728)*(-56*56)==-56)
# Convex/density constructive controls for finite degree-2 SU2 rule at Hurwitz support
# Hurwitz units 8 axial plus 16 all half-integer signs
pts=[]
for a in range(4):
 for sg in [1,-1]:
  p=np.zeros(4);p[a]=sg;pts.append(p)
for x in range(16):pts.append(np.array([(.5 if x>>b&1 else -.5) for b in range(4)]))
pts=np.array(pts)
ck('POSITIVE_CUBATURE',469,'24 Hurwitz unit nodes',len(pts)==24 and len({tuple(p) for p in pts})==24)
ck('POSITIVE_CUBATURE',469,'first moments zero',close(pts.mean(axis=0),np.zeros(4)))
ck('POSITIVE_CUBATURE',469,'second moments 1/4 identity',close(pts.T@pts/24,np.eye(4)/4))
# Positive exactification algebra independently checks corrective mass identity in vector-valued moments
for dim in [2,3,6]:
 for k in range(4):
  en=rng.normal(size=dim)*.005;rr=0.75
  norm=np.linalg.norm(en);eps=2*norm/(rr+2*norm); y=-(1-eps)/eps*en
  ck('POSITIVE_EXACTIFICATION',471,f'centered correction {dim}:{k}',close((1-eps)*en+eps*y,np.zeros(dim)))
  ck('POSITIVE_EXACTIFICATION',471,f'correction interior {dim}:{k}',np.linalg.norm(y)<rr)
# Nested evaluation partial isometry for orthonormal embeddings
for m,n,ell in [(2,4,6),(3,5,7),(1,1,4)]:
 # canonical isometry S_k to bigger Euclidean sample via column QR
 def iso(rows,cols):
  A=rng.normal(size=(rows,cols)); return np.linalg.qr(A)[0][:,:cols]
 Sa=iso(m+3,m);Sb=iso(n+3,n);Sc=iso(ell+3,ell)
 Jnm=np.eye(n)[:,:m];Jln=np.eye(ell)[:,:n];Jlm=np.eye(ell)[:,:m]
 Uba=Sb@Jnm@Sa.T;Ucb=Sc@Jln@Sb.T;Uca=Sc@Jlm@Sa.T
 ck('NESTED_ISOMETRIES',472,f'partial initial {m}n{n}',close(Uba.T@Uba,Sa@Sa.T))
 ck('NESTED_ISOMETRIES',472,f'partial final {m}n{n}',close(Uba@Uba.T,Sb@Jnm@Jnm.T@Sb.T))
 ck('NESTED_ISOMETRIES',472,f'composition {m}n{n}l{ell}',close(Ucb@Uba,Uca))
# degree dimension and Parseval bounds
for L,N in [(5,14),(7,30),(11,91),(19,385)]:
 m=L//2;d=(m+1)*(m+2)*(2*m+3)//6
 ck('FINITE_SAMPLER',473,f'node bound L={L}',N==d)
ck('EXCHANGE_MODULE',474,'factor rank products',16*16==256 and 16*25==400 and 25*25==625)
ck('EXCHANGE_MODULE',474,'Petersen wedge Sym counts',15*16//2==120 and 15*14//2==105)
ck('EXCHANGE_MODULE',475,'product 225 and sectors',15*15==225 and 120+105==225)
# For L: eigenvalues 1(3), -1(3), 0(9); contrast L tensor L; signed flip
l=np.array([1]*3+[-1]*3+[0]*9)
C=np.outer(l,l).flatten();
ck('CONTRAST_SPECTRA',476,'full +,-,zero counts',[(C==v).sum() for v in (1,-1,0)]==[18,18,189])
# Sym/antisym operator on pairs (i,j), diag sign li*lj
sym=[];wedge=[]
for i in range(15):
 sym.append(l[i]*l[i]);
 for j in range(i+1,15):
  sym.append(l[i]*l[j]); wedge.append(l[i]*l[j])
for v,arr,exp in [(1,sym,[12,9,99]),(2,wedge,[6,9,90])]:
 ck('CONTRAST_SPECTRA',476,f'contrast spectrum sector {v}',[arr.count(k) for k in (1,-1,0)]==exp)
ck('CONTRAST_SPECTRA',477,'unique 15 active wedge modes',sum(1 for z in wedge if z)!=0 and sum(z!=0 for z in wedge)==15)
ck('CONTRAST_SPECTRA',477,'105 decomposes 15+90',105==15+90)
ck('CONTRAST_SPECTRA',478,'adjoint Casimir 2x6 4x9 0x90',sorted(set((3*z*z-z for z in wedge)))==[0,2,4])
# S5 character table and exterior-square transform
chs=[15,3,-1,0,0,-1,0];g2=[0,0,0,3,3,2,6];signs=[1,-1,1,1,-1,-1,1]
ext=[(c*c-chs[q])//2 for c,q in zip(chs,g2)]
ck('SYMMETRIC_GROUP',478,'S5 signed-edge exterior-square characters',ext==[105,-3,-7,0,0,1,0])
ck('SYMMETRIC_GROUP',478,'3W+4(sign W) decomposition',ext==[(3+4*sg)*c for sg,c in zip(signs,chs)])
# rank-12 finite icosahedral representation using A5 irreps character orthogonality
cls=np.array([1,15,20,12,12]); spin2=np.array([5,1,-1,0,0]);
ck('ICOSAHEDRAL_ALIAS',480,'finite quadratic spin2 character',np.dot(cls,spin2**2)==60)
ck('ICOSAHEDRAL_ALIAS',480,'finite cubic spin2 character 2',np.dot(cls,spin2**3)==120)

# SU(2) Haar class-moment functional: E[x^(2n)]=Catalan(n)/4^n, x=Re(q) on S^3
x=sp.symbols('x',real=True); ch=16*x**4-12*x*x+1
def haar_polynomial(poly):
 p=sp.Poly(sp.expand(poly),x)
 return sp.simplify(sum(coef* (sp.catalan(exp[0]//2)/4**(exp[0]//2) if exp[0]%2==0 else 0) for exp,coef in p.terms()))
ck('ICOSAHEDRAL_ALIAS',480,'Haar spin2 square exactly 1',haar_polynomial(ch**2)==1)
ck('ICOSAHEDRAL_ALIAS',480,'Haar spin2 cube exactly 1',haar_polynomial(ch**3)==1)
ck('ICOSAHEDRAL_ALIAS',480,'degree12 spin6 norm 13',13==12+1)
ck('TWISTED_CUBATURE',481,'quartic product degree <=19',4*4<=19)
ck('TWISTED_CUBATURE',481,'derivative product bound <=19',2*3+4*2<=19)
# Independent realization on the actual 120-element binary-icosahedral group, not only abstract Gram matrices.
def spin_six_source_controls():
    import itertools
    from math import comb
    golden=(1+np.sqrt(5))/2
    elements=[]
    for axis in range(4):
        for sign in (-1,1):
            v=np.zeros(4);v[axis]=sign;elements.append(v)
    for signs in itertools.product((-1,1),repeat=4):
        elements.append(np.array(signs,dtype=float)/2)
    seed=np.array([0,.5,golden/2,1/(2*golden)])
    for perm in itertools.permutations(range(4)):
        if sum(perm[i]>perm[j] for i in range(4) for j in range(i+1,4))%2: continue
        x=seed[list(perm)];ix=np.nonzero(abs(x)>1e-14)[0]
        for signs in itertools.product((-1,1),repeat=3):
            y=x.copy();y[ix]=x[ix]*np.array(signs);elements.append(y)
    elements=np.array(elements)
    ck('ICOSIAN_SPIN6',465,'120 unique vertices',len(elements)==120 and len({tuple(np.round(q,12)) for q in elements})==120)
    ck('ICOSIAN_SPIN6',465,'unit norm 120 vertices',np.max(np.abs(np.linalg.norm(elements,axis=1)-1))<1e-12)
    # Character check for the entire 19-band: avg_2I chi_n is invariant rank.
    x=elements[:,0];u0=np.ones_like(x);u1=2*x
    for deg in range(20):
        if deg==0: char=u0
        elif deg==1:char=u1
        else:
            u0,u1=u1,2*x*u1-u0;char=u1
        exp=1 if deg in (0,12) else 0
        ck('ICOSIAN_ALIAS_19',480,f'2I invariant spin rank degree {deg}',abs(np.mean(char)-exp)<2e-9)
    # Spin-six 13x13 normalized symmetric-power representation.
    d=12;norms=np.array([np.sqrt(comb(d,k)) for k in range(d+1)])
    def rep(q):
        mat=q[0]*I+1j*(q[1]*sx+q[2]*sy+q[3]*sz)
        out=np.zeros((d+1,d+1),dtype=complex)
        for k in range(d+1):
            for a in range(d-k+1):
                for b in range(k+1):
                    l=a+b
                    out[l,k]+=norms[k]/norms[l]*comb(d-k,a)*comb(k,b)*mat[0,0]**(d-k-a)*mat[0,1]**a*mat[1,0]**(k-b)*mat[1,1]**b
        return out
    representations=[rep(q) for q in elements]
    for ix in [0,17,43,82,117]:
        ck('ICOSIAN_SPIN6',465,f'unitarity rep {ix}',close(representations[ix].conj().T@representations[ix],np.eye(13),1e-9),'numerical')
    projector=sum(representations)/120
    ck('ICOSIAN_SPIN6',465,'rank-one Reynolds trace',abs(np.trace(projector)-1)<1e-9,'numerical')
    ck('ICOSIAN_SPIN6',465,'Reynolds idempotence',close(projector@projector,projector,1e-9),'numerical')
    ck('ICOSIAN_SPIN6',465,'Reynolds Hermiticity',close(projector.conj().T,projector,1e-9),'numerical')
    vals,vec=np.linalg.eigh((projector+projector.conj().T)/2)
    ck('ICOSIAN_SPIN6',465,'unique fixed spin-six line',np.sum(vals>.5)==1,'numerical')
    v=vec[:,-1];Piv=np.outer(v,v.conj())
    for ix in [0,20,60,90,119]:
        ck('ICOSIAN_SPIN6',465,f'invariant vector {ix}',close(representations[ix]@v,v,1e-8),'numerical')
    # Derivatives of spin-six, with SU2 Casimir 168 (quaternionic unit speed).
    Jz=np.diag([6-k for k in range(13)])
    Jplus=np.zeros((13,13))
    for k in range(1,13):Jplus[k-1,k]=np.sqrt(k*(13-k))
    Jx=(Jplus+Jplus.T)/2; Jy=(Jplus-Jplus.T)/(2j)
    T=[2j*Jx,2j*Jy,2j*Jz]
    ck('ICOSIAN_SPIN6',465,'Casimir =168',close(sum((ti.conj().T@ti for ti in T),np.zeros((13,13))),168*np.eye(13),1e-10),'numerical')
    for a in range(3):
        ck('ICOSIAN_SPIN6',465,f'P T_{a} P=0',close(Piv@T[a]@Piv,np.zeros((13,13)),1e-9),'numerical')
        ck('ICOSIAN_SPIN6',465,f'seed derivative h=13P orthogonal T{a}',abs(np.trace(Piv@T[a]))<1e-9,'numerical')
        for b in range(3):
            expected=728 if a==b else 0
            gram=13*np.trace(Piv@T[a].conj().T@T[b]@Piv)
            ck('ICOSIAN_SPIN6',465,f'exact derivative Gram {a},{b}',abs(gram-expected)<1e-8,'numerical')
            cross=13*np.trace((Piv@T[a]).conj().T@(T[b]@Piv))
            ck('ICOSIAN_SPIN6',465,f'left/right derivative cross-zero {a},{b}',abs(cross)<1e-8,'numerical')
    # All mixed left/right derivative coefficient matrix units, not only diagonal channels.
    for a in range(3):
        for b in range(3):
            for i in range(3):
                for j in range(3):
                    observed=13/728*np.trace(Piv@T[b].conj().T@T[j]@Piv@T[a]@T[i])
                    expected=-56*(b==j)*(a==i)
                    ck('MIXED_DERIVATIVE_UNITS',468,f'2I SU2 spin-six {a},{b},{i},{j}',abs(observed-expected)<1e-8,'numerical')
                    sameL=13/728*np.trace((Piv@T[b]).conj().T@T[j]@(Piv@T[a])@T[i])
                    sameR=13/728*np.trace((T[b]@Piv).conj().T@T[j]@(T[a]@Piv)@T[i])
                    ck('MIXED_DERIVATIVE_UNITS',468,f'same-left block zero {a},{b},{i},{j}',abs(sameL)<1e-8,'numerical')
                    ck('MIXED_DERIVATIVE_UNITS',468,f'same-right block zero {a},{b},{i},{j}',abs(sameR)<1e-8,'numerical')
    char5=16*x**4-12*x*x+1
    ck('ICOSIAN_ALIAS_19',480,'2I finite spin-two character second moment 1',abs(np.mean(char5**2)-1)<1e-9,'numerical')
    ck('ICOSIAN_ALIAS_19',480,'2I finite spin-two character cubic moment 2',abs(np.mean(char5**3)-2)<1e-9,'numerical')
spin_six_source_controls()
# statuses / report
stats={}
for c in out: stats.setdefault(c['group'],{'pass':0,'fail':0}); stats[c['group']]['pass' if c['pass'] else 'fail']+=1
result={'artifact':'Paper1B-IndependentControlsBatch10Results-v1_1.json', 'source':'Paper1B-M8Geometry-v1_131.tex','census_indices':[447,482], 'scope':'finite/symbolic/constructive mathematical checks, not universal global proof verification', 'total_controls':len(out), 'passing_controls':sum(c['pass'] for c in out), 'failing_controls':sum(not c['pass'] for c in out),'families':stats,'controls':out,'independent_reviewers':0}
path=Path('/mnt/data/Paper1B-IndependentControlsBatch10Results-v1_1.json');path.write_text(json.dumps(result,indent=2))
print('PASS',len(out),'controls across',len(stats),'families')
