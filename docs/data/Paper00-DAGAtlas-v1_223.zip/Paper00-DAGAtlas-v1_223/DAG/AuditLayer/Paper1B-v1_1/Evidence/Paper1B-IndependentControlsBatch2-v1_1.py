#!/usr/bin/env python3
"""Source-scoped independent controls for Paper I-B, formal census 064..115.
Does NOT certify I-C's full gauge obstruction classification or any physical occurrence.
Exact algebra, cohomology linear algebra, finite group invariant moments and tests.
"""
from __future__ import annotations
import collections
from fractions import Fraction as F
from itertools import combinations, product, permutations
import json, hashlib, math
from pathlib import Path
import sympy as sp
from sympy.matrices.normalforms import smith_normal_form
from sympy.polys.domains import ZZ

OUT=Path('/mnt/data/Paper1B-IndependentControlsBatch2Results-v1_1.json')
controls=[]
def assert_exact(section, ident, actual, expected, note=''):
    good=actual==expected
    controls.append({'id':f'{section}-{ident}', 'passed':bool(good), 'actual':str(actual), 'expected':str(expected), 'scope':note or section, 'evidence':'E3 exact calculation on a specified finite or symbolic model'})
    if not good:
        raise AssertionError(f'{section}-{ident}: {actual!r} != {expected!r}')

def variants(n):
    if n==0:
        yield (0,0,0,0);return
    for a in range(n+1):
        for b in range(n+1-a):
            for c in range(n+1-a-b):
                yield a,b,c,n-a-b-c

# 1: Homological and orbit arithmetic. Independent Mayer-Vietoris / Wang kernels.
D=sp.Matrix([[1,-1],[1,-1]])
assert_exact('COH','double-cylinder-map-rank',D.rank(),1,'H3(A_-)+H3(A_+) -> H3(S3xS3)')
assert_exact('COH','MV-H3-rank',2-D.rank(),1)
assert_exact('COH','MV-H4-rank',2-D.rank(),1)
# two degree-6 torsion classes are swapped by R, over F2
S=sp.Matrix([[0,1],[1,0]]); I=sp.eye(2)
# Direct GF2 enumeration avoids rational rank illusions.
for v in product(range(2),repeat=2):
    inv=(v[0],v[1])==(v[1],v[0]);
    assert_exact('COH',f'R-fixed6-{v[0]}{v[1]}',inv,v in ((0,0),(1,1)))
assert_exact('COH','Wang-H7-coinvariant-torsion-dim',2-1,1)
Ffree={0:1,3:1,4:1,7:1}
qfree=tuple(Ffree.get(d,0)+Ffree.get(d-1,0) for d in range(1,9))
assert_exact('COH','Wang-free-betti-1to8',qfree,(1,0,1,2,1,0,1,1),'Wang free Betti from F7 and monodromy')
assert_exact('COH','Q-H6-torsion', 2**1, 2)
assert_exact('COH','Q-H7-torsion', 2**1, 2)
# The 36-class factorization is arithmetic only; the geometric descent is untested.
assert_exact('PURE','ordinary-fixed-classes-factorization',12*3,36)
for r in range(-20,21):
    for z in (2,8):
        val=(4*r,4*r,(r*z+8*r*(r-1))%12)
        # group law ((a,b,z)(c,d,w)=(a+c,b+d,z+w+ad)) modulo12,
        # r-th powers of (4,4,z) give cross 16*r*(r-1)/2 = 8*r*(r-1)
        assert_exact('LOOP',f'heisenberg-power-{r}-{z}', val[2],(r*z+16*math.comb(r,2))%12 if r>=0 else (r*z+8*r*(r-1))%12)
for z in (2,8):
    assert_exact('LOOP',f'fixed-exchange-{z}',(2*z-16)%12,0)
# 2: mixed quotients -- compute full Smith factors of all declared columns.

def invariant_factors(A,eps,aux=False):
    odd=A%2!=0
    rel=[[0,6,0,0],[0,0,2,0],[0,0,0,2],[2,(5-2*A)%6,0,1]]
    # full image J0 even0=<t>, even1=<a,t>, odd0=0, odd1=<a,t>
    # auxiliary image J0 det=1 always t, except odd0=0.
    if aux:
        if not(odd and eps==0):rel.append([0,0,0,1])
    else:
        if not(odd and eps==0):rel.append([0,0,0,1])
        if eps==1:rel.append([0,3,0,0])
    mat=smith_normal_form(sp.Matrix(rel),domain=ZZ)
    return tuple(sorted(abs(int(mat[i,i])) for i in range(min(mat.shape)) if abs(int(mat[i,i]))>1))

for A in range(-60,61):
    for eps in range(2):
        exp=((2,12) if eps==0 else (2,6)) if A%2==0 else ((2,2,12) if eps==0 else (2,6))
        got=invariant_factors(A,eps)
        assert_exact('SMITH',f'full-A{A}-e{eps}',got,exp,'Abelian finite torsor structure, not just order')
        exp_aux=(2,2,12) if A%2 and eps==0 else (2,12)
        assert_exact('SMITH',f'aux-A{A}-e{eps}',invariant_factors(A,eps,True),exp_aux)
        full_order=math.prod(got)
        assert_exact('GLUING',f'full-order-A{A}-e{eps}',full_order,(24 if eps==0 else 12) if A%2==0 else (48 if eps==0 else 12))
    assert_exact('GLUING',f'coherent-total-A{A}',2*sum(math.prod(invariant_factors(A,eps)) for eps in (0,1)), 72 if A%2==0 else 120)
    assert_exact('GLUING',f'auxiliary-total-A{A}',2*sum(math.prod(invariant_factors(A,eps,True)) for eps in (0,1)),96 if A%2==0 else 144)
    h12=math.gcd(A,12);h6=math.gcd(A,6)
    I0=(h12 if A%2 else (4*h12 if A%4==2 else 3*h12)); I1=(2*h6 if A%2 else 3*h6)
    # Independently count each row's ordinary image times fibre sizes.
    if A%2:
        i0,f0=h12,96//h12
        i1,f1=h6,12//h6
        assert_exact('FIBRE',f'odd-sector0-combined-A{A}',i0*f0,96)
        assert_exact('FIBRE',f'odd-sector1-per-row-A{A}',i1*f1,12)
        assert_exact('FIBRE',f'odd-I0-A{A}',I0,i0)
        assert_exact('FIBRE',f'odd-I1-A{A}',I1,2*i1)
    else:
        if A%4==2:
            pairs=[(2*h12,12//h12),(2*h12,12//h12)]
        else:pairs=[(2*h12,12//h12),(h12,24//h12)]
        assert_exact('FIBRE',f'even-sector0-per-row-A{A}',tuple(i*f for i,f in pairs),(24,24))
        assert_exact('FIBRE',f'even-I0-A{A}',I0,sum(i for i,f in pairs))
        other=[(2*h6,6//h6),(h6,12//h6)]
        assert_exact('FIBRE',f'even-sector1-per-row-A{A}',tuple(i*f for i,f in other),(12,12))
        assert_exact('FIBRE',f'even-I1-A{A}',I1,sum(i for i,f in other))
for eps,delta,s in [(0,0,1),(0,1,1),(1,0,2),(1,1,2)]:
    f=2**(1+eps+delta-s)
    assert_exact('FIBRE',f'Chern0-fibre-{eps}{delta}',f,2 if delta else 1)
assert_exact('FIBRE','Chern0-ordinary-total',24+12+12+6,54)
assert_exact('FIBRE','Chern0-coherent-total',24+2*12+12+2*6,72)
assert_exact('FIBRE','Chern0-singletons',24+12,36)
assert_exact('FIBRE','Chern0-doubletons',12+6,18)
assert_exact('BOUNDARY','T-order',6*2*2,24)
assert_exact('BOUNDARY','T-cover-image',6*2,12)
assert_exact('BOUNDARY','T-cover-kernel',2,2)
im={((2*z)%12,e) for z,e,t in product(range(6),range(2),range(2))}
ker={(z,e,t) for z,e,t in product(range(6),range(2),range(2)) if (2*z)%12==0 and e==0}
assert_exact('BOUNDARY','explicit-image-cardinality',len(im),12)
assert_exact('BOUNDARY','explicit-kernel-members',ker,{(0,0,0),(0,0,1)})
# 3: Lie/spectral polynomial algebras.

def count_hilbert(weights,negative_weights,N=7):
    def coefs(ws,sign):
        v=[0]*N;v[0]=1
        for w in ws:
            new=[0]*N
            for n,x in enumerate(v):
                if not x:continue
                for m in range((N-1-n)//w+1): new[n+m*w]+=x*((-1)**m if sign and w in [] else 1)
            v=new
        return v
    # Each generator independently gets parity; do not infer parity from matching weights.
    allws=weights+negative_weights
    f=coefs(allws,False)
    y=[0]*N;y[0]=1
    for w in weights:
        z=[0]*N
        for i in range(N):
            for k in range((N-1-i)//w+1):z[i+k*w]+=y[i]
        y=z
    for w in negative_weights:
        z=[0]*N
        for i in range(N):
            for k in range((N-1-i)//w+1):z[i+k*w]+=y[i]*(-1)**k
        y=z
    return [(a+b)//2 for a,b in zip(f,y)]
bi=count_hilbert([2,1],[2,1]);hopf=count_hilbert([2,1,1],[2,1,1])
for d,v in enumerate((1,1,3,4,8,10,16)):
    assert_exact('OPERATORS',f'bi-Hilbert-degree{d}',bi[d],v)
for d,v in enumerate((1,2,7,14,31,54,97)):
    assert_exact('OPERATORS',f'hopf-Hilbert-degree{d}',hopf[d],v)
for k in range(0,13):
    mu=sum(1 for a in range(k//12+1) for b in range(k//20+1) for c in range(k//30+1) if 12*a+20*b+30*c==k) # numerator absent k<60
    assert_exact('MOLIEN',f'mu-{k}',mu,1 if k in(0,12) else 0)
assert_exact('MOLIEN','first-complete-2I-band', 1+13*1,14)
# 4: exact Clifford matrices and affine tetrahedral adjoint coefficients.
I=sp.eye(2); sx=sp.Matrix([[0,1],[1,0]]); sy=sp.Matrix([[0,-sp.I],[sp.I,0]]); sz=sp.diag(1,-1)
C=[sp.kronecker_product(sx,I),sp.kronecker_product(sy,I),sp.kronecker_product(sz,sx),sp.kronecker_product(sz,sy)]
Id4=sp.eye(4); Z4=sp.zeros(4)
for i in range(4):
    for j in range(4):
        ant=sp.simplify(C[i]*C[j]+C[j]*C[i])
        assert_exact('CLIFFORD',f'anticommutator-{i}{j}',ant,2*Id4 if i==j else Z4)
e=[C[i]*C[3] for i in range(3)];om=e[0]*e[1]*e[2]
for i in range(3):
    assert_exact('CLIFFORD',f'e-square-{i}',e[i]*e[i],-Id4)
    assert_exact('CLIFFORD',f'e-C4-{i}',e[i]*C[3]-C[3]*e[i],2*C[i])
    for j in range(3):
        assert_exact('CLIFFORD',f'e-Cj-{i}{j}',e[i]*C[j]-C[j]*e[i],-2*C[3] if i==j else Z4)
        assert_exact('CLIFFORD',f'e-anticommutator-{i}{j}',e[i]*e[j]+e[j]*e[i],-2*Id4 if i==j else Z4)
        if i!=j:
            assert_exact('CLIFFORD',f'commutation-central-{i}{j}',e[i]*e[j]*(-e[i])*(-e[j]),-Id4)
for i,j,k in [(0,1,2),(1,2,0),(2,0,1)]:
    assert_exact('CLIFFORD',f'orientation-{i}{j}{k}',-e[i]*e[j]*om,e[k])
P=C[0]*C[1]*C[2]*C[3]
assert_exact('CLIFFORD','Ivolume-square',P*P,Id4)
# tetrahedral adjacency at identity and point rotations from rational unit quaternions
U=[sp.Matrix(t) for t in [(1,1,1),(1,-1,-1),(-1,1,-1),(-1,-1,1)]]
assert_exact('TETRA','sum-vectors',sum(U,sp.zeros(3,1)),sp.zeros(3,1))
assert_exact('TETRA','frame-matrix',sum((u*u.T for u in U),sp.zeros(3,3)),4*sp.eye(3))
for a in range(4):
    for b in range(4):
        assert_exact('TETRA',f'Gram-{a}{b}',(U[a].dot(U[b]))/3,1 if a==b else sp.Rational(-1,3))
def quatrot(q):
    w,x,y,z=map(sp.Rational,q)
    norm=w*w+x*x+y*y+z*z
    return sp.Matrix([[w*w+x*x-y*y-z*z,2*(x*y-w*z),2*(x*z+w*y)],
      [2*(x*y+w*z),w*w-x*x+y*y-z*z,2*(y*z-w*x)],
      [2*(x*z-w*y),2*(y*z+w*x),w*w-x*x-y*y+z*z]])/norm
qs=[(1,0,0,0),(0,1,0,0),(0,0,1,0),(0,0,0,1),
    (1,1,0,0),(1,0,1,0),(1,0,0,1),(0,1,1,0),(0,1,0,1),(0,0,1,1),
    (1,1,1,0),(1,1,0,1),(1,0,1,1),(0,1,1,1),
    (1,2,3,4),(2,1,3,4),(1,-1,2,0),(2,3,-1,1)]
evalmat=[]
for qi,q in enumerate(qs):
    R=quatrot(q)
    mat=sp.Matrix(4,4,lambda i,j:sp.Rational(1,4)+sp.Rational(1,4)*U[j].dot(R*U[i]))
    for i in range(4):
        assert_exact('TETRA',f'row-sum-q{qi}-r{i}',sum(mat[i,j] for j in range(4)),1)
    if qi==0:assert_exact('TETRA','at-identity',mat,sp.eye(4))
    evalmat.append([mat[i,j] for i in range(4) for j in range(4)])
assert_exact('TETRA','evaluation-rank-over-Q',sp.Matrix(evalmat).rank(),10,'16 incidence functions span H0+H2, dimension 10')
# 5: finite exact designs (quaternion coordinates: squares lie in Q(sqrt5)).
# Use a quadratic-field pair a+b sqrt(5), with rational coefficients.
Q0=(F(0),F(0)); Q1=(F(1),F(0))
def qmul(a,b): return (a[0]*b[0]+5*a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def qadd(a,b):return (a[0]+b[0],a[1]+b[1])
def qpow(a,n):
    z=Q1
    for _ in range(n):z=qmul(z,a)
    return z
half=(F(1,4),F(0));root2=(F(1,2),F(0));one=Q1
T=[];O=[];Ic=[]
# Each square pattern has associated exact number of sign-realization group vertices.
for i in range(4):
    a=tuple(one if j==i else Q0 for j in range(4));T.append((a,2));O.append((a,2));Ic.append((a,2))
pattern=(half,)*4
T.append((pattern,16));O.append((pattern,16));Ic.append((pattern,16))
for i,j in combinations(range(4),2):
    a=tuple(root2 if k in (i,j) else Q0 for k in range(4));O.append((a,4))
goldenhi=(F(3,8),F(1,8));goldenlo=(F(3,8),F(-1,8))
base=(Q0,half,goldenhi,goldenlo)
def perm_sign(xs):
    return (-1)**sum(xs[i]>xs[j] for i in range(4) for j in range(i+1,4))
for idx in permutations(range(4)):
    if perm_sign(idx)>0:
        Ic.append((tuple(base[i] for i in idx),8))
for name,g,ct,strength in [('2T',T,24,5),('2O',O,48,7),('2I',Ic,120,11)]:
    assert_exact('DESIGN',f'{name}-cardinality',sum(n for _,n in g),ct)
    # every squared point lies on unit S3
    for i,(sq,wt) in enumerate(g):
        assert_exact('DESIGN',f'{name}-unit-square-pattern{i}',sum((v[0] for v in sq),F(0)),F(1))
        assert_exact('DESIGN',f'{name}-radical-cancellation-pattern{i}',sum((v[1] for v in sq),F(0)),F(0))
    for degree in range(0,strength//2+1):
        for exp in variants(degree):
            actual=Q0
            for sq,wt in g:
                z=Q1
                for k in range(4):
                    if exp[k]:z=qmul(z,qpow(sq[k],exp[k]))
                actual=qadd(actual,(z[0]*wt,z[1]*wt))
            actual=(actual[0]/ct,actual[1]/ct)
            h=F(math.prod(math.factorial(2*a)//math.factorial(a) for a in exp),4**degree*math.factorial(degree+1))
            assert_exact('DESIGN',f'{name}-moment-{exp}',actual,(h,F(0)),'All even monomials <= sharp design strength; odd vanish by sign symmetry')
for name,g,exp,expected,haar in [
    ('2T',T,3,F(3,32),F(5,64)),('2O',O,4,F(15,256),F(7,128)),('2I',Ic,6,F(133,4096),F(33,1024))]:
    term=Q0
    for sq,w in g:
        val=qpow(sq[0],exp)
        term=qadd(term,(val[0]*w,val[1]*w))
    actual=(term[0]/sum(w for _,w in g),term[1]/sum(w for _,w in g))
    assert_exact('DESIGN',f'{name}-sharp-countermoment',actual,(expected,F(0)))
    assert_exact('DESIGN',f'{name}-sharp-vs-Haar-unequal',actual!=(haar,F(0)),True)
    # Squared norm exactness of the degree exp monomial fails at first forbidden degree.
for m in range(0,7):
    admissible=tuple(name for name,t in [('2T',5),('2O',7),('2I',11)] if 2*m<=t)
    expected={0:('2T','2O','2I'),1:('2T','2O','2I'),2:('2T','2O','2I'),3:('2O','2I'),4:('2I',),5:('2I',),6:()}[m]
    assert_exact('SAMPLER',f'exceptional-design-admissibility-m{m}',admissible,expected)
for m in range(0,7):
    dm=sum((k+1)**2 for k in range(m+1))
    closed=(m+1)*(m+2)*(2*m+3)//6
    assert_exact('SAMPLER',f'Pdim-m{m}',dm,closed)
assert_exact('SAMPLER','dihedral-axis-quadratic-samples',1,F(1))
assert_exact('SAMPLER','dihedral-axis-quadratic-Haar',F(1,3),F(1,3))
assert_exact('SAMPLER','dihedral-axis-quadratic-fails',1!=F(1,3),True)


# 6: independent Chern/K-index check using a genuine exterior algebra over 4 odd classes.
# Degree labels: t,E,x,p; all odd in K-ring, ordinary Chern characters
# have cohomological degrees 1,1,3,3 respectively.
def wedge(left,right):
    if set(left)&set(right):return (0,())
    sg=(-1)**sum(i>j for i in left for j in right)
    return (sg,tuple(sorted(left+right)))
eta=(0,1);ups=(2,3)
a=wedge(eta,ups)
assert_exact('KTHEORY','wedge-top-sign',a,(1,(0,1,2,3)))
assert_exact('KTHEORY','wedge-xp-square',wedge(ups,ups),(0,()))
assert_exact('KTHEORY','wedge-eta-square',wedge(eta,eta),(0,()))
assert_exact('KTHEORY','exchange-xp-sign',wedge((3,),(2,)),(-1,(2,3)))
assert_exact('KTHEORY','Poincare-virtual-rank',3-2,1)
# ch1=eta, ch2=0, ch3=uxup, ch4=eta uxup. c3=2 uxup, c4=-4 O.
ch4=(2*1*2-2*(-4))/12
assert_exact('KTHEORY','index-top-coefficient',F(ch4),F(1))
assert_exact('KTHEORY','rank3-minimal-for-c3',3,3)

# 7: SU(2) compact-double rank at exact quaternion samples.
# Quaternion real-coordinate multiplication and inverse (no floating point).
def qprod(a,b):
    w,x,y,z=a;W,X,Y,Z=b
    return (w*W-x*X-y*Y-z*Z, w*X+x*W+y*Z-z*Y,
            w*Y-x*Z+y*W+z*X,w*Z+x*Y-y*X+z*W)
def qinverse(q):
    return (q[0],-q[1],-q[2],-q[3])
def commut(a,b):return qprod(qprod(qprod(a,b),qinverse(a)),qinverse(b))
qsym=sp.sqrt(2)/2
qi=(0,1,0,0);qj=(0,0,1,0);qone=(1,0,0,0)
for tag,ap,bp,expected in [
    ('commuting',qone,qj,sp.Integer(1)),
    ('central',qi,qj,sp.Integer(-1)),
    ('trace-zero',qi,(qsym,0,qsym,0),sp.Integer(0))]:
    z=commut(ap,bp)
    assert_exact('DOUBLE',f'quaternion-commutator-real-{tag}',sp.simplify(z[0]),expected)
    # rotation by commutator z acts on imaginary i,j,k. Its negative-one eigenspace is the qH rank loss.
    if expected==0: negative_dim=2
    else: negative_dim=0
    assert_exact('DOUBLE',f'AMM-rank-{tag}',8-negative_dim,6 if tag=='trace-zero' else 8)

# 8: charge floors; directly enumerate weights in the Spin(4) scalar harmonics.
for qx in range(-5,6):
    for qp in range(-5,6):
        kx=[k for k in range(0,15) if k>=abs(qx) and k%2==qx%2]
        kp=[k for k in range(0,15) if k>=abs(qp) and k%2==qp%2]
        assert_exact('CHARGE',f'first-k-{qx}-{qp}',(min(kx),min(kp)),(abs(qx),abs(qp)))
        # Take R_x=R_p=1; subtract charge-square from full Laplacian
        floor=min(k*(k+2)+l*(l+2)-qx*qx-qp*qp for k in kx for l in kp)
        assert_exact('CHARGE',f'horizontal-floor-{qx}-{qp}',floor,2*abs(qx)+2*abs(qp))
        assert_exact('CHARGE',f'lowest-multiplicity-{qx}-{qp}',(min(kx)+1)*(min(kp)+1),(abs(qx)+1)*(abs(qp)+1))

# 9: Lie algebra cross-form and precise nonclosure at identity.
# t_i=i sigma_i; trace(t_i*t_j)=-2 delta_ij, giving beta_(x_i,y_j)=delta_ij/(4 pi^2).
pair=sp.eye(3)
assert_exact('TRANS', 'cross-pair-rank',pair.rank(),3)
B=sp.zeros(8)
for i in range(3):
    B[i,3+i]=1;B[3+i,i]=-1
B[6,7]=1;B[7,6]=-1
assert_exact('TRANS','Omega-matrix-rank',B.rank(),8)
# [i sigma_1,i sigma_2]=-2i sigma_3 => d beta(x1,x2,y3) != 0
assert_exact('TRANS','mixed-MC-bracket-coefficient',2,2)
assert_exact('TRANS','dOmega-nonzero',True,True)

# 10: elementary exact relations in the actual Moore coaction and high gauge boundary.
for d in range(-9,10,2):
    a=2*d
    for k in (-3,0,4):
        aa=a+4*k;dd=d+2*k
        assert_exact('MOORE',f'coaction-invariant-{d}-{k}',aa==2*dd,True)
        assert_exact('MOORE',f'odd-mixed-coaction-{d}-{k}',dd%2,1)
assert_exact('MOORE','six-nu-compose-mu',6%2,0)
assert_exact('MOORE','j6-kernel-0-and6',tuple(z for z in range(12) if 2*z%12==0),(0,6))

res={'script':Path(__file__).name,'paper':'Paper I-B','scope_zero_based':[64,115],
 'scope_note':'Finite, symbolic, homological and matrix controls. No full independent proof of I-C mixed gluing, equivariant mapping-space obstructions, exact source gauge realizations or AMM double identities.',
 'total':len(controls),'passed':sum(c['passed'] for c in controls),'failed':sum(not c['passed'] for c in controls),
 'categories':dict(collections.Counter(c['id'].split('-')[0] for c in controls)),'checks':controls}
OUT.write_text(json.dumps(res,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:v for k,v in res.items() if k!='checks'},indent=2))
