#!/usr/bin/env python3
"""Paper I-B, source v1_131, census 000–063: independently reimplementable
SCOPED exact mathematical controls. Not a full proof of unstable-bundle
classification or imported index/fixed-point theorems.
Python 3; sympy installed. Independent finite algebra + adversarial cases.
"""
from collections import Counter
from itertools import combinations, product
from math import gcd, sqrt, sin, cos
import json
import sympy as sp
from sympy.matrices.normalforms import smith_normal_form
from sympy.polys.domains import ZZ

CHECKS=[]
def check(id_, condition, note=''):
    ok=bool(condition); CHECKS.append({'id':id_, 'passed':ok, 'note':note})
    if not ok: raise AssertionError(id_+(' '+note if note else ''))

# Independent exterior-algebra model, four odd generators with degrees 1,1,3,3.
deg=(1,1,3,3)
monomials=[()] + [t for k in range(1,5) for t in combinations(range(4),k)]
def ext(a,b):
    if set(a)&set(b): return 0,()
    sign=(-1)**sum(deg[i]*deg[j] for i in a for j in b if i>j)
    return sign,tuple(sorted(a+b))
perm=(1,0,3,2)
def swap(t):
    vals=tuple(perm[i] for i in t)
    sign=(-1)**sum(deg[vals[i]]*deg[vals[j]] for i in range(len(vals)) for j in range(i+1,len(vals)) if vals[i]>vals[j])
    return sign,tuple(sorted(vals))
expected_b=[1,2,1,2,4,2,1,2,1]
actual_b=[sum(sum(deg[i] for i in t)==d for t in monomials) for d in range(9)]
check('COH-BETTI-POLYNOMIAL',actual_b==expected_b,str(actual_b))
check('COH-16-MONOMIALS',len(monomials)==16)
check('COH-EXCHANGE-INVOLUTION',all((lambda first,second: first[0]*second[0]==1 and second[1]==t)(swap(t),swap(swap(t)[1])) for t in monomials))
expected_plus=(1,1,0,1,2,1,0,1,1)
expected_minus=(0,1,1,1,2,1,1,1,0)
expected_defect=(0,1,0,1,2,1,0,1,0)
plus=[0]*9;minus=[0]*9;defect=[0]*9
seen=set()
for t in monomials:
  if t in seen: continue
  d=sum(deg[i] for i in t)
  s,u=swap(t)
  if u==t:
    (plus if s==1 else minus)[d]+=1;seen.add(t)
  else:
    check(f'COH-SWAP-PAIR-{t}',swap(u)==(s,t))
    plus[d]+=1;minus[d]+=1;defect[d]+=1;seen|={t,u}
check('COH-PLUS-EIGENRANKS',tuple(plus)==expected_plus,str(plus))
check('COH-MINUS-EIGENRANKS',tuple(minus)==expected_minus,str(minus))
check('COH-INTEGRAL-EXCHANGE-DEFECT',tuple(defect)==expected_defect,str(defect))
check('COH-TOTAL-SATURATION-INDEX',sum(defect)==6)
forms4=[(0,2),(0,3),(1,2),(1,3)]
Q=sp.Matrix([[ext(a,b)[0] if ext(a,b)[1]==(0,1,2,3) else 0 for b in forms4] for a in forms4])
Q_source=sp.Matrix([[0,0,0,-1],[0,0,1,0],[0,1,0,0],[-1,0,0,0]])
check('COH-INTERSECTION-MATRIX',Q==Q_source)
check('COH-INTERSECTION-EVEN-UNIMODULAR',Q.det()==1 and all(int(v)%2==0 for v in Q.diagonal()) and Q==Q.T)
# Independent coefficient-computation: c2^2 and (c1*c3); ch_4 integrality.
A,B,C,D,n,m,k=sp.symbols('A B C D n m k', integer=True)
c2_coeffs=[A,B,C,D]
c2sq=sp.expand(sum(c2_coeffs[i]*c2_coeffs[j]*Q[i,j] for i in range(4) for j in range(4)))
Delta=B*C-A*D
check('CHERN-C2-SQUARE',sp.simplify(c2sq-2*Delta)==0)
c4=Delta+2*n*m-6*k
ch4=sp.cancel((c2sq+2*(2*n*m)-2*c4)/12)
check('CHERN-CH4-INDEX-COEFFICIENT',sp.simplify(ch4-k)==0)
check('CHERN-EXCHANGE-NO-FIXED-C1',swap((0,1))[0]==-1)
check('CHERN-EXCHANGE-NO-FIXED-C3',swap((2,3))[0]==-1)
check('K-RANK-EVEN-ODD',sum(actual_b[::2])==8 and sum(actual_b[1::2])==8)

# Scalar eigenphase cover A: character lattice cokernel Z/2, angle relations.
angle=sp.Matrix([[1,1],[1,-1]])
check('SCALAR-EIGENPHASE-SQUARE',angle*angle==2*sp.eye(2))
check('SCALAR-EIGENPHASE-DEGREE',int(angle.det())==-2)
check('SCALAR-EIGENPHASE-SNF',list(smith_normal_form(angle,domain=ZZ).diagonal())==[1,-2] or sorted(abs(int(z)) for z in smith_normal_form(angle,domain=ZZ).diagonal())==[1,2])
check('SCALAR-EIGENPHASE-CHARACTER-PARITY',all((i+j)%2==0 for a,b in product(range(-8,9),repeat=2) for i,j in [(a+b,a-b)]))
check('SCALAR-EIGENPHASE-KERNEL',[(x,y) for x,y in product([-1,1],repeat=2) if x*y==1 and x/y==1]==[(-1,-1),(1,1)])
centralizers=[]
for aa,bb,cc,dd in product(range(-3,4),repeat=4):
 M=sp.Matrix([[aa,bb],[cc,dd]])
 if abs(int(M.det()))==1 and M*sp.Matrix([[0,1],[1,0]])==sp.Matrix([[0,1],[1,0]])*M:
  centralizers.append(tuple(M))
check('GROUP-EXCHANGE-GL2Z-CENTRALIZER',len(centralizers)==4,str(centralizers))

# Primitive cocharacters and exact exchange-stability necessity/sufficiency
stable=[]
for weights in product(range(-2,3), repeat=4):
 if gcd(*weights)!=1: continue
 a,b,m_,n_=weights
 is_stable=(b,a,n_,m_)==weights or (b,a,n_,m_)==tuple(-x for x in weights)
 shape=(a==b and m_==n_) or (a==-b and m_==-n_)
 check(f'COCHAR-{a},{b},{m_},{n_}',is_stable==shape) if is_stable or shape else None
 if is_stable: stable.append(weights)
check('COCHAR-EXCHANGE-STABLE-ENUMERATION',bool(stable))
check('COCHAR-PURE-HOPF-PRIMITIVE',all(abs(a)==abs(b)==1 for a,b,m_,n_ in stable if m_==n_==0))
check('COCHAR-SCALAR-ONLY-PRIMITIVE',all((abs(m_),abs(n_))==(1,1) for a,b,m_,n_ in stable if a==b==0))

# Quotient long exact sequence homotopy: Z -> Z^2, weights (m,n).
for m_,n_ in [(0,0),(1,0),(0,1),(1,1),(-2,2),(3,6),(2,4)]:
  d=gcd(m_,n_)
  ker_rank=1 if d==0 else 0
  pi1_free=2 if d==0 else 1
  pi1_torsion=d if d>1 else 1
  check(f'QUOTIENT-PI2-{m_}-{n_}',ker_rank==(1 if (m_,n_)==(0,0) else 0))
  check(f'QUOTIENT-PI1-{m_}-{n_}',pi1_free+(1 if pi1_torsion>1 else 0)==2 if d>1 else (pi1_free==2 if d==0 else pi1_free==1))

# Hopf quotient: c1=b eps_x h_x - a eps_p h_p, Chern square -2 ab epsx epsp.
for a,b in [(1,0),(0,1),(1,1),(1,-1),(2,3),(-3,2)]:
 for ex,ep in product([-1,1], repeat=2):
  c1square=2*(b*ex)*(-a*ep)
  check(f'HOPF-CONTACT-C1SQ-{a}-{b}-{ex}-{ep}',c1square==-2*a*b*ex*ep)
  check(f'HOPF-CONTACT-IFF-{a}-{b}-{ex}-{ep}',(c1square!=0)==(a*b!=0))

# Lie bracket symmetric pair and Cartan connection algebra model with su2 structure constants.
def cross(X,Y): return sp.Matrix([2*(X[1]*Y[2]-X[2]*Y[1]),2*(X[2]*Y[0]-X[0]*Y[2]),2*(X[0]*Y[1]-X[1]*Y[0])])
unit=[sp.Matrix([int(i==j) for i in range(3)]) for j in range(3)]
for X,Y in product(unit,repeat=2):
  z=cross(X,Y)
  # +/- of pair brackets on  x 
  # [ (X,-X), (Y,-Y)] = ([X,Y],[X,Y]) even sector.
  check(f'K-SYMMETRIC-ODD-ODD-{list(X)}-{list(Y)}',cross(-X,-Y)==z)
  # [ (X,X), (Y,-Y)] = ([X,Y],-[X,Y]) odd sector.
  check(f'K-SYMMETRIC-EVEN-ODD-{list(X)}-{list(Y)}',cross(X,-Y)==-z)

# Separate finite nonabelian group model of relative-bundle and pair-groupoid
# identities. This tests the universal algebra of the claim, not all Lie topology.
from itertools import permutations
S3=list(permutations(range(3)))
def compose(a,b): return tuple(a[b[i]] for i in range(3))
def invperm(a): return tuple(a.index(i) for i in range(3))
idperm=tuple(range(3))
for a,b,h in product(S3,repeat=3):
 r0=compose(a,invperm(b))
 r1=compose(compose(a,h), invperm(compose(b,h)))
 if r0!=r1: raise AssertionError('relative bundle invariance')
check('GROUP-RELATIVE-NONABELIAN-TRIVIALIZATION',True,'All S3^3 triples checked; inverse Phi(r,b)=(rb,b)')
check('GROUP-RELATIVE-IDENTITY-FIBRE',all((compose(a,invperm(b))==idperm)==(a==b) for a,b in product(S3,repeat=2)))
check('GROUP-PAIR-COCYCLE',all(compose(compose(a,invperm(b)),compose(b,invperm(c)))==compose(a,invperm(c)) for a,b,c in product(S3,repeat=3)))
# A principal C2 bundle over three points: transformation groupoid and
# kernel-pair groupoid are the same under (q,z)->(q,q.z).
P=list(product(range(3),(0,1)))
trans={(q,z):(q,(q[0],(q[1]+z)%2)) for q,z in product(P,(0,1))}
kernel={(q,q2) for q,q2 in product(P,P) if q[0]==q2[0]}
check('GROUP-HOPF-KERNEL-PAIR-BIJECTION',len(trans)==len(kernel)==len(P)*2 and set(trans.values())==kernel)
# Exchange linearisation on two real four-planes, and cotangent reversal.
I4=sp.eye(4);Z4=sp.zeros(4)
SW=I4.row_join(Z4).col_join(Z4.row_join(I4))
SW=Z4.row_join(I4).col_join(I4.row_join(Z4))
RE=I4.row_join(Z4).col_join(Z4.row_join(-I4))
J=Z4.row_join(I4).col_join(-I4.row_join(Z4))
check('GROUP-EXCHANGE-ORIENTATION-SIGN',SW.det()==1)
check('GROUP-EXCHANGE-PLUS-MINUS-NORMAL',SW.eigenvals()=={sp.Integer(1):4,sp.Integer(-1):4})
check('SYMPLECTIC-COTANGENT-REVERSAL',RE.T*J*RE==-J)
# Formal Maurer-Cartan curvature expansion, with cross term x∧y+y∧x.
u=sp.symbols('u',real=True)
f=(1+u)/2
# A_f=f theta_x+(1-f)theta_p
coefs=(sp.expand(f*f-f),sp.expand((1-f)**2-(1-f)),sp.expand(f*(1-f)))
ref=tuple(sp.expand(c*(u*u-1)/4) for c in (1,1,-1))
check('CARTAN-CURVATURE-COEFFICIENTS',all(sp.simplify(a-b)==0 for a,b in zip(coefs,ref)))
check('CARTAN-EXCHANGE-UNIQUE-MIDPOINT',sp.solve(sp.Eq(f,1-f),u)==[0])
check('CARTAN-VERTICAL-CONNECTION-CHECK',sp.simplify(f+1-f)==1)
check('CARTAN-HORIZONTAL-SOLDER-CHECK',sp.simplify(f-(1-f)-u)==0)
# Nonabelian gauge defect: in G×C2 use a base swap lift (s,1), with
# s an S3 3-cycle; check (u f)^2 = u conj_s(u) f^2 exactly.
s=(1,2,0)
A_def=compose(s,s)
for v in S3:
  left=compose(compose(compose(v,s),v),s)
  alpha=compose(compose(s,v),invperm(s))
  right=compose(compose(v,alpha),A_def)
  if left!=right: raise AssertionError('nonabelian norm equation')
check('GAUGE-BORN-NORM-NONABELIAN',True,'Exhaustive S3 test with nonidentity f²')

# Noncommutative group commutator BCH: two Pauli quaternion rotations.
def mul(q,p):
  w,x,y,z=q;v,a,b,c=p
  return (w*v-x*a-y*b-z*c,w*a+x*v+y*c-z*b,w*b-x*c+y*v+z*a,w*c+x*b-y*a+z*v)
def inv(q):return (q[0],-q[1],-q[2],-q[3])
def expaxis(e,axis):return tuple([cos(e)]+[sin(e) if j==axis else 0 for j in range(3)])
def defect(e):
  q=expaxis(e,0);p=expaxis(e,1);com=mul(mul(mul(q,p),inv(q)),inv(p))
  return sqrt((com[0]-1)**2+com[1]**2+com[2]**2+(com[3]-2*e*e)**2)
check('COMMUTATOR-BCH-2ND-ORDER',defect(.002)<defect(.004)/6 and defect(.002)<1e-6)

# Rank-three fixed-Chern Smith invariants, including zero class.
for g in (2,6):
 for a,b,c,d in [(0,0,0,0),(1,0,0,0),(2,2,2,2),(3,0,0,3),(1,2,3,4),(6,12,-3,0),(-4,4,6,-6),(2,0,0,4),(6,6,6,6)]:
  mat=sp.Matrix([[g,0,a,b],[0,g,c,d]])
  diag=smith_normal_form(mat,domain=ZZ)
  smith=[abs(int(diag[i,i])) for i in range(2)]
  d1=gcd(g,a,b,c,d)
  d2=gcd(g*g,g*a,g*b,g*c,g*d,a*d-b*c)
  check(f'RANK3-SMITH-{g}-{a}-{b}-{c}-{d}',smith==[d1,d2//d1],str((smith,d1,d2//d1)))
check('RANK3-ZERO-CHERN-COUNT',6**2==36)

# Independent secondary-shear orbit enumeration on F2^3.
secondary=list(product((0,1),repeat=3))
def rank2(M):
  rows=[tuple(v%2 for v in row) for row in M]
  nonzero=set(rows)-{(0,0)}
  return 0 if not nonzero else (1 if len(nonzero)==1 else 2)
def ker2(M):
  return [(a,b) for a,b in product((0,1),repeat=2) if all((row[0]*a+row[1]*b)%2==0 for row in M)]
def orbits(M):
  kern=ker2(M);left=set(secondary); out=[]
  while left:
    r,s,e=min(left)
    orbit={(r,s,(e+b*r+a*s)%2) for a,b in kern}
    out.append(orbit);left-=orbit
  return out
for entries in product((0,1),repeat=4):
  M=[entries[:2],entries[2:]]
  N=len(orbits(M)); expected=4+2**rank2(M)
  check(f'RANK2-F2-SHEAR-{entries}',N==expected,str((N,expected)))
check('RANK2-ZERO-SHEAR-ORBIT',len(orbits([(0,0),(0,0)]))==5)
check('RANK2-ZERO-CHERN-PRINCIPAL',12**2*5==720)
check('RANK2-ZERO-CHERN-ORDINARY',720+5*6**2==900)
check('RANK2-ZERO-CHERN-STABILIZATION',36*(20+5)==900)
check('RANK2-ZERO-CHERN-BORN-ORDINARY',3*12+3*6==54)
# Rank-one primitive sample (A,B,C,D)=(d,0,0,0): N=[[0,-d],[0,0]]
for d in [1,2,3,4,6,8,12]:
  # stabilizer of N_c modulo 12: a unconstrained, d*b=0 mod12.
  H={(a%2,b%2) for a,b in product(range(12),repeat=2) if (d*b)%12==0}
  remaining=set(secondary);n_orb=0
  while remaining:
    r,s,e=min(remaining)
    # For odd d the top beta line is in the image, so e is quotiented.
    if d%2: orbit={(r,s,0),(r,s,1)}
    else: orbit={(r,s,(e+b*r+a*s)%2) for a,b in H}
    n_orb+=1;remaining-=orbit
  expected=4 if d%2 else (6 if d%4==2 else 5)
  check(f'RANK2-RANK1-SHEAR-{d}',n_orb==expected)

# Odd/even determinant Chern-data existence: only tested NECESSARY K-integrality,
# not full sufficiency/desuspension (which remains imported from I-C).
check('CHERN-RANK2-CH4-NECESSARY',sp.simplify(c2sq/12-Delta/6)==0)
# Fixed-point index arithmetic (does not reprove Atiyah--Segal--Singer's formula).
A_,B_=sp.symbols('A_ B_', integer=True)
idx=sp.expand((B_**2-A_**2)/6)
local=sp.expand((A_+B_)/2)
mplus=sp.expand((idx+local)/2)
mminus=sp.expand((idx-local)/2)
check('BORNFIXED-INDEX-CHARACTER-MPLUS',sp.simplify(mplus-(B_**2-A_**2)/12-(A_+B_)/4)==0)
check('BORNFIXED-INDEX-CHARACTER-MMINUS',sp.simplify(mminus-(B_**2-A_**2)/12+(A_+B_)/4)==0)
check('BORNFIXED-EXOTIC-EXAMPLE', mplus.subs({A_:0,B_:12})==15 and mminus.subs({A_:0,B_:12})==9)
for aa,bb in product(range(-12,13),repeat=2):
  if (bb*bb-aa*aa)%12: continue
  plus4=sp.Rational(bb*bb-aa*aa,12)+sp.Rational(aa+bb,4)
  minus4=sp.Rational(bb*bb-aa*aa,12)-sp.Rational(aa+bb,4)
  single=((bb*bb-aa*aa+3*(aa+bb))%24==0)
  full=(plus4.q==1 and minus4.q==1 and plus4.p%2==minus4.p%2==0)
  if single!=full:
    raise AssertionError('BORNFIXED quaternionic congruence equivalence fails at '+str((aa,bb)))
check('BORNFIXED-QUATERNIONIC-24-CONGRUENCE',True,'Exhaustive admissible A,B in [-12,12]')
check('BORNFIXED-MIXED-RESTRICTION',sp.simplify(2*(A_+B_)-2*A_-2*B_)==0)
# Spin-c line twists preserve c2 because eta^2=0 and eta*c1=0.
check('SPINC-LINE-TWIST-C2-NILPOTENCE',ext((0,1),(0,1))[0]==0)
# Boundary adversarial cases: nonprimitive slopes break faithfulness, and
# topological fixed class never certifies an equivariant cocycle by itself.
check('BOUNDARY-NONPRIMITIVE-COCHAR',gcd(2,0,0,0)==2)
check('BOUNDARY-PURE-EXCHANGE-MISMATCH', (1,0,0,0)!=(0,1,0,0))
check('BOUNDARY-DETERMINANT-TYPE-DISTINCTION', 720!=180)

summary={'target':'Paper1B-M8Geometry-v1_131.tex','census':[0,63],
 'total_controls':len(CHECKS),'pass':sum(r['passed'] for r in CHECKS),
 'fail':sum(not r['passed'] for r in CHECKS),
 'groups':dict(Counter(r['id'].split('-')[0] for r in CHECKS)),
 'limitation':'Scoped E3/E4 finite algebra, not independent full low-rank obstruction classification.'}
from pathlib import Path
Path('/mnt/data/Paper1B-IndependentControlsBatch1Results-v1_1.json').write_text(json.dumps({'summary':summary,'checks':CHECKS},indent=2))
print(json.dumps(summary,indent=2))
