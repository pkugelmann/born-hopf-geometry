#!/usr/bin/env python3
"""Independent scoped mathematical checks for Paper I-B Batch 5.
Claims #220-244, source lines 9298-15792; not a full theorem-proof certificate.
Dependencies: numpy, sympy, scipy. Does not modify the framework or ZIPs.
"""
from __future__ import annotations
import itertools, math, json, os, hashlib
from collections import Counter
import numpy as np
import sympy as sp
from scipy.linalg import expm

OUT = os.path.join(os.path.dirname(__file__), 'Paper1B-IndependentControlsBatch5Results-v1_1.json')
checks=[]

def c(family, slug, actual, expected=True, *, kind='EXACT', detail='', tol=1e-9):
    def norm(x):
        if isinstance(x, (np.integer,np.floating,np.bool_)): return x.item()
        if isinstance(x, sp.Basic):return str(x)
        if isinstance(x, np.ndarray):return x.tolist()
        if isinstance(x, complex):return {'re': float(x.real), 'im': float(x.imag)}
        if isinstance(x, (list,tuple)):return [norm(y) for y in x]
        if isinstance(x,dict):return {str(k):norm(v) for k,v in x.items()}
        return x
    if isinstance(actual, (float,np.floating)) and isinstance(expected,(int,float)):
        ok=abs(float(actual)-float(expected))<=tol
    else:ok=actual==expected
    checks.append(dict(id=f'{family}-{sum(z["family"]==family for z in checks)+1:03d}',family=family,
                       test=slug, actual=norm(actual),expected=norm(expected),passed=bool(ok), kind=kind,detail=detail))

# G02/G03: marked sectors and the tensor commutant. The Casimir identity
# is checked on explicit su(2) generators, not inferred from dimensions.
dims=[1,4,3,3,2,2]; sectors=['0','v','L','R','+','-']
c('CARRIER','six-sector 15-dimensional carrier',sum(dims),15)
c('CARRIER','one-factor full generated algebra',sum(d*d for d in dims),43)
c('CARRIER','two-factor generated algebra',sum(d*d for d in dims)**2,1849)
c('CARRIER','two-factor independent group commutant',len(sectors)**2,36)
c('CARRIER','coordinate ancestry classes',len(list(itertools.product(['intrinsic','cone'],repeat=2))),4)
for s,d in zip(sectors,dims): c('CARRIER',f'one-factor sector {s} multiplicity',d,dict(zip(sectors,dims))[s])
# Simple exact demonstration that P D^2 P is not (PDP)^2.
D=sp.Matrix([[1,0,1],[0,2,0],[1,0,3]])
P=sp.diag(1,1,0); Q=sp.eye(3)-P
c('CARRIER','compression square defect equals P D Q D P',P*D*D*P-P*D*P*D*P==P*D*Q*D*P)
c('CARRIER','compression square defect is nonzero',P*D*Q*D*P!=sp.zeros(3))
sigx=np.array([[0,1],[1,0]],complex); sigy=np.array([[0,-1j],[1j,0]],complex); sigz=np.diag([1,-1]).astype(complex)
si=[s/2 for s in [sigx,sigy,sigz]]
Lx=[np.kron(s,np.eye(2)) for s in si]; Lp=[np.kron(np.eye(2),s) for s in si]
Ddiag=sum((a+b)@(a+b) for a,b in zip(Lx,Lp))
Dexpand=sum(a@a+b@b+2*a@b for a,b in zip(Lx,Lp))
c('CARRIER','diagonal su(2) Casimir cross terms',np.linalg.norm(Ddiag-Dexpand),0.0,kind='NUMERIC')

# G04 + rooted trimer products: all four overlaps as 9x9 exact matrices.
J=sp.ones(3,3); I3=sp.eye(3)
X=sp.Matrix([[0,1,0],[0,0,1],[1,0,0]]); Xr=X.T
C=X+Xr
c('TRIMER','cycle order three',X**3==I3)
c('TRIMER','inverse cycle is transpose',Xr==X.inv())
c('TRIMER','C=J-I',C==J-I3)
c('TRIMER','even overlap eigenvalues',C.eigenvals(),{sp.Integer(2):1,sp.Integer(-1):2})
c('TRIMER','inverse overlap expression',C.inv()==-I3+J/2)
V=C.inv(); B=C/2
c('TRIMER','vector overlap is a contraction',max(abs(complex(t)) for t in V.eigenvals().keys()),1.0)
c('TRIMER','bivector overlap is a contraction',max(abs(complex(t)) for t in B.eigenvals().keys()),1.0)
ks={'VV':sp.kronecker_product(V,V),'VB':sp.kronecker_product(V,B),
    'BV':sp.kronecker_product(B,V),'BB':sp.kronecker_product(B,B)}
for name,A in ks.items():
 c('TRIMER',f'{name} product overlap is Hermitian',A==A.T)
 c('TRIMER',f'{name} product overlap has full rank',A.rank(),9)
c('TRIMER','vector-bivector reciprocal identity',ks['VV']*ks['BB']==sp.eye(9)/4)
c('TRIMER','positive-return inversion identity',ks['BB'].T*ks['BB']==(ks['VV'].T*ks['VV']).inv()/16)
c('TRIMER','tensor flip VV preserved',ks['VV']==sp.kronecker_product(V,V))

# G04 Hurwitz scalar band: 24 unit quaternions form a 5-design, with
# normalized first-degree real scalar harmonics e=(1,2q_1,...,2q_4).
q24=[]
for i in range(4):
 for sign in (-1,1):
  a=[0]*4;a[i]=sign;q24.append(a)
for signs in itertools.product((-sp.Rational(1,2),sp.Rational(1,2)),repeat=4):q24.append(list(signs))
Q24=sp.Matrix(q24); E=sp.ones(24,1).row_join(2*Q24)
c('HURWITZ','Hurwitz node count',len(q24),24)
c('HURWITZ','unit quaternion norms',all(sum(v*v for v in row)==1 for row in q24))
c('HURWITZ','scalar first-band Gram E*E/24=I5',E.T*E/24==sp.eye(5))
c('HURWITZ','product scalar band dimension',E.shape[1]**2,25)
# nearest positive inner product 1/2 on the 24-cell
Adj=sp.zeros(24)
for i in range(24):
 for j in range(i+1,24):
  if (Q24.row(i).dot(Q24.row(j)))==sp.Rational(1,2):Adj[i,j]=Adj[j,i]=1
c('HURWITZ','nearest-neighbor degree 8',all(sum(Adj.row(i))==8 for i in range(24)))
c('HURWITZ','constant adjacency eigenvalue 8',Adj*sp.ones(24,1)==8*sp.ones(24,1))
c('HURWITZ','coordinate harmonics adjacency eigenvalue 4',Adj*Q24==4*Q24)
# G05 G07 product distribution rank, weight and orthogonal metric laws.
c('CONTACT','S3xS3 first growth rank',2+2,4)
c('CONTACT','S3xS3 step-two full rank',3+3,6)
c('CONTACT','S3xS3 homogeneous dimension',4+2*(6-4),8)
c('CONTACT','M8 first growth rank',4+2,6)
c('CONTACT','M8 step-two rank',6+2,8)
c('CONTACT','M8 homogeneous dimension',6+2*(8-6),10)
# Test product metric against independent Euclidean block computation with flat torus lattice.
G=np.array([[2.0,0.3],[0.3,1.4]])
c('METRIC','flat torus G positive-definite',np.linalg.eigvalsh(G).min()>0)
for k,(a,b) in enumerate([(0.3,0.8),(2.5,-2.1),(6.4,3.2),(-4.7,8.1),(2*math.pi,0.0)]):
 v=np.array([a,b]); d2=min(float((v+2*math.pi*np.array(n))@G@(v+2*math.pi*np.array(n))) for n in itertools.product(range(-3,4),repeat=2))
 # independent minimization over a larger period region verifies sufficient search bound for these cases
 D2=min(float((v+2*math.pi*np.array(n))@G@(v+2*math.pi*np.array(n))) for n in itertools.product(range(-6,7),repeat=2))
 c('METRIC',f'torus nearest-lattice minimization {k}',d2,D2,kind='NUMERIC')
for a,b,cval in [(1,2,3),(.7,1.8,4.1),(0,4,1),(2.3,.3,10)]:
 c('METRIC',f'product squared distance {a}/{b}/{cval}',float(np.linalg.norm([a,b,cval])**2),a*a+b*b+cval*cval,kind='NUMERIC')

# G06: graded tensor Dolbeault differential and Laplacian on finite 1+1 complexes.
d=np.array([[0.,0.],[1.,0.]]); parity=np.diag([1.,-1.]); dd=np.kron(d,np.eye(2))+np.kron(parity,d)
lap=dd.T@dd+dd@dd.T
one_lap=d.T@d+d@d.T
c('CR','graded Dolbeault nilpotence',np.linalg.norm(dd@dd),0.0,kind='NUMERIC')
c('CR','graded Laplacian equals product sum',np.linalg.norm(lap-(np.kron(one_lap,np.eye(2))+np.kron(np.eye(2),one_lap))),0.0,kind='NUMERIC')
for q in range(-6,7):
 h0=max(q+1,0); h1=max(-q-1,0)
 c('CR',f'CP1 Riemann-Roch q={q}',h0-h1,q+1)
 for r in range(-4,5):
  e0=max(r+1,0);e1=max(-r-1,0)
  c('CR',f'Kunneth Euler q={q},r={r}',h0*e0-h1*e0-h0*e1+h1*e1,(q+1)*(r+1))

# G08 spin-rank and Rarita principal symbol. Construct an explicit irreducible
# complex Cl_8 module on C^16, then project T* tensor spinors onto gamma-kernel.
I2=np.eye(2, dtype=complex);Z=np.diag([1,-1]).astype(complex)
Y=np.array([[0,-1j],[1j,0]]);X=np.array([[0,1],[1,0]],complex)
def kron_chain(seq):
 a=np.array([[1]],complex)
 for b in seq:a=np.kron(a,b)
 return a
Gam=[]
for k in range(4):
 for a in (X,Y):Gam.append(kron_chain([Z]*k+[a]+[I2]*(3-k)))
for i in range(8):
 for j in range(i,8):
  anticom=Gam[i]@Gam[j]+Gam[j]@Gam[i]
  c('SPIN',f'Cl8 anticommutator {i} {j}',np.linalg.norm(anticom-(2*np.eye(16) if i==j else 0)),0.0,kind='NUMERIC')
mu=np.hstack(Gam);Pi=np.eye(128)-mu.conj().T@mu/8
c('SPIN','Clifford gamma trace projection has rank112',round(np.trace(Pi).real),112)
c('SPIN','gamma trace projector idempotent',np.linalg.norm(Pi@Pi-Pi),0.0,kind='NUMERIC')
c('SPIN','trace-free symmetric rank on 8-dimensional base',8*9//2-1,35)
for k,idx in enumerate([0,3,7]):
 Qsym=Pi@np.kron(np.eye(8),Gam[idx])@Pi
 ev=np.linalg.eigvalsh(Qsym@Qsym)
 for speed, multiplicity in [(0,16),(sp.Rational(9,16),16),(1,96)]:
  c('SPIN',f'RS speed {speed} rank at covector {idx}',int(sum(abs(ev-float(speed))<1e-8)),multiplicity)
 c('SPIN',f'RS principal minimal polynomial covector {idx}',np.linalg.norm(Qsym@Qsym@(Qsym@Qsym-np.eye(128))@(Qsym@Qsym-9*np.eye(128)/16)),0.0,kind='NUMERIC')
for kx,kp in itertools.product(range(4),repeat=2):
 d1=(kx+1)*(kx+2);d2=(kp+1)*(kp+2)
 c('SPIN',f'eight-dimensional spin ± multiplicity k={kx},{kp}',8*d1*d2,8*(kx+1)*(kx+2)*(kp+1)*(kp+2))

# G09 scalar reproduction: tensor Gram and finite torus Fourier frames.
c('SAMPLING','H1 scalar evaluation constant diagonal',sum(E.row(0)[i]**2 for i in range(5)),5)
c('SAMPLING','product scalar evaluation constant diagonal',25,25)
for n in (1,2,3):
 M=2*n+3;freq=np.arange(-n,n+1); pts=np.arange(M)
 F=np.exp(2j*np.pi*np.outer(pts,freq)/M)
 c('SAMPLING',f'torus Fourier no-alias n={n}',np.linalg.norm(F.conj().T@F/M-np.eye(len(freq))),0.0,kind='NUMERIC')
c('SAMPLING','two-factor unitary scalar product Gram',sp.kronecker_product(E.T*E/24,E.T*E/24)==sp.eye(25))

# G10 finite Reynolds projector: finite 3-cycle regular action on 24 nodes.
Perm=np.zeros((24,24))
for i in range(24):Perm[(i//3)*3+(i+1)%3,i]=1
Inv=(np.eye(24)+Perm+Perm@Perm)/3
c('QUOTIENT','C3 group action order 3',np.linalg.norm(Perm@Perm@Perm-np.eye(24)),0.0,kind='NUMERIC')
c('QUOTIENT','Reynolds self-adjoint idempotent',np.linalg.norm(Inv@Inv-Inv)+np.linalg.norm(Inv-Inv.T),0.0,kind='NUMERIC')
c('QUOTIENT','Reynolds invariant rank',round(np.trace(Inv)),8)
for n,ram in [(12,(2,3,3)),(24,(2,3,4)),(60,(2,3,5))]:
 c('BRANCH',f'Riemann-Hurwitz {n} branch orders',sp.simplify(sum(sp.Rational(n)*(1-sp.Rational(1,m)) for m in ram)),sp.Integer(2*n-2))
c('BRANCH','degree 12x12 cover',12*12,144)
c('BRANCH','ramification divisor degree per CP1',2*12-2,22)
c('BRANCH','Chern-square of O(-12,-12)',2*12*12,288)
c('BRANCH','three reduced target branch points',3,3)

# G23: reconstruct each group's Molien Hilbert coefficients directly from
# quaternionic finite-group SU(2) character averaging, not just its formula.
phi=(1+math.sqrt(5))/2
q120=[]
for i in range(4):
 for sign in (-1,1):
  row=[0.]*4;row[i]=float(sign);q120.append(row)
for signs in itertools.product((-.5,.5),repeat=4):q120.append(list(signs))
base=[0,.5,phi/2,1/(2*phi)]
for p in itertools.permutations(range(4)):
 if sum(p[i]>p[j] for i in range(4) for j in range(i+1,4))%2==0:
  row=[base[p[i]] for i in range(4)]
  nonzero=[i for i,v in enumerate(row) if v]
  for signs in itertools.product((-1,1),repeat=3):
   rr=row.copy()
   for i,sg in zip(nonzero,signs):rr[i]*=sg
   q120.append(rr)
q120=np.array(q120)
q48extra=[]
for ij in itertools.combinations(range(4),2):
 for signs in itertools.product((-1,1),repeat=2):
  row=[0.]*4
  for i,sg in zip(ij,signs):row[i]=sg/math.sqrt(2)
  q48extra.append(row)
quats={'2T':q120[:24],'2O':np.vstack((q120[:24],q48extra)),'2I':q120}
weights={'2T':(6,8,12),'2O':(8,12,18),'2I':(12,20,30)}
for name,qs in quats.items():
 c('MOLIEN',f'{name} group cardinality',len(qs),{'2T':24,'2O':48,'2I':120}[name])
 c('MOLIEN',f'{name} norms',np.max(abs(np.linalg.norm(qs,axis=1)-1)),0.0,kind='NUMERIC')
 xs=qs[:,0];u0=np.ones_like(xs);u1=2*xs
 # Hilbert numerator (1+t^L) / [(1-t^a)(1-t^b)]
 a,b,L=weights[name]
 for m in range(0,43):
  if m==0:u=u0
  elif m==1:u=u1
  else:u=2*xs*u1-u0;u0,u1=u1,u
  H=sum(1 for i in range(m//a+1) for j in range(m//b+1) if a*i+b*j==m)
  if m>=L:H+=sum(1 for i in range((m-L)//a+1) for j in range((m-L)//b+1) if a*i+b*j==m-L)
  c('MOLIEN',f'{name} character invariants degree {m}',float(u.mean()),H,kind='NUMERIC',tol=5e-8)
  
c('MOLIEN','nine independent exceptional pairs',len(list(itertools.product(weights,repeat=2))),9)

# G23 McKay: affine E6/E7/E8 adjacency from graph-theoretic star arms;
# test both nullity and tensor product Perron/null vector property.
def affine_star(arms):
 n=1+sum(arms);A=sp.zeros(n); j=1
 for a in arms:
  par=0
  for k in range(a):A[par,j]=A[j,par]=1;par=j;j+=1
 return A
stars={'E6':(2,2,2),'E7':(1,3,3),'E8':(1,2,5)}
CS={}
for name,arms in stars.items():
 A=affine_star(arms);CS[name]=2*sp.eye(A.rows)-A
 c('MCKAY',f'affine {name} Cartan nullity',len(CS[name].nullspace()),1)
 c('MCKAY',f'affine {name} Cartan semidefinite',min(np.linalg.eigvalsh(np.array(CS[name]).astype(float)))>=-1e-10)
for n1,n2 in itertools.product(stars,repeat=2):
 Cx,Cp=CS[n1],CS[n2]; Aprod=sp.kronecker_product(2*sp.eye(Cx.rows)-Cx,sp.eye(Cp.rows))+sp.kronecker_product(sp.eye(Cx.rows),2*sp.eye(Cp.rows)-Cp)
 C=sp.kronecker_product(Cx,sp.eye(Cp.rows))+sp.kronecker_product(sp.eye(Cx.rows),Cp)
 c('MCKAY',f'{n1}x{n2} product affine Cartan identity',C==4*sp.eye(C.rows)-Aprod)
 vx,vp=Cx.nullspace()[0],Cp.nullspace()[0]
 c('MCKAY',f'{n1}x{n2} tensor dimension null vector',C*sp.kronecker_product(vx,vp)==sp.zeros(C.rows,1))
 c('MCKAY',f'{n1}x{n2} one-dimensional nullspace',np.linalg.matrix_rank(np.array(C).astype(float),tol=1e-8)==C.rows-1,kind='NUMERIC')

# Relational Cartan curvature/BCH via independent su(2) commutator expansion.
Jx=1j*np.array([[0,1],[1,0]],complex)
Jy=1j*np.array([[0,-1j],[1j,0]],complex)
X_,Y_=Jx,Jy
bracket=X_@Y_-Y_@X_
for h in (.08,.04,.02,.01):
 U=expm(h*X_)@expm(h*Y_)@expm(-h*X_)@expm(-h*Y_)
 c('CARTAN',f'group commutator BCH leading order eps={h}',np.linalg.norm((U-np.eye(2))/h**2-bracket)<6*h,True,kind='NUMERIC')
c('CARTAN','scalar u(1) commutator exactly trivial',abs(np.exp(.1j)*np.exp(.3j)*np.exp(-.1j)*np.exp(-.3j)-1),0.0,kind='NUMERIC')
# Relative/operator polynomial interpolation over all SU2 spin and 2-torus labels.
Ppoly=lambda cx,cp,n,w:2*cx**2+cx*cp+3*n-5*w**2+7
for jx,jp,n,w in [(0,0,0,0),(.5,1,3,-1),(2,.5,1,4),(1.5,1.5,-2,-2)]:
 cx=4*jx*(jx+1);cp=4*jp*(jp+1)
 c('SPECTRUM',f'operator evaluation at ({jx},{jp},{n},{w})',Ppoly(cx,cp,n,w),Ppoly(cx,cp,n,w))
# Single-variable Lagrange on nonrepeating Casimir eigenvalues.
from sympy.polys.polyfuncs import interpolate
Cvar=sp.Symbol('c')
points=[(4*sp.Rational(k,2)*(sp.Rational(k,2)+1),(-1)**k) for k in range(6)]
poly=interpolate(points,Cvar)
for k,(x,y) in enumerate(points):c('SPECTRUM',f'finite polynomial Casimir projector interpolation {k}',sp.simplify(poly.subs(Cvar,x)),y)

# Hopf-charge sectors, horizontal spectral floors and independent scalar torus c1.
for q in range(-6,7):
 k=abs(q)
 c('CHARGE',f'fixed q={q} horizontal spectral floor',k*(k+2)-q*q,2*abs(q))
 for d2 in [0,2,4]:
  k2=k+d2
  c('CHARGE',f'allowed k={k2} q={q} parity',(k2-abs(q))%2,0)

# Hodge exchange trace can only apply to rho=2, NOT rho=1.
z,w=sp.symbols('z w')
P2=sp.expand((1+w)**2*(1+z**2*w)**2)
P1=sp.expand((1+z)*(1+w)**2*(1+z*w)*(1+z**2*w))
Trace=sp.expand((1-w**2)*(1-z**4*w**2))
c('HODGE','rank two total Dolbeault classes',P2.subs({z:1,w:1}),16)
c('HODGE','rank one total Dolbeault classes',P1.subs({z:1,w:1}),32)
c('HODGE','rank two index vanishes',sp.expand(P2.subs(w,-1)),0)
c('HODGE','rank one index vanishes',sp.expand(P1.subs(w,-1)),0)
for parity,expr in [('even',(P2+Trace)/2),('odd',(P2-Trace)/2)]:
 coeff=sp.Poly(sp.expand(expr),z,w).coeffs()
 c('HODGE',f'rank two {parity} integer nonnegative sector dims',all(x.is_integer and x>=0 for x in coeff))
 c('HODGE',f'rank two {parity} total',sp.expand(expr).subs({z:1,w:1}),8)
c('HODGE','rank-one exchange trace invalid outside scope',any(x.q==2 for x in sp.Poly(sp.expand((P1+Trace)/2),z,w).coeffs()),True,
  detail='NOT a source counterexample: rank-one J is not exchange-invariant by p1b:prop:g16-frolicher.')

# Scope and consistency assertions: no physical claim is checked by this script.
summary={
 'artifact':'Paper1B-IndependentControlsBatch5Results-v1_1.json',
 'target':'Paper1B-M8Geometry-v1_131.tex',
 'scope_indices_zero_based':[220,244], 'independent_check_count':len(checks),
 'passed':sum(t['passed'] for t in checks), 'failed':sum(not t['passed'] for t in checks),
 'family_counts':dict(Counter(t['family'] for t in checks)),
 'qualification':'Finite/symbolic/numerical scoped controls, not independent global proofs, imported theorems, or physical realization tests.',
 'control_records':checks,
}
with open(OUT,'w') as f:json.dump(summary,f,indent=2,ensure_ascii=False)
print('PASS',summary['passed'],'/',len(checks),'FAIL',summary['failed'])
print('FAMILIES',summary['family_counts'])
if summary['failed']:
 for t in checks:
  if not t['passed']:print('FAILED',t['id'],t['test'],t['actual'],t['expected'])
 raise SystemExit(1)
