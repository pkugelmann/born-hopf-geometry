#!/usr/bin/env python3
"""Paper I-B Batch 9 scoped E3/E4 controls: indices 401..446.
Reproducible arithmetic/finite-matrix tests only; no claim of re-proving
unstable bundle classification, all-spin spectral completeness or global gauge descent.
"""
import json, math, itertools, sys
from pathlib import Path
import numpy as np
import sympy as sp
from scipy.linalg import null_space
B=Path('/mnt/data'); records=[]

def check(family,label,ok,details=None,kind='E3_EXACT'):
    try: yes=bool(ok)
    except Exception: yes=False
    records.append(dict(family=family,label=str(label),passed=yes,kind=kind,details=str(details)[:350] if details is not None else None))
    if not yes: raise AssertionError(f'{family}: {label}: {details}')

def f2rank(rows,n=5):
    a=[int(v) for v in rows];r=0
    for col in range(n):
      v=next((i for i in range(r,len(a)) if (a[i]>>col)&1),None)
      if v is None:continue
      a[r],a[v]=a[v],a[r]
      for j in range(len(a)):
       if j!=r and ((a[j]>>col)&1):a[j]^=a[r]
      r+=1
    return r

# F2^5 torsion monodromy: two transpositions, one fixed bit
# Transform basis e0->e0, e1->e1+e0, e2->e2, e3->e3+e2, e4->e4.
N=[0,1,0,4,0]
def Nmap(v):return (v>>1&1) | ((v>>3&1)<<2)
image={Nmap(v) for v in range(32)};kernel={v for v in range(32) if Nmap(v)==0}
check('TWISTED_LOOPS','N^2=0',all(Nmap(Nmap(v))==0 for v in range(32)))
check('TWISTED_LOOPS','rank N=2',len(image)==4)
check('TWISTED_LOOPS','ker N dim3',len(kernel)==8)
check('TWISTED_LOOPS','carry H1=ker/im has 2 cosets',len(kernel)//len(image)==2)
for v in sorted(kernel):
   rank=f2rank(N+[v]); check('TWISTED_LOOPS',f'carry {v:05b}',rank in (2,3) and (rank==2)==(v in image),{'torsion_cokernel_cardinality':2**(5-rank)})
check('TWISTED_LOOPS','trivial-component invariants',len(kernel)==8)
check('TWISTED_LOOPS','trivial-component odd H=Z2',len(kernel)//len(image)==2)
check('TWISTED_LOOPS','trivial-component even H=Z2^2',2*len(kernel)//len(image)==4)
for d in range(-25,26):
  gd=math.gcd(3,d)
  check('TWISTED_LOOPS',f'd={d} endpoint step',4*(3//gd) in (4,12))
  if d%2==0:
    check('TWISTED_LOOPS',f'd={d} z0=2 bound',4*gd*8<=96)
    check('TWISTED_LOOPS',f'd={d} z0=8 bound',8*gd*8<=192)

# Mathematical 137-simplex frame of I-A: analytic Gram, frame operator and dense coefficient bounds.
d=136;n=d+1;eta=sp.Rational(1,2)
for i,j in [(0,0),(0,1),(52,52),(52,101)]:
 v=sp.Rational(1) if i==j else -sp.Rational(1,d)
 trace=sp.factor(sp.Rational(1,n)+(d*eta/sp.Integer(n))*(v/eta)) # trace(Ei Dj) = (1+d* dot)/n
 check('TOMOGRAPHY',f'dual Gram {i},{j}',trace==(1 if i==j else 0),trace)
check('TOMOGRAPHY','traceless effect frame',eta**2/(n*d)==sp.Rational(1,74528))
# Build a traceless Hermitian basis on M11⊕M4 and numeric 137-simplex using Householder.
rs=np.random.default_rng(1126)
F=[]
for blockstart,bs in [(0,11),(11,4)]:
  for i in range(bs):
   for j in range(i+1,bs):
    a=np.zeros((15,15),dtype=complex);a[blockstart+i,blockstart+j]=a[blockstart+j,blockstart+i]=2**(-.5);F.append(a)
    b=np.zeros((15,15),dtype=complex);b[blockstart+i,blockstart+j]=1j/np.sqrt(2);b[blockstart+j,blockstart+i]=-1j/np.sqrt(2);F.append(b)
# traceless diagonal basis for all 15 coordinates (block-diagonal still retains common scalar trace)
for k in range(1,15):
  a=np.zeros((15,15),dtype=complex);a[:k,:k]=np.eye(k)/np.sqrt(k*(k+1));a[k,k]=-k/np.sqrt(k*(k+1));F.append(a)
check('TOMOGRAPHY','basis dimension 136',len(F)==136)
# Simplex columns of one Householder reflection, with final column equal normalized ones vector.
u=np.ones(n)/np.sqrt(n);e=np.zeros(n);e[-1]=1;w=e-u;w=w/np.linalg.norm(w)
Q=np.eye(n)-2*np.outer(w,w);V=np.sqrt(n/d)*Q[:,:d]
check('TOMOGRAPHY','simplex unit Gram',np.linalg.norm(V@V.T-(n/d*np.eye(n)-np.ones((n,n))/d))<1e-10,kind='E3_NUMERICAL')
F=np.asarray(F);Bmat=np.tensordot(V,F,axes=(1,0));E=(np.eye(15)[None,:,:]+float(eta)*Bmat)/n
D=(np.eye(15)/15)[None,:,:]+(d/float(eta))*Bmat
for count in range(10):
 coeff=rs.normal(size=136);A=np.eye(15)*(rs.normal()/15)+np.tensordot(coeff,F,axes=(0,0))
 qs=np.einsum('nij,ji->n',E,A); rec=np.tensordot(qs,D,axes=(0,0))
 check('TOMOGRAPHY',f'complex native inverse #{count}',np.linalg.norm(A-rec)<1e-8,kind='E3_NUMERICAL')
 check('TOMOGRAPHY',f'HS estimate #{count}',np.linalg.norm(A)<=np.sqrt(n*d)/float(eta)*np.linalg.norm(qs)+1e-8,kind='E3_NUMERICAL')
 check('TOMOGRAPHY',f'projector frame dual #{count}',np.linalg.norm(np.einsum('nij,ji->n',E,rec)-qs)<1e-8,kind='E3_NUMERICAL')

# Finite Hermitian response sharpness, exact polynomial counts and source jet check.
w=sp.symbols('w');
M1=w+sp.Rational(13,7)/(-3-w)+sp.Rational(4,3)/(2-w)
M2=w-1+sp.Rational(1,3)/(-1-w)+sp.Rational(34,7)/(4-w)
diff=sp.factor(M1-M2)
expected=(w*w+1)*(w*w+4)/((-3-w)*(-1-w)*(2-w)*(4-w))
check('RESPONSE','sharp rational identity',sp.simplify(diff-expected)==0)
for z in [sp.I,2*sp.I]:check('RESPONSE',f'sharp zero z={z}',sp.simplify(diff.subs(w,z))==0)
check('RESPONSE','sharp nonzero z=3i',sp.simplify(diff.subs(w,3*sp.I))!=0)
C1=sp.diag(-3,2);C2=sp.diag(-1,4)
B1=sp.Matrix([[sp.sqrt(sp.Rational(13,7)),sp.sqrt(sp.Rational(4,3))]])
B2=sp.Matrix([[sp.sqrt(sp.Rational(1,3)),sp.sqrt(sp.Rational(34,7))]])
for C,Bb,Ai in [(C1,B1,0),(C2,B2,1)]:
 parent=sp.BlockMatrix([[sp.Matrix([[Ai+10]]),Bb], [Bb.T,C+10*sp.eye(2)]]).as_explicit()
 check('RESPONSE','positive shifted parent (Sylvester)',all(sp.det(parent[:k,:k])>0 for k in [1,2,3]))
# Numeric randomized response frames; self-adjoint reality and 5-point overdetermined uniqueness detection
for _ in range(12):
  cs=rs.uniform(-3,3,4);bs=rs.normal(size=4);A0=rs.normal()
  def response(z):return z-A0+sum(bs[i]**2/(cs[i]-z) for i in range(4))
  check('RESPONSE','Hermitian reality',abs(response(1+.7j).conjugate()-response(1-.7j))<1e-11,kind='E3_NUMERICAL')
  # Independently interpolate the numerator after clearing real poles.
  dd=np.poly1d([1.0]);
  for c in cs: dd=np.polymul(dd,np.poly1d([-1.0,c]))
  # The cleared pole part is a polynomial of degree <=3.
  xs=np.array([.3+.31*i for i in range(7)])
  ys=np.array([np.polyval(dd,x)*(response(x)-(x-A0)) for x in xs])
  fit=np.polyfit(xs,ys,3)
  check('RESPONSE','cleared 4-pole numerator degree<=3',np.max(np.abs(np.polyval(fit,xs)-ys))<1e-7,kind='E3_NUMERICAL')
# Explicit source jet: rational resolvent derivative for diagonal C(t)
t,z=sp.symbols('t z', real=True)
res=(t+2-z)**-1;check('RESPONSE','first resolvent jet',sp.simplify(sp.diff(res,t)+res**2)==0)
check('RESPONSE','second resolvent jet',sp.simplify(sp.diff(res,t,2)-2*res**3)==0)

# Gibbs covariance under swap or random unitary, and degenerate ground caution.
from scipy.linalg import expm
for delta in [0.001,0.01,0.1,0.7,1,3]:
  for beta in [.01,.1,1,3]:
    eps=delta;dist=2*math.tanh(beta*delta/2)
    check('GIBBS',f'sharp bound gap {delta} beta {beta}',dist <=min(2,beta*eps)+1e-12)
    check('GIBBS',f'old bound gap {delta} beta {beta}',dist <=2*min(1,beta*eps)+1e-12)
check('GIBBS','optimal tangent coefficient 1',abs(2*math.tanh(1e-6/2)/1e-6-1)<1e-10,kind='E3_NUMERICAL')
for a in range(10):
   X=rs.normal(size=(5,5))+1j*rs.normal(size=(5,5));H=(X+X.conj().T)/2
   Y=rs.normal(size=(5,5))+1j*rs.normal(size=(5,5));Z=Y-Y.conj().T
   U=expm(Z*.17);beta=.2+rs.random()*3
   er,vec=np.linalg.eigh(H);rho=(vec*np.exp(-beta*er))@vec.conj().T;rho=rho/np.trace(rho)
   dr=U@rho@U.conj().T-rho;trace_norm=np.linalg.svd(dr,compute_uv=False).sum()
   eps=np.linalg.norm(H@U-U@H,2)
   check('GIBBS',f'random 5x5 sharp covariance #{a}',trace_norm <=min(2,beta*eps)+2e-10,kind='E3_NUMERICAL')
# Ground gap P full and selected substate countercheck
H=np.diag([0.,0.,2.,5.]);U=np.diag([-1.,1.,1.,1.]);eps=np.linalg.norm(H@U-U@H)
P=np.diag([1.,1.,0.,0.]);rho=P/2
check('GIBBS','full degenerate ground invariant',np.linalg.norm(U@rho@U.conj().T-rho)<1e-12)
psi=np.array([1.,1.,0.,0.])/np.sqrt(2);rhopsi=np.outer(psi,psi.conj())
check('GIBBS','partial degenerate ground need not invariant',np.linalg.norm(U@rhopsi@U.conj().T-rhopsi)>1)

# Central blocks: even observables commute with block central shifts; odd connectors and global Gibbs reveal centers.
for count in range(14):
 n1,n2=2,3
 X=rs.normal(size=(5,5))+1j*rs.normal(size=(5,5));H=sp.zeros(5)
 Hn=np.zeros((5,5),complex);Hn[:2,:2]=(X[:2,:2]+X[:2,:2].conj().T)/2;Hn[2:,2:]=(X[2:,2:]+X[2:,2:].conj().T)/2
 c1,c2=rs.uniform(-3,3,2);C=np.diag([c1]*2+[c2]*3)
 even=np.zeros((5,5),complex);even[:2,:2]=rs.normal(size=(2,2));even[2:,2:]=rs.normal(size=(3,3))
 odd=np.zeros((5,5),complex);odd[:2,2:]=rs.normal(size=(2,3))
 check('CENTRAL',f'even commutator #{count}',np.linalg.norm((Hn+C)@even-even@(Hn+C)-(Hn@even-even@Hn))<1e-12,kind='E3_NUMERICAL')
 check('CENTRAL',f'odd commutator #{count}',np.linalg.norm((Hn+C)@odd-odd@(Hn+C)-(Hn@odd-odd@Hn)-(c1-c2)*odd)<1e-12,kind='E3_NUMERICAL')

# SU2 fundamental group data, topological signs, Chern-Simons and scalar gaps are conditional on imported proofs.
for iota2 in range(1,12):
 iota=sp.Rational(iota2,2);dval=iota+sp.Rational(1,2)
 if dval.q==1:
   Ii=sp.factor(dval*(4*dval*dval-1)/3)
   check('SPATIAL_INDEX',f'isospin {iota} integer index',Ii.q==1)
   check('SPATIAL_INDEX',f'isospin {iota} index parity',int(Ii)%2==int(dval)%2)
for c in [1,-1]:
  check('SPATIAL_LIFTS',f'central sign at +I={c}',c*c==1)
  check('SPATIAL_LIFTS',f'central sign at -I={c}',(-c)*(-c)==1)
check('SPATIAL_LIFTS','four fixed sign classes',len(list(itertools.product([1,-1],repeat=2)))==4)

# Spin matrices in dimensions 2j+1. Compare all j/iota blocks with source-specified signed spectra.
def spinmat(j2):
    j=j2/2; mvals=np.arange(-j,j+1,1);dim=j2+1
    plus=np.zeros((dim,dim),complex)
    for idx,m in enumerate(mvals[:-1]):plus[idx+1,idx]=math.sqrt((j-m)*(j+m+1))
    minus=plus.conj().T
    return [(plus+minus)/2, (plus-minus)/(2j), np.diag(mvals)]
pauli=spinmat(1);pauli=[2*x for x in pauli]
for ji in range(0,7):
 for ii in range(0,7):
  j=ji/2;iota=ii/2
  J=spinmat(ji);I=spinmat(ii)
  dim=(ji+1)*(ii+1)*2
  mat=np.eye(dim,dtype=complex)*1.5
  for k in range(3):
   mat+=2*np.kron(np.kron(J[k],np.eye(ii+1)),pauli[k])+np.kron(np.kron(np.eye(ji+1),I[k]),pauli[k])
  got=np.linalg.eigvalsh(mat)
  expected=[]
  # possible total spins: first pair J+I; then add spin 1/2
  ks=set()
  for a2 in range(abs(ji-ii),ji+ii+1,2):
   for k2 in [abs(a2-1),a2+1]:ks.add(k2)
  for k2 in sorted(ks):
   kval=k2/2;L=j+kval;delta=j-kval;tau=iota-.5;p=iota+.5
   if ii>=1 and abs(L-tau)<1e-9 and abs(delta)<=tau+1e-9:
       expected += [delta]*(k2+1)
   elif abs(abs(delta)-p)<1e-9 and L>=p-1e-9:
       expected += [-np.sign(delta)*(L+1)]*(k2+1)
   elif ii>=1 and L>=p-1e-9 and abs(delta)<=tau+1e-9:
       root=math.sqrt(max(0,L*(L+2)+delta**2-tau*(tau+2)))
       expected += [root]*(k2+1)+[-root]*(k2+1)
   else:raise AssertionError(('unassigned',ji,ii,k2,L,delta))
  check('MIDPOINT_DIRAC',f'j={j} iota={iota} signed eigenvalues',len(expected)==len(got) and np.max(np.abs(got-np.sort(expected)))<2e-10,kind='E3_NUMERICAL')

# Low-rank matrix protected zero line and its Neumann reconstruction, odd-block index one.
for case in range(20):
  a=.7+rs.random()*3;b=.1+rs.random()*2
  # grading diag (+,+,-) with + index one
  B0=np.array([[0,0,a],[0,0,0],[a,0,0]],dtype=float)
  psi0=np.array([0.,1.,0.]);P=np.outer(psi0,psi0)
  G=np.array([[0,0,1/a],[0,0,0],[1/a,0,0]])
  v=(.05+rs.random()*.35)*a
  V=np.array([[0,0,0],[0,0,v],[0,v,0]])
  K=np.eye(3)+G@V
  psi=np.linalg.solve(K,psi0)
  e=np.linalg.eigvalsh(B0+V)
  check('PROTECTED_LINE',f'single index zero #{case}',np.min(np.abs(e))<2e-12 and np.count_nonzero(np.abs(e)<1e-9)==1,kind='E3_NUMERICAL')
  check('PROTECTED_LINE',f'schur Neumann zero #{case}',np.linalg.norm((B0+V)@psi)<1e-12,kind='E3_NUMERICAL')
  check('PROTECTED_LINE',f'fixed P component #{case}',np.linalg.norm(P@psi-psi0)<1e-12,kind='E3_NUMERICAL')
  check('PROTECTED_LINE',f'gap bound #{case}',min(abs(x) for x in e if abs(x)>1e-9) >= a-v-1e-10,kind='E3_NUMERICAL')

# Spatial cohomology on the trivial free⊕(J2)^2⊕1 module checked algebraically.
check('DESCENT','trivial component cohomology positive-odd C2',2**(3-2)==2)
check('DESCENT','trivial component cohomology positive-even C2²',2**(3-2+1)==4)
for d0 in range(-24,25):
  gd=math.gcd(3,d0);kd=3//gd
  check('DESCENT',f'free Chern increment d={d0}',4*kd!=0)
  if d0%2==0:
   check('DESCENT',f'finite quotient bound z0=2 d={d0}',4*gd*8<=96)
   check('DESCENT',f'finite quotient bound z0=8 d={d0}',8*gd*8<=192)

out={'artifact':'Paper1B-IndependentControlsBatch9Results-v1_1.json','scope':'Paper I-B census #401-446, E3/E4 bounded controls, source-v2.371','independent_agents':False,'total':len(records),'passed':sum(r['passed'] for r in records),'failed':sum(not r['passed'] for r in records),'families':{k:sum(r['family']==k for r in records) for k in sorted({r['family'] for r in records})},'controls':records,'method_limitations':['Finite example checks do not replace global bundle or spectral completeness proofs.','No separate human agents.','Numerical eigenspectrum comparisons are tolerance-dependent.']}
(B/'Paper1B-IndependentControlsBatch9Results-v1_1.json').write_text(json.dumps(out,indent=2))
print('RESULT',out['total'],out['passed'],out['failed'],out['families'])
