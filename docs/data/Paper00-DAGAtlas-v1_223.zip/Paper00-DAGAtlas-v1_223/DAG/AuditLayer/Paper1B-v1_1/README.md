# Paper I-B registered full source-proof audit

Source: Paper1B-M8Geometry-v1_131.tex, v2.371; 483/483 source statements, 415 proof environments.
This directory registers one review layer of the existing global theorem DAG; it does not replace the canonical graph.
Start with Index.json, SourceCensus.json, AuditClaimLedger.json, TypedDependencyEdges.json and ProofRoutes.json.
Material edges: reviewed source proof uses only. QuarantinedCandidateEdges.json is navigation, not traversable proof.
GapRegistry.json carries all 11 inherited evidence obligations and mathematically supported impacts.
BatchEvidence and Evidence contain all ten preserved checkpoints and independent finite controls.
No physical action occurrence or particle selection is asserted.
