# Born–Hopf Geometry — DAG Semantic Audit v1_8

**Target:** source-native noncentral hierarchy incidence; intrinsic best-approximation characterization of the **existing** rooted negative-Hopf polar triple. Continuation of `BH-G-000113`, `BH-VA-G-0007`, and the conditional `p5:def:v228-hierarchy-origin` certificate.  
**Authoritative paper archive:** `Paper00-PapersMinimal-v3_023(1).zip` (31 `.tex` sources).  
**Previous atlas:** `Paper00-DAGAtlas-v1_163.zip`; **previous audit:** `Paper00-DAGSemanticAudit-v1_7.zip`.  
**Scope:** bounded source-first mathematical verification and an explicitly *audit-derived* sharp lemma. NOT a full Paper V-A/V-B audit, new physical source claim, paper revision, or upgrade of any inherited physical obligation.

## Verdict

**MATHEMATICAL E3:** From the *source's own* rank-one root projector `P=|c><c|`, unitary `W=R_-`, Paper V-B's canonical polar arrows, and Paper V-A's published hierarchy-corner defect, one can **uniquely characterize the nearest zero-defect source matrix and the nearest unitary zero-defect source matrix to W** in the fixed Hilbert–Schmidt chart. The characterizations are exact, sharp, and require no terminal mass, fit or new geometrical selector:

\[
\boxed{\min_{R\ne0\,,\Delta_{\rm hier}(R)=0}\|W-R\|_{\rm HS}^2=\frac29,\quad
R_{\min}=B_e^{\rm pol}+s B_\mu^{\rm pol}+s B_\tau^{\rm pol},}
\]
\[
\boxed{\min_{U\in U(3)\,,\Delta_{\rm hier}(U)=0}\|W-U\|_{\rm HS}^2
=4-\frac{8\sqrt2}{3},\quad U_{\min}=B_e^{\rm pol}+B_\mu^{\rm pol}+B_\tau^{\rm pol}.}
\]
Here `s=2sqrt(2)/3`. Uniqueness is in the **fixed rooted chart**, without allowing free changes of the source or target geometry. The unitary minimizer is exactly the *previously published* canonical polar triple's unweighted sum; the variational characterization is new to this audit, **not** the construction of the arrows.

**E4 boundary:** Neither a minimum-distance law nor an instruction to insert `R_min`/`U_min` is specified in the occurring fermion action. The original `W` is a structural *charged-current* relation, not an independently evaluated chiral mass-source mixed derivative. Hence this mathematical lemma **does not discharge** `Cert_hier`, actual source ownership, any of the nine comparison-port operations, kinetic/normalization placement, or the physical pole/rest interface. Status: `PARTIALLY_AUDITED; WITH_OPEN_PHYSICAL_SELECTION_CONDITIONS; NO_NEW_REFUTATION`.

## 1. Exact imported source claims and scope

| Imported source label | Current source | Consumed content and boundary |
|---|---|---|
| `p5:prop:v3211-hopf-crossing-commutator` | Paper5A v3.211, ~5430 | `W=diag(1,i,-i)`, `c=(1,1,1)/sqrt(3)`, rooted crossing norms `8/9`; **current** relation, not mass-source member |
| `p5:thm:v3211-hierarchy-corner-defect` | Paper5A v3.211, ~5491 | `Delta_hier` nonnegative; zero iff `D=0`, `rank C<=1`, `C^* A=C B^*=0`; nonzero blocks give a three-arrow transport |
| `p6:thm:v240-canonical-polar-hopf-triple` | Paper5B v5.200, ~6327 | Equivariant polar arrows `B_e,B_mu,B_tau`, unit left returns, no fitted values; explicit **physical-source origin firewall** |
| `p5:thm:v392-rooted-member-owner-readout` | Paper5A v3.211, ~5023 | Primitive rooted member has family-identity `I_G`, not automatically a noncentral hierarchy member |
| `p5:cor:v3211-primitive-mixed-jet-centrality` | Paper5A v3.211, ~5463 | Family-blind uninserted primitive jet has no rooted off-diagonal crossing |
| `p5:thm:v397-charged-preterminal-srcval-realization` | Paper5A v3.211, ~5281 | Physical charged source handoff **conditional** on independently certified hierarchy arrows |
| `p6:cor:v5124-owner-selection-open` | Paper5D v1.54, ~2994 | Distinct actual chiral/exterior/Hodge/loop/rest certificates remain unresolved |
| `p5:def:v228-hierarchy-origin` | Paper5A v3.211, ~3307 | Required independently generated hierarchy-arrow source condition |

The accompanying `Ledger/SourceClaims.json` gives exact source filenames, current label lines, and verified SHA-256s. No historical TeX version was substituted.

## 2. A general sharp lemma already implicit in the published geometry

Let `W in U(3)`, `c` a fixed unit singlet, `P=cc*`, `Q=I-P`, `a=c* W c`, and `s=sqrt(1-|a|^2)` with `0<|a|<1`. Define the Paper V-B projectors

\[
P_\mu=s^{-2}QWPW^*Q,\qquad P_e=Q-P_\mu,
\]

and its three **already published** partial isometries

\[
 B_e=P_eWQ,\quad B_\mu=s^{-1}QWP,\quad B_\tau=s^{-1}PWQ.
\]

The source theorem proves their mutually orthogonal left/right returns. Put

\[
 T:=B_e+sB_\mu+sB_\tau=P_eWQ+QWP+PWQ,\qquad
 U:=B_e+B_\mu+B_\tau.
\]

### E3.1. Singular values of the augmentation compression

From `W W*=I` and rank-one `P`, one has

\[
 CC^*=QWQW^*Q=Q-QWPW^*Q=P_e+|a|^2P_\mu,
 \qquad C:=QWQ.
\]

Thus the two singular values of `C` acting on the 2D augmentation are **exactly** `1,|a|`, and `B_e` is its unique best rank-one Hilbert–Schmidt approximation for `0<|a|<1` (Eckart–Young in this *two-dimensional* setting; alternatively diagonalize the explicit displayed return). In particular

\[
\|C-B_e\|_{\rm HS}^2=|a|^2.
\]

### E3.2. Nearest zero-defect **unconstrained-amplitude** matrix

For any `R` with `Delta_hier(R)=0`, Paper V-A gives `PRP=0` and `rank(QRQ)<=1`. The four rooted corners are mutually orthogonal in the Hilbert–Schmidt inner product, so

\[
\begin{aligned}
\|W-R\|_{\rm HS}^2={}&\|PWP\|_{\rm HS}^2
 +\|QWP-QRP\|_{\rm HS}^2
 +\|PWQ-PRQ\|_{\rm HS}^2\\
 &+\|QWQ-QRQ\|_{\rm HS}^2
 \;\ge\; |a|^2+|a|^2=2|a|^2.
\end{aligned}
\]

Equality requires both crossings to equal those of `W` and `QRQ=B_e` by uniqueness of the rank-one truncation. Exactly `T` realizes all equalities, and `B_e^*QWP=0`, `B_e(PWQ)^*=0` show `Delta_hier(T)=0`, with all three arrows nonzero. Hence **unique attainment** by `T`.

### E3.3. Nearest zero-defect **unitary** matrix

If additionally `R=U'` is unitary, the zero singlet corner forces `||QU'P||_HS=||PU'Q||_HS=1` and the rank-one augmentation block has singular value 1. The existing `W` cross blocks have norm `s`. Therefore each of the two cross-block deviations is at least `(1-s)^2`, with equality precisely when the corresponding arrow is the normalized existing `B_mu` or `B_tau`. The `D` and `C` blocks cost at least `|a|^2` each. Thus

\[
\|W-U'\|_{\rm HS}^2\ge 2|a|^2+2(1-s)^2=4(1-s).
\]

The published unweighted sum `U` is unitary and has zero defect; it attains the bound. Uniqueness follows from the strict singular-value gap `1>|a|` plus equality in each cross-block Cauchy–Schwarz inequality. This is a **global result over all unitary zero-defect matrices in the fixed chart**, not merely a minimization within a guessed candidate family.

### E3.4. Specialization to the actual rooted negative-Hopf parent

For `W=diag(1,i,-i)` and `c=(1,1,1)/sqrt(3)`, `a=1/3`, `s=2sqrt(2)/3`, giving

\[
 \|W-T\|_{\rm HS}^2=2/9,\qquad
 \|W-U\|_{\rm HS}^2=4-8\sqrt2/3.
\]

Paper V-A's *original* defect of the unreduced `W` evaluates to

\[
 \Delta_{\rm hier}(W)=\frac{52}{729}>0,
\]

while `Delta_hier(T)=Delta_hier(U)=0`. The `W` corner norms are `||PWP||²=1/9`, `||QWP||²=||PWQ||²=8/9`, `||QWQ||²=10/9`, `||C* A||²=||CB*||²=8/81`, with `sigma_C=1/9` and `N=3`, reproducing the exact defect. This is *not* a refutation of `W`: `W` was declared a current relation, not a zero-defect chiral mass source.

## 3. Independent commuting-class adversarial control

Since the three eigenvalues of `W=diag(1,i,-i)` are distinct, every unitary commuting with `W` is diagonal. For `V=diag(z_1,z_2,z_3)` with `|z_j|=1`, the zero-defect unitary condition is `c*Vc=0`, i.e. `z_1+z_2+z_3=0`. Three unit phases sum to zero iff, up to a common phase and permutation, they are the cube roots `1,omega,omega²` with `omega=exp(2pi i/3)`. Maximizing `Re Tr(W* V)` over that finite family and the global phase gives `1+sqrt(3)`. Hence

\[
 \boxed{\min_{\substack{V\in U(3),\ [V,W]=0\\\Delta_{\rm hier}(V)=0}}
 \|W-V\|_{\rm HS}^2=4-2\sqrt3.}
\]

It is **strictly larger** than `4-8sqrt(2)/3` by `8sqrt(2)/3-2sqrt(3)>0`. Thus the *root-sensitive* published polar construction wins in this precise Hilbert–Schmidt comparison. A commuting unitary zero-defect example nonetheless **exists**, namely `diag(1,omega,omega²)`: the result does **not** prove that noncommuting constructions are logically required for hierarchy structure. Nor does it turn minimal Hilbert–Schmidt distance into a physical action principle.

## 4. What this does and does not close

The new best-approximation property is a **rigidity/optimality theorem for the already defined geometric triple**. It eliminates arbitrary *orientation choice* for a particular **mathematical nearest-point question**, while leaving the real source route unchanged.

| Proposed implication | Audit status | Why |
|---|---|---|
| Existing `W,P` uniquely produce `T` and `U` as nearest zero-defect candidates in stated classes | **E3 proved** | Exact blockwise lower bounds and unique equality witnesses |
| `T,U` satisfy source's three-arrow hierarchy-corner test | **E3 proved** | Existing canonical polar triple and exact replay |
| Actual independently varied fermion action chooses the Hilbert–Schmidt-nearest candidate | **NOT ESTABLISHED** | No such selection law appears in the consumed action; physical jet is a different sort from current relation |
| `Cert_hier` of Paper V-A thereby discharged | **NO** | Requires independently generated and source-consumed chiral incidence arrow, not a geometric candidate |
| Nine polar grades from `24/25` thereby selected | **NO** | The defect is invariant under scalar rescaling; chiral/exterior/Hodge placement remains uncomputed |
| Physical charged pole/rest masses independently predicted | **NO PROMOTION** | Physical action/source-to-pole interface remains distinct |

The two original issue roots stay OPEN:

- **`BH-VA-G-0007`** (Paper V-A `p5:prop:v221-charged-comparison-source-scope`): independently establish actual same-action left/right comparison-port placement and its relation to the chiral mixed jet. This is the upstream physical source-port obligation.
- **`BH-G-000113`** (Paper V-B `p6:thm:v591-owner-provenance-charged-grades`): independently establish which exterior/Hodge/reciprocal words and chiral frames are consumed by *each of the nine roles* before terminal coefficients are read out. Mathematical existence of available words alone is not enough.

The separate antecedent **`p5:def:v228-hierarchy-origin` / `Cert_hier`** remains a required *conditional input* to `p5:thm:v397-charged-preterminal-srcval-realization`, without creating a duplicate issue node. No new counterexample to any current source theorem is asserted.

## 5. Evidence, ledger and DAG effect

- **47/47 exact symbolic replay checks passed** under `Evidence/replay_v1_8.py`; those cover core projection identities, rank-one SVD, actual source defect, both equality witnesses, commuting control, scale independence, and a second real-unitary control.
- All targeted source labels were reanchored and current source file hashes checked against `DAG/CurrentSourceAnchorMap-v3_023.json` and the actual v3_023 TeX bytes. A successful source hash is an **E0** integrity check, not an E3 proof.
- One **audit-derived proposition** is registered under `BH-SA18-LEMMA-NEAREST-ROOTED-HIERARCHY`; its mathematical proof is entirely in this report and it is not silently added as a source theorem label.
- Existing `5,335` canonical material edges and `5,406` proof routes retain their exact bytes/hashes. New audit-layer relations are **nontraversable evidence/scope links**, not material proof-route edges.
- No new source theorem, physical root, comparison grade, source-action coefficient, mass fit, parameter, or proof status is created; no upstream theorem is reopened.

**Next actual physical test:** independently evaluate the mixed chiral source of the native action, test its `Delta_hier`, `Tr(B_r^* M_s)` and full Hilbert–Schmidt remainder, and compare its *source-generated* comparison placements with the nine port matrix **before** applying terminal mass coefficients. If a native principle establishes proximity-to-`W` as a physical source equation, it must be sourced and proved rather than inferred from the optimization. Otherwise this mathematically sharp nearest-point result remains a candidate, not a physical derivation.
