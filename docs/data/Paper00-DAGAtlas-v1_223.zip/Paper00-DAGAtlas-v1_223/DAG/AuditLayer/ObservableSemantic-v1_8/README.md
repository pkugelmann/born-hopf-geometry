# Born–Hopf DAG Semantic Audit v1_8

Target: sharp metric characterization of the existing rooted Hopf three-arrow geometry, with source-action provenance firewalls.

The report contains a full mathematical proof; `Evidence/replay_v1_8.py` independently replays 47 exact symbolic checks. `Ledger` contains current source-hash anchors, audit-only dependency/scope links, inherited issue IDs, and explicit nonpromoting proof-route semantics. No actual charged physical source selection is claimed.

**Canonical material graph remains unchanged.** The successor DAG Atlas is `Paper00-DAGAtlas-v1_164.zip`.
