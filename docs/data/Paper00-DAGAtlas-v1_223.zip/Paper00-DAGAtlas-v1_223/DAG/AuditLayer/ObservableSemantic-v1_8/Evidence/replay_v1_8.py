#!/usr/bin/env python3
"""Exact arithmetic audit of the published rooted Hopf triple.
Requires SymPy; runs without external data or internet.
This is a mathematical-source check, NOT physical source certification.
"""
import sympy as sp
from itertools import permutations
import json,os

I=sp.I
E=sp.eye(3)
c=sp.ones(3,1)/sp.sqrt(3)
P=c*c.H;Q=E-P
W=sp.diag(1,I,-I)
a=sp.simplify((c.H*W*c)[0])
sq=sp.simplify(1-sp.conjugate(a)*a)
s=sp.sqrt(sq)
Pm=sp.simplify(Q*W*P*W.H*Q/sq)
Pe=sp.simplify(Q-Pm)
Be=sp.simplify(Pe*W*Q)
Bm=sp.simplify(Q*W*P/s)
Bt=sp.simplify(P*W*Q/s)
R=sp.simplify(Be+s*Bm+s*Bt)
U=sp.simplify(Be+Bm+Bt)
checks=[]
def chk(name,cond,detail=None):
    if not bool(cond):raise AssertionError(name+': '+str(detail))
    checks.append(dict(id=f'E3-{len(checks)+1:02}',name=name,status='PASS',value=None if detail is None else str(detail)))
def eq(x,y):return sp.simplify(x-y)==0
def mat0(x):return all(eq(el,0) for el in x)
def norm2(M):return sp.simplify(sp.trace(M.H*M))
def delta(R):
    D=P*R*P;A=Q*R*P;B=P*R*Q;C=Q*R*Q
    N=norm2(R)
    CS=sp.simplify(C.H*C)
    sig=sp.simplify((sp.trace(CS)**2-sp.trace(CS*CS))/2)
    return sp.simplify(norm2(D)/N+(norm2(C.H*A)+norm2(C*B.H)+sig)/N**2)

chk('root norm',eq((c.H*c)[0],1))
chk('root projector',mat0(P*P-P))
chk('augmentation projector',mat0(Q*Q-Q))
chk('orthogonal split',mat0(P*Q))
chk('W unitary',mat0(W.H*W-E))
chk('scalar return',eq(a,sp.Rational(1,3)),a)
chk('cross norm squared',eq(sq,sp.Rational(8,9)),sq)
chk('rooted Pmu rank-one projector',mat0(Pm*Pm-Pm) and eq(sp.trace(Pm),1))
chk('rooted Pe rank-one projector',mat0(Pe*Pe-Pe) and eq(sp.trace(Pe),1))
chk('Pe and Pmu orthogonal',mat0(Pe*Pm))
chk('cross A norm',eq(norm2(Q*W*P),sq))
chk('cross B norm',eq(norm2(P*W*Q),sq))
chk('canonical Be return',mat0(Be*Be.H-Pe))
chk('canonical Bmu return',mat0(Bm*Bm.H-Pm))
chk('canonical Btau return',mat0(Bt*Bt.H-P))
chk('orthogonality Be Bmu',mat0(Be*Bm.H))
chk('orthogonality Be Btau',mat0(Be*Bt.H))
chk('orthogonality Bmu Btau',mat0(Bm*Bt.H))
chk('C singular squares',set(sp.simplify((Q*W*Q).H*(Q*W*Q)).eigenvals().keys())=={0,1,sp.Rational(1,9)})
chk('C positive singular gap',eq(sp.simplify(sp.trace((Q*W*Q).H*(Q*W*Q))),sp.Rational(10,9)))
chk('C best rank-one residual norm',eq(norm2(Q*W*Q-Be),sp.Rational(1,9)))
chk('C best-rank-one remains orthogonal to Be',mat0(Be.H*(Q*W*Q-Be)) and mat0(Be*(Q*W*Q-Be).H))
chk('source projection in zero hierarchy class',eq(delta(R),0),delta(R))
chk('source projection has nonzero A B C',all(not eq(norm2(M),0) for M in [Q*R*P,P*R*Q,Q*R*Q]))
chk('source projection singlet corner zero',mat0(P*R*P))
chk('source projection source C rank one',eq(sp.simplify(sp.trace((Q*R*Q).H*(Q*R*Q))),1) and eq(sp.simplify(sp.trace(((Q*R*Q).H*(Q*R*Q))**2)),1))
chk('exact nearest source projection squared distance',eq(norm2(W-R),sp.Rational(2,9)),norm2(W-R))
chk('source projection equals published weighted arrows',mat0(R-(Be+s*Bm+s*Bt)))
chk('unweighted polar U unitary',mat0(U.H*U-E))
chk('unweighted U hierarchy defect zero',eq(delta(U),0),delta(U))
chk('unweighted U singlet zero',eq((c.H*U*c)[0],0))
chk('unweighted U squared distance',eq(norm2(W-U),4-sp.Rational(8,3)*sp.sqrt(2)),norm2(W-U))
chk('unweighted general formula 4(1-s)',eq(norm2(W-U),4*(1-s)))
chk('W hierarchy defect nonzero',eq(delta(W),sp.Rational(52,729)),delta(W))
chk('identity hierarchy defect baseline',eq(delta(E),sp.Rational(4,9)),delta(E))
chk('rooted change noncommutes with W',not mat0(W*U-U*W))

omega=sp.exp(2*sp.pi*I/3)
vals=[sp.simplify(sp.expand_complex(sp.trace(W.H*sp.diag(*pi))*sp.conjugate(sp.trace(W.H*sp.diag(*pi))))) for pi in permutations((1,omega,omega**2))]
chk('diagonal/cyclic phase optimizer',all(sp.simplify(v-(4+2*sp.sqrt(3)))==0 or sp.simplify(v-(4-2*sp.sqrt(3)))==0 for v in vals),list(map(str,vals)))
chk('best commuting distance squared',eq(6-2*sp.sqrt(max(vals,key=lambda x:float(x.evalf()))),4-2*sp.sqrt(3)))
chk('commuting restriction strictly worse',sp.simplify((sp.Rational(8,3)*sp.sqrt(2))**2-(2*sp.sqrt(3))**2)>0)
Ucomm=sp.diag(1,omega,omega**2)
chk('commuting zero-defect witness',mat0(Ucomm.H*Ucomm-E) and mat0(Ucomm*W-W*Ucomm) and eq(delta(Ucomm),0))
chk('commuting zero-defect witness norm',eq(sp.expand_complex(norm2(W-Ucomm)),4-2*sp.sqrt(3)))
chk('graded scalar invariance of hierarchy for t',eq(delta((2*sp.sqrt(6)/5)*R),0))
chk('graded scalar invariance of hierarchy for t inverse',eq(delta((5/(2*sp.sqrt(6)))*R),0))

# A second exact three-family unitary verifies the general formula independent of R_-.
W2=sp.diag(1,1,-1)
a2=sp.simplify((c.H*W2*c)[0]);s22=sp.simplify(1-a2**2);s2=sp.sqrt(s22)
Pm2=sp.simplify(Q*W2*P*W2.H*Q/s22);Pe2=sp.simplify(Q-Pm2)
Be2=sp.simplify(Pe2*W2*Q);Bm2=sp.simplify(Q*W2*P/s2);Bt2=sp.simplify(P*W2*Q/s2)
U2=sp.simplify(Be2+Bm2+Bt2);R2=sp.simplify(Be2+s2*Bm2+s2*Bt2)
chk('independent real-unitary cross amplitude',eq(a2,sp.Rational(1,3)) and eq(s22,sp.Rational(8,9)))
chk('independent real-unitary minimal source exact',eq(norm2(W2-R2),2*a2**2))
chk('independent real-unitary minimal unitary exact',eq(norm2(W2-U2),4*(1-s2)))
chk('independent real-unitary three-arrow unitary',mat0(U2.H*U2-E))

out={
 'scope':'E3 exact algebra; no charged physical action source selected',
 'claim':'Unique closest zero-defect matrices to native rooted R_- under fixed Hilbert-Schmidt chart',
 'source_labels':['p6:thm:v240-canonical-polar-hopf-triple','p5:thm:v3211-hierarchy-corner-defect','p5:prop:v3211-hopf-crossing-commutator','p6:cor:v5124-owner-selection-open'],
 'checks_count':len(checks), 'checks':checks,
 'computed':{'a':str(a),'s':str(s),'delta_W':str(delta(W)),'delta_identity':str(delta(E)), 'C_singular_values':['1','1/3'],'R_min_distance_squared':str(norm2(W-R)),'U_min_distance_squared':str(norm2(W-U)),'commuting_unitary_distance_squared':'4-2*sqrt(3)', 'source_conclusion':'NOT_PHYSICAL_PORT_CERTIFIED'},
 'mathematical_proof_required':'Sharp inequalities and uniqueness proved in accompanying Markdown; finite replay independently checks exact attaining witnesses and control spectra.'
}
p=os.path.join(os.path.dirname(__file__),'replay_results_v1_8.json')
with open(p,'w') as f:json.dump(out,f,indent=2)
print('PASS',len(checks),'exact checks; results',p)
