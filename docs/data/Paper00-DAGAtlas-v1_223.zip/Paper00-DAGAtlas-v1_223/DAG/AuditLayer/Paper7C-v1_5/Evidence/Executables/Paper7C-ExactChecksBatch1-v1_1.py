"""Scoped independent exact-moment and counterexample checks for Paper VII-C batch 1.
External QFT/physical-realization premises are not discharged by these algebra checks.
"""
import sympy as S, json, pathlib
k,n,t,L=S.symbols('k n t L', integer=True, nonnegative=True)
D=S.factor(S.summation((n+1)**2,(n,0,k)))
T2=S.factor(S.summation((n+1)**2*n*(n+2)/3,(n,0,k))/D)
T4=S.factor(S.summation((n+1)**2*n*(n+2)*(3*n*(n+2)-4)/15,(n,0,k))/D)
checks={
 'frontier_dimension':S.simplify(D-(k+1)*(k+2)*(2*k+3)/6)==0,
 'second_directional_moment':S.simplify(T2-k*(k+3)/5)==0,
 'fourth_directional_moment':S.simplify(T4-k*(k+3)*(3*k*k+9*k-5)/35)==0,
 'normalized_second_limit':S.limit(T2/k**2,k,S.oo)==S.Rational(1,5),
 'normalized_fourth_limit':S.limit(T4/k**4,k,S.oo)==S.Rational(3,35),
 'massless_energy_integral':S.integrate(4*S.pi*L**2*L,(L,0,1))/(2*S.pi)**3==1/(8*S.pi**2),
 'one_dimensional_marginal_normalized':S.integrate(S.Rational(3,4)*(1-L*L),(L,-1,1))==1,
 'one_dimensional_second_moment':S.integrate(S.Rational(3,4)*(1-L*L)*L**2,(L,-1,1))==S.Rational(1,5),
 'one_dimensional_fourth_moment':S.integrate(S.Rational(3,4)*(1-L*L)*L**4,(L,-1,1))==S.Rational(3,35),
 'ground_degeneracy_counterexample':S.simplify(S.exp(-t)!=1),
 'rank_one_positive_control':S.simplify(S.exp(-t)-S.exp(-t))==0,
}
assert all(checks.values()),checks
out={
 'scope':'Exact finite scalar representation controls and transfer-degeneracy E4 only',
 'source':'Paper7C-ContinuousQFT-v2_195.tex',
 'checks':{key:bool(val) for key,val in checks.items()},
 'derived_formulas':{
  'D_k':str(D),
  'tau_Q3_squared':str(T2),
  'tau_Q3_fourth':str(T4),
  'q3_fourth_scaled_limit':str(S.limit(T4/k**4,k,S.oo)),
  'counterexample_H':'diag(0,0,1)',
  'counterexample_Omega':'(1,0,0)',
  'counterexample_gap':1,
  'actual_transfer_norm_on_Omega_perp':'1',
  'claimed_transfer_norm_on_Omega_perp':'exp(-t)',
  'rank_one_control_H':'diag(0,1)',
  'rank_one_control_norm_on_Omega_perp':'exp(-t)'
 },
 'caveat':'No exhaustive upstream provenance certification, no interacting analytic continuum proof, no independent agent used.'
}
path=pathlib.Path('/mnt/data/audit7c_work/Paper7C-ExactChecksBatch1-v1_1.json');path.write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
