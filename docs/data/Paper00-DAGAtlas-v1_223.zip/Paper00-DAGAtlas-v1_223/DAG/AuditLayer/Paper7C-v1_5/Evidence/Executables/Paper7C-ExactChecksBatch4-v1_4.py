"""Independent E3/E4 checks for Paper VII-C named claims #139-192.
Source-as-printed scope, no TeX or global DAG changes, no physical interpolation invented.
"""
from pathlib import Path
import sympy as s
import json, hashlib
P=Path('/mnt/data/audit7c_work'); chk=[]
def rec(eid, nums, level, description, passed, evidence, scope):
    q={'evidence_id':f'VIIC-{level}-B4-{eid}','claim_numbers':nums,'level':level,'check':description,'passed':bool(passed),'exact_evidence':str(evidence),'scope_limit':scope}
    chk.append(q)
    if not passed:raise AssertionError(q)

x,t,u,ell,k,Lam,m,om,a,b,r,z,phi=s.symbols('x t u ell k Lam m om a b r z phi',real=True,positive=True)
# Heat representative exact on a compact circle, with 0<u<1.
w=1+u*s.exp(-t/2)*s.cos(x)
Ss=-s.log(w)
res=s.simplify(s.diff(Ss,t)-s.diff(Ss,x,2)/2+s.diff(Ss,x)**2/2)
rec('139H',[139],'E3','Compact-circle heat representative and Hamilton--Jacobi logarithm',res==0,f'S_t-Delta(S)/2+|grad S|²/2 = {res}', 'tau>=0, 0<u<1, smooth positive circle heat data; not spacetime heat/RG identification')
# Gaussian covariance shell + explicit scalar Gaussian convolution.
cc=s.exp(-m/Lam**2)/m-s.exp(-m/k**2)/m
rec('139C',[139,140],'E3','Endpoint derivative of heat-shell covariance',s.simplify(k*s.diff(cc,k)+2*s.exp(-m/k**2)/k**2)==0, f'dC/d(log k)={s.simplify(k*s.diff(cc,k))}', 'Positive scalar eigenvalue, special zero eigenvalue separate')
V=s.log(1+m*z)/2+m*x*x/(2*(1+m*z))
rec('139G',[139],'E3','Gaussian convolution quadratic interaction satisfies heat nonlinear flow',s.simplify(s.diff(V,z)-(s.diff(V,x,2)-s.diff(V,x)**2)/2)==0, 'V(C,x)=log(1+m C)/2+m x²/[2(1+m C)]','Assumes m>0 and Gaussian field split; not an exact expression for a general Haar action')
# zero mode shell and lower bound by monotonicity
rec('140Z',[140],'E3','Zero eigenvalue shell and finite-window norm bounds',s.simplify(s.limit(cc,m,0)-(k**(-2)-Lam**(-2)))==0,f'C(0)={s.limit(cc,m,0)}','Assumes 0<k<Lambda and a fixed finite spectral ceiling')
# Affine support: positive tilted two-point distribution x=(1,y) with y=+-1.
p=s.symbols('p',real=True,positive=True)
var=s.simplify(4*p/(1+p)**2)
rec('141',[141,143],'E3','Positive non-degenerate affine support covariance, exterior kernel',var>0 if isinstance(var,bool) else var.subs(p,2)>0, 'For weights p:1 on y=+-1, covariance diag(0,4p/(1+p)^2); kernel spanned by (1,0)','Finite positive tilted law; does not extend to signed/Grassmann measures')
# Finite EAA Gaussian has exactly one-loop-shaped but nonperturbative trace identity.
R=s.symbols('R',real=True,positive=True)
Gamma=m*phi**2/2+s.log((m+R)/(2*s.pi))/2
rec('142',[142,143],'E3','Finite Gaussian modified Legendre transform flow',s.simplify(s.diff(Gamma,R)-1/(2*(m+R)))==0, f'dGamma/dR={s.diff(Gamma,R)}=G/2','One real Gaussian mode with UV measure e^{-m x²/2} dx, R>0')
# Linear Born involution parity, including allowed +-- term.
y=s.symbols('y',real=True);g=x*x+y*y+a*x*y*y
rec('144',[144,145],'E3','Linear Born vertex parity distinguishes +-- from ++-',s.simplify(g.subs(y,-y)-g)==0 and s.diff(g,x,y).subs({x:0,y:0})==0 and s.diff(g,x,y,2).subs({x:0,y:0})==2*a, 'Gamma(x,-y)=Gamma(x,y); Gamma_xy(0)=0; Gamma_xyy(0)=2a ≠0','J=diag(+1,-1) is LINEAR orthogonal and background is J fixed')
# Smooth nonlinear involution E4 counterexample to mixed field selection rule #147.
xx=s.symbols('xx',real=True)
h=xx+xx*xx
B=(-1+s.sqrt(1-4*h))/2
f=h*h
ch=s.simplify(s.expand(h.subs(xx,B)+h))
inv=s.simplify(s.expand(f.subs(xx,B)-f))
third=s.diff(f,xx,3).subs(xx,0)
rec('147',[146,147],'E4','Smooth nonlinear Born involution invalidates ordinary third-vertex parity',ch==0 and inv==0 and s.diff(B,xx).subs(xx,0)==-1 and third==12,f"h(B)+h={ch}, f(B)-f={inv}; B(0)=0, Bprime(0)=-1, f'''(0)={third}; constant Gamma_s=f makes reflected family C^infinity",'Actual nonlinear B smooth local; DOES NOT attack the linear orthogonal J case of #144; impacts field derivative parity only, not #146 jet parity or beta equivariance')
# Reflected beta stability matrix and spectrum
A=s.Matrix([[0,2],[3,0]]); J=s.diag(1,-1)
rec('148149',[148,149,150],'E3','Born-reflected beta anticommutation and symmetric stability spectrum',A*J+J*A==s.zeros(2) and A.charpoly().as_expr()==s.Symbol('lambda')**2-6, f'A={A.tolist()}, J={J.tolist()}, characteristic polynomial={A.charpoly().as_expr()}','Autonomous flow tangent at a true beta fixed point; no conclusion about physical QG relevance count')
# Moving field chart linear S=e^{a ell}, R=e^{b ell}, gaussian EAA
Gmov=m*(phi/s.exp(a*ell))**2/2+s.log((m+s.exp(b*ell))/(2*s.pi))/2
Rhat=s.exp((b-2*a)*ell)
Gh=s.exp(2*a*ell)/(m+s.exp(b*ell))
lhs=s.simplify(s.diff(Gmov,ell)+a*phi*s.diff(Gmov,phi))
rhs=s.simplify(Gh*(s.diff(Rhat,ell)+2*a*Rhat)/2)
rec('151',[151],'E3','Moving-field-chart EAA convective derivative and regulator connection',s.simplify(lhs-rhs)==0,f'LHS={lhs}, RHS={rhs}','1d positive Gaussian, S=e^{a ell}, R=e^{b ell}; full transformed measure/Jacobian retained')
# UV fixed limit and necessary Newton scaling
q=s.symbols('q',real=True,positive=True)
Gk=q/k**2; gN=k**2*Gk; ZN=1/(16*s.pi*Gk)
eta=-k*s.diff(s.log(ZN),k)
rec('154156',[154,156],'E3','Autonomous convergent limit and d=4 Newton stationary anomalous dimension',gN==q and eta==-2 and s.simplify((2+eta)*gN)==0, f'g_N={gN}, eta_N={eta}, beta_g={(2+eta)*gN}; T_s x=e^s x fixes x=0','Newton identity is necessary only, not a gravitational fixed-point construction')
# Laurent balance exact Euler identity with nontrivial r dependence
rr,zz,lam=s.symbols('rr zz lam',real=True)
ff=rr*rr+3*rr+4; pp=s.simplify(rr*s.diff(ff,rr)-ff)
re=s.simplify(4*zz*(ff-2*lam)-2*rr*zz*s.diff(ff,rr)-2*zz*(ff-pp-4*lam))
rec('157',[157,158],'E3','Laurent--Legendre fixed-function Euler scaling',re==0, f'f={ff}; p=rfprime-f={pp}; balance residual={re}', 'Stationary dimensionless profile and couplings; does not prove RG invariance of profile family')
# Blocking second derivatives contain covariance, not naive same-action derivative
pA=s.exp(-a)/(1+s.exp(-a))
Seff=-s.log(1+s.exp(-a))
rec('160',[159,160,175],'E3','Exact 2-point conditional blocking: source first and second derivative',s.simplify(s.diff(Seff,a)-pA)==0 and s.simplify(s.diff(Seff,a,2)+pA*(1-pA))==0, f'Seff_a=p={pA}; Seff_aa=-p(1-p), whereas E[S_aa]=0', 'Exact blocking composition; higher responses include connected covariance terms, not a naive linear source-derivative pushforward')
# Schur pole and raw source residue independent
z0=s.symbols('z0',real=True)
DD=s.Matrix([[z0,1],[1,1]]);j=s.Matrix([1,2]);Fresp=s.simplify((j.T*DD.inv()*j)[0])
res=s.limit((z0-1)*Fresp,z0,1)
rec('161',[161,177],'E3','Simple Schur pole: energy derivative and complement-source term',res==1,f'D=[[z,1],[1,1]], z*=1, j=(1,2); j^T D^-1 j={Fresp}; residue={res}','Finite real Hermitian analytic quadratic branch; NOT an interacting physical electron pole')
# Primitive E1 profile and decoupling
y0=s.symbols('y0',real=True,positive=True)
der=s.simplify(k*s.diff(s.expint(1,y0/k**2),k)-2*s.exp(-y0/k**2))
rec('162',[162,163],'E3','Exponential-integral shell threshold integration',der==0, f'd/dlogk E1(m²/k²) = 2exp(-m²/k²); residual={der}','Primitive Gaussian heat representative, not universal exact interacting RG function')
# Current source response delta at energy 2
omega=s.symbols('omega',real=True)
chi=4/(4+omega**2)
dq=s.simplify((chi.subs(omega,0)-chi)/omega**2)
rec('164',[164],'E3','One-current positive spectral measure Fourier/difference quotient',s.simplify(dq-1/(4+omega**2))==0 and s.limit(dq,omega,0)==s.Rational(1,4), f'mu=delta_(Delta=2), chi=4/(4+omega²), (chi0-chi)/omega²={dq}, endpoint=1/4', 'Finite normalized vacuum; no zero atom, contact held separate')
# gapless spectral measure with finite inverse-cubic moment
Delta=s.symbols('Delta',real=True,positive=True)
first=s.integrate(Delta**4/Delta,(Delta,0,1)); cubic=s.integrate(Delta**4/Delta**3,(Delta,0,1))
rec('164G',[164,165],'E3','Gapless current spectral law can have finite inverse-cubic moment',first==s.Rational(1,4) and cubic==s.Rational(1,2), f'dmu=Delta^4 dDelta on (0,1): int Delta^-1 dmu={first}, int Delta^-3 dmu={cubic}; inf supp=0','Mathematical non-gapped positive spectral model; no asserted native QCD realization')
# Uniform cubic bounded not uniform IR integrable: vanishing weighted atom.
vals=[]
for n in [2,3,10,100]:
 w=s.Rational(1,n)**3; en=s.Rational(1,n);vals.append((n,w/en**3,w/en))
rec('165',[165],'E4','Uniform inverse-cubic moment bound does not imply IR uniform integrability',all(e==1 for _,e,_ in vals),f'dmu_L=(1/L)^3 delta_(1/L), cubic moment=1, inverse first->0; values={vals}', 'Confirms printed necessity of UI; not a refutation of #165, which explicitly assumes UI')
# Scalar source normalized determinant derivative sea response
aa=s.symbols('aa',real=True,positive=True)
d1=aa+1; d2=aa+3; Z=d1+d2
Sbar=2/Z
G2=(1/d1+1/d2)/Z
cov=s.simplify(G2-Sbar*Sbar)
expr=s.simplify(s.diff(Sbar,aa)+G2-cov)
rec('170',[169,170,171],'E3','Finite vectorlike scalar derivative includes determinant-weight sea covariance',expr==0 and cov.subs(aa,1)==s.Rational(1,72), f'two gauge configs D1=m+1 D2=m+3, det weights D_i: mean G={Sbar}, mean G²={G2}, cov(m=1)={cov.subs(aa,1)}; derivative identity residual={expr}', 'One-dimensional positive determinant toy model; tests exact normalized expectation identity, not native overlap source occurrence')
# scheme comparison ordered matrix quotient
VB=s.diag(2,3);VS=s.Matrix([[1,2],[3,4]]);C=VS*VB.inv()
rec('173',[172,173,174],'E3','Unique finite scheme matrix coordinate comparison on noncritical chart',C*VB==VS and VB.det()!=0, f'VBH={VB.tolist()}, VS={VS.tolist()}, C={C.tolist()}', 'Common already-matched scalar source subspace and projection; not a calculation of physical conversion')
# same observable across nonunique cluster states
AA=s.eye(2);BB=s.diag(1,-1)
rec('176',[176],'E3','Observable converges despite alternating distinct cluster states',(s.Matrix([1,0]).T*AA*s.Matrix([1,0]))[0]==(s.Matrix([0,1]).T*AA*s.Matrix([0,1]))[0] and (s.Matrix([1,0]).T*BB*s.Matrix([1,0]))[0] != (s.Matrix([0,1]).T*BB*s.Matrix([0,1]))[0],'Alternating pure states |e1>,|e2> on M2, identity observable value 1 in both; sigma_z differs','Shows theorem scope for a single bounded observable, not unique QFT state')
# K16 stationary bound threshold
ratio=s.Rational(357732,10000)/ (s.Rational(50457,10000)*10**9)
rec('181',[180,181],'E3','Numerical stationary H/T rate benchmark',abs(float(ratio)-7.0898e-9)<1e-12, f'35.7732/(5.0457e9)={ratio}, decimal={float(ratio)}','Stationary tangent only, not actual dynamical post-K16 H or sufficient gamma>>H')
# K16 WKB relation vs independent RG heat regulator: E4 type mismatch.
# At a=1, n=1, m_s=2, p=1 fixed. Gaussian shell exists at k=1 or 1/2 for Lambda=10.
cp=lambda kk:s.simplify((s.exp(-s.Rational(1,100))-s.exp(-1/kk**2)))
v1=cp(s.Integer(1));vhalf=cp(s.Rational(1,2))
rec('183',[167,183,184,186,188],'E4','K16 resonance fixes p but does not mathematically select RG shell k',v1>0 and vhalf>0 and v1!=vhalf, f'For a=1,n=1,m_s=2, p=1. Primitive Gaussian shell P=1,Lambda=10 valid at k=1: {v1}; at k=1/2: {vhalf}. Nothing in 2n=a m_s selects one.', 'Abstract jointly admissible kinematics+independent RG shell comparator; not proof that actual BH same-owner intertwiner cannot exist. Tests missing source-specific k=p map')
# k16 ratio
U=s.symbols('U',real=True,positive=True)
kratio=s.simplify((s.sqrt(U/6)/2)/(s.sqrt(96)*s.pi*s.sqrt(U)))
rec('184',[184],'E3','Lower-branch K16 hard/heat scale ratio',kratio==1/(48*s.pi), f'kstar/kh={kratio}; log ratio=-log(48pi) to O(alpha^-2)','Assumes separately established k*=m/2 and selected common heat normalization')
# exact spurion derivative and 2body width factor
g0,bet,Ms,alpha=s.symbols('g0 bet Ms alpha',real=True,positive=True)
T=s.symbols('T',real=True)
# infinitesimal scaling dg/dT=-beta; L=-F^2/(4g^2) with canonical Fcanon²=g² F²
GofT=g0-bet*T
LofT=-g0**2/(4*GofT**2)
vertex=s.diff(LofT,T).subs(T,0)
lam_exact=2*alpha**(-s.Rational(1,2))*bet/(Ms*g0)
width=s.simplify(lam_exact**2*m**3/(64*s.pi))
rec('185186',[185,186,187,189],'E3','Scale-spurion source derivative and scalar-to-two-vector leading WKB width',s.simplify(vertex+bet/(2*g0))==0 and s.simplify(width-alpha**(-1)*m**3*(bet/g0)**2/(16*s.pi*Ms**2))==0, f'dLcanon/dtau at tau=0={vertex}; lambda_exact={lam_exact}; width/per gauge d_i={width}', 'ALGEBRA ONLY conditional on tau being actual physical scalaron-source pullback; k=p matching separately open; width leading source/WKB domain')
# Petersen A5 multiplicity-free 4+5+3+3 and scalar coeffs cannot imply gap
rec('191',[190,191,192],'E3','Petersen real A5 isotypic dimensions and no forced spectral gap',4+5+3+3==15, 'A5 irreps dimensions 4,5,3,3prime; choosing b4=b5=b3=b3prime gives B=b I with identically zero energy differences','Tests commutant structure and finite-to-continuum non-promotion; does not claim Petersen geometry never couples to physical QCD')
assert len(chk)==26,len(chk)
source=P/'sources/Paper7C-ContinuousQFT-v2_195.tex'
obj={'target':'Paper7C','batch':4,'manuscript':source.name,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'scope':'Claims #139-192; source lines 4080-5863 (plus narrow cited upstream source-step checks)','check_count':len(chk),'checks':chk,'all_passed':all(c['passed'] for c in chk),'limitations':'Independent exact controls test printed specific steps and negative implications; do not certify actual interacting continuum/QCD/K16 source realization.'}
out=P/'Paper7C-ExactChecksBatch4-v1_4.json';out.write_text(json.dumps(obj,indent=2,ensure_ascii=False));print('WROTE',out,'checks',len(chk))
