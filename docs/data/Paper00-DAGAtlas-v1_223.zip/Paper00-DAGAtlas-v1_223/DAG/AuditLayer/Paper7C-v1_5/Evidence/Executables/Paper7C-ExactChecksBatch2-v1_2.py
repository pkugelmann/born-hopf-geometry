"""Independent finite-matrix and source-scope checks for Paper VII-C Batch 2.
Not a proof by simulation of infinite-dimensional OS reconstruction.
"""
import json, math, hashlib
import numpy as np
from pathlib import Path
from sympy import Matrix, sqrt, eye, kronecker_product, simplify, I, diag
O=Path('/mnt/data/audit7c_work')
# Jordan-Wigner finite CAR on 2 modes
am=Matrix([[0,1],[0,0]]); Z=diag(1,-1); Id=eye(2)
a1=kronecker_product(am,Id); a2=kronecker_product(Z,am)
f=a1; g=(a1+a2)/sqrt(2)
assert f*f==Matrix.zeros(4) and g*g==Matrix.zeros(4)
CAR_fg=f*g.H+g.H*f
nf=f.H*f; ng=g.H*g
comm=nf*ng-ng*nf
assert simplify(CAR_fg[0,0]-1/sqrt(2))==0
assert all(simplify(x-(1/sqrt(2) if i==j else 0))==0 for i,row in enumerate(CAR_fg.tolist()) for j,x in enumerate(row))
assert comm != Matrix.zeros(4)
# Show CAR for orthogonal control (a1,a2)
assert a1*a2.H+a2.H*a1==Matrix.zeros(4)
n2=a2.H*a2
assert nf*n2==n2*nf
# Gap / covariance comparison; rank-2 ground permits nondecaying centered correlations
H=diag(0,0,1); P0=diag(1,1,0); rho=P0/2; A=diag(1,-1,0)
assert (rho*A).trace()==0
assert (rho*A*A).trace()==1
assert list(H.diagonal())==[0,0,1]
# Fixed-gap finite matrices may have a nondecaying connected part;
# however their excited spectral support is exactly {1}.
# Uniform interchange of two limits: an elementary triangle-inequality check
T=[1,2,4,8,16]
N=[2,3,5,9,17]
vals=[[(1+1/n)+1/t for n in N] for t in T]
assert abs(max(abs(vals[i][j] - (1+1/N[j])) for j in range(len(N)) for i in range(len(T))) - 1.0)<1e-12
# covariance proof controls: finite H sym, U swaps two ground eigenvectors
Uswap=Matrix([[0,1,0],[1,0,0],[0,0,1]])
assert H*Uswap==Uswap*H
assert rho==Uswap*rho*Uswap.H
out={
 'target':'Paper7C-ContinuousQFT-v2_195.tex', 'batch':2,
 'checks':[
  {'id':'VIIC-E4-B2-054','claim':'p12:prop:graded-chiral-sector-compatibility','type':'exact finite CAR counterexample to unsupported locality inference','hypothesis_scope':'finite CAR structure alone; no spacelike orthogonality prescribed','witness':'f=e1; g=(e1+e2)/sqrt(2) in two-mode CAR; local regions assigned these modes','anticommutator':'{a(f),a*(g)}=I/sqrt(2) !=0','even_commutator':'[n_f,n_g] is nonzero','positive_control':'orthogonal e1,e2 satisfy zero odd cross-anticommutator and commuting even number operators','implication':'CAR without geometric orthogonality / graded locality does not give the claimed local field step; does not refute a sector with added locality contract'},
  {'id':'VIIC-E3-B2-055','claim':'p12:prop:v248-finite-quantum-ward-antecedent','type':'independent automorphism differentiation','certificate':'For delta=d alpha_s/ds at s=0, 0=omega(delta(A1...An))=sum omega(A1...delta(Ak)...An) using fixed invariant state and derivation property.'},
  {'id':'VIIC-E3-B2-059','claim':'p12:rem:v254-static-noise-limit-gate','type':'independent double limit test','certificate':'If |C_L(T)-C_L0|<=eta(T), eta(T)->0, C_L0->c and C_L(T)->C_inf(T) at fixed T, then |C_inf(T)-c|<=eta(T) and both iterated limits equal c.'},
  {'id':'VIIC-E3-B2-077','claim':'p12:thm:native-bh-covariance','type':'independent projector functional calculus','certificate':'[H,U]=0 implies [f(H),U]=0 for all spectral indicator f. Invariant P0/r and invariant trace. For H=diag(0,0,1), U swaps ground vectors, rho0=P0/2 exactly invariant despite degeneracy.'},
  {'id':'VIIC-E3-B2-078','claim':'p12:lem:bounded-cylinder-regularity','type':'multilinear seminorm bound','certificate':'|S_n,L|<=prod_i C_i p_i(f_i); pointwise limit preserves joint continuity for finite n in test-function topology, provided the p_i are continuous seminorms.'},
  {'id':'VIIC-E3-B2-079','claim':'p12:lem:rp-survives-limit','type':'closure of cone of positive semidefinite matrices','certificate':'For any finite reflected test family, Gram matrices G_L PSD and converge entrywise => G PSD. Assumes reflections and products use common compatible representatives.'},
  {'id':'VIIC-E4-B2-082','claim':'p12:thm:local-chart-os-reconstruction','type':'internal-source adversarial boundary comparison','certificate':'QFT1-7 do not explicitly require representation-wide locality or nontrivial time-zero algebra; source p12:def:v2210-lit-bounded-os-certificate (5957-5977) lists both and p12:lem:v2210-lit-locality-sandwich (5931-5955) refutes upgrade from vacuum commutator norm.'},
  {'id':'VIIC-E4-B2-088','claim':'p12:def:uniform-transfer-gap','type':'exact degenerate-ground falsification inherited from B1','certificate':'H=diag(0,0,1),rho0=P0/2,A=diag(1,-1,0): tr(rho0 A)=0 and tr(rho0 A(t)A)=1 for all t, while Spec(H) cap (0,1)=empty.'},
  {'id':'VIIC-E3-B2-089-091','claim':'p12:lem:sector-spectral-measure-gap-discharge; p12:thm:mass-gap-transfer; p12:cor:paper11-pure-glue-gap-floor','type':'alternative independent spectral-support check, with scope','certificate':'For finite measures mu_L supported on closed S={0} union [Delta*,infty), convergence of all Euclidean semigroup matrix elements including t=0 implies weak convergence of mu_L to mu by uniqueness of Laplace transforms (tightness follows from t=0 normalization plus Laplace continuity at 0). Closed-support preservation gives mu((0,Delta*))=0. Cyclicity excludes subgap spectrum. Unlike printed proof, this does not infer full decay of centered correlators in degenerate vacua.','scope_guard':'requires genuine common test-vector and semigroup convergence and fixed gap on the same sector; this is proof check of a printed result, not a theory extension'},
  {'id':'VIIC-E3-B2-086-087','claim':'p12:cor:v227-covariance-provider; p12:cor:v230-sharp-gibbs-provider','type':'matched upstream exact theorem check','certificate':'Current Paper1B source at 22246-22265 and 22293-22343 gives full-ground bound 2 min{1,epsilon/Delta} and Gibbs bound min{2,beta epsilon}. Finite trace duality plus delta_A yields exactly both VII-C coefficients.'},
  {'id':'VIIC-E3-B2-058-TEXT','claim':'p12:thm:finite-identity-preservation','type':'independent algebraic termwise limit','certificate':'For fixed finite sum of controlled scalar/distributional terms T_{j,L}->T_j in a linear Hausdorff space, sum_j T_{j,L}=0 implies sum_j T_j=0; polynomial/composite terms require their own mixed-moment QFT4/QFT10 limits rather than separate fieldwise weak convergence.'},
  {'id':'VIIC-E3-B2-064-TEXT','claim':'p12:prop:scattering-nonclaim','type':'independent premise audit','certificate':'The ordinary local Euclidean reconstruction objects can be defined without asymptotic channel wave operators Omega_± or incident flux measures. Thus the latter are separate claims and not logical consequences of local OS state alone.'},
  {'id':'VIIC-E3-B2-071-TEXT','claim':'p12:prop:spectral-symbol-qft123','type':'independent representation/operational bound','certificate':'Peter-Weyl matrix coefficients of SU(2) span a uniformly dense *-subalgebra of C(S3); P_m M_f P_m is contractive for bounded f, and fixed finite polynomials of uniformly bounded generators obey polynomial operator norm bounds.'},
  {'id':'VIIC-E3-B2-073-TEXT','claim':'p12:cor:canonical-local-state-quotient-discharge','type':'independent quotient functional test','certificate':'If I is a two-sided *-ideal of a *-algebra A with lim_L omega_L(iota_L(N))=0 for every N in I and the same for all products used, a positive limit omega descends to A/I with omega([A])=lim_L omega_L(iota_L(A)). This is conditional on the actual ideal/positive-map compatibility.'},
  {'id':'VIIC-E3-B2-081-TEXT','claim':'p12:lem:euc-invariance-survives','type':'independent state comparison estimate','certificate':'If rho0,L commutes with U_L(g), then |omega_L((gA)_L)-omega_L(A_L)|<=||(gA)_L-U_L(g)A_LU_L(g)*||. Limit-zero for each actual local motion gives covariance of phase state. Native Spin(4) invariance does not itself implement mixed tau-space rotations.'}
 ],
 'warnings':['The finite CAR example isolates the proof step; it does not purport to realize all QFT1-QFT10 and is not a refutation of an appropriately locality-certified graded sector.',
             'The independent spectral argument certifies conclusion at the stated semigroup-convergence scope; it does not repair the printed vacuum-subtracted decay proof or establish the continuum gap antecedent.']
}
f=O/'Paper7C-ExactChecksBatch2-v1_2.json';f.write_text(json.dumps(out,indent=2,ensure_ascii=False))
print('PASS',len(out['checks']),'records',f)
