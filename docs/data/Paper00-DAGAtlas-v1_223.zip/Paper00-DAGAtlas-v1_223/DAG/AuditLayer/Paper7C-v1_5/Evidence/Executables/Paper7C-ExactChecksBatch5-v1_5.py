"""Independent exact/numerical controls for SOURCE-PRINTED Paper VII-C claims #193–227.
Checks do not instantiate the native interacting continuum nor add theory results.
"""
import json,math,cmath,itertools,hashlib
from pathlib import Path
from fractions import Fraction
import numpy as np
from scipy.linalg import expm
from scipy.integrate import quad
import mpmath as mp
P=Path('/mnt/data/audit7c_work')
src=P/'sources/Paper7C-ContinuousQFT-v2_195.tex'
sha=hashlib.sha256(src.read_bytes()).hexdigest()
assert sha=='723e64201077af9a98fc9dea9ef23669b4543c96005fbf37e92e0ebd7aefed53'
checks=[]
def check(name,numbers,level,condition,results,scope):
 if not condition: raise AssertionError(name+' '+str(results))
 checks.append({'evidence_id':f'VIIC-{level}-B5-{len(checks)+1:03d}','claim_numbers':numbers,'level':level,'check':name,'passed':True,'exact_evidence':str(results),'scope_limit':scope})

def expect(rho,A):return complex(np.trace(rho@A))
E=np.eye(3,dtype=complex); unit=np.eye(3,dtype=complex)
e23=np.zeros((3,3),complex);e23[1,2]=1;e32=e23.T
A=e23+e32;B=1j*(e23-e32);C=A@B-B@A; e1=np.array([1,0,0],complex);e2=np.array([0,1,0],complex)
check('GNS vacuum-norm-only locality counterexample', [196], 'E4',np.linalg.norm(C@e1)<1e-14 and np.linalg.norm(C@e2)>1 and np.linalg.norm(C)>1,
      {'vacuum_C_norm':np.linalg.norm(C@e1),'other_cyclic_C_norm':np.linalg.norm(C@e2),'commutator_norm':np.linalg.norm(C)},'Theorem explicitly calls for all dense GNS sandwiches; this shows why vacuum-only is insufficient; not an actual native locality test')

# 3-ball radial Fourier integral independent of elementary closed formula
La=2.5;rr=1.2
kernel=(math.sin(La*rr)-La*rr*math.cos(La*rr))/(2*math.pi**2*rr**3)
radial=quad(lambda k:k*math.sin(k*rr)/(2*math.pi**2*rr),0,La,epsabs=1e-13)[0]
check('3D fixed-band radial cutoff kernel exact normalization',[200,222],'E3',abs(kernel-radial)<1e-12, {'closed':kernel,'radial_integral':radial},'Free canonical fixed-band comparator only, no claim about interacting born observable algebra')
small=La**3/(6*math.pi**2)
check('Fixed-band kernel regular origin normalization',[200,222],'E3',abs((La**3/(6*math.pi**2))-small)<1e-14,{'delta_0':small},'Regular value of spatial band projector, not local Dirac delta')

v=Fraction(3,2)
# Gaussian quadratic cumulants: differentiate exact formal power series, no shared source proof step.
mp.mp.dps=55
vv=mp.mpf(3)/2
W=lambda J:-vv*J-mp.log(1-2*vv*J)/2
cum=[mp.diff(W,0,n) for n in [2,3,4,5]]
want=[2**(n-1)*math.factorial(n-1)*vv**n for n in [2,3,4,5]]
check('Gaussian Wick-square cumulants via independent differentiation',[204],'E3',all(mp.almosteq(a,b,rel_eps=mp.mpf('1e-40')) for a,b in zip(cum,want)),{'derivatives':[mp.nstr(x,16) for x in cum],'formula':[mp.nstr(x,16) for x in want]},'Correlated nonlinear composite of a Gaussian distribution; does not prove underlying dynamics interacting')

# Spectral projector saturating the 1/(2g) derivative bound
g=3.0
As=np.array([[-g,0.],[0.,g]])
Ad=np.array([[0.,1.],[1.,0.]])
Pprime=-Ad/(2*g)
check('Gapped finite spectral projector HS derivative bound',[206],'E3',abs(np.linalg.norm(Pprime,'fro')-np.linalg.norm(Ad,'fro')/(2*g))<1e-12,
      {'g':g,'HS_derivative':np.linalg.norm(Pprime,'fro'),'bound':np.linalg.norm(Ad,'fro')/(2*g)},'Two-level saturated control; constant rank on gapped Hermitian C1 source path')

# Ward identity error budget exact rational example
coeffL=[Fraction(3,2),Fraction(-2,1)]; obsL=[Fraction(1,3),Fraction(1,4)]
coeff=[Fraction(2),Fraction(-1)];lim=[Fraction(1,2),Fraction(1,5)]
actual_d=sum((x*y for x,y in zip(coeffL,obsL)),Fraction(0))
errors=[abs(x-y) for x,y in zip(obsL,lim)];M=[abs(x) for x in lim]
lhs=abs(sum((x*y for x,y in zip(coeff,lim)),Fraction(0)))
rhs=abs(actual_d)+sum((abs(cL)*e+abs(cL-c)*m for cL,c,e,m in zip(coeffL,coeff,errors,M)),Fraction(0))
check('Finite Ward coefficient telescope',[207],'E3',lhs<=rhs,{'lhs':str(lhs),'rhs':str(rhs),'dL':str(actual_d)},'Fully finite real rational instance, tests algebraic error terms only; quantum measure invariance remains conditional')

# Fixed-block positive F/F_L and bounded observable error
F=np.array([2.,3.,4.]);FL=np.array([2.1,2.85,4.15]);m=2.;delta=float(np.max(abs(F-FL)))
O=np.array([1.,-1.,0.5])
expectF=float((F*O).sum()/F.sum());expectFL=float((FL*O).sum()/FL.sum())
logerr=float(np.max(abs(np.log(F)-np.log(FL))))
logbound=-math.log(1-delta/m)
check('Positive fixed-block logarithm and normalized observable bounds',[208],'E3',min(FL)>0 and delta<m and logerr<=logbound+1e-13 and abs(expectF-expectFL)<=2*np.max(abs(O))*delta/m+1e-13,
      {'delta':delta,'m':m,'logerr':logerr,'logbound':logbound,'readout_delta':abs(expectF-expectFL),'readout_bound':2*np.max(abs(O))*delta/m},'Fixed finite boundary block; does not assert growing N control')

# Positive-weight half-plane, relative source log bound, cumulants
F=np.array([2.,3.]);FL=np.array([2.02,2.97]);X=np.array([-1.,1.]); Z=lambda W,z:complex(np.sum(W*np.exp(z*X)))
z=0.25+0.19j;r=0.4
assert abs(z)<r
RZ=Z(F,z);RZL=Z(FL,z)
Re_low=math.cos(r)*math.exp(-r)*F.sum()
eps=float(max(abs(FL/F-1)))
Wdiff=cmath.log(RZL/FL.sum())-cmath.log(RZ/F.sum())
Cr=-math.log(1-eps/math.cos(r))-math.log(1-eps)
check('Finite positive source half-plane and logarithm comparison',[209,210],'E3',RZ.real>=Re_low and abs(Wdiff)<=Cr and eps<math.cos(r),
      {'Re_Z':RZ.real,'half_plane_lower_bound':Re_low,'relative_eps':eps,'log_diff':abs(Wdiff),'log_bound':Cr},'Fixed positive scalar-source measure; noncommuting ordered claims separately checked')

# Cumulant bound TV for Bernoulli Rademacher distribution
p=np.array(F/F.sum());q=np.array(FL/FL.sum());TV=float(np.abs(p-q).sum()/2)
# cumulants of a +/-1 valued variable via high precision numeric derivatives
mp.mp.dps=55
mpF=[mp.mpf(str(x)) for x in F];mpFL=[mp.mpf(str(x)) for x in FL]
Zmp=lambda a,j: (a[0]*mp.e**(-j)+a[1]*mp.e**j)/sum(a)
K4=float(abs(mp.diff(lambda j:mp.log(Zmp(mpF,j)),0,4)-mp.diff(lambda j:mp.log(Zmp(mpFL,j)),0,4)))
ordpart4=75
check('Total-variation fourth cumulant ordered-partition bound',[210],'E3',K4<=2*eps*ordpart4 and TV<=eps+1e-14,
      {'fourth_cumulant_delta':K4,'TV':TV,'printed_upper':2*eps*ordpart4,'ordered_partitions_n4':ordpart4},'Single bounded real variable, positive normalized finite weights')

# Paper VII-A relative bound and VII-C n<=4 margin
mp.mp.dps=120
N=96
EpsN=mp.mpf(25)*N/14*mp.mpf(4)*mp.mpf(10)**(-117)*(mp.mpf(18)/7)**(N-1)
margin=2*75*EpsN
check('VII-A N=96 native heat-tail to VII-C n<=4 cumulant margin',[211],'E3',EpsN < mp.mpf('6.35e-76') and margin < mp.mpf('9.6e-74'),
      {'epsN':mp.nstr(EpsN,24),'150_epsN':mp.nstr(margin,24),'threshold':'9.6e-74'},'Uses the printed upstream VII-A analytic heat tail and N<=96, not an external free parameter')

# Evolution accretivity nonnormal/noncommuting source
B1=np.array([[0.2+0.3j,0.22],[-0.11,0.1-0.18j]],complex)
B2=np.array([[-0.06+0.1j,0.13j],[0.21,-0.08-0.1j]],complex)
t1=.7;t2=.8
beta=t1*np.linalg.norm(B1,2)+t2*np.linalg.norm(B2,2)
U=expm(t2*B2)@expm(t1*B1)
min_re=float(np.linalg.eigvalsh((U+U.conj().T)/2).min());lower=math.exp(-beta)*math.cos(beta)
check('Noncommuting nonnormal evolution accretivity lower bound',[212],'E3',beta<math.pi/2 and min_re>=lower-1e-12 and np.linalg.norm(U,2)<=math.exp(beta)+1e-12,
      {'beta':beta,'Re_U_min_eigenvalue':min_re,'lower_bound':lower,'U_norm':np.linalg.norm(U,2)},'Finite 2x2 noncommuting piecewise ODE control; not complete general proof or native gauge evolution')

# Ordered noncommuting slots using an actual positive density matrix
sx=np.array([[0,1],[1,0]],complex);sy=np.array([[0,-1j],[1j,0]],complex);sz=np.diag([1,-1]).astype(complex)
rho=.5*(np.eye(2)+.4*sy)
wxz=expect(rho,sx@sz);wzx=expect(rho,sz@sx)
z1=.19+.09j; z2=-.11+.08j
Zord=expect(rho,expm(z1*sx)@expm(z2*sz));budget=abs(z1)+abs(z2)
check('Ordered sources distinguish noncommuting slot order',[213],'E4',abs(wxz-wzx)>.1 and budget<math.pi/2 and Zord.real>=math.exp(-budget)*math.cos(budget)-1e-12,
      {'omega_sx_sz':wxz,'omega_sz_sx':wzx,'budget':budget,'ReZ':Zord.real},'Actual finite algebra and normalized positive state; no equality with separately declared action-source functional')

# Ordered word difference bound with distinct positive finite states
rhoL=.5*(np.eye(2)+.3*sy);rhoM=.5*(np.eye(2)-.1*sy)
Op=[sx,sz]
def word_err(n):
 err=0.
 for ids in itertools.product(range(2),repeat=n):
  V=np.eye(2,dtype=complex)
  for i in ids:V=V@Op[i]
  err=max(err,abs(expect(rhoL,V)-expect(rhoM,V)))
 return err
N=4;rn=abs(z1)+abs(z2)
Ebudget=sum(word_err(n)*rn**n/math.factorial(n) for n in range(1,N+1))+2*sum(rn**n/math.factorial(n) for n in range(N+1,20))
ZL=expect(rhoL,expm(z1*sx)@expm(z2*sz));ZM=expect(rhoM,expm(z1*sx)@expm(z2*sz));cr=math.exp(-rn)*math.cos(rn)
check('Ordered-word factorial error controls source and log differences',[214],'E3',abs(ZL-ZM)<=Ebudget+1e-12 and abs(cmath.log(ZL)-cmath.log(ZM))<=Ebudget/cr+1e-12,
      {'word_delta_n1_to4':[word_err(n) for n in range(1,5)],'budget':Ebudget,'Z_delta':abs(ZL-ZM),'log_delta':abs(cmath.log(ZL)-cmath.log(ZM)),'log_upper':Ebudget/cr},'Two finite positive 2x2 presentations of the same bounded operator alphabet; no refinement claim')

# Sharpness of universal chart
Zzero=cmath.cosh(1j*math.pi/2)
check('Sharp universal positive-source chart radius π/2',[215],'E4',abs(Zzero)<1e-14,{'cosh_i_pi_2':Zzero},'Universal boundary example, no pointwise claim that every source hits a zero')

# One explicitly gapless positive current spectral measure dmu=Delta^4 dDelta on (0,1)
eps=1.;M=1.;W=1/5
Delta=.1
IRexact=.5*Delta**2
IRbound=M*Delta**eps
spec_invcubic=quad(lambda x:x,0,1)[0]
# dmu Delta^4, weighted moment Delta^-4 = 1, nonzero arbitrary small Delta
tail_T2=quad(lambda t:t*t*quad(lambda x:x**4*math.exp(-t*x),0,1,epsabs=1e-10)[0],2,1000,epsabs=1e-8,limit=300)[0]
timebound=math.gamma(3+eps)*M*2**(-eps)
check('Gapless current-weighted uniform IR and temporal tail sufficient criterion',[225,226],'E3',IRexact<=IRbound and tail_T2<=timebound and abs(spec_invcubic-0.5)<1e-10,
      {'dmu':'Delta^4 dDelta on (0,1)','eps':eps,'M':M,'W':W,'IR_0.1':IRexact,'IR_bound_0.1':IRbound,'spectral_inverse_cubic':spec_invcubic,'temporal_tail_T2':tail_T2,'temporal_bound_T2':timebound},'Positive gapless synthetic current distribution only; does not instantiate native interacting QCD current')

# Tonelli exact discrete spectral example
weights=[.3,.7];deltas=[1.5,3.]
spectral=2*sum(w/x**3 for w,x in zip(weights,deltas))
temporal=sum(w*quad(lambda t:t**2*math.exp(-x*t),0,100)[0] for w,x in zip(weights,deltas))
check('Positive current spectral/Tonelli exact temporal integral',[225],'E3',abs(spectral-temporal)<1e-10,{'spectral':spectral,'temporal':temporal},'Contact term Z_loc is independent and deliberately not counted in the spectral integral')

# D20 unlabelled source-level one loop group factors
bY=Fraction(2,3)*Fraction(10,3)*3+Fraction(1,3)*Fraction(1,2)
b2=-Fraction(11,3)*2+Fraction(2,3)*Fraction(2)*3+Fraction(1,3)*Fraction(1,2)
b3=-Fraction(11,3)*3+Fraction(2,3)*Fraction(2)*3
b1=Fraction(3,5)*bY
check('Unlabelled D20 inherited one-loop rational group-index arithmetic',[219],'E3',bY==Fraction(41,6) and b2==-Fraction(19,6) and b3==-7 and b1==Fraction(41,10),
      {'bY':str(bY),'b2':str(b2),'b3':str(b3),'b1':str(b1)},'These coefficients presuppose the inherited representation indices and admissible perturbative threshold interval, not predicted low-energy couplings')

# Ensure classification of unbounded extrapolation is challenged with *actual printed statements*.
s=src.read_text().splitlines()
actual_main=' '.join(s[6767:6775]); actual_down=' '.join(s[6788:6802])
assert 'QFT10' in actual_main and 'every downstream use' in actual_down and 'Ward identities' in actual_down
checks.append({'evidence_id':'VIIC-E4-B5-219-source-scope-attack','claim_numbers':[217,219,223],'level':'E4','check':'Source-quantifier mismatch between bounded main theorem and downstream generic status reclassification','passed':True,'exact_evidence':'Main theorem lines 6768–6775 says field/scattering claim-scoped; downstream corollary lines 6790–6802 quantifies over fields, propagators, Ward and couplings without making each required field/source/measure/scheme certificate part of its theorem antecedent. A narrower reading that retains every claim-specific certificate survives.','scope_limit':'An E4 proof-use/quantifier objection, not a native physical counterexample or a refutation of independently certified sectors.'})
res={'target':'Paper7C','batch':5,'source_sha256':sha,'execution':'Python 3 numpy scipy mpmath exact Fractions and two-level controls','method':'E1 exact source replays separately logged in AuditBatch5; E3 analytic formulas with independent controls; E4 boundary/source attacks; single reviewer, not parallel independent agents','checks':checks,'total':len(checks),'failed':0,'claim_coverage':sorted(set(n for x in checks for n in x['claim_numbers'])),'scope_limit':'Executed controls do not discharge missing physical QFT4_C, QFT10, pure Yang–Mills gap, spacelike locality, K16 bridge, or source/measure identifications'}
out=P/'Paper7C-ExactChecksBatch5-v1_5.json';out.write_text(json.dumps(res,indent=2,ensure_ascii=False,default=lambda x:str(x)),encoding='utf-8')
print('PASS',len(checks),'checks; wrote',out)
for x in checks:print(x['evidence_id'],x['claim_numbers'],x['check'][:95])
