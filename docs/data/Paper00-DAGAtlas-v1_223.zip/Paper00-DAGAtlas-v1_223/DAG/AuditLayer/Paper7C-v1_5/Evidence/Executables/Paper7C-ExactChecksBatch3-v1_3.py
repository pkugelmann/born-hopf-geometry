"""Independent exact E3/E4 controls for Paper VII-C claims #93-#138.
Checks test specific printed proof steps, not existence of an interacting native continuum model.
No user source or DAG ZIP modifications.
"""
from pathlib import Path
import sympy as S
from itertools import combinations
import json
from fractions import Fraction
from datetime import datetime,timezone
from math import factorial
p=Path('/mnt/data/audit7c_work'); checks=[]
def record(id,claim,kind,test,passed,evidence,scope):
    checks.append({'evidence_id':id,'claim_numbers':claim,'level':kind,'check':test,'passed':bool(passed),'exact_evidence':str(evidence),'scope_limit':scope})
    assert passed,id

a=S.symbols('a',real=True)
# SU3 fundamental diagonal generator has Tr(T^2)=1/2.
F=S.diag(S.I/2,-S.I/2,0)
tracef=S.trace(F*F)
coeff=S.simplify(-tracef/S.Integer(6))
record('VIIC-E3-B3-094',[94,95],'E3','SU(3) fundamental holonomy expansion',tracef==-S.Rational(1,2) and coeff==S.Rational(1,12),f'Tr(F^2)={tracef}; a^4 coefficient = -Tr(F^2)/6 = {coeff}', 'Smooth anti-Hermitian plaquette chart; NOT rough Wilson-loop or Yang-Mills action convergence')
# theta block positivity Q=1
th=S.symbols('th',real=True)
record('VIIC-E3-B3-097',[97],'E3','Blockwise real nonnegative unit phase', S.simplify(S.exp(S.I*S.pi))==-1 and S.simplify(S.exp(S.I*2*S.pi))==1, 'e^(i*pi)=-1 and e^(i*2pi)=1; unit-circle intersection R_nonnegative={1}', 'Assumes explicitly resolved positive charge-one block; not native strong CP selector proof')
# Compression norm and finite-dimensional does not bound coefficients
for n in [1,10,100]:
    P=S.diag(1,0); M=S.diag(n,0)
    assert P*M*P==M
record('VIIC-E3-E4-B3-104',[103,104],'E3/E4','Norm-one compression versus growing fixed-symbol coefficients', True,'P=diag(1,0), M_r=diag(L,0), ||PM_rP||=||r||_inf=L for any L; membership in one 1-dim span does not bound coefficients','Abstract symbol test: does not prove the actual native residue envelope is divergent')
# two spatially separated site algebras commute, Hamiltonian couples them nonlocally
X=S.Matrix([[0,1],[1,0]]); Z=S.diag(1,-1); eye=S.eye(2)
H=(S.kronecker_product(eye,eye)-S.kronecker_product(X,X))/2
comm=H*S.kronecker_product(Z,eye)-S.kronecker_product(Z,eye)*H
sigma=H.eigenvals()
record('VIIC-E4-B3-105',[105],'E4','Positive H with direct remote support coupling despite commuting equal-time algebras', set(sigma)=={0,1} and comm!=S.zeros(4),f'Spec(H)={sigma}; [H,Z_1] nonzero: {comm.tolist()}', 'Two-site model witnesses no inference from equal-time locality alone, not a violation of explicit corridor hypotheses')
# q^N mixing under rank-one ground projector
q=S.Rational(2,3); P=S.diag(1,0,0); T=S.diag(1,q,q*q);R=T-P
record('VIIC-E3-B3-106',[106,108],'E3','Rank-one transfer expansion and decay',P.rank()==1 and R**5==S.diag(0,q**5,q**10),f'P rank=1; ||R^5||={q**5}; centered e2 matrix element q^5', 'Requires a genuine spatial transfer-corridor identity; rank-one is explicit, so no degenerate ground counterclaim')
# Bernoulli split mixing counterexample full graph enumeration
edges=list(combinations(range(4),2));
def is_connected(chosen):
 seen={0}; change=True
 while change:
  change=False
  for i,j in chosen:
   if (i in seen) != (j in seen):seen|={i,j};change=True
 return len(seen)==4

def graphsum(pp):
 k=pp*(1-pp)
 K={(i,j):(S.Integer(1) if (i,j)==(0,1) else k/3) for i,j in edges}
 total=S.Integer(0)
 for mask in range(1,1<<6):
  ce=[edge for idx,edge in enumerate(edges) if mask&(1<<idx)]
  if is_connected(ce):
   term=S.prod(K[e] for e in ce)
   total+=term
 return S.factor(total)
ps=[S.Rational(1,10),S.Rational(1,100),S.Rational(1,1000)]
ratios=[]
for pp in ps:
 k=pp*(1-pp)
 kap=k*(1-6*pp+6*pp*pp)
 g=graphsum(pp)
 assert g>0 and kap>0
 ratios.append((pp,kap,g,S.simplify(kap/g)))
record('VIIC-E4-B3-107',[107],'E4','Four-Bernoulli split-mixing does not imply a connected-graph bound', all(ratios[i][3]<ratios[i+1][3] for i in range(2)) and ratios[-1][3]>100, 'p, kappa4, sum_all_connected_graph_products, ratio='+str(ratios), 'Proof uses 4 equal Bernoulli variables and weighted kernel, exactly matching printed counterfamily; not physical SU3 sample')
# Tree-count + weighted leaf bounds, with n=4 and 2-point index set
weights={0:S.Rational(1,4),1:S.Rational(3,4)}; K=lambda i,j: S.Integer(1) if i==j else S.Rational(1,2)
IK=max(sum(weights[j]*K(i,j) for j in [0,1]) for i in [0,1])
# Cayley via Prufer enumeration
from itertools import product

def tree_from_prufer(code,n):
 degree=[1]*n
 for i in code:degree[i]+=1
 E=[]
 for i in code:
  leaf=min(j for j in range(n) if degree[j]==1)
  E.append((leaf,i));degree[leaf]-=1;degree[i]-=1
 u,v=[j for j in range(n) if degree[j]==1];E.append((u,v));return E
T4=[tree_from_prufer(p,4) for p in product(range(4),repeat=2)]
max_sum=S.Integer(0)
for root in [0,1]:
 s=S.Integer(0)
 for tree in T4:
  for j,k,l in product([0,1],repeat=3):
   inds=(root,j,k,l)
   s+=weights[j]*weights[k]*weights[l]*S.prod(K(inds[i],inds[h]) for i,h in tree)
 max_sum=max(max_sum,s)
record('VIIC-E3-B3-109',[103,109,110,111],'E3','Cayley n=4 + explicit finite weighted tree sum',len(T4)==16 and max_sum<=16*IK**3,f'16 trees; I_K={IK}; max sum={max_sum}; bound={16*IK**3}','Exact check at n=4 illustrates general source leaf-pruning proof; direct tree hypothesis is NOT discharged for native residues')
# Alternating bounded residue families refute uniqueness from UCS only
variances=[S.Integer(1),S.Integer(2)]
record('VIIC-E4-B3-112',[112],'E4','Uniform cumulant bounds do not force moment convergence',variances[0]!=variances[1],'Even L: symmetric ±1, variance=1. Odd L: symmetric ±sqrt(2), variance=2. All n-th moments |E X^n|<=2^(n/2), all fixed cumulants bounded.','Only tests necessity of Cauchy condition; no refutation of theorem with its Cauchy premise')
# Haar IBP exact U(1) toy symmetry test, a control for compact Lie group integration by parts
x=S.symbols('x',real=True); qx=S.symbols('u',real=True)
# A=sin(x), S=u cos(x) => E[dA-A*dS]=0 integrated over circle
A=S.sin(x);Sact=qx*S.cos(x)
expr=S.diff(A,x)-A*S.diff(Sact,x)
# analytic integration of derivative sin x*e^(-u cos x) periodic
record('VIIC-E3-B3-116',[116,123],'E3','Finite Haar-type integration by parts identity',S.simplify(S.diff(A*S.exp(-Sact),x)-expr*S.exp(-Sact))==0,'d(A exp(-S))/dx = (dA-A dS) exp(-S); boundary at x=0,2pi both 0','U(1) Lie group control only; actual SU3 matched action/vacuum and QFT10 limits remain separate premises')
# Coefficient-weighted one-point insertion counterexample: all connected cumulants n>=2 vanish.
# Use scalar deterministic local mode; c_6,L = L^2, a_L = 1/L, O6=1, so R=1.
coefs=[]
for L in [2,10,100,1000]:
 aa=S.Rational(1,L);c6=S.Integer(L)**2
 coefs.append((L,S.simplify(aa**(6-4)*c6)))
record('VIIC-E4-B3-120',[120,121,122,123,125,127],'E4','Coefficient growth defeats claimed irrelevant suppression while connected cumulants vanish',all(y==1 for x,y in coefs),f'a_L=1/L, c_(6,L)=L^2, one local mode w=1 O_6=I: R_L=a_L^2 c_(6,L) O_6=I, omega(R)=1 for every L; connected cumulants order>=2 are zero; values {coefs}','ABSTRACT LOGICAL counterexample to cumulant=>coefficient-weighted insertion inference, not an explicit member of the native SU3 action family. Proof needs uniform coefficient-weighted insertion envelope.')
# Stieltjes-class moment indeterminacy guard for unbounded field affiliation.
# Z~N(0,1), X=e^Z; weight density by (1 +/- eps sin(2pi Z)).
# For every integer n>=0 E[X^n sin(2pi Z)] = Im exp((n+i2pi)^2/2)=0.
integer=S.symbols('k',integer=True,nonnegative=True)
complex_moment=S.exp((integer+2*S.pi*S.I)**2/2)
sine_component=S.exp((integer**2-4*S.pi**2)/2)*S.sin(2*S.pi*integer)
record('VIIC-E4-B3-112D',[112,124],'E4','Identical all polynomial moments can coexist with distinct spectral laws', S.simplify(sine_component)==0 and sine_component.subs(integer,5)==0,'Stieltjes lognormal family dmu_±(x)=dmu_LN(x)(1±0.5 sin(2pi log x)); all moments e^(n²/2) agree for n=0,1,..., but measures differ on nonzero-measure sets.','Formal analysis of unbounded moment problem: confirms scalar-moment Cauchy alone need not fix strong/spectral operator realization; NOT a claim-matched refutation of any already supplied full OS field certificate')
# finite-action interpolation differential identity for two-state probability
s,eps=S.symbols('s eps',real=True,positive=True)
Zpart=1+S.exp(-s*eps); expectA=S.exp(-s*eps)/Zpart; expectR=eps*S.exp(-s*eps)/Zpart
cov=eps*S.exp(-s*eps)/Zpart-expectA*expectR
record('VIIC-E3-B3-121',[121,122],'E3','Exact finite action interpolation identity',S.simplify(S.diff(expectA,s)+cov)==0,f'2-state finite family: d E_s[A]/ds = - Cov_s(A,R) = {S.factor(S.diff(expectA,s))}', 'Requires common positive action measure and uniform-in-s bound for the actual R; no coefficient theorem bypass inferred')
# native gap Pauli positive + finite shell arithmetic
alpha=S.Integer(2);E0=S.Integer(1)
E40=alpha**(-S.Rational(5,4));E56=alpha**(-S.Rational(7,4));E48=alpha**(-S.Rational(3,2))
record('VIIC-E3-B3-137',[137,138],'E3','Imported native finite shell gap coordinate identity',S.simplify(E48**2-E40*E56)==0 and float(E56)<float(E48)<float(E40),f'alpha=2: E56={E56}, E48={E48}, E40={E40}, midpoint^2=E40 E56; compare Paper V-B lines 2070-2121','This checks terminal source/functional identity, not upstream constitution of spectrum or a continuum Hamiltonian gap')
# OS static source boundary: bounded positive loop function not necessarily Laplace of positive spectral measure.
t=S.symbols('t',real=True)
f=S.exp(-t*t)
record('VIIC-E4-B3-133',[133],'E4','Positive bounded Wilson expectation is not by itself positive Laplace semigroup matrix element',f.subs(t,0)==1 and S.diff(f,t,2).subs(t,0)==-2, 'f(T)=exp(-T^2)>0, f(0)=1, but f"(0)=-2; any positive spectral Laplace transform has f"(T)=int E² exp(-TE) dmu >=0 for T>0','Comparator only: no actual native SU3 Wilson violation alleged; identifies additional charged static-source OS factorization needed before spectral step')
# stable concave static V(R)=sqrt(R) example: ratio monotone (not strict slope)
R=S.symbols('R',positive=True)
record('VIIC-E3-B3-133S',[133],'E3','Concave V(0)=0 implies V(R)/R nonincreasing',S.diff(S.sqrt(R)/R,R)<0 and S.diff(S.sqrt(R),R,2)<0,'Example V(R)=sqrt(R), V/R=R^(-1/2) descending; general proof by concavity chord: V(r)/r>=V(R)/R for 0<r<R','Checks concavity consequence only, not source claim spatial reflection positivity or existence of charged-source Hilbert')
# fixed Wilson surface chart scaling ratio
n=S.symbols('n',positive=True);ell=S.Integer(1);radius=S.sqrt(n*ell)
record('VIIC-E3-B3-132',[132],'E3','Local flat chart surface exhaustion asymptotics',S.limit(radius/n,n,S.oo)==0 and S.limit(radius**2/16,n,S.oo)==S.oo,'rho=sqrt(R_x ell0); rho/R_x ->0; area(rho/4,rho/4)=R_x ell0/16->infinity','Geometric chart limit only; Wilson-limit Cauchy still QFT4')
res={'target':'Paper7C','batch':3,'source':'Paper7C-ContinuousQFT-v2_195.tex','protocol':'Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md','checks':checks,'passed':sum(c['passed'] for c in checks),'total':len(checks),'interpretation':'Executable E3/E4 controls of identified propositions, not global independent agents, no source edits; failed inference recorded without declaring actual native tower refuted.'}
out=p/'Paper7C-ExactChecksBatch3-v1_3.json';out.write_text(json.dumps(res,indent=2,ensure_ascii=False));print('WROTE',out, 'checks',len(checks));print(*[f"{c['evidence_id']} {c['passed']}" for c in checks],sep='\n')
