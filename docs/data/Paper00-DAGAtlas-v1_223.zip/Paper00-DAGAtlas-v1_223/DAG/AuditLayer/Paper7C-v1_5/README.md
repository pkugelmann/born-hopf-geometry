# Paper VII-C source-bound audit layer v1_5

This audit layer records all **227 named Paper VII-C source claims** with their source text and exact line anchors, **11 unique first-origin issues**, 176 source-reviewed material DAG edges and 86 exact/adversarial checks. It is **FULLY_AUDITED_WITH_OPEN_GAPS**, not a claim of unconditional interacting QCD. Original Paper VII-C and all prior source materials are unchanged.

Index.json is the entrypoint; material graph edges only have source proof-use lineage. Do not turn cited/contextual or inferred open-condition edges into theorem ancestry, and do not convert an open claim-specific proof route into a global proof-status downgrade.
