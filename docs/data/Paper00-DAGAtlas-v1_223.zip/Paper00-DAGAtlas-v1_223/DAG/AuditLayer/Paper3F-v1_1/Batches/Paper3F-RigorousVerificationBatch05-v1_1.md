# Paper III-F — Rigorous Verification DAG Audit, Batch 05

**Frozen source:** `Paper3F-CompleteDynamics-v1_256.tex` SHA256 `47d43b2d08b2245ade810eae64a9e1cc827398f60899af0afed7cb2398358a77`; framework `v2_370`. **Protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md`.

**Coverage:** lines 9,071–11,272 inclusive; 44 named claims, 38 attached proofs, 7 formal remarks, 16 clusters of material unnamed equations/interfaces. 114 explicit refs uniquely resolved. 37 reviewed source-matched proof-use edges; 23 unpromoted candidate references. No paper source or ZIP edited.

**Disposition counts:** FORMALIZED=3, INCONSISTENT=2, REPRODUCED=14, VERIFIED=18, VERIFIED-CONDITIONAL=7. A verified local identity is not automatic certification of physically occurring action/history.

**Independent checks:** 17 E3 and 9 E4 in the saved script, plus 2 targeted condition/scope E4 controls. All pass their assigned test; counterexamples may confirm a localized scope issue.

## All new issue findings

### BH-IIIF-G-0003 — MISSING_CONDITION / minor / OPEN

**Origin:** `p3:thm:local-fR-field-equation`, line **9848**; the source says `U=Λ_EH²=(3/π)K_p` without attaching `CELL_{K→U}`. Paper III-E lines 457–484 define this as an independent, origin-certified comparison test, not a consequence of `K_p=6/R_mom²` and `U=Λ_EH²`. The **same** III-F theorem at line 9929 explicitly restores `CELL_{K→U}`. This is a source-internal scope inconsistency of one sentence, not a failure of the preceding normalized metric variation or an additional physical axiom.

**Independent domain challenge:** with `R_mom=1`, `K_p=6`, and `U=Λ_EH²=1` (before the optional cell port), `U != (3/π)K_p=18/π`. The scope of the equality needs the port, not a fitted numerical identification. **Required closure:** attach the existing upstream `CELL_{K→U}` guard at line 9848; no paper edited and no cross-paper failure inferred.

### BH-IIIF-G-0004 — MISSING_CONDITION / moderate / OPEN

**Origin:** `p3:cor:no-independent-lr-gauge-coefficient`, lines **11166–11171**. It says inside only `GRED_7+CAL_GRED(κ)` that `g_L^{-2}=g_R^{-2}=κ f₂/48`. But the preceding theorem lines 11124–11131 first derives the more general `g_s^{-2}=κ r_fib² (f₂ Λ_cut²/48)` and reduces it to `κ f₂/48` **only with** `r_fib Λ_cut=1`. The optional saturation is pre-existing **`BH-IIIF-A-0016`**, separate from calibration `BH-IIIF-A-0012`, as introduced in lines 441–447 and the earlier audit. The later source summary at 20198–20200 also explicitly lists cell saturation, corroborating that this is a missing local condition in the corollary, not an unknown new mechanism.

**Exact test:** `κ=1, f₂=48, r_fib=1, Λ_cut=2` gives `g_s^{-2}=4` by the general reduction, while the stated short expression gives `1`. Nothing in bare `CAL_GRED` forces `r_fibΛ_cut=1`. **Unaffected:** the round-fibre geometric equality `g_L=g_R`, the general reduction coefficient, and the valid saturated special case. **Required closure:** inherit the already-registered `BH-IIIF-A-0016` saturation guard for the absolute numeric corollary and its descendants; do not fabricate a new axiom.

### Prior open issues retained

**`BH-IIIF-G-0001`** — `p3f:cor:v176-first-class-constraint-propagation` (6191–6218), missing complete ADM first-class Poisson-bracket proof. No such proof supplied in this region.

**`BH-IIIF-G-0002`** — `p3f:prop:vacuum-shift-symplectic-scope` (8277–8297), incorrect claim of full off-shell metric symplectic blindness to `aR`. Neither corrected nor contradicted by the separate action/quotient identities in this batch.

## What the independent verification establishes

1. **Cap/UV & bare vacuum:** exact cap and UV jet comparison, static Schur Hessian under regular elimination, unique bare trace root, admissible interval threshold `U>=3C`, positive algebraic trace mass, and non-invariance of vacua under reciprocal map except at special fixed ratio.

2. **Terminal same-action quotients:** the additive zero-order shift and positive action scaling preserve the normalized terminal-vacuum coordinate; this is not a physical vacuum-selection theorem or a new free scalar mode.

3. **Curvature response:** constant-background trace linearization and its degenerate `fʺ=0` branch; independent Weyl/conformal Hessian and on-shell vacuum factorization. The conformal determinant does not contain the full tensor/ghost sector.

4. **Generated Born connection:** exact parent-descended midpoint `ω_B`, nonzero SU2 curvature, projector connection, full restricted holonomy, and two correlated but distinct faithful fibre-spin extensions. The source deliberately excludes independently selected fluctuation fields and physical histories.

5. **Native weak readouts:** explicit dipole zero equation, Bessel-based scalar and one-form norms at three distinct parameter values, source-matched finite-matrix Schur root test, CS/barrier polynomial and pure-gauge Lorentzian instability. Analytic infinite-operator gap, full Morse/index and matter-coupled status remain at imported/evidence-limited scopes.

6. **Seven-dimensional reduction:** exact normalized left/right Haar cross-average, equality of round-fibre averaged generator metrics, and general conditional gauge coefficient. Generator basis `κ` and optional compact-cell saturation are **distinct conditions**, not independent emergent physics.

7. **Euclidean vs Lorentzian locality:** QLOC yields only the Euclidean local derivative-controlled branch; a physical Lorentz action/continuation plus explicit `IR_{2∂}` bound is needed for the macrolocal readout.

## Claim-by-claim source dispositions

| ID | Lines | Statement | Disposition | Exact domain/verification boundary | E3/E4 |
|---|---:|---|---|---|---:|
| BH-IIIF-C-0162 | 9073–9100 | Same-chart cap/UV Hessian separation | VERIFIED | Same signed cap f_c and separate UV quadratic target; matching necessary only after same-chart normalization P>0; P=U numerical diagnostic is optional. | 1 |
| BH-IIIF-C-0163 | 9112–9127 | Actual curvature-Schur and coherent-oscillation test | VERIFIED | Actual complete parent W(R,z), regular stationary z elimination with invertible Hzz; equality of static Hessians is not an oscillation pole. | 2 |
| BH-IIIF-C-0164 | 9167–9202 | Exact bare two-root vacuum and trace mass | VERIFIED | Bare undressed f_b, 0<C<U, complete source-free constant-curvature trace without new Lambda, root only physically in prescribed action interval. | 6 |
| BH-IIIF-C-0165 | 9216–9228 | Born-even response does not imply reciprocal vacua | VERIFIED | Bare algebraic vacuum trace unique; reciprocal invariance of normalized response does not imply reciprocal vacuum action symmetry. | 5 |
| BH-IIIF-C-0166 | 9252–9312 | Laurent--Legendre terminal scalar-remnant representative | REPRODUCED | Same-action dressed endpoint Euler P(C7)=C7 and inverse-Euler representative; positive action scale and renormalization are a separate quotient. | 1 |
| BH-IIIF-C-0167 | 9331–9357 | Native cyclic zero-order completion and \(\mathrm{REN}_0\) nonduplication | REPRODUCED | Exact finite cyclic REN0 and generated terminal action on already-certified same action; the cyclic zero term is not a new action occurrence. | 1 |
| BH-IIIF-C-0168 | 9369–9381 | Historical rank-two K16/K48 local-jet classification | REPRODUCED | Only historical rank-two K16/K48 local jet and matching role; no new independent global junction dynamics. | 1 |
| BH-IIIF-C-0169 | 9383–9405 | Historical rank-two GP-exact matching at the K16 coefficient freeze | REPRODUCED | Source-free metric and scalar K16 matching under independent no-distributional-curvature-layer and no extra junction stress conditions; not complete Israel matching without those. | 1 |
| BH-IIIF-C-0170 | 9417–9454 | Positive multiplicative kernel of the TERM--REN action | VERIFIED | Complete same action with TERM/REN both transformed, positive overall factor and additive common zero-order shift; matter/source variation normalized consistently. | 1 |
| BH-IIIF-C-0171 | 9473–9493 | PQTI relative coefficient on the same-action quotient | VERIFIED | Same-action positive quotient, PQTI ratio invariant; fixed dimensions/field owner and no independent physical member selection. | 1 |
| BH-IIIF-C-0172 | 9507–9524 | REN-aware terminal constant-curvature condition | VERIFIED | Constant-curvature terminal vacuum on normalized fbar=f-2Lambda with terminal Z_C>0; not a blanket vacuum at C. | 1 |
| BH-IIIF-C-0173 | 9542–9555 | Normalized terminal-vacuum datum | VERIFIED | Positive Z_C and terminal constant curvature, normalized endpoint C/2 in action quotient; no claimed realized history. | 1 |
| BH-IIIF-C-0174 | 9564–9611 | Trace-linearized scalaron mass | VERIFIED | Four-dimensional trace relation on constant background with fixed Lambda and differentiable source; f twice differentiable at R0; mass formula only fsecond!=0, physical mode requires full solution. | 2 |
| BH-IIIF-C-0175 | 9634–9656 | Derived smooth-MRESP scalaron endpoint criterion | REPRODUCED | Smooth MRESP family on (C,R+], Z_C>0; limit m_s²→+infinity is algebraic; no constant-curvature vacuum family existence. | 2 |
| BH-IIIF-C-0176 | 9668–9690 | Conformal Hessian of the complete local curvature density | VERIFIED | Compact boundaryless/compact-support 4D Riemannian constant-curvature background, C² local density including cosmological term; conformal scalar restriction only. | 1 |
| BH-IIIF-C-0177 | 9700–9716 | Vacuum scalaron factor and dimensionless Hessian | VERIFIED | Vacuum RFprime=2F and Fsecond!=0; dimensionless conformal Hessian is not full gravity fluctuation determinant. | 2 |
| BH-IIIF-C-0178 | 9734–9799 | Imported nonlinear response realization atlas | FORMALIZED | Imported REG, TERM, CRP4, PQTI and nonlinear response roles are typed; definition not physical proof by itself. | 0 |
| BH-IIIF-C-0179 | 9801–9939 | MRESP specialization of the local metric equation | INCONSISTENT | MRESP imported complete action on LORdir or source-certified CONTcl, compact metric variations, f C1 and fprime(R) C2; equation valid, but one Kp/U sentence omits upstream CELL_KtoU condition explicitly restored later. | 1 |
| BH-IIIF-C-0180 | 9955–9974 | Geometric gauge--gravity split of the reciprocal role | REPRODUCED | Round vector fibre isometry algebra SU2_L×SU2_R; scalar circle is only metric-free representation role until separate calibration. | 0 |
| BH-IIIF-C-0181 | 10018–10041 | Canonical local pullback of the compact GRED carrier | VERIFIED-CONDITIONAL | Pullback along already generated diffeomorphism j_x, no arbitrary bundle topology/gluing; local principal SU2 only. | 2 |
| BH-IIIF-C-0182 | 10067–10120 | Parent-descended Born connection and homogeneous uniqueness certificate | VERIFIED-CONDITIONAL | Parent-Cartan basic descent supplies ω_B, Born-fixed homogeneous uniqueness, nonflat SU2; no independent physical fluctuation family generated. | 2 |
| BH-IIIF-C-0183 | 10158–10167 | Full restricted holonomy of the canonical Born connection | VERIFIED | SU2 full restricted holonomy from span of noncommuting midpoint curvature; no faithful Hopf-U1 reduction of full connection. | 2 |
| BH-IIIF-C-0184 | 10177–10202 | Protected-projector ancestry of the midpoint connection | VERIFIED | Protected rank-two Clifford projectors in chosen chiral U(n) frame, same induced midpoint connection; physical adiabatic action separate. | 2 |
| BH-IIIF-C-0185 | 10219–10333 | Canonical fibre-spin extensions and generated joint operator | REPRODUCED | Structure-group extensions and joint Dirac anchor from source-generated ω_B and W_L⊕W_R, K nonzero spectator, GP2 licensed constructor; no selected fluctuations or physical occupation. | 2 |
| BH-IIIF-C-0186 | 10413–10432 | A nonconstant Born-equivariant zero mode | VERIFIED | Smooth native dipole mode u=epsilon q3; uniqueness only /epsilon/≤1 under imported spectral gap, no particle-state occupation. | 4 |
| BH-IIIF-C-0187 | 10458–10485 | Closed normalization of the supplied dipole zero | VERIFIED | Round S3 normalized scalar/1-form norms for native dipole; κa is offset slope of that root, not measured mass. | 4 |
| BH-IIIF-C-0188 | 10537–10555 | Quantified shifted signed root | REPRODUCED | Compact selfadjoint native signed Dirac with simple zero, gap g, bounded V and exact /e/+w/t/<g/90; finite-matrix E3 is diagnostic, not operator-scale proof. | 1 |
| BH-IIIF-C-0189 | 10587–10618 | Displacement coefficients and an explicit residual bound | REPRODUCED | Same native signed-gap and analytic perturbation, target e, Schur/Kato remainder bound; separate independent full-operator certificate not completed. | 1 |
| BH-IIIF-C-0190 | 10660–10704 | The generated weak doublet is the trivial G15 class with pure fixed isotropy | REPRODUCED | Generated relative vector bundle with fixed induced Born lift, unmarked G15 class trivial, fixed isotropy; not generic U2 or arbitrary principal bundle classification. | 1 |
| BH-IIIF-C-0191 | 10726–10737 | Discharge of Paper I-B's provisional native \(SU(2)\) premise | REPRODUCED | Imported I-B Hvert provider role discharged on this generated SU2 and Born connection; no generic descent fibre count. | 1 |
| BH-IIIF-C-0192 | 10755–10766 | Minimal Born protection before midpoint specialization | REPRODUCED | Smooth connections preserving the specific native exchange lift and I-B metric/index domain; half CS, holonomy and odd kernel imported, analytic gap separate. | 0 |
| BH-IIIF-C-0193 | 10777–10809 | The weak Morse mode is the protected Dirac crossing coordinate | REPRODUCED | Round homogeneous YM pure-gauge midpoint with gauge quotient and protected Dirac alignment; coordinate polynomial E3, full Morse spectrum from I-B import. | 1 |
| BH-IIIF-C-0194 | 10821–10837 | Native common-heat barrier normalization | VERIFIED-CONDITIONAL | Native source-heat branch with g₂²=2π² from V-A, R proper-time convention, only matching-datum barrier not observed particle mass. | 1 |
| BH-IIIF-C-0195 | 10850–10871 | Pure-gauge Lorentzian midpoint instability | VERIFIED | Same classical Lorentz homogeneous YM truncation, t=Rτ proper time, x=0 equilibrium, matter backreaction not included. | 1 |
| BH-IIIF-C-0196 | 10934–10962 | Normalized Born vector ratio submersion | FORMALIZED | Residual optional physical GRED7 branch selects equal auxiliary vector fibre metrics, r_fib=Rmom; no scalar circle metric. | 2 |
| BH-IIIF-C-0197 | 10964–11019 | Displayed connection, fibre average, and Yang--Mills convention | FORMALIZED | GRED basis Γ_AB=κ r_fib²δ_AB, normalized Haar measure, YM coefficient convention; optional r_fib Λcut=1 is independent BH-IIIF-A-0016. | 2 |
| BH-IIIF-C-0198 | 11030–11043 | Protected scalar rank and corner weight | REPRODUCED | Protected octet unique IR scalar object and separate corner 1/8 coefficient, sourced from III-B; no multiplication of their meanings. | 1 |
| BH-IIIF-C-0199 | 11053–11059 | Totally geodesic diagonal vector fibres | VERIFIED | Round diagonal graph under two positive constant product weights, affine isometry of bi-invariant connection; vanishing O’Neill T. | 2 |
| BH-IIIF-C-0200 | 11075–11088 | Geometric left--right equality on the round vector fibre | VERIFIED | Geometric equality of isometric left/right round fibre ideals under common basis convention; no absolute coupling or cell condition implied. | 2 |
| BH-IIIF-C-0201 | 11096–11144 | Seven-dimensional Born-spherical connection reduction | VERIFIED-CONDITIONAL | Optional GRED7, CAL(κ), EH coefficient f₂Λcut²/48, and additional CELL_GRED_SAT only for dimensionless κ f₂/48 formula; 8D comparison not used. | 2 |
| BH-IIIF-C-0202 | 11166–11177 | Calibrated absolute left--right coefficient | INCONSISTENT | As written, formula κ f₂/48 is asserted under GRED7+CAL alone, although κ r_fib² f₂Λcut²/48 only collapses after optional CELL_GRED_SAT; localized missing condition. | 2 |
| BH-IIIF-C-0203 | 11179–11192 | Separation of the connection reduction and bulk diagnostic | VERIFIED-CONDITIONAL | 7D connection normalization separated from independent BULK8 and MATCH8→7; absolute f₂/48 requires inherited optional saturation and κ representative. | 1 |
| BH-IIIF-C-0204 | 11204–11214 | Conditional Euclidean quasi-locality | VERIFIED-CONDITIONAL | QLOC with semiclassical Euclidean spectral derivative expansion on local U0; no Lorentzian inference. | 0 |
| BH-IIIF-C-0205 | 11229–11246 | Conditional Lorentzian macrolocality | VERIFIED-CONDITIONAL | QLOC+Euclidean expansion, LORdir or fixed CONTcl preserving sign/field, normed IR2∂ remainder; no global cosmology from local macrolocal sector. | 0 |

## Formal proof environments examined

- **9101–9110** follows `BH-IIIF-C-0162`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **9128–9133** follows `BH-IIIF-C-0163`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **9203–9214** follows `BH-IIIF-C-0164`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **9229–9233** follows `BH-IIIF-C-0165`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **9314–9329** follows `BH-IIIF-C-0166`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **9358–9367** follows `BH-IIIF-C-0167`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **9407–9415** follows `BH-IIIF-C-0169`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **9456–9471** follows `BH-IIIF-C-0170`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **9495–9505** follows `BH-IIIF-C-0171`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **9526–9540** follows `BH-IIIF-C-0172`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **9557–9562** follows `BH-IIIF-C-0173`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **9613–9632** follows `BH-IIIF-C-0174`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **9658–9665** follows `BH-IIIF-C-0175`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **9691–9698** follows `BH-IIIF-C-0176`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **9717–9722** follows `BH-IIIF-C-0177`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **9941–9953** follows `BH-IIIF-C-0179`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **9976–9983** follows `BH-IIIF-C-0180`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **10043–10065** follows `BH-IIIF-C-0181`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **10122–10140** follows `BH-IIIF-C-0182`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **10168–10175** follows `BH-IIIF-C-0183`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **10203–10209** follows `BH-IIIF-C-0184`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **10335–10398** follows `BH-IIIF-C-0185`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **10433–10456** follows `BH-IIIF-C-0186`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **10486–10510** follows `BH-IIIF-C-0187`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **10556–10585** follows `BH-IIIF-C-0188`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **10619–10640** follows `BH-IIIF-C-0189`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **10705–10724** follows `BH-IIIF-C-0190`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **10738–10753** follows `BH-IIIF-C-0191`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **10767–10775** follows `BH-IIIF-C-0192`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **10810–10819** follows `BH-IIIF-C-0193`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **10838–10848** follows `BH-IIIF-C-0194`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **10872–10879** follows `BH-IIIF-C-0195`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **11045–11051** follows `BH-IIIF-C-0198`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **11061–11073** follows `BH-IIIF-C-0199`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **11090–11094** follows `BH-IIIF-C-0200`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **11146–11164** follows `BH-IIIF-C-0201`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **11216–11227** follows `BH-IIIF-C-0204`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

- **11248–11257** follows `BH-IIIF-C-0205`; source text frozen in the JSON proof-anchor and formal claim statement ledger.

## Formal remarks examined

- **9135–9149** — Positive Euclidean auxiliary-block diagnostic; read as a source scope/negative-control statement, not automatic proof of a physical occurrence.

- **9151–9161** — K16 current identification is an equality test; read as a source scope/negative-control statement, not automatic proof of a physical occurrence.

- **10142–10154** — Born inheritance and the homogeneous comparison family; read as a source scope/negative-control statement, not automatic proof of a physical occurrence.

- **10881–10893** — Downstream firewall; read as a source scope/negative-control statement, not automatic proof of a physical occurrence.

- **10912–10929** — Parameter versus Born connection comparison; read as a source scope/negative-control statement, not automatic proof of a physical occurrence.

- **11194–11202** — Optional scalar-circle metric branch; read as a source scope/negative-control statement, not automatic proof of a physical occurrence.

- **11259–11265** — Forward realization interface deferred; read as a source scope/negative-control statement, not automatic proof of a physical occurrence.

## Consumed unnamed equations and interfaces

- **B5-U01 / 9073–9133:** Cap/UV same-chart equality requires equality of normalized jets; Schur elimination is static, retarded pole is dynamical.

- **B5-U02 / 9135–9161:** Positive Euclidean auxiliary-block K′(s) PSD and full K16 current is a same-action/same-clock equality test.

- **B5-U03 / 9167–9245:** Bare positive trace root exists as algebraic root; physical interval and realized solution are separate.

- **B5-U04 / 9252–9555:** Terminal Euler, additive REN shift and positive multiplicative quotient act on the same action and matter-source normalization.

- **B5-U05 / 9369–9405:** Historical rank-two junction requires no independent distributional curvature layer, not just scalar flux.

- **B5-U06 / 9564–9729:** Trace mass and conformal Hessian are separate on-shell scalar readouts; TT determinant requires additional blocks.

- **B5-U07 / 9801–9949:** MRESP variation is local; U-Kp comparison additionally needs imported CELL_KtoU; the source is self-qualifying at 9929.

- **B5-U08 / 9955–10120:** Round SU2 diagonal vector fibre carries full Spin4 isometry; parent Cartan descent fixes one nonflat midpoint connection.

- **B5-U09 / 10158–10398:** Protected projectors share midpoint SU2 connection; full fibre-spin extensions co-realize correlated source on two distinct factor roles.

- **B5-U10 / 10413–10510:** Native nonconstant zero and Bessel mean normalization; gap uniqueness conditional for |ε|<=1.

- **B5-U11 / 10537–10640:** Simple signed root under bounded perturbation uses I-B gap/slope; finite matrix is limited E3 certificate.

- **B5-U12 / 10660–10775:** Relative-vertical native class and fixed induced exchange are not generic mixed U2 bundle classification.

- **B5-U13 / 10777–10893:** Round pure-gauge Morse/Dirac alignment and barrier are not complete matter-coupled history or cosmological event.

- **B5-U14 / 10934–11094:** Equal round auxiliary fibre metrics, normalized Haar and generator convention; geometric equality independent of absolute gauge coefficient.

- **B5-U15 / 11096–11202:** GRED coefficient κr²f2Λ²/48, dimensionless specialization only after optional cell saturation; BULK8 separate.

- **B5-U16 / 11204–11265:** QLOC plus Euclidean local derivative expansion not Lorentzian; LOR and normed IR2∂ bridge required.

## Specialized condition registry (first-known in this region)

These are sourced, typed domain specializations, **not** G0/GP axioms. Conditions `BH-IIIF-A-0001`, `0010`, `0011`, `0012`, `0016`, `0053`, `0056`, `0058`, and the Paper III-E `CELL_{K→U}` are **inherited**, not declared again.

- **BH-IIIF-A-0080 / source line 9114 (DOMAIN):** Complete same-action W(R,z) with invertible stationary Hessian Hzz; dynamic scalaron pole additionally uses full kinetic-normalized retarded inverse.

- **BH-IIIF-A-0081 / source line 9169 (DOMAIN):** Bare undressed same-action f_b, 0<C<U, no separate Lambda, source-free constant scalar curvature, action domain [C,U].

- **BH-IIIF-A-0082 / source line 9254 (NORMALIZATION):** Euler endpoint P(C7)=C7 with paired TERM and REN in one physical action, raw ZC>0 for normalized end datum; action and source scale jointly.

- **BH-IIIF-A-0083 / source line 9383 (BOUNDARY):** Historical rank-two junction uses source-matched identical geometric metric and excludes an independent surface curvature/distributional stress layer; current continuity alone is insufficient.

- **BH-IIIF-A-0084 / source line 9566 (REGULARITY):** Differentiable family of four-dimensional metric trace equations at a constant-background R0,T0 with fixed Lambda; f twice differentiable at R0 and regular d/dε commute with Box; fsecond nonzero only on wave branch.

- **BH-IIIF-A-0085 / source line 9670 (DOMAIN):** Four-dimensional Riemannian constant scalar background with C2 F(R), compact support or boundaryless integration-by-parts, and conformal g=exp(2σ)gbar.

- **BH-IIIF-A-0086 / source line 9803 (PHYSICAL-IDENTIFICATION):** ACT_MRESP direct or source-certified classical-continuation normalized action on compact interior U0, complete matter source and local MRESPcl regularity.

- **BH-IIIF-A-0087 / source line 10020 (DOMAIN):** Generated Paper III-B ratio diffeomorphism j_x, scalar-diagonal SU2 quotient, and actual III-A reciprocal position chart U.

- **BH-IIIF-A-0088 / source line 10078 (DOMAIN):** Parent-generated basic SU2 midpoint connection ωB=1/2(θx+θp) and exact Born action; full holonomy and fibre-spin images are derived.

- **BH-IIIF-A-0089 / source line 10222 (DOMAIN):** Generated P_B/ω_B and both multiplication-side embeddings into Spin(4), faithful W_L⊕W_R, any nonzero generated finite spectator K; no independent fluctuations.

- **BH-IIIF-A-0090 / source line 10415 (REGULARITY):** Native spatial Cartan insertion u=εq3 with |ε|≤1 for uniqueness, nonhomogeneous-gap prerequisite; exact mode exists for all permitted finite ε.

- **BH-IIIF-A-0091 / source line 10529 (REGULARITY):** Native selfadjoint spatial Dirac with simple zero and gap g, bounded perturbation V of size w, and |e|+w|t|<g/90.

- **BH-IIIF-A-0092 / source line 10660 (DOMAIN):** Generated principal vertical SU2 role with induced inversion-equivariant lift on source spatial sphere and specified M8 relative quotient; not an arbitrary U2 bundle.

- **BH-IIIF-A-0093 / source line 10779 (DOMAIN):** Specified round homogeneous SU2 Yang–Mills pure-gauge A=fΘ branch and physical gauge quotient; no claim for complete matter-coupled Hessian.

- **BH-IIIF-A-0094 / source line 10823 (NORMALIZATION):** Imported Paper V-A common-heat g2²=2π² matched to same round Yang–Mills group and proper time t=Rτ.

- **BH-IIIF-A-0095 / source line 10936 (DOMAIN):** Optional GRED7 homogeneous physical round-fibre connection member, equal auxiliary vector round metric factors, normalized Haar measure; fibre radius r_fib=Rmom.

- **BH-IIIF-A-0096 / source line 10970 (NORMALIZATION):** Generator conventions κ and normalized Γ_AB=κr_fib²δ_AB and source YM coefficient convention; κ=1 vs κ=1/4 are distinct basis choices.

- **BH-IIIF-A-0097 / source line 11206 (DOMAIN):** Semiclassical Euclidean local spectral derivative action in U0 with QLOC bound and complete higher-derivative remainder.

- **BH-IIIF-A-0098 / source line 11231 (PHYSICAL-IDENTIFICATION):** Actually occurring LORdir or source/field-matched CONTcl plus normed IR2∂(ε*) bound on retained higher-variation terms.

## Adversarial attacks and adjudication

- **BH-IIIF-ATTACK-B5-0001 / p3f:thm:v2188-bare-vacuum-trace:** Use reciprocal response symmetry to claim two distinct bare vacua or positive scalaron outside action interval. **Verdict:** REJECTED: paper excludes second vacuum and out-of-domain physical interpretation.

- **BH-IIIF-ATTACK-B5-0002 / p3f:thm:v266-gp-exact-k16-junction-condition:** Continuity of scalar R and scalar flux alone fails distributional traceless Israel matching. **Verdict:** OUT OF PRINTED DOMAIN: source explicitly excludes an independent surface curvature layer; retain boundary guard.

- **BH-IIIF-ATTACK-B5-0003 / p3f:cor:v181-full-born-holonomy:** Reduce full generated nonflat SU2 midpoint connection to a faithful Hopf U1. **Verdict:** REJECTED: theorem correctly excludes connection-faithful U1 reduction.

- **BH-IIIF-ATTACK-B5-0004 / p3:thm:local-fR-field-equation:** Set Rmom=1, U=1, Kp=6 with raw U=Λ_EH² and test unqualified U=(3/π)Kp. **Verdict:** VALID LOCAL SCOPE INCONSISTENCY at 9848, not a counterexample to the normalized metric variation theorem.

- **BH-IIIF-ATTACK-B5-0005 / p3:cor:no-independent-lr-gauge-coefficient:** Choose GRED7+CAL_GRED but r_fibΛcut=2; compare stated κf₂/48 with general reduction κr_fib² f₂Λcut²/48. **Verdict:** VALID MISSING SCOPE GUARD in corollary as written; source elsewhere includes saturation on specialized branch; original geometric equality intact.

- **BH-IIIF-ATTACK-B5-0006 / p3f:thm:generated-fibre-spin-joint-operator:** Collapse co-realized SU2_L×SU2_R to diagonal H and maintain faithful W_L⊕W_R and both fluctuation directions. **Verdict:** REJECTED: theorem retains independent representation roles while canonical background curvatures remain correlated.

- **BH-IIIF-ATTACK-B5-0007 / p3f:thm:native-shifted-signed-root:** Assume finite 5×5 Schur witness proves all spectrum estimates for infinite native S3 operator. **Verdict:** NOT A REFUTATION; evidence frontier retained REPRODUCED on whole operator claim.

## Proof DAG status and audit boundary

37 source-anchored material imported proof-use edges, 23 quarantined candidates, 6 equation/nonmaterial references, 37 statement-only refs, 50 new specialized scope edges and 24 inherited scope edges. Every target result has one route object and exact-source text; candidate and citation edges are excluded from theorem proof traversal. 114 explicit cross-references resolve uniquely. No remote theorem was retroactively audited.

**Cumulative after Batch 5:** 205/442 named results, 154/364 proof environments, 39/66 formal remarks. **Next Batch 6:** lines 11,273–14,514. The global DAG Atlas and ProofChainAudits latest-only ZIPs are intentionally deferred until the final batch. These staged files are not a completed globally integrated Atlas.
