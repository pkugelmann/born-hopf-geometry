# Paper III-F — Rigorous Verification DAG Audit, Batch 8 (v1_1)

- **Authoritative source:** `Paper3F-CompleteDynamics-v1_256.tex`; Framework `Paper00-PapersMinimal-v2_370`.
- **Protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4`.
- **Coverage:** lines **17,238–20,000**; **54/54 named results**, **54/54 proof environments**, **0 formal remarks**, **20 reviewed unnamed material section clusters**.
- **Frozen source SHA256:** `47d43b2d08b2245ade810eae64a9e1cc827398f60899af0afed7cb2398358a77`.
- **Independent evidence:** **37 E3** and **8 E4** checks; no failing final control. Earlier two harness convention/symbolic simplification mistakes corrected before evidence freeze.
- **New in-domain issues:** **none confirmed**. Five inherited issues remain **OPEN**, not modified by this batch.
- **Claim dispositions:** 15 `VERIFIED`, 20 `VERIFIED-CONDITIONAL`, 19 `REPRODUCED`.
- **Integrity:** 85 explicit refs/eqrefs resolve uniquely in the current frozen corpus; no unresolved/ambiguous reference. Stable claim IDs C-0334–C-0387.

## Principal audited mathematical routes

1. **Full finite-source Cauchy and spherical systems (C-0334–0340):** A velocity-dependent Hermitian generator contributes to the Cauchy Hessian and action energy. The native spherical metric–scalar kinetic determinant, curvature trace and full off-constraint constraint-flow identities pass independent symbolic controls. Positive graviton and regular first-jet restrictions remain explicit.
2. **Finite orbit/characteristic evolution and gauge moment (C-0341–0344):** The KKS finite orbit form and finite source gauge bracket are checked. Joint characteristic existence and local nonlinear graph continue to depend on the regular Legendre chart and imported II-A / IV-B theorems. The finite gauge moment identity does **not** establish the missing complete ADM first-class bracket of G-0001.
3. **Independent Ricci/Hopf/source ports (C-0345–0352):** Independent lapse/scale Ricci contacts, fixed positive Cauchy inverse, charge-one physical Hopf oscillator and retarded chain derivatives are tested. Two-metric-work adjoints, central source contact and noncommuting common-interior Schur variance pass. An assumed complete physical source or global realization is not derived.
4. **Finite spectral/source and cold tail (C-0353–0357):** Positive finite spectral moments, nullity and controlled remainder; gapped finite-CAR state with bounded scale variation, finite epoch correction and sign-population bounds pass. Exact source pole versus interpreted continuum particle poles remains a separate identification.
5. **Coupled FLRW and terminal handoff (C-0358–0363):** Exact algebraic lapse preservation, terminal momentum budget, constrained nonminimal corner jump with its crucial p=1 endpoint, and action-residual Stieltjes estimate pass. Local Peano handoff does not prove global passage; smooth finite heat locality does not imply sharp projector locality.
6. **Transverse geometry, boundary Schur and physical work (C-0364–0381):** Positive shared-interior square, curved hyperbolic target and local tangent transfer, native transverse scalar operator/pump and source response terms, positive same-action fourth-grade remainder, normalized fRR overlaps, Gaussian logdet, regular analytic K16 exclusion and static curl obstruction are checked. Some full imported three-test response calculations remain reproduced, not independently certified.
7. **Pure Dirac conformal and sixth-order ports (C-0382–0387):** Unitary fixed-pairing conformal Dirac/heat and noncommuting localizer derivatives pass; independent algebra verifies the cited a6 normalization and Kottler Ward/trace/anisotropy consistency. **No full independent variation of the complete raw a6 Euler tensor** was obtained. These remain a mathematical raw response, not physical tidal matter.

## Open issue carry-forward (none newly confirmed)

1. **BH-IIIF-G-0001 (MODERATE; `p3f:cor:v176-first-class-constraint-propagation`, lines 6191–6218)** — Full coupled ADM first-class bracket and propagation certificate absent; finite source gauge-moment closure in C-0344 is not this proof. **Required:** Compute the smeared ADM/scalar-tensor/gauge bracket algebra on the exact physical quotient with all boundary terms.
2. **BH-IIIF-G-0002 (MODERATE; `p3f:prop:vacuum-shift-symplectic-scope`, lines 8275–8297)** — Off-shell full metric symplectic current changes under an aR affine shift; prior proposed insensitivity is incorrect. **Required:** Correct the claim by distinguishing the curvature second derivative from the full covariant metric symplectic form.
3. **BH-IIIF-G-0003 (MINOR; `p3:thm:local-fR-field-equation`, lines 9848)** — A source identification U=(3/pi)K_p loses the imported CELL qualifier in one sentence. **Required:** Restore CELL at the exact source claim location; do not alter valid metric field equation.
4. **BH-IIIF-G-0004 (MODERATE; `p3:cor:no-independent-lr-gauge-coefficient`, lines 11166–11171)** — Absolute g_L^(-2)=g_R^(-2)=κ f_2/48 requires optional fibre-cutoff saturation; equality alone is robust. **Required:** Insert r_fib Lambda_cut=1 or display the general r_fib² Lambda_cut² factor.
5. **BH-IIIF-G-0005 (MODERATE; `p3f:prop:v1118-feshbach-propagation-not-genesis`, lines 13225–13229)** — Full-row-rank rectangular couplings need not have a positive product singular value; previous lower gap bound false. **Required:** State a sufficient product injectivity/alignment condition and retain exact Schur formulas independently.

The original issue anchors lie outside Batch 8; no full cross-paper impact traversal or repair is claimed here. The source's correct conditional theorems are not reclassified as defects for lacking physical occurrence.

## Exact claim-by-claim disposition

| Claim | Lines | Printed title | E1/E3/E4 disposition | E3 / E4 |
|---|---:|---|---|---:|
| BH-IIIF-C-0334 | 17252–17289 | Source-corrected Cauchy matrix and action energy | `VERIFIED-CONDITIONAL` | 1 / 0 |
| BH-IIIF-C-0335 | 17333–17346 | Native positive-graviton scalar coordinate bound | `VERIFIED` | 1 / 0 |
| BH-IIIF-C-0336 | 17361–17400 | Native spherical action and exact kinetic determinant | `VERIFIED-CONDITIONAL` | 1 / 0 |
| BH-IIIF-C-0337 | 17427–17437 | Native curvature trace with the residual source retained | `VERIFIED` | 1 / 0 |
| BH-IIIF-C-0338 | 17456–17513 | Local spherical first-jet Cauchy construction | `REPRODUCED` | 1 / 0 |
| BH-IIIF-C-0339 | 17536–17556 | Regular first-jet canonical matching | `VERIFIED-CONDITIONAL` | 1 / 0 |
| BH-IIIF-C-0340 | 17580–17603 | Spherical quadratic metric principal block | `VERIFIED` | 1 / 0 |
| BH-IIIF-C-0341 | 17639–17667 | Inherited finite-state orbit form | `VERIFIED` | 1 / 0 |
| BH-IIIF-C-0342 | 17688–17733 | Joint source--geometry characteristic flow | `REPRODUCED` | 0 / 0 |
| BH-IIIF-C-0343 | 17768–17783 | Local nonlinear graph, source spectrum and action work | `REPRODUCED` | 0 / 0 |
| BH-IIIF-C-0344 | 17794–17810 | Complete finite gauge moment and constraint propagation | `VERIFIED-CONDITIONAL` | 1 / 0 |
| BH-IIIF-C-0345 | 17852–17876 | Independent lapse and scale contacts of curvature | `VERIFIED` | 1 / 0 |
| BH-IIIF-C-0346 | 17888–17911 | Fixed-Cauchy causal Ricci inverse | `VERIFIED-CONDITIONAL` | 1 / 0 |
| BH-IIIF-C-0347 | 17938–17965 | Canonical four-dimensional physical Hopf mode | `VERIFIED-CONDITIONAL` | 1 / 0 |
| BH-IIIF-C-0348 | 17991–18031 | Complete action and causal-source composition | `VERIFIED` | 1 / 0 |
| BH-IIIF-C-0349 | 18048–18068 | The complete two metric-work ports | `VERIFIED` | 1 / 0 |
| BH-IIIF-C-0350 | 18084–18105 | Complete stress tests and exact moving-range execution | `REPRODUCED` | 0 / 0 |
| BH-IIIF-C-0351 | 18147–18174 | Shared-interior variance and terminal compatibility | `VERIFIED` | 1 / 2 |
| BH-IIIF-C-0352 | 18211–18250 | Complete finite-source metric response | `VERIFIED-CONDITIONAL` | 1 / 0 |
| BH-IIIF-C-0353 | 18266–18292 | Positive spectral moments, exact nullity and error | `VERIFIED` | 1 / 0 |
| BH-IIIF-C-0354 | 18335–18344 | Full-pole obstruction and explicit-matter interpretation | `REPRODUCED` | 0 / 0 |
| BH-IIIF-C-0355 | 18385–18419 | Finite-source cold tail under bounded scale variation | `VERIFIED-CONDITIONAL` | 1 / 0 |
| BH-IIIF-C-0356 | 18432–18443 | Finite-epoch error and positivity certificate | `VERIFIED-CONDITIONAL` | 1 / 0 |
| BH-IIIF-C-0357 | 18454–18469 | Monotone massive sign-population tails | `VERIFIED` | 1 / 0 |
| BH-IIIF-C-0358 | 18505–18537 | Coupled normal form and exact lapse preservation | `VERIFIED-CONDITIONAL` | 1 / 0 |
| BH-IIIF-C-0359 | 18560–18583 | Terminal momentum budget and the required trace | `VERIFIED-CONDITIONAL` | 1 / 0 |
| BH-IIIF-C-0360 | 18611–18638 | Local compatible terminal handoff | `REPRODUCED` | 0 / 1 |
| BH-IIIF-C-0361 | 18667–18687 | Full nonminimal corner-energy identity | `VERIFIED-CONDITIONAL` | 1 / 0 |
| BH-IIIF-C-0362 | 18709–18727 | Finite-frontier locality certificate | `REPRODUCED` | 0 / 0 |
| BH-IIIF-C-0363 | 18756–18788 | Action residuals, vacuum roots and trace stability | `VERIFIED-CONDITIONAL` | 1 / 0 |
| BH-IIIF-C-0364 | 18838–18860 | Frozen Schur square with physical kinetic pairing | `VERIFIED` | 1 / 0 |
| BH-IIIF-C-0365 | 18873–18881 | Analytic regular reduction and the cubic critical point | `REPRODUCED` | 0 / 1 |
| BH-IIIF-C-0366 | 18892–18930 | Geometric work and conditional local tangent loading | `VERIFIED-CONDITIONAL` | 2 / 0 |
| BH-IIIF-C-0367 | 18956–18979 | Matched normal balance with the residual scalar port | `REPRODUCED` | 0 / 0 |
| BH-IIIF-C-0368 | 19031–19051 | Surviving support and the native curvature test | `VERIFIED` | 1 / 0 |
| BH-IIIF-C-0369 | 19063–19120 | Native geodesic transverse operator with complete source contacts | `VERIFIED-CONDITIONAL` | 1 / 0 |
| BH-IIIF-C-0370 | 19143–19177 | Evaluated native potential and frozen metric-trace contact | `VERIFIED-CONDITIONAL` | 1 / 0 |
| BH-IIIF-C-0371 | 19199–19222 | Closed-curvature correction to the kinetic instability test | `REPRODUCED` | 0 / 0 |
| BH-IIIF-C-0372 | 19230–19250 | Canonical finite-harmonic pump and its source conjugation | `VERIFIED` | 1 / 0 |
| BH-IIIF-C-0373 | 19260–19276 | Geometric exchange cancels in the constituent work | `REPRODUCED` | 0 / 0 |
| BH-IIIF-C-0374 | 19291–19331 | Complete finite boundary pullback and moving-contact derivatives | `VERIFIED-CONDITIONAL` | 1 / 0 |
| BH-IIIF-C-0375 | 19358–19397 | Same-action positive-remainder criterion for grade-four susceptibility | `VERIFIED-CONDITIONAL` | 1 / 0 |
| BH-IIIF-C-0376 | 19417–19462 | Three exact action-level coefficients for one curvature susceptibility | `REPRODUCED` | 1 / 0 |
| BH-IIIF-C-0377 | 19480–19501 | Finite Gaussian determinant jets when the integration is licensed | `VERIFIED-CONDITIONAL` | 1 / 0 |
| BH-IIIF-C-0378 | 19512–19529 | Exact scalar response requires both operator and source matching | `REPRODUCED` | 0 / 0 |
| BH-IIIF-C-0379 | 19545–19559 | Regular analytic elimination cannot create the exact K16 kink | `REPRODUCED` | 0 / 2 |
| BH-IIIF-C-0380 | 19573–19583 | Causal support is retained by the admitted Schur composition | `REPRODUCED` | 0 / 0 |
| BH-IIIF-C-0381 | 19594–19611 | Static metric integrability test for a scalar envelope | `REPRODUCED` | 0 / 1 |
| BH-IIIF-C-0382 | 19658–19700 | Exact conformal Dirac and heat loads | `VERIFIED-CONDITIONAL` | 2 / 1 |
| BH-IIIF-C-0383 | 19718–19747 | Complete conformal--shape contacts | `VERIFIED` | 1 / 0 |
| BH-IIIF-C-0384 | 19759–19773 | Algebraic Weyl weights under the same conformal map | `REPRODUCED` | 0 / 0 |
| BH-IIIF-C-0385 | 19784–19812 | Ordinary-Dirac sixth-jet Euler representative and coefficient | `REPRODUCED` | 1 / 0 |
| BH-IIIF-C-0386 | 19860–19917 | Exact raw Kottler Euler ports and their competing signs | `REPRODUCED` | 1 / 1 |
| BH-IIIF-C-0387 | 19972–19984 | Scalar overlap does not erase the evaluated tidal ports | `VERIFIED` | 1 / 0 |

## Evidence-level and DAG semantics

- **E0:** The 85 source reference resolutions and SHA/coverage validation are integrity, not mathematical proofs.
- **E1:** Every source-as-printed formal claim and its own proof (54 pairs) was retained verbatim in JSON, with full theorem and proof source ranges. The 20 unnamed material section clusters are indexed separately.
- **E3:** Thirty-seven separately coded algebraic, finite-matrix, variational and numerical tests passed. A finite representative test may verify only a displayed identity, not the strongest existence or physical interpretation in the entire theorem.
- **E4:** Eight adversarial/negative controls passed. Invalid attacks caused by omitted p=1 corner conditions or by test-harness sign/simplification errors were corrected, not promoted into manuscript findings.
- **Typed material proof dependencies:** 19 source-witnessed links registered as `IMPORTED_PROOF, SOURCE_PREMISE`; 3 unpromoted candidates. 23 specialized new first-known source-condition records and 31 explicitly reused pre-existing condition-use edges. Conditions are **not** new fundamental axioms.
- **Imported certification boundary:** II-A characteristic flow, full IV-B propagator transport, positive heat/locality provider, physical choice of the scalar/source action, and full imported unprojected sixth-order Euler evaluation have not all been globally independently recertified.
- **Multi-agent limitation:** Separate review passes were performed sequentially by a single model/runtime, not by independent agents; independence refers to distinct test computations, not personnel.

## Theorem boundary and adversarial ledger

- `BND-IIIF-B8-001` **p3f:thm:v2190-joint-characteristic-flow** — A C³ locally regular inverse Legendre chart + finite-state orbit establishes local characteristic existence, not global solution, canonical physical state or constraint algebra.
- `BND-IIIF-B8-002` **p3f:cor:v2190-complete-gauge-constraint** — Prelicensed finite group moment Lie closure must not be promoted to full coupled first-class ADM bracket closure (G-0001).
- `BND-IIIF-B8-003` **p3f:thm:v2216-causal-ricci-inverse** — Positive fixed-Cauchy local inverse on a bounded regular interval does not imply arbitrary global Ricci-history realization or physical action.
- `BND-IIIF-B8-004` **p3f:thm:v2216-shared-response** — Same physical interior variable must be eliminated once from the *sum* of actions; separate Schur complements can overcount and are not the same proof route.
- `BND-IIIF-B8-005` **p3f:thm:v2216-local-terminal-handoff** — Peano local handoff with tangent data is not global incoming/outgoing history or physical completion.
- `BND-IIIF-B8-006` **p3f:thm:v2216-finite-locality** — Smooth finite-stage heat/localizer estimates do not imply a sharp spectral projector is quasi-local.
- `BND-IIIF-B8-007` **p3f:thm:v286-same-action-grade-four-survival** — Positive remainder within a shared complete action is a conditional lower bound; no physical occurrence of positive remainder follows.
- `BND-IIIF-B8-008` **p3f:thm:v2212-a6-kottler-ports** — Raw ordinary-Dirac sixth heat Euler response has no automatic physical source/tidal matter identification; full independent Euler variation remains uncompleted.
- `BND-IIIF-B8-009` **p3f:cor:v2212-scalar-overlap-tidal-ports** — Scalar-only h(R) subtraction does not erase Weyl-sector anisotropy; mixed quotient action not equivalent.
- `BND-IIIF-B8-010` **p3f:prop:v2210-lit-analytic-projection** — An exact K16 kink cannot arise from finite regular analytic eliminations under common analytic fixed-rank hypotheses; does not rule out singular/nonanalytic physical inputs.

## Coverage and release policy

- **Cumulative Paper III-F:** **387/442** named results, **305/364** proof environments, **56/66** formal remarks.
- **Next source batch (9):** lines **20,001–23,747**; 55 named results and 59 proofs remain across the final region (10 remarks remain).
- **Export policy:** This intermediate batch saves a Markdown audit and JSON proof/DAG evidence ledger. Consolidated successor **DAG Atlas ZIP** and **ProofChainAudits ZIP** are generated only after the last source batch, with only latest applicable versions and full archive integrity validation.
- **Full-paper classification:** Not yet classified: current state is `PARTIALLY_AUDITED_WITH_OPEN_PRIOR_GAPS` pending Batch 9.
