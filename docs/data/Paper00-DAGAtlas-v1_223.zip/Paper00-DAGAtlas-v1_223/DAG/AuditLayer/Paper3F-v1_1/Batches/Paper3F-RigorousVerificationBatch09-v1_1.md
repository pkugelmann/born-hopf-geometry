# Paper III-F — rigorous verification Batch 9 (final source region)

**Target:** `Paper3F-CompleteDynamics-v1_256.tex`; lines 20,001–23,747 (framework v2_370). **SHA-256:** `47d43b2d08b2245ade810eae64a9e1cc827398f60899af0afed7cb2398358a77`. **Protocol:** v2_4. Source content has not been modified.

**Scope:** 55/55 named results, 59/59 proof environments (including four separate proof blocks within the end-of-paper consequences), 10/10 remarks; 20 material unnamed equation/claim clusters. E0 file and reference integrity is not independent correctness evidence.

**Disposition:** VERIFIED=21; VERIFIED-CONDITIONAL=22; REPRODUCED=12. **E3:** 38 independent scoped tests; **E4:** 11 adversarial/scope controls; all passed their defined predicates. No new mathematical defect confirmed. These check certificates do not establish every imported geometric/physical proof or actual physical occurrence.

## Named claim census, exact statement and proof

### BH-IIIF-C-0388: Coefficient-complete native Schur response

**theorem; source:** `p3f:thm:v226-response-reconstruction`, lines 20668–20682. **Disposition:** `REPRODUCED`.

**Typed condition nodes:** BH-IIIF-A-0132, BH-IIIF-A-0161. **Independent checks:** none (E1 only; imported certificates not globally reproduced).

```tex

\begin{theorem}[Coefficient-complete native Schur response]
\label{p3f:thm:v226-response-reconstruction}
Let an actual same-action elimination supply a finite response $M(z)$ on
an admitted domain, and suppose its retained native fibre lies in
$\mathcal A_D$ (or in the tensor extension of
Corollary~\ref{p1b:cor:v226-source-jets}). Then
\[
 M(z)=\sum_{j=1}^{137}m_j(z)D_j,
 \qquad m_j(z)=\operatorname{Tr}(E_jM(z)).
\]
Holomorphic derivatives and residues at admitted isolated poles obey the
same inverse. Source and metric derivatives obey it in a fixed frame, or
with the common transported-frame covariant derivatives. Thus all native
operator, residue and consumed-jet matching is coefficient-complete.
\end{theorem}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
Apply the complex-linear inverse of
Theorem~\ref{p1b:thm:v226-dual-coefficients} pointwise. In finite dimension
it commutes with differentiation and contour integration, including the
residue contour. The source-jet and tensor statements are the cited corollary.
\end{proof}

```

### BH-IIIF-C-0389: The complete Schur handoff needs only finitely many energies

**corollary; source:** `p3f:cor:v227-finite-handoff`, lines 20704–20713. **Disposition:** `REPRODUCED`.

**Typed condition nodes:** BH-IIIF-A-0132, BH-IIIF-A-0161. **Independent checks:** none (E1 only; imported certificates not globally reproduced).

```tex

\begin{corollary}[The complete Schur handoff needs only finitely many energies]
\label{p3f:cor:v227-finite-handoff}
Two actual finite Hermitian complete Schur words with the same retained
and consumed source target, common kinetic normalization and complementary
sizes at most $m$ agree meromorphically once their full matrices agree at
$m+1$ distinct upper-half-plane energies. All consumed order-$k$ source
jets agree meromorphically after the enlarged tests of
Corollary~\ref{p1b:cor:v227-response-jets}. Equality then passes to their
admitted Green responses and contour poles/residues.
\end{corollary}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
Use Theorem~\ref{p1b:thm:v227-finite-response}; use the common inverse
on its regular domain and integrate around common admitted pole contours.
For a native target, the preceding 137-coefficient inverse supplies every
sample matrix. Larger targets retain their actual complete frames.
\end{proof}

```

### BH-IIIF-C-0390: An exact scalar-isospectral ambiguity of the charged source grammar

**proposition; source:** `p3f:prop:v246-charged-marked-isospectral-ambiguity`, lines 20736–20770. **Disposition:** `VERIFIED`.

**Typed condition nodes:** BH-IIIF-A-0175. **Independent checks:** BH-IIIF-EV-B09-006.

```tex

\begin{proposition}[An exact scalar-isospectral ambiguity of the charged source grammar]
\label{p3f:prop:v246-charged-marked-isospectral-ambiguity}
Fix the rooted role and right frames
$U=(g_e,g_\mu,c)$ and $V^\sharp=(h_e,h_\tau,c)$, and positive
coefficients $e\ne m$, $t>0$. On the algebraic three-corner source domain put
\[
 M_0=eB_e+mB_\mu+tB_\tau,
 \qquad L_\theta g_e=\cos\theta\,g_e+\sin\theta\,g_\mu,
 \quad L_\theta g_\mu=-\sin\theta\,g_e+\cos\theta\,g_\mu,
 \quad L_\theta c=c,
 \qquad M_\theta=L_\theta M_0.
\]
Then the three arrows $L_\theta B_r$ retain the same hierarchy corner
supports, rank one and Hilbert--Schmidt norm one. Every unordered singular
value and every scalar heat trace of the finite chiral operator
$h_\theta=\left(\begin{smallmatrix}0&M_\theta\\M_\theta^\dagger&0\end{smallmatrix}\right)$
is independent of $\theta$:
\[
 \operatorname{Tr}e^{-\tau h_\theta^2}
   =2(e^{-\tau e^2}+e^{-\tau m^2}+e^{-\tau t^2})
 \quad(\tau>0).
\]
Nevertheless the \emph{fixed rooted} left electron source
$j_e=(g_e,0)^T$ has the exact resolvent
\[
 \boxed{j_e^\dagger(zI-h_\theta)^{-1}j_e
 =\cos^2\theta\frac{z}{z^2-e^2}
  +\sin^2\theta\frac{z}{z^2-m^2},\qquad
 \|(M_\theta M_\theta^\dagger-e^2I)g_e\|^2
 =(m^2-e^2)^2\sin^2\theta.}
\]
Thus three-corner membership, unit source-arrow norms, the entire scalar
spectrum and all uninserted scalar heat moments together do not imply
the marked electron response.
\end{proposition}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
$L_\theta$ commutes with $Q_0$ and $Q_\perp$, so left multiplication
preserves all three source corners, ranks and norms. The polar Hopf
identities give $M_0M_0^\dagger=e^2P_e+m^2P_\mu+t^2Q_0$;
left multiplication gives its conjugate by $L_\theta$, while
$M_\theta^\dagger M_\theta=M_0^\dagger M_0$. These prove the heat formula.
The left compression of the chiral resolvent is
$z(z^2I-M_\theta M_\theta^\dagger)^{-1}$.
The fixed $g_e$ has squared overlaps $\cos^2\theta$ and $\sin^2\theta$
with the first two eigenlines. Spectral decomposition gives both displayed
identities.
\end{proof}

```

### BH-IIIF-C-0391: A one-contraction electron test on an independently certified spectral floor

**proposition; source:** `p3f:prop:v246-electron-spectral-floor-test`, lines 20799–20812. **Disposition:** `VERIFIED`.

**Typed condition nodes:** BH-IIIF-A-0175. **Independent checks:** BH-IIIF-EV-B09-007.

```tex

\begin{proposition}[A one-contraction electron test on an independently certified spectral floor]
\label{p3f:prop:v246-electron-spectral-floor-test}
Let $B=MM^\dagger$ be the actual normalized action return and let
$g_e$ be the actual normalized tagged left source. If the same action has
\emph{independently} established $e^2I\le B\le\Lambda I$, then with
$d_0=g_e^\dagger Bg_e-e^2$ one has
\[
 \boxed{0\le\|(B-e^2I)g_e\|^2\le(\Lambda-e^2)d_0.}
\]
Consequently the exact electron mass-only response holds if and only if the
single contraction $d_0$ vanishes. The lower spectral bound is indispensable:
a mean equal to an interior spectral value need not make its probe an
eigenvector.
\end{proposition}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
For $A=B-e^2I$, spectral calculus gives $0\le A^2\le(\Lambda-e^2)A$.
Contract with $g_e$. If $d_0=0$, positivity gives $A^{1/2}g_e=0$ and hence
$Ag_e=0$; the converse is immediate. The existing tagged chiral-resolvent
theorem then applies. If the bound is unavailable, use all three actual
contractions of Proposition~\ref{p3f:prop:v245-electron-actual-block-defect}.
\end{proof}

```

### BH-IIIF-C-0392: The endpoint cap mismatch is an interior metric Hessian defect

**proposition; source:** `p3f:prop:v246-cap-metric-hessian-defect`, lines 20826–20857. **Disposition:** `VERIFIED-CONDITIONAL`.

**Typed condition nodes:** BH-IIIF-A-0176, BH-IIIF-A-0134, BH-IIIF-A-0161. **Independent checks:** BH-IIIF-EV-B09-008.

```tex

\begin{proposition}[The endpoint cap mismatch is an interior metric Hessian defect]
\label{p3f:prop:v246-cap-metric-hessian-defect}
Let $f_+=\bar f^{\rm L}_{2\mid7}$ on its admitted lower collar, and
let $f_c$ satisfy the hypotheses of
Theorem~\ref{p3f:thm:v224-reference-cap-parent}, with $R_s^2=UC$.
Choose positive density normalizations $\nu_+,\nu_c$ and constants $a,b$
so the scalar densities
\[
 \Phi_+=\nu_+f_+,\qquad \Phi_c=\nu_cf_c+a+bR
\]
agree in value and first derivative at $C$. Let $g_r$ be a smooth
family of constant-scalar-curvature metrics on one fixed interior patch,
with $R[g_r]=r\downarrow C$ and regular limit $g_C$. Assume the
actual compactly supported metric test variations and pairings are
transported smoothly along this family. For
$I_\bullet[g]=\int\sqrt{|g|}\,\Phi_\bullet(R[g])$, one has
\[
 \boxed{\lim_{r\downarrow C}(D^2 I_c-D^2 I_+)_{g_r}[h,k]
 =k_C\int\sqrt{|g_C|}\,\delta R_C[h]\,\delta R_C[k],
 \qquad k_C=\nu_cf_c''(C)>0.}
\]
The right side has a nonzero rank-one fourth-order principal symbol
at every nonzero covector $\xi$:
\[
 k_C\bigl(\xi^\mu\xi^\nu h_{\mu\nu}-\xi^2
                 g_C^{\mu\nu}h_{\mu\nu}\bigr)^2.
\]
The irrelevant common Fourier sign in $\delta R$ disappears on squaring.
Compact-interior boundary contributions cannot cancel this defect.
An invertible derivative-free metric field change preserves its
nonzero principal rank. Positive whole-action rescaling preserves it.
\end{proposition}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
Write $\Delta\Phi=\Phi_c-\Phi_+$. Twice differentiating
$\sqrt{|g|}\Delta\Phi(R[g])$ gives one term
$\sqrt{|g|}\Delta\Phi''\delta R[h]\delta R[k]$;
every other term contains $\Delta\Phi$ or $\Delta\Phi'$.
The latter vanish in the limit by endpoint alignment, whereas
$\Delta\Phi''\to\nu_cf_c''(C)$ because $f_+''(C)=0$.
The asserted regularity permits passing the limit through compact
test integrals. The two-derivative principal symbol of scalar-curvature
linearization is, up to its common sign,
$L_\xi(h)=\xi^\mu\xi^\nu h_{\mu\nu}-\xi^2\operatorname{tr}_g h$.
In dimension four $L_\xi$ is a nonzero linear form for every nonzero
$\xi$, also for a null Lorentzian covector. Thus $k_CL_\xi^*L_\xi$
has rank one. Under a derivative-free field chart with invertible
Jacobian $J$, the fourth-order symbol transforms by $J^*(\cdot)J$.
The additional chain-rule term pairs the action Euler covector with
the pointwise second derivative of the chart and has no fourth-order
principal part. Rank is therefore preserved. Boundary variations
vanish on the stated compact-interior tests.
\end{proof}

```

### BH-IIIF-C-0393: Sharp scaling required for a terminal scalaron cancellation

**proposition; source:** `p3f:prop:v246-singular-scalaron-cancellation`, lines 20887–20903. **Disposition:** `VERIFIED`.

**Typed condition nodes:** BH-IIIF-A-0176, BH-IIIF-A-0134, BH-IIIF-A-0161, BH-IIIF-A-0170. **Independent checks:** BH-IIIF-EV-B09-009.

```tex

\begin{proposition}[Sharp scaling required for a terminal scalaron cancellation]
\label{p3f:prop:v246-singular-scalaron-cancellation}
Consider a one-dimensional retained curvature port and a finite positive
scalaron block on $\chi>0$. Suppose
\[
 C_F^{-1}=\chi(T_0+o(1)),\qquad T_0>0,\qquad
 B_F=\chi^{-p}(B_0+o(1)),\quad B_0\ne0,
\]
and the direct coefficient tends to $k_C>0$. If its stationary Schur
coefficient tends to zero, then necessarily
\[
 \boxed{p=\tfrac12,\qquad B_0^*T_0B_0=k_C.}
\]
More generally, the bound $\|C_F^{-1}\|\le M\chi$ and convergence
$B_F^*C_F^{-1}B_F\to k_C>0$ imply
$\liminf\sqrt\chi\,\|B_F\|\ge\sqrt{k_C/M}$.
\end{proposition}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
The return is
$\chi^{1-2p}(B_0^*T_0B_0+o(1))$. Its leading coefficient is strictly
positive. A finite nonzero limit therefore requires $1-2p=0$ and
the stated coefficient equality. For the general assertion use
$B_F^*C_F^{-1}B_F\le M\chi\|B_F\|^2$ and take the lower limit.
\end{proof}

```

### BH-IIIF-C-0394: Nonlocal causal memory is not a one-history action Hessian

**proposition; source:** `p3f:prop:v246-causal-hessian-integrability`, lines 20930–20941. **Disposition:** `VERIFIED`.

**Typed condition nodes:** stated source hypotheses in full quote; no new node needed. **Independent checks:** none (E1 only; imported certificates not globally reproduced).

```tex

\begin{proposition}[Nonlocal causal memory is not a one-history action Hessian]
\label{p3f:prop:v246-causal-hessian-integrability}
Let $\Gamma[q]$ be a twice continuously differentiable scalar
functional of one real history with compact-interior test variations.
Suppose its Hessian has distribution kernel $K(t,s)$ and is retarded,
so $\operatorname{supp}K\subseteq\{t\ge s\}$. Then
\[
 \boxed{\operatorname{supp}K\subseteq\{t=s\}.}
\]
In particular a nonzero memory kernel away from the time diagonal in
Theorem~\ref{p3f:thm:v2216-source-response} cannot itself be this Hessian.
\end{proposition}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
Symmetry of the second Fr\'echet differential gives $K(t,s)=K(s,t)$
distributionally. Retarded support and its transposed support then
intersect only on the time diagonal. A nonzero off-diagonal retarded
term contradicts that intersection.
\end{proof}

```

### BH-IIIF-C-0395: An exact causal parent for the admitted finite source

**theorem; source:** `p3f:thm:v246-finite-source-influence-parent`, lines 20961–21007. **Disposition:** `VERIFIED-CONDITIONAL`.

**Typed condition nodes:** BH-IIIF-A-0177, BH-IIIF-A-0144, BH-IIIF-A-0160. **Independent checks:** BH-IIIF-EV-B09-011.

```tex

\begin{theorem}[An exact causal parent for the admitted finite source]
\label{p3f:thm:v246-finite-source-influence-parent}
On the actual finite source domain of
Theorem~\ref{p3f:thm:v2216-source-response}, let $H[q](t)=H(t,q(t))$ be
its complete time-local Hermitian generator, including its central contact,
in the fixed inherited clock and frame. Work on a finite interval
$[t_i,t_f]$, with histories in $C([t_i,t_f],O)$ in the uniform norm.
Assume $H$ and its first two control derivatives are jointly continuous
on a compact tube about the base history. Let $\rho_i$ be its supplied
positive trace-one initial
density, held fixed under the stated source variation. Write $U_q$ for
its unitary propagator from $t_i$ to $t_f$, with
$i\hbar\partial_tU_q=H[q](t)U_q$. Define
\[
 Z[q_+,q_-]=\operatorname{Tr}(U_{q_+}\rho_iU_{q_-}^\dagger),\qquad
 \Gamma[q_+,q_-]=-i\hbar\log Z[q_+,q_-].
\]
There is a unique continuous logarithm with $\log Z[q,q]=0$ on a
sufficiently small simply connected neighborhood of each diagonal
history. Thus $\Gamma[q,q]=0$, and on that neighborhood
\[
 Z[q_-,q_+]=Z[q_+,q_-]^*,\qquad |Z|\le1,\qquad
 \Gamma[q_-,q_+]=-\Gamma[q_+,q_-]^*,\qquad
 \operatorname{Im}\Gamma=-\hbar\log|Z|\ge0.
\]
Put
$q_\pm=q_c\pm q_\Delta/2$ and
$B=\partial_qH$, $Q=\partial_q^2H$ on the admitted local control
member, with $\langle B(t)\rangle=\operatorname{Tr}(\rho_i B_H(t))$
and the analogous convention for $Q$. Its exact diagonal physical derivatives are
\[
 \boxed{\left.\frac{\delta\Gamma}{\delta q_\Delta(t)}\right|_{q_\Delta=0}
       =-\langle B(t)\rangle,}
\]
\[
 \boxed{\left.\frac{\delta^2\Gamma}
 {\delta q_\Delta(t)\delta q_c(s)}\right|_{q_\Delta=0}
 =-\langle Q(t)\rangle\delta(t-s)
 +\frac{i}{\hbar}\Theta(t-s)
          \langle[B_H(t),B_H(s)]\rangle.}
\]
In the manuscript's $\hbar=1$ source units this is exactly the
complete causal source-action kernel already evaluated there. It is
a mixed Hessian of the doubled-history parent, whose transposed
branch block has advanced support; hence it obeys the symmetry of a
full second differential without making a single block time symmetric.
\end{theorem}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
Finite-dimensional unitary evolution and smooth dependence on the
supplied coefficients give continuous $Z$ and its stated variations.
On the diagonal unitarity and trace normalization give $Z[q,q]=1$;
continuity therefore gives a convex product neighborhood with
$|Z-1|<1/2$, on which the principal logarithm has the stated regularity
and normalization. Swapping the two histories
conjugates the trace. Also
$Z=\operatorname{Tr}(\rho_iU_{q_-}^\dagger U_{q_+})$ is a convex
combination of diagonal matrix elements of a unitary in an eigenbasis
of $\rho_i$, so $|Z|\le1$. The normalized logarithm then gives the
stated conjugation and nonnegative imaginary part. Duhamel's identity
\[
 \delta U_q(t_f,t_i)
 =-\frac{i}{\hbar}\int_{t_i}^{t_f}
 U_q(t_f,t)\delta H(t)U_q(t,t_i)\,dt
\]
gives $\delta_+\Gamma=-\langle\delta H\rangle$ and
$\delta_-\Gamma=+\langle\delta H\rangle$ on the diagonal.
The difference-coordinate derivative is their half difference.
Differentiation in the common coordinate varies the actual unitary
history and the insertion. The former is the retarded commutator
term and the latter is the displayed $Q$ contact, by the same
Duhamel identity. This gives the boxed mixed kernel. Transposition
interchanges both time arguments and branch indices of the complete
second differential, proving the final assertion.
\end{proof}

```

### BH-IIIF-C-0396: Exact finite mean-source Euler parent on a constituted common branch

**corollary; source:** `p3f:cor:v246-finite-mean-source-euler-parent`, lines 21047–21079. **Disposition:** `REPRODUCED`.

**Typed condition nodes:** BH-IIIF-A-0177, BH-IIIF-A-0144. **Independent checks:** none (E1 only; imported certificates not globally reproduced).

```tex

\begin{corollary}[Exact finite mean-source Euler parent on a constituted common branch]
\label{p3f:cor:v246-finite-mean-source-euler-parent}
Suppose $S_0[q]$ is an actually constituted classical action on the
same source-control chart, with its inherited source incidence,
clock, physical normalization and boundary conditions. Work on a common
differentiable history subspace on which $S_0$ is $C^2$ and the source
functional above restricts continuously (for example sufficiently smooth
histories with the actual endpoint rule). Retain the actual $H[q]$ and fixed initial $\rho_i$ of the theorem, and assume
their source contribution has not already been included in $S_0$.
Then the locally defined doubled functional
\[
 \boxed{\mathcal I[q_c,q_\Delta]
 =S_0[q_c+q_\Delta/2]-S_0[q_c-q_\Delta/2]
                   +\Gamma[q_c+q_\Delta/2,q_c-q_\Delta/2]}
\]
generates the exact finite-source mean equation and its causal
linearization:
\[
 \left.\frac{\delta\mathcal I}{\delta q_\Delta(t)}\right|_0
 =\frac{\delta S_0}{\delta q(t)}-\langle B(t)\rangle,
 \qquad
 \left.\mathcal I_{\Delta c}\right|_0=D^2S_0-K_q^{\rm force}.
\]
In addition $\rho$ obeys the exact finite equation
$i\hbar\dot\rho=[H[q],\rho]$ with its supplied initial condition.
These are exact differential identities. Setting the mean Euler
expression to zero is the declared stationarity problem; existence or
occurrence of its self-consistent solution is not proved here.
No continuum measure or semiclassical expansion of the finite source
trace enters these identities. The classical control remains a
classical mean field; a quantum measure for that control is a separate
construction.
\end{corollary}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
The difference-coordinate derivative of the classical difference is
the first variation of $S_0$; its common-coordinate derivative is the
full second variation with the actual boundary rule. Add the two
identities of the theorem. The density equation follows by
differentiating $\rho(t)=U_q(t,t_i)\rho_iU_q(t,t_i)^\dagger$.
\end{proof}

```

### BH-IIIF-C-0397: Native lapse, scale and scalar influence ports with their Ward identity

**theorem; source:** `p3f:thm:v247-native-influence-ward`, lines 21114–21176. **Disposition:** `REPRODUCED`.

**Typed condition nodes:** BH-IIIF-A-0177, BH-IIIF-A-0144, BH-IIIF-A-0160, BH-IIIF-A-0138. **Independent checks:** none (E1 only; imported certificates not globally reproduced).

```tex

\begin{theorem}[Native lapse, scale and scalar influence ports with their Ward identity]
\label{p3f:thm:v247-native-influence-ward}
Use exactly the licensed spherical scalar--metric action
\eqref{p3f:eq:native-spherical-action}, its physical multiplier $\hbar$,
and the compatible coordinate-only proper finite source
$h(q)=h(A,B,\phi)$ of
Theorem~\ref{p3f:thm:native-spherical-local-cauchy}, on its actual flat
canonical source frame. Put $q=(A,B,\phi_a)$,
$V_3=\Omega_zAB^2$, and retain lapse $N>0$ before variation.
In the source influence parent of
Theorem~\ref{p3f:thm:v246-finite-source-influence-parent} use the actual
coordinate-time generator
\[
 H[N,q]=Nh(q),\qquad
 i\hbar\dot\sigma=[Nh,\sigma],\qquad
 E=\operatorname{Tr}(\sigma h).
\]
All central, mass-owner and retained interaction terms of $h$ are
included. The exact diagonal difference-coordinate covectors are
\[
 \boxed{F_N:=\Gamma_{N_\Delta}=-E,\qquad
 F_i:=\Gamma_{q_\Delta^i}=-N\operatorname{Tr}(\sigma h_{,i}).}
\]
Their complete action-normalized native ports are therefore
\[
 \boxed{\rho_r=\frac E{\hbar V_3},\quad
 p_{z,r}=-\frac{A\operatorname{Tr}(\sigma h_{,A})}{\hbar V_3},\quad
 p_{\perp,r}=-\frac{B\operatorname{Tr}(\sigma h_{,B})}{2\hbar V_3},\quad
 J_a=\frac{\operatorname{Tr}(\sigma h_{,\phi_a})}{\hbar V_3}.}
\]
For every control history on this source domain, without imposing a
metric equation, these covectors obey the exact reparametrization
Ward identity
\[
 \boxed{\sum_iF_i\dot q^i-N\dot F_N=0.}
\]
Equivalently, with $D_\tau=N^{-1}\partial_t$,
$H_A=D_\tau\log A$, $H_B=D_\tau\log B$,
\[
 \boxed{D_\tau\rho_r+H_A(\rho_r+p_{z,r})
             +2H_B(\rho_r+p_{\perp,r})
       =\sum_aJ_aD_\tau\phi_a.}
\]
For $y^a=(N,q^i)$, let $B_a=H_{,a}$ and $Q_{ab}=H_{,ab}$.
The full retarded source kernel is
\[
 \Gamma_{\Delta a,c b}(t,s)
 =-\langle Q_{ab}(t)\rangle\delta(t-s)
 +\frac i\hbar\Theta(t-s)\langle[B_a(t),B_b(s)]\rangle,
\]
with the actual Heisenberg transport understood in the commutator.
In particular
\[
 B_N=h,\quad B_i=Nh_{,i},\qquad
 Q_{NN}=0,\quad Q_{Ni}=h_{,i},\quad Q_{ij}=Nh_{,ij}.
\]
For every compact control perturbation $(n,u^i)$ its response obeys
the differentiated Ward identity
\[
 \boxed{\sum_i\bigl(\delta F_i\dot q^i+F_i\dot u^i\bigr)
              -n\dot F_N-N\partial_t\delta F_N=0.}
\]
\end{theorem}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
The first covectors are the difference-coordinate derivative of the
finite trace with $H=Nh$. Comparing their coefficient with
\[
 \delta\Gamma\big|_{\Delta=0}
 =\hbar\int NV_3\left[-\rho_r\frac{\delta N_\Delta}{N}
 +p_{z,r}\frac{\delta A_\Delta}{A}
 +2p_{\perp,r}\frac{\delta B_\Delta}{B}
 -\sum_aJ_a\delta\phi^a_\Delta\right]dt
\]
gives all four ports with their absolute signs and volume factors.
Cyclicity of the full finite trace gives
$\dot E=\sum_i\operatorname{Tr}(\sigma h_{,i})\dot q^i$;
the state commutator contributes
$\operatorname{Tr}([Nh,\sigma]h)=0$. This proves the first Ward
identity, and differentiating $V_3=\Omega_zAB^2$ gives the work law.
It also follows from source invariance under
$\delta q^i=\epsilon\dot q^i$,
$\delta N=\partial_t(\epsilon N)$ with compact $\epsilon$:
$\delta H=\partial_t(\epsilon H)$ is a pure change of clock and
leaves the endpoint propagator unchanged. An integration by parts
gives the displayed Ward identity. Duhamel differentiation gives the
kernel, with $Q_{Ni}=h_{,i}$ before any lapse choice. Differentiating
the already proved Ward identity proves its linearized form. No
commuting approximation, one-body factorization or source reset is
used. A central $c(q)I$ drops out of the commutator but contributes
$c,c_{,i},c_{,ij}$ to the stated covectors and contacts.
\end{proof}

```

### BH-IIIF-C-0398: The causal influence equations and the native Cauchy system are equivalent

**corollary; source:** `p3f:cor:v247-native-causal-cauchy-equivalence`, lines 21206–21225. **Disposition:** `REPRODUCED`.

**Typed condition nodes:** BH-IIIF-A-0177, BH-IIIF-A-0144, BH-IIIF-A-0160. **Independent checks:** none (E1 only; imported certificates not globally reproduced).

```tex

\begin{corollary}[The causal influence equations and the native Cauchy system are equivalent]
\label{p3f:cor:v247-native-causal-cauchy-equivalence}
On the same compatible restriction define
\[
 \mathcal I=\hbar S_{g\Phi}[N_+,q_+]
            -\hbar S_{g\Phi}[N_-,q_-]+\Gamma[N_+,q_+;N_-,q_-],
\]
where $S_{g\Phi}=\int L_{g\Phi}dt$ is precisely the native action
above with its inherited endpoint rule, and the source partition
counts no source contribution twice. Its physical mean equations
$\mathcal I_{\Delta}=0$ are exactly the native metric and scalar
equations with the four source ports in the theorem, including the
lapse equation. After lapse variation and the actual compatible
constraint reduction, $N=1$ gives the already derived native local
Cauchy system and its source state equation. Conversely every solution
of that system with its initial lapse constraint and supplied state
solves these causal mean equations. The lapse constraint propagation
is the existing native propagation identity, now owned by this same
influence functional.
\end{corollary}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
The first difference-coordinate derivative of the classical
difference is $\hbar\delta S_{g\Phi}$, while the theorem evaluates
the source derivative. Therefore their sum is the original native
Euler system with the source insertion used in the Cauchy
construction, with no missing lapse/scale mixed contact. The source
work identity is precisely its Ward antecedent. The cited Cauchy
theorem then gives the reduced evolution and constraint propagation.
Conversely its construction reconstructs the complete Euler system
on the constraint. Uniqueness of the finite propagator identifies its
state with the state inside the influence functional.
\end{proof}

```

### BH-IIIF-C-0399: Causal elimination adds no independent memory data and has a quantitative continuation bound

**proposition; source:** `p3f:prop:v247-native-causal-continuation`, lines 21244–21276. **Disposition:** `REPRODUCED`.

**Typed condition nodes:** BH-IIIF-A-0177. **Independent checks:** none (E1 only; imported certificates not globally reproduced).

```tex

\begin{proposition}[Causal elimination adds no independent memory data and has a quantitative continuation bound]
\label{p3f:prop:v247-native-causal-continuation}
Fix a regular proper-time native Cauchy chart and write its classical
state as $x=(q,v)$, with its smooth source-corrected acceleration
field $\dot x=f(x,\sigma)$. For the coordinate-only source under
consideration the native kinetic determinant is nonzero on
$A,B,\mathscr F,\kappa_J>0$. Suppose the coefficients are sufficiently
smooth to be locally Lipschitz on this chart. The source spectrum,
positivity and trace are preserved. Eliminating $\sigma$ with the
fixed initial state gives a causal history equation for $x$ that is
locally equivalent to this finite Cauchy system; it requires no
additional memory initial data.

More quantitatively, let two solutions remain on a compact regular
chart where
\[
 |f(x,\sigma)-f(\widetilde x,\widetilde\sigma)|
 \le L_f(|x-\widetilde x|+\|\sigma-\widetilde\sigma\|_1),\qquad
 \|h(x)-h(\widetilde x)\|\le L_h|x-\widetilde x|.
\]
Then, for $t\ge t_i$ in that common chart,
\[
 \boxed{|x(t)-\widetilde x(t)|+\|\sigma(t)-\widetilde\sigma(t)\|_1
 \le\bigl(|x_i-\widetilde x_i|+\|\sigma_i-\widetilde\sigma_i\|_1\bigr)
 e^{(L_f+2L_h/\hbar)(t-t_i)}.}
\]
If a solution on a finite maximal time interval keeps $x$ in a compact
subset of the regular chart, it extends past that endpoint. Thus a
finite source density by itself cannot terminate this regular local
evolution. A noncompact geometric/velocity escape, degeneration of the
kinetic chart, or failure of the licensed source/domain remains a
separate possible obstruction.
\end{proposition}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
Finite unitary conjugation preserves the source spectrum, hence its
positive trace-one orbit is compact. Variation of constants in the
two state equations, using trace-norm invariance under conjugation
and $\|[A,\sigma]\|_1\le2\|A\|\|\sigma\|_1$, gives
\[
 \|\sigma(t)-\widetilde\sigma(t)\|_1
 \le\|\sigma_i-\widetilde\sigma_i\|_1
       +\frac2\hbar\int_{t_i}^t\|h(x(s))-h(\widetilde x(s))\|ds.
\]
Combining this with the integral equation for $x$ and applying
Gronwall gives the displayed bound. With common initial state the
causal source is uniquely $U_x\sigma_iU_x^\dagger$; inserting it or
retaining its finite state equation are inverse descriptions of the
same solutions, which proves the memory-data assertion. On a compact
regular classical chart times the compact source orbit the full
vector field is bounded and locally Lipschitz, so a finite endpoint
has a limit and the local existence theorem extends it.
\end{proof}

```

### BH-IIIF-C-0400: State-spectrum bounds for the native curvature source

**proposition; source:** `p3f:prop:v247-native-curvature-orbit-bounds`, lines 21297–21325. **Disposition:** `VERIFIED`.

**Typed condition nodes:** BH-IIIF-A-0155. **Independent checks:** BH-IIIF-EV-B09-012.

```tex

\begin{proposition}[State-spectrum bounds for the native curvature source]
\label{p3f:prop:v247-native-curvature-orbit-bounds}
On this same native first-jet branch define the complete Hermitian
trace insertion
\[
 \mathsf T(q)=-h-Ah_{,A}-Bh_{,B}
                       +\sum_a\phi_a h_{,\phi_a},\qquad
 X=\operatorname{Tr}_F\Phi^2.
\]
The actual curvature trace is
\[
 \boxed{R_*=-\frac{2\alpha_\Phi\Lambda_g^2X}{\kappa_J}
            -\frac{\operatorname{Tr}(\sigma\mathsf T)}
                         {2\kappa_J\hbar V_3}.}
\]
Let $p_1\ge\cdots\ge p_d\ge0$ be the inherited, conserved eigenvalues
of $\sigma$, and $t_1(q)\ge\cdots\ge t_d(q)$ the eigenvalues of
$\mathsf T$. Put $R_0=-2\alpha_\Phi\Lambda_g^2X/\kappa_J$. Then
\[
 \boxed{R_0-\frac{\sum_jp_jt_j}{2\kappa_J\hbar V_3}
 \le R_*\le
 R_0-\frac{\sum_jp_jt_{d+1-j}}{2\kappa_J\hbar V_3}.}
\]
These bounds are sharp over the full unitary orbit of the supplied
density spectrum at fixed $q$. They do not assert that a single
actual history reaches either extreme. In particular $R_*$ is
uniformly bounded whenever the actual classical history stays in a
compact regular source chart with $V_3$ bounded away from zero.
\end{proposition}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
Substitute the exact source ports into
\eqref{p3f:eq:native-source-curvature-trace}:
$T_r+\sum_a\phi_aJ_a=\operatorname{Tr}(\sigma\mathsf T)/(\hbar V_3)$.
This gives $R_*$. In a descending eigenbasis of $\mathsf T$, the sum
of any first $k$ diagonal entries of $\sigma$ is
$\sum_j\alpha_jp_j$, with $0\le\alpha_j\le1$ and
$\sum_j\alpha_j=k$, so it is at most $\sum_{j\le k}p_j$.
Summation by parts against the descending $t_j$ gives
$\operatorname{Tr}(\sigma\mathsf T)\le\sum_jp_jt_j$.
Apply the same argument to $-\mathsf T$ for the lower bound.
Aligned and oppositely aligned density eigenbases attain the two
bounds on its full orbit. The curvature inequalities follow because
$2\kappa_J\hbar V_3>0$. Smooth finite source coefficients and positive
volume on a compact chart give the last assertion.
\end{proof}

```

### BH-IIIF-C-0401: Complete constant Einstein--scalar equations with the owned vacuum coefficient

**theorem; source:** `p3f:thm:v248-native-constant-vacua`, lines 21360–21420. **Disposition:** `VERIFIED-CONDITIONAL`.

**Typed condition nodes:** BH-IIIF-A-0178, BH-IIIF-A-0153. **Independent checks:** BH-IIIF-EV-B09-013.

```tex

\begin{theorem}[Complete constant Einstein--scalar equations with the owned vacuum coefficient]
\label{p3f:thm:v248-native-constant-vacua}
On the actual local action domain of
Definition~\ref{p3f:def:v176-local-bosonic-noether-domain}, retain a
fixed action-owned constant density $V_0$ and write
\[
 \mathscr F=\kappa_J-\frac\alpha6\operatorname{Tr}_F\Phi^2,
 \qquad
 \mathcal V=V_0+\alpha\operatorname{Tr}_F(\Phi^4-2L\Phi^2),
 \qquad L=\Lambda_g^2>0.
\]
Here $\kappa_J,\alpha>0$ are the inherited action coefficients. If a
constant term is allocated to a residual source, $V_0$ denotes its
same-owner constant density in this particular vacuum comparison;
setting it to zero is an additional branch specialization, not a
vacuum subtraction. Assume the actual source-free comparison has
zero gauge curvature, $D_\mu\Phi=0$, no other retained source or
metric constituent, and a regular positive-graviton chart
$\mathscr F>0$. Consume the full native scalar equation on its
admitted matrix support, rather than only a selected ray variation.
In particular the actual variation slot must see
$\Phi^3+(R/12-L)\Phi$ faithfully; stationarity of its projection onto
an arbitrary restricted plane does not imply this matrix equation.
The functional throughout is the native ordinary $\operatorname{Tr}_F$.
It is not replaced by a rooted comparison functional without the
separate actual trace-incidence certificate.
Then constant Einstein vacua are exactly
\[
 \boxed{\mathscr F R=2\mathcal V,\qquad
       \Phi^3=(L-R/12)\Phi.}
\]
The zero-scalar solution has $R=2V_0/\kappa_J$.
For a nonzero solution let $n=\operatorname{rank}\Phi$ and write its
nonzero eigenvalues as $\pm v$, $v>0$, with whatever multiplicities
the actual scalar support allows. If
$D_n=6\kappa_J-\alpha nL\ne0$, all its scalar and curvature values
are explicitly
\[
 \boxed{v^2=\frac{6\kappa_JL-V_0}{6\kappa_J-\alpha nL},\qquad
 \mathscr F=\kappa_J-\frac{\alpha n v^2}{6},\qquad
 R=12(L-v^2).}
\]
Only $v^2>0$, $\mathscr F>0$ and the actual allowed spectral patterns
are retained. These algebraic equations are also sufficient for the
stated constant sector when its parallel scalar and Einstein metric
are admitted by the actual bundle/domain.

At $D_n=0$ there is no nonzero rank-$n$ solution unless
$V_0=6\kappa_JL$. If both equalities hold, every admitted
$0<v^2<L$ on that rank obeys the constant equations, with
\[
 \mathscr F=\kappa_J(1-v^2/L),\qquad R=12(L-v^2).
\]
For $g_E=(\mathscr F/\kappa_J)g$ the Einstein coefficient is
$\kappa_J$, and the potential and Einstein scalar curvature on this
exceptional family are exactly
\[
 W_E=\frac{\kappa_J^2\mathcal V}{\mathscr F^2}
          =6\kappa_JL,\qquad R_E=12L.
\]
\end{theorem}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
The native metric equation at a parallel scalar has no derivative
terms and is $2\mathscr F G_{\mu\nu}=-\mathcal V g_{\mu\nu}$.
On an Einstein metric this is the first boxed equation. The native
scalar equation is
$\alpha R\Phi/3+4\alpha(\Phi^3-L\Phi)=0$, giving the second.
Hermiticity implies every nonzero eigenvalue has square
$v^2=L-R/12>0$, and $\operatorname{Tr}_F\Phi^2=nv^2$.
Combining the scalar equation with the metric trace gives
\[
 2\kappa_JR=4V_0-4\alpha Lnv^2,
 \qquad (6\kappa_J-\alpha nL)v^2=6\kappa_JL-V_0.
\]
Solving proves the nondegenerate formulas and the exceptional
alternative. The converse substitutes them in both full constant
equations. In the exceptional case
$\mathcal V=6\kappa_JL(1-v^2/L)^2$, so the Einstein potential is
constant, and constant Weyl scaling gives
$R_E=\kappa_JR/\mathscr F=12L$.
\end{proof}

```

### BH-IIIF-C-0402: Evaluated radial and dormant scalar Hessians at those vacua

**proposition; source:** `p3f:prop:v248-native-vacuum-masses`, lines 21442–21468. **Disposition:** `VERIFIED-CONDITIONAL`.

**Typed condition nodes:** BH-IIIF-A-0178, BH-IIIF-A-0153. **Independent checks:** BH-IIIF-EV-B09-014.

```tex

\begin{proposition}[Evaluated radial and dormant scalar Hessians at those vacua]
\label{p3f:prop:v248-native-vacuum-masses}
On a nonzero vacuum of the theorem use the Einstein metric above and
the canonical scalar kinetic form inherited from that same Weyl
transport. If the scaling ray of its actual matrix $\Phi$ is retained,
its canonically normalized radial potential curvature is
\[
 \boxed{m_{\rm rad}^2
       =\frac{2v^2(6\kappa_J-\alpha nL)}{3\mathscr F}.}
\]
It vanishes on the exceptional family. If a nonzero admissible
Hermitian scalar tangent $T$ is supported in $\ker\Phi$, so
$\Phi T=T\Phi=0$, its canonically normalized potential curvature is
\[
 \boxed{m_{\rm ker}^2=-\frac{2\kappa_Jv^2}{\mathscr F}<0.}
\]
Thus every such dormant scalar direction is an actual negative
direction of the Einstein potential. At the zero-scalar vacuum the
common canonical potential curvature is
\[
 \boxed{m_0^2=\frac{V_0}{3\kappa_J}-2L.}
\]
These are local potential curvatures on the declared source-free
constant sector. They do not by themselves establish a global
Lorentzian instability with unspecified boundary conditions, or the
spectrum of an action with additional source/gauge/higher terms.
\end{proposition}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
On a rank-$n$ scaling ray, put $x=v^2$ so
$\mathscr F=\kappa_J-\alpha nx/6$ and
$\mathcal V=V_0+\alpha n(x^2-2Lx)$. Direct differentiation gives
\[
 \frac{dW_E}{dx}
 =\frac{\alpha n\kappa_J^2}{3\mathscr F^3}
       [(6\kappa_J-\alpha nL)x-(6\kappa_JL-V_0)].
\]
At stationarity its second derivative with respect to $v$ is
$4v^2\alpha n\kappa_J^2(6\kappa_J-\alpha nL)/(3\mathscr F^3)$.
The actual radial kinetic metric is
\[
 G_{vv}=\frac{2\alpha\kappa_J n}{\mathscr F}
         +3\kappa_J(\partial_v\log\mathscr F)^2
       =\frac{2\alpha\kappa_J^2n}{\mathscr F^2}.
\]
Division gives $m_{\rm rad}^2$.
For $\Phi T=T\Phi=0$, the first derivatives of $\mathscr F$ and
$\mathcal V$ vanish, whereas
$\mathscr F''=-\alpha\operatorname{Tr}_FT^2/3$ and
$\mathcal V''=-4\alpha L\operatorname{Tr}_FT^2$.
Using $\mathcal V/\mathscr F=R/2$ gives
\[
 W_E''[T,T]
 =\frac{\kappa_J^2}{\mathscr F^2}
       \alpha(R/3-4L)\operatorname{Tr}_FT^2
 =-\frac{4\alpha\kappa_J^2v^2}{\mathscr F^2}
                      \operatorname{Tr}_FT^2.
\]
Its kinetic norm is
$2\alpha\kappa_J\operatorname{Tr}_FT^2/\mathscr F$, proving the
second formula. At $\Phi=0$ the metric is already Einstein and the
quadratic equation has curvature coefficient $R/6-2L$, which with
$R=2V_0/\kappa_J$ gives the last formula.
\end{proof}

```

### BH-IIIF-C-0403: All-rank obstruction and global potential minimum for the actual bare constant

**corollary; source:** `p3f:cor:v248-bare-all-rank-vacuum`, lines 21506–21536. **Disposition:** `VERIFIED-CONDITIONAL`.

**Typed condition nodes:** BH-IIIF-A-0178, BH-IIIF-A-0153. **Independent checks:** BH-IIIF-EV-B09-015.

```tex

\begin{corollary}[All-rank obstruction and global potential minimum for the actual bare constant]
\label{p3f:cor:v248-bare-all-rank-vacuum}
Use the actual bare constant
$V_0^{\rm bare}=12\kappa_JL$ of
Proposition~\ref{p3f:prop:v2216-bare-heat-vacuum}, with its
same-support coefficient ancestry. On the preceding constant sector
there is no nonzero Hermitian Einstein--scalar vacuum of any rank
with $\mathscr F>0$. The only one is
\[
 \boxed{\Phi=0,\qquad R=24L,\qquad m_0^2=2L.}
\]
More generally, as a function on the entire positive-graviton
Hermitian scalar chart, put
$x=\alpha\operatorname{Tr}_F\Phi^2/(6\kappa_J)\in[0,1)$ and
$Y=\operatorname{Tr}_F\Phi^4\ge0$. The exact formal Einstein
potential of this same truncated local packet is
\[
 \boxed{W_E(\Phi)=\frac{12\kappa_JL}{1-x}
                    +\frac{\alpha Y}{(1-x)^2}
       \ge\frac{12\kappa_JL}{1-x}\ge12\kappa_JL.}
\]
Equality at the lower endpoint holds only for $\Phi=0$; the potential
is strictly increasing on every nonzero retained scaling ray and
blows up at $\mathscr F\downarrow0$. This strengthens the earlier
single canonical-ray result without assuming a full-rank Clifford
ansatz or identifying arbitrary scalar supports. The potential proof
needs only that the actual nonzero configuration retains its scaling
variation. Thus the exclusion of nonzero critical points also applies
on any narrower homogeneous linear scalar support with that property,
even when the full matrix classification hypothesis is unavailable.
\end{corollary}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
For $V_0=12\kappa_JL$, positivity of the formula for $v^2$ would
require $\alpha nL>6\kappa_J$ and give
\[
 v^2=\frac{6\kappa_JL}{\alpha nL-6\kappa_J},\qquad
 \mathscr F=-\frac{6\kappa_J^2}{\alpha nL-6\kappa_J}<0.
\]
The denominator-zero case also fails its required numerator equality.
Thus every nonzero rank is excluded. The origin values follow from
the theorem and proposition. Independently,
$\mathcal V=12\kappa_JL(1-x)+\alpha Y$ and
$\mathscr F=\kappa_J(1-x)$ give the displayed potential identity.
Along a nonzero scaling ray, $x$ grows quadratically and $Y$ quartically,
so both nonconstant nonnegative terms are strictly increasing wherever
$x<1$. The lower bound gives the endpoint divergence.
\end{proof}

```

### BH-IIIF-C-0404: Exact promotion condition for an isolated native quartic extremum

**corollary; source:** `p3f:cor:v248-quartic-vacuum-promotion`, lines 21554–21567. **Disposition:** `VERIFIED-CONDITIONAL`.

**Typed condition nodes:** BH-IIIF-A-0178, BH-IIIF-A-0153. **Independent checks:** none (E1 only; imported certificates not globally reproduced).

```tex

\begin{corollary}[Exact promotion condition for an isolated native quartic extremum]
\label{p3f:cor:v248-quartic-vacuum-promotion}
Suppose an admitted nonzero constant matrix obeys the isolated native
quartic extremum condition $\Phi^3=L\Phi$ with rank $n$. It solves the
coupled constant Einstein--scalar equations only if
\[
 \boxed{R=0,\qquad V_0=\alpha nL^2,\qquad
                    \alpha nL<6\kappa_J.}
\]
These conditions are sufficient on the stated constant geometric
and scalar domain. In particular they cannot hold for the actual
bare $V_0=12\kappa_JL$. Isolated scalar minimization therefore does
not supply the native bare coupled vacuum.
\end{corollary}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
The full scalar equation forces $R\Phi=0$, hence $R=0$.
Then the metric equation requires $\mathcal V=0$; at this quartic
extremum $\mathcal V=V_0-\alpha nL^2$. The strict inequality is exactly
$\mathscr F>0$. For the bare value, the equality would instead force
$\alpha nL=12\kappa_J$, contradicting that inequality. Conversely
these conditions satisfy both constant equations.
\end{proof}

```

### BH-IIIF-C-0405: Explicit finite source actions with the same current and single-role data

**proposition; source:** `p3f:prop:v249-fixed-current-source-nonimplication`, lines 21607–21658. **Disposition:** `VERIFIED`.

**Typed condition nodes:** BH-IIIF-A-0175. **Independent checks:** BH-IIIF-EV-B09-016.

```tex

\begin{proposition}[Explicit finite source actions with the same current and single-role data]
\label{p3f:prop:v249-fixed-current-source-nonimplication}
Use the established left frame $(g_e,g_\mu,c)$ and right frame
$(h_e,h_\tau,c)$ of the rooted negative-Hopf construction, with all vectors
and their phases held fixed. Keep the already generated positive coefficients
$e,m,t$ unchanged. For $0\le\theta<\pi/2$ put
\[
 r_\theta=\cos\theta\,h_\tau+\sin\theta\,h_e,\qquad
 \iota_e=g_eh_e^\dagger,\quad
 \iota_\mu=g_\mu c^\dagger,\quad
 \iota_{\tau,\theta}=cr_\theta^\dagger,
 \qquad M_\theta=e\iota_e+m\iota_\mu+t\iota_{\tau,\theta}.
\]
These concrete finite source words have the same following data:
\begin{enumerate}
\item the native three hierarchy corners
$Q_\perp\operatorname{End}(G)Q_\perp$,
$Q_\perp\operatorname{End}(G)Q_0$,
$Q_0\operatorname{End}(G)Q_\perp$;
\item the three role coefficients, rank-one arrow singular spectra and
unit left returns
$\iota_r\iota_r^\dagger=P_r$, where
$(P_e,P_\mu,P_\tau)=(g_eg_e^\dagger,g_\mu g_\mu^\dagger,Q_0)$;
\item every scalar heat trace of each \emph{separate} weighted chiral arrow,
the fixed left-current map $W_e=(g_e,g_\mu,c)$ and its current Gram,
and the uninserted kinetic pairing $c_FI_L\oplus c_FI_R$;
\item the complete second source moment
$\operatorname{Tr}(M_\theta M_\theta^\dagger)=e^2+m^2+t^2$.
\end{enumerate}
They are realized by the explicit self-adjoint mass-only Hamiltonians
\[
 h_\theta=\begin{pmatrix}0&M_\theta\\M_\theta^\dagger&0\end{pmatrix},
 \qquad
 S_\theta[\Psi]=c_F\int\Psi^\dagger(i\hbar\partial_t-h_\theta)\Psi\,dt,
 \qquad c_F>0.
\]
The current source, clock and any fixed preparation may be held identical.
For a source $M$ put $B=MM^\dagger$ and define
$\mathcal D_e:=\|(B-e^2I)g_e\|^2$; use the subscript $\theta$
for the comparison words. Nevertheless their exact tagged electron resolvents are
\begin{equation}
 \boxed{G_{e,\theta}(z)
 =\frac{z(z^2-t^2)}
 {(z^2-e^2)(z^2-t^2)-e^2t^2\sin^2\theta},\qquad
 \mathcal D_{e,\theta}=e^2t^2\sin^2\theta.}
 \label{p3f:eq:v249-right-overlap-electron-return}
\end{equation}
In particular $G_{e,0}(z)=z/(z^2-e^2)$, while every
$0<\theta<\pi/2$ has a different response.
Thus even the listed data, which are stronger than presently proved for the
actual mass-source arrows, do not imply the electron mass-only closure.
\end{proposition}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
Both $r_\theta$ and $h_e$ are unit vectors in $Q_\perp G$, so every
support, rank and single-arrow return in the list follows by multiplication.
For a weighted rank-one arrow of weight $a$, the six-dimensional chiral
square has spectrum $(a^2,a^2,0,0,0,0)$, proving equality of all separate
heat traces. The current map is unchanged by construction; its role Gram
is $I$, independently of $r_\theta$. Canonical normalization cancels $c_F$.
In the fixed left role frame the complete positive return is
\[
 B_\theta=M_\theta M_\theta^\dagger
 =\begin{pmatrix}
 e^2&0&et\sin\theta\\
 0&m^2&0\\
 et\sin\theta&0&t^2
 \end{pmatrix}.
\]
Its trace is fixed, but its action on $g_e$ contains the displayed nonzero
tau component, giving $\mathcal D_{e,\theta}$.
The left block of the chiral resolvent is $z(z^2I-B_\theta)^{-1}$.
Inverting its electron--tau block proves the rational formula. The
finite CAR anticommutator of this linear source equals its one-particle
resolvent, so no change of state is used to create the difference.
\end{proof}

```

### BH-IIIF-C-0406: Complete tagged response from the mixed fourth source moment on this stronger branch

**proposition; source:** `p3f:prop:v249-fourth-moment-right-overlap`, lines 21683–21727. **Disposition:** `VERIFIED`.

**Typed condition nodes:** BH-IIIF-A-0175. **Independent checks:** BH-IIIF-EV-B09-017.

```tex

\begin{proposition}[Complete tagged response from the mixed fourth source moment on this stronger branch]
\label{p3f:prop:v249-fourth-moment-right-overlap}
Suppose, independently, that the \emph{actual} three-corner source has the
unit, current-aligned arrows
\[
 \begin{gathered}
 \iota_e=g_er_e^\dagger,\qquad
 \iota_\mu=g_\mu r_\mu^\dagger,\qquad
 \iota_\tau=cr_\tau^\dagger,\\
 \|r_e\|=\|r_\mu\|=\|r_\tau\|=1,
 \quad r_e,r_\tau\in Q_\perp G,\quad r_\mu\in Q_0G.
 \end{gathered}
\]
Let $M=e\iota_e+m\iota_\mu+t\iota_\tau$, $B=MM^\dagger$, and retain
its actual complete mixed scalar contraction
\[
 \Delta_4:=\operatorname{Tr}B^2-(e^4+m^4+t^4).
\]
Then the full tagged electron mass-only response is exactly
\[
 \boxed{0\le\Delta_4\le2e^2t^2,\qquad
 \mathcal D_e=\frac{\Delta_4}{2},\qquad
 G_e(z)=\frac{z(z^2-t^2)}
 {(z^2-e^2)(z^2-t^2)-\Delta_4/2}.}
\]
For $0<\Delta_4<2e^2t^2$ it has four simple source-visible poles
$\pm\sqrt{\lambda_-},\pm\sqrt{\lambda_+}$, with
\[
 \lambda_\pm=\frac{e^2+t^2
       \pm\sqrt{(e^2-t^2)^2+2\Delta_4}}2,
\]
\[
 \boxed{\operatorname*{Res}_{z=\pm\sqrt{\lambda_-}}G_e
       =\frac{t^2-\lambda_-}{2(\lambda_+-\lambda_-)},\qquad
 \operatorname*{Res}_{z=\pm\sqrt{\lambda_+}}G_e
       =\frac{\lambda_+-t^2}{2(\lambda_+-\lambda_-)}.}
\]
All four residues are positive. In this independently certified branch,
$\Delta_4=0$ proves not only the electron return but the complete three-role
left-return identity
\[
 \boxed{B=e^2P_e+m^2P_\mu+t^2P_\tau.}
\]
It does not choose a preferred right frame.
\end{proposition}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
Set $\gamma=r_e^\dagger r_\tau$. The muon mixed terms vanish by the
orthogonal right supports. The electron--tau block of $B$ is
$\left(\begin{smallmatrix}e^2&et\gamma\\et\bar\gamma&t^2\end{smallmatrix}\right)$.
Consequently
$\Delta_4=2e^2t^2|\gamma|^2$ and
$\mathcal D_e=e^2t^2|\gamma|^2$. Cauchy--Schwarz gives the range.
Direct inversion gives $G_e$; its characteristic polynomial gives
$\lambda_\pm$. In the strict range both eigenvalues are positive and
$\lambda_-<t^2<\lambda_+$; partial fractions give the stated positive
residues. Vanishing $\Delta_4$ forces the only remaining mixed return to
vanish, while all three diagonal returns are already the independently
certified unit ones. This proves the full left-return identity.
\end{proof}

```

### BH-IIIF-C-0407: An exact same-owner trace budget for low native curvature

**theorem; source:** `p3f:thm:v249-native-vacuum-correction-budget`, lines 21776–21823. **Disposition:** `VERIFIED-CONDITIONAL`.

**Typed condition nodes:** BH-IIIF-A-0178, BH-IIIF-A-0179, BH-IIIF-A-0153, BH-IIIF-A-0138. **Independent checks:** BH-IIIF-EV-B09-018.

```tex

\begin{theorem}[An exact same-owner trace budget for low native curvature]
\label{p3f:thm:v249-native-vacuum-correction-budget}
Use the actual native local scalar--metric action, with
$\kappa_J,\alpha>0$, $L=\Lambda_g^2>0$,
\[
 X=\operatorname{Tr}_F\Phi^2,\qquad
 \mathscr F=\kappa_J-\alpha X/6,\qquad
 \mathcal V_0=12\kappa_JL+
                   \alpha\operatorname{Tr}_F(\Phi^4-2L\Phi^2).
\]
The constant is the owned bare heat value of
Proposition~\ref{p3f:prop:v2216-bare-heat-vacuum}; it has not been
subtracted. Let an actually co-consumed remainder supply complete
action-normalized metric trace $T_\Delta$ and scalar insertion
$J_\Delta$, including any retained source, measure, nonlocal or higher
term exactly once. Thus its scalar variation is
$-\int\sqrt{-g}\operatorname{Tr}_F(J_\Delta\delta\Phi)$, and its
metric variation defines its Hilbert trace in the same pairing.
Assume these insertions are defined on the compared solution domain,
and set
\[
 \mathcal I_\Delta:=T_\Delta+\operatorname{Tr}_F(\Phi J_\Delta).
\]
On the full native metric and scalar mean equations, the exact
pointwise improved trace is
\[
 \boxed{2\kappa_JR
       =24L(\kappa_J+\mathscr F)-\mathcal I_\Delta,
 \qquad
 \frac RL=12\left(1+\frac{\mathscr F}{\kappa_J}\right)
                    -\frac{\mathcal I_\Delta}{2\kappa_JL}.}
\]
Consequently on any portion with $\mathscr F\ge f\kappa_J>0$
and $R\le\epsilon L$, one necessarily has
\[
 \boxed{\mathcal I_\Delta\ge
            2\kappa_JL[12(1+f)-\epsilon].}
\]
Equivalently, a certified bound
$|\mathcal I_\Delta|\le2\kappa_JL\eta$ implies
$R/L\ge12(1+f)-\eta$ there. A low-curvature target with
$\epsilon<12(1+f)-\eta$ is therefore impossible on that domain.
This identity also applies to a changing native scalar and metric:
the native covariant-gradient terms cancel in the improved trace.
It does not replace a complete remainder insertion by a potential
value or a single scalar heat trace. A common positive whole-action
normalization leaves every dimensionless inequality unchanged.
\end{theorem}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
The full native improved trace, with the constant retained, is
\[
 2\kappa_JR=4(12\kappa_JL)-4\alpha LX
            -T_\Delta-\operatorname{Tr}_F(\Phi J_\Delta).
\]
It follows by the same metric trace and scalar-Euler cancellation as
Proposition~\ref{p3f:prop:native-source-curvature-trace}. In
particular the quartic and native kinetic contributions cancel, so
parallel or frozen fields have not been assumed. Substitute
$\alpha X=6(\kappa_J-\mathscr F)$ to obtain the exact boxed
identity. Inserting the two stated inequalities proves the budget.
For an actual common normalization $z>0$, the coefficients
$\kappa_J,\alpha,\mathscr F,T_\Delta,J_\Delta$ all acquire the
same factor $z$, while $L$ and the curvature coordinate do not;
their displayed ratios are unchanged.
\end{proof}

```

### BH-IIIF-C-0408: What a controlled constant local remainder must supply

**proposition; source:** `p3f:prop:v249-weighted-remainder-budget`, lines 21842–21885. **Disposition:** `VERIFIED-CONDITIONAL`.

**Typed condition nodes:** BH-IIIF-A-0179. **Independent checks:** BH-IIIF-EV-B09-019.

```tex

\begin{proposition}[What a controlled constant local remainder must supply]
\label{p3f:prop:v249-weighted-remainder-budget}
For a declared constant-scalar-curvature and parallel-scalar
comparison, suppose the actual local remainder is
$\Delta S=-\int\sqrt{-g}\,W(R,\Phi)$ with its true fixed
coefficients. Compact interior tests or the actual endpoint rule
are used. Then
\[
 \boxed{\mathcal I_\Delta
       =2RW_{,R}+\operatorname{Tr}_F(\Phi W_{,\Phi})-4W.}
\]
Off the constant-curvature/parallel-scalar comparison the metric
trace also contains $6\Box W_{,R}$; other derivative or tensor
terms retain their actual insertions. If
$W=\sum_dW_d$ is an actually supplied sum with
\[
 W_d(e^{2s}R,e^s\Phi)=e^{ds}W_d(R,\Phi)
\]
and the sum and its displayed first derivatives converge on the
comparison, then
\[
 \boxed{\mathcal I_\Delta=\sum_d(d-4)W_d.}
\]
Thus quartic weighted-degree-four terms cannot change this constant
improved-trace equation. A genuinely controlled bound
$\sum_d|d-4|\,|W_d|\le2\kappa_JL\eta$ obeys the previous theorem's
exclusion. Smallness of $W$ alone, without these metric and scalar
derivative bounds, is insufficient.

For an isolated weighted-degree-six correction the necessary
low-curvature size is explicitly
\[
 \boxed{|W_6|\ge\kappa_JL[12(1+f)-\epsilon].}
\]
At small $\epsilon$ this is at least the order of the entire bare
vacuum density $12\kappa_JL$, even as the positive-graviton margin
$f$ approaches zero. If instead only an owned constant correction
$\delta V$ is available and $\Phi=0$, the exact required value is
\[
 \boxed{\delta V=-12\kappa_JL+\kappa_JR/2.}
\]
This is a required independently derived cancellation, not a license
to choose or subtract that constant.
\end{proposition}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
Variation of $-W$ gives
$T_\Delta=2RW_{,R}-4W+6\Box W_{,R}$ and
$J_\Delta=W_{,\Phi}$. The derivative term vanishes on the stated
constant comparison. Differentiating the displayed weighted scaling
at $s=0$ gives
$2RW_{d,R}+\operatorname{Tr}_F(\Phi W_{d,\Phi})=dW_d$.
Termwise summation proves the trace identity and the error bound.
For degree six, $|\mathcal I_\Delta|=2|W_6|$, so the previous
budget proves the stated size. At $\Phi=0$, a constant remainder has
$\mathcal I_\Delta=-4\delta V$ and $\mathscr F=\kappa_J$;
substitution in the exact trace proves its required cancellation.
\end{proof}

```

### BH-IIIF-C-0409: The actual first raw higher heat term still has no low-curvature bare vacuum

**theorem; source:** `p3f:thm:v249-evaluated-raw-a6-vacuum`, lines 21900–21923. **Disposition:** `VERIFIED-CONDITIONAL`.

**Typed condition nodes:** BH-IIIF-A-0179, BH-IIIF-A-0153, BH-IIIF-A-0173. **Independent checks:** BH-IIIF-EV-B09-020.

```tex

\begin{theorem}[The actual first raw higher heat term still has no low-curvature bare vacuum]
\label{p3f:thm:v249-evaluated-raw-a6-vacuum}
Use the actual unprojected ordinary torsion-free Dirac pure-metric
heat coefficients with their fixed exponential profile, common trace
support and finite-local Lorentzian clock domain, as in
Proposition~\ref{p3f:prop:v2212-dirac-a6-einstein}. Consider the
specified raw truncation through $a_6$, with $\Phi=0$, no source,
and a four-dimensional maximally symmetric interior metric. Retain
the same bare $a_0$ and Einstein $a_2$ coefficients and all
pure-metric $a_4$ terms. Then its exact constant-curvature Euler
equation is
\[
 \boxed{r+\frac{31}{181440}r^3=24,\qquad r=R/L.}
\]
It has exactly one real root, with
\[
 \boxed{22<r<23,\qquad r\simeq22.1446183528.}
\]
Thus this actually evaluated first higher raw heat term shifts the
bare $r=24$ stationary candidate but does not produce a controlled
$|R|/L\ll1$ vacuum. The root remains outside the small-curvature
domain; it is a stationary value of this stated truncation, not a
controlled solution or no-go for the full heat parent.
\end{theorem}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
The cited same-owner evaluation gives the interior Euler
representative, before specializing the metric,
\[
 P_{6,E}\simeq_\delta\frac{31}{2160}R^3
                -\frac16RC^2+\frac1{15}J_C,
 \qquad S_{6,L}^{\rm raw}=-z\int\sqrt{-g}\,P_6,
 \qquad z=\frac{\kappa_J}{84L^2}>0.
\]
On the maximally symmetric jet $C=0$. Both the Weyl-square and
cubic-Weyl constituents have zero first variation there. The pure
$a_4$ terms also have zero interior Euler tensor there: they reduce
to constant-coefficient $R^2$, Weyl-square and Euler-density
constituents plus divergences; the $R^2$ tensor vanishes on a
constant-curvature Einstein metric, the Weyl-square tensor vanishes
at $C=0$, and Euler/divergence terms have no compact-interior Euler
variation in four dimensions. Their boundary terms are not being
deleted from a separate boundary claim. The full compared first
variation is therefore that of
\[
 \int\sqrt{-g}\left[
    \kappa_JR-12\kappa_JL
                 -\frac{31\kappa_J}{181440L^2}R^3\right].
\]
Its trace equation is
$2\kappa_JR=48\kappa_JL-
31\kappa_JR^3/(90720L^2)$, yielding the cubic. The derivative of
$r+31r^3/181440-24$ is strictly positive for every real $r$.
Its values at $22$ and $23$ are respectively negative and positive,
which proves uniqueness and the exact bracket. Ordinary bisection
gives the printed approximation.
\end{proof}

```

### BH-IIIF-C-0410: Exact mixed jet before and after regular classical boson elimination

**proposition; source:** `p3f:prop:v250-boson-elimination-fermion-jet`, lines 21978–22015. **Disposition:** `REPRODUCED`.

**Typed condition nodes:** BH-IIIF-A-0138, BH-IIIF-A-0149. **Independent checks:** none (E1 only; imported certificates not globally reproduced).

```tex

\begin{proposition}[Exact mixed jet before and after regular classical boson elimination]
\label{p3f:prop:v250-boson-elimination-fermion-jet}
On an admitted complete finite coefficient chart, or a supplied common
differentiable action domain where the corresponding reduction is licensed,
write the printed common action in its uninserted fermion form
\[
 S[B,\bar\psi,\psi;Y]
 =S_B[B;Y]+c_F\langle\bar\psi,\mathscr D(B;Y)\psi\rangle,
 \qquad c_F>0.
\]
Here $B$ denotes exactly the retained bosonic fields, $Y$ the fixed
finite-owner member when the chart uses such a member, and $S_B$ includes
the actual spectral trace, its role weights and any retained purely
bosonic companions. The Dirac operator has no fermion dependence in this
printed word. Its exact mixed fermion derivative is consequently
\[
 \boxed{\frac{\delta^2S}{\delta\bar\psi_L\,\delta\psi_R}
       =c_F\mathscr D_{LR}(B;Y),}
\]
with the inherited graded derivative convention and the required
zero-order coefficient extraction when the source sort calls for it.
The bosonic heat term contributes zero to this derivative, independently
of whether its admissible profile is expanded locally.

Suppose $B_0(Y)$ is an actual stationary bosonic background at zero
fermion fields and a regular classical stationary elimination of $B$
is supplied on that same chart, with its actual gauge, constraint and
boundary treatment. Then the reduced fermion two-jet is still exactly
\[
 \boxed{\frac{\delta^2S_{\rm red}}
 {\delta\bar\psi_L\,\delta\psi_R}\bigg|_{\psi=0}
       =c_F\mathscr D_{LR}(B_0(Y);Y).}
\]
Thus the uninserted canonical kinetic cancellation leaves the finite
member already present in this evaluated Dirac coefficient. The background
can affect that coefficient through $B_0(Y)$, but regular classical boson
elimination supplies no additional quadratic source word.
\end{proposition}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
$S_B$ contains neither fermion variable. Differentiating the printed
bilinear therefore gives the first identity directly. At zero fermion
fields each mixed boson--fermion Hessian block vanishes: differentiating
the bilinear once in a fermion variable leaves one fermion factor.
The exact stationary Schur formula consequently has zero cross-block
correction to the fermion two-jet. Equivalently the stationary bosonic
shift starts in fermion degree two. Its contribution to $S_B$ starts in
degree four because $DS_B(B_0)=0$, and its change of the fermion bilinear
also starts in degree four. The degree-two coefficient is precisely the
one displayed. This concerns regular classical stationary elimination;
quantum integration, a nonzero fermion background or a singular reduction
retains its actual measure, state and reduction problem.
\end{proof}

```

### BH-IIIF-C-0411: What the native scalar variation varies

**proposition; source:** `p3f:prop:v250-native-scalar-variation-scope`, lines 22031–22049. **Disposition:** `REPRODUCED`.

**Typed condition nodes:** stated source hypotheses in full quote; no new node needed. **Independent checks:** none (E1 only; imported certificates not globally reproduced).

```tex

\begin{proposition}[What the native scalar variation varies]
\label{p3f:prop:v250-native-scalar-variation-scope}
On the no-constant-odd-offset coordinate-linear family
$\Phi_Y(H)=\Theta_Y(Y)(H)$ of
Theorem~\ref{p5:thm:v186-generated-yukawa-dirac-owner-family}, fixing the
finite member $Y$ and varying the retained scalar field $H$ gives
\[
 \boxed{\delta_HS_Y
 =D_\Phi S\,[\Theta_Y(Y)(\delta H)].}
\]
It gives the Euler equation on those admitted field directions, not an
Euler equation for $Y$. If a broader matrix-scalar variational domain is
actually licensed, its full scalar Euler equation instead acts on that
broader field; it still needs an independently proved identification of
its selected background with the charged preterminal mass-source target.
Promoting constant owner-family coordinates $Y$ to variational variables,
or promoting them to additional spacetime fields, is a different
variational problem unless that promotion has its own native constructor.
\end{proposition}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
The first statement is the exact chain rule for the printed field map.
Its tangent at fixed $Y$ contains $\delta H$ and not $\delta Y$.
The owner-family bijection enumerates available source members; a
bijection does not enlarge the tangent space of a field variational
problem. Broader admitted scalar variations may be used only on their
own declared domain. The charged direct-source target and its incidence
are distinct entries of the action, so an equality to a chosen stationary
scalar background requires its actual source correspondence.
\end{proof}

```

### BH-IIIF-C-0412: The zero-scalar fibre does not become a unique member selector

**proposition; source:** `p3f:prop:v250-zero-scalar-member-fibre`, lines 22061–22081. **Disposition:** `REPRODUCED`.

**Typed condition nodes:** stated source hypotheses in full quote; no new node needed. **Independent checks:** none (E1 only; imported certificates not globally reproduced).

```tex

\begin{proposition}[The zero-scalar fibre does not become a unique member selector]
\label{p3f:prop:v250-zero-scalar-member-fibre}
For this particular no-offset family, restrict to the source-free printed
spectral word and only companions that share its grading invariance and
have no independent $Y$ dependence on the $H=\psi=0$ fibre,
with no independent scalar source. Suppose the complete retained
Dirac domain, localizer/window and gauge data preserve the internal
grading $\Gamma_F$, the source-free base operator commutes with it, and
$\Gamma_F\Phi_Y(H)\Gamma_F=-\Phi_Y(H)$. Then the actual bosonic spectral
word is even under $H\mapsto-H$. Hence at $H=\psi=0$ the scalar first
variation vanishes for every $Y$, and the action and its metric/gauge
variations there are independent of $Y$.

If a metric/gauge critical configuration of that zero-scalar word is
independently supplied, it therefore extends to the entire available
$Y$ family at $H=\psi=0$. Even a formal enlargement allowing constant
$\delta Y$ would have $\delta_YS=0$ on this fibre. Thus existence of
such a zero-scalar stationary configuration cannot select a noncentral
charged member. This statement does not assert existence of an exact
full-heat metric critical configuration.
\end{proposition}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
On the stated complete domain the constant unitary internal grading
conjugates $\mathscr D(H)$ to $\mathscr D(-H)$, and hence conjugates
its square and admissible profile in the same way. The retained trace
and localizer are invariant under that conjugation. Thus the bosonic
functional is even, and its derivative at zero scalar is zero.
Coordinate linearity gives $\Phi_Y(0)=0$ for every $Y$; the source-free
operator, action and metric/gauge derivatives on that fibre consequently
contain no $Y$. The fermionic term and its first variation vanish at
zero fermion fields. These facts prove the conditional extension and
also its formally enlarged constant-$Y$ version.
\end{proof}

```

### BH-IIIF-C-0413: The exact ordinary heat trace has no unconstrained homothetic stationary metric

**theorem; source:** `p3f:thm:v250-exact-heat-homothety`, lines 22115–22141. **Disposition:** `VERIFIED`.

**Typed condition nodes:** BH-IIIF-A-0180. **Independent checks:** BH-IIIF-EV-B09-021.

```tex

\begin{theorem}[The exact ordinary heat trace has no unconstrained homothetic stationary metric]
\label{p3f:thm:v250-exact-heat-homothety}
Let $D_0$ be the actual ordinary self-adjoint geometric Dirac operator
on a closed compact Riemannian spin parent in the unlocalized
Euclidean heat domain, and put $L=\Lambda_g^2>0$. Retain its fixed
trace prescription, fixed positive cutoff and the common transported
spinor/domain identification. Suppose the configuration domain admits
the homothetic metric variation $g_a=a^2g_0$, $a>0$, without a
fixed-volume constraint or other independent scale condition. With
the standard unitary density transport one has $D_a=a^{-1}D_0$ and
\[
 \boxed{S(a)=\operatorname{Tr}e^{-D_0^2/(a^2L)},\qquad
 \frac{dS}{d\log a}=2\operatorname{Tr}(A_ae^{-A_a})>0,
 \quad A_a=D_0^2/(a^2L).}
\]
Strictness holds whenever the retained carrier contains a nonzero
Dirac eigenvalue; in particular it holds for the complete compact
elliptic carrier. Therefore this exact ordinary, unnormalized pure
heat functional has no finite-scale critical metric on that admitted
unconstrained homothetic branch. A positive constant action or
protected trace multiplier preserves this conclusion.

The same identity holds on an actual fixed finite reducing spectral
window, with strictness precisely when that window sees a nonzero
eigenvalue. It is not asserted across a moving sharp band or a change
of boundary domain.
\end{theorem}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
Constant metric scaling multiplies the inverse coframe and the
geometric Dirac operator by $a^{-1}$ under the common unitary
density identification. Hence $D_a^2=a^{-2}D_0^2$. Write the actual
squared eigenvalues of $D_0$ as $\lambda_j^2\ge0$, including
multiplicities. On a compact $a$ interval bounded away from zero,
both the heat sum and its differentiated sum converge uniformly:
$x e^{-cx}\le C e^{-cx/2}$ for every fixed $c>0$, and the latter
heat operator is trace class. Thus termwise differentiation is
licensed and gives
\[
 \frac{dS}{d\log a}
   =2\sum_j\frac{\lambda_j^2}{a^2L}
                    e^{-\lambda_j^2/(a^2L)}.
\]
Every term is nonnegative and a retained positive eigenvalue makes
the sum strictly positive. The geometric metric derivative cannot
vanish on all allowed variations because this one is nonzero.
In a fixed finite reducing window the same calculation is a finite
sum. It includes the actual transported volume through the spectrum;
there is no additional volume division.
\end{proof}

```

### BH-IIIF-C-0414: An explicit source-native compact product test with momentum fixed

**proposition; source:** `p3f:prop:v250-native-product-heat-scale`, lines 22165–22196. **Disposition:** `VERIFIED`.

**Typed condition nodes:** BH-IIIF-A-0180. **Independent checks:** BH-IIIF-EV-B09-022.

```tex

\begin{proposition}[An explicit source-native compact product test with momentum fixed]
\label{p3f:prop:v250-native-product-heat-scale}
Use the actual ordinary-spin product spectrum and heat trace of
Paper~I-B, Eqs.~\eqref{p1b:der:g08:eq-G08-6}--
\eqref{p1b:der:g08:eq-G08-9}. Hold the momentum radius $R_p$, torus
metric $G$, spin structure $\sigma$ and heat time $t>0$ fixed, and
vary only the round position-factor radius $a=R_x$. The exact
declared spectral readout is
\[
 Z_{\rm spin}(t;a)
   =4\mathcal S_a(t)\mathcal S_{R_p}(t)\Theta_{G,\sigma}(t),
 \quad
 \mathcal S_a(t)=2\sum_{k\ge0}(k+1)(k+2)
                  e^{-t(k+3/2)^2/a^2}.
\]
Its actual derivative is
\[
 \boxed{a\partial_a Z_{\rm spin}
   =\frac{16t}{a^2}\mathcal S_{R_p}(t)\Theta_{G,\sigma}(t)
       \sum_{k\ge0}(k+1)(k+2)(k+3/2)^2
                   e^{-t(k+3/2)^2/a^2}>0.}
\]
Fixed nonempty complete finite product shell windows obey the same
strict formula with their actual finite sums. An arbitrary fixed
reducing multiindex window instead retains its complete finite
positive derivative sum, without assuming product factorization.
No homothety of the
microscopic momentum radius has been used. This is an exact test
of the declared eight-dimensional geometric readout, not an
identification of that readout with a four-dimensional physical
metric action.
\end{proposition}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
The native product square is the sum of the commuting squared sphere
Dirac operators and fixed shifted torus Laplacian. Its actual heat
trace therefore factorizes as printed. Differentiate the position
factor only; its complete two-sign multiplicity is already included
in $\mathcal S_a$, so no additional sign or Clifford multiplicity is
inserted. Uniform convergence follows from the Gaussian spectral
tail. Every factor and every term in the derivative is positive.
\end{proof}

```

### BH-IIIF-C-0415: The exact native raw joint heat has no nonzero parallel scalar stationary point

**theorem; source:** `p3f:thm:v250-exact-parallel-scalar-heat`, lines 22207–22254. **Disposition:** `VERIFIED`.

**Typed condition nodes:** BH-IIIF-A-0180, BH-IIIF-A-0181. **Independent checks:** BH-IIIF-EV-B09-023.

```tex

\begin{theorem}[The exact native raw joint heat has no nonzero parallel scalar stationary point]
\label{p3f:thm:v250-exact-parallel-scalar-heat}
On an admitted even-dimensional compact unlocalized Euclidean joint
Dirac domain, use the actual generated operator word of
Theorem~\ref{p3f:thm:v175-native-local-scalar-action},
\[
 D_{a,s}=a^{-1}D_0\otimes I+\gamma_g\otimes s\Phi_0,
 \qquad \Phi_0=\Phi_0^\dagger,
\]
with a finite internal factor, zero added gauge curvature and a
parallel $\Phi_0$. Require its actual tensor-product domain and
Clifford grading, so $\{D_0,\gamma_g\}=0$,
$\gamma_g^2=I$, and $[D_0,\Phi_0]=0$ on the common core. Keep the
ordinary raw trace, fixed cutoff $L$ and any actual constant common
positive multiplier. The geometric carrier contains a nonzero
Dirac mode, as automatically holds on the complete
positive-dimensional compact elliptic parent. Then
\[
 \boxed{\begin{aligned}
 D_{a,s}^2&=a^{-2}D_0^2\otimes I+I\otimes s^2\Phi_0^2,\\
 S(a,s)&=Z_g(a)\operatorname{Tr}_F e^{-s^2\Phi_0^2/L},\qquad
 Z_g(a)=\operatorname{Tr}_g e^{-D_0^2/(a^2L)}.
 \end{aligned}}
\]
The two exact derivatives are
\[
 \boxed{\partial_{\log a}S
   =2\operatorname{Tr}_g(A_ae^{-A_a})
                    \operatorname{Tr}_F e^{-s^2\Phi_0^2/L}>0,}
\]
\[
 \boxed{\partial_sS
  =-\frac{2s}{L}Z_g(a)
             \operatorname{Tr}_F(\Phi_0^2e^{-s^2\Phi_0^2/L})<0
  \quad(s>0,\ \Phi_0\ne0).}
\]
Thus any admitted nonzero parallel scalar configuration has a
nonvanishing radial variation of this exact raw heat functional.
If the full parallel scalar linear support is varied, its only
finite scalar stationary point is $\Phi=0$. The metric variation
there still does not vanish on the admitted homothetic branch.

This is an exact Euclidean raw-parent statement. It does not replace
the physical common-action pure-metric/nonmetric role scalarizer
by one uniform raw weight, assert an exact global Lorentzian heat
action, or apply to a rooted midpoint scalar whose covariant spatial
derivative is nonzero.
\end{theorem}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
The actual Clifford anticommutation and parallel internal factor
remove the mixed square term. The two surviving positive operators
commute on different tensor factors, so their heat operator and
ordinary trace factorize exactly. The first derivative is the
preceding theorem. Finite internal functional calculus gives the
second derivative. A nonzero Hermitian matrix has a positive squared
eigenvalue, and every exponential weight is positive, so its stated
trace is strictly positive. The radial direction at any nonzero
matrix therefore prevents stationarity. At zero all scalar first
variations vanish, proving the remaining assertion.
\end{proof}

```

### BH-IIIF-C-0416: Explicit primitive scalar and fermion member packet

**proposition; source:** `p3f:prop:v251-primitive-canonical-scalar-packet`, lines 22341–22365. **Disposition:** `VERIFIED`.

**Typed condition nodes:** BH-IIIF-A-0182. **Independent checks:** BH-IIIF-EV-B09-024.

```tex

\begin{proposition}[Explicit primitive scalar and fermion member packet]
\label{p3f:prop:v251-primitive-canonical-scalar-packet}
On the no-offset coordinate-linear Dirac-neutrino branch, the independently
generated primitive $Y_*=(I_G,I_G,I_G,I_G)$ has
\[
 \boxed{a_*=b_*=24,\quad
 H_c=\frac{\sqrt3}{\pi}H,\quad
 Y_{s,c}=\frac\pi{\sqrt3}I_G,\quad
 \lambda_* =\frac{\pi^2}{3}.}
\]
Consequently its native scalar--Einstein restriction is exactly
\begin{equation}
\label{p3f:eq:v251-primitive-canonical-local-action}
 \int\sqrt{-g}\left[
 \left(\kappa_J-\frac{H_c^\dagger H_c}{6}\right)R
 -(D_\mu H_c)^\dagger D^\mu H_c
 +2\Lambda_g^2H_c^\dagger H_c
 -\frac{\pi^2}{3}(H_c^\dagger H_c)^2
 \right]d^4x .
\end{equation}
The Yang--Mills term keeps its inherited $Q_\rho$ and the weak family
vertex remains $I_G$.  The canonically normalized local fermion member is
the original $D_{Y_*}$; no new Yukawa member or positive wavefunction
insertion is selected by this evaluation.
\end{proposition}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
The generated trace invariants are
$a_Y=3\operatorname{tr}Y_u^\dagger Y_u+
3\operatorname{tr}Y_d^\dagger Y_d+
\operatorname{tr}Y_e^\dagger Y_e+
\operatorname{tr}Y_\nu^\dagger Y_\nu$, with the analogous squares for
$b_Y$.  Each $\operatorname{tr}I_G=3$, so both evaluate to
$9+9+3+3=24$.  Substitute in the already constituted canonical formulas
\[
 H_c=\sqrt{a_Y/(8\pi^2)}H,\quad
 Y_{s,c}=\sqrt{8\pi^2/a_Y}Y_s,\quad
 \lambda_Y=8\pi^2 b_Y/a_Y^2.
\]
Moreover $\operatorname{Tr}_F\Phi_Y^2=2a_YH^\dagger H$ implies
$\alpha_\Phi\operatorname{Tr}_F\Phi_Y^2=H_c^\dagger H_c$.
This proves every scalar/curvature coefficient at once.  The gauge action
and its representation are family blind, giving $I_G$ in the family
vertex.  The uninserted fermion jet is
$(Z_L,D,Z_R)=c_F(I,D_{Y_*},I)$, whose canonical normalization cancels
$c_F$ exactly.  No field equation or target mass is used.
\end{proof}

```

### BH-IIIF-C-0417: Same-packet scalar and mixed jets

**proposition; source:** `p3f:prop:v251-native-scalar-mixed-jets`, lines 22399–22425. **Disposition:** `VERIFIED`.

**Typed condition nodes:** BH-IIIF-A-0182. **Independent checks:** BH-IIIF-EV-B09-025.

```tex

\begin{proposition}[Same-packet scalar and mixed jets]
\label{p3f:prop:v251-native-scalar-mixed-jets}
Let $\Phi=\sum_a\phi_aT_a$ in actual orthonormal real Hermitian coordinates,
$\operatorname{Tr}_F(T_aT_b)=\delta_{ab}$.  The local coefficient jets are
\[
 \mathscr F_{,a}=-\frac{\alpha_\Phi}{3}\phi_a,\qquad
 \mathscr F_{,ab}=-\frac{\alpha_\Phi}{3}\delta_{ab},
\]
\[
 V_{,a}=4\alpha_\Phi\operatorname{Tr}_F
         [T_a(\Phi^3-\Lambda_g^2\Phi)],
\]
\[
 V_{,ab}=4\alpha_\Phi\operatorname{Tr}_F
 \left[T_a\left(\Phi^2T_b+\Phi T_b\Phi+T_b\Phi^2
                         -\Lambda_g^2T_b\right)\right].
\]
For any actual commuting control coordinates $q^i$ in the same fermionic
word, the ordered bilinear coefficients are
\[
 [\bar\psi_a\psi_b]S=c_F\mathcal D_{ab},\quad
 [\bar\psi_a\psi_b]\partial_iS=c_F\mathcal D_{ab,i},\quad
 [\bar\psi_a\psi_b]\partial_i\partial_jS=c_F\mathcal D_{ab,ij}.
\]
Thus the mixed connection, scalar and metric vertices are derivatives of
the same member, not freely chosen companion maps.
\end{proposition}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
Differentiate $\operatorname{Tr}\Phi^2$ and the cyclic polynomial trace.
For the quartic, $D(\Phi^3)[T_b]=\Phi^2T_b+\Phi T_b\Phi+T_b\Phi^2$;
cyclicity proves the displayed symmetric Hessian without assuming that
$\Phi$ and $T_b$ commute.  Ordered Grassmann coefficient extraction
commutes with ordinary coefficient differentiation, proving the last
three formulas.
\end{proof}

```

### BH-IIIF-C-0418: Forward causal source integration and Ward coherence

**theorem; source:** `p3f:thm:v251-forward-causal-native-packet`, lines 22472–22526. **Disposition:** `VERIFIED-CONDITIONAL`.

**Typed condition nodes:** BH-IIIF-A-0177, BH-IIIF-A-0182, BH-IIIF-A-0144, BH-IIIF-A-0153, BH-IIIF-A-0160, BH-IIIF-A-0138. **Independent checks:** BH-IIIF-EV-B09-026.

```tex

\begin{theorem}[Forward causal source integration and Ward coherence]
\label{p3f:thm:v251-forward-causal-native-packet}
Restrict the same native action to its compatible homogeneous spherical
chart with $q=(A,B,\phi_a)$, $V_3=\Omega_zAB^2$, and its actual smooth
coordinate-only proper generator $h(q)$ in a flat canonical source frame.
Retain the actual initial density $\sigma_i$, every central term and the
lapse $N$ until variation.  With $H[N,q]=Nh(q)$ define
\[
 Z[q_+,q_-]=\operatorname{Tr}
  (U_{q_+}\sigma_iU_{q_-}^\dagger),\qquad
 \Gamma=-i\hbar\operatorname{Log}Z
\]
on the local normalized logarithm branch containing the diagonal.
The action
\[
 \mathcal I=\hbar S_{g\Phi}[N_+,q_+]
            -\hbar S_{g\Phi}[N_-,q_-]+\Gamma
\]
has the exact source covectors
\[
 F_N=-\langle h\rangle,\qquad F_i=-N\langle h_{,i}\rangle,
\]
and complete mixed source kernel
\[
 \Gamma_{\Delta a,c b}(t,s)
 =-\langle H_{,ab}(t)\rangle\delta(t-s)
 +\frac i\hbar\Theta(t-s)
       \langle[H_{,a}(t),H_{,b}(s)]\rangle.
\]
In particular $H_{,Ni}=h_{,i}$ is a required lapse/source contact.
The action-normalized ports are
\[
 \rho_r=\frac{\langle h\rangle}{\hbar V_3},\quad
 p_{z,r}=-\frac{A\langle h_{,A}\rangle}{\hbar V_3},\quad
 p_{\perp,r}=-\frac{B\langle h_{,B}\rangle}{2\hbar V_3},\quad
 J_a=\frac{\langle h_{,\phi_a}\rangle}{\hbar V_3}.
\]
These satisfy the exact work identity and its differentiated contact
identity.  For a compact control perturbation $(n,u^i)$ the latter is
\[
 \sum_i(\delta F_i\dot q^i+F_i\dot u^i)
       -n\dot F_N-N\partial_t\delta F_N=0.
\]
The same action gives the coupled curvature insertion
\begin{equation}
\label{p3f:eq:v251-forward-curvature-insertion}
 \boxed{R_*=-\frac{2\alpha_\Phi\Lambda_g^2}{\kappa_J}
             \operatorname{Tr}_F\Phi^2
       -\frac{\operatorname{Tr}(\sigma\mathsf T)}
                    {2\kappa_J\hbar V_3},\qquad
 \mathsf T=-h-Ah_{,A}-Bh_{,B}+\sum_a\phi_a h_{,\phi_a}.}
\end{equation}
No independent scalar charge, pressure coefficient, central-energy
subtraction, or fitted curvature cap occurs in these equations.
\end{theorem}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
The finite propagator is unitary and the diagonal trace equals one, so
the normalized logarithm exists on a sufficiently small history
neighborhood.  Duhamel differentiation gives $F_a=-\langle H_{,a}\rangle$
and the contact-plus-retarded-commutator kernel, including every mixed
derivative.  Cyclicity and $i\hbar\dot\sigma=[Nh,\sigma]$ give
$d\langle h\rangle/dt=\sum_i\langle h_{,i}\rangle\dot q^i$.
Therefore $\sum_iF_i\dot q^i-N\dot F_N=0$.  Dividing by the actual
volume and differentiating that volume gives
\[
 D_\tau\rho_r+H_A(\rho_r+p_{z,r})
 +2H_B(\rho_r+p_{\perp,r})=\sum_aJ_aD_\tau\phi_a.
\]
The mixed kernel is its actual differentiated source response.  Trace
the native metric equation and use the same scalar Euler equation:
\[
 2\kappa_JR=4V-\operatorname{Tr}(\Phi V_{,\Phi})
                 -T_r-\operatorname{Tr}(\Phi J),
 \qquad
 4V-\operatorname{Tr}(\Phi V_{,\Phi})
       =-4\alpha_\Phi\Lambda_g^2\operatorname{Tr}\Phi^2.
\]
Substitute the four finite-source ports.  Their combination is exactly
$\operatorname{Tr}(\sigma\mathsf T)/(\hbar V_3)$, proving the boxed
curvature insertion.  The native common-action Cauchy equivalence retains
the lapse constraint and source state, so no independently prescribed
source balance is needed on this chart.
\end{proof}

```

### BH-IIIF-C-0419: The exact finite-source operator for the bare trace budget

**proposition; source:** `p3f:prop:v251-forward-source-trace-operator`, lines 22591–22621. **Disposition:** `VERIFIED-CONDITIONAL`.

**Typed condition nodes:** BH-IIIF-A-0179, BH-IIIF-A-0153, BH-IIIF-A-0138. **Independent checks:** none (E1 only; imported certificates not globally reproduced).

```tex

\begin{proposition}[The exact finite-source operator for the bare trace budget]
\label{p3f:prop:v251-forward-source-trace-operator}
Let the complete retained remainder Hamiltonian be
$h=h(A,B,\phi_1,\ldots,\phi_d)$ on the actual flat finite source frame,
with state $\sigma$, volume $V_3=\Omega_zAB^2$, and native source ports.
Define the geometric scaling derivation and Hermitian operator
\[
 \mathscr D_0=A\partial_A+B\partial_B-\sum_a\phi_a\partial_{\phi_a},
 \qquad \mathsf K_h=-h-\mathscr D_0h.
\]
Then the complete improved source trace is
\[
 \mathcal I_h=T_h+\sum_a\phi_aJ_a
          =\frac{\operatorname{Tr}(\sigma\mathsf K_h)}{\hbar V_3}.
\]
On the native metric and scalar mean equations with no omitted remainder,
\[
 \boxed{\frac RL=12\left(1+\frac{\mathscr F}{\kappa}\right)
       -\frac{\operatorname{Tr}(\sigma\mathsf K_h)}{2\kappa L\hbar V_3}.}
\]
If the state eigenvalues are $p_1\ge\cdots\ge p_n$ and the eigenvalues
of $\mathsf K_h$ are $k_1\ge\cdots\ge k_n$, its expectation lies sharply
between $\sum_jp_jk_{n+1-j}$ and $\sum_jp_jk_j$. Consequently any point
with $\mathscr F\ge f\kappa>0$ and $R\le\epsilon L$ requires
\[
 \sum_jp_jk_j\ge
 2\kappa L\hbar V_3\,[12(1+f)-\epsilon].
\]
This is a necessary pointwise feasibility test, not a proof that its
extremizing state occurs or obeys all other field equations.
\end{proposition}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
The actual native ports are
$\rho_h=\operatorname{Tr}(\sigma h)/(\hbar V_3)$,
$p_{z,h}=-A\operatorname{Tr}(\sigma h_{,A})/(\hbar V_3)$,
$p_{\perp,h}=-B\operatorname{Tr}(\sigma h_{,B})/(2\hbar V_3)$ and
$J_a=\operatorname{Tr}(\sigma h_{,a})/(\hbar V_3)$.
Insert them into $T_h=-\rho_h+p_{z,h}+2p_{\perp,h}$ to get the first
identity. Substitution into the native bare improved-trace identity gives
the boxed equation. The expectation bounds follow from the finite
Hermitian trace rearrangement inequality, and the final inequality follows
by using the upper bound on the required expectation.
\end{proof}

```

### BH-IIIF-C-0420: Conformal source homogeneity and a positive-excitation sign test

**proposition; source:** `p3f:prop:v251-forward-source-trace-sign`, lines 22635–22656. **Disposition:** `VERIFIED`.

**Typed condition nodes:** BH-IIIF-A-0179, BH-IIIF-A-0138. **Independent checks:** BH-IIIF-EV-B09-027.

```tex

\begin{proposition}[Conformal source homogeneity and a positive-excitation sign test]
\label{p3f:prop:v251-forward-source-trace-sign}
On one actual fixed finite source chart the following implications hold.
\begin{enumerate}
\item If
$h(\lambda A,\lambda B,\lambda^{-1}\phi)=\lambda^{-1}h(A,B,\phi)$
in its fixed canonical frame, then $\mathsf K_h=0$ for every state.
Such a source cannot change the bare improved trace.
\item Let a free positive one-particle source have
$\omega=(K+M^2)^{1/2}>0$, where $K,M^2\succeq0$,
$\mathscr D_0K=-2K$ and $\mathscr D_0M^2=0$ on the compared chart.
Then
\[
 \boxed{\mathsf K_\omega=-\omega-\mathscr D_0\omega
       =-2\int_0^\infty e^{-t\omega}M^2e^{-t\omega}\,dt\preceq0.}
\]
The same sign holds for its positive free excitation second quantization
on an admitted fixed finite fermionic or bounded bosonic occupation space.
It does not require $[K,M^2]=0$. Such excitations alone cannot supply the
positive trace cancellation necessary for low bare curvature.
\end{enumerate}
\end{proposition}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
Differentiate the homogeneity identity at $\lambda=1$.
For the second statement differentiating $\omega^2=K+M^2$ gives the
Sylvester equation
$\omega(\mathscr D_0\omega)+(\mathscr D_0\omega)\omega=-2K$.
Therefore
$\omega\mathsf K_\omega+\mathsf K_\omega\omega=-2M^2$.
Positive $\omega$ makes its Lyapunov inverse the displayed convergent
positive integral. Second quantization on free excitation sectors
preserves the operator order and commutes with the fixed-chart derivative.
The trace budget proves the last assertion.
\end{proof}

```

### BH-IIIF-C-0421: The complete Einstein scalar metric of the primitive packet

**theorem; source:** `p3f:thm:v251-forward-higgs-hyperbolic-target`, lines 22721–22748. **Disposition:** `VERIFIED-CONDITIONAL`.

**Typed condition nodes:** BH-IIIF-A-0182, BH-IIIF-A-0153. **Independent checks:** BH-IIIF-EV-B09-028.

```tex

\begin{theorem}[The complete Einstein scalar metric of the primitive packet]
\label{p3f:thm:v251-forward-higgs-hyperbolic-target}
Write the canonical complex doublet as four real fields $q^a$, so
$x=\tfrac12\sum_a(q^a)^2$ and its kinetic term is
$-\tfrac12\delta_{ab}Dq^aDq^b$. On $\mathscr F>0$ set
$g_E=(\mathscr F/\kappa)g$. The complete transformed scalar metric is
\[
 G_{ab}=\frac\kappa{\mathscr F}\delta_{ab}
           +\frac{3\kappa}{\mathscr F^2}\mathscr F_{,a}\mathscr F_{,b},
 \qquad\mathscr F=\kappa-|q|^2/12.
\]
It is the complete hyperbolic metric of radius $\beta=\sqrt{12\kappa}$.
In radial coordinates $r=|q|=\beta\tanh(\varphi/\beta)$,
\[
 ds_G^2=d\varphi^2+\beta^2\sinh^2(\varphi/\beta)d\Omega_3^2.
\]
The bare Einstein potential is exactly
\[
 \boxed{W(\varphi)=12\kappa L\cosh^2(\varphi/\beta)
              +36\lambda\kappa^2\sinh^4(\varphi/\beta),}
\]
and its covariant Hessian obeys $\nabla_G^2W\succeq2L G$.
For the actual primitive coefficients its entire dimensionless shape is
\[
 \frac{W}{12\kappa L}=\cosh^2u+\tfrac18\sinh^4u,
 \quad u=\varphi/\sqrt{12\kappa}.
\]
\end{theorem}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
The Weyl transformation of $\sqrt{-g}\mathscr F R$ contributes
$-3\kappa(\partial\log\mathscr F)^2/2$ to the scalar kinetic form.
Combining this with the transformed original kinetic term gives $G$,
including the metric--scalar mixing contribution. Its radial eigenvalue
is $\kappa^2/\mathscr F^2$ and its tangential eigenvalue is
$\kappa/\mathscr F$. Substitution of $r=\beta\tanh(\varphi/\beta)$
gives the hyperbolic metric and makes the boundary $\mathscr F=0$ an
infinite metric distance. The potential is
$W=\kappa^2(V_0-Lr^2+\lambda r^4/4)/\mathscr F^2$.
The stated bare $V_0$ gives the displayed formula.
Put $u=\varphi/\beta$. The radial Hessian eigenvalue is
\[
 W''=2L(\cosh^2u+\sinh^2u)
          +36\lambda\kappa\sinh^2u\cosh^2u
          +12\lambda\kappa\sinh^4u\ge2L.
\]
The tangential eigenvalue is
$W'\coth u/\beta=2L\cosh^2u+
12\lambda\kappa\sinh^2u\cosh^2u\ge2L$, with its regular origin
limit $2L$. These are the full covariant Hessian eigenvalues.
\end{proof}

```

### BH-IIIF-C-0422: Source-force bound and positive-graviton margin

**corollary; source:** `p3f:cor:v257-native-force-margin`, lines 22772–22797. **Disposition:** `VERIFIED-CONDITIONAL`.

**Typed condition nodes:** BH-IIIF-A-0182, BH-IIIF-A-0153. **Independent checks:** none (E1 only; imported certificates not globally reproduced).

```tex

\begin{corollary}[Source-force bound and positive-graviton margin]
\label{p3f:cor:v257-native-force-margin}
Import precisely the exact primitive scalar chart of
Theorem~\ref{p3f:thm:v251-forward-higgs-hyperbolic-target}, with
$L>0$, $\kappa=L/(8\pi^2)$, $\beta=\sqrt{12\kappa}$,
$\mathscr F=\kappa-|q|^2/12>0$ and $\rho=d_G(q,0)$.
Its bare potential satisfies
\[
 W(q)-W(0)\ge Lr^2,\qquad |\nabla_GW(q)|\ge2Lr.
\]
If an actually licensed extra covector $J$ on this same scalar chart
satisfies $dW(q_*)+J(q_*)=0$ and $|J(q_*)|_{G^{-1}}\le\varepsilon$,
then
\[
 \rho_*\le\frac{\varepsilon}{2L},\qquad
 \mathscr F(q_*)\ge\kappa\operatorname{sech}^2
 \!\left(\frac{\varepsilon}{2L\sqrt{12\kappa}}\right)>0.
\]
For $|dO|_{G^{-1}}\le K$ along the radial geodesic,
$|O(q_*)-O(0)|\le K\varepsilon/(2L)$.
If $J=dV$ and globally $\nabla_G^2V\succeq-\delta G$ with $\delta<2L$,
then $W+V$ has a unique critical point and minimum, with
\[
 \rho_*\le\frac{|dV(0)|_{G^{-1}}}{2L-\delta}.
\]
\end{corollary}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
Along a unit-speed radial geodesic, the source's Hessian bound gives
$(W\circ\gamma)''\ge2L$ and $(W\circ\gamma)'(0)=0$. Integrate twice.
At stationarity the gradient norm equals the source norm. Use
$\mathscr F=\kappa\operatorname{sech}^2(\rho/\beta)$ and integrate $dO$.
For the final claim, $\mu=2L-\delta>0$ is a global convexity constant.
Along geodesics from zero,
$(W+V)(q)\ge(W+V)(0)-|dV(0)|\rho+\mu \rho^2/2$.
Completeness and finite dimension give compact bounded closed balls,
hence existence of a minimum. Strict geodesic convexity gives uniqueness;
the integrated first derivative at the minimum gives the distance bound.
\end{proof}

```

### BH-IIIF-C-0423: A global source-free radial future for the exact polynomial packet

**theorem; source:** `p3f:thm:v251-forward-bare-radial-global-future`, lines 22846–22872. **Disposition:** `VERIFIED-CONDITIONAL`.

**Typed condition nodes:** BH-IIIF-A-0182, BH-IIIF-A-0183, BH-IIIF-A-0153. **Independent checks:** BH-IIIF-EV-B09-029.

```tex

\begin{theorem}[A global source-free radial future for the exact polynomial packet]
\label{p3f:thm:v251-forward-bare-radial-global-future}
Regard the supplied degree-at-most-four scalar--metric action as an exact
classical polynomial functional on its positive-graviton chart. Restrict
to its gauge-compatible source-free real doublet
$H_c=(0,h/\sqrt2)$, with zero gauge curvature/current and no omitted
source or higher term. Use closed Einstein-frame FLRW proper time.
Let $W$ be the potential above extended evenly to $\varphi\in\mathbb R$,
let $W_0=12\kappa L$, and impose its Friedmann constraint at $t_i$.
If
\[
 a_i>\sqrt{6\kappa/W_0}=1/\sqrt{2L},\qquad H_i>0,
 \qquad E_i=\tfrac12\dot\varphi_i^2+W(\varphi_i)<\infty,
\]
then its solution exists for every $t\ge t_i$ and remains expanding.
Moreover
\[
 \mathscr F(t)\ge\kappa W_0/E_i>0,\quad
 \varphi(t)\to0,\quad\dot\varphi(t)\to0,\quad
 H(t)\to\sqrt{2L},\quad a(t)\to\infty.
\]
The corresponding Jordan proper-time interval is also infinite, since
$dt_J=\sqrt{\kappa/\mathscr F}\,dt_E$ and the conformal factor remains
bounded above and below by positive constants on this solution.
This is a global theorem for the stated exact polynomial restriction,
not a controlled low-curvature theorem for the original heat functional.
\end{theorem}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
The actual Einstein-frame equations are
\[
 H^2+a^{-2}=E/(6\kappa),\qquad
 \dot H=a^{-2}-\dot\varphi^2/(4\kappa),\qquad
 \ddot\varphi+3H\dot\varphi+W'(\varphi)=0.
\]
Thus $\dot E=-3H\dot\varphi^2$. On any expanding interval,
$a\ge a_i$, $E\le E_i$ and $E\ge W_0$. The constraint implies
\[
 H^2\ge W_0/(6\kappa)-a_i^{-2}=:H_{\min}^2>0.
\]
Continuity excludes a first zero of $H$, so expansion persists. Also
$H\le\sqrt{E_i/(6\kappa)}=:H_{\max}$. Coercivity and
$W\ge W_0\cosh^2(\varphi/\beta)$ bound $\varphi$, its velocity and
$\mathscr F=\kappa\operatorname{sech}^2(\varphi/\beta)$ as stated.
Use $b=1/a$ instead of $a$. The variables $(b,H,\varphi,p)$, with
$p=\dot\varphi$, remain in a compact set of the smooth system
\[
 \dot b=-Hb,\quad \dot H=b^2-p^2/(4\kappa),\quad
 \dot\varphi=p,\quad\dot p=-3Hp-W'(\varphi).
\]
It is smooth also at $b=0$, so no finite-time endpoint exists. This
proves global future continuation and $b\le b_ie^{-H_{\min}(t-t_i)}$.
Energy dissipation gives $\int_{t_i}^\infty p^2dt<\infty$.
The compact bounds give bounded $\dot p$ and $\ddot p$.
If $p$ failed to tend to zero, bounded $\dot p$ would produce disjoint
intervals of fixed positive width on which $p^2$ is bounded below,
contradicting its finite integral. If $\dot p$ failed to tend to zero,
bounded $\ddot p$ would produce fixed-width intervals on which $\dot p$
has one sign and fixed magnitude, contradicting $p\to0$. Thus both
$p\to0$ and $\dot p\to0$. The equation gives $W'(\varphi)\to0$.
Since the strongly convex potential has the unique critical point zero,
$\varphi\to0$. The constraint now gives $H\to\sqrt{W_0/(6\kappa)}$.
\end{proof}

```

### BH-IIIF-C-0424: Local curvature canonical exchange with endpoint and Hamiltonian

**corollary; source:** `p3f:cor:v260-canonical-exchange`, lines 22934–22969. **Disposition:** `VERIFIED-CONDITIONAL`.

**Typed condition nodes:** stated source hypotheses in full quote; no new node needed. **Independent checks:** BH-IIIF-EV-B09-030.

```tex

\begin{corollary}[Local curvature canonical exchange with endpoint and Hamiltonian]
\label{p3f:cor:v260-canonical-exchange}
\label{p3f:cor:v229-canonical-exchange}
Let $\Phi=f_c'(r)$ on an interval with $\chi(r)=f_c''(r)\ne0$,
and let $\eta\ne0$ be a constant conversion factor. At any regular
canonical chart with scalar momentum $p_\Phi$, define
\[
 P_c=\eta r,\qquad Q=-\frac{\chi(r)}{\eta}p_\Phi.
\]
Then $r=P_c/\eta$, $p_\Phi=-\eta Q/\chi(P_c/\eta)$, and
\begin{equation}
\label{p3f:eq:v260-canonical-exchange}
 \boxed{p_\Phi\,d\Phi=P_c\,dQ-d(P_cQ),\qquad
  dp_\Phi\wedge d\Phi=dP_c\wedge dQ.}
\end{equation}
For closed-FLRW gravity with $B_g=M^2V_\gamma$, $k=1$, and
$U_J(\Phi)=r\Phi-f_c(r)$, the exact pulled-back gravitational
Hamiltonian is
\begin{equation}
\label{p3f:eq:v260-exchanged-hamiltonian}
\begin{aligned}
\mathcal H_g'={}&
\frac{\eta p_aQ}{3B_ga^2\chi(P_c/\eta)}
+\frac{\eta^2\Phi(P_c)Q^2}{3B_ga^3\chi(P_c/\eta)^2}
-3B_gka\Phi(P_c)\\
&+\frac{B_ga^3}{2}\left[
\frac{P_c}{\eta}\Phi(P_c)-f_c(P_c/\eta)\right],\qquad
\Phi(P_c)=f_c'(P_c/\eta).
\end{aligned}
\end{equation}
The full source Hamiltonian and canonical/source momenta must be pulled
back from the \emph{same} action. The phase action changes by
$-[P_cQ]_{t_i}^{t_f}$, so changing the fixed endpoint polarization
requires the compensating Legendre boundary term. No unchanged $P_c^2$
energy or boundary flux follows from the exchange.
\end{corollary}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
Since $d\Phi=\chi\,dr=(\chi/\eta)\,dP_c$,
$p_\Phi d\Phi=-QdP_c=P_c dQ-d(P_cQ)$; exterior differentiation
proves the symplectic statement. The inverse exists by the
inverse-function theorem when $\eta\chi\ne0$. Substitute
$p_\Phi=-\eta Q/\chi$ and $\Phi=f_c'(P_c/\eta)$ into the
existing Jordan Hamiltonian in
Eq.~\eqref{p3f:eq:v169-flrw-hamiltonian}; the displayed mixed,
quadratic, curvature, and potential terms follow separately.
The phase-action endpoint claim is the integrated one-form identity.
No transformation of an omitted velocity-dependent source is implied.
\end{proof}

```

### BH-IIIF-C-0425: Jordan lapse constraint and nonuniqueness of boundary flux at fixed curvature

**proposition; source:** `p3f:prop:v260-jordan-flux`, lines 22983–23015. **Disposition:** `REPRODUCED`.

**Typed condition nodes:** BH-IIIF-A-0137. **Independent checks:** none (E1 only; imported certificates not globally reproduced).

```tex

\begin{proposition}[Jordan lapse constraint and nonuniqueness of boundary flux at fixed curvature]
\label{p3f:prop:v260-jordan-flux}
\label{p3f:prop:v229-jordan-flux}
On the same closed-FLRW Jordan action with a velocity-independent
homogeneous source, retain the lapse until variation. The gravity
momenta and Hamiltonian constraint are
\begin{align}
 p_a&=-6B_gFa\dot a/N-3B_ga^2\dot F/N,
 &p_F&=-3B_ga^2\dot a/N=-B_ga^3K,\\
 3F(H_\Sigma^2+a^{-2})&=\frac12U_J(F)-3H_\Sigma D_tF
                              +\frac{\rho_s}{M^2},
 &K&=3H_\Sigma .
\end{align}
On the sourceless complete cap $f_c(r)=P_Er+r^2B(r)-\sigma^2/B(r)^2$,
with $B(r)=B_U+2\Delta/(1+\sqrt{1+(r/R_s)^2})$,
$\Delta=B_I-B_U>0$, $\sigma=B_IR_s$,
$B_U,P_E,R_s>0$, there exists a positive constant-curvature root
$r_*>0$ with $r_*f_c'(r_*)-2f_c(r_*)=0$. If the regularity
condition of Proposition~\ref{p3f:prop:v223-cap-legendre}
holds, $F_*=f_c'(r_*)>0$ and the vacuum equations admit the closed
de Sitter chart
\[
  H_*^2=r_*/12,\qquad a(t)=H_*^{-1}\cosh(H_*t),\qquad
  K(t)=3H_*\tanh(H_*t),\qquad F(t)=F_* .
\]
At any $t_0>0$, the two slices $\pm t_0$ have identical induced metric
and identical $r_*,F_*$, yet opposite nonzero $p_F$.
Thus neither the scalar curvature nor its Legendre field and the
induced metric alone determine the Jordan scalar boundary momentum.
In particular the fixed-source complete conormal norm of
Theorem~\ref{p3e:thm:v229-conormal-cap} is not identified with
$p_F$, $p_F^2$, or the metric canonical flux by this calculation.
\end{proposition}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
Differentiating the lapse-unfixed Jordan minisuperspace Lagrangian
\eqref{p3f:eq:v169-flrw-lagrangian} gives the momenta. Lapse variation
gives the displayed constraint; these are the \emph{same-action}
scalar and gravitational boundary data. For the cap,
$f_c(0)=-R_s^2$, hence $[rf_c'-2f_c]_{r=0}=2R_s^2>0$.
As $r\to+\infty$,
\[
 B(r)=B_U+\frac{2\Delta R_s}{r}+O(r^{-2}),\qquad
 f_c(r)=B_Ur^2+(P_E+2\Delta R_s)r+O(1),
\]
so $rf_c'(r)-2f_c(r)=-(P_E+2\Delta R_s)r+O(1)\to-\infty$.
Continuity yields $r_*>0$. For constant $F_*$, the vacuum
metric equation becomes
$(F_*r_*/4-f_c(r_*)/2)g_{\mu\nu}=0$ on an Einstein metric;
the root makes it zero. Closed de Sitter has
$R_{\mu\nu}=3H_*^2g_{\mu\nu}$ and
$H_\Sigma^2+a^{-2}=H_*^2$.
The Jordan constraint holds because
$U_J(F_*)=r_*F_*-f_c(r_*)=r_*F_*/2$.
Finally $a(-t_0)=a(t_0)$, whereas $K(-t_0)=-K(t_0)$;
the momentum formula proves the counterexample.
The usual contracted-Bianchi identity plus the scalar/source Euler
identity propagates the lapse constraint within this consistent
sourceless reduction; no arbitrary extra curvature cap is imposed.
\end{proof}

```

### BH-IIIF-C-0426: Conormal norm and absolute-amplitude firewall

**corollary; source:** `p3f:cor:v260-conormal-jordan-distinction`, lines 23042–23056. **Disposition:** `REPRODUCED`.

**Typed condition nodes:** BH-IIIF-A-0137. **Independent checks:** none (E1 only; imported certificates not globally reproduced).

```tex

\begin{corollary}[Conormal norm and absolute-amplitude firewall]
\label{p3f:cor:v260-conormal-jordan-distinction}
For the separately constituted positive two-channel conormal problem
of Theorem~\ref{p3e:thm:v229-conormal-cap}, the constrained minimum is
\[
 \boxed{\mathcal E_{\partial}(r;b)=
 \frac{b^2\gamma_N^2d_0r^2}{2(1+G(r))},\quad
 G(r)=\sqrt{1+(r/R_s)^2}.}
\]
It equals the target $2\Delta r^2/(1+G(r))$ precisely when
$b^2\gamma_N^2d_0=4\Delta$. This fixes the required magnitude
\emph{within the matched source class}; it does not determine the
physical incoming amplitude $b$, actual source/operator identity,
or the occurrence of that cap in the common action.
\end{corollary}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
For $p_0+p_1=j_r$ and inverse blocks
$\bar K^{-1},(G\bar K)^{-1}$, variation gives
$p_0=j_r/(1+G)$ and $p_1=Gj_r/(1+G)$.
The minimum is
$\langle j_r,\bar K^{-1}j_r\rangle/[2(1+G)]$.
Putting $j_r=b\gamma_NrJ_1$ and transporting the frozen trace
as in Theorem~\ref{p3e:thm:v229-conormal-cap} gives the boxed norm.
Comparison with the target fixes the displayed necessary and
sufficient scalar equation. The preceding proposition proves that
Jordan canonical momentum is not fixed by this curvature-only value.
\end{proof}

```

### BH-IIIF-C-0427: Common finite action jets and compressed observables without subgroup ceiling

**theorem; source:** `p3f:thm:v275-joint-positive-action-jets`, lines 23073–23123. **Disposition:** `VERIFIED-CONDITIONAL`.

**Typed condition nodes:** BH-IIIF-A-0161, BH-IIIF-A-0149. **Independent checks:** none (E1 only; imported certificates not globally reproduced).

```tex

\begin{theorem}[Common finite action jets and compressed observables without subgroup ceiling]
\label{p3f:thm:v275-joint-positive-action-jets}
Work on the existing compact $SU(2)$ comparison factor, with
Haar probability $\sigma$ and a \emph{supplied} tetrahedral
core $H$. Fix a finite-dimensional field-parameter domain
$\theta$, a finite jet order $s$, a parameter point $\theta_0$,
and finitely many continuous action integrands
$L_j(q,\theta)$ whose parameter derivatives through order $s$
are jointly continuous on $G\times U$ for a neighborhood $U$
of $\theta_0$. There is a single positive
finite rule on words in the two icosahedral completions of $H$
that reproduces all prescribed integrated action jets exactly:
\[
 \left.\partial_\theta^\alpha\int L_j(q,\theta)
                       \,d\sigma(q)\right|_{\theta_0}
 =\left.\partial_\theta^\alpha
             \sum_iw_iL_j(q_i,\theta)\right|_{\theta_0}
 \quad (|\alpha|\le s),
\]
provided differentiation under the integral is licensed by the
stated compact-domain regularity.

If $L_j(q,\theta)=\sum_{a=1}^{d_j}c_{ja}(\theta)f_{ja}(q)$
has a finite separated expansion, the same rule reproduces the
entire finite action for all $\theta$ in its domain, not only
the specified jets. Any finite list of identities involving
these exact integrated coefficient functions is preserved.

Additionally, let $a_1,\dots,a_t$ be polynomial scalar
observable symbols with degrees at most $d_a$, and consider
the compressed multiplication operators
$C_{a_j}^{(m)}=P_mM_{a_j}|_{\mathcal P_m}$. If a single positive
rule is exact on $\mathcal P_L$ with
\[
 \boxed{L\ge\max\{2m+d_a,\ r+2,\ d_{\rm action}\}},
\]
where $r$ is the prescribed endpoint-POVM moment degree and
$d_{\rm action}$ bounds the polynomial action-jet integrands,
then that same rule reconstructs the exact matrices
\[
 \boxed{C_{a_j}^{(m)}
       =(S_m)^*\operatorname{diag}(a_j(q_i))S_m}
\]
and their finite-dimensional spectra and compressed-matrix
identities, simultaneously with the action jets and the
readout moments. The evaluation $S_m$ is isometric and the
node count is at least $\dim\mathcal P_m$.
No result here asserts a physical occurrence, all-resolution
exactness by one fixed finite set, local gauge Ward identities
beyond the tested span, or full interacting continuum dynamics.
\end{theorem}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
The finitely many parameter jets form a finite-dimensional
real span of continuous scalar functions; apply
Theorem~\ref{p1b:thm:v275-dense-twin-word-cubature}
(or Corollary~\ref{p2e:cor:v275-joint-observable-exactification})
to that span. Uniform regularity on the compact factor permits
interchange of integration and the stated derivatives, and
exactness applies to every jet coefficient separately. A
finite separated expansion places every $L_j(\cdot,\theta)$
in one fixed finite-dimensional span, proving full-parameter
exactness.

For the polynomial assertion, $\overline f a_jg$ has degree
at most $2m+d_a$ whenever $f,g\in\mathcal P_m$.
By cubature exactness,
\[
 \langle f,C_{a_j}^{(m)}g\rangle_{L^2(\sigma)}
  =\sum_iw_i\overline{f(q_i)}a_j(q_i)g(q_i)
  =\langle S_mf,\operatorname{diag}(a_j(q_i))S_mg\rangle.
\]
The degree-$2m$ subcase gives $S_m^*S_m=I$; hence the
operator matrix identity holds exactly. The terms $r+2$ and
$d_{\rm action}$ guarantee the other specified equalities.
Injectivity of $S_m$ yields the node lower bound. Notice that
products of compressed operators are not generally equal to
compressions of products without additional off-band control;
only actual compressed-matrix identities are exported.
\end{proof}

```

### BH-IIIF-C-0428: A finite complete-source two-jet reconstruction

**theorem; source:** `p3f:thm:v289-complete-source-twojet`, lines 23163–23187. **Disposition:** `VERIFIED`.

**Typed condition nodes:** BH-IIIF-A-0184, BH-IIIF-A-0161, BH-IIIF-A-0149. **Independent checks:** BH-IIIF-EV-B09-031.

```tex

\begin{theorem}[A finite complete-source two-jet reconstruction]
\label{p3f:thm:v289-complete-source-twojet}
Fix one real $n$-dimensional source port and its comparison frame, with a
common invertible $n\times n$ probe-incidence matrix $Q$. For $a=1,2$
let $T_a=T_a^{\mathsf T}>0$, $j_a\in\mathbb R^n$ and
$\ell_a\in\mathbb R$. Consider the quadratic source parents and their
classical stationary generating functions
\[
 W_a(y;q)=y^{\mathsf T}T_ay+2(j_a+Qq)^{\mathsf T}y+\ell_a,
 \qquad
 F_a(q)=\min_yW_a(y;q)
   =\ell_a-(j_a+Qq)^{\mathsf T}T_a^{-1}(j_a+Qq).
\]
Then equality of the values, all first derivatives and all second
derivatives of $F_1,F_2$ at $q=0$ is \emph{equivalent} to
\[
 \boxed{T_1=T_2,\quad j_1=j_2,\quad \ell_1=\ell_2.}
\]
For the full real $4\times4$ cap source ($n=16$), this is a
finite $1+16+16\cdot17/2=153$ scalar-jet certificate, once a
source-faithful set of $16$ actual independent probes and their
common normalization has been supplied. With incomplete or compressed
probes the implication need not hold. The statement neither creates
those physical probes nor eliminates extra source or tensor ports.
\end{theorem}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
The exact source jets are
\[
 F_a(0)=\ell_a-j_a^{\mathsf T}T_a^{-1}j_a,\quad
 (DF_a)_0=-2Q^{\mathsf T}T_a^{-1}j_a,\quad
 (D^2F_a)_0=-2Q^{\mathsf T}T_a^{-1}Q.
\]
Equality of Hessians and invertibility of $Q$ first imply
$T_1^{-1}=T_2^{-1}$, hence $T_1=T_2$. Equality of gradients then
implies $j_1=j_2$, and equality of values gives
$\ell_1=\ell_2$. The converse is direct. Symmetry gives
$n(n+1)/2$ independent Hessian entries. For a nonspanning
probe $Q=(1,0)^{\mathsf T}$, the two distinct positive kernels
$T_1=I_2$ and $T_2=\operatorname{diag}(1,2)$, with zero sources,
both give $F(q)=-q^2$; this proves the stated limitation.
\end{proof}

```

### BH-IIIF-C-0429: Closed-$S^3$ FLRW blindness and the native tensor Hessian

**proposition; source:** `p3f:prop:v289-flrw-tensor-obstruction`, lines 23205–23242. **Disposition:** `VERIFIED-CONDITIONAL`.

**Typed condition nodes:** BH-IIIF-A-0185, BH-IIIF-A-0161. **Independent checks:** none (E1 only; imported certificates not globally reproduced).

```tex

\begin{proposition}[Closed-$S^3$ FLRW blindness and the native tensor Hessian]
\label{p3f:prop:v289-flrw-tensor-obstruction}
On a smooth four-dimensional Lorentzian curvature chart with
compactly supported interior variations, let
\[
 I_f[g]=\int\sqrt{-g}\,f(R[g]),\qquad
 I_{f,\beta}[g]=I_f[g]+\beta\int\sqrt{-g}\,
 C_{\mu\nu\rho\sigma}C^{\mu\nu\rho\sigma},\qquad \beta\ne0.
\]
Every FLRW metric, including a closed-$S^3$ FLRW metric, is
conformally flat. Thus the two functionals have identical
restrictions to the \emph{entire} FLRW metric family, irrespective
of its time derivatives. At a conformally flat background $g_0$,
the Weyl-square first variation vanishes for every interior metric
tangent, while its second variation is
\[
 \boxed{D^2(I_{f,\beta}-I_f)_{g_0}[h,h]
      =2\beta\int\sqrt{-g_0}\,
          C^{(1)}[h]_{\mu\nu\rho\sigma}
          C^{(1)}[h]^{\mu\nu\rho\sigma}.}
\]
On a constant-curvature Einstein background, for transverse-traceless
$h$, $DR_{g_0}[h]=0$. Therefore the four-derivative principal Hessian
of a pure $f(R)$ density vanishes on that TT slot, while the displayed
Weyl-square Hessian is nonzero for suitable TT tangents.
At a locally flat static spatial symbol with
$h_{12}=h_{21}=u(z)$, all other components zero,
$DR[h]=0$ and $C^{(1)}[h]^2=(u''(z))^2$.
Consequently the ordinary native Dirac tensor packet of
Proposition~\ref{p3f:prop:v224-native-tensor}, with its nonzero
$\beta=3/(160\pi^2)$, cannot be identified with a \emph{pure}
metric-$f(R)$ action on the same complete off-shell metric chart
unless its tensor contribution is canceled by other full-action
terms or a complete source/field/boundary transformation is supplied.
The Euler term retains its separate topological and boundary
completion; this proposition neither adds the native tensor packet
again nor claims a physical extra pole from a local expansion.
\end{proposition}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
FLRW metrics have $C=0$, which proves equality on the entire
restricted family. Since $C[g_0]=0$, every first variation of
$\sqrt{-g}C^2$ vanishes and the quadratic term is precisely the
square of the linearized Weyl tensor. The first curvature variation
is $DR[h]=\nabla_\mu\nabla_\nu h^{\mu\nu}-\Box h
-R_{\mu\nu}h^{\mu\nu}$, hence zero for TT tangents on an
Einstein background. A pure $f(R)$ density has four-derivative
quadratic principal term $f''(R_0)(DR[h])^2$, which therefore
vanishes in this slot. In the displayed flat static spatial test,
$R^{(1)}_{12}=-u''/2$, $R^{(1)}=0$ and
$(\mathrm{Riem}^{(1)})^2=2(u'')^2$,
$(\mathrm{Ric}^{(1)})^2=(u'')^2/2$.
The four-dimensional identity
$C^2=\mathrm{Riem}^2-2\mathrm{Ric}^2+R^2/3$
gives $C^{(1)2}=(u'')^2$. These are local principal-symbol
tests; an admitted compactly supported wave packet yields a
nonzero tensor quadratic form. The coefficient in
Proposition~\ref{p3f:prop:v224-native-tensor} is nonzero,
proving the conditional same-chart obstruction.
\end{proof}

```

### BH-IIIF-C-0430: Vanishing scalar contact, nonvanishing tensor round trip

**theorem; source:** `p3f:thm:v319-petersen-mirror-contact`, lines 23288–23308. **Disposition:** `VERIFIED`.

**Typed condition nodes:** stated source hypotheses in full quote; no new node needed. **Independent checks:** BH-IIIF-EV-B09-032.

```tex

\begin{theorem}[Vanishing scalar contact, nonvanishing tensor round trip]
\label{p3f:thm:v319-petersen-mirror-contact}
For each of the ten pair axes $u=u_{ij}$ with
$Q_{ij}=uu^{\mathsf T}-I_3/3$, the exact composition is
\[
 C_{ij}:=T_{ij}^{\mathsf T}\mathcal B(Q_{ij})
       =\frac13Q_{ij},
\]
and consequently
\[
 \operatorname{Tr}C_{ij}=0,\qquad
 \operatorname{Tr}C_{ij}^2=\frac{2}{27},\qquad
 \operatorname{Tr}C_{ij}^3=\frac{2}{243}.
\]
The complementary three-core subset changes $C_{ij}$ to $-C_{ij}$.
Thus a scalar linear trace contact of these two candidate source
families vanishes identically; a quadratic tensor contraction is
nonzero and complement-even, while the cubic contraction is
complement-odd.  These are \emph{conditional action diagnostics},
not action terms selected by the geometry.
\end{theorem}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
The first identity is the exact core/quadrupole interface of Paper~I-A,
Theorem~\ref{p1:thm:petersen-mirror-envelope}.  The eigenvalues of
$Q_{ij}/3$ are $2/9,-1/9,-1/9$, giving the three traces.
Complementation sends $T_{ij}\mapsto-T_{ij}$ and leaves the
fixed quadrupole $Q_{ij}$ unchanged.
\end{proof}

```

### BH-IIIF-C-0431: Exact requirement for a physical Petersen response

**corollary; source:** `p3f:cor:v319-petersen-response-owner`, lines 23317–23328. **Disposition:** `REPRODUCED`.

**Typed condition nodes:** BH-IIIF-A-0185, BH-IIIF-A-0138. **Independent checks:** none (E1 only; imported certificates not globally reproduced).

```tex

\begin{corollary}[Exact requirement for a physical Petersen response]
\label{p3f:cor:v319-petersen-response-owner}
Suppose an actual same-owner finite source action contains a
specified Petersen-marked operator family with licensed source ports.
Then the physical first and second response must include all varying
operator entries, markings, cross-sector blocks, kinetic metrics and
contact terms of that same action.  The finite trace and quadratic
identities above can then be evaluated in its actual Hessian;
without this premise no new mass pole, chiral splitting, hadron
spectrum, color-singlet contraction, Newton correction or running
coupling is obtained.
\end{corollary}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
Apply the generated action co-consumption theorem
\ref{p3a:thm:v2216-common-action-consumption} and the complete
source-jet conditions of Paper~III-D,
Theorem~\ref{p3d:thm:v2216-complete-action-jets}.  Algebraic
existence of a finite operator is logically weaker than physical
incidence of that operator in the action.  The two hypotheses cannot
be interchanged.
\end{proof}

```

### BH-IIIF-C-0432: No unique energy functional from source eligibility

**proposition; source:** `p3f:prop:v338-no-unique-two-core-mass-map`, lines 23352–23365. **Disposition:** `VERIFIED-CONDITIONAL`.

**Typed condition nodes:** stated source hypotheses in full quote; no new node needed. **Independent checks:** none (E1 only; imported certificates not globally reproduced).

```tex

\begin{proposition}[No unique energy functional from source eligibility]
\label{p3f:prop:v338-no-unique-two-core-mass-map}
On $U=\Lambda^2\mathbb R^5$ the unbroken $A_5$ symmetry permits
independently scaled self-adjoint quadratic forms
\[
 H_{a,b,c}=aP_4+bP_++cP_-.
\]
For example the identity $P_4+P_++P_-=I$ and the signed Hodge
response $P_+-P_-$ are both native but have different eigenvalues.
Therefore the five-core incidence and oriented-pair symmetries alone
do not fix a unique two-body rest-energy operator, nor any numerical
pion or kaon mass.  A same-action kinetic normalization and source
Hessian are necessary.
\end{proposition}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
The three pairwise orthogonal equivariant idempotents have nonzero
ranks $4,3,3$.  Their real linear span consists of distinct invariant
Hermitian matrices, and symmetry places no relation on their three
scalar coefficients.  In particular, two coefficient triples can
produce different spectra while preserving every incidence and
exterior-algebra identity.  A physical operator must be derived by
applying the fixed action to the typed source rather than choosing
one such triple afterward.
\end{proof}

```

### BH-IIIF-C-0433: Sharp neighborhood for the actual source-free active vacuum

**theorem; source:** `p3f:thm:v346-near-terminal-active-vacuum`, lines 23396–23414. **Disposition:** `VERIFIED-CONDITIONAL`.

**Typed condition nodes:** BH-IIIF-A-0186, BH-IIIF-A-0169. **Independent checks:** BH-IIIF-EV-B09-033.

```tex

\begin{theorem}[Sharp neighborhood for the actual source-free active vacuum]
\label{p3f:thm:v346-near-terminal-active-vacuum}
For $T(R):=Rf'(R)-2f(R)$ one has the exact identity
\[
 \boxed{T(R)=2C-R+\int_C^R(2x-R)\chi_7(x)\,dx.}
\]
There is no source-free constant-curvature root in the terminal sector
$R\le C$ or in the adjoining active interval $C<R\le2C$.
There is exactly one such root $R_*$ in $(2C,3C)$, with explicit bounds
\[
 \boxed{
 \frac{(2-2\log2)C^2}{U+5C}
 \ \le\ R_*-2C\ \le\ \frac{2C^2}{U-5C}.
 }
\]
In particular $R_*=2C+O(C^2/U)$, while $f''(R_*)>0$:
the self-consistent source-free vacuum is on the \emph{active} branch,
not the affine terminal stratum where $f''=0$.
\end{theorem}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
For $R\le C$, $f_{\rm term}(R)=R-C$ gives
$T(R)=2C-R>0$.  On $C<R\le2C$, both
$2C-R\ge0$ and $2x-R\ge0$ for $x\ge C$,
so $T(R)>0$.  At $R=2C$, boundedness
$1\le1+n_7\le2$ implies
\[
 \frac{(2-2\log2)C^2}{U+C}\le T(2C)
 \le\frac{2C^2}{U+C}.
\]
At $R=3C$, discarding the negative part of the integral gives
$T(3C)\le-C+9C^2/[2(U+C)]<0$.
Differentiation yields
\[
 T'(R)=-1+R\chi_7(R)-\int_C^R\chi_7(x)\,dx,
\]
and, for $2C\le R\le3C$,
$-1-4C/(U+C)\le T'(R)\le-1+6C/(U+C)<0$.
Thus precisely one zero lies in $(2C,3C)$; the mean-value theorem
combined with the two-sided bounds on $T(2C)$ proves the displayed
curvature estimates.
\end{proof}

```

### BH-IIIF-C-0434: Positive trace-mode scalaron mass at the active vacuum

**corollary; source:** `p3f:cor:v346-active-vacuum-scalaron`, lines 23438–23453. **Disposition:** `VERIFIED-CONDITIONAL`.

**Typed condition nodes:** BH-IIIF-A-0186, BH-IIIF-A-0169. **Independent checks:** BH-IIIF-EV-B09-034.

```tex

\begin{corollary}[Positive trace-mode scalaron mass at the active vacuum]
\label{p3f:cor:v346-active-vacuum-scalaron}
On the trace-linearized metric $f(R)$ domain of
Theorem~\ref{p3f:thm:trace-linearized-scalaron-mass}, the scalaron at
$R_*$ satisfies $f'(R_*)>0$, $f''(R_*)>0$, and
\[
 \boxed{m_{\rm sc}^2
 =\frac{f'(R_*)-R_*f''(R_*)}{3f''(R_*)}
 =\frac{4(U+C)}{9[1+n_7(2C)]}
  \left[1+O\!\left(\frac CU\right)\right]>0.}
\]
At $\sigma_{\rm fin}=0$, the formal half-determinant convention gives
$C/U\simeq4.216119310922\cdot10^{-121}$, and
$n_7(2C)\simeq0.00250704$, so $m_{\rm sc}^2/U\simeq0.44333$.
This is not an all-spin or nonlocal ghost-freedom certificate.
\end{corollary}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
At $2C$, $\chi_7=3[1+n_7(2C)]/[4(U+C)]$.
The location bound gives $R_*=2C+O(C^2/U)$ and hence
$f'(R_*)=1+O(C/U)$, with the same leading susceptibility at $R_*$.
Substitute into the existing trace-mode scalaron mass formula; positivity
uses $U>5C$ and the hierarchy $U/C\gg1$.  This proof is a
near-terminal asymptotic on the certified jet branch, not a derivation of
the complete physical cosmological history.
\end{proof}

```

### BH-IIIF-C-0435: Transverse projector and inverse-square identity

**proposition; source:** `p3f:prop:v353-projector-transversality`, lines 23489–23514. **Disposition:** `VERIFIED`.

**Typed condition nodes:** BH-IIIF-A-0187. **Independent checks:** BH-IIIF-EV-B09-035.

```tex

\begin{proposition}[Transverse projector and inverse-square identity]
\label{p3f:prop:v353-projector-transversality}
Let $P$ be a rank-$r$ orthogonal projector, $M=M^\dagger$ an
involution $M^2=I$, and $L_u=(I+uM)^{-1}$ for real $|u|<1$.
Then
\begin{equation}
\label{p3f:eq:v353-projector-iff}
 \operatorname{Tr}(PL_uPL_u)=\frac{r}{(1-u^2)^2}
 \quad\text{for every }u\text{ in an open interval}
 \quad\Longleftrightarrow\quad PMP=0.
\end{equation}
For the conditional canonical non-null Dirac boundary of
Remark~\ref{p3f:rem:v175-canonical-dirac-boundary-completion},
$\chi=\gamma_n\gamma_g$, $P=\Pi_+=(I+\chi)/2$ and $M=\gamma_g$
satisfy $PMP=0$ on its specified Clifford convention.  Therefore
with $J=R_sP/\sqrt2$, $r=2$ and
$u=cR/[R_s(1+\sqrt{1+(R/R_s)^2})]$ one has the exact
\emph{comparison} identity
\[
 -\frac18\operatorname{Tr}(JL_uJL_u)
 =-\frac{R_s^2}{8(1-u^2)^2}
 =-\frac{\sigma^2}{8B(R)^2}.
\]
This identity alone does not show that the native spectral operator
produces $L_u$ or $J$, nor that a physical non-null boundary occurs.
\end{proposition}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
Since $L_u=(I-uM)/(1-u^2)$,
$PL_uP=(P-uPMP)/(1-u^2)$ and
\[
 \operatorname{Tr}(PL_uPL_u)=
 \frac{r-2u\operatorname{Tr}(PMP)
      +u^2\operatorname{Tr}[(PMP)^2]}{(1-u^2)^2}.
\]
Equality on an interval forces the polynomial coefficients to vanish.
Self-adjointness gives $\operatorname{Tr}[(PMP)^2]=0$ precisely when
$PMP=0$.  For the canonical boundary $\{\chi,\gamma_g\}=0$.
Insert $\operatorname{Tr}P=2$ and $\sigma=B_IR_s$.
\end{proof}

```

### BH-IIIF-C-0436: Interior parity and its inherited reduction obstruction

**theorem; source:** `p3f:thm:v353-interior-parity`, lines 23529–23547. **Disposition:** `VERIFIED-CONDITIONAL`.

**Typed condition nodes:** BH-IIIF-A-0181, BH-IIIF-A-0187. **Independent checks:** none (E1 only; imported certificates not globally reproduced).

```tex

\begin{theorem}[Interior parity and its inherited reduction obstruction]
\label{p3f:thm:v353-interior-parity}
On an ordinary compact interior Dirac heat domain assume
$\{D_0,\Gamma\}=0$, $[V,\Gamma]=0$, and
$D(\phi)=D_0+\phi\Gamma V$, with common, conjugation-invariant
operator domain, trace and localizer.  Then
\[
 \Gamma D(\phi)\Gamma=-D(-\phi),\qquad
 S_{\rm heat}(R,\phi)=S_{\rm heat}(R,-\phi).
\]
If the curvature variation transports this grading equivariantly,
$\partial_R\partial_\phi S_{\rm heat}(R,0)=0$.
Moreover, any stationary auxiliary elimination or positive auxiliary
integration respecting the same involution on fields and measure
preserves this evenness.  An unmarked odd scalar source cannot thereby
produce a nonzero mixed curvature/odd-source first jet.
The claim does not apply to a boundary domain that fails the stipulated
conjugation invariance or to a source not identified with $\phi$.
\end{theorem}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
Conjugate the operator, square and take the invariant heat trace.
For $S(R,\phi,y)=S(R,-\phi,Cy)$ with $C^2=I$ and invariant
admissible $y$ domain, change variables $y\mapsto Cy$ in the
minimum (or invariant integral).  The reduced action remains even.
Differentiate at $\phi=0$.
\end{proof}

```

### BH-IIIF-C-0437: Exact cap chiral mixed-jet discriminator

**proposition; source:** `p3f:prop:v353-chiral-mixed-jet`, lines 23556–23585. **Disposition:** `VERIFIED`.

**Typed condition nodes:** BH-IIIF-A-0187. **Independent checks:** BH-IIIF-EV-B09-036.

```tex

\begin{proposition}[Exact cap chiral mixed-jet discriminator]
\label{p3f:prop:v353-chiral-mixed-jet}
In the purely finite comparison representation set
$\Gamma=\mathrm{diag}(I_2,-I_2)$,
$\chi=\bigl(\begin{smallmatrix}0&I_2\\I_2&0\end{smallmatrix}\bigr)$,
$P=(I+\chi)/2$, $\rho=R_s/2$, $J=\sqrt2\rho P$ and
\[
 F(R,q)=-\frac18\operatorname{Tr}
 \bigl[(J+q\Gamma)L_u(J+q\Gamma)L_u\bigr].
\]
Then the exact finite polynomial in the source is
\begin{equation}
\label{p3f:eq:v353-chiral-return}
 F(R,q)=-\frac{\rho^2-2\sqrt2\rho u q+(1+u^2)q^2}
                      {2(1-u^2)^2},
\end{equation}
and hence
\begin{equation}
\label{p3f:eq:v353-mixed-jet}
 \left.\partial_qF\right|_{q=0}=\frac{\sqrt2\rho u}{(1-u^2)^2},
 \qquad
 \left.\partial_R\partial_qF\right|_{R=q=0}
 =\frac{c}{2\sqrt2}.
\end{equation}
For $B_I>B_U$ this mixed jet is nonzero.  Therefore a direct
identification of $q\Gamma$ with the parity-odd source $\phi\Gamma V$
on the domain of Theorem~\ref{p3f:thm:v353-interior-parity}
would be inconsistent.  Other licensed physical source maps must
be compared by their own complete source transport, not ruled out.
\end{proposition}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
Use the $2+2$ chiral blocks, $L_u=\mathrm{diag}((1+u)^{-1}I_2,
(1-u)^{-1}I_2)$ and $P=(I+\chi)/2$.  Taking the trace gives
Eq.~\eqref{p3f:eq:v353-chiral-return}.
Differentiate, use $u(0)=0$ and $u'(0)=c/(2R_s)$.
\end{proof}

```

### BH-IIIF-C-0438: Observable-relative quadratic source identity

**proposition; source:** `p3f:prop:v353-observable-quadratic`, lines 23612–23633. **Disposition:** `VERIFIED`.

**Typed condition nodes:** BH-IIIF-A-0184, BH-IIIF-A-0149. **Independent checks:** none (E1 only; imported certificates not globally reproduced).

```tex

\begin{proposition}[Observable-relative quadratic source identity]
\label{p3f:prop:v353-observable-quadratic}
For two real stationary source models on a \emph{common physically licensed}
real probe space $q$, allow distinct real auxiliary dimensions and put
\[
 F_a(q)=\ell_a-(j_a+Q_aq)^\mathsf T T_a^{-1}(j_a+Q_aq),
 \quad T_a=T_a^\mathsf T>0,\qquad a=1,2.
\]
The two reduced quadratic polynomials coincide on an open real
probe set if and only if the three reduced quantities coincide:
\[
 \ell_a-j_a^\mathsf T T_a^{-1}j_a,\qquad
 Q_a^\mathsf T T_a^{-1}j_a,\qquad
 Q_a^\mathsf T T_a^{-1}Q_a.
\]
Complex auxiliary systems can be compared after a fixed, actual
realification of their physical source variables and Hermitian forms.  This criterion certifies \emph{physical quadratic response}
without assuming all auxiliary directions are observable; it does
not certify their complete parent identity or higher nonlinear jets.
Quantum-integrated spectators additionally require their measure
and determinant terms.
\end{proposition}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
Expand each quadratic polynomial into constant, linear and quadratic
coefficients.  Equality on an open real probe domain is equivalent
to equality of these coefficients; no invertibility of $Q_a$ is used.
\end{proof}

```

### BH-IIIF-C-0439: Native cone and complete-action frontier

**proposition; source:** `p3f:prop:v358-native-photon-cone-scope`, lines 23645–23660. **Disposition:** `VERIFIED-CONDITIONAL`.

**Typed condition nodes:** BH-IIIF-A-0188, BH-IIIF-A-0138. **Independent checks:** none (E1 only; imported certificates not globally reproduced).

```tex

\begin{proposition}[Native cone and complete-action frontier]
\label{p3f:prop:v358-native-photon-cone-scope}
On the stationary, parity-even source-free native Yang--Mills branch of
Theorem~\ref{p3f:thm:joint-gauge-principal-symbol-inheritance},
Corollary~\ref{p3f:cor:v244-transverse-gauge-propagation} already
establishes the transverse wave operator
$K_{\gamma,T}=\partial_t^2+c_{\rm op}^2\Delta_1^{\rm co}$
and its common metric characteristic cone.  The represented massless
photon eigendirection inherits the cone on the domain of the
corresponding Paper~V electroweak export.  The neutral mixed-Hessian
vanishing of Proposition~\ref{p3f:prop:v1166-neutral-photon-mixing}
identifies its Schur block with the \emph{direct} photon Hessian on the
stated neutral branch; it does not identify the complete direct block
with the retained local Yang--Mills constituent.  Full physical optical
transport requires a separate same-action source/cone certificate.
\end{proposition}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
The cited native corollary specifies the stationary coexact transverse
operator.  A vanishing mixed block removes the mixed Schur correction
but imposes no additional identity on the direct diagonal block.
Thus neither the protected native cone nor the stated full-action
frontier is strengthened beyond its original domain.
\end{proof}

```

### BH-IIIF-C-0440: Exact finite heat-trace two-jet

**proposition; source:** `p3f:prop:v358-photon-heat-hessian`, lines 23669–23690. **Disposition:** `VERIFIED`.

**Typed condition nodes:** BH-IIIF-A-0188. **Independent checks:** BH-IIIF-EV-B09-037.

```tex

\begin{proposition}[Exact finite heat-trace two-jet]
\label{p3f:prop:v358-photon-heat-hessian}
On a fixed finite covariant source window and fixed positive cutoff
$\Lambda$, let $D=D^*$ be twice differentiable in real source
coordinates $u,v$ and $S(D)=\frac12\operatorname{Tr}
\exp(-D^2/\Lambda^2)$.  At the base source put
\[
 X=D^2/\Lambda^2,\quad X_u=\{D,D_u\}/\Lambda^2,
 \quad X_v=\{D,D_v\}/\Lambda^2,
 \quad X_{uv}=(D_uD_v+D_vD_u+\{D,D_{uv}\})/\Lambda^2.
\]
In an eigenbasis $X|r\rangle=\lambda_r|r\rangle$, define
$\phi(a,b)=\int_0^1e^{-(1-s)a-sb}\,ds$.  Then
\begin{equation}
\label{p3f:eq:v358-photon-heat-two-jet}
 d_vd_uS=\frac12\sum_{r,s}\phi(\lambda_r,\lambda_s)
 (X_u)_{rs}(X_v)_{sr}
 -\frac12\sum_r e^{-\lambda_r}(X_{uv})_{rr}.
\end{equation}
The formula is continuous through spectral degeneracy.  Its contact
term, including $D_{uv}$, cannot in general be omitted.
\end{proposition}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
Differentiate $e^{-X}$ using the Duhamel integral and cyclicity
of the finite trace; then diagonalize $X$.  The integral definition
of $\phi$ is continuous at $a=b$, with $\phi(a,a)=e^{-a}$.
This is a specialization of the exact finite heat two-jet already
proved in Paper~III-B, Proposition~\ref{p3b:prop:v245-exact-finite-heat-two-jet}.
\end{proof}

```

### BH-IIIF-C-0441: Pure-gauge Ward cancellation and regulator test

**corollary; source:** `p3f:cor:v358-photon-gauge-orbit`, lines 23699–23715. **Disposition:** `VERIFIED`.

**Typed condition nodes:** BH-IIIF-A-0188. **Independent checks:** BH-IIIF-EV-B09-038.

```tex

\begin{corollary}[Pure-gauge Ward cancellation and regulator test]
\label{p3f:cor:v358-photon-gauge-orbit}
If the retained window is invariant under a unitary source orbit
$D(u)=U(u)D_0U(u)^*$ with $U(u)=e^{uT}$, $T^*=-T$, then
$D_u=[T,D_0]$, $D_{uu}=[T,[T,D_0]]$, and the complete quadratic
heat response along the gauge orbit is zero.  A non-invariant
projection can spoil this cancellation: if
$D_0=\operatorname{diag}(1,2)$ is rotated through angle $u$ and
compressed onto its first coordinate, one may take
$D_P(u)=1+\sin^2u$, for which
\[
 \left.\frac{d^2}{du^2}\left(\frac12e^{-D_P(u)^2}\right)
 \right|_{u=0}=-2e^{-1}\ne0.
\]
This is an example of a \emph{bad} window, not an assertion that the
framework's own finite cutoff is noncovariant.
\end{corollary}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
On the invariant window the heat trace is constant under conjugation;
differentiate twice, including the nonzero orbit acceleration.
The compressed counterexample follows from two elementary derivatives.
\end{proof}

```

### BH-IIIF-C-0442: Observable-oriented local optical-cone criterion

**proposition; source:** `p3f:prop:v358-local-photon-cone-test`, lines 23722–23738. **Disposition:** `VERIFIED`.

**Typed condition nodes:** BH-IIIF-A-0188. **Independent checks:** BH-IIIF-EV-B09-039.

```tex

\begin{proposition}[Observable-oriented local optical-cone criterion]
\label{p3f:prop:v358-local-photon-cone-test}
Assume an actually selected, local, homogeneous and isotropic,
parity-even, gauge-invariant two-derivative transverse source action
has positive coefficients $Z_E,Z_B$ and quadratic part
\[
 S_T^{(2)}=\frac12\int dt\,d\mu_h
 \bigl(Z_E|\dot a_T|^2-c_{\rm op}^2Z_B|da_T|^2\bigr).
\]
Its transverse characteristic speed equals the native operational
speed exactly when $Z_E=Z_B$, since
$c_\gamma^2=c_{\rm op}^2Z_B/Z_E$.  The native Yang--Mills branch
already satisfies this criterion.  For the complete nonlocal direct
action this test is only applicable after deriving the appropriate
principal symbol and physical Lorentzian transport; minimal Maxwell
form is \emph{not} a necessary premise for a shared null cone.
\end{proposition}

```

**Printed proof, source replay (E1):**

```tex

\begin{proof}
The transverse Euler equation has principal part
$Z_E\partial_t^2+c_{\rm op}^2Z_B\Delta_1^{\rm co}$.
Its characteristic equation yields the displayed ratio; positivity
selects the stated positive speed.
\end{proof}

```

## Source-level unnamed material proofs and consequences

### Lines 20496–20501: D03 Schur pole and retained residue

```tex

\begin{proof}
Normalize the full vector $(u,v)$ by
$(1+\|v\|^2)^{-1/2}$. Its spectral projector has retained weight
$(1+\|v\|^2)^{-1}$. Differentiation of the Schur operator gives the
displayed positive matrix, and the resolvent norm gives the bound.
\end{proof}

```

### Lines 20532–20538: D09 Bloch pair source work

```tex

\begin{proof}
Use the Pauli commutator for the state equation and
$p_s=-\langle\partial_a\widehat H\rangle/(3\mathcal Va^{-1})$.
Since $a\partial_ap=-p$, the kinetic terms cancel in the trace and the
displayed coherence remains. The identity
$d\mathcal E/dt=-3Hp_s\mathcal V$ gives exact source conservation.
\end{proof}

```

### Lines 20570–20577: D10 scalaron/source trace exchange

```tex

\begin{proof}
At fixed Einstein metric, $g_J=F^{-1}g_E$ and
$d\log F/d\phi=\sqrt{2/3}/M$. The Jordan metric variation is a Weyl
variation; its on-equation source is the complete trace. Comparing
$\delta S_s=-\int\sqrt{-g_E}\,J_\phi\delta\phi$ gives the first identity.
Multiply the scalar equation by $\dot\phi$ and differentiate its canonical
energy to obtain the two cancellation laws.
\end{proof}

```

### Lines 20605–20609: D14 third-jet K16 crossing

```tex

\begin{proof}
Differentiate $\log g_2/\log(R/U)$ at its zero numerator.
Above $C_2$, $D_{2,R}=\log Q\,n_{2,R}$; below $C_2$ it is zero.
The remaining factor is smooth, so only this term jumps.
\end{proof}

```

- `BH-IIIF-UNNAMED-B09-001`, lines 20001–20476: Final-response summary of inherited physical premises, calibration and local occurrence branches.

- `BH-IIIF-UNNAMED-B09-002`, lines 20478–20506: D03 quantitative Schur pole residue, with standalone proof 20496–20501.

- `BH-IIIF-UNNAMED-B09-003`, lines 20508–20549: D09 complete Bloch-pair finite source and pressure/trace ports.

- `BH-IIIF-UNNAMED-B09-004`, lines 20553–20582: D10 common scalaron matter-trace exchange.

- `BH-IIIF-UNNAMED-B09-005`, lines 20586–20617: D14 third-jet selector jump and crossing derivative.

- `BH-IIIF-UNNAMED-B09-006`, lines 20623–20665: A4 one-sided terminal Legendre cusp and finite potential slope.

- `BH-IIIF-UNNAMED-B09-007`, lines 20683–20734: Complete response coordinates, physical pole/actual action occurrence boundary.

- `BH-IIIF-UNNAMED-B09-008`, lines 20814–20957: Cap metric Hessian and asymmetric causal-memory candidate compatibility boundaries.

- `BH-IIIF-UNNAMED-B09-009`, lines 21008–21112: Finite CTP parent local-history source-action branch and normalization.

- `BH-IIIF-UNNAMED-B09-010`, lines 21326–21357: Fixed-state orbit bound is not a global curvature cap.

- `BH-IIIF-UNNAMED-B09-011`, lines 21568–21606: Source-free native vs complete physical vacuum domain distinctions.

- `BH-IIIF-UNNAMED-B09-012`, lines 21728–21775: Right source overlap and actual rooted action-incidence boundary.

- `BH-IIIF-UNNAMED-B09-013`, lines 21924–21974: Unresummed raw a6 vs complete heat fixed cutoff limitations.

- `BH-IIIF-UNNAMED-B09-014`, lines 22293–22340: Common local Einstein/YM/scalar packet and no-offset primitive member assumptions.

- `BH-IIIF-UNNAMED-B09-015`, lines 22426–22471: Finite CAR/Fock forward Hamiltonian, Sylvester normalization and source state.

- `BH-IIIF-UNNAMED-B09-016`, lines 22692–22720: Bare constant in first-jet source trace; no independent physical cancellation.

- `BH-IIIF-UNNAMED-B09-017`, lines 22834–22845: De Sitter equation-level witness and no extra scalaron in same doublet.

- `BH-IIIF-UNNAMED-B09-018`, lines 22922–22933: Canonical Jordan polarization and endpoint variation domain.

- `BH-IIIF-UNNAMED-B09-019`, lines 23188–23204: Full source/TT two-jet identity comparison.

- `BH-IIIF-UNNAMED-B09-020`, lines 23476–23488: Terminal affine root is an extrapolation, not physical active vacuum.

## Remarks (all read; not silently converted into unconditional claims)

- p3f:rem:v246-isospectral-owner-scope, lines 20783–20797: Exact scope of this obstruction.

- p3f:rem:v249-right-word-origin-scope, lines 21743–21769: What is, and is not, proved about the rooted source.

- p3f:rem:v250-full-heat-scope, lines 22268–22292: What has and has not been resummed.

- UNLABELED:Paper3F:remark:22670, lines 22670–22691: Absolute central energy is indispensable.

- p3f:rem:v257-bare-equation-witness, lines 22815–22833: An equation-level stationary witness on the exact bare restriction.

- UNLABELED:Paper3F:remark:22836, lines 22836–22844: No additional scalaron has been inserted.

- UNLABELED:Paper3F:remark:22909, lines 22909–22921: What this forward construction does and does not close.

- UNLABELED:Paper3F:remark:23264, lines 23264–23275: What a native cap identity must now test.

- p3f:rem:v346-terminal-affine-extrapolation, lines 23464–23475: Affine terminal Einstein root is an extrapolation.

- p3f:rem:v353-grading-frontier, lines 23593–23610: Physical boundary and finite grading.

## Five earlier open findings, no new defect from Batch 9

### BH-IIIF-G-0001: MISSING_EVIDENCE (moderate; OPEN)
**Location:** `p3f:cor:v176-first-class-constraint-propagation` — `Paper3F-CompleteDynamics-v1_256.tex:6191-6218`.
**Precise issue/obligation:** Supply explicit source-matched bracket/constraint closure proof (or checked imported ADM theorem) on regular same-owner scalar-tensor–Yang–Mills phase space; identify any further local differentiability/constraint conditions. Not a demand for a global Cauchy flow.
**Proven other-paper impact:** []; possible or unverified propagation is not asserted as proven.

### BH-IIIF-G-0002: INCORRECT_STEP (moderate; OPEN)
**Location:** `p3f:prop:vacuum-shift-symplectic-scope` — `Paper3F-CompleteDynamics-v1_256.tex:8277-8284`.
**Precise issue/obligation:** Correct/distinguish curvature Hessian from full metric covariant off-shell symplectic current. The aR affine direction changes the Einstein-Hilbert presymplectic current. Retain b-only invisibility, and separately retain valid coefficient-family connection argument for κ=0.
**Proven other-paper impact:** []; possible or unverified propagation is not asserted as proven.

### BH-IIIF-G-0003: MISSING_CONDITION (minor; OPEN)
**Location:** `p3:thm:local-fR-field-equation` — `Paper3F-CompleteDynamics-v1_256.tex:9848`.
**Precise issue/obligation:** Keep the Paper III-E condition CELL_{K→U} attached to the U=(3/π)Kp comparison. It is not derived solely from Kp=6/Rmom² and U=Lambda_EH². The same theorem correctly includes that condition at line 9929.
**Proven other-paper impact:** []; possible or unverified propagation is not asserted as proven.

### BH-IIIF-G-0004: MISSING_CONDITION (moderate; OPEN)
**Location:** `p3:cor:no-independent-lr-gauge-coefficient` — `Paper3F-CompleteDynamics-v1_256.tex:11166-11171`.
**Precise issue/obligation:** For the absolute dimensionless expression κ f₂/48, also require r_fib Λcut=1 (BH-IIIF-A-0016). Without it theorem 201 gives κ r_fib² f₂ Λcut²/48. The base CAL_GRED by itself explicitly excludes automatic saturation.
**Proven other-paper impact:** []; possible or unverified propagation is not asserted as proven.

### BH-IIIF-G-0005: INVALID_GENERAL_BOUND / MISSING_RANK_ALIGNMENT (moderate; OPEN)
**Location:** `p3f:prop:v1118-feshbach-propagation-not-genesis` — `Paper3F-CompleteDynamics-v1_256.tex:13215-13233, decisive lines 13225-13229`.
**Precise issue/obligation:** Paired complement U unitary and Delta !=0, A_L and A_R only full rank. Establish additional compatible subspace alignment/invertibility of product, or restrict theorem to an actual square-invertible couplings domain supported by source. As written full rank does not guarantee that bound. No new repair theorem added.
**Proven other-paper impact:** []; possible or unverified propagation is not asserted as proven.

## Independent calculation and counterexample checks

- `BH-IIIF-EV-B09-001` E3 **E3-summary-D03-residue-normalized-schur**; labels=['p3f:sec:v2201-derived-d03']; passed=True; residual=6.661338147750939e-16; tolerance=1e-12; domain=simple isolated full eigenvalue outside complementary spectrum, finite real Hermitian block.

- `BH-IIIF-EV-B09-002` E3 **E3-summary-D09-Bloch-commutator**; labels=['p3f:sec:v2201-derived-d09']; passed=True; residual=6.206335383118183e-17; tolerance=1e-12; domain=fixed paired source 2x2 Hermitian nonstationary state and central term.

- `BH-IIIF-EV-B09-003` E3 **E3-summary-A4-Legendre-endpoint-cusp**; labels=['p3f:sec:v2201-derived-a4']; passed=True; residual=0.0; tolerance=1e-10; domain=active one-sided terminal jet, delta>0, fixed U,C.

- `BH-IIIF-EV-B09-004` E3 **E3-summary-D10-conformal-trace-source**; labels=['p3f:sec:v2201-derived-d10']; passed=True; residual=1.734723475976807e-18; tolerance=1e-13; domain=conformal Jordan metric source, fixed Einstein pairing.

- `BH-IIIF-EV-B09-005` E3 **E3-summary-D14-descending-crossing-jump**; labels=['p3f:sec:v2201-derived-d14']; passed=True; residual=5.551115123125783e-17; tolerance=1e-14; domain=strict crossing, no source impulse, continuous chi and Fdd.

- `BH-IIIF-EV-B09-006` E3 **E3-scalar-isospectral-marked-response**; labels=['p3f:prop:v246-charged-marked-isospectral-ambiguity']; passed=True; residual=4.440892098500626e-16; tolerance=1e-12; domain=algebraic three-corner comparison, rooted probe held fixed; not physical constructor license.

- `BH-IIIF-EV-B09-007` E3 **E3-tagged-spectral-floor-inequality**; labels=['p3f:prop:v246-electron-spectral-floor-test']; passed=True; residual=0.0; tolerance=1e-14; domain=normalized g, global spectral lower and upper bound.

- `BH-IIIF-EV-B09-008` E3 **E3-endpoint-constant-scalar-Hessian-difference**; labels=['p3f:prop:v246-cap-metric-hessian-defect']; passed=True; residual=0.0; tolerance=1e-14; domain=matched value/first derivative endpoint, common compact interior patch.

- `BH-IIIF-EV-B09-009` E3 **E3-singular-Schur-threshold**; labels=['p3f:prop:v246-singular-scalaron-cancellation']; passed=True; residual=4.996003610813204e-16; tolerance=1e-13; domain=positive scalar auxiliary, chi>0, p=1/2 singular coupling.

- `BH-IIIF-EV-B09-010` E4 **E4-off-diagonal-retarded-kernel-nonsymmetric**; labels=['p3f:prop:v246-causal-hessian-integrability']; passed=True; residual=0.0; tolerance=1e-12; domain=nonzero strict lower triangular retarded kernel cannot equal symmetric Hessian.

- `BH-IIIF-EV-B09-011` E3 **E3-CTP-influence-first-control-derivative**; labels=['p3f:thm:v246-finite-source-influence-parent']; passed=True; residual=1.3992987373221115e-10; tolerance=2e-08; domain=finite 2-level source, fixed positive rho, finite history, normalized branch, hbar=1.

- `BH-IIIF-EV-B09-012` E3 **E3-state-orbit-rearrangement-bounds**; labels=['p3f:prop:v247-native-curvature-orbit-bounds']; passed=True; residual=0.0; tolerance=1e-13; domain=fixed positive density spectrum and Hermitian insertion at fixed geometry.

- `BH-IIIF-EV-B09-013` E3 **E3-native-constant-vacuum-elimination**; labels=['p3f:thm:v248-native-constant-vacua']; passed=True; residual=0.0; tolerance=1e-12; domain=full scalar matrix equation and constant Einstein equations, D_n nonzero.

- `BH-IIIF-EV-B09-014` E3 **E3-native-radial-Einstein-scalar-mass**; labels=['p3f:prop:v248-native-vacuum-masses']; passed=True; residual=2.5426472483047746e-07; tolerance=2e-06; domain=admitted rank n constant vacuum and retained scaling tangent.

- `BH-IIIF-EV-B09-015` E3 **E3-bare-native-Einstein-potential-identity**; labels=['p3f:cor:v248-bare-all-rank-vacuum']; passed=True; residual=0.0; tolerance=1e-12; domain=positive F Hermitian scalar matrix, actual bare V0.

- `BH-IIIF-EV-B09-016` E3 **E3-fixed-current-right-overlap-resolvent**; labels=['p3f:prop:v249-fixed-current-source-nonimplication']; passed=True; residual=5.551115123125783e-17; tolerance=1e-12; domain=fixed left current and single-arrow returns, varying right overlap, source-only comparison.

- `BH-IIIF-EV-B09-017` E3 **E3-mixed-fourth-source-moment-and-residues**; labels=['p3f:prop:v249-fourth-moment-right-overlap']; passed=True; residual=1.1379786002407855e-15; tolerance=1e-12; domain=unit-current aligned arrows, orthogonal muon support, strict mixed overlap.

- `BH-IIIF-EV-B09-018` E3 **E3-complete-native-improved-trace-budget**; labels=['p3f:thm:v249-native-vacuum-correction-budget']; passed=True; residual=0.0; tolerance=1e-13; domain=full co-consumed remainder trace+scalar insertion, bare constant once.

- `BH-IIIF-EV-B09-019` E3 **E3-remainder-weighted-Euler-trace**; labels=['p3f:prop:v249-weighted-remainder-budget']; passed=True; residual=0.0; tolerance=1e-13; domain=constant curvature/parallel scalar, finite weighted homogeneous sum.

- `BH-IIIF-EV-B09-020` E3 **E3-raw-a6-truncation-cubic-root**; labels=['p3f:thm:v249-evaluated-raw-a6-vacuum']; passed=True; residual=3.1590730031894054e-11; tolerance=1e-09; domain=fixed unprojected a6 Euler representative, maximally symmetric truncation, not controlled heat sum.

- `BH-IIIF-EV-B09-021` E3 **E3-exact-heat-homothety-fixed-window**; labels=['p3f:thm:v250-exact-heat-homothety']; passed=True; residual=7.865930129469234e-11; tolerance=1e-09; domain=fixed finite reducing window, positive eigenvalues, fixed cutoff.

- `BH-IIIF-EV-B09-022` E3 **E3-native-product-position-factor-heat**; labels=['p3f:prop:v250-native-product-heat-scale']; passed=True; residual=1.1455796311565791e-09; tolerance=1e-08; domain=fixed position factor spectral truncation, momentum/torus held fixed.

- `BH-IIIF-EV-B09-023` E3 **E3-parallel-scalar-exact-heat-radial-variation**; labels=['p3f:thm:v250-exact-parallel-scalar-heat']; passed=True; residual=1.9216850333236835e-11; tolerance=1e-09; domain=parallel internal Hermitian scalar, commuting graded tensor Dirac, fixed cutoff.

- `BH-IIIF-EV-B09-024` E3 **E3-primitive-family-canonical-coefficients**; labels=['p3f:prop:v251-primitive-canonical-scalar-packet']; passed=True; residual=0.0; tolerance=1e-13; domain=fixed primitive four identity family matrices, no-offset chart.

- `BH-IIIF-EV-B09-025` E3 **E3-ordered-noncommuting-scalar-jet**; labels=['p3f:prop:v251-native-scalar-mixed-jets']; passed=True; residual=2.1054225030070484e-10; tolerance=5e-07; domain=Hermitian noncommuting generator directions, orthonormal finite trace.

- `BH-IIIF-EV-B09-026` E3 **E3-causal-packet-no-double-work-central-source**; labels=['p3f:thm:v251-forward-causal-native-packet']; passed=True; residual=0.0; tolerance=1e-13; domain=fixed 2-level trace-one finite source and complete Hamiltonian.

- `BH-IIIF-EV-B09-027` E3 **E3-noncommuting-positive-source-Lyapunov**; labels=['p3f:prop:v251-forward-source-trace-sign']; passed=True; residual=5.644119504969763e-16; tolerance=1e-12; domain=K and M² noncommuting positive, fixed finite free occupation source.

- `BH-IIIF-EV-B09-028` E3 **E3-hyperbolic-primitive-Einstein-scalar-metric**; labels=['p3f:thm:v251-forward-higgs-hyperbolic-target']; passed=True; residual=0.0; tolerance=1e-11; domain=four-real-component primitive doublet, positive F, conformal Weyl transport.

- `BH-IIIF-EV-B09-029` E3 **E3-source-free-closed-FLRW-future-constraint**; labels=['p3f:thm:v251-forward-bare-radial-global-future']; passed=True; residual=2.419264788500186e-11; tolerance=1e-07; domain=exact polynomial radial restriction, a_i>1/sqrt(2L), expanding initial constraint.

- `BH-IIIF-EV-B09-030` E3 **E3-curvature-canonical-symplectic-exchange**; labels=['p3f:cor:v260-canonical-exchange']; passed=True; residual=3.469446951953614e-18; tolerance=1e-13; domain=nonzero eta chi, fixed scalar metric chart and endpoint polarization.

- `BH-IIIF-EV-B09-031` E3 **E3-complete-source-two-jet-inverse**; labels=['p3f:thm:v289-complete-source-twojet']; passed=True; residual=1.2609709600486848e-15; tolerance=1e-10; domain=invertible common probe Q, real symmetric positive parent, fixed common normalization.

- `BH-IIIF-EV-B09-032` E3 **E3-Petersen-trace-quadratic-cubic**; labels=['p3f:thm:v319-petersen-mirror-contact']; passed=True; residual=1.734723475976807e-18; tolerance=1e-13; domain=source-matched 3-dimensional mirror map, Paper I-A identity imported.

- `BH-IIIF-EV-B09-033` E3 **E3-terminal-active-root-interval-and-bound**; labels=['p3f:thm:v346-near-terminal-active-vacuum']; passed=True; residual=0.0; tolerance=1e-12; domain=fixed n7=0.15 within bounded 0<=n7<=1, C>0, U>5C.

- `BH-IIIF-EV-B09-034` E3 **E3-terminal-scalaron-mass-asymptotic**; labels=['p3f:cor:v346-active-vacuum-scalaron']; passed=True; residual=0.004604673346662036; tolerance=0.02; domain=fixed n7 profile positive, U/C sufficiently large, asymptotic tolerance stated.

- `BH-IIIF-EV-B09-035` E3 **E3-transverse-projector-resolvent-trace**; labels=['p3f:prop:v353-projector-transversality']; passed=True; residual=2.220446049250313e-16; tolerance=1e-13; domain=orthogonal rank-one projector and self-adjoint involution with PMP=0.

- `BH-IIIF-EV-B09-036` E3 **E3-chiral-cap-finite-mixed-source-polynomial**; labels=['p3f:prop:v353-chiral-mixed-jet']; passed=True; residual=2.7755575615628914e-17; tolerance=1e-13; domain=given chiral 4-state finite comparison; source is not automatically a physical odd scalar.

- `BH-IIIF-EV-B09-037` E3 **E3-photon-finite-noncommuting-heat-twojet**; labels=['p3f:prop:v358-photon-heat-hessian']; passed=True; residual=3.742544786231039e-09; tolerance=1e-07; domain=fixed finite covariant source window, noncommuting D,D_u,D_v, nonzero D_uv contact.

- `BH-IIIF-EV-B09-038` E3 **E3-photon-full-Ward-cancellation-and-bad-window**; labels=['p3f:cor:v358-photon-gauge-orbit']; passed=True; residual=1.1846956304850664e-08; tolerance=1e-07; domain=unitary invariant whole finite window and explicit noninvariant compressed window.

- `BH-IIIF-EV-B09-039` E3 **E3-optical-cone-principal-speed-ratio**; labels=['p3f:prop:v358-local-photon-cone-test']; passed=True; residual=0.0; tolerance=1e-14; domain=local homogeneous isotropic parity-even gauge invariant 2-derivative action.

- `BH-IIIF-EV-B09-040` E4 **E4-spectrum-without-floor-not-eigenvector**; labels=['p3f:prop:v246-electron-spectral-floor-test']; passed=True; residual=4.440892098500626e-16; tolerance=1e-13; domain=2x2 B positive with interior e²=2, mean zero but non-eigenvector: excluded branch.

- `BH-IIIF-EV-B09-041` E4 **E4-rectangular-Schur-fullrank-unprotected**; labels=['p3f:prop:v246-singular-scalaron-cancellation', 'p3f:cor:v227-finite-handoff']; passed=True; residual=0.0; tolerance=1e-14; domain=counterexample to earlier BH-IIIF-G-0005 remains; not imported automatically into current regular invertible Schur branch.

- `BH-IIIF-EV-B09-042` E4 **E4-single-history-retarded-nonzero-is-not-Hessian**; labels=['p3f:prop:v246-causal-hessian-integrability']; passed=True; residual=0.0; tolerance=1e-13; domain=nonzero retarded off-diagonal kernel violates Hessian symmetry; doubles histories cure.

- `BH-IIIF-EV-B09-043` E4 **E4-unknown-scalar-complete-parent-not-selected**; labels=['p3f:thm:v248-native-constant-vacua', 'p3f:thm:v250-exact-parallel-scalar-heat']; passed=True; residual=0.0; tolerance=1e-13; domain=Euclidean raw parent and local truncated Lorentzian action different physical domains, no valid cross-refutation.

- `BH-IIIF-EV-B09-044` E4 **E4-bare-high-curvature-extrapolation-not-controlled**; labels=['p3f:cor:v248-bare-all-rank-vacuum', 'p3f:thm:v251-forward-bare-radial-global-future']; passed=True; residual=0.0; tolerance=1e-13; domain=R/L=24 outside |R|/L << 1 regime; mathematical truncation not false.

- `BH-IIIF-EV-B09-045` E4 **E4-physical-source-state-need-not-extremize-orbit**; labels=['p3f:prop:v247-native-curvature-orbit-bounds']; passed=True; residual=0.0; tolerance=1e-13; domain=orbit extrema reachable by some states, not necessarily by given trajectory.

- `BH-IIIF-EV-B09-046` E4 **E4-fixed-window-vs-moving-sharp-frontier**; labels=['p3f:thm:v250-exact-heat-homothety']; passed=True; residual=0.0; tolerance=1e-13; domain=moving spectral-window derivative has jump/contact; excluded from fixed-window theorem.

- `BH-IIIF-EV-B09-047` E4 **E4-finite-cap-identity-not-complete-TT-action**; labels=['p3f:prop:v289-flrw-tensor-obstruction']; passed=True; residual=0.0; tolerance=1e-13; domain=scalar FLRW variation cannot detect Weyl-square TT Hessian.

- `BH-IIIF-EV-B09-048` E4 **E4-projector-nontransverse-defeats-iff**; labels=['p3f:prop:v353-projector-transversality']; passed=True; residual=0.0; tolerance=1e-13; domain=P=(I+sz)/2, M=sz, nonzero PMP and resolvent trace different.

- `BH-IIIF-EV-B09-049` E4 **E4-photon-gauge-noninvariant-window-ward-failure**; labels=['p3f:cor:v358-photon-gauge-orbit']; passed=True; residual=0.0; tolerance=1e-13; domain=non-equivariant projection gives -2/e source Hessian, not physical projector claim.

## DAG and release boundaries
Every source proof/use edge has a typed proof route and claim-matched source locator; statement-only references are nonpromoting candidates. Reuse of inherited conditions does not create new constitutional axioms. E3/E4 tests are performed by one executor with independent formulas and separate adversarial controls; there is no claimed multi-agent corroboration. Final source-coverage and global atlas/audit ZIP integration will be checked by separate post-write validation.