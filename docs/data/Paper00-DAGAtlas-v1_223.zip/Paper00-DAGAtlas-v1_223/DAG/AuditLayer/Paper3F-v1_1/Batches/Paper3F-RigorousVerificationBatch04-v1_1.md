# Paper III-F — Rigorous Verification DAG Audit, Batch 04

**Frozen source:** Paper3F-CompleteDynamics-v1_256.tex (SHA256 `47d43b2d08b2245ade810eae64a9e1cc827398f60899af0afed7cb2398358a77`), Framework `v2_370`.

**Protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md`; selected manuscript only; no theory repairs, paper rewrite, or ZIP exports.

**Source region:** 6,570–9,070 inclusive, current 23,747-line source.

**Coverage:** 50 named claims, 42 proof environments, 13 formal remarks, 18 independent unnamed material clusters. 100 source references resolve uniquely. 35 reviewed theorem proof-use edges, 1 proof-only nonmaterial references.

**Epistemic dispositions:** FORMALIZED=4, INCONSISTENT=1, REPRODUCED=13, VERIFIED=17, VERIFIED-CONDITIONAL=15. Status counts classify proof scopes, not direct claims of physically occurring dynamical histories.

**Independent evidence:** 76 E3, 8 E4 pass; 8 native candidate high-precision checks pass. A PASS confirms only its attached equation/domain, not all physical assertions in a theorem.

## Findings — all issues in this batch

### BH-IIIF-G-0002 — INCORRECT_STEP / moderate / OPEN

**First defective clause:** `p3f:prop:vacuum-shift-symplectic-scope`, lines 8277–8284; proof 8288–8297. **The curvature-Hessian statement and subsequent coefficient connection still pass.**

The text says that equality of the **off-shell symplectic current** cannot determine affine `κ` for the metric density after `f(R) -> f(R)+aR+b`. This is false for the full covariant metric symplectic current: the `aR` contribution has the Einstein–Hilbert kinetic presymplectic form, although the constant `b` term has none.

**Independent exact E4 witness:** Smooth Lorentzian metric on a local chart `g=diag(-1,e^{2q(t)},e^{-2q(t)},1)` has `sqrt(-g)=1`, `R=2(qdot)^2` by direct Christoffel/Ricci computation. The shift density is `ΔL=2a(qdot)^2+b`. Its presymplectic current on two local variations is `Δω^t=4a(δ₁q δ₂qdot − δ₂q δ₁qdot)` (sign convention immaterial). For `δ₁q=1, δ₂q=t` on an interior patch, `Δω^t=4a ≠0`. Smooth compact-support variations may be chosen to agree with these profiles within that patch. Thus a change in `a` is visible to the full off-shell current. **Positive control:** `b` alone leaves the current invariant.

**Scope/adjudication:** The witness satisfies the printed smooth metric action class and concerns a full metric field-space symplectic current, not an ambient unrelated physical constructor. Only the symplectic-current-blindness clause fails. Bare `κ=0` follows independently from the horizontal coefficient connection; the certified bare constructor theorem remains intact. No proven cross-paper/observable failure has been assigned. Any further impact requires a source-matched consumer edge.

**Precise obligation:** Distinguish curvature Hessian from covariant metric symplectic current, or explicitly define and scope a different projected object. No source changes were made in this audit.

### Previously open issue retained, not re-adjudicated as resolved

`BH-IIIF-G-0001` at `p3f:cor:v176-first-class-constraint-propagation` (6191–6218) remains **OPEN / MISSING_EVIDENCE**. Batch 4 does not provide an explicit bracket computation or checked imported first-class proof; no closure is inferred from unrelated Schur/Noether results.

### Conditions and evidence frontiers — not mathematical errors

1. `ACT_cl` stationary family is an exact finite role-level zero locus only when the complete classical action and frozen exact-solution constructor exist. Neither a particular world history nor nonempty physical family is proved.

2. `QROOT` is a separate quantum excitation-source-completeness bridge; the classical source-free homogeneous datum alone does not discharge it. A later target theorem is referenced but has not been audited in this batch.

3. The bare Born coefficient, the fixed-`Q` finite-orbit candidate, the active dressed `4|7` response, the conditional two-sided UV scalaron and the separate capped action are *not* one automatically selected action. Physical owner/overlap/continuation certificates must not be inferred from algebraic agreement.

4. The UV scalaron mass is proven for an additional same-parent two-sided quadratic continuation. The IR terminal `C7` is not a UV wall. Variable `A(s(t))` requires its own owner and coefficient-work source.

5. Collar results compare same-geometry action values at fixed width. An actually integrated collar adds an independent determinant; neither result proves nearby physical solutions or a quantum measure.

6. Full heat Hessian, localizer contact, causal Schur, photon direct Hessian, and Dirac `a6` remain distinct action-readout levels; no automatic additive `a6` physical action or extra particle is implied.

7. Source remark 7491–7548 quotes full slow-roll table, 205-point sign scan and 48/64-node quadratures. The E3 numeric certificate here independently checks eight **late-vacuum** numbers, not the entire scan/table. Hence unexecuted numerical checks retain E1/REPRODUCED status, not a blanket verified inflationary prediction.

## Independent evidence highlights

- **Grassmann / two-frame:** full mixed coefficient differentiation and same-action chiral kinetic cancellation; comparison factor `sqrt(24/25)` applies only to specified opposite frames.

- **Born coefficient/Legendre:** horizontal connection Euler derivative, terminal selector, affine defect, renormalized vacuum redundancy and general metric-`f(R)` coupling.

- **Native infrared high precision:** direct 175-digit reconstruction of original finite 2×2 eigenvalue orbit with independent dilogarithmic `Ψ` primitive. Reproduces `w0(2)`, first two derivatives, the `2.23583777e−116` relative vacuum shift, both `F` contacts, `U K`, and positive `m_sc²/U`. See `E3Numeric-Batch04.json`.

- **UV/cap:** scalaron potential Taylor coefficients; homogeneous time-dependent coefficient trace; cap source-complete curvature momentum and Hessian; global cap-vacuum proof replay with independent exact rational identities + admissible parameter control; finite DN collar determinant from eigenvalue product.

- **Heat/constraints:** noncommuting unlocalized and localizer-aware second Duhamel matrix tests, curvature Weyl–Euler decomposition, scalar diagnostic cubic terminal jet, positive Schur inequality, hyperbolic odd target curvature, on-shell trace, gauge Ward correction and signed low-mode resolvent bound.

## Claim-by-claim source dispositions

| ID | Source lines | Statement | Disposition | Exact scope / retained frontier | E3/E4 controls |
|---|---:|---|---|---|---:|
| BH-IIIF-C-0112 | 6572–6601 | Coefficientwise local common-parent differentiation | VERIFIED | Fixed finite-window complete quadratic bilinear owner, independent ordered odd coefficients; no physical selection from bosonic Hessian. | 3 |
| BH-IIIF-C-0113 | 6609–6630 | Exact conditional discharge of kinetic normalization | VERIFIED-CONDITIONAL | Uninserted local clock branch, cF>0, I_L=I_R identity same-action chiral source Gram, actual charged D_LR independently generated and certified. | 2 |
| BH-IIIF-C-0114 | 6640–6664 | Conditional same-action two-frame chiral normalization | VERIFIED | Specified two-frame port-augmented action with isometries j0,j1 and j0†j1=sqrt(24/25)I; no selection of physical frame assignment. | 2 |
| BH-IIIF-C-0115 | 6687–6728 | Generated stationary-solution family under the classical-action bridge | REPRODUCED | Conditional complete finite/exact classical Lorentz action and exact stationary equalizer/GP2 quotient; family can be empty and no occurring member is selected. | 0 |
| BH-IIIF-C-0116 | 6741–6758 | Classical stationary-family provider for the cascade | REPRODUCED | Complete finite/exact cascade ACT_cl action node and inherited stationary-family constructor; role-specific, no second occurrence for nonempty generated family. | 0 |
| BH-IIIF-C-0117 | 6767–6783 | Local stationary-family host and covariant history identity | REPRODUCED | Nonempty local stationary-family branch with full-domain section tuples; host co-realized but no Cauchy well-posedness or world history selection. | 0 |
| BH-IIIF-C-0118 | 6785–6802 | Local discharge of the historical Einstein action-role bridge | REPRODUCED | Existing v1.75 analytic local clock/ADM interior joint Dirac action; EH restriction only and conditional CELL K→U scale identification. | 0 |
| BH-IIIF-C-0119 | 6813–6835 | Certified action/contact and local-excess response domain | FORMALIZED | Definition of two independently imported certificates: actual action/contact normalized root/zero defect and fixed-depth Euler-excess character; no certificate from response alone. | 0 |
| BH-IIIF-C-0120 | 6837–6877 | Generated action response under configuration and coefficient-family variation | REPRODUCED | Two independent tangent sorts B_sd and local configuration; coefficient-line response relative to certified action/contact only, no physical history selected. | 0 |
| BH-IIIF-C-0121 | 6898–6954 | Coefficient-family evaluation response on the bare Born leaf | VERIFIED-CONDITIONAL | Fixed scheme sigma, certified action/contact aU=id, horizontal determinant evaluation and supplied R=Ue^-Lq coefficient line; no reverse CRP4 reconstruction. | 3 |
| BH-IIIF-C-0122 | 7036–7086 | Metric backreaction in the generated joint-EH coupling coordinate | REPRODUCED | Physical SOLHIST member, REN0, exact zero higher-curvature or IR small-norm alternative; local joint EH coupling raw G and claim-complete matter stress source. | 1 |
| BH-IIIF-C-0123 | 7106–7129 | Renormalized vacuum baseline and quantum excitation source | FORMALIZED | Definition of state-independent vacuum offset plus positive excitation Hamiltonian on an already defined quantum branch; not absolute vacuum renormalization. | 0 |
| BH-IIIF-C-0124 | 7131–7155 | QROOT quantum-source-completeness bridge | FORMALIZED | Definition of QROOT additional excitation-source completeness; classical rho0=p0=0 alone does not imply quantum expectation vanishes. | 0 |
| BH-IIIF-C-0125 | 7170–7225 | General local metric-\(f(\scal)\) variation | VERIFIED-CONDITIONAL | Metric f(R) with local C2 g, f C1 near compact variation supports and phi=fprime(R) C2; admitted LORdir or CONTcl and SOLHIST/REN0. | 3 |
| BH-IIIF-C-0126 | 7253–7277 | Joint TERM--REN zero-order redundancy | VERIFIED | Single complete local action with TERM and REN redistributed together; fixed fprime/fsecond and common physical dimension. | 1 |
| BH-IIIF-C-0127 | 7290–7312 | Legendre potential of the complete same action | VERIFIED | Same-action fbar=f-2Lambda, U>0, fbarsecond≠0 on local interval; auxiliary scalar is a Legendre rewrite, not independent field. | 2 |
| BH-IIIF-C-0128 | 7334–7366 | Generated bare normalized potential and the dressed target | VERIFIED-CONDITIONAL | Certified undressed two-root and bare first-response branch; Born even only for scalarized bare target, not automatic dressed marked potential. | 3 |
| BH-IIIF-C-0129 | 7408–7445 | Regular late-vacuum branch of the fixed-$Q$ candidate | VERIFIED-CONDITIONAL | Composed fixed Q finite orbit candidate with fixed hierarchy H; local bookkeeping mu small and w0second(2)>0 for scalaron sign; not physical action selection. | 6 |
| BH-IIIF-C-0130 | 7550–7579 | Canonical response rate on a fixed visibility parent | VERIFIED-CONDITIONAL | Fixed visibility/depth R_tau readout and certified active Laurent action; tau not physical proper time, candidate compared only as distinct coefficient graph. | 2 |
| BH-IIIF-C-0131 | 7601–7614 | Rank-four generated positive-response representative | REPRODUCED | Positive response branch R>C7 and fixed-depth carrier-four coefficient and contacts; action/excess certificates required for physical port. | 0 |
| BH-IIIF-C-0132 | 7623–7650 | Coherent UV scalaron on a closed universe: conditional two-sided branch | VERIFIED-CONDITIONAL | Additional SAME PARENT regular signed two-sided UV quadratic action through R_J=0 with Q/U; not automatically continued from one-sided IR Legendre chart. | 2 |
| BH-IIIF-C-0133 | 7659–7685 | Closed-$S^3$ trace and coefficient-work terms | VERIFIED-CONDITIONAL | Closed k=+1 FLRW trace on admitted UV owner; variable A(s(t)) requires separately owned coordinate and full coefficient stress counted once. | 2 |
| BH-IIIF-C-0134 | 7694–7719 | Complete particle Schur vertex and exact energy-bookkeeping port | VERIFIED | Source-conditioned Hessian with invertible eliminated particle block and same-action vertices; physical occupations/energy transfer not executed. | 3 |
| BH-IIIF-C-0135 | 7739–7765 | First-order cap parent with canonical boundary | VERIFIED-CONDITIONAL | Conditional cap parent + smooth non-null Dirichlet boundary with h and Phi fixed; no extra auxiliary dependence in rest action. | 1 |
| BH-IIIF-C-0136 | 7790–7806 | Complete curvature momentum and metric equation | VERIFIED | Retained cap f_c=PR+R²B(R)-sigma²/B(R)²; source-derivative contacts included in metric/boundary momentum. | 2 |
| BH-IIIF-C-0137 | 7819–7835 | Regular Legendre chart of the retained cap | REPRODUCED | Cap Legendre chart with 2B_U>d and Phi>0; regular scalaron coordinate but not universal pole stability. | 2 |
| BH-IIIF-C-0138 | 7860–7898 | Unique positive cap vacuum and scalaron-sign certificate | REPRODUCED | Conditional capped action, e in (0,1), BU>2, pe>8, p>1, BI<=p; one positive source-free constant-curvature root and scalaron sign. | 4 |
| BH-IIIF-C-0139 | 7965–8033 | Fixed finite collar and complete scalar error | REPRODUCED | Fixed finite DN collar width lambda, fixed reference frequency and identical geometry; action-value error only, not solution-error or field integration. | 15 |
| BH-IIIF-C-0140 | 8072–8087 | An integrated collar has a different determinant | VERIFIED | An actual independent Gaussian collar field with fixed L2 measure and DN eigenmodes; determinant correction only if integrated. | 4 |
| BH-IIIF-C-0141 | 8135–8186 | Separated-scale bare same-action reconstruction | VERIFIED | Generated undressed two-root coefficient first response, connected R>0 and complete terminal fbar(C)=0; distinct from physical dressed action. | 5 |
| BH-IIIF-C-0142 | 8208–8259 | Affine Hessian family and exact constructor defect | VERIFIED | All bare coefficients with same curvature Hessian and terminal value; constructor detects nonparallel constant affine mode, sharp comparison remains distinct. | 4 |
| BH-IIIF-C-0143 | 8275–8287 | Vacuum shifts, Hessian blindness and coefficient-family detection | INCONSISTENT | Two separable assertions: curvature-Hessian blindness is valid; full off-shell metric symplectic-current blindness to aR is false. | 3 |
| BH-IIIF-C-0144 | 8299–8318 | Constructor discharge of the bare affine selector | VERIFIED-CONDITIONAL | Certified bare first-response constructor and terminal fbar(C)=0; no physical junction width or trajectory constructed. | 3 |
| BH-IIIF-C-0145 | 8358–8377 | Generated curvature readout versus dynamical response | FORMALIZED | Dependent exceptional-curvature metric readout Y_6u and complete action-conditioned susceptibility; no new particle/action. | 0 |
| BH-IIIF-C-0146 | 8379–8403 | Same-action retarded exceptional-curvature susceptibility | VERIFIED-CONDITIONAL | Ward/constraint-reduced physical retarded Schur inverses and complete source-conditioned common action; no new independent exceptional gravity action. | 1 |
| BH-IIIF-C-0147 | 8415–8435 | The exact heat Hessian is fixed before local curvature expansion | VERIFIED | Unlocalized compact Euclidean joint Dirac heat trace with differentiable trace-class operator family; exact Duhamel second variation. | 1 |
| BH-IIIF-C-0148 | 8446–8486 | Local Dirac metric coefficients and the non-scalar test | REPRODUCED | Ordinary torsion-free pure Dirac metric a4/a6 specialization, modulo divergences, with unknown common-heat coefficient zeta6; no additive physical action. | 2 |
| BH-IIIF-C-0149 | 8501–8527 | Terminal scalar jets obstruct a naive additive six-derivative completion | VERIFIED | Counterfactual diagnostic only: independently appended nonzero ordinary Dirac a6 to exact terminal normalized f(R) with no cancellation. | 2 |
| BH-IIIF-C-0150 | 8536–8575 | Scalaron port-matching criterion for a generalized curvature response | VERIFIED-CONDITIONAL | Nondegenerate scalaron coordinate fRR(R0)≠0, causal physical retarded Hww inverse, Ward/constraint reduction, source matched. | 1 |
| BH-IIIF-C-0151 | 8586–8607 | Exact scalar-action matching is required before combining sectors | REPRODUCED | Exact identity of proposed residual + inherited scalar action on same physical units and boundary; no double counting. | 0 |
| BH-IIIF-C-0152 | 8636–8662 | Raw Laurent secant is not the terminal metric Euler response | REPRODUCED | Fixed-depth active dressed action, C7<R≤C2, fRR(C7)=0; raw secant remains readout, not physical Euler port. | 0 |
| BH-IIIF-C-0153 | 8671–8699 | Stationary positive-block no-free-curvature-force test | VERIFIED | Stationary real Hilbert patch, self-adjoint strictly positive invertible Cw, no claim on indefinite Lorentzian retarded block. | 2 |
| BH-IIIF-C-0154 | 8710–8734 | Protected scalar and joint Dirac heat owners have unequal curvature jets | VERIFIED-CONDITIONAL | Ordinary minimal scalar and four-spin Dirac heat are different operators; additive scalar a4 shift is counterfactual comparison only. | 1 |
| BH-IIIF-C-0155 | 8736–8752 | Analytic fixed-rank heat trace cannot itself generate the K16 kink | VERIFIED | Analytic fixed-rank compact-domain trace-class heat family crossing C2 transversely, f C2-not-C3; excludes direct unprojected analytic equality. | 2 |
| BH-IIIF-C-0156 | 8791–8814 | Zero photon--geometric mixed Hessian on a neutral branch | VERIFIED | Neutral homogeneous isotropic A=0, no background EM current, and no term linear in photon perturbation for any nearby z. | 2 |
| BH-IIIF-C-0157 | 8847–8862 | On-shell conformal trace of the native local odd-field action | VERIFIED-CONDITIONAL | Native local scalar and metric Euler on-shell with four-dimensional metric-independent internal YM pairing; complete spectral action excluded. | 1 |
| BH-IIIF-C-0158 | 8885–8907 | Hyperbolic odd-field mass Gram and stabilizer | VERIFIED | Trace-orthonormal real odd linear support with F>0; N>=2 for hyperbolic sectional curvature, gauge mass Gram normalized separately by Qrho. | 3 |
| BH-IIIF-C-0159 | 8920–8941 | Conditional Dirichlet scalar--tensor boundary coefficient | VERIFIED | Smooth non-null Dirichlet boundary with h, Phi fixed; local scalar-tensor FR term only, no spectral mixed/null/corner boundary matching. | 1 |
| BH-IIIF-C-0160 | 8953–8986 | Complete localizer-aware mixed heat Hessian | VERIFIED | Full differentiable localizer and common Euclidean Dirac/coframe jets, entire noncommuting matrix second variation; packet weighted once. | 2 |
| BH-IIIF-C-0161 | 8995–9021 | Off-shell gauge Ward correction and protected signed low-mode bound | VERIFIED-CONDITIONAL | Gauge-invariant off-shell action with full Euler term; separately compact protected spatial Dirac gap and norm-small complement perturbation. | 4 |

## Source proof environments reviewed

- **6602–6608**: follows BH-IIIF-C-0112; exact text frozen and material references typed in JSON.

- **6631–6636**: follows BH-IIIF-C-0113; exact text frozen and material references typed in JSON.

- **6665–6671**: follows BH-IIIF-C-0114; exact text frozen and material references typed in JSON.

- **6730–6739**: follows BH-IIIF-C-0115; exact text frozen and material references typed in JSON.

- **6759–6764**: follows BH-IIIF-C-0116; exact text frozen and material references typed in JSON.

- **6804–6811**: follows BH-IIIF-C-0118; exact text frozen and material references typed in JSON.

- **6879–6896**: follows BH-IIIF-C-0120; exact text frozen and material references typed in JSON.

- **6956–6992**: follows BH-IIIF-C-0121; exact text frozen and material references typed in JSON.

- **7088–7103**: follows BH-IIIF-C-0122; exact text frozen and material references typed in JSON.

- **7227–7241**: follows BH-IIIF-C-0125; exact text frozen and material references typed in JSON.

- **7279–7288**: follows BH-IIIF-C-0126; exact text frozen and material references typed in JSON.

- **7313–7321**: follows BH-IIIF-C-0127; exact text frozen and material references typed in JSON.

- **7367–7377**: follows BH-IIIF-C-0128; exact text frozen and material references typed in JSON.

- **7446–7457**: follows BH-IIIF-C-0129; exact text frozen and material references typed in JSON.

- **7580–7591**: follows BH-IIIF-C-0130; exact text frozen and material references typed in JSON.

- **7615–7622**: follows BH-IIIF-C-0131; exact text frozen and material references typed in JSON.

- **7651–7658**: follows BH-IIIF-C-0132; exact text frozen and material references typed in JSON.

- **7686–7693**: follows BH-IIIF-C-0133; exact text frozen and material references typed in JSON.

- **7766–7780**: follows BH-IIIF-C-0135; exact text frozen and material references typed in JSON.

- **7807–7813**: follows BH-IIIF-C-0136; exact text frozen and material references typed in JSON.

- **7836–7852**: follows BH-IIIF-C-0137; exact text frozen and material references typed in JSON.

- **7899–7962**: follows BH-IIIF-C-0138; exact text frozen and material references typed in JSON.

- **8034–8059**: follows BH-IIIF-C-0139; exact text frozen and material references typed in JSON.

- **8088–8094**: follows BH-IIIF-C-0140; exact text frozen and material references typed in JSON.

- **8187–8206**: follows BH-IIIF-C-0141; exact text frozen and material references typed in JSON.

- **8260–8273**: follows BH-IIIF-C-0142; exact text frozen and material references typed in JSON.

- **8288–8297**: follows BH-IIIF-C-0143; exact text frozen and material references typed in JSON.

- **8404–8413**: follows BH-IIIF-C-0146; exact text frozen and material references typed in JSON.

- **8436–8444**: follows BH-IIIF-C-0147; exact text frozen and material references typed in JSON.

- **8487–8499**: follows BH-IIIF-C-0148; exact text frozen and material references typed in JSON.

- **8528–8534**: follows BH-IIIF-C-0149; exact text frozen and material references typed in JSON.

- **8576–8584**: follows BH-IIIF-C-0150; exact text frozen and material references typed in JSON.

- **8608–8615**: follows BH-IIIF-C-0151; exact text frozen and material references typed in JSON.

- **8663–8669**: follows BH-IIIF-C-0152; exact text frozen and material references typed in JSON.

- **8700–8708**: follows BH-IIIF-C-0153; exact text frozen and material references typed in JSON.

- **8753–8761**: follows BH-IIIF-C-0155; exact text frozen and material references typed in JSON.

- **8815–8822**: follows BH-IIIF-C-0156; exact text frozen and material references typed in JSON.

- **8863–8883**: follows BH-IIIF-C-0157; exact text frozen and material references typed in JSON.

- **8908–8918**: follows BH-IIIF-C-0158; exact text frozen and material references typed in JSON.

- **8942–8951**: follows BH-IIIF-C-0159; exact text frozen and material references typed in JSON.

- **8987–8993**: follows BH-IIIF-C-0160; exact text frozen and material references typed in JSON.

- **9022–9029**: follows BH-IIIF-C-0161; exact text frozen and material references typed in JSON.

## Formal remarks reviewed

- **6672–6683 · No free source-selection theorem from a common kinetic trace** — source scope/exclusions reviewed; no extra theorem/physics inferred.

- **6994–7034 · Common-action/CRP4 dependency firewall** — source scope/exclusions reviewed; no extra theorem/physics inferred.

- **7157–7165 · QROOT is not a repeated mode-admission vacuum rule** — source scope/exclusions reviewed; no extra theorem/physics inferred.

- **7243–7250 · Weak metric-response branch** — source scope/exclusions reviewed; no extra theorem/physics inferred.

- **7459–7489 · Executed native infrared evaluation; numerical scope** — source scope/exclusions reviewed; no extra theorem/physics inferred.

- **7491–7548 · Finite-band inflation test of the same candidate** — source scope/exclusions reviewed; no extra theorem/physics inferred.

- **7720–7728 · UV/IR action typing** — source scope/exclusions reviewed; no extra theorem/physics inferred.

- **8617–8628 · Result and exact remaining action obligation** — source scope/exclusions reviewed; no extra theorem/physics inferred.

- **8764–8775 · Zero crossings do not evade the analytic heat obstruction** — source scope/exclusions reviewed; no extra theorem/physics inferred.

- **8777–8784 · Physical closure still requires the complete action owner** — source scope/exclusions reviewed; no extra theorem/physics inferred.

- **8823–8834 · Scope and unresolved direct-heat contribution** — source scope/exclusions reviewed; no extra theorem/physics inferred.

- **9032–9045 · An evaluated signed cubic curve** — source scope/exclusions reviewed; no extra theorem/physics inferred.

- **9048–9065 · Route-2 scope and causal source completion** — source scope/exclusions reviewed; no extra theorem/physics inferred.

## Unnamed consumed mathematical/physical claims

- **B4-U01 / 6570–6683:** Bilinear odd coefficient cannot be inferred from bosonic restriction, and physical two-frame chiral leg assignments are not generated automatically. — E1/E3 direct coefficient and isometric frame controls.

- **B4-U02 / 6687–6811:** Stationary zero-locus constructor does not select nonempty world solution; local EH action role is separately derived in v1.75 interior. — E1 imported exact-solution moduli theorem; action/role domain checked.

- **B4-U03 / 6813–6896:** Certified action/contact connection plus distinct local-excess condition is required before declaring actual CRP4 coefficient response. — E1 source/peer certificate + two-base derivative role check.

- **B4-U04 / 6900–7034:** Coefficient-family horizontal R section defines first-response Euler operator, not a reverse inference from already imported f(R) action. — E3 symbolic line connection; E4 circularity firewall checked.

- **B4-U05 / 7036–7103:** Joint Einstein raw Newton coordinate is not automatically observed Newton; higher curvature and REN conditions remain alternatives. — E1 source + E3 Newton coupling coefficient.

- **B4-U06 / 7106–7165:** QROOT is an additional quantum excitation-source bridge distinct from absolute vacuum REN and mode re-admission. — E1 definition/remark only; later source theorem may discharge QROOT.

- **B4-U07 / 7170–7329:** Local metric f(R) first variation, TERM REN redundancy and action Legendre potential retain compact support and fprime regularity. — E3 independent variational sign and coupling algebra.

- **B4-U08 / 7334–7591:** Bare potential Born symmetry and fixed-Q candidate late vacuum/slow-roll only for separate scoped coefficient graphs. — E3 symbolic+175-digit candidate values; inflation N integrals not independently executed.

- **B4-U09 / 7601–7728:** Carrier-four positive response, conditional signed UV scalaron and homogeneous variable-coefficient trace are different parent reductions. — E3 UV Taylor, trace source-work and Schur vertex.

- **B4-U10 / 7739–7857:** Retained cap auxiliary elimination, full source derivative momentum, Legendre and scalar boundary are conditional same-action maps. — E3 auxiliary completion, total derivative and scalaron chamber controls.

- **B4-U11 / 7860–7963:** Cap positive source-free vacuum monotonicity and scalaron signs rely on explicit positivity parameter chamber. — E1 global proof; E3 exact rational identities and admissible root numerical attack.

- **B4-U12 / 7965–8105:** Fixed finite collar yields controlled action-value errors, while actually integrated Gaussian field adds a distinct fluctuation determinant. — E1 collar estimates; E3 finite DN determinant product, E4 boundary/measure separation.

- **B4-U13 / 8135–8353:** Constructor connection kills bare affine constant defect while equal curvature Hessian alone cannot; metric off-shell symplectic claim overreaches. — E3 coefficient connection, E4 exact symplectic counterexample issue G0002.

- **B4-U14 / 8358–8615:** Complete heat/curvature Schur susceptibility and local a4/a6 coefficients are not separate unconstrained physical scalaron actions. — E3 noncommuting trace Hessian, curvature invariant and cubic terminal tests.

- **B4-U15 / 8636–8784:** Terminal raw Laurent secant differs from Euler port; analytic fixed-rank heat cannot itself acquire third derivative jump. — E1 exact endpoint/analyticity proof, E3 finite analytic heat, E4 kink mutation.

- **B4-U16 / 8791–8834:** Neutral mixed photon-geometric Hessian vanishes, but direct heat photon Hessian still requires independent full action evaluation. — E3 neutral mixed polynomial, E4 charged countercontrol.

- **B4-U17 / 8847–8951:** On-shell local odd trace, hyperbolic real mass Gram and Dirichlet boundary do not certify complete global spectral boundary action. — E3 on-shell cancellation, hyperbolic sectional curvature and GHY source coefficient.

- **B4-U18 / 8953–9065:** Localizer-aware mixed Duhamel, offshell Ward and gapped signed Dirac Schur remain finite/local and exclude continuum quantum inference. — E3 noncommuting full localizer Hessian, SO2 Ward and 3x3 signed Schur checks.

## First-appearance specialized condition registry

Each ID is a source-scoped typed condition/conjunction, **not a new GP principle**. Existing premises (`REN0`, `SOLHIST`, joint heat, localizer, ADM and clock fermion) are inherited by references, not reintroduced.

- **BH-IIIF-A-0050 / line 6574 (DOMAIN):** Complete local finite bosonic+ordered quadratic odd action A+cF barpsi D(q) psi, cF>0.

- **BH-IIIF-A-0051 / line 6613 (PHYSICAL-IDENTIFICATION):** Actual chiral D_LR coefficient has independently generated charge-source incidence and required charged Cert_hier certificate.

- **BH-IIIF-A-0052 / line 6642 (SELECTION):** Two isometric port frames with j0*j1=sqrt(24/25)I and explicitly specified left/right assignment within same action.

- **BH-IIIF-A-0053 / line 6693 (DOMAIN):** Complete local ACTcl action; exact finite target, equalizer, GP2 quotient and declared stationary family sort, without chosen member.

- **BH-IIIF-A-0054 / line 6815 (PHYSICAL-IDENTIFICATION):** Actual scalar-action coefficient satisfies Paper3B action/contact normalized root and zero defect; physical chi7 additionally passes Paper3D fixed-depth excess.

- **BH-IIIF-A-0055 / line 6899 (DOMAIN):** Fixed scheme sigma and connected positive R range of horizontal L_U determinant-dual coefficient line on certified contact action.

- **BH-IIIF-A-0056 / line 7172 (REGULARITY):** g C2 nondegenerate Lorentz, compactly supported inverse metric variations, f C1 in neighborhood and phi=fprime(R) C2 there; admitted action continuation.

- **BH-IIIF-A-0057 / line 7131 (PHYSICAL-IDENTIFICATION):** On an occurring complete-cap fresh root rho0=p0=0, renormalized quantum excitation Hilbert stress has zero expectation.

- **BH-IIIF-A-0058 / line 7336 (DOMAIN):** Generated undressed bare coefficient first-response constructor and retained fbar(C)=0 on positive separated roots 0<C<U.

- **BH-IIIF-A-0059 / line 7392 (NORMALIZATION):** Composed candidate fQ with fixed Q=8 sqrt(alpha), visibility y and finite Psi orbit, physical incidence not independently selected.

- **BH-IIIF-A-0060 / line 7555 (PHYSICAL-IDENTIFICATION):** On fixed visibility parent R_tau=C exp(H exp(-tau)), admit active curvature equal to hierarchy readout; tau is not physical time.

- **BH-IIIF-A-0061 / line 7625 (PHYSICAL-IDENTIFICATION):** Additional same-parent signed two-sided UV quadratic scalaron action through R_J=0 with coefficient Q/U, distinct from IR chart.

- **BH-IIIF-A-0062 / line 7672 (DOMAIN):** Separately owned homogeneous s(t) coefficient A(s)>0 in UV action, with its metric variation in the same total stress source.

- **BH-IIIF-A-0063 / line 7748 (BOUNDARY):** Exact conditional cap first-order auxiliary owner, smooth non-null Dirichlet boundary with h and Phi fixed, rest independent of auxiliaries.

- **BH-IIIF-A-0064 / line 7821 (REGULARITY):** On cap coefficient anchors 2B_U>d=1-B_U/B_I, positive regular Hessian and Phi branch.

- **BH-IIIF-A-0065 / line 7865 (DOMAIN):** Cap e in (0,1), B_U>2, p e>8, p>1 and B_I<=p for one positive vacuum root.

- **BH-IIIF-A-0066 / line 7967 (BOUNDARY):** Finite Dirichlet-Neumann fixed reference width lambda>0 and fixed metric geometry with matching B_lambda used in both source and gravity.

- **BH-IIIF-A-0067 / line 8074 (PHYSICAL-IDENTIFICATION):** Collar extension is integrated as independent Gaussian field with fixed L2 measure and claimed multiplicity m_c.

- **BH-IIIF-A-0068 / line 8380 (REGULARITY):** Complete same-action quotient physical retarded inverse for eliminated source block and reduced retained metric/scalar response.

- **BH-IIIF-A-0069 / line 8417 (REGULARITY):** Compact Euclidean joint Dirac heat e^-A is trace class with differentiable A and mixed jets, unlocalized for trace-cyclic second variation.

- **BH-IIIF-A-0070 / line 8448 (DOMAIN):** Pure ordinary torsion-free Dirac metric a4/a6 heat on conformally flat restricted metric test; full zeta6 common-heat normalization uncalculated.

- **BH-IIIF-A-0071 / line 8538 (REGULARITY):** Constrained causal physical scalaron chart has fRR(R0)!=0 and a retarded invertible remaining block with compatible source normalization.

- **BH-IIIF-A-0072 / line 8673 (DOMAIN):** Stationary real Ward/constraint quotient has strictly positive self-adjoint boundedly invertible eliminated Cw block.

- **BH-IIIF-A-0073 / line 8738 (REGULARITY):** Operator D(s)^2 analytic on compact fixed-domain uniformly analytic trace-class heat patch, with transverse analytic R(s) crossing C2.

- **BH-IIIF-A-0074 / line 8793 (DOMAIN):** On regular homogeneous isotropic A=0 background, external EM current zero and local common action has no linear photon term for nearby z.

- **BH-IIIF-A-0075 / line 8847 (DOMAIN):** Source-free four-dimensional native local odd-scalar and metric Euler on shell with metric-independent internal Yang-Mills pairing.

- **BH-IIIF-A-0076 / line 8887 (DOMAIN):** Trace-orthonormal gauge-stable real odd support of dimension N with F=kJ-r²/12>0; N>=2 for sectional curvature statement.

- **BH-IIIF-A-0077 / line 8922 (BOUNDARY):** Additionally constituted smooth non-null boundary with fixed induced metric and odd scalar for local nonminimal F(Ph)R term.

- **BH-IIIF-A-0078 / line 8955 (REGULARITY):** Actual localized heat owner L=phi_U and D have all first/mixed second metric/source/coframe jets, with trace-class Duhamel legitimacy.

- **BH-IIIF-A-0079 / line 9004 (REGULARITY):** Compact selfadjoint midpoint weak Dirac has protected projector P, complement gap g and ||QVQ||+|z|<g.

## Adversarial challenge dispositions

- **BH-IIIF-ATTACK-B4-0001: p3f:prop:vacuum-shift-symplectic-scope** — Does aR leave the full off-shell metric covariant presymplectic current invariant? **Adjudication:** VALID SOURCE-MATCHED COUNTEREXAMPLE: source claims symplectic equality cannot distinguish affine slope, which is false.

- **BH-IIIF-ATTACK-B4-0002: p3f:thm:v288-cap-vacuum-root-stability** — Choose valid cap parameters and attempt to find a second positive trace root or wrong scalaron sign. **Adjudication:** REJECTED AS REFUTATION: source global monotonic proof passes E1 and admissible sample agrees; sampling alone not global E3.

- **BH-IIIF-ATTACK-B4-0003: p3f:prop:v118-localizer-aware-hessian** — Drop varying analytic localizer L and contact terms in mixed heat Hessian. **Adjudication:** REJECTED AS REFUTATION: source includes all localizer derivatives, so attack verifies firewall.

- **BH-IIIF-ATTACK-B4-0004: p3f:prop:v1166-neutral-photon-mixing** — Introduce linear j(z)A term on alleged neutral branch. **Adjudication:** OUT OF PRINTED DOMAIN: does not refute neutral mixed Hessian result.

- **BH-IIIF-ATTACK-B4-0005: p3f:prop:v1165-analytic-k16-obstruction** — Generate C2-not-C3 curvature kink directly from analytic finite-rank heat under a zero eigenvalue crossing. **Adjudication:** REJECTED AS REFUTATION: cannot achieve kink while satisfying analytic unprojected trace premises.

- **BH-IIIF-ATTACK-B4-0006: p3f:thm:v2219-coherent-uv-scalaron** — Use one-sided terminal IR Legendre chart to force negative-curvature turning point at C7. **Adjudication:** OUT OF PRINTED DOMAIN: would conflate UV action with distinct IR reduction.

- **BH-IIIF-ATTACK-B4-0007: p3f:thm:general-local-fR-variation** — Demand global C4 f C3 even for compactly supported variations with f C1 and fprime(R) C2. **Adjudication:** REJECTED AS REFUTATION: source uses exact local regularity and variation support.

- **BH-IIIF-ATTACK-B4-0008: p3f:prop:v2219-closed-uv-trace** — Drop dot A and ddot A terms when homogeneous coefficient A varies. **Adjudication:** REJECTED AS REFUTATION: source contains the complete coefficient derivative.

## Material DAG proof-use edges / issue attribution

35 source-matched theorem-use edges (from exact proof spans) plus one `ISSUE_AT` edge. Reference resolution: 100 / 100 unique; equation citations never used as proof-traversal edges. All 50 source claims carry route IDs with per-route specialized condition use edges. No unreviewed cross-paper claim is labeled audited.

## Batch completion and release boundary

**Cumulative through Batch 4:** 161/442 formal claims, 116/364 proofs, 32/66 remarks. **Next:** Batch 5, lines 9,071–11,272.

**No archive export this batch.** Final batch only: validate source-aligned globally integrated DAG ZIP and proof-chain audits ZIP, each with only latest suitable versions, preserve original source archives unchanged. The current files are a staging audit, not yet a globally integrated successor atlas.
