# Paper III-F — Rigorous Verification DAG Audit, Batch 7 (v1_1)

- **Authoritative source:** `Paper3F-CompleteDynamics-v1_256.tex`
- **Protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md`
- **Current framework:** `Paper00-PapersMinimal-v2_370`
- **Coverage:** lines **14,515–17,237**, 54/54 formal results, 51/51 proof environments, 4/4 remarks, 19 reviewed unnamed material clusters.
- **Frozen source SHA-256:** `47d43b2d08b2245ade810eae64a9e1cc827398f60899af0afed7cb2398358a77`
- **Independent evidence:** 43 E3 and 7 E4 controls, all passing after explicit correction of two test-harness convention errors.
- **New in-domain issues:** none confirmed. **Previously open:** BH-IIIF-G-0001, BH-IIIF-G-0002, BH-IIIF-G-0003, BH-IIIF-G-0004, BH-IIIF-G-0005.
- **Disposition:** 37 verified in mathematical scope; 16 verified conditionally; 1 source-reproduced pending independent imported provider certification.

## Key independently checked proof chains

1. **Finite pole/source transport (C-0280–0282).** Noncommuting Hermitian Schur-pole residues agree with the direct spectral projection; effective source overlap, positive-complement population bounds, and elimination-order independence are certified. No interacting continuum pole is inferred.
2. **Moving and higher Schur jets (C-0283–0287, C-0291–0297).** First/second and cubic/quartic stationary derivatives, moving critical eigenvalue, exact all-order residual, Ward-null descent, and rank-change memory are checked with finite matrix and symbolic tests. Source/trace realization and critical exponent remain separate conditions.
3. **Generated depth-two Laurent coefficient (C-0288–0290).** Positive one-dimensional coefficient character and conditional Hessian integration/junction arithmetic are checked; the upstream actual local-excess and action-port certificates are not globally re-proved.
4. **Complete work, heat and Hopf geometry (C-0298–0314).** Hilbert work sign, moving pairing/port product rules, C3 localizer EHH combinatorics, anchored f(R) subtraction, Hopf Euler–connection split, conformal scalar square, source CTP mean and frozen Dirac response pass targeted controls.
5. **Terminal sources and cold readout (C-0315–0319).** Terminal budget, finite CAR integrable cold tail with central allocation, history commutator derivative, and frozen energy-noise cumulants are mathematically checked. Actual cold source state/history and abundance remain unselected.
6. **Full FLRW two-port, loaded energy and forcing (C-0320–0328).** Independent lapse and scale Euler variations match the printed equations; same-source response stress, noncommuting metric Schur jet, static loaded Routh energy, advected temporal stress and pulse/monotone work identities pass.
7. **Imported geometry and Cartan gauge (C-0329–0333).** I-B source statements and scope match the singular continuation and provider claims. Exact Cartan gauge energy/exchange and protected coexact equation pass numerical differentiation; full independent spin-provider recertification remains outstanding.

## Existing issue carry-forward

- **BH-IIIF-G-0001 (Moderate):** First-class ADM constraint-algebra bracket calculation not supplied here; a diffeomorphism/Noether work identity is not a substitute.
- **BH-IIIF-G-0002 (Moderate):** Incorrect earlier off-shell symplectic-current insensitivity to affine `aR` not corrected by this metric-work region.
- **BH-IIIF-G-0003 (Minor):** Earlier unqualified `U=(3/pi)K_p` still needs the local `CELL` guard. The present qualified use does not repair earlier source wording.
- **BH-IIIF-G-0004 (Moderate):** Absolute gauge coefficient still needs optional fibre-cutoff saturation; the Cartan restricted action does not establish it.
- **BH-IIIF-G-0005 (Moderate):** Earlier rectangular full-rank Feshbach lower singular-value bound remains refuted; the positive Hamiltonian pivot in this batch is a different, correctly guarded theorem.

## Complete result disposition

| Claim ID | Source lines | Printed result | Disposition | E3/E4 controls |
|---|---:|---|---|---:|
| BH-IIIF-C-0280 | 14524–14569 | Finite isolated pole and residue under exact Schur elimination | VERIFIED | 2 |
| BH-IIIF-C-0281 | 14592–14610 | Same-sector lowering and source weight on a positive Hamiltonian pivot | VERIFIED-CONDITIONAL | 1 |
| BH-IIIF-C-0282 | 14625–14630 | Grouping-independent finite pole and source transport | VERIFIED | 2 |
| BH-IIIF-C-0283 | 14663–14681 | Exact first and second boundary Schur jets | VERIFIED | 2 |
| BH-IIIF-C-0284 | 14694–14704 | Moving simple critical eigenvalue | VERIFIED | 2 |
| BH-IIIF-C-0285 | 14752–14769 | Exact cubic and quartic boundary reduction | VERIFIED | 1 |
| BH-IIIF-C-0286 | 14779–14796 | Source derivatives at a critical full Hessian | VERIFIED | 2 |
| BH-IIIF-C-0287 | 14807–14831 | Exact all-order same-action Schur residual | VERIFIED | 1 |
| BH-IIIF-C-0288 | 14857–14892 | Generated positive coefficient character and Laurent pullback | VERIFIED | 1 |
| BH-IIIF-C-0289 | 14910–14966 | Historical depth-two fixed-depth local-jet Born--Legendre comparison | VERIFIED-CONDITIONAL | 1 |
| BH-IIIF-C-0290 | 14990–15011 | Discharge of the Laurent--Legendre structural G24 subfrontier | VERIFIED-CONDITIONAL | 1 |
| BH-IIIF-C-0291 | 15018–15051 | Source-conditioned boundary Schur descendant | VERIFIED | 1 |
| BH-IIIF-C-0292 | 15070–15082 | Regular dual boundary response is a restriction | VERIFIED | 1 |
| BH-IIIF-C-0293 | 15097–15114 | Boundary third variation is the K16 response analogue | VERIFIED-CONDITIONAL | 1 |
| BH-IIIF-C-0294 | 15116–15154 | Explicit first source jet of the stationary Schur descendant | VERIFIED | 2 |
| BH-IIIF-C-0295 | 15190–15210 | Ward descent through the same-action Schur reduction | VERIFIED | 2 |
| BH-IIIF-C-0296 | 15232–15272 | Eliminate-before-quotient rule for a rank-changing terminal mode | VERIFIED | 1 |
| BH-IIIF-C-0297 | 15291–15308 | Terminal scalaron load is not yet a boundary stress | VERIFIED-CONDITIONAL | 1 |
| BH-IIIF-C-0298 | 15340–15355 | Work conservation with retained source marks | VERIFIED | 2 |
| BH-IIIF-C-0299 | 15422–15440 | Symmetry-preserving work and the first broken jet | VERIFIED | 1 |
| BH-IIIF-C-0300 | 15454–15480 | Complete stationary boundary work | VERIFIED | 1 |
| BH-IIIF-C-0301 | 15551–15578 | Two cosmological work ports and formation | VERIFIED-CONDITIONAL | 1 |
| BH-IIIF-C-0302 | 15598–15611 | Finite physical pressure exclusions | VERIFIED | 2 |
| BH-IIIF-C-0303 | 15658–15692 | Complete Euler-marked heat third jet | VERIFIED | 2 |
| BH-IIIF-C-0304 | 15729–15750 | Terminal anchored work identity | VERIFIED | 1 |
| BH-IIIF-C-0305 | 15769–15791 | Source-normalized geometric remainder and canonical work | VERIFIED-CONDITIONAL | 2 |
| BH-IIIF-C-0306 | 15828–15858 | Inherited Hopf--Euler action incidence | VERIFIED-CONDITIONAL | 1 |
| BH-IIIF-C-0307 | 15880–15902 | Allocated scalar insertion and anisotropic work | VERIFIED | 1 |
| BH-IIIF-C-0308 | 15931–15949 | The complete nonminimal conformal constituent | VERIFIED | 1 |
| BH-IIIF-C-0309 | 15984–16020 | Active density as a matched boundary square | VERIFIED-CONDITIONAL | 1 |
| BH-IIIF-C-0310 | 16047–16059 | Isolated classical native scalar cannot be a positive cold source | VERIFIED-CONDITIONAL | 2 |
| BH-IIIF-C-0311 | 16086–16097 | Stationary reduction preserves the parent mean | VERIFIED | 1 |
| BH-IIIF-C-0312 | 16126–16149 | The complete two-history source gives both mean ports | VERIFIED | 1 |
| BH-IIIF-C-0313 | 16170–16183 | Homogeneous collisionless driven memory cancels | VERIFIED | 1 |
| BH-IIIF-C-0314 | 16193–16228 | Exact frozen free-sign-pair response with its contact | VERIFIED | 1 |
| BH-IIIF-C-0315 | 16247–16258 | No second mean on the completed minimal domain | VERIFIED-CONDITIONAL | 0 |
| BH-IIIF-C-0316 | 16278–16306 | Terminal residual boundary budget | VERIFIED | 1 |
| BH-IIIF-C-0317 | 16343–16370 | Cold survival on the complete finite local source | VERIFIED-CONDITIONAL | 1 |
| BH-IIIF-C-0318 | 16392–16410 | The late energy is an actual history output | VERIFIED | 1 |
| BH-IIIF-C-0319 | 16433–16450 | Frozen late mean and energy noise are different jets | VERIFIED | 1 |
| BH-IIIF-C-0320 | 16502–16532 | Lapse and spatial work of the completed matched action | VERIFIED-CONDITIONAL | 1 |
| BH-IIIF-C-0321 | 16548–16587 | Fixed-Einstein-coefficient response stress | VERIFIED-CONDITIONAL | 2 |
| BH-IIIF-C-0322 | 16624–16660 | Complete mixed heat derivative | VERIFIED | 2 |
| BH-IIIF-C-0323 | 16670–16686 | Metric derivative of the actual Schur block | VERIFIED | 2 |
| BH-IIIF-C-0324 | 16694–16732 | Stored energy, source work and net induced energy | VERIFIED | 2 |
| BH-IIIF-C-0325 | 16743–16758 | No positive excess from passive global relaxation | VERIFIED | 2 |
| BH-IIIF-C-0326 | 16800–16830 | Temporal stress is not identifiable from stationary response alone | VERIFIED | 1 |
| BH-IIIF-C-0327 | 16851–16896 | Quadratic response energy, pressure and complete work | VERIFIED | 1 |
| BH-IIIF-C-0328 | 16911–16928 | Monotone frozen loading cannot give a positive completed increment | VERIFIED | 2 |
| BH-IIIF-C-0329 | 16980–17011 | Exact bundle and operator comparisons | REPRODUCED | 0 |
| BH-IIIF-C-0330 | 17033–17061 | Same-action boundary relation at a singular interior block | VERIFIED-CONDITIONAL | 1 |
| BH-IIIF-C-0331 | 17070–17094 | Crossing tests for the same response | VERIFIED-CONDITIONAL | 1 |
| BH-IIIF-C-0332 | 17142–17181 | Exact homogeneous restriction and its energy exchange | VERIFIED | 2 |
| BH-IIIF-C-0333 | 17197–17219 | The represented lowest coexact equation | VERIFIED | 2 |

## Proof-route scope, certification and outstanding import limits

Each disposition is for the exact SOURCE-AS-PRINTED mathematical proposition in the source-domain guard in the JSON ledger. `VERIFIED` is **not** a proof that a physical action/source/spectral carrier actually occurs; `VERIFIED-CONDITIONAL` explicitly preserves its occurrence/normalization conditions; `REPRODUCED` indicates that the identified imported provider comparison was source-matched but not independently recertified.

- **Explicit references resolved uniquely:** 123 across the current `.tex` corpus.
- **Positive material proof-use edges recorded:** 39; **nonpromoting candidates:** 8; **proof citation-only:** 19; **statement references:** 22.
- **New specialized source-scoped conditions:** 20 (canonical BH-IIIF-A-0132..0151); **inherited condition-use edges:** 44. None is a new G0/GP1–GP3 axiom.
- **No route promoted merely from a citation:** all material edges preserve exact use locator and guarded proof-route ID. External source spans are inspected only for the imported interface, not as newly audited whole papers.
- **No new mathematical issue confirmed:** all seven adversarial controls were adjudicated; failed/stronger hypotheses outside the printed domain are explicitly negative controls.

## Independent test certificates

| Evidence | Claim coverage | Worst error / tolerance | Status |
|---|---|---:|---|
| E3-pole-residue-source | 0280 | 6.04e-16 / 1e-09 | PASS |
| E3-positive-gap-population | 0281 | 0 / 1e-12 | PASS |
| E3-schur-order-composition | 0282 | 8.95e-16 / 1e-09 | PASS |
| E3-exact-second-Schur-jet | 0283,0294 | 2.41e-06 / 5e-05 | PASS |
| E3-moving-critical-eigenvalue | 0284 | 3.26e-06 / 3e-05 | PASS |
| E3-quartic-interior-inverse | 0285,0286,0293 | 0 / 1e-13 | PASS |
| E3-exact-all-order-Schur-residual | 0287 | 5.3e-16 / 1e-11 | PASS |
| E3-positive-one-parameter-character | 0288 | 0 / 1e-13 | PASS |
| E3-conditional-Laurent-integration | 0289,0290 | 1.23e-06 / 0.00012 | PASS |
| E3-Schur-boundary-and-dual | 0291,0292 | 4.44e-16 / 1e-10 | PASS |
| E3-source-velocity-Hessian-jet | 0294 | 3.83e-12 / 1e-08 | PASS |
| E3-Ward-null-Schur-descent | 0295 | 0 / 1e-13 | PASS |
| E3-terminal-Schur-order | 0296,0297 | 0 / 1e-12 | PASS |
| E3-Hilbert-Noether-work-sign | 0298 | 0 / 1e-08 | PASS |
| E3-symmetry-broken-Schur-jet | 0299 | 7.67e-11 / 1e-07 | PASS |
| E3-complete-moving-port-derivative | 0300,0323 | 4.71e-10 / 1e-07 | PASS |
| E3-causal-mean-lapse-port | 0301,0312 | 7.38e-12 / 1e-08 | PASS |
| E3-finite-cold-spectral-exclusions | 0302 | 0 / 1e-13 | PASS |
| E3-homothety-fR-work | 0298,0305 | 9.27e-07 / 3e-06 | PASS |
| E3-anchored-J-work-integral | 0304,0305 | 0 / 1e-13 | PASS |
| E3-Hopf-Euler-and-connection-split | 0306 | 1.42e-14 / 1e-11 | PASS |
| E3-anisotropic-Euler-pressure | 0307 | 1.22e-08 / 1e-07 | PASS |
| E3-native-conformal-square | 0308 | 0 / 1e-13 | PASS |
| E3-matched-boundary-square-frame | 0309 | 2.22e-16 / 1e-09 | PASS |
| E3-native-scalar-cold-obstruction | 0310 | 5.55e-17 / 1e-13 | PASS |
| E3-stationary-envelope-mean | 0311 | 3.35e-11 / 1e-09 | PASS |
| E3-homogeneous-Poisson-memory-zero | 0313 | 0 / 1e-13 | PASS |
| E3-Dirac-active-contact-retarded | 0314 | 2.28e-08 / 1e-06 | PASS |
| E3-terminal-boundary-budget | 0316 | 0 / 1e-12 | PASS |
| E3-frozen-lapse-influence-cumulants | 0319 | 2.46e-13 / 1e-10 | PASS |
| E3-closed-FLRW-two-ports | 0320,0321 | 0 / 1e-09 | PASS |
| E3-fixed-Einstein-response-ports | 0321 | 1.11e-16 / 1e-09 | PASS |
| E3-noncommuting-mixed-heat-jet-stability | 0322,0303 | 2.43e-05 / 0.0004 | PASS |
| E3-metric-Schur-jet-noncommuting | 0323 | 5.15e-09 / 1e-07 | PASS |
| E3-static-loaded-energy-and-work | 0324,0325 | 1.19e-11 / 1e-10 | PASS |
| E3-static-temporal-identifiability-pressure | 0326 | 7.72e-11 / 1e-10 | PASS |
| E3-dynamical-two-port-energy-Ward | 0327 | 2.43e-17 / 1e-13 | PASS |
| E3-monotone-loading-vs-pulse | 0328 | 2.78e-17 / 1e-11 | PASS |
| E3-singular-interior-Schur-relation | 0330,0331 | 0 / 1e-10 | PASS |
| E3-Cartan-gauge-energy-and-protected-mode | 0332,0333 | 1.67e-16 / 1e-11 | PASS |
| E3-finite-source-integrable-cold-tail | 0317 | 0 / 1e-10 | PASS |
| E3-history-energy-variation-commutator | 0318 | 8.46e-13 / 1e-09 | PASS |
| E3-Euler-heat-EHH-localizer-contacts | 0303,0322 | 0 / 1e-13 | PASS |
| E4-singular-complement-excluded | 0280,0282 | 0 / 0 | PASS |
| E4-moving-eigenvector-not-frozen | 0283,0284,0286 | 2.5e-09 / 2e-08 | PASS |
| E4-Ward-null-needs-source-identity | 0295 | 0 / 1e-14 | PASS |
| E4-static-field-not-additional-mean | 0324,0325 | 0 / 1e-14 | PASS |
| E4-definite-pressure-cold-excluded | 0302,0310 | 0 / 0 | PASS |
| E4-pulse-bypasses-monotone-sign | 0328 | 0 / 0 | PASS |
| E4-no-spontaneous-Cartan-profile | 0332,0333 | 0 / 0 | PASS |

## Unnamed material claim clusters

- **B7-U01 · lines 14515–14661:** Actual pole-isolation chart, analytic source continuation and positive-gap normalized Hamiltonian specialization.
- **B7-U02 · lines 14632–14735:** Fixed-pole derivative normalization and moving fourth-vertex/source boundary response.
- **B7-U03 · lines 14739–14853:** Higher critical Schur jets; exact residual zero is stronger than vanishing second derivative.
- **B7-U04 · lines 14845–15016:** Laurent coefficient-character versus physical secant distinction, C2 third-jet and conditional physical action/port scope.
- **B7-U05 · lines 15013–15116:** Physical boundary split, local dual restriction, and source-to-boundary third vertex; not an independent K16 action.
- **B7-U06 · lines 15116–15334:** Ward-null descent, rank-changing terminal quotient memory and absence of unlicensed boundary stress identification.
- **B7-U07 · lines 15336–15453:** Hilbert work including actual external marks, homothety and moving projector/occupation insertion.
- **B7-U08 · lines 15455–15550:** Moving actual boundary port/metric pairing and exact stationary collar comparison.
- **B7-U09 · lines 15551–15657:** Two homogeneous lapse/scale ports, coldness pressure operator and source-state spectral restrictions.
- **B7-U10 · lines 15640–15728:** Conditional topological work coupling versus Hilbert work, complete noncommuting Euler-marked heat third jet.
- **B7-U11 · lines 15729–15827:** Terminal anchoring f(C)=0,F(C)=1 and complete source-normalized f(R) comparison stress.
- **B7-U12 · lines 15828–15983:** Hopf Euler/connection decomposition, anisotropic work, canonical conformal scalar action and completed endpoint trace.
- **B7-U13 · lines 15984–16125:** Matched Ω boundary-square and Weyl map, improved scalar trace, Gaussian determinant versus classical stationary mean.
- **B7-U14 · lines 16126–16276:** Retarded two-history source mean, homogeneous Casimir memory, Dirac sign-pair response and no-double-mean scope.
- **B7-U15 · lines 16278–16492:** Terminal comparison boundary charge and cold history, finite CAR asymptotic energy, late source errors and noise distinction.
- **B7-U16 · lines 16493–16690:** Completed closed FLRW two-port stress and mixed noncommuting heat metric derivative.
- **B7-U17 · lines 16692–16972:** Complete static loaded energy, temporal derivative identifiability and forced dynamical source work.
- **B7-U18 · lines 16976–17138:** Matched spin provider comparisons, singular boundary continuation, crossing/rank-change and first-order auxiliary carrier exclusions.
- **B7-U19 · lines 17140–17237:** Cartan geometric gauge restriction, exact scalar exchange and protected coexact linearization.

## Integrity/readback

Batch-7 ledger contains source-as-printed full theorem/proof text, stable IDs, each proof-route scope and positive proof-use witness, condition inheritance, retained five issue IDs, and 50 E3/E4 certificates. It is a staged audit layer only; **no papers/source ZIP or canonical atlas modified**. The consolidated DAG and ProofChainAudits ZIPs will be written after the final batch and must contain only latest applicable versions.

### Next source batch
Lines **17,238–20,000** (Batch 8).
