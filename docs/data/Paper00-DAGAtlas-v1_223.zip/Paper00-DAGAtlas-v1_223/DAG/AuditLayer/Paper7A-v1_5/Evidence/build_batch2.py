import re, json, hashlib, collections
from pathlib import Path
root=Path('/mnt/data/audit7a_work')
source=root/'Papers/Paper7A-QCDKernel-v1_165.tex'
s=source.read_text().splitlines();sha=hashlib.sha256(source.read_bytes()).hexdigest()
old=json.loads((root/'Paper7A-AuditState-Batch1-v1_1.json').read_text())
assert old['source_sha256']==sha
# Source-matched discrete claim dispositions; independent only where checked separately
P=[
('REPRODUCED','Finite package yields deterministic readouts given the actual action, physical projector, source and state. Carries earlier global-versus-local Gauss issue BH-G-000138 and source-derivative issues BH-G-000139/140.'),
('VERIFIED-CONDITIONAL','E3 commuting finite self-adjoint generators and equivariant equal-time seed imply the stated time/Hopf covariance on retained test functions; the chosen unitary generator is explicit, not a new physical field-intertwiner.'),
('VERIFIED-CONDITIONAL','E3 differentiation of the constructed unitary and joint spectral positive-polar bound; no species conservation inferred.'),
('FORMALIZED','Six-clause LFRep certificate; R3 physical/Fock identity and R4–R6 remain explicit. The R4 short name P_L^+ is not locally bound; BH-G-000142 records a minor traceability ambiguity.'),
('REPRODUCED','Source-matched reuse of the earlier constructed null unitary, with same-carrier R1/R2 guards and R3–R6 retained.'),
('FORMALIZED','Status theorem expressly leaves native seed, Fock, Gauss, color path, sampling/refinement certificates open; no standalone finite LFRep assertion.'),
('REPRODUCED','Owner split isolates source current/stress normalization from optional exact finite Fock simplex; imported V-A source/III-E clock conditions are not newly proved.'),
('FORMALIZED','Six-row execution record is a reproducibility and no-backflow rule, not a new physical prediction.'),
('FORMALIZED','Five orthogonal 3D cores and rank-three mirror projectors typed as abstract 15D Petersen role, not QCD quarks/links.'),
('REPRODUCED','Direct 2-core block characteristic polynomial agrees with VII-D p13:prop:v323-petersen-charpolys; its independent full ten-axis coordinate E3 was not rerun; conditional contrast bound follows.'),
('VERIFIED-CONDITIONAL','E3 block-diagonal commutation preserves incoherence under U(t); no assertion that actual strong H commutes with all P_m.'),
('FORMALIZED','Physical incidence map, isometry, leakage/reducing condition and source insertions are explicit tests, not QCD compiler outputs.'),
('VERIFIED','E3 gcd(2,3)=1 gives trivial Z2-to-Z3 homomorphism. Equal incidence valency supplies no SU3 gauge map.'),
('VERIFIED','E3 independent random Hermitian K and isometric compression: iota†K²iota=Keff²+B†B to 3.1e-15; self-adjoint invariant implies reducing.'),
('FORMALIZED','Optional Wmn⊗C4 candidate has unsupplied physical embedding, flavor owner and coefficients; does not identify its dimension with Hurwitz 24 vertices.'),
('VERIFIED-CONDITIONAL','E3 direct diagonalization of 24×24 abstract operator matches 8+2+2+6+6 eigenmultiplicities, trace and second moment; physical spectrum explicitly not derived.'),
('VERIFIED-CONDITIONAL','E3 U and Q spin-blind; Q=Dmn² is block diagonal, so core-block-incoherent states persist under only-Q evolution.'),
('FORMALIZED','Finite color connection and Hermitian physics-generator convention stated. Heat sections later use anti-Hermitian Lie coordinate X; conversion is a convention guard.'),
('REPRODUCED','Invariant bilinear form uniqueness for simple su3, with upstream traceless-color constructor; 3D triplet dimension alone does not force SU3.'),
('REPRODUCED','Imported Paper3F v174 regular local Yang–Mills symplectic/Gauss phase-space theorem applies only on stationary product parity-even pure gauge branch; not a finite Haar regulator.'),
('VERIFIED-CONDITIONAL','E3 linear YM curvature gives eight uncoupled color copies; coexact round S3 spectrum n≥2 and primitive clock imported from Paper3A; free periodicity only.'),
('REPRODUCED','Native alpha_s=pi/2 and g_s=sqrt(2)pi import common-heat V-C source; comparison alpha_s(mu) needs owned RG transport.'),
('FORMALIZED','Theta zero is declared native CP member, not a consequence of CP-even kinetic uniqueness; later V-C determinant orientation is separate import.'),
('FORMALIZED','Parametric finite strong H and exp[-t(H-E0)] defined; actual coupling at execution scale, mass and action representative remain supplied.'),
('VERIFIED-CONDITIONAL','E3 U_free(T)=I implies V_I periodic and exact Dyson one-turn unitary; global Haar reduction is unitary if both blocks gauge invariant. Local Gauss physical scope inherits BH-G-000138.'),
('REPRODUCED','Parametric pure-glue/full-QCD family exists on supplied admissible action and source choices; representative-independent continuum is not claimed.'),
('REPRODUCED','Paper II-A whole-family evaluation on typed mass coefficient port; no G0 physical member or G16 evaluation produced by this construction.'),
('FORMALIZED','G34 historical scope retyped as quark-mass family already generated and physical member/RG needed for numerical selection.'),
('VERIFIED-CONDITIONAL','E3 Haar uniqueness on SU3^E and bi-invariant symmetric strongly local diffusion Casimir generator on each simple SU3 group; nonlocal jumps excluded explicitly.'),
('FORMALIZED','Spectral heat, group face heat and Euclidean transfer times are distinct types; no numeric equality inferred.'),
('FORMALIZED','Holonomy–flux cotangent quantization implies electric Laplacian conditionally; no magnetic nonlinear face law selected.'),
('VERIFIED','E3 independent SU3 character-sum evaluation h(t), hprime<0 and endpoint limits; strict variance yields inverse on positive axis.'),
('VERIFIED-CONDITIONAL','E3 kappa=w/(g3²A²) exact under stated curvature/quadrature convention; independent SU3 root t_iso=5.75329584663306 and quartic checks.'),
('VERIFIED','E3 nonzero SU3 triple epsilon contraction and absence of one-variable modes under Haar elimination refute one-face product closure generically.'),
('REPRODUCED','Degree-two heat semigroup exact but three-face blocking generates joint terms; refinement targets multiface effective action.'),
('VERIFIED','E3 product exp(-2sum t_i/3)=exp(-2t/3); subdivision count cannot manufacture uniform physical area exponent.'),
('VERIFIED','E3 curvature-fourth-order action deformation preserves Hessian and changes finite density; fixed-UV QFT4_E import remains conditional on its actual action/phase.'),
('VERIFIED','E3 q(e^X)=O(||X||²) so s_H+lambda q² retains first/second identity jets but changes positive density for lambda>0.'),
('VERIFIED','E3 Peter–Weyl convolution eigenvalue a_R/d_R criterion; strictly positive U1 counterweight 1-0.4cos2theta has negative Fourier coefficient -0.2.'),
('REPRODUCED','Retirement of independent G33 follows current VII-C v2.83 fixed-UV QFT4_E; G33-COMP remains representative-equivalence claim-scoped.'),
('REPRODUCED','Imported Paper1B unstable rank-two M8 sector not independently reproved; correct stable-trivialization warning for fixed-rank bundles.'),
('FORMALIZED','Paired finite algebra does not construct QCD action or LFRep; earlier historical G33 shorthand must be interpreted under newer G33-COMP scope.'),
('FORMALIZED','Comparison harmonic/occupation refinement is not a new momentum carrier or automatic physical mode occupation.'),
('VERIFIED','E3 independent SU3 rep sums agree quartic coefficient k4=-0.000309567546080; original Paper1C character contraction supplies proof.'),
('VERIFIED-CONDITIONAL','E3 invariant Haar projector on each interior edge plus SU3 epsilon 3-face polynomial; finite positive heat time ensures summable character expansion; no continuum limit.'),
('VERIFIED','E3 exact rational comparisons and independent SU3 sum yield a=0.5632936302,b=1.4367063698 and eps96=6.349176e-76<6.35e-76; analytic face tails imported from Paper1C.'),
('VERIFIED','E3 N commuting SU3 faces: center holonomy omega I while sum integrated HS curvature squares=8pi²/(3N). No area-extensive floor from center alone.'),
('VERIFIED','E3 balanced finite odd chiral block has equal rank on domain/codomain; index zero by rank-nullity.'),
('VERIFIED-CONDITIONAL','E3 independent finite random Hermitian sign involution satisfies exact GW identity and integer trace index. Native 4D Hurwitz/transfer incidence imports Paper1C proof; gap condition mandatory.'),
('FORMALIZED','Native clutching target pi3(SU3)=Z and candidate diag(q,1); full overlap/clutching matching explicitly not asserted.'),
('REPRODUCED','Follows gapped GW identity and bounded finite functional calculus; nonzero physical topological sector probabilities are not derived here.'),
('FORMALIZED','Scalar temporal spin sign is not an additional gauge-curvature dimension; index independence restricted to same closed index family.'),
('FORMALIZED','Active G20 layer split names native index/finite neighborhoods and unresolved continuum clutching comparison; imported later positive-sector theorem not reaudited in this batch.'),
('VERIFIED','E3 discrete positive-weight source check confirms A_a=<S_a>, A_ab=<S_ab>-Cov(S_a,S_b) and nonlinear chart Hessian; mean-source contacts retained.'),
('VERIFIED-CONDITIONAL','Kotecky–Preiss criterion applied on assumed exact polymer activities with uniform holomorphic bound; actual source polymer representation/bounds not supplied by theorem.'),
('VERIFIED','E3 noncommuting 2×2 finite Hermitian source check Duhamel first and second Ward derivatives; Kubo–Mori covariance operator norm bounds.'),
('VERIFIED-CONDITIONAL','E3 chain rule of same functional yields derivative kernel identity K=-D_S Sigma and mismatch norm; axial physical pole not inferred.'),
('VERIFIED','E3 composition u(s mu(u)) and scheme chain rule on same local injective scale branch; no RG function generated.'),
('VERIFIED','E3 finite cumulant differentiation; symmetric ±1 yields kappa4=-2, sparse symmetric ±1 yields epsilon-3epsilon²>0 for 0<epsilon<1/3.'),
]
rows=[]
for idx,line in enumerate(s,1):
 if not (1878<=idx<=3943):continue
 m=re.search(r'\\begin\{(theorem|lemma|proposition|corollary|definition|remark)\}(?:\[(.*)\])?',line)
 if m:
  t=m.group(1); title=m.group(2) or '';e=idx
  while e<=len(s) and r'\end{'+t+'}' not in s[e-1]:e+=1
  assert e<=3943,(idx,e,title)
  lab=next((re.search(r'\\label\{([^}]+)\}',s[x-1]).group(1) for x in range(idx,e+1) if re.search(r'\\label\{([^}]+)\}',s[x-1])),f'NO_LABEL_AT_{idx}')
  proof=None;nx=e+1
  while nx<len(s) and not s[nx-1].strip():nx+=1
  if s[nx-1].strip().startswith(r'\begin{proof}'):
   py=nx+1
   while py<len(s) and r'\end{proof}' not in s[py-1]:py+=1
   proof=[nx,py]
  rows.append({'id':f'P7A-{58+len(rows):03d}', 'source_label':lab,'type':t,'title':title,'statement_lines':[idx,e],'proof_lines':proof,'source_sha256':sha,'source_status':'SOURCE-AS-PRINTED'})
assert len(rows)==len(P)==59, (len(rows),len(P))
for i,(st,note) in enumerate(P):
 rows[i]['status']=st;rows[i]['evidence_summary']=note;rows[i]['issues']=['BH-G-000142'] if i==3 else []
rows += [
 {'id':'P7A-U002','source_label':'p10:sec:v2201-derived-d21','type':'unnamed_material_derivation','title':'Exact SU3 three-face source interaction and asymptotic heat-order expansion','statement_lines':[3851,3887],'proof_lines':[3870,3876],'source_sha256':sha,'source_status':'SOURCE-AS-PRINTED','status':'VERIFIED-CONDITIONAL','evidence_summary':'E3 independent epsilon tensor polynomial and independent character-selection orders; source correctly restricts to valence-three SU3 heat block.','issues':[]},
 {'id':'P7A-U003','source_label':'p10:sec:v2201-derived-d22','type':'unnamed_material_derivation','title':'Exact three-face source Hessian, rank, monotonicity and numeric table','statement_lines':[3891,3937],'proof_lines':[3902,3910],'source_sha256':sha,'source_status':'SOURCE-AS-PRINTED','status':'VERIFIED-CONDITIONAL','evidence_summary':'E3 independently evaluate Weyl-torus quadrature with Schur-character recurrence on grid 96×96: reproduces all five reported Z3,k table pairs and rank16 relative-source Hessian.','issues':[]}
]
issue={
 'id':'BH-G-000142','severity':'minor','source_label':'p10:def:finite-null-representation-certificate','statement_layer':'SOURCE-AS-PRINTED',
 'first_origin':{'paper':'Paper7A','theorem_id':'p10:def:finite-null-representation-certificate','step_locator':'Paper7A-QCDKernel-v1_165.tex:2118-2122','source_excerpt':r'The physical projector G_L commutes with P_L^+, every P_{i,L}^+'},
 'class':'TYPE_OR_DOMAIN','lifecycle':'OPEN','issue_status':'unresolved','exact_obligation':'Bind P_L^+ in Paper VII-A R4 to P_{\\mathrm{phys},L}^+ or to the common P_{F,L}^+=P_{\\mathrm{phys},L}^+ specifically after R3 is assumed; state whether R4 is meant independently of R3.',
 'why_it_matters':'R4 uses a plus-momentum shorthand with no local definition in VII-A even though the same definition distinguishes P_F,L^+ from P_phys,L^+ until R3 holds. This is a scoped certificate notational ambiguity, not a counterexample to LFRep.',
 'source_replayed':True,'independent_evidence':['EV-P7A-B02-IMPORT-TRACE'], 'adversarial_evidence':['EV-P7A-B02-NOTATION-SCOPE'],
 'constitution_boundary':None,'conditions_consumed':[],'conditions_open':[],
 'upstream_material_paths':[['p10:eq:v252-r3-fock-physical-equality','p10:def:finite-null-representation-certificate']],
 'downstream_verified_paths':[], 'other_papers_affected':[],
 'possible_unconfirmed_impacts':['Paper7B exact finite LFRep on the fully certified R3 branch; Paper7D optional simplex branch'],
 'verified_bypass_routes':['On full R3 certificate P_F,L^+=P_phys,L^+, and P7B/P7D explicitly define P_L^+ to mean the common operator'],
 'resolution_requirement':'Explicitly state the short name at R4 or use P_phys,L^+ directly; record that R3 is consumed if the common operator is intended.',
 'audit_scope_limit':'No refutation of R3–R4 on complete LFRep branch; no independent proof of the actual six clauses for the QCD state.',
 'evidence_details':'Exact search of current P7A finds P_L^+ only at 2119, while its R2/R3 clauses name P_phys,L^+ at 2068–2075 and P_F,L^+ at 2103–2108. Current VII-B lines 2549–2562 and VII-D lines 2539–2542 explicitly introduce the shorthand only after consuming R3.'
}
state=old.copy()
state.update({'batch':2,'audited_through_line':3943,'formal_covered':116,'formal_remaining':198,
 'unnamed_material_checked':3,
 'current_status':'PARTIALLY_AUDITED_WITH_OPEN_ISSUES',
 'claims':old['claims']+rows,
 'issues':old['issues']+[issue],
 'unreviewed':['All 198 formal statements from line 3944 through source end (including technical appendices) remain unaudited; central later mass-gap/confinement/positive native topological sector proofs not certified yet; physical Gauss and complete LFRep/source realizations remain conditional where printed.']})
state['evidence_records']=old['evidence_records']+[
 {'id':'EV-P7A-B02-E1','tier':'E1','details':'All 59 formal statements and two unnamed derivations in current source lines 1878–3943 replayed and dispositioned; current 1C, 3F, 5C, 7B, 7C and 7D exact imports checked only for cited scoped claims.'},
 {'id':'EV-P7A-B02-INDEPENDENT','tier':'E3','details':'Direct 24×24 mirror-spin diagonalization; random Hermitian Schur compression leakage; independent SU3 Peter-Weyl heat sums and h inverse; quartic; heat bounds N<=96; epsilon face invariant; positive-type U1 test; finite overlap GW; blocked conditional source derivative; noncommuting finite Ward tests; cumulant and center-flux algebra.','script':'audit7a_work/check_batch2.py','results':'audit7a_work/batch2_independent_checks.json'},
 {'id':'EV-P7A-B02-D22-WEYL','tier':'E3','details':'Direct 96×96 Weyl-torus Haar quadrature with SU3 Schur characters from independent recurrence agrees with all five Z3,k table pairs in unnamed D22 derivation.','script':'audit7a_work/check_d22.py','results':'audit7a_work/batch2_d22_weyl_check.json'},
 {'id':'EV-P7A-B02-IMPORT-TRACE','tier':'E1','details':'Source labels resolved for Paper1C heat-block, overlap; Paper3F generated Yang–Mills phase space; Paper7D mirror compression; Paper7C QFT4_E; Paper5C strong-CP. External imports remain claim-scoped.'},
 {'id':'EV-P7A-B02-NOTATION-SCOPE','tier':'E4','details':'Search P7A P_L^+ has sole occurrence R4 at 2119; VII-B and VII-D define this short name only after R3. This scope witness is minor and has an explicit valid bypass on the all-clauses domain.'}
]
state['boundary_records']=old['boundary_records']+[
 {'id':'BND-P7A-003','type':'null_representation_owner','source':'Paper7A lines 1916–2224; Paper7B 2549–2562; Paper7D 2531–2542','sort':'R1/R2 elapsed null construction vs independent R3 species/Fock equality vs R4 local Gauss, R5 color path, R6 sampling','realization':'R1/R2 only on same-carrier Hopf-equivariant seed and commuting positive-polar generator; R3–R6 remain additional proof obligations; full LFRep is not an established physical QCD output','provenance':['[CONST] finite good-field equal-time seed in R1 is an explicit condition','[DER] null generator on same carrier from H and P_H','[REAL] R3–R6 distinct unresolved interface clauses']},
 {'id':'BND-P7A-004','type':'heat_and_physical_scale','source':'Paper7A lines 2830–2994, 3200–3353','sort':'SU3 Casimir heat on exact finite face representative vs spectral heat matching and Euclidean transfer time','realization':'Heat inverse is unique only after positive exact-cell stiffness kappa and strongly local heat representative have been supplied; no face mesh or physical string tension thereby produced','provenance':['[CONST] source common heat g3² branch','[DER] unique heat t from given face quadratic form','[CAL] isotropic face ratio optional presentation convention']},
 {'id':'BND-P7A-005','type':'petersen_mirror_realization','source':'Paper7A lines 2261–2487; Paper7D lines 1157–1224','sort':'geometric W(15) mirror representation vs actual gauge-invariant QCD singlet H_L','realization':'No SU3 link or physical meson is inferred from 2I incidence; physical use needs actual embedding, leakage/reducing test and source residues','provenance':['[GEN] 2I-only Petersen packet','[DER] two-core mirror compression','[REAL] QCD source/physical embedding conditional']}
]
state['batch2_status_counts']=dict(collections.Counter(r['status'] for r in rows if r['type']!='unnamed_material_derivation'))
state['cumulative_status_counts']=dict(collections.Counter(r['status'] for r in state['claims'] if r['type']!='unnamed_material_derivation'))
assert len([r for r in state['claims'] if r['type']!='unnamed_material_derivation'])==116
p=root/'Paper7A-AuditState-Batch2-v1_2.json';p.write_text(json.dumps(state,indent=2,ensure_ascii=False))
print('wrote',p,'bytes',p.stat().st_size,'batch counts',state['batch2_status_counts'],'cumulative',state['cumulative_status_counts'],'issues',len(state['issues']))
