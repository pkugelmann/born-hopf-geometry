import itertools as it,numpy as np, collections, json
from pathlib import Path
verts=sorted(set(tuple([sg1 if i in p and i==p[0] else sg2 if i in p else 0 for i in range(4)]) for p in it.combinations(range(4),2) for sg1 in [-1,1] for sg2 in [-1,1]))
assert len(verts)==24
v=np.array(verts,float)
edges=[pair for pair in it.combinations(range(24),2) if abs(np.dot(v[pair[0]],v[pair[1]])-1)<1e-10]
eidx={e:i for i,e in enumerate(edges)}
faces=[tri for tri in it.combinations(range(24),3) if all((min(a,b),max(a,b)) in eidx for a,b in it.combinations(tri,2))]
fidx={f:i for i,f in enumerate(faces)}
assert (len(edges),len(faces))==(96,96)
B2=np.zeros((96,96),dtype=int)
for j,(a,b,c) in enumerate(faces):
 for e,s in [((b,c),1),((a,c),-1),((a,b),1)]: B2[eidx[e],j]=s
normals=np.vstack([np.diag([1]*4),-np.diag([1]*4),np.array(list(it.product([-0.5,0.5],repeat=4)))])
cells=[]
for normal in normals:
 vertex_indices=tuple(np.where(np.abs(v@normal-1)<1e-10)[0]); assert len(vertex_indices)==6,(normal,vertex_indices)
 cells.append(vertex_indices)
assert len(set(cells))==24
B3=np.zeros((96,24),dtype=int)
for k,c in enumerate(cells):
 C=set(c)
 fs=[fidx[f] for f in faces if set(f).issubset(C)]
 assert len(fs)==8
 edge_to_face=collections.defaultdict(list)
 for f in fs:
  for e in np.where(B2[:,f])[0]: edge_to_face[e].append(f)
 assert len(edge_to_face)==12 and all(len(x)==2 for x in edge_to_face.values())
 signs={fs[0]:1}
 front=[fs[0]]
 while front:
  f=front.pop()
  for e in np.where(B2[:,f])[0]:
   f2=next(ff for ff in edge_to_face[e] if ff!=f)
   s2=-signs[f]*B2[e,f]//B2[e,f2]
   if f2 in signs:assert signs[f2]==s2
   else:signs[f2]=s2;front.append(f2)
 for f,s in signs.items(): B3[f,k]=s
assert np.all(B2@B3==0)
H=B2.T@B2+B3@B3.T
r=np.linalg.eigvalsh(H)
counts=collections.Counter(np.round(r,8))
expected=[(1.,6),(2.,16),((9-np.sqrt(17))/2,9),(4.,16),(5.,16),((9+np.sqrt(17))/2,9),(8.,13),(9.,1),(10.,8),(12.,2)]
for x,m in expected:assert np.sum(abs(r-x)<1e-6)==m,(x,m)
import sympy as sp
lam=sp.Symbol('lambda')
exact_factor=(lam-1)**6*(lam-2)**16*(lam**2-9*lam+16)**9*(lam-4)**16*(lam-5)**16*(lam-8)**13*(lam-9)*(lam-10)**8*(lam-12)**2
assert sp.factor(sp.Matrix(H.tolist()).charpoly().as_expr())==exact_factor
print({'vertices':24,'edges':96,'faces':96,'cells':24,'d2d3_norm':float(np.linalg.norm(B2@B3)),'H_2_min':float(r[0]),'eigenmultiplicities':[(round(x,8),m) for x,m in expected],'trace':int(np.trace(H)),'rank_d1':np.linalg.matrix_rank(B2),'rank_d2':np.linalg.matrix_rank(B3)})
Path('/mnt/data/audit7a_work/batch3_geometry_check.json').write_text(json.dumps({'n_vertices':24,'n_edges':96,'n_faces':96,'n_cells':24,'d_squared_zero':True,'H2_eigenvalues':[(x,m) for x,m in expected],'trace_H2':int(np.trace(H)),'exact_charpoly_verified':True,'exact_charpoly_factored':str(sp.factor(exact_factor))},indent=2))
