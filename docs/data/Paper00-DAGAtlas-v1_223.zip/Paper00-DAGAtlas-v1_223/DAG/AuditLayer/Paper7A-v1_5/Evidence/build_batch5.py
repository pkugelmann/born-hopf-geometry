"""Final Paper7A batch 5: source-bound exhaustive statements and evidence, no manuscript edits."""
import json,re,hashlib,collections
from pathlib import Path
root=Path('/mnt/data/audit7a_work'); src=root/'Papers/Paper7A-QCDKernel-v1_165.tex'; ls=src.read_text().splitlines(); sha=hashlib.sha256(src.read_bytes()).hexdigest()
s=json.load(open(root/'Paper7A-AuditState-Batch4-v1_4.json')); assert sha==s['source_sha256'] and len(s['issues'])==13 and s['formal_covered']==247
# Explicit numbered judgement; ``VERIFIED`` only for claims with mathematical E3 or exact simple independent proof.
P={
248:('REPRODUCED','Cartan link, holonomy and curvature profiles source-matched to Paper1B; direct reflection and midpoint curvature bound replay, not a fresh full edge-by-edge spin calculation.'),
249:('VERIFIED-CONDITIONAL','Differentiating 96-face/96-ribbon restricted heat action gives the printed Euler equations; N=3 midpoint stationary by reflection. Restriction is not full action stationary point.'),
250:('UNRESOLVED','Exact 864×864 inertia and >0.256 gap rely on 16-phase integer witness payload and verifier reported in Paper7D but absent from the supplied minimal/Atlas archives. Formulas and finite perturbation estimate replay only (BH-G-000147).'),
251:('REPRODUCED','Clock-cover Fourier block replication and index additivity follow if the exact 16-phase uniform-gap certificate is supplied; no independent integer replay of that premise (BH-G-000147).'),
252:('VERIFIED-CONDITIONAL','Row/column norm b=6eps_s+2eps_t+eps_rho and Weyl stability valid for the printed Hermitian stencil, conditional on base exact gap and native link representation (BH-G-000147).'),
253:('VERIFIED','On two gapped Hermitian matrices sign-resolvent difference is norm bounded by ||H-K||/g, giving the displayed overlap bound and gauge-orbit covariance.'),
254:('VERIFIED-CONDITIONAL','Every nonempty all-link SU3 neighborhood has positive Haar measure; a pointwise positive pure-heat product gives Z_{±1}>0 and primitive gcd, conditional on certified centers and positive-domain measure (BH-G-000147).'),
255:('VERIFIED','SU3 torus Vandermonde rectangle bound and exact rational q*=7061881225/199022581174732616540136492402475008 independently rechecked, including factor normalization.'),
256:('VERIFIED-CONDITIONAL','Exact rational comparison 4(7/18)^1152 q*^720>1e-18796 E3 checked; positive masses and index-±1 product balls require exact center certificate not independently replayed (BH-G-000147).'),
257:('VERIFIED','Primitive characteristic-function lower bound follows from positive ±1 event weights; its least period 2π and unit-return set do not imply strict modulus bound.'),
258:('VERIFIED','Independent gamma5-Hermitian sign-unitary matrices verify positive determinant and singular-value bounds for all positive scalar flavor masses; no physical mass selection.'),
259:('VERIFIED-CONDITIONAL','Whole-weight sector lower bound multiplies heat Haar-ball bound and actual positive determinant ratio, conditional on ±1 certified centers, positive retained scalar masses and fixed Ω (BH-G-000147).'),
260:('REPRODUCED','Zero-index center analytic temporal Fourier/polar lower bounds source-replayed for either spin sign; exact full 864-mode result not independently diagonalized, algebraic inequalities valid on displayed stencil.'),
261:('VERIFIED-CONDITIONAL','At least one unsaturated massless determinant kills |ν|>0; zero-index invertible positive-Haar ball prevents zero total partition, conditional on preceding center witness.'),
262:('REPRODUCED','GW source C_PP=||Et Q Es||², contact 72aR² and sum_t [D,Et]=0 algebraically rechecked; reducing uniform zero-index temporal sector/normalization not independently rebuilt.'),
263:('VERIFIED-CONDITIONAL','Finite determinant zeros give χV≤Eν² and upper product O(∏x_f), conditional on fixed positive mass-independent domain containing invertible zero-index ball.'),
264:('VERIFIED','Gamma5-hermitian unitary phase pairing gives nonnegative determinant polynomial coefficients, n0/parity lower order, and for F≥2 a zero first common mass derivative when Z(0)>0.'),
265:('FORMALIZED','Distinct pure heat, real massive and unsaturated massless topology weight/domain branches cannot be equated; all keep actual finite index components.'),
266:('VERIFIED-CONDITIONAL','Range-one Chebyshev/sign locality inherited Paper1B; exact substitution q=10941/11059 and prefactor 11000/(59 aR) independently checked; global spatial refinement not proved.'),
267:('VERIFIED-CONDITIONAL','Sign derivative bounds imported from Paper1B on fixed smooth gapped family; projector rank 431k conditional on unreplayed index center; connection curvature and ODE transport follow from finite projectors.'),
268:('VERIFIED-CONDITIONAL','Projector chart bound follows by decomposing H into ± spectral subspaces; polar isometry, determinant overlap cocycle on a fixed local chart, not a gauge-global chiral measure.'),
269:('VERIFIED-CONDITIONAL','Substitution of all-link neighborhood gap and M bound satisfies imported finite chart hypotheses; exact native center gap premise is not independently integer-replayed (BH-G-000147).'),
270:('VERIFIED','Epsilon-color projection is invariant under common-endpoint SU3 transformations and symmetric in three faces; Haar triple fundamental integral gives same W_e with factor 1/6.'),
271:('VERIFIED','Spin-sector trace factor 1/12 and first nonflat flux coefficient verified through independent polarized three-leg calculation, not a physical baryon mass claim.'),
272:('VERIFIED','Fresh matrix construction of C3,C4,C5 for six arbitrary noncommuting SU3 triples reproduces all-link D_e to <7e-16; correct first squared contrast at x8.'),
273:('VERIFIED','F(U)=|z-1/2|²-1/4, upper 3/2 and sharp three-face sums proven; edge-face double-count gives 1/96 face average=1/288 edge sum.'),
274:('VERIFIED','Haar character orthogonality reproduces E(F)=1/9, Var(F)=11/162 and independent pairwise-face variance=11/15552; positive density yields strict variance.'),
275:('VERIFIED','3×3 directed relative incidence M^T M=3I−J exact; equality to earlier label Hessian is on the D22 source-label block only.'),
276:('VERIFIED','Each face occurs in three edge fans; symmetric common/relative fan Gram adds to 9 I96, providing lossless formal face-frame decomposition.'),
277:('REPRODUCED','Signed chi/psi are gauge class functions under common rooted SU3 conjugacy; quaternionic orientation sign compensates face enumeration; color-C parity separated from physical CP.'),
278:('VERIFIED','Pauli/quaternionic cubic spin trace gives 6σ_e tr(V0V1V2−V0V2V1), hence 18 ψhat; no assertion that physical Hamiltonian contains that cubic.'),
279:('REPRODUCED','Single-fan SU3 character integrations yield proposed 5/144 and 8/81 squared Haar norms; cross-edge orthogonality asserted via exclusive-link Haar integrals, full 96×96 exact group replay not conducted.'),
280:('REPRODUCED','Conditional link-Casimir counts 6×3=18 and 3+6×4/3=11 agree with stated representation types; not a physical interacting energy.'),
281:('FORMALIZED','Finite QCD core tuple explicitly distinguishes constructed operators, target maps, conditional chiral and topology packets, imported charge source and comparison calibrations.'),
282:('REPRODUCED','Structural descendant assertion source-matched to Paper2A co-realization grammar, conditional on actual licensed color, link and mass/source constructors; no new physical occurrence claim.'),
283:('REPRODUCED','Completion certificate is definition/computation-target closure only; unresolved gauge/local-source, string tension, chiral limits and nonperturbative mass-gap findings remain in audit.'),
284:('VERIFIED-CONDITIONAL','Exact 24-cell and Hodge numbers and finite δgeom earlier independently verified; RG crossing/mixed-clock values explicitly comparison-branch, not physical.'),
285:('FORMALIZED','Paper7A→7B acyclic data interface and no downstream numerical back-selection; no new mathematical performance claim.'),
286:('VERIFIED','Finite momentum factor End(K)⊗Mat_N expansion exists on actually factorized corner; physical signal status remains separate.'),
287:('UNRESOLVED','Formal 120-dimensional char-factorization and rank counts are internally consistent (60+60, t=0 spectrum), but the stated complete 2I character/integer certificate is not present for source-independent replay (BH-G-000148).'),
288:('REPRODUCED','Commutation of central character convolution projector with diagonal multiplier forces constant f once nonzero-kernel generating support holds; exact HS coupling table not independently verified from missing 2I certificate (BH-G-000148).'),
289:('FORMALIZED','Occupancy parameter t is unselected and the 120-dimensional comparison kernel is not the physical QCD Hamiltonian.'),
290:('REPRODUCED','Character Fourier combination of existing edge-fan Wilson determinants is gauge invariant; one-link 4/9 witness replayed at counting level using Paper1C but no full eight-orbit independent certificate.'),
291:('FORMALIZED','One-link witness is algebraic not certified action domain, and its Fourier mode is not a new particle/mass/source owner.'),
292:('REPRODUCED','F40 fivefold disjoint group supports and proper Hamiltonian leakage/Schur readout follow on supplied group marking and actual isometry candidate; no action selection.'),
293:('VERIFIED-CONDITIONAL','A5-equivariant symmetric quotient annihilates mirror 3+3prime iff factoring only through the specified T_R+T_L map; antisymmetric channel algebraic only.'),
294:('REPRODUCED','44-component/23 equation and missing A5 quintet claims imported with exact same-cycle and representation types; no universal physical source claim.'),
295:('VERIFIED','No A5-fixed vector in 3⊕3prime⊕3·5, giving zero invariant linear scalar; symmetric quadratic space dimension 1+1+6=8.'),
296:('FORMALIZED','F40 geometric readouts are candidates; an actual SU3-singlet source, leakage and physical correlator residues remain open.'),
297:('VERIFIED','Spinor low-band intertwining iff finite residual ED=0 is direct exact operator equality, not inferred from scalar 14-band proof.'),
298:('VERIFIED-CONDITIONAL','Vertexwise compact Haar average is orthogonal projector, commutes with invariant H and is contained in global singlet; link/matter representation/truncation is explicit hypothesis (also BH-G-000138).'),
299:('VERIFIED','Exact finite Duhamel/log-partition Hessian includes contact H_ab and centered Kubo correlation; corrects missing terms of earlier source rule (BH-G-000139/BH-G-000140 unresolved earlier scope).'),
300:('VERIFIED','Normalized epsilon singlet matrix coefficient establishes |E(A,B,C)|≤1 and three distinct transports not a determinant.'),
301:('FORMALIZED','Actual mass/source and dynamical-gap boundary distinguishes generated source, physical Gauss action, interacting spectrum and Haar statistics.'),
302:('VERIFIED','SU3 center triality kills lower moments; shared U gives exact connected third moment e^(−2t)/27 under declared heat law.'),
303:('VERIFIED','Positive character coefficients and two singlet 3^3/conjugate 3^3 triple terms imply C3(t)≥54 e^(−2t), with no APBI action claim.'),
304:('FORMALIZED','Numerical heat-star representative explicitly conditional on heat time transport/APBI; not physical shell or measured QCD heat time.'),
305:('VERIFIED','SU3 3⊗3bar=1⊕8 identity gives pointwise fundamental−adjoint flux formula and transfers to integrable positive expectations.'),
306:('FORMALIZED','Wilson-character contrast is only the selected comparison transfer, not a nonperturbative baryon mass splitting.'),
307:('VERIFIED','Epsilon normalized vectors and Cauchy–Schwarz give W_e color Gram and |W_e|≤1; mesonic trace Gram likewise.'),
308:('VERIFIED','G^−1/2 G G^−1/2=I on support, with singular Moore–Penrose version; raw |W|² is not a branching fraction.'),
309:('FORMALIZED','APBI same-physical-Hamiltonian isometry and Schur self-energy are necessary source test; physical embedding and pole overlap remain unestablished.'),
310:('FORMALIZED','Cartan 8/9 and jet ranks 3,8 explicitly kept candidate/reference-scoped; no physical rank/mass theorem.'),
311:('VERIFIED','C3 Fourier diagonalization 3I−J=3(Pchi+Pchibar); independent SU3 polarized determinant Taylor quadratic coefficient matches source to ≲1.2e−6 at eps=3e−4.'),
312:('REPRODUCED','Formal four inverse pairs yield 4+4 conjugation grading; full 8×8 one-link determinant claimed 2^20·3² but named v1_12 witness absent in supplied archives (BH-G-000148).'),
313:('VERIFIED-CONDITIONAL','Qχ normalized traceless spin-two tensor has vanishing dipole, and given factorized 5⊗2 representation X projectors yield 2/5 and 3/5 norms; not decay probabilities.'),
314:('FORMALIZED','Final mixed-source test defines conditional physical isometry, C-even stress correlator and genuine O_B requirement; no new transition/width asserted.'),
}
assert len(P)==67 and set(P)==set(range(248,315))
rows=[]
for line_num,l in enumerate(ls,1):
 if line_num<6273:continue
 m=re.search(r'\\begin\{(theorem|lemma|proposition|corollary|definition|remark)\}(?:\[(.*)\])?',l)
 if not m:continue
 ty,title=m.groups();title=title or ''
 e=line_num
 while e<=len(ls) and ('\\end{'+ty+'}') not in ls[e-1]:e+=1
 assert e<=len(ls)
 labels=[x for k in range(line_num,e+1) for x in re.findall(r'\\label\{([^}]+)\}',ls[k-1])]
 label=labels[0] if labels else f'UNLABELED:Paper7A:{ty}:{line_num}'
 proof=None;p=e+1
 while p<=len(ls) and not ls[p-1].strip():p+=1
 if p<=len(ls) and ls[p-1].lstrip().startswith(r'\begin{proof}'):
  pe=p
  while pe<=len(ls) and r'\end{proof}' not in ls[pe-1]:pe+=1
  proof=[p,pe]
 n=248+len(rows);status,note=P[n]
 issue_map={250:['BH-G-000147'],251:['BH-G-000147'],252:['BH-G-000147'],254:['BH-G-000147'],256:['BH-G-000147'],259:['BH-G-000147'],269:['BH-G-000147'],287:['BH-G-000148'],288:['BH-G-000148'],312:['BH-G-000148'],298:['BH-G-000138'],299:['BH-G-000139','BH-G-000140']}
 rows.append(dict(id=f'P7A-{n:03d}',source_label=label,source_aliases=labels[1:],type=ty,title=title,statement_lines=[line_num,e],proof_lines=proof,source_sha256=sha,source_status='SOURCE-AS-PRINTED',status=status,evidence_summary=note,issues=issue_map.get(n,[])))
assert len(rows)==67 and rows[0]['statement_lines'][0]==6289 and rows[-1]['statement_lines'][0]==8800
s['claims']+=rows
s['claims'] += [dict(id=k,source_label=f'unnamed:Paper7A:{a}-{b}',type='unnamed_material_derivation',title=title,statement_lines=[a,b],proof_lines=None,source_status='SOURCE-AS-PRINTED',source_sha256=sha,status=status,evidence_summary=note,issues=issues) for k,a,b,title,status,note,issues in [
 ('P7A-U007',6291,6368,'Cartan connection transport and restricted heat action','REPRODUCED','Native Cartan endpoint/face coefficient source from Paper1B; stationary midpoint is restricted heat action only; exact matrix phase gap remains in external certificate.',['BH-G-000147']),
 ('P7A-U008',7510,7607,'All-link third-to-fifth amplitude order spin-flux coefficient','VERIFIED','Independent six random SU3 triples, direct 8×8 polarized singlet spin traces give D_e coefficient at x8 with residual 6.66e−16.',[]),
 ('P7A-U009',8065,8146,'Paired 2I incidence occupancy comparison and character certificate','REPRODUCED','Full 60+60 polynomial degree and t=0 eigenvalue multiplicities rechecked; underlying named group-character and integer witness arrays absent from supplied artifacts.',['BH-G-000148'])]]
s['issues'] += [
 {
  'id':'BH-G-000147','severity':'moderate','source_label':'p10:thm:v199-native-unit-component','statement_layer':'SOURCE-AS-PRINTED',
  'first_origin':{'paper':'Paper7A','theorem_id':'p10:thm:v199-native-unit-component','step_locator':'Paper7A-QCDKernel-v1_165.tex:6381–6400; controlling Paper7D-TechnicalMaterial-v1_46.tex:384–527','source_excerpt':'The exact integer certificate ... proves ... n_-(H_*)=433 ... min|Spec H_*|>0.256'},
  'class':'MISSING_EVIDENCE','lifecycle':'OPEN','issue_status':'unresolved','source_replayed':True,
  'exact_obligation':'Reproduce and independently verify the exact 16-phase dyadic witness arrays and integer-computed Gram/congruence/gap bounds of Paper7D Theorem p10:thm:v256-exact-native-inertia on the actual 864×864 kernel. Current supplied PapersMinimal and DAGAtlas have the descriptions but do not contain the named Audit/Paper00-NativeExactInertiaChecks-v1_1.py, its manifest, or phase witnesses.',
  'why_it_matters':'All-link 3k index and finite ±1 susceptibility certificates have a mathematically clear conditional proof from uniform gap/inertia, but the crucial exact numeric base certificate is not replayable from the supplied archives. No counterexample to index/inertia is asserted.',
  'independent_evidence':['EV-P7A-B05-TOPO-RATIONAL','EV-P7A-B05-SOURCE-INVENTORY'],'adversarial_evidence':['EV-P7A-B05-E4'],
  'constitution_boundary':'BND-P7A-010','conditions_consumed':[],'conditions_open':[],
  'upstream_material_paths':[['p10:thm:v256-exact-native-inertia','p10:thm:v199-native-unit-component']],
  'downstream_verified_paths':[['p10:thm:v256-exact-native-inertia','p10:thm:v199-native-clock-covers','p10:thm:m8td-all-link-neighborhood'],['p10:thm:m8td-all-link-neighborhood','p10:thm:v161-positive-primitive-native-sectors'],['p10:thm:m8td-all-link-neighborhood','p10:thm:next187-native-heat-interval'],['p10:thm:m8td-all-link-neighborhood','p10:cor:v2189-massive-topological-interval']],
  'other_papers_affected':['Paper7D: exact integer 16-phase witness/verifier is imported only, not declared newly audited'],
  'possible_unconfirmed_impacts':['Paper7B physical topological responses require their own action/measure; no proved impact beyond the source-matched native index condition'],
  'verified_bypass_routes':['Generic Haar ball lower bound and mass-branch determinant positivity do not require the 864×864 exact inertia figures','All-link spin-flux and Wilson character formulas are separate finite color identities'],
  'resolution_requirement':'Supply exact active verifier, witness arrays and manifest for all 16 phases and independently replay integer inequalities. Do not infer a new physical topological theta action from successful replay.',
  'audit_scope_limit':'This is lack of reproducible supplied numerical proof evidence, not an established inconsistency in the arithmetic result. Structural derivations under a uniform base gap remain correct.',
  'evidence_details':'Paper7D v1_46 at 389 says all witness arrays/verifier/results in release Audit directory; at 397–404 names active exact checker and restored phase05 v1_1. The supplied Paper00-PapersMinimal-v2_371(1)(1).zip contains only TeX/PDF/bib, and supplied Paper00-DAGAtlas-v1_116(1).zip lacks these Audit files; no 16-phase exact replay possible. Independent rational 417/7000 and 10^-18796 arithmetic succeeds but is downstream of that missing premise.'
 },
 {
  'id':'BH-G-000148','severity':'moderate','source_label':'p10:thm:v338-full-occupancy-secular','statement_layer':'SOURCE-AS-PRINTED',
  'first_origin':{'paper':'Paper7A','theorem_id':'p10:thm:v338-full-occupancy-secular','step_locator':'Paper7A-QCDKernel-v1_165.tex:8070–8113; 8115–8146; 8730–8763','source_excerpt':'An exact character calculation and independent 60-by-60 and 120-by-120 numerical checks certify the factorization'},
  'class':'MISSING_EVIDENCE','lifecycle':'OPEN','issue_status':'unresolved','source_replayed':True,
  'exact_obligation':'Independently reconstruct the full 2I 120×120 unsigned incidence Gram and marked 12/36/72 diagonal occupancy operators and exact character projectors, verifying all three secular cubics, the HS coupling table and the later eight-function Wilson evaluation determinant. The named full-current v1_11/v1_12 finite witnesses are not in the supplied archives.',
  'why_it_matters':'The polynomial multiplicities/t=0 spectrum and central/odd rank bookkeeping pass internal checks, and independently verified Hurwitz spin/color formulas remain valid; the exact group-character factors and 8×8 rank certificate are not independently reproduced from available controlling data. No evidence of a false polynomial has been found.',
  'independent_evidence':['EV-P7A-B05-SOURCE-INVENTORY','EV-P7A-B05-CHAR-BOOKKEEPING'],'adversarial_evidence':['EV-P7A-B05-E4'],'constitution_boundary':'BND-P7A-011','conditions_consumed':[],'conditions_open':[],
  'upstream_material_paths':[['p5b:thm:paired-incidence-spectrum','p10:thm:v338-full-occupancy-secular']],
  'downstream_verified_paths':[['p10:thm:v338-full-occupancy-secular','p10:prop:v338-diagonal-occupancy-leakage']],
  'other_papers_affected':['Paper1C v1_59 mentions finite v1_12 witness; only narrower exact current source claims imported for Paper7A, not a new Paper1C audit'],
  'possible_unconfirmed_impacts':['Paper7B physical source comparisons are possible consumers, but source keeps t unselected and no actual Hamiltonian route certified'],
  'verified_bypass_routes':['p10:thm:v230-all-link-spinflux, p10:thm:v2220-haar-flux and p10:prop:v365-baryon-color-gram have direct calculations not using 2I 120-mode occupancy factors'],
  'resolution_requirement':'Supply or independently reconstruct the full source-defined 2I incidence/group character and eight Wilson function evaluation matrices with exact normalization, then replay the factorizations and determinant; retain physical comparison status.',
  'audit_scope_limit':'This is a missing independent group-representation certificate, not a refutation of the exact 120-mode spectral claim or of the separate eight-character functions.',
  'evidence_details':'Degree check: 13+10+20+3+2+4×3=60 even; odd 54+6=60, at t=0 even multiplicities z^18(z−30)^16(z−24)^25(z−120). Current Paper1C lines 25812–25819 refers to v1_10/v1_12 finite scripts; not shipped in current PapersMinimal or existing Atlas files. Source 8730 also cites verifier-normalized integer 2^20×3² without the actual 8×8 matrix.'
 }
]
s['evidence_records'] += [
 dict(id='EV-P7A-B05-E0',tier='E0',details='Current Paper7A SHA256 identity reconfirmed; 67 consecutive source formal items P7A-248..314 plus 3 unnamed steps; current Paper7D exact-inertia import located and matched.'),
 dict(id='EV-P7A-B05-TOPO-RATIONAL',tier='E3',details='Fresh exact Python Fraction q* rational formula identity, strict 4(7/18)^1152 q*^720>10^-18796, 32/125−11/56=417/7000 and locality (11000−59)/(11000+59)=10941/11059; log10 lower−18795.9059246241.'),
 dict(id='EV-P7A-B05-FLUX-COMPUTE',tier='E3',details='Fresh independently implemented polarized SU3 epsilon contraction and 8x8 Pauli three-spin projector, C3/C4/C5 full coefficients on six noncommuting SU3 triples, predicts D_e with max 6.66×10^-16; script check_batch5.py.'),
 dict(id='EV-P7A-B05-SOURCE-MATRIX',tier='E3',details='Fresh gamma5-Hermitian unitary random spectral test for positive massive determinant and singular-value bounds; SU3 triply-polarized Wilson Taylor coefficient checked on four independent models; adjoint character test residual 1.1×10^-16.'),
 dict(id='EV-P7A-B05-HAAR-HEAT',tier='E3',details='Independent SU3 normalized Haar character/representation moments, exact Var(F)=11/162 and full mean/variance=1/9,11/15552; heat-star third cumulant exp(−2tiso)/27=3.7272365646358e−7.'),
 dict(id='EV-P7A-B05-CHAR-BOOKKEEPING',tier='E1/E3-bounded',details='120-mode secular polynomial degrees sum60+60, at t=0 even spectrum z^18(z−30)^16(z−24)^25(z−120); central+odd t-eigenspace rank6. Group-character model and 8×8 witness still unavailable.'),
 dict(id='EV-P7A-B05-SOURCE-INVENTORY',tier='E4',details='Verified Paper7D exact inertia certificate source and named active missing Audit checker/manifest/phase payload; no matching files in supplied PapersMinimal v2_371 nor DAGAtlas v1_116. Paper1C cites v1_12 8×8 witness, absent from supplied archive.'),
 dict(id='EV-P7A-B05-E4',tier='E4',details='Adversarial checks: no false claim physical mass from comparison spin-flux; off-domain determinant phases excluded; no refutation of positive massless endpoint; missing numeric witness bars E3 status, not mathematical counterexample. Verified finite math using countertest group SU3 triples and noncommuting holonomies.'),
]
s['boundary_records'] += [
 dict(id='BND-P7A-010',type='finite_exact_inertia_witness_vs_physical_topology',source='Paper7A 6370–6542 and Paper7D 384–527',sort='native 864×864 Hermitian 16-phase integer index certificate; physical QCD theta, continuum clutch and vacuum are separate roles',realization='Assume exact source inertia/gap as claimed; heat and determinant consequences remain conditional. Witness absent from supplied archives so independent source-level verification incomplete.',provenance=['[DER] Paper7D exact certificate claimed','[HOST] integer witness payload missing for replay','[REAL] physical action/state selection not supplied']),
 dict(id='BND-P7A-011',type='finite_2I_occupancy_vs_physical_HL',source='Paper7A 8063–8154 and 8730–8763',sort='120-mode comparison incidence spectral factorization and character-labeled Wilson source functions, not actual hadron Hamiltonian',realization='Finite 2I group-character determinant warrants independent exact replay; physical t parameter and hadronic state are not selected.',provenance=['[HOST] finite 2I comparison','[DER] printed character factorization','[REAL] physical source/energy separate']),
]
s['batch5_status_counts']=dict(collections.Counter(c['status'] for c in rows));s['formal_covered']=314;s['formal_remaining']=0;s['batch']=5;s['audited_through_line']=len(ls);s['unnamed_material_checked']=9;s['current_status']='FULLY_AUDITED_WITH_OPEN_GAPS';s['unreviewed']=[]
s['cumulative_status_counts']=dict(collections.Counter(c['status'] for c in s['claims'] if c['id'].startswith('P7A-') and c['id'][4:].isdigit()))
s['batch5_condition_uses']=[
 {'condition':'native_16_phase_exact_integer_inertia_certificate','first_known':'Paper7D v1_46 lines 384–527 (source-reported; executable witness absent)','used_by':['P7A-250','P7A-251','P7A-252','P7A-254','P7A-256','P7A-259','P7A-269'],'status':'PROOF_CERTIFICATE_REPLAY_PENDING'},
 {'condition':'positive_all_link_harr_product_on_fixed_gapped_omega','first_known':'Paper7A lines 6542–6553 and 6651–6659','used_by':['P7A-254','P7A-256','P7A-259','P7A-261'],'status':'SOURCE_STIPULATED'},
 {'condition':'strictly_positive_real_massive_vectorlike_source_branch','first_known':'Paper7A vectorlike branch 6757–6779, owner earlier P7A source and P7D 202 appendix','used_by':['P7A-258','P7A-259','P7A-263','P7A-264'],'status':'DECLARED_FINITE_BRANCH'},
 {'condition':'uniform_invertible_massless_zero_index_ball','first_known':'Paper7A 6840–6906','used_by':['P7A-261','P7A-262','P7A-263','P7A-264'],'status':'SOURCE_PROVED_CONDITIONALLY'},
 {'condition':'actual_gauge_compatible_same_hamiltonian_source_isometry_APBI','first_known':'Paper7A prior APBI source owner; source-dependent formulation 8649–8670','used_by':['P7A-309','P7A-314'],'status':'OPEN_PHYSICAL_REALIZATION'},
 {'condition':'A5_F40_one_cycle_coherent_frame','first_known':'Paper1C v1_59 v349 theorem; Paper7A 8282–8297','used_by':['P7A-292','P7A-293','P7A-294','P7A-295'],'status':'MATHEMATICAL_SCOPE_ONLY'},
 {'condition':'positive_full_support_pure_harr_link_weight','first_known':'Paper7A 7663–7705','used_by':['P7A-274','P7A-279','P7A-312'],'status':'DECLARED_PURE_GAUGE_MEASURE'},
 {'condition':'conditional_fixed_link_same_one_body_comparison_stencil','first_known':'Paper7A 7420–7453','used_by':['P7A-271','P7A-272','P7A-273','P7A-305'],'status':'SOURCE_COMPARISON_ONLY'},
 {'condition':'physical_HL_vertexwise_su3_action_invariant_truncation','first_known':'Paper7A 8368–8386','used_by':['P7A-298','P7A-309','P7A-314'],'status':'DECLARED_CONDITIONAL'},
]
out=root/'Paper7A-AuditState-Batch5-v1_5.json';out.write_text(json.dumps(s,indent=2,ensure_ascii=False)+'\n')
print('Wrote',out,'size',out.stat().st_size,'new count',s['batch5_status_counts'],'cumulative',s['cumulative_status_counts'],'issues',len(s['issues']),'all',len(s['claims']))
