"""Source-anchored Paper7A Batch3 claim ledger, no source edits. v1_2 -> v1_3."""
import re,hashlib,json,collections
from pathlib import Path
root=Path('/mnt/data/audit7a_work')
source=root/'Papers/Paper7A-QCDKernel-v1_165.tex';s=source.read_text().splitlines();sha=hashlib.sha256(source.read_bytes()).hexdigest()
old=json.loads((root/'Paper7A-AuditState-Batch2-v1_2.json').read_text())
assert sha==old['source_sha256']
# Status, precisely bounded evidence judgment by statement ID.
P={
117:('FORMALIZED','Perturbative inverse clock is a declared fixed-flavor comparison observable, not the native physical strong energy.'),
118:('VERIFIED-CONDITIONAL','E3 direct SU(3) CA=3 and TF=1/2 one-loop coefficient check; running requires fixed nf/perturbative physical matching.'),
119:('REPRODUCED','Exact imported color/heat boundary versus threshold physical mass owner; does not discharge mass/RG scale map.'),
120:('VERIFIED-CONDITIONAL','Finite binary-octahedral quotient and SU3 C⊗C*=1⊕8 decomposition; E36 clock zero explicitly excluded.'),
121:('REPRODUCED','2O/[2O,2O]=C2 and sign character replayed; defect provenance inherited from upstream M8, not re-proved here.'),
122:('VERIFIED','Orthogonal singlet/adjoint projectors on C⊗C* multiply to zero; independent scalar/projector check.'),
123:('REPRODUCED','Separate source deformation and Ward-current observable maps; no asserted equality of the two determinants.'),
124:('FORMALIZED','Legacy coordinate ledger isolated; explicit mass numbers do not become physical Mq eigenvalues.'),
125:('VERIFIED-CONDITIONAL','E3 independent logarithmic derivative and Brent roots at 0.3158981634270 and 0.5510277102129; conditional coordinates.'),
126:('VERIFIED-CONDITIONAL','E3 separate sharp nf=5,4,3 threshold integration yields 0.2843536969782847 GeV on printed comparison branch.'),
127:('REPRODUCED','Usual perturbative matching usable only once actual mass operator, decoupling domain and renormalization scheme supplied; no independent heavy threshold realization.'),
128:('REPRODUCED','Readout/scaling types kept distinct and old E36 identification withdrawn; no equality asserted.'),
129:('VERIFIED-CONDITIONAL','RG ODE separation determines scheme-dependent integration constant for specified beta, thresholds and seed.'),
130:('VERIFIED','Independent dimensional rescaling argument shows 24/15 and finite counts cannot set absolute energy amplitude.'),
131:('VERIFIED','Finite Hodge eigenvalues/moments independent of any dimensional Hamiltonian multiplier; E3 reconstructed spectrum below.'),
132:('VERIFIED-CONDITIONAL','Finite Rayleigh positivity iff positive restricted excitation infimum, on nonempty correctly typed invariant subspace.'),
133:('REPRODUCED','Scale, spectral gap and flux-area readouts are separate maps; no equality or common coefficient inferred.'),
134:('VERIFIED','Explicit K_epsilon eigenvalues 1,1−epsilon on unchanged carrier; no implied positive uniform excitation gap.'),
135:('VERIFIED','E3 independent compact Haar projection proof; only global SU3 invariants, not full local Gauss physical space (BH-G-000138).'),
136:('VERIFIED-CONDITIONAL','Center-character average annihilates r≠0 on global singlet readout; local Gauss interpretation inherits BH-G-000138.'),
137:('VERIFIED','Haar projection onto invariants, including zero-triality adjoint with no trivial summand; purely kinematic scope.'),
138:('VERIFIED-CONDITIONAL','One adjoint gluon has no global SU3-invariant ray; conditional identification with actual local physical state requires Gauss check.'),
139:('VERIFIED-CONDITIONAL','8⊗8 includes singlet, Bose-symmetric delta_ab and two free n=2 modes give 4Eper on specified free quadratic branch; not glueball mass.'),
140:('VERIFIED','Center characters multiply in tensor products; zero triality necessary (not sufficient) for singlet.'),
141:('VERIFIED','Mod-3 quark-minus-antiquark center character implies integer B for color-singlet quark composites.'),
142:('VERIFIED-CONDITIONAL','Quark charges all congruent −1/3 modulo Z, antiquarks +1/3; integer triality implies integer total charge on standard assignments.'),
143:('VERIFIED-CONDITIONAL','Vector phase symmetry gives [H,Qf]=0 if same-action H is vectorlike/diagonal in preserved flavors.'),
144:('VERIFIED','Adjoint has trivial Z3 character, hence cannot screen a lone nonzero-triality source with gluons only.'),
145:('FORMALIZED','Physical Wilson/area sector explicit: unscreened pure-glue for positive fundamental tension, excludes universal full-QCD tension.'),
146:('VERIFIED-CONDITIONAL','E3 center transformation forces <L>=0 in invariant thermal measure; only forward symmetry implication established.'),
147:('VERIFIED','Finite self-adjoint spectrum and ordered E1−E0 gap including ground multiplicity; no continuum conclusion.'),
148:('VERIFIED','Direct spectral calculus of exp[−t(H−E0)] gives strictly positive self-adjoint contraction norm one.'),
149:('REPRODUCED','Reducing-projector and finite Wedderburn provenance inherited from earlier proved generated *-algebra; graph connectivity alone insufficient.'),
150:('VERIFIED-CONDITIONAL','Classical finite cone Perron–Frobenius applies only under positivity-improving cone action; mere positive semidefiniteness is weaker.'),
151:('VERIFIED','E3 fresh reconstruction of 24 vertices,96 edges,96 faces,24 cells, ∂²=0 and full 96×96 face-Hodge spectrum.'),
152:('VERIFIED-CONDITIONAL','E3 spectrum Δ2,H≥I and generalized PSD Rayleigh stiffness; physical QYM form must be supplied nonnegative.'),
153:('FORMALIZED','Geometric face-projector spectral definition valid on C²(K_H); action on H_L is separate unresolved typed bridge BH-G-000143.'),
154:('VERIFIED','Independent rank computation gives H1=H2=0 on 24-cell S3 cellular complex; only linearized gauge statement.'),
155:('VERIFIED','Spectral projector unique for specified interval in face-Hodge carrier; not physical H_L projector by itself.'),
156:('VERIFIED','Finite face Hodge spectral projectors resolve identity; proper scalar shell is not all of face space.'),
157:('UNRESOLVED','Rayleigh quotient and restricted inequality valid if P_sh acts nontrivially on H_L; source only defines P_sh on face cochains; BH-G-000143.'),
158:('UNRESOLVED','Uniform inf-of-Rayleigh equivalence is algebraic but L-family shell projections lack a typed lift to physical H_L; BH-G-000143.'),
159:('VERIFIED-CONDITIONAL','Pure-glue gap does not imply gap on different chiral full-QCD state/limit; Goldstone scenario conditional.'),
160:('REPRODUCED','External convergent cluster expansion area-law result conditional on its actual expansion hypotheses; no native derivation from counts.'),
161:('VERIFIED-CONDITIONAL','Parallel transporter needed to contract two uncontracted separated gauge-charged endpoints; no claim for products of already-local singlets.'),
162:('VERIFIED-CONDITIONAL','Contractible spanning complex with flat connection forces trivial loop holonomy; global topology restriction is essential.'),
163:('VERIFIED','P_I F≠0 exactly says Hodge band activated; no amplitude bound inferred.'),
164:('FORMALIZED','Exact Rayleigh definition on designated nonempty flux-vector domain; positivity remains physical quadratic-form condition.'),
165:('REPRODUCED','Chain embedding, metric area and position Wilson holonomy owner; no live monolithic PAIRxp or positive tension implication.'),
166:('VERIFIED-CONDITIONAL','Rayleigh form inequality by flux kappa on nonempty specified domain; strict positivity not inferred.'),
167:('VERIFIED-CONDITIONAL','E3 direct chain of inequalities gives E≥κ*cA*A under explicitly assumed full-domain coercivity and extent.'),
168:('REPRODUCED','Center support and global singlets alone do not prove a nonlinear area tension; explicit qualifications retained.'),
169:('FORMALIZED','Finite map and continuum handoff as targets; no uniform gap/tension certified by finite structure.'),
170:('VERIFIED','E3 direct finite spectral Gibbs beta→∞ gives P0/rank P0; PF simplicity only on improving transfer cone.'),
171:('VERIFIED-CONDITIONAL','Physical spectral gap −log(qL)/aL on positive duration and positive eigenvalue; uniform limit and OS/cyclicity separate.'),
172:('VERIFIED-CONDITIONAL','E3 independent commuting SU3 center flux distributed over N faces has 8π²/(3N) energy, no area coercivity; map is inherited.'),
173:('REPRODUCED','Exact fixed-Wilson QFT4 and OS spectral static-sector import matched to Paper7C v2.195; state/reflection conditions remain required.'),
174:('UNRESOLVED','E3 all local heat/triality numeric constants and polynomial checks pass, but claimed full normalized polymer/handle-to-tree bound is not independently certified; BH-G-000144.'),
175:('UNRESOLVED','Finite-type monotone supersolution implication on rooted trees algebraically holds; extension to all connected polymers and Wilson expectation inherits BH-G-000144.'),
176:('VERIFIED-CONDITIONAL','E3 native triangle/ribbon equal-heat four numerical supersolution margins reproduced; does not prove physical equal heat or APBI.'),
177:('UNRESOLVED','Physical area conversion A≤A+ Acell valid under APBI, but full connected surface inequality inherits missing independent proof step BH-G-000144.'),
178:('UNRESOLVED','Square APBC specialization and physical-area conversion algebraically correct, but source-level full surface majorant obligation BH-G-000144 remains.'),
179:('FORMALIZED','APBI same-owner nonlinear action presentation remains explicit open physical bridge; does not treat a chart or one-face subdivision as proof.'),
180:('REPRODUCED','Imported native Paper5B carrier support theorem is separate from optional QCD continuum-gap branch; physical transfer scaling and QFT4/OS are conditional.'),
}
assert len(P)==64
rows=[]
for idx,line in enumerate(s,1):
 if not (3944<=idx<=4946):continue
 m=re.search(r'\\begin\{(theorem|lemma|proposition|corollary|definition|remark)\}(?:\[(.*)\])?',line)
 if not m:continue
 t=m.group(1);title=m.group(2) or '';e=idx
 while e<=len(s) and r'\end{'+t+'}' not in s[e-1]:e+=1
 assert e<=4946,(idx,e,title)
 lab=next((re.search(r'\\label\{([^}]+)\}',s[x-1]).group(1) for x in range(idx,e+1) if re.search(r'\\label\{([^}]+)\}',s[x-1])),f'NO_LABEL_AT_{idx}')
 proof=None;nx=e+1
 while nx<len(s) and not s[nx-1].strip():nx+=1
 if s[nx-1].strip().startswith(r'\begin{proof}'):
  py=nx
  while py<len(s) and r'\end{proof}' not in s[py-1]:py+=1
  proof=[nx,py]
 n=117+len(rows);status,note=P[n]
 issues=[]
 if n in (153,157,158):issues+=['BH-G-000143']
 if n in (174,175,177,178):issues+=['BH-G-000144']
 if n in (135,136,138):issues+=['BH-G-000138']
 rows.append({'id':f'P7A-{n:03d}','source_label':lab,'source_aliases':[a for x in range(idx,e+1) for a in re.findall(r'\\label\{([^}]+)\}',s[x-1]) if a!=lab],'type':t,'title':title,'statement_lines':[idx,e], 'proof_lines':proof,'source_sha256':sha,'source_status':'SOURCE-AS-PRINTED','status':status,'evidence_summary':note,'issues':issues})
assert len(rows)==64 and rows[0]['statement_lines'][0]==3962 and rows[-1]['statement_lines'][0]==4924
# Persistent issue IDs allocated after the prior 9 unique issues.
issues=[
{'id':'BH-G-000143','severity':'moderate','source_label':'p10:thm:primitive-scalar-shell-coefficient-fixed','statement_layer':'SOURCE-AS-PRINTED',
 'first_origin':{'paper':'Paper7A','theorem_id':'p10:thm:primitive-scalar-shell-coefficient-fixed','step_locator':'Paper7A-QCDKernel-v1_165.tex:1208-1215 (first occurrence), 4375-4377, 4407-4417 (confirmation)','source_excerpt':r'\inf_{\substack{\psi\in P_{{\rm sh},L}\mathcal H_L\\\|\psi\|=1}}'},
 'class':'TYPE_OR_DOMAIN','lifecycle':'OPEN','issue_status':'unresolved',
 'exact_obligation':'Identify a licensed operator representation/lift of the 96-dimensional face-Hodge projector 1_I(Delta_2,H) on the compiled physical Hilbert space H_L for each L, with compatible domains and a nonzero shell range; then state its interaction with H_L (invariant or explicitly restricted Rayleigh).',
 'why_it_matters':'Delta_2,H acts on cellular face two-cochains, whereas H_L is the full finite quantum/gauge/Fock Hilbert space. The expression P_sh,L H_L and its gap Rayleigh test are not well-typed solely from the geometric projector definition. This does not refute the 96×96 Hodge spectrum, spectral projection, or a conditional restricted Rayleigh inequality.',
 'source_replayed':True,'independent_evidence':['EV-P7A-B03-HODGE','EV-P7A-B03-DOMAIN'], 'adversarial_evidence':['EV-P7A-B03-E4'], 'constitution_boundary':'BND-P7A-006','conditions_consumed':[],'conditions_open':[],
 'upstream_material_paths':[['p10:thm:finite-plaquette-hodge-curvature-hessian','p10:thm:scalar-shell-primitive-curvature-norm','p10:thm:primitive-scalar-shell-coefficient-fixed']],
 'downstream_verified_paths':[['p10:thm:primitive-scalar-shell-coefficient-fixed','p10:lem:scalar-shell-transfer-domination','p10:thm:uniform-scalar-shell-transfer-gap']],
 'other_papers_affected':[], 'possible_unconfirmed_impacts':['Paper7B/Hadronic scalar-shell readout if it identifies physical shell energies via P_sh,L'],
 'verified_bypass_routes':['Geometric Hodge eigenspaces and their full spectrum are certified independently without a physical shell-to-state map'],
 'resolution_requirement':'Provide source evidence for the typed Hodge-to-state projection/intertwiner and retained physical shell carrier, or explicitly treat the Rayleigh as a conditional target until that map is available; do not infer it from equal notation.',
 'audit_scope_limit':'Previously audited P7A-041 already inconsistent for independent issues BH-G-000136/137; this is a distinct typed-cross-carrier finding located retrospectively at its earliest actual occurrence.',
 'evidence_details':'Exact source search finds P_sh,L defined by face Delta_2,H at 4377 and 4393 and applied to H_L at 1214 and 4411, while H_L is the full generated algebra carrier at 1133 and may include Fock operators. No face-to-H_L lift or second quantization is specified in the inspected current Paper7A source. E3 24-cell Hodge spectrum reconstructed separately; E4 2×2 example demonstrates that even with a typed P the inequality H−E0≥kP is valid only on P-range absent reducing hypothesis, a qualification the current statement explicitly retains.'},
{'id':'BH-G-000144','severity':'major','source_label':'p10:thm:v2155-triality-branch-core-majorant','statement_layer':'SOURCE-AS-PRINTED',
 'first_origin':{'paper':'Paper7A','theorem_id':'p10:thm:v2155-triality-branch-core-majorant','step_locator':'Paper7A-QCDKernel-v1_165.tex:4662-4695, especially 4685-4695','source_excerpt':'The rooted-tree recursion therefore dominates the complete connected surface sum.'},
 'class':'LOGICAL_GAP','lifecycle':'OPEN','issue_status':'unresolved',
 'exact_obligation':'Prove that the explicit neutral/charged monotone recursion and heat trace-tail/corridor bounds control every connected SU(3) Peter–Weyl surface contribution, including cycles, handles, neutral vacuum decorations, tensor-contraction multiplicities and normalization of the full finite Wilson expectation, with a perimeter-only constant uniform in surface area and APBI levels.',
 'why_it_matters':'The scalar heat bounds u,v, q±, q0* and local supersolutions are independently correct. But the short proof does not supply a checkable full graph-to-rooted-tree majorization and normalized measure/linked-cluster estimate for the stated all-genus, all-representation Wilson claim. Therefore the positive area exponent and the APBI/APBC consequences cannot be certified solely by the local numeric checks.',
 'source_replayed':True,'independent_evidence':['EV-P7A-B03-SURFACE-NUMERIC'], 'adversarial_evidence':['EV-P7A-B03-E4'], 'constitution_boundary':'BND-P7A-007','conditions_consumed':[],'conditions_open':[],
 'upstream_material_paths':[['p10:cor:v185-common-heat-face-stiffness','p10:thm:v2155-triality-branch-core-majorant']],
 'downstream_verified_paths':[['p10:thm:v2155-triality-branch-core-majorant','p10:cor:v2155-apbc-string-tension-reduction'],['p10:thm:v2155-triality-branch-core-majorant','p10:thm:v2158-finite-type-triality-branch-core','p10:cor:v2158-apbi-string-tension-reduction']],
 'other_papers_affected':[], 'possible_unconfirmed_impacts':['Paper7C p12:thm:v2158-same-owner-apbi-bridge uses Paper7A finite-type bound conditionally','Paper7B positive Wilson string-tension readout if this route is invoked'],
 'verified_bypass_routes':['Paper7A explicitly permits an alternative direct same-owner multiface/flux/cluster estimate; that alternative has not been proved in this batch'],
 'resolution_requirement':'Source-match a full finite normalized Wilson polymer expansion and a uniform tree/cycle-cut counting bound with precise local type map and face-time decay. Provide independently reproducible finite test controls or theorem citations proving the all-connected-graph step; no new framework claim is to be introduced by the auditor.',
 'audit_scope_limit':'UNRESOLVED proof step, not a counterexample to area laws and not a claim that numerical branch data or APBI conditions are false. The APBI physical existence obligation is already explicitly conditional and is not this issue.',
 'evidence_details':'E3 direct SU3 Peter–Weyl sums: u=0.02158988060835, v=0.00017867469177, q±=0.19682346534 (<0.197), q0*=0.01144163903 (<0.012), Phi5=0.43189268292 (<0.45); two-type 4 inequalities exact. The manuscript states but does not derive an injective/equivalence-class cycle-cut assignment or vacuum denominator bound. E4 checked distinction of local recursion convergence versus full normalized all-genus Wilson expectation; no in-domain counterexample produced.'}
]
state=old.copy()
state.update({'batch':3,'audited_through_line':4946,'formal_covered':180,'formal_remaining':134,'unnamed_material_checked':3,'current_status':'PARTIALLY_AUDITED_WITH_OPEN_ISSUES','claims':old['claims']+rows,'issues':old['issues']+issues,
'unreviewed':['134 formal statements from the chiral/CP/topological section beginning at line 4960 and remaining appendices through line 8831 remain unaudited. No complete Paper7A verdict and no final ZIP release.']})
state['claims'][40]['issues']=list(dict.fromkeys(state['claims'][40]['issues']+['BH-G-000143']))
state['claims'][40]['evidence_summary'] += ' Retrospective distinct typed face-Hodge-to-H_L projection concern BH-G-000143 found in Batch 3.'
state['evidence_records']=old['evidence_records']+[
 {'id':'EV-P7A-B03-E1','tier':'E1','details':'All 64 formal source blocks P7A-117..180 lines 3962–4943 read against their proofs, guards and source cross-references. Current Paper7C exact QFT4_E/C, Wilson static OS, APBI scope read only for direct imports.'},
 {'id':'EV-P7A-B03-HODGE','tier':'E3','details':'Independent 24-cell combinatorial reconstruction using 24 permutations of (±1,±1,0,0), 96 oriented edges, 96 triangles, 24 octahedral facets and boundary complexes with ∂2∂3=0; exact 96x96 face Hodge eigenmultiplicities and trace 480 recovered.','script':'audit7a_work/check_batch3_geometry.py','results':'audit7a_work/batch3_geometry_check.json'},
 {'id':'EV-P7A-B03-SURFACE-NUMERIC','tier':'E3','details':'Independent Brent roots of legacy inverse clocks; sharp threshold clock; complete SU3 triality trace tails up to p,q<24; exact rooted Φ5, native 2-type supersolutions; center-flux N-face Hilbert–Schmidt energy. Numerical E3 establishes only local/comparison results, not all-graph proof.','script':'audit7a_work/check_batch3_numerics.py','results':'audit7a_work/batch3_independent_checks.json'},
 {'id':'EV-P7A-B03-DOMAIN','tier':'E1','details':'Cross-carrier source exact types: Delta_2,H explicitly defined on 96 face cochains, P_sh,L applied to full H_L at 1214/4411; no Hodge-to-quantum-state projection supplied in Paper7A.'},
 {'id':'EV-P7A-B03-IMPORT','tier':'E1','details':'Paper7C v2.195 lines 3846–3971 gives QFT4 conditional state, Wilson static sector and same-owner APBI; Paper7A 3033–3058 independently warns heat subdivision cannot manufacture area fugacity; Paper7A 4276–4294 separates pure-glue tension from dynamical fundamental screening.'},
 {'id':'EV-P7A-B03-E4','tier':'E4','details':'Challenges: explicit 2x2 self-adjoint H and rank-one P gives min eig(H−kP)<0 while restricted Rayleigh holds, so printed qualifier prevents false global counterexample. Center flux spread 8π²/(3N) validates non-extensivity warning. Local heat supersolutions do not by themselves certify full normalized cycle/handle Wilson bound; no valid in-domain refutation constructed.'},
]
state['boundary_records']=old['boundary_records']+[
 {'id':'BND-P7A-006','type':'face_vs_fock_shell_domains','source':'Paper7A lines 1133, 1208–1225, 4344–4377, 4391–4429','sort':'geometric face-cochain Hodge P vs finite gauge-quark/Fock Hamiltonian carrier H_L','realization':'Only face cochain spectral projector is proved. A physical state-space shell action/lift must be explicitly typed before applying P to H_L; shell nonemptiness also inherited BH-G-000136.','provenance':['[GEN] 24-cell face Hodge on C²(K_H)','[DER] spectral projector on face space','[REAL] P_sh,L acting on physical H_L unresolved']},
 {'id':'BND-P7A-007','type':'surface_area_owner_vs_conditional_apbi','source':'Paper7A lines 4276–4294, 4580–4922; Paper7C lines 3885–3989','sort':'finite SU3 single-face heat and local recursion vs complete nonlinear same-action face presentation vs normalized Wilson state and macroscopic area','realization':'Same-owner APBI remains an explicit condition; local branch supersolution is numerical check, and its extension to all full-surface/normalized expectations is separately unresolved BH-G-000144. Pure-glue/unscreened sector only.','provenance':['[CONST] current SU3 heat member','[DER] local Peter–Weyl triality tails/recursions','[REAL] APBI on extensive same owner conditional','[DER] full connected polymer bound unresolved','[ID] physical metric-area conversion conditional']}
]
state['batch3_status_counts']=dict(collections.Counter(r['status'] for r in rows))
state['cumulative_status_counts']=dict(collections.Counter(r['status'] for r in state['claims'] if r['type']!='unnamed_material_derivation'))
state['batch3_condition_uses']=[
 {'condition':'fixed_nf_perturbative_branch','first_known':'Paper7A 3962; earlier G16 RG source to trace in final DAG','used_by':['P7A-117','P7A-118','P7A-126'],'status':'CONDITIONAL'},
 {'condition':'physical_quark_mass_and_RG_scale_map','first_known':'Paper5A/5B/5C owner; already inherited in P7A batch 1','used_by':['P7A-119','P7A-127','P7A-129'],'status':'OPEN_PHYSICAL_INTERFACE'},
 {'condition':'local_Gauss_vs_global_Haar_readout','first_known':'Paper7A 1322 / BH-G-000138','used_by':['P7A-135','P7A-136','P7A-138','P7A-139'],'status':'OPEN_PHYSICAL_INTERFACE'},
 {'condition':'typed_nonempty_Hodge_shell_on_quantum_carrier','first_known':'Paper7A 1208 / BH-G-000136 + BH-G-000143','used_by':['P7A-157','P7A-158'],'status':'UNRESOLVED'},
 {'condition':'positive_coercive_unscreened_flux_and_extent','first_known':'Paper7A 4276; 4472; 4517','used_by':['P7A-164','P7A-166','P7A-167'],'status':'CONDITIONAL'},
 {'condition':'QFT4_OS_static_sector_and_physical_step','first_known':'Paper7C v2.195 bounded state/reflection results','used_by':['P7A-171','P7A-173','P7A-177','P7A-178'],'status':'CONDITIONAL'},
 {'condition':'same_owner_APBI_and_branch_supersolution','first_known':'Paper7A 4622, 4842; Paper7C 3939–3989','used_by':['P7A-174','P7A-175','P7A-176','P7A-177','P7A-178'],'status':'CONDITIONAL'},
]
assert len([r for r in state['claims'] if r['type']!='unnamed_material_derivation'])==180
assert len(state['issues'])==11
out=root/'Paper7A-AuditState-Batch3-v1_3.json';out.write_text(json.dumps(state,indent=2,ensure_ascii=False));print('WROTE',out,out.stat().st_size,'batch',state['batch3_status_counts'],'cumulative',state['cumulative_status_counts'],'issues',len(state['issues']))
