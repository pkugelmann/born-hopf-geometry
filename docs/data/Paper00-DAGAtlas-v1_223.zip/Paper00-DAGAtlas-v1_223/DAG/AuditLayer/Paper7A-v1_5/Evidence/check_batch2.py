"""Independent mathematical controls for Paper7A batch 2; not a physical model calibration."""
import json, numpy as np, math
from numpy.linalg import eigvalsh, norm
from scipy.optimize import brentq
from pathlib import Path
r={};
# SU3 irreps p,q, Weyl dimension and spectral Casimir; cut at total p+q<=18
reps=[]
for p in range(25):
 for q in range(25):
  C=(p*p+q*q+p*q+3*p+3*q)/3
  d=(p+1)*(q+1)*(p+q+2)//2
  reps.append((p,q,d,C))

def moments(t):
 w=np.array([d*d*np.exp(-t*C/2) for p,q,d,C in reps]); c=np.array([C for p,q,d,C in reps]);
 z=w.sum(); m=(w*c).sum()/z; var=(w*c*c).sum()/z-m*m
 return z,m/8,-var/16
k_target=1/(2*np.pi**2)
tstar=brentq(lambda t:moments(t)[1]-k_target,3,8,xtol=1e-14)
z,h,hp=moments(tstar); k4=(h*h+hp+h/4)/40
r['native_heat']={'target_h':k_target,'t_iso':tstar,'h':h,'hprime':hp,'quartic_k4':k4,'root_residual':abs(h-k_target)}
a=(np.pi**2-6)/(np.pi**2-3);b=np.pi**2/(np.pi**2-3)
N=96; epsN=(25*N/14)*(4e-117)*(18/7)**(N-1)
r['native_heat_bounds']={'a':a,'b':b,'eps96':epsN,'a_gt_14_25':bool(a>14/25),'b_lt_36_25':bool(b<36/25),'epsilon_bound':bool(epsN<6.35e-76)}
# Native 24-dim mirror-spin block algebra, on W_m+W_n with U eigenvalues +/-1(2 each) and Q=U^2
u=np.diag([1.,1.,-1.,-1.,0.,0.]); Q=u@u
T=np.array([[1,0,0,0],[0,-1,2,0],[0,2,-1,0],[0,0,0,1]],dtype=float)
a0,b0,k0=5.1,0.7,0.19
M=a0*np.eye(24)+b0*np.kron(u,np.eye(4))+k0*np.kron(Q,T)
computed=np.sort(eigvalsh(M)); declared=np.sort(np.array([a0]*8+[a0+b0-3*k0]*2+[a0-b0-3*k0]*2+[a0+b0+k0]*6+[a0-b0+k0]*6))
r['mirror_spin']={'spectrum_error':float(norm(computed-declared)),'trace':float(np.trace(M)),'trace_predicted':24*a0,'second_moment':float(np.trace((M-a0*np.eye(24))@(M-a0*np.eye(24)))),'second_predicted':16*b0*b0+48*k0*k0}
# direct SU3 three-face baryon identity via epsilon-epsilon; separate polarization polynomial
import itertools
rng=np.random.default_rng(716)
A,B,C=[rng.normal(size=(3,3))+1j*rng.normal(size=(3,3)) for _ in range(3)]
from sympy import LeviCivita
left=0j
for i,j,k in itertools.product(range(3),repeat=3):
 for a,b,c in itertools.product(range(3),repeat=3):
  left+=float(LeviCivita(i,j,k)*LeviCivita(a,b,c))*A[i,a]*B[j,b]*C[k,c]/6
right=(np.trace(A)*np.trace(B)*np.trace(C)-np.trace(A)*np.trace(B@C)-np.trace(B)*np.trace(A@C)-np.trace(C)*np.trace(A@B)+np.trace(A@B@C)+np.trace(A@C@B))/6
r['three_face_epsilon']={'equality_abs_error':float(abs(left-right))}
# Gauss overlap GW identity, arbitrary finite gamma5-balanced Hermitian sign involution
from scipy.linalg import eigh
G5=np.diag([1,1,-1,-1]); E=rng.normal(size=(4,4))+1j*rng.normal(size=(4,4)); H=(E+E.conj().T)/2
w,v=eigh(H); s=(v*np.sign(w))@v.conj().T; ao=0.37; D=(np.eye(4)+G5@s)/ao
r['GW']={'sign_involution_resid':float(norm(s@s-np.eye(4))),'GW_resid':float(norm(G5@D+D@G5-ao*D@G5@D)),'index_minus_half_trace_eps':float(-np.trace(s).real/2)}
# Explicit spectral-positivity distinction for central U(1) w=1-eps*cos(2theta)
theta=np.linspace(0,2*np.pi,8192,endpoint=False); epsilon=0.4; w=1-epsilon*np.cos(2*theta)
coeff2=(w*np.cos(2*theta)).mean()
r['positive_type_control']={'density_min':float(w.min()),'negative_second_fourier_coefficient':float(coeff2)}
# Ward finite QCD same-source identity on 2x2 noncommuting Hermitian source
from scipy.linalg import expm
H0=np.array([[0.4,0.12],[0.12,1.8]]);Ha=np.array([[0.3,.09],[.09,-.2]]);Hb=np.array([[.7,.2],[.2,-.35]])
Qop=np.array([[0.,1.],[1.,0.]]);beta=2.4
J=.08
H=H0+J*Ha+(J**2/2)*Hb
R=Ha+J*Hb-1j*(Qop@H-H@Qop)
Z=np.trace(expm(-beta*H)).real; rho=expm(-beta*H)/Z
W_prime=-beta*np.trace(rho@R).real
c0=np.trace(rho@R).real
# W(J)=derivative of logZ along v=1 (v-source first-derivative) use centered numerical derivative
hstep=1e-5
def dlogZ(x):
 return np.log(np.trace(expm(-beta*(H0+x*Ha+(x*x/2)*Hb))).real)
W_num=(dlogZ(J+hstep)-dlogZ(J-hstep))/(2*hstep)
r['Ward']={'first_w_error':abs(W_num-W_prime),'mean_commutator':float(np.trace(rho@(1j*(Qop@H-H@Qop))).real)}
# Null test finite commuting H,P on same carrier and nontrivial q0, finite C^1 time integrals via quadrature.
P=np.diag([1.,0.]);Hc=np.diag([2.,1.]);q=np.array([[0.,1.],[1.,0.]])
# q0(Phi_H(-r)) as conjugation, verifies null group multiplication pointwise
s=.43;c=1.8;hbar=1.; U=np.diag(np.exp(-1j*s*(np.diag(Hc)/c+np.diag(P))/np.sqrt(2)))
# E3 direct commutation + spectral period for U
r['null_generator']={'generator_commutator':float(norm(Hc@P-P@Hc)),'unitarity_error':float(norm(U@U.conj().T-np.eye(2)))}
# Schur compression leakage on arbitrary finite Hermitian 8x8
Z=rng.normal(size=(8,8))+1j*rng.normal(size=(8,8)); K=(Z+Z.conj().T)/2
Qv,_=np.linalg.qr(rng.normal(size=(8,3))+1j*rng.normal(size=(8,3)))
Proj=Qv@Qv.conj().T; E=Qv.conj().T@K@Qv; L=(np.eye(8)-Proj)@K@Qv
r['compression_leakage']={'identity_residual':float(norm(Qv.conj().T@K@K@Qv -E@E-L.conj().T@L)), 'leakage_nonnegative':bool(eigvalsh(L.conj().T@L).min()>-1e-10)}
# Discrete real positive-weight independent check of the complete blocked Hessian
values=np.array([-1.2,0.5,1.8]); weights=np.array([.2,.3,.5]);
def act(j,k):
 return 0.2*values**2+j*values+0.5*k*values**2+j*k*np.sin(values)
def A(j,k):
 return -np.log(np.sum(weights*np.exp(-act(j,k))))
j,k=.31,-.13;hs=1e-4
W=weights*np.exp(-act(j,k));W=W/W.sum()
Sa=values+k*np.sin(values);Sb=.5*values**2+j*np.sin(values);Sab=np.sin(values)
cent=lambda x:x-np.sum(W*x)
ana_a=np.sum(W*Sa);ana_ab=np.sum(W*Sab)-np.sum(W*cent(Sa)*cent(Sb))
num_a=(A(j+hs,k)-A(j-hs,k))/(2*hs)
num_ab=(A(j+hs,k+hs)-A(j+hs,k-hs)-A(j-hs,k+hs)+A(j-hs,k-hs))/(4*hs*hs)
r['blocked_source_jets']={'first_error':float(abs(ana_a-num_a)),'mixed_second_error':float(abs(ana_ab-num_ab)),'source_contact':float(np.sum(W*Sab)),'covariance':float(np.sum(W*cent(Sa)*cent(Sb)))}
# Ward differentiated identity via spectral logarithmic means
H=H0+J*Ha+(J**2/2)*Hb;U,eigv=np.linalg.eigh(H)
probs=np.exp(-beta*U);probs=probs/probs.sum()
E=eigv.conj().T@R@eigv;B=eigv.conj().T@(Ha+J*Hb)@eigv
R_b=Hb-1j*(Qop@(Ha+J*Hb)-(Ha+J*Hb)@Qop)
Acent=E-np.eye(2)*np.sum(probs*np.diag(E));Bcent=B-np.eye(2)*np.sum(probs*np.diag(B))
C=0j
for i in range(2):
 for k in range(2):
  pm,pn=probs[i],probs[k]
  lm=(pm-pn)/(np.log(pm)-np.log(pn)) if i!=k else pm
  C+=lm*Acent[i,k]*Bcent[k,i]
ana_W2=-beta*np.trace(rho@R_b).real+beta**2*C.real
hstep=1e-4
num_W2=(dlogZ(J+hstep)-2*dlogZ(J)+dlogZ(J-hstep))/(hstep*hstep)
r['Ward']['second_response_error']=float(abs(ana_W2-num_W2));r['Ward']['Kubo_Mori_covariance']=float(C.real)
out=Path('/mnt/data/audit7a_work/batch2_independent_checks.json');out.write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
