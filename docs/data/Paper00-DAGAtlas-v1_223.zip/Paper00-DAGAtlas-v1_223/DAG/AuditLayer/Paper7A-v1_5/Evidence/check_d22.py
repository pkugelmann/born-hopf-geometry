import numpy as np, json
from pathlib import Path
# Independent Weyl-torus projection using SU3 characters through Jacobi-Trudi Schur polynomials.
N=96
x,y=np.meshgrid(2*np.pi*np.arange(N)/N,2*np.pi*np.arange(N)/N,indexing='ij')
z1=np.exp(1j*x);z2=np.exp(1j*y);z3=1/(z1*z2)
e1=z1+z2+z3;e2=z1*z2+z1*z3+z2*z3;e3=1
h=[np.ones_like(z1),e1]
for n in range(2,23):h.append(e1*h[-1]-e2*h[-2]+e3*h[-3] if n>=3 else e1*h[1]-e2)
# corrections to recursion h_2 = e1 h1 - e2, h_3=e1 h2 - e2 h1 + 1
# compute explicitly again to avoid error
h=[np.ones_like(e1)];
for n in range(1,23):
 v=e1*h[n-1]
 if n>=2:v=v-e2*h[n-2]
 if n>=3:v=v+h[n-3]
 h.append(v)
Delta=(z1-z2)*(z1-z3)*(z2-z3)
haar=(Delta*Delta.conj()).real/6
assert abs(haar.mean()-1)<1e-13
chars=[];dims=[];cas=[]
for p in range(10):
 for q in range(10):
  chi=h[p+q]*h[q]-(h[p+q+1]*h[q-1] if q>=1 else 0)
  d=(p+1)*(q+1)*(p+q+2)/2
  c=(p*p+q*q+p*q+3*p+3*q)/3
  chars.append(chi);dims.append(d);cas.append(c)
results=[]
for t in [2.0,3.0,4.420998862,5.75329584663306,6.0]:
 K=np.zeros_like(e1);Kd=np.zeros_like(e1)
 for chi,d,c in zip(chars,dims,cas):
  term=d*np.exp(-t*c/2)*chi
  K+=term;Kd-=0.5*c*term
 Z=(haar*K**3).mean();Zp=(haar*3*K*K*Kd).mean();k=-Zp/Z/12
 results.append({'t':t,'Z3':float(Z.real),'k':float(k.real),'imagZ':float(Z.imag)})
p=Path('/mnt/data/audit7a_work/batch2_d22_weyl_check.json');p.write_text(json.dumps({'grid':N,'max_p_q':9,'method':'independent Weyl torus quadrature with characters from Schur recurrence','results':results},indent=2));print(p.read_text())
