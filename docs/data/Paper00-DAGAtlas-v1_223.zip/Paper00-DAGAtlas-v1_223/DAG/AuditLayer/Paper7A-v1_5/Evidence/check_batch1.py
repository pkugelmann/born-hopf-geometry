from fractions import Fraction as F
from itertools import product
from collections import Counter
import numpy as np, sympy as s, json
out={}
V=[(a,0,0,0) for a in [-1,1]]
for i in range(1,4):
 for a in [-1,1]:
  v=[0,0,0,0];v[i]=a;V.append(tuple(v))
V += [tuple(F(a,2) for a in signs) for signs in product([-1,1],repeat=4)]
assert len(V)==24
A=s.zeros(24)
for i,a in enumerate(V):
 for j,b in enumerate(V):
  if i!=j and sum(x*y for x,y in zip(a,b))==s.Rational(1,2):A[i,j]=1
out['hurwitz_vertex_count']=len(V)
out['hurwitz_degree_distribution']={str(k):int(v) for k,v in Counter(sum(A[i,j] for j in range(24)) for i in range(24)).items()}
out['adjacency_eigenvalues_exact']={str(k):v for k,v in A.eigenvals().items()}
idx=V.index((1,0,0,0))
nbr=[V[j] for j in range(24) if A[idx,j]==1]
# Tangent unit direction = 2/sqrt(3) * imaginary components
N=np.array([[float(2*s.sqrt(s.Rational(1,3))*x) for x in p[1:]] for p in nbr])
out['cube_neighbor_tangent_vectors']=N.tolist()
out['cube_first_moment']=N.sum(axis=0).round(12).tolist()
out['cube_second_moment']=(N.T@N).round(12).tolist()
# checks 24-cell octahedral/triangles count; graph is 8-regular => 96 edges
out['edge_count']=int(sum(A)/2)
# Schur with fixed split H, O and h
rng=np.random.default_rng(7511)
B=rng.normal(size=(5,5));H=B+B.T; Q=rng.normal(size=(5,5));O=Q+Q.T
E,U=np.linalg.eigh(H);ind=1; e=E[ind]; ufull=U[:,ind]
# choose complement so e outside C spectrum
n=3; A0=H[:n,:n]; X=H[:n,n:];Y=X.T;C=H[n:,n:];R=np.linalg.inv(C-e*np.eye(2))
u=ufull[:n];norm=u@u + u@(X@R@R@Y)@u
F=A0-e*np.eye(n)-X@R@Y
Z=np.eye(n)+X@R@R@Y
Oeff=O[:n,:n]-O[:n,n:]@R@Y-X@R@O[n:,:n]+X@R@O[n:,n:]@R@Y
energy_minus_O=float(-ufull@O@ufull)
energy_pred=float(-u@Oeff@u/(u@Z@u))
out['schur_residual']=float(np.linalg.norm(F@u));out['schur_norm']=float(norm);out['schur_energy_derivative_pred_vs_full']=[energy_pred,energy_minus_O]
# contrast scalar-shell source claim: P noncommuting with H
H2=np.diag([0., 4.]);P=np.array([[.5,.5],[.5,.5]])
w=np.array([1.,1.])/np.sqrt(2)
gamma=float(w@H2@w)
t=1
real=float(w@np.diag(np.exp(-np.array([0.,4.])))@w)
out['scalar_shell_countertest']={'H':H2.tolist(),'P':P.tolist(),'rayleigh_gamma':gamma,'nominal_e_minus_t_gamma':np.exp(-gamma*t),'actual_compressed_transfer_eigenvalue':real}
# source response check H(j)=H0-jO + j*j/2 C
H0=np.diag([0.,3.]);O2=np.array([[0.,1.],[1.,0.]]);contact=np.diag([4.,0.]);eps=1e-4
def eigen(j):return float(np.linalg.eigvalsh(H0-j*O2+j*j*contact/2)[0])
curv=(eigen(eps)-2*eigen(0)+eigen(-eps))/eps**2
out['susceptibility_contact_test']={'chi_spectral_only':2/3,'minus_E_ground_second_deriv_with_contact':-curv,'ground_contact_term':float(contact[0,0])}
# exact monomial singlet normalization f_abc f_abc=24 and dabc dabc=40/3 for TrT^a T^b=delta/2
out['known_su3_tensors']={'f2':24,'d2':40/3,'ggg_f_norm':1/np.sqrt(24),'ggg_d_norm':np.sqrt(3/40)}
open('/mnt/data/audit7a_work/batch1_independent_checks.json','w').write(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
# Additional independent source-layer tests, exact algebraic witnesses
z=s.symbols('z',real=True)
Hcontact=s.Matrix([[2*z*z,-z],[-z,3]])
# Eground = (tr H -sqrt((a-c)^2 + 4z^2))/2
trace=Hcontact.trace();diff=Hcontact[0,0]-Hcontact[1,1]
Eground=(trace-s.sqrt(diff**2+4*z*z))/2
print('ground_E2',s.diff(Eground,z,2).subs(z,0))
# zero-contact susceptibility 2 |<0|sigma_x|1>|^2/3 = 2/3
# on degenerate ground H=diag(0,0,3), H(z) has ±|z| ground branches => no 2nd derivative
# noninvariant projector transfer counterexample exact e^-2 != (1+e^-4)/2
print('PexpHP', '(1+exp(-4))/2 vs exp(-2)')
# strict source sign: 1x1 K(J)=e^-J, O=-d log K =1, dW=-1
print('source_sign',{'operator_from_negative_log':1,'Wprime':-1})
# fixed Dirac Schur trace and derivative identity under arbitrary complex Hermitian K
rng=np.random.default_rng(314159);B=rng.normal(size=(4,4))+1j*rng.normal(size=(4,4));K=B+B.conj().T;m=2.0;n=2
EQ=m*np.eye(2)+1j*K[n:,n:];X=K[:n,n:];Y=K[n:,:n]
SE=m*np.eye(2)+1j*K[:n,:n]+X@np.linalg.inv(EQ)@Y
whole=m*np.eye(4)+1j*K
lhs=np.trace(np.linalg.inv(whole));rhs=np.trace(np.linalg.inv(EQ))+np.trace(np.linalg.inv(SE)@(np.eye(2)-X@np.linalg.matrix_power(np.linalg.inv(EQ),2)@Y))
print('dirac_trace_error',abs(lhs-rhs),'det_error',abs(np.linalg.det(whole)-np.linalg.det(EQ)*np.linalg.det(SE)))
