"""Batch4 rigorous source-first ledger, exact frozen Paper7A v1_165; append only to cumulative state."""
import json,re,hashlib,collections
from pathlib import Path
root=Path('/mnt/data/audit7a_work')
source=root/'Papers/Paper7A-QCDKernel-v1_165.tex';lines=source.read_text().splitlines();sha=hashlib.sha256(source.read_bytes()).hexdigest()
old=json.loads((root/'Paper7A-AuditState-Batch3-v1_3.json').read_text());assert sha==old['source_sha256']
P={
181:('VERIFIED','SU(3)_L×SU(3)_R bifundamental and identity stabilizer SU(3)_V verified by direct matrix action; source order parameter is not an established condensate.'),
182:('VERIFIED','Direct one-dimensional-character proof: connected semisimple SU(3)×SU(3) has no nontrivial character, so a unique invariant ground ray cannot spontaneously break it.'),
183:('UNRESOLVED','8=8+8−8 broken-generator count correct after stated SSB stabilizer; massless excitations require a local/positive QFT current-and-spectrum Goldstone theorem domain not discharged by condensate limit alone (BH-G-000145).'),
184:('VERIFIED-CONDITIONAL','Anomalous U(1)_A is not exact when anomaly survives; excludes singlet from 8 Goldstone count. Physical anomaly existence remains scoped.'),
185:('VERIFIED','Ward current/charge normalization is algebraically distinct from normalized one-Goldstone F_pi residue; no count-only F_pi inference.'),
186:('FORMALIZED','Lorentz covariant axial matrix-element definition on a supplied normalized one-pion state; finite approximants only on licensed correlator branch.'),
187:('VERIFIED-CONDITIONAL','Spectral insertion gives squared axial vacuum-to-Goldstone residue under local/current-state normalization and a Goldstone pole; existence branch inherits BH-G-000145.'),
188:('REPRODUCED','Standard PCAC/GMOR identity imported with analytic chiral/ordered-limit conditions, and B0=Sigma/F_pi². Printed O(mq²) depends on explicitly stated analyticity rather than uncontrolled chiral logs.'),
189:('VERIFIED','Inverse of an invertible finite Hessian unique on the specified tangent block; not scalar numerical prediction.'),
190:('VERIFIED','Adjoint octet SU(3)_V irreducible over C; Schur implies real d I8 for a Hermitian equivariant Hessian; delta_geom not fixed.'),
191:('VERIFIED-CONDITIONAL','Chiral leading mass-source coefficient defined by Sigma/F_pi² only if physical ordered Sigma and finite nonzero F_pi are supplied; not a geometric scale.'),
192:('VERIFIED','E3 exact D_m derivative gives R=(I−V)/2; a_R cancels at fixed sign kernel.'),
193:('VERIFIED','E3 fresh 12×12 gamma5-Hermitian unitary V verifies Cayley factorization, anti-Hermitian D_c, resolvent and paired-phase trace to ≤3.1e−14.'),
194:('VERIFIED-CONDITIONAL','Finite zero-mode determinant/trace mass powers follow from actual n0 and Nf; full positive normalized ensemble requires nonvanishing massless denominator and actual sector weights.'),
195:('FORMALIZED','No MS-bar scheme, physical mass selection or universal overlap normalization follows from the finite scalar derivative.'),
196:('VERIFIED-CONDITIONAL','Direct variational E1 with Paper4B finite energy/source theorem; E3 random finite controls. Ordered liminf positive only from supplied q* and subextensive excess.'),
197:('VERIFIED-CONDITIONAL','Finite convexity, Lipschitz, Legendre duality checked against Paper4B:909–955; diagonal sourced-ground argument gives states iff full compatible p(h) and positive slope; no full limit proved.'),
198:('VERIFIED','E3 positive scalar resolvent m/(lambda²+m²) bounded below on shrinking ±αm window; requires positive normalized action-dependent μ, not fixed spectral density.'),
199:('VERIFIED-CONDITIONAL','E3 50 independent Hermitian 7×7 random controls verify chi≥2M0²/(NM1) and variational source certificate; under simple invariant ground, nonzero M0, positive M1, assumed quadratic moments.'),
200:('REPRODUCED','Finite-source and Schur/readout objects exist on designated physical source branch without condensate, APBI, pressure limit; full physical mass/source member remains imported.'),
201:('FORMALIZED','XFE-EXT-CAR constructed word kept distinct from XFE-PRESSURE-COMP limiting analytic certificate; no false promotion from mode density or finite CAR to pressure convergence.'),
202:('REPRODUCED','Canonical j_x pullback and local chart compatibilities algebraically follow from supplied Paper3B/3F bundle owner; no new spin/topology selection.'),
203:('VERIFIED-CONDITIONAL','Base-fiber normalized pullback n^(−1/2) isometry and composition; isometric CAR/Fock embeddings and odd cover cofinality exact when repeated clutch and signs satisfy stated compatibility.'),
204:('VERIFIED','Unitary overlap D_m singular values bounded below by min(m,2/aR); Neumann complex tube and trace/logdet bounds q! verified algebraically for retained positive massive branch.'),
205:('VERIFIED-CONDITIONAL','Finite Fourier Bloch blocks give Riemann sums and local uniform scalar derivatives given imported all-phase sign-kernel gap; only clock determinant pressure, not interacting QCD pressure.'),
206:('REPRODUCED','Current Paper5A quark restriction rank72 and Paper2C complete scalar bands matched; isometric frame R^−3/2 field/dual embedding conditional on admitted generated physical quark-action word.'),
207:('VERIFIED','E3 SU(2) addition of j=n/2 with S=1/2 gives ± branches and exact (n+1)(n+2), n(n+1) ranks; totals 2D_m for each rank-two spin component.'),
208:('VERIFIED','E3 D_m sum and rank72 give density 12 Λ_F³/π²; homothety factor and exact CAR creation/annihilation functor checked. Density is not full Fock dimension.'),
209:('VERIFIED-CONDITIONAL','Transporting full moving field frame M_g J_m gives exact covariance; compressed fixed-band multiplier not asserted; source jets require actual J derivatives.'),
210:('REPRODUCED','Banks–Casher is an imported spectral theorem requiring mass-dependent measure and ordered thermodynamic/chiral convergence; finite zero count not enough.'),
211:('FORMALIZED','Random-matrix microscopic universality only under matching symmetry/index/volume/epsilon-regime domain, not automatically a finite kernel identity.'),
212:('VERIFIED-CONDITIONAL','If admissible GW/overlap index ν=±1 exists it is a unit sector by definition; shell topology alone does not supply required gauge/Dirac pair.'),
213:('VERIFIED','Direct finite covariance expansion Var(sum νx)=sum Cov; positive extensive normalized limit is an explicit independent dynamical condition.'),
214:('VERIFIED-CONDITIONAL','Topological variance nonzero iff integer charge distribution not point mass under genuine normalized positive transfer measure; not implied by topology support.'),
215:('VERIFIED','Index equals net chirality of exact zero modes and imposes no unrelated source matrix element; logical independence correct.'),
216:('VERIFIED','Finite exact zero support does not imply volume-normalized near-zero spectral density; distinction verified by fixed number of zeros / growing volume counterexample.'),
217:('VERIFIED','Topology index/sector weights and action-weighted near-zero/chiral density are logically distinct computation targets.'),
218:('VERIFIED-CONDITIONAL','Minimization of explicit chiral potential on SU3 is correct given broken phase, mass spurion and positive Sigma; no finite unique-vacuum breaking inferred.'),
219:('REPRODUCED','Standard SU3 chiral LO two-invariant action conditional on local broken EFT, parity/covariance, matching F_pi and B0; not a native computed amplitude.'),
220:('VERIFIED-CONDITIONAL','Quadratic spurion expansion gives standard LO octet mass matrix on supplied M_chi and F_pi/B0 normalization.'),
221:('REPRODUCED','Mass spurion inherits current charged preterminal source owner; numerical mass eigenvalues at claim scale still require G16 RG/threshold transport and are not certified by H8.'),
222:('VERIFIED-CONDITIONAL','Mass ratios algebraic once matched physical M_chi furnished, not source-independent predictions.'),
223:('FORMALIZED','Strict one-way Paper7A→7B data export and no reverse choice of QCD source/mass member.'),
224:('REPRODUCED','Anomaly matching fixes integer WZW level N_c=3 on constructed chiral EFT; amplitudes still depend on Goldstone normalization and mixing.'),
225:('REPRODUCED','UV anomaly coefficient separate from nonperturbative hadronic operator matrix elements; physical rates downstream.'),
226:('VERIFIED-CONDITIONAL','Derivative/mass power-counting follows on supplied local broken EFT with scale separation; extracting renormalized NLO coefficients from raw connected cumulants additionally consumes unresolved matching step BH-G-000146.'),
227:('UNRESOLVED','Connected generating functional at O(p⁴) contains Goldstone propagation/nonlocal loops, so direct basis projection does not uniquely extract renormalized local L_i without 1PI/loop subtraction and scheme (BH-G-000146).'),
228:('REPRODUCED','Leading axial-source coefficient is the actual F_pi/F_K/F_eta matrix-element residue, not color count or Casimir.'),
229:('VERIFIED-CONDITIONAL','Same-owner U(1)_em source normalization fixes Q_f at p=0; higher form-factor slopes dynamic, conditional physical quark/current branch.'),
230:('VERIFIED-CONDITIONAL','Admissible GW/overlap index integer and locally constant on sign-kernel-gapped components; actual operator/domain premise retained.'),
231:('VERIFIED','Index homotopy invariance does not determine regulator admissibility numerical threshold; mathematical scope clear.'),
232:('VERIFIED-CONDITIONAL','Unit native topological character changes no admissible gauge components; existence of nonzero sectors requires separately generated regulator.'),
233:('VERIFIED-CONDITIONAL','E3 positive normalized integer-weight characteristic function gives -logZ curvature=Var/V; without positive normalized sector weights nonnegativity need not hold (guard not an in-domain refutation).'),
234:('FORMALIZED','θ Fourier variable is an auxiliary cumulant source; physical CP-odd action requires an independently licensed sector character.'),
235:('VERIFIED-CONDITIONAL','E3 exact CP-even cosine series and ν=0,±1 truncation; r=2p1∈[0,1] requires positive sector weights, truncation independently justified.'),
236:('VERIFIED','Dimensional analysis cannot fix χ_t numerical prefactor or cell four-volume; definition remains variance/actual V map.'),
237:('FORMALIZED','Enhancement is computed variance/susceptibility ratio on specified two measures and defined positive reference denominator.'),
238:('VERIFIED','E3 direct covariance quadratic form wᵀCw; specific factors require weights/overlap and covariance matrix, not carrier count.'),
239:('VERIFIED-CONDITIONAL','Full sector weights/characteristic function determines all finite cumulants; covariance matrix only second cumulant unless higher tensors additionally retained.'),
240:('REPRODUCED','LO chi_t=Sigma/(sum 1/m_f) from standard anomalous chiral potential on supplied physical masses and condensate; no finite-shell numerical value.'),
241:('VERIFIED','Even C² Taylor yields 0.5 chi_t θ²+o(θ²), and C⁴ gives O(θ⁴), only with source-curvature/limit/physical-angle conditions.'),
242:('REPRODUCED','Regulated index=topological charge is imported continuum/GW theorem strictly on admissible regulator and index-matching domain.'),
243:('REPRODUCED','Fermion zero-mode Grassmann saturation yields t Hooft flavor determinant conditional on index/sector and additional zero-mode overlap; coefficient dynamical.'),
244:('REPRODUCED','Witten–Veneziano mass relationship applies only on large-Nc, chiral and pure-YM susceptibility matching branch.'),
245:('VERIFIED-CONDITIONAL','On Witten–Veneziano branch m0²=2N_f χ_YM/F0² plus cited asymptotic remainder; no known numerical χ or F0.'),
246:('VERIFIED','No lower mass bound can follow from counts without positive χ_YM lower and F0² upper control.'),
247:('VERIFIED','Every SU2 root quotient SU2/U1≅S² and π3(S²)=Z; transferring Hopf charge to gauge/QCD state requires actual map and weight.'),
}
assert len(P)==67 and set(P)==set(range(181,248))
rows=[]
for i,l in enumerate(lines,1):
 if not (4947<=i<=6272):continue
 match=re.search(r'\\begin\{(theorem|lemma|proposition|corollary|definition|remark)\}(?:\[(.*)\])?',l)
 if not match:continue
 ty,title=match.group(1),match.group(2) or ''
 e=i
 while e<=len(lines) and r'\end{'+ty+'}' not in lines[e-1]:e+=1
 assert e<=len(lines)
 labs=[item for k in range(i,e+1) for item in re.findall(r'\\label\{([^}]+)\}',lines[k-1])]
 assert labs
 label=labs[0]
 proof=None;cur=e+1
 while cur<len(lines) and not lines[cur-1].strip():cur+=1
 if lines[cur-1].strip().startswith(r'\begin{proof}'):
  pen=cur
  while pen<=len(lines) and r'\end{proof}' not in lines[pen-1]:pen+=1
  proof=[cur,pen]
 n=181+len(rows);status,note=P[n]
 iss=[]
 if n in (183,187):iss.append('BH-G-000145')
 if n in (226,227):iss.append('BH-G-000146')
 if n in (183,187):iss.append('BH-G-000139') # same connected source normalization issue inherited only on source-functional branch
 rows.append({'id':f'P7A-{n:03d}','source_label':label,'source_aliases':[x for x in labs[1:] if x!=label],
 'type':ty,'title':title,'statement_lines':[i,e],'proof_lines':proof,'source_sha256':sha,
 'source_status':'SOURCE-AS-PRINTED','status':status,'evidence_summary':note,'issues':iss})
assert len(rows)==67 and rows[0]['statement_lines'][0]==4960 and rows[-1]['statement_lines'][0]==6263
issues=[
 {'id':'BH-G-000145','severity':'moderate','source_label':'p10:thm:conditional-goldstone-package','statement_layer':'SOURCE-AS-PRINTED',
  'first_origin':{'paper':'Paper7A','theorem_id':'p10:thm:conditional-goldstone-package','step_locator':'Paper7A-QCDKernel-v1_165.tex:4977–4987, especially 4983/4986','source_excerpt':'then the standard Goldstone theorem gives eight non-singlet Goldstone modes'},
  'class':'MISSING_CONDITION','lifecycle':'OPEN','issue_status':'unresolved','source_replayed':True,
  'exact_obligation':'To infer eight physical massless Goldstone excitations (not just eight broken Lie algebra directions) from an ordered nonzero condensate with SU(3)_V stabilizer, verify that the limiting branch satisfies an applicable local/positive relativistic QFT Goldstone theorem: conserved local nonsinglet axial currents, field/locality and regularity, suitable vacuum/cluster and spectral hypotheses, with required source-limit transport.',
  'why_it_matters':'The 8-dimensional coset count and the finite unique-vacuum obstruction are correct. Nonzero ordered source slope plus group stabilizer alone does not certify eight massless particle poles without the local-QFT and current/spectral conditions consumed by Goldstone’s theorem. Paper7C lists OS/local reconstruction as a separate conditional bridge.',
  'independent_evidence':['EV-P7A-B04-CHIRAL-CROSSPAPER'],'adversarial_evidence':['EV-P7A-B04-E4'],'constitution_boundary':'BND-P7A-008',
  'conditions_consumed':[],'conditions_open':[],
  'upstream_material_paths':[['p10:thm:vector-flavor-vacuum-preservation','p10:thm:conditional-goldstone-package']],
  'downstream_verified_paths':[['p10:thm:conditional-goldstone-package','p10:thm:goldstone-tangent-axial-saturation'],['p10:thm:conditional-goldstone-package','p10:thm:gmor-chiral-bridge','p10:thm:native-chiral-coset-action']],
  'other_papers_affected':[],'possible_unconfirmed_impacts':['Paper7B pion/axial readouts only on actually consumed Goldstone limiting branch','Paper7C local field/QFT4_E/OS export is a potential condition discharge, not automatically inherited by Paper7A'],
  'verified_bypass_routes':['Algebraic coset dimension eight and finite symmetry/no-SSB theorem verified independently without QFT4/OS'],
  'resolution_requirement':'Source-match a certified local/current/spectrum Goldstone domain (e.g. actual matching Paper7C local QFT branch with chiral current and controlled limit), or explicitly qualify the massless-mode conclusion by those hypotheses. Do not add a new dynamics/condensate proof.',
  'audit_scope_limit':'Not a refutation of Goldstone theorem or QCD chiral physics, and does not assert that continuum locality fails. Eight group generators remain correctly counted.',
  'evidence_details':'Paper7A statement line 4983 consumes standard Goldstone theorem but prints only source/condensate order and SU3_V stabilizer. Paper7C v2.195 lines 2527–2587 describes local OS/Wightman reconstruction with additional QFT/reflection/cluster/regularity hypotheses. Neither the current Paper7A finite source algebra nor Paper7A 4983 separately discharges that theorem domain. No in-domain counterexample asserted.'},
 {'id':'BH-G-000146','severity':'moderate','source_label':'p10:thm:native-chiral-eft-hierarchy','statement_layer':'SOURCE-AS-PRINTED',
  'first_origin':{'paper':'Paper7A','theorem_id':'p10:thm:native-chiral-eft-hierarchy','step_locator':'Paper7A-QCDKernel-v1_165.tex:6027–6032 (first), 6035–6040 (explicit projection)','source_excerpt':'Coefficients at each order are Taylor/source-cumulant coefficients of the same generating functional'},
  'class':'NORMALIZATION_OR_READOUT','lifecycle':'OPEN','issue_status':'unresolved','source_replayed':True,
  'exact_obligation':'Identify the defined renormalized chiral matching functional for L1…L10,H1,H2, including separation of connected Goldstone exchange/loop terms from local 1PI action coefficients, subtraction scale and local operator-basis convention, before claiming that bare connected functional O(p4) basis projection uniquely returns these couplings.',
  'why_it_matters':'The chiral p²/p⁴ hierarchy and the fact that the couplings can in principle be computed from QCD correlation functions are sound. But the full connected functional generally contains nonlocal Goldstone poles and chiral loops; projecting it directly onto local p⁴ invariants does not uniquely isolate renormalized L_i without matching/subtractions. Paper7B independently states scheme-dependent L_i^r and chiral-loop terms.',
  'independent_evidence':['EV-P7A-B04-NLO-IMPORT'],'adversarial_evidence':['EV-P7A-B04-E4'],'constitution_boundary':'BND-P7A-009',
  'conditions_consumed':[],'conditions_open':[],
  'upstream_material_paths':[['p10:thm:native-chiral-coset-action','p10:thm:native-chiral-eft-hierarchy']],
  'downstream_verified_paths':[['p10:thm:native-chiral-eft-hierarchy','p10:cor:nlo-chiral-constants-native-targets'],['p10:cor:nlo-chiral-constants-native-targets','p10:thm:pseudoscalar-source-matrix-export']],
  'other_papers_affected':[],'possible_unconfirmed_impacts':['Paper7B L1..L10 hadronic amplitudes wherever matched low-energy constants consumed; Paper7B explicitly requires renormalized scheme'],
  'verified_bypass_routes':['Chiral LO source matrices, Ward-normalized axial currents and rank/count/finite regulator results do not require this NLO projection rule'],
  'resolution_requirement':'Locate a source-verified matching prescription that extracts local renormalized 1PI/chiral EFT coefficients from the same connected QCD generating functional with Goldstone loop/exchange subtraction and scale, or treat direct connected projection as an unresolved readout step; do not fit new coefficients.',
  'audit_scope_limit':'Not a claim L_i are impossible to derive, nor a refutation of the native current/correlator definitions. This audits only the Paper7A projection statement and Paper7B dependency text.',
  'evidence_details':'Algebraic E4: W(p)=A/(p²+M²)+L p⁴ has p⁴ Taylor coefficient A/M⁶+L, not the local L. At M→0 the connected Goldstone term becomes nonanalytic. Paper7B v1.150 lines 1294–1303 requires matching of amplitudes in a chosen renormalization scheme; lines 1959–1979 explicitly retain one-loop chiral logarithms and L_i^r counterterms. Thus direct projection without subtraction/matching is underdetermined.'}
]
state=old.copy();state.update({'batch':4,'audited_through_line':6272,'formal_covered':247,'formal_remaining':67,'unnamed_material_checked':6,
 'current_status':'PARTIALLY_AUDITED_WITH_OPEN_ISSUES','claims':old['claims']+rows,'issues':old['issues']+issues,
 'unreviewed':['67 formal statements from the Cartan-clock index theorem beginning at line 6289 and final source sections through line 8831 remain unaudited. Last-batch DAG and audit ZIP releases deferred.']})
# Material unnamed claims consumed by formal results, with exact source-line anchors.
state['claims'] += [
 {'id':'P7A-U004','source_label':'unnamed:Paper7A:5191-5199','source_aliases':[],'type':'unnamed_material_derivation','title':'Stationary ground-energy pressure versus Euclidean clock-normalized scalar source','statement_lines':[5191,5199],'proof_lines':None,'source_sha256':sha,'source_status':'SOURCE-AS-PRINTED','status':'FORMALIZED','evidence_summary':'H(h)=H−hO and p=(E0(0)−E0(h))/(NfV) are source definitions. Euclidean overlap response comparison consumes separately licensed clock, transfer and state identifications; no equality is inferred automatically.','issues':['BH-G-000139']},
 {'id':'P7A-U005','source_label':'unnamed:Paper7A:5331-5343','source_aliases':[],'type':'unnamed_material_derivation','title':'Mixed source moment co-consumption and connected CAR variance route','statement_lines':[5331,5343],'proof_lines':None,'source_sha256':sha,'source_status':'SOURCE-AS-PRINTED','status':'VERIFIED-CONDITIONAL','evidence_summary':'Direct expansion O=Σ Oa verifies all mixed M0,M1 terms; M0=W+Xi and connected four-point return imported from Paper4B/current source under its bounded CAR hypotheses. No count substitutes for expectation.','issues':[]},
 {'id':'P7A-U006','source_label':'unnamed:Paper7A:5447-5465','source_aliases':[],'type':'unnamed_material_derivation','title':'Quark-source constructor versus ordered condensate/pressure handoff','statement_lines':[5447,5465],'proof_lines':None,'source_sha256':sha,'source_status':'SOURCE-AS-PRINTED','status':'REPRODUCED','evidence_summary':'Current licensed spatial family provides algebra/action embeddings and mode density; matched QCD sea/clock/source, full pressure and ordered critical response remain separate stated consumers.','issues':[]},
]
state['evidence_records']=old['evidence_records']+[
 {'id':'EV-P7A-B04-E1','tier':'E1','details':'67 formal blocks P7A-181..247, source lines 4960–6269, independently reviewed for literal source claim, proof, conditional scope, admitted carrier and direct source-use; 3 unnamed proof-use steps/definitions reviewed.'},
 {'id':'EV-P7A-B04-CAYLEY','tier':'E3','details':'Fresh 12x12 random gamma5-Hermitian unitary V generated as product of Hermitian involutions; overlap R source cancellation, Cayley D_c anti-Hermiticity, factorization, resolvent derivative and zero/phase-paired controls at ∼1e−14.','script':'audit7a_work/check_batch4.py','results':'audit7a_work/batch4_independent_checks.json'},
 {'id':'EV-P7A-B04-MOMENTS','tier':'E3','details':'50 independent finite Hermitian random 7x7 models with simple zero-source vacuum and O00=0; positive margins for spectral chi ≥2 M0²/(N M1) and sourced-ground variational expectation; 30 independent positive shrinking-window resolvent controls.','script':'audit7a_work/check_batch4.py','results':'audit7a_work/batch4_independent_checks.json'},
 {'id':'EV-P7A-B04-CAR-DENSITY','tier':'E3','details':'Independent SU2 j⊗1/2 diagonalization identity and exact complete orbital polynomial sums for m=0..19, positive/negative spin Dirac shell ranks, 72-dimensional physical quark mode density; current Paper5A factorization and Paper2C band owner source-matched.','script':'audit7a_work/check_batch4.py','results':'audit7a_work/batch4_independent_checks.json'},
 {'id':'EV-P7A-B04-TOPO','tier':'E3','details':'Independent CP-even five-sector charge probability model ν=−2..2 with χ=0.78/7 and Fourier cosine error ∼1e−16; confirm normalized positive sector necessity.','script':'audit7a_work/check_batch4.py','results':'audit7a_work/batch4_independent_checks.json'},
 {'id':'EV-P7A-B04-CHIRAL-CROSSPAPER','tier':'E1','details':'Paper7C v2.195 2527–2587 conditional OS/Wightman local net reconstruction with additional reflection, regularity, covariance and cluster hypotheses. Distinct from Paper7A 4977–4987 ordered scalar source limit and symmetry stabilizer.'},
 {'id':'EV-P7A-B04-NLO-IMPORT','tier':'E1','details':'Paper7B v1.150 1294–1303 requires renormalized scheme to define L1,L2,L3 by four-point matching; 1959–1979 explicitly includes chiral logs and local counterterms. Paper7A 6032–6040 does not match full connected and local 1PI/loop-subtracted functions.'},
 {'id':'EV-P7A-B04-E4','tier':'E4','details':'Goldstone theorem scope attack: unbroken SU3_V plus scalar order alone does not supply Wightman current/locality/cluster spectral axioms; no in-domain physical counterexample claimed. NLO connected projection test W(p)=A/(p²+M²)+L p⁴ has O(p⁴) coefficient A/M⁶+L, not local L; requires projection prescription. Signed charge-sector algebra would permit negative formal χ but is excluded on stated positive transfer-measure branch; rejected as an in-domain refutation.'},
]
state['boundary_records']=old['boundary_records']+[
 {'id':'BND-P7A-008','type':'finite_source_SSB_vs_local_Goldstone_spectrum','source':'Paper7A lines 4969–5036; Paper7C lines 2527–2587','sort':'finite SU3 chiral source-pressure and ordered condensate vs local current algebra/OS Wightman spectrum in selected infinite-volume phase','realization':'Coset dimension 8 confirmed. Massless-mode theorem consumes locality, current, positive spectrum and cluster/QFT reconstruction; source order alone not a full theorem-domain certificate.','provenance':['[DER] finite unique-vacuum symmetry','[COND] nonzero ordered scalar condensate, SU3_V stabilizer','[REAL] local Goldstone theorem domain not discharged at P7A-183']},
 {'id':'BND-P7A-009','type':'full_connected_QCD_vs_renormalized_local_chiral_coefficients','source':'Paper7A lines 6027–6040; Paper7B lines 1294–1303 and 1959–1979','sort':'finite connected source cumulants vs local renormalized chiral EFT 1PI coefficients L_i^r/H_i^r','realization':'The local derivative hierarchy and correlator origin are conditional truths; directly projecting connected W onto p4 basis cannot yield scheme-fixed L_i without Goldstone pole/loop matching subtraction.','provenance':['[COND] local broken chiral EFT and scale separation','[DER] connected W cumulants','[REAL] local 1PI/renormalized chiral coefficient projection requires matched scheme']},
]
state['batch4_status_counts']=dict(collections.Counter(r['status'] for r in rows))
state['cumulative_status_counts']=dict(collections.Counter(r['status'] for r in state['claims'] if r['type']!='unnamed_material_derivation'))
state['batch4_condition_uses']=[
 {'condition':'goldstone_local_QFT4_OS_current_spectrum_domain','first_known':'Paper7C v2.195 OS/Wightman local reconstruction theorem; P7A 4977 consumes standard Goldstone theorem without proof-matched domain','used_by':['P7A-183','P7A-187','P7A-188','P7A-219'],'status':'UNRESOLVED_AT_THIS_USE'},
 {'condition':'positive_vectorlike_overlap_massive_branch','first_known':'Paper7A existing P7A overlap sign operator and massive vectorlike branch 5076','used_by':['P7A-192','P7A-193','P7A-194','P7A-198','P7A-204','P7A-205'],'status':'PROVED_ON_DECLARED_FINITE_BRANCH'},
 {'condition':'physical_source_member_and_action_clock_normalization','first_known':'Paper5A/Paper3F licensed source constructor; Paper7A earlier generating-functional audit BH-G-000139','used_by':['P7A-183','P7A-187','P7A-196','P7A-200','P7A-201','P7A-206','P7A-209'],'status':'CONDITIONAL_SOURCE_MATCHING'},
 {'condition':'unique_invariant_zero_source_ground_and_nonzero_M0_M1','first_known':'Paper7A 5288, with Paper4B source theorem owner for convexity','used_by':['P7A-196','P7A-197','P7A-199'],'status':'CONDITIONAL'},
 {'condition':'full_compatible_pressure_limit_and_nonzero_chiral_slope','first_known':'Paper7A 5223; pressure theorem conditional, separate from XFE constructor','used_by':['P7A-197','P7A-201','P7A-218','P7A-219'],'status':'CONDITIONAL'},
 {'condition':'native_temporal_clutched_cover_and_all_phase_gap','first_known':'Paper7A p10:thm:v199-native-clock-covers at 6415 (source later, direct proof-use by label); ancestor Paper1B cover transfer','used_by':['P7A-203','P7A-204','P7A-205'],'status':'PROVED_SOURCE_CLAIM_PENDING_BATCH5_AUDIT'},
 {'condition':'native_spatial_rank72_action_retained_field_and_dual','first_known':'Paper5A physical factorization 1038 and Paper3F finite-metric constructor','used_by':['P7A-206','P7A-207','P7A-208','P7A-209'],'status':'CONDITIONAL_ON_LICENSED_QUARK_BRANCH'},
 {'condition':'renormalized_local_chiral_1PI_L_i_matching','first_known':'Paper7A 6032; clearer Paper7B v1.150 1294–1303 as downstream source matching clause','used_by':['P7A-226','P7A-227'],'status':'UNRESOLVED_AT_THIS_USE'},
 {'condition':'normalized_nonnegative_charge_sector_transfer_measure','first_known':'Paper7A positive vectorlike determinant and native pure heat theta=0 context; 6101 mathematical transfer charge','used_by':['P7A-214','P7A-233','P7A-235','P7A-239'],'status':'CONDITIONAL'},
 {'condition':'admissible_GW_overlap_index_gapped_component','first_known':'Paper7A earlier native overlap/GW; Paper7A 6068 gives conditional index theorem','used_by':['P7A-212','P7A-230','P7A-232','P7A-242','P7A-243'],'status':'CONDITIONAL'},
 {'condition':'physical_topological_theta_action_vs_auxiliary_fourier_source','first_known':'Paper7A 3805, 6119 and Paper5C strong CP boundary','used_by':['P7A-233','P7A-234','P7A-235','P7A-240','P7A-241'],'status':'CONDITIONAL_PHYSICAL_IDENTIFICATION'},
]
assert len([c for c in state['claims'] if c['type']!='unnamed_material_derivation'])==247
assert len({i['id'] for i in state['issues']})==13
out=root/'Paper7A-AuditState-Batch4-v1_4.json';out.write_text(json.dumps(state,indent=2,ensure_ascii=False))
print('WROTE',out,'bytes',out.stat().st_size,'batch',state['batch4_status_counts'],'cumulative',state['cumulative_status_counts'],'issues',len(state['issues']))
