"""Independent math checks for Paper7A lines 3944-4943. No physical normalization assumption."""
from pathlib import Path
from scipy.optimize import brentq
import numpy as np, math, json
MZ=91.1872058;quark=np.array([0.002156185,0.004700044,0.093377822,1.264775,4.207890]); E=0.219578897269190; D=1/(6*np.sqrt(2));
def tau(Q):
 return 1/D+11/(2*np.pi)*np.log(Q/MZ)-np.sum(np.log((Q*Q+quark*quark)/(MZ*MZ+quark*quark)))/(6*np.pi)+3/(4*np.pi)*np.log((Q*Q+E*E)/(quark[-1]**2+E*E))
q0=brentq(tau,.001,1,xtol=1e-15); q1=brentq(lambda q:tau(q)-1,.01,1,xtol=1e-15)
b,c=quark[-1],quark[-2]
tau_sharp=1/D +23/(6*np.pi)*np.log(b/MZ) +25/(6*np.pi)*np.log(c/b)
mu=c*np.exp(-2*np.pi/9*(tau_sharp-1))
t=5.75329584663306;u=np.exp(-2*t/3);v=np.exp(-3*t/2);z=1.1;N=1/500;y=1+N;B=9/20
x=u*z*(y+B)**3
phi5=((y+2*x)**5-(y-x)**5)/3
neutral_square=(1+v*z*y**3)**5-1
# two-type recursions
Ns,Nt,Bs,Bt=(0.001,0.002,0.20,0.41); ys=1+Ns;yt=1+Nt
nT=v*z*ys*ys; nRs=v*z*ys*yt*yt;nRt=v*z*ys*ys*yt
NNs=max((1+nT)**2*(1+nRs)**2-1,(1+nT)**3*(1+nRs)-1)
NNt=(1+nRt)**7-1
xT=u*z*(ys+Bs)**2; xRs=u*z*(ys+Bs)*(yt+Bt)**2;xRt=u*z*(ys+Bs)**2*(yt+Bt)
def psi(p,q,x1,x2,y): return ((y+2*x1)**p*(y+2*x2)**q-(y-x1)**p*(y-x2)**q)/3
BBs=max(psi(2,2,xT,xRs,ys),psi(3,1,xT,xRs,ys))
BBt=((yt+2*xRt)**7-(yt-xRt)**7)/3
# independent SU3 Peter-Weyl trace tail at t_H
qplus=0.;qminus=0.;q0star=0.
for p in range(24):
 for q in range(24):
  if p==q==0:continue
  d=(p+1)*(q+1)*(p+q+2)//2
  c2=(p*p+q*q+p*q+3*p+3*q)/3
  w=d*d*np.exp(-t*c2/2)
  if (p+2*q)%3==0:q0star+=w
  elif (p+2*q)%3==1:qplus+=w
  else:qminus+=w
# For omitted SU3 terms p>=24 or q>=24, n=p+q>=24.
# C2 >= n^2/4+n, d^2 <= (n+2)^6/64, (n+1) irreps of total degree n.
# A monotone ratio upper bound for the n>=24 tail is <1e-14, so first term/(1-1e-14) suffices.
n=24
first_tail=(n+1)*(n+2)**6/64*np.exp(-t*(n*n/4+n)/2)
all_tail_bound=float(first_tail/(1-1e-14))
# separate refutation witness for non-invariant form inequality
H=np.array([[0.,0.],[0.,1.]])
# P onto (1,1)/sqrt2: inf on P k=.5, but H >= .5P globally fails
w=np.array([1.,1.])/np.sqrt(2);P=np.outer(w,w);k=np.vdot(w,H@w).real
mineig=float(np.linalg.eigvalsh(H-k*P).min())
# center flux N copies
nf=17
F=(2*np.pi/(nf))*np.diag([1/3,1/3,-2/3]); normsq=float(nf*np.trace(F@F));expected=8*np.pi**2/(3*nf)
res={
'legacy_clock':{'root0':q0,'root1':q1,'clock_at_root2_E36':tau(np.sqrt(2)*E),'clock_at_root6_E36':tau(np.sqrt(6)*E),'sharp_tau':tau_sharp,'sharp_scale':mu,'unique_positive_derivative_lower_bound':23/(6*np.pi)},
'heat_surface':{'u':u,'v':v,'charged_phi5':phi5,'charged_supersolution':B,'neutral_candidate_map':neutral_square,'neutral_supersolution':N,'trace_tail_q_plus':qplus,'trace_tail_q_minus':qminus,'trace_tail_q0star':q0star,'analytic_tail_upper_bound':all_tail_bound, 'area_exponent':np.log(z)},
'hurwitz_two_type':{'neutral_s':NNs,'neutral_t':NNt,'charged_s':BBs,'charged_t':BBt,'bounds':{'neutral_s':Ns,'neutral_t':Nt,'charged_s':Bs,'charged_t':Bt}},
'flux_continuous_spread':{'n':nf,'normsum':normsq,'expected':expected},
'global_form_warning':{'min_eigenvalue_of_H_minus_kP':mineig,'k_rayleigh_on_projector_range':k,'only_restricted_inequality_holds':bool(mineig<0)},
}
Path('/mnt/data/audit7a_work/batch3_independent_checks.json').write_text(json.dumps(res,indent=2));print(json.dumps(res,indent=2))
