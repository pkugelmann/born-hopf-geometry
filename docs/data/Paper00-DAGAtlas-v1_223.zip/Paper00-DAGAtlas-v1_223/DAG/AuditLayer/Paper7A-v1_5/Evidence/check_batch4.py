"""Independent finite controls for Paper7A chiral/CP/topological source claims, exact source hash v1_165."""
import numpy as np, scipy.linalg as la, json, math
from numpy.linalg import norm, eigvalsh, eigvals
np.random.seed(20261113)
a=0.37
m=0.23
# Two Hermitian involutions, giving exact unitary gamma5-hermitian V and paired phases.
d=12
G=np.diag([1.]*6+[-1.]*6).astype(complex)
Z=np.random.randn(d,d)+1j*np.random.randn(d,d)
U,_=np.linalg.qr(Z)
epsilon=U@np.diag([1.]*6+[-1.]*6)@U.conj().T
V=G@epsilon
D=(np.eye(d)+V)/a
R=(np.eye(d)-V)/2
Dm=D+m*R
Dc=(D@la.inv(R))
sourceR= (np.eye(d)-a*D/2)
res={}
res['overlap_unitarity_error']=float(norm(V.conj().T@V-np.eye(d)))
res['gamma5_hermiticity_error']=float(norm(G@V@G-V.conj().T))
res['mass_source_cancellation_error']=float(norm(R-sourceR))
res['cayley_factor_error']=float(norm(Dm-R@(Dc+m*np.eye(d))))
res['resolvent_source_error']=float(norm(la.inv(Dm)@R-la.inv(Dc+m*np.eye(d))))
res['antihermitian_Cayley_error']=float(norm(Dc+Dc.conj().T))
res['scalar_trace_vs_cayley_error']=float(abs(np.trace(la.inv(Dm)@R)-np.trace(la.inv(Dc+m*np.eye(d)))))
# End states with V=+1, V=-1: trace source zero/inverse at m etc.
G4=np.diag([1.,1.,-1.,-1.]);e4=np.diag([1.,-1.,1.,-1.]);V4=G4@e4;R4=(np.eye(4)-V4)/2
res['special_phase_V_plus_rank']=int(np.count_nonzero(np.abs(np.diag(V4)-1)<1e-12))
res['special_phase_V_minus_rank']=int(np.count_nonzero(np.abs(np.diag(V4)+1)<1e-12))
res['special_zero_scalar_insertion']=float(norm(R4@np.eye(4)[:, np.isclose(np.diag(V4),1)]))
# Source moment/susceptibility and variational bound, at fixed N=3 on random H/O.
err=[];sus=[];source=[]
for seed in range(50):
 rng=np.random.default_rng(seed+784)
 d=7
 ground=np.zeros(d);ground[0]=1
 H=np.diag([0]+sorted(rng.uniform(0.25,4.1,size=d-1).tolist()))
 x=rng.normal(size=(d,d))+1j*rng.normal(size=(d,d))
 O=(x+x.conj().T)/2;O[0,0]=0
 N=3.0
 M0=np.vdot(ground,O@O@ground).real
 M1=np.vdot(ground,O@H@O@ground).real
 M3=np.vdot(ground,O@O@O@ground).real
 A=np.sqrt(M0);B=M3/M0
 op=(B+np.sqrt(B*B+4*A*A))/2
 ch=2*sum(abs(O[j,0])**2/H[j,j] for j in range(1,d))/N
 lower=2*M0*M0/(N*M1)
 h=0.23
 eig,vec=la.eigh(H-h*O)
 q=np.vdot(vec[:,0],O@vec[:,0]).real/N
 certificate=op/N-(M1/M0)/(h*N)
 sus.append(ch-lower);source.append(q-certificate)
 err.append(abs(0.5*np.vdot(ground,O@(H@O)- (H@O)@O - (O@H)@O+ (O@O)@H @ ground))) if False else None
res['moment_susceptibility_margin_min']=float(min(sus))
res['moment_source_certificate_margin_min']=float(min(source))
# Exact representation/counted spatial mode density and complete component Dirac spectrum.
counts=[]
for k in range(0,20):
 Dk=(k+1)*(k+2)*(2*k+3)//6
 plus=sum((n+1)*(n+2) for n in range(k+1))
 minus=sum(n*(n+1) for n in range(1,k+1))
 counts.append({'m':k,'D_m':Dk,'component_dirac_modes':plus+minus,'expected_2D_m':2*Dk,'physical_quark_modes':72*Dk})
 assert plus+minus==2*Dk
res['orbital_all_shell_counts_match']=True
res['m_1000_density_relative_error']=float(abs((72*((1001*1002*2003)/6))/(2*np.pi**2*(1000/0.79)**3)/(12*.79**3/np.pi**2)-1))
# CP-even finite characteristic function/variance including beyond nearest-winding contribution.
p=np.array([.05,.19,.52,.19,.05]);charges=np.arange(-2,3);Vcell=7
cs=lambda th: sum(p[j]*np.exp(1j*int(charges[j])*th) for j in range(5))
var=float((p*charges**2).sum()-(p*charges).sum()**2)
step=2e-4
numeric=-np.log(cs(step)/cs(0)).real*2/(step*step*Vcell)
res['cp_even_partition_var']=var
res['topological_chi_numeric']=float(numeric)
res['topological_chi_expected']=var/Vcell
res['cp_even_chi_error']=float(abs(numeric-var/Vcell))
res['cp_Fourier_even_error']=float(max(abs(cs(x)-(.52+2*.19*np.cos(x)+2*.05*np.cos(2*x))) for x in np.linspace(0,2*np.pi,32)))
# Adversarial check: without positivity, the algebraic normalized 'variance' can be negative.
# Not an in-domain challenge if the transfer measure is stipulated positive.
ps=np.array([-.125,1.25,-.125]);qs=np.array([-1,0,1]);res['signed_sector_formal_chi']=float((ps*qs*qs).sum()-(ps*qs).sum()**2)
# Weighted-window positivity, deterministic masses and sampled normalized positive spectral measures.
rng=np.random.default_rng(155)
window=[]
for t in range(30):
 lam=rng.standard_normal(21);weights=rng.uniform(0.1,2.0,21);weights/=weights.sum();mass=.01+1.2*rng.random();alpha=.2+2*rng.random()
 C=sum(weights*mass/(lam*lam+mass*mass))
 lower=sum(weights[np.abs(lam)<=alpha*mass])/(mass*(1+alpha**2))
 window.append(C-lower)
res['weighted_window_min_margin']=float(min(window))
# local NLO chiral projection conceptual check: distinguish 1PI coefficients from full connected W.
res['source']='Paper7A-QCDKernel-v1_165.tex lines 5076-5140, 5201-5310, 5512-5622, 5675-5828, 6101-6141'
res['scope']='Finite exact controls only, no condensate, QFT4/OS, or physical winding distribution certified'
out='/mnt/data/audit7a_work/batch4_independent_checks.json'
open(out,'w').write(json.dumps(res,indent=2))
for k,v in res.items():print(k, v)
assert all(v<1e-9 for k,v in res.items() if k.endswith('_error') and isinstance(v,float) and 'density' not in k)
assert res['moment_susceptibility_margin_min']>=-1e-10 and res['moment_source_certificate_margin_min']>=-1e-10 and res['weighted_window_min_margin']>=-1e-10
