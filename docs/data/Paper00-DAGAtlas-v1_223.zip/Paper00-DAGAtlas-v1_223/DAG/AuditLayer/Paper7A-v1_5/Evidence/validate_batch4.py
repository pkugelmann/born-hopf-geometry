import json,collections,re,hashlib
from pathlib import Path
p=Path('/mnt/data/audit7a_work');state=json.loads((p/'Paper7A-AuditState-Batch4-v1_4.json').read_text());source=(p/'Papers/Paper7A-QCDKernel-v1_165.tex').read_text().splitlines()
report=Path('/mnt/data/Paper7A-ProofChainAudit-v1_4.md').read_text()
assert len(source)==8831
assert state['source_sha256']==hashlib.sha256(('\n'.join(source)+'\n').encode()).hexdigest() or state['source_sha256']==hashlib.sha256((p/'Papers/Paper7A-QCDKernel-v1_165.tex').read_bytes()).hexdigest()
formal=[c for c in state['claims'] if c['type']!='unnamed_material_derivation'];unnamed=[c for c in state['claims'] if c['type']=='unnamed_material_derivation']
assert len(formal)==247 and len(unnamed)==6
assert [c['id'] for c in formal]==[f'P7A-{n:03d}' for n in range(1,248)]
assert [c['id'] for c in unnamed]==[f'P7A-U{n:03d}' for n in range(1,7)]
ids=[i['id'] for i in state['issues']];assert len(ids)==len(set(ids))==13
assert ids==[f'BH-G-{n:06d}' for n in range(134,147)]
for c in state['claims']:
 start,end=c['statement_lines'];assert 0<start<=end<=len(source),(c['id'],start,end)
 if c['type']!='unnamed_material_derivation':
  assert re.match(r'\\begin\{(theorem|lemma|proposition|corollary|definition|remark)\}',source[start-1]),c['id']
  assert '\\label{'+c['source_label']+'}' in '\n'.join(source[start-1:end]),(c['id'],c['source_label'])
 for item in c['issues']:assert item in ids,(c['id'],item)
 assert c['source_sha256']==state['source_sha256']
for issue in state['issues']:
 assert issue['source_label'] and issue['first_origin']['theorem_id'] and issue['exact_obligation']
 if issue['id'] in ('BH-G-000145','BH-G-000146'):
  assert issue['id'] in report
for c in formal[180:]:
 assert f'| {int(c["id"][4:]):03d} |' in report
counts=collections.Counter(c['status'] for c in formal[180:]);assert dict(counts)==state['batch4_status_counts']
assert sum(state['batch4_status_counts'].values())==67
assert state['formal_covered']+state['formal_remaining']==314
assert report.count('## BATCH 4')==1
print('VALIDATION PASS source 8831 lines formal 247+67 left unnamed 6, issue 13, 67 ledger rows; counts',counts)
