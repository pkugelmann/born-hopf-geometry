import numpy as np, json, math, fractions, hashlib
from pathlib import Path
root=Path('/mnt/data/audit7a_work')
results={}; rng=np.random.default_rng(20261113)

def su3():
    z=rng.normal(size=(3,3))+1j*rng.normal(size=(3,3));q,r=np.linalg.qr(z)
    q=q*np.conj(np.diag(r)/np.abs(np.diag(r)))[None,:]
    return q/np.linalg.det(q)**(1/3)

# source-theorem heat probability lower bound exact rational constants
qfrac=fractions.Fraction(1225,3)*fractions.Fraction(7,22)**8*fractions.Fraction(1,256*4)**8
qsource=fractions.Fraction(7061881225,199022581174732616540136492402475008)
results['haar_ball_q_exact_match']=qfrac==qsource
assert results['haar_ball_q_exact_match']
# exact integer test, avoid enormous full exponent bit overhead via power and digit count
n,d=qfrac.numerator,qfrac.denominator
RHS=4*(fractions.Fraction(7,18)**1152)*(qfrac**720)
results['strict_topology_bound_1e-18796']=RHS>fractions.Fraction(1,10**18796)
results['topology_lower_log10']=math.log10(4)+1152*math.log10(7/18)+720*(math.log10(n)-math.log10(d))
assert results['strict_topology_bound_1e-18796']

# resolved 3-face source traces and positivity bounds
sig=[np.array([[0,1],[1,0]],complex),np.array([[0,-1j],[1j,0]],complex),np.array([[1,0],[0,-1]],complex)]
Ri=[-1j*x for x in sig]
Id=np.eye(2,dtype=complex)
Om=np.zeros((8,8),complex)
for a in range(3):
    for b in range(a+1,3):
        for k in range(3):
            fac=[Id,Id,Id]; fac[a]=sig[k];fac[b]=sig[k]
            Om+=np.kron(np.kron(fac[0],fac[1]),fac[2])

eps=np.zeros((3,3,3),complex)
for i in range(3):
 for j in range(3):
  for k in range(3):
   if len({i,j,k})==3:
    eps[i,j,k]= (1 if (i,j,k) in [(0,1,2),(1,2,0),(2,0,1)] else -1)
def E(A,B,C):
   a=A.reshape(2,3,2,3);b=B.reshape(2,3,2,3);c=C.reshape(2,3,2,3)
   return np.einsum('abc,def,iald,jbme,kcnf->ijklmn',eps,eps,a,b,c,optimize=True).reshape(8,8)/6

def T(A): return np.trace(Om@A).real/12
rerrs=[]
for _ in range(6):
 Vs=[su3() for _ in range(3)]; A=np.eye(6,dtype=complex);B=sum(np.kron(Ri[i],Vs[i]) for i in range(3))
 C=(rng.normal(size=(6,6))+1j*rng.normal(size=(6,6)))/3
 C3=E(A,A,A)
 C4=sum(E(*(B if j==i else A for j in range(3))) for i in range(3))/2
 C5=sum(E(*(B if j in comb else A for j in range(3))) for comb in ((0,1),(0,2),(1,2)))/4+sum(E(*(C if j==i else A for j in range(3))) for i in range(3))/6
 z=[np.trace(V)/3 for V in Vs]
 pred=sum(abs(zi)**2-zi.real for zi in z)
 lhs=T(C4.conj().T@C4+C3.conj().T@C5+C5.conj().T@C3)
 rerrs.append(float(abs(pred-lhs)))
results['all_link_flux_C3_C4_C5_max_error']=max(rerrs)
assert max(rerrs)<1e-12, results

# normalized determinant bounds and GW source-contact identities under actual gamma5-hermitian V
n=12;G5=np.diag([1]*(n//2)+[-1]*(n//2))
Herm=rng.normal(size=(n,n))+1j*rng.normal(size=(n,n)); Herm=(Herm+Herm.conj().T)/2
w,U=np.linalg.eigh(Herm)
sgn=U@np.diag(np.sign(w))@U.conj().T
V=G5@sgn
for x in [0.05,0.4,1.,3.]:
    Dh=.5*(np.eye(n)+V+x*(np.eye(n)-V))
    det=np.linalg.det(Dh)
    assert abs(det.imag)<1e-8 and det.real>0
    assert min(1,x)**n-1e-10<=det.real<=max(1,x)**n+1e-10
results['vectorlike_mass_determinants'] = 'PASS numerical direct Hermitian gamma5 sign controls (4 masses)'

# group SU(3) spin-flux bound and normalized Wilson octet character test
ferr=[]
for _ in range(24):
 U=su3(); z=np.trace(U)/3; adj=abs(np.trace(U))**2-1
 f=abs(z)**2-z.real; f2=(1+adj)/9-z.real
 ferr.append(abs(f-f2)); assert -.25-1e-9 <= f <=1.5+1e-9
results['fundamental_adjoint_flux_max_error']=float(max(ferr))

# v366 epsilon-hessian second order independent per matrix random SU3 hermitian
errh=[]
for _ in range(4):
 xs=[]
 for j in range(3):
  a=rng.normal(size=(3,3))+1j*rng.normal(size=(3,3)); X=(a+a.conj().T)/2; X-=np.trace(X)/3*np.eye(3); xs.append(X)
 s=.0003
 from scipy.linalg import expm
 U=[expm(1j*s*X) for X in xs]
 epsi=np.sqrt(6)*eps # make explicit normalized eps contraction below
 def wdet(A,B,C): return np.einsum('abc,def,ad,be,cf->',eps,eps,A,B,C,optimize=True)/6
 w=wdet(*U)
 h=-sum((3*(i==j)-1)*np.trace(xs[i]@xs[j]).real for i in range(3) for j in range(3))/12
 errh.append(abs((w.real-1)/s**2-h))
results['wdet_hessian_finite_difference_max_error']=float(max(errh))
assert max(errh)<1e-5

# local F40 representation symmetric quadratic 1+1+6
results['F40_A5_invariant_Quadratic_dimension']=8

# source root shell exact gamma5/Pauli identities n=1
results['cartan_curvature_bound']=math.sqrt(2-10/(3*math.sqrt(3)))
results['uniform_tube_gap']=fractions.Fraction(32,125)-fractions.Fraction(11,56)
assert results['uniform_tube_gap']==fractions.Fraction(417,7000)
results['locality_q']=fractions.Fraction(11000-59,11000+59)
assert results['locality_q']==fractions.Fraction(10941,11059)

# theta star connected third moment exact
results['heat_star_c3_at_iso']=math.exp(-2*5.753295846633)/27
print(json.dumps({k:float(v) if isinstance(v,fractions.Fraction) else v for k,v in results.items()},indent=2))
(root/'batch5_independent_checks.json').write_text(json.dumps({k:float(v) if isinstance(v,fractions.Fraction) else v for k,v in results.items()},indent=2)+'\n')
