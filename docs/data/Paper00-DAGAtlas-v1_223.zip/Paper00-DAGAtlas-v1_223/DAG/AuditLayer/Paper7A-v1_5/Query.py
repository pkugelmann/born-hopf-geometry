#!/usr/bin/env python3
"""Global Paper7A / Born–Hopf theorem-DAG material query (no citation promotion)."""
import json,sys
from pathlib import Path
D=Path(__file__).resolve().parents[2]
G=json.loads((D/'CombinedGraphIndex-v1_119.json').read_text())
I=json.loads((Path(__file__).parent/'ImpactIndex.json').read_text())
C=json.loads((Path(__file__).parent/'AssumptionRegistry.json').read_text())
A=G['aliases']
def follow(root,direction='forward'):
 root=A.get(root,root);adj=G[direction];seen=set([root]);queue=[(root,[root])];out=[]
 for node,path in queue:
  for nxt in adj.get(node,[]):
   if nxt in seen:continue
   seen.add(nxt);q=(nxt,path+[nxt]);queue.append(q);out.append({'node':nxt,'witness_path':q[1]})
 return out
if __name__=='__main__':
 if len(sys.argv)<3:
  print('Usage: python Query.py [forward|backward|conditions|issue] <node_or_P7A-###_or_BH-G-id>');sys.exit(2)
 typ,target=sys.argv[1:3]
 if typ in ('forward','backward'):print(json.dumps(follow(target,typ),indent=2))
 elif typ=='conditions':print(json.dumps([v for v in C['condition_uses'] if v['claim']==target or v['target_source_label']==A.get(target,target)],indent=2))
 elif typ=='issue':print(json.dumps(next((x for x in I['issue_impacts'] if x['issue_id']==target),{}),indent=2))
 else:raise SystemExit('unknown query')
