# Paper VII-A complete source audit — v1_5

Source `Paper7A-QCDKernel-v1_165.tex`, SHA256 `11233c2be618f189ec69edef36bc7a78122d90f13d28cc2f7c39b5b94076788a`. 314/314 formal and 9 unnamed consumed derivations reviewed; 15 issue roots OPEN. 5 batch source-first adjudication, no source edits, no theory repair. New material proof-use edges: 45; source citation candidates quarantined: 24; scoped condition references: 27, use edges: 106. The current active global graph files are `DAG/CombinedGraphIndex-v1_119.json`, `DAG/CombinedMaterialEdges-v1_119.json`, and `DAG/CombinedProofRoutes-v1_119.json`.

Canonical old source theorem graph `DAG/Paper00-TheoremDAG.json` retains its schema and old proof-status flags; new layer indexed via `graph_layers.paper7a_audit_layer`. `GapRegistry.json` in global root links this layer and does not replace inherited old issue histories. All target claim labels and audit alias P7A-001–314 index into the same global combined node map, so this is not a disconnected addendum.

## Query
From release root: `python DAG/AuditLayer/Paper7A-v1_5/Query.py conditions P7A-250`, `python .../Query.py issue BH-G-000147`, `python .../Query.py forward p10:thm:v199-native-unit-component`. Only material indexed edges are traversed. Condition references are branch-local, not all globally conjoined. `CITATION_ONLY` references are retained separately, not proof-promoted; issue impacts beyond explicit material paths remain POSSIBLE/UNCONFIRMED. Ancestor/forward results inherit historical atlas source-evidence boundaries and do not retroactively certify other papers.

The exact native inertia phases/v1_1 payload (Paper7D) and full 2I character/eight-function witness matrices (Paper1C / older certificate v1_12) were not present in supplied archives, logged as BH-G-000147 and 000148, not refutations. Exact source and all preceding batch data preserved.

Release v1_119 merged VI-A/VI-C source audits; the active global material index now includes their edges as well. VII-A source audit evidence remains v1_5.
