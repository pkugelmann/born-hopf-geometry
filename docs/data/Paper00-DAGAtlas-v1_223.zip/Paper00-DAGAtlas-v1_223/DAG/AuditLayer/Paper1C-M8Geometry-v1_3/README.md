# Current Paper I-C M8 geometry audit layer (v1_3)

This is the active **506-source-object** single-paper DAG audit for `Paper1C-M8Geometry-v1_140.tex`. It replaces the active v1_2 layer; its frozen earlier evidence is retained here under `Evidence/` without proof-status promotion. The separate historical Paper1C-v1_1 TechnicalMaterial layer is a different source owner and remains intact.

**Query keys:** `AuditClaimLedger.json` lists exact statement/proof text and status; `ProofRoutes.json` groups necessary inputs by AND; `TypedDependencyEdges.json` records provenance/witness and quarantines candidate references; `AssumptionRegistry.json` cites the global canonical register rather than duplicating axioms. `GapRegistry.json` stores all 13 open roots and the one resolved graph registration. `ImpactIndex.json` lists certified reach only. Combine with `DAG/Paper00-TheoremDAG.json`, `DAG/CombinedMaterialEdges-v1_156.json`, and `DAG/CombinedGraphIndex-v1_156.json` for forward/backward queries. Physical identification is not inferred from finite mathematics.

**Latest source:** SHA256 `b26b32973091d56b3ae87321f598245fca17850c35718c36627a70cc033143ed`. Current batch4 checked 177 bounded controls on 56 statements, 506/506 statements source-bound; 11 independent global proof gaps and 2 minor normalization ambiguities retained. Independent global E3 for every claim is not asserted.
