#!/usr/bin/env python3
"""Independent bounded exact/numeric controls for Paper1C v1_140, formal 451-506.
Retains reproducible checks; NOT a certificate for all global proofs.
"""
from __future__ import annotations
import json, itertools, math, hashlib
import numpy as np
import sympy as sp
from pathlib import Path
from scipy.special import eval_chebyu

HERE = Path(__file__).parent
checks=[]
def record(name, ok, val, detail='', label=None, grade='E3_BOUNDED'):
    checks.append({'id': 'IC-B4-EV-%03d'% (len(checks)+1),'name':name,'passed':bool(ok), 'value': str(val), 'detail':detail,'source_label':label, 'grade':grade})
    if not ok: print('FAILED',name, val)

R=sp.sqrt(5)
c=(1+3*R)/8; d=(5+R)/8
labels={
 'chamber':'p1c:thm:cc17-face-graph-harmonic-Galerkin',
 'heat':'p1c:cor:cc17-chamber-heat-obstruction',
 'reg':'p1c:prop:cc17-register-degree-six-eight',
 '720':'p1c:thm:cc17-720-shell-projectors',
 '120':'p1b:thm:cc16-120-spectral-compiler',
 'mixed':'p1b:prop:cc16-120-mixed-galerkin',
 'tom':'p1c:prop:cc18-720-tomography-bound',
 'grass':'p1b:thm:cc14-grassmann',
 'spin':'p1b:thm:cc15-grassmann-spin-cancellation',
 'gap':'p1b:thm:cc16-grassmann-spin-gap',
 'heatcap':'p1b:prop:v229-cap-moment-rank',
 'jet':'p1:thm:v357-normal-jet-exact'
}
for n in range(6):
    la=sp.simplify(4*sp.chebyshevu(n,c)/(n+1))
    de=sp.simplify(4+12*sp.chebyshevu(n,d)/(n+1)-la**2)
    known_la={3:sp.Rational(13,8)+3*R/4,4:(43+33*R)/40,5:(55+11*R)/32}
    known_de={3:sp.Rational(27,64)-3*R/16,4:(1173-519*R)/800,5:(1273-557*R)/512}
    record('Chamber lambda_n exact radical n='+str(n), n not in known_la or sp.simplify(la-known_la[n])==0,la,label=labels['chamber'])
    record('Chamber delta_n exact radical n='+str(n), n not in known_de or sp.simplify(de-known_de[n])==0,de,label=labels['chamber'])
    record('Chamber delta_n sign n='+str(n), bool(de==0 if n<=2 else de>0),de,label=labels['chamber'])

record('Chamber heat-rate gamma1',sp.simplify(1-(4*sp.chebyshevu(1,c)/2)/4-(7-3*R)/8)==0,1-(4*sp.chebyshevu(1,c)/2)/4,label=labels['heat'])
record('Chamber heat-rate gamma2',sp.simplify(1-(4*sp.chebyshevu(2,c)/3)/4-(3-R)/8)==0,1-(4*sp.chebyshevu(2,c)/3)/4,label=labels['heat'])
record('Non-round-heat ratio exact',sp.simplify(((3-R)/(7-3*R))-(3+R)/2)==0,(3+R)/2,label=labels['heat'])
record('Cap Hankel 3x3 determinant',sp.Matrix([[1,sp.Rational(1,4),sp.Rational(1,4)], [sp.Rational(1,4),sp.Rational(1,4),sp.Rational(15,32)], [sp.Rational(1,4),sp.Rational(15,32),sp.Rational(21,16)]]).det()==sp.Rational(71,1024),sp.Rational(71,1024),label=labels['heatcap'])
record('Spectral shell dimensions sum to 91',sum((n+1)**2 for n in range(6))==91,sum((n+1)**2 for n in range(6)),label=labels['120'])
record('720 shell dims sum 385',sum((n+1)**2 for n in range(10))==385,sum((n+1)**2 for n in range(10)),label=labels['720'])
record('720 complement dim 335',720-385==335,720-385,label=labels['720'])
record('720 tomography dimension',385**2-1-(720-1)==147505,385**2-1-(720-1),label=labels['tom'])
record('720 weights sum one',sp.Rational(120,504)+600*sp.Rational(2,1575)==1,sp.Rational(120,504)+600*sp.Rational(2,1575),label=labels['720'])
record('Register projector rank',sp.trace(sp.eye(5)-sp.ones(5)/5)**2==16,16,label=labels['reg'])

# Structural flat curvature computation with elementary 3x3 off-diagonal frames.
E=[]
for i in range(3):
 for a in range(3):
  x=np.zeros((6,6)); x[i,3+a]=1.; x[3+a,i]=-1.; E.append(x)
first=E[0]; k=[]
for other in E[1:]:
 comm=first@other-other@first
 k.append(-np.trace(comm@comm)/2)
record('Grassmann sectional curvature basis 4+4',sorted(round(v) for v in k)==[0]*4+[1]*4, list(map(float,k)),label=labels['grass'])
record('Grassmann Ricci=4 and scalar=36',sum(k)==4 and 9*sum(k)==36, (sum(k),9*sum(k)),label=labels['gap'])
record('SO3xSO3 fundamental group kernel +',sum((a+b)%2==0 for a,b in itertools.product((0,1),repeat=2))==2, 'ker(Z2²→Z2)=Z2',label='p1b:cor:cc14-grassmann-topology')
record('Tangent w2 cancellation 3w2(E)+3w2(F)',(3+3)%2==0,'0 mod 2',label=labels['spin'])
for N in (3,4,5,6,7):
 # Sym^N(C eta + C^f), dim kernel eta Sym^(N-1)(F)
 f=5
 dim=lambda n,k: math.comb(n+k-1,k)
 lhs=dim(f+1,N)
 rhs=dim(f,N)+dim(f+1,N-2)+dim(f,N-1)
 record('Normal-jet exact rank N='+str(N),lhs==rhs,(lhs,rhs),label=labels['jet'])

# Unit quaternion 2I vertices: 8 coordinate axes, 16 half-cubes, 96 permutations.
phi=(1+math.sqrt(5))/2
Q=[]; H=[]
for i in range(4):
 for s in [-1,1]:
  x=np.zeros(4);x[i]=s;Q.append(x);H.append(x)
for signs in itertools.product((-1,1),repeat=4):
 x=np.array(signs,dtype=float)/2;Q.append(x);H.append(x)
base=[0,.5,phi/2,1/(2*phi)]
def perm_sign(p):
 return (-1)**sum(1 for i in range(4) for j in range(i+1,4) if p[i]>p[j])
for p in itertools.permutations(range(4)):
 if perm_sign(p)==1:
  for signs in itertools.product((-1,1),repeat=3):
   x=np.array([base[i] for i in p]); positive=np.flatnonzero(x!=0);x[positive]*=signs
   Q.append(x)
Q=np.array(Q,dtype=float);H=np.array(H,dtype=float)
record('2I geometry size 120',len(Q)==120 and len({tuple(np.round(x,10)) for x in Q})==120,(len(Q),len({tuple(np.round(x,10)) for x in Q})),label=labels['120'])
record('2T geometry size 24',len(H)==24 and len({tuple(np.round(x,10)) for x in H})==24,len(H),label=labels['reg'])
record('2I vertex unit norms',np.max(np.abs(np.sum(Q*Q,axis=1)-1))<1e-12,np.max(np.abs(np.sum(Q*Q,axis=1)-1)),label=labels['120'])

def mul(a,b):
 # broadcast nvec: (...,4)x(...,4), scalar-first quaternion
 a=np.asarray(a);b=np.asarray(b)
 v=a[...,0]*b[...,0]-np.sum(a[...,1:]*b[...,1:],axis=-1)
 xyz=a[...,0,None]*b[...,1:]+a[...,1:]*b[...,0,None]+np.cross(a[...,1:],b[...,1:])
 return np.concatenate([v[...,None],xyz],axis=-1)

def key(q):
 return tuple(np.round(q,9))
u=np.array([1,1,0,0])/math.sqrt(2)
allF=mul(mul(Q[:,None,:],u),Q[None,:,:]).reshape(-1,4)
_, raw_indices = np.unique(np.round(allF,9),axis=0,return_index=True)
F=allF[np.sort(raw_indices)]
record('IuI size exactly 600',len(F)==600,len(F),label=labels['720'])
record('IuI non-overlap with I',not ({key(x) for x in Q}&{key(x) for x in F}),len({key(x) for x in Q}&{key(x) for x in F}),label=labels['720'])

# 720-node moment verification: all restricted coordinate monomials degree≤19, weighted Haar.
Z=np.concatenate([Q,F],axis=0); weights=np.array([1/504]*120+[2/1575]*600)
# Stable double factorial construction for 4-sphere moment.
def df_odd(n):
 x=1
 for i in range(1,n+1,2): x*=i
 return x

def haar(alpha):
 if any(e%2 for e in alpha):return 0.
 a=[e//2 for e in alpha]; A=sum(a)
 return float(math.prod(df_odd(2*v-1) for v in a)/math.prod(4+2*k for k in range(A)))

powZ=np.stack([Z[:,i,None]**np.arange(20)[None,:] for i in range(4)],axis=1)
max_dev=0; worst=None;tested=0
for alpha in itertools.product(range(20),repeat=4):
 if sum(alpha)>19:continue
 value=float(weights@(powZ[:,0,alpha[0]]*powZ[:,1,alpha[1]]*powZ[:,2,alpha[2]]*powZ[:,3,alpha[3]]))
 dev=abs(value-haar(alpha))
 tested+=1
 if dev>max_dev:max_dev=dev; worst=(alpha,value,haar(alpha))
record('720 cubature every monomial degree≤19',max_dev<3e-12,{'tested':tested,'max_abs_error':max_dev,'worst':worst},label=labels['720'],detail='Independent explicit coordinate enumeration + spherical Haar monomial formula')

# 600 facet dot and face graph enumeration
DD=F@F.T
cfloat=float(c);dfloat=float(d)
A=(np.abs(DD-cfloat)<1e-8);np.fill_diagonal(A,False)
counts=A.sum(axis=1)
record('Face adjacency 4-regular 600 vertices',np.all(counts==4),{'range':[int(counts.min()),int(counts.max())]},label=labels['chamber'])
AA=A.astype(np.int16)@A.astype(np.int16)
record('Face adjacency 4 self returns',np.all(AA.diagonal()==4),list(np.unique(AA.diagonal())),label=labels['chamber'])
N2=(AA>0)&(~A)&(~np.eye(600,dtype=bool))
record('Face adjacency 12 second neighbours',np.all(N2.sum(axis=1)==12),[int(N2.sum(axis=1).min()),int(N2.sum(axis=1).max())],label=labels['chamber'])
record('Face second-neighbour dot=d*',np.max(np.abs(DD[N2]-dfloat))<1e-8,np.max(np.abs(DD[N2]-dfloat)),label=labels['chamber'])

# 600 kernel orthogonality via trace(E_n^2) and trace(E_n E_m), adequate because PSD.
EkF=[]
for n in range(6):
  E=(n+1)*eval_chebyu(n,DD)/600
  EkF.append(E)
  dim=(n+1)**2
  tr=np.trace(E)
  hs=float(np.sum(E*E))
  record('600 E_n trace/HS n='+str(n),abs(tr-dim)<1e-8 and abs(hs-dim)<1e-7,{'trace':tr,'HS2':hs,'expected':dim},label=labels['chamber'])
for n in range(6):
 for m in range(n):
  record('600 E_n orthogonality n,m='+str(n)+','+str(m),abs(float(np.sum(EkF[n]*EkF[m])))<1e-8,float(np.sum(EkF[n]*EkF[m])),label=labels['chamber'])

# 720 kernel orthogonality via trace(E_nE_m) and trace(E_n^2).
DOT=np.clip(Z@Z.T,-1,1); WW=np.sqrt(weights[:,None]*weights[None,:]); Ek720=[]
for n in range(10):
 E=(n+1)*eval_chebyu(n,DOT)*WW
 Ek720.append(E)
 dim=(n+1)**2
 tr=np.trace(E); hs=float(np.sum(E*E))
 record('720 E_n trace/HS n='+str(n),abs(tr-dim)<1e-8 and abs(hs-dim)<2e-7,{'trace':tr,'HS2':hs,'expected':dim},label=labels['720'])
for n in range(10):
 for m in range(n):
  cross=float(np.sum(Ek720[n]*Ek720[m]))
  record('720 E_n orthogonality n,m='+str(n)+','+str(m),abs(cross)<2e-7,cross,label=labels['720'])

# Exact pair matrix compression, 600 A tests via E_n A E_n -lambda E_n.
for n in range(6):
 E=EkF[n]
 lam=4*float(sp.chebyshevu(n,c))/(n+1)
 AE=A@E
 # trace(E A) and trace(E A²) only requires E and sparse A/A².
 ta=float(np.sum(E*A))
 ta2=float(np.sum(E*AA))
 delta=ta2/((n+1)**2)-lam*lam
 expected=float(sp.simplify(4+12*sp.chebyshevu(n,d)/(n+1)- (4*sp.chebyshevu(n,c)/(n+1))**2))
 record('Face compressed A tr n='+str(n),abs(ta/((n+1)**2)-lam)<1e-9, (ta/((n+1)**2),lam),label=labels['chamber'])
 record('Face leakage trace delta n='+str(n),abs(delta-expected)<1e-9, (delta,expected),label=labels['chamber'])
 # norm equality on a subset of 12 independent columns; full Schur equality is conditional imported representation.
 for j in (0,41,121,257,521):
  lhs=E@(AE[:,j]);rhs=lam*E[:,j]
  record('Face compression E A E sample n='+str(n)+',j='+str(j),float(np.max(abs(lhs-rhs)))<1e-9,float(np.max(abs(lhs-rhs))),label=labels['chamber'])

# Source-claimed 25 bi-Hurwitz blocks and averaged low-band readout.
Hset={key(x) for x in H}; Qkey={key(x):i for i,x in enumerate(Q)}
left_reps=[];right_reps=[];covered=set()
for q in Q:
 if key(q) in covered:continue
 left_reps.append(q)
 covered|={key(x) for x in mul(q,H)}
covered=set()
for q in Q:
 if key(q) in covered:continue
 right_reps.append(q)
 covered|={key(x) for x in mul(H,q)}
record('Five each left/right 2I/2T cosets',len(left_reps)==5 and len(right_reps)==5,(len(left_reps),len(right_reps)),label=labels['reg'])
Fidx={key(x):i for i,x in enumerate(F)}
S=np.zeros((len(F),25))
try:
 for ai,a in enumerate(left_reps):
  for bi,b in enumerate(right_reps):
   bx=mul(mul(mul(a,H),u),b)
   ids=[Fidx[key(x)] for x in bx]
   assert len(set(ids))==24
   S[ids,ai*5+bi]=1/math.sqrt(24)
 S_valid= np.all(np.sum(S>0,axis=0)==24) and np.all(np.sum(S>0,axis=1)==1)
except Exception as e:
 S_valid=False
 record('Bi-2T block assembly runtime',False,repr(e),label=labels['reg'])
record('25 blocks partition facet nodes',S_valid,'600 nodes × 25 disjoint 24-point blocks',label=labels['reg'])
if S_valid:
 P5=np.eye(5)-np.ones((5,5))/5
 Pc=np.kron(P5,P5)
 record('Register centered P_c rank=16',np.linalg.matrix_rank(Pc,tol=1e-10)==16, np.linalg.matrix_rank(Pc,tol=1e-10),label=labels['reg'])
 for n in range(1,9):
  K=(n+1)*eval_chebyu(n,DD)/600
  compression=S.T@K@S
  target= np.zeros((25,25)) if n<=5 else ((n+1)/16)*Pc if n in (6,8) else None
  if target is not None:
   res=float(np.linalg.norm(compression-target,ord='fro'))
   record('Register harmonic compression n='+str(n),res<1e-8,res,label=labels['reg'])

# Source 2x2 positive partner matrix and conormal spectral scalar identity.
m=2.;g=3.
AA2=np.array([[m*m,math.sqrt(3)*g*m/2],[math.sqrt(3)*g*m/2,m*m+g*g]])
evals,Qe=np.linalg.eigh(AA2)
SqrtA=(Qe*np.sqrt(evals))@Qe.T
record('Rooted singlet spectral example m=2 g=3',abs(SqrtA[0,0]-math.sqrt(3))<1e-12,SqrtA[0,0],label='p1b:prop:v229-rooted-return')
record('Rooted partner eigenvalues m=2 g=3',np.max(abs(evals-(m*m+g*g/2+np.array([-1,1])*g/2*math.sqrt(g*g+3*m*m))))<1e-12,list(evals),label='p1b:prop:v229-rooted-return')

# Save report machine-readable.
result={'source':'Paper1C-M8Geometry-v1_140.tex','source_sha256':hashlib.sha256((HERE/'Paper1C-M8Geometry-v1_140.tex').read_bytes()).hexdigest(),
        'scope':'BATCH4_451_506','count':len(checks),'pass':sum(x['passed'] for x in checks), 'fail':sum(not x['passed'] for x in checks),
        'proof_scope':'Mathematical exact/numeric controls only; E3 complete theorem proofs NOT implied; 2I/2T group enumeration explicit; monomial design checked degree ≤19',
        'checks':checks}
(HERE/'Paper1C-Batch4-IndependentChecks-v1_1.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
if result['fail']: raise SystemExit(1)
