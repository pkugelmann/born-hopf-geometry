# Paper 1C — Rigorous Verification DAG Audit — Batch 1 (v1_2)

- **Controlling source**: `Paper1C-M8Geometry-v1_139.tex` (Paper00-PapersMinimal-v3_018), sha256 `4af36222f413886acaa3f0528ea10f040605839b6db2d021f06b2abb5f764044`.
- **Scope**: formal statements **1–150 of 505**, exact source lines **319–6104**; one-paper audit only.
- **Source replay**: all 150 statements match previously audited Paper1C v1_138 verbatim; 137 adjacent proofs also match, with no source-content divergence. Older statuses preserved as provenance; no global proof-status promotion.
- **Baseline grades**: {'FORMALIZED': 12, 'REPRODUCED': 78, 'VERIFIED': 60}.
- **Proof dependence**: 49 historical source-witnessed material edge proposals have current matched consumer in this batch, with source locators shifted +5; no citation-only edge is promoted.
- **Independent controls**: 10/10 exact/bounded tests passed. `Paper1C-Batch1-IndependentChecks-v1_1.py` and JSON certificate retain exact test code, scope and results. Controls do not independently certify global gauge action and rank-two theorems.

## Current source-bound findings

**BH-IC-139-OR-0001 (MINOR, convention ambiguity, not a refutation)** — `p1b:thm:g17-contact`, source L1127–1137. The concluding sentence (L1135–1136) says reversing residual fibre orientation changes "both displayed signs" without fixing the total/base integration orientation. With a fixed oriented base and compatible fibre-first total orientation, reversing fibre orientation sends `c1` to `-c1`, but preserves `c1^2` and the displayed normalized contact integral. Specify which signs and orientation conventions are intended; the contact iff condition and boxed integral at the original convention remain valid.

Existing open **E3/E4 independent-proof** roots retained without duplication or reclassification: **BH-IB-EV-0001** (unstable rank-two existence); **BH-IB-EV-0002** (affine determinant unframing and orbit counts); **BH-IB-EV-0003** (equivariant fixed/lift/descent); **BH-IB-EV-0004** (global mixed boundary/gauge image); **BH-IB-EV-0005** (global finite icosahedral character/measure control). No certified mathematical refutation in this batch, and no physical prediction/selector promotion.

## Exact independent control results

- exchange-centralizer: PASS — E3 exact exhaustive [-3,3], algebraic (p-q)(p+q)=±1.
- exchange-stable-primitive-slopes: PASS — E3 finite grid + exact ± eigenspaces.
- primitive-circle-quotient-SNF: PASS — E3 exact matrix Smith form.
- signed-exchange-cohomology-eigenlattices: PASS — E3 independent full 16 monomial Koszul computation.
- chern-four-vs-integral-character: PASS — E3 exact independent Newton polynomial.
- ranktwo-finite-torsor-arithmetic: PASS — E3 finite group-order consistency, does not establish gauge image theorem.
- ranktwo-fixed-row-orbit-stabilizer: PASS — E3 exact finite-order comparison under all integer Chern residues.
- petersen-exchange-tensor: PASS — E3 direct tensor matrix block rank count.
- triple-coset-degree19-root-control: PASS — E3 exact polynomial gcd + numerical root enclosure only (not full group character reconstruction).
- contact-fibre-orientation-invariance-test: PASS — E4 orientation-sensitivity note: compatible oriented fibre integration gives c1^2 unchanged.

**Audit progress:** `PARTIALLY_AUDITED` (150/505 statements), 355 statements scheduled for remaining batches. No framework, TeX, PDF, baseline ZIP, or historical proof status changed. Deliver revised DAG and audit archives only after the last batch, using filenames `Paper00-DAGAtlas-v1_154.zip` and `Paper00-ProofChainAudits-v1_67.zip` if no intervening archive revision supersedes the supplied versions.

E0 source-reference check: 132 distinct referenced labels in source lines 319–6104 resolve against the 31 current TeX manuscripts; this is a location check, not mathematical evidence.
