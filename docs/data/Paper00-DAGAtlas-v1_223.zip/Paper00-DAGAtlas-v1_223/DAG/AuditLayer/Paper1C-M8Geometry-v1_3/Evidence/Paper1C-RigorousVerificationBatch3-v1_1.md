# Paper 1C — Rigorous Verification DAG Audit — Batch 3 (v1_1)

## Controlling identity and audit boundary

- **Authoritative current paper:** `Paper1C-M8Geometry-v1_140.tex`, SHA-256 `b26b32973091d56b3ae87321f598245fca17850c35718c36627a70cc033143ed`.
- **Supplied current paper archive:** `Paper00-PapersMinimal-v3_019.zip` (uploaded filename includes `(1)`); current mathematical dependency `Paper1B-M8Geometry-v1_11.tex`.
- **Global DAG baseline:** `Paper00-DAGAtlas-v1_155.zip`, not v1_153. **Proof-chain audit baseline:** `Paper00-ProofChainAudits-v1_68.zip`, not v1_66.
- **Protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md`, source-first, single-paper, proof-adjudication-only; no new theory, no edits to input TeX or archives, no presentation/PDF review.
- **Batch:** formal statements **301–450 of 506**, lines **18094–23686** of v1_140. Cumulative source-bound dispositions: **450/506 (88.93%)**. Remaining: statements **451–506 (56)** for the final batch.

## Latest-version rebase — exact source evidence (E0)

1. All **505/505 pre-existing statement bodies** and all **429/429 pre-existing adjacent proof environments** agree exactly, including text and displayed mathematics, between `v1_139` and current `v1_140`. The latest version adds just one formal proposition in the final range, `p1c:prop:cc18-720-tomography-bound` (statement 506), in addition to release/reference metadata changes. The new proposition has **not** been independently audited in this batch.
2. All **490/490 historical DAG source statement/proof pairs** in the `Paper1C-M8Geometry-v1_2` audit layer of DAG v1_155 source-match the current `v1_140` paper. This is a rebase of already-attested E1 content, **not** fresh E3 global verification.
3. In the present range **150/150 current statement bodies** and **128/128 adjacent proof environments** match the historical v1_138 source audit verbatim; **22** named/unnamed source objects lack *adjacent* proof environments (principally remarks, corollaries or inline calculations, not automatically proof gaps).
4. **35 previously reviewed material proof-use edges** are exact-label source-matched on the current source lines (historical v1_138 shift **+6**). The edge locator match verifies named use, not soundness of the whole imported theorem. Current full-corpus TeX references within these source lines: **138** occurrences, **102** unique labels, **0 unresolved**, across **32** TeX files.

All records with prior `VERIFIED`, `REPRODUCED`, `VERIFIED-CONDITIONAL` and `FORMALIZED` dispositions preserve their inherited grade and their actual conditional domain. Their counts in this batch are respectively **64, 29, 40 and 17**. No existing claim is promoted to unconditional merely because a finite consequence passed.

## Independent mathematical controls (E2/E3 bounded subclaims)

**250/250 independent calculations passed; 0 failed.** These are **not 250 separately re-proved theorems**: 148 checks are exhaustive finite normal-form monodromy sweeps for 37 integer indices and two candidate end images, and 24 are Chebyshev-character subgroup degree sweeps. Fresh controls cover **44 distinct labelled claim objects**, not every one of the 150 formal statements. The reproducible script and complete per-check ledger are delivered with this batch.

### I. Native family and six-port harmonic operators (statements 301–326)

- Native Hilbert–Schmidt identity/retraction maps have singular values `sqrt(n)` and `1/sqrt(n)` for independently evaluated dimensions `n=2,4,6`.
- The rooted trimer projector Gram is `3/4 I_3 + 1/4 J_3`; eigenvalues `3/4` twice and `3/2` once. Direct early scalar trace has rank one; it cannot silently stand in for the two augmentation channels.
- Explicit `C_3` Fourier projectors add to identity and are pairwise orthogonal. The derived singlet/augmentation decomposition is independently verified within the three-mode model.
- Six rooted half-unit sample points give `G=156 I_6+13 J_6`, eigenvalues `156` (multiplicity five) and `234` (multiplicity one). Its positive inverse, coisometry, `163+5+1` projector count, nonsinglet Green Gram and Schur residual `163/168` pass exact checks.
- The rank-one `H_12` singlet source fraction `1/39` and its projection-commutator norm pass exact finite tests; this does **not** identify a neutral physical state probability.

### II. Finite response, Born-chart and projector operators (statements 327–376)

- Independent full `4x4` matrix inversion agrees with the `2x2` Schur/Weyl resolvent, including visible pole-rank counting. A positive-gap example satisfies the stated retained-population bounds.
- Pauli anticommuting matrices verify the positive reciprocal Born chart and `x↔1/x` covariance. Convex minimization confirms the conjugate-flux coefficient `2 Δ r²/(1+G)`.
- A noncommuting positive square-root example passes the asserted finite perturbation norm cap. The noncommuting Sylvester/Poisson identity, odd affine completion and representative singular Schur/pole-cancellation cases pass exact controls.
- A direct complex `3x3` calculation confirms the stated cyclic character defect formula **numerically** at `10^-10` tolerance (E2), and a distinct-character commutant example verifies the precise limitations of the stated no-go claim. No general operator theorem is inferred from a single numerical model.
- An explicit nonconstant smooth positive projector profile has the asserted projected flat connection after enforcing the real-positive square-root branch. The exact logarithmic Legendre Hessian **and its derivative** pass symbolic independent tests.
- The compact-pulse Volterra theorem's **first** Born coefficient sign `i λ ω ĥ(2ω)` passes the exact integration-by-parts calculation; its uniform nonlinear remainder bound is not separately globally re-derived in this batch.

### III. Principal monodromy, 600-cell moments and comparison (statements 377–420)

- All normal-form coordinates of `p1b:v215:prop:F7-monodromy` for `d=-18,…,18` were exhaustively enumerated under both stated candidate end images. The quotient actions square to the identity. The fixed-component counts are `0` for odd `d`; for even `d`, `8 gcd(3,d)` for `z0=8` and `4 gcd(3,d)` for `z0=2`. These tests **do not** independently establish the actual global mapping-space homotopy-pullback extension or select an origin.
- The Hurwitz `2T` quadratic family exactly reproduces the four-atom law for `a=(1,-1,0)`. Deleting the root register gives the prescribed `24/25` normalization and second/fourth rooted moments.
- Independent `SU(2)` Chebyshev character averages over **all 24 Hurwitz** and **all 120 binary-icosahedral** elements reproduce the `H` and `I` Reynolds ranks through degrees `1,…,12`: `H` first at 6 and 8, and `I` first at 12. This confirms the distinct rooted/unrooted harmonic onsets in the stated finite groups.
- Six half-unit evaluations reconstruct the `M=2I-(1/2)J` imaginary Gram and the norm-8 family augmentation.
- **Independent sextic defect:** explicit 120-vertex sum gives `τ_I(f^6)=1241/16`; independently integrating the degree-12 polynomial on the round `S^3` by exact Gaussian/Dirichlet angular moments gives `540/7`. Their difference is `47/112`, agreeing exactly with `p1b:thm:v243-icosian-h12-origin`.
- The quartic subgroup discriminator's diagnostic values are independently obtained: `τ_{2T}[(q0²-q1²)^4]=1/6`, `τ_{2O}[(q0²-q1²)^4]=5/48`, Haar `S^3=3/40`. This checks the stated exclusion witness, not every premise of the complete finite-subgroup classification or any physical selection.
- A distinct positive rational response pair agrees at the prescribed two nonreal sample points, confirming the finite-sample sharpness example. Finite two-level Gibbs sharpness and same-sector block-central commutator cancellation pass exact matrix checks.

### IV. Conditional residual carriers and trimer quotient (statements 421–450)

- Sampled angular-label spectra for isospins `0`, `1/2`, `1`, `3/2`, `2` reproduce the source-stated kernel dimensions and gap values within a finite angular-momentum cutoff. These are **bounded spectral checks**, not a complete proof of every elliptic domain, global index, signed multiplicity or geometric physical realization.
- The Hurwitz quaternion normal subgroup has order eight in `2T` of order 24, giving quotient `C_3`. The Cartan representative square acts by exponent doubling and swaps its two nontrivial oriented cosets. This does not infer physical masses or decays.
- The source *explicitly conditions* the residual provider, descent, gauge and physical consumer interfaces. Their scope is preserved, not represented as an unverified unconditional mechanism.

## Issue and gap adjudication

**New mathematical counterexamples found:** **none**.

**New source-level issues certified in Batch 3:** **none**. No new axiom, condition, gap-root or correction to the supplied theory was introduced.

**Inherited issues preserved exactly:** `BH-IB-EV-0001` through `BH-IB-EV-0011` remain **open independent E3/E4 evidence obligations**, not established mathematical refutations. Their primary source origins lie in statements 1–300; no new duplicate root is introduced for a conditional global argument in statements 301–450. In particular, finite tests of principal monodromy, finite icosian moments, or isospin eigenlabels do not resolve the upstream rank-two classification, complete global gauge-image, Dolbeault, quotient, or native Hessian obligations.

**Prior minor clarifications preserved:** `BH-IC-139-OR-0001` (contact orientation wording) and `BH-IC-139-NM-0002` (Cartan radius/gradient normalization). Their exact source text is unchanged by `v1_140`; neither is newly adjudicated as a mathematical refutation.

**Audit-status boundary:** `PARTIALLY_AUDITED`, with all 150 source statements dispositioned via exact current-source comparison and inherited audits, **not** an independent global E3 proof of every theorem. The current batch includes both exact finite/arithmetic subclaim calculations (E3 restricted), numerical/finite-cutoff adversarial examples (E2), prior source-argument matches (E1), and source/ref/dependency integrity (E0). Execution involved one reproducible sequential checker; no separate multi-agent signoffs are claimed.

## Artifacts and next boundary

- `Paper1C-RigorousVerificationBatch3-v1_1.md` — this report.
- `Paper1C-RigorousVerificationBatch3Ledger-v1_1.json` — full 150-claim source-span ledger and 35 current proof-use dependency source matches, scope metadata and inherited issue lineage.
- `Paper1C-Batch3-IndependentChecks-v1_1.py` / `.json` — 250 reproducible bounded mathematical controls with evidence levels and scopes.
- `Paper1C-SourceRebase-v1_1.json` — explicit exact source/proof rebase from `v1_139` to `v1_140`, including earlier batches.

**Next/final batch:** statements **451–506**, including the new CC18 tomography proposition at index 506. Only then should the DAG ZIP and audit ZIP be regenerated from the latest supplied baselines `v1_155` and `v1_68`, respectively, with duplicate historical versions excluded, full archive memberships validated, and no source papers modified.
