# Paper I-C — Independent derivations integrated into current framework — v1_2

**Update date:** 2026-11-15. **Release:** PapersMinimal v3_013, DAGAtlas v1_138, ProofChainAudits v1_54.

**Current authoritative sources:** `Paper1C-M8Geometry-v1_138.tex` (SHA-256 `d953a7b07bec0909ee4d8396e5a727de4ab6367d50a56078baec123a8f63ff33`), `Paper1D-TechnicalMaterial-v1_66.tex` (SHA-256 `653482c0e4aa3013c015573a50d0350f136c5ef62da31bfd6c536daafcd9d020`).

**Scope of this revision:** The earlier eleven-obligation independent derivation report is preserved below as a prior verification record. Its source-version descriptions reflect the original audited source `c09f2f8b49860114e0eb840c5414528efd16ff588e2e99f6d48aa03cb529b029`; the new TeX manuscripts append documentary evidence summaries without changing the original 490 Paper I-C formal statements, their labels, or any pre-existing mathematical proof body. The five executable check scripts were rerun successfully as part of the update, and their restricted scope is unchanged.

**Authoritative disposition:** Four **candidate** independent-proof certificates (EV-0005, EV-0007, EV-0008, EV-0011) remain pending final claim-/convention-matched adjudication. Seven obligations (EV-0001, EV-0002, EV-0003, EV-0004, EV-0006, EV-0009, EV-0010) retain open global steps and partial independent evidence. **None of the eleven historical issue records is silently closed**; no confirmed in-domain mathematical contradiction was produced. The new verification ledger and source update do not certify a physical measure, geometric selector, or Lorentzian transition.

---

## Preserved prior derivation record (v1_1, historical source benchmark)

# Born–Hopf Geometry — Paper I-C: independent derivations of the eleven open evidence obligations

**Artifact:** `Paper1C-IndependentGapDerivations-v1_1.md`  
**Manuscript:** `Paper1C-M8Geometry-v1_137.tex` (SHA-256 `c09f2f8b49860114e0eb840c5414528efd16ff588e2e99f6d48aa03cb529b029`)  
**Supporting appendix:** `Paper1D-TechnicalMaterial-v1_65.tex` (SHA-256 `0d4b31371bf755d13dfee1d3570cffe5d4c0c3c6f948950b2651d88ca4a91097`)  
**Canonical evidence baseline:** `Paper00-DAGAtlas-v1_137.zip` / `Paper00-ProofChainAudits-v1_53.zip`  
**Nature of this artifact:** Independent proof and computational evidence developed *after* the four-batch audit. This is an adjudication proposal, **not** a modification of the source manuscript, the original issue identities, or the canonical DAG. The audit protocol's prohibition on creating new physical hypotheses is observed; no additional physical member or mechanism is selected.

## Status and standard

The eleven records are `MISSING_INDEPENDENT_PROOF_EVIDENCE`, not established mathematical contradictions. “Candidate certificate” means a claim-matched mathematical argument is now present and may be adjudicated as satisfying independent verification. “Partial” means at least one specified global proof obligation remains. A passing test is not a proof of an untested global claim.

| Issue | Scope | Derivation status | Remaining condition for canonical closure |
|---|---|---|---|
| `BH-IB-EV-0001` | G15, rank-two/rank-three existence and fibers | **PARTIAL** | Rank-two necessity/sufficiency and full fixed-Chern rank-three fiber without importing unverified classification |
| `BH-IB-EV-0002` | Heisenberg mapping 2-type and determinant-unframing | **PARTIAL** | All affine torus-filling actions and ordinary/Born orbit counts |
| `BH-IB-EV-0003` | Equivariant Hopf, symmetric-square, indices, descent | **PARTIAL** | Independent Born-fixed class enumeration and all equivariant gauge-orbit identifications |
| `BH-IB-EV-0004` | Mixed gluing, W-cohomology, global gauges | **PARTIAL** | Actual global determinant-one gauge lifts and boundary images; full relative Thom spectral sequence |
| `BH-IB-EV-0005` | Binary-icosahedral design and twin convolution | **CANDIDATE CERTIFICATE** | Final audit adjudication of exact moment and convergence proof |
| `BH-IB-EV-0006` | Full complex-geometry and generalized Kähler normal form | **PARTIAL** | Check the full source convention mapping and all generalized-bracket components independently |
| `BH-IB-EV-0007` | All pluriclosed metrics and canonical bundle | **CANDIDATE CERTIFICATE** | Final audit adjudication of global holomorphic averaging and differential-form calculation |
| `BH-IB-EV-0008` | All-level homogeneous realization and positive sampling | **CANDIDATE CERTIFICATE** | Final audit adjudication of universal Schur/degree and transport argument |
| `BH-IB-EV-0009` | TT, intrinsic Rarita, full heat/zeta | **PARTIAL** | Remaining all-block gamma/constrained operator and associated zeta verifications |
| `BH-IB-EV-0010` | Quotient stabilizers and degree-12 branch geometry | **PARTIAL** | Global independent classification of every specified nonfree action and its stabilizers |
| `BH-IB-EV-0011` | Native midpoint Yang–Mills Morse quotient | **CANDIDATE CERTIFICATE** | Final audit adjudication of curvature normalization and full-spin proof |

**Proposed disposition:** four candidate certificates, seven partial; zero new source-matched counterexamples. The canonical DAG issue statuses should not be marked closed solely from the above summary; each proposed certificate must be accepted at the E3/adjudication gate.

---

## 1. EV-0001: fixed-rank bundles, obstruction and desuspension

Source: `p1b:thm:g15-unstable` (I-C ~1521), `p1b:thm:g20-rank2-existence` (~1632), `p1b:thm:g20-rank3-existence` (~1765), `p1b:thm:g20-rank3-fibre` (~1794).

Let `P=S^3_x×S^3_p` and `M=P×T²`. The six-complex sees the first nontrivial stage of `BSU(2)`, with `[P,BSU(2)]≈π_6(S⁴)=Z/2`: the degree-three wedge maps vanish against a 3-connected target, and the stable suspended product splitting supplies the sole top-cell class. The nonzero bundle has all Chern classes zero (H⁴(P)=0, rank two), is stably trivial because K⁰(P) is torsion-free, becomes trivial on adding one complex line by the rank-three stable range in dimension six, and stays nontrivial on pullback to M because projection has a section. Exchange reverses the top-cell orientation, which acts trivially on Z/2. This independently confirms the characteristic G15 two-class phenomenon within the ordinary principal bundle category; it does not select its nontrivial member physically.

**Independent bypass of Yang for rank-three existence.** The established K-character lattice gives

`c1=nη,  c2=A a_tu_x+B a_tu_p+C a_Eu_x+D a_Eu_p,  Δ=BC−AD,`

`c3=2m u_xu_p,  c4=(Δ+2nm−6s) O` for `s∈Z`. If `6 | (Δ+2nm)`, choose `s=(Δ+2nm)/6`. The stable K-class has an actual rank-four realization over the eight-dimensional CW complex, because rank four lies in the bijective stable range. It has `c4=0`. The unit-sphere bundle of any complex rank-four bundle has fiber `S⁷`, so all obstruction groups below degree eight vanish and the remaining top obstruction is precisely `c4`; thus a nowhere-zero section exists and `V≅E₃⊕C`. This produces the desired rank-three Chern triple. Conversely any rank-three bundle has `c4=0`, so the lattice forces the same divisibility. Hence **rank-three existence iff** `6 | (Δ+2nm)` without invoking Yang's congruence theorem.

**Not yet independently certified:** rank-two `12 | Δ` at even determinant and `6 | Δ` at odd determinant; the determinant-twisted symplectic splitting in the latter case; and the exact fixed-Chern rank-three fiber `Z²/(gZ²+⟨(A,C),(B,D)⟩)`, `g=gcd(6,2m)`. The Smith reduction of this *claimed* quotient is easy, but does not establish that this quotient is the actual classification fiber. The external Čadek–Crabb–Vanžura/Yang hypotheses must be checked in their original theorems or replaced by an independent obstruction theory argument.

## 2. EV-0002: mapping-space extension and determinant quotient

Source: `p1b:thm:g20-rank2-fibre-even`, `p1b:thm:v2170-ordinary-counts`, `p1b:thm:v2170-ordinary-born`; I-D appendix `p1b:app:g20` and `p1b:app:g20-determinant-forgetting`.

For `P=S³×S³`, let `x,p` be the two sphere projections and `κ=[x,p]`. The Samelson generator has order 12, giving the Heisenberg presentation

`(a,b;z)(a',b';z') = (a+a',b+b';z+z'+ab')`, `z∈Z/12`.

The suspension splitting identifies three Z/2 secondary generators `(r,s,e)`; conjugation acts linearly by `(r,s,e) ↦ (r,s,e+br+as)`. For zero Chern data, at `(r,s)=(0,0)` the two choices of `e` each stay fixed; at each of the three nonzero `(r,s)` values `e` is toggled and has one orbit. Thus five secondary orbits, times `12²` primary labels, reproduce **720 determinant-preserving** classes per G15 sector. This agrees with a fresh finite-action implementation. The same program independently enumerates **2,401** values of `(A,B,C,D)` and checks the primary `Z12² / im [[B,-A],[D,-C]]` order against the gcd of all 2×2 minors of `[12I | N]`. None tests the affine action on actual relative filling torsors.

Forgetting a determinant trivialization is a genuinely nontrivial quotient. On `Y=S¹_a×S¹_b×S³_u`, with `c2=a u`, the first determinant Postnikov obstruction is `Sq² c2 + c1 c2`. The fixed `(c1,c2)` lift set on a five-complex has an `H⁵(Y;Z₂)=Z₂` distinction. Changing the determinant framing along `h=b` sends the secondary choice by `h c2=b a u ≠0`. Therefore two distinct SU(2) classes have the same ordinary U(2) bundle, and their pullbacks to M stay distinct as SU(2) bundles because `Y→M` is a factor with a section. This refutes any shortcut equating determinant-preserving counts with ordinary complex counts.

**Open:** independently derive the affine unframing cocycle on the full 8-complex, the ordinary counts (including exotic-sector zero-Chern 180), and all Born-fixed ordinary orbit counts. Numerical tests of the linear shear do not supply these global operations.

## 3. EV-0003: coherent Born lifts and equivariant indices

Source: `p1b:thm:g21-born-fixed-count`, `p1b:thm:g21-index-obstruction`, `p1b:thm:g21-exotic-lift`, `p1b:thm:g21-exotic-nogo`, `p1b:thm:g21-principal-descent`; I-D `p1b:app:g21-exotic-construction`.

The exchange of factors on `S³∧S³` is the one-point compactification of `R³⊕σ³`, where `σ` is the sign representation. Standard complex conjugation makes the Hopf map `S^{1+2σ}→S^{1+σ}` equivariant. Suspending by `2+σ` gives `S^{3+3σ}→S^{3+2σ}`; forgetting the action yields `η₅:S⁶→S⁵`. The unit sphere of `C³` with involution `diag(1,1,-1)` is the target `S^{3+2σ}`. Pull back the orthogonal complement bundle `ξ_v=v⊥⊂C³` along this equivariant Hopf map and the smash collapse. The fibration `U(2)→U(3)→S⁵` has a connecting homomorphism onto `π₄ U(2)=Z/2`; composing with `η₅` yields the nontrivial class `η₄η₅∈π₆S⁴=Z/2`. Thus the pullback is the G15-exotic class with a genuine coherent **complex** Born action. On its fixed locus the complement splits into positive and negative complex lines, so its determinant transforms by sign; no determinant-preserving lift is produced.

Conversely, a principal SU(2) involution on a fixed fiber has order dividing two and is necessarily `±I`. Multiplying by its central negative gives trivial isotropy and hence a coarse-quotient principal bundle. The symmetric square of `S³` has reduced quotient `Σ⁴RP²` and the relevant smash-orbit map is `Σ⁴p` for the double cover `p:S²→RP²`. Its stable nullity prevents pulling the exotic Z/2 class back from that quotient. This is the principal-versus-complex lift distinction.

For the fixed locus `F≈S¹×S³`, the rank-four anti-diagonal normal bundle carries `-I`. The spin Lefschetz denominator is `sqrt(det(1+I₄))=4`. The source's pure-fiber index trace is `t=±(A+B)/2` and the ordinary index is `s=(B²−A²)/6`; integrality of `(s±t)/2` gives `4 | A+B`. A quaternionic structure commuting with a principal SU(2) lift makes both virtual multiplicities even and hence `24 | (B²−A²+3(A+B))`. Mixed eigenlines restrict to trivial lines on F (H²(F)=0), giving `A+B=0`.

The *descent class* description for a pure principal lift is `Desc(E)={\bar E on SP²(K):q*\bar E≈E}`; two central signs remain distinct. This is the correct categorical endpoint. **Open:** the independent equivariant enumeration of all `Desc(E)` fibers and Born-fixed ordinary classes, which depends on EV-0002, plus a separate check of the stable nullity and every sign convention in the index formula.

## 4. EV-0004: mixed quotient, top obstruction and gauge arithmetic

Source: `p1b:prop:v2170-mixed-gluing`, `p1b:lem:v2170-w-cohomology`, `p1b:thm:v2170-mixed-quotient`, `p1b:thm:complete-mixed-rank-two`.

For the exchange `M=K²`, `K=S¹×S³`, the fixed set is `F≈K`. Excise an invariant normal disk; the free complement quotient `W` is a compact oriented 8-manifold with nonempty boundary `R=F×RP³`. A mixed fiber action has two eigenlines with ordinary first Chern class zero on F, so the local boundary bundle is `C⊕λ_R`, λ the complex sign line. Born invariance forces `c1=0`, while its restriction to F forces `c2=A(a_t−a_E)(u_x−u_p)`. Since `∂W≠∅`, Poincaré–Lefschetz duality gives `H⁸(W;G)=0` for every coefficient group G used for the last absolute obstruction. This is a *top-stage only* conclusion.

The normalized boundary group in the source is `A=Z⟨b⟩⊕T`, `T=C₆⊕C₂⊕C₂`, and the claimed global integer image is `2Z`. Conditional on the source's listed **actual** global images `J_{0,V}` of sizes 2,4,1,4 (even-trivial, even-exotic, odd-trivial, odd-exotic), each quotient has order `2·24/|J_{0,V}|`, i.e. 24,12,48,12. With two free-region rows per sector the totals are 72 (even) and 120 (odd). An independent finite group enumerator reproduces these arithmetic consequences.

**Open:** the equivariant Thom/Cartan–Leray differentials identifying the full W-cohomology groups, the existence and normalized restriction of all required genuine global gauge transformations, the source-specific natural π₄/π₇ joining carry, and actual forgetful torsor images. Neither `H⁸(W)=0` nor finite quotient orders prove these difficult lower and relative stages.

## 5. EV-0005: exact 2I moments and twin convolutions — candidate certificate

Source: `p1b:thm:v273-triple-icosahedral-nineteen-design`, `p1b:thm:v274-branch-symmetric-twin-convolution`.

Reconstruct the set of 120 unit quaternions representing `2I` as the eight axis vertices, sixteen Hurwitz half-coordinate vertices, and ninety-six icosian vertices in even permutations of `(0, ±1, ±φ, ±φ⁻¹)/2`. Exact coordinate moments determine all traces `U_n(Re g)` and the exceptional invariant degrees. Through degree 20, the only nonconstant fixed degrees are 12 and 20, both rank one. At an orientation parameter `w=cos²θ sin²θ`, the overlaps are independently calculated to be

`F12(w)=1−28w+196w²−420w³`,

`F20(w)=1−(220/3)w+(4532/3)w²−(36212/3)w³+(119680/3)w⁴−44880w⁵`.

At `w=0`, `F12=1`, and at `w=1/4`, `F12=−5/16`. Hence there is a real root `w0∈(0,1/4)`, giving a positive three-stage Reynolds convolution exact for all nonconstant representation degrees ≤19. Exact rational polynomial gcd gives `gcd(F12,F20)=1`, excluding degree-20 exactness at `w0` (sharp degree 19).

For two binary-icosahedral completions of a 2T core, the normalizer quaternion `g=(1+i)/√2` gives overlap `−5/16` on the degree-twelve invariant line. The 2T-invariant subspace is two-dimensional and the 2O-invariant line splits it; averaged twin-projector eigenvalues are `11/32` and `21/32`. The triple-convolution factor `25/256` yields `a=275/8192`, `b=525/8192`, with moment-error norm `√[13(a^{2n}+b^{2n})]`. Distinct binary-icosahedral subgroups cannot lie in one proper closed subgroup of SU(2) (the 2I subgroup is maximal among finite SU2 subgroups), so the generated subgroup is dense; averaging spectral norms are <1 on nontrivial irreps and Peter–Weyl approximation gives weak convergence to Haar, with strong L² averaging-operator convergence.

The exact moment and overlap calculation is supplied as a standalone executable symbolic checker. **Scope:** geometric convolution and positive sampling; no physical frame, scattering amplitude, or interaction coupling is selected.

## 6. EV-0006: global complex structures — independent route, final bracket audit pending

Source: `p1b:thm:g22-global-complex`, `p1b:thm:g16-model`, `p1b:thm:g14-generalized` and Dolbeault section. An alternative external classification source is Pittie's theorem on left-invariant integrable complex structures on compact even-dimensional connected Lie groups; using it as an imported mathematical theorem (not a source-independent proof from axioms) specializes to the two root-sign choices and an arbitrary complex structure `J0` on the four-dimensional Cartan–central block of `su2⊕su2⊕u1²`. This is a different starting point from the Magnin classification used in the manuscript.

The holomorphic principal torus has four real vertical generators. Fourier-decompose the Dolbeault complex along these characters. For a nonzero character `m∈Z⁴`, the vertical `\bar∂` symbol is a nonzero complex vector `λ(m)`; the Koszul contraction `h_m=(Σ over j conj(λ_j(m)) i_{\bar Z_j})/(Σ|λ_j(m)|²)` obeys `\bar∂h_m+h_m\bar∂=1`. Since this real character map is injective, its norm is bounded below by `c|m|`, so all contractions preserve smooth Fourier convergence. Consequently all nonzero vertical-character summands are acyclic, and invariant forms compute the whole Dolbeault cohomology. For generalized Kähler claims, one can check the H-twisted Dorfman brackets of the two invariant metric-graph eigenbundles; the full sign and curvature convention comparison is still required.

**Open:** independently checking the entire correspondence between the external classification and *all* source normal forms and verifying every H-twisted bracket, not just their integrability pattern.

## 7. EV-0007: pluriclosed metrics and canonical bundle — candidate certificate

Source: `p1b:thm:v214-full-skt-locus`, `p1b:cor:v214-canonical-kodaira`. For every complex structure in the normal-form family, the right action of the maximal torus and all left translations are holomorphic (the right torus acts by rotations on each root plane and trivially on Cartan–central directions). Hence averaging an *arbitrary*, not necessarily invariant, Hermitian metric over these compact holomorphic groups preserves positivity and `∂\bar∂ω=0`.

An averaged metric has two positive base area coefficients and a positive Hermitian `2×2` vertical matrix `H`, with no mixed rotating-root terms. Rank-one normal form `du=x+τy, dv=0` gives `∂\bar∂ω=i h_{1\bar1} Re(τ) x∧y`. Since `h_{1\bar1}>0` and the base four-form `x∧y` is a nonzero *differential form*, a pluriclosed metric exists iff `Re(τ)=0`. Rank-two normal form `du1=x, du2=y` gives `∂\bar∂ω=i Re(h_{1\bar2}) x∧y`; choose diagonal positive H to obtain existence. Global averaging makes these criteria necessary and sufficient across **all** Hermitian metrics.

The holomorphic torus translation fields trivialize the rank-two holomorphic vertical tangent bundle. From the holomorphic exact sequence `0→O²→T^{1,0}M→π*T^{1,0}(CP¹×CP¹)→0`, determinants give `K_M=π*O(-2,-2)`. The connected compact complex-torus fibers imply `π_*O_M=O_{CP¹×CP¹}`, so every `H⁰(M,K_M^m)` equals `H⁰(CP¹×CP¹,O(-2m,-2m))=0` for `m>0`. Consequently Kodaira dimension `−∞`; smooth triviality of K does not imply holomorphic torsion.

## 8. EV-0008: homogeneous all-level realization and positive cubature — candidate certificate

Source: `p1b:thm:all-level-sampling`. Set `G=SU2_L×SU2_R`, `K=diag SU2`, `G/K≈S³`, and let `U_{a,b}=V_{a/2}⊗V_{b/2}` with `a+b≤2m`. The top diagonal spin `V_s`, `s=(a+b)/2`, occurs with multiplicity one. Choose the equivariant coisometry `T:U_{a,b}→V_s`. Define `F_v(g)=sqrt[(a+1)(b+1)/(a+b+1)] T π(g^{-1})v`. It satisfies `F_v(gk)=ρ_s(k^{-1})F_v(g)` and is a global section. Schur orthogonality yields `∫_G π(g) T*T π(g)* dg = [(a+b+1)/((a+1)(b+1))] I`, giving exact isometry of each irreducible block. Different `(a,b)` are orthogonal by Peter–Weyl. Thus the full direct sum at every m is realized as an isometric homogeneous section space.

In the global section `(q,1)`, its matrix coefficients have quaternion polynomial degree ≤`a≤2m`; pairings have degree ≤`4m`. A strength-`t≥4m` sphere design therefore reproduces all pairings exactly; a product of r retained fields and polynomial coefficient degree d needs `t≥2rm+d`. More generally, let `F⊂C(X,R)` be the finite-dimensional space containing the real and imaginary parts of every required operator coefficient, section pairing, and 1. The Haar integration functional is a point in the convex hull of evaluation functionals on F. Carathéodory (within the constant-1 affine hyperplane) gives positive weights on at most `dim F` points exactly realizing the integral. The resulting weighted evaluation is an isometry. Operators whose coefficients are included in F transport by conjugation with that isometry. This does **not** claim exactness for arbitrary symbols omitted from F or for operations not transported by that isometry.

## 9. EV-0009: TT and intrinsic Rarita — new exact constant-orbital block

Source: G08 ~13374–13880, especially equations (G08.23)–(G08.43). For `M=S³_x×S³_p×T²`, the trace-free symmetric fiber branches as `(2,0)⊕(0,2)⊕(1,1)⊕2(1,0)⊕2(0,1)⊕4(0,0)` (rank 35). Its one-form target has rank 8. Divergence's adjoint is trace-free symmetrized gradient and its kernel is the conformal-Killing space; on this compact product the only conformal-Killing fields are Killing, dim 14 (the two 6-dimensional sphere isometry algebras and 2 torus translations). Thus at each Peter–Weyl label the source's exact constrained formula follows by rank–nullity, with source-specific Killing corrections. Four parallel trace-free metric combinations form the TT zero modes; the first positive gap is `min(3/Rx²,3/Rp², λT1)`. Independent symbolic multiplication of the scalar/coexact/tracefree sphere heat profiles reproduces `A0TT=27V`, `A2TT=−27(a+b)V`, `A4TT=V[(129/2)(a²+b²)−45ab]`.

For intrinsic Rarita, use eight anti-Hermitian Clifford matrices `c_i` on C¹⁶; the gamma contraction `μ:C⁸⊗C¹⁶→C¹⁶` has `μμ*=8I`. Thus `Πγ=I−μ*μ/8` has rank 112. From the 8D round-product Koszul spin and tangent connection matrices, construct the full constant orbital `(jx,jp,n)=(0,0,0)` tangent-twisted Dirac operator **directly**, not by substituting the printed Q spectrum. Form `Q=Πγ D_T Πγ`, `P=Πγ ∇`. The executable calculation verifies the matrix identities `P*P=(7/8)D_8²−S/4`, `Q²+(1/2)PP*=ΠγD_T²Πγ` to floating-point roundoff 0 on the full block and `D_8²=9I/2`, `P*P=15I/16` for unit round spheres and zero torus momentum. The 16 zero eigenvalues of the **ambient 128×128 projection matrix** lie entirely in the excluded gamma-trace complement. On the physical 112-dimensional gamma-traceless space, **this tested block has no Q zeros**, and its smallest absolute Q eigenvalue is about `1.4510262343`. The least eigenvalue of the coupled operator in the gamma-traceless subspace is `2.5` at these parameters.

General Peter–Weyl decomposition provides the source's all-block matrix prescription `Q(jx,jp,n)` and constraints; however **one block is not a full independent verification** of all infinite-level coupled spectra, transversality restrictions, and zeta/heat statements. No one-factor Einstein Rarita split may be silently promoted to the non-Einstein product, where trace-free Ricci produces nonzero mixing.

## 10. EV-0010: finite quotients and degree-twelve branch locus

Source: G10 ~14500–14950; `p1b:prop:g10-product`, the degree-twelve pencil and I-D G10 appendix. For a finite unitary action `Γ`, `P_Γ=|Γ|^{-1}Σ_γ ρ(γ)` is an orthogonal projection: `P²=P=P*`. For a **free** quotient the heat kernel relative to Riemannian volume is `K_Q^vol([x],[y])=Σ_{γ∈Γ}K_M^vol(x,γy)` with the correct bundle lift factors; when measures on both spaces are normalized probabilities, the corresponding formula is a `1/|Γ|` average. In an SU2 left-right action `q↦a q b^{-1}`, a fixed point exists exactly if `a` and `b` are conjugate in SU2, equivalently `Re(a)=Re(b)`; for affine torus action one must also solve `(A−I)θ=−φ mod 2πZ²`. These are action-sensitive and do not apply indiscriminately to orbifold kernels.

Independently take `f6=z(z⁴−1)`, `f8=z⁸+14z⁴+1`, `g12=z¹²−33z⁸−33z⁴+1`, and `u12=f6²` (homogeneous degree twelve; the affine expression has degree ten and a zero of order two at infinity). Exact symbolic polynomial computations give `f8³=g12²+108u12²` and `u12' g12−u12 g12'=−2f6 f8²`; `u12,g12` are coprime. Thus the rational pencil `[u12:g12]` has degree 12 and 6 simple index-2 branch points and 8 index-3 branch points, including the correct point at infinity. Riemann–Hurwitz gives `6·1+8·2=22=2·12−2`. The product map has degree `12²=144`, ramification class `22(hx+hp)`, target reduced branch class `3(Hx+Hp)`, and pulled-back line square `[−12(hx+hp)]²=288`.

**Open:** a truly exhaustive independent stabilizer enumeration for the remaining specified correlated/central/two-sided/exchange actions, with their fixed-strata orbifold treatment, beyond these general action-dependent criteria and branch calculations.

## 11. EV-0011: midpoint YM Hessian and complete gauge quotient — candidate certificate

Source: `p1b:thm:native-midpoint-gauge-morse` (~16423); I-D appendix `p1b:app:native-weak-morse-bridge` (~22954). Let `e_a` be a left-invariant orthonormal frame on `S³_R` with `[e_a,e_b]=(2/R) ε_{abc}e_c`; normalize adjoint generators `[I_a,I_b]=ε_{abc}I_c`. At the midpoint `A_B(e_a)=I_a/R` the curvature is `F_B(e_a,e_b)=−ε_{abc}I_c/R²`. The spin-one Levi-Civita and adjoint color terms combine with orbital spin j to give `∇^{A_B}=−i(2L+S+T)/R`, `S²=T²=2`. The background-gauge-fixed second variation of classical pure SU2 Yang–Mills is the curvature Weitzenböck operator `H_gf=∇*∇+Ric−2ad(F)`; the convention-matched curvature term gives `R²H_gf=(2L+S+T)²+2+2S·T=2(L+S+T)²+2L²−T²`. Hence in total J sector, `R² λ=2J(J+1)+2j(j+1)−2`. On scalars the ghost is `R² d_A*d_A=(2L+T)²=2(L+T)²+2L²−T²`, with `R² μ=2j(j+1)+2k(k+1)−2` for `k⊂j⊗1`.

Exact spin matrices for `j=0,1/2,1` verify respectively vector spectra `{-2:1,2:3,10:5}`, `{1:4,7:8,17:6}`, `{2:1,6:9,14:10,26:7}` and positive ghost spectra `{2:3}`, `{1:2,7:4}`, `{2:1,6:3,14:5}` (keys are dimensionless eigenvalues, values are irrep dimensions). Since the unfixed Hessian annihilates gauge derivatives at a Yang–Mills critical point, the gauge-fixed Hessian restricts on `im d_A` to `d_A(d_A*d_A)`, removing exactly the ghost multiplets. The j=0 quotient has one negative singlet at `−2/R²` and a positive quintet at `10/R²`. At j=1/2 one positive irrep survives at `1/R²`. For every j≥1, `R² λ≥2j(j+1)−2≥2` regardless of allowed J. Thus **Morse index 1, no quotient zero modes, sharp positive gap `R⁻²`**. The geometric statement does not imply a dynamical or Lorentzian transition.

## Independent reproducibility and adjudication checklist

Five executable Python source files accompany this report:

1. `Paper1C-IndependentExceptionalMomentClosure-v1_1.py` — exact rational/quaternionic 2I degree 12/20 overlaps and twin convolution values.
2. `Paper1C-IndependentQuotientMorseChecks-v1_1.py` — exact projective-polynomial branch identities; independent j=0, 1/2, 1 YM representations.
3. `Paper1C-IndependentOrbitBoundaryChecks-v1_1.py` — 2,401 finite Z12 quotient checks, zero-Chern 5-orbit action, conditional W boundary quotient arithmetic.
4. `Paper1C-IndependentTTHeat-v1_1.py` — exact TT heat coefficient, rank and kernel algebra.
5. `Paper1C-IndependentRaritaBlock-v1_1.py` — complete 8D Clifford/tangent-spinor constant-orbital matrix, projection and coupled-operator identity; explicitly excludes projection-complement artifacts from the RS kernel.

Run with Python 3 and `sympy`, `numpy` installed. All five completed successfully during this derivation session. The mathematical proofs above contain additional global arguments (Schur orthogonality, averaging, descent) not certified by those scripts alone.

**Recommended next proof target:** EV-0004 and EV-0002. They supply global gauge/affine data consumed by other open claims; closing them first reduces the number of genuinely independent remaining proof obligations. Keep the original source manuscripts and their physics/observer claims unchanged until a separate author-approved update.
