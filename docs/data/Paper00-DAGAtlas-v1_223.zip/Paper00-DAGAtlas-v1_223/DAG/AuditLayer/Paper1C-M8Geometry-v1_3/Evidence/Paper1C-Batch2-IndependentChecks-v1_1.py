#!/usr/bin/env python3
"""Source-matched independent mathematical controls for Paper1C 151-300.
No inherited audit status is upgraded by these bounded checks.
All checks are independent recomputations of existing printed subclaims.
"""
import json, math, collections, itertools, random, hashlib
import sympy as S
from functools import lru_cache
W='/mnt/data/audit1c_work'
reports=[]
def run(name, target, kind, scope, f):
    ans=f(); assert ans is not False
    reports.append({'name':name,'source_label':target,'evidence_level':kind,'scope':scope,'result':'PASS','detail':str(ans)[:1800]})

# 1. Independent tensor-invariance dimension enumeration.
def invariant_connection_dims():
    # B on g has four + and four - eigendirections.
    sig=[1]*4+[-1]*4
    d=sum(1 for i in range(8) for j in range(8) for k in range(j+1,8) if sig[i]*sig[j]*sig[k]==1)
    alt=sum(1 for i in range(8) for j in range(i+1,8) for k in range(j+1,8) if sig[i]*sig[j]*sig[k]==1)
    assert (d,alt)==(112,28)
    return {'even_metric_connection_dimension':d,'even_three_form_dimension':alt,'total':(8*28,math.comb(8,3))}
run('exchange-connection-dimensions','p1b:thm:left-metric-connections','E3','exact character enumeration on Λ²⊗g and Λ³ of 4+4 signed real space',invariant_connection_dims)

# 2. Independent torsion-contorsion inversion.
def contorsion_inverse():
    T={}
    for a in range(4):
      for b in range(4):
       for c in range(4):
        T[a,b,c]=(a-b)*(c+1) if a!=b else 0
    # K_{abc} = -K_{acb}; torsion T_{abc} = K_{abc}-K_{bac}.
    def K(a,b,c):return S.Integer(T[a,b,c]-T[b,c,a]+T[c,a,b])/2
    for a,b,c in itertools.product(range(4),repeat=3):
      assert K(a,b,c)==-K(a,c,b)
      assert K(a,b,c)-K(b,a,c)==T[a,b,c]
    assert 8+56+160==224 and 4+28+80==112
    return 'exact rational inverse of 4×4×4 representative torsion tensors; both decompositions agree'
run('torsion-contorsion-inverse','p1b:prop:g19-torsion','E3','exact index-level tensor isomorphism check plus O(8) dimension counts',contorsion_inverse)

# 3. Numeric-exact curvature matrices for independent bi-invariant flat branches.
def flat_bi_curvature():
    # Orthornormal frames [e_a,e_b]=2 ε_ab_c e_c; sphere R=1, center Euclidean.
    epsi=lambda a,b,c:int((a,b,c) in [(0,1,2),(1,2,0),(2,0,1)])-int((a,b,c) in [(0,2,1),(2,1,0),(1,0,2)])
    br=[]
    for i in range(8):
      for j in range(8):
        v=S.zeros(8,1)
        for f in [0,3]:
          if f<=i<f+3 and f<=j<f+3:
            for k in range(3): v[f+k]=2*epsi(i-f,j-f,k)
        br.append(v)
    def trial(sx,sp,vx,vp,kappa):
      s=[sx,sp];v=[S.Matrix(vx),S.Matrix(vp)]; kap=S.Matrix(kappa)
      As=[]
      for i in range(8):
        A=S.zeros(8)
        if i<6:
          f=i//3; a=i%3; off=f*3
          for b in range(3):
            for c in range(3): A[off+c,off+b]=s[f]*2*epsi(a,b,c)
          for j in range(2):
            A[off+a,6+j]=v[f][j]
            A[6+j,off+a]=-v[f][j]
        else:
          k=kap[i-6]
          A[6,7]=-k; A[7,6]=k
        assert A+A.T==S.zeros(8)
        As.append(A)
      curv=[]
      for i in range(8):
        for j in range(i+1,8):
          R=As[i]*As[j]-As[j]*As[i]-sum((br[8*i+j][k]*As[k] for k in range(8)),S.zeros(8))
          curv.append(R)
      return all(m==S.zeros(8) for m in curv)
    assert trial(0,1,[0,0],[0,0],[3,4])
    assert trial(S.Rational(1,2),0,[1,0],[0,0],[0,0])
    assert trial(S.Rational(1,2),S.Rational(1,2),[1,0],[0,1],[0,0])
    assert not trial(S.Rational(1,2),S.Rational(1,2),[1,0],[1,0],[0,0])
    assert not trial(S.Rational(1,2),0,[1,0],[0,0],[1,0])
    assert not trial(S.Rational(1,2),0,[S.Rational(1,2),0],[0,0],[0,0])
    return '6 exact rational 8×8 curvature matrix tests: 3 flat strata and 3 independent nonflat mutations'
run('bi-invariant-flat-curvature-replay','p1b:thm:v214-flat-bi-connections','E3+E4','exact matrices on radius-one sphere/Euclidean center, confirms representative strata not global uniqueness',flat_bi_curvature)

# 4. Torsion Dirac: exact branch zeros and kernel formula.
def torsion_spectrum():
    h=lambda s: next(((r+1)*(r+2) for r in range(10) if s in (-S.Rational(r,3),1+S.Rational(r,3))),0)
    samples=[S.Integer(0),S.Integer(1),S.Rational(1,2),-S.Rational(1,3),S.Rational(4,3),-S.Rational(2,3)]
    for s in samples:
       zeros=0
       for l in range(10):
         d=(l+1)*(l+2)
         if l+3-3*s==0:zeros+=d
         if -(l+3*s)==0:zeros+=d
       assert zeros==h(s)
    assert 4*h(S.Integer(0))*h(S.Integer(1))==16
    assert h(S.Rational(1,2))==0
    return {'samples':{str(s):h(s) for s in samples},'endpoint_8d_kernel':16}
run('torsion-dirac-kernel-arithmetic','p1b:thm:v214-torsion-dirac','E3','independently enumerate both signed branches for levels 0–9, endpoint and nonendpoint kernels',torsion_spectrum)

# 5. Complex family dimensions and exchange admissibility.
def complex_cones():
    # Dimension GL(4,R)/GL(2,C)=16-8; exchange complex structures on two independent real planes=4.
    assert 16-8==8 and 2*(4-2)==4
    assert 2*2*2==8
    # No complex structure commutes with a linear involution having 1+1 split on real W.
    a,b,c,d=S.symbols('a b c d',real=True)
    M=S.Matrix([[a,b],[c,d]]); invol=S.diag(1,-1)
    eq=list(M*invol-invol*M)+list(M*M+S.eye(2))
    assert S.solve(eq,[a,b,c,d],dict=True)==[]
    return 'homogeneous-space dimensions, eight metric-orthogonal exchange J values; no commuting J on a 1+1 real Hopf plane'
run('complex-family-exchange-rank','p1b:thm:complex-family','E3','exact linear-algebra dimension/count and 2×2 commuting obstruction',complex_cones)

# 6. Dolbeault cohomology of printed finite model, independent full-rank differential.
def finite_dolbeault():
    z,w=S.symbols('z w')
    basis=list(itertools.product((0,1),(0,1),range(16)))
    def deg(t):
      x,y,m=t;return (x+y+((m&1)!=0)+((m&2)!=0), x+y+((m&4)!=0)+((m&8)!=0))
    groups=collections.defaultdict(list)
    for j,m in enumerate(basis):groups[deg(m)].append(j)
    def hodge(C):
      D=S.zeros(64)
      for j,(x,y,mask) in enumerate(basis):
       for k in range(2):
        if not(mask&(1<<k)):continue
        sign=(-1)**int((mask&((1<<k)-1)).bit_count())
        out_mask=mask^(1<<k)
        for pos,co in enumerate(C[k]):
         if co==0:continue
         xx=x+(pos==0);yy=y+(pos==1)
         if xx>1 or yy>1:continue
         i=basis.index((xx,yy,out_mask))
         D[i,j]+=sign*co
      assert D*D==S.zeros(64)
      ranks={(p,q):D.extract(groups.get((p,q+1),[]),ids).rank() for (p,q),ids in groups.items()}
      h={}
      for (p,q),ids in groups.items():
        val=len(ids)-ranks[(p,q)]-ranks.get((p,q-1),0)
        assert val>=0
        h[(p,q)]=val
      P=S.expand(sum(val*z**p*w**q for (p,q),val in h.items()))
      return P,h
    P2,H2=hodge([[1,0],[0,1]])
    P1,H1=hodge([[1,S.I],[0,0]])
    exp2=S.expand((1+w)**2*(1+z*z*w)**2)
    exp1=S.expand((1+z)*(1+w)**2*(1+z*w)*(1+z*z*w))
    assert S.simplify(P2-exp2)==0
    assert S.simplify(P1-exp1)==0
    assert sum(H2.values())==16 and sum(H1.values())==32
    return {'rho2_hodge_sum':16,'rho1_hodge_sum':32,'rho2_P':str(S.factor(P2)),'rho1_P':str(S.factor(P1)),'model_dimension':64}
run('dolbeault-model-full-complex','p1b:thm:g16-hodge','E3','independent exact 64-dimensional Koszul algebra and differential rank calculation for both normal-form strata; not quasi-isomorphism proof',finite_dolbeault)

# 7. Frölicher E2 count from printed d1, against topology.
def frolicher_reduction():
   # H rank1 = Λ(s,a,b,γ) ⊗ C[ζ]/ζ², d1(a)=ζ, other generators closed.
   # pair (a,ζ) with da=ζ, d(aζ)=ζ²=0; H(a,ζ)=span{1,aζ}.
   total=2**3*2
   assert total==16
   t=S.symbols('t'); betti=S.expand((1+t)**2*(1+t**3)**2)
   assert sum(int(c) for c in S.Poly(betti,t).all_coeffs())==16
   return {'E1_dimension':32,'E2_dimension':16,'topological_betti_polynomial':str(S.factor(betti))}
run('frolicher-rank1-E2-topology','p1b:prop:g16-frolicher','E3','calculate cohomology of explicit d1 derivation; matches S³×S³×T² Betti dimensions',frolicher_reduction)

# 8. Finite representation shell and parity formulas.
def all_level_dims():
   stats=[]
   for m in range(0,9):
    even=sum((a+1)*(b+1) for a in range(2*m+1) for b in range(2*m+1-a) if (a+b)%2==0)
    odd=sum((a+1)*(b+1) for a in range(2*m+1) for b in range(2*m+1-a) if (a+b)%2==1)
    E=(m+1)*(m+2)*(2*m*m+6*m+3)//6
    O=m*(m+1)**2*(m+2)//3
    assert (even,odd)==(E,O)
    h=sum(S.binomial(r+3,3) for r in range(2*m+1))
    assert even+odd==h
    stats.append((m,int(h)))
   assert stats[:4]==[(0,1),(1,15),(2,70),(3,210)]
   return {'levels':stats,'parity_1':(11,4)}
run('all-level-dimensions-parity','p1b:thm:mixed-dimensions','E3','exact sector enumeration m=0..8, closed parity polynomials and H1 tensor dimension',all_level_dims)

# 9. Equivariant intertwiner algebra dimensions.
def matrix_block_dims():
    for m in range(6):
      n=2*m
      value=sum((a+1)**2*(b+1)**2 for a in range(n+1) for b in range(n-a+1))
      formula=S.Rational((n+1)*(n+2)*(n+3)*(n+4)*(2*n*n+10*n+15),360)
      assert value==formula
    for l in range(10):
      lhs=sum((k+1)**4 for k in range(l+1))
      rhs=S.Rational((l+1)*(l+2)*(2*l+3)*(3*l*l+9*l+5),30)
      assert lhs==rhs
    return 'exact sums of squared full matrix-block sizes for H_m m≤5, P_l l≤9'
run('mixed-operator-algebras-dimensions','p1b:thm:mixed-algebras','E3','independent combinatorial sums of block matrix dimensions at multiple levels',matrix_block_dims)

# 10. Full coordinate graph enumeration and product exchange cycles.
def coordinate_graphs():
    from collections import deque
    def graph(m):
      v={(a,b) for a in range(2*m+1) for b in range(2*m+1-a)}
      edges={frozenset((a,(a[0]+da,a[1]+db))) for a in v for da in (-1,1) for db in (-1,1) if (a[0]+da,a[1]+db) in v}
      adj={a:set() for a in v}
      for e in edges:
        u,w=tuple(e);adj[u].add(w);adj[w].add(u)
      seen=set();ncomp=0
      for v0 in v:
        if v0 in seen:continue
        ncomp+=1;queue=[v0];seen.add(v0)
        while queue:
          u=queue.pop()
          for w in adj[u]-seen:seen.add(w);queue.append(w)
      return len(v),len(edges),ncomp
    for m in range(8):
       v,e,c=graph(m)
       assert v==S.binomial(2*m+2,2) and e==4*m*m and c==(1 if m==0 else 2)
       if m:assert e-v+c==(2*m-1)*(m-1)
    # H1 graph has (v,e,c)=(6,4,2), products and exchange quotient.
    v,e,c=6,4,2
    assert (v*v,2*e*v,c*c,2*e*v-v*v+c*c)==(36,48,4,16)
    assert (e*v,e*v-v*(v+1)//2+c*(c+1)//2)==(24,6)
    return 'full graph adjacency for m=0..7, H1×H1 48/16 and exchange 24/6'
run('coordinate-graphs-cycle-count','p1b:thm:all-level-product-graph','E3','exhaustive finite graph construction, connected components and cycle ranks',coordinate_graphs)

# 11. Spin(4) one-handed branching weights.
def onehanded_branching():
    for m in range(6):
       n=2*m
       for a in range(n+1):
          dim_spectator=sum((b+1) for b in range(n-a+1))
          assert dim_spectator==S.binomial(n-a+2,2)
       assert sum((a+1)*S.binomial(n-a+2,2) for a in range(n+1))==sum((a+1)*(b+1) for a in range(n+1) for b in range(n-a+1))
    return 'one-handed spectator multiplicities b_m(a) and sum-to-dimension m=0..5'
run('one-handed-branching','p1b:thm:all-level-chiral','E3','direct decomposition of U_ab into chiral weights over retained simplex',onehanded_branching)

# 12. Scalar cutoff at ℓ=1 explicit exact 5×5 matrices.
def scalar_cutoff_l1():
    C=[]
    for a in range(4):
      M=S.zeros(5);M[0,a+1]=S.Rational(1,2);M[a+1,0]=S.Rational(1,2);C.append(M)
    D=S.eye(5)-sum((M*M for M in C),S.zeros(5))
    pi=S.diag(0,1,1,1,1)
    assert D==S.Rational(3,4)*pi
    comm=C[0]*C[1]-C[1]*C[0]
    L=S.zeros(5);L[1,2]=1;L[2,1]=-1
    assert comm==S.Rational(1,4)*L
    norm_trace=S.trace(D)/5
    assert norm_trace==S.Rational(3,5)
    cs=sum(((C[a]*C[b]-C[b]*C[a]).T*(C[a]*C[b]-C[b]*C[a]) for a in range(4) for b in range(a+1,4)),S.zeros(5))
    assert S.trace(cs)/5==S.Rational(3,20)
    return {'l':1,'radius_defect':str(S.Rational(3,4)),'normalized_defect':str(norm_trace),'commutator_norm':'1/4','commutator_square_normalized_trace':'3/20'}
run('scalar-coordinate-cutoff-l1','p1b:thm:scalar-cutoff-identities','E3','full exact scalar degree≤1 projected multiplication matrices on 5D harmonics',scalar_cutoff_l1)

# 13. Fixed-factor heat asymptotic via integral leading terms.
def heat_asymptotics():
    # On R-radius S³: Vol/(4πt)^(3/2)=sqrtπR³/(4t^(3/2)).
    R,gx,gp,F,t=S.symbols('R gx gp F t',positive=True)
    sphere=S.simplify((2*S.pi**2*R**3)/(4*S.pi*t)**S.Rational(3,2))
    H=S.integrate(S.Symbol('x',positive=True)*S.exp(-t*gx*S.Symbol('x',positive=True)**2/4),(S.Symbol('x',positive=True),0,S.oo))
    assert S.simplify(sphere-S.sqrt(S.pi)*R**3/(4*t**S.Rational(3,2)))==0
    assert S.simplify(H-2/(gx*t))==0
    assert S.simplify(15*H**2-60/(gx**2*t**2))==0
    assert S.simplify((H**2)*(H.subs(gx,gp)**2)-16/(gx**2*gp**2*t**4))==0
    return 'Weyl factor on sphere, factorized Gaussian integrals on bivariate SU2 labels; exact leading constants'
run('large-level-heat-leading-constants','p1b:thm:all-level-limits','E3','separate Weyl law/integral asymptotics for claimed scalar and enriched completions',heat_asymptotics)

# 14. Universal all-level Casimir m=1 four-branch table.
def casimir_level1():
    dd=collections.Counter()
    for a in range(3):
      for b in range(3-a):
       k=S.Rational(a*(a+2)+b*(b+2),4);dd[k]+=(a+1)*(b+1)
    assert dd=={S.Integer(0):1,S.Rational(3,4):4,S.Rational(3,2):4,S.Integer(2):6}
    return {str(k):v for k,v in sorted(dd.items())}
run('level-one-casimir-four-towers','p1b:thm:mixed-spectra','E3','independently enumerate all a+b≤2 representation Casimirs and multiplicities',casimir_level1)

# 15. Nonconstant Cartan moments, CS and YM polynomial.
def nonconstant_cartan_moments():
    q,e=S.symbols('q e',real=True)
    avg=lambda polynomial:S.expand(polynomial).subs(q,0) if False else sum(co*S.rf(S.Rational(1,2),k)/S.rf(S.Integer(2),k) for (j,),co in S.Poly(S.expand(polynomial),q).terms() for k in [j//2] if j%2==0)
    # every polynomial only even powers in q
    h=q**2-S.Rational(1,4)
    assert [avg(h**k) for k in range(1,5)]==[0,S.Rational(1,16),S.Rational(1,64),S.Rational(3,256)]
    grad2=8*avg(h**2) # unit-radius ∫|∇h|² = 8∫h²
    energy=S.expand(S.Rational(1,4)-e**2*avg(h**2)/2+e**4*avg(h**4)/4+e**2*grad2/6)
    CS=S.expand(S.Rational(1,2)-e**3*avg(h**3)/4)
    assert energy==S.Rational(1,4)+S.Rational(5,96)*e**2+S.Rational(3,1024)*e**4
    assert CS==S.Rational(1,2)-e**3/S.Integer(256)
    return {'moments':[str(avg(h**k)) for k in range(1,5)],'energy':str(energy),'CS':str(CS),'gradient_convention':'unit-radius S3 used, as in source proof'}
run('nonconstant-cartan-moments-energy-cs','p1b:thm:v2217-nonconstant-cartan-dirac','E3','exact beta-distribution sphere moments, normalized unit-radius gradient, energy/CS polynomials, not eigenbranch cubic oracle',nonconstant_cartan_moments)

# 16. Native Dirac CS/YM barrier reparametrization.
def native_dirac_barrier():
    l,R=S.symbols('l R');f=S.Rational(1,2)-R*l/3
    CS=S.expand(3*f*f-2*f*f*f)
    E=S.expand(4*f*f*(1-f)**2)
    assert S.simplify(CS-(S.Rational(1,2)-R*l/2+2*R**3*l**3/27))==0
    assert S.simplify(E-S.Rational(1,4)*(1-4*R*R*l*l/9)**2)==0
    return {'CS':str(CS),'E':str(S.factor(E))}
run('native-dirac-cs-barrier-algebra','p1b:cor:native-dirac-cs-barrier-coordinate','E3','independent symbolic elimination of f via exact native signed eigenbranch',native_dirac_barrier)

# 17. Morse low spectrum, quotient one negative mode.
def morse_low_levels():
    checks=[]
    for n in range(0,9):
       j=S.Rational(n,2)
       # J from j⊗1⊗1; possibilities j-2..j+2, but nonnegative as from k=(0,1,2) spin.
       allowed=set()
       for k in (0,1,2):
          a=abs(j-k)
          for i in range(int(2*min(j,k))+1):allowed.add(a+i)
       vals={J:S.simplify(2*J*(J+1)+2*j*(j+1)-2) for J in allowed}
       if n==0:assert vals=={0:-2,1:2,2:10}
       if n==1:assert min(vals.values())==1
       if n>=2:assert min(vals.values())>=2
       checks.append((str(j),str(min(vals.values()))))
    return {'lowest_by_j':checks}
run('midpoint-morse-nonnegative-other-orbitals','p1b:thm:native-midpoint-gauge-morse','E3','independent angular-momentum coupling enumeration through j=4; assumes printed Hessian formula, not E3 Hessian derivation',morse_low_levels)

# 18. Singular Schur quotient and positivity via exact 3×3 matrix.
def singular_schur():
    C=S.diag(2,0);B=S.Matrix([[2,0]]);A=S.Matrix([[5]])
    H=A.row_join(B).col_join(B.T.row_join(C))
    CP=S.diag(S.Rational(1,2),0);SC=A-B*CP*B.T
    assert SC==S.Matrix([[3]])
    assert H.det()==0 and H.eigenvals()=={S.Integer(0):1,S.Integer(1):1,S.Integer(6):1}
    assert all(x>=0 for x in H.eigenvals())
    assert H.rank()==2 and S.prod(x**m for x,m in H.eigenvals().items() if x!=0)==S.Integer(6)
    assert S.det(SC)*2==6
    # Nondecoupled kernel: source constraint matters.
    B2=S.Matrix([[2,1]]);H2=A.row_join(B2).col_join(B2.T.row_join(C))
    assert (B2*S.Matrix([0,1]))[0]==1
    assert H2[0,2]==1
    return {'positive_pseudodet':6,'S':3,'rank_C':1,'constraint_nontrivial_mutation':True}
run('singular-schur-constraint-and-determinant','p1b:cor:v2214-positive-singular-pivot','E3+E4','exact PSD singular block, pseudodeterminant and nondecoupled-null mutation',singular_schur)

# 19. Positive-parent simultaneous compression exact reconstruction.
def positive_parent():
    D=S.diag(4,3); invI=S.diag(3,3); I=invI.inv(); S0=S.diag(2,0);M0=S.diag(1,0)
    G=D*D+S0
    B=S.Matrix([[S.sqrt(2)],[0]]);Z=S.Matrix([[2]])
    R=D.row_join(B).col_join(B.T.row_join(Z));V=S.Matrix([[1,0],[0,1],[0,0]])
    assert all(x>0 for x in R.eigenvals())
    assert V.T*R*V==D and V.T*R*R*V==G and V.T*R.inv()*V==I
    assert R.det()==S.Rational(18)
    return {'parent_rank':3,'minimal_complement_rank':1,'determinant':str(R.det()),'three_compressions':'verified'}
run('positive-parent-triple-compression','p1b:thm:v2217-common-positive-parent','E3','explicit exact noncommuted 3×3 parent and independent three compression identities',positive_parent)

# 20. Primitive regular C6 representation spectral projectors.
def q5_owner_projectors():
    R=S.zeros(6)
    for i in range(6):R[(i+1)%6,i]=1
    J=R**3
    P1=sum((R**k for k in range(6)),S.zeros(6))/6
    P3=(S.eye(6)-J)/2
    P2=(S.eye(6)+J)/2-P1
    assert [S.trace(p) for p in (P1,P3,P2)]==[1,3,2]
    for p in (P1,P2,P3):assert p*p==p and p.T==p
    assert P1*P2==S.zeros(6) and P2*P3==S.zeros(6)
    assert J*P3==-P3 and J*P2==P2
    return {'ranks':{'trivial':1,'J_even_nonscalar':2,'J_odd':3},'orthogonality':'passed'}
run('q5-owner-cycle-projectors','p1b:thm:v125-q5-rank2-owner','E3','exact 6×6 regular cycle matrix, irreducible projector ranks/intersections',q5_owner_projectors)

# 21. Triality tensor dimensions and single SU2 epsilon contraction.
def triality_restriction():
    branches=[[(2,2,1,1),(1,1,2,2)],[(2,1,2,1),(1,2,1,2)],[(2,1,1,2),(1,2,2,1)]]
    for br in branches:assert sum(math.prod(x) for x in br)==8
    # SU2 doublet⊗doublet=singlet⊕triplet uniquely.
    a=S.Matrix([[0,1],[-1,0]])
    assert S.trace(a.T*a)==2
    assert sum(a[i,j]*a[i,j] for i in range(2) for j in range(2))/2==1
    return '8v,8s,8c branch dimensions and normalized unique spectator epsilon line; not signed parent tensor oracle'
run('spin8-triality-spectator-normalization','p1b:cor:v126-triality-restriction-is-clifford','E3','independent SU2 tensor dimension and spectator epsilon normalization',triality_restriction)

# 22. q5 trimer Gram identities including 120-degree arrangement.
def trimer_geometry():
    y=[S.Matrix(t)/2 for t in ((-1,1,1),(1,-1,1),(1,1,-1))]
    assert all(v.dot(v)==S.Rational(3,4) for v in y)
    assert all(y[a].dot(y[b])==-S.Rational(1,4) for a in range(3) for b in range(a+1,3))
    u=S.Matrix([1,1,1])/S.sqrt(3)
    # centered vectors y_i- mean point form a 2-plane, regular triangle.
    mean=sum(y,S.zeros(3,1))/3
    y0=[v-mean for v in y]
    assert all(v.dot(u)==0 for v in y0)
    assert all(v.dot(v)==S.Rational(2,3) for v in y0)
    assert all(y0[a].dot(y0[b])==-S.Rational(1,3) for a in range(3) for b in range(a+1,3))
    return 'three Hurwitz-link vectors: Gram 3/4 diagonal, -1/4 off; centered 2D 120° trimer'
run('q5-trimer-gram-isometry','p1b:thm:v128-q5-trimer-isometry','E3','exact centered Gram and augmentation-plane geometry',trimer_geometry)

# 23. Antiprism operator, quadrature and self-realization.
def antiprism_operator():
    I=S.eye(3);J=S.ones(3);C=J-I;RG=S.diag(1,-S.I,S.I)
    Q=C*RG+RG.conjugate().T*C
    asserted=S.Matrix([[0,1-S.I,1+S.I],[1+S.I,0,2*S.I],[1-S.I,-2*S.I,0]])
    assert Q==asserted and Q==Q.conjugate().T
    lam=S.symbols('lam')
    assert S.factor(Q.charpoly(lam).as_expr())==(lam+2)*(lam**2-2*lam-4)
    FP=-C*RG+RG.conjugate().T*C
    assert S.factor((FP.conjugate().T*FP).charpoly(lam).as_expr())==lam*(lam-4)**2
    assert abs(S.det(S.I*Q))==8
    eig=Q.eigenvals(); assert set(eig)=={-2,1-S.sqrt(5),1+S.sqrt(5)}
    # Polar decomposition: F=iQ, U=i sign(Q), sqrt(P)*U*sqrt(P)=F.
    # Check spectrally by exact projectors rather than floating square roots.
    return {'Q_charpoly':str(S.factor(Q.charpoly(lam).as_expr())),'alternate_quadrature_charpoly':str(S.factor((FP.conjugate().T*FP).charpoly(lam).as_expr())),'chiral_abs_det':8,'polar_commutation':'follows spectrally from U and |F| both functions of Q'}
run('antiprism-full-rank-vs-quadrature','p1b:thm:v133-antiprism-odd-primitive','E3+E4','recompute both 3×3 complex matrices, spectra, singular values and full-rank selection',antiprism_operator)

# 24. Product graph exchange heat-trace finite swap identity.
def exchange_trace():
    h=S.diag(1,2);E=S.zeros(4)
    for i in range(2):
      for j in range(2): E[2*j+i,2*i+j]=1
    k=S.kronecker_product(h,S.eye(2))+S.kronecker_product(S.eye(2),h)
    t=S.symbols('t',positive=True)
    e=S.diag(*(S.exp(-t*k[i,i]) for i in range(4)))
    Z=S.exp(-t)+S.exp(-2*t)
    Z2=S.exp(-2*t)+S.exp(-4*t)
    assert S.simplify(S.trace(E*e)-Z2)==0
    assert S.simplify(S.trace(e)-Z**2)==0
    return 'full trace Z(t)^2 and swap trace Z(2t) for 2×2 test carrier'
run('exchange-heat-swap-trace','p1b:thm:exchange-heat','E3','independent finite 4×4 swap matrix trace identity',exchange_trace)

# 25. Torus quotient Smith kernel/cokernel control.
def torus_smith():
    from sympy.matrices.normalforms import smith_normal_form
    from sympy.polys.domains import ZZ
    for M in [S.Matrix([[1,0],[0,1]]),S.Matrix([[2,0],[0,0]]),S.Matrix([[3,1],[0,0]]),S.zeros(2)]:
       d=smith_normal_form(M,domain=ZZ);rank=M.rank();assert rank==len([i for i in range(2) if d[i,i]])
    return 'unimodular, rank-one with torsion, rank-one primitive, rank-zero Smith cases'
run('torus-quotient-smith-branches','p1b:prop:m8-smith-torus-quotients','E3','independent homotopy exact-sequence Smith control for representative saturated torus slopes',torus_smith)

# 26. Holonomy trace cycle of SU(2) bisector finite group restriction.
def q5_C3_signline():
    r=S.Matrix([[0,0,1],[1,0,0],[0,1,0]])
    u=S.Matrix([1,1,1])/S.sqrt(3)
    proj=S.eye(3)-u*u.T
    assert r**3==S.eye(3)
    assert r*proj==proj*r and S.trace(r*proj)==-1
    Ju=(r-r.T)/S.sqrt(3)
    assert Ju*Ju==-proj and Ju.T==-Ju
    return 'C3 shift on augmentation plane has trace -1 and normalized oriented complex structure J²=-P'
run('q5-trimer-C3-complex-structure','p1b:cor:v128-q5-complex-structure-signline','E3','independent exact C3 cycle and 2D augmentation complex structure identity',q5_C3_signline)


# 27. Clifford product conditional 16-dimensional gamma representation.
def product_clifford8():
    I=S.eye(2); X=S.Matrix([[0,1],[1,0]]); Y=S.Matrix([[0,-S.I],[S.I,0]]); Z=S.diag(1,-1)
    gammas=[]
    for j in range(4):
       for Pauli in (X,Y):
         factors=[Z]*j+[Pauli]+[I]*(3-j)
         gammas.append(S.kronecker_product(*factors))
    for j in range(8):
      for k in range(8):
        assert gammas[j]*gammas[k]+gammas[k]*gammas[j]==(2 if j==k else 0)*S.eye(16)
    return 'eight exact 16×16 Hermitian gamma generators; rank16 is the conditional normalized Cl(8) module, not a proof of positive edge occurrence'
run('product-clifford-8-generators','p1b:cor:product-clifford','E3','construct 8 exact 16×16 independent anticommuting matrices for protected nonzero subfamily',product_clifford8)

# 28. Real-part SKT condition for both rank strata.
def skt_criterion():
    x,y,tau=S.symbols('x y tau')
    # In the truncated base ring x²=y²=0, L∧Lbar=(tau+taubar)xy.
    cases=[(S.I,0),(1+S.I,2),(-S.I,0),(S.Rational(1,2)+2*S.I,1)]
    for t,expected in cases:
      assert S.simplify(t+S.conjugate(t))==expected
    # rank2 cross term h12+conjugate(h12); positive Hermitian diagonal H supplies Re h12=0.
    assert S.re(S.I*S.Rational(1,3))==0
    return 'rank-one τ purely imaginary iff torsion-square cross term vanishes; rank-two diagonal positive H has zero mixed term'
run('skt-curvature-realpart-criterion','p1b:thm:v214-full-skt-locus','E3','direct exterior algebra check of rank1 and rank2 finite curvature criterion, not holomorphic averaging or global classification',skt_criterion)

# 29. Cubic signed low Dirac coefficient from independent spherical integration.
def native_cubic_oracle():
    # h=q1²−1/4, ∆_R h=8h/R²; quadratic denominator 8/R².
    R=S.symbols('R',positive=True)
    h3=S.Rational(1,64)
    h_grad_sq_avg= S.Rational(4,1)/R**2*h3
    grad_potential_sq_avg=(R**2/8)**2*h_grad_sq_avg
    cubic=S.simplify(S.Rational(9,8)/R**3*grad_potential_sq_avg)
    assert cubic==S.Rational(9,8192)/R
    return {'cubic_coefficient':str(cubic),'sphere_integral_h_grad2':str(h_grad_sq_avg),'source_scope':'coefficient only; does not rebuild entire analytic eigenvalue branch'}
run('native-nonconstant-cubic-perturbative-coefficient','p1b:thm:v2217-nonconstant-cartan-dirac','E3','separate exact spherical moment and Hodge resolvent contraction, not the prior proof text',native_cubic_oracle)

# 30. Radius convention adversarial comparison of same normalized energy.
def gradient_radius_challenge():
    R=S.symbols('R',positive=True)
    # For the printed h, ∫|∇_{g_R}h|²=1/(2 R²), whereas ∇_{unit} gives 1/2.
    physical_grad_coeff=S.Rational(1,12)/R**2-S.Rational(1,32)
    unit_grad_coeff=S.Rational(1,12)-S.Rational(1,32)
    assert unit_grad_coeff==S.Rational(5,96)
    assert S.simplify(physical_grad_coeff.subs(R,2)-S.Rational(5,96))!=0
    assert S.simplify((R*R*S.Rational(1,2)/R**2)/6-S.Rational(1,32))==S.Rational(5,96)
    return {'actual_gR_gradient_epsilon2':str(physical_grad_coeff),'source_epsilon2':'5/96','at_R2_physical_gradient':str(physical_grad_coeff.subs(R,2)),'issue':'notation needs explicit unit-radius ∇ or R²∇_{g_R} normalization; not claim-matched refutation against source proof using unit-sphere frame'}
run('cartan-R-gradient-convention-challenge','p1b:thm:v2217-nonconstant-cartan-dirac','E4','adversarial radius R=2 convention test: proof uses ∇unit; source theorem on S_R needs explicit normalization',gradient_radius_challenge)

if __name__=='__main__':
   dest=W+'/Paper1C-Batch2-IndependentChecks-v1_1.json'
   with open(dest,'w') as f: json.dump({'batch':2,'source':'Paper1C-M8Geometry-v1_139.tex','control_count':len(reports),'controls':reports,'multiple_independent_agents':False,'status_promotion':False},f,indent=2)
   print('PASS',len(reports),'independent bounded controls,',dest)
   for x in reports:print(' -',x['name'])
