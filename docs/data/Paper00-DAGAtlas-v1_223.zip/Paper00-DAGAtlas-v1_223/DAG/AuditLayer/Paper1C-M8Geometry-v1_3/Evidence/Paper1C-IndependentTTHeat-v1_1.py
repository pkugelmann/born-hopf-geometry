#!/usr/bin/env python3
"""Independent rank/trace TT analytic spectral checks of the all-level 8D product formula."""
import sympy as sp
a,b,t=sp.symbols('a b t', positive=True)
def A(h):return sp.exp(h)
def C(h):return sp.exp(h)+2-4*h
def B(h):return 2*sp.exp(-3*h)*(1-8*h)+sp.exp(h)+2-4*h
P=B(a*t)*A(b*t)+A(a*t)*B(b*t)+C(a*t)*C(b*t)+C(a*t)*A(b*t)+A(a*t)*C(b*t)+2*A(a*t)*A(b*t)
series=sp.series(P,t,0,3).removeO().expand()
assert sp.simplify(series.coeff(t,0)-27)==0
assert sp.simplify(series.coeff(t,1)+27*(a+b))==0
assert sp.simplify(series.coeff(t,2)-(sp.Rational(129,2)*(a*a+b*b)-45*a*b))==0
print('TT local A0=27V A2=-27(a+b)V A4=[129/2(a²+b²)-45ab]V PASS')
# Fiber isotropy rank: tf has 35 vs vector 8 => principal symbol 27
assert 5+5+9+6+6+4==35 and 3+3+2==8
# Killing correction rank: (3+3)+(3+3)+2=14
assert 4*3+2==14
# Scalar tensor components independent of sphere directions: 2 sphere traces + torus sym(2)=3 minus one overall trace =>4
assert 2+2*(2+1)//2-1==4
print('TT representation rank 35, vector constraint rank 8, Killing dim 14, zero-mode dim 4 PASS')
