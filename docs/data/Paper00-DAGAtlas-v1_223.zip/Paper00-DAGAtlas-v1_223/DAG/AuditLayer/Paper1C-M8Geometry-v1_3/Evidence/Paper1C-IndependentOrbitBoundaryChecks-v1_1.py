#!/usr/bin/env python3
"""Independent finite quotients supporting EV0002/EV0004, not topology/affine certificates."""
import math
from itertools import product

def closure_image(vals):
 A,B,C,D=vals
 return {((B*i-A*j)%12,(D*i-C*j)%12) for i in range(12) for j in range(12)}

def index_minors(vals):
 A,B,C,D=vals
 minors=[144,12*A,12*B,12*C,12*D,B*C-A*D]
 return math.gcd(*minors)

cases=0
for A,B,C,D in product(range(-3,4),repeat=4):
 actual=144//len(closure_image((A,B,C,D)))
 expected=index_minors((A,B,C,D))
 assert actual==expected,(A,B,C,D,actual,expected)
 cases+=1
print(f'PASS: {cases} full finite image quotients = exact 2x4 minor gcd.')

# The linear Heisenberg 2-type shear on F2^3 (r,s,e) ->(r,s,e+b*r+a*s)
def secondary_orbits():
 domain=set(product(range(2),repeat=3)); out=[]
 while domain:
  r,s,e=min(domain)
  orbit={(r,s,(e+b*r+a*s)%2) for a,b in product(range(2),repeat=2)}
  assert orbit<=domain
  domain-=orbit;out.append(orbit)
 return out
O=secondary_orbits()
assert len(O)==5 and sorted(map(len,O))==[1,1,2,2,2]
print('PASS: zero-Chern secondary shear has 5 orbits, yielding 12²*5=720 determinant-preserving classes per epsilon sector.')

# Source-specified normalized boundary group Z x T, T=C6 x C2 x C2,
# integer image 2Z, with finite images J0 below.
T=list(product(range(6),range(2),range(2)))
t=(0,0,1);a=(3,0,0)
def add(x,y):return ((x[0]+y[0])%6,(x[1]+y[1])%2,(x[2]+y[2])%2)
def span(*gens):
 S={(0,0,0)}
 for g in gens:S|={add(x,y) for x in list(S) for y in {add(add(g,g),g),g}}
 # closure exhaustive
 while True:
  N={add(x,y) for x in S for y in S}
  if N==S:break
  S=N
 return S
sz={'even0':len(span(t)),'even1':len(span(a,t)),'odd0':len(span()),'odd1':len(span(a,t))}
assert sz=={'even0':2,'even1':4,'odd0':1,'odd1':4}
counts={key:48//v for key,v in sz.items()}
assert counts=={'even0':24,'even1':12,'odd0':48,'odd1':12}
assert 2*(counts['even0']+counts['even1'])==72
assert 2*(counts['odd0']+counts['odd1'])==120
print('PASS: conditional normalized W boundary quotient 24,12,48,12; even/odd totals 72/120.')
print('LIMIT: this script does not certify global gauge realizability or missing affine stabilizer actions.')
