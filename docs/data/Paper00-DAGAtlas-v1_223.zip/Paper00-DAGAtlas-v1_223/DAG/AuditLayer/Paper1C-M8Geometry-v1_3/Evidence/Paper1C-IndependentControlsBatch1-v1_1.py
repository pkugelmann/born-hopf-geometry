#!/usr/bin/env python3
"""Independent exact checks of explicit current Paper1C v1_137 claims, formal #0--125.
Checks are mathematical controls, not complete proofs of imported topology or equivariance.
"""
from itertools import combinations,product
from math import gcd
from functools import reduce
from collections import Counter,defaultdict
from pathlib import Path
import hashlib, json, re
from sympy import Matrix
from sympy.matrices.normalforms import smith_normal_form
from sympy.polys.domains import ZZ
P=Path('/mnt/data/bh_audit_work/papers/Paper1C-M8Geometry-v1_137.tex')
assert hashlib.sha256(P.read_bytes()).hexdigest()=='c09f2f8b49860114e0eb840c5414528efd16ff588e2e99f6d48aa03cb529b029'
checks=[]
def check(key,actual,expected,derivation,grade='E3_exact_control'):
 assert actual==expected,(key,actual,expected)
 checks.append({'id':key,'result':'PASS','actual':actual,'expected':expected,'basis':derivation,'evidence_level':grade})

def wedge(left,right):
 if len(set(left+right))<len(left)+len(right):return (0,())
 vals=left+right
 inv=sum(vals[i]>vals[j] for i in range(len(vals)) for j in range(i+1,len(vals)))
 return (-1 if inv%2 else 1,tuple(sorted(vals)))

deg=(1,1,3,3)
basis=[p for n in range(5) for p in combinations(range(4),n)]
betti=Counter(sum(deg[i] for i in c) for c in basis)
check('B1-E3-001',tuple(betti[d] for d in range(9)),(1,2,1,2,4,2,1,2,1),'Exterior Kunneth basis for two S1 and two S3 factors')

def exchange(m):
 t=tuple({0:1,1:0,2:3,3:2}[i] for i in m)
 sign,_=wedge(t,())
 return sign,tuple(sorted(t))

seen=set();ep=Counter();em=Counter();defects=Counter(); signed_orbits=[]
for m in basis:
 if m in seen:continue
 sign,r=exchange(m)
 d=sum(deg[i] for i in m)
 if m==r:
  (ep if sign==1 else em)[d]+=1
  seen.add(m);signed_orbits.append({'basis':list(m),'paired':list(r),'sign':sign,'defect':0})
 else:
  assert exchange(r)==(sign,m)
  ep[d]+=1;em[d]+=1;defects[d]+=1
  seen.update((m,r));signed_orbits.append({'basis':list(m),'paired':list(r),'sign':sign,'defect':1})
check('B1-E3-002',tuple(ep[i] for i in range(9)),(1,1,0,1,2,1,0,1,1),'Signed factor exchange on all 16 Kunneth monomials')
check('B1-E3-003',tuple(em[i] for i in range(9)),(0,1,1,1,2,1,1,1,0),'Signed factor exchange and rank-one antisymmetrizers on two-cycles')
check('B1-E3-004',tuple(defects[i] for i in range(9)),(0,1,0,1,2,1,0,1,0),'Index two per swapped integral-basis pair; total Z2^6')

b4=((0,2),(0,3),(1,2),(1,3))
Q=tuple(tuple(wedge(a,b)[0] if wedge(a,b)[1]==(0,1,2,3) else 0 for b in b4) for a in b4)
check('B1-E3-005',Q,((0,0,0,-1),(0,0,1,0),(0,1,0,0),(-1,0,0,0)),'Use graded exterior signs, not guessed intersection convention')
check('B1-E3-006',int(Matrix(Q).det()),1,'Unimodular middle intersection lattice')
check('B1-E3-007',tuple(Matrix(Q).eigenvals().items()),((-1,2),(1,2)),'Signature (2,2) as H plus H')

# centralizer of scalar swap in GL(2,Z): [a b; b a] with |a^2-b^2|=1
C=[]
for a,b in product(range(-12,13),repeat=2):
 if abs(a*a-b*b)==1:C.append((a,b))
check('B1-E3-008',sorted(C),sorted(((1,0),(-1,0),(0,1),(0,-1))), 'Integer factorization (a-b)(a+b)=±1')

# Smith invariant factors for rank-three fixed-Chern fibre. Independent finite quotient counting.
def gcds(*args):return reduce(gcd,(abs(int(x)) for x in args),0)
counts=0
examples=[(m,A,B,C,D) for m in (-5,-3,-2,0,1,3,6) for A,B,C,D in ((0,0,0,0),(1,2,3,4),(4,3,2,1),(-2,2,3,6),(1,0,0,1),(5,2,-3,7),(6,0,0,6))]
for m,A,B,C,D in examples:
 g=gcd(6,2*m)
 mat=Matrix([[g,0,A,B],[0,g,C,D]])
 S=smith_normal_form(mat,domain=ZZ)
 invariants=tuple(abs(int(S[i,i])) for i in (0,1))
 d1=gcds(g,A,B,C,D)
 d2=gcds(g*g,g*A,g*B,g*C,g*D,A*D-B*C)
 assert invariants==(d1,d2//d1)
 # independent direct enumeration of generated submodule in (Z/g)^2
 v=[(A%g,C%g),(B%g,D%g)]
 covered={(0,0)};front=[(0,0)]
 while front:
  x,y=front.pop()
  for vx,vy in v:
   nxt=((x+vx)%g,(y+vy)%g)
   if nxt not in covered:covered.add(nxt);front.append(nxt)
 assert (g*g//len(covered))==d2
 counts+=1
check('B1-E3-009',counts,49,'Direct finite quotient, determinantal divisors and Smith form agree for 49 diverse M8 cases','E2_sample_crosscheck_plus_exact_Smith_identity')
check('B1-E3-010',(gcd(6,0)**2, (gcd(6,0),gcd(6,0))), (36,(6,6)),'Zero-Chern rank-three fibre from Z2/6Z2')

# determinant boundary under Heisenberg commutator; inverse and direct product, not imported orbit formula
def mul(h,k):
 a,b,z=h;x,y,w=k
 return (a+x,b+y,(z+w+a*y)%12)
def inv(h):
 a,b,z=h;return (-a,-b,(-z+a*b)%12)
for A,B,C,D in product(range(-3,4),repeat=4):
 x=(A,B,0);y=(C,D,0)
 assert mul(mul(mul(x,y),inv(x)),inv(y))==(0,0,((A*D-B*C)%12))
check('B1-E3-011',7**4,2401,'Heisenberg group multiplication directly yields commutator AD-BC = -Delta modulo 12','E2_samples_of_symbolic_group_identity')

# fixed G15 sector bit ε, determinant parity n: existence theorem equivalence over both ε choices
ntries=0
for n in range(-2,3):
 for A,B,C,D in product(range(-3,4),repeat=4):
  delta=B*C-A*D
  lhs= delta%(12 if n%2==0 else 6)==0
  rhs=any((delta-6*eps*n)%12==0 for eps in (0,1))
  assert lhs==rhs
  ntries+=1
check('B1-E3-012',ntries,5*(7**4),'G20 complex rank-two existence equals union of epsilon=0/1 determinant boundary congruences','E2_samples_plus_mod12_caseproof')

# equivariant index integrality and quaternionic parity in the actual Born-invariant existence locus
tries=0
for A,B in product(range(-128,129),repeat=2):
 delta=B*B-A*A
 if delta%12:continue
 v= A+B
 mp=(delta+3*v)
 mm=(delta-3*v)
 assert ((mp%12==0 and mm%12==0)==(v%4==0))
 assert ((mp%24==0 and mm%24==0)==(mp%24==0))
 tries+=1
check('B1-E3-013',tries,tries,'On the Born-invariant 12|Delta domain, both Dirac virtual indices integral iff 4|(A+B), and both even iff mod24 test','E2_samples_plus_modular_identity')
check('B1-E3-014',(gcd(12,0)*3,2*gcd(12,0)*3),(36,72),'G21 zero-Chern fixed principal class count; not coherent lift count')

# Primitive exchange-stable cocharacter slopes in Z^2.
slopes=[(a,b) for a,b in product(range(-12,13),repeat=2) if gcd(abs(a),abs(b))==1 and (b,a) in ((a,b),(-a,-b))]
check('B1-E3-015',sorted(slopes),sorted(((1,1),(-1,-1),(1,-1),(-1,1))),'Exchange invariance of primitive scalar one-torus up to orientation')

# Exactly verify the reported stable Chern character and eigenphase map without imported theorems.
from sympy import symbols,simplify
A0,B0,C0,D0,n0,m0,s0=symbols('A B C D n m s', integer=True)
delta0=B0*C0-A0*D0
ch4=simplify((2*delta0+2*(2*n0*m0)-2*(delta0+2*n0*m0-6*s0))/12)
check('B1-E3-023',ch4,s0,'Newton ch4 numerator from c2 square and c1c3, exact for all integer parameters')
check('B1-E3-024', (int(Matrix([[1,1],[1,-1]]).det()),Matrix([[1,1],[1,-1]])**2==2*Matrix.eye(2)),(-2,True),'Eigenphase cover is index-two with A²=2I')

# Exact degree-12/20 overlap polynomial obstruction from the printed finite icosahedral theorem.
from sympy import symbols,Rational,Poly,gcd as poly_gcd
w=symbols('w')
F12=1-28*w+196*w**2-420*w**3
F20=1-Rational(220,3)*w+Rational(4532,3)*w**2-Rational(36212,3)*w**3+Rational(119680,3)*w**4-44880*w**5
check('B1-E3-016',(F12.subs(w,0),F12.subs(w,Rational(1,4))),(1,Rational(-5,16)),'Intermediate value theorem supplies an interior degree-12 overlap zero')
check('B1-E3-017',int(Poly(poly_gcd(F12,F20),w).degree()),0,'Euclidean polynomial gcd is 1; degree-12 overlap root does not annul degree-20 character')
check('B1-E3-018',((9+1)*(9+2)*(2*9+3)//6,(19+1)*(19+2)*(2*19+3)//6),(385,2870),'Complete S3 scalar harmonic band dimension formula')
check('B1-E3-019',(Rational(25,256)*Rational(11,32),Rational(25,256)*Rational(21,32)),(Rational(275,8192),Rational(525,8192)),'Sandwiched rank-one projectors and branch-symmetric Reynolds decomposition')
check('B1-E3-020',all(0 < x < 1 for x in (Rational(275,8192),Rational(525,8192))),True,'Finite powers remain nonzero in degree 12, while they tend to zero')

# Check current relocated appendix imports exist, preserving label identity.
other=Path('/mnt/data/bh_audit_work/papers/Paper1D-TechnicalMaterial-v1_65.tex').read_text()
imported=('p1b:app:g15','p1b:app:g20','p1b:app:g20-determinant-forgetting','p1b:app:g21','p1b:app:g21-exotic-construction','p1b:app:g12','p1b:app:finite-checks')
found=[x for x in imported if '\\label{'+x+'}' in other]
check('B1-E0-021',tuple(found),imported,'Cross-paper exact label identity is source-presence only, not E3 theorem verification','E0_locator')

# Crawl actual current source labels referenced by exact statements / immediately following proofs, #0--125.
alltex='\n'.join(p.read_text() for p in Path('/mnt/data/bh_audit_work/papers').glob('Paper*.tex'))
all_labs=set(re.findall(r'\\label\{([^}]+)\}',alltex))
census=json.load(open('/mnt/data/bh_audit_work/work/full_census.json'))
missing=set(); hits=set();
for c in census[:126]:
 for ref in re.findall(r'\\(?:ref|eqref|autoref)\{([^}]+)\}',c['source_text']+'\n'+(c['proof_text'] or '')):
  hits.add(ref)
  if ref not in all_labs:missing.add(ref)
check('B1-E0-022',tuple(sorted(missing)),(),f'Resolved {len(hits)} literal theorem/equation refs to current 31-paper source corpus','E0_locator')

result={'target_file':P.name,'target_source_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'audit_batch':1,'formal_indices':[0,125],'independent_script_author':'sequential single-executor fresh code, distinct from historical audit scripts','checks':checks,'passed':len(checks),'failed':0,'material_scope_limits':['Exact group/cohomology/number-theory computations and locator integrity only; do not imply independent global equivariant bundle classification','Tests over samples are supporting E2; analytical Smith invariant proof uses established determinantal divisor theorem','No proof of physical realization, source incidence or observable mass/decay supplied by these controls']}
out=Path('/mnt/data/bh_audit_work/work/Paper1C-IndependentControlsBatch1Results-v1_1.json')
out.write_text(json.dumps(result,indent=2,ensure_ascii=False,default=str))
print('PASSED',len(checks),'controls; checked',len(hits),'references; source',result['target_source_sha256'])
for c in checks:print(c['id'],c['result'],str(c['actual'])[:150])
