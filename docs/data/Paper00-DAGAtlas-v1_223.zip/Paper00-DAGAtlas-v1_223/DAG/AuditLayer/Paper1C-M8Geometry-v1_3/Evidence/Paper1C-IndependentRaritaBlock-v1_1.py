#!/usr/bin/env python3
"""Independent exact constant-orbital block of intrinsic 8D Rarita--Schwinger on S3xS3xT2.
Directly constructs 8D Clifford, torsion-free spin/tangent connections,
gamma projection, twistor, and twisted Dirac. Checks full Weitzenbock
identities on block (j_x,j_p,n)=(0,0,0).
"""
import numpy as np
from functools import reduce
I2=np.eye(2,dtype=complex)
X=np.array([[0,1],[1,0]],dtype=complex)
Y=np.array([[0,-1j],[1j,0]],dtype=complex)
Z=np.diag([1.,-1.]).astype(complex)
def kr(*a): return reduce(np.kron,a)
c=[]
for k in range(4):
 c.append(1j*kr(*([Z]*k+[X]+[I2]*(3-k))))
 c.append(1j*kr(*([Z]*k+[Y]+[I2]*(3-k))))
c=np.array(c)
spin=16;tan=8;D=128
Id16=np.eye(spin,dtype=complex);Id8=np.eye(tan,dtype=complex);Id128=np.eye(D,dtype=complex)
assert max(np.linalg.norm(c[i]@c[j]+c[j]@c[i]+(2*Id16 if i==j else 0)) for i in range(8) for j in range(8))<1e-12
def eps(i,j,k):
 if len({i,j,k})<3:return 0
 return 1 if (i,j,k) in [(0,1,2),(1,2,0),(2,0,1)] else -1
B=[np.zeros((8,8),dtype=complex) for i in range(8)]
Omega=[np.zeros((16,16),dtype=complex) for i in range(8)]
for offs in (0,3):
 for a in range(3):
  i=offs+a
  for b in range(3):
   j=offs+b
   for d in range(3):
    k=offs+d
    Gamma=eps(a,b,d)
    B[i][k,j]+=Gamma
    Omega[i]+=(Gamma/4)*c[j]@c[k]
# Gamma^i and inverse contraction/gamma trace
mu=np.concatenate(list(c),axis=1)
mu_adj=mu.conj().T
assert np.linalg.norm(mu@mu_adj-8*Id16)<1e-11
proj=Id128-mu_adj@mu/8
assert np.linalg.norm(proj@proj-proj)<1e-11
assert abs(np.trace(proj)-112)<1e-10
# spinor covariant derivative block
Dspin=sum(c[i]@Omega[i] for i in range(8))
S=12
assert np.linalg.norm(Dspin@Dspin-4.5*Id16)<1e-10
nabla=np.concatenate(list(Omega),axis=0)
P=proj@nabla
# section covariant derivative on tangent-spinors
DT=sum(np.kron(B[i],c[i])+np.kron(Id8,c[i]@Omega[i]) for i in range(8))
assert np.linalg.norm(DT-DT.conj().T)<1e-10
Q=proj@DT@proj
lhs=P.conj().T@P
rhs=7/8*(Dspin@Dspin)-S/4*Id16
assert np.linalg.norm(lhs-rhs)<1e-10, (np.linalg.norm(lhs-rhs), np.linalg.eigvalsh(lhs))
A=Q@Q+0.5*P@P.conj().T
Bcheck=proj@DT@DT@proj
err=np.linalg.norm(A-Bcheck)
print('identity err',err)
assert err<1e-10
vals=np.linalg.eigvalsh(Q)
maxghost=float(np.max(abs(np.linalg.eigvalsh(lhs)-0.9375)))
print('Clifford rank 112, Dspin² 9/2, P†P 15/16:', maxghost)
print('Q on (j_x,j_p,n)=(0,0,0), nonzero eigenvalues (sample):',np.unique(np.round(vals[np.abs(vals)>1e-8],8),return_counts=True))
print('Q full ambient zero eigenvalues (gamma-trace projection complement, excluded):',int(np.sum(abs(vals)<1e-7)))
assert int(np.sum(abs(vals)<1e-7))==16
print('Q genuine zero modes within gamma-traceless subspace:',int(np.sum(abs(vals)<1e-7))-16)
print('Q smallest absolute genuine eigenvalue:',float(np.min(abs(vals[abs(vals)>1e-8]))))
print('Positive coupled A_RS min eigen within gamma subspace:',np.linalg.eigvalsh(A)[16])
assert np.linalg.eigvalsh(A)[16] > 1.0
print('PASS: exact Clifford projection and squared operator identity on full constant-orbital block.')
