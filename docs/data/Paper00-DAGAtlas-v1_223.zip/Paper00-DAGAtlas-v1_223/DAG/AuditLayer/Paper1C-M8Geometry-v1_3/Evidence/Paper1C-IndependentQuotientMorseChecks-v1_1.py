#!/usr/bin/env python3
"""Independent exact checks for G10 branching and native YM spin coupling.
Strictly finite/algebraic tests; explanatory global proofs are in the closure report.
"""
import sympy as sp
from collections import Counter
from functools import reduce
z=sp.symbols('z')
f6=z*(z**4-1);f8=z**8+14*z**4+1;g=z**12-33*z**8-33*z**4+1;u=f6**2
assert sp.expand(f8**3-g**2-108*u**2)==0
assert sp.expand(sp.diff(u,z)*g-u*sp.diff(g,z)+2*f6*f8**2)==0
assert sp.gcd(u,g)==sp.gcd(f6,f8)==1
assert sp.gcd(f8,sp.diff(f8,z))==1
assert sp.gcd(f6,sp.diff(f6,z))==1
assert sp.degree(g)==12 and sp.degree(u)==10 # u12 is homogeneous degree 12 with y^2 at infinity
print('G10 PASS: basepoint-free degree-12 pair, Wronskian, 6 simple index-2 and 8 index-3 finite/infinity roots.')

def spin_matrices(j):
    d=int(2*j+1)
    mz=[j-k for k in range(d)]
    p=sp.zeros(d)
    for col,m in enumerate(mz):
        if col>0:
            p[col-1,col]=sp.sqrt((j-m)*(j+m+1))
    mm=p.T
    return ((p+mm)/2,(p-mm)/(2*sp.I),sp.diag(*mz))

def kr(*matrices):return reduce(sp.kronecker_product,matrices)

def mat_spectrum(M):
    vals=M.eigenvals()
    return dict(sorted([(sp.simplify(k),v) for k,v in vals.items()],key=lambda kv:float(kv[0])))

for j,expected,expectedghost in [
    (sp.Integer(0),{-2:1,2:3,10:5},{2:3}),
    (sp.Rational(1,2),{1:4,7:8,17:6},{1:2,7:4}),
    (sp.Integer(1),{2:1,6:9,14:10,26:7},{2:1,6:3,14:5})]:
    L=spin_matrices(j);S=spin_matrices(sp.Integer(1));T=spin_matrices(sp.Integer(1))
    dl=int(2*j+1)
    D=dl*9
    eyej=sp.eye(dl); eyes=sp.eye(3); eyet=sp.eye(3)
    Jsq=sp.zeros(D)
    for a in range(3):
        Ja=kr(L[a],eyes,eyet)+kr(eyej,S[a],eyet)+kr(eyej,eyes,T[a]); Jsq+=Ja*Ja
    H=2*Jsq+(2*j*(j+1)-2)*sp.eye(D)
    spec=mat_spectrum(H)
    assert spec=={sp.Integer(k):v for k,v in expected.items()},(j,spec)
    Ksq=sp.zeros(dl*3)
    for a in range(3):
        Ka=kr(L[a],eyet)+kr(eyej,T[a]);Ksq+=Ka*Ka
    Ghost=2*Ksq+(2*j*(j+1)-2)*sp.eye(dl*3)
    gspec=mat_spectrum(Ghost)
    assert gspec=={sp.Integer(k):v for k,v in expectedghost.items()},(j,gspec)
    print(f'YM PASS: j={j}, vector Hessian spectrum={spec}, ghost={gspec}')
print('YM all tested representations: ghost strictly positive, unique homogeneous negative mode, first positive quotient at 1.')
