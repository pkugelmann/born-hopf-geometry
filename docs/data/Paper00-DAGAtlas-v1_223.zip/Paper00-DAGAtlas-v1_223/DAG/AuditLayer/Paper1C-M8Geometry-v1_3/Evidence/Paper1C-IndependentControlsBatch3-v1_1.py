#!/usr/bin/env python3
"""Adversarial independent, scope-limited algebra/geometry checks for Paper I-C M8, claims #250-373.

Each control specifies exactly what it tests. Exact finite identities != global geometric verification.
The current manuscript is source authority. No paper source or atlas is modified.
"""
import hashlib, json, math, itertools, collections, re
from pathlib import Path
import numpy as np
from sympy import (Matrix, MatrixSymbol, Rational as Q, symbols, Symbol, sqrt, I, pi, cos, sin,
                   simplify, expand, factor, diag, eye, diff, binomial, cancel, Poly, conjugate)
from sympy.physics.wigner import clebsch_gordan
P=Path('/mnt/data/bh_audit_work/papers/Paper1C-M8Geometry-v1_137.tex')
W=Path('/mnt/data/bh_audit_work/work')
SHA='c09f2f8b49860114e0eb840c5414528efd16ff588e2e99f6d48aa03cb529b029'
assert hashlib.sha256(P.read_bytes()).hexdigest()==SHA
census=json.load(open(W/'full_census.json'))
assert len(census)==490 and census[250]['label']=='p1b:result:an-explicit-inhomogeneous-zero-mode' and census[373]['label']=='p1b:prop:v215-log-legendre-hessian'
C=[]
def test(got,want,method,claim,grade='E3_EXACT_RESTRICTED_RESULT',tol=None):
    code=f'B3-{grade[:2]}-{len(C)+1:03d}'
    if tol is None: ok=got==want
    else:ok=bool(np.allclose(np.asarray(got,dtype=float),np.asarray(want,dtype=float),atol=tol,rtol=tol))
    C.append({'id':code,'status':'PASS' if ok else 'FAIL','actual':repr(got)[:600],
       'expected':repr(want)[:600],'independent_method':method,'evidence_grade':grade,
       'related_claim_indices':claim if isinstance(claim,list) else [claim],
       'tolerance':tol})
    if not ok:print('FAIL',code,method,repr(got)[:170],repr(want)[:170])

def z(x):return simplify(x)==0

def zr(m):return all(z(x) for x in m)

# 250-257: protected state, Cartan barrier, spatial Morse and shell pair representations.
y,eps,R,eta,U,s,L=symbols('y eps R eta U s L',real=True,positive=True)
a=sqrt(3)*eps/2
# Entire power series about y=0 is 1 + a^2*y/6 + ...; no y-sqrt pole.
test((simplify(a*a/6),simplify(a**4/120)),(eps**2/8,3*eps**4/640),'Taylor coefficients of sinh(a sqrt y)/(a sqrt y) at y=0',250)
# Cartan N_CS and YM in lambda as an independent polynomial expansion.
f=symbols('f',real=True);lam=symbols('lam',real=True)
fl=Q(1,2)-R*lam/3
test(z((3*fl**2-2*fl**3)-(Q(1,2)-R*lam/2+2*R**3*lam**3/27)),True,'Exact cubic Chern-Simons interpolation after substituting Dirac parameter',255)
test(z(4*fl**2*(1-fl)**2 - Q(1,4)*(1-4*R*R*lam**2/9)**2),True,'Exact quartic YM barrier as a Dirac eigenvalue function',255)
test((simplify((12-U*U)/(12+8*U*U)).subs(U,1),simplify(-3*(3-U*U)/(2*R*(3+2*U*U))).subs(U,1)),(Q(11,20),-Q(3,5)/R),'Sharp endpoint of bounded-profile scalar weight and signed-slope estimates',251)
test(z((1-4*Q(11,20))/(2*R)+Q(3,5)/R),True,'Hellmann-Feynman lower slope from scalar-weight bound',251)
# Orbital harmonic j, vector spin one, isospin 1: j=0,1/2,1.
def val(j,J):return 2*J*(J+1)+2*j*(j+1)-2
for j,labels,expected in [(Q(0),[Q(0),Q(1),Q(2)],[-2,2,10]),(Q(1,2),[Q(1,2),Q(3,2),Q(5,2)],[1,7,17]),(Q(1),[Q(0),Q(1),Q(2),Q(3)],[2,6,14,26])]:
    test([val(j,v) for v in labels],expected,f'Independent Clebsch 1⊗1⊗j Casimir spectrum j={j}, before ghost quotient',253)
for j,k,expected in [(0,1,2),(Q(1,2),Q(1,2),1),(1,0,2),(1,1,6)]:
    test(2*j*(j+1)+2*k*(k+1)-2,expected,'Ghost orbital+isospin Casimir gap from exact rational spins',253)
# S3 coordinate moments: beta(1/2,3/2) for q1^2: moment E[q1^(2r)] = (1/2)_r/(2)_r
mom=lambda r: math.prod([Q(1,2)+k for k in range(r)],start=Q(1))/math.prod([Q(2)+k for k in range(r)],start=Q(1))
h=[sum(binomial(k,i)*(-Q(1,4))**(k-i)*mom(i) for i in range(k+1)) for k in range(1,5)]
test(tuple(map(simplify,h)),(0,Q(1,16),Q(1,64),Q(3,256)),'Integrate q1^2−1/4 moments via exact Beta-law of the S3 coordinate',256)
# Laplacian evalue on degree-2 harmonic is 8/R²; <|grad h|²>=8<h²>.
test(8*Q(1,16),Q(1,2),'Round-sphere harmonic gradient mean from Laplace eigenvalue n(n+2)',256)
test(simplify((Q(1,6)*Q(1,2)-Q(1,2)*Q(1,16))),Q(5,96),'Independent second-order energy coefficient from kinetic and quartic potential',256)
test(Q(1,4)*Q(3,256),Q(3,1024),'Fourth-order energy from h4 without perturbation theory',256)
test(-h[2]/4,-Q(1,256),'Spatial CS cubic term from centred harmonic',256)
for n in range(1,9):
    m=n*(n+2)
    r=Q(1)-Q(m,3*(m-2))
    test(r>=0 and r<=1,True,f'Adversarial positivity/range of transverse projection norm ratio for scalar harmonic n={n}',256,grade='E2_BOUNDED_DOMAIN_TEST')
test(Q(1)-Q(3,3*(3-2)),Q(0),'Degree-one scalar profile is pure gauge after projection',256)
# Spin4: symmetric square decomposition by exchange parity of same irrep; cross-products via SU(2) CG.
def tensor_spin(a,b): # a,b = doubled spin labels
    return list(range(abs(a-b),a+b+1,2))
def cg_prod(V,W):
    return collections.Counter((l,r) for l in tensor_spin(V[0],W[0]) for r in tensor_spin(V[1],W[1]))
def sym2_spin(V):
    a,b=V;return collections.Counter((p,q) for p in range(0,2*a+1,2) for q in range(0,2*b+1,2) if ((a-p//2)+(b-q//2))%2==0)
for K in range(1,7):
    reps=[(k+1,k-1) for k in range(1,K+1)]+[(k-1,k+1) for k in range(1,K+1)]
    mult=collections.Counter()
    for i,V in enumerate(reps):
        mult.update(sym2_spin(V))
        for Wv in reps[i+1:]: mult.update(cg_prod(V,Wv))
    want=(2*K,0,0,2*(K-1),0,0)
    got=tuple(mult[z] for z in ((0,0),(1,0),(0,1),(1,1),(2,0),(0,2)))
    test(got,want,f'Direct SU2×SU2 CG tensor/symmetric plethysm through coexact shell K={K}',257)
test(tuple(cg_prod((1,0),(1,0))[x] for x in ((0,0),(2,0))), (1,1),'Spinor-square has scalar and triplet in one chiral factor',257)

# 258-262: block elimination, Moore-Penrose, Hessian zero and positive parent.
H=Matrix([[7,2,1],[2,5,1],[1,1,4]])
# z pivot last coordinate, Schur then y; compare both routes.
Az=H[:2,:2]-H[:2,2:3]*H[2:3,2:3].inv()*H[2:3,:2]
seq=Az[0,0]-Az[0,1]*Az[1,1]**-1*Az[1,0]
one=H[0,0]-(H[0:1,1:3]*H[1:3,1:3].inv()*H[1:3,0:1])[0]
test(z(seq-one),True,'Nested vs all-at-once Schur complements for non-diagonal exact 3×3 parent',258)
test(z(H[1:3,1:3].det()-H[2,2]*Az[1,1]),True,'Determinant composition of Gaussian pivots with exact rational entries',258)
# singular positive pivot with rank(C)=1, source range checked by residuals.
A=Matrix([[5,1],[1,4]]);B=Matrix([[1,0],[2,0]]);Cc=diag(3,0);Cp=diag(Q(1,3),0)
S=A-B*Cp*B.T;P0=diag(0,1)
H0=A.row_join(B).col_join(B.T.row_join(Cc))
x=Matrix([2,3]);y=Matrix([1,5]);j=H0*(x.col_join(y));n=P0*y
lhs=Matrix.vstack(S.row_join(B[:,1:2]),(P0*B.T)[1:2,:].row_join(Matrix([[0]])))*x.col_join(Matrix([n[1]]))
rhs=(j[:2,0]-B*Cp*j[2:4,0]).col_join((P0*j[2:4,0])[1:2,0])
test(zr(lhs-rhs),True,'Explicit rank-one singular Hermitian block elimination with null multiplier retained',259)
test(zr(H0* x.col_join((Cp*(j[2:4,0]-B.T*x)+n))-j),True,'Reconstruction of the full singular block solution after constrained elimination',259)
test(zr(H0-H0.T),True,'Hermitian source and pivot conventions of singular Schur data',259)
test((Cc.rank(),S.det()>0,(H0).is_positive_semidefinite),(1,True,True),'Positive block with singular C and BC-null: C≥0 and S positive',260)
test(z((H0.det())),True,'Rank-deficient positive parent has one exact gauge-null vector',260)
# derivative pseudoinverse of constant-rank rotating Hermitian C(t)=R(t) diag(3,0) R(t)^T at t=0.
t=symbols('t',real=True);Rot=Matrix([[cos(t),-sin(t)],[sin(t),cos(t)]])
Cr=Rot*Cc*Rot.T;Cpr=Rot*Cp*Rot.T;Pnr=eye(2)-Cr*Cpr
lhs=diff(Cpr,t).subs(t,0);D=diff(Cr,t).subs(t,0)
rhs=-Cp*D*Cp+Cp**2*D*P0+P0*D*Cp**2
test(zr(lhs-rhs),True,'Differentiate rotating constant-rank pseudoinverse vs printed differential identity',261)
test(zr(diff(Pnr,t).subs(t,0)+Cp*D*P0+P0*D*Cp),True,'Differentiate rotating null projector independently',261)
# Noncommuting S,M common-support parent construction 2 retained + rank-2 complement.
Dr=Matrix([[4,1],[1,3]]); Sr=diag(2,3); Mr=Matrix([[2,1],[1,2]])
Iinv=Dr-Mr; Iop=Iinv.inv();Br=diag(sqrt(2),sqrt(3));Z=Br*Mr.inv()*Br
Parent=Dr.row_join(Br).col_join(Br.T.row_join(Z))
test(zr(Parent[:2,:2]-Dr),True,'Positive-parent direct compression equals D',262)
test(zr((Parent*Parent)[:2,:2]-(Dr**2+Sr)),True,'Positive-parent square compression equals D²+S',262)
test(zr(Parent.inv()[:2,:2]-Iop),True,'Positive-parent inverse compression equals I=(D−M)^−1',262)
test(Parent.is_positive_definite,True,'Minimal common-parent block is positive definite on full X⊕Y',262)
test(z(Parent.det()-Sr.det()/(Mr.det()*Iop.det())),True,'Common-parent determinant support formula',262)

# 263-301: torus long exact sequence, 2T countermodels, three-state owner and antiprism.
# π2(S3×S3×T2)=0; π1(M8)=Z²; principal torus boundary homomorphism is P_sc.
for Psc,kercok in [(Matrix([[1,0],[0,1]]),(0,0)),(Matrix([[2,0],[0,0]]),(1,1)),(Matrix([[0,0],[0,0]]),(2,2))]:
    tker=2-Psc.rank(); freecok=2-Psc.rank()
    test((tker,freecok),kercok,'Long exact homotopy of connected torus bundle, free ranks from integer scalar projection',263)
# Hopf coordinates q=(cos rho e^{i alpha},sin rho e^{i beta}): h3=cos²rho−sin²rho.
rho=symbols('rho',real=True)
test(z(cos(rho)**2-sin(rho)**2-cos(2*rho)),True,'Hopf latitude condition of Clifford torus in S3 coordinates',264)
# SU(4) exact kernel: (-I,-I,-1) maps blockwise to identity.
I2=eye(2);qz=-1
im=diag(*(list(qz*(-I2)) + list(qz**-1*(-I2)))) if False else diag(qz*(-I2),qz**-1*(-I2))
test(zr(im-eye(4)),True,'Exact central order-two kernel element in block SU4 embedding',265)
test((2+2,2*2+1+1),(4,6),'Independent wedge-square branching dimension check: fundamental 4 and antisymmetric 6',265,grade='E2_REPRESENTATION_DIMENSION')
# 72-node design: Gaussian-Legendre 2-point quadrature on uniform u∈[0,1].
up=(1+1/sqrt(3))/2;um=(1-1/sqrt(3))/2
for n in range(4):
    test(z((up**n+um**n)/2-Q(1,n+1)),True,f'Independent exact radial Gauss quadrature moment n={n}',267)
# S3 harmonic 6-angle grid rejects all nontrivial Fourier |m|≤5.
for m in range(1,6):
    ang=sum(complex(np.exp(1j*math.pi*m*j/3)) for j in range(6))
    test(abs(ang)<1e-12,True,f'Root-of-unity angular 6-grid annihilates Fourier mode {m}',267,grade='E2_NUMERICAL_FOURIER')
# Rational orthogonal-two-point obstruction at one irrational radial layer.
test(z(up*Q(1,2)+(1-up)*(-Q(1,2))),False,'Adversarial same-layer dot product can be nonzero; no false blanket nonzero claim for arbitrary signs',267,grade='E2_DOMAIN_NEGATIVE_CONTROL')
# six-cycle regular representation of C6 and q5 projector dimensions.
R6=Matrix(6,6,lambda i,j:1 if i==(j+1)%6 else 0);Id6=eye(6);J6=R6**3
P1=sum((R6**k for k in range(6)), Matrix.zeros(6))/6
P3=(Id6-J6)/2;P2=(Id6+J6)/2-P1
for k,Pj,rank in [('P1',P1,1),('P2',P2,2),('P3',P3,3)]:
    test((Pj.rank(),zr(Pj*Pj-Pj)),(rank,True),f'Direct 6×6 cyclic group-algebra projector {k} rank and idempotence',270)
test(zr(P1*P2+P1*P3+P2*P3),True,'Rooted 6-cycle decomposition mutually orthogonal under Fourier parity',270)
# 3-state trimer projection to axial imaginary plane.
u=Matrix([1,1,1])/sqrt(3)
Y=Matrix.hstack(Matrix([-1,1,1])/2,Matrix([1,-1,1])/2,Matrix([1,1,-1])/2)
Pplane=eye(3)-u*u.T
test(zr(Y.T*Y*Pplane-Pplane),True,'Exact restricted-isometry of Hurwitz trimer map on sum-zero plane',278)
test(zr(u.T*Y*Pplane),True,'Hurwitz-rooted three-vector map sends augmentation into u⊥',278)
X3=Matrix(3,3,lambda i,j:1 if i==(j+1)%3 else 0)
Rplane=Y*X3*Y.inv() if False else X3 # cyclic permutation of imaginary coordinates in same orientation
# Y=-I +1/2 J, hence it commutes with cyclic permutation.
test(zr(Y*X3-X3*Y),True,'Direct rooted C3 trimer rotation intertwining on 3-space',279)
test(zr((X3-X3.T)**2/3+Pplane),True,'Canonical q5 complex structure squares to −I on augmentation plane',280)
# 6 graph edges a_k b_{k±1}: verify degree2, one connected cycle and 3-to-1 covering.
import networkx as nx
G6=nx.Graph();G6.add_nodes_from([('a',k) for k in range(3)]+[('b',k) for k in range(3)])
for k in range(3):
  for o in (-1,1):G6.add_edge(('a',k),('b',(k+o)%3))
test((len(G6.nodes),len(G6.edges),nx.is_connected(G6),sorted(dict(G6.degree).values())),(6,6,True,[2]*6),'Independent full graph traversal of rooted Hurwitz six-cycle covering',283)
test(len({tuple(sorted(((u[0],(u[1]+q)%3),(v[0],(v[1]+q)%3)))) for u,v in G6.edges for q in range(3)}),6,'Simultaneous C3 shift preserves all six graph edges (deck candidates)',283)
C1=X3+X3.T;C2=-I*(X3-X3.T)
test(zr(X3-(C1+I*C2)/2),True,'Reconstruct cyclic transport from simultaneously generated Hermitian cosine/sine ports',285)
test(zr(X3.T-(C1-I*C2)/2),True,'Opposite cyclic port reconstruction and root reversal',285)
# odd 6×6 involutions, Coxeter product.
Dplus=(eye(3)*0).row_join(X3).col_join(X3.T.row_join(Matrix.zeros(3)))
Dminus=(eye(3)*0).row_join(X3.T).col_join(X3.row_join(Matrix.zeros(3)))
Grad=diag(eye(3),-eye(3))
test(zr(Dplus.T-Dplus) and zr(Dplus**2-eye(6)),True,'Explicit odd chiral matrix is Hermitian involution',288)
test(zr(Grad*Dplus+Dplus*Grad),True,'Odd lift anticommutes with rooted q5 grading',288)
test(zr((Dminus*Dplus)**3-eye(6)),True,'Coxeter product has exact order 3',288)
# scalar owner's normalized trace and singular values for n=2,4,6.
for n in (2,4,6):
    a=Matrix.eye(n);sing=Q(n)**Q(1,2)
    test((simplify((a.T*a).trace()),simplify(sing*1/sing)),(n,1),f'HS norm of identity and normalized scalar-owner support rank n={n}',300)
# three rooted rays have mutual overlap −1/2; Gram of rank-one projectors = 3/4 I+1/4 J.
rr=Matrix.hstack(Matrix([1,0]),Matrix([-Q(1,2),sqrt(3)/2]),Matrix([-Q(1,2),-sqrt(3)/2]))
proj=[rr[:,j]*rr[:,j].T for j in range(3)]
Gram=Matrix(3,3,lambda i,j:simplify((proj[i]*proj[j]).trace()))
test(zr(Gram-(Q(3,4)*eye(3)+Q(1,4)*Matrix.ones(3))),True,'Independent projectors on a 120° trimer and exact family Gram',301)
test(Gram.det(),Q(27,32),'Rooted trimer tensor map has full rank three (positive Gram determinant)',301)
test(zr((sum(proj,Matrix.zeros(2))*Q(2,3))-eye(2)),True,'Trimer sum of projectors maps scalar line to normalized owner identity',301)
# spin(8) triality branching (2×2×1×1 etc) and nontrivial SU(2) Clebsch 2⊗2→1.
test(tuple(2*2*1*1+1*1*2*2 for _ in range(3)),(8,8,8),'Branching representations have exact triality vector/spinor dimension 8',273,grade='E2_REPRESENTATION_DIMENSION')
test((2 in tensor_spin(1,1),0 in tensor_spin(1,1)),(True,True),'Spinor-doubling restriction has unique 2⊗2 scalar and triplet',273)
# antiprism direct finite matrices from C=J−I, R=diag(1,−i,i).
CC=Matrix.ones(3)-eye(3); RG=diag(1,-I,I)
QA=CC*RG+RG.conjugate().T*CC;FA=I*QA
qprint=Matrix([[0,1-I,1+I],[1+I,0,2*I],[1-I,-2*I,0]])
test(zr(QA-qprint),True,'Construct chiral q5 antitwisted block directly from antiprism C and phase R',296)
test(z((L*eye(3)-QA).det()-(L+2)*(L*L-2*L-4)),True,'Characteristic polynomial of explicit 3×3 q5 Hermitian chiral block',296)
test(abs(QA.det()),8,'Exact determinant magnitude of full-rank antiprism primitive',296)
Fcomp=-CC*RG+RG.conjugate().T*CC
FPF=Fcomp.conjugate().T*Fcomp
test(z((L*eye(3)-FPF).det()-L*(L-4)**2),True,'Competing quadrature singular spectrum (zero,2,2)',297)
# paired Feshbach polar check using Hermitian polynomial functional calculus identity F=iQ, full 3×3.
test(zr(FA.conjugate().T*FA-QA*QA),True,'Finite chiral polar magnitude |F|²=Q², independent of sign eigenvalues',298)
test(zr(FA*FA.conjugate().T-FA.conjugate().T*FA),True,'Canonical chiral block normal => unitary polar factor commutes with magnitude',298)

# 313-350: root harmonic restriction, full positive responses, Born pencil and compression.
# Six Hurwitz points from cube link: all sign triples except (1,1,1), (-1,-1,-1).
hurwitz=[Matrix([Q(1,2)]+[Q(s,2) for s in bits]) for bits in itertools.product((-1,1),repeat=3) if bits not in [(1,1,1),(-1,-1,-1)]]
assert len(hurwitz)==6
# Chebyshev U_n(t) recurrence, no built-in polynomial lookup.
def Ucheb(n,tval):
    prev=1;curr=2*tval
    if n==0:return prev
    for k in range(2,n+1):prev,curr=curr,2*tval*curr-prev
    return curr
Gram=Matrix(6,6,lambda i,j:13*Ucheb(12,(hurwitz[i].T*hurwitz[j])[0]))
want=156*eye(6)+13*Matrix.ones(6)
test(zr(Gram-want),True,'Independently build degree-twelve reproducing kernel Gram from six Hurwitz quaternions',314)
test((Gram.rank(),Gram.eigenvals()),(6,{234:1,156:5}),'Direct spectrum of exact 6×6 native harmonic boundary Gram',314)
P0=Matrix.ones(6)/6;Pa=eye(6)-P0
Ghalf=P0/sqrt(234)+Pa/sqrt(156)
test(zr(Ghalf*Gram*Ghalf-eye(6)),True,'Positive Gram normalization yields boundary coisometry BB†=I6',315)
test(zr(Ghalf*Gram*Ghalf*P0-P0),True,'The normalized singlet projector retains unique positive scalar eigenchannel',315)
test((169-6,Pa.rank(),P0.rank()),(163,5,1),'Projector ranks 163+5+1 from full degree-twelve S3 harmonic dimension',317)
test((Q(163,169)+Q(5,169)+Q(1,169),Q(163,169)),(1,Q(163,169)),'Born norm probabilities only for specified maximally mixed harmonic state',318)
# S3 regular char with h12 class traces (169,1,1), character inner products.
classes=[(1,169),(3,1),(2,1)]; chars={'triv':[1,1,1],'sign':[1,-1,1],'std':[2,0,-1]}
mult={key:sum(cnt*trace*char for (cnt,trace),char in zip(classes,cht))/6 for key,cht in chars.items()}
test(mult,{'triv':29,'sign':28,'std':56},'Exact order-six character averaging of H12 conjugation representation',319)
test((29-1,28-1,56-2),(28,27,54),'Subtract visible regular representation from full harmonic carrier',319)
traceNS=Q(168,168); traceCross=Q(5,168); traceAug=Q(5,168)
test((traceNS,traceCross,traceAug),(1,Q(5,168),Q(5,168)),'Direct projector overlap traces when Laplacian kinetic inverse is 1/168',319)
test(traceNS-traceCross**2/traceAug,Q(163,168),'Full 2×2 positive Green Gram Schur residual distinguishes 168 vs 163 returns',319)
test(27*1+54*2,135,'Realized S3-intertwiner Hom dimension for E163→E5',321)
# Z12 character U12(Re q) is 1 at each h_a.
test(Ucheb(12,Q(1,2)),1,'Round degree-twelve zonal harmonic evaluates to one on all six local half-unit points',324)
pZ=Q(6,234)
test((pZ,Q(1)-pZ,2*pZ*(1-pZ)),(Q(1,39),Q(38,39),Q(76,1521)),'Reproducing-kernel projector component and rank-one commutator Hilbert–Schmidt norm',324)
# Symplectic Born triple with exact nontrivial dual metric.
AA=diag(1,2,3,4);OO=Matrix.zeros(4).row_join(AA).col_join((-AA).row_join(Matrix.zeros(4)))
KK=diag(eye(4),-eye(4));Eta=KK*OO
Hpos=diag(eye(4),AA.T*AA)
test(zr(Eta-Eta.T),True,'η=Ω(K·,·) becomes symmetric for Lagrangian reciprocal splitting',326)
test(zr(Eta.inv()*Hpos-Hpos.inv()*Eta),True,'Exact Born metric compatibility η^{-1}H=H^{-1}η on positive 8-fibre',326)
test(zr(OO.inv()*Hpos+Hpos.inv()*OO),True,'Exact anti-symplectic Born metric compatibility Ω^{-1}H=−H^{-1}Ω',326)
# Weyl function of complete 3×3 Hermitian parent 1 retained/2 environment.
zz=symbols('zz');Ar=Matrix([[3]]); Br=Matrix([[1,2]]); Cr=diag(4,7)
Full=Ar.row_join(Br).col_join(Br.T.row_join(Cr))
Mfun=zz-Ar[0,0]+(Br*(Cr-zz*eye(2)).inv()*Br.T)[0]
res=((zz*eye(3)-Full).inv())[0,0]
test(z(res-1/Mfun),True,'Compute 3×3 retained resolvent independently of explicit Schur response formula',328)
test(z(diff(Mfun,zz)-(1+Q(1)/(4-zz)**2+4/(7-zz)**2)),True,'Complete Hermitian boundary Weyl derivative and positive residue weights',328)
test(z(Mfun-(zz-3+1/(4-zz)+4/(7-zz))),True,'Visible environmental poles and rank-positive weights from diagonal C',329)
# Positive complementary gap population with E=0 on constructed parent via M(E)=0.
E=0; Cgap=diag(2,4); Bb=Matrix([[1,1]]);A0=Matrix([[Q(3,4)]])
Mat0=A0.row_join(Bb).col_join(Bb.T.row_join(Cgap))
M0=E-A0[0,0]+(Bb*Cgap.inv()*Bb.T)[0]
q=(Bb*Cgap.inv()*Bb.T)[0];vnorm=(Bb*Cgap.inv()*Cgap.inv()*Bb.T)[0]
w=1/(1+vnorm)
test(z(M0),True,'Visible zero root of explicitly supplied Hermitian positive-gap 3×3 pencil',331)
test((w>=Q(2)/(2+q), w<=Q(4)/(4+q)),(True,True),'Retained-population lower/upper bounds for visible 0-mode with [2,4] gap',331)
test(z(w*(1+vnorm)-1),True,'Normalized projected residue weight from eigenvector norm reconstruction',331)
# One-parameter unitary gauge transport: mixed ordinary source derivatives remain invariant.
th=symbols('th',real=True);RR=Matrix([[cos(th),-sin(th)],[sin(th),cos(th)]])
Aux=Matrix([[2,1],[1,4]]);Ttilde=RR*Aux*RR.T;Theta=diff(RR,th)*RR.T
cov=diff(Ttilde,th)-(Theta*Ttilde-Ttilde*Theta)
test(zr(cov),True,'Rotating-frame covariant derivative cancels artificial unitary source-frame variation',333)
test(z(diff((Ttilde*Ttilde).trace(),th)),True,'Trace of squared transported source word preserves ordinary first jets',333)
# Weighted Born involutions on a 2×2 Cl2 block.
JJ=Matrix([[1,0],[0,-1]]);K2=Matrix([[0,1],[1,0]])
xx=symbols('xx',positive=True)
Ac=JJ+xx*K2;Uc=(JJ+K2)/sqrt(2);GG=sqrt(1+xx*xx)
test(zr(Ac**2-GG**2*eye(2)),True,'Direct Cl2 weighted Born pencil square and positive dispersion',334)
test(zr(Uc*Ac*Uc-(xx*JJ+K2)),True,'Rooted reciprocal involution exchanges Clifford slots with weight x',334)
test(z(xx/(1+GG)*(1+(1-xx/(1+GG))/(1+xx/(1+GG)))-1),False,'Independent check: inversion of t alone is not scalar identity without x inversion',334,grade='E2_NEGATIVE_RESTRICTION')
test(z((1/xx)/(1+sqrt(1+xx**-2))-(1-xx/(1+GG))/(1+xx/(1+GG))),True,'Positive reciprocal t-chart Möbius transform',334)
# Scalar flux cap stationary min, exact.
r,Delta=symbols('r Delta',positive=True);ww=2*sqrt(Delta)*r
al=ww/(1+GG);bb=GG*ww/(1+GG)
test(z(al+bb-ww),True,'Flux conservation in two-branch extension source port',335)
test(z((al**2+bb**2/GG)/2-2*Delta*r*r/(1+GG)),True,'Conjugate-flux cap from exact constrained positive minimization',335)
# Noncommuting root bound: positive 2x2 A and rank-one V (not simultaneously diagonal).
from numpy.linalg import eigvalsh, eigh, norm
def sqrtm(A):
 v,T=eigh(A);return (T*np.sqrt(v))@T.T
An=np.array([[4.,0.],[0.,9.]])
Vn=np.array([[.8,.4],[.4,.2]]) # PSD rank-one, noncommuting with diagonal A
s0=sqrtm(An);s1=sqrtm(An+Vn);nn=norm(Vn,ord=2);g0=2.
test(norm(s1-s0,ord=2)<=nn/(2*g0)+1e-10,True,'Adversarial noncommuting positive square-root Lipschitz bound on exact 2×2 pair',337,grade='E2_NONCOMMUTING_NUMERICAL')
test(norm(2*np.linalg.inv(np.eye(2)+s1)-2*np.linalg.inv(np.eye(2)+s0),ord=2)<=nn/(g0*(1+g0)**2)+1e-10,True,'Noncommuting reciprocal boundary response bound for same perturbed matrices',337,grade='E2_NONCOMMUTING_NUMERICAL')
# Noncommuting Sylvester differentiation of sqrt A from actual smooth A(t)=(K+tE)^2.
Kbase=diag(2,3);Epert=Matrix([[1,1],[1,0]]);Ap=Kbase*Epert+Epert*Kbase
KB=Matrix([[Ap[i,j]/(Kbase[i,i]+Kbase[j,j]) for j in range(2)] for i in range(2)])
test(zr(KB-Epert),True,'Independent Sylvester equation K K_a+K_a K=A_a for noncommuting matrices',339)
Kb2=Matrix([[(-2*Epert**2)[i,j]/(Kbase[i,i]+Kbase[j,j]) for j in range(2)] for i in range(2)])
test(zr(Kb2+Matrix([[2*(Epert**2)[i,j]/(Kbase[i,i]+Kbase[j,j]) for j in range(2)] for i in range(2)])),True,'Sylvester equation for mixed second square-root jets',339)
# Canonical trace-source supremum completed square with real positive owner.
T=diag(2,3); Jsrc=Matrix([[1,2],[0,1]]); Xstar=T.inv()*Jsrc
objective=(2*(Jsrc.T*Xstar).trace()-(Xstar.T*T*Xstar).trace())
test(z(objective-(Jsrc.T*T.inv()*Jsrc).trace()),True,'Complete square of finite heat-source variational trace with 2-column source',340)
# Heat cap moments H(s)=2/(1+sqrt(1+s)) at s=0: H(0)=1,Hprime=-1/4,Hdouble=1/4.
ss=symbols('ss',positive=True)
heat=2/(1+sqrt(1+ss))
test((simplify(heat.subs(ss,0)),simplify(diff(heat,ss).subs(ss,0)),simplify(diff(heat,ss,2).subs(ss,0))),(1,-Q(1,4),Q(1,4)),'Positive heat moment normalization and first two moments by direct Laplace derivatives',342)
# Full relative-chiral rank nspin4 times owner48, normalized trace rank.
test((Q(4*48,2),Q(4*48,2)/48),(96,2),'Relative odd spin/owner chiral projector rank and primitive normalized trace',341)
test(Q(2,192),Q(1,96),'Primitive-to-ordinary coefficient ratio for full parent trace',341)
# Clifford-normal completion identity with exact anticommuting involutions.
DC=sqrt(2*xx)*JJ+(xx-1)*K2
test(zr(DC*DC-(1+xx**2)*eye(2)),True,'Affine relative-odd normal completion exact square',343)
# Isometric compression: multiplying two distinct endomorphisms produces an exact defect.
Zv=Matrix([[1],[0]]);Pz=Zv*Zv.T; AA1=Matrix([[0,1],[0,0]]);BB1=Matrix([[0,0],[1,0]])
actual=Zv.T*AA1*Zv*Zv.T*BB1*Zv-Zv.T*AA1*BB1*Zv
expected=-Zv.T*AA1*(eye(2)-Pz)*BB1*Zv
test(zr(actual-expected),True,'Explicit off-subspace multiplication defect of a nonreducing compression',350)
test((actual[0],expected[0]),(-1,-1),'Exact nonzero multiplicative loss on a faithful isometric chart',350)
# Family chart in theorem 351: J e_i = (U e_i)⊗e_i ; overlap of Ui,Uj = δij.
Qm=Matrix.ones(3)/3;Um=eye(3)+(I-1)*Qm
J=Matrix(9,3,lambda i,j:Um[i//3,j] if i%3==j else 0)
test(zr(J.conjugate().T*J-eye(3)),True,'Direct isometric 9×3 family/mode chart with nontrivial phase U',351)
Op=Matrix([[0,1,2],[1,3,4],[2,4,5]])
test(zr(J.conjugate().T*Matrix(9,9,lambda i,j:Op[i%3,j%3] if i//3==j//3 else 0)*J-diag(0,3,5)),True,'Direct current compression erases all offdiagonal family normal terms',351)
# Hadamard pair coefficient I−2Q has no zero entry, so six symmetric basis coefficients inject.
Had=eye(3)-2*Qm
test((Had[0,0],Had[0,1],Had.det()),(Q(1,3),-Q(2,3),-1),'Full symmetric pair map multiplier has no zero entries',351)

# 353-373: connection projections, 8d contracted torsion, singular stationary/gap geometry.
# Projected trivial connection for smooth varying f and nontrivial U(t); no df in V†dV.
q=symbols('q',real=True);ff=cos(q)**2
Uspin=diag(cos(q)+I*sin(q),cos(q)-I*sin(q))
Vp=Matrix.vstack(cos(q)*Uspin,sin(q)*eye(2))
Vm=Matrix.vstack(-sin(q)*Uspin,cos(q)*eye(2))
Aplus=simplify(Vp.conjugate().T*diff(Vp,q));Aminus=simplify(Vm.conjugate().T*diff(Vm,q))
Th=simplify(Uspin.conjugate().T*diff(Uspin,q))
test(zr(Aplus-ff*Th),True,'Independently differentiate varying projected frame and see complete df cancellation',354)
test(zr(Aminus-(1-ff)*Th),True,'Complement projected connection contains (1-f)Θ with zero spurious df',354)
test(zr(Vp.conjugate().T*Vm),True,'Cartan projector complements orthogonal for a nonconstant profile',354)
# Quaternion S4 rank-two projection, direct 4x4 matrices, nontrivial q not scalar.
qa,qb,qc,qd=symbols('qa qb qc qd',real=True)
Quat=Matrix([[qa+I*qb,qc+I*qd],[-qc+I*qd,qa-I*qb]])
rad=qa**2+qb**2+qc**2+qd**2;rho=symbols('rho',real=True,positive=True)
P4=Matrix.vstack(Matrix.hstack(rad*eye(2),rho*Quat),Matrix.hstack(rho*Quat.conjugate().T,rho**2*eye(2)))/(rad+rho**2)
test(zr(simplify(P4*P4-P4)),True,'BPST quaternionic 4-sphere projector idempotence in four symbolic coordinates',355)
test(zr(simplify(P4.conjugate().T-P4)),True,'BPST quaternionic rank-two projector is globally Hermitian',355)
# Spin lift metric connection Dirac contraction independent 3d Clifford tensor check.
sx=Matrix([[0,1],[1,0]]);sy=Matrix([[0,-I],[I,0]]);sz=Matrix([[1,0],[0,-1]])
gam=[I*s for s in (sx,sy,sz)]
Kcont={}
for a0 in range(3):
 for b0 in range(3):
  for c0 in range(b0+1,3):
   v=Q(2*a0+b0+2*c0+1,4)
   Kcont[a0,b0,c0]=v;Kcont[a0,c0,b0]=-v
Kelem=lambda a0,b0,c0:Kcont.get((a0,b0,c0),0)
Ttor=lambda a0,b0,c0:Kelem(a0,b0,c0)-Kelem(b0,a0,c0)
Talt=lambda a0,b0,c0:(Ttor(a0,b0,c0)+Ttor(b0,c0,a0)+Ttor(c0,a0,b0))/3
tr=[sum(Ttor(a0,b0,b0) for b0 in range(3)) for a0 in range(3)]
Ddirect=Matrix.zeros(2);Dalt=Matrix.zeros(2);Dtrace=Matrix.zeros(2)
for a0,b0,c0 in itertools.product(range(3),repeat=3):
    Ddirect+=Q(1,4)*Kelem(a0,b0,c0)*gam[a0]*gam[b0]*gam[c0]
    Dalt+=Q(3,4)*Q(1,6)*Talt(a0,b0,c0)*gam[a0]*gam[b0]*gam[c0]
for a0 in range(3): Dtrace+=-Q(1,2)*tr[a0]*gam[a0]
test(zr(Ddirect-Dalt-Dtrace),True,'Direct independent Clifford contraction of arbitrary metric contorsion confirms 3/4 c(Talt)−1/2 c(t)',357)
test((8*math.comb(8,2),math.comb(8,3),8,8*math.comb(8,2)-math.comb(8,3)-8),(224,56,8,160),'8d invariant metric-contorsion decomposition and exact Dirac kernel dimension',357)
test((112-(28+4),112-80),(80,32),'Exchange-even metric connection: 80 Cartan kernel and 32 observable contracted channels',357)
test(224-8,216,'Zero vectorial trace restricts self-adjoint invariant metric connection family to 216 dimensions',357)
# 3d torsion sphere Dirac endpoints using printed labelled spectrum, check midpoint special.
for sp,expected in [(0,(0,-3)),(Q(1,2),(Q(3,2),-Q(3,2))),(1,(3,0))]:
 test((3*sp,-3+3*sp),expected,'Independent k=0 direct branches of 3sphere s spin connection Dirac spectrum',359)
# Projected connection curvature identity in a diagonal U family (zero 2-form) and rank positivity.
test(zr(P4*P4-P4),True,'Projector curvature source begins with genuine idempotent, not ambient flatness',353)
# Schur null equations including constraint; choose coupled singular C with source.
Aa=Matrix([[4]]); Bb=Matrix([[1,2]]);Cc=diag(3,0);Cp=diag(Q(1,3),0)
Hsing=Aa.row_join(Bb).col_join(Bb.T.row_join(Cc))
xx=Matrix([1]);yy=Matrix([2,3]);src=Hsing*xx.col_join(yy)
Ssing=Aa-Bb*Cp*Bb.T
red_eq=(Ssing*xx+(Bb*Matrix([0,3]))-(src[:1,0]-Bb*Cp*src[1:3,0]))
constraint=((eye(2)-Cc*Cp)*(Bb.T*xx-src[1:3,0]))
test(zr(red_eq) and zr(constraint),True,'Stationary null-constrained block Euler equations retained explicitly',364)
test(zr(Hsing*xx.col_join(Cp*(src[1:3,0]-Bb.T*xx)+Matrix([0,3]))-src),True,'Reconstruct exact full stationary singular block from constrained reduced system',364)
# Output L null-space condition iff full Hq=L†h solvable for all source h.
Hkern=diag(2,0);Lgood=Matrix([[1,0]]);Lbad=Matrix([[0,1]])
test((zr(Lgood*Matrix([0,1])),not zr(Lbad*Matrix([0,1]))),(True,True),'Output map must annihilate homogeneous null directions for source compatibility',365)
test((Lgood*Hkern.pinv()*Lgood.T)[0],Q(1,2),'Direct Moore-Penrose input-output response of compatible reduced map',365)
# Interior crossing with C0=diag(2,0), derivative −M_N and nonzero coupling to its kernel.
dz=symbols('dz',real=True); Ccross=diag(2,-3*dz);Bcross=Matrix([[2,1]])
CrossSch=7-(Bcross*Ccross.inv()*Bcross.T)[0]
test(z(dz*CrossSch-Q(1,3)),False,'No substitution of finite analytic part for Laurent residue (negative control)',366,grade='E2_NEGATIVE_RESIDUE_CONTROL')
test(simplify((dz*CrossSch).limit(dz,0)),Q(1,3),'Schur pole coefficient F M_N^{-1}F† at interior C-kernel crossing',366)
test(simplify((dz*Ccross.inv()[1,1]).limit(dz,0)),-Q(1,3),'Interior scalar pivot inverse has correct negative Laurent coefficient',366)
# Full pencil projected resolvent and positive residues with a two-level model.
KT=diag(2,5);MT=diag(1,4);LL=Matrix([[1,1]])
Qp=LL*(KT-zz*MT).inv()*LL.T
want=1/(2-zz)+1/(5-4*zz)
test(z(Qp[0]-want),True,'Direct full weighted generalized-eigenvector resolvent vs spectral two-pole expansion',367)
test(tuple(simplify(-((zz-r)*Qp[0]).limit(zz,r)) for r in (Q(2),Q(5,4))),(Q(1),Q(1,4)),'Direct Laurent residue extraction at both generalized eigenpoles gives M-normalized PSD projection weights',367)
# Positive discontinuity despite all H(t) ≥0.
tv=symbols('tv',real=True);Hr=Matrix([[2,tv],[tv,tv**2]])
test(z(Hr.det()-tv**2),True,'Rank-changing positive 2×2 Schur example has strictly nonnegative determinant',368)
test(z(2-tv**2/(tv**2)-1),True,'Schur complement t≠0 is exactly 1 and not limiting pseudoinverse 2',368)
test((Hr.subs(tv,0).pinv()[0,0], (Hr[0,0]-Hr[0,1]**2/Hr[1,1]).subs(tv,1)),(Q(1,2),1),'Entire inverse vs Schur must keep pivot-domain scope separate',368,grade='E2_DOMAIN_PRECONTROL')
# Stationary C3 f(q,η)=q^2 η/2+q^4/4 has null Hessian at η=0 and a smooth branch q=0.
qv,et=symbols('qv et',real=True);action=et*qv*qv/2+qv**4/4
J=diff(action,qv,et).subs({qv:0,et:0});HH=diff(action,qv,2).subs({qv:0,et:0})
test((J,HH),(0,0),'Compatibility of smooth singular branch first derivative at stationary zero',369)
# Positive gap rational scalar and 2d matrix inequalities.
Ds=[Q(2),Q(3)];As=[diag(1,0),Matrix([[1,1],[1,1]])]
Ssum=2*sum((As[i]/Ds[i] for i in range(2)),Matrix.zeros(2));Tsum=2*sum((As[i]/Ds[i]**3 for i in range(2)),Matrix.zeros(2))
test((Tsum-Ssum/9).is_positive_semidefinite,True,'Lower Löwner positive-gap coefficient bound (D=max 3)',370)
test((Ssum/4-Tsum).is_positive_semidefinite,True,'Upper Löwner positive-gap coefficient bound (δ=min 2)',370)
test((Ssum.rank(),Tsum.rank()),(2,2),'Positive gap sums have same combined kernel when all input A_r PSD',370)
# Bipartite 1+1+1 model: X0 dim1, E dim1, Xs dim1, Y dim1.
Ascalar=Matrix([[0,0,0],[0,0,0],[0,0,4]]);Gc=Matrix([[0],[3],[0]])
Db=Ascalar.row_join(Gc).col_join(Gc.T.row_join(Matrix([[0]])) )
proj=((Db-zz*eye(4)).inv())[:3,:3]
claimed=diag(-1/zz,zz/(9-zz**2),1/(4-zz))
test(zr(proj-claimed),True,'Exact full first-order bipartite block inversion and cancellation of spurious interior pole at z=0',371)
test(simplify((zz/(9-zz**2)).subs(zz,0)),0,'Bipartite visible E return regular and zero at zero even though interior inverse diverges',371)
# Weighted logistic profile persists only for constant weight where derivative f_* nonzero.
ff=symbols('ff');Zweight=1+ff**2;Vpot=4*ff**2*(1-ff)**2
logprime=2*ff*(1-ff)
rel=simplify(2*logprime**2- Q(1,2)*diff(Vpot,ff)) # f'' = d/d f f' * f' => here 2(1-2f)f'
rel=simplify(diff(logprime,ff)*logprime-Q(1,2)*diff(Vpot,ff))
test(z(rel),True,'Unweighted logistic derivative solves EL equation for quartic YM double well',372)
test(z(diff(Zweight,ff)*logprime**2),False,'Variable positive weight generically destroys logistic profile stationary equation',372,grade='E2_SOURCE_BOUNDARY_COUNTERTEST')
# Log–Legendre Hessian and its derivative via direct chain rules.
F=symbols('F',positive=True);ch=symbols('ch',positive=True);ff0=symbols('ff0',real=True);a,b=symbols('a b',real=True,positive=True)
rr=symbols('rr',real=True)
func=rr**3/3+rr**2+2*rr+1
Fs=diff(func,rr); chis=diff(Fs,rr);Ph=rr*Fs-func;Bp=2*func-rr*Fs
Wexpr=b*Ph/Fs**2; ph=a*Matrix([1])[0]*0+a*0 if False else a*0 # differentiation only needs φ'=a χ/F
phi_d=a*chis/Fs
Wphi=simplify(diff(Wexpr,rr)/phi_d)
Wphiphi=simplify(diff(Wphi,rr)/phi_d)
claimed_Wphi=b/a*Bp/Fs**2
claimed_hess=b/a**2*(1/chis-rr/Fs-2*Bp/Fs**2)
claimed_dh=b/a**2*(-diff(chis,rr)/chis**2-3*(Fs-rr*chis)/Fs**2+4*Bp*chis/Fs**3)
test(z(Wphi-claimed_Wphi),True,'Direct symbolic derivative of W=b(Rf′−f)/(f′)² via φ′=a f″/f′',373)
test(z(Wphiphi-claimed_hess),True,'Independent explicit C3 positive convex f(R) logarithmic Hessian',373)
test(z(diff(Wphiphi,rr)-claimed_dh),True,'Independent symbolic derivative of logarithmic Hessian without truncation',373)

# Source reference and control integration are E0 only; no cross-paper proof promotion.
alltex='\n'.join(z.read_text() for z in Path('/mnt/data/bh_audit_work/papers').glob('Paper*.tex'))
labels=set(re.findall(r'\\label\{([^}]+)\}',alltex));refs=set(); missing=set()
for st in census[250:374]:
  for sref in re.findall(r'\\(?:ref|eqref|autoref)\{([^}]+)\}',st['source_text']+'\n'+(st['proof_text'] or '')):
    refs.add(sref)
    if sref not in labels:missing.add(sref)
test(tuple(sorted(missing)),(),f'Current exact label resolution for all {len(refs)} distinct references in 124 source statements and adjacent proofs',list(range(250,374)),grade='E0_REFERENCE_INTEGRITY')
tech=Path('/mnt/data/bh_audit_work/papers/Paper1D-TechnicalMaterial-v1_65.tex').read_text()
test('\\label{p1b:app:native-weak-morse-bridge}' in tech,True,'Locate relocated native Morse operator derivation owner in current Paper I-D, not an E3 certificate',253,grade='E0_REFERENCE_INTEGRITY')
R3={'target_file':P.name,'source_sha256':SHA,'batch':3,'formal_indices':[250,373],
  'checks':C,'passed':sum(x['status']=='PASS' for x in C),'failed':sum(x['status']=='FAIL' for x in C),
  'by_evidence_grade':dict(collections.Counter(x['evidence_grade'] for x in C)),
  'unique_literal_reference_count':len(refs),'dangling_labels':sorted(missing),
  'independent_limit':'Exact identities or explicit finite matrices only; complete YM operator/gauge-slice E3, global finite S3 realization, 8d flat-connection all-parameter classification, low Dirac perturbation, global bundle results and analytic source bounds not independently re-proved.',
  'checker':'One sequential executor; distinct source replay, independent symbolic/finite calculations and adversarial boundary checks, not multiple independent agent signoffs'}
out=W/'Paper1C-IndependentControlsBatch3Results-v1_1.json';out.write_text(json.dumps(R3,indent=2,ensure_ascii=False,default=str))
print('Batch3',R3['passed'],'PASS',R3['failed'],'FAIL','refs',len(refs),'dangling',len(missing))
for bad in C:
 if bad['status']!='PASS':print('FAIL DETAIL',bad)
