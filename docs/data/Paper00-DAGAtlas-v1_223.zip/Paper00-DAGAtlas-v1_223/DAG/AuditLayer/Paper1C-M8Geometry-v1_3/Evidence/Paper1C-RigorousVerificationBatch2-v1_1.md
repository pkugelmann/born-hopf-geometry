# Paper 1C — Rigorous Verification DAG Audit — Batch 2 (v1_1)

- **Controlling source**: `Paper1C-M8Geometry-v1_139.tex` (Paper00-PapersMinimal-v3_018), SHA-256 `4af36222f413886acaa3f0528ea10f040605839b6db2d021f06b2abb5f764044`.
- **Scope**: formal statements **151–300 of 505**, source lines **6135–18080**, including the long embedded technical appendices. Paper 1C only.
- **E0/E1 lineage**: 150/150 statement bodies and 118/118 adjacent proof bodies exactly match the previous v1_138 source-audit ledger; 32 objects have no *adjacent* proof environment (some cite separate I-D appendices or contain inline calculations, so this is not itself a proof failure). No source change, no automatic grade promotion.
- **Inherited grades**: {'VERIFIED': 69, 'REPRODUCED': 41, 'FORMALIZED': 17, 'VERIFIED-CONDITIONAL': 23}. These are historical evidence grades and do not mean 150 freshly independent E3 proofs.
- **Typed proof-use edges**: 41 previously reviewed material links have matched source references with the +5-line location shift; no citation-only edge or physical-actuality selection is promoted.
- **Source ref coverage**: 325 `ref/eqref` occurrences, 207 distinct labels, **zero unresolved** against 32 current TeX files; E0 only.
- **Fresh controls**: **30/30 passed** (exact arithmetic/matrix computations and explicit adversarial cases). Full test definitions, scope limitations and results are in the paired `.py` and `.json` artifacts.

## New source-bound finding

**BH-IC-139-NM-0002 — MINOR, radius/gradient normalization ambiguity, not a certified refutation.** Theorem `p1b:thm:v2217-nonconstant-cartan-dirac`, source L16572–16627, displays `\mathcal E(u)=\langle |\nabla u|^2/6 + (1-u^2)^2/4\rangle` on `S_R^3`, with a radius-independent epsilon² coefficient `5/96` for the specified `h`. The proof uses a **unit-sphere frame**; under that convention the formula passes. If the unqualified `\nabla` is instead read as the radius-R gradient, the coefficient is `1/(12R²)−1/32`, equal to `5/96` only at R=1. At R=2 it is `−1/96`. **Required clarification:** explicitly type the gradient as unit-sphere `\nabla_1`, or write `R²|\nabla_{g_R}u|²`. This is a normalization-notation issue, not evidence that the intended unit-sphere formula is false. Boundary record `BND-IC-B2-0002` is included; no new assumption/physical-actuality node was created.

## Inherited independent-verification obligations with origins in this batch

The following pre-existing **E3/E4 evidence gaps** retain their original IDs and origin; no independently established counterexample is asserted:

- **BH-IB-EV-0006:** global Magnin/u(2)⊕u(2) complex normal form, full Dolbeault filtered quasi-isomorphism and H-twisted generalized-Kähler integrability; origins `g22-global-complex`, `g16-model`, `g14-generalized`. This batch verifies finite model Hodge arithmetic **only**, not the global equivalence.
- **BH-IB-EV-0007:** for all normal-form parameters, holomorphic averaging and global vertical frame/descent underlying SKT existence and canonical-bundle results; origins `v214-full-skt-locus`, `v214-canonical-kodaira`. Finite curvature real-part tests pass, but do not certify holomorphic averaging.
- **BH-IB-EV-0008:** all-level Spin(4)/SU(2)_diag section model, polynomial degree ≤2m and exact positive quadrature transport; origin `all-level-sampling` (L9082–9117). Sector dimensions/graphs and heat controls do not prove the general bundle-isometry or full cubature claim.
- **BH-IB-EV-0009:** full constrained transverse-traceless and Rarita–Schwinger spectra and multiplicities, beyond scalar/Dirac controls; origin `g08-product` (L13356–13377 and detailed appendix).
- **BH-IB-EV-0010:** global finite-quotient kernel, stabilizer strata and degree-twelve pencil ramification, beyond generic topology; origin `g10-product` (L14529–14551 and detailed appendix).
- **BH-IB-EV-0011:** independent full midpoint Yang–Mills Hessian and gauge/ghost projection with conventions and gauge slice; origin `native-midpoint-gauge-morse` (L16428–16471). This batch checks its angular-momentum consequences but not the full differential-operator derivation.

Earlier root IDs `BH-IB-EV-0001` through `0005` and Batch 1 convention issue `BH-IC-139-OR-0001` remain preserved without duplication.

## Mathematical cross-check highlights

- Exchange-invariant metric connection dimensions **112** and skew-torsion **28**; six exact curvature-branch tests on the full bi-invariant family; torsion Dirac zero-mode arithmetic including **16** endpoint product zero modes.
- Full **64-dimensional** Dolbeault model computed independently in both curvature ranks. Its Hodge totals **16** (`rho=2`) and **32** (`rho=1`) match the claimed polynomials. Rank-one Frölicher `E2` total **16** matches `S³×S³×T²` Betti totals, **without** certifying global quasi-isomorphism.
- Sector dimension/parity polynomials for `H_m`; all-level one-factor coordinate graphs; product graph `H1×H1` gives **48 magnitudes, 16 phases** and exchange subfamily **24 magnitudes, 6 phases**; conditional Cl(8) module represented by eight exact 16×16 matrices.
- `P_1` coordinate radius and commutators (exact 5×5 model), level-one Casimir multiplicities `(1,4,4,6)`, large-level heat coefficients, and exchange heat trace.
- Native constant-profile Dirac/CS/YM algebra; nonconstant `h` moments, energy/CS coefficients and cubic low-Dirac coefficient **9/(8192R)**; source-conditional midpoint Morse low angular-momentum count.
- Singular Schur complement with rank-deficient pivot; positive-parent three-compression reconstruction; exact primitive `C_6` projectors of ranks **1,2,3**; trimer Gram matrix and `C_3` complex structure; full antiprism characteristic polynomial `(λ+2)(λ²−2λ−4)` and competing quadrature singular values `(0,2,2)`.

**Audit progress:** `PARTIALLY_AUDITED`, **300/505** formal objects source-disposed; **205 remain** for subsequent batches. No confirmed claim-matched mathematical refutation in Batch 2, one new minor normalization-convention ambiguity, six inherited independent-evidence roots in this range. No supplied ZIP, TeX, framework axiom, or historical verdict was altered. **Final DAG + proof-chain audit ZIPs are reserved for the last batch** (provisionally `Paper00-DAGAtlas-v1_154.zip` and `Paper00-ProofChainAudits-v1_67.zip`).
