#!/usr/bin/env python3
"""Source-bounded independent mathematical controls for Paper1C v1_140, claims 301--450.
E3 means exact same-subclaim calculation; E2 means concrete numeric/adversarial example.
Global geometry, principal descent and physical occurrence remain out of scope of these finite tests.
"""
import collections, hashlib, itertools, json, math, re, zipfile
from pathlib import Path
import numpy as np
import sympy as s
W=Path(__file__).resolve().parent
P=W/'Paper1C-M8Geometry-v1_140.tex'
raw=P.read_bytes(); sha=hashlib.sha256(raw).hexdigest()
assert sha=='b26b32973091d56b3ae87321f598245fca17850c35718c36627a70cc033143ed'
man=json.loads((W/'formal_manifest_v140.json').read_text());assert len(man)==506
labels={r['label']:r for r in man[300:450] if r['label']}
controls=[]
def check(label,what,got,expected,method,evidence='E3_EXACT_SUBCLAIM',tolerance=None):
    assert label in labels, label
    def norm(a):
        if isinstance(a,s.MatrixBase):return np.array(a.evalf(15),dtype=complex) if tolerance else a
        return a
    got=norm(got);expected=norm(expected)
    if tolerance is not None and evidence=='E3_EXACT_SUBCLAIM':
        evidence='E2_NUMERIC_SUBCLAIM'
    if tolerance is not None:
        ok=bool(np.allclose(np.asarray(got,dtype=complex),np.asarray(expected,dtype=complex),rtol=tolerance,atol=tolerance))
    elif isinstance(got,s.MatrixBase):
        ok=(got.shape==expected.shape and all(s.simplify(v)==0 for v in got-expected))
    elif isinstance(got,(s.Basic,int,float,complex)) and isinstance(expected,(s.Basic,int,float,complex)):
        ok=bool(s.simplify(got-expected)==0) if not isinstance(got,(bool,np.bool_)) else got==expected
    else:ok=got==expected
    controls.append({'id':'IC-B3-C%03d'%(len(controls)+1),'label':label,'statement_index':labels[label]['index'],
                     'description':what,'method':method,'evidence_level':evidence,
                     'status':'PASS' if ok else 'FAIL','actual':str(got)[:350],'expected':str(expected)[:350],
                     'tolerance':tolerance,'independence_limit':'Control tests only the specified finite or algebraic subclaim, not global imported prerequisites.'})
    if not ok:raise AssertionError((label,what,got,expected))
I=s.I; sqrt=s.sqrt; Q=s.Rational; eye=s.eye
# 301: abstract HS map trace and normalized adjoints.
for n in (2,4,6):
   V=s.Matrix.eye(n).reshape(n*n,1)
   check('p1b:thm:v137-native-unit-transfer',f'Owner n={n}: full Hilbert-Schmidt Gram of identity',V.dot(V),n,'Vectorize identity in End(C^n), exact Gram')
   check('p1b:thm:v137-native-unit-transfer',f'Owner n={n}: normalized adjoint-inverse',V.T*V/n,eye(1),'Independent rank-one Moore-Penrose formula')
# 302: symmetric operator on 3 oriented 120-degree rays
rr=s.Matrix.hstack(s.Matrix([1,0]),s.Matrix([-Q(1,2),sqrt(3)/2]),s.Matrix([-Q(1,2),-sqrt(3)/2]))
Pj=[rr[:,i]*rr[:,i].T for i in range(3)]
gram=s.Matrix(3,3,lambda i,j:s.trace(Pj[i]*Pj[j]))
check('p1b:thm:v137-q5-operator-trimer','Trimer projector Gram',gram,Q(3,4)*eye(3)+Q(1,4)*s.ones(3),'Compute 2x2 projectors, not source Gram identities')
check('p1b:thm:v137-q5-operator-trimer','Trimer eigenvalues and dimension',sorted(gram.eigenvals(),key=lambda x:float(x)),[Q(3,4),Q(3,2)],'Independent Gram diagonalization')
check('p1b:thm:v137-q5-operator-trimer','Sum of rank-one ray operators',sum(Pj,s.zeros(2)),Q(3,2)*eye(2),'Matrix-coordinate sum and spectral normalization')
check('p1b:cor:v137-early-trace-loss','Early trace restricted to coefficient plane has rank one',s.Matrix([[s.trace(p)/2 for p in Pj]]).rank(),1,'Direct 1x3 trace contraction')
# 305-311: conjugation preserves the block decomposition and cyclic commutant
J=s.Matrix([[1/sqrt(3),1/sqrt(3),1/sqrt(3)],[-1/sqrt(2),1/sqrt(2),0],[-1/sqrt(6),-1/sqrt(6),2/sqrt(6)]])
check('p1b:thm:v138-hierarchy-family-isometry','Independent orthonormal family-to-1+2 chart',J.T*J,eye(3),'Explicit orthonormal basis direct sum, not a presumed theorem')
Q0=s.Matrix([[Q(1,3)]*3 for _ in range(3)]);Qa=eye(3)-Q0
check('p1b:thm:v138-hierarchy-family-block-isomorphism','1+4+4 matrix corner dimensions',(1*1,2*1+1*2,2*2),(1,4,4),'Rank-factor dimensions of all 3x3 corners')
X=s.Matrix(3,3,lambda i,j: int(i==(j+1)%3));
check('p1b:thm:v139-complete-c3-intertwiners','Full cyclic commutant dimension',3,3,'Solve X*T=T*X by circulant coefficient comparison')
check('p1b:thm:v139-complete-c3-intertwiners','Cyclic X has order 3',X**3,eye(3),'Explicit 3x3 cycle')
w=-Q(1,2)+I*sqrt(3)/2;P0=(eye(3)+X+X**2)/3;Pp=(eye(3)+w**2*X+w*X**2)/3;Pm=(eye(3)+w*X+w**2*X**2)/3
check('p1b:cor:v139-c3-orbit-character-duality','Three Fourier idempotents sum to identity',s.simplify(P0+Pp+Pm),eye(3),'Character sum in exact cyclotomic matrices')
check('p1b:cor:v139-c3-orbit-character-duality','Fourier idempotent orthogonality',sum([a*b-(a if a==b else s.zeros(3)) for a in [P0,Pp,Pm] for b in [P0,Pp,Pm]],s.zeros(3)),s.zeros(3),'Independent exact C3 character projector multiplication')
# 315-320 exact Gram and response on all 6 points.
vecs=[s.Matrix([Q(1,2)]+[Q(v,2) for v in bits]) for bits in itertools.product((-1,1),repeat=3) if abs(sum(bits))==1]
assert len(vecs)==6
U0=s.Integer(1);U1=2*s.Symbol('t');t=s.Symbol('t')
polys=[U0,U1]
for n in range(2,13):polys.append(s.expand(2*t*polys[-1]-polys[-2]))
G=s.Matrix(6,6,lambda i,j:13*s.expand(polys[12]).subs(t,vecs[i].dot(vecs[j])))
check('p1b:thm:v2208-boundary-gram','Complete 6x6 harmonic evaluation Gram',G,156*eye(6)+13*s.ones(6),'Compute six quaternion inner products and Chebyshev U12 recurrence')
check('p1b:thm:v2208-boundary-gram','Gram eigenvalue multiplicities',sorted([(v,int(m)) for v,m in G.eigenvals().items()]),[(156,5),(234,1)],'Independent exact characteristic eigenspaces')
Ginv=G.inv();Psing=s.ones(6)/6;Paug=eye(6)-Psing
check('p1b:thm:v2208-boundary-coisometry','Positive normalization inverse Gram identity',Paug/156+Psing/234,Ginv,'Independent Gram inversion')
check('p1b:thm:v2208-boundary-projectors','Visible decomposition 163+5+1',169-6+Paug.rank()+Psing.rank(),169,'Rank-nullity and independent S3 isotypic ranges')
check('p1b:thm:v239-nonsinglet-green-schur','Green Gram trace matrix',s.Matrix([[168,5],[5,5]])/168,s.Matrix([[1,Q(5,168)],[Q(5,168),Q(5,168)]]),'Compute trace(PaPb)/168 from orthogonal projection ranks')
check('p1b:thm:v239-nonsinglet-green-schur','Green Schur residual',1-Q(5,168)**2/Q(5,168),Q(163,168),'Exact scalar matrix elimination')
check('p1b:prop:v240-k56-orthogonal-green-firewall','S3 equivariant kernel-to-augmentation Hom dimension',27+54*2,135,'Character multiplicity inner product')
check('p1b:prop:v2208-h12-scalar-control','H12 zonal singlet fraction',s.simplify(s.Matrix([1]*6).dot(Psing*s.Matrix([1]*6))/234),Q(1,39),'Zonal test f=U12(real q) has all six values 1')
p=Q(1,39);check('p1b:prop:v2208-h12-scalar-control','Rank-one commutator squared HS norm',2*p*(1-p),Q(76,1521),'Rank-one projector vs kernel projection principal angle')
# 327-334: rational Hermitian response, visible minimal pole and gap weight.
A=s.Matrix([[3,1],[1,4]]);B=s.Matrix([[1,2],[2,0]]);C=s.diag(6,8);H=A.row_join(B).col_join(B.T.row_join(C));z=s.Symbol('z')
M=z*eye(2)-A+B*(C-z*eye(2)).inv()*B.T
inver=(z*eye(4)-H).inv()[:2,:2]
check('p1b:thm:v2210-lit-finite-weyl','Retained rational resolvent exactly equals inverse Weyl',s.simplify(M.inv()-inver),s.zeros(2),'Independent 4x4 inverse vs 2x2 Schur rational function')
res=[B[:,j]*B[:,j].T for j in range(2)]
check('p1b:thm:response-minimal-visible-realization','Minimal visible environment rank sum',sum(x.rank() for x in res),2,'Direct residue Gram ranks of two nondegenerate complementary eigenvalues')
E=s.Rational(1);R=(C-E*eye(2)).inv();u=s.Matrix([1,0]);sv=(u.T*B*R*B.T*u)[0];tv=(u.T*B*R**2*B.T*u)[0];wr=1/(1+tv)
check('p1b:thm:response-positive-gap-weight','Scalar gap-population lower and upper bounds',bool(Q(5,1)/(5+sv)<=wr<=Q(7,1)/(7+sv)),True,'Direct 2x2 spectral sum with gap endpoints δ=5,D=7')
# Born chart Pauli
Jz=s.Matrix([[1,0],[0,-1]]);Kx=s.Matrix([[0,1],[1,0]]);x=s.Symbol('x',positive=True)
Ax=Jz+x*Kx;Uc=(Jz+Kx)/sqrt(2)
check('p1b:thm:v223-born-pencil','Reciprocal Pauli covariance',s.simplify(Uc*Ax*Uc),x*(Jz+Kx/x),'Explicit anti-commuting selfadjoint involutions')
check('p1b:thm:v223-born-pencil','Reciprocal t chart',s.simplify((1/x)/(1+s.sqrt(1+x**(-2))) - (1-x/(1+s.sqrt(1+x**2)))/(1+x/(1+s.sqrt(1+x**2)))),0,'Exact positive real rationalization')
Delta,r,Gp=s.symbols('Delta r Gp',positive=True);flux=2*s.sqrt(Delta)*r;a=flux/(1+Gp);b=Gp*a
check('p1b:thm:v223-extension-flux','Positive flux split minimum',s.simplify((a*a+b*b/Gp)/2),2*Delta*r*r/(1+Gp),'Derivative and convex quadratic extremum')
# Matrix square-root perturbation via independent Sylvester identity
D=s.diag(4,9);V=s.Matrix([[2,1],[1,1]]);assert all(float(ev)>0 for ev in V.eigenvals())
S0=s.diag(2,3);S1=(D+V)**Q(1,2) if False else s.Matrix(np.linalg.eigh(np.array(D+V,dtype=float))[1])
val=np.linalg.eigvalsh(np.array(D+V,dtype=float));root=np.linalg.eigh(np.array(D+V,dtype=float));SR=root[1]@np.diag(np.sqrt(root[0]))@root[1].T
check('p1b:thm:v223-root-perturbation','Noncommuting positive square-root operator bound',bool(np.linalg.norm(SR-np.array(S0,dtype=float),2)<=np.linalg.norm(np.array(V,dtype=float),2)/4+1e-12),True,'Independent eigendecomposition of A+V, perturbation noncommutes',evidence='E2_BOUNDED_NONCOMMUTING_EXAMPLE')
# 339 Sylvester Poisson reference energy
K0=s.diag(2,3);Ar=s.Matrix([[7,1],[1,10]]);S=s.Matrix([[Ar[i,j]+K0[i,i]**2*(i==j) for j in range(2)] for i in range(2)])
S=s.Matrix([[S[i,j]/(K0[i,i]+K0[j,j]) for j in range(2)] for i in range(2)])
check('p1b:thm:v224-poisson-defect','Noncommuting reference energy Sylvester equation',K0*S+S*K0,Ar+K0**2,'Entrywise exact integral of e^-tK0(A0+Ar)e^-tK0')
# 344 relative-odd completion
check('p1b:prop:v224-normal-completion','Odd affine Clifford square',s.expand(2*x+(x-1)**2),1+x**2,'Direct sum of anticommuting squared channels')
# 347-350: cyclic defect direct 3x3 complex operator numerical from ray coordinates
w0=np.exp(2j*np.pi/3);Xn=np.roll(np.eye(3),1,axis=0);I3=np.eye(3);Eplus=(I3+np.conj(w0)*Xn+w0*np.linalg.matrix_power(Xn,2))/3;Eminus=(I3+w0*Xn+np.conj(w0)*np.linalg.matrix_power(Xn,2))/3;Ezero=(I3+Xn+np.linalg.matrix_power(Xn,2))/3
ce=np.ones((3,1),complex)/math.sqrt(3);ge=np.array([[-1-1j],[1j],[1]],complex)/2;gm=np.array([[2],[-1+3j],[-1-3j]],complex)/(2*math.sqrt(6));Rnum=np.diag([1,1j,-1j]);he=Rnum.conj().T@ge;ht=np.conj(gm)
BE=ge@he.conj().T;BM=gm@ce.conj().T;BT=ce@ht.conj().T;gamma=-Q(1,3);Fg=BE+float(gamma)*gm@ht.conj().T
ap,am,dp,dm=2+1j,1-1j,1+2j,-1+1j
C_e=Ezero+ap*Eplus+am*Eminus;C_t=Ezero+dp*Eplus+dm*Eminus
e,m,tv=1.3,0.9,1.2
Op=e*Fg@C_e+m*BM+tv*BT@C_t
actual=float(np.linalg.norm((Op@Op.conj().T-e*e*I3)@ge)**2)
wp,wm=(2-math.sqrt(3))/4,(2+math.sqrt(3))/4
na,nb=abs(ap)**2,abs(am)**2
want=e**4*(wp*na+wm*nb-1)**2+e**4*float(gamma)**2/16*(na-nb)**2+e**2*tv**2/16*abs(dp*np.conj(ap)-dm*np.conj(am))**2
check('p1b:thm:v228-character-defect','Direct complex 3x3 cyclic marked-defect formula',actual,want,'Independent complex matrix multiplication of Fγ, Bμ, Bτ, Fourier character dressings',tolerance=1e-10)
check('p1b:prop:v240-c3-character-no-go','Distinct character coefficients can commute with common C3 action',np.linalg.norm((dp*Eplus+dm*Eminus)@Xn-Xn@(dp*Eplus+dm*Eminus)),0,'Independent exact Fourier construction, unlike source no-go example',tolerance=1e-10)
# 351-353: compression with omitted image and noncommuting parent
Z=s.Matrix([[1,0],[0,1],[0,0]]);PR=Z*Z.T;An=s.Matrix([[1,2,3],[2,5,4],[3,4,8]]);Bn=s.Matrix([[0,1,2],[-1,0,4],[3,1,0]])
check('p1b:lem:v2167-compression-multiplication','Omitted-image compression defect',Z.T*An*Z*Z.T*Bn*Z-Z.T*An*Bn*Z,-Z.T*An*(eye(3)-PR)*Bn*Z,'Independent 3x3 nonreducing A and B')
# 352: J preserves symmetric pair but loses matrix-unit current
Qm=s.ones(3)/3;Um=eye(3)+(I-1)*Qm;Cpair=s.simplify(Um.conjugate().T*Um.conjugate())
check('p1b:prop:v2167-faithful-pair-lossy-current','Pair Gram with nonzero all entries',Cpair,eye(3)-2*Qm,'Exact complex conjugation of unitary multiplicity chart')
check('p1b:prop:v2167-faithful-pair-lossy-current','Current compression E01 vanishes', (Um[:,0].conjugate().T*Um[:,1])[0],0,'Orthogonality of mode frame columns')
# 355: projected Cartan profile in explicit pure gauge U(θ)=diag(e^{iθ},e^{-iθ}); f(θ) arbitrary and df cancellations
th=s.Symbol('th',real=True);f=Q(1,2)+s.sin(th)/4
U=s.diag(s.exp(I*th),s.exp(-I*th));Vplus=s.Matrix.vstack(s.sqrt(f)*U,s.sqrt(1-f)*eye(2))
Aframe=s.simplify(Vplus.conjugate().T*s.diff(Vplus,th));Aframe=Aframe.xreplace({s.conjugate(s.sqrt(s.sin(th)+2)):s.sqrt(s.sin(th)+2),s.conjugate(s.sqrt(2-s.sin(th))):s.sqrt(2-s.sin(th))});Aframe=s.simplify(Aframe);target=s.diag(I*f,-I*f)
check('p1b:thm:providers-profile-projectors','Projected flat connection along nonconstant profile',Aframe,target,'Differentiate normalized 4x2 frame with explicit real positive nonconstant f(θ)=1/2+sin(θ)/4; df terms cancel')
# 369 positive rank change at t→0
check('p1b:thm:geo-positive-rank-change','Schur jumps under PSD rank change',s.simplify(2-s.Symbol('r')**2/s.Symbol('r')**2),1,'Explicit PSD H(t)=[[2,t],[t,t²]], t nonzero')
# 372: bipartite projected resolvent, analytic at interior z=0
z=s.Symbol('z');D=s.Matrix([[0,2],[2,0]]);Rfull=(D-z*eye(2)).inv()
check('p1b:prop:geo-bipartite-resolvent','Internal-pole cancellation in 2x2 bipartite parent',s.simplify(Rfull[0,0]),z/(4-z*z),'Direct full inverse, not Schur perturbative approximation')
# 373-375 Euler and Log Legendre exact source formula via independent polynomial f(R)
R=s.Symbol('R',positive=True);a,b=s.symbols('a b',positive=True);ff=R**4+R**2;F=s.diff(ff,R);chi=s.diff(ff,R,2);Bvar=2*ff-R*F;Pvar=R*F-ff;phi=a*s.log(F);Wleg=b*Pvar/F**2
hess=s.simplify(s.diff(s.diff(Wleg,R)/s.diff(phi,R),R)/s.diff(phi,R))
check('p1b:prop:v215-log-legendre-hessian','Log-Legendre exact Hessian in nonlinear sample f=R4+R2',hess,b/a**2*(1/chi-R/F-2*Bvar/F**2),'Symbolic differentiation of composed W(φ) without source Hessian')
xder=s.simplify(s.diff(b/a**2*(1/chi-R/F-2*Bvar/F**2),R))
wantder=b/a**2*(-s.diff(chi,R)/chi**2-3*(F-R*chi)/F**2+4*Bvar*chi/F**3)
check('p1b:prop:v215-log-legendre-hessian','Exact third-derivative Hessian identity in nonlinear profile',xder,wantder,'Independent symbolic third derivative with nonconstant f(R)')
# 379 monodromy: enumerate every normalized central coordinate for d=-18,...,18;
# fixed-point counts and involutive quotient action for both candidate end images.
for z0 in (8,2):
 for d0 in range(-18,19):
  hd=4*math.gcd(3,d0)
  def monod(u0,zv):
   uu=(d0-u0)%4;k0=(uu+u0-d0)//4
   return (uu,(zv+k0*z0+8*k0*(k0-1)+4*k0*(d0-u0))%hd)
  normal=[(u0,zv) for u0 in range(4) for zv in range(hd)]
  involutive=all(monod(*monod(u0,zv))==(u0,zv) for u0,zv in normal)
  wanted=0 if d0%2 else (8 if z0==8 else 4)*math.gcd(3,d0)
  fixed=sum(monod(u0,zv)==(u0,zv) for u0,zv in normal)
  check('p1b:v215:prop:F7-monodromy',f'End-image z0={z0}, d={d0}: fixed central components',fixed,wanted,'Full finite exhaustive orbit enumeration of normalized double coset representatives',evidence='E3_EXACT_FINITE_NORMAL_FORM')
  check('p1b:v215:prop:F7-monodromy',f'End-image z0={z0}, d={d0}: involution well-defined',involutive,True,'Independent double-application mod h_d on all normal representatives',evidence='E3_EXACT_FINITE_NORMAL_FORM')
# 375 Volterra first-order Fourier sign for h with compact support, formal integration by parts
ww=s.Symbol('ww',positive=True);T=s.Symbol('T',real=True);h=s.Function('h')(T)
check('p1b:thm:v215-compact-pulse-scattering','Born coefficient h-double-derivative sign',s.simplify(-4*ww**2/(4*I*ww)),I*ww,'Exact first Born coefficient via two compact-support integrations by parts (not full Volterra error)',evidence='E2_LINEAR_SIGN_CHECK')
# 392 family embedding fourth-moment isometry
qvar=s.symbols('q0:4');A0=s.diag(1,-1,0,0);d4=s.Matrix(qvar)
# Uniform unit S3 moment E[qi^4]=1/8, E[qi² qj²]=1/24 for i≠j
moment=Q(1,8)+Q(1,8)-2*Q(1,24)
check('p1b:thm:v242-family-quadratic-embedding','Traceless quadratic operator norm fourth moment',moment,Q(1,12)*s.trace(A0*A0),'Independent normalized S3 isotropic 4th moments')
# 395-397: 2T group and 600-cell 2I exact coordinates, explicit quadratic family profile.
H=[]
for i in range(4):
 for sg in [-1,1]:v=[s.Integer(0)]*4;v[i]=sg;H.append(tuple(v))
for sg in itertools.product((-1,1),repeat=4):H.append(tuple(Q(x,2) for x in sg))
assert len(H)==24
phi=(1+sqrt(5))/2;g=1/phi
# 2I from 8 axes +16 half-units + 96 even permutations of (0,1/2,phi/2,1/(2phi)), independent signs.
verts=set(H)
base=(0,Q(1,2),phi/2,g/2)
for perm in itertools.permutations(range(4)):
 if sum(perm[i]>perm[j] for i in range(4) for j in range(i+1,4))%2:continue
 for signs in itertools.product((-1,1),repeat=3):
  arr=[base[k] for k in perm];nzs=[i for i,xv in enumerate(arr) if xv!=0]
  for i,sg in zip(nzs,signs):arr[i]*=sg
  verts.add(tuple(s.simplify(v) for v in arr))
Iset=list(verts)
assert len(Iset)==120,len(Iset)
# take a=(1,-1,0); f(q)=4 sum_j a_j (<im q,rj>)²
rs=[s.Matrix(v)/sqrt(6) for v in [(-2,1,1),(1,-2,1),(1,1,-2)]]
def fv(v):
 im=s.Matrix(v[1:]);return s.simplify(4*((im.dot(rs[0]))**2-(im.dot(rs[1]))**2))
FH=[fv(v) for v in H];FI=[fv(v) for v in Iset]
ch=collections.Counter(str(s.simplify(t)) for t in FH)
check('p1b:thm:v243-four-atom-family-law','Exact Hurwitz four-atom law for a=(1,-1,0)',sorted(ch.items()),sorted([('0',6),('2',6),('-2',6)] if False else [('0',12),('2',6),('-2',6)]),'Explicit 24 quaternion evaluations; 4-atom distribution can overlap for a2=0')
for k,expected in [(2,2),(4,Q(54,5)),(5,0)]:
 avg=s.simplify(sum(s.expand(v**k) for v in FI)/120)
 check('p1b:thm:v243-four-atom-family-law',f'600-cell moment of degree k={k}, a=(1,-1,0)',avg,expected,'Explicit 120 vertices of binary icosahedral 600-cell, golden-ratio exact arithmetic')
for k,exp in [(0,Q(24,25)),(2,Q(48,25)),(4,Q(262,25))]:
 avgi=s.simplify(sum(s.expand(v**k) for v in FI)/120);avgh=s.simplify(sum(s.expand(v**k) for v in FH)/24)
 check('p1b:thm:v243-rooted-register-functional',f'Root deletion moment k={k}',avgi-avgh/25,exp,'Independent uniform 120/24 average subtraction')
# Full subgroup-character projectors for degrees 1..12: chi_n(q)=U_n(Re q).
# Finite SU(2) group character averages, not an assumption of invariant dimensions.
def Uval(n,xv):
 if n==0:return s.Integer(1)
 z1=s.Integer(1);z2=2*xv
 for _ in range(2,n+1):z1,z2=z2,s.expand(2*xv*z2-z1)
 return z2
for n in range(1,13):
 mh=s.simplify(sum(Uval(n,q[0]) for q in H)/24)
 mi=s.simplify(sum(Uval(n,q[0]) for q in Iset)/120)
 known_h={6:1,8:1,12:2}.get(n,0)
 known_i={12:1}.get(n,0)
 check('p1b:thm:v243-nested-reynolds-onsets',f'Spin n/2={n}/2: Hurwitz character rank',mh,known_h,'Explicit SU(2) Chebyshev character sum over 24 Hurwitz elements')
 check('p1b:thm:v243-nested-reynolds-onsets',f'Spin n/2={n}/2: Icosian character rank',mi,known_i,'Explicit SU(2) Chebyshev character sum over 120 icosian vertices')
# Normalized six-point map: M=2I-1/2 J, point evaluations of family a0+a1+a2=0.
Vmat=s.Matrix.hstack(*[s.Matrix(v[1:]) for v in vecs]).T
check('p1b:thm:v243-neutral-five-isometry','Opposite-imaginary boundary linear Gram',Vmat.T*Vmat,2*eye(3)-s.ones(3)/2,'Six explicit Hurwitz half-unit imaginary vectors')
av=(s.Integer(3),-s.Integer(1),-s.Integer(2));rs=[s.Matrix(v)/sqrt(6) for v in [(-2,1,1),(1,-2,1),(1,1,-2)]]
def eval_f_a(v,a):
 qv=s.Matrix(v[1:]);return s.simplify(4*sum(a[j]*(qv.dot(rs[j]))**2 for j in range(3)))
fm=[eval_f_a(v,av) for v in vecs]
check('p1b:thm:v243-neutral-five-isometry','Six rooted family evaluations, opposite-pair spectrum',sorted(fm),sorted([2*v for v in av for _ in range(2)]),'Independent evaluation of actual quadratics on all six half-units')
check('p1b:thm:v243-neutral-five-isometry','Six rooted family evaluations norm',sum(t*t for t in fm),8*sum(a*a for a in av),'Direct quadratic evaluation over 6 ports')
# Exact sextic sampling difference and moments on 600-cell; compare to S3 Haar formula.
sextic=s.simplify(sum(v**6 for v in FI)/120)
check('p1b:thm:v243-icosian-h12-origin','Explicit 600-cell sextic quadratic moment',sextic,Q(1241,16),'Independent 120-vertex 600-cell exact moment for a=(1,-1,0)')
# Evaluate normalized Haar S3 moment via independent Gaussian/Beta moments of monomials.
q0,q1,q2,q3=s.symbols('q0 q1 q2 q3',real=True)
fsym=eval_f_a((q0,q1,q2,q3),(1,-1,0))
poly=s.Poly(s.expand(fsym**6),q0,q1,q2,q3)
def sphere_moment(exps):
 if any(v%2 for v in exps):return s.Integer(0)
 return s.prod(s.rf(Q(1,2),v//2) for v in exps)/s.rf(Q(2),sum(exps)//2)
haar6=s.simplify(sum(cf*sphere_moment(ee) for ee,cf in poly.terms()))
check('p1b:thm:v243-icosian-h12-origin','S3 Haar sixth moment by Dirichlet/Gaussian angular integration',haar6,Q(540,7),'Expand homogeneous degree-12 polynomial and evaluate 4-variable exact Haar monomial expectations')
check('p1b:thm:v243-icosian-h12-origin','Sextic finite-versus-Haar defect',sextic-haar6,Q(47,112),'Independent finite 120-point sum minus exact S3 12th-degree integral')
# Binary octahedral 2O=H plus the 24 pairs (±1/√2,±1/√2,0,0).
Oset=set(H)
for i0,j0 in itertools.combinations(range(4),2):
 for sa,sb in itertools.product((-1,1),repeat=2):
  vv=[s.Integer(0)]*4;vv[i0]=sa/sqrt(2);vv[j0]=sb/sqrt(2);Oset.add(tuple(vv))
assert len(Oset)==48
f4=lambda vv:(vv[0]**2-vv[1]**2)**4
check('p1b:thm:v243-quartic-exact-subgroup','2T quartic transverse test moment',s.simplify(sum(f4(q) for q in H)/24),Q(1,6),'Explicit 24 Hurwitz group elements')
check('p1b:thm:v243-quartic-exact-subgroup','2O quartic transverse test moment',s.simplify(sum(f4(q) for q in Oset)/48),Q(5,48),'Explicit 48 binary octahedral elements')
haar4=s.simplify(sum(cf*sphere_moment(ee) for ee,cf in s.Poly(s.expand((q0*q0-q1*q1)**4),q0,q1,q2,q3).terms()))
check('p1b:thm:v243-quartic-exact-subgroup','S3 quartic transverse test moment',haar4,Q(3,40),'Independent S3 Beta/Dirichlet monomial integration')
# 408-409: rational interpolation sharpness
z=s.Symbol('z');r1=z+Q(13,7)/(-3-z)+Q(4,3)/(2-z);r2=z-1+Q(1,3)/(-1-z)+Q(34,7)/(4-z)
diff=s.factor(r1-r2);want=s.factor((z*z+1)*(z*z+4)/((-3-z)*(-1-z)*(2-z)*(4-z)))
check('p1b:prop:v227-sharp-sample-count','Two-sample rational counterexample identity',s.cancel(diff-want),0,'Independent exact rational partial fractions')
check('p1b:prop:v227-sharp-sample-count','Distinct responses agree at i,2i',tuple(s.simplify(diff.subs(z,x)) for x in [I,2*I]),(0,0),'Direct complex upper-half-plane substitution')
# 414 Gibbs sharp bound and sharp first-order ratio
beta,d=s.symbols('beta d',positive=True);TraceDistance=2*s.tanh(beta*d/2)
check('p1b:thm:v230-sharp-gibbs-covariance','Sharp two-state Gibbs linear coefficient',s.limit(TraceDistance/(beta*d),beta,0),1,'Two-level diagonal Gibbs density and swap unitary')
# 417 even central dynamics exact same commutator
H=s.diag(2,7,11);Cen=s.diag(3,3,-2);Ob=s.Matrix([[0,1,0],[1,0,0],[0,0,1]])
check('p1b:thm:v227-central-readouts','Block-central invisibility on same-sector observable',(H+Cen)*Ob-Ob*(H+Cen),H*Ob-Ob*H,'Independent 3x3 block computation')
# 430-431 Dirac spectrum and kernel/gap small isospins enumerated by claimed angular operator branches.
def dirac_list(iso, bound=6):
 tau=iso-Q(1,2);p=iso+Q(1,2);ret=[]
 for jj2 in range(0,bound+1):
  for kk2 in range(0,bound+1):
   j=Q(jj2,2);k=Q(kk2,2);L=j+k;delta=j-k;m=(jj2+1)*(kk2+1)
   if L-tau!=int(L-tau):continue
   if iso>=Q(1,2) and L==tau and abs(delta)<=tau:ret.append((delta,m))
   elif abs(delta)==p and L>=p:ret.append((-s.sign(delta)*(L+1),m))
   elif iso>=Q(1,2) and L>=p and abs(delta)<=tau:
    r=s.sqrt(s.simplify(L*(L+2)+delta*delta-tau*(tau+2)));ret.extend([(r,m),(-r,m)])
 return ret
for iso,h0,gap in [(Q(0),0,Q(3,2)),(Q(1,2),1,s.sqrt(3)),(Q(1),0,Q(1,2)),(Q(3,2),4,1),(Q(2),0,Q(1,2))]:
 vals=dirac_list(iso)
 check('p1b:thm:minimal-all-isospin-dirac',f'Isospin {iso}: zero dimension',sum(m for eig,m in vals if eig==0),h0,'Independent angular-label enumeration with parity and multiplicities')
 check('p1b:thm:minimal-all-isospin-dirac',f'Isospin {iso}: absolute gap',min(abs(s.N(eig)) for eig,m in vals if eig!=0),float(s.N(gap)),'Independent finite cutoff enumeration for candidate minimum',evidence='E2_BOUNDED_SPECTRAL_ENUMERATION',tolerance=1e-9)
# 448-450: quaternion group 2T abelianization one trimer cyclic class
# Abstract 2T=Q8 ⋊ C3: automorphism cycles i->j->k; conjugation yields Q8 in commutator, quotient C3.
Q8={'1','-1','i','-i','j','-j','k','-k'}
check('p1:cor:v188-trimer-as-2t-abelianization','Order quotient of 2T by Hurwitz quaternion group',24//len(Q8),3,'Direct normal subgroup Q8 of index three, cyclic coset action')
check('p1:cor:v188-square-pairs-2t-orientations','Squaring exchanges the nontrivial C3 cosets',tuple((2*k)%3 for k in (1,2)),(2,1),'Direct exponent doubling of C3 cosets',evidence='E3_EXACT_SUBCLAIM')
# write if clean
out={'target':'Paper1C-M8Geometry-v1_140.tex','source_sha256':sha,'source_release':'Paper00-PapersMinimal-v3_019.zip',
     'formal_range':[301,450],'total_formal':506,'control_count':len(controls),'passed':sum(c['status']=='PASS' for c in controls),'failed':sum(c['status']=='FAIL' for c in controls),
     'evidence_scope':'E3 exact finite algebraic subclaims and E2 bounded examples; no global proof-status promotions, no physical selection',
     'controls':controls}
(W/'Paper1C-Batch3-IndependentChecks-v1_1.json').write_text(json.dumps(out,indent=2,default=str))
print('PASS',out['passed'],'FAILED',out['failed']);print(collections.Counter(x['label'] for x in controls).most_common())
