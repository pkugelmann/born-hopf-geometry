#!/usr/bin/env python3
"""Independent rational-moment reconstruction of 2I degree 12/20 overlaps."""
import sympy as sp
from functools import lru_cache
from math import comb

t,w=sp.symbols('t w')

@lru_cache(None)
def r_sum(k):
    # q^2 external-coordinate square options: 0,1/4,(3+-sqrt5)/8
    if k==0:return sp.Integer(4)
    if k==1:return sp.Integer(1)
    # golden pair a+b=3/4, ab=1/16
    p0,p1=sp.Integer(2),sp.Rational(3,4)
    for _ in range(2,k+1):p0,p1=p1,sp.Rational(3,4)*p1-sp.Rational(1,16)*p0
    return sp.Rational(1,4)**k+p1

@lru_cache(None)
def moment(i,j):
    if i+j==0:return sp.Integer(1)
    axes=2*(int(i==0)+int(j==0))
    hurwitz=sp.Rational(16,4**(i+j))
    external=8*(r_sum(i)*r_sum(j)-r_sum(i+j))
    return sp.factor((axes+hurwitz+external)/120)

@lru_cache(None)
def even_power(d):
    return sp.expand(sum(sp.binomial(2*d,2*i)*t**i*(1-t)**(d-i)*moment(i,d-i) for i in range(d+1)))

def overlap(k):
    assert k%2==0
    p=sp.Poly(sp.expand(sum((-1)**r * sp.binomial(k-r,r)*2**(k-2*r)*even_power((k-2*r)//2) for r in range(k//2+1))),t)
    out=sp.rem(p,sp.Poly(t*t-t+w,t),domain='QQ[w]')
    return sp.factor(out.as_expr())

# Independent moments of q0 on Hurwitz subgroup and its binary octahedral extension.
def A_k(k,group):
    U=sp.chebyshevu(k,t)
    if group=='2T':
        return sp.simplify((U.subs(t,1)+U.subs(t,-1)+6*U.subs(t,0)+8*U.subs(t,sp.Rational(1,2))+8*U.subs(t,-sp.Rational(1,2)))/24)
    if group=='2O':
        # extra 24 points: 12 with q0=0, six each q0=+-1/sqrt2
        new=12*U.subs(t,0)+6*U.subs(t,sp.sqrt(2)/2)+6*U.subs(t,-sp.sqrt(2)/2)
        return sp.simplify((24*A_k(k,'2T')+new)/48)
    if group=='2I':
        if k%2:return sp.Integer(0)
        return sp.simplify(overlap(k).subs(w,0))
    raise ValueError(group)

f12=overlap(12)
f20=overlap(20)
claim12=1-28*w+196*w**2-420*w**3
claim20=1-sp.Rational(220,3)*w+sp.Rational(4532,3)*w**2-sp.Rational(36212,3)*w**3+sp.Rational(119680,3)*w**4-44880*w**5
assert sp.expand(f12-claim12)==0, (f12,claim12)
assert sp.expand(f20-claim20)==0, (f20,claim20)
assert sp.factor(sp.gcd(sp.Poly(f12,w),sp.Poly(f20,w)).as_expr())==1
assert f12.subs(w,sp.Rational(1,4))==-sp.Rational(5,16)
assert [k for k in range(1,21) if A_k(k,'2I')!=0]==[12,20]
assert A_k(12,'2T')==2 and A_k(12,'2O')==1
print('PASS: exact 2I coordinate moment formulas and f12/f20 overlap polys')
print('F12(w)=',f12); print('F20(w)=',f20)
print('ranks k<=20 for 2I:',{k:A_k(k,'2I') for k in range(1,21) if A_k(k,'2I')})
print('H/O fixed rank at k=12:',A_k(12,'2T'),A_k(12,'2O'))
print('normalizer overlap c=',f12.subs(w,sp.Rational(1,4)))
c=f12.subs(w,sp.Rational(1,4))
a=sp.factor(c**2*(1+c)/2)
b=sp.factor(c**2*(1-c)/2)
assert (a,b)==(sp.Rational(275,8192),sp.Rational(525,8192))
print('three-stage symmetric eigenvalues a,b=',a,b)
assert sp.factor((sp.Rational(1,4)*1-0))
