Archived certificate executables were checked separately; exact v366/v370 and F40 v1_10 predecessor missing. See Batch 7 evidence ledger.
