#!/usr/bin/env python3
"""Independent, scoped controls for Paper I-C, source census #97--135.
This tests finite identities and concrete sample points; it DOES NOT prove global
homotopy classes, geometric classification, or the natural bit by numerical sampling.
"""
import json, math, hashlib
from pathlib import Path
from collections import Counter
import numpy as np

rng=np.random.default_rng(20261113)
results=[]

def check(group, name, good, *, kind='NUMERICAL', description='', value=None):
    good=bool(good)
    results.append({'family':group,'case':name,'passed':good,'kind':kind,
                    'scope':description,'result':None if value is None else float(np.real(value))})
    if not good: raise AssertionError(f'{group}: {name}; {value}')

def near(a,b,tol=5e-9): return np.allclose(a,b,rtol=tol,atol=tol)

def normq(q): return np.linalg.norm(q)
def qmul(p,q):
    a,x=p[0],p[1:]; b,y=q[0],q[1:]
    return np.r_[a*b-np.dot(x,y),a*y+b*x+np.cross(x,y)]
def qconj(q): return np.r_[q[0],-q[1:]]
def qinv(q): return qconj(q)/np.dot(q,q)
def qunit():
    p=rng.normal(size=4);return p/np.linalg.norm(p)
def qpow(q,n):
    if n<0: return qpow(qinv(q),-n)
    z=np.array([1.,0,0,0]);base=q.copy()
    while n:
        if n&1: z=qmul(z,base)
        base=qmul(base,base);n//=2
    return z
def qexp(v):
    t=np.linalg.norm(v)
    return np.r_[math.cos(t), v*math.sin(t)/t if t>1e-14 else v]
def qdist(q,p):
    v=qmul(qinv(q),p);return np.arccos(np.clip(v[0],-1,1))
def su2(q):
    a,b,c,d=q
    return np.array([[a+1j*b,c+1j*d],[-c+1j*d,a-1j*b]],dtype=complex)
def qlog(q):
    x=q[1:];s=np.linalg.norm(x)
    return x*(math.atan2(s,q[0])/s) if s>1e-13 else x

def sec(x,p):
    ax=1-x[0]; ap=1-p[0]
    if ax<1e-13 or ap<1e-13: return np.array([1.+0j,0j,0j])
    K=2*ax+2*ap-ax*ap
    u0=1-2*ax*ap/K
    ux=2*ap*x[1:]/K
    up=2*ax*p[1:]/K
    ua=(ux+up)/np.sqrt(2); ub=(ux-up)/np.sqrt(2)
    z0=u0+1j*ub[1];z1=ua[2]+1j*ub[2]
    r=np.sqrt(abs(z0)**2+abs(z1)**2)
    h=np.array([0.,0.,0.]) if r<1e-14 else np.array([2*(z0*np.conj(z1)).real,2*(z0*np.conj(z1)).imag,abs(z0)**2-abs(z1)**2])/r
    return np.array([h[2]+1j*h[0],ua[0]+1j*ua[1],ub[0]+1j*h[1]])

J=np.diag([1,1,-1]).astype(complex);e1=np.array([1.,0,0],complex);e2=np.array([0.,1,0],complex);e3=np.array([0.,0,1],complex);I=np.eye(3,dtype=complex)
def proj(v): return np.outer(v,np.conj(v))
def transport(a,b):
    c=np.vdot(a,b)
    if abs(1+c)<1e-9: raise ValueError('bad chart')
    w=b-c*a;alpha=(1+c)/(1+np.conj(c))
    d=(1+np.conj(c))/abs(1+c)
    U=I+(c-1)*proj(a)+np.outer(w,a.conj())-alpha*np.outer(a,w.conj())-np.outer(w,w.conj())/(1+np.conj(c))
    return (proj(b)+d*(I-proj(b)))@U

def Qjoin(a): return np.column_stack([e2,a*e3,e1])
def Tjoin(w): return transport(e1,sec(w,-w))
def F0(y):
    a=sec(y,y)
    return np.column_stack([[-np.conj(a[1]),np.conj(a[0]),0],e3,a]).astype(complex)

def cap(x,delta=1/12):
    v=qlog(x);r=np.linalg.norm(v)
    if r>=delta: return np.array([1.,0,0,0])
    g=delta*delta-r*r; den=r*r+g*g
    return np.r_[(r*r-g*g)/den,-2*g*v/den]

def frameQ(x,p): return transport(e1,sec(x,p))@Qjoin(1)
def gaugeX(x,p):
    if np.linalg.norm(qlog(x))>=1/12: return I.copy()
    Q=frameQ(x,p);V=np.eye(3,dtype=complex);V[:2,:2]=su2(cap(x))
    return Q@V@Q.conj().T

def gauges(x,p):
    X=gaugeX(x,p);P=J@gaugeX(p,x)@J
    A=X@P;B=P@X;V=A@B;H=X@P@X.conj().T@P.conj().T
    return X,P,A,B,V,H

def fs(t,x,p):
    X,P,A,B,V,H=gauges(x,p)
    s=sec(x,p);PS=proj(s);PE=I-PS
    c=np.clip(((np.trace(A).real)-1)/2,-1.,1.)
    W=(A-A.conj().T)/2
    h=np.linalg.norm(W)/np.sqrt(2)
    if h<1e-10:
        if c<0: return I.copy() # on E the value V=I at A=-I
        return V
    theta=math.atan2(h,c)
    R=PS+math.cos(t*theta)*PE + math.sin(t*theta)*W/h
    return R.conj().T@V@R

def h_s(t,q):
    theta=(math.pi/2)*(1-t)
    z0,z1=su2(q)[:,0]
    return np.array([math.sin(theta)**2+math.cos(theta)**2*z0,
       math.cos(theta)*z1,math.sin(theta)*math.cos(theta)*(1-z0)],complex)
def gkd(t,lam,q,k=1,d=1):
    h=h_s(t,qpow(q,d))
    return e3+(lam**k-1)*np.conj(h[2])*h

# RT58: exact normative identities plus sample-quantified inequalities
for i in range(48):
    x=qunit();p=qunit();ss=sec(x,p)
    check('RT58-suspended-section',f'unit-{i}',near(np.vdot(ss,ss),1),description='unit vector formula')
    check('RT58-suspended-section',f'equiv-{i}',near(sec(p,x),J@ss),description='exchange J-equivariance')
    a=sec(qunit(),qunit());b=sec(qunit(),qunit())
    T=transport(a,b)
    check('RT58-SU3-transport',f'unitary-{i}',near(T.conj().T@T,I),description='transport is unitary')
    check('RT58-SU3-transport',f'det-{i}',near(np.linalg.det(T),1),description='transport has determinant +1')
    check('RT58-SU3-transport',f'image-{i}',near(T@a,b),description='transport sends a to b')
    check('RT58-SU3-transport',f'covariance-{i}',near(transport(J@a,J@b),J@T@J),description='J equivariance')
    w=qunit();bw=sec(w,-w);tw=Tjoin(w)
    check('RT60-joining',f'special-chart-{i}',(1+np.vdot(e1,bw)).real>=2/9-1e-8,
          description='global antipodal transport denominator')
    check('RT60-joining',f'equiv-{i}',near(Tjoin(-w),J@tw@J),description='joining transport exchange')
    z=complex(math.cos(float(i)),math.sin(float(i)))
    QZ=Qjoin(z);QY=tw@QZ
    check('RT60-joining',f'detQZ-{i}',near(np.linalg.det(QZ),z),description='ordinary joining-frame determinant')
    check('RT60-joining',f'detQY-{i}',near(np.linalg.det(QY),z),description='ordinary joining-frame determinant')
    check('RT60-joining',f'deckQZ-{i}',near(Qjoin(-z),J@QZ),description='joining frame deck descent')
    check('RT60-joining',f'deckQY-{i}',near(Tjoin(-w)@Qjoin(-z),J@QY),description='joining frame deck descent')

# RT58 small normal, with representative quaternion n; and cap frame bound
for i in range(36):
    y=qunit(); n=qunit(); eps=1/12*rng.random()
    x=qmul(y,qexp(eps*n[1:]));p=qmul(y,qexp(-eps*n[1:]))
    a=sec(y,y);b=sec(x,p)
    check('RT58-small-normal',f'bound-{i}',np.linalg.norm(b-a)<=3*np.sqrt(2)*eps*np.linalg.norm(n[1:])+3e-8,description='Lipschitz normal chart')
    check('RT58-small-normal',f'positive-overlap-{i}',np.vdot(a,b).real>0,description='overlap excludes -1')
    x=qexp(rng.normal(size=3)*0.011);p=qunit();ss=sec(x,p)
    check('RT62-cap',f'capbound-{i}',np.linalg.norm(ss-e1)<=.25+1e-7,description='uniform cap bound')
    check('RT62-cap',f'frame-last-{i}',near(frameQ(x,p)@e3,ss),description='local frame last column')

# RT61 actual U3 joining homotopy and local degree
for i in range(64):
    q=qunit();theta=2*np.pi*rng.random();lam=np.exp(1j*theta);t=rng.random()
    h=h_s(t,q)
    check('RT61-homotopy',f'h-unit-{i}',near(np.vdot(h,h),1),description='h_s unit')
    L=I+(lam-1)*proj(h)
    check('RT61-homotopy',f'unitary-{i}',near(L.conj().T@L,I),description='L is unitary')
    check('RT61-homotopy',f'determinant-{i}',near(np.linalg.det(L),lam),description='det L=lam')
    check('RT61-homotopy',f'projected-norm-{i}',near(np.vdot(gkd(t,lam,q),gkd(t,lam,q)),1),description='last-column image unit')
    check('RT61-homotopy',f'wedge-{i}',near(gkd(t,1,q),e3),description='based circle wedge')
    check('RT61-homotopy',f'end0-{i}',near(gkd(0,lam,q),e3),description='s=0 collapse')
    check('RT61-homotopy',f'end1-{i}',near(gkd(1,lam,q),e3),description='s=1 collapse')

def gchart(z):
    t,phi,*im=z
    q=np.r_[-math.sqrt(max(0.,1-np.dot(im,im))),im]
    lam=-np.exp(1j*phi)
    out=gkd(t,lam,q)
    return np.array([out[0].real,out[0].imag,out[1].real,out[1].imag,out[2].imag])
eps=2e-6; at=np.array([.5,0,0,0,0.])
D=np.column_stack([(gchart(at+eps*np.eye(5)[j])-gchart(at-eps*np.eye(5)[j]))/(2*eps) for j in range(5)])
D_expected=np.array([[2*np.pi,0,0,0,0],[0,0,-1,0,0],[0,0,0,np.sqrt(2),0],[0,0,0,0,-np.sqrt(2)],[0,-1,0,0,0]])
check('RT61-local-degree','Jacobian-matrix',near(D,D_expected,tol=1e-7),description='five-variable finite-difference differential at unique antipode')
check('RT61-local-degree','Jacobian-determinant',abs(np.linalg.det(D)-4*np.pi)<1e-6,description='nonzero local Jacobian for degree-one proof',value=np.linalg.det(D))

# RT62 actual gauge matrices, exchange, pointwise identities, central N and special cap compatibility
for i in range(64):
    if i%4==0:
        x=qexp(rng.normal(size=3)*.015);p=qexp(rng.normal(size=3)*.015)
    elif i%4==1:
        x=qexp(rng.normal(size=3)*.015);p=qunit()
    elif i%4==2:
        x=qunit();p=qexp(rng.normal(size=3)*.015)
    else: x=qunit();p=qunit()
    X,P,A,B,V,H=gauges(x,p)
    S=sec(x,p);N=2*proj(S)-I
    check('RT62-actual-gauges',f'fixs-{i}',near(A@S,S),description='actual fibre operator fixes stabilizing section')
    check('RT62-actual-gauges',f'det-{i}',near(np.linalg.det(A),1),description='actual gauge has determinant one')
    check('RT62-actual-gauges',f'sigmaA-{i}',near(J@gauges(p,x)[2]@J,B),description='exchange takes A to B')
    check('RT62-actual-gauges',f'sigmaH-{i}',near(J@gauges(p,x)[5]@J,H.conj().T),description='exchange commutator inverse')
    check('RT62-actual-gauges',f'sigmaV-{i}',near(J@gauges(p,x)[4]@J,B@A),description='exchange takes V to BA')
    check('RT62-actual-gauges',f'N^2-{i}',near(N@N,I),description='central fibre sign involution')
    f=fs(rng.random(),x,p)
    check('RT63-closing',f'unit-{i}',near(f.conj().T@f,I),description='closing conjugation unitary')
    check('RT63-closing',f'fix-section-{i}',near(f@S,S),description='closing fixes actual stabilizing line')
    check('RT63-closing',f'det-{i}',near(np.linalg.det(f),1),description='closing determinant one')
    check('RT63-closing',f'end0-{i}',near(fs(0,x,p),V),description='closing initial root')
    check('RT63-closing',f'end1-{i}',near(fs(1,x,p),B@A),description='closing exchange endpoint')

for i in range(64):
    w=qunit();x=w;p=-w
    X,P,A,B,V,H=gauges(x,p)
    check('RT63-joining',f'AeqB-{i}',near(A,B),description='disjoint cap supports on antipodal pairs')
    check('RT63-joining',f'H=I-{i}',near(H,I),description='commutator is pointwise identity on joining')
    check('RT63-joining',f'closing-constant-{i}',near(fs(.7,x,p),A@A),description='joining closing family is t-independent')

# RT60 clutch is actual stabilized map between different last columns, deck check.
for i in range(32):
    a=np.exp(2j*np.pi*rng.random()); w=qunit();u=qmul(np.array([a.real,a.imag,0,0])*-1 if False else np.array([a.real,-a.imag,0,0]),w)
    Z=Qjoin(a);Y=Tjoin(w)@Z
    B=np.eye(3,dtype=complex);B[:2,:2]=su2(u)
    clutch=Y@B@Z.conj().T
    check('RT60-odd-clutch',f'det-{i}',near(np.linalg.det(clutch),1),description='determinant-one stabilized clutch')
    check('RT60-odd-clutch',f'lastcol-{i}',near(clutch@e1,sec(w,-w)),description='clutch sends stabilizer to exotic section')
    an=-a;un=qmul(np.array([an.real,-an.imag,0,0]),-w)
    Zn=Qjoin(an);Yn=Tjoin(-w)@Zn
    Bn=np.eye(3,dtype=complex);Bn[:2,:2]=su2(un)
    check('RT60-odd-clutch',f'deck-{i}',near(Yn@Bn@Zn.conj().T,J@clutch@J),description='clutch descends under deck')

# RT59 proof identity over GF(2): finite prism with injected or repeated image vertices.
def bd(chain):
    out=Counter()
    for face in chain:
        for j in range(len(face)):
            sub=face[:j]+face[j+1:]
            out[sub]^=1
    return {f for f,c in out.items() if c%2}
def prism(simplex,f):
    faces=[];n=len(simplex)-1
    for j in range(n+1):
        v=tuple(('A',x) for x in simplex[:j+1])+tuple(('T',f[x]) for x in simplex[j:])
        if len(set(v))==len(v): faces.append(v)
    return set(faces)
def xor(*sets):
    out=set()
    for S in sets:out^=S
    return out
for n in range(1,10):
    for collapse in (False,True):
        v=list(range(n+1));f={i:(i//2 if collapse else i) for i in v}
        L=prism(tuple(v),f)
        # Boundary mod 2; account multiplicities in sum on faces.
        bl=bd(L)
        boundary_n=set()
        for j in range(n+1):
            pp=prism(tuple(v[:j]+v[j+1:]),f)
            boundary_n^=pp
        left=bl^boundary_n
        rhs={tuple(('A',x) for x in v)}
        if len(set(f.values()))==len(v):rhs.add(tuple(('T',f[x]) for x in v))
        check('RT59-mapping-prism',f'n{n}-collapse{collapse}',left==rhs,
             kind='EXACT',description='mod-2 prism identity for injective and simplicially collapsed maps')

# Global maximal bound in ND.4 (the actual denominator formula, not a topological proof)
import sympy as sp
t=sp.symbols('t',real=True)
rat=8*t*(1-t)/(3+t)**2
check('ND1-joining-line','max-at-3over7',sp.simplify(sp.diff(rat,t)-8*(3-7*t)/(3+t)**3)==0,
      kind='EXACT',description='exact derivative of joining line norm')
check('ND1-joining-line','max-equals-one-sixth',sp.simplify(rat.subs(t,sp.Rational(3,7))-sp.Rational(1,6))==0,
      kind='EXACT',description='exact 1/6 supremum')

# NC41 cap inversion with specified negative direction: check actual q_delta(b(Q)) = Q
for i in range(40):
    q=qunit()
    if abs(q[0]-1)<1e-10:continue
    kval=np.linalg.norm(q[1:])/(1-q[0]);delta=1/12
    rad=2*kval*delta**2/(1+np.sqrt(1+4*kval*kval*delta*delta))
    x=qexp(-rad*q[1:]/np.linalg.norm(q[1:]))
    check('NC41-cap-inverse',f'inverse-{i}',near(cap(x),q,tol=2e-8),description='explicit inverse of rational quaternion cap')

# NC5 frame construction: 16 exact transports and C0(1,u) diagonal logarithm
for i in range(12):
    y=qunit();uv=rng.normal(size=3);uv=uv/np.linalg.norm(uv)
    sfun=lambda a:sec(qmul(y,qexp(a*uv)),qmul(y,qexp(-a*uv)))
    f=F0(y)
    for k in range(16):f=transport(sfun(k*np.pi/32),sfun((k+1)*np.pi/32))@f
    check('NC5-coherent-frame',f'unitary-{i}',near(f.conj().T@f,I),description='coherent 16-step frame unitary')
    check('NC5-coherent-frame',f'lastcol-{i}',near(f@e3,sfun(np.pi/2)),description='coherent frame last column')
    C0=Qjoin(1).conj().T@Tjoin(qmul(y,np.r_[0.,uv])).conj().T@f
    check('NC5-coherent-frame',f'C0-stabilizer-{i}',near(C0@e3,e3),description='outer C0 fixes stabilizer')
    check('NC5-coherent-frame',f'C0-2block-{i}',near(np.linalg.det(C0[:2,:2]),1),description='coherent C0 block in SU2')

# NC5/NC11 y=1 phase check with actual SU3 transporter
for i in range(20):
    uv=rng.normal(size=3);uv/=np.linalg.norm(uv)
    qfun=lambda a:sec(qexp(a*uv),qexp(-a*uv))
    f=F0(np.array([1.,0,0,0]));ell=0.
    for k in range(16):
        a0=qfun(k*np.pi/32);a1=qfun((k+1)*np.pi/32)
        c=np.vdot(a0,a1)
        ell+=np.angle(1+np.conj(c))
        f=transport(a0,a1)@f
    bf=qfun(np.pi/2);T=Tjoin(np.r_[0.,uv]);C0=Qjoin(1).conj().T@T.conj().T@f
    ell-=np.angle(1+np.conj(bf[0]))
    D=np.diag([np.exp(1j*ell),np.exp(-1j*ell),1])
    check('NC11-global-log',f'diag-{i}',near(C0,D),description='C0(1,u) actual diagonal phase computed from finite exact transports')

# RT52 fibre group component arithmetic: c in Z/12 as unknown central coordinate.
def gp(x,y):
    p,q,r=x;a,b,z=y
    return (p+a,q+b,(r+z+p*b)%12)
def gi(x):
    p,q,r=x;return (-p,-q,(-r+p*q)%12)
def gcomm(x,y):return gp(gp(gp(x,y),gi(x)),gi(y))
for c in range(12):
    X=(1,0,c); P=(0,1,(-c)%12)
    A=gp(X,P);B=gp(P,X);H=gcomm(X,P);V=gp(A,B)
    check('RT62-Heisenberg',f'A-{c}',A==(1,1,1),kind='EXACT',description='source exotic gauge A component')
    check('RT62-Heisenberg',f'B-{c}',B==(1,1,0),kind='EXACT',description='source exotic gauge B component')
    check('RT62-Heisenberg',f'H-{c}',H==(0,0,1),kind='EXACT',description='source H component independent of c')
    check('RT62-Heisenberg',f'V-{c}',V==(2,2,2),kind='EXACT',description='source sphere root component')
    c0=gp((0,0,3),gi(V))
    check('RT62-Heisenberg',f'C-{c}',c0==(-2,-2,5),kind='EXACT',description='combined root component')

# NC.2/3: explicit displaced clutch support misses joining sphere gauge; test matrix agreement
j=np.array([0.,0,1,0]);jinv=qconj(j)
for i in range(52):
    a=np.exp(1j*2*np.pi*rng.random());w=qunit();uv=qmul(np.array([a.real,-a.imag,0,0]),w)
    fj=cap(qmul(jinv,uv));T=Tjoin(w);QZ=Qjoin(a);QY=T@QZ
    F=np.eye(3,dtype=complex);F[:2,:2]=su2(fj)
    clutch=QY@F@QZ.conj().T
    X,P,A,B,V,H=gauges(w,-w)
    KZ=T.conj().T@A@T;SZ=KZ@KZ
    check('NC2-odd-clutch',f'commutes-{i}',near(clutch@SZ@clutch.conj().T,A@A),description='disjoint support ensures pointwise matched odd sphere triple')


# ND3 exact singular circle of the e2-projection: test entire parameter family.
for i in range(32):
    angle=2*np.pi*i/32
    y=np.array([-1/3,(2*np.sqrt(2)/3)*np.cos(angle),(2*np.sqrt(2)/3)*np.sin(angle),0.])
    s0=sec(y,y)
    check('ND3-singular-locus',f'circle-{i}',np.linalg.norm((I-proj(s0))@e2)<2e-9,
         description='exact source singular circle gives P_s e2=0')

# NC34 projective parametrization of the FULL preimage locus, checking precisely
# the u·X^{-1}uX=1/3 equation; this is not a PT classification of the full map.
for i in range(60):
    u=rng.normal(size=3);u/=np.linalg.norm(u)
    tmp=rng.normal(size=3);w=tmp-np.dot(tmp,u)*u;w/=np.linalg.norm(w)
    theta=2*np.pi*rng.random()
    X=np.r_[np.sqrt(2/3)*np.cos(theta),np.sqrt(2/3)*np.sin(theta)*u+np.sqrt(1/3)*w]
    U=np.r_[0.,u]
    V=qmul(qmul(qconj(X),U),X)
    check('NC34-branch-chart',f'unitX-{i}',near(np.dot(X,X),1),description='normal-branch X unit')
    check('NC34-branch-chart',f'conj-angle-{i}',abs(np.dot(u,V[1:])-1/3)<2e-9,
          description='quaternion conjugation branch equation d=1/3')

D37=sp.Matrix([[sp.Rational(8,9),sp.Rational(4,3),-sp.sqrt(3)/2],
  [4*sp.sqrt(2)/9,-4*sp.sqrt(2)/3,sp.sqrt(6)/2],[0,2*sp.sqrt(6)/3,3*sp.sqrt(2)/2]])
check('NC37-normal-derivative','det-minus-eight',sp.simplify(D37.det()+8)==0,
      kind='EXACT',description='exact source normal Jacobian determinant; not full PT framing certificate')

out={'artifact':'Paper1C-IndependentControlsBatch3Results-v1_1.json',
     'audit_target':'Paper1C-TechnicalMaterial-v1_59.tex',
     'source_census_zero_based':[97,135],
     'disclaimer':'Exact/finite and sampled controls only. Global equivariant bundle classification, nontrivial Pontryagin-Thom framing, original natural sphere bit and imported triangulation are not independently proved by this suite.',
     'count':len(results),'passed':sum(z['passed'] for z in results),'kinds':dict(Counter(z['kind'] for z in results)),
     'families':dict(Counter(z['family'] for z in results)),
     'checks':results}
file=Path('/mnt/data/Paper1C-IndependentControlsBatch3Results-v1_1.json')
file.write_text(json.dumps(out,indent=2)+'\n')
print('OK',out['passed'],'/',out['count'],out['kinds'],out['families'])
