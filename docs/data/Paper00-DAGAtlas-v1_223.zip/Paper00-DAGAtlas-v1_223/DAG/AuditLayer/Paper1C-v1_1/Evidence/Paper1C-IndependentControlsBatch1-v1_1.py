#!/usr/bin/env python3
"""Paper I-C Batch 1 independent scoped controls (census 0..49).
This suite tests finite consequences of the actual source, NOT the completeness
of its global equivariant homotopy/bundle gauge constructions.
No network or inputs modified. CP suite finite-precision checks are labeled.
"""
import math, json, hashlib, itertools
from pathlib import Path
from sympy import Matrix, ZZ
from sympy.matrices.normalforms import smith_normal_form

RESULT=[]
def check(family,name,condition,detail='',kind='EXACT'):
    result=bool(condition)
    RESULT.append(dict(family=family,control=name,passed=result,kind=kind,detail=str(detail)))
    if not result: raise AssertionError(f'{family}:{name} {detail}')

def subgroup(generators):
    s={(0,0,0)}
    todo=list(generators)
    while todo:
        g=todo.pop()
        if g in s: continue
        s.add(g)
        for x in list(s):
            for y in (tadd(x,g), tadd(x,(-g[0]%6,g[1],g[2]))):
                if y not in s:todo.append(y)
    return s

def tadd(a,b):return ((a[0]+b[0])%6,(a[1]+b[1])%2,(a[2]+b[2])%2)
Z=(0,0,0); t=(0,0,1);a=(3,0,0); e=(0,1,0)
T=[(z,e0,t0) for z in range(6) for e0 in range(2) for t0 in range(2)]
T2=[x for x in T if tadd(x,x)==Z]
check('finite-T','T-24',len(T)==24)
check('finite-T','T2-eight',len(T2)==8 and set(T2)==set(itertools.product((0,3),(0,1),(0,1))))
for eps in (0,1):
 for k in range(-3,4):
    candidates=[z for z in (0,3) if (2*z-6*eps*k)%12==0 and (-2*z-6*eps*k)%12==0]
    check('natural-low-column',f'eps{eps}-k{k}',candidates==[3*(eps*k%2)],candidates)
for A in range(-24,25):
    even=A%2==0
    j0=subgroup([t]) if even else {Z}
    j1=subgroup([t,a]) if even else subgroup([t,a])
    j0det=subgroup([t]) if even else {Z}
    j1det=subgroup([t])
    sizes=(48//len(j0),48//len(j1))
    check('mixed-count',f'A{A}',2*sum(sizes)==(72 if even else 120),sizes)
    aux=(48//len(j0det),48//len(j1det))
    check('determinant-one-count',f'A{A}',2*sum(aux)==(96 if even else 144),aux)
    zA=(5-2*A)%6
    check('sphere-primary',f'congruence-A{A}',(2+2*zA+4*A)%12==0)
    check('sphere-primary',f'odd-zA-A{A}',zA%2==1)
    h12=math.gcd(12,A); h6=math.gcd(6,A)
    if even:
        check('lift-fibres',f'even-sector0-A{A}',(12//h12)*(2*h12)==24)
        check('lift-fibres',f'even-sector1-special-A{A}',(6//h6)*(2*h6)==12)
        check('lift-fibres',f'even-sector1-other-A{A}',(12//h6)*h6==12)
        check('lift-fibres',f'even-bound-A{A}',12//h12<=6 and (A%4 != 0 or 24//h12<=6) and 12//h6<=6)
    else:
        check('lift-fibres',f'odd-sector0-A{A}',(96//h12)*h12==96)
        check('lift-fibres',f'odd-sector1-A{A}',(12//h6)*h6==12)
    for n in range(-2,3):
       lhs=(zA-4*n)%6
       rhs=(5-2*(A+2*n))%6
       check('normal-component-shear',f'A{A}-n{n}',lhs==rhs)

# Exact group presentations [b,z,e,t]: 6z=2e=2t=0,
# 2b+z_Az+w_e e+w_t t=0, plus source-supported gauge relations.
def invariants(A, sec, det=False, omega=0, we=0, wt=0):
    zA=(5-2*A)%6
    rels=[[0,6,0,0],[0,0,2,0],[0,0,0,2],[2,zA,we,wt]]
    if A%2==0:
        rels.append([0,0,0,1])
        if sec==1 and not det: rels.append([0,3,0,0])
    elif sec==1:
        rels.append([0,0,0,1])
        if not det:
            rels.append([0,3,omega^we,0])
    d=smith_normal_form(Matrix(rels), domain=ZZ)
    diag=sorted(abs(int(d[i,i])) for i in range(min(d.rows,d.cols)) if d[i,i] != 0)
    return tuple(x for x in diag if x>1)
for A in range(-15,16):
 for sec in (0,1):
  for det in (0,1):
   for omega in (0,1):
    for we in (0,1):
     for wt in (0,1):
      if A%2==0 and we!=0: continue  # even source normalization fixes the e coefficient
      iv=invariants(A,sec,det,omega,we,wt)
      if A%2==0:exp=(2,12) if (sec==0 or det) else (2,6)
      elif sec==0:exp=(2,2,12)
      elif det:exp=(2,12)
      else:exp=(12,) if omega else (2,6)
      check('Smith-presentations',f'A{A}-s{sec}-d{det}-o{omega}-e{we}-t{wt}',iv==exp,(iv,exp))

# Group law for cyclic vs split extension, associativity and group orders.
for omega in (0,1):
  def op(x,y):
   r=x[0]+y[0]
   return (r%6,(x[1]+y[1]+omega*(r//6))%2)
  U=list(itertools.product(range(6),range(2)))
  for a0 in U:
   check('odd-exotic-law',f'inverse-{omega}-{a0}',any(op(a0,b)==(0,0) and op(b,a0)==(0,0) for b in U))
  for a0,b0,c0 in itertools.product(U,U,U):
   check('odd-exotic-law',f'assoc-{omega}-{a0}-{b0}-{c0}',op(op(a0,b0),c0)==op(a0,op(b0,c0)))
  def mul(x,n):
   y=(0,0)
   for _ in range(n):y=op(y,x)
   return y
  order=lambda x: next(k for k in range(1,13) if mul(x,k)==(0,0))
  check('odd-exotic-law',f'ord-3b-{omega}',order(mul((1,0),3))==(4 if omega else 2))
  check('odd-exotic-law',f'ord-g-{omega}',order((1,0))==(12 if omega else 6))

# Actual relative sequence (RT.38.3), exactness of finite maps.
G=list(itertools.product(range(12),range(2)))
delta=lambda x: ((2*x[0])%12,x[1])
ker={x for x in G if delta(x)==(0,0)}
im={(6*s,0) for s in range(2)}
check('relative-C12-sequence','kernel-equals-image',ker==im,(ker,im))
imd={delta(x) for x in G}
kerlast={x for x in G if x[0]%2==0}
check('relative-C12-sequence','image-equals-next-kernel',imd==kerlast,(len(imd),len(kerlast)))
check('relative-C12-sequence','top-cokernel-C2',len(G)//len(imd)==2)
for z0 in range(6):
 for e0 in range(2):
  check('seven-skeleton',f'z{z0}e{e0}',(delta((z0,e0))==(0,0)) == (z0==0 and e0==0))
# H^*(S1 x S3 x RP3; F2): x^2=u^2=chi^4=0.
# beta4=u chi, xi_bar=p x chi^2; product=p x u chi^3.
for p in (0,1):
    beta={(0,1,1):1}
    xi={(1,0,2):p}
    product={}
    for (x,u,c),co in beta.items():
       for (xx,uu,cc),co2 in xi.items():
          ex=(x+xx,u+uu,c+cc)
          if ex[0]<2 and ex[1]<2 and ex[2]<4:
             product[ex]=(product.get(ex,0)+co*co2)%2
    check('relative-cup',f'p{p}',product.get((1,1,3),0)==p)

# RT.32.7 based contraction in unit quaternions and RT.30.4 equivariance.
def qmul(p,q):
 a,b,c,d=p; e,f,g,h=q
 return (a*e-b*f-c*g-d*h,a*f+b*e+c*h-d*g,a*g-b*h+c*e+d*f,a*h+b*g-c*f+d*e)
def qconj(q):return (q[0],-q[1],-q[2],-q[3])
def qinv(q):
 norm2=sum(x*x for x in q)
 return tuple(x/norm2 for x in qconj(q))
def qclose(q,r,tol=1e-11):return max(abs(a-b) for a,b in zip(q,r))<tol
ONE=(1,0,0,0);J=(0,0,1,0)
def cmv(m,v):
   em=(math.cos(m),math.sin(m),0,0)
   n=tuple(math.cos(v)*em[i]+math.sin(v)*J[i] for i in range(4))
   d=(math.cos(v),0,math.sin(v),0)
   return qmul(n,qinv(d))
for j,m in enumerate([0,math.pi/8,math.pi/3,math.pi,7*math.pi/4,2*math.pi]):
 for k,v in enumerate([0,math.pi/12,math.pi/4,math.pi/3,math.pi/2]):
    q=cmv(m,v)
    check('based-quaternion-loop',f'unit-{j}-{k}',abs(sum(x*x for x in q)-1)<1e-12,kind='NUMERICAL')
    check('based-quaternion-loop',f'period-{j}-{k}',qclose(q,cmv(m+2*math.pi,v)),kind='NUMERICAL')
    if v==0:check('based-quaternion-loop',f'v0-{j}',qclose(q,(math.cos(m),math.sin(m),0,0)),kind='NUMERICAL')
    if v==math.pi/2:check('based-quaternion-loop',f'vend-{j}',qclose(q,ONE),kind='NUMERICAL')
    if m==0:check('based-quaternion-loop',f'm0-{k}',qclose(q,ONE),kind='NUMERICAL')

def f_n(n):
   nlen2=sum(x*x for x in n)
   if nlen2<1e-20:return (-1,0,0,0)
   radius=math.sqrt(nlen2); theta=math.pi*(1-radius)
   if radius>=1:return ONE
   qi=qmul(qmul(n,(0,1,0,0)),qconj(n))
   return tuple((math.cos(theta) if k==0 else 0)+math.sin(theta)*qi[k]/nlen2 for k in range(4))
vs=[(1,0,0,0),(0,1,0,0),(0,0,1,0),(0.5,0.5,0.5,0.5)]
ns=[(r,a*r,0,0) for r in (0.1,0.3,0.5) for a in (0,0.5)]
ns+=[(0.15,0.2,0.1,0.1),(0.35,0.1,0.15,0.05)]
for idx,n in enumerate(ns):
  q=f_n(n);check('Hopf-suspension',f'unit-{idx}',abs(sum(x*x for x in q)-1)<1e-10,kind='NUMERICAL')
  check('Hopf-suspension',f'even-{idx}',qclose(q,f_n(tuple(-x for x in n))),kind='NUMERICAL')
  for vi,v in enumerate(vs):
    vr=qmul(qinv(v),n)  # exact source transformation v^-1 n, NOT conjugation
    equiv=qmul(qmul(qinv(v),q),v)
    check('Hopf-suspension',f'conjugation-{idx}-{vi}',qclose(f_n(vr),equiv),kind='NUMERICAL')
check('Hopf-suspension','center',qclose(f_n((0,0,0,0)),(-1,0,0,0)),kind='NUMERICAL')
check('Hopf-suspension','boundary',qclose(f_n((1,0,0,0)),ONE),kind='NUMERICAL')

# Explicit deformation retract of two distinct points on S3 to antipodal pair.
import random
rng=random.Random(7)
for i in range(30):
 y=[rng.gauss(0,1) for k in range(4)]; r=math.sqrt(sum(x*x for x in y));y=[x/r for x in y]
 yp=[rng.gauss(0,1) for k in range(4)]; r=math.sqrt(sum(x*x for x in yp));yp=[x/r for x in yp]
 m=[(y[k]+yp[k])/2 for k in range(4)];d=[(y[k]-yp[k])/2 for k in range(4)]
 dn=math.sqrt(sum(x*x for x in d))
 if dn<1e-10:continue
 for t0 in (0,0.2,0.4,0.7,1):
  mt=[(1-t0)*z for z in m];dnnew=math.sqrt(1-sum(z*z for z in mt));dt=[dnnew*z/dn for z in d]
  yt=[mt[k]+dt[k] for k in range(4)];ypt=[mt[k]-dt[k] for k in range(4)]
  check('coincident-circle-retraction',f'norm-y-{i}-{t0}',abs(sum(z*z for z in yt)-1)<1e-12,kind='NUMERICAL')
  check('coincident-circle-retraction',f'norm-yp-{i}-{t0}',abs(sum(z*z for z in ypt)-1)<1e-12,kind='NUMERICAL')
  check('coincident-circle-retraction',f'separation-{i}-{t0}',dnnew+1e-12>=dn,kind='NUMERICAL')
  if t0==1:check('coincident-circle-retraction',f'antipodal-{i}',max(abs(yt[k]+ypt[k]) for k in range(4))<1e-12,kind='NUMERICAL')

report={'artifact':'Paper1C-IndependentControlsBatch1Results-v1_1.json','paper':'Paper I-C','batch':1,
 'scope_census_zero_based':[0,49], 'date':'2026-11-13',
 'controls':RESULT,'total':len(RESULT),'passed':sum(r['passed'] for r in RESULT),
 'kind_counts':{k:sum(r['kind']==k for r in RESULT) for k in set(r['kind'] for r in RESULT)},
 'limitations':'Scoped controls; topology/bundle gauge existence, global stable homotopy and domain matching not independently proven by finite checks.'}
out=Path('/mnt/data/Paper1C-IndependentControlsBatch1Results-v1_1.json')
out.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
from collections import Counter
print('PASSED',report['passed'],'/',report['total'],'FAMILIES',Counter(r['family'] for r in RESULT),'KIND',report['kind_counts'])
