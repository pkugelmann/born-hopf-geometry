#!/usr/bin/env python3
"""Independent scoped controls for Paper I-C Batch 5 (census 150--159).
All tests use the source's stated formulas, not prior report expected values.
These algebraic, numerical, and group-theoretic checks are *not*
certificates of the full global homotopy or Steenrod-square evaluations.
"""
from __future__ import annotations
import json, numpy as np, sympy as S
from pathlib import Path

R=Path('/mnt/data'); rng=np.random.default_rng(2026111305); records=[]
def check(family,label,value,tol=2.e-11,scope='sampled matrix identity'):
    err=float(abs(value))
    records.append(dict(family=family,label=label,error=err,tolerance=tol,passed=bool(err<=tol),scope=scope))
    if err>tol: raise AssertionError(f'{family}/{label}: {err} > {tol}')
def dif(a,b): return np.linalg.norm(np.asarray(a)-np.asarray(b),ord=2)
def qmul(q,r):
    a,b,c,d=q; e,f,g,h=r
    return np.array([a*e-b*f-c*g-d*h, a*f+b*e+c*h-d*g,
                     a*g-b*h+c*e+d*f, a*h+b*g-c*f+d*e],dtype=float)
I=np.array([1.,0,0,0]); qi=np.array([0.,1,0,0]); qj=np.array([0.,0,1,0]);qk=np.array([0.,0,0,1])
def qcon(q):return np.array([q[0],-q[1],-q[2],-q[3]])
def qpow(q,n):
    res=I.copy()
    for _ in range(n):res=qmul(res,q)
    return res

def qexp_axis(phi,axis):
    axis=np.asarray(axis,float);axis=axis/np.linalg.norm(axis)
    return np.r_[np.cos(phi),np.sin(phi)*axis]
def qrandom():
    v=rng.normal(size=4);return v/np.linalg.norm(v)
def qmat(q):
    a,b,c,d=q
    return np.array([[a+1j*b,c+1j*d],[-c+1j*d,a-1j*b]],dtype=complex)
def qclose(q,r):return np.linalg.norm(q-r)
def qcomm(g,h):return qmul(qmul(qmul(qcon(g),qcon(h)),g),h)
def b(t,s,theta):
    ct=np.cos(np.pi*t/2); st=np.sin(np.pi*t/2)
    jtheta=np.r_[0.,0.,np.cos(theta),np.sin(theta)]
    return qmul(ct*qexp_axis(s,[1.,0,0])+st*jtheta,ct*I-st*jtheta)
def D(t,s,theta):return qmul(b(t,s,theta),qcon(b(t,s,0.)))
# OB.3: unit quaternion, theta deck via diag(1,-1), all based endpoints.
for k in range(55):
    t=float(rng.uniform(0,1));s=float(rng.uniform(0,2*np.pi));theta=float(rng.uniform(0,2*np.pi))
    u=b(t,s,theta)
    check('OB3-based-circle',f'unit-{k}',np.linalg.norm(u)-1)
    check('OB3-based-circle',f'deck-{k}',qclose(qmat(b(t,s,theta+np.pi)),np.diag([1,-1])@qmat(u)@np.diag([1,-1])))
    check('OB3-based-circle',f's0-{k}',qclose(b(t,0,theta),I))
    check('OB3-based-circle',f't0-{k}',qclose(b(0,s,theta),qexp_axis(s,[1,0,0])))
    check('OB3-based-circle',f't1-{k}',qclose(b(1,s,theta),I))
    check('OB3-based-circle',f'D-t0-{k}',qclose(D(0,s,theta),I))
    check('OB3-based-circle',f'D-t1-{k}',qclose(D(1,s,theta),I))
# OB.5 actual non-abelian seam: N1 ND^-1 = b0^-1 C(D,c) b0.
for k in range(100):
    t=float(rng.uniform(0,1));s=float(rng.uniform(0,2*np.pi));theta=float(rng.uniform(0,2*np.pi));c=qrandom()
    b1=b(t,s,theta);b0=b(t,s,0);N1=qcomm(b1,c);ND=qcomm(b0,c)
    lhs=qmul(N1,qcon(ND));rhs=qmul(qmul(qcon(b0),qcomm(D(t,s,theta),c)),b0)
    check('OB5-noncommutative-seam',f'seam-{k}',qclose(lhs,rhs))
# OB.8--10 conformal 3-sphere source map and its actual inverse.
def M(q):
    a=q[0];return np.r_[(1+3*a)/(3+a),2*np.sqrt(2)*q[1:]/(3+a)]
def Minv(q):
    a=q[0];return np.r_[(3*a-1)/(3-a),2*np.sqrt(2)*q[1:]/(3-a)]
def C2(y):
    A,B,C,DD=M(-y);radius=np.hypot(A,DD)
    if radius<1.e-12: alpha=0j
    else: alpha=(A-1j*DD)**2/radius
    beta=B+1j*C
    return np.array([[alpha,beta],[-np.conj(beta),np.conj(alpha)]])
for k in range(125):
    y=qrandom();z=M(y)
    check('OB8-map-inverse',f'unit-{k}',np.linalg.norm(z)-1)
    check('OB8-map-inverse',f'inverse-{k}',np.linalg.norm(Minv(z)-y))
    X=C2(y)
    check('OB8-map-inverse',f'SU2-{k}',dif(X.conj().T@X,np.eye(2)))
    check('OB8-map-inverse',f'det-{k}',abs(np.linalg.det(X)-1))
check('OB8-map-inverse','basepoint',dif(C2(I),np.eye(2)))
# OZ.3 and PB.3 are nontrivial word identities; order matters.
for k in range(150):
    a,b0=qrandom(),qrandom();w=qmul(qpow(a,2),qmul(qpow(b0,2),qcon(qpow(qmul(a,b0),2))))
    F=qmul(qpow(a,2),qmul(b0,qmul(qcon(a),qmul(qcon(b0),qcon(a)))))
    check('OZ3-root-power-word',f'full-{k}',qclose(w,F))
    check('OZ3-root-power-word',f'antidiagonal-{k}',qclose(qmul(qpow(a,2),qmul(qcon(a),qmul(qcon(a),I))),I))
    check('OZ3-root-power-word',f'wedge-a-{k}',qclose(qmul(qpow(I,2),qmul(b0,qmul(I,qmul(qcon(b0),I)))),I))
for k in range(130):
    a,hatb,L=qrandom(),qrandom(),qrandom();bb=qmul(L,hatb)
    def Fword(a,b0):return qmul(qpow(a,2),qmul(b0,qmul(qcon(a),qmul(qcon(b0),qcon(a)))))
    C=qmul(qmul(hatb,a),qcon(hatb))
    left=qmul(Fword(a,bb),qcon(Fword(a,hatb)))
    right=qmul(qpow(a,2),qmul(L,qmul(qcon(C),qmul(qcon(L),qmul(C,qcon(qpow(a,2)))))))
    check('PB3-free-group-word',f'full-{k}',qclose(left,right))
# OB.10: the displayed two inverse-image caps solve the same actual C2 target.
for k in range(70):
    beta=(rng.normal()+1j*rng.normal())*float(rng.uniform(.001,.012))
    phase=float(rng.uniform(-.012,.012))
    alpha=-np.sqrt(1-abs(beta)**2)*np.exp(1j*phase)
    target=np.array([[alpha,beta],[-np.conj(beta),np.conj(alpha)]],dtype=complex)
    angle=np.pi+np.angle(-alpha)
    cap=[]
    for sign in (1,-1):
        z=sign*abs(alpha)*np.exp(.5j*angle)
        AB=(z.real,beta.real,beta.imag,-z.imag)
        yp=-Minv(np.array(AB))
        cap.append(yp)
        check('OB10-two-cap-inversion',f'cap{sign}-{k}',dif(C2(yp),target))
    check('OB10-two-cap-inversion',f'separation-{k}',max(0,1.8-np.linalg.norm(cap[0]-cap[1])))
# PN.4--PN.5: the frame-axis change must retain its moving lower value.
for k in range(130):
    t=float(rng.uniform(0,1));ss=float(rng.uniform(0,2*np.pi));theta=float(rng.uniform(0,2*np.pi))
    kap=float(rng.uniform(0,2));cc=qrandom();Bth=b(t,ss,theta);Bk=b(t,ss,kap*np.pi);B0=b(t,ss,0.)
    Dk=qmul(Bth,qcon(Bk));ek=qmul(B0,qcon(Bk));D0=qmul(Bth,qcon(B0))
    check('PN4-PN5-moving-lower',f'lower-{k}',qclose(qmul(Dk,qcon(ek)),D0))
    lhs=qmul(qcomm(Dk,cc),qcon(qcomm(ek,cc)))
    rhs=qmul(qmul(qcon(ek),qcomm(D0,cc)),ek)
    check('PN4-PN5-moving-lower',f'conjugation-{k}',qclose(lhs,rhs))
# OY.3 2nd/3rd pinch compatibility, using nonabelian based f(z).
def fbox(z):
    z=np.asarray(z); rad=max(0.,1.-float(z@z));
    theta=.83*rad*(.3*z[0]- .18*z[1]+.14*z[4]+.07)
    axis=np.array([.1+z[1],.2+z[3],.3+z[4]])
    return qexp_axis(theta,axis)
def z_from_interval(aperp,bs,u):
    ell=np.sqrt(max(0,1-np.sum(aperp**2)-np.sum(bs**2)))
    return np.r_[ell*(2*u-1),aperp,bs]
def pinch2(h,u,aperp,bs):
    t1=(1-h)*u+h*min(2*u,1)
    t2=1-(1-h)*u-h*max(2*u-1,0)
    return qmul(qcon(fbox(z_from_interval(aperp,bs,t1))),qcon(fbox(z_from_interval(aperp,bs,t2))))
def pinch3(h,u,aperp,bs):
    t=(1-h)*min(2*u,2-2*u)
    return qcon(fbox(z_from_interval(aperp,bs,t)))
for k in range(165):
    ww=rng.normal(size=5);ww*=.62/max(1.,np.linalg.norm(ww));ap,bs=ww[:2],ww[2:];u=float(rng.uniform(0,1))
    z=z_from_interval(ap,bs,u);zr=z_from_interval(ap,bs,1-u)
    check('OY3-pinching',f'start-{k}',qclose(pinch2(0,u,ap,bs),qmul(qcon(fbox(z)),qcon(fbox(zr)))))
    check('OY3-pinching',f'seam-{k}',qclose(pinch2(1,u,ap,bs),pinch3(0,u,ap,bs)))
    check('OY3-pinching',f'end-{k}',qclose(pinch3(1,u,ap,bs),I))
# OY.6 square-sweep seam and edge checks. F(ρ,λ) genuinely noncommutes across parameters.
def Fsq(rho,lam):return qmul(qexp_axis(.3*(1-lam)*(1-rho),[1,0,0]),qexp_axis(.45*(1-lam)*rho,[0,1,0]))
def sweep(u,h):
    if u<=1/3:r,l=1.,3*h*u
    elif u<=2/3:r,l=2-3*u,h
    else:r,l=0.,3*h*(1-u)
    return r,l
for k in range(135):
    u=float(rng.uniform(0,1));h=float(rng.uniform(0,1));r,l=sweep(u,h)
    check('OY6-square-sweep',f'range-{k}',max(0,-r,r-1,-l,l-1))
    if u<=1/3:r0=1.
    elif u<=2/3:r0=2-3*u
    else:r0=0.
    check('OY6-square-sweep',f'bottom-{k}',np.linalg.norm(Fsq(*sweep(u,0.))-Fsq(r0,0)))
for h in np.linspace(0,1,27):
    check('OY6-square-sweep',f'seam1-{h:.3f}',dif(qmat(Fsq(*sweep(1/3-1e-12,h))),qmat(Fsq(*sweep(1/3+1e-12,h)))))
    check('OY6-square-sweep',f'seam2-{h:.3f}',dif(qmat(Fsq(*sweep(2/3-1e-12,h))),qmat(Fsq(*sweep(2/3+1e-12,h)))))
for u in np.linspace(0,1,51):
    r,l=sweep(u,1)
    if u<=1/3:expected=Fsq(1,3*u)
    elif u<=2/3:expected=Fsq(2-3*u,1)
    else:expected=Fsq(0,3*(1-u))
    check('OY6-square-sweep',f'top-{u:.3f}',np.linalg.norm(Fsq(r,l)-expected))
# PF.4: sewn two-cut midpoint for random noncommuting f and sigma f.
def qt(t):return qexp_axis(np.pi*t,[1,0,0])
def lin_path(start,t):
    if abs(start[0]+1)<1e-12:return qmul(start,qexp_axis(np.pi*t,[1,0,0]))
    phi=np.arccos(np.clip(start[0],-1,1));v=start[1:];
    return qexp_axis(phi*(1-t),v if np.linalg.norm(v)>1e-11 else [1,0,0])
for k in range(90):
    f=qrandom();fs=qrandom();kfirst0=f; ksecond0=fs
    # Source-required endpoints k(t=0)=f, k(t=1)=-I and k^σ likewise.
    z0=qmul(qcon(f),qcon(fs));qfirstend=-I;qsecondend=-I
    first_mid=qmul(qmul(qcon(qt(1.)),qfirstend),qcon(f))
    second_mid=qmul(z0,fs)
    second_final=qmul(qcon(qt(1.)),qsecondend)
    check('PF4-sewn-midpoint',f'mid-{k}',qclose(first_mid,second_mid))
    check('PF4-sewn-midpoint',f'firststart-{k}',qclose(qmul(kfirst0,qcon(f)),I))
    check('PF4-sewn-midpoint',f'secondend-{k}',qclose(second_final,I))
# FP.1 and v263 lemma homotopy-group arithmetic, exact mod 12 / mod 2.
for k in range(12):
    n=(2*k)%12
    if n in (0,6):
        ep=int(n==6)
        check('V263-mod12-carry',f'bridge-{k}',abs((k%2)-ep),tol=0,scope='exact modular computation')
    check('V263-mod12-carry',f'twice-order2-{k}',(2*(k%2))%2,tol=0,scope='exact modular computation')
# SC.5 and SC.8: actual noncommutative lower/second-cut words, with q_t in U(2).
def Su2():return qmat(qrandom())
for k in range(180):
    t=float(rng.uniform(0,1));U,V,Z,Dmat=Su2(),Su2(),Su2(),Su2()
    qtU=np.diag([np.exp(2j*np.pi*t),1.])
    def Pu(X):return qtU.conj().T@X@qtU@X.conj().T
    lhs=Pu(U@V)
    rhs=Pu(U)@U@Pu(V)@U.conj().T
    check('SC5-noncommutative-cocycle',f'cocycle-{k}',dif(lhs,rhs))
    G=U;B=V
    target=Pu(G)@(G@Pu(B)@G.conj().T)@np.linalg.inv(Pu(B))
    # actual P(G B) / P(B) equals RHS of SC.5 after lower division.
    check('SC5-noncommutative-cocycle',f'lower-{k}',dif(Pu(G@B)@Pu(B).conj().T,target))
    M0=qtU.conj().T@Dmat
    Mnew=qtU.conj().T@Z@Dmat@Z.conj().T
    lhs2=Mnew@M0.conj().T
    rhs2=Pu(Z)@(Z@M0@Z.conj().T@M0.conj().T)
    check('SC8-second-cut',f'full-{k}',dif(lhs2,rhs2))
for k in range(120):
    U,W=Su2(),Su2();t=float(rng.uniform(0,1))
    def Q(word1,word2):return word1@word2@word1.conj().T@word2.conj().T
    Pt=Pu(W)
    check('SC10-smash-faces',f't0-{k}',dif(Q(U,np.eye(2)),np.eye(2)))
    check('SC10-smash-faces',f'u1-{k}',dif(Q(np.eye(2),Pt),np.eye(2)))
for n in range(-60,61):
    check('SC12-even-degree',f'n-{n}',(2*n)%2,tol=0,scope='exact parity/cup-product computation')
# AJ.6: fourteen source-scoped combinations (4+4+2+4) and exact ordinal tests.
rows=[]
for typ in ['D','S']:
 for e0 in (0,1):
  for t0 in (0,1):
   rows.append((f'{typ}_{e0},{t0}',(e0==0 and t0==1)))
for t0 in (0,1):rows.append((f'C_{t0}',t0==0))
for d0 in (0,1):
 for p0 in (0,1):rows.append((f'B_{d0},{p0}',d0==p0==0))
check('AJ6-extension-ledger','14-entries',abs(len(rows)-14),tol=0,scope='exact domain enumeration')
check('AJ6-extension-ledger','4-yes',abs(sum(int(ok) for _,ok in rows)-4),tol=0,scope='exact domain enumeration')
expected={'D_0,1','S_0,1','C_0','B_0,0'}
for name,v in rows:check('AJ6-extension-ledger',name,int(bool(v)!=(name in expected)),tol=0,scope='exact predicate evaluation')
check('AJ5-coefficients','Z',((1)%2)-1,tol=0,scope='exact C2 coefficient')
check('AJ5-coefficients','rJ',(1+1)%2,tol=0,scope='exact C2 coefficient')
check('AJ5-coefficients','ht',((1+1+1)%2)-1,tol=0,scope='exact C2 coefficient')
check('AJ5-coefficients','zeta',(1+1)%2,tol=0,scope='exact C2 coefficient')
# Exact symbolic source normalizations used in OB and PF.
x=S.symbols('x',real=True)
y=(1+3*x)/(3+x)
check('OB-M-symbolic','inverse-function',(0 if S.simplify((3*y-1)/(3-y)-x)==0 else 1),tol=0,scope='exact symbolic identity')
check('PF-composition','six-mu-zero',(6%2),tol=0,scope='exact modular computation')
check('PF-composition','mu-minus-mu',(1-1)%2,tol=0,scope='exact modular computation')
check('PF-composition','mu-plus-mu',(1+1)%2,tol=0,scope='exact modular computation')
fails=[v for v in records if not v['passed']]
from collections import Counter
summary=dict(Counter(v['family'] for v in records))
out=dict(artifact='Paper1C-IndependentControlsBatch5Results-v1_1.json',source='Paper1C-TechnicalMaterial-v1_59.tex',census_zero_based=[150,159],
         total=len(records),passed=len(records)-len(fails),failed=len(fails),seed=2026111305,
         test_families=summary,limitations=[
         'Finite matrix and sampled source identities do not prove global relative nullhomotopy in the actual ordering-line gauge bundle.',
         'OY square sweep is checked at interfaces; source-specific F(B_rho) and all global cap source identifications are not independently reconstructed.',
         'PF Steenrod-square/evaluation, PG source-specific Toda comparison, SC global gauge degree and AJ paired-bigon topological class remain source-proof dependent, not numerically certified.',
         'Full extended proof regions were inspected against the source; a test count is not a theorem count.'
         ],records=records)
p=R/out['artifact'];p.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='records'},indent=2))
