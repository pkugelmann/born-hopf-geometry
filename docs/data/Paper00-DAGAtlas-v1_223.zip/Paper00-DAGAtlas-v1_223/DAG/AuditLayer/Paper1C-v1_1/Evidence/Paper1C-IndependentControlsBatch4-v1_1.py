#!/usr/bin/env python3
"""Independent scoped checks of Paper I-C census 136–149, current v1_59 source.

Tests only the displayed local/finite equations, seam and endpoint formulas.
A passing suite is NOT an independent proof of global G2/Spin7 horizontal
transport, full source homotopies, interval certificate NZ.4, or bundle
classification. All numerical tests state their tolerance and sample count.
"""
import json, math, hashlib
from pathlib import Path
from collections import Counter
import numpy as np

OUT = Path('/mnt/data')
RNG = np.random.default_rng(20261113_04)
REC = []
def record(group, item, actual, target=None, atol=1e-8, *, kind='NUMERICAL', note=''):
    if target is None: ok = bool(actual); err=None
    else:
        err=float(np.max(np.abs(np.asarray(actual)-np.asarray(target))))
        ok=bool(np.isfinite(err) and err<=atol)
    REC.append({'family':group,'test':item,'status':'PASS' if ok else 'FAIL','kind':kind,
                'tolerance':None if target is None else float(atol), 'max_error':err,'scope':note})
    if not ok: raise AssertionError(f'{group}/{item}: err {err}; a={str(actual)[:200]}, b={str(target)[:200]}')

def qmul(p,q):
    a=p[0]; b=q[0]; x=p[1:]; y=q[1:]
    return np.r_[a*b-x@y, a*y+b*x+np.cross(x,y)]
def qc(q): return np.r_[q[0],-q[1:]]
def qinv(q): return qc(q)/np.dot(q,q)
def qunit():
    x=RNG.normal(size=4);return x/np.linalg.norm(x)
def qexp(v):
    t=np.linalg.norm(v)
    return np.r_[np.cos(t),np.sin(t)*v/t if t>1e-13 else v]
def qlog(q):
    n=np.linalg.norm(q[1:]);return q[1:]*math.atan2(n,q[0])/n if n>1e-13 else q[1:]
def qdist(a,b): return math.atan2(np.linalg.norm(qmul(qinv(a),b)[1:]),qmul(qinv(a),b)[0])
def qpow(q,n):
    z=np.array([1.,0,0,0]);a=q.copy()
    for _ in range(n): z=qmul(z,a)
    return z
ONE=np.array([1.,0,0,0]);ZERO=np.zeros(4)
qi=np.array([0.,1,0,0]);qj=np.array([0.,0,1,0]);qk=np.array([0.,0,0,1.])
def quatmatmul(A,B):
    return [[sum((qmul(A[i][k],B[k][j]) for k in range(len(B))),ZERO.copy())
             for j in range(len(B[0]))] for i in range(len(A))]
def quatadj(A): return [[qc(A[j][i]) for j in range(len(A))] for i in range(len(A[0]))]

# Input S^3 section and exact SU(3) point-to-point transporter from I-C RT.58.
Id3=np.eye(3,dtype=complex);e1=np.r_[1.,0,0].astype(complex);e2=np.r_[0.,1,0].astype(complex)
J=np.diag([1,1,-1]);
def proj(x):return np.outer(x,np.conj(x))
def sec(x,p):
    ax=1-x[0];ap=1-p[0]
    if abs(ax)<1e-12 or abs(ap)<1e-12:return e1.copy()
    K=2*ax+2*ap-ax*ap
    u0=1-2*ax*ap/K
    ux=2*ap*x[1:]/K;up=2*ax*p[1:]/K
    ua=(ux+up)/np.sqrt(2);ub=(ux-up)/np.sqrt(2)
    z0=u0+1j*ub[1];z1=ua[2]+1j*ub[2];r=math.sqrt(abs(z0)**2+abs(z1)**2)
    h=np.zeros(3) if r<1e-13 else np.array([2*(z0*np.conj(z1)).real,2*(z0*np.conj(z1)).imag,abs(z0)**2-abs(z1)**2])/r
    return np.array([h[2]+1j*h[0],ua[0]+1j*ua[1],ub[0]+1j*h[1]])
def trans(a,b):
    c=np.vdot(a,b)
    if abs(1+c)<1e-9:raise ValueError('antipodal transporter')
    w=b-c*a;alpha=(1+c)/(1+np.conj(c));d=(1+np.conj(c))/abs(1+c)
    U=Id3+(c-1)*proj(a)+np.outer(w,a.conj())-alpha*np.outer(a,w.conj())-np.outer(w,w.conj())/(1+np.conj(c))
    return (proj(b)+d*(Id3-proj(b)))@U

def invst(X):
    n=X@X
    return np.r_[(n-1)/(n+1),2*X/(n+1)]
def st(q):return q[1:]/(1-q[0])
def phi(mu,q):
    if q[0]>1-1e-13:return ONE.copy()
    return invst(st(q)-mu*np.array([1.,0,0]))
def smu(x,p,mu):return sec(phi(-mu,x),phi(-mu,p))
def utransport(x,p,mu):
    a=sec(x,p);U=Id3.copy();t=0.
    while t+1e-12 < mu:
        t1=min(mu,t+1/16)
        b=smu(x,p,t1);U=trans(a,b)@U;a=b;t=t1
    return U

def cutmu(x,p):
    d=qdist(x,p)
    if d<=1/3:return 32.
    if d>=2/3:return 0.
    v=3*d-1;return 32*(1-3*v*v+2*v*v*v)

# NT.1–NT.9: cap localization, based isotopy and actual shifted singular circle.
rb=1/6
for i in range(15):
    x=qunit();p=qunit();mu=(i+1)/16
    U=utransport(x,p,mu)
    record('NT-transport',f'unitarity-{i}',U.conj().T@U,Id3,kind='NUMERICAL')
    record('NT-transport',f'determinant-{i}',np.linalg.det(U),1.,kind='NUMERICAL')
    record('NT-transport',f'column-{i}',U@sec(x,p),smu(x,p,mu))
    record('NT-transport',f'exchange-{i}',utransport(p,x,mu),J@U@J)
for i in range(17):
    ang=2*np.pi*i/17
    y=np.array([-1/3,(2*np.sqrt(2)/3)*np.cos(ang),(2*np.sqrt(2)/3)*np.sin(ang),0.])
    x=phi(32,y)
    record('NT-singular',f'shifted-circle-{i}',np.linalg.norm((Id3-proj(smu(x,x,32)))@e2),0.,atol=2e-9)
    record('NT-singular',f'cutoff-{i}',cutmu(x,x),32.,atol=0)
    record('NT-singular',f'round-ball-{i}',np.sqrt(2)*2*np.arctan(1/(32-1/np.sqrt(2)))<rb)
    record('NT-singular',f'actual-distance-{i}',np.sqrt(2)*math.acos(x[0])<rb)
for i in range(32):
    dx=RNG.normal(size=3);dp=RNG.normal(size=3)
    r=math.sqrt(dx@dx+dp@dp)
    dx=dx/r*(RNG.random()*rb*.99);dp=dp/r*(RNG.random()*rb*.99)
    x=qexp(dx);p=qexp(dp)
    record('NT-localization',f'ball-is-32-{i}',cutmu(x,p),32.,atol=0)
    record('NT-localization',f'within-1/3-{i}',qdist(x,p)<1/3)

# NU.1–NU.4 and NW.4, NW.9–NW.11: actual side/top frame arithmetic.
M=np.array([[0,1j],[1j,0]],complex)
Id2=np.eye(2, dtype=complex)
def asu(t):return np.diag([np.exp(1j*np.pi*t),np.exp(-1j*np.pi*t)])
def su2(q):
    a,b,c,d=q
    return np.array([[a+1j*b,c+1j*d],[-c+1j*d,a-1j*b]],complex)
def sg(t,g):return g@asu(t)@g.conj().T@asu(t).conj().T
def g0(t,r,g):return sg(1-(1-t)*r,g)
def phib(y,z):
    th=(np.pi/2)*(y+1)
    if np.linalg.norm(z)<1e-13: return math.cos(th)*Id2
    P=proj(z)/(np.vdot(z,z).real)
    return math.cos(th)*Id2+1j*math.sin(th)*(2*P-Id2)
for i in range(40):
    g=su2(qunit());r=RNG.uniform(.002,.998);t=RNG.random();v=g@np.array([1,0],complex)
    y=1-2*r;z=2*np.sqrt(r*(1-r))*M@v
    E0=M.conj().T@phib(y,z)@asu(1-r)@M
    E1=M.conj().T@phib(y,z)@M
    record('NU-side-top',f'side-{i}',g0(t,1,g)@asu(t),g@asu(t)@g.conj().T)
    record('NU-side-top',f'top-{i}',g0(1,r,g),Id2)
    record('NU-side-top',f'center-{i}',g0(t,0,g),Id2)
    record('NU-side-top',f'initial-Eg-{i}',g0(0,r,g),sg(1-r,g))
    record('NU-side-top',f'norm-bound-{i}',np.linalg.norm(g0(t,r,g)-Id2,ord=2)<=2*np.pi*(1-t)*r+1e-11)
    record('NW-characteristic',f'map-unit-{i}',np.vdot(z,z).real+y*y,1.)
    record('NW-characteristic',f'phi-ident-{i}',phib(y,z),M@g@asu(1-r)@g.conj().T@M.conj().T)
    record('NW-characteristic',f'E0-{i}',E0,sg(1-r,g))
    record('NW-characteristic',f'E1-{i}',E1,M.conj().T@phib(y,z)@M)
    record('NW-characteristic',f'south-{i}',phib(-1,np.array([0j,0j])),Id2)

# NU.5–NU.8: source S^6 collapse and applied based normalization.
def s6data(a,b):
    p=qlog(-b)/np.pi
    u=a*np.sqrt(max(0.,1-np.dot(p,p)))
    return p,u
def fcollapse(p,u,l):
    R=u[0]
    Rp=min(1.,R+l*(1+R))
    c=math.sqrt(max(0,1-Rp*Rp)/(1-R*R)) if abs(R)<1-1e-12 else 0
    return c*p,np.r_[Rp,c*u[1:]]
def exp_pi(p):return qexp(np.pi*p)
def comm(a,b):return qmul(qmul(qmul(a,b),qinv(a)),qinv(b))
def Tsource(p,u,l):
    a=u/np.linalg.norm(u)
    v0=qmul(qmul(a,exp_pi(p)),qinv(a))
    mid=qexp(-(1-l)*np.pi*p+l*np.pi*np.array([1.,0,0]))
    return qmul(qmul(v0,mid),qexp(-l*np.pi*np.array([1.,0,0])))
for i in range(60):
    a=qunit();b=qunit();p,u=s6data(a,b);l=RNG.random();p1,u1=fcollapse(p,u,l)
    record('NU-bottom',f'S6-original-{i}',np.dot(p,p)+np.dot(u,u),1.)
    record('NU-bottom',f'S6-collapse-{i}',np.dot(p1,p1)+np.dot(u1,u1),1.)
    if np.linalg.norm(u)>1e-8:
        record('NU-bottom',f'comm-start-{i}',comm(a,b),Tsource(p,u,0.))
        record('NU-bottom',f'T-end-{i}',Tsource(p,u,1.),qmul(qmul(a,exp_pi(p)),qinv(a)))
        record('NU-bottom',f'T-unit-{i}',np.linalg.norm(Tsource(p,u,l)),1.)
    record('NU-bottom',f'f0-{i}',fcollapse(p,u,0)[0],p)
    if u[0]>=0:
        pF,uF=fcollapse(p,u,1)
        record('NU-bottom',f'upper-disk-pole-{i}',np.r_[pF,uF],np.r_[np.zeros(3),1.,0,0,0])

# NV.1–NV.6: independent sampled horizontal lifts and pole/edge controls.
def hopf(z):
    a,b=z;L=np.linalg.norm(z)
    h1=np.array([abs(a)**2-abs(b)**2,2*(np.conj(a)*b).real,2*(np.conj(a)*b).imag])/L
    h2=np.array([-2*(a*b).real,(np.conj(a)**2-b*b).real,(np.conj(a)**2-b*b).imag])/L
    return h1,h2
def first_stage(t,v,theta):
    c=math.cos(2*t);s=math.sin(2*t);k=abs(s);d=s*v[0]
    z=np.array([v[3]+1j*v[4],v[1]+1j*v[2]])
    normz=np.linalg.norm(z);R=k*normz;L=math.sqrt(c*c+d*d)
    e1_,e2_=hopf(z);e1_/=normz;e2_/=normz
    e=math.cos(theta)*e1_+math.sin(theta)*e2_
    T=-math.sin(theta)*e1_+math.cos(theta)*e2_
    sc=math.sin(L*theta)/L if L>1e-12 else theta
    return np.r_[c,d,R*e],np.r_[d-R*R*c*sc,-c-R*R*d*sc,R*math.cos(L*theta)*T+R*L*math.sin(L*theta)*e]
for i in range(52):
    t=RNG.uniform(math.pi/2+0.15,math.pi-0.15)
    v=RNG.normal(size=5);v/=np.linalg.norm(v);th=RNG.uniform(.1,math.pi-.1);dt=1e-6
    z=np.array([v[3]+1j*v[4],v[1]+1j*v[2]]);a,b=hopf(z)
    record('NV-Hopf',f'norm-h1-{i}',np.linalg.norm(a),np.linalg.norm(z))
    record('NV-Hopf',f'norm-h2-{i}',np.linalg.norm(b),np.linalg.norm(z))
    record('NV-Hopf',f'perp-{i}',a@b,0.)
    gamma,delta=first_stage(t,v,th)
    gp,dp=first_stage(t,v,th+dt);gm,dm=first_stage(t,v,th-dt)
    gdot=(gp-gm)/(2*dt);ddot=(dp-dm)/(2*dt)
    record('NV-horizontal',f'norm-g-{i}',gamma@gamma,1.)
    record('NV-horizontal',f'norm-d-{i}',delta@delta,1.)
    record('NV-horizontal',f'orth-{i}',gamma@delta,0.)
    record('NV-horizontal',f'horizontal-{i}',ddot,-(delta@gdot)*gamma,atol=3e-8)

# NV.10–NV.11: exact norm and oriented source-permutation controls.
for i in range(40):
    x=RNG.normal(size=8);x/=np.linalg.norm(x)
    w=x[6:];th=RNG.uniform(.05,math.pi/2);c=math.cos(th);s=math.sin(th)
    A=s*s+x[0]*c*c;B=(1-x[0])*c*s
    v=np.r_[x[0]**2-np.dot(x[1:6],x[1:6])-np.dot(w,w)*c*c,
            2*x[0]*x[1:6],2*(w[0]*A-w[1]*B),2*(w[1]*A+w[0]*B)]
    record('NV-double-suspension',f'norm-{i}',np.linalg.norm(v),1+np.dot(w,w)*s*s)
    record('NV-double-suspension',f'nonzero-{i}',np.linalg.norm(v)>0)
    x5=RNG.normal(size=6);x5/=np.linalg.norm(x5)
    f5=x5[[4,5,2,3,0,1]]
    record('NV-rotations',f'f5-norm-{i}',f5@f5,1.)
    y5=RNG.normal(size=5);y5/=np.linalg.norm(y5)
    f6=y5[[3,4,0,1,2]]
    record('NV-rotations',f'f6-norm-{i}',f6@f6,1.)

# NY.1–NY.10 quaternionic alternative and explicit normalized nullhomotopy.
def ny(x):
    a,b,x2,x3,x4,x5=x
    L=math.sqrt(x2*x2+x3*x3+x4*x4+x5*x5)
    q=np.array([x4,-x5,-x3,x2])/L
    e1_=qmul(qmul(q,qi),qinv(q));e2_=qmul(qmul(q,qj),qinv(q))
    u=np.r_[b,L*e1_[1:]]
    q2=(np.r_[2*a,0,0,0]-qmul(qmul(qc(u),qi),u))/(1+a*a)
    k=np.r_[2*L*L-1.,0.,0.,0.]+2*L*qmul(qmul(q,np.r_[0,-b,a,0]),qinv(q))
    tau=-qmul(k,qinv(q2))
    return L,q,e1_,e2_,u,q2,k,tau

def nyR(r,u):
    fac=qmul(ONE+r,qinv(ONE+qc(r)))
    return [[r,-qmul(fac,qc(u))],
            [u,ONE-qmul(qmul(u,qinv(ONE+qc(r))),qc(u))]]
for i in range(65):
    x=RNG.normal(size=6);x/=np.linalg.norm(x)
    if x[2:]@x[2:]<1e-6:continue
    a,b=x[:2];L,q,e1_,e2_,u,q2,k,tau=ny(x)
    record('NY-quaternion',f'unit-e1-{i}',e1_@e1_,1.)
    record('NY-quaternion',f'unit-e2-{i}',e2_@e2_,1.)
    record('NY-quaternion',f'perp-{i}',e1_@e2_,0.)
    record('NY-quaternion',f'q2-unit-{i}',q2@q2,1.)
    record('NY-quaternion',f'k-unit-{i}',k@k,1.)
    record('NY-quaternion',f'tau-unit-{i}',tau@tau,1.)
    c=2*a*a-1.;d=2*a*b;r=2*abs(a)*L
    record('NY-frame',f'frame-normal-{i}',c*c+d*d+r*r,1.)
    record('NY-frame',f'u-norm-{i}',u@u,1-a*a)
    rv=RNG.random();realpart=RNG.uniform(0,1);r0=qunit();r0[0]=abs(r0[0]);
    norm_r=RNG.uniform(.1,.99);r0=r0*norm_r
    U=qunit()*math.sqrt(1-r0@r0)
    T=nyR(r0,U);TT=quatmatmul(quatadj(T),T)
    record('NY-R',f'first-r-{i}',T[0][0],r0)
    record('NY-R',f'first-U-{i}',T[1][0],U)
    for a_ in range(2):
        for b_ in range(2):
            record('NY-R',f'unit-{i}-{a_}-{b_}',TT[a_][b_],ONE if a_==b_ else ZERO,atol=2e-10)
    R=math.sqrt(a*a+b*b)
    if R>1e-8 and L>1e-8:
        n=np.r_[0.,-b,a,0.]/R
        for j,th in enumerate([0.,.36,math.pi/2]):
            axis=math.cos(th)*n+math.sin(th)*qk
            K=np.r_[2*L*L-1,0.,0,0]+2*L*R*qmul(qmul(q,axis),qinv(q))
            record('NY-nullhomotopy',f'first-unit-{i}-{j}',K@K,1.)
        for j,f in enumerate([0.,.2,.85,1.]):
            l=(1-f)*L
            K=np.r_[2*l*l-1.,0,0,0]+2*l*math.sqrt(1-l*l)*qmul(qmul(q,qk),qinv(q))
            record('NY-nullhomotopy',f'second-unit-{i}-{j}',K@K,1.)
            if f==1:record('NY-nullhomotopy',f'endminus-{i}',K,-ONE)


# NY.4–NY.7: noncommutative pointwise frame endpoint, including q2/k.
for i in range(58):
    x=RNG.normal(size=6);x/=np.linalg.norm(x)
    L,q,e1_,e2_,u,q2,k,tau=ny(x);a,b=x[:2]
    E=[[qi,ZERO.copy()],[ZERO.copy(),ONE.copy()]]
    Ed=quatadj(E)
    v=[np.r_[a,0.,0.,0.],qc(u)]
    rv=[qmul(Ed[row][0],v[0])+qmul(Ed[row][1],v[1]) for row in range(2)]
    A0=quatmatmul(quatmatmul(E,nyR(rv[0],rv[1])),Ed)
    F=[[np.r_[a,0.,0.,0.],-u],[qc(u),np.r_[a,0.,0.,0.]]]
    left=quatmatmul(quatadj(A0),F)
    record('NY-endpoint',f'NY7-diag-i-{i}',left[0][0],qi)
    record('NY-endpoint',f'NY7-diag-q2-{i}',left[1][1],q2)
    record('NY-endpoint',f'NY7-offdiag01-{i}',left[0][1],ZERO)
    record('NY-endpoint',f'NY7-offdiag10-{i}',left[1][0],ZERO)
    d=2*a*b; r=2*a*L; c=2*a*a-1
    w=np.r_[1-2*a*a,r*e2_[1:]]
    gam=[[np.r_[d,0.,0.,0.],w],[qc(w),np.r_[-d,0.,0.,0.]]]
    test=quatmatmul(quatmatmul(quatadj(F),gam),F)
    record('NY-endpoint',f'NY7-Gamma-d0-{i}',test[0][0],ZERO)
    record('NY-endpoint',f'NY7-Gamma-d1-{i}',test[1][1],ZERO)
    record('NY-endpoint',f'NY7-Gamma-k-{i}',test[0][1],k)
    record('NY-endpoint',f'NY7-Gamma-kstar-{i}',test[1][0],qc(k))

# NZ.14: trace-free skew-Hermitian gauge for S^5 unit section and tangent derivative.
for i in range(70):
    s=RNG.normal(size=3)+1j*RNG.normal(size=3);s/=np.linalg.norm(s)
    v=RNG.normal(size=3)+1j*RNG.normal(size=3)
    v=v-s*(np.vdot(s,v).real)
    alpha=np.vdot(s,v)
    A=np.outer(v,s.conj())-np.outer(s,v.conj())-alpha/2*(Id3+proj(s))
    record('NZ-SU3-connection',f'skew-{i}',A.conj().T,-A)
    record('NZ-SU3-connection',f'trace-{i}',np.trace(A),0.)
    record('NZ-SU3-connection',f'As-dot-{i}',A@s,v)
    record('NZ-SU3-connection',f'unit-tangent-{i}',np.vdot(s,v).real,0.)

# NZ.18: a strong retraction onto antipodal wedge, never decreasing pair distance.
for i in range(50):
    x=qunit();p=qunit();ax=math.acos(np.clip(x[0],-1,1));ap=math.acos(np.clip(p[0],-1,1))
    m=max(ax,ap);t=RNG.random();fac=1-t+t*math.pi/m
    record('NZ-wedge-retraction',f'angular-progress-{i}',max(fac*ax,fac*ap)>=m-1e-11)
    record('NZ-wedge-retraction',f'range-{i}',fac*m<=math.pi+1e-10)
    record('NZ-wedge-retraction',f'endpoint-{i}',math.isclose(max(math.pi*ax/m,math.pi*ap/m),math.pi,abs_tol=1e-10))


# NZ.1, NZ.3, NZ.10: independent orthogonality/orientation certificate and
# local inverse derivative. The full NZ.4 interval Hessian bounds are NOT tested.
import sympy as SP
rr=SP.sqrt(2)
Amat=SP.Matrix([[0,0,0,-1,0,0],[0,0,0,0,0,-1],[0,0,0,0,1,0],
                [1,0,0,0,0,0],[0,1,0,0,0,0],[0,0,-1,0,0,0]])
Bmat=SP.Matrix([[1/rr,0,0,-1/rr,0,0],
 [0,0,0,0,1/rr,1/rr],[0,1/rr,1/rr,0,0,0],
 [-1/rr,0,0,-1/rr,0,0],[0,0,0,0,-1/rr,1/rr],[0,1/rr,-1/rr,0,0,0]])
Ri=SP.Matrix([[-1,0,0],[0,-SP.Rational(1,3),-2*rr/3],[0,2*rr/3,-SP.Rational(1,3)]])
Oi=SP.diag(Ri,Ri)*Bmat
for name,mat,det in [('A',Amat,-1),('B6',Bmat,-1),('R_i',Ri,-1),('O_kappa',Oi,-1)]:
    record('NZ-exact-frames',name+'-orthogonal',mat.T*mat==SP.eye(mat.rows),kind='EXACT')
    record('NZ-exact-frames',name+'-det',mat.det().simplify()==det,kind='EXACT')
record('NZ-exact-frames','G2-dim-fibre',14-11==3,kind='EXACT')

def emu_inverse(y):
    delta=1/12
    theta=np.linalg.norm(y); vv=y*(math.sin(theta)/theta if theta>1e-12 else 1.)
    cc=math.cos(theta/2);fac=math.sqrt(1+cc*cc)/(2*cc)
    pp=fac*np.array([-vv[0],-vv[2],vv[1]])
    uu=np.r_[-cc*cc,fac*np.array([-vv[3],-vv[4],vv[5]])]
    aa=uu/math.sqrt(1-pp@pp)
    pn=np.linalg.norm(pp)
    bb=-np.r_[math.cos(np.pi*pn),pp*(math.sin(np.pi*pn)/pn if pn>1e-12 else np.pi)]
    bp=bb*np.r_[1,1,-1,-1]
    def ii(q):
        xx=-q[1:]/(1-q[0]);return 2*delta*delta*xx/(1+math.sqrt(1+4*delta*delta*(xx@xx)))
    return np.r_[ii(aa),ii(bp)]

Ad=np.array(Amat,dtype=float)
delta=1/12
E_expected=Ad.T@np.diag([np.pi*delta*delta/(2*np.sqrt(2))]*3 + [delta*delta/(2*np.sqrt(2))]*3)
Z6=np.zeros(6);h=2e-6
J_mu=np.column_stack([(emu_inverse(Z6+h*np.eye(6)[i])-emu_inverse(Z6-h*np.eye(6)[i]))/(2*h) for i in range(6)])
record('NZ-inverse-local','NZ3-mu-Jacobian',J_mu,E_expected,atol=2e-10)
record('NZ-inverse-local','NZ3-mu-det-negative',np.linalg.det(J_mu)<0)
record('NZ-inverse-local','NZ3-mu-singular-values-positive',np.linalg.svd(J_mu,compute_uv=False).min() > (delta**2)/3)

# OA.1–OA.3: finite face checks are conditional on a genuine source-matched bridge;
# they do NOT construct a bridge or validate NZ.4 / exact global geometry.
for i in range(50):
    g=su2(qunit());t=RNG.random();r=RNG.uniform(.02,.98)
    eg=sg(1-r,g);h=su2(qunit());dummy=Id2
    # An arbitrary path of group elements B_l with B0=h, B1=eg is easy locally.
    # Verify ONLY algebraic endpoints, not boundary-relative nullhomotopy.
    X0=h@eg.conj().T@eg
    X1=eg@eg.conj().T@(-Id2)
    record('OA-face-algebra',f'bottom-{i}',X0,h)
    record('OA-face-algebra',f'top-{i}',X1,-Id2)
    record('OA-face-algebra',f'side-{i}',Id2@Id2@g@asu(t)@g.conj().T,g@asu(t)@g.conj().T)

assert all(q['status']=='PASS' for q in REC)
kind=Counter(q['kind'] for q in REC)
families=Counter(q['family'] for q in REC)
result={'artifact':'Paper1C-IndependentControlsBatch4Results-v1_1.json',
        'manuscript':'Paper1C-TechnicalMaterial-v1_59.tex',
        'scope_census_zero_based':[136,149],
        'method':'Single-model independent numeric finite/matrix controls. Exact group identities only at sampled finite points. Not a certificate of global topology or uniform interval estimates.',
        'total':len(REC),'passed':len(REC),'failed':0,
        'kind_counts':dict(kind),'test_families':dict(families),'checks':REC,
        'explicit_not_verified':['NZ.4 uniform interval Hessian certificate','G2/Spin7 infinitesimal triality and full horizontal lift on all source parameters','complete Puttmann-based cap homotopy','actual global bundle section transport and g-to-g_can nullhomotopy','global relative bridge NZ.20','computation of natural determinant bit h_t']}
(OUT/'Paper1C-IndependentControlsBatch4Results-v1_1.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',result['total'],'controls',len(families),'families',dict(kind))
