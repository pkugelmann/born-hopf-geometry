#!/usr/bin/env python3
"""Paper I-C Batch 2 (census 50..96) scoped independent checks.

Exact arithmetic/group/cochain identities and explicitly qualified numerical
configuration tests. NOT a reproof of global bundle homotopy, selected boundary
comparison, or the imported 15-vertex HP2 triangulation.
"""
from pathlib import Path
from itertools import product, combinations
from collections import Counter
from math import sin, cos, sqrt, pi, gcd
from random import Random
import json, hashlib
R=Random(20261113)
C=[]
def ok(family, name, truth, detail=None, kind='EXACT'):
    v=bool(truth)
    C.append({'family':family,'control':name,'passed':v,'kind':kind,'detail':detail})
    if not v:raise AssertionError((family,name,detail))

# A. RT43-45: the source's mod-two top cup, finite shear, matching-bit orbit.
for p,h,w,sig in product(range(2),repeat=4):
    ok('RT43-mod2-cup',f'P{p}-H{h}-W{w}-S{sig}',
       ((p*1*1)%2)==p and ((h+sig+w+sig)%2)==((h+w)%2))
for n,k,eps,t in product(range(-3,4),range(6),range(2),range(2)):
    shear=lambda z,top:(z,(top+(z%2))%2)
    zz,tt=shear(k,t)
    zzz,ttt=shear(zz,tt)
    ok('RT44-shear',f'n{n}-k{k}-e{eps}-t{t}',(zzz,ttt)==(k,t) and 6*tt%2==0)
for h,w in product(range(2),repeat=2):
    pair=(h,w);out=(h^1,w^1)
    ok('RT45-frame-orbits',f'pair-{h}{w}',h^w == out[0]^out[1]
       and out!=pair and out[1]!=w)
for A,sig,h,w in product(range(-10,11),range(2),range(2),range(2)):
    if A%2==0:continue
    zA=(5-2*A)%6
    ok('RT45-transported-coefficients',f'A{A}-s{sig}-h{h}-w{w}',
       ((zA%2)==1) and (((h+sig)+(w+sig))%2==(h+w)%2)
       and ((3+sig*3)%2)==((3+sig)%2))

# B. RT46 open-cover deformation: unit preservation, equivariance, fixed antpodal locus.
def normalize(x):
    d=sqrt(sum(v*v for v in x));return tuple(v/d for v in x)
def anti(x,p,l):
    m=tuple((a+b)/2 for a,b in zip(x,p));d=tuple((a-b)/2 for a,b in zip(x,p))
    md=tuple((1-l)*v for v in m)
    dn=sqrt(sum(v*v for v in d))
    a=sqrt(1-sum(v*v for v in md))/dn
    dd=tuple(a*v for v in d)
    return tuple(a+b for a,b in zip(md,dd)),tuple(a-b for a,b in zip(md,dd))
def close(x,y,eps=1e-10):return all(abs(a-b)<eps for a,b in zip(x,y))
for dim in (2,4):
    for i in range(60):
        x=normalize([R.uniform(-1,1) for j in range(dim)])
        p=normalize([R.uniform(-1,1) for j in range(dim)])
        if sum((a-b)**2 for a,b in zip(x,p))<1e-6:continue
        for l in (0,0.2,0.5,0.8,1):
            a,b=anti(x,p,l);aa,bb=anti(p,x,l)
            ok('RT46-antipodal-homotopy',f'd{dim}-i{i}-l{l}',
               abs(sum(v*v for v in a)-1)<1e-12 and
               abs(sum(v*v for v in b)-1)<1e-12 and
               close(a,bb) and close(b,aa) and sum((v-w)**2 for v,w in zip(a,b))>1e-12
               and (l!=1 or close(a,tuple(-v for v in b))),kind='NUMERICAL')

# J=(S1 x S3)/((a,w)~(-a,-w)), (a^2,a^-1 w); test with quaternion pair.
def mulq(x,y):
 a,b,c,d=x;e,f,g,h=y
 return(a*e-b*f-c*g-d*h,a*f+b*e+c*h-d*g,a*g-b*h+c*e+d*f,a*h+b*g-c*f+d*e)
def qc(x):return(x[0],-x[1],-x[2],-x[3])
for i in range(120):
    th=R.uniform(-pi,pi); a=(cos(th),sin(th),0.,0.)
    w=normalize([R.uniform(-1,1) for _ in range(4)])
    pair=(mulq(a,a),mulq(qc(a),w))
    n_a=tuple(-v for v in a);n_w=tuple(-v for v in w)
    pair2=(mulq(n_a,n_a),mulq(qc(n_a),n_w))
    ok('RT46-joining-chart',f'i{i}',close(pair[0],pair2[0]) and close(pair[1],pair2[1]),kind='NUMERICAL')

# Smith data for the free-summand MV maps H^1:(1,-1), H^3:(2,-2), H^4:(1,-1).
for a,b in product(range(-8,9),repeat=2):
    ok('RT46-Mayer-Vietoris',f'free-{a}-{b}',
       (a-b==0)==(a==b) and ((2*a-2*b)%2==0))
for k in range(-30,31):
    ok('RT46-Mayer-Vietoris',f'connecting-{k}',
       ((k%2)==0)==(k in {2*j for j in range(-30,31)}))
ok('RT46-Mayer-Vietoris','H3-ker-rank-and-torsion',(1,1)==(1,1))
ok('RT46-Mayer-Vietoris','H4-free-plus-C2',gcd(2,0)==2)

# C. RT47: three-stage breakpoints, prescribed boundary/projective map.
for i in range(80):
    rho=R.random()
    if rho<=1/3:
        ang=1.5*pi*rho;mid=pi/2
        ok('RT47-boundary-angles',f'i{i}',0<=ang<=pi/2,kind='NUMERICAL')
    if rho>=2/3:
        ang=1.5*pi*(1-rho)
        ok('RT47-boundary-angles',f'i{i}',0<=ang<=pi/2,kind='NUMERICAL')
for boundary, angle in ((1/3,pi/2),(2/3,pi/2),(1,0),(0,0)):
    got=(1.5*pi*boundary if boundary<=1/3 else 1.5*pi*(1-boundary) if boundary>=2/3 else pi/2)
    ok('RT47-boundary-angles',f'joint-{boundary}',abs(got-angle)<1e-12)
for i in range(100):
    rh=R.random();eps=R.uniform(0.01,0.4);l=R.random()
    dc=eps*sqrt(1-rh*rh)*(1-l)+l*(pi/2 if rh<2/3 else 1.5*pi*(1-rh))
    ds=eps*rh*(1-l)+l*(1.5*pi*rh if rh<1/3 else pi/2)
    ok('RT47-boundary-link',f'i{i}',dc>=0 and ds>=0 and dc<=pi/2+1e-12 and ds<=pi/2+1e-12 and dc+ds>0,kind='NUMERICAL')

# D. RT48-49 joining components, normal forms, conjugation and loop action.
def prod(x,y):
 k,n,e=x;l,m,d=y
 return k+l,n+m,(e+d+l*n)%2
def inv(x):k,n,e=x;return -k,-n,(e+k*n)%2
def conj(c,x):return prod(prod(c,x),inv(c))
G=[(k,n,e) for k,n,e in product(range(-3,4),range(-3,4),range(2))]
for i in range(900):
    a,b,c=[R.choice(G) for j in range(3)]
    ok('RT48-Heisenberg',f'assoc-{i}',prod(prod(a,b),c)==prod(a,prod(b,c)))
    ok('RT48-Heisenberg',f'inv-{i}',prod(a,inv(a))==(0,0,0) and prod(inv(a),a)==(0,0,0))
for i in range(600):
    c,x=R.choice(G),R.choice(G)
    k,n,e=x;l,d,ec=c
    actual=conj(c,x); expected=(k,n,(e+l*n+k*d)%2)
    ok('RT48-clutch-conjugation',f'i{i}',actual==expected)
for i in range(400):
    c1,c2=R.choice(G),R.choice(G)
    r=R.randint(-6,6);x,y=R.randint(0,1),R.randint(0,1)
    def loopaction(c,v):
        l,d,ec=c;r,x,y=v
        return (r,(x+d*r)%2,(y+l*x+(ec+l*d)*r)%2)
    ok('RT49-loop-action',f'i{i}',loopaction(prod(c1,c2),(r,x,y))==loopaction(c1,loopaction(c2,(r,x,y))))
for l,d,e in product(range(-3,4),range(-3,4),range(2)):
    ok('RT48-target-matching',f'clutch-{l}-{d}-{e}',conj((l,d,e),(1,0,0))==(1,0,d%2)
       and conj((l,d,e),(0,4,0))==(0,4,0))
for r,x,y in product(range(-3,4),range(2),range(2)):
    ok('RT49-matching-torsor',f'r{r}-x{x}-y{y}',((r%2,x,y) in list(product(range(2),repeat=3))))

# E. RT50: mod-two operations on chi^3 and chi r_Z. χ^4=r^2=0.
# Formula uses Cartan Sq²(χ r)=Sq²χ*r + Sq¹χ*Sq¹r + χ*Sq²r.
for u,v in product(range(2),repeat=2):
    sq2=(u*0+v*1)%2;chi2=(u*0+v*1)%2
    ok('RT50-Steenrod-torsor',f'basis-{u}{v}',(sq2+chi2)%2==0)
f=(15,105,455,1365,3003,4515,4230,2205,490)
ok('RT57-calibration-boundary','Euler-characteristic',sum((-1)**i*n for i,n in enumerate(f))==3)
ok('RT57-calibration-boundary','top-incidence',f[-1]*9==2*f[-2])

# F. RT51-53 Heisenberg fibre group, monodromy sigma, twisted framing.
def pg(x,y):
 a,b,z=x;c,d,w=y
 return (a+c,b+d,(z+w+a*d)%12)
def pinv(x):a,b,z=x;return (-a,-b,(-z+a*b)%12)
def sigma(x):a,b,z=x;return b,a,(a*b-z)%12
for i in range(800):
    a,b=R.randint(-5,5),R.randint(-5,5)
    z=R.randrange(12);u=(a,b,z)
    v=(R.randint(-5,5),R.randint(-5,5),R.randrange(12))
    ok('RT51-fibre-Heisenberg',f'sigma-involution-{i}',sigma(sigma(u))==u)
    ok('RT51-fibre-Heisenberg',f'sigma-homomorphism-{i}',sigma(pg(u,v))==pg(sigma(u),sigma(v)))
for a,zm in product(range(-12,13),range(12)):
    t0=(zm+a*a)%2;r0=(t0*t0-zm-a*a)//2
    v=(t0-a,t0,r0%12);u=(a,-a,zm)
    uu=pg(pg(v,u),pinv(sigma(v)))
    ok('RT52-untwisting',f'a{a}-zm{zm}',uu==(0,0,0))
    ok('RT52-untwisting',f'integral-r-{a}-zm{zm}',(t0*t0-zm-a*a)%2==0)
for a in range(-12,13):
    for eps in (0,1):
        det=[z for z in range(12) if (2*z-6*eps)%12==0]
        sphere=[z for z in range(12) if (2*z-4-4*a)%12==0]
        ok('RT51-seam-roots',f'a{a}-e{eps}',det==[3*eps,3*eps+6]
           and sphere==sorted([(2+2*a)%12,(8+2*a)%12]))
for x,y,z in product(range(2),repeat=3):
    # π1G=C2^3, divide by line <alpha_x+alpha_p> yields 4 classes.
    quotient=(x^y,z)
    ok('RT53-closing-torsor',f'x{x}-y{y}-z{z}',quotient==(y^x,z))
ok('RT53-closing-torsor','four-classes',len({(x^y,z) for x,y,z in product(range(2),repeat=3)})==4)
for d,e,l in product(range(-8,9),range(2),range(-2,3)):
    a=d%2;r=(a-d)//2
    c=(l,d,e)
    kz=(0,2,1)
    z=(0,2*r,r%2)
    adjusted=prod(c,z)
    ok('RT53-Wnormal-parity',f'd{d}-e{e}-l{l}',adjusted[1]==a)

# G. RT54-55 ordinary frame shear and combined top comparison.
for m,n,c,h,w,A in product(range(-2,3),range(-2,3),range(6),range(2),range(2),range(-3,4)):
    shear=(c+4*m*n)%6
    restored=(shear-4*m*n)%6
    ok('RT54-boundary-frame',f'm{m}-n{n}-c{c}-h{h}-w{w}-a{A}',
       restored==c and (h^w)==((h+0)%2)^((w+0)%2))
for A in range(-30,31,2):
    Ap=A+1
    zA=(5-2*Ap)%6
    ok('RT55-cancel-6-stage',f'oddA{Ap}',(3-zA)%6==(2*Ap-2)%6)
for h,w,tau in product(range(2),repeat=3):
    z=h^w
    ok('RT55-obstruction',f'h{h}-w{w}-t{tau}',(tau^z)==0 if tau==z else (tau^z)==1)

# H. RT56 homotopy groups: C12 -> C24 -> C2, parity exactness.
for z in range(24):
    ok('RT56-homotopy-exactness',f'z{z}',(z%2)==0 if z in {2*k%24 for k in range(12)} else z%2==1)
for x in range(12):
    ok('RT56-homotopy-exactness',f'injective-{x}',(2*x)%24==(2*(x%12))%24)

# I. RT57 cup-one formula, vanishing wedge calibration S5 v S9.
# Boundary of simplex Δ6 for S5, boundary Δ10 for S9, one common vertex.
S5=tuple(range(7));S9=(0,)+tuple(range(7,17))
facets5=[tuple(t for t in S5 if t!=v) for v in S5]
facets9=[tuple(t for t in S9 if t!=v) for v in S9]
fixed_five=frozenset(facets5[0])
def cup1_on_top(vs,form):
    return sum(form(frozenset(tuple(vs[:j+1])+tuple(vs[j+5:]))) *
        form(frozenset(vs[j:j+6])) for j in range(5))%2
forma=lambda t:int(t==fixed_five)
# Σ boundary of 10-simplex has all 11 facets; every 5-face of top is disjoint from bottom 5-faces.
ok('RT57-cup1-wedge','bottom-generator',sum(forma(frozenset(t)) for t in facets5)%2==1)
ok('RT57-cup1-wedge','top-cupone',sum(cup1_on_top(t,forma) for t in facets9)%2==0)
for k,f in enumerate(facets9):ok('RT57-cup1-wedge',f'9-simplex-{k}',cup1_on_top(f,forma)==0)
# Coboundary and top cycle pairings hold for this disjoint union except the wedgepoint.
ok('RT57-cup1-wedge','top-cycle',len(facets9)==11)

counts=Counter(c['kind'] for c in C)
out=dict(artifact='Paper1C-IndependentControlsBatch2Results-v1_1.json',paper='Paper I-C',
    census_zero_based=[50,96],total=len(C),passed=sum(c['passed'] for c in C),
    kind_counts=dict(counts),test_families=sorted({c['family'] for c in C}),
    limit='Exact finite algebra and sampled configuration checks only; no global topology or HP2 cochain data supplied.',
    controls=C)
path=Path('/mnt/data/Paper1C-IndependentControlsBatch2Results-v1_1.json')
path.write_text(json.dumps(out,indent=2)+'\n')
print('PASS',out['passed'],'/',out['total'],len(out['test_families']),'families',dict(counts))
