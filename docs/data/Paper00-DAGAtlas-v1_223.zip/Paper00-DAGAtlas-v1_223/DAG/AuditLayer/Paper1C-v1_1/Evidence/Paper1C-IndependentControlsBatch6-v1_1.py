#!/usr/bin/env python3
"""Paper I-C Batch 6: independently specified mathematical checks of census 160--219.
Checks are finite/exact or explicitly tolerance-bound, not complete global proofs.
No change to any paper, DAG, or audit ZIP.  Python3 + numpy + sympy + mpmath.
"""
import json, math, cmath, itertools
from pathlib import Path
from collections import Counter
import numpy as np
import sympy as sp
import mpmath as mp
mp.mp.dps=50
OUT=Path('/mnt/data'); rng=np.random.default_rng(416160)
records=[]
def chk(family,name,ok,details='',kind='exact',tol=None):
    passed=bool(ok)
    records.append(dict(family=family,name=name,passed=passed,kind=kind,tolerance=tol,details=str(details)[:400]))
    if not passed: raise AssertionError((family,name,details))
def near(a,b,eps=1e-9):return abs(complex(a)-complex(b))<=eps
# TGN: exact polynomial-basis test of source's reciprocal-odd coexact shell for k=1..4
T,X,Y,Z=sp.symbols('t x y z');qv=[T,X,Y,Z]
mons=lambda k: [(a,b,c,k-a-b-c) for a in range(k+1) for b in range(k-a+1) for c in range(k-a-b+1)]
pol=lambda m:sp.prod(qv[i]**m[i] for i in range(4))
for k in [1,2,3,4]:
 M=mons(k);Mminus=[m for m in M if sum(m[1:])%2]; Mplus=[m for m in M if not sum(m[1:])%2]
 cols=[(i,m) for i in range(4) for m in (Mminus if i==0 else Mplus)]
 M2=mons(k-2) if k>=2 else [];M0=mons(k-1);M1=mons(k+1)
 L=[]
 for i in range(4):
  for m in M2:
   L.append([sp.Poly(sum(sp.diff(pol(mm),qq,2) for qq in qv) if ii==i else 0,*qv).coeff_monomial(pol(m)) for ii,mm in cols])
 for m in M0:L.append([sp.Poly(sp.diff(pol(mm),qv[ii]),*qv).coeff_monomial(pol(m)) for ii,mm in cols])
 for m in M1:L.append([sp.Poly(qv[ii]*pol(mm),*qv).coeff_monomial(pol(m)) for ii,mm in cols])
 S=sp.Matrix(L); dimension=len(cols)-S.rank()
 Sm=sp.Matrix([[sp.Poly(sum(sp.diff(pol(mm),qq,2) for qq in qv),*qv).coeff_monomial(pol(m)) for mm in Mminus] for m in M2]) if M2 else sp.zeros(0,len(Mminus))
 scalarbasis=[sum(cc*pol(mm) for cc,mm in zip(b,Mminus)) for b in Sm.nullspace()]
 vecs=[]
 for a in range(1,4):
  for g in scalarbasis:
   vecs.append([sp.expand(sum(sp.LeviCivita(mu,nu,a,sig)*qv[nu]*sp.diff(g,qv[sig]) for nu in range(4) for sig in range(4))) for mu in range(4)])
 W=sp.Matrix([[sp.Poly(V[ii],*qv).coeff_monomial(pol(mm)) for V in vecs] for ii,mm in cols]); r=W.rank()
 chk('transverse-generation',f'k={k}-exact-shell-rank',r==dimension,dict(dim=dimension,rank=r,basis=len(scalarbasis)))
 chk('transverse-generation',f'k={k}-tangent-harmonic',S*W==sp.zeros(S.rows,W.cols))
for k in range(1,19):
 R=sp.symbols('R',nonzero=True)
 actual=sp.factor(sp.Rational(3,4)/(k+1)**2 * (R**2/sp.Integer(k*(k+2))-R**2/sp.Integer(3)))
 expect=-R**2*(k-1)*(k+3)/sp.Integer(4*k*(k+2)*(k+1)**2)
 chk('transverse-generation',f'mixed-coefficient-k{k}',sp.simplify(actual-expect)==0)
# KO-product splitting
z=sp.symbols('z');b=[int(sp.Poly((1+z)**2*(1+z**3)**2,z).nth(d)) for d in range(9)]
KO=[(1,0),(0,1),(0,1),(0,0),(1,0),(0,0),(0,0),(0,0)]
expected=[(6,3),(4,4),(2,4),(4,3),(6,3),(4,6),(2,6),(4,3)]
for i in range(8):
 val=tuple(sum(b[d]*KO[(i+d)%8][j] for d in range(9)) for j in range(2))
 chk('KO-table',f'KO-minus-{i}',val==expected[i],val)
# Feshbach complement & heat trace blocks
D0=np.array([[0.,0.,0.],[0.,0.,2.],[0.,2.,0.]])
Pinv=np.diag([1.,0.,0.]);Qinv=np.diag([0.,1.,1.]); V=np.array([[3.,1.,0.],[1.,5.,0.],[0.,0.,7.]])
for eta in [0.01,0.03,0.06,0.1]:
 H=D0+eta*V;zc=0.;CQ=H[1:,1:];K=H[0,0]-zc-H[0,1:]@np.linalg.inv(CQ-zc*np.eye(2))@H[1:,0]
 chk('feshbach',f'example-exact-Schur-{eta}',near(np.linalg.det(H),np.linalg.det(CQ)*K,1e-10),kind='numeric',tol=1e-10)
for n in range(1,12):
 delta=0.2;b=n*(n+2);c=(n+1)**2;h=0.1
 # Exact/gradient 2x2 eigenroots, coexact two doublets, compare cosh-pair formula
 M=-delta*np.eye(2)+math.sqrt(b)*np.array([[0,1],[1,0]])-2*delta*np.diag([1,-1])
 exp_pair=sum(math.exp(-h*v*v) for v in np.linalg.eigvalsh(M))
 formula_pair=2*math.exp(-h*(b+5*delta**2))*math.cosh(2*h*delta*math.sqrt(b+4*delta**2))
 chk('dirac-heat',f'gradient-pair-n{n}',near(exp_pair,formula_pair,1e-10),kind='numeric',tol=1e-10)
# Sphere reciprocal angular f_eps test
for vec in [(1,0,0),(1,1,0),(1,1,1),(1,2,2),(2,3,6)]:
 v=np.array(vec,dtype=float);v/=np.linalg.norm(v)
 vals=[(3-float(np.dot(e,v))**2)/4 for e in itertools.product([-1,1],repeat=3)]
 chk('angular-moments',f'mean-{vec}',near(sum(vals),4,2e-14),kind='numeric',tol=2e-14)
 chk('angular-moments',f'square-{vec}',near(sum(x*x for x in vals),3-sum(v**4),2e-14),kind='numeric',tol=2e-14)
# Cartan transport w(s), symmetry and gap
th=math.pi/3
for s in np.linspace(0,1,9):
 def w(z):return math.cos(th*z)+4/(3*math.sqrt(3))*math.sin(th*z)**3
 chk('cartan-face',f'symmetry-s={s:.3f}',near(w(s),w(1-s),3e-15),kind='numeric',tol=3e-15)
chk('cartan-face','midpoint-defect',near(math.sqrt(2-2*w(.5)),math.sqrt(2-10/(3*math.sqrt(3))),1e-14),kind='numeric',tol=1e-14)
# Overlap GW identity with explicit gamma5-graded finite blocks
G5=np.diag([1,1,-1,-1]).astype(complex)
for j in range(12):
 Z=(rng.normal(size=(2,2))+1j*rng.normal(size=(2,2)))/4
 D=np.block([[np.zeros((2,2)),Z],[-Z.conj().T,np.zeros((2,2))]])
 J=np.block([[np.diag(rng.uniform(.3,1.,2)),np.zeros((2,2))],[np.zeros((2,2)),np.diag(rng.uniform(.3,1.,2))]])
 H=G5@(D+J-.6*np.eye(4));err=np.linalg.norm(H-H.conj().T)
 E,U=np.linalg.eigh(H);eps=(U*np.sign(E))@U.conj().T;V=G5@eps;Do=np.eye(4)+V
 chk('finite-overlap',f'hermiticity-{j}',err<1e-12,kind='numeric',tol=1e-12)
 chk('finite-overlap',f'GW-{j}',np.linalg.norm(G5@Do+Do@G5-Do@G5@Do)<2e-12,kind='numeric',tol=2e-12)
 chk('finite-overlap',f'gamma-hermiticity-{j}',np.linalg.norm(Do.conj().T-G5@Do@G5)<2e-12,kind='numeric',tol=2e-12)
# Polynomial invariant structure
x,y=sp.symbols('x y');f6=x*y*(x**4-y**4);f8=x**8+14*x**4*y**4+y**8;g12=x**12-33*x**8*y**4-33*x**4*y**8+y**12
chk('Hurwitz-invariant','Klein-polynomial',sp.expand(f8**3-g12**2-108*f6**4)==0)
chk('Hurwitz-invariant','twelfth-norm-u12',sum(sp.Rational(c**2,sp.binomial(12,12-k)) for (k,c) in [(2,1),(6,-2),(10,1)])==sp.Rational(8,231))
chk('Hurwitz-invariant','twelfth-norm-g12',sp.Rational(2)+2*33**2/sp.binomial(12,4)==sp.Rational(32,5))
for u in [sp.Rational(1,2),sp.Rational(2,3),2,3]:
 F6=sp.expand(f6.subs({x:u,y:1}));G=g12.subs({x:u,y:1})
 chk('Hurwitz-invariant',f'nonbasepoint-sample-{u}',F6!=0 or G!=0)
# Theta series modular checks in absolutely convergent regime
def eta(tau):
 q=mp.e**(2*mp.pi*1j*tau);return q**(mp.mpf(1)/24)*mp.fprod([1-q**n for n in range(1,110)])
def thetaZ(R,tau):
 q2=mp.e**(2*mp.pi*1j*tau);val=mp.mpc(0)
 for n in range(-9,10):
  for w in range(-9,10):
   pl=n/R+w*R;pr=n/R-w*R
   val+=mp.e**(mp.pi*1j*tau*pl**2/2 -mp.pi*1j*mp.conj(tau)*pr**2/2)
 return val/abs(eta(tau))**2
for R in [mp.mpf('0.85'),mp.mpf('1.0'),mp.mpf('1.3')]:
 tau=mp.mpc('.23','1.15');V=thetaZ(R,tau)
 chk('theta-modular',f'T-{R}',abs(V-thetaZ(R,tau+1))<mp.mpf('1e-22'),kind='numeric',tol=1e-22)
 chk('theta-modular',f'S-{R}',abs(V-thetaZ(R,-1/tau))<mp.mpf('1e-18'),kind='numeric',tol=1e-18)
 chk('theta-modular',f'T-dual-{R}',abs(V-thetaZ(1/R,tau))<mp.mpf('1e-22'),kind='numeric',tol=1e-22)
# Matrix congruence vs map-type, exact Schur second/third/fourth jets
w,z=sp.symbols('w z');a=sp.Rational(5,2);b0=sp.Rational(3,5);c=sp.Rational(7,3);T3=sp.Rational(4,7);T4=sp.Rational(8,11)
S=a*w*w/2+b0*w*z+c*z*z/2 + T3*w*w*z/2 + T4*w**4/sp.factorial(4)
zs=-(b0*w+T3*w*w/2)/c; phi=sp.expand(S.subs(z,zs));L=-b0/c
for n in [2,3,4]:
 dn=sp.diff(phi,w,n).subs(w,0)
 if n==2: target=a-b0*b0/c
 if n==3: target=3*T3*L
 if n==4: target=T4-3*T3*T3/c
 chk('stationary-Schur',f'{n}th-jet',sp.simplify(dn-target)==0,details=(dn,target))
for j in range(10):
 A=rng.normal(size=(2,2));C=rng.normal(size=(2,2));C=C.T@C+2*np.eye(2);B=rng.normal(size=(2,2))
 H=np.block([[A.T@A+2*np.eye(2), B.T],[B,C]])
 K=H[:2,:2]-H[2:,:2].T@np.linalg.inv(C)@H[2:,:2]
 if abs(np.linalg.det(H))>1e-5:
  chk('stationary-Schur',f'inverse-restriction-{j}',np.linalg.norm(np.linalg.inv(K)-np.linalg.inv(H)[:2,:2])<1e-11,kind='numeric',tol=1e-11)
# rank-three matrix-pair reconstruction via genuine Haar U3 and direct mixed traces
for j in range(12):
 Z=rng.normal(size=(3,3))+1j*rng.normal(size=(3,3));V,_=np.linalg.qr(Z)
 aa=np.array([1.,2.3,5.]);bb=np.array([.7,3.2,4.8]);A=np.diag(aa);B=V@np.diag(bb)@V.conj().T
 M=np.array([[np.trace(np.linalg.matrix_power(A,p)@np.linalg.matrix_power(B,q)).real for q in range(3)] for p in range(3)])
 SA=np.vander(aa,3,increasing=True).T;SB=np.vander(bb,3,increasing=True).T
 W=np.linalg.inv(SA)@M@np.linalg.inv(SB).T;r=np.multiply(W[0,:],W[1,:]);J2=(2*(r[0]*r[1]+r[0]*r[2]+r[1]*r[2])-np.sum(r*r))/4
 Cmt=A@B-B@A;chi=np.trace(Cmt@Cmt@Cmt)/(6j)
 DA=(aa[0]-aa[1])*(aa[1]-aa[2])*(aa[2]-aa[0]);DB=(bb[0]-bb[1])*(bb[1]-bb[2])*(bb[2]-bb[0]);ratio=(chi/(DA*DB))**2
 chk('rank3-mixed-moment',f'W-reconstruction-{j}',np.linalg.norm(W-np.abs(V)**2)<5e-12,kind='numeric',tol=5e-12)
 chk('rank3-mixed-moment',f'J-chi-{j}',abs(J2-ratio)<1e-11,details=(J2,ratio),kind='numeric',tol=1e-11)
# Projection chart normalized intertwiners
for j in range(12):
 H0=np.diag([-3.,-1.2,1.3,2.5]);Z=rng.normal(size=(4,4))+1j*rng.normal(size=(4,4));dH=(Z+Z.conj().T)*.12
 H=H0+dH;gap0=1.2;delta=np.linalg.norm(dH,2)
 if delta>=gap0:continue
 eig,vec=np.linalg.eigh(H);P=(vec[:,eig>0])@(vec[:,eig>0].conj().T);P0=np.diag([0,0,1,1]);G=(P0@P@P0)[2:,2:]
 vals,V=np.linalg.eigh(G);Tmat=P@P0[:,2:]@(V@np.diag(1/np.sqrt(vals))@V.conj().T)
 bound=2*(gap0-delta)/(np.linalg.norm(H,2)+gap0-delta)
 chk('chiral-projector',f'Gram-bound-{j}',min(vals)>=bound-1e-10,kind='numeric',tol=1e-10)
 chk('chiral-projector',f'polar-isometry-{j}',np.linalg.norm(Tmat.conj().T@Tmat-np.eye(2))<1e-10,kind='numeric',tol=1e-10)
# SU3 frame root shells: coordinate E8 roots, Gram E7 and E6 from two nonorthogonal roots
vecs=[]
for i in range(8):
 for k in range(i+1,8):
  for p in (-1,1):
   for r in (-1,1):
    x=np.zeros(8);x[i]=p/math.sqrt(2);x[k]=r/math.sqrt(2);vecs.append(x)
for signs in itertools.product((-1,1),repeat=8):
 if math.prod(signs)==1:vecs.append(np.array(signs,dtype=float)/(2*math.sqrt(2)))
V8=np.array(vecs);ra=np.zeros(8);ra[6]=ra[7]=1/math.sqrt(2)
rb=np.zeros(8);rb[5]=1/math.sqrt(2);rb[6]=-1/math.sqrt(2)
V7=V8[np.abs(V8@ra)<1e-12];V6=V7[np.abs(V7@rb)<1e-12]
for name,Vv,dim,expectedn in [('E8',V8,8,240),('E7',V7,7,126),('E6',V6,6,72)]:
 frame=Vv.T@Vv;P=np.linalg.pinv(frame)@frame
 chk('exceptional-frames',f'{name}-count',len(Vv)==expectedn,details=len(Vv))
 chk('exceptional-frames',f'{name}-rank',np.linalg.matrix_rank(frame,tol=1e-9)==dim)
 chk('exceptional-frames',f'{name}-Gram',np.linalg.norm(frame-expectedn/dim*P)<1e-10,kind='numeric',tol=1e-10)
# Finite covariance and blocking
for j in range(10):
 lam=np.array([0.,1.,3.,5.]);k=.8+.05*j;L=2.;a=L**-2;b=k**-2
 Cv=np.array([(math.exp(-a*l)-math.exp(-b*l))/l if l else b-a for l in lam])
 chk('finite-covariance',f'heat-eigenvalues-{j}',max(abs(Cv-np.array([float(mp.quad(lambda ss:mp.e**(-ss*l),[a,b])) for l in lam])))<1e-12,kind='numeric',tol=1e-12)
 chk('finite-covariance',f'positive-interval-{j}',np.min(Cv)>=(b-a)*math.exp(-5/k**2)-1e-12)
# Sharp TV oscillation bound on arbitrary two-point positive measures
for j in range(18):
 p=.05+.9*float(rng.uniform());t=float(rng.uniform(-5,5));P=np.array([p,1-p]);Q=P*np.exp([-t,0.]);Q/=sum(Q)
 tv=sum(abs(P-Q))/2
 chk('positive-blocking',f'tv-bound-{j}',tv<=math.tanh(abs(t)/4)+1e-13,details=(tv,t),kind='numeric',tol=1e-13)
# Dyadic trace moments, Euler/Hopf data
for r in range(1,10):
 closed=sp.Rational(2**(r+1),(2**r-1)**2)
 approximate=mp.nsum(lambda j:2*j*mp.power(2,-r*j),[1,mp.inf])
 chk('Hopf-dyadic',f'trace-power-{r}',abs(approximate-float(closed))<1e-14,kind='numeric',tol=1e-14)
for t0 in [mp.mpf('.0002'),mp.mpf('.00005')]:
 H=2*mp.e**(2*t0)*mp.nsum(lambda j:j*mp.e**(-4*t0*j*j),[1,mp.inf]);approx=1/(4*t0)+mp.mpf(1)/3
 chk('Hopf-dyadic',f'heat-asympt-{t0}',abs(H-approx)<mp.mpf('0.0005'),kind='numeric',tol=5e-4)
# Weighted involution & Euler reconstruction
R=sp.symbols('R',positive=True);B=sp.Rational(5,3);F=R**3+sp.Rational(2,7)*R**2-R+1/R
Tfun=lambda f:sp.simplify(R*R/B*f.subs(R,B/R))
Efun=lambda f:sp.simplify(R*sp.diff(f,R)-f)
chk('born-euler','involution',sp.simplify(Tfun(Tfun(F))-F)==0)
chk('born-euler','anticommutation',sp.simplify(Efun(Tfun(F))+Tfun(Efun(F)))==0)
chk('born-euler','paired-Hessian',sp.simplify(sp.Rational(1,2)*(R**2*sp.diff(F,R,2)-B*sp.diff(Tfun(F),R,2).subs(R,B/R))-Efun(F))==0)
for bval in [sp.Rational(1,2),sp.Rational(3,5),sp.Rational(7,2)]:
 chk('born-euler',f'quadratic-partner-{bval}',sp.simplify(Efun(R*R+bval)- (R*R-bval))==0)
# Contact lift and reciprocal Laurent formulas
p,z,hp,e=sp.symbols('p z h e'); rprime=B/R
zprime=e*B/R**2*z+hp*(B/R);pprime=e*(2*z/R-p)+hp
# for h=cR, derivative h'(B/R)=c, we test constant derivative consistently
c0=sp.Rational(2,5);zprime=e*B/R**2*z+c0*B/R;pprime=e*(2*z/R-p)+c0
coef=sp.simplify(sp.diff(zprime,R)-pprime*sp.diff(rprime,R))
chk('contact-lift','dR-coefficient',sp.simplify(coef+e*B*p/R**2)==0)
chk('contact-lift','dz-coefficient',sp.diff(zprime,z)==e*B/R**2)
for C,U in [(1,4),(sp.Rational(1,2),7),(2,9)]:
 B0=C*U;hz=(R**2+B0)/((C+U)*R);vv=sp.simplify(R*sp.diff(sp.log(hz),R))
 chk('laurent-secants',f'C={C}-U={U}',sp.simplify(vv-(R**2-B0)/(R**2+B0))==0)
# quartic SU3 finite central heat expansion using fundamental+antifundamental+adjoint
for tt in [sp.Rational(1,2),sp.Rational(3,2),sp.Rational(5,1)]:
 a0=sp.exp(-sp.Rational(2,3)*tt);bb=sp.exp(-sp.Rational(3,2)*tt)
 zz=1+18*a0+64*bb
 # theta g=diag(e^ix,e^-ix,1). |trace|=1+2 cos x
 xc=sp.symbols('xc');KI=1+6*a0*(1+2*sp.cos(xc))+8*bb*((1+2*sp.cos(xc))**2-1)
 vq=sp.series(-sp.log(KI/zz),xc,0,6).removeO().expand()
 Cmean=(18*a0*sp.Rational(4,3)+64*bb*3)/zz
 C2mean=(18*a0*sp.Rational(16,9)+64*bb*9)/zz
 kval=Cmean/8;hdot=-(C2mean-Cmean**2)/16
 coeffpred=sp.Rational(2,5)*(kval*kval+hdot+kval/4)
 chk('SU3-heat-Hessian',f'quadratic-t={tt}',abs(complex(sp.N(vq.coeff(xc,2)-2*kval)))<1e-13,kind='numeric',tol=1e-13)
 chk('SU3-heat-Hessian',f'quartic-t={tt}',abs(complex(sp.N(vq.coeff(xc,4)-coeffpred)))<1e-13,kind='numeric',tol=1e-13)
# Conformal stationary factor and parameter-uniform response inequalities
R0,P0,gp,gpp=sp.symbols('R0 P0 gp gpp',nonzero=True)
Hess=16*(R0*gp/2)-12*R0*gp+12*gp*P0+4*gpp*(R0-3*P0)**2
fact=36*gpp*(P0-R0/3)*(P0+(gp-R0*gpp)/(3*gpp))
chk('conformal-Hessian','Einstein-factor',sp.simplify(Hess-fact)==0)
for A0 in [39.5,40.0]:
 la=math.log(8)+A0/2;eta=math.exp(la-A0)*(1+math.exp(-3*A0))*(20*la/3+4*la*la)
 chk('uniform-dressed-trace',f'eta-A{A0}',eta<.001,details=eta,kind='numeric',tol=0.001)
# Schur exact residual for y with nonzero retained/complement coupling
for n in range(12):
 A0=rng.normal(size=(3,3));A0=A0+A0.T;B0=rng.normal(size=(2,3));C0=np.array([[4.,.1],[.1,3.]])
 Z0=-np.linalg.solve(C0,B0);L0=np.vstack([np.eye(3),Z0]);
 y=float(rng.uniform(-.5,.5));A=A0+y*np.eye(3);B=B0+y*rng.normal(size=(2,3));C=C0+y*np.eye(2)
 H=np.block([[A,B.T],[B,C]]);RS=B+C@Z0;KS=A-B.T@np.linalg.solve(C,B);KC=L0.T@H@L0-RS.T@np.linalg.solve(C,RS)
 chk('all-order-Schur',f'exact-y={n}',np.linalg.norm(KS-KC)<2e-12,kind='numeric',tol=2e-12)
# Compression defects, mass positivity and sign locality stress tests
for j in range(16):
  A=rng.normal(size=(5,5))+1j*rng.normal(size=(5,5))
  B=rng.normal(size=(5,5))+1j*rng.normal(size=(5,5))
  Z=rng.normal(size=(5,3))+1j*rng.normal(size=(5,3))
  Q,_=np.linalg.qr(Z); P=Q@Q.conj().T; Pperp=np.eye(5)-P
  lhs=(P@A@P)@(P@B@P)-(P@B@P)@(P@A@P)-P@(A@B-B@A)@P
  rhs=-P@A@Pperp@B@P+P@B@Pperp@A@P
  chk('compression-defect',f'identity-{j}',np.linalg.norm(lhs-rhs)<4e-12,kind='numeric',tol=4e-12)
for j in range(12):
  z=rng.normal(size=(2,2))+1j*rng.normal(size=(2,2))
  u,_,vh=np.linalg.svd(z);Vblock=u@vh;V=np.block([[Vblock,np.zeros((2,2))],[np.zeros((2,2)),Vblock.conj().T]])
  Gamma=np.block([[np.zeros((2,2)),np.eye(2)],[np.eye(2),np.zeros((2,2))]])
  m=.1+.42*j;a=.75
  Dm=(1/a+m/2)*np.eye(4)+(1/a-m/2)*V
  chk('massive-determinants',f'graded-unitary-{j}',np.linalg.norm(Gamma@V@Gamma-V.conj().T)<1e-12,kind='numeric',tol=1e-12)
  chk('massive-determinants',f'positive-{j}',np.linalg.svd(Dm,compute_uv=False).min()+1e-12>=min(m,2/a) and np.linalg.det(Dm).real>0 and abs(np.linalg.det(Dm).imag)<1e-10,kind='numeric',tol=1e-10)
# Fredholm singlet factor and normalization
zz=sp.symbols('zz',real=True); a=sp.Rational(3,2); tanh=sp.tanh(zz); sech=sp.sech(zz)
zero=sech**a
chk('kink-Fredholm','singlet-Qstar-zero',sp.simplify(-sp.diff(zero,zz)+(-a*tanh)*zero)==0)
chk('kink-Fredholm','sech3-integral',abs(mp.quad(lambda z:mp.sech(z)**3,[-mp.inf,mp.inf])-mp.pi/2)<mp.mpf('1e-39'),kind='numeric',tol=1e-39)
# Locus of partition-function nonzeros
for j in range(12):
  obs=rng.uniform(-1,1,size=5); ww=rng.uniform(size=5);ww/=sum(ww)
  Jc=complex(rng.normal(),rng.normal())*.15;L=abs(Jc)*max(abs(obs))
  Fv=sum(ww*np.exp(Jc*obs))
  chk('complex-source-domain',f'nonzero-{j}',L<math.log(2) and abs(Fv-1)<=math.exp(L)-1+1e-14 and abs(Fv)>1-(math.exp(L)-1),kind='numeric',tol=1e-14)
# Relative covariant KO/K twist torsion arithmetic, not a complete K-theory proof
for k,l in [(0,5),(2,0),(2,3),(4,6),(15,9),(6,12),(1,1),(8,24),(-12,18),(77,28)]:
  g=math.gcd(abs(k),abs(l)); chk('twisted-K-arithmetic',f'gcd-{k}-{l}',g>0 and (k%g==0 and l%g==0),details=g)
# Trace-calculus exact differentiation with non-quadratic f
r=sp.symbols('r',positive=True);cc=sp.symbols('cc',positive=True)
f=r**3/sp.Integer(3)+r**2+sp.exp(r)/10
FF=sp.diff(f,r);GG=sp.diff(f,r,2);H3=sp.diff(f,r,3);H4=sp.diff(f,r,4)
TT=2*f-r*FF
W2=cc**2/sp.Integer(3)*(FF/GG-r)
W3=-cc**2*FF*H3/(3*GG**3)
W4=-cc**2*(GG**2*H3+FF*GG*H4-3*FF*H3**2)/(3*GG**5)
chk('trace-calculus','W3-derivative',sp.simplify(sp.diff(W2,r)/GG-W3)==0)
chk('trace-calculus','W4-derivative',sp.simplify(sp.diff(W3,r)/GG-W4)==0)
# Full affine contact involution and fixed reference section
rr=sp.symbols('rr',positive=True);BB=sp.Rational(4);UU=sp.Rational(7)
F=rr**3+2*rr**2+1
TA=lambda f:sp.simplify(rr**2/BB*f.subs(rr,BB/rr))
JJ=lambda f:sp.expand(2*UU*rr-TA(f))
chk('contact-lift','reference-involution',sp.simplify(JJ(JJ(F))-F)==0)
chk('contact-lift','reference-fixed',sp.simplify(JJ(UU*rr)-UU*rr)==0)
# spectral chart locality at finite k: bound for a tridiagonal Hermitian H
for j in range(12):
  d=7;H=np.diag(np.array([1.8+0.05*i for i in range(d)]))
  xx=rng.uniform(-.15,.15,size=d-1)
  for k in range(d-1):H[k,k+1]=H[k+1,k]=xx[k]
  eig,V=np.linalg.eigh(H);gamma=np.min(abs(eig));M=np.max(abs(eig));qq=(M-gamma)/(M+gamma)
  signH=(V*np.sign(eig))@V.T
  for dist in [2,3,4,5,6]:
    bd=M/gamma*qq**math.floor(dist/2)
    chk('overlap-locality',f'j{j}-d{dist}',abs(signH[0,dist])<=bd+1e-10,kind='numeric',tol=1e-10)
# End
count=Counter(x['family'] for x in records)
res=dict(artifact='Paper1C-IndependentControlsBatch6Results-v1_1.json',source_scope=dict(census=[160,219],lines=[18805,21426]),
         executor='One model; reproducible exact and finite/numeric controls, no independent agents',
         total=len(records),passed=sum(x['passed'] for x in records),failed=sum(not x['passed'] for x in records),
         kinds=dict(Counter(x['kind'] for x in records)),test_families=dict(count),records=records,
         limitations='Finite levels k<=4 for transverse span; finite SU3 truncation in heat expansion; finite-dimensional overlap and Schur tests; no global theorem, external analytic classification or physical realization is thereby certified.')
(OUT/res['artifact']).write_text(json.dumps(res,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:res[k] for k in ['total','passed','failed','kinds','test_families']},indent=2))
