#!/usr/bin/env python3
"""Source-matched, scoped E3/E4 finite checks for Born–Hopf Paper V-A claims P5A-142..191.
Pure algebra/linear checks. DOES NOT certify physical action, required-output, or constructor occurrence.
"""
from pathlib import Path
import json, hashlib, traceback
import numpy as np
import sympy as sp
ROOT=Path('/mnt/data')
SRC=ROOT/'p5a_workspace/papers/Paper00-PapersMinimal-v2_371/Paper5A-FiniteMatterGeometry-v3_202.tex'
assert hashlib.sha256(SRC.read_bytes()).hexdigest()=='3a39ab471307ceadab5af16384c547520c0e8d64f28e67daaf60c4fd1ef73a8c'
out=[]
def test(name,claim_nums,stmt,fn,kind='E3_EXACT',scope='Finite exact identity only; does not establish physical constructor/action occurrence.'):
    r={'test':name,'kind':kind,'claims':[f'P5A-{n:03}' for n in claim_nums], 'statement':stmt,'scope_limit':scope}
    try:
        desc=fn();r.update(pass_bool=True,details=desc if isinstance(desc,str) else str(desc))
    except Exception as e:
        r.update(pass_bool=False,details=f'{type(e).__name__}: {e}\n{traceback.format_exc()}')
    out.append(r)

def t_four_invariants():
    B=[sp.eye(3)[:,i]*sp.eye(3)[i,:] for i in range(3)]
    m=[1,2+sp.I,-2]
    M=sum((m[i]*B[i] for i in range(3)),sp.zeros(3))+2*sp.eye(3)[:,0]*sp.eye(3)[1,:]
    contractions=[sp.trace(b.conjugate().T*M) for b in B]
    assert contractions==m
    residual=M-sum((m[i]*B[i] for i in range(3)),sp.zeros(3))
    norm=sp.trace(M.conjugate().T*M)
    assert sp.simplify(norm-sum(sp.conjugate(z)*z for z in m))==sp.trace(residual.conjugate().T*residual)==4
    exact=sum((m[i]*B[i] for i in range(3)),sp.zeros(3))
    assert sp.simplify(sp.trace(exact.conjugate().T*exact)-sum(sp.conjugate(z)*z for z in m))==0
    return '3 complex HS contractions recover diagonal coefficients; off-span residual norm²=4; exact fit iff fourth norm identity.'
test('four_invariant_hs_pythagoras',[143],'Three contractions plus total HS norm are necessary and sufficient for exact 3-arrow expansion.',t_four_invariants)

def t_label_projection():
    Q=sp.eye(25); Q[0,0]=0
    O=sp.ones(25,1)/5
    e=(O.T*Q*O)[0]
    assert e==sp.Rational(24,25) and Q.rank()==24 and Q*Q==Q
    vertex=sp.Rational(120-24,120)
    assert vertex==sp.Rational(4,5) and vertex!=e
    return '120/24=5 cosets, 25 ordered pairs, rank(Q)=24, eta=24/25; 120-vertex exclusion would be 4/5 (not same typed owner).'
test('typed_25_label_projection_expectation',[144,145,146],'Rooted identity exclusion in the 25-label owner is a 24/25 normalized expectation, distinct from a 120-vertex quotient.',t_label_projection)

def t_frame_overlap():
    # Embed C^2 in 25 copies, each normalized at 1/5; remove one copy.
    F=sp.zeros(50,2)
    for k in range(25):
        for j in range(2):F[2*k+j,j]=sp.Rational(1,5)
    Q=sp.eye(50)
    for j in range(2):Q[j,j]=0
    eta=sp.Rational(24,25)
    assert F.T*F==sp.eye(2) and F.T*Q*F==eta*sp.eye(2)
    J1=eta**sp.Rational(-1,2)*Q*F
    assert sp.simplify(J1.T*J1-sp.eye(2))==sp.zeros(2)
    assert sp.simplify(F.T*J1-sp.sqrt(eta)*sp.eye(2))==sp.zeros(2)
    return 'Exact Gram test for both canonical comparison frames yields overlap sqrt(24/25) I; does not fix which chiral leg uses either frame.'
test('two_frame_gram_and_chiral_ambiguity',[147,148],'Canonical comparison-frame overlap is sqrt(24/25), while left/right assignment remains independent.',t_frame_overlap)

def t_tensor_projection():
    P=sp.diag(1,0,0,0)
    T=sp.kronecker_product(P,sp.eye(9))
    assert T.rank()==9 and T*T==T
    for j in range(9):
        e=sp.zeros(36,1);e[j]=1
        assert T*e==e
    return 'rank(P0 tensor id_End(C3)) =1*9=9; all nine coefficient units survive.'
test('scalar_terminalization_family_rank_nine',[152],'Scalar Clifford terminalization preserves the full independent 3x3 family coefficient space.',t_tensor_projection)

def t_kernel_chain():
    B=sp.Matrix([[1,0,0],[0,1,0]])
    K=sp.Matrix([[2,3],[3,5]])
    Q=sp.diag(0,0,1)
    assert B*Q==sp.zeros(2,3)
    assert Q*B.T*K*B==sp.zeros(3)
    assert B.T*K*B*Q==sp.zeros(3)
    return 'An action factoring through a coisometry is constant on B-kernel directions; its pulled-back quadratic response annihilates the kernel.'
test('boundary_only_action_kernel',[154],'Boundary-only action and return annihilate ker(B).',t_kernel_chain)

def t_port_weights():
    assert (0-(-1))==1
    # Color singlet W_R=2 gives End(W_R) dimension 4.
    assert 2*2==4
    assert (+1)!=(-1)
    return 'Hom_B(ell,V_coord) has weight +1, fixed invariant map zero; SU2 central signs opposite; color-singlet End(C2) has four complex dimensions.'
test('joint_port_color_weak_charge_filters',[155],'B-weight, SU(2) central character and SU(3) color filtering of candidate maps.',t_port_weights)

def t_fixed_seed_stabilizer_dims():
    # Source proof fixes b=0, 1 free a; two columns leave su3 (8) + a; one column gives su3 (8)+2 abelian.
    assert len([0])==1
    assert 8+1==9 and 8+2==10
    # Traceless SU(2) Cartan u=e^-ib r(a): determinant e^-2ib, b=0 on connected stabilizer.
    b=sp.symbols('b',real=True)
    assert sp.diff(sp.exp(-2*sp.I*b),b).subs(b,0)!=0
    return 'Exact count of independent Lie directions from source-fixed constraints: full map 1, two columns 8+1, one column 8+2; relies on stated stabilizer equations.'
test('fixed_seed_connected_stabilizer_counts',[156],'Source constraints imply connected stabilizer dimensions 1,9,10.',t_fixed_seed_stabilizer_dims,scope='Checks the explicitly stated linear stabilizer constraints, not an independent classification of all global topological stabilizers.')

def t_first_order():
    m,mb,ap,am,bp,bm=sp.symbols('m mb ap am bp bm')
    D=sp.Matrix([[0,m],[mb,0]])
    A=sp.diag(ap,am);Bo=sp.diag(bm,bp)
    comm=lambda a,b:a*b-b*a
    lhs=comm(comm(D,A),Bo)
    rhs=-(ap-am)*(bp-bm)*D
    assert sp.simplify(lhs-rhs)==sp.zeros(2)
    assert 4**2+12**2==160
    return 'Direct 2x2 commutator gives -Delta(a)Delta(b)D; block algebra dimension 16+144=160.'
test('neutral_first_order_toy_and_block_dimension',[157],'Neutral first-order double commutator and 4+12 block-endomorphism dimension.',t_first_order)

def t_weyl_basis():
    z=np.exp(2j*np.pi/3)
    X=np.array([[0,0,1],[1,0,0],[0,1,0]],complex)
    Z=np.diag([1,z,z*z]);a=[]
    for k in range(3):
        for q in range(3):a.append(np.linalg.matrix_power(X,k)@np.linalg.matrix_power(Z,q))
    gram=np.array([[np.trace(u.conj().T@v) for v in a] for u in a])
    assert np.allclose(gram,3*np.eye(9),atol=1e-12)
    return '9 finite Weyl words span M3(C) by orthonormal trace basis; availability of grammar does not imply selected physical weighted source.'
test('family_matrix_operator_grammar',[159,160],'Trimer Weyl generators give End(G) without selecting physical Yukawa/source member.',t_weyl_basis)

def t_central_lift():
    x=sp.real_root(192,3)
    assert sp.simplify(x**3)==192
    # x^3 is strictly increasing for x>0, so unique positive lift.
    assert sp.diff(sp.Symbol('q',positive=True)**3,sp.Symbol('q',positive=True))!=0
    return 'Conditional positive scalar rank-3 determinant lift uniquely has x=192^(1/3); does not show K56 occurrence.'
test('positive_central_rank3_lift',[164,165],'Central rank-three lift of a determinant return 192 gives x=192^(1/3).',t_central_lift)

def t_triality_extraction():
    eps=sp.Matrix([[0,1],[-1,0]])
    assert sp.trace(eps.T*eps)==2
    def Ext(F):return sum((sp.conjugate(eps[a,b])*F[a,b] for a in range(2) for b in range(2)),sp.Integer(0))/2
    assert Ext(eps)==1 and Ext((1+sp.I)*eps)==1+sp.I
    return 'Spectator alternating form has HS norm²=2; normalized Ext_B coefficient reproduces exact complex scalar, no spurious sqrt(2) factor.'
test('signed_triality_spectator_extraction',[167,168],'The declared alternating-form coefficient extraction returns a normalized primitive Clifford factor.',t_triality_extraction,scope='Independent spectator coefficient algebra only; does not show that an occurring action must contain the extracted port.')

def t_orientation_conjugations():
    X=sp.Matrix([[0,0,1],[1,0,0],[0,1,0]])
    R=sp.diag(1,-sp.I,sp.I)
    C1=X+X.T;C2=-sp.I*(X-X.T)
    S=sp.Matrix([[1,0,0],[0,0,1],[0,1,0]])
    assert X.T==X**2 and X**3==sp.eye(3)
    assert S*X*S==X.T and S*R*S==R.conjugate().T
    assert S*C2*S==-C2
    assert S*C2.conjugate()*S==C2  # Anti-linear reversal differs from linear family reversal
    return 'Linear rooted reflection swaps X and X† and sends C2→−C2. Anti-linear reflection fixes C2 instead, so the two operations must remain typed distinctly.'
test('rooted_orientation_linear_vs_antilinear',[173,180,181],'Linear orientation reversal vs anti-linear core conjugation act differently on i and C2.',t_orientation_conjugations,kind='E3_EXACT_PLUS_E4_TYPE_CONTROL')

def t_det_orientation():
    A=sp.Matrix([[1+sp.I,2,0],[0,2-sp.I,1],[1,0,3]])
    AA=A.conjugate()
    pd=[sp.diag(2,3,4),sp.diag(1,2,5),sp.diag(6,1,2),sp.diag(3,4,1)]
    U=pd[0]*A*pd[1];D=pd[2]*AA*pd[3]
    det=sp.expand(sp.det(U*D))
    want=sp.prod(sp.det(p) for p in pd)*sp.expand(sp.det(A)*sp.conjugate(sp.det(A)))
    assert sp.simplify(det-want)==0 and det.is_positive
    return 'Full-rank positive Hermitian polar factors contribute positive determinants; conjugate roots give det(DuDd)=prod det P * |det A|² >0.'
test('rooted_quark_determinant_phase',[174,175],'Conjugate source cores with positive polar factors fix determinant phase +1.',t_det_orientation)

def t_gram_c3():
    X=sp.Matrix([[0,0,1],[1,0,0],[0,1,0]])
    I=sp.eye(3);C1=X+X.T;C2=-sp.I*(X-X.T)
    G=sp.Matrix([[sp.trace(a.conjugate().T*b) for b in [I,C1,C2]] for a in [I,C1,C2]])
    assert G==sp.diag(3,6,6)
    return 'Three Hermitian source-cell ports are pairwise trace-orthogonal, norms²=3,6,6.'
test('c3_three_port_hs_gram',[176,177,178],'Exact C3 port linear independence and Hilbert–Schmidt Gram.',t_gram_c3)

def t_c3_basis():
    X=sp.Matrix([[0,0,1],[1,0,0],[0,1,0]])
    C1=X+X.T;C2=-sp.I*(X-X.T)
    assert sp.simplify((C1+sp.I*C2)/2-X)==sp.zeros(3)
    assert sp.simplify((C1-sp.I*C2)/2-X.T)==sp.zeros(3)
    assert X**3==sp.eye(3)
    return 'Invertible even/odd ↔ cyclic basis change exact; X†=X^-1, one cell with three presentations.'
test('c3_cyclic_transport_change_of_basis',[179,183],'The source cell basis (I,C1,C2) equals (I,X,X^-1).',t_c3_basis)

def t_reflection_orbit():
    X=sp.Matrix([[0,0,1],[1,0,0],[0,1,0]])
    for c in range(3):
        S=sp.zeros(3)
        for k in range(3):S[(c-k)%3,k]=1
        assert S*S==sp.eye(3)
        assert S*X*S==X.T
    return 'All three rooted trimer reflections exchange X and X^-1, fixing I; inversion-orbit partition sizes 1+2.'
test('trimer_reflection_inversion_orbits',[180,181],'For each S_c e_k=e_{c-k}, S_c X S_c^-1=X^-1.',t_reflection_orbit)

def t_antilinear_spectra():
    T=np.array([[1+2j,1,0],[2j,3,2],[0,1j,4-1j]],complex)
    S=np.array([[1,0,0],[0,0,1],[0,1,0]],complex)
    Tc=S@T.conjugate()@S.T
    lhs=Tc.conj().T@Tc
    rhs=S@(T.conj().T@T).conjugate()@S.T
    assert np.allclose(lhs,rhs)
    assert np.allclose(np.linalg.svd(T,compute_uv=False),np.linalg.svd(Tc,compute_uv=False))
    return 'Explicit antiunitary map preserves Hermitian mass singular spectrum; physical particle IDs require a separate representation/occurrence match.'
test('antilinear_mass_spectrum_equality',[181,182],'Antiunitary conjugation leaves singular values invariant.',t_antilinear_spectra)

def t_zero_port_firewall():
    P=sp.Matrix([[1,0],[0,-1]])
    s=sp.symbols('s'); q=s*P
    assert P!=sp.zeros(2) and q.subs(s,0)==sp.zeros(2)
    return 'Nonzero normalized port P with allowed zero scalar member s=0 demonstrates logical necessity of independent ReqOut/nonzero occurrence certificate.'
test('nonzero_source_port_not_source_value',[188,189,190],'A nonzero operator port alone does not imply a nonzero selected source member.',t_zero_port_firewall,kind='E4_ANTECEDENT_CONTROL',scope='Logical negative test applies only where zero is compatible with all frozen relations; not a counterexample to a separately proven required output.')

def t_missing_port_placement():
    eta=sp.Rational(24,25); t=sp.sqrt(eta)
    # Same comparison geometry allows either common or relative chiral leg frames.
    expected={'same':sp.Integer(1),'relative':t}
    assert expected['same']!=expected['relative']
    return 'Same geometric 24/25 supplies both same-frame (factor 1) and relative-frame (sqrt(24/25)) normalized source maps; only an action leg-placement selects between them.'
test('same_vs_relative_chiral_placement',[144,147,148],'Physical comparison factor cannot be fixed from the scalar exclusion expectation without the same-action source leg assignments.',t_missing_port_placement,kind='E4_MISSING_ANTECEDENT_CONTROL')

record={
    'artifact':'Paper5A-Batch4ExactChecks-v1_1.json',
    'source':SRC.name,'source_sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),
    'scope':'Only P5A-142 through P5A-191 and named imported conditional source statements; exact scoped algebra, not physical constructor/action proof.',
    'checks':out,'pass_count':sum(bool(t['pass_bool']) for t in out),'total':len(out),
    'all_pass':all(t['pass_bool'] for t in out),'disclaimer':'E3/E4 independent calculations are scoped finite evidence; physical occurrence and GP2 required-output remain separate obligations.'
}
(ROOT/'Paper5A-Batch4ExactChecks-v1_1.json').write_text(json.dumps(record,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'pass':record['pass_count'],'total':record['total'],'failed':[t['test']+' '+t['details'][:200] for t in out if not t['pass_bool']]},indent=2))
if not record['all_pass']:raise SystemExit(1)
