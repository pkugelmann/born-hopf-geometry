#!/usr/bin/env python3
"""Claim-matched Paper V-A Batch 3 finite algebra checks, NOT an occurrence certificate.
Only examines source P5A-093 through P5A-141; no framework development.
"""
from __future__ import annotations
import json, math
from fractions import Fraction
from pathlib import Path
import sympy as s
import numpy as np
from sympy import I, Matrix, Rational as R, eye, zeros

results=[]
def test(name, claims, statement, fn, kind='E3_EXACT'):
    try:
        detail=fn(); passed=detail is not False
        assert passed
        results.append(dict(test=name,claims=claims,kind=kind,statement=statement,pass_bool=True,details=str(detail)))
    except Exception as ex:
        results.append(dict(test=name,claims=claims,kind=kind,statement=statement,pass_bool=False,details=str(type(ex).__name__)+':'+str(ex)))

# P5A-093: traceless block scalar line

def splitter():
    assert Matrix([[3,1]]).nullspace()==[Matrix([R(-1,3),1])]
    b=Matrix.diag(R(1,3),R(1,3),R(1,3),-1)
    assert s.trace(b)==0 and b.rank()==4
    return 'kernel(3a+b) 1D; B-L diag(1/3,1/3,1/3,-1) traceless'
test('traceless_BminusL_line',['P5A-093'],'one-dimensional traceless 3+1 block scalar splitter',splitter)

# P5A-094: full su4 real basis and global kernel

def su4():
    # 6 anti-real off-diag plus 6 imaginary symmetric off-diag + 3 diagonal
    basis=[]
    for i in range(4):
      for j in range(i+1,4):
        A=zeros(4); A[i,j]=1;A[j,i]=-1
        B=zeros(4); B[i,j]=I;B[j,i]=I
        basis.extend([A,B])
    for i in range(3):
      A=zeros(4);A[i,i]=I;A[3,3]=-I
      basis.append(A)
    M=Matrix.hstack(*[Matrix(16,1,list(a)) for a in basis]); assert M.rank()==15
    # center on (2,1,4) + (1,2,4): signs in Z2 x Z2, z4 in roots of unity
    kernel=[]
    for l in [-1,1]:
      for r in [-1,1]:
        for z in [1,I,-1,-I]:
          if l*z==1 and r*z==1: kernel.append((l,r,z))
    assert kernel==[(1,1,1),(-1,-1,-1)] or set(kernel)=={(1,1,1),(-1,-1,-1)}
    return '15 traceless anti-Hermitian generators; joint center kernel exactly {(+,+,+),(-,-,-)}'
test('su4_offdiagonal_parent_closure',['P5A-094'],'conditional full off-diagonal + split stabilizer span su(4) with faithful diagonal Z2 quotient',su4)

# P5A-096-098: B commutes with all block-diagonal SU3/quark and weak; offdiagonal breaks

def baryon():
    B=Matrix.diag(R(1,3),R(1,3),R(1,3),0)
    X=Matrix([[0,2+I,0,0],[-2+I,0,0,0],[0,0,I,0],[0,0,0,0]])
    Y=zeros(4);Y[0,3]=1;Y[3,0]=-1
    assert B*X-X*B==zeros(4)
    assert B*Y-Y*B!=zeros(4)
    C=zeros(4);C[3,3]=3
    assert B*C-C*B==zeros(4)
    return 'all sector-preserving generators commute with B, explicit SU4 offblock does not; lepton pair has B=0'
test('split_baryon_vertex_commutant',['P5A-096','P5A-097','P5A-098'],'B conservation within declared split-phase vertex algebra only',baryon)

# P5A-099 Haar projector finite group example

def haar():
    omega=s.exp(2*s.pi*I/3)
    w=-R(1,2)+s.sqrt(3)*I/2
    g=Matrix.diag(1,w,w**2)
    avg=(eye(3)+g+g*g)/3
    assert s.simplify(avg-Matrix.diag(1,0,0))==zeros(3)
    assert s.simplify(avg*avg-avg)==zeros(3)
    return 'Z3 exact average diag(1,0,0); nontrivial irreducible lines killed'
test('haar_reynolds_invariant_projection',['P5A-099'],'normalized Haar average is the invariant orthogonal projector',haar)

# P5A-101-102: 6 eigenvalue plane; one-field constraints leave 3 params

def abelian():
    # order L ell, L C, + ell, + C, - ell, - C
    C=Matrix([[1,0,0,0,1,0],[0,1,0,0,0,1],
              [1,0,-1,0,0,0],[-1,0,0,0,1,0]])
    # more robust equations impose (xLe-x-e)+(xLe-x+e)=0 etc and equal weights
    A=Matrix([[2,0,-1,0,-1,0],[0,2,0,-1,0,-1],
              [1,-1,-1,1,0,0]])
    assert A.rank()==3
    ones=Matrix([1]*6)
    t=Matrix([0,0,R(1,2),R(1,2),R(-1,2),R(-1,2)])
    bl=Matrix([-1,R(1,3),-1,R(1,3),-1,R(1,3)])
    N=Matrix.hstack(ones,t,bl)
    assert A*N==zeros(3,3) and N.rank()==3
    pL=Matrix([1,1,0,0,0,0]); assert Matrix.hstack(N,pL).rank()==4
    return 'nullity 3 spanned by 1,T_R^3,B-L; P_L independent modulo identity'
test('one_field_six_block_abelian_plane',['P5A-101','P5A-102'],'6D diagonal centralizer and 3D one-field opposite-weight plane',abelian)

# P5A-103-104: ranks and gauge characters

def projectors():
    ph=Matrix.diag(1,0,0); pc=Matrix.diag(1,*([0]*9))
    A=s.kronecker_product(ph,eye(10));B=s.kronecker_product(eye(3),pc)
    assert A*B==B*A and s.trace(A*B)==1
    a,b=s.symbols('a b')
    assert s.solve(a-2*b,a)==[2*b]
    return 'Sym²W_R* dimension3, Sym²Q* dimension10, joint rank1, character a-2b'
test('commuting_hopf_color_character',['P5A-103','P5A-104'],'two factor projections commute; joint projected line has rank 1; Y kernel a=2b',projectors)

# P5A-105-106: SU2 weak source stabilizer arbitrary frame

def ew():
    t=R(3,5);v=s.sqrt(1-t*t)
    H=Matrix([t,I*v]);Ht=Matrix([s.conjugate(H[1]),-s.conjugate(H[0])]);U=Matrix.hstack(Ht,H)
    sz=Matrix([[1,0],[0,-1]]);sx=Matrix([[0,1],[1,0]]);sy=Matrix([[0,-I],[I,0]])
    assert s.simplify(U.H*U-eye(2))==zeros(2)
    assert s.simplify(U.det()-1)==0
    T=U*(sz/2)*U.H
    n=[-s.expand((H.H*q*H)[0]) for q in (sx,sy,sz)]
    assert s.simplify(T-sum((n[i]*q/2 for i,q in enumerate((sx,sy,sz))),zeros(2)))==zeros(2)
    # charge slots force x3=b
    x,b=s.symbols('x b')
    for lhs,rhs in ((x/2+b/6,2*b/3),(-x/2+b/6,-b/3),(x/2-b/2,0),(-x/2-b/2,-b)):
      assert s.solve(lhs-rhs,x)==[b]
    return 'unit H=(3/5,4i/5), U in SU2, rotated Cartan from Bloch vector; each allowed slot enforces x3=b'
test('rotated_ew_solder_stabilizer',['P5A-105','P5A-106'],'stabilizer is frame-conjugate span(T_L^3+Y) for nonzero typed slot',ew)

# P5A-107: positive quartic if assumed strictly quartic stability

def doublet():
    a,b=s.symbols('a b',positive=True)
    H=Matrix([a,b*I]);r2=(H.H*H)[0]
    q=s.symbols('q',real=True)
    assert s.simplify(((q*H).conjugate().T*(q*H))[0]-q*q*r2)==0
    return 'SU2 acts transitively on fixed doublet norm; quartic polynomial in H†H; positivity of quartic coefficient remains a separately stated stability condition'
test('single_doublet_invariant_scope',['P5A-107'],'one-doublet invariant polynomial generated by norm; boundary quartic positivity requires stated stability meaning',doublet)

# P5A-109-110: exact anomaly coefficients (3 families)
def anomalies():
    tab=[(6,R(1,6),R(1,3),0),(2,-R(1,2),0,1),(3,-R(2,3),-R(1,3),0),(3,R(1,3),-R(1,3),0),(1,1,0,-1),(1,0,0,-1)]
    sY=sum(dim*y for dim,y,_,__ in tab);sY3=sum(dim*y**3 for dim,y,_,__ in tab)
    assert sY==0 and sY3==0
    for which,w2,wy2 in ((2,R(3,2),-R(3,2)),(3,R(3,2),-R(3,2)),(4,0,0)):
      xB=1 if which==2 else (0 if which==3 else 1)
      xL=0 if which==2 else (1 if which==3 else -1)
      ww=3*(3*xB*R(1,3)+xL)*R(1,2)
      yy=3*sum(dim*(xB*B+xL*L)*y*y for dim,y,B,L in tab)
      assert ww==w2 and yy==wy2
    assert 3*R(1,6)*R(1,2)-R(1,2)*R(1,2)==0
    assert 2*R(1,6)*R(1,2)-R(2,3)*R(1,2)+R(1,3)*R(1,2)==0
    assert 4%2==0
    return 'per generation U1^3 and grav²U1 vanish; across 3 generations B/L SU2²=3/2, Y²=-3/2, B-L zero; 4 weak doublets/generation even'
test('exact_chiral_anomaly_coefficients',['P5A-109','P5A-119'],'generated slot table B,L,B-L and perturbative SM anomaly coefficients',anomalies)

# P5A-111-114: parallel transport on flat trivial holonomy; Jacobi phase

def phases():
    t=s.symbols('t',real=True)
    Du=Matrix([[s.exp(I*t),0],[0,2]])
    Dd=Matrix([[3,0],[0,s.exp(-I*t)]])
    f=s.expand(s.simplify(s.det(Du*Dd)));assert f==6
    deriv=s.simplify(s.trace(Du.inv()*Du.diff(t)+Dd.inv()*Dd.diff(t)))
    assert deriv==0
    # reference unit vector in trivial line, phase gauge alpha multiplies both endpoints
    z0,z1,theta=s.symbols('z0 z1 theta')
    assert s.simplify((s.exp(I*theta)*z1)/(s.exp(I*theta)*z0)-z1/z0)==0
    return 'Jacobi derivative zero for conjugate determinant phases, reference-line phase cancels from transport ratio; not a native quantum measure proof'
test('determinant_phase_jet',['P5A-111','P5A-113','P5A-114'],'parallel line reference phase and exact determinant-phase derivative under full rank',phases)

# P5A-115-118: parity and spin sign algebra

def signlines():
    cls=[(a,b) for a in (0,1) for b in (0,1)]
    fixed=[x for x in cls if x==(x[1],x[0])]
    assert fixed==[(0,0),(1,1)]
    # sign tensor absorbs K2 sign with Z2 quotient
    elems=[(sg,ep) for sg in (0,1) for ep in (0,1)]
    hom=lambda sg,ep:(sg+ep)%2
    ker=[(sg,ep) for sg,ep in elems if hom(sg,ep)==0]
    assert ker==[(0,0),(1,1)]
    return 'H1(T²;Z2)=Z2² four classes; exchange fixed diagonal two; spin x K2 diagonal sign quotient map has kernel {(0,0),(1,1)}'
test('quadratic_sign_class_and_spin_absorption',['P5A-115','P5A-116','P5A-118'],'quadratic line sign parities and diagonal spin-sign absorption on common tensor role',signlines)

# P5A-117 evenness of squared determinant line; avoid torsion issue as M8 H2 is free

def parity():
    d,k=s.symbols('d k',integer=True)
    assert s.solve(-2*d+k,k)==[2*d]
    assert all(2*d0!=k0 for d0 in range(-20,21) for k0 in range(-19,20,2))
    return 'c1(N*²)=-2c1(N); nonzero N*²⊗P^k iff k=2d; no odd k'
test('determinant_line_even_class',['P5A-117'],'primitive class parity and nonzero quadratic tensor section condition',parity)

# P5A-120-121: exact four block family coefficient extraction

def diracfamily():
    Y=[Matrix([[i+2,1,0],[0,i+3,2],[0,0,i+4]]) for i in range(4)]
    slots=Matrix.diag(*[eye(3) for _ in range(4)])
    # Instead of assuming one physical action, check inverse block direct-sum bijection
    D=zeros(12)
    for j,Yj in enumerate(Y):D[3*j:3*j+3,3*j:3*j+3]=Yj
    recovered=[D[3*j:3*j+3,3*j:3*j+3] for j in range(4)]
    assert recovered==Y
    assert len(Y)==4
    aY=3*s.trace(Y[0].H*Y[0])+3*s.trace(Y[1].H*Y[1])+s.trace(Y[2].H*Y[2])+s.trace(Y[3].H*Y[3])
    bY=3*s.trace((Y[0].H*Y[0])**2)+3*s.trace((Y[1].H*Y[1])**2)+s.trace((Y[2].H*Y[2])**2)+s.trace((Y[3].H*Y[3])**2)
    assert aY>0 and bY>0
    return 'four orthogonal End(G) slots uniquely invertible (4 x M3C), color trace weights 3,3,1,1; physical generated family separate'
test('four_slot_owner_block_inversion',['P5A-120','P5A-121','P5A-122'],'ThetaY four sector support coefficients and finite same carrier weighted trace',diracfamily)

# P5A-123: nonzero quadratic member imposes a-2b=0; no physical origin inferred

def strata():
    a,b=s.symbols('a b')
    assert s.solve(-a+2*b,a)==[2*b]
    return 'nonzero quadratic line stabilizer hypercharge; zero stratum imposes no generator relation'
test('charged_member_stabilizer_strata',['P5A-123'],'optional source member imposes conditional character kernel only',strata)

# P5A-125-127: D4 rooted primitive finite operator exact unitarity + block readout

def primitive():
    H=Matrix([R(3,5),R(4,5)*I]);U=Matrix.hstack(Matrix([s.conjugate(H[1]),-s.conjugate(H[0])]),H)
    assert s.simplify(U.H*U-eye(2))==zeros(2)
    # Root unit Clifford map on 2D weak chiral and 4x3 internal/family
    T=s.kronecker_product(U,eye(12)); Z=zeros(24)
    D=Matrix.vstack(Matrix.hstack(Z,T),Matrix.hstack(T.H,Z))
    assert s.simplify(D*D-eye(48))==zeros(48)
    assert D.rank()==48
    return 'unit rooted Clifford factor tensored with I_Q⊗I_G: 48x48 odd Hermitian square identity; no physical ReqOut checked'
test('rooted_primitive_unitarity',['P5A-125','P5A-126','P5A-127'],'unitary c(h*) and full-rank dagger-completed primitive operator',primitive)

# P5A-128,136,139: algebraic local jet normalization only (not physical handoff)
def localjet():
    c=R(9,4); D=Matrix([[0,1+I], [1-I,0]])
    norm=s.simplify((c*eye(2))**R(-1,2)*(c*D)*(c*eye(2))**R(-1,2))
    assert norm==D
    return 'Z_L=Z_R=cI, Djet=cD yields normalized D exactly; required-output/occurrence remains a separate antecedent'
test('uninserted_fermion_jet_normalization',['P5A-128','P5A-136','P5A-139'],'Paper III-F conditional uninserted common kinetic/source scalar cancels',localjet)

# P5A-132-141: packet synthesis linearity and noninjective scalarization distinction

def charged():
    Deta=Matrix.diag(1,-1,1)
    A=Matrix([[1,0,2],[0,0,0],[0,0,0]]);B=Matrix([[0,3,0],[0,1,0],[0,0,0]])
    m0,m1=R(2),R(5)
    chi=lambda X:Deta*X*Deta
    Rp=m0*A+m1*B
    Wp=m0*chi(A)+m1*chi(B)
    assert chi(Wp)==Rp
    assert Rp.rank()<3
    # mass coefficients 2,5 are not eigen/singular values of a rank-deficient 3x3 return
    return 'chi^{-1}=chi and chi(sum mW)=sum m chi(W); rank-deficient return may coexist with nonzero prescribed masses; no source occurrence inferred'
test('charged_sibling_packet_linear_synthesis',['P5A-132','P5A-133','P5A-135','P5A-136','P5A-138','P5A-139','P5A-140','P5A-141'],'same-root paired incidence and mass coefficients assemble linearly on conditional certified-arrow domain',charged)

out={'artifact':'Paper5A-Batch3ExactChecks-v1_1.json','batch_span':['P5A-093','P5A-141'],
  'source':'Paper5A-FiniteMatterGeometry-v3_202.tex','checks':results,
  'pass_count':sum(x['pass_bool'] for x in results),'total':len(results),
  'all_pass':all(x['pass_bool'] for x in results),
  'warning':'Scope-limited finite controls only; source-claimed G0 physical owner/source occurrence, native gauge regulator, and actual Cert_hier not independently established.'}
path=Path('/mnt/data/Paper5A-Batch3ExactChecks-v1_1.json');path.write_text(json.dumps(out,indent=2))
for x in results:print(('PASS' if x['pass_bool'] else 'FAIL'),x['test'],x['details'][:160])
print('summary:',out['pass_count'],'/',out['total'])
if not out['all_pass']:raise SystemExit(1)
