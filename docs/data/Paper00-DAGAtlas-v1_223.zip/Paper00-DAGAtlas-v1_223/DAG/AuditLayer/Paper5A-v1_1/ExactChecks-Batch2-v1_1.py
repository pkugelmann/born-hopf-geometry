"""Paper V-A batch 2 independently checkable finite-algebra controls.
Only scope-matched identities are proved; geometric/physical origin claims are NOT settled by finite examples.
"""
import json, hashlib, pathlib
import numpy as np
import sympy as s
OUT=pathlib.Path('/mnt/data/p5a_workspace/Paper5A-Batch2ExactChecks-v1_1.json')
results=[]
def check(name, claims, statement, ok, details, control_type='E3_EXACT'):
    results.append(dict(test=name, claims=claims, statement=statement, pass_bool=bool(ok), details=str(details), kind=control_type))
    if not ok: raise AssertionError(f'FAIL: {name}: {details}')

# Fierz commutant of 2+2 inequivalent external left/right SU2 Weyl blocks
pauli=[s.Matrix([[0,1],[1,0]]), s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
Mvars=s.symbols('z0:16'); M=s.Matrix(4,4,Mvars)
Gleft=[s.diag(*([0]*4)) for _ in range(3)]
C=[]
for p in pauli:
    L=s.diag(1,1,1,1);L[:2,:2]=p; L[2:,2:]=s.zeros(2)
    R=s.zeros(4);R[2:,2:]=p
    C.extend(list(M*L-L*M));C.extend(list(M*R-R*M))
A=s.linear_eq_to_matrix(C,Mvars)[0]
check('protected_schur_commutant','P5A-045','End_Spin4(W)=C⊕C Γ5',A.rank()==14,'rank of 48x16 commutator constraints = '+str(A.rank()))

# Exact projective Hopf weight condition
x,y=s.symbols('a b',real=True)
check('hopf_l0_character','P5A-044,P5A-056,P5A-089','q(L0)=a/2-b; quadratic character -a+2b; kernel b=a/2',s.simplify(-2*(x/s.Integer(2)-y)-(-x+2*y))==0,'character correct; physical projection not tested')

# Case-specific heat arithmetic, not physical vacuum
rank=s.Matrix([4,48,12,192]); w=s.Matrix([s.Rational(1,2),s.Rational(1,2),-1,-s.Rational(1,4)])
check('graded_matter_a0_a2','P5A-049','a0=-34, geometry a2=0 and Higgs mass a2=4 Lambda²', sum(rank[i]*w[i] for i in range(4))==-34 and -2-2+4==0 and 4*s.Rational(1,2)*2==4,'ranks and determinant weights checked')

# Core/family commutant and SM charge values
rng=np.random.default_rng(20261112)
core=rng.normal(size=(4,4))+1j*rng.normal(size=(4,4)); X=np.roll(np.eye(3),1,axis=0)
check('core_family_tensor_commutation','P5A-052','[A⊗1,1⊗X]=0',np.allclose(np.kron(core,np.eye(3))@np.kron(np.eye(4),X),np.kron(np.eye(4),X)@np.kron(core,np.eye(3))), '12x12 exact tensor actions (floating cross-check)')
charges={'Q_L':s.Rational(1,6),'L_L':-s.Rational(1,2),'u_R':s.Rational(2,3),'d_R':-s.Rational(1,3),'nu_R':0,'e_R':-1}
actual={'Q_L':s.Rational(1,2)*s.Rational(1,3),'L_L':-s.Rational(1,2),'u_R':s.Rational(1,2)+s.Rational(1,6),'d_R':-s.Rational(1,2)+s.Rational(1,6),'nu_R':s.Rational(1,2)-s.Rational(1,2),'e_R':-s.Rational(1,2)-s.Rational(1,2)}
check('six_sector_charge_table','P5A-053','six SM charge sectors follow Y=T_R3+(B-L)/2',actual==charges,f'weights={actual}')

# P5A-063 mixed-current trace and commutator. 
q,_=np.linalg.qr(rng.normal(size=(3,3))+1j*rng.normal(size=(3,3)))
r,_=np.linalg.qr(rng.normal(size=(3,3))+1j*rng.normal(size=(3,3)))
A3=q@np.diag([1.,2.,5.])@q.conj().T;B3=r@np.diag([3.,7.,11.])@r.conj().T
Pu=np.diag([1.,0.]); Pd=np.diag([0.,1.]);Tplus=np.array([[0.,1.],[0.,0.]])
Ag=np.kron(Pu,A3);Bg=np.kron(Pd,B3);Tp=np.kron(Tplus,np.eye(3));Tm=Tp.conj().T
err=0.
for p in range(3):
 for qq in range(3):
    val=np.trace(np.linalg.matrix_power(Ag,p)@Tp@np.linalg.matrix_power(Bg,qq)@Tm)
    ref=np.trace(np.linalg.matrix_power(A3,p)@np.linalg.matrix_power(B3,qq))
    err=max(err,abs(val-ref))
C1=Ag@(Tp@Bg@Tm)-(Tp@Bg@Tm)@Ag
C2=A3@B3-B3@A3
err=max(err,abs(np.trace(C1@C1@C1)-np.trace(C2@C2@C2)))
check('same_carrier_mixed_current','P5A-063','9 traces and commutator cube coincide on same G',err<1e-9,f'max error {err:.3g}')

# Neutral regular-module incidence: cycle-permutation matrix Wν.
g0=np.array([1.,0.,0.]);Wnu=np.column_stack([np.linalg.matrix_power(X,2)@g0,X@g0,g0])
check('neutral_three_role_unitarity','P5A-065','Wν=(g2,g1,g0) unitary',np.allclose(Wnu.conj().T@Wnu,np.eye(3)),f'Wν={Wnu.astype(int).tolist()}')

# Native current polar factors, four moments, CP sign frame class, Stieltjes residues
Eu=rng.normal(size=(3,3))+1j*rng.normal(size=(3,3)); Ed=rng.normal(size=(3,3))+1j*rng.normal(size=(3,3))
def Wpolar(E):
    zz=E.conj().T@E;z,vec=np.linalg.eigh(zz)
    return E@(vec@np.diag(1/np.sqrt(z))@vec.conj().T)
Wu=Wpolar(Eu);Wd=Wpolar(Ed);Cud=Wu.conj().T@Wd
check('quark_polar_current_unitary','P5A-066','W_s=E_s(E_s†E_s)^−1/2, Cud=Wu†Wd unitary on full rank domain',np.allclose(Cud.conj().T@Cud,np.eye(3),atol=1e-12),f'detZu={np.linalg.det(Eu.conj().T@Eu):.3g} detZd={np.linalg.det(Ed.conj().T@Ed):.3g}')
Du=np.diag([1.,4.,9.]);Dd=np.diag([2.,3.,7.]); PuCur=np.abs(Cud)**2; Vu=np.vstack([np.diag(Du)**p for p in range(3)]);Vd=np.vstack([np.diag(Dd)**p for p in range(3)]);Mom=np.array([[np.trace(np.linalg.matrix_power(Du,p)@Cud@np.linalg.matrix_power(Dd,qq)@Cud.conj().T) for qq in range(3)] for p in range(3)])
precon=np.linalg.solve(Vu,Mom)@np.linalg.inv(Vd.T)
check('quark_vandermonde_4plus_cp','P5A-069,P5A-070','9 moment matrix reconstructs |Cud_ij|², only 4 mixed are independent',np.max(np.abs(precon-PuCur))<1e-11 and np.allclose(PuCur.sum(axis=0),np.ones(3)) and np.allclose(PuCur.sum(axis=1),np.ones(3)),f'max difference {np.max(np.abs(precon-PuCur)):.3g}; 5 single-sector constraints fixed by unitarity')
phaseL=np.diag(np.exp(1j*np.array([0.12,0.87,1.22])));phaseR=np.diag(np.exp(1j*np.array([0.56,1.11,-.36])));C2=phaseL@Cud@phaseR
M11=lambda cc: np.trace(Du@cc@Dd@cc.conj().T)
def jcur(cc):
    comm=Du@cc@Dd@cc.conj().T-cc@Dd@cc.conj().T@Du
    return np.trace(comm@comm@comm)/(6j)
check('quark_rephasing_invariants','P5A-069,P5A-070','Mixed trace and CP test unchanged under left/right role phases',abs(M11(Cud)-M11(C2))<1e-10 and abs(jcur(Cud)-jcur(C2))<1e-10 and abs(jcur(Cud).imag)<1e-10,f'CP-odd χ={jcur(Cud).real:.7g}')
z,w=s.symbols('z w'); xx=[1,4,9]; yy=[2,3,7];F=s.Add(*[s.Rational(1,3)/((z+xi)*(w+yj)) for xi in xx for yj in yy]); res_ok=all(s.simplify(s.residue(s.residue(F,z,-xi),w,-yj)-s.Rational(1,3))==0 for xi in xx for yj in yy)
check('current_double_stieltjes_residues','P5A-071','9 exact rational double residues reconstruct P_ij',res_ok,'exact symbolic residues of Fourier-current P_ij=1/3')

# Charged lepton restricted negative Hopf relation.
Rminus=np.diag([1.,1j,-1j]); v=np.ones(3,dtype=complex)/np.sqrt(3); Q0=np.outer(v,v.conj());Qperp=np.eye(3)-Q0; muon=Qperp@Rminus@Q0;tau=Q0@Rminus@Qperp
check('negative_hopf_offdiag_ranks','P5A-075,P5A-076','Qperp R_- Q0 and Q0 R_- Qperp rank1, nonzero',np.linalg.matrix_rank(muon,tol=1e-12)==1 and np.linalg.matrix_rank(tau,tol=1e-12)==1 and np.linalg.norm(muon)>0 and np.linalg.norm(tau)>0, f'norms {np.linalg.norm(muon):.9g},{np.linalg.norm(tau):.9g}')

# Rooted symmetric M, charge, determinant and family phase
mu0=(-1+s.I)/2; R=s.diag(1,-s.I,s.I); GM=mu0*R
check('rooted_BL2_family_invariants','P5A-082','M symmetric, MM†=1/2 I, HS²=3/2, det=(1+i)/4', GM.T==GM and s.simplify(GM*GM.conjugate().T-s.eye(3)/2)==s.zeros(3) and s.simplify(s.trace(GM*GM.conjugate().T)-s.Rational(3,2))==0 and s.simplify(GM.det()-(1+s.I)/4)==0, f'det={GM.det()}')

# Type adversarial test: symmetric family M has vanishing CAR pair operator if
# naively placed on only three unstructured family modes; antisym tensor index
# from a *licensed* spin/pair support insertion would be required for fermions.
def creation(n,k):
    S=np.zeros((2**n,2**n),dtype=complex)
    for mask in range(2**n):
        if mask & (1<<k): continue
        sign=(-1)**sum((mask>>j)&1 for j in range(k))
        S[mask|(1<<k),mask]=sign
    return S
def creation_pair(delta):
    n=len(delta); crates=[creation(n,k) for k in range(n)];A=np.zeros((2**n,2**n),dtype=complex)
    for i in range(n):
      for j in range(n):A+=delta[i,j]*(crates[i]@crates[j])
    return A
GMn=np.array(GM.evalf(),dtype=complex);A3pair=creation_pair(GMn)
eps=np.array([[0,1],[-1,0]],dtype=complex)
GM6=np.kron(eps,GMn);A6=creation_pair(GM6)
check('fermionic_pair_antisymmetry_scope','P5A-085,P5A-086,P5A-089','symmetric 3x3 family matrix vanishes as a 3-mode CAR pair, epsilon⊗M yields a nonzero skew 6-mode pair',np.linalg.norm(A3pair)<1e-12 and np.allclose(GM6.T,-GM6) and np.linalg.norm(A6)>1e-8,f'||A_sym||={np.linalg.norm(A3pair):.3g}; ||A_epsilon_tensor||={np.linalg.norm(A6):.3g}; does NOT prove physical iota_pair exists', 'E4_TYPE_SCOPE')
# Canonical Q acts on each spin mode with inherited one-particle charge x/2-b.
charge=1.7/2-.3;N6=np.zeros((64,64),dtype=complex)
for k in range(6):N6+=creation(6,k)@creation(6,k).conj().T
Q=charge*N6;H=(A6+A6.conj().T)/2
errq=np.linalg.norm(Q@A6-A6@Q-2*charge*A6)
errh=np.linalg.norm(Q@H-H@Q-charge*(A6-A6.conj().T))
check('owned_pair_charge_commutators','P5A-089','[dΓX,A]=qA and [dΓX,H]=q/2(A-A†)',errq<1e-11 and errh<1e-11 and np.linalg.norm(A6@np.eye(64)[:,0])>1e-8,f'max Frobenius residuals {errq:.2g},{errh:.2g}; only a typed abstract CAR model, not K16 occurrence')

# Independent SU(2)_L x SU(2)_R Clebsch–Gordan multiplicity check for
# (1/2,1/2) coordinate times (0,1/2) right spinor into (1/2,0):
# 1/2⊗1/2 = 0⊕1 on the right, so exactly one right singlet.
t=s.symbols('t', nonzero=True)
chi_half=t+1/t
chi_tensor=s.expand(chi_half**2)
chi_spin_one=t**2+1+t**(-2)
right_singlet_mult=s.simplify(chi_tensor-chi_spin_one)
check('scalar_coordinate_clebsch_gordan','P5A-047',
      'exactly one (1/2,0) channel within (1/2,1/2)⊗(0,1/2)',
      right_singlet_mult==1,
      f'right half×half character={chi_tensor}; right spin1={chi_spin_one}; singlet multiplicity={right_singlet_mult}')

# Independent exact witness to the boundary/bulk torus firewall:
# U=(-1,1), S={0}, f is a smooth bump in (1/3,2/3), zero on S and
# nonzero at x=1/2. Smoothness of the standard flat-endpoint bump is
# a standard analytic fact, not tested by a finite array.
xn=s.symbols('x',real=True)
a=s.Rational(1,3);b=s.Rational(2,3)
ft=lambda x: s.exp(-1/((x-a)*(b-x))) if a<x<b else s.Integer(0)
status=(ft(s.Rational(0))==0 and ft(s.Rational(1,2))==s.exp(-36) and ft(s.Rational(1))==0)
check('bulk_boundary_compact_bump','P5A-090',
      'compact-support smooth torus gauge rotation equal identity on boundary S yet nontrivial inside bulk U',
      status,
      'U=(-1,1), S={0}, smooth bump supported (1/3,2/3); f(0)=0 and f(1/2)=exp(-36)>0')

OUT.write_text(json.dumps({'paper':'Paper5A-FiniteMatterGeometry-v3_202.tex','batch':2,'checks':results,'all_pass':all(x['pass_bool'] for x in results),'pass_count':sum(x['pass_bool'] for x in results),'scope':'Finite mathematical controls E3 or adversarial E4; source-generated cross-sort maps and physical occurrence require separate certificates.'},indent=2,ensure_ascii=False))
print(json.dumps({'pass_count':len(results),'checks':[r['test'] for r in results]},indent=2))
