# Paper III-G — registered current audit layer

This namespaced layer is read together with `DAG/Paper00-TheoremDAG.json` and
`DAG/CombinedGraphIndex-v1_105.json` from the release root. `AuditClaimLedger.json`
contains all 179 exactly source-located claims; `AssumptionRegistry.json` is the
source-scoped condition registry. `GapRegistry.json` has the one historical
quantifier issue. `TypedDependencyEdges.json` distinguishes traversable
material theorem/condition edges from quarantined citations and `ISSUE_AT`.
`ProofRoutes.json` supplies AND route groups; a missing alternative cannot
be silently inferred. `ImpactIndex.json` excludes unproven physical impacts.
`ProofEvidenceLedger.json` retains all 269 independently logged scoped controls.

Query `conditions(target)` by traversing only reviewed `REQUIRES` and
`IMPORTED_PROOF` edges backwards; use canonical-ID aliases for local source
labels. Query `descendants(A)` by reviewed material edges forwards. Do not
include `CANDIDATE_LINK` or `ISSUE_AT` as theorem-premise edges.

All source statements are SOURCE-AS-PRINTED; no sources rewritten.
This layer is a **source-level full audit with one open historical gap**,
not a certification of optional physical action/field occurrences.
