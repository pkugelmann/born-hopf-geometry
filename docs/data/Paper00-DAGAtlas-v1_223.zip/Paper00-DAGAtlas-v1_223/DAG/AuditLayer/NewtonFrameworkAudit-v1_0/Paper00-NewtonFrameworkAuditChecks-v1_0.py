"""Replay explicit owner-label links and normalization arithmetic against the current source tree."""
import argparse
import hashlib
import json
import re
from fractions import Fraction
from pathlib import Path

LABELS = (
    "p3:prop:EH_from_a2",
    "p3f:cor:v267-joint-eh-newton-readout",
    "p3f:prop:v2211-newton-owner-matching",
    "p1b:prop:v224-retained-primitive",
    "p5:thm:g24-raw-eh-transport",
    "p8:thm:reciprocal-position-source-normalization",
    "p8:prop:v3036-newton-physical-matching-criterion",
    "p9:rem:v3036-cosmology-newton-dependency",
)
MACROS = ("UEHjoint", "Gread", "GreadJoint")
LINK = re.compile(r"\\(label|ref|eqref|autoref|cref|Cref)\s*\{([^{}]*)\}")
MACRO = re.compile(r"\\providecommand\{\\(UEHjoint|Gread|GreadJoint)\}\{(.*)\}$")

def without_comment(line):
    """Treat the first percent preceded by an even backslash run as TeX comment."""
    for index, char in enumerate(line):
        if char == "%":
            preceding = line[:index]
            if (len(preceding) - len(preceding.rstrip("\\"))) % 2 == 0:
                return preceding
    return line

def execute(source):
    hits = {label: [] for label in LABELS}
    files = {}
    macros = {}
    for path in sorted(source.glob("*.tex")):
        if not path.name.startswith(("Paper", "Macros")):
            continue
        raw = path.read_bytes()
        lines = raw.decode("utf-8").splitlines()
        files[path.name] = {"sha256": hashlib.sha256(raw).hexdigest(), "lines": len(lines)}
        clean = "\n".join(without_comment(line) for line in lines)
        if path.name.startswith("Macros"):
            for text in clean.splitlines():
                entry = MACRO.fullmatch(text.strip())
                if entry:
                    macros.setdefault(path.name, {})[entry[1]] = entry[2]
            continue
        for match in LINK.finditer(clean):
            for label in (s.strip() for s in match[2].split(",")):
                if label in hits:
                    hits[label].append({"file": path.name, "line": clean.count("\n", 0, match.start()) + 1,
                                        "kind": match[1]})
    assert files and all(sum(row["kind"] == "label" for row in locs) == 1 for locs in hits.values())
    assert macros and all(set(m) == set(MACROS) for m in macros.values())
    assert len({tuple(sorted(m.items())) for m in macros.values()}) == 1
    # Dimensions and relative heat coefficients are common positive magnitudes.
    # Each has the same Born weight, cutoff and common loop factor in this comparison.
    scalar = Fraction(1, 6)
    joint = Fraction(4 * 48, 12)
    marked = Fraction((4 * 48) // 2, 48 * 12)
    assert joint / scalar == 96 and marked == scalar
    assert (Fraction(1, 2) / 12) / (Fraction(1, 2) / Fraction(1, 8)) == Fraction(1, 96)
    return {"method": "Scan exact TeX label and reference commands, excluding comments. Positions are literal occurrences, not evidence that a theorem proves the physical implication.",
            "checked_files": files, "exact_occurrences": hits, "macro_definitions": macros,
            "coefficient_arithmetic": {"joint_over_scalar": str(joint / scalar),
                                       "marked_over_scalar": str(marked / scalar),
                                       "raw_over_primitive_Hilbert_source_gain": "1/96"}}

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("source_tree", type=Path)
    args = parser.parse_args()
    print(json.dumps(execute(args.source_tree), indent=2, sort_keys=True))
