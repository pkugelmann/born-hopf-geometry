"""Verify the framework-wide Newton census against the supplied current TeX ZIP.

Pass Paper00-PapersMinimal-v3_036.zip followed by an optional output path.
Only paper TeX sources are searched. Regex counts are navigation aids, never proof.
"""
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import argparse
import json
import re
import zipfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("papers", type=Path)
parser.add_argument("output", type=Path, nargs="?")
args = parser.parse_args()
def digest(data):
    return sha256(data).hexdigest()

terms = {
    "Newton_or_Planck_language": r"Newton|Planck|\\Gread\b|\\GreadJoint\b",
    "EH_or_curvature_normalization": r"Einstein.{0,3}Hilbert|\\UEHjoint|\\Lambda_\{\\rm EH\}|\\kappa_J",
    "momentum_cell_or_shell_scale": r"CELL.{0,15}K\\to U|momentum.{0,4}curvature|24\\sqrt\{3\\pi\}|E_0=\\hbar|Rmom=6",
    "source_and_exchange": r"Hilbert.{0,8}(stress|tensor|source)|massless.{0,16}(tensor|pole)|source.{0,12}exchange|source.{0,12}normaliz",
    "absolute_physical_or_mass_calibration": r"\\overline M_\{\\rm Pl\}|M\^2(?:\s*:?=\s*)U/4|Newton.{0,18}(measur|observ|metrol|calibr)|(?:measur|observ).{0,18}Newton",
}
regexes = {k:re.compile(v,re.I) for k,v in terms.items()}
roots = ["p3f:prop:v2211-newton-owner-matching","p5:thm:g24-raw-eh-transport",
         "p1b:prop:v224-retained-primitive","p3e:thm:v346-cell-scale-independence",
         "p8:thm:reciprocal-position-source-normalization","p8:prop:v3036-newton-physical-matching-criterion",
         "p3e:prop:v2211-whole-action-newton-certificate","p3f:prop:v1165-scalar-dirac-heat-mismatch"]
token=r"\\(?:eqref|ref|cref|Cref|autoref|pageref)\s*\{([^}]+)\}"
papers = []
anchors = {}
literal_uses = {root:[] for root in roots}
tag_uses = []
with zipfile.ZipFile(args.papers) as z:
    members = sorted(n for n in z.namelist() if re.fullmatch(r"Paper[1-7][A-G]-.+\.tex",Path(n).name))
    for name in members:
        data = z.read(name)
        lines = data.decode("utf8").splitlines()
        counts = Counter()
        windows = {k:[] for k in terms}
        for i,source in enumerate(lines,1):
            line = re.split(r"(?<!\\)%",source,1)[0]
            for k,term in regexes.items():
                if term.search(line):
                    counts[k] += 1
                    windows[k].append(i)
            for label in re.findall(r"\\label\{([^}]+)\}",line):
                if label in roots:
                    assert label not in anchors
                    anchors[label] = [name,i]
            for group in re.findall(token,line):
                for key in group.split(","):
                    key=key.strip()
                    if key in literal_uses:
                        literal_uses[key].append([name,i])
            if r"\mathrm{MATCH}_{J/\mathrm{scal}}^{\rm EH}" in line:
                tag_uses.append([name,i])
        papers.append(dict(source=name,sha256=digest(data),lines=len(lines),
                          matching_lines={k:counts[k] for k in terms},lines_by_search=windows))
assert len(papers)==31 and len(anchors)==len(roots)
assert len(tag_uses)==4
# Heat densities before the common 1/[8(4pi)^2], for unit R in a2.
scalar = [F(1),F(1,6)]
marked = [F(2),-F(2,12)]
ordinary = [F(192),-F(192,12)]
assert abs(ordinary[1]/marked[1])==96 and abs(marked[1])==scalar[1]
# S^3_a x S^1 with a=1. R=6, Ric^2=Riem^2=12, C^2=Euler=0.
R,ric,riem=6,12,12
Weyl = riem-2*ric+F(R*R,3)
Euler = riem-4*ric+R*R
assert Weyl==Euler==0
a4_scalar=(5*R*R+3*Weyl-Euler)/360
a4_marked=(-18*Weyl+11*Euler)/720
assert a4_scalar==F(1,2) and a4_marked==0
# Natural units hbar=c=1; pi-dependent constants split explicitly.
for n in (1,96):
    # At CELL, U Rmom^2 =18/pi; G_n U=1/(2pi n).
    assert F(1,2*n)*F(1,18)==F(1,36*n)
    # Dimensionless shell diagnostic 2pi G_n E0².
    assert 2*F(1,2*n)==F(1,n)
assert F(1,3456)*96==F(1,36)
record = dict(scope="Whole-corpus text census plus exact bounded checks. A literal reference, a count and a hash are not proof edges.",
              release_sha256=digest(args.papers.read_bytes()),papers=papers,
              searches=terms,anchor_definitions=anchors,explicit_label_uses=literal_uses,
              reused_raw_and_physical_match_notation=tag_uses,
              paper_count=len(papers),total_lines=sum(p["lines"] for p in papers),
              calculations={"heat_a0_a2_scalar":list(map(str,scalar)),
              "heat_a0_a2_marked":list(map(str,marked)),"heat_a0_a2_ordinary":list(map(str,ordinary)),
              "S3xS1_scalar_a4_at_unit_radius":str(a4_scalar),"S3xS1_marked_a4_at_unit_radius":str(F(a4_marked)),
              "cell_primitive_dimensionless":str(F(1,36)),"cell_ordinary_dimensionless":str(F(1,3456))})
result=json.dumps(record,ensure_ascii=False,indent=2,sort_keys=True)+"\n"
if args.output:
    args.output.write_text(result,encoding="utf8")
else:
    print(result,end="")
