# Paper VI-C — Rigorous Verification DAG Audit, Batch 05

**Target:** `Paper6C-TechnicalMaterial-v1_43.tex` (10,448 lines; SHA-256 `95584cae4b46ce8aef588f664b2b91e1ae6e60c4703a305e720672d1fa82efbc`).
**Inputs:** `Paper00-PapersMinimal-v2_371`, `Paper00-DAGAtlas-v1_115`, `Paper00-ProofChainAudits-v1_32`; **protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md`.
**Scope:** lines **6,888–8,897**. **Next:** line **8,898**. **Formal census:** **42** constructions; **7** substantive unnamed calculation/matching groups. **Cumulative:** **215** formal statements over five batches. All 14 earlier findings `BH-VIC-G-0134`–`BH-VIC-G-0147` remain carried forward as unresolved (not re-adjudicated here).

## A. Adjudicated Batch-05 findings

### BH-VIC-G-0148 — Historical K48/RAR firewall overstates its active-branch scope (MODERATE; scope/stale import)

**Earliest source:** `p9:thm:v166-structural-bridge-rar-firewall` (VI-C **7775–7810**); repeated in `p9:thm:v167-rar-limit-readout-firewall` (**7816–7877**). The unqualified “until β48 exists” / “no galaxy curve until ...” wording is liable to be read as a current all-RAR prohibition. That conflicts with the same paper’s **7431–7437** (β48 already generated locally), **7675–7687** and **7741–7747** (native **S+T** deep-RAR closed; stronger historical **L/Calderón/G26-GLOBAL** open). The current VI-B **4153–4176** and **4183–4205** explicitly limits the copied historical chain to its optional route. **BND-01:** this is an epistemic/branch-scope contradiction in the copied firewall, *not* a refutation of the historical conditional theorem or the independent native S+T law. Its G25 original antecedent is already discharged by generated PCAD β. **Required:** use explicit historical route guard for both copied theorems and do not propagate their open premises onto native G26-DEEP.

### BH-G-000149 — Stationary axisymmetric Kerr–de Sitter exhaustiveness is not established (MODERATE; missing uniqueness domain)

**Source:** `p8:thm:scalar-frozen-compact-exterior` **8149–8173**, especially **8169–8172**. The proof correctly reduces constant-scalar, nonzero-`F` vacuum metric-`f(R)` to `Ric=(R_ext/4)g`. Its further conclusion that *the* stationary axisymmetric exterior is Kerr–de Sitter with only the mass/spin charges is not implied by Einstein-space equations without appropriate global horizon/boundary/asymptotic and regularity restrictions. **Exact E4 control:** a static axisymmetric Weyl vacuum metric with `ψ=-m/√(ρ²+z²)` and `γ=-m²ρ²/[2(ρ²+z²)²]` satisfies all three Weyl vacuum equations outside its compact source and is not locally Schwarzschild/Kerr; the constant-lapse-sphere Gaussian curvature varies with polar angle. This is a valid zero-curvature Einstein/root subcase for compatible `f(0)=0,F(0)≠0` actions, illustrating the missing inference. For the specific current nonzero curvature root, the proof still needs an actual applicable uniqueness theorem; no unverified generic metric is promoted to the native physical branch. **Positive control:** spherical Kottler and Kerr–dS as a *solution family* remain valid. **BND-02:** `E`/`R` of one Kerr metric must not be conflated with uniqueness of all stationary-axisymmetric Einstein exteriors.

### BH-G-000150 — Cited black-hole regulator reproducibility packet is absent (MODERATE; EVIDENCE_MISSING, not mathematical refutation)

**Source:** VI-C **8001–8077**, with cited programs at 8022 (`v1_9.py`), 8027 (`v1_10.py`), 8047 (`v1_11.py`) and 8071–8072 (`v1_12.json` and companion Python). These are not in the current supplied PapersMinimal v2.371 ZIP, DAG Atlas v1.115 ZIP, or mounted source inputs. The printed two-marginal first-jet solution, claimed `2×10^{-13}` Raychaudhuri residual, positivity of energy/constraints, simple-turn derivatives and sixth-degree buffer cannot be independently rerun without the actual state/ODE and coefficients. We did independently check the cancellation of the printed Raychaudhuri terms and the strict causal buffer margin `0.5−0.446275223520=0.053724776480>0.0537`. **BND-03:** exact solver/existence evidence remains pending; this is *not* evidence that the witness is false. **Required:** provide the frozen code, JSON, precise initial state/parameter packet and independent rerun/interval controls.

## B. Independently verified mathematical results (at their exact scopes)

1. **Scalaron modality classification:** The four *defined* native modes `H,L,S,T` are pairwise distinct under the declared operator/target invariants; finite-dependency structural induction proves no fifth tag can appear **within the frozen grammar**. This is a relative theorem, not global cosmic field completeness. A separate Paper-IV finite-mode interface `M` is a distinct sort. The ledger-exhaustion and ultimate physical-role imports remain partly source-level, not fully independently enumerated.
2. **Transverse boundary module:** Exact `C₂` commutant computation gives `dim Hom_{C₂}(1⊕sgn,1⊕sgn)=2`; unit-fixing alone leaves odd-flux normalization free. The upstream later-generated β48 is a distinct physical constructor, not a consequence of the two-line isomorphism. A positive-definite Hessian `H_ε=[[2,√ε],[√ε,ε]]` has `Schur=1` but quotient-first block `2`, demonstrating the source’s eliminate-before-quotient warning.
3. **Finite-collar DtN:** Direct solution of `−u″+μ²u=0` with Dirichlet/Neumann endpoints gives `μ tanh(Lμ)`, fixed-`L` expansion `Ly−L³y²/3+O(y³)` and controlled `A^{1/2} tanh(LA^{1/2})`. Independent spectral/analytic checks reproduce the **uniform absolute** error `≤1/(eL)`, but the **relative** ratio has supremum-one error for every finite L. The limits at `y↓0` and `L→∞` do not commute.
4. **Finite return:** Exact geometric expansion yields `ν_N=N+1−N(N+1)√y/2+O(y)` and `(N+1)g_b+O(g_b^{3/2})` at bounded N. The controlled unbounded limit changes its asymptotic to `√(a_*g_b)`; it is not a proof of physical unbounded return ownership. The apparent `0/0` in the rational form at `y=0` has the explicitly given finite series extension and is not filed as a gap.
5. **Scalar jet and strong-field diagnostics:** At `R=U`, `β_jet,U=Q(U−C7)/U²`; its reciprocal and conditional radius match. Independent orthonormal sectional-curvature computation of Kottler gives `Kretsch=12 r_s²/r⁶+R_ext²/6`, `Icur=R_ext²+72 χ_W²`; the Schwarzschild tidal diagnostic `r_*³=r_s R_mom²` gives proper-time `2R_mom/(3c)=4 t_P` under the paper’s normalization. Finite Kottler shells demonstrate **no** universal `U²` amplitude bound from GP1 alone.
6. **Complete four-curvature normalization:** Independent complex 4×4 Euclidean Clifford matrices reproduce `Σ_{ab}Tr(Ω_{ab}†Ω_{ab})=||Rm||²/2` for an arbitrary pair-index curvature matrix; space-form matching yields `Icur=6||Rm||_+²`. This determines the readout normalization, not a new action term, physical core radius or uniform actual-history range.
7. **Exceptional E6 response:** The current imported 72-root/6-dimensional tight-frame theorem gives Gram `12 P₆`. Independent linear algebra checks `J_{6,u}†J_{6,u}=I₆`, `||Y||_{HS}²=12||K||²`, `Icur=2||Y||²` and Schwarzschild `||Y||=6|χ_W|`; the physical amplitude limit `≤U/√2` remains explicitly conditional. The theorem is labeled `p1b:thm:exroot-response-norms` but currently **lives in Paper I-C 20170–20217** under an inline Paper-I-B source header: locator note, not a new math issue.
8. **Hopf shape and quadratic sector:** The Berger factorization `(ε²−1)(11 ε²−13)` is positive on `0<ε<1`, so the conditional budget selects `ε=1` on the declared *shape* family. It selects neither a Lorentzian core nor an areal radius. The local four-derivative quadratic metric Euler tensors vanish on constant-scalar Einstein backgrounds at the source’s scope, using the four-dimensional Euler/Gauss–Bonnet relation; independent computation of full source-dependent higher-tidal evolution is not asserted.

## C. Full formal-statement census

`E1` = source proof replay; `E2` = located owner/corrob.; `E3` = independent check of exact mathematical statement at declared conditional scope; `E4` = adversarial test. `E0_E1_FROZEN_DEFINITION` is a frozen definition, not theorem verification. High-impact physical-source/occurrence claims remain **unverified** absent external constructor/historical evidence; no simulated agents are claimed.

| # | Lines | Label | Evidence status |
|---:|---:|---|---|
| 1 | 6900–6915 | `p8:def:frozen-scalaron-response-grammar` | `E0_E1_FROZEN_DEFINITION` |
| 2 | 6917–6938 | `p8:def:internal-scalaron-representation-closure` | `E0_E1_FROZEN_DEFINITION` |
| 3 | 6940–6944 | `p8:lem:scalaron-completeness-one-root` | `E1_E2_IMPORT_LOCATED_E3_PENDING` |
| 4 | 6964–6983 | `p8:def:scalaron-response-modality` | `E0_E1_FROZEN_DEFINITION` |
| 5 | 6985–7000 | `p8:def:scalaron-native-modality-generators` | `E0_E1_FROZEN_DEFINITION` |
| 6 | 7002–7011 | `p8:def:scalaron-modality-support` | `E0_E1_FROZEN_DEFINITION` |
| 7 | 7016–7024 | `p8:prop:complete-scalaron-response-ledger` | `E1_E3_SUBCHECK_E2_IMPORT_FULL_SCOPE_PENDING` |
| 8 | 7144–7148 | `p8:lem:scalaron-native-modalities-noncollapse` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 9 | 7185–7197 | `p8:lem:scalaron-modality-support-induction` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 10 | 7256–7271 | `p8:cor:scalaron-modality-vs-readout-provenance` | `E1_E3_SUBCHECK_E2_IMPORT_FULL_SCOPE_PENDING` |
| 11 | 7285–7299 | `p8:cor:scalaron-modalities-corealization` | `E1_E3_SUBCHECK_E2_IMPORT_FULL_SCOPE_PENDING` |
| 12 | 7312–7332 | `p8:cor:scalaron-five-role-support` | `E1_E3_SUBCHECK_E2_IMPORT_FULL_SCOPE_PENDING` |
| 13 | 7348–7363 | `p8:cor:no-scalaron-triple-counting` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 14 | 7369–7389 | `p8:def:v166-zero-mode-boundary-jet` | `E0_E1_FROZEN_DEFINITION` |
| 15 | 7391–7458 | `p8:thm:v166-boundary-module-owner-criterion` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 16 | 7484–7516 | `p8:thm:v252-owner-factorized-terminal-rar` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 17 | 7518–7528 | `p8:cor:v252-terminal-load-boundary-firewall` | `E1_E2_IMPORT_LOCATED_E3_PENDING` |
| 18 | 7530–7543 | `p8:cor:v166-no-k48-transition-from-bridge` | `E1_E3_SUBCHECK_E2_IMPORT_FULL_SCOPE_PENDING` |
| 19 | 7549–7621 | `p8:thm:v167-finite-collar-dtn` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 20 | 7649–7673 | `p8:cor:v167-finite-return-relinearization` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 21 | 7675–7748 | `p8:thm:v167-critical-boundary-corealization-criterion` | `E1_E3_SUBCHECK_E2_IMPORT_FULL_SCOPE_PENDING` |
| 22 | 7775–7810 | `p9:thm:v166-structural-bridge-rar-firewall` | `E1_WITH_SCOPE_OR_PROOF_EVIDENCE_ISSUE`; BH-VIC-G-0148 |
| 23 | 7816–7877 | `p9:thm:v167-rar-limit-readout-firewall` | `E1_WITH_SCOPE_OR_PROOF_EVIDENCE_ISSUE`; BH-VIC-G-0148 |
| 24 | 8112–8147 | `p8:prop:uv-crossover-length-diagnostic` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 25 | 8149–8173 | `p8:thm:scalar-frozen-compact-exterior` | `E1_WITH_SCOPE_OR_PROOF_EVIDENCE_ISSUE`; BH-G-000149 |
| 26 | 8184–8207 | `p8:prop:kottler-weyl-tidal-growth` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 27 | 8209–8244 | `p8:cor:primitive-tidal-diagnostic-surface` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 28 | 8246–8269 | `p8:prop:strong-field-gp1-curvature-boundedness` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 29 | 8285–8325 | `p8:thm:complete-four-curvature-owner` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 30 | 8365–8391 | `p8:cor:v2181-gp1-classical-kottler-departure` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 31 | 8404–8427 | `p8:prop:v2181-arbitrary-finite-kottler-shells` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 32 | 8442–8534 | `p8:thm:v2181-e6-curvature-response-map` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 33 | 8565–8583 | `p8:cor:v2181-e6-root-range-equivalence` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 34 | 8585–8596 | `p8:rem:v2181-e6-amplitude-firewall` | `E1_SCOPE_REPLAY_ONLY` |
| 35 | 8598–8616 | `p8:cor:v2184-octahedral-determinant-balanced-e6-response` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 36 | 8618–8648 | `p8:cor:conditional-root-curvature-range` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 37 | 8650–8665 | `p8:prop:quadratic-curvature-kottler-no-go` | `E1_E3_SUBCHECK_E2_IMPORT_FULL_SCOPE_PENDING` |
| 38 | 8687–8721 | `p8:thm:strong-field-hopf-cap-rigidity` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 39 | 8741–8750 | `p8:rem:strong-field-cap-owner-firewall` | `E1_SCOPE_REPLAY_ONLY` |
| 40 | 8752–8769 | `p8:rem:strong-field-cap-hopf-ancestry-gap` | `E1_SCOPE_REPLAY_ONLY` |
| 41 | 8771–8804 | `p8:prop:conditional-exterior-breakdown-scales` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 42 | 8806–8894 | `p8:rem:strong-field-status-boundary` | `E1_WITH_SCOPE_OR_PROOF_EVIDENCE_ISSUE`; BH-G-000150 |

## D. Named and unnamed proof-source coverage

- **Mathematical/role grammar (6888–7365):** definitions, complete frozen-ledger table, noncollapse, induction proof imported to previous Batch-04 scalaron modality theorem, Paper-II loop/boundary provenance and generated-role co-realization.
- **Boundary owner (7366–7882):** `B48` C₂ module and current PCAD β, same-action Schur and terminal rank change, finite collar DtN/spectral refinement, finite return, optional historical local-L/Calderón route, VI-B historically scoped copy. All five physical-ownership conditions on that *optional* route are preserved.
- **Strong field (7883–8897):** first-jet scalar-frozen matching, Dirac memory equations and unprovided witness scripts, scalar-frozen Einstein/Kottler reduction, GP1 region-domain bound, canonical curvature readout, E6 root response and explicitly conditional amplitude, Hopf shape, and downstream scope/firewall remarks. No physical regular-collapse history proved by merely replaying the stated numerical witness.

## E. Evidence and graph staging

- **Machine ledger:** `Paper6C-RigorousAuditBatch05Evidence-v1_1.json` contains all 42 source locators, evidence levels, three issue certificates, **four** boundary-gate records, **29** reviewed direct dependency edges, twelve staging condition predicates, and negative/rejected challenge records.
- **Independent executable:** `Paper6C-Batch05-IndependentChecks-v1_1.py` (12 reported check groups; conditional algebra and E4 counterexample). Its log is local `_bh_b05_independent.log`. A finite small test and an upstream I-C tight-frame identity are distinguished from independent verification of actual primitive root matrices.
- **Archive status:** original manuscripts and v1.115/v1.32 archives are unchanged. The global canonical registry/DAG Atlas mutation and latest-version-only zip packaging are deferred to **final Batch** to prevent mixing partial claim statuses with completed cross-paper graph integration.
- **Open/impact policy:** prior `BH-VIC-G-0134`–`BH-VIC-G-0147` are retained; new `BH-VIC-G-0148`–`BH-G-000150` are not duplicated at downstream restatements. No gap is silently closed, no new theory is developed, and the proof chain is not relabeled `VERIFIED` simply because a formula was replayed.

## F. Next batch

**Start at line 8,898** (source/thermodynamic/nuclear/cosmological validation, lithium window, historical/open validation and appendix/source statements through line 10,448). Last batch must finish the exact claim census, review inherited findings, integrate the DAG audit layer, and release **only latest versions** in both requested ZIPs after read-back validation.
