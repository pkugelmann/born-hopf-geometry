# Paper VI-C — Rigorous Verification/DAG Audit, Batch 04 (v1.1)

**Authoritative source:** `Paper6C-TechnicalMaterial-v1_43.tex` from current `Paper00-PapersMinimal-v2_371`; verification protocol v2.4. **Scope:** lines **5296–6887** inclusive of 10448; **29 formal statements**, plus the unnumbered stationary TT, right-2I projector and K48 semigroup calculations. Cumulative claim census after batches 1–4: **173 statements**; next starts at **6888**. **State:** `PARTIALLY_AUDITED`, not a full mathematical certification of all upstream physical owner proofs. The original papers, DAG ZIP and audit ZIP remain unchanged.

## Audit result and most important scope distinction

- **Independent E3 positive controls:** canonical kinetic Lebesgue projector and collisionless measure transport; active metric tangent/kinetic susceptibility; positive-domain Green quotient normalization; cluster radial operator/density scale; explicit Born-balance (B1) geometric mean, the conditional BBG26 first jet and deep BTFR algebra; stationary three-frequency tensor response and four-pole interlacing; finite seven-coordinate tensor memory; massless retarded sinusoidal kernel; right-2I tensor rank fractions and K48 no-instantaneous-export controls.
- **4 distinct findings (3 moderate, 1 minor)** are recorded below, no duplicate of BH-VIC-G-0134..143. The Green positive-semigroup premise is **not** equated with the kinetic Hessian algebra, which checks. The two merger issues concern vector realization and quantitative morphology, **not** a falsification of the formal Poisson PDE itself. The terminal curvature discrepancy is in an **alternative printed equality**; the primary acceleration scale is the correct one.
- **Source-only / dependency-bound limits:** `p8:thm:scalaron-response-modality-completeness` points explicitly to Appendix 6888ff, to be checked in the next batch. Paper III-F generated cotangent targets, Paper IV retarded finite response, and the full metric action Hessian are not declared globally E3 verified here. SC1/TR1/R1/R2 and B1/BBG26 are retained as typed physical conditions, not new predictions.

## New issue certificates

### BH-VIC-G-0144 — Nonnegative boundary form is not alone a positivity-preserving Green domain (moderate; MISSING_CONDITION)
**Earliest origin:** `p8:thm:v2129-action-owned-environmental-hessian` 5732–5746. The text derives coercivity when the boundary term is nonnegative, and then calls `G_env=P_env^-1` positivity preserving and `G_env1>0`. The former certifies an invertible positive quadratic form, but by itself does not imply the maximum-principle property for every possibly nonlocal boundary. **Exact E4 countercontrol:** on `[0,1]`, `q[u]=∫_0^1(|u′|²+u²)dx + 4(u(0)+u(1))²` has a nonnegative boundary form and is coercive. Its boundary Green response to positive endpoint input at `0` has opposite endpoint value `u(1)=-(4-csch1)/[(4+coth1)²-(4-csch1)²] ≈ −0.17197171`, thus the inverse is not positive. A local positive Robin boundary gives a positive inverse, and the independent Hessian algebra `χ_kin=(κ/2)∫ E(1+4b−b²)` passes exactly. **Scope:** the adversarial nonlocal boundary has not been shown to belong to the framework's *actual supplied* boundary realizations, so this is a necessary **boundary-class/maximum-principle certificate**, **not** an in-domain refutation of a licensed local positive boundary. **Impact path:** environmental Hessian → normalized Green selector → galaxy/cluster/merger readout, all conditional on this property. **Required evidence:** an actual boundary owner certifying Markov/positive-inverse behavior or the explicit positive-domain assumption; no source changed.

### BH-VIC-G-0145 — Nonspherical merger Reeb force requires a vector-to-potential bridge (moderate; TYPE_OR_DOMAIN)
**Earliest origin:** `p8:thm:merger-lensing-green-propagation` 6096–6115, proof 6135–6154. The earlier Reeb theorem gives a scalar *magnitude* on a static response; the merger proof lifts it to `g_resp = ν(|∇Φ_b|/a_*(x)) ∇Φ_b` and treats its divergence as a scalar potential for lensing. Such a vector generally has **nonzero curl**, because `∇a_*` need not be parallel to `∇Φ_b`. **Exact E4 witness:** `Φ_b=(x²+y²)/2` and `a_*(x)=1+0.1x`, giving `curl_z[ν(|∇Φ_b|/a_*)∇Φ_b](1,1)=0.03605583458`. Therefore the direct local vector is generally **not** `∇Φ_resp`; taking its divergence specifies its longitudinal projection but does not establish equality or physical ownership of the projection. **Scope:** a divergence-defined scalar Poisson equation can still be a legitimate separate conditional mathematical readout, and radial/constant-scale cases evade the counterexample. The issue is the missing typed bridge to the claimed nonspherical observable and its no-slip lensing potential, not the existence of Poisson solutions. **Required evidence:** source-owned vector/longitudinal projection map or an actual curl-free restriction; no new mechanism invented here.

### BH-VIC-G-0146 — Large kernel separation alone does not force two merger peaks (moderate; MISSING_CONDITION)
**Earliest origin:** `p8:cor:two-component-merger-morphology` 6158–6178. It says `D≫ℓ_env` yields separated peaks for positive source weights but gives no lower bound on `W_c/W_g`. **Exact E4 counter-witness:** smooth positive strictly radial-decreasing Gaussian `K(r)=exp(−r²/(2ℓ²))`, `D=10ℓ`, `W_g=1`, `W_c=10^-30`. Along the line of centers, stationary points require `ε=G(x)=x/(D−x)exp(D²/2−Dx)`; the secondary local minimum of `G` equals `5.190190197×10^-20`, so `ε` below it yields only one stationary maximum, near the dominant source. Transverse derivatives exclude off-axis maxima. Equal weights at the same separation are a positive two-peak control. **Impact:** local morphology criterion, not the Green sum itself. **Requirement:** a source-weight/profile condition for bimodality or a genuinely conditional case-specific statement.

### BH-VIC-G-0147 — Inconsistent terminal \(\mathcal R_{56}\) normalization (minor; INCORRECT_STEP)
**Earliest origin:** `p8:thm:terminal-rar-readout` 6397–6398. Current VI-A owner states `\mathcal R_{56}=\sqrt Ulpha^{-7/2}` and `C_{56}=\mathcal R_{56}^2=Ulpha^{-7}` (VI-A 2953–2955 and 14566–14568), repeated in VI-C 6285. Thus the displayed second equality `a_0=(c²/4π)√(\mathcal R_{56}²/U)` does **not** equal the correct first equality `a_0=(c²/4π)√C_{56}`; it differs by `1/√U` and is dimensionally wrong. The primary `a_0` readout, B1 geometric mean, and BTFR algebra survive. A later unreviewed restatement at line 9910 apparently repeats the same normalization, so it should inherit this one issue when reached. **Requirement:** reconcile the printed alternative with the current owner; do not modify source in an audit.

## Inherited issues and propagation

All earlier 10 findings `BH-VIC-G-0134`–`BH-VIC-G-0143` remain in the global *staging* ledger. In particular, endpoint divergence of `ν(0)` inherits **BH-VIC-G-0143** and is not duplicated as a new finding; `g_b ν(g_b/a_*)` has a finite zero-limit. Merger/cluster physical predictions inherit their actual kinetic member, the positive environmental Green condition, the selected hierarchy and R1/R2/SC1/TR1; they are **not** declared falsified by an ambient counterexample. The K48 tensor projector has no physically constituted sky bridge and is not interpreted as a CMB prediction. The fully proven source-to-modality schema (H,L,S,T plus Paper-IV M) is deferred to the next batch, exactly as stated by the manuscript.

## Independent verification details

1. The symbolic active-leaf kinetic Hamiltonian `H(s)=e^s sqrt(m²+q e^{2s})` yields `H′(0)=E(1+b)` and `H″(0)=E(1+4b−b²)` with `b=q/E²`. The ratio `χ_kin/R_active=(1+4b−b²)/(2+2b)` lies in `[1/2,1]` for `b∈[0,1]`. This verifies the stated *matter* Hessian moment, not the full Einstein boundary owner.
2. For the fixed linear pointwise schema `T_cf(x)=c(x)Gf(x)`, constant preservation forces `c=1/G1`, and the least real scalar bounding floor and environment is exactly `max(C56,Renv)`. The approximate cluster local-density conversion produces `1.375631063×10^-26 kg m^-3` from the paper's `a56`, consistent with `1.4×10^-26` printed. The exact radial Green operator and the optional slow-gradient limit are distinct.
3. The B1 exchange fixed point `R/Rsel = Rb/R` has the unique positive root `R=sqrt(Rsel Rb)`; using the static determinant acceleration readout gives `g_obs²=a0 gb` conditional on B1. BBG26 matches only the leading `λ(y)/y→1` and does not establish exact all-order `λ=y`. The conditional extra mass, deep BTFR and Reeb asymptotics pass at positive `gb`.
4. Independent spectral-sum evaluation reproduces the paper's rational stationary TT denominator for `q_m=0,0.001,0.1,1,100`, at multiple `η,x`. The interlacing theorem follows from four interval sign crossings and quartic degree; numerical root tests independently confirm the exact order for 20 positive examples up to the allowed `η` bound; the massless quadratic has two positive simple roots in all tested bounded controls. No source population/history was fitted.
5. Independently evaluating Pauli commutator matrices for an arbitrary nonstationary real covariance recovers all seven displayed real response-coordinate derivatives to `1e-12`, the null quaternion output and tangency condition. The massless sum gives the sine-6 retarded kernel and its `Z″+36Z=6h` companion; it introduces no new quantum degree of freedom.
6. Right-2I rank fractions obtained independently from Molien coefficients are `f_T(2)=1/2` and `f_T(10)=f_T(14)=1/26`; these are same-shell mathematical fractions only. The explicit K48 `e^-τ−1/7` continuation is negative for `τ>log7`, while the continuous semigroup remains positive; no instantaneous export follows.

## Full source-environment census

| # | Source lines | Exact source label | Evidence disposition |
|---:|---:|---|---|
| 1 | 5296–5356 | `p8:thm:scalaron-response-modality-completeness` | `E1_E2_IMPORT_LOCATED_E3_PENDING` |
| 2 | 5358–5379 | `p8:cor:headline-scalaron-role-map` | `E1_E2_IMPORT_LOCATED_E3_PENDING` |
| 3 | 5381–5395 | `p8:cor:stress-energy-phase-space-projections` | `E1_E3_SUBCHECK_E2_IMPORT_FULL_SCOPE_PENDING` |
| 4 | 5403–5432 | `p8:def:v2127-kinetic-baryon-source-packet` | `E1_SOURCE_REPLAY_ONLY_E3_PENDING` |
| 5 | 5434–5456 | `p8:prop:v2127-stress-only-phase-no-go` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 6 | 5458–5489 | `p8:thm:v2127-canonical-kinetic-environment-projector` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 7 | 5502–5527 | `p8:cor:v2127-finite-thickness-coherent-source` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 8 | 5540–5563 | `p8:lem:v2187-canonical-kinetic-projector-transport` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 9 | 5586–5608 | `p8:lem:source-environment-separation` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 10 | 5615–5653 | `p8:lem:v2129-active-stress-dual-static-leaf` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 11 | 5667–5769 | `p8:thm:v2129-action-owned-environmental-hessian` | `E1_WITH_OPEN_PROOF_LINK_OR_DOMAIN_ISSUE` |
| 12 | 5789–5798 | `p8:rem:v2129-environment-measure-transport` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 13 | 5800–5849 | `p8:thm:green-kernel-active-contact-selector` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 14 | 5872–5906 | `p8:cor:cold-thin-disk-terminal-floor` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 15 | 5920–5988 | `p8:cor:relaxed-spherical-cluster-halo-limit` | `E1_E3_SUBCHECK_E2_IMPORT_FULL_SCOPE_PENDING` |
| 16 | 6004–6049 | `p8:cor:cluster-core-bcg-uplift-limit` | `E1_E3_SUBCHECK_E2_IMPORT_FULL_SCOPE_PENDING` |
| 17 | 6061–6115 | `p8:thm:merger-lensing-green-propagation` | `E1_WITH_OPEN_PROOF_LINK_OR_DOMAIN_ISSUE` |
| 18 | 6158–6175 | `p8:cor:two-component-merger-morphology` | `E1_WITH_OPEN_PROOF_LINK_OR_DOMAIN_ISSUE` |
| 19 | 6182–6213 | `p8:thm:hierarchy-selected-reeb-response` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 20 | 6239–6252 | `p8:rem:hierarchy-reeb-data-status` | `E1_E2_IMPORT_LOCATED_E3_PENDING` |
| 21 | 6260–6297 | `p8:def:dark-response-ladder` | `E1_SOURCE_REPLAY_ONLY_E3_PENDING` |
| 22 | 6300–6320 | `p8:lem:terminal-static-d1-quotient` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 23 | 6330–6348 | `p8:prop:unique-terminal-geomean` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 24 | 6372–6416 | `p8:thm:terminal-rar-readout` | `E1_WITH_OPEN_PROOF_LINK_OR_DOMAIN_ISSUE` |
| 25 | 6436–6472 | `p8:thm:v260-born-g26-first-jet` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 26 | 6500–6523 | `p8:cor:rar-apparent-mass-btfr` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 27 | 6621–6635 | `p8:thm:stationary-first-tt-positive-poles` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 28 | 6720–6752 | `p8:prop:first-tt-real-realization` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 29 | 6773–6796 | `p8:cor:massless-tt-memory-realization` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |

## Evidence, graph, and release checkpoint

- **Reproducible source files:** `Paper6C-Batch04-IndependentChecks-v1_1.py` and `Paper6C-RigorousAuditBatch04Evidence-v1_1.json` (also the independent calculation log, local only). `B04-EV-00`–`B04-EV-10` distinguish E0 integrity, E1 source proof replay, E2 imported owner location, E3 independently verified conditional algebra, and E4 valid/bypassed adversarial controls.
- **Graph staging:** 4 first-origin issue certificates, 4 boundary-gate records, 22 reviewed source dependency edges, explicit inherited conditions, negative-allegation log. No paper modification, fabricated proof, new physical mechanism, or edit to incoming source ZIP.
- **Next source range:** line **6888** (native scalaron response-schema completeness appendix; followed by boundary-owner and DtN interfaces). The Atlas ZIP and ProofChain Audits ZIP will be released **only after the final Batch**, each with only the latest applicable versions and a post-write structure/content check.
