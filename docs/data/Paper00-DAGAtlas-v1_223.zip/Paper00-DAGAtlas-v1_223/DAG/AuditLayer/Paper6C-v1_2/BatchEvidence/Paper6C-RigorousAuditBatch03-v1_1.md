# Paper VI-C — Rigorous Verification/DAG Audit, Batch 03 (v1.1)

**Authoritative source:** `Paper6C-TechnicalMaterial-v1_43.tex` from `Paper00-PapersMinimal-v2_371`, checked against current Paper I-A, V-B, VI-A and applicable III/IV prerequisites. **Procedure:** RigorousVerificationDAGWorkProtocol v2.4; no theory changes.
**Audited span:** lines **3158–5295** of **10448**, comprising the entire K16 reheating/split/finite source section and the initial K48 Hopf–Reeb/scalaron-uniqueness chain (up to before modality completeness). **59 formal statements**, cumulative **144** from batches 01–03. **Next:** line 5296.
**Honest state:** `PARTIALLY_AUDITED`. For these 59 environments source-level scope/typed claims and dependencies have been reviewed; many independent checks are conditional algebraic checks, not a full physical realization or E3 of all imported owner proofs.

## Independent checks and cross-source controls

- **Optional smooth-MRESP reheating:** Using the declared `MASS_UV` and one-real-scalar interface, independent `alpha=exp(4π²+1/(6√2))` evaluation gives `M_H=3.530190067471e13 GeV`, `Gamma0=12.30113638274 GeV`, `T0=2.958801428042e9 GeV`. The algebraic Γ and temperature formulas in the theorem agree exactly; this does **not** establish a total Standard Model width.
- **Direct K16 branch:** `E16=1.228311317862e10 GeV`, `T16(xi=1)=5.045705049777e9 GeV`, `T16(xi=delta)=2.956346251426e9 GeV` all match. `xi_dec=0.1182431086142`, the `0.3326047%` near-match and `0.08304767%` temperature difference match independently. The `DEC` and `REH16` branches have distinct premises, not a common dynamical source by default.
- **Representation and source:** Paper I-A `p1:prop:h1-symmetric-exterior-form` supplies the exact `E9⊕L6` irreducible types; `dim E9=1+2+2+4=9`, `dim L6=3+3`. Independent block maps confirm Schur annihilation and rank nine **if** the physical pair-target is equivariantly isomorphic to `E9` and all four allowed blocks are nonzero. This narrows, but does not discharge, inherited `BH-VIC-G-0134`. The K16 `[dot F]=chi(C2)[dot R]` equivalence checks under chi continuous/nonzero; issue `BH-VIC-G-0136` remains branch-scoped.
- **First-split and transition:** For all tested deposition efficiencies, `8 eps/15 + eps/15 + (1-3eps/5)=1`, and saturated partial widths evaluate to `6.56`, `0.820`, `7.38`, `4.92 GeV` when the total benchmark is supplied. Independent rank-one 8→9 maps demonstrate all Born probabilities `[0,1]` and distinguish a uniform amplitude `1/sqrt(72)` from its squared per-entry probability. No K16 production coefficient follows solely from dimensions or conservation.
- **Finite Dirac and baryogenesis:** Three independent 2×2 diagonalizations confirm `|(D)_{-+}|=|MP|/E`, the static Kubo contact sum, and `E″=(M²+4P²)/E+M²P²/E³`. The conditional Majorana ratio `2x²(1-4x²)^(3/2)` maximizes at `x=1/sqrt(10)`, value `0.092951600309`. Yield/required efficiency remains the conditional sudden-decay interface, not a baryogenesis prediction.
- **K48 Hopf/Schur:** `Pic(CP1)=Z` and `O(s)=(O(1))^⊗s` follow from explicit `(SC1)` plus composition. `dim H0(O(s))=s+1`, Schur trace with `(TR1)` gives `Lambda_s=alpha^(s/16)/(s+1)`. Direct values `Lambda1=5.939468286732`, `Lambda2=47.036378038794`, `eta_log(18)=0.535809809214` agree. Neither `(SC1)` nor `(TR1)` is newly derived or physically realized by this check.
- **Reeb static class:** With explicit `(R1)` and `(R2)`, `lambda(y)=y` via continuous additive Cauchy, and the positive-line Green ratio is `exp(-sqrt y)`. Independent geometric sums give `nu(y)=1/(1-exp(-sqrt y))` for `y>0`. `nu(0)` diverges, whereas `a*y*nu(y)→0`, an endpoint-domain issue only, not a positive-y refutation.
- **Active Einstein scalar:** Separate trace reversal with a generic perfect fluid confirms `R_active=(8πG/c²)(rho+3P/c²)`, with cancellation of the cosmological term in the defined contraction. The scalaron-uniqueness claim is checked as a **stable pinned-momentum-carrier conditional**: it does not remove unfolded position-metric spin-two modes or prove unqualified identity of the hierarchy and canonical scalar readouts.

## New issues — complete first-origin list for this batch

### BH-VIC-G-0139 — Partial scalar decay channel promoted to total reheating width (moderate; NORMALIZATION_OR_READOUT)
**Origin:** lines 3178–3194, then theorem `p8:thm:scalaron-decay-reheating-rung` (3243–3281); used as total `Gamma_s` again at 3925–3958. **Precise imported owner:** Paper V-B `p6:prop:one-real-scalar-interface` (6811–6867), which explicitly calls `1/(192π)` the **one minimally coupled real scalar partial width**, multiplies by `N_s` for equivalent real components, and states a Higgs doublet has four components if all minimally coupled. Paper VI-C identifies the same normalization with the Higgs-doublet/trace-anomaly channel and subsequently uses `Gamma_s` as the **total** source-width ledger. Independent arithmetic verifies the benchmark if that total width is supplied, but the partial-to-total channel map is not in the imported proof. **Known impact path:** imported V-B partial-width → optional VI-C decay theorem → conditional first-split and sector-source widths → the reheating export packet. **Bypass:** the direct `REH16[xi]` temperature does not use `MASS_UV`/decay width. **Obligation:** source-match a channel-summed total-rate theorem or explicitly type an effective-total-rate interface. No claim of a wrong one-real-scalar coefficient.

### BH-VIC-G-0140 — Conservation alone does not impose xi16dyn≤1 in the stated normalization (moderate; MISSING_CONDITION)
**Origin:** `p8:def:dynamical-k16-production-fraction` lines 3386–3415. Positivity proves `xi≥0`, but total Noether conservation and absence of external injection do not, by themselves, give `Tr(h^1/2 Γ h^1/2)/V_*≤I16` without a matching initial/final source ledger identifying `I16` as all available input and nonnegative retained sectors. A positive closed internal-ledger countercontrol allows output fraction above `I16` if an additional internally owned reservoir exists. **Positive source control:** later definition `p8:def:direct-k16-radiation-transfer-interface` (3512–3533) explicitly restricts `0≤xi≤1` to the **pure-transfer** normalization, preserving the conditional direct theorem. **Obligation:** inherit that exact ledger guard at the first claim or prove an actual normalized bound.

### BH-VIC-G-0141 — Rounded split-reheating multiplication is printed incorrectly (minor; INCORRECT_STEP)
**Origin:** `p8:cor:first-split-reheating-value`, lines 4013–4035. `2.96e9 × (3/5)^(.25) = 2.6051307409e9 GeV`, not `2.6041e9 GeV` as printed. The result `2.6041e9` **is** correct if the unrounded imported `2.9588e9` is used (`2.6040746068e9`). This is a displayed precision/rounding defect, **not a failure of the fourth-root law**. **Impact:** local displayed identity only. **Obligation:** print the unrounded factor or correct the rounded product.

### BH-VIC-G-0142 — Geometric-delta and saturated-democratic same-variable conflict (moderate; NORMALIZATION_OR_READOUT)
**Origin:** `paper6c:corollary:atlas-legacy-geometric-comparison-member-a65187d` (4330–4354), tied to definitions 3420–3424 and theorem 3862–3867. The historical comparison imposes `xi16dyn=delta=1/(6sqrt2)=0.117851...`; adding `(DEM15)` and saturated `eps_dep=1` imposes on the **same xi16dyn** `xi=3/5=0.6`. These hypotheses have no joint same-variable realization. The displayed `2.6019150e9 GeV` is correct as the arithmetic product of two separate factors, but is not justified by the stated simultaneous conditions; applying a visibility factor to a fraction already defined as produced visible energy also double-counts unless a separately typed pre-split coefficient is supplied. **Bypasses:** standalone delta direct temperature and standalone democratic temperature remain conditional and correct. **Obligation:** split coefficient types and establish a source bridge, or mark the numerical visible comparison as a non-co-realizable historical exercise.

### BH-VIC-G-0143 — Zero-source endpoint outside finite Reeb-return-kernel domain (minor; TYPE_OR_DOMAIN)
**Origin:** theorem `p8:thm:geometry-forced-compact-reeb-envelope` (4927–4949), compared with definition `p8:def:admissible-scalar-reeb-response-kernel` (4788–4820), which permits `y≥0`. Its earlier general-envelope proposition (4837–4855) correctly requires `lambda(y)>0`. At `y=0` the displayed `sum_{n≥0}exp(-n√y)=sum_n1` diverges, so `nu(0)` is not a finite response factor. The **observable product** `g_b nu = a*y/(1-e^-√y)` has a right limit zero, so no physical zero-acceleration refutation is claimed. **Obligation:** restrict the finite kernel to `y>0` and separately state any continuous observable extension.

## Prior open issues inherited, not duplicated
- **BH-VIC-G-0134:** pair vertex requires physically constituted Spin4-equivariant E9 target and nonzero blocks; new conditional Schur theorem confirms only mathematical implication.
- **BH-VIC-G-0135:** curved scalar oscillator requires nonsingular H_E and rolling branch.
- **BH-VIC-G-0136:** K16 nonunit one-sided chi/mass ratios require separate historical scope from active C2 continuous chi.
- **BH-VIC-G-0137:** first scalar perturbation plateau lacks physical source-to-mode response map.
- **BH-VIC-G-0138:** flat k=aH scaling not exact small integer closed-S3 harmonic degree relation.

## Classification, scope guards and graph staging

| Disposition | Statements |
|---|---:|
| `E1_E2_IMPORT_LOCATED_E3_PENDING` | 7 |
| `E1_E3_SUBCHECK_E2_IMPORT_FULL_SCOPE_PENDING` | 8 |
| `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` | 20 |
| `E1_SOURCE_REPLAY_ONLY_E3_PENDING` | 19 |
| `E1_WITH_OPEN_PROOF_LINK_OR_DOMAIN_ISSUE` | 5 |

The exact stage of every claim is in the JSON checkpoint below. The batch uses E3 only for independently recreated algebra/numerics at their explicit conditional scopes; physical occurrence, full imported theorem proofs and later scalaron-modality completeness are **not** promoted. The source-level allocation distinguishes `MASS_UV`, `DEC`, `THERM`, `REH16[xi]`, `DEM15`, `Hkin`, `SC1`, `TR1`, `R1`, `R2`, and the stable pinned momentum carrier. No new constitutional physical mechanism or repaired theorem is introduced.

## Source census of all 59 formal environments

| # | Lines | Source label | Evidence disposition |
|---:|---|---|---|
| 1 | 3158–3176 | `p8:def:mass-uv-interface` | `E1_SOURCE_REPLAY_ONLY_E3_PENDING` |
| 2 | 3243–3281 | `p8:thm:scalaron-decay-reheating-rung` | `E1_WITH_OPEN_PROOF_LINK_OR_DOMAIN_ISSUE` |
| 3 | 3287–3297 | `p8:rem:e16-no-octahedral-backselection` | `E1_E2_IMPORT_LOCATED_E3_PENDING` |
| 4 | 3299–3313 | `p8:cor:unique-k16-action-junction` | `E1_E3_SUBCHECK_E2_IMPORT_FULL_SCOPE_PENDING` |
| 5 | 3315–3320 | `Paper6C:remark:3315` | `E1_SOURCE_REPLAY_ONLY_E3_PENDING` |
| 6 | 3322–3339 | `p8:thm:k16-physical-time-junction-pullback` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 7 | 3348–3371 | `p8:thm:nine-six-representation-reduction` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 8 | 3386–3427 | `p8:def:dynamical-k16-production-fraction` | `E1_WITH_OPEN_PROOF_LINK_OR_DOMAIN_ISSUE` |
| 9 | 3429–3451 | `p8:thm:same-action-exchange-current` | `E1_E3_SUBCHECK_E2_IMPORT_FULL_SCOPE_PENDING` |
| 10 | 3465–3471 | `Paper6C:remark:3465` | `E1_SOURCE_REPLAY_ONLY_E3_PENDING` |
| 11 | 3475–3487 | `p8:cor:v176-local-gauge-scalar-exchange` | `E1_E3_SUBCHECK_E2_IMPORT_FULL_SCOPE_PENDING` |
| 12 | 3489–3501 | `p8:rem:v176-no-scalaron-noether-energy` | `E1_SOURCE_REPLAY_ONLY_E3_PENDING` |
| 13 | 3503–3509 | `p8:rem:v176-local-trace-fR-firewall` | `E1_SOURCE_REPLAY_ONLY_E3_PENDING` |
| 14 | 3512–3533 | `p8:def:direct-k16-radiation-transfer-interface` | `E1_SOURCE_REPLAY_ONLY_E3_PENDING` |
| 15 | 3535–3555 | `p8:thm:direct-k16-radiation-equivalent-scale` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 16 | 3571–3597 | `p8:thm:k16-produced-modes-radiation-like` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 17 | 3609–3615 | `p8:rem:radiation-like-not-thermalized` | `E1_SOURCE_REPLAY_ONLY_E3_PENDING` |
| 18 | 3617–3624 | `p8:cor:direct-k16-delta-diagnostic` | `E1_SOURCE_REPLAY_ONLY_E3_PENDING` |
| 19 | 3626–3648 | `p8:rem:alpha-delta-squeeze-bridge` | `E1_SOURCE_REPLAY_ONLY_E3_PENDING` |
| 20 | 3650–3671 | `p8:rem:direct-k16-delta-status` | `E1_SOURCE_REPLAY_ONLY_E3_PENDING` |
| 21 | 3692–3733 | `p8:def:first-split-geometry-certificate` | `E1_E2_IMPORT_LOCATED_E3_PENDING` |
| 22 | 3735–3749 | `p8:def:hopf-chiral-hurwitz-roles` | `E1_SOURCE_REPLAY_ONLY_E3_PENDING` |
| 23 | 3751–3771 | `p8:post:inflationary-chiral-separation` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 24 | 3782–3829 | `p8:def:typed-first-split-carrier` | `E1_E2_IMPORT_LOCATED_E3_PENDING` |
| 25 | 3831–3844 | `p8:def:first-split-democratic-kinetic-interfaces` | `E1_SOURCE_REPLAY_ONLY_E3_PENDING` |
| 26 | 3846–3881 | `p8:thm:first-split-reheating-visibility` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 27 | 3899–3972 | `p8:thm:sector-resolved-first-split-reheating` | `E1_E3_SUBCHECK_E2_IMPORT_FULL_SCOPE_PENDING` |
| 28 | 3986–4002 | `p8:cor:first-split-reduced-closure-status` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 29 | 4013–4030 | `p8:cor:first-split-reheating-value` | `E1_WITH_OPEN_PROOF_LINK_OR_DOMAIN_ISSUE` |
| 30 | 4038–4044 | `p8:rem:first-split-normalization` | `E1_SOURCE_REPLAY_ONLY_E3_PENDING` |
| 31 | 4046–4058 | `p8:rem:first-split-no-energy-loss` | `E1_SOURCE_REPLAY_ONLY_E3_PENDING` |
| 32 | 4060–4074 | `p8:rem:first-split-standard-reheating-reduction` | `E1_SOURCE_REPLAY_ONLY_E3_PENDING` |
| 33 | 4076–4097 | `p8:prop:scalaron-readout-handoff` | `E1_E3_SUBCHECK_E2_IMPORT_FULL_SCOPE_PENDING` |
| 34 | 4112–4131 | `p8:cor:k16-k48-coordinate-intersection` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 35 | 4330–4354 | `paper6c:corollary:atlas-legacy-geometric-comparison-member-a65187d` | `E1_WITH_OPEN_PROOF_LINK_OR_DOMAIN_ISSUE` |
| 36 | 4362–4372 | `p8:prop:no-unmarked-eight-nine-transition-map` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 37 | 4382–4408 | `p8:prop:marked-uniform-eight-nine-counterfamily` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 38 | 4419–4438 | `p8:prop:k16-conservation-does-not-select-xi` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 39 | 4450–4475 | `p8:prop:k16-decay-direct-near-match-status` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 40 | 4504–4538 | `p8:prop:v285-scalaron-majorana-width` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 41 | 4547–4582 | `p8:prop:v285-nonthermal-baryogenesis-factor` | `E1_E3_SUBCHECK_E2_IMPORT_FULL_SCOPE_PENDING` |
| 42 | 4591–4599 | `Paper6C:remark:4591` | `E1_SOURCE_REPLAY_ONLY_E3_PENDING` |
| 43 | 4610–4652 | `p8:def:planck-normalized-hierarchy-readout` | `E1_SOURCE_REPLAY_ONLY_E3_PENDING` |
| 44 | 4654–4680 | `p8:thm:shell-uplift-hopf-charge` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 45 | 4690–4738 | `p8:lem:projected-contact-channel-splitting` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 46 | 4749–4752 | `p8:rem:projected-endpoint-scope` | `E1_E2_IMPORT_LOCATED_E3_PENDING` |
| 47 | 4754–4781 | `p8:lem:multiplicative-hierarchy-interpolation` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 48 | 4788–4820 | `p8:def:admissible-scalar-reeb-response-kernel` | `E1_SOURCE_REPLAY_ONLY_E3_PENDING` |
| 49 | 4823–4835 | `p8:rem:v203-born-legendre-target` | `E1_E2_IMPORT_LOCATED_E3_PENDING` |
| 50 | 4837–4855 | `p8:prop:v260-general-reeb-envelope` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 51 | 4869–4878 | `p8:lem:static-reeb-normal-operator` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 52 | 4884–4909 | `p8:lem:reeb-single-return-damping` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 53 | 4927–4949 | `p8:thm:geometry-forced-compact-reeb-envelope` | `E1_WITH_OPEN_PROOF_LINK_OR_DOMAIN_ISSUE` |
| 54 | 4991–5010 | `p8:rem:excluded-rar-response-alternatives` | `E1_SOURCE_REPLAY_ONLY_E3_PENDING` |
| 55 | 5013–5056 | `p8:lem:active-stress-selector-scalar` | `E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE` |
| 56 | 5082–5151 | `p8:thm:momentum-carrier-rigidity-scalar-trace` | `E1_E3_SUBCHECK_E2_IMPORT_FULL_SCOPE_PENDING` |
| 57 | 5224–5236 | `p8:cor:scalar-only-modified-gravity-lane` | `E1_E3_SUBCHECK_E2_IMPORT_FULL_SCOPE_PENDING` |
| 58 | 5251–5284 | `p8:rem:v2218-fixed-momentum-interpolation` | `E1_E2_IMPORT_LOCATED_E3_PENDING` |
| 59 | 5286–5294 | `p8:rem:scalaron-uniqueness-regime` | `E1_E2_IMPORT_LOCATED_E3_PENDING` |

## Evidence lineage and release contract

- `B03-EV-00`: exact source/hash freeze, all 59 environments and independently inventory locations; no proof promotion from indexing.
- `B03-EV-01`: independent natural-unit K16 reheating, transfer, widths, branch conflict and rounding. Script `Paper6C-Batch03-IndependentChecks-v1_1.py`.
- `B03-EV-02`: hierarchy mass/ultrarelativistic energy conditional domain analysis.
- `B03-EV-03`: Spin4 Schur rank positive/negative controls, exact Dirac matrices, Einstein scalar trace reversal and source inequality countercontrol. Scripts `Paper6C-Batch03-IndependentChecks-v1_1.py`, `Paper6C-Batch03-AdversarialChecks-v1_1.py`.
- `B03-EV-04`: Hopf charge composition/Borel-Weil and Schur under physical `SC1` and `TR1`; interpolation.
- `B03-EV-05`: positive-Reeb Green/return sum on y>0, endpoint adversarial check.
- `B03-EV-06`: pinpoint imported-source checks, including Paper V-B partial-width theorem and Paper VI-A DtN/curvature map.
- `B03-EV-07`: explicit issue certificates and failed-allegation countercontrols. JSON checkpoint contains 5 full issue objects, 13 scoped reviewed graph edges, 6 rejected allegations, and authoritative hashes.

**Global DAG state:** staging only. No original paper or archive changed. On the **last** batch integrate the global typed conditions, claims, evidence and issues as a backward-compatible DAG layer, then produce only latest-version files in `Paper00-DAGAtlas-v1_116.zip` and `Paper00-ProofChainAudits-v1_33.zip` (or subsequent versions if newer inputs are provided). **Next span:** start at **line 5296** with scalaron modality completeness and the remainder of K48 proof chain.
