# Paper VI-C — Rigorous Verification/DAG Audit, Batch 01 (v1.1)

**Authoritative source:** `Paper6C-TechnicalMaterial-v1_43.tex` from PapersMinimal v2.371.  **Protocol:** RigorousVerificationDAGWorkProtocol v2.4.
**Covered:** lines **80–1374 of 10448**; **32 formal statements/remarks** fully inventoried and source-classified (not all yet independently E3 certified); includes the associated substantive unnumbered equations.
**Status:** PARTIALLY_AUDITED; first batch only. Originals remain unchanged.  No ZIPs have been generated yet: both requested latest-only global ZIPs are reserved for the final batch.

## E3/adversarial findings (not conventional-framework requirements)

- **Optional smooth-MRESP endpoint, inflation, UV mass gate:** independent direct-variable quadrature reproduces `N=56`, `u_end=0.91939087894`, `u_star=0.93433249102`, `F_star=74.50254259`, `n_s=0.96296077839`, `r=0.00288427536`, and `A_s^(S³)=3.86944262e-9`. The exact two-jet mismatch and negative UV algebraic mass are source-consistent. These are *optional* smooth comparator outputs, **not active Laurent predictions**. Integration near machine precision generated a SciPy roundoff-warning; no source-displayed digits were contradicted.
- **Historical quadratic f(R) and cosmological kernels:** independent exact algebra reproduces historical constant-curvature root and `m_alg²=(U+C)/6`; tensor affine defect and fermion/two-level and vector pairing expressions check at the stated reduced-mode level. Original closed curved Mukhanov action was verified against the imported primary formula (Handley 2019, Eq. 26), with domain restriction recorded below.
- **G26 no-go controls:** affine source example has stationary `z=y, phi=0` and stiffness `y+c*y²`; positive reciprocal family has exact reciprocal identity, positive derivative polynomial, and nonzero higher jets. These support the *basis-relative no-go*, not a global proof that no all-order source law is possible.
- **Petersen–Hopf / icosahedral sector:** exact ten-axis moments `M₂,M₄,M₈`, harmonic `H₆,H₁₀`, nonzero odd `H₁₅`, Molien ring, `A₅` character multiplicities through degree 15 and right-2I `k=12` dimension 13 independently check. `12,20,30` are Hopf shell degrees, not sky multipoles or observed power; no mode occupation/transfer is inferred.
- **Verification limit:** K48 gap, fresh-root QROOT state, occupation/thermalization and some action/physical occurrence assertions currently have E1/import review without full independent E3/E4 for their full strongest stated scopes. No bulk promotion to VERIFIED.

## Open findings — all Batch 01 issues

### BH-VIC-G-0134 — MISSING_CONDITION (moderate)
**Target:** `p8:thm:v164-k16-action-vertex-rank` at `Paper6C-TechnicalMaterial-v1_43.tex:415-430`.
**Exact obligation:** A covariant V:H1(E9⊕L6)→V_pair kills L6 only if the equivariant target has no (1,0) or (0,1) representation; the target type and covariance of the actual mode-map must be established.
**Needed:** Trace the actual action/ordered-mode pair-vertex module to the E9 target with correct quantifiers or make 415 conditional on the explicitly proved later statement. No source repair performed.
**Impact/scope:** No declaration that the full 9+6 physical model is false. POSSIBLY_AFFECTED until upstream target-module discharge and typed link shown

### BH-VIC-G-0135 — TYPE_OR_DOMAIN (moderate)
**Target:** `p8:thm:v189-curved-scalar-kernel` at `Paper6C-TechnicalMaterial-v1_43.tex:612-643`.
**Exact obligation:** On the comoving single-clock scalar reduction, require H_E≠0 and φdot_E≠0 for a nonsingular curvature-variable/canonical oscillator interval; M_k=C_E γ_k>0 in 647-713 requires φdot_E≠0; regularity of derivatives as needed.
**Needed:** Record/scoped proof of rolling nonzero-H interval, patch with valid alternative gauge at a bounce/turning point, or explicitly restrict these kernel/oscillator statements. Do not infer from F>0,fRR>0.
**Impact/scope:** Does not invalidate kernel on non-degenerate intervals or TT sector. 

### BH-VIC-G-0136 — TYPE_OR_DOMAIN (moderate)
**Target:** `p8:rem:v189-k16-one-sided-diagnostics` at `Paper6C-TechnicalMaterial-v1_43.tex:968-982`.
**Exact obligation:** On the same active REG0 K16 junction with [F]16=[χ]16=0 and R+ = R− = C2, positive χ(C2), the one-sided χ ratio and m_alg ratio must both equal 1. If displayed nonunit values are historical, identify the separate branch precisely.
**Needed:** Show the explicit comparator/historical action, branch labels and non-conflicting K16 endpoint for the quoted nonunit ratios, or withdraw them from the current branch. No edit made.
**Impact/scope:** Not evidence of a discontinuity in the active restored Laurent–Legendre f_RR; that continuity was separately checked. 

## Evidence and reproducibility

| ID | Scope | Artifact |
|---|---|---|
| E0 | Current source/corpus/archive hash freeze | checkpoint JSON |
| E3-01 | Direct smooth-MRESP numerical replay; reciprocal source counterexample | `Paper6C-Batch01-ExactChecks-v1_1.py` |
| E3-02 | Petersen ten-axis invariants and character averages | `Paper6C-Batch01-Hopfsym-v1_1.py` |
| E3/E4-03 | Ward/f(R)/kernels, branch continuity control | `Paper6C-Batch01-KernelChecks-v1_1.py` |
| E2-04 | Independent primary imported Mukhanov action | Handley, arXiv:1907.08524, page 3, eq. 26 |

The machine checkpoint stores every one of the 32 labels, line ranges, evidence status, issue IDs, provenance hashes, and controlled downstream impact candidates. `BH-VIC-G-0134`–`BH-VIC-G-0136` are staged canonical slots and remain subject to global registry first-origin/alias verification before final archive commit.

## Next batch boundary

Start at **line 1375**, continuing through the next major source section (approximately line 3000, adjusted to the next complete environment boundary) without reopening reviewed first-section results except for genuine cross-references. Complete other batches before generating the **two requested latest-only ZIPs**: `Paper00-DAGAtlas-v1_115.zip` and `Paper00-ProofChainAudits-v1_32.zip`.

### Scope cautions

- None of these findings requires reproducing conventional inflationary physics. They check only the manuscript’s own exact type, branch, endpoint and representation claims.
- No source paper has been rewritten; no theory gap has been repaired; earlier files/ZIPs are unchanged.
