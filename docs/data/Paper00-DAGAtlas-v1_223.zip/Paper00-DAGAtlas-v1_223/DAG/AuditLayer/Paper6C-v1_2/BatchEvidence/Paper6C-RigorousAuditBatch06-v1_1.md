# Paper VI-C — Rigorous Verification/DAG Audit, Batch 06 (Final Source Batch)

**Frozen target:** `Paper6C-TechnicalMaterial-v1_43.tex`; SHA-256 `95584cae4b46ce8aef588f664b2b91e1ae6e60c4703a305e720672d1fa82efbc`. **Scope:** lines **8898–10448** (last 1551 lines); no theory/source edits. **Protocol:** v2.4. **Named statements:** **32**; cumulative across batches **247**. Prior findings BH-VIC-G-0134–BH-G-000150 retained as open, not treated as fresh.

## Two new issue certificates

### BH-G-000151 — Optional Reeb kernel mislabeled as selected native static RAR (moderate)
Earliest origin: lines **9946–9999** (`p8:app:darkmatter`). Code claims to implement the hierarchy-selected static RAR response via `nu_reeb`, while 10018–10020 explicitly say it is an enlarged optional comparison and **not** the same-action metric Green function. Current **10234–10251** and **7675–7748** separate the independently closed native **S+T G26-DEEP** from historical local-L/Calderón/Reeb all-order return requiring R1/R2 and physical unbounded-return ownership. This is a branch/interpretation inconsistency, not a refutation of the Reeb mathematical quotient or native deep law. *Required:* exact branch-scope correction or existing physical owner certificate, without inventing a mechanism.

### BH-G-000152 — Missing 4π in printed SI SymPy check (minor)
Earliest origin: **10023–10034**. The theoretical formula defines `a_0 = c² sqrt(2 Lambda_eff)/(4π)` but the numerical line uses `c² sqrt(2 Lambda_prim_num)` without `/ (4π)`. Independent evaluation yields **1.4399729708×10^-9 m/s²** as printed, not the comment's **1.146×10^-10**. With `/ (4π)` it gives **1.1458940811×10^-10**. The actual theoretical normalization is unaltered. *Required:* correct the code demonstration, not the physics.

## Inherited occurrences

- **BH-VIC-G-0147:** line **9910** repeats `C56=R56²/U`, while **9461–9462** state `R56²=C56=U alpha^-7`. Original defect at **6397–6398**; no duplicated issue.
- **BH-VIC-G-0143:** the `nu_reeb(0)` code at **9987–9994** has the same zero-endpoint undefined-factor domain as the earlier source; the observable-weighted product has a finite limit.
- **BH-VIC-G-0148:** historical G26 theorem at **10139–10184** is historical, not a new active RAR firewall.

## Independent mathematical checks (13 reproducible groups)

The executable `Paper6C-Batch06-IndependentChecks-v1_1.py` confirms: (1) kinetic projector/smoothing singular-vs-ac behavior; (2) frozen Green normalization vs broadened Markov post-map; (3) nonGaussian axis/Rayleigh and pooled Beta variance (`6/175` vs `1/25`); (4) thermal window K=40 and 93.119 keV orientation; (5) `H8=761/280` and 24-cell sixth-moment defect `3/8`; (6) closed-FLRW `f(R)` 00/lapse constraint; (7) spatial/Raychaudhuri equation; (8) non-scalar `S+` with same scalar trace; (9) exact top-hat commutator `D(WF)=4 A4 y³ + A3 h²`; (10) weighted mean-square variance identity; (11) positive optical-speed counterfamily; (12) printed missing-`4π` countercheck; and (13) repeated earlier owner-normalization error. No physical initial-state or observables license follows from these mathematical tests.

## Statement dispositions

| # | Lines | Source label | Evidence status |
|---:|---:|---|---|
| 1 | 8916–8937 | `p8:prop:v2187-kinetic-smoothing-diagnostic` | `E1_E3_CHECKED_AT_EXACT_CONDITIONAL_SCOPE` |
| 2 | 8951–8956 | `p8:prop:v2187-linear-postmap-diagnostic` | `E1_E3_CHECKED_AT_EXACT_CONDITIONAL_SCOPE` |
| 3 | 8982–8990 | `p8:prop:v2187-nongaussian-axis-diagnostic` | `E1_E3_CHECKED_AT_EXACT_CONDITIONAL_SCOPE` |
| 4 | 8997–9005 | `p8:prop:v2187-fixed-radius-pooling-diagnostic` | `E1_E3_CHECKED_AT_EXACT_CONDITIONAL_SCOPE` |
| 5 | 9034–9051 | `p9:def:lithium-native-thermal-coordinate` | `E0_E1_STATED_DEFINITION` |
| 6 | 9053–9070 | `p9:lem:lithium-k40-placement` | `E1_E3_CHECKED_AT_EXACT_CONDITIONAL_SCOPE` |
| 7 | 9097–9117 | `p9:lem:local-k40-spurion-import` | `E1_E2_WITH_E3_SUBCHECK_IMPORT_OR_OWNER_NOT_FULLY_REVERIFIED` |
| 8 | 9126–9149 | `p9:def:mass-seven-mirror-projector` | `E0_E1_STATED_DEFINITION` |
| 9 | 9151–9169 | `p9:prop:lithium-k40-mirror-kernel` | `E1_E2_WITH_E3_SUBCHECK_IMPORT_OR_OWNER_NOT_FULLY_REVERIFIED` |
| 10 | 9182–9204 | `p9:cor:lithium-lab-and-deuterium-boundary` | `E1_E2_SOURCE_REPLAY_IMPORTED_FULL_E3_PENDING` |
| 11 | 9255–9279 | `p9:def:scalaron-abundance-certificate-datum` | `E0_E1_STATED_DEFINITION` |
| 12 | 9281–9291 | `p9:lem:scalaron-certificate-acceptance` | `E1_E3_CHECKED_AT_EXACT_CONDITIONAL_SCOPE` |
| 13 | 9311–9314 | `p8:thm:cosmological-realization-criterion` | `E1_E2_WITH_E3_SUBCHECK_IMPORT_OR_OWNER_NOT_FULLY_REVERIFIED` |
| 14 | 9328–9349 | `p8:rem:hurwitz-link-cosmology-scope` | `E1_SCOPE_AND_BRANCH_REVIEW` |
| 15 | 9352–9374 | `p8:rem:m8-batch-cosmology-inputs` | `E1_SCOPE_AND_BRANCH_REVIEW` |
| 16 | 9379–9382 | `p8:rem:series-selected-finite-cell-kernels` | `E1_SCOPE_AND_BRANCH_REVIEW` |
| 17 | 9384–9417 | `p8:thm:imported-hopf-born-cosmological-carrier` | `E1_E2_WITH_E3_SUBCHECK_IMPORT_OR_OWNER_NOT_FULLY_REVERIFIED` |
| 18 | 9430–9477 | `p8:thm:flrw-determinant-owner-inheritance` | `E1_E2_WITH_E3_SUBCHECK_IMPORT_OR_OWNER_NOT_FULLY_REVERIFIED` |
| 19 | 9496–9518 | `p8:def:curvature-shell-coordinate` | `E0_E1_STATED_DEFINITION` |
| 20 | 9522–9587 | `p8:prop:d4-cosmology-origin` | `E1_E2_WITH_E3_SUBCHECK_IMPORT_OR_OWNER_NOT_FULLY_REVERIFIED` |
| 21 | 9608–9629 | `p8:thm:gp2-closed-flrw-background` | `E1_E2_WITH_E3_SUBCHECK_IMPORT_OR_OWNER_NOT_FULLY_REVERIFIED` |
| 22 | 9634–9648 | `p8:cor:flrw-source-pressure-open-residues` | `E1_E2_SOURCE_REPLAY_IMPORTED_FULL_E3_PENDING` |
| 23 | 9654–9680 | `p8:cor:closed-flrw-friedmann-derived` | `E1_E3_CHECKED_AT_EXACT_CONDITIONAL_SCOPE` |
| 24 | 9698–9709 | `p8:prop:first-full-cell-cosmology-correction` | `E1_E3_CHECKED_AT_EXACT_CONDITIONAL_SCOPE` |
| 25 | 9726–9729 | `p8:prop:central-proof-discharge` | `E1_E2_SOURCE_REPLAY_IMPORTED_FULL_E3_PENDING` |
| 26 | 9735–9743 | `p8:def:exhaustion-readout-chronology-ledger` | `E0_E1_STATED_DEFINITION` |
| 27 | 10139–10184 | `p9:thm:v192-g26-readout-frontier` | `E1_E2_WITH_E3_SUBCHECK_IMPORT_OR_OWNER_NOT_FULLY_REVERIFIED` |
| 28 | 10320–10334 | `p6c:prop:v353-native-action-status` | `E1_E3_CHECKED_AT_EXACT_CONDITIONAL_SCOPE` |
| 29 | 10364–10381 | `p6c:prop:v358-window-null-contamination` | `E1_E3_CHECKED_AT_EXACT_CONDITIONAL_SCOPE` |
| 30 | 10393–10405 | `p6c:prop:v358-mean-square-window` | `E1_E3_CHECKED_AT_EXACT_CONDITIONAL_SCOPE` |
| 31 | 10414–10429 | `p6c:prop:v358-optical-speed-counterfamily` | `E1_E3_CHECKED_AT_EXACT_CONDITIONAL_SCOPE` |
| 32 | 10438–10445 | `p6c:rem:v358-observer-clock-frontier` | `E1_SCOPE_AND_BRANCH_REVIEW` |

## Unnamed source-section coverage and audit limitations

The source groups for thermal orientation, optional H8 code, scalaron interval certificate, terminal action and normalized hierarchy, Reeb example, K16/K48 sync, optical/observer limits, and source/action discharge ledger were also reviewed. The exact unnamed-section index is in `Paper6C-RigorousAuditBatch06Evidence-v1_1.json`. Full upstream physical-owner correctness was not inferred from a local numerical/symbolic E3 check. No actual numeric lithium response, black-hole full-history certificate, observer-state selection, or exact Reeb native owner was verified. No separate real parallel agents were available; E1/E3/E4 are distinct test methods, not agent counts.
