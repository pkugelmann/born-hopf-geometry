"""Adversarial and positive controls for Paper6C batch03, source-matched domains.
Maintains the source constitution: irreps over C, physical target needs separate premise.
"""
import numpy as np
from math import sqrt,pi,exp
from fractions import Fraction

# Spin(4) E9 and L6 multiplicity-free types: (2jL+1)(2jR+1)
e9={(0,0):1,(.5,0):2,(0,.5):2,(.5,.5):4}
l6={(1,0):3,(0,1):3}
assert sum(e9.values())==9 and sum(l6.values())==6
assert not set(e9).intersection(l6)
# Schur intertwiner on E9 target necessarily kills L6; full rank iff each block nonzero.
T=np.zeros((9,15));pos=0
for d in e9.values():
 T[pos:pos+d,pos:pos+d]=np.eye(d);pos+=d
assert np.linalg.matrix_rank(T)==9 and np.linalg.norm(T[:,9:])==0
# Failure of one 'nonvanishing on every E9 block' yields rank drop, as claimed.
Tmissing=T.copy();Tmissing[0,0]=0
assert np.linalg.matrix_rank(Tmissing)==8
# A larger target containing an L6 irrep admits a nonzero equivariant L6 map,
# which is why earlier issue 000134 needs the actual pair-target module premise.
Tbig=np.zeros((12,15));Tbig[:9,:]=T;Tbig[9:12,9:12]=np.eye(3)
assert np.linalg.matrix_rank(Tbig)==12
print('SPIN4: 9+6, nonzero E9 blocks, and missing target constraint controls PASS')

# For C2 χ>0 continuous, [dotF]=χ [dotR], no lower-order delta from an R-rate jump.
chi=2.4
for left,right in [(0,0),(2,2),(.1,-.3),(-4,8)]:
 assert abs(chi*(right-left))<1e-10 if right==left else abs(chi*(right-left))>1e-9
print('JUNCTION: equivalence under nonzero continuous chi PASS')

# Exact perfect-fluid active-focusing trace identity with signature (-,+,+,+), c=1.
for rho,p,Lam,kappa in [(2,0,.3,.7),(1,.2,1,1),(0,3,0,.3)]:
 # Einstein trace reversal Rnn = kappa*(Tnn + T/2)-Lam
 T=-rho+3*p;Rn=kappa*(rho+T/2)-Lam
 Ractive=2*(Rn+Lam)
 assert abs(Ractive-kappa*(rho+3*p))<1e-12
print('EINSTEIN ACTIVE STRESS: trace reversal and Lambda cancellation PASS')

# Explicit V-B channel multiplicity witness: one-real-scalar partial width versus four
# minimally coupled independent real Higgs components (no assertion about actual SM).
m=3.5e13; Mp=2.435e18
one=m**3/(192*pi*Mp**2)
four=4*one
assert four/one==4
assert (four/one)**.5==2
print('PARTIAL/TOTAL WIDTH COUNTERCONTROL: 4 independent minimal scalars give width factor',four/one)

# Source upper-bound statement uses more than total covariant conservation: exhibit
# a conservative positive finite ledger with production greater than I16 if a
# separate initial reservoir is allowed; pure transfer assumption excludes it.
I16=1;other_reservoir=3;final_ord=2;final_rest=I16+other_reservoir-final_ord
assert final_rest>=0 and final_ord/I16>1
print('PRODUCTION BOUND: conservation without pure-I16-source normalization does not imply xi<=1')
print('ADVERSARIAL CONTROLS PASS')
