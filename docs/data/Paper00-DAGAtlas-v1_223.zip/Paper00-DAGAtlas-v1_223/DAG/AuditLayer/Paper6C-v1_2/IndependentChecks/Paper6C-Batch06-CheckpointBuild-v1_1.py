#!/usr/bin/env python3
"""Source-bound final Paper VI-C (only) batch checkpoint and standalone audit note."""
import re, json, hashlib, zipfile, collections, datetime
from pathlib import Path
root=Path('/mnt/data'); src=root/'Paper6C-TechnicalMaterial-v1_43.tex'
lines=src.read_text().splitlines();assert len(lines)==10448
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
with zipfile.ZipFile(root/'Paper00-PapersMinimal-v2_371(1)(1).zip') as z:
 i=[x for x in z.namelist() if x.endswith('/Paper6C-TechnicalMaterial-v1_43.tex')]; assert len(i)==1
 assert hashlib.sha256(z.read(i[0])).hexdigest()==sha(src)
start,end=8898,10448
claims=[]
for i in range(start-1,end):
 m=re.search(r'\\begin\{(theorem|lemma|proposition|corollary|definition|remark|claim)\}(?:\[([^]]*)\])?',lines[i])
 if not m:continue
 kind=m.group(1)
 lab=next((a.group(1) for j in range(i,min(i+18,len(lines))) if (a:=re.search(r'\\label\{([^}]+)\}',lines[j]))),None)
 assert lab
 stop=next(j+1 for j in range(i,end) if f'\\end{{{kind}}}' in lines[j])
 claims.append({'id':lab,'kind':kind,'title':(m.group(2) or '').replace('\\texorpdfstring','').strip(), 'source_start_line':i+1,'source_end_line':stop})
assert len(claims)==32 and len({x['id'] for x in claims})==32
E3={
 'p8:prop:v2187-kinetic-smoothing-diagnostic',
 'p8:prop:v2187-linear-postmap-diagnostic',
 'p8:prop:v2187-nongaussian-axis-diagnostic',
 'p8:prop:v2187-fixed-radius-pooling-diagnostic',
 'p9:lem:lithium-k40-placement',
 'p9:lem:scalaron-certificate-acceptance',
 'p8:cor:closed-flrw-friedmann-derived',
 'p8:prop:first-full-cell-cosmology-correction',
 'p6c:prop:v353-native-action-status',
 'p6c:prop:v358-window-null-contamination',
 'p6c:prop:v358-mean-square-window',
 'p6c:prop:v358-optical-speed-counterfamily',
 }
PARTIAL={
 'p8:thm:imported-hopf-born-cosmological-carrier',
 'p8:thm:flrw-determinant-owner-inheritance',
 'p8:prop:d4-cosmology-origin',
 'p8:thm:gp2-closed-flrw-background',
 'p9:lem:local-k40-spurion-import',
 'p9:prop:lithium-k40-mirror-kernel',
 'p8:thm:cosmological-realization-criterion',
 'p9:thm:v192-g26-readout-frontier',
 }
ISSUE={
 'p8:thm:flrw-determinant-owner-inheritance':[],
}
for x in claims:
 k=x['id']; x['issue_ids']=[]
 if x['kind']=='definition':x['evidence_status']='E0_E1_STATED_DEFINITION'
 elif k in E3:x['evidence_status']='E1_E3_CHECKED_AT_EXACT_CONDITIONAL_SCOPE'
 elif k in PARTIAL:x['evidence_status']='E1_E2_WITH_E3_SUBCHECK_IMPORT_OR_OWNER_NOT_FULLY_REVERIFIED'
 elif x['kind']=='remark':x['evidence_status']='E1_SCOPE_AND_BRANCH_REVIEW'
 else:x['evidence_status']='E1_E2_SOURCE_REPLAY_IMPORTED_FULL_E3_PENDING'
 x['evidence_ids']=['B06-EV-00','B06-EV-01']
 if k in E3:x['evidence_ids'].append('B06-EV-02')
 if k in PARTIAL:x['evidence_ids'].append('B06-EV-03')
 if k=='p9:thm:v192-g26-readout-frontier':x['evidence_ids'].append('B06-EV-04')
 if k=='p8:cor:closed-flrw-friedmann-derived':x['scope_warning']='E3 checks metric-f(R) field equations on closed FLRW; physical GP1--GP2 realization remains inherited, not independently proved here.'
 if k=='p9:prop:lithium-k40-mirror-kernel':x['scope_warning']='Analytic rate-kernel slot only; no QCD-to-nuclear functional, rate amplitude or lithium abundance prediction reconstructed.'
 if k=='p8:thm:gp2-closed-flrw-background':x['scope_warning']='Mathematical ADM isotropy reduction checked; source-to-physical-FLRW premise imported from Papers II/III at claimed scope.'
 if k=='p8:thm:flrw-determinant-owner-inheritance':x['scope_warning']='Conditional on action/excess certificates and nonzero host-natural ancestry morphism, not an unconditional generated history.'
 if k=='p9:lem:scalaron-certificate-acceptance':x['scope_warning']='Finite interval inclusion proof only; no actual reheating-stress numerical certificate supplied.'
 if k=='p8:prop:v2187-linear-postmap-diagnostic':x['scope_warning']='G^-1 positive definite in quadratic-form/operator sense, not entrywise positive.'

issues=[
 {
  'id':'BH-G-000151','issue_class':'SOURCE_BRANCH_SCOPE_INCONSISTENCY','severity':'moderate',
  'lifecycle':'ACTIVE','issue_status':'established','status':'OPEN',
  'first_origin':{'paper':'Paper6C','source_file':src.name,'source_label':'p8:app:darkmatter','lines':[9946,9999]},
  'statement_layer':'SOURCE-AS-PRINTED',
  'exact_obligation':'To advertise the displayed ν_Reeb(y)=1/(1−exp(−sqrt(y))) as the native selected static RAR response requires the actual R1/R2/same-action scalar stiffness and return-ownership certificates; the current manuscript only grants that kernel an enlarged comparison-branch status.',
  'source_replayed':True,
  'independent_evidence':['B06-EV-04'], 'adversarial_evidence':['B06-EV-05'],
  'constitution_boundary':'B06-BND-01',
  'conditions_consumed':['R1','R2','same-action-Reeb-scalar-line','physical-return-ownership'],
  'conditions_open':['R1 optional branch','R2 optional branch'],
  'upstream_material_paths':[['p8:thm:v167-critical-boundary-corealization-criterion','p8:app:darkmatter']],
  'downstream_verified_paths':[],
  'other_papers_affected':[],
  'possible_unconfirmed_impacts':['p8:app:darkmatter demonstration used as physical RAR forecast'],
  'verified_bypass_routes':['p8:thm:v252-owner-factorized-terminal-rar','native S+T G26-DEEP as stated in VI-C:10234-10251'],
  'why_it_matters':'Code at lines 9949, 9992-9994 labels the Reeb profile hierarchy-selected/native, then lines 10018-10020 explicitly say it is NOT the same-action metric Green function and is usable only as an enlarged comparison; 10234-10251 distinguish independent native deep S+T law from optional elementary profile.',
  'resolution_requirement':'Explicitly scope all Reeb example headings, documentation and code as a conditional (R1/R2) comparison, or provide existing same-action owner certificates; do not replace native S+T with the example.',
  'audit_scope_limit':'No native all-order RAR kernel constructed, no physical galaxy fit, no source changes.'
 },
 {
  'id':'BH-G-000152','issue_class':'NUMERIC_IMPLEMENTATION_OMITTED_FACTOR','severity':'minor',
  'lifecycle':'ACTIVE','issue_status':'established','status':'OPEN',
  'first_origin':{'paper':'Paper6C','source_file':src.name,'source_label':'p8:app:darkmatter','lines':[10023,10034]},
  'statement_layer':'SOURCE-AS-PRINTED',
  'exact_obligation':'Numerical a_0 code must divide by 4π to reproduce the immediately preceding displayed a0=c² sqrt(2 Λ_eff)/(4π) and printed 1.146×10^-10 m/s².',
  'source_replayed':True,
  'independent_evidence':['B06-EV-02','B06-EV-05'], 'adversarial_evidence':['B06-EV-05'],
  'constitution_boundary':None,
  'conditions_consumed':['Lambda_prim=1.2835e-52 m^-2','c=299792458 m/s','a_0 SI conversion'],
  'conditions_open':[],
  'upstream_material_paths':[['p8:eq:owner-inherited-flrw-curvature-law','p8:app:darkmatter:SymPy']],
  'downstream_verified_paths':[],
  'other_papers_affected':[], 'possible_unconfirmed_impacts':['any numeric result copied from the displayed SymPy variable a_0_prim_num'],
  'verified_bypass_routes':['p8:thm:terminal-rar-readout:primary correctly normalized a0 formula'],
  'why_it_matters':'The script gives 1.4399729708×10^-9 instead of 1.1458940811×10^-10 m/s² (ratio exactly 4π). This is not a failure of the analytical formula.',
  'resolution_requirement':'Correct the printed verification code independently of any theory work; retain native and optional branch distinction.',
  'audit_scope_limit':'Exact printed code and assigned Λ only; no numerical cosmological calibration reassessment.'
 }
]
source_lines={
 'B06-BND-01':{'id':'B06-BND-01','source_stage':'numeric optional comparison at 9946-10020','source_sort':'Reeb scalar response vs native S+T metric-response operator','frozen_inventory':['active source-conditioned Schur operator','native S+T G26-DEEP'], 'licensed_operations':['Reeb profile only with R1,R2 and physical return ownership','additional history/observable pushforward'], 'quantifier':'optional all-order local-L scalar-return class, not all native static RAR','E_U_C_R_I':{'E':'analytic ν_Reeb exists for y>0','U':'optional class uniqueness requires R1/R2','C':'ordinary selected native kernel not established','R':'no actual physical ownership certificate','I':'code title incorrectly conflates optional comparator with native'}},
 'B06-BND-02':{'id':'B06-BND-02','source_stage':'final v1.43 validation/thermodynamic scope','source_sort':'conditional K40 mirror-response slot','frozen_inventory':['T0 as comparison ruler','quark mass physical RG owner','ordinary mass-seven BBN rates'], 'licensed_operations':['conditional QCD-to-nuclear response map only','no H8 rate constant'], 'quantifier':'conditional K40 rate response, not unique physical lithium abundance','E_U_C_R_I':{'E':'thermal label algebra','U':'no amplitude uniqueness','C':'channel as selected diagnostic slot','R':'QCD nuclear rate history open','I':'not a measured lithium prediction'}}
}
# E1/E2/E3/E4 check records; distinguish proof replay from script and historical owner imports.
ev=[
 {'id':'B06-EV-00','level':'E0','description':'Frozen source SHA, 32 named statement exact census and complete 1551-line source scan; prior 5 batch checkpoint hashes re-checked.'},
 {'id':'B06-EV-01','level':'E1','description':'Source-level proof and hypothesis replay for all named statements and material unnamed validation/implementation subsections.'},
 {'id':'B06-EV-02','level':'E3','description':'13 reproducible symbolic/analytical/numeric/adversarial check groups for the exact mathematical comparisons; script is only evidence for named subclaims actually reproduced.', 'artifact':'Evidence/Paper6C-Batch06-IndependentChecks-v1_1.py'},
 {'id':'B06-EV-03','level':'E2','description':'Trace imported owners/guard domain to Papers I-A/II-C/III-C/III-F/VI-A/VI-B and compare source-current 2I/RAR status; imports are NOT independently re-audited.'},
 {'id':'B06-EV-04','level':'E1+E4','description':'Read source lines 9946-10020 and 10139-10251: native S+T deep RAR separately closed; Reeb ν is conditional optional scalar-return comparison.'},
 {'id':'B06-EV-05','level':'E4','description':'Run exact printed SI snippet: 1.4399729708e-9 vs 1.1458940811e-10; factor 4π. Separate optional Reeb branch code from physical owner.'},
 {'id':'B06-EV-06','level':'E4','description':'Owner normalization line 9910 repeats BH-G-000147 (C56=R56²/U); source line 9461 and earlier VI-A establish C56=R56². Do not allocate new issue.'},
 {'id':'B06-EV-07','level':'E4','description':'Endpoint ν_Reeb(0) remains undefined in the displayed code and inherits BH-G-000143 only; zero acceleration limit is finite, distinct from factor behavior.'}
]
# reviewed edges: exact source-use witness; candidate references separated.
edges=[
 ('p8:thm:v2127-canonical-kinetic-environment-projector','p8:prop:v2187-kinetic-smoothing-diagnostic','IMPORTED_PROOF','8927-8944','projector on absolutely-continuous component; phase chart'),
 ('p8:prop:environment-green-normalization','p8:prop:v2187-linear-postmap-diagnostic','IMPORTED_PROOF','8951-8969','frozen pointwise multiplier schema c independent of f'),
 ('p8:thm:finite-mode-axis-scatter','p8:prop:v2187-nongaussian-axis-diagnostic','SCOPE_GUARD','8975-8995','Gaussian assumption cannot be dropped'),
 ('p8:cor:finite-planarity-tail','p8:prop:v2187-fixed-radius-pooling-diagnostic','SCOPE_GUARD','8975-9013','independent Gaussian copy/amplitude convention required'),
 ('p9:def:lithium-native-thermal-coordinate','p9:lem:lithium-k40-placement','REQUIRES','9055-9081','T/T0 positive; α>1'),
 ('p9:lem:lithium-k40-placement','p9:prop:lithium-k40-mirror-kernel','REQUIRES','9153-9178','thermal support only, not response amplitude'),
 ('p9:lem:local-k40-spurion-import','p9:prop:lithium-k40-mirror-kernel','REQUIRES','9173-9179','physical running quark spurion owner'),
 ('p9:def:mass-seven-mirror-projector','p9:prop:lithium-k40-mirror-kernel','REQUIRES','9163-9166','selected A=7 channel'),
 ('p9:thm:finite-bbn-response','p9:prop:lithium-k40-mirror-kernel','IMPORTED_PROOF','9153-9177','network rate-kernel response; matching still open'),
 ('p9:prop:lithium-k40-mirror-kernel','p9:cor:lithium-lab-and-deuterium-boundary','REQUIRES','9184-9214','conditional QCD/nuclear rate slot'),
 ('p9:def:scalaron-abundance-certificate-datum','p9:lem:scalaron-certificate-acceptance','REQUIRES','9281-9297','validated outward-rounded interval premises'),
 ('p8:thm:imported-hopf-born-cosmological-carrier','p8:prop:d4-cosmology-origin','IMPORTED_PROOF','9524-9605','local link octet and finite-cell imports'),
 ('p8:thm:2I-selection','p8:prop:d4-cosmology-origin','IMPORTED_PROOF','9568-9604','2I global mobile-completion branch only'),
 ('p8:thm:flrw-determinant-owner-inheritance','p8:def:curvature-shell-coordinate','REQUIRES','9496-9517','C56 and alpha, positive curvature branch'),
 ('p8:thm:gp2-closed-flrw-background','p8:cor:flrw-source-pressure-open-residues','REQUIRES','9635-9652','constituted smooth homogeneous scalar branch'),
 ('p8:thm:gp2-closed-flrw-background','p8:cor:closed-flrw-friedmann-derived','REQUIRES','9655-9683','closed ADM representative and metric f(R) action'),
 ('p8:thm:imported-hopf-born-cosmological-carrier','p8:prop:first-full-cell-cosmology-correction','IMPORTED_PROOF','9698-9713','full F4 symmetry and constant radius support'),
 ('p8:thm:v167-critical-boundary-corealization-criterion','p9:thm:v192-g26-readout-frontier','SCOPE_GUARD','10139-10184','OPTIONAL local L/Calderon route only; native S+T bypass'),
 ('p8:thm:v252-owner-factorized-terminal-rar','p8:app:darkmatter','INTERPRETATION_OF','9946-10020','CODE IS NOT CERTIFIED NATIVE SCHUR OPERATOR: nonpromoting interpretation'),
 ('p8:prop:v358-window-null-contamination','p6c:rem:v358-observer-clock-frontier','SCOPE_GUARD','10438-10445','actual measurement map, not generic top-hat'),
 ('p6c:prop:v358-optical-speed-counterfamily','p6c:rem:v358-observer-clock-frontier','SCOPE_GUARD','10438-10445','actual same-action photon propagation law distinct from free optical gK'),
 ('p8:thm:flrw-determinant-owner-inheritance','p8:app:darkmatter','SCOPE_GUARD','9949-10000','correct hierarchy scale, but Reeb kernel optional')
]
# only verified true material use may enter proof-route graph
material={'REQUIRES','IMPORTED_PROOF'}
verified=[]
for i,(fr,to,relation,locator,guard) in enumerate(edges,1):
 verified.append({'id':f'B06-EDGE-{i:03}', 'from':fr,'to':to,'kind':relation,
                  'source_use_locator':f'Paper6C:{locator}','scope_guard':guard,
                  'proof_route_id':f'B06-ROUTE-{to}', 'logic_group':'AND',
                  'review_status':'REVIEWED_MATERIAL' if relation in material else 'REVIEWED_NON_PROMOTING',
                  'proof_traversable':relation in material,'evidence_id':'B06-EV-01'})
# review external end IDs; historical nonmaterial node p8:app:darkmatter intentionally source-section, not claim
conditions=[
 {'id':'B06-FIRSTKNOWN-01','normalized_predicate':'T>0, T0>0, alpha>1, K_T:=56-8log_alpha((T/T0)^4)','origin':'Paper6C:9034-9051','category':'DEFINITION','identity_status':'SOURCE_FIRST_KNOWN; not new foundational condition','used_by':['p9:lem:lithium-k40-placement','p9:prop:lithium-k40-mirror-kernel']},
 {'id':'B06-FIRSTKNOWN-02','normalized_predicate':'physical quark spurion M_q^phys(mu) transferred by native RG and controlled QCD/chiral/nuclear matching for A=7','origin':'Paper6C:9097-9180; imported PaperVII-A','category':'PHYSICAL-IDENTIFICATION','identity_status':'IMPORTED_OWNER_REFERENCE; do not create duplicate condition node','used_by':['p9:prop:lithium-k40-mirror-kernel']},
 {'id':'B06-FIRSTKNOWN-03','normalized_predicate':'all interval primitive inputs and evolution enclosures contain exact data with outward rounding','origin':'Paper6C:9255-9297','category':'REGULARITY','identity_status':'MATHEMATICAL_STATED_FIRST_KNOWN; parameterized certificate','used_by':['p9:lem:scalaron-certificate-acceptance']},
 {'id':'B06-FIRSTKNOWN-04','normalized_predicate':'homogeneous/isotropic smooth macroscopic scalar-clock branch with positive S3 spatial geometry','origin':'Paper6C:9608-9633; inherited Papers II/III','category':'DOMAIN','identity_status':'IMPORTED_OWNER_REFERENCE; no new GP1/GP2 axioms','used_by':['p8:thm:gp2-closed-flrw-background','p8:cor:closed-flrw-friedmann-derived']},
 {'id':'B06-FIRSTKNOWN-05','normalized_predicate':'R1 same-action source additivity and R2 positive primitive return ownership','origin':'Paper6C:4807-4881 (earlier VI-A), optional','category':'PHYSICAL-IDENTIFICATION','identity_status':'EARLIER_SOURCE_OWNER; do not duplicate','used_by':['p8:app:darkmatter (optional Reeb only)']},
 {'id':'B06-FIRSTKNOWN-06','normalized_predicate':'normalized positive survey window W and square-integrable Lipschitz H on support','origin':'Paper6C:10393-10412','category':'DOMAIN','identity_status':'FIRST_KNOWN_COMPARISON; not physical observational window selection','used_by':['p6c:prop:v358-mean-square-window']},
 {'id':'B06-FIRSTKNOWN-07','normalized_predicate':'optical comparison H>0,D>0,D’>0,K>0,KD²<1 and an independent g_K>0','origin':'Paper6C:10414-10436','category':'DOMAIN','identity_status':'FIRST_KNOWN_COMPARISON; not native photon source','used_by':['p6c:prop:v358-optical-speed-counterfamily']},
 {'id':'B06-FIRSTKNOWN-08','normalized_predicate':'scalar source S_+>0 on dim_C E_+=2, scalar trace input alone','origin':'Paper6C:10320-10343','category':'DOMAIN','identity_status':'IMPORTED_OWNER: PaperIII-E action-Schur counterfamily','used_by':['p6c:prop:v353-native-action-status']},
 {'id':'B06-FIRSTKNOWN-09','normalized_predicate':'positive scalar curvature owner U with alpha>1; first F4 full-cell correction must preserve whole Hurwitz symmetry','origin':'Paper6C:9698-9713; imported PaperI-A','category':'DOMAIN','identity_status':'IMPORTED_MATHEMATICAL; no new physical selector','used_by':['p8:prop:first-full-cell-cosmology-correction']},
]
# avoid claiming identity is globally resolved where upstream import remains incomplete.
negative=[
 {'allegation':'Weak convergence forces continuity of exact kinetic projector','adjudication':'FALSE; valid singular-limit counterexample as printed','evidence_id':'B06-EV-02'},
 {'allegation':'G pointwise normalized map is uniquely the only possible linear postmap','adjudication':'FALSE for enlarged comparison; source explicitly restricts frozen multiplier schema','evidence_id':'B06-EV-02'},
 {'allegation':'Beta pooled-Gaussian law should hold for all isotropic independent copies','adjudication':'FALSE; equal-radius S4 counterexample correct','evidence_id':'B06-EV-02'},
 {'allegation':'K40 selects numerical Li abundance by hierarchy alone','adjudication':'NOT A SOURCE CLAIM; source explicitly requires QCD-to-nuclear response and network history','evidence_id':'B06-EV-03'},
 {'allegation':'GP1/GP2 automatically unique physical full FLRW dynamics in every history','adjudication':'NOT SOURCE CLAIM; statement on unperturbed smooth homogeneous scalar clock branch only','evidence_id':'B06-EV-03'},
 {'allegation':'Repeated owner typo at line 9910 should create new issue node','adjudication':'DUPLICATE: BH-G-000147 has earlier first origin at 6397-6398; only add occurrence edge','evidence_id':'B06-EV-06'},
 {'allegation':'Reeb nu(y) divergence at exact zero invalidates finite limiting acceleration','adjudication':'NO: function ν(0) undefined but yν(y) has finite zero; earlier BH-G-000143 already tracks stated domain vs factor','evidence_id':'B06-EV-07'},
 {'allegation':'Auxiliary optical-speed comparison must itself occur as physical photon transport','adjudication':'NOT SOURCE CLAIM; the positive gK family is explicitly nonnative','evidence_id':'B06-EV-02'}
]
unnamed=[
 {'lines':[8909,8914],'content':'mathematical comparison vs licensed actual native source','status':'E1 source scope checked'},
 {'lines':[9015,9020],'content':'optimized-axis vs fixed-axis tail and actual Born pushforward','status':'E1 scope checked'},
 {'lines':[9084,9095],'content':'terminal thermal conversion to ~93 keV','status':'E3 numerical replay'},
 {'lines':[9231,9248],'content':'finite entropy derivative and pure global/reduced entropy comparisons','status':'E1 source-reported checks, scripts absent; no fresh E3'},
 {'lines':[9855,9923],'content':'generated coefficient/terminal action and source normalization restatement','status':'E1 E2 prior action import; repeated BH-G-000147 at 9910'},
 {'lines':[9930,9943],'content':'pivot/rank H8 SymPy reproducibility snippet','status':'E3 independent exact arithmetic'},
 {'lines':[9946,10020],'content':'Reeb numerical implementation: conditional vs mislabeled native','status':'E4 BH-G-000151; endpoint inherits BH-G-000143'},
 {'lines':[10023,10044],'content':'RAR SI acceleration snippet','status':'E4 BH-G-000152'},
 {'lines':[10050,10093],'content':'2I harmonic rank and finite-support detectability','status':'E1/E2 imported prior 2I comb; E3 subcheck previous batches'},
 {'lines':[10095,10133],'content':'axis/Borel-Weil and Legendre trace junction firewalls','status':'E1/E2 prior owner; physical state not inferred'},
 {'lines':[10198,10300],'content':'K16/K48/deep RAR synchronization and H8 retirement','status':'E1 scope checked; no new gap beyond 151'},
 {'lines':[10345,10357],'content':'explicit native boundary/action physical discharge obligations','status':'E1 source-defined open, not a new mathematical contradiction'}
]
D={
 'record_type':'BORN_HOPF_VERIFICATION_DAG_BATCH_CHECKPOINT',
 'checkpoint_version':'v1_1','paper':'Paper6C','protocol':'Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md',
 'source_file':src.name,'batch':6,'batch_lines':[start,end],'next_batch_first_line':None,'manuscript_total_lines':len(lines),
 'frozen_sha256':{'target_tex':sha(src),'papers_minimal_archive':sha(root/'Paper00-PapersMinimal-v2_371(1)(1).zip'),'dag_atlas_archive':sha(root/'Paper00-DAGAtlas-v1_116(1).zip'), 'proof_chain_archive':sha(root/'Paper00-ProofChainAudits-v1_33(1).zip'),'verification_protocol':sha(root/'Paper00-RigorousVerificationDAGWorkProtocol-v2_4(1).md')},
 'scanned_formal_statement_count':len(claims),
 'batch_status_counts':dict(collections.Counter(c['evidence_status'] for c in claims)),
 'cumulative_claims_inventoried':247,'cumulative_source_span':[80,10448],
 'claims':claims,'evidence':ev,'issues':issues,
 'inherited_open_issue_ids':[f'BH-G-{i:06}' for i in range(134,151)],
 'inherited_occurrences':[{'issue_id':'BH-G-000147','source_lines':[9909,9910],'inherited_from':[6397,6398],'scope':'incorrect secondary owner normalization'},{'issue_id':'BH-G-000143','source_lines':[9987,9994],'inherited_from':[6200,6202],'scope':'ν(y) undefined at y=0; finite g-limit separate'},{'issue_id':'BH-G-000148','source_lines':[10139,10184],'inherited_from':[7775,7810],'scope':'historical scalar return route conditional, not native S+T'}],
 'constitution_boundary_records':list(source_lines.values()),
 'source_proof_edges_reviewed':verified,
 'negative_or_rejected_allegations':negative,
 'conditions_pending_global_registry_identity':conditions,
 'unnamed_source_sections_reviewed':unnamed,
 'coverage_classification':'32/32 named target statements source-audited; unnamed material subsections enumerated, all prior five checkpoint claims retained (cumulative 247). E3 remains incomplete for imported physical owner claims; conditional mathematical E3 does not imply physical occurrence.',
 'graph_status':'FINAL BATCH; global DAG integration and archive validation completed by separate release build, not by this file alone.',
 'zip_delivery_policy':'latest versions only; DAG v1_117 and ProofChainAudits v1_34; original inputs unchanged.'
}
(root/'Paper6C-RigorousAuditBatch06Evidence-v1_1.json').write_text(json.dumps(D,ensure_ascii=False,indent=2)+'\n')
notes=f'''# Paper VI-C — Rigorous Verification/DAG Audit, Batch 06 (Final Source Batch)\n\n**Frozen target:** `{src.name}`; SHA-256 `{sha(src)}`. **Scope:** lines **8898–10448** (last 1551 lines); no theory/source edits. **Protocol:** v2.4. **Named statements:** **32**; cumulative across batches **247**. Prior findings BH-G-000134–BH-G-000150 retained as open, not treated as fresh.\n\n## Two new issue certificates\n\n### BH-G-000151 — Optional Reeb kernel mislabeled as selected native static RAR (moderate)\nEarliest origin: lines **9946–9999** (`p8:app:darkmatter`). Code claims to implement the hierarchy-selected static RAR response via `nu_reeb`, while 10018–10020 explicitly say it is an enlarged optional comparison and **not** the same-action metric Green function. Current **10234–10251** and **7675–7748** separate the independently closed native **S+T G26-DEEP** from historical local-L/Calderón/Reeb all-order return requiring R1/R2 and physical unbounded-return ownership. This is a branch/interpretation inconsistency, not a refutation of the Reeb mathematical quotient or native deep law. *Required:* exact branch-scope correction or existing physical owner certificate, without inventing a mechanism.\n\n### BH-G-000152 — Missing 4π in printed SI SymPy check (minor)\nEarliest origin: **10023–10034**. The theoretical formula defines `a_0 = c² sqrt(2 Lambda_eff)/(4π)` but the numerical line uses `c² sqrt(2 Lambda_prim_num)` without `/ (4π)`. Independent evaluation yields **1.4399729708×10^-9 m/s²** as printed, not the comment's **1.146×10^-10**. With `/ (4π)` it gives **1.1458940811×10^-10**. The actual theoretical normalization is unaltered. *Required:* correct the code demonstration, not the physics.\n\n## Inherited occurrences\n\n- **BH-G-000147:** line **9910** repeats `C56=R56²/U`, while **9461–9462** state `R56²=C56=U alpha^-7`. Original defect at **6397–6398**; no duplicated issue.\n- **BH-G-000143:** the `nu_reeb(0)` code at **9987–9994** has the same zero-endpoint undefined-factor domain as the earlier source; the observable-weighted product has a finite limit.\n- **BH-G-000148:** historical G26 theorem at **10139–10184** is historical, not a new active RAR firewall.\n\n## Independent mathematical checks (13 reproducible groups)\n\nThe executable `Paper6C-Batch06-IndependentChecks-v1_1.py` confirms: (1) kinetic projector/smoothing singular-vs-ac behavior; (2) frozen Green normalization vs broadened Markov post-map; (3) nonGaussian axis/Rayleigh and pooled Beta variance (`6/175` vs `1/25`); (4) thermal window K=40 and 93.119 keV orientation; (5) `H8=761/280` and 24-cell sixth-moment defect `3/8`; (6) closed-FLRW `f(R)` 00/lapse constraint; (7) spatial/Raychaudhuri equation; (8) non-scalar `S+` with same scalar trace; (9) exact top-hat commutator `D(WF)=4 A4 y³ + A3 h²`; (10) weighted mean-square variance identity; (11) positive optical-speed counterfamily; (12) printed missing-`4π` countercheck; and (13) repeated earlier owner-normalization error. No physical initial-state or observables license follows from these mathematical tests.\n\n## Statement dispositions\n\n| # | Lines | Source label | Evidence status |\n|---:|---:|---|---|\n'''
for i,c in enumerate(claims,1):notes+=f"| {i} | {c['source_start_line']}–{c['source_end_line']} | `{c['id']}` | `{c['evidence_status']}` |\n"
notes+='''\n## Unnamed source-section coverage and audit limitations\n\nThe source groups for thermal orientation, optional H8 code, scalaron interval certificate, terminal action and normalized hierarchy, Reeb example, K16/K48 sync, optical/observer limits, and source/action discharge ledger were also reviewed. The exact unnamed-section index is in `Paper6C-RigorousAuditBatch06Evidence-v1_1.json`. Full upstream physical-owner correctness was not inferred from a local numerical/symbolic E3 check. No actual numeric lithium response, black-hole full-history certificate, observer-state selection, or exact Reeb native owner was verified. No separate real parallel agents were available; E1/E3/E4 are distinct test methods, not agent counts.\n'''
(root/'Paper6C-RigorousAuditBatch06-v1_1.md').write_text(notes)
print('WROTE BATCH6',len(claims),'issues',len(issues),'edges',len(verified),'E3',len(E3),'partial',len(PARTIAL),'bytes',len(json.dumps(D)))
