#!/usr/bin/env python3
"""Paper6C audit Batch 05: independent E3/E4 controls; no modification of theory/source.
Frozen source range: 6888-8897. Printed physical claims are checked only within stated domains.
"""
import math
import numpy as np
import sympy as s

records=[]
def record(key, value):
    print(f'{key}: {value}')
    records.append((key,str(value)))

# E3: 2-line C2 intertwiner rank and Schur complement order.
a,b,c,d=s.symbols('a b c d', real=True)
Z=s.diag(1,-1); T=s.Matrix([[a,b],[c,d]])
assert Z*T-T*Z == s.Matrix([[0,2*b],[-2*c,0]])
record('E3-C2-intertwiner-free-parameters', 'a,d only; dim Hom_C2=2')
for eps in [s.Rational(1,100), s.Rational(1,10000)]:
    A=s.Integer(2); B=s.sqrt(eps); C=eps
    H=s.Matrix([[A,B],[B,C]])
    assert s.factor(H.det()) == eps
    assert s.simplify(A - B*B/C) == 1
record('E4-Schur-before-quotient-positive-H-eps', 'A=2, B=sqrt(eps), C=eps => Schur=1, quotient-first=2; det(H)=eps>0')

# E3: scalar finite-collar DtN analyticity, limits, universal bounded difference.
mu,L=s.symbols('mu L', positive=True)
ss=s.symbols('ss',real=True)
u=s.cosh(mu*(L-ss))/s.cosh(mu*L)
assert s.simplify((-s.diff(u,ss,2)+mu**2*u))==0
assert s.simplify(u.subs(ss,0))==1
assert s.simplify(s.diff(u,ss).subs(ss,L))==0
assert s.simplify(-s.diff(u,ss).subs(ss,0)-mu*s.tanh(mu*L))==0
y=s.symbols('y',positive=True)
assert s.simplify(s.limit(s.sqrt(y)*s.tanh(L*s.sqrt(y))/y,y,0)) == L
bound_max=[]
for lv in (0.15, 1.0, 10.0):
    xs=np.concatenate(([0.0],np.geomspace(1e-7,60,10000)))
    dif=xs*(1-np.tanh(xs))/lv
    assert np.max(dif)<=1/(math.e*lv)+1e-13
    bound_max.append((lv,round(float(np.max(dif)),9),round(1/(math.e*lv),9)))
record('E3-DtN-absolute-error-upper-bound',bound_max)
record('E3-DtN-relative-critical-limits', 'fixed finite L: y↓0 gives 0; L→∞ at y>0 gives 1')

# E3: finite-depth return expansion with t=sqrt(y)
t=s.symbols('t', nonnegative=True)
for N in (0,1,2,5,10):
    nu=sum(s.exp(-n*t) for n in range(N+1))
    assert s.simplify(nu.subs(t,0))==N+1
    assert s.simplify(s.diff(nu,t).subs(t,0)) == -s.Rational(N*(N+1),2)
record('E3-finite-Reeb-return-jet','nu_N=N+1-N(N+1)/2 *sqrt(y)+O(y), N=0,1,2,5,10')

# E3: exact local f_RR quadratic-jet algebra.
Q,U,C7,R=s.symbols('Q U C7 R',positive=True)
fRR=2*Q*(R**2-C7**2)/((U+C7)*R**2)
assert s.simplify(fRR.subs(R,U)/2 - Q*(U-C7)/U**2)==0
record('E3-local-quadratic-jet','beta_jet_U=Q(U-C7)/U^2; R_quad reciprocal verified')

# E3: Kottler invariants, roots, infall clock and shell bounds.
rs,Rcur,r,U0,Rmom=s.symbols('rs Rcur r U0 Rmom', positive=True)
Icur=Rcur**2+72*rs**2/r**6
# Independent orthonormal curvature components of ds²=-Fdt²+dr²/F+r²dOmega².
F=1-rs/r-Rcur*r**2/12
Fprime=s.diff(F,r); Fsecond=s.diff(F,r,2)
Kretsch=s.factor(4*((Fsecond/2)**2+4*(Fprime/(2*r))**2+((1-F)/r**2)**2))
assert s.simplify(Kretsch-(12*rs**2/r**6+Rcur**2/6))==0
rL=(72*rs**2/(U0-Rcur**2))**s.Rational(1,6)
assert s.simplify(Icur.subs(r,rL)-U0)==0
assert s.simplify(s.diff(Icur,r)+432*rs**2/r**7)==0
rstar=(rs*Rmom**2)**s.Rational(1,3)
clock=s.integrate(s.sqrt(r/rs),(r,0,rstar))
assert s.simplify(clock-2*Rmom/3)==0
record('E3-Kottler-Icur-and-infall','Icur=R_ext^2+72(rs/r^3)^2; shell max exact; infall=2 Rmom/(3c)')

# E3: spin-frame trace with independent 4x4 Clifford matrices and arbitrary 6x6 pair operator.
sigma1=np.array([[0,1],[1,0]],complex)
sigma2=np.array([[0,-1j],[1j,0]],complex)
sigma3=np.diag([1,-1]).astype(complex)
unit2=np.eye(2,dtype=complex)
gamma=[np.kron(sigma1,unit2),np.kron(sigma2,unit2),np.kron(sigma3,sigma1),np.kron(sigma3,sigma2)]
for i in range(4):
 for j in range(4):
    v=gamma[i]@gamma[j]+gamma[j]@gamma[i]
    assert np.allclose(v, 2*(i==j)*np.eye(4), atol=1e-12)
pairs=[(i,j) for i in range(4) for j in range(i+1,4)]
rng=np.random.default_rng(206)
K=rng.normal(size=(6,6)); K=(K+K.T)/2
Rabcd=np.zeros((4,4,4,4))
for i,(a0,b0) in enumerate(pairs):
 for j,(c0,d0) in enumerate(pairs):
    k=K[i,j]
    Rabcd[a0,b0,c0,d0]=k;Rabcd[b0,a0,c0,d0]=-k
    Rabcd[a0,b0,d0,c0]=-k;Rabcd[b0,a0,d0,c0]=k
G2={(i,j):(gamma[i]@gamma[j]-gamma[j]@gamma[i])/2 for i in range(4) for j in range(4)}
LHS=0
for a0 in range(4):
 for b0 in range(4):
    Omega=sum((Rabcd[a0,b0,c0,d0]/4)*G2[(c0,d0)] for c0 in range(4) for d0 in range(4))
    LHS+=np.trace(Omega.conj().T@Omega).real
RHS=np.sum(Rabcd**2)/2
assert np.isclose(LHS,RHS,rtol=1e-12)
record('E3-spin-curvature-trace',(round(LHS,8),round(RHS,8)))

# E3: exceptional-root tight-frame implication independently in matrix form.
Rframe=np.tile(np.eye(6),(12,1))  # a tight frame witness of the asserted 12I Gram
assert np.allclose(Rframe.T@Rframe,12*np.eye(6))
S=np.eye(6); S[0,0]=0; S[-1,-1]=0; S[0,-1]=1; S[-1,0]=1
sigma6=np.eye(6)
J=Rframe@S@sigma6/math.sqrt(12)
assert np.allclose(J.T@J,np.eye(6))
Y=Rframe@S@sigma6@K
I=24*np.sum(K**2)
assert np.isclose(np.sum(Y**2),12*np.sum(K**2))
assert np.isclose(I,2*np.sum(Y**2))
chi=3.0
Ksw=np.diag([-chi,chi/2,chi/2,chi,-chi/2,-chi/2])
Ysw=Rframe@Ksw
assert np.isclose(np.linalg.norm(Ysw),6*chi)
assert np.isclose(2*np.sum(Ysw**2),72*chi**2)
record('E3-root-frame-norm','given 12I Gram: Icur=2||Y||^2=24||J K||^2; Schwarz Y=6|chi|')

# E3: Berger conditional factor (source-imported formula independently tested).
z=s.symbols('z',real=True)
identity=s.expand(11*z**2-24*z+13 - (z-1)*(11*z-13))
assert identity==0
for ez in [0.01,0.125,0.36,0.64,0.99]:
    assert (ez-1)*(11*ez-13)>0
record('E3-Berger-cap-rigidity','factorization and positive excess on 0<epsilon<1')

# E4: Weyl-vacuum counterexample to unrestricted stationary-axisymmetric Kerr uniqueness.
# Static, axisymmetric Weyl metric: ds²=-exp(2psi)dt²+exp(-2psi)[exp(2g)(drho²+dz²)+rho² dphi²].
rho,zz,m=s.symbols('rho zz m', positive=True)
rr=s.sqrt(rho**2+zz**2)
psi=-m/rr
g=-m**2*rho**2/(2*rr**4)
assert s.simplify(s.diff(psi,rho,2)+s.diff(psi,rho)/rho+s.diff(psi,zz,2))==0
assert s.simplify(s.diff(g,rho)-rho*(s.diff(psi,rho)**2-s.diff(psi,zz)**2))==0
assert s.simplify(s.diff(g,zz)-2*rho*s.diff(psi,rho)*s.diff(psi,zz))==0
th,Rr=s.symbols('theta Rr', positive=True)
# Intrinsic curvature of each constant-lapse 2-sphere, using theta∈(0,pi).
sqrtE=Rr*s.exp(m/Rr-m**2*s.sin(th)**2/(2*Rr**2))
sqrtG=Rr*s.exp(m/Rr)*s.sin(th)
Ktheta=s.simplify(-s.diff(s.diff(sqrtG,th)/sqrtE,th)/(sqrtE*sqrtG))
Kexpected=s.exp(-2*m/Rr+m**2*s.sin(th)**2/Rr**2)*(1-m**2*s.cos(th)**2/Rr**2)/Rr**2
assert s.simplify(Ktheta-Kexpected)==0
Kpole=s.exp(-2*m/Rr)*(1-m**2/Rr**2)/Rr**2
Kequ=s.exp(-2*m/Rr+m**2/Rr**2)/Rr**2
assert s.simplify((Kequ-Kpole).subs(Rr,2*m))>0
record('E4-Curzon-Weyl-exterior','Ricci-flat Weyl equations exact; static axisym asymptotic exterior, lapse-level S² K(pole) ≠ K(equator), hence not Schwarzschild/Kerr')

# E2: arithmetic-only checks for unreproducible nonlinear source memory certificate.
assert abs((-4.940162149375)+(4.940162149375))<2e-13
assert .5-.446275223520>.0537
record('E2-printed-source-memory-arithmetic', 'Raychaudhuri printed pair cancels; buffer margin >0.0537; ODE cannot be replayed without cited scripts/state packet')

print(f'PASS {len(records)} independent/adversarial subchecks')
