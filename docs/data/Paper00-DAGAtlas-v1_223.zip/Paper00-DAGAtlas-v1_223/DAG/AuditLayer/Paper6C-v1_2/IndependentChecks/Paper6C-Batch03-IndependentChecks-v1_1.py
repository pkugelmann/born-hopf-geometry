"""Rigorous source-independent algebra/numerics, Paper6C v1_43 lines 3158--5295.
Only tests printed mathematical consequences on their explicit conditional branches.
No observational state, physical transition, or unsupplied source coefficient is inferred.
"""
import numpy as np
import sympy as s
from math import sqrt, pi, exp, log, sinh, cosh

def near(label, actual, expected, rel=3e-4):
    assert abs(actual-expected)<=rel*max(1e-30,abs(expected)), (label,actual,expected)
    print(f'{label}: {actual:.13g}  printed: {expected:.13g}')

# Independent metrological natural-unit pipeline from the declared primitive inputs.
delta=1/(6*sqrt(2)); L=4*pi*pi+delta;alpha=exp(L); M=2.435e18; U=4*M*M; gstar=427/4
MH=M/(2*sqrt(3))*exp(-pi*pi-delta/4)
gamma=MH**3/(192*pi*M**2)
c=(90/(pi*pi*gstar))**.25
T0=c*sqrt(gamma*M)
C_reh=(90/(pi*pi*gstar))**.25/(sqrt(2*pi)*48**1.25)
T0b=C_reh*sqrt(U)*alpha**(-3/8)
assert abs(T0-T0b)/T0 <1e-14
near('M_H [GeV]',MH,3.53e13,rel=0.02)
near('Gamma_s [GeV]',gamma,12.30,rel=0.01)
near('T0 [GeV]',T0,2.9588e9,rel=0.001)
E16=sqrt(U)*alpha**(-.5)
T16=(30/(pi*pi*gstar))**.25*E16
near('E16 [GeV]',E16,1.2283113e10,rel=0.002)
near('T16(xi=1) [GeV]',T16,5.0457050e9,rel=0.002)
xi_delta=delta
near('T16(xi=delta) [GeV]',T16*xi_delta**.25,2.9563463e9,rel=0.002)
near('T16(delta visible) [GeV] [as printed arithmetic]',T16*(xi_delta*.6)**.25,2.6019150e9,rel=0.002)
xi_dec=sqrt(alpha)/(2**22*3**4*pi*pi)
near('xi_dec',xi_dec,0.118243108614,rel=1e-8)
near('xi_delta',xi_delta,0.117851130198,rel=1e-9)
near('relative xi diff',xi_dec/xi_delta-1,3.32604716e-3,rel=1e-6)
near('relative T diff',(xi_dec/xi_delta)**.25-1,8.30476679e-4,rel=1e-6)

# Independent algebraic incompatibility of two source-printed SAME xi conditions.
# Xi16_delta: xi_dyn = delta; DEM15 + saturated dep: xi_dyn = 9/15*1 = .6.
assert abs(xi_delta-.6)>0.48
print('SOURCE-BRANCH CONFLICT: xi_dyn(delta)=',xi_delta,'vs xi_dyn(DEM15, eps=1)=',.6)
print('If delta denotes PRE-split scalaron fraction, a separate variable is required; source uses xi_dyn.')

for eff in [0,.2,.5,1]:
 B8=8/15*eff; B1=1/15*eff; Brem=1-3/5*eff
 assert abs(B8+B1+Brem-1)<1e-14
print('SECTOR LEDGER: all 4 tested efficiencies conserve unit source mass-energy')
for name,v,expected in [('gamma8',12.3*8/15,6.56),('gamma1',12.3/15,.820),('gammavis',12.3*3/5,7.38),('gammarem',12.3*2/5,4.92)]: near(name,v,expected,1e-10)
# IMPORTANT: the printed 2.96e9 multiplication does not give the printed 2.6041e9.
actual_rounded=2.96e9*.6**.25
actual_unrounded=2.9588e9*.6**.25
near('Tvis using unrounded branch',actual_unrounded,2.6041e9,1e-4)
assert abs(actual_rounded-2.6041e9)>1e6
print('SOURCE-ROUNDING ISSUE: 2.96e9 factor gives',actual_rounded, 'not 2.6041e9; full 2.9588e9 gives',actual_unrounded)

# Majorana y phi N N vertex: unique maximum in 0<x<1/2.
r=s.symbols('r',positive=True); b=2*r*(1-4*r)**s.Rational(3,2)
assert s.solve(s.diff(b,r),r)==[s.Rational(1,10),s.Rational(1,4)]  # second stationary point is excluded branch endpoint
assert s.simplify(b.subs(r,s.Rational(1,10))-s.Rational(1,5)*(s.Rational(3,5))**s.Rational(3,2))==0
near('Majorana maximal width ratio',float(b.subs(r,s.Rational(1,10))),.09295,1e-4)
# Geometric projection no unmarked O(8)xO(9) operator; marked rank-one amplitude c.
u8=np.ones(8)/sqrt(8);u9=np.ones(9)/3
for cval in [0,.2,.5,1]:
 T=cval*np.outer(u9,u8)
 assert np.allclose(T@u8,cval*u9)
 assert abs(np.linalg.norm(T@u8)**2-cval*cval)<1e-14
 assert abs(np.sum(T*T)-cval*cval)<1e-14
assert abs(np.outer(u9,u8)[0,0]-1/sqrt(72))<1e-14
print('TRANSITION COUNTERFAMILY: full [0,1] Born probability under fixed 8/9 dimensions.')

# Check 2x2 finite Dirac response with an independent spectral diagonalization and finite differences.
Z=np.array([[1,0],[0,-1]],complex); X=np.array([[0,1],[1,0]],complex)
for PP,MM in [(1.9,3.2),(2.3,0.),(.4,1.)]:
 def H(q):return PP*exp(2*q)*Z+MM*exp(q)*X
 E=sqrt(PP*PP+MM*MM)
 vals,vec=np.linalg.eigh(H(0)); D=2*PP*Z+MM*X;Q=4*PP*Z+MM*X
 off=abs((vec.conj().T@D@vec)[0,1]); assert abs(off-abs(MM*PP)/E)<1e-12
 hh=1.e-4; epp=(np.linalg.eigvalsh(H(hh))[1]-2*E+np.linalg.eigvalsh(H(-hh))[1])/hh**2
 epp_src=(MM*MM+4*PP*PP)/E+MM*MM*PP*PP/E**3
 assert abs(epp-epp_src)<2e-7,(PP,MM,epp,epp_src)
 # stationary occupied minus/unoccupied r=1: Q+Pi(0) = -E''
 Qbar=np.real((vec.conj().T@Q@vec)[0,0]); pi0=-MM*MM*PP*PP/E**3
 assert abs(Qbar+pi0+epp_src)<1e-12
 print('DIRAC P,M,Epp',PP,MM,epp_src)

# R1 Cauchy response; Reeb Green return ratio on y>0, including asymptotic and zero endpoint.
for yy in [.001,.01,.1,1,3,12]:
 q=exp(-sqrt(yy)); pos=(1-q)**(-1)
 G=lambda tau: exp(-sqrt(yy)*abs(tau))/(2*sqrt(yy))
 assert abs(G(2)/G(1)-q)<1e-14
 assert abs(sum(q**n for n in range(40000))-pos)<1e-9
 assert abs(yy*pos-yy/(1-q))<1e-13
print('REEB: one-sided positive series and Green transfer ratio verified for y>0')
y=s.symbols('y',positive=True)
lim=s.limit(y/(1-s.exp(-s.sqrt(y))),y,0,dir='+')
assert lim==0
assert s.limit(1/(1-s.exp(-s.sqrt(y))),y,0,dir='+')==s.oo
print('REEB ENDPOINT: nu(y) diverges as y->0+, observable y*nu(y)->0. Original nu(0) undefined.')

# Hopf charge monoid -> O(s) and Schur dimension, hierarchy readout numerical endpoints.
for sd in range(7):
 # dim H0(CP1,O(s))=s+1; Lambda_s=alpha^{s/16}/(s+1)
 ll=alpha**(sd/16)/(sd+1)
 assert ll>0
 if sd>0: assert ll>alpha**((sd-1)/16)/sd
 print('HOPF shell depth',sd,'section dim',sd+1,'Lambda',ll)
l1=alpha**(1/16)/2;l2=alpha**(2/16)/3
eta=log(18/l1)/log(l2/l1)
near('Lambda1',l1,6,0.02)
near('Lambda2',l2,47,.02)
near('eta_log(18)',eta,.54,.02)
assert abs(l1**(1-eta)*l2**eta-18)<1e-12

# Exactly H/m=1 at H_end=0.3m; matter e-fold estimate.
near('Gamma/H_end',gamma/(.3*MH),1.16e-12,.01)
print('ALL INDEPENDENT CHECKS COMPLETED')
