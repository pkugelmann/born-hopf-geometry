"""Independent exact tests (Paper VI-C lines 1888--3154)."""
from fractions import Fraction
from math import sqrt,pi,log,exp
from collections import defaultdict
import numpy as np
from scipy.special import betainc
from scipy.stats import beta

# 2I Molien coefficient enumeration from 1+t^30/((1-t^12)(1-t^20))
mu=defaultdict(int)
for a in range(100):
 for b in range(100):
  for c in [0,30]:
   mu[12*a+20*b+c]+=1
onset=[k for k in range(1,120) if mu[k]!=0]
assert onset[:9]==[12,20,24,30,32,36,40,42,44]
assert all(mu[k+60]-mu[k]==1 for k in range(0,360,2))
assert all(mu[k+60]-mu[k]==0 for k in range(1,360,2))
equalities=[k for k in range(1,360) if 13*mu[k]==k+1]
assert equalities==[12]
assert all(13*mu[k]<=k+1 for k in range(1,360))
# group volume normalization and multiplicity
assert mu[12]==1
print('MOLIEN first_allowed:',onset[:15], 'nonconstant equality',equalities,
      'sample k=12', Fraction(13*mu[12],13), 'k=60',Fraction(13*mu[60],61))

# Independent Hilbert series for the E6/E7/E8 binary-polyhedral invariant rings
# 2T: (1+t^12)/((1-t^6)(1-t^8)); 2O: (1+t^18)/((1-t^8)(1-t^12)).
for name,a,b,extra,kfirst in [('2T',6,8,12,6),('2O',8,12,18,8),('2I',12,20,30,12)]:
    bins=defaultdict(int)
    for i in range(40):
      for j in range(40):
       for c in [0,extra]: bins[a*i+b*j+c]+=1
    nonzero=next(k for k in range(1,100) if bins[k]>0)
    assert nonzero==kfirst
    print('EXCEPTIONAL ONSET',name,nonzero, 'Haar fidelity degree',nonzero-1)

# Frontier event values, sqrt-floor and match cutoff
L=4*pi*pi+1/(6*sqrt(2));U=1.;LAMBDA2=96*pi*pi*U
m_P=max(1,int(np.floor(np.sqrt(1+6*LAMBDA2/U)-1)))
assert m_P==74
assert 6*LAMBDA2/U==576*pi*pi
assert max(1,int(np.floor(np.sqrt(1+6*1.33332)-1)))==1
assert max(1,int(np.floor(np.sqrt(1+6*(4/3))-1)))==2
N_2_12=.5*log(12*14/8)
assert abs(N_2_12-.5*log(21))<1e-14
plateau61=2/sqrt(3)*exp(-61)
assert abs(plateau61-3.72e-27)<1e-29
for m,p,ratio in [(3,4,Fraction(15,8)),(4,3,Fraction(3)),(6,2,Fraction(6)),(12,1,Fraction(21))]:
 assert m*p>=12 and (m-1)*p<12
 assert abs(exp(2*(.5*log(m*(m+2)/8)))-float(ratio))<1e-10
print('FRONTIER m_planck:',m_P, 'N_2_12:',N_2_12,'61 plateau bound:',plateau61)

# Step: exact closed harmonic eigen-wavenumber, not flat k, at constant H.
k1,k2=3,4
N_exact=.5*log(k2*(k2+2)/(k1*(k1+2)))
N_flat=log(k2/k1)
print('CLOSED-HORIZON example k=3->4: deltaN_exact',N_exact,
      'log(k2/k1)',N_flat,'e^DeltaN',exp(N_exact), 'k2/k1',k2/k1)

# Exact SU(2) angular momentum matrices for real extremal pairs
for ell in range(2,9):
 n=2*ell+1
 Jplus=np.zeros((n,n),complex)
 ms=np.arange(-ell,ell+1)
 for i,m in enumerate(ms[:-1]):
  Jplus[i+1,i]=sqrt((ell-m)*(ell+m+1))
 Jminus=Jplus.conj().T
 Jx=(Jplus+Jminus)/2
 Jy=(Jplus-Jminus)/(2j)
 P=np.zeros((n,n),complex);P[0,0]=P[-1,-1]=1
 # Real-valued signal condition m -> (-1)^m conjugation
 for phi in [.0,.6,1.57]:
  a0=np.zeros(n,complex)
  a0[-1]=np.exp(1j*phi)/sqrt(2)
  a0[0]=(-1)**ell*np.exp(-1j*phi)/sqrt(2)
  Aa=np.column_stack([(np.eye(n)-P)@J@a0 for J in [Jx,Jy]])
  G=Aa.conj().T@Aa
  assert np.allclose(G,np.eye(2)*ell/2,rtol=0,atol=1e-13), (ell,phi,G)
 print('AXIS Gram ell',ell,'diag ell/2:',ell/2)

# Betas: 2 + (2ell-1) real Gaussian degrees -> Beta(1, (2ell-1)/2)
for ell in range(2,6):
 for N_eff in [1,2,15]:
  a,b=N_eff,N_eff*(2*ell-1)/2
  for p in [.1,.5,.9]:
   if N_eff==1:
    assert abs((1-p)**((2*ell-1)/2) - (1-betainc(a,b,p)))<1e-14
  if N_eff==1: print('FIXED-AXIS Beta',ell,'a,b:',a,b,'tail p=.9:',1-betainc(a,b,.9))
print('All closed-form checks passed')
