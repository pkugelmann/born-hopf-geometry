#!/usr/bin/env python3
"""Paper VI-C Batch 06 independent E3/E4 checks, fixed source domain, no theory edits."""
from fractions import Fraction as F
from math import pi, sqrt, exp, log, isclose
import sympy as S
from scipy.constants import c, Boltzmann

results=[]
def check(label, cond, info):
    assert cond, (label, info)
    results.append((label,info))

# L8916: Lebesgue decomposition on momentum graph vs 3-D smooth Gaussian.
# Explicit finite-dimensional evidence: graph support has 6D Liouville measure zero;
# epsilon>0 convolution density is strictly positive in momentum fibers.
eps=S.symbols('eps',positive=True)
test_moment=(1+2*eps**2)**S.Rational(-3,2)
check('kinetic-smoothing-noncommutation',S.limit(test_moment,eps,0,dir='+')==1 and test_moment.subs(eps,S.Rational(1,2))<1 and S.limit(eps**3,eps,0,dir='+')==0,
      f'Gaussian ∫exp(-|p|²) dN(0,eps² I)=(1+2eps²)^(-3/2) -> 1; the delta graph is 6D-Liouville-null (codimension 3), while eps-Gaussian is ac for every eps>0.')

# L8951-70: frozen pointwise schema vs arbitrary Markov post-map.
G=S.Matrix([[2,1],[1,2]])
T=G/3
P=S.ones(2)/2
f=S.Matrix([1,0])
check('pointwise-green-and-comparison',G.det()==3 and T*S.ones(2,1)==S.ones(2,1) and P*T*S.ones(2,1)==S.ones(2,1) and T*f!=P*T*f,
      f'Tf={tuple(T*f)}, PTf={tuple(P*T*f)}; G inverse eigenvalues {G.inv().eigenvals()}')

# L8982-9013: Rayleigh tail contrast and independent uniform-sphere pooling.
var_single=(F(1,1)*F(3,2))/(F(5,2)**2*F(7,2))
var_pool=var_single/2
var_beta23=F(2*3,5*5*6)
check('nonGaussian-axis-and-pooling',var_single==F(12,175) and var_pool==F(6,175) and var_beta23==F(1,25) and exp(-2)>0,
      f'fixed-radius max diff 2sqrt2 s but Rayleigh tail exp(-2)={exp(-2):.9f}; pooled var {var_pool} != {var_beta23}')

# L9034: thermal K=40 coordinate and current CMB comparison.
alpha=exp((2*pi)**2+1/(6*sqrt(2)))
T0=2.7255
Tc=T0*sqrt(alpha)
energy_keV=Tc*Boltzmann/(1000*1.602176634e-19)
check('thermal-K40-placement',abs(4*log(sqrt(alpha))/log(alpha)-2)<1e-12 and abs((56-8*2)-40)<1e-12 and 92<energy_keV<94,
      f'alpha={alpha:.12g}; Tc={Tc:.9g} K; energy={energy_keV:.9g} keV')

# L9390-9409: carrier ranks, H8, and independent 24-cell cubature at l9703.
H8=sum(F(1,k) for k in range(1,9))
# 8 coordinate Hurwitz units with first coordinate +/-1 only twice;
# 16 half-units first coordinate +/-1/2; S3 sixth moment=5/64.
cell6=F(2,1)+F(16,64)
sphere6=F(24*5,64)
diff=cell6-sphere6
check('Hurwitz-D4-and-F4-moments',H8==F(761,280) and cell6==F(9,4) and diff==F(3,8),
      f'H8={H8}, cell6={cell6}, sphere6={sphere6}, defect={diff}, fullcell=24, link=8, reduced=7')

# L9654: independent f(R) 00/ii equations by contraction of metric field equation
Ff,H,Hd,adot,addot,fdot,fddot,R,f,rho,p,k,a,kap=S.symbols('F H Hdot adot addot Fdot Fddot R f rho p k a kap', nonzero=True)
# Ric00=-3(Hdot+H^2), Ric_ij/gij=Hdot+3H^2+2k/a^2
# covariant differential (nabla_00-g00 Box)F=-3H Fdot; spatial=(Fddot+2H Fdot).
# Use R=6(Hdot+2H^2 +k/a^2), map to first Friedmann constraint
eq00=-3*Ff*(Hd+H**2)+f/2+3*H*fdot-kap*rho
con1=3*Ff*(H**2+k/a**2)-kap*rho-(Ff*R-f)/2+3*H*fdot
check('closed-fR-00-constraint',S.simplify((con1-eq00).subs(R,6*(Hd+2*H**2+k/a**2)))==0,
      'Field eq 00 with Ric00=-3(Hdot+H^2) gives 3F(H²+k/a²)=κ²ρ+(FR-f)/2−3H Fdot.')
eqij=Ff*(Hd+3*H**2+2*k/a**2)-f/2-fddot-2*H*fdot-kap*p
ray=-2*Ff*(Hd-k/a**2)-kap*(rho+p)-fddot+H*fdot
check('closed-fR-raychaudhuri',S.simplify(ray-(eqij+eq00))==0,
      'Subtracting 00 and spatial Einstein-frame metric-f(R) components gives -2F(Hdot−k/a²)=κ²(ρ+p)+Fddot−H Fdot.')

# L10320: precise positive non-scalar 2x2 witness satisfying scalar trace.
b=S.symbols('b',positive=True)
Sm=S.diag(S.sqrt(S.Rational(3,4))*b,S.sqrt(S.Rational(3,2))*b)
check('scalar-source-nonidentity',S.simplify(S.trace(Sm.inv()**2)-2/b**2)==0 and Sm[0,0]!=Sm[1,1],
      f'S=diag(sqrt3 b/2,sqrt(3/2)b), Tr S^-2={S.trace(Sm.inv()**2)} but S!=b I2')

# L10364: top-hat window and null noncommutation.
y,h,A0,A2,A3,A4=S.symbols('y h A0 A2 A3 A4',real=True)
t=S.symbols('t',real=True)
Fpoly=A0+A2*y**2+A3*y**3+A4*y**4
W=S.simplify(S.integrate(Fpoly.subs(y,t),(t,y-h,y+h))/(2*h))
D=lambda x:S.simplify(S.diff(x,y)-y*S.diff(x,y,2)+y**2*S.diff(x,y,3)/2)
check('window-kinematic-null',S.simplify(D(Fpoly)-4*A4*y**3)==0 and S.simplify(D(W)-4*A4*y**3-A3*h**2)==0,
      f'D(F)={D(Fpoly)}, D(WF)={D(W)}')

# L10393: exact variance decomposition and Lipschitz variance inequality.
w=S.symbols('w',real=True)
h1,h2=S.symbols('H1 H2',real=True)
mean=w*h1+(1-w)*h2
var=w*(h1-mean)**2+(1-w)*(h2-mean)**2
ms=w*h1**2+(1-w)*h2**2
check('variance-decomposition',S.simplify(ms-mean**2-var)==0 and S.simplify(var-w*(1-w)*(h1-h2)**2)==0,
      'E(H²)=E(H)²+Var(H); independent-copy Lipschitz bound follows pointwise.')

# L10414 optical-speed counterfamily for same H,D different positive K.
Hval=2.3; Dval=.61; Dp=1.4; speed=299792458
K1,K2=.1,.4
opt=lambda K:Hval*Dp/(speed*sqrt(1-K*Dval**2))
check('optical-speed-counterfamily', all(isclose((Hval*Dp/speed)**2,opt(K)**2*(1-K*Dval**2), rel_tol=1e-13) for K in [K1,K2]) and opt(K1)!=opt(K2),
      f'same H,D with K=0.1 or 0.4 and distinct positive g_K ({opt(K1)}, {opt(K2)})')

# L10023: exact audit of printed SymPy snippet; its variable is missing /(4*pi).
Lambda_prim_num=1.2835e-52
as_printed=c**2*sqrt(2*Lambda_prim_num)
corrected=as_printed/(4*pi)
check('NUMERICAL_E4_MISSING_4PI',abs(as_printed-1.146e-10)>1e-9 and abs(corrected-1.146e-10)<5e-14,
      f'code-as-printed={as_printed:.12g} m/s2, stated={1.146e-10}, formula={corrected:.12g}, factor={as_printed/corrected:.12g}')

# L9909 (repeated of BH-G-000147): owner dimensional consistency.
Utest=7.123
C=Utest*alpha**-7
r56sq=Utest*alpha**-7
check('E4_REPEATED_OWNER_NORMALIZATION_147',isclose(C,r56sq,rel_tol=1e-14) and not isclose(C,r56sq/Utest,rel_tol=1e-14),
      'Paper L9910 repeats C56=R56²/U while L9461 fixes R56²=C56; this inherits BH-G-000147.')

for label, msg in results:print('PASS',label,'|',msg)
print('TOTAL',len(results),'CHECK GROUPS PASSED')
