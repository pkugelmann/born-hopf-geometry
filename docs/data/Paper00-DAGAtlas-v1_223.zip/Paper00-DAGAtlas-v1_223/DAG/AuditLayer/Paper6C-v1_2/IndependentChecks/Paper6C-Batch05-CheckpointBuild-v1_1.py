#!/usr/bin/env python3
"""Build factual, source-located Paper VI-C Batch 05 audit checkpoint. No source/ZIP mutation."""
import hashlib,json,re,os,collections,datetime,zipfile
from pathlib import Path
ROOT=Path('/mnt/data'); SRC=ROOT/'Paper6C-TechnicalMaterial-v1_43.tex'
lines=SRC.read_text().splitlines(); start,end=6888,8897
assert len(lines)==10448

def shafile(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
sha=shafile(SRC)
arch=ROOT/'Paper00-PapersMinimal-v2_371(1)(1).zip'
with zipfile.ZipFile(arch) as z:
    target=[n for n in z.namelist() if n.endswith('/Paper6C-TechnicalMaterial-v1_43.tex')]
    assert len(target)==1
    assert hashlib.sha256(z.read(target[0])).hexdigest()==sha

claim_list=[]
for i in range(start-1,end):
    m=re.search(r'\\begin\{(theorem|lemma|proposition|corollary|definition|remark|claim)\}(?:\[([^]]*)\])?',lines[i]);
    if not m: continue
    kind=m.group(1); label=None
    for k in range(i,min(i+16,len(lines))):
        lm=re.search(r'\\label\{([^}]+)\}',lines[k])
        if lm:label=lm.group(1);break
    assert label
    last=next(j+1 for j in range(i,end) if f'\\end{{{kind}}}' in lines[j])
    claim_list.append({'id':label,'kind':kind,'title':re.sub(r'\\[A-Za-z]+','',m.group(2) or '').replace('$','').strip(),
                       'source_start_line':i+1,'source_end_line':last})
assert len(claim_list)==42
ids={c['id'] for c in claim_list}

E3 = {
'p8:lem:scalaron-native-modalities-noncollapse',
'p8:lem:scalaron-modality-support-induction',
'p8:cor:no-scalaron-triple-counting',
'p8:thm:v166-boundary-module-owner-criterion',
'p8:thm:v252-owner-factorized-terminal-rar',
'p8:thm:v167-finite-collar-dtn',
'p8:cor:v167-finite-return-relinearization',
'p8:prop:uv-crossover-length-diagnostic',
'p8:prop:kottler-weyl-tidal-growth',
'p8:cor:primitive-tidal-diagnostic-surface',
'p8:prop:strong-field-gp1-curvature-boundedness',
'p8:thm:complete-four-curvature-owner',
'p8:cor:v2181-gp1-classical-kottler-departure',
'p8:prop:v2181-arbitrary-finite-kottler-shells',
'p8:thm:v2181-e6-curvature-response-map',
'p8:cor:v2181-e6-root-range-equivalence',
'p8:cor:v2184-octahedral-determinant-balanced-e6-response',
'p8:cor:conditional-root-curvature-range',
'p8:thm:strong-field-hopf-cap-rigidity',
'p8:prop:conditional-exterior-breakdown-scales',
}
E3_PART = {
'p8:prop:complete-scalaron-response-ledger',
'p8:cor:scalaron-modality-vs-readout-provenance',
'p8:cor:scalaron-modalities-corealization',
'p8:cor:scalaron-five-role-support',
'p8:thm:v167-critical-boundary-corealization-criterion',
'p8:prop:quadratic-curvature-kottler-no-go',
'p8:cor:v166-no-k48-transition-from-bridge',
}
ISSUE_BY_CLAIM={
'p9:thm:v166-structural-bridge-rar-firewall':['BH-G-000148'],
'p9:thm:v167-rar-limit-readout-firewall':['BH-G-000148'],
'p8:thm:scalar-frozen-compact-exterior':['BH-G-000149'],
'p8:rem:strong-field-status-boundary':['BH-G-000150'],
}
SCOPED = {'p8:rem:v2181-e6-amplitude-firewall','p8:rem:strong-field-cap-owner-firewall','p8:rem:strong-field-cap-hopf-ancestry-gap'}
for c in claim_list:
    ident=c['id']
    if ident in ISSUE_BY_CLAIM:
        c['evidence_status']='E1_WITH_SCOPE_OR_PROOF_EVIDENCE_ISSUE'; c['issue_ids']=ISSUE_BY_CLAIM[ident]
    elif c['kind']=='definition': c['evidence_status']='E0_E1_FROZEN_DEFINITION';c['issue_ids']=[]
    elif ident in E3: c['evidence_status']='E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE';c['issue_ids']=[]
    elif ident in E3_PART: c['evidence_status']='E1_E3_SUBCHECK_E2_IMPORT_FULL_SCOPE_PENDING';c['issue_ids']=[]
    elif ident in SCOPED: c['evidence_status']='E1_SCOPE_REPLAY_ONLY';c['issue_ids']=[]
    else: c['evidence_status']='E1_E2_IMPORT_LOCATED_E3_PENDING';c['issue_ids']=[]
    c['evidence_ids']= ['B05-EV-00','B05-EV-01']
    if ident in E3: c['evidence_ids']+=['B05-EV-03']
    if ident in E3_PART: c['evidence_ids']+=['B05-EV-02','B05-EV-03']
    if ident in ISSUE_BY_CLAIM: c['evidence_ids']+=['B05-EV-04']
    if ident in ['p8:thm:v166-boundary-module-owner-criterion','p8:thm:v252-owner-factorized-terminal-rar']:
        c['evidence_ids']+=['B05-EV-05']
    if ident == 'p8:thm:v167-finite-collar-dtn':
        c['evidence_ids']+=['B05-EV-06']
    if ident == 'p8:thm:scalar-frozen-compact-exterior': c['evidence_ids']+=['B05-EV-07']
    if ident == 'p8:rem:strong-field-status-boundary': c['evidence_ids']+=['B05-EV-08']
    if ident == 'p8:thm:v2181-e6-curvature-response-map': c['scope_warning']='E3 checks the norm implication from the rooted tight-frame Gram; original E6 root frame only verified by located upstream Paper I-C theorem.'
    if ident == 'p8:prop:complete-scalaron-response-ledger': c['scope_warning']='Exhaustiveness is relative to frozen Σ^6A,grav; external constructors and downstream physical histories are excluded; no independent global corpus enumeration certificate.'
    if ident == 'p8:thm:scalar-frozen-compact-exterior': c['scope_warning']='Einstein-space reduction and spherical Kottler valid; unqualified stationary-axisymmetric Kerr uniqueness/hair sentence not proved.'
    if ident in ['p9:thm:v166-structural-bridge-rar-firewall','p9:thm:v167-rar-limit-readout-firewall']:
        c['scope_warning']='Historical local-L/Calderón/G26-GLOBAL firewall, not current native S+T G26-DEEP; as printed can be read globally.'
    if ident == 'p8:rem:strong-field-status-boundary': c['scope_warning']='Inherited nonlinear source-memory regulator existence and basin depend on referenced numerical state and scripts absent from freeze; not reverified.'

counts=dict(collections.Counter(c['evidence_status'] for c in claim_list))
issues=[
 {
  'id':'BH-G-000148','type':'SCOPE_OVERREACH_STALE_IMPORT','severity':'moderate','status':'OPEN','lifecycle':'ACTIVE',
  'first_known_source':{'file':SRC.name,'line_start':7775,'line_end':7810,'label':'p9:thm:v166-structural-bridge-rar-firewall'},
  'additional_occurrences':[{'line_start':7816,'line_end':7877,'label':'p9:thm:v167-rar-limit-readout-firewall'}],
  'statement':'VI-C reprints K48/RAR firewall as though the physical β48 map and every deep RAR export remain unprovided; VI-C 7431-7437 and 7677-7687 expressly state β48 is now generated locally and native S+T deep RAR is independently closed. VI-B 4153-4176, 4183-4205 explicitly scopes those earlier theorems to historical local-L/Schur/Calderón/G26-GLOBAL. An unqualified terminal/current branch reading is inconsistent with active ancestry.',
  'first_failed_step':'7777-7806: not separating historical missing-map antecedent from the currently generated local β48; 7858-7876: downstream all-branch firewall overriding already closed native S+T.',
  'positive_control':'7391-7458 and 7675-7748 preserve both the current β48 source and the distinct historical local-L no-go; VI-B current status explicitly limits old chain.',
  'refutation_scope':'The historical conditional no-go is valid. No refutation of the native S+T deep RAR theorem or the finite collar mathematics.',
  'prerequisites':['p8:thm:v166-boundary-module-owner-criterion','p8:thm:v167-critical-boundary-corealization-criterion','Paper6B:current:v1_199:historical-local-L-typed-chain'],
  'affected_consumers':['p9:thm:v166-structural-bridge-rar-firewall','p9:thm:v167-rar-limit-readout-firewall','historical K48-boundary/global-RAR export users (candidate)'],
  'required_discharge':'Explicitly inherit current VI-B route restriction on reprinted firewalls and separate current β48 local owner, current native S+T deep law, and optional historical local-L/G26-GLOBAL completion; do not postulate a new mechanism.',
  'boundary_record_id':'B05-BND-01','independent_evidence':['B05-EV-02'],'adversarial_evidence':['B05-EV-04']
 },
 {
  'id':'BH-G-000149','type':'MISSING_UNIQUENESS_CONDITIONS','severity':'moderate','status':'OPEN','lifecycle':'ACTIVE',
  'first_known_source':{'file':SRC.name,'line_start':8149,'line_end':8173,'label':'p8:thm:scalar-frozen-compact-exterior'},
  'statement':'Constant F and vacuum trace root establish Rμν=(R_ext/4)gμν; stationary-axisymmetry alone does not force Kerr-(A)dS nor absence of all exterior multipoles or NUT/acceleration-like charges. The theorem supplies no global uniqueness/horizon/asymptotic hypotheses.',
  'first_failed_step':'8169-8172: promotes Einstein-space field equation to unique stationary axisymmetric Kerr-de Sitter family and no-hair conclusion without a black-hole uniqueness domain.',
  'positive_control':'Static spherical Einstein vacuum gives the Kottler family; Kerr-(A)dS remains an allowed stationary axisymmetric solution under suitable boundary conditions.',
  'exact_negation_witness':'Static, asymptotically flat Weyl Curzon exterior has ψ=-m/sqrt(ρ²+z²), γ=-m²ρ²/[2(ρ²+z²)²], satisfies vacuum Weyl equations and has nonround constant-lapse 2-spheres; it is not Schwarzschild/Kerr, illustrating nonuniqueness for an admissible zero-curvature trace-root subcase. For a fixed nonzero constant-curvature root, extra Einstein-Λ solutions also exist unless the global uniqueness hypotheses are added.',
  'refutation_scope':'Attacks unqualified family exhaustion and hair claim, not Einstein reduction, Kottler spherical branch or existence of Kerr-de Sitter solutions. Source-current f(R) root specificity remains an explicit qualification.',
  'prerequisites':['p8:eq:compact-vacuum-trace-root','p8:eq:compact-einstein-space'],
  'affected_consumers':['p8:thm:scalar-frozen-compact-exterior:axisymmetric-sentence','p8:rem:strong-field-status-boundary:claim-of-exterior'],
  'required_discharge':'State and source the exact boundary/horizon/asymptotic hypotheses under which a Kerr(-dS) uniqueness theorem applies, or type the Kerr family as one allowed solution; audit records only, no source repair.',
  'boundary_record_id':'B05-BND-02','independent_evidence':['B05-EV-03'],'adversarial_evidence':['B05-EV-07']
 },
 {
  'id':'BH-G-000150','type':'MISSING_REPRODUCIBILITY_EVIDENCE','severity':'moderate','status':'OPEN','lifecycle':'ACTIVE',
  'first_known_source':{'file':SRC.name,'line_start':8021,'line_end':8077,'label':'p8:app:black-hole-native-regulation'},
  'statement':'The printed coupled two-marginal solution, residual <2e-13, transversality derivatives, positivity, and sixth-order constraint buffers rely on four explicitly named numerical files not included in the supplied paper or DAG archives. The inputs, normalization and ODE integration cannot be independently rerun from those archives.',
  'first_failed_step':'8022, 8027, 8047, 8071: references to Paper00-BlackHoleRegulationChecks-v1_9.py, v1_10.py, v1_11.py, v1_12.json (and companion Python file), none available in current freeze.',
  'positive_control':'The printed Raychaudhuri terms cancel algebraically; 0.5−0.446275223520=0.053724776480>0.0537, and simple-zero implies local continuation conditional on a certified solution.',
  'refutation_scope':'Evidence/coverage defect, not a counterexample to existence of the regulator member, nor an allegation of incorrect numerical values.',
  'prerequisites':['Paper6A:p8:prop:v2184-native-source-memory-regulator','Paper6A:p8:cor:v2184-native-regulating-basin','Paper6A:p8:prop:v2184-spherical-constraint-buffer-matching'],
  'affected_consumers':['Paper6C:8025-8077:numerical-witness','p8:rem:strong-field-status-boundary:claimed-regulator-existence'],
  'required_discharge':'Supply the cited frozen scripts/json and full source-state packet, rerun with checksum/result tolerances and independent solver/constraints; no claim of numerical refutation.',
  'boundary_record_id':'B05-BND-03','independent_evidence':['B05-EV-00'],'adversarial_evidence':['B05-EV-08']
 }
]

EV=[
 {'id':'B05-EV-00','level':'E0','description':'Frozen file and all supplied archive inventory; target source matches PapersMinimal verbatim; missing external numerical files checked across local mounted inputs, PapersMinimal and Atlas.', 'certificate':{'source_sha256':sha,'manuscript_lines':len(lines),'scripts_expected':['Paper00-BlackHoleRegulationChecks-v1_9.py','Paper00-BlackHoleRegulationChecks-v1_10.py','Paper00-BlackHoleRegulationChecks-v1_11.py','Paper00-BlackHoleRegulationChecks-v1_12.json']}},
 {'id':'B05-EV-01','level':'E1','description':'Statement, proof and branch/source replay of each of 42 formal environments; unnamed matching, source-memory and buffer passages included; explicit source 6888-8897.'},
 {'id':'B05-EV-02','level':'E2','description':'Current imported source locations resolved: II/Paper I-C exceptional-frame norm, III-C B48/PCAD, III-F Schur and joint-connection, VI-A current native S+T and finite source main, VI-B current historical-local-L firewall; no imported paper newly declared fully audited.'},
 {'id':'B05-EV-03','level':'E3','description':'Independent symbolic/numerical checks of C2 Hom, finite collar and return jets, curvature Kottler with orthonormal sectional components, scalar jet, 4x4 Clifford trace, exceptional tight-frame conditional norm, Berger cap, Schur order, UV clock and radius; see reproducible script.', 'script':'Paper6C-Batch05-IndependentChecks-v1_1.py','log':'_bh_b05_independent.log','scope':'E3 for the specified identities/conditional implications, NOT a global physical realization or imported root-list certification.'},
 {'id':'B05-EV-04','level':'E4','description':'Two-route source-hierarchy adversarial test: VI-C 7391-7458 and 7675-7748 vs VI-C 7775-7877; VI-B current 4153-4205 explicitly limits historical local-L result.', 'finding_id':'BH-G-000148'},
 {'id':'B05-EV-05','level':'E4','description':'Positive finite Hessian Hε=[[2,sqrt ε],[sqrt ε,ε]] has Schur=1 but quotient-first A=2; proves noncommuting rank-change elimination without violation of positive branch.', 'script':'Paper6C-Batch05-IndependentChecks-v1_1.py'},
 {'id':'B05-EV-06','level':'E4','description':'Finite-collar absolute error uniformly bounded for all nonnegative spectral values, normalized error supremum 1 for any finite L; zero-point ratio is excluded and controlled by the stated one-sided limit.', 'script':'Paper6C-Batch05-IndependentChecks-v1_1.py'},
 {'id':'B05-EV-07','level':'E4','description':'Independent Weyl solution equations checked exactly for Curzon static axisymmetric Ricci-flat vacuum, nonround constant-lapse surfaces, showing vacuum Einstein reduction alone does not select Kerr uniqueness.', 'script':'Paper6C-Batch05-IndependentChecks-v1_1.py','finding_id':'BH-G-000149'},
 {'id':'B05-EV-08','level':'E2_NEGATIVE','description':'Printed two Raychaudhuri integrals cancel and causal margin is positive; absent cited numerical code prevents an E3 solver/coupled-state certificate; not a failed mathematical witness.', 'finding_id':'BH-G-000150'},
 {'id':'B05-EV-09','level':'E0','description':'Upstream I-C 20170-20217 contains p1b:thm:exroot-response-norms under an original Paper I-B inline-source label. VI-C text cites Paper I-B; current label resolves to I-C, so record a locator/alias note, not a mathematical gap.'}
]

boundaries=[
 {'id':'B05-BND-01','claim_id':'p9:thm:v166-structural-bridge-rar-firewall','provenance':['[CONST] Paper III-C B48 C2 module','[GEN] parent-collar PCAD β48 local source generated in III-C v1.87','[DER] same-action III-F Schur','[DER] native VI-A S+T G26-DEEP','[HOST] optional local-L/Calderon G26-GLOBAL'], 'scope':'historical route versus currently owned branch; local β existence versus physical source/history map','import_loci':['Paper6C:7431-7437','Paper6C:7675-7748','Paper6B:4153-4205'], 'E_U_C_R_I':'E module and local β asserted/proven upstream; global source-history map unresolved only on optional stronger route; no implication from abstract module to physical observable.'},
 {'id':'B05-BND-02','claim_id':'p8:thm:scalar-frozen-compact-exterior','provenance':['[DER] constant scalaron trace root → Einstein equation','[HOST] spherical Birkhoff and stationary-axisymmetric metric classes','[ID] source identifies all stationary axisymmetric exteriors with Kerr-dS'], 'scope':'local field equation vs global exterior uniqueness; regularity/horizon/asymptotics not part of antecedent','E_U_C_R_I':'E Kerr-dS member does not imply U classification, C canonicality, R historical realization or I absence of extra external charges.'},
 {'id':'B05-BND-03','claim_id':'p8:rem:strong-field-status-boundary','provenance':['[FROZEN] numerical source packet at VI-A 11655-11738 and VI-C 8001-8077','[DER] printed first-jet local member and buffer','[REAL] actual collapse/source matching explicitly remains open'], 'scope':'exists member vs fully occurring collapse; reproducibility blocked by absent referenced inputs','E_U_C_R_I':'No observed invalidity of existence, but numerical E3 certificate unavailable; physical occurrence/uniqueness not implied.'},
 {'id':'B05-BND-04','claim_id':'p8:thm:complete-four-curvature-owner','provenance':['[DER] III-F joint-connection curvature and spin trace','[CONST] primitive scalar R² overlap and Born handoff','[HOST] finite curvature Kottler comparison'], 'scope':'complete Icur readout and normalization vs independent global amplitude U²','E_U_C_R_I':'E/C of positive readout and its normalization conditional on source; no universal amplitude bound nor successor core.'}
]

conditions=[
 {'normalized_id':'B05-FIRSTKNOWN-01','statement':'X generated only by frozen Σ^{6A,grav}_φ; ambient or downstream constructors excluded', 'kind':'DOMAIN','first_known':'Paper6C:6900-6915','status':'STIPULATED; prior source ancestry still to dedupe','consumers':['p8:prop:complete-scalaron-response-ledger','p8:lem:scalaron-modality-support-induction']},
 {'normalized_id':'B05-FIRSTKNOWN-02','statement':'one scalaron root on stable unfolded mp=1, mx≫1', 'kind':'DOMAIN','first_known':'Paper6C:6940-6959 importing Paper6C:5083','status':'EARLIER_PROVED_SOURCE_LOCATED','consumers':['p8:prop:complete-scalaron-response-ledger','p8:lem:scalaron-native-modalities-noncollapse']},
 {'normalized_id':'B05-FIRSTKNOWN-03','statement':'C2 parity even 1,d and odd u,n; β owner and its flux normalisation are separate', 'kind':'BOUNDARY','first_known':'Paper6C:7369-7389; imported III-C active owner','status':'DEFINED_AND_IMPORTED','consumers':['p8:thm:v166-boundary-module-owner-criterion','p8:thm:v252-owner-factorized-terminal-rar']},
 {'normalized_id':'B05-FIRSTKNOWN-04','statement':'same-action block Hessian has invertible interior Cε and well-defined terminal Schur limit', 'kind':'REGULARITY','first_known':'Paper6C:7484-7516, upstream III-F','status':'CONDITIONAL','consumers':['p8:thm:v252-owner-factorized-terminal-rar','p9:thm:v167-rar-limit-readout-firewall']},
 {'normalized_id':'B05-FIRSTKNOWN-05','statement':'A nonnegative self-adjoint tangential operator and finite positive collar L', 'kind':'DOMAIN','first_known':'Paper6C:7549-7621','status':'MATHEMATICAL_STATED','consumers':['p8:thm:v167-finite-collar-dtn']},
 {'normalized_id':'B05-FIRSTKNOWN-06','statement':'physical unbounded return/collar refinement and return ownership on optional local-L/global branch', 'kind':'PHYSICAL-IDENTIFICATION','first_known':'Paper6C:7675-7748; prior VI-A/B ancestry to dedupe','status':'CONDITIONAL_OPEN_HISTORICAL_ROUTE','consumers':['p8:thm:v167-critical-boundary-corealization-criterion','p9:thm:v167-rar-limit-readout-firewall']},
 {'normalized_id':'B05-FIRSTKNOWN-07','statement':'f_R(R_ext)≠0 and f_R R_ext−2f=0, constant R_ext vacuum exterior', 'kind':'DOMAIN','first_known':'Paper6C:8149-8173','status':'STATED','consumers':['p8:thm:scalar-frozen-compact-exterior','p8:prop:kottler-weyl-tidal-growth']},
 {'normalized_id':'B05-FIRSTKNOWN-08','statement':'stationary axisymmetric exterior uniqueness requires additional global boundary/horizon hypotheses not stated', 'kind':'INFERRED-CONDITION','first_known':'Paper6C:8169-8172','status':'UNRESOLVED','consumers':['p8:thm:scalar-frozen-compact-exterior']},
 {'normalized_id':'B05-FIRSTKNOWN-09','statement':'GP1 bounded readouts assumed constituted over one complete realized region', 'kind':'FOUNDATIONAL/DOMAIN','first_known':'Paper6C:8246-8283 importing GP1','status':'CONSTITUTIONAL_SCOPE','consumers':['p8:prop:strong-field-gp1-curvature-boundedness','p8:cor:v2181-gp1-classical-kottler-departure']},
 {'normalized_id':'B05-FIRSTKNOWN-10','statement':'finite numerical source-memory state/ODE with sixth-order constraint-buffer coefficients and solver tolerances', 'kind':'EVIDENCE-MISSING','first_known':'Paper6C:8001-8077, VI-A:11655-11738','status':'NOT_YET_ACCESSIBLE_AS_FROZEN_ARTIFACT','consumers':['p8:rem:strong-field-status-boundary']},
 {'normalized_id':'B05-FIRSTKNOWN-11','statement':'physical exceptional E6 root-response amplitude bounded by U/√2 on actual history', 'kind':'SELECTION/DOMAIN','first_known':'Paper6C:8565-8648','status':'CONDITIONAL_NOT_GLOBALLY_DERIVED','consumers':['p8:cor:conditional-root-curvature-range']},
 {'normalized_id':'B05-FIRSTKNOWN-12','statement':'physical Hopf shape member restricted 0<epsilon≤1 and C_B≤Kp²', 'kind':'DOMAIN','first_known':'Paper6C:8687-8721','status':'CONDITIONAL','consumers':['p8:thm:strong-field-hopf-cap-rigidity']},
]

edges0=[
 ('p8:thm:momentum-carrier-rigidity-scalar-trace','p8:lem:scalaron-completeness-one-root','IMPORTED_PROOF','6946-6955'),
 ('p8:cor:scalar-only-modified-gravity-lane','p8:lem:scalaron-completeness-one-root','IMPORTED_PROOF','6953-6956'),
 ('p8:thm:gp2-closed-flrw-background','p8:prop:complete-scalaron-response-ledger','IMPORTED_PROOF','7103-7106'),
 ('p8:thm:absorbing-spectral-handoff','p8:prop:complete-scalaron-response-ledger','IMPORTED_PROOF','7113-7115'),
 ('p8:prop:complete-scalaron-response-ledger','p8:lem:scalaron-modality-support-induction','PREMISE_OF','7205-7215'),
 ('p8:lem:scalaron-completeness-one-root','p8:thm:scalaron-response-modality-completeness','PREMISE_OF','7219-7239'),
 ('p8:lem:scalaron-native-modalities-noncollapse','p8:thm:scalaron-response-modality-completeness','PREMISE_OF','7221-7225'),
 ('p8:lem:scalaron-modality-support-induction','p8:thm:scalaron-response-modality-completeness','PREMISE_OF','7246-7250'),
 ('p8:def:v166-zero-mode-boundary-jet','p8:thm:v166-boundary-module-owner-criterion','PREMISE_OF','7394-7423'),
 ('p8:thm:v166-boundary-module-owner-criterion','p8:thm:v252-owner-factorized-terminal-rar','SCOPE_GUARD','7484-7506'),
 ('p8:thm:v252-owner-factorized-terminal-rar','p8:thm:v167-critical-boundary-corealization-criterion','PREMISE_OF','7700-7704'),
 ('p8:thm:v167-finite-collar-dtn','p8:thm:v167-critical-boundary-corealization-criterion','PREMISE_OF','7717-7720'),
 ('p8:cor:v167-finite-return-relinearization','p9:thm:v167-rar-limit-readout-firewall','PREMISE_OF','7818-7827'),
 ('p8:thm:v252-owner-factorized-terminal-rar','p9:thm:v167-rar-limit-readout-firewall','PREMISE_OF','7828-7856'),
 ('p8:thm:scalar-frozen-compact-exterior','p8:prop:kottler-weyl-tidal-growth','PREMISE_OF','8184-8199'),
 ('p8:prop:kottler-weyl-tidal-growth','p8:cor:primitive-tidal-diagnostic-surface','PREMISE_OF','8219-8236'),
 ('p8:prop:strong-field-gp1-curvature-boundedness','p8:thm:complete-four-curvature-owner','SCOPE_GUARD','8285-8306'),
 ('p8:prop:kottler-weyl-tidal-growth','p8:thm:complete-four-curvature-owner','PREMISE_OF','8356-8361'),
 ('p8:thm:complete-four-curvature-owner','p8:cor:v2181-gp1-classical-kottler-departure','PREMISE_OF','8365-8402'),
 ('p8:thm:complete-four-curvature-owner','p8:prop:v2181-arbitrary-finite-kottler-shells','PREMISE_OF','8404-8440'),
 ('p1b:thm:exroot-response-norms','p8:thm:v2181-e6-curvature-response-map','IMPORTED_PROOF','8481-8492; I-C 20170-20217'),
 ('p8:thm:complete-four-curvature-owner','p8:thm:v2181-e6-curvature-response-map','PREMISE_OF','8554-8562'),
 ('p8:thm:v2181-e6-curvature-response-map','p8:cor:v2181-e6-root-range-equivalence','PREMISE_OF','8565-8583'),
 ('p8:thm:v2181-e6-curvature-response-map','p8:cor:v2184-octahedral-determinant-balanced-e6-response','PREMISE_OF','8598-8616'),
 ('p8:cor:v2181-e6-root-range-equivalence','p8:cor:conditional-root-curvature-range','SCOPE_GUARD','8618-8648'),
 ('p8:thm:complete-four-curvature-owner','p8:cor:conditional-root-curvature-range','PREMISE_OF','8620-8648'),
 ('p1:cor:berger-primitive-cap-rigidity','p8:thm:strong-field-hopf-cap-rigidity','IMPORTED_PROOF','8723-8739'),
 ('p1:cor:spinframe-hopf-shape-descendant','p8:thm:strong-field-hopf-cap-rigidity','IMPORTED_PROOF','8723-8729'),
 ('p8:prop:v2184-native-source-memory-regulator','p8:rem:strong-field-status-boundary','IMPORTED_PROOF_UNVERIFIED_NUMERICS','8836-8844')
]
edges=[{'id':f'B05-EDGE-{i:03d}','from':a,'to':b,'relation':c,'source_use_witness':w,
        'review_status': 'E1_MATERIAL_USE_E3_PARTIAL' if c!='IMPORTED_PROOF_UNVERIFIED_NUMERICS' else 'E1_SOURCE_USE_E3_MISSING',
        'scope_guard':'stated target premise/branch; no unscoped propagation', 'route_id':f'B05-ROUTE-{b}'} for i,(a,b,c,w) in enumerate(edges0,1)]

negative=[
 {'allegation':'The abstract B48 representation creates a unique physical DtN normalization','verdict':'REJECTED','reason':'C2 Hom has 2 parameters; current β separately generated; this does not reopen G25.'},
 {'allegation':'A finite collar cannot approximate sqrt(y) uniformly','verdict':'REJECTED','reason':'Uniform absolute error ≤1/(eL) is proved; relative critical ratio is nonuniform.'},
 {'allegation':'Schur memory automatically vanishes after rank change','verdict':'VALID_COUNTEREXAMPLE_TO_UNRESTRICTED_CLAIM_ONLY','reason':'Explicit positive 2x2 Hessian; source explicitly warns against quotient-first.'},
 {'allegation':'The E6 frame norm implies the absolute physical amplitude ≤U/sqrt2','verdict':'REJECTED','reason':'Source explicitly distinguishes map/norm equivalence from amplitude bound/history; no false claim.'},
 {'allegation':'Strong-field c1=1 determines a regular spacetime core radius','verdict':'REJECTED','reason':'Source confines Hopf geometry to spin-frame shape, not spacetime metric/radius.'},
 {'allegation':'Kerr uniqueness follows from Einstein equation without global conditions','verdict':'VALID_SCOPE_CHALLENGE','reason':'Exact Weyl Ricci-flat stationary-axisymmetric non-Schwarzschild exterior; see BH-G-000149.'},
 {'allegation':'The printed source-memory figures are false because scripts absent','verdict':'REJECTED','reason':'Missing reproducibility evidence is not a refutation; classify EVIDENCE_MISSING BH-G-000150.'},
 {'allegation':'VI-C Paper I-B reference to exroot-response-norms has no theorem','verdict':'REJECTED_AS_MATH_GAP','reason':'Exact label found in the current Paper I-C 20170-20217 (inline historical Paper I-B source); E0 locator note.'},
]

json_obj={
 'record_type':'rigorous_single_paper_audit_batch_evidence','checkpoint_version':'1.1','paper':'Paper6C',
 'protocol':'Paper00-RigorousVerificationDAGWorkProtocol v2.4', 'source_file':SRC.name,
 'batch':5,'batch_lines':[start,end],'next_batch_first_line':end+1,'manuscript_total_lines':len(lines),
 'frozen_sha256':{'target_tex':sha,'papers_minimal_archive':shafile(arch), 'dag_atlas_archive':shafile(ROOT/'Paper00-DAGAtlas-v1_115(1).zip'),'proof_chain_archive':shafile(ROOT/'Paper00-ProofChainAudits-v1_32(1).zip'),'verification_protocol':shafile(ROOT/'Paper00-RigorousVerificationDAGWorkProtocol-v2_4(1).md')},
 'scanned_formal_statement_count':len(claim_list),'batch_status_counts':counts,'cumulative_claims_inventoried':173+len(claim_list),
 'cumulative_source_span':[80,end],'claims':claim_list,'evidence':EV,'issues':issues,
 'inherited_open_issue_ids':[f'BH-G-{n:06d}' for n in range(134,148)],
 'first_known_issue_id_policy':'New only 148-150; no duplicate of earlier 134-147; global registry final integration only after last batch.',
 'constitution_boundary_records':boundaries,'source_proof_edges_reviewed':edges,
 'negative_or_rejected_allegations':negative,'conditions_pending_global_registry_identity':conditions,
 'unnamed_source_sections_reviewed':[
  {'lines':[7893,7914],'type':'scalar-frozen first-jet compatibility and match scope','status':'E1_E2'},
  {'lines':[7916,7929],'type':'complete canonical matching','status':'E1_E2'},
  {'lines':[7932,7945],'type':'quadratic background-versus-principal caveat','status':'E1_E2'},
  {'lines':[7948,7980],'type':'density, retarded memory and remaining exterior application','status':'E1_E2'},
  {'lines':[8001,8023],'type':'Dirac Bloch source packet and script reference','status':'E1_E2_SCRIPT_MISSING'},
  {'lines':[8025,8056],'type':'coupled two-marginal regulator and transversality numerics','status':'E2_PRINTED_ARITHMETIC_ONLY_E3_MISSING'},
  {'lines':[8058,8087],'type':'constraint-buffer matching and localization firewall','status':'E1_E2_SCRIPT_MISSING'}],
 'coverage_classification':'PARTIALLY_AUDITED: 42 formal constructs in span 6888-8897 and 7 substantive unnamed technical groups. Mathematical E3 only on indicated conditional identities. Three issues, no unverified physical occurrence promoted.',
 'graph_status':'STAGING_ONLY_NO_CANONICAL_ATLAS_MUTATION. Final batch merges audit layer and reviews global assumption registry; original ZIPs unchanged.',
 'zip_delivery_policy':'Final batch only: latest-version-only updated DAG Atlas and ProofChain Audits ZIP after validation.'
}

out=ROOT/'Paper6C-RigorousAuditBatch05Evidence-v1_1.json';out.write_text(json.dumps(json_obj,indent=2,ensure_ascii=False)+'\n')

S={
'E0_E1_FROZEN_DEFINITION':'Definition / frozen grammar (not a theorem requiring E3)',
'E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE':'E1 plus independent E3 for the stated conditional identity',
'E1_E3_SUBCHECK_E2_IMPORT_FULL_SCOPE_PENDING':'E1 plus E3 subcheck; imported/global completeness not independently certified',
'E1_E2_IMPORT_LOCATED_E3_PENDING':'E1 source + located import; independent full verification pending',
'E1_SCOPE_REPLAY_ONLY':'E1 scope/negative remark',
'E1_WITH_SCOPE_OR_PROOF_EVIDENCE_ISSUE':'Open adjudicated scope/evidence issue',
}
md=[]
md.extend([
'# Paper VI-C — Rigorous Verification DAG Audit, Batch 05',
'',
'**Target:** `Paper6C-TechnicalMaterial-v1_43.tex` (10,448 lines; SHA-256 `'+sha+'`).',
'**Inputs:** `Paper00-PapersMinimal-v2_371`, `Paper00-DAGAtlas-v1_115`, `Paper00-ProofChainAudits-v1_32`; **protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md`.',
'**Scope:** lines **6,888–8,897**. **Next:** line **8,898**. **Formal census:** **42** constructions; **7** substantive unnamed calculation/matching groups. **Cumulative:** **215** formal statements over five batches. All 14 earlier findings `BH-G-000134`–`BH-G-000147` remain carried forward as unresolved (not re-adjudicated here).',
'',
'## A. Adjudicated Batch-05 findings',
'',
'### BH-G-000148 — Historical K48/RAR firewall overstates its active-branch scope (MODERATE; scope/stale import)',
'',
'**Earliest source:** `p9:thm:v166-structural-bridge-rar-firewall` (VI-C **7775–7810**); repeated in `p9:thm:v167-rar-limit-readout-firewall` (**7816–7877**). The unqualified “until β48 exists” / “no galaxy curve until ...” wording is liable to be read as a current all-RAR prohibition. That conflicts with the same paper’s **7431–7437** (β48 already generated locally), **7675–7687** and **7741–7747** (native **S+T** deep-RAR closed; stronger historical **L/Calderón/G26-GLOBAL** open). The current VI-B **4153–4176** and **4183–4205** explicitly limits the copied historical chain to its optional route. **BND-01:** this is an epistemic/branch-scope contradiction in the copied firewall, *not* a refutation of the historical conditional theorem or the independent native S+T law. Its G25 original antecedent is already discharged by generated PCAD β. **Required:** use explicit historical route guard for both copied theorems and do not propagate their open premises onto native G26-DEEP.',
'',
'### BH-G-000149 — Stationary axisymmetric Kerr–de Sitter exhaustiveness is not established (MODERATE; missing uniqueness domain)',
'',
'**Source:** `p8:thm:scalar-frozen-compact-exterior` **8149–8173**, especially **8169–8172**. The proof correctly reduces constant-scalar, nonzero-`F` vacuum metric-`f(R)` to `Ric=(R_ext/4)g`. Its further conclusion that *the* stationary axisymmetric exterior is Kerr–de Sitter with only the mass/spin charges is not implied by Einstein-space equations without appropriate global horizon/boundary/asymptotic and regularity restrictions. **Exact E4 control:** a static axisymmetric Weyl vacuum metric with `ψ=-m/√(ρ²+z²)` and `γ=-m²ρ²/[2(ρ²+z²)²]` satisfies all three Weyl vacuum equations outside its compact source and is not locally Schwarzschild/Kerr; the constant-lapse-sphere Gaussian curvature varies with polar angle. This is a valid zero-curvature Einstein/root subcase for compatible `f(0)=0,F(0)≠0` actions, illustrating the missing inference. For the specific current nonzero curvature root, the proof still needs an actual applicable uniqueness theorem; no unverified generic metric is promoted to the native physical branch. **Positive control:** spherical Kottler and Kerr–dS as a *solution family* remain valid. **BND-02:** `E`/`R` of one Kerr metric must not be conflated with uniqueness of all stationary-axisymmetric Einstein exteriors.',
'',
'### BH-G-000150 — Cited black-hole regulator reproducibility packet is absent (MODERATE; EVIDENCE_MISSING, not mathematical refutation)',
'',
'**Source:** VI-C **8001–8077**, with cited programs at 8022 (`v1_9.py`), 8027 (`v1_10.py`), 8047 (`v1_11.py`) and 8071–8072 (`v1_12.json` and companion Python). These are not in the current supplied PapersMinimal v2.371 ZIP, DAG Atlas v1.115 ZIP, or mounted source inputs. The printed two-marginal first-jet solution, claimed `2×10^{-13}` Raychaudhuri residual, positivity of energy/constraints, simple-turn derivatives and sixth-degree buffer cannot be independently rerun without the actual state/ODE and coefficients. We did independently check the cancellation of the printed Raychaudhuri terms and the strict causal buffer margin `0.5−0.446275223520=0.053724776480>0.0537`. **BND-03:** exact solver/existence evidence remains pending; this is *not* evidence that the witness is false. **Required:** provide the frozen code, JSON, precise initial state/parameter packet and independent rerun/interval controls.',
'',
'## B. Independently verified mathematical results (at their exact scopes)',
'',
'1. **Scalaron modality classification:** The four *defined* native modes `H,L,S,T` are pairwise distinct under the declared operator/target invariants; finite-dependency structural induction proves no fifth tag can appear **within the frozen grammar**. This is a relative theorem, not global cosmic field completeness. A separate Paper-IV finite-mode interface `M` is a distinct sort. The ledger-exhaustion and ultimate physical-role imports remain partly source-level, not fully independently enumerated.',
'2. **Transverse boundary module:** Exact `C₂` commutant computation gives `dim Hom_{C₂}(1⊕sgn,1⊕sgn)=2`; unit-fixing alone leaves odd-flux normalization free. The upstream later-generated β48 is a distinct physical constructor, not a consequence of the two-line isomorphism. A positive-definite Hessian `H_ε=[[2,√ε],[√ε,ε]]` has `Schur=1` but quotient-first block `2`, demonstrating the source’s eliminate-before-quotient warning.',
'3. **Finite-collar DtN:** Direct solution of `−u″+μ²u=0` with Dirichlet/Neumann endpoints gives `μ tanh(Lμ)`, fixed-`L` expansion `Ly−L³y²/3+O(y³)` and controlled `A^{1/2} tanh(LA^{1/2})`. Independent spectral/analytic checks reproduce the **uniform absolute** error `≤1/(eL)`, but the **relative** ratio has supremum-one error for every finite L. The limits at `y↓0` and `L→∞` do not commute.',
'4. **Finite return:** Exact geometric expansion yields `ν_N=N+1−N(N+1)√y/2+O(y)` and `(N+1)g_b+O(g_b^{3/2})` at bounded N. The controlled unbounded limit changes its asymptotic to `√(a_*g_b)`; it is not a proof of physical unbounded return ownership. The apparent `0/0` in the rational form at `y=0` has the explicitly given finite series extension and is not filed as a gap.',
'5. **Scalar jet and strong-field diagnostics:** At `R=U`, `β_jet,U=Q(U−C7)/U²`; its reciprocal and conditional radius match. Independent orthonormal sectional-curvature computation of Kottler gives `Kretsch=12 r_s²/r⁶+R_ext²/6`, `Icur=R_ext²+72 χ_W²`; the Schwarzschild tidal diagnostic `r_*³=r_s R_mom²` gives proper-time `2R_mom/(3c)=4 t_P` under the paper’s normalization. Finite Kottler shells demonstrate **no** universal `U²` amplitude bound from GP1 alone.',
'6. **Complete four-curvature normalization:** Independent complex 4×4 Euclidean Clifford matrices reproduce `Σ_{ab}Tr(Ω_{ab}†Ω_{ab})=||Rm||²/2` for an arbitrary pair-index curvature matrix; space-form matching yields `Icur=6||Rm||_+²`. This determines the readout normalization, not a new action term, physical core radius or uniform actual-history range.',
'7. **Exceptional E6 response:** The current imported 72-root/6-dimensional tight-frame theorem gives Gram `12 P₆`. Independent linear algebra checks `J_{6,u}†J_{6,u}=I₆`, `||Y||_{HS}²=12||K||²`, `Icur=2||Y||²` and Schwarzschild `||Y||=6|χ_W|`; the physical amplitude limit `≤U/√2` remains explicitly conditional. The theorem is labeled `p1b:thm:exroot-response-norms` but currently **lives in Paper I-C 20170–20217** under an inline Paper-I-B source header: locator note, not a new math issue.',
'8. **Hopf shape and quadratic sector:** The Berger factorization `(ε²−1)(11 ε²−13)` is positive on `0<ε<1`, so the conditional budget selects `ε=1` on the declared *shape* family. It selects neither a Lorentzian core nor an areal radius. The local four-derivative quadratic metric Euler tensors vanish on constant-scalar Einstein backgrounds at the source’s scope, using the four-dimensional Euler/Gauss–Bonnet relation; independent computation of full source-dependent higher-tidal evolution is not asserted.',
'',
'## C. Full formal-statement census',
'',
'`E1` = source proof replay; `E2` = located owner/corrob.; `E3` = independent check of exact mathematical statement at declared conditional scope; `E4` = adversarial test. `E0_E1_FROZEN_DEFINITION` is a frozen definition, not theorem verification. High-impact physical-source/occurrence claims remain **unverified** absent external constructor/historical evidence; no simulated agents are claimed.',
'',
'| # | Lines | Label | Evidence status |',
'|---:|---:|---|---|'
])
for i,c in enumerate(claim_list,1):
    md.append(f'| {i} | {c["source_start_line"]}–{c["source_end_line"]} | `{c["id"]}` | `{c["evidence_status"]}`'+(('; '+','.join(c['issue_ids'])) if c['issue_ids'] else '')+' |')
md+=['', '## D. Named and unnamed proof-source coverage', '',
'- **Mathematical/role grammar (6888–7365):** definitions, complete frozen-ledger table, noncollapse, induction proof imported to previous Batch-04 scalaron modality theorem, Paper-II loop/boundary provenance and generated-role co-realization.',
'- **Boundary owner (7366–7882):** `B48` C₂ module and current PCAD β, same-action Schur and terminal rank change, finite collar DtN/spectral refinement, finite return, optional historical local-L/Calderón route, VI-B historically scoped copy. All five physical-ownership conditions on that *optional* route are preserved.',
'- **Strong field (7883–8897):** first-jet scalar-frozen matching, Dirac memory equations and unprovided witness scripts, scalar-frozen Einstein/Kottler reduction, GP1 region-domain bound, canonical curvature readout, E6 root response and explicitly conditional amplitude, Hopf shape, and downstream scope/firewall remarks. No physical regular-collapse history proved by merely replaying the stated numerical witness.',
'', '## E. Evidence and graph staging', '',
'- **Machine ledger:** `Paper6C-RigorousAuditBatch05Evidence-v1_1.json` contains all 42 source locators, evidence levels, three issue certificates, **four** boundary-gate records, **29** reviewed direct dependency edges, twelve staging condition predicates, and negative/rejected challenge records.',
'- **Independent executable:** `Paper6C-Batch05-IndependentChecks-v1_1.py` (12 reported check groups; conditional algebra and E4 counterexample). Its log is local `_bh_b05_independent.log`. A finite small test and an upstream I-C tight-frame identity are distinguished from independent verification of actual primitive root matrices.',
'- **Archive status:** original manuscripts and v1.115/v1.32 archives are unchanged. The global canonical registry/DAG Atlas mutation and latest-version-only zip packaging are deferred to **final Batch** to prevent mixing partial claim statuses with completed cross-paper graph integration.',
'- **Open/impact policy:** prior `BH-G-000134`–`BH-G-000147` are retained; new `BH-G-000148`–`BH-G-000150` are not duplicated at downstream restatements. No gap is silently closed, no new theory is developed, and the proof chain is not relabeled `VERIFIED` simply because a formula was replayed.',
'', '## F. Next batch', '',
'**Start at line 8,898** (source/thermodynamic/nuclear/cosmological validation, lithium window, historical/open validation and appendix/source statements through line 10,448). Last batch must finish the exact claim census, review inherited findings, integrate the DAG audit layer, and release **only latest versions** in both requested ZIPs after read-back validation.',
'']
report=ROOT/'Paper6C-RigorousAuditBatch05-v1_1.md'; report.write_text('\n'.join(md))
assert len(edges)==29 and len(claim_list)==42
assert json.loads(out.read_text())['scanned_formal_statement_count']==42
print('Wrote:',out.name,'size',out.stat().st_size,'Report:',report.name,'size',report.stat().st_size)
print('count',counts,'cumulative',json_obj['cumulative_claims_inventoried'])
