"""Batch04 source-only audit checkpoint: preserves archives, stages typed issue/DAG records."""
from pathlib import Path
import re,json,hashlib,collections,datetime,subprocess,math
R=Path('/mnt/data');p=R/'Paper6C-TechnicalMaterial-v1_43.tex';s=p.read_text().splitlines()
start,end=5296,6887
assert len(s)==10448
b03=json.loads((R/'Paper6C-RigorousAuditBatch03Evidence-v1_1.json').read_text())
assert b03['next_batch_first_line']==start and b03['cumulative_claims_inventoried']==144
assert hashlib.sha256(p.read_bytes()).hexdigest()==b03['frozen_sha256']['Paper6C-TechnicalMaterial-v1_43.tex']
rc=subprocess.run(['python',str(R/'Paper6C-Batch04-IndependentChecks-v1_1.py')],capture_output=True,text=True)
assert rc.returncode==0 and 'ALL BATCH04 INDEPENDENT TESTS PASSED' in rc.stdout,rc.stderr or rc.stdout
(R/'_bh_b04_independent.log').write_text(rc.stdout)

E3={
'p8:prop:v2127-stress-only-phase-no-go':'B04-EV-01',
'p8:thm:v2127-canonical-kinetic-environment-projector':'B04-EV-01',
'p8:cor:v2127-finite-thickness-coherent-source':'B04-EV-01',
'p8:lem:v2187-canonical-kinetic-projector-transport':'B04-EV-01',
'p8:lem:source-environment-separation':'B04-EV-01',
'p8:lem:v2129-active-stress-dual-static-leaf':'B04-EV-02',
'p8:rem:v2129-environment-measure-transport':'B04-EV-02',
'p8:thm:green-kernel-active-contact-selector':'B04-EV-03',
'p8:cor:cold-thin-disk-terminal-floor':'B04-EV-03',
'p8:thm:hierarchy-selected-reeb-response':'B04-EV-05',
'p8:lem:terminal-static-d1-quotient':'B04-EV-05',
'p8:prop:unique-terminal-geomean':'B04-EV-05',
'p8:thm:v260-born-g26-first-jet':'B04-EV-05',
'p8:cor:rar-apparent-mass-btfr':'B04-EV-05',
'p8:thm:stationary-first-tt-positive-poles':'B04-EV-06',
'p8:prop:first-tt-real-realization':'B04-EV-07',
'p8:cor:massless-tt-memory-realization':'B04-EV-07'
}
PARTIAL={
'p8:cor:stress-energy-phase-space-projections':'B04-EV-09',
'p8:cor:relaxed-spherical-cluster-halo-limit':'B04-EV-03',
'p8:cor:cluster-core-bcg-uplift-limit':'B04-EV-03',
}
IMPORTED={
'p8:thm:scalaron-response-modality-completeness':'B04-EV-09',
'p8:cor:headline-scalaron-role-map':'B04-EV-09',
'p8:rem:hierarchy-reeb-data-status':'B04-EV-09',
}
ISSUES={
'p8:thm:v2129-action-owned-environmental-hessian':['BH-G-000144'],
'p8:thm:merger-lensing-green-propagation':['BH-G-000145'],
'p8:cor:two-component-merger-morphology':['BH-G-000146'],
'p8:thm:terminal-rar-readout':['BH-G-000147'],
}
ISSUE_EXCERPTS={
'BH-G-000144':'"On every supplied scalar boundary realization for which the boundary term is nonnegative" / "is a positivity-preserving inverse"',
'BH-G-000145':'"The acceleration response theorem gives the local constitutive law" followed by g_resp=nu(|grad Phi_b|/a_*) grad Phi_b',
'BH-G-000146':'"If D\\gg\\ell_{\\rm env}, the selector has separated peaks near the two baryonic stress centers"',
'BH-G-000147':'"a_0=\\frac{c^2}{4\\pi}\\sqrt{C_{56}}:=\\frac{c^2}{4\\pi}\\sqrt{\\frac{\\mathcal R_{56}^{\\,2}}{U}}"'
}
claims=[]
for i in range(start-1,end):
 m=re.match(r'\s*\\begin\{(theorem|proposition|lemma|corollary|definition|remark|postulate)\}',s[i])
 if not m:continue
 k=m.group(1)
 j=next(j for j in range(i,end) if re.match(r'\s*\\end\{'+k+r'\}',s[j]))
 labels=re.findall(r'\\label\{([^{}]+)\}','\n'.join(s[i:min(j+1,i+23)]));lab=labels[0] if labels else f'Paper6C:{k}:{i+1}'
 if lab in ISSUES:st='E1_WITH_OPEN_PROOF_LINK_OR_DOMAIN_ISSUE';ev=['B04-EV-02' if lab.startswith('p8:thm:v2129') else 'B04-EV-04' if 'merger' in lab or 'morphology' in lab else 'B04-EV-05','B04-EV-10']
 elif lab in E3:st='E1_E3_SUPPORTED_AT_STATED_CONDITIONAL_SCOPE';ev=[E3[lab]]
 elif lab in PARTIAL:st='E1_E3_SUBCHECK_E2_IMPORT_FULL_SCOPE_PENDING';ev=[PARTIAL[lab]]
 elif lab in IMPORTED:st='E1_E2_IMPORT_LOCATED_E3_PENDING';ev=[IMPORTED[lab]]
 else:st='E1_SOURCE_REPLAY_ONLY_E3_PENDING';ev=['B04-EV-00']
 claims.append({'id':lab,'kind':k,'source_start_line':i+1,'source_end_line':j+1,'evidence_status':st,'evidence_ids':ev,'issue_ids':ISSUES.get(lab,[]),'scope_warning':'environment-level status; conditional algebra is not full physical occurrence/owner audit'})
assert len(claims)==29,len(set(x['id'] for x in claims))==29
counts=dict(collections.Counter(c['evidence_status'] for c in claims))

EVIDENCE=[
{'id':'B04-EV-00','level':'E0/E1','method':'SHA256 source freeze, exact 5296-6887 environment census, label and proof statement/references review','artifacts':['Paper6C-TechnicalMaterial-v1_43.tex'],'positive_controls':['29 formal environments, 10448 source lines unchanged; no original ZIP changed'],'limitation':'Integrity/index evidence, not a mathematical certificate'},
{'id':'B04-EV-01','level':'E3/E4','method':'Lebesgue decomposition; graph-supported singular measure; invariance of null sets under symplectomorphism; stress-only alpha-split counterfamily','artifacts':['Paper6C-Batch04-IndependentChecks-v1_1.py'],'positive_controls':['unique ac/singular decomposition for finite positive kinetic measures under sigma-finite Liouville reference','countable coherent stream graphs null in 6d','actual symplectic maps preserve Liouville null sets'],'negative_controls':['smooth source phase not determined from total Hilbert stress','two distinct ac material populations not separated by Lebesgue type'],'limitation':'Actual kinetic source-member, phase history and map generation remain imported/conditional'},
{'id':'B04-EV-02','level':'E3/E4','method':'Independent sympy differentiation of N(s)E(s) on active dual metric leaf; susceptibility bounds; exact continuous positive-boundary-form/non-Markov countercontrol','artifacts':['Paper6C-Batch04-IndependentChecks-v1_1.py'],'positive_controls':['d²[N(s)E(s)]|0=E(1+4b-b²)','1/2 R_active ≤chi≤ R_active, exact at b=0 and b=1','local nonnegative Robin boundary preserves positive inversion'],'negative_controls':['nonlocal PSD boundary term beta(u0+u1)^2 has q≥0 but positive endpoint source yields negative response at opposite endpoint','exact continuum formula u(1)=-(beta-csch1)/[(coth1+beta)^2-(beta-csch1)^2] <0 for beta=4'],'limitation':'Nonlocal boundary is an abstract adversarial counter to coercivity=>positivity, not shown to be licensed in actual physics; exact native boundary class unverified'},
{'id':'B04-EV-03','level':'E3/E4','method':'Independently proved c(x)=1/G1(x) for constant-preserving pointwise Green functional, min floor max, radial Sturm-Liouville action measure, cold-source zero-drive and cluster density arithmetic','artifacts':['Paper6C-Batch04-IndependentChecks-v1_1.py'],'positive_controls':['normalized Green quotient unique within fixed multiplier schema','terminal floor if R_env=0','c²C56/(8πG)=1.3756310632607492e-26 kg/m³ from a56=1.146e-10'],'negative_controls':['coercivity alone does not certify source-positivity for arbitrary scalar boundaries'],'limitation':'Requires positivity-preserving physical scalar Green and actual kinetic background, no cluster occurrence certified'},
{'id':'B04-EV-04','level':'E4','method':'Adversarial vector-curl/integrability test and exact Gaussian-mixture mode countercontrol for two-source merger morphology','artifacts':['Paper6C-Batch04-IndependentChecks-v1_1.py'],'positive_controls':['spherical radial constant-a* scalar response is locally curl-free','comparable separated Gaussian source weights yield two maxima'],'negative_controls':['Phi_b=(x²+y²)/2, a*(x)=1+0.1x gives curl_z[nu(|grad Phi_b|/a*)grad Phi_b](1,1)=0.0360558345824621','Gaussian K(r)=exp(-r²/2), D=10 ell, Wg=1, Wc=1e-30 has one maximum because Wc<minimum 5.19019e-20 of derivative-weight threshold G(x)'],'limitation':'Curl issue concerns vector lift claimed in the proof; the divergence-defined scalar Poisson equation remains a mathematically valid conditional definition if separately owned'},
{'id':'B04-EV-05','level':'E3/E4','method':'Independent algebraic B1 exchange fixed point, readout dimensional normalization, BBG26 first-jet limit, terminal Reeb small-y/large-y asymptotics and inferred outer BTFR','artifacts':['Paper6C-Batch04-IndependentChecks-v1_1.py'],'positive_controls':['R_resp=sqrt(Rsel Rb) uniquely from B1 on positive domain','g_obs²=a0 g_b with a0=c² sqrt(C56)/(4π)','BBG26 requires lambda/y→1; no all-order lambda=y implied','C56=R56²=U alpha^-7 per current PaperVI-A'],'negative_controls':['printed a0 alternative c² sqrt(R56²/U)/(4π) differs by 1/sqrt(U) and is dimensionally inconsistent'],'limitation':'(B1), (BBG26), SC1/TR1/R1/R2 are physical boundary premises, not independently actualized here'},
{'id':'B04-EV-06','level':'E3/E4','method':'Recompute stationary TT rational response from three spectral frequencies and Kubo weights; positivity/pole interlacing via one-sided signs plus degree bound; 20 positive parameter tests and massless quadratic','artifacts':['Paper6C-Batch04-IndependentChecks-v1_1.py'],'positive_controls':['Dspec=Drat for q_m=0,.001,.1,1,100 and η in bounded range','four roots satisfy 0<x1<u_d<x2<16<x3<A<x4<u_s for 20 tested cases','quadratic has two positive simple roots for massless η=0.001,0.01,0.02'],'negative_controls':['δ=0 cancels all spectral residues except x=8; no spurious extra pole counted','other retained TT sectors require zero TT response for full-channel statement'],'limitation':'Stationary source covariance/TT angular multiplicities are inherited from Paper III-F; no physical stationary history selected'},
{'id':'B04-EV-07','level':'E3','method':'Independent full Pauli-matrix commutator dynamics compared with seven real ODEs; quaternion-force null, preserved tangency; direct massless spectral sum and forced oscillator convolution','artifacts':['Paper6C-Batch04-IndependentChecks-v1_1.py'],'positive_controls':['matrix and real ODE derivatives agree to 1e-12','xdot·r + x·rdot=0','massless ωs=6/a and K=4δℏ/[Vγ a(t)a(s)] sin6Δη','Z''+36Z=6h by derivative of retarded convolution'],'limitation':'Tests one displayed finite Dirac source/output channel, not all evolving full matter sectors'},
{'id':'B04-EV-08','level':'E3/E4','method':'Compute right-2I tensor shell multiplicities from invariant-ring Molien coefficients instead of source character-average; exact K48 semigroup sign/continuity countercontrols','artifacts':['Paper6C-Batch04-IndependentChecks-v1_1.py'],'positive_controls':['f_T(2)=1/2; f_T(10)=f_T(14)=1/26 in common chirality scalar covariance','Vτ=P0+e^-τ PW remains positive/continuous'],'negative_controls':['Vτ-D48 has coefficient e^-τ-1/7<0 for τ>log7','2I tensor same-shell fraction does not imply observed-sky transport'],'limitation':'Tensor reciprocal physical bridge and K48 dimensionful Hilbert-map conditions remain open/conditional'},
{'id':'B04-EV-09','level':'E2','method':'Exact imported owner check for Paper VI-A C56=R56²=U alpha^-7, Paper III-F phase-space/Dirac inputs, Paper IV finite-mode interface and later VI-C modality appendix locator','artifacts':['Paper6A-GravityCosmology-v2_253.tex','Paper3F-CompleteDynamics-v1_256.tex','Paper4A-FiniteQuantumMechanics-v4_208.tex'],'positive_controls':['current VI-A lines 2953-2955, 3170 and 14566-14568 support C56=R56²; Paper VI-C 6285 repeats','scalaron H/L/S/T/M ledger begins at VI-C 6888 and must be audited next'],'limitation':'Not a full upstream owner audit of VI-A/III-F/IV or later VI-C schema appendix'},
{'id':'B04-EV-10','level':'E4','method':'Source-anchored issue certificates with earliest origins, exact positive/negative controls, bypass and condition propagation','artifacts':['Paper6C-RigorousAuditBatch04Evidence-v1_1.json'],'positive_controls':['four new BH-G-000144..147, none duplicate earlier ten'],'limitation':'Staged records pending final global DAG integration'}
]

def issue(id,cls,sev,status,tid,loc,obligation,ev,advers,bnd,conditions,openconds,up,down,bypass,impact,fix,limit):
 return {'id':id,'issue_class':cls,'severity':sev,'lifecycle':'OPEN','issue_status':status,'first_origin':{'paper':'Paper6C','theorem_id':tid,'step_locator':'Paper6C-TechnicalMaterial-v1_43.tex:'+loc,'source_excerpt':ISSUE_EXCERPTS[id]},'statement_layer':'SOURCE-AS-PRINTED','exact_obligation':obligation,'source_replayed':True,'independent_evidence':ev,'adversarial_evidence':advers,'constitution_boundary':bnd,'conditions_consumed':conditions,'conditions_open':openconds,'upstream_material_paths':up,'downstream_verified_paths':down,'other_papers_affected':[],'possible_unconfirmed_impacts':impact,'verified_bypass_routes':bypass,'why_it_matters':obligation,'resolution_requirement':fix,'audit_scope_limit':limit}
ISSUE_DATA=[
issue('BH-G-000144','MISSING_CONDITION','moderate','conditional_boundary_positive_semigroup','p8:thm:v2129-action-owned-environmental-hessian','5732-5746','Nonnegative scalar boundary quadratic form and coercivity imply invertibility, but NOT a positive inverse without a positivity-preserving/Markov boundary condition, as consumed by G_env1>0 and normalized source Green selection.',['B04-EV-02','B04-EV-03'],['B04-EV-02'],'BND-04-01',['C56>0','chi_kin>=0','nonnegative boundary quadratic form'],['actual scalar boundary domain supports maximum principle / positivity-preserving inverse'],[['Paper6C:p8:lem:v2129-active-stress-dual-static-leaf','Paper6C:p8:thm:v2129-action-owned-environmental-hessian']],[['Paper6C:p8:thm:v2129-action-owned-environmental-hessian','Paper6C:p8:thm:green-kernel-active-contact-selector'],['Paper6C:p8:thm:green-kernel-active-contact-selector','Paper6C:p8:cor:relaxed-spherical-cluster-halo-limit'],['Paper6C:p8:thm:green-kernel-active-contact-selector','Paper6C:p8:thm:merger-lensing-green-propagation']],['local positive Robin/Dirichlet source realization supplies positivity if actually licensed'],['galaxy/cluster RAR and merger applications inherit condition; not shown false on their actual local boundary'], 'Locate an actual local Markov/Robin/Dirichlet scalar boundary theorem or certify positive semigroup for the actual nonlocal boundary; not enough to cite quadratic coercivity.', 'Adversarial boundary is ambient 1D nonlocal mathematical realization, not shown physically licensed; cannot refute the actual restricted physical Green.'),
issue('BH-G-000145','TYPE_OR_DOMAIN','moderate','undischarged_vector_lift','p8:thm:merger-lensing-green-propagation','6092-6115;6135-6154','A radial scalar RAR law g_obs=nu(g_b/a*)g_b is used as the local nonspherical vector force g_resp=nu(|grad Phi_b|/a*)grad Phi_b and then as gradient of the lensing scalar potential; a spatially varying a* generally creates nonzero curl, so the force-to-potential step is not justified by taking its divergence.',['B04-EV-04'],['B04-EV-04'],'BND-04-02',['quasi-static merger','a*(x)>0 from environmental selector','scalar Reeb response'],['licensed curl-free vector lift OR explicit longitudinal Helmholtz projection as physical response'],[['Paper6C:p8:thm:hierarchy-selected-reeb-response','Paper6C:p8:thm:merger-lensing-green-propagation'],['Paper6C:p8:thm:green-kernel-active-contact-selector','Paper6C:p8:thm:merger-lensing-green-propagation']],[['Paper6C:p8:thm:merger-lensing-green-propagation','Paper6C:p8:cor:two-component-merger-morphology']],['the divergence Poisson equation remains well-defined as a separately stipulated scalar response; radial/constant-a* cases have curl zero'],['precise lensing peak location and Bullet-like offset physical claims'], 'Trace a sourced scalar Helmholtz/Poisson response operator directly from the native action, or establish curl-free condition in declared merger domain; do not add a new physical mechanism in the audit.', 'Counter-witness validates failure of automatic integrability; no refutation of a separately stipulated Poisson equation as mathematical PDE.'),
issue('BH-G-000146','MISSING_CONDITION','moderate','gaussian_counterexample_to_separation_alone','p8:cor:two-component-merger-morphology','6158-6178','K radial positive decreasing and D≫ell do not alone ensure separated selector maxima when component positive weights Wg,Wc can be arbitrarily imbalanced; two-peak conclusion requires additional weight/profile control.',['B04-EV-04'],['B04-EV-04'],'BND-04-03',['radial strictly decreasing evaluated kernel','positive Wg,Wc','D≫ell'],['relative mass/weight sufficient for second local maximum, or weaken conclusion to potential not guaranteed'],[['Paper6C:p8:thm:merger-lensing-green-propagation','Paper6C:p8:cor:two-component-merger-morphology']],[['Paper6C:p8:cor:two-component-merger-morphology','Paper6C:p8:thm:merger-lensing-green-propagation (morphology-only consumer, not proof ancestry)']],['Gaussian K with comparable W_g and W_c gives two maxima when D=10ell'],['assertions of automatic two peaks in merger selectors; does not refute general lensing Poisson map'], 'Require a quantitative relative weight/profile condition for bimodality or treat morphology as case-dependent; leave standalone Renv field intact.', 'Adversarial Gaussian satisfies printed kernel shape and D≫ell; exact root count one by derivative threshold Gmin.'),
issue('BH-G-000147','INCORRECT_STEP','minor','exact_symbolic_normalization_mismatch','p8:thm:terminal-rar-readout','6393-6399','Current owner defines C56=R56²=U alpha^-7, whereas the second printed a0 equality uses R56²/U; these differ by factor 1/U inside the square root, making the second expression dimensionally wrong.',['B04-EV-05','B04-EV-09'],['B04-EV-05'],'BND-04-04',['U>0 intrinsic curvature owner','R56=sqrt(U) alpha^-7/2','C56=R56²'],['exact dimensional identity C56=R56², not R56²/U'],[['Paper6A:terminal-hierarchy-identity','Paper6C:p8:def:dark-response-ladder'],['Paper6C:p8:def:dark-response-ladder','Paper6C:p8:thm:terminal-rar-readout']],[['Paper6C:p8:thm:terminal-rar-readout','Paper6C:later terminal synchronization line 9910 (unreviewed future occurrence)']],['primary a0=c²sqrt(C56)/(4π) identity and B1/BTFR derivation remain intact; 6239 and 6426 use correct expression'],['future restatements of normalized R56²/U need same origin'], 'Align the displayed secondary equality and later reuse with current VI-A definition without changing physically correct primary a0 value; report only, no source edit.', 'Explicit VI-A current versions checked for convention; later line 9910 is a locator, NOT audited as a theorem in Batch04.')
]

BND=[
{'id':'BND-04-01','claim':'p8:thm:v2129-action-owned-environmental-hessian','source_stage':'terminal static Einstein kinetic/source branch, after active-dual tangent and before Green normalization','sorts':'elliptic scalar operator on action measure; form domain + boundary condition','frozen_inventory':'C56, chi_kin, N,h, actual kinetic member, supplied scalar boundary realization','licensed_ops':'local kinetic second variation, integration by parts and local maximum principle when domain is a maximum-principle domain','quantifier':'printed every supplied boundary with nonnegative boundary term; actual boundary class not enumerated','E_U_C_R_I':'coercivity/inverse existence E valid; positivity P not implied by E; physical boundary R needs explicit inherited certificate','warrant':'analytic positive quadratic nonlocal boundary with nonpositive Green counter; no claim this boundary is licensed'},
{'id':'BND-04-02','claim':'p8:thm:merger-lensing-green-propagation','source_stage':'quasi-static non-spherical vector/lensing observable after scalar RAR','sorts':'radial acceleration magnitude -> vector field -> scalar Poisson potential -> line-of-sight lensing','frozen_inventory':'P_env normalized selector, a*(x), Phi_b, nu_Reeb, scalar no-slip branch','licensed_ops':'scalar magnitude law, divergence of any vector, Poisson solution under boundary; curl-free lift not automatic','quantifier':'merger non-spherical and spatially varying hierarchy; not only radial constant a*','E_U_C_R_I':'PDE definition exists as mathematical object; equality to the constitutive vector and physical lensing realization need extra proof','warrant':'nonzero curl exact analytic counter; preserves scalar Poisson as conditional definition'},
{'id':'BND-04-03','claim':'p8:cor:two-component-merger-morphology','source_stage':'evaluated radial kernel, two localized baryonic stress weights','sorts':'positive scalar convolution map and number of local maxima','frozen_inventory':'radial K decreasing, D≫ell, Wg>0,Wc>0','licensed_ops':'linear convolution, local extrema comparison; no weight ratio fixed by separation','quantifier':'all positive weights as printed; no minimum ratio assumption','E_U_C_R_I':'two peaks possible E, not universal U under separation; physical weights not selected by kernel math','warrant':'Gaussian with extreme admissible ratio has only one maximum'},
{'id':'BND-04-04','claim':'p8:thm:terminal-rar-readout','source_stage':'already fixed terminal curvature owner and physical acceleration readout','sorts':'dimensional curvature C56=R56², U has inverse-square length dimensions','frozen_inventory':'Paper VI-A R56=sqrtU alpha^-7/2; C56=U alpha^-7','licensed_ops':'B1 geomean of positive curvatures and a=(c²/4π)sqrtR; no redefinition of R56','quantifier':'literal displayed equation at lines 6397-6398','E_U_C_R_I':'primary B1 result verified at mathematical scope, secondary symbol equality false','warrant':'cross-checked current VI-A 2953-2955/14566-14568'}
]

def edge(fr,to,kind,route,guard,loc,ev,review='MATERIAL_SOURCE_USE_CONDITIONAL'):
 return {'from':fr,'to':to,'kind':kind,'proof_route':route,'logic_group':'AND','scope_guard':guard,'review':review,'source_use_locator':f'Paper6C:{loc}','evidence_id':ev}
EDGES=[
 edge('Paper3F:generated-local-cotangent-phase','Paper6C:p8:def:v2127-kinetic-baryon-source-packet','IMPORTED_PROOF','KINETIC_MEMBER','only actual certified local kinetic cotangent domain','5405-5417','B04-EV-09','SOURCE_LOCATED_OWNER_FULL_PROOF_PENDING'),
 edge('Paper6C:p8:def:v2127-kinetic-baryon-source-packet','Paper6C:p8:thm:v2127-canonical-kinetic-environment-projector','REQUIRES','KINETIC_LD','finite positive Radon source measure and canonical Liouville form','5458-5489','B04-EV-01'),
 edge('Paper6C:p8:thm:v2127-canonical-kinetic-environment-projector','Paper6C:p8:cor:v2127-finite-thickness-coherent-source','REQUIRES','KINETIC_COHERENT','exact graph-singular source','5502-5527','B04-EV-01'),
 edge('Paper6C:p8:thm:v2127-canonical-kinetic-environment-projector','Paper6C:p8:lem:v2187-canonical-kinetic-projector-transport','REQUIRES','KINETIC_TRANSPORT','certified symplectic diffeomorphism preserving Liouville null sets','5540-5563','B04-EV-01'),
 edge('Paper6C:p8:lem:active-stress-selector-scalar','Paper6C:p8:lem:v2129-active-stress-dual-static-leaf','REQUIRES','ACTIVE_DUAL','separating stress test class','5627-5653','B04-EV-02'),
 edge('Paper6C:p8:lem:v2129-active-stress-dual-static-leaf','Paper6C:p8:thm:v2129-action-owned-environmental-hessian','REQUIRES','STATIC_HESSIAN','actual kinetic member and amplitude-only source tangent','5667-5769','B04-EV-02'),
 edge('Paper6C:p8:thm:v2127-canonical-kinetic-environment-projector','Paper6C:p8:thm:v2129-action-owned-environmental-hessian','REQUIRES','STATIC_HESSIAN','actual dispersed source packet and fixed occupation profile','5703-5716','B04-EV-02'),
 edge('Paper6C:p8:thm:v2129-action-owned-environmental-hessian','Paper6C:p8:thm:green-kernel-active-contact-selector','REQUIRES','ENV_GREEN','positive G_env1, local maximum-principle boundary unverified','5800-5849','B04-EV-03','MATERIAL_WITH_OPEN_BOUNDARY_CONDITION'),
 edge('Paper6C:p8:thm:green-kernel-active-contact-selector','Paper6C:p8:cor:cold-thin-disk-terminal-floor','REQUIRES','COLD_FLOOR','coherent kinetic packet no dispersed component','5872-5906','B04-EV-03'),
 edge('Paper6C:p8:thm:green-kernel-active-contact-selector','Paper6C:p8:cor:relaxed-spherical-cluster-halo-limit','REQUIRES','CLUSTER_GREEN','radial static boundary and actual gas kinetic member','5920-5988','B04-EV-03'),
 edge('Paper6C:p8:thm:green-kernel-active-contact-selector','Paper6C:p8:cor:cluster-core-bcg-uplift-limit','REQUIRES','CORE_GREEN','actual core data and local-kernel limit only for density formula','6004-6049','B04-EV-03'),
 edge('Paper6C:p8:thm:green-kernel-active-contact-selector','Paper6C:p8:thm:merger-lensing-green-propagation','REQUIRES','MERGER_GREEN','quasi-static Green selector and scalar physical source','6061-6095','B04-EV-04'),
 edge('Paper6C:p8:thm:hierarchy-selected-reeb-response','Paper6C:p8:thm:merger-lensing-green-propagation','REQUIRES','MERGER_VECTOR_LIFT','nonspherical vector constitutive lift not certified','6096-6115','B04-EV-04','MATERIAL_WITH_OPEN_CURL_INTEGRABILITY'),
 edge('Paper6C:p8:thm:merger-lensing-green-propagation','Paper6C:p8:cor:two-component-merger-morphology','REQUIRES','TWO_COMPONENT_SELECTOR','scalar propagated selector, two positive source weights and radial K','6158-6178','B04-EV-04','MATERIAL_WITH_OPEN_WEIGHT_CONDITION'),
 edge('Paper6C:p8:prop:v260-general-reeb-envelope','Paper6C:p8:thm:hierarchy-selected-reeb-response','REQUIRES','REEB_STATIC','R1,R2, SC1,TR1 and positive y','6182-6237','B04-EV-05'),
 edge('Paper6C:p8:lem:terminal-static-d1-quotient','Paper6C:p8:prop:unique-terminal-geomean','REQUIRES','IR_BORN','explicit B1 balanced fixed-point physical premise','6330-6369','B04-EV-05'),
 edge('Paper6C:p8:prop:unique-terminal-geomean','Paper6C:p8:thm:terminal-rar-readout','REQUIRES','IR_BORN','B1 and cold-disk R_sel=C56 plus determinant acceleration readout','6372-6426','B04-EV-05'),
 edge('Paper6C:p8:prop:v260-general-reeb-envelope','Paper6C:p8:thm:v260-born-g26-first-jet','REQUIRES','BBG26','explicit physical co-realization BBG26, continuous lambda>0','6436-6499','B04-EV-05'),
 edge('Paper6C:p8:thm:hierarchy-selected-reeb-response','Paper6C:p8:cor:rar-apparent-mass-btfr','REQUIRES','BTFR','positive y, finite outer baryonic mass and deep regime','6500-6523','B04-EV-05'),
 edge('Paper3F:tt-angular-contacts','Paper6C:p8:thm:stationary-first-tt-positive-poles','IMPORTED_PROOF','TT_SOURCE','full angular trace and occupied plus 7/2 empty transition shells','6530-6621','B04-EV-06','SOURCE_LOCATED_INPUT_E3_CHECKED_NUMERIC'),
 edge('Paper4A:finite-commutator-response','Paper6C:p8:prop:first-tt-real-realization','IMPORTED_PROOF','TT_MEMORY','retarded finite tangent, no instantaneous state reset','6706-6767','B04-EV-07','SOURCE_LOCATED_INPUT_MATRIX_REPLAYED'),
 edge('Paper6C:p8:prop:first-tt-real-realization','Paper6C:p8:cor:massless-tt-memory-realization','REQUIRES','TT_MASSLESS','m=0, r=e_z, inherited a(t), F(t), delta','6773-6812','B04-EV-07'),
]

HASHFILES={
'Paper00-PapersMinimal-v2_371(1)(1).zip':R/'Paper00-PapersMinimal-v2_371(1)(1).zip',
'Paper00-DAGAtlas-v1_115(1).zip':R/'Paper00-DAGAtlas-v1_115(1).zip',
'Paper00-ProofChainAudits-v1_32(1).zip':R/'Paper00-ProofChainAudits-v1_32(1).zip',
'Paper00-RigorousVerificationDAGWorkProtocol-v2_4(1).md':R/'Paper00-RigorousVerificationDAGWorkProtocol-v2_4(1).md',
'Paper6C-TechnicalMaterial-v1_43.tex':p,
'Paper6A-GravityCosmology-v2_253.tex':R/'_bh_audit_inputs/Paper6A-GravityCosmology-v2_253.tex',
'Paper3F-CompleteDynamics-v1_256.tex':R/'_bh_audit_inputs/Paper3F-CompleteDynamics-v1_256.tex',
'Paper4A-FiniteQuantumMechanics-v4_208.tex':R/'_bh_audit_inputs/Paper4A-FiniteQuantumMechanics-v4_208.tex',
'Paper6C-RigorousAuditBatch03Evidence-v1_1.json':R/'Paper6C-RigorousAuditBatch03Evidence-v1_1.json',
'Paper6C-Batch04-IndependentChecks-v1_1.py':R/'Paper6C-Batch04-IndependentChecks-v1_1.py',
}
hashes={k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in HASHFILES.items()}
for key in ['Paper00-PapersMinimal-v2_371(1)(1).zip','Paper00-DAGAtlas-v1_115(1).zip','Paper00-ProofChainAudits-v1_32(1).zip','Paper6C-TechnicalMaterial-v1_43.tex']:
 assert hashes[key]==b03['frozen_sha256'][key],key

raw={
'record_type':'rigorous_single_paper_audit_batch_evidence','checkpoint_version':'1.1','paper':'Paper6C','protocol':'RigorousVerificationDAGWorkProtocol v2.4','source_file':p.name,'batch':4,'batch_lines':[start,end], 'next_batch_first_line':6888,'manuscript_total_lines':len(s),
'frozen_sha256':hashes,'scanned_formal_statement_count':len(claims),'batch_status_counts':counts,'cumulative_claims_inventoried':144+len(claims),'cumulative_source_span':[80,end],
'claims':claims,'evidence':EVIDENCE,'issues':ISSUE_DATA,'inherited_open_issue_ids':[f'BH-G-{i:06d}' for i in range(134,144)],
'first_known_issue_id_policy':'BH-G-000144 is earliest new finding in this source span; earlier BH-G-000134..143 inherited and not duplicated; future references to normalization discrepancy inherit BH-G-000147.',
'constitution_boundary_records':BND,'source_proof_edges_reviewed':EDGES,
'negative_or_rejected_allegations':[
 'No new issue for cold finite-thickness streams: phase-space measure graph, not position-space volume, controls exact kinetic classification; source states this distinction explicitly.',
 'No issue for absence of four-modality proof at line 5296: the proof is explicitly deferred to VI-C 6900-7365, to be audited next; not yet E3 promoted.',
 'No claim B1 is already derived: paper expressly introduces B1 as a physical ownership premise; no falsification of conditional geomean.',
 'No issue for BBG26 all-order lambda=y: source expressly excludes that stronger implication.',
 'No claim a tensor right-2I rank fraction predicts an observed quadrupole: source expressly says mathematical same-shell rank only.',
 'No claim generic endpoint y=0 has finite Reeb nu: inherits earlier BH-G-000143 and y>0 E3; observable limit finite.',
 'No issue in exact stationary 4-pole theorem based on pure q/eta numeric grid: combined with printed sign/degree proof, all tested corners pass.',
 'No issue for positive Robin/Dirichlet scalar boundaries: these give countercontrols to wide positivity claim; only missing scope certificate for supplied boundary class is reported.',
 'No contradiction between Poisson divergence PDE and scalar mathematical existence: the issue is unproven equivalence to local vector force and physical realization.',
 'No new theory or new source mechanism derived; B1/BBG26/kinetic member/readout assumptions kept visible.'
 ],
'conditions_pending_global_registry_identity':[
 'existing: stable m_p=1 and actual unfolded terminal static source; no new baseline gap',
 'B04 first: positive Radon kinetic member relative to Liouville measure (lines 5418-5432)',
 'B04 first: exact graph-momentum coherent singular class vs dispersed ac (lines 5458-5489)',
 'B04 first: actual licensed symplectic flow preserves null sets (5540-5563)',
 'B04 first: separating stress class for unique active-dual tangent (5627-5649)',
 'B04 first: amplitude-only dispersed source tangent and positive kinetic occupation (5679-5716)',
 'B04 OPEN: supplied scalar boundary positivity/maximum principle, beyond nonnegative form (5732-5746)',
 'B04 first: frozen positive Green constant-preserving multiplier schema (5804-5817)',
 'B04 first: conditional local-kernel cluster/core approximation (5959-5974, 6022-6048)',
 'B04 OPEN: nonspherical physical vector-to-scalar integrability/Helmholtz readout (6096-6115)',
 'B04 OPEN: two-source kernel weight ratio for bimodality (6158-6175)',
 'existing inherited R1/R2, SC1/TR1, y>0 (6182-6237)',
 'B04 first: explicit B1 as a physical fixed-point ownership premise, no derivation by quotient alone (6330-6348)',
 'B04 first: BBG26 explicit co-realization plus lambda continuity/positivity (6436-6472)',
 'B04 first: stationary TT eta bound and exclusion of other TT sectors (6621-6669)',
 'B04 first: actual evolution initial state, no tensor state reset (6681-6720)',
 'B04 OPEN: current VI-A C56=R56²; printed secondary normalized formula wrong (6397-6398)'
 ],
'coverage_classification':'PARTIALLY_AUDITED: all 29 formal environments in this source span scanned and scope-reviewed; E3 only exact isolated mathematical and conditional results indicated; later modality ledger not yet audited; actual full native action and all imported owner proofs not fully verified. Supplemental non-environment tensor 2I projection and K48 no-go independently replayed.',
'graph_status':'STAGING_ONLY_NO_CANONICAL_ATLAS_MUTATION. Single canonical assumptions and issues must be integrated at final batch; no original paper or incoming archive modified.',
'zip_delivery_policy':'Final batch only: produce updated DAG Atlas and ProofChain Audits ZIP, both retaining only latest per-paper applicable versions, after actual archive validation.'
}
out=R/'Paper6C-RigorousAuditBatch04Evidence-v1_1.json'
out.write_text(json.dumps(raw,indent=2,ensure_ascii=False)+'\n')
assert json.loads(out.read_text())['cumulative_claims_inventoried']==173

SUMMARY='''# Paper VI-C — Rigorous Verification/DAG Audit, Batch 04 (v1.1)

**Authoritative source:** `Paper6C-TechnicalMaterial-v1_43.tex` from current `Paper00-PapersMinimal-v2_371`; verification protocol v2.4. **Scope:** lines **5296–6887** inclusive of 10448; **29 formal statements**, plus the unnumbered stationary TT, right-2I projector and K48 semigroup calculations. Cumulative claim census after batches 1–4: **173 statements**; next starts at **6888**. **State:** `PARTIALLY_AUDITED`, not a full mathematical certification of all upstream physical owner proofs. The original papers, DAG ZIP and audit ZIP remain unchanged.

## Audit result and most important scope distinction

- **Independent E3 positive controls:** canonical kinetic Lebesgue projector and collisionless measure transport; active metric tangent/kinetic susceptibility; positive-domain Green quotient normalization; cluster radial operator/density scale; explicit Born-balance (B1) geometric mean, the conditional BBG26 first jet and deep BTFR algebra; stationary three-frequency tensor response and four-pole interlacing; finite seven-coordinate tensor memory; massless retarded sinusoidal kernel; right-2I tensor rank fractions and K48 no-instantaneous-export controls.
- **4 distinct findings (3 moderate, 1 minor)** are recorded below, no duplicate of BH-G-000134..143. The Green positive-semigroup premise is **not** equated with the kinetic Hessian algebra, which checks. The two merger issues concern vector realization and quantitative morphology, **not** a falsification of the formal Poisson PDE itself. The terminal curvature discrepancy is in an **alternative printed equality**; the primary acceleration scale is the correct one.
- **Source-only / dependency-bound limits:** `p8:thm:scalaron-response-modality-completeness` points explicitly to Appendix 6888ff, to be checked in the next batch. Paper III-F generated cotangent targets, Paper IV retarded finite response, and the full metric action Hessian are not declared globally E3 verified here. SC1/TR1/R1/R2 and B1/BBG26 are retained as typed physical conditions, not new predictions.

## New issue certificates

### BH-G-000144 — Nonnegative boundary form is not alone a positivity-preserving Green domain (moderate; MISSING_CONDITION)
**Earliest origin:** `p8:thm:v2129-action-owned-environmental-hessian` 5732–5746. The text derives coercivity when the boundary term is nonnegative, and then calls `G_env=P_env^-1` positivity preserving and `G_env1>0`. The former certifies an invertible positive quadratic form, but by itself does not imply the maximum-principle property for every possibly nonlocal boundary. **Exact E4 countercontrol:** on `[0,1]`, `q[u]=∫_0^1(|u′|²+u²)dx + 4(u(0)+u(1))²` has a nonnegative boundary form and is coercive. Its boundary Green response to positive endpoint input at `0` has opposite endpoint value `u(1)=-(4-csch1)/[(4+coth1)²-(4-csch1)²] ≈ −0.17197171`, thus the inverse is not positive. A local positive Robin boundary gives a positive inverse, and the independent Hessian algebra `χ_kin=(κ/2)∫ E(1+4b−b²)` passes exactly. **Scope:** the adversarial nonlocal boundary has not been shown to belong to the framework's *actual supplied* boundary realizations, so this is a necessary **boundary-class/maximum-principle certificate**, **not** an in-domain refutation of a licensed local positive boundary. **Impact path:** environmental Hessian → normalized Green selector → galaxy/cluster/merger readout, all conditional on this property. **Required evidence:** an actual boundary owner certifying Markov/positive-inverse behavior or the explicit positive-domain assumption; no source changed.

### BH-G-000145 — Nonspherical merger Reeb force requires a vector-to-potential bridge (moderate; TYPE_OR_DOMAIN)
**Earliest origin:** `p8:thm:merger-lensing-green-propagation` 6096–6115, proof 6135–6154. The earlier Reeb theorem gives a scalar *magnitude* on a static response; the merger proof lifts it to `g_resp = ν(|∇Φ_b|/a_*(x)) ∇Φ_b` and treats its divergence as a scalar potential for lensing. Such a vector generally has **nonzero curl**, because `∇a_*` need not be parallel to `∇Φ_b`. **Exact E4 witness:** `Φ_b=(x²+y²)/2` and `a_*(x)=1+0.1x`, giving `curl_z[ν(|∇Φ_b|/a_*)∇Φ_b](1,1)=0.03605583458`. Therefore the direct local vector is generally **not** `∇Φ_resp`; taking its divergence specifies its longitudinal projection but does not establish equality or physical ownership of the projection. **Scope:** a divergence-defined scalar Poisson equation can still be a legitimate separate conditional mathematical readout, and radial/constant-scale cases evade the counterexample. The issue is the missing typed bridge to the claimed nonspherical observable and its no-slip lensing potential, not the existence of Poisson solutions. **Required evidence:** source-owned vector/longitudinal projection map or an actual curl-free restriction; no new mechanism invented here.

### BH-G-000146 — Large kernel separation alone does not force two merger peaks (moderate; MISSING_CONDITION)
**Earliest origin:** `p8:cor:two-component-merger-morphology` 6158–6178. It says `D≫ℓ_env` yields separated peaks for positive source weights but gives no lower bound on `W_c/W_g`. **Exact E4 counter-witness:** smooth positive strictly radial-decreasing Gaussian `K(r)=exp(−r²/(2ℓ²))`, `D=10ℓ`, `W_g=1`, `W_c=10^-30`. Along the line of centers, stationary points require `ε=G(x)=x/(D−x)exp(D²/2−Dx)`; the secondary local minimum of `G` equals `5.190190197×10^-20`, so `ε` below it yields only one stationary maximum, near the dominant source. Transverse derivatives exclude off-axis maxima. Equal weights at the same separation are a positive two-peak control. **Impact:** local morphology criterion, not the Green sum itself. **Requirement:** a source-weight/profile condition for bimodality or a genuinely conditional case-specific statement.

### BH-G-000147 — Inconsistent terminal \(\mathcal R_{56}\) normalization (minor; INCORRECT_STEP)
**Earliest origin:** `p8:thm:terminal-rar-readout` 6397–6398. Current VI-A owner states `\mathcal R_{56}=\sqrt U\alpha^{-7/2}` and `C_{56}=\mathcal R_{56}^2=U\alpha^{-7}` (VI-A 2953–2955 and 14566–14568), repeated in VI-C 6285. Thus the displayed second equality `a_0=(c²/4π)√(\mathcal R_{56}²/U)` does **not** equal the correct first equality `a_0=(c²/4π)√C_{56}`; it differs by `1/√U` and is dimensionally wrong. The primary `a_0` readout, B1 geometric mean, and BTFR algebra survive. A later unreviewed restatement at line 9910 apparently repeats the same normalization, so it should inherit this one issue when reached. **Requirement:** reconcile the printed alternative with the current owner; do not modify source in an audit.

## Inherited issues and propagation

All earlier 10 findings `BH-G-000134`–`BH-G-000143` remain in the global *staging* ledger. In particular, endpoint divergence of `ν(0)` inherits **BH-G-000143** and is not duplicated as a new finding; `g_b ν(g_b/a_*)` has a finite zero-limit. Merger/cluster physical predictions inherit their actual kinetic member, the positive environmental Green condition, the selected hierarchy and R1/R2/SC1/TR1; they are **not** declared falsified by an ambient counterexample. The K48 tensor projector has no physically constituted sky bridge and is not interpreted as a CMB prediction. The fully proven source-to-modality schema (H,L,S,T plus Paper-IV M) is deferred to the next batch, exactly as stated by the manuscript.

## Independent verification details

1. The symbolic active-leaf kinetic Hamiltonian `H(s)=e^s sqrt(m²+q e^{2s})` yields `H′(0)=E(1+b)` and `H″(0)=E(1+4b−b²)` with `b=q/E²`. The ratio `χ_kin/R_active=(1+4b−b²)/(2+2b)` lies in `[1/2,1]` for `b∈[0,1]`. This verifies the stated *matter* Hessian moment, not the full Einstein boundary owner.
2. For the fixed linear pointwise schema `T_cf(x)=c(x)Gf(x)`, constant preservation forces `c=1/G1`, and the least real scalar bounding floor and environment is exactly `max(C56,Renv)`. The approximate cluster local-density conversion produces `1.375631063×10^-26 kg m^-3` from the paper's `a56`, consistent with `1.4×10^-26` printed. The exact radial Green operator and the optional slow-gradient limit are distinct.
3. The B1 exchange fixed point `R/Rsel = Rb/R` has the unique positive root `R=sqrt(Rsel Rb)`; using the static determinant acceleration readout gives `g_obs²=a0 gb` conditional on B1. BBG26 matches only the leading `λ(y)/y→1` and does not establish exact all-order `λ=y`. The conditional extra mass, deep BTFR and Reeb asymptotics pass at positive `gb`.
4. Independent spectral-sum evaluation reproduces the paper's rational stationary TT denominator for `q_m=0,0.001,0.1,1,100`, at multiple `η,x`. The interlacing theorem follows from four interval sign crossings and quartic degree; numerical root tests independently confirm the exact order for 20 positive examples up to the allowed `η` bound; the massless quadratic has two positive simple roots in all tested bounded controls. No source population/history was fitted.
5. Independently evaluating Pauli commutator matrices for an arbitrary nonstationary real covariance recovers all seven displayed real response-coordinate derivatives to `1e-12`, the null quaternion output and tangency condition. The massless sum gives the sine-6 retarded kernel and its `Z″+36Z=6h` companion; it introduces no new quantum degree of freedom.
6. Right-2I rank fractions obtained independently from Molien coefficients are `f_T(2)=1/2` and `f_T(10)=f_T(14)=1/26`; these are same-shell mathematical fractions only. The explicit K48 `e^-τ−1/7` continuation is negative for `τ>log7`, while the continuous semigroup remains positive; no instantaneous export follows.

## Full source-environment census

| # | Source lines | Exact source label | Evidence disposition |
|---:|---:|---|---|
'''
for i,c in enumerate(claims,1):
 SUMMARY+=f"| {i} | {c['source_start_line']}–{c['source_end_line']} | `{c['id']}` | `{c['evidence_status']}` |\n"
SUMMARY+='''
## Evidence, graph, and release checkpoint

- **Reproducible source files:** `Paper6C-Batch04-IndependentChecks-v1_1.py` and `Paper6C-RigorousAuditBatch04Evidence-v1_1.json` (also the independent calculation log, local only). `B04-EV-00`–`B04-EV-10` distinguish E0 integrity, E1 source proof replay, E2 imported owner location, E3 independently verified conditional algebra, and E4 valid/bypassed adversarial controls.
- **Graph staging:** 4 first-origin issue certificates, 4 boundary-gate records, {edge_count} reviewed source dependency edges, explicit inherited conditions, negative-allegation log. No paper modification, fabricated proof, new physical mechanism, or edit to incoming source ZIP.
- **Next source range:** line **6888** (native scalaron response-schema completeness appendix; followed by boundary-owner and DtN interfaces). The Atlas ZIP and ProofChain Audits ZIP will be released **only after the final Batch**, each with only the latest applicable versions and a post-write structure/content check.
'''.format(edge_count=len(EDGES))
report=R/'Paper6C-RigorousAuditBatch04-v1_1.md';report.write_text(SUMMARY)
# Final self-check 
assert len(ISSUE_DATA)==4 and len(BND)==4
assert sorted(int(x['id'].split('-')[-1]) for x in ISSUE_DATA)==list(range(144,148))
for c in claims:assert 5296<=c['source_start_line']<=c['source_end_line']<=6887
for x in ISSUE_DATA:assert x['first_origin']['theorem_id'] in {c['id'] for c in claims}
print('READY',report.name,out.name,'formal',len(claims),'counts',counts,'issues',[x['id'] for x in ISSUE_DATA],'edges',len(EDGES),'bytes',report.stat().st_size,out.stat().st_size)
