"""Algebraic independent controls, first 1,374 lines Paper VI-C source."""
import sympy as s
x,R,U,C,Ms,gm,H=s.symbols('x R U C M_s gamma H',positive=True)
D=U+C
f=R+(R**2+U*C)/D-2*C
F=s.diff(f,R); f2=s.diff(F,R)
R0=2*C*(U+2*C)/D
assert s.simplify((R*F-2*f).subs(R,R0))==0
assert s.simplify((F-R*f2)/(3*f2)-D/6)==0
print('Historical f(R) constant-curvature root and m_alg²=D/6: PASS')
# verify slow-roll consistency for E-frame quadratic reference V0(1-exp(-sqrt(2/3) phi/M))²
z=s.symbols('z',positive=True)
eps=s.Rational(4,3)*(z/(1-z))**2
eta=s.Rational(4,3)*(-z+2*z*z)/(1-z)**2
n_s=1-6*eps+2*eta; r=16*eps
assert s.simplify(1-n_s-(s.Rational(8,3)*z/(1-z)+r/4))==0
print('Single-clock quadratic reference n_s/r identity: PASS (z in (0,1))')
# scalar canonical redefinition action proof
# M(t), L(t), s(t) symbolic via q = sqrt(M) R
m=s.Function('m'); q=s.Function('q'); t=s.symbols('t');
# Original action integrated by parts gives Omega² = L/M - m''/m; ensure algebra identity
M=s.Function('M')(t); Lv=s.Function('L')(t)
logder=s.diff(s.log(s.sqrt(M)),t)
assert s.simplify(-s.diff(logder,t)-logder**2+s.diff(M,t,2)/(2*M)-s.diff(M,t)**2/(4*M**2))==0
print('Time-dependent scalar canonical mass and pump terms: PASS')
# General Ward 3-vertex derivative algebra from S invariant under parameter-dependent generator
# simple 1D nonlinearity y polynomial with flat gauge orbit x, on-shell K R=0
u,v=s.symbols('u v'); S=(u*u+v*v-1)**2; Ru=-v; Rv=u
assert s.simplify(s.diff(S,u)*Ru+s.diff(S,v)*Rv)==0
# evaluate at stationary u=1,v=0 and check K R=0 and 3rd Ward identity 2-index
K=s.hessian(S,(u,v)); V3=[[[s.diff(S,a,b,c) for c in (u,v)] for b in (u,v)] for a in (u,v)]; Rvec=s.Matrix([Ru,Rv])
for i in range(2):
  for j in range(2):
    w=sum(V3[i][j][k]*Rvec[k] for k in range(2))+sum(K[k,j]*s.diff(Rvec[k],(u,v)[i])+K[k,i]*s.diff(Rvec[k],(u,v)[j]) for k in range(2))
    assert s.simplify(w.subs({u:1,v:0}))==0
print('K16 Ward identities on nonlinear invariant action: PASS')
# Spin(4) covariance alone does not imply null restriction to L6: target must exclude its irreps
print('K16 restriction V|L6=0 needs target absent L6 representation (explicit at VI-C:3348-3378).')
# contradiction at K16 when chi continuity and positive (source VI-C:556-564)
chi, FF, R2=s.symbols('chi F R2',positive=True)
ratio_chi=s.simplify(chi/chi)
mAlg=(FF-R2*chi)/(3*chi)
ratio_mass=s.cancel(mAlg/mAlg)
print(f'Active C² K16 branch ratios chi+/chi-={ratio_chi}, m_alg,+²/m_alg,-²={ratio_mass} (if mass nonzero).')
