"""Independent analytical third-derivative (xi²/running) of optional smooth comparator.
Uses B01 independent direct quadrature for the smooth F,A moment values only.
"""
from math import log, pi, sqrt, exp
from scipy.optimize import brentq
from scipy.integrate import quad
import importlib.util
spec=importlib.util.spec_from_file_location('prior','/mnt/data/Paper6C-Batch01-ExactChecks-v1_1.py')
prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
from math import log
T=prior.T; gamma=prior.gamma
uend=brentq(lambda u:prior.cov(u)['eps']-1.,.915,.925,xtol=1e-14)
umax=brentq(lambda u:prior.cov(u)['B'],.94,.945,xtol=1e-14)
ustar=brentq(lambda u:prior.n_efolds(uend,u)-56,.93,umax-1e-8,xtol=1e-13)
x=exp(T*(ustar-1));fpp=gamma*prior.psi(ustar)
logg_uder=(7/(1+7*ustar))+(1/(ustar*(1+7*ustar)))-(7*log(ustar)/(1+7*ustar)**2)
gp=fpp*logg_uder/(T*x)
v=prior.cov(ustar);F=v['F'];A=v['A'];B=v['B'];C=F-x*fpp
# Derive eta_x independently by differentiation of closed formula in F,A,g
M=2*F*C/(3*fpp*A)
Mx=2/3*((fpp*C-F*x*gp)/(fpp*A) - (F*C)/(fpp*A)*(gp/fpp+x*fpp/A))
Qx=4/3*(C/A-(B/A)*x*fpp/A)
etax=Mx-Qx
xisq=(2/3)*(B/A)*(F/fpp)*etax+(2/3)*(B/A)**2*v['eta']
run=16*v['eps']*v['eta']-24*v['eps']**2-2*xisq
print('ustar',ustar,'xi_squared',xisq,'alpha_running',run,'n_t',-2*v['eps'])
assert abs(xisq-2.7252812e-4)<8e-11
assert abs(run-(-5.9769199e-4))<8e-11
