import sympy as s
x,y,z=s.symbols('x y z'); r2=x*x+y*y+z*z
rt5=s.sqrt(5); ph=(1+rt5)/2
U=[(1,1,1),(1,1,-1),(1,-1,1),(1,-1,-1),
(1/ph,-ph,0),(ph,0,-1/ph),(0,1/ph,-ph),
(0,1/ph,ph),(ph,0,1/ph),(1/ph,ph,0)]
V=s.Matrix([x,y,z]); M={2*j:s.expand(sum(((s.Matrix(a).dot(V))/s.sqrt(3))**(2*j) for a in U)) for j in range(1,6)}
h6=s.expand(M[6]-s.Rational(10,7)*r2**3)
h10=s.expand(M[10]-s.Rational(10,11)*r2**5-s.Rational(42,17)*r2**2*h6)
def simp(z): return s.simplify(s.radsimp(z))
checks={'M2':M[2]-s.Rational(10,3)*r2,
'M4':M[4]-2*r2**2,
'M8':M[8]-s.Rational(10,9)*r2**4-s.Rational(28,15)*r2*h6,
'LaplaceH6':sum(s.diff(h6,v,2) for v in (x,y,z)),
'LaplaceH10':sum(s.diff(h10,v,2) for v in (x,y,z))}
for k,p in checks.items():
 p=s.Poly(s.expand(p),x,y,z)
 nonzeros={str(m):simp(c) for m,c in p.terms() if simp(c)!=0}
 print(k,'PASSED' if not nonzeros else f'FAIL:{nonzeros}')
 assert not nonzeros,k
u=s.Matrix(U[0])/s.sqrt(3)
print('H6(u12)',simp(h6.subs(dict(zip((x,y,z),u)))))
print('H10(u12)',simp(h10.subs(dict(zip((x,y,z),u)))))
J=s.Matrix([list(V),[s.diff(h6, a) for a in (x,y,z)],[s.diff(h10, a) for a in (x,y,z)]])
Hv=simp(J.det().subs({x:1,y:2,z:3}))
print('H15(1,2,3)=',Hv,'numerical=',Hv.evalf(20))
assert Hv!=0
import itertools
for l in (0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15):
 def chi(theta):return s.sin((s.Rational(2*l+1,2))*theta)/s.sin(theta/2)
 m=s.simplify((2*l+1+15*chi(s.pi)+20*chi(2*s.pi/3)+12*chi(2*s.pi/5)+12*chi(4*s.pi/5))/60)
 print(l,m, 'EXPECTED' if (l in (0,6,10,12,15) and m==1) or (l not in (0,6,10,12,15) and m==0) else 'MISMATCH')
