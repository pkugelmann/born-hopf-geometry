"""Independent finite controls for Paper VI-C v1.43, lines 80-1374.
Uses direct quadrature over t=x*v (not source's u-parameterization).
"""
import scipy.integrate as si
import scipy.optimize as so
import sympy as sp
from math import exp, log, pi, sqrt
L=4*pi*pi+1/(6*sqrt(2)); T=7*L; c=exp(-T); gamma=16*exp(L/2)
def w(u):
    if u<=0: return 1/8
    S=log(1+7*u) - 7*u/(1+7*u)*log(u)
    return exp(S)/8
def psi(u): return max(0.,u)*w(u) if u>0 else 0.
def cov(u):
    x=exp(T*(u-1))
    def pf(v):
        return psi(u+log(v)/T) if v>0 else 0
    a=si.quad(pf,0,1,epsabs=2.e-13,epsrel=1e-12,limit=150)[0]
    b=si.quad(lambda v:v*pf(v),0,1,epsabs=2.e-13,epsrel=1e-12,limit=150)[0]
    I1=x*a; It=x*x*b
    F=1+gamma*I1; A=c+gamma*It
    fhat=x-c+gamma*(x*I1-It)
    B=2*fhat-x*F
    fpp=gamma*psi(u)
    eps=(B/A)**2/3
    eta=2*F*(F-x*fpp)/(3*fpp*A)-4*B/(3*A)
    As=A/(12*pi*pi*F*F*eps)
    return dict(u=u,x=x,F=F,A=A,B=B,eps=eps,eta=eta,ns=1-6*eps+2*eta,r=16*eps,As=As)

def n_efolds(u_end,u_star):
    return si.quad(lambda u:1.5*cov(u)['A']*gamma*psi(u)/(cov(u)['F']*cov(u)['B'])*T*cov(u)['x'],u_end,u_star,epsabs=1e-9,epsrel=1e-9,limit=100)[0]
if __name__=='__main__':
    uend=so.brentq(lambda u:cov(u)['eps']-1,0.915,0.925,xtol=1e-14)
    umax=so.brentq(lambda u:cov(u)['B'],0.94,0.945,xtol=1e-14)
    ustar=so.brentq(lambda u:n_efolds(uend,u)-56,0.93,umax-1e-8,xtol=1e-13)
    import json
    print(json.dumps({'L':L,'T':T,'gamma':gamma,'cstar':c,'u_end':uend,'u_max':umax,'u_star':ustar,'end':cov(uend),'star':cov(ustar),'N':n_efolds(uend,ustar)},indent=2))
    y=sp.symbols('y'); P=1+2*y+y*y+y**3; Q=1+y+2*y*y+y**3; f=y*P/Q
    assert sp.simplify(f*f.subs(y,1/y))==1
    assert sp.factor(sp.diff(f,y))==(y**6+4*y**5+3*y**4+4*y**3+3*y**2+4*y+1)/Q**2
    assert sp.series(f,y,0,7).removeO()==y+y**2-2*y**3+3*y**5-y**6
    print('Exact G26 reciprocal family, derivative, series verified.')
