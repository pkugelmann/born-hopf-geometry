"""Independent E3/E4 checks of Paper6C lines 5296-6887, 2026-11-13.
This is verification only; not a modification/repair of the framework.
"""
import math
import numpy as np
import sympy as sp
from scipy.optimize import brentq

# 01. Static action leaf and kinetic susceptibility by a different symbolic route.
s,m,q=sp.symbols('s m q',real=True,positive=True)
H=sp.exp(s)*sp.sqrt(m**2+q*sp.exp(2*s))
b=q/(m**2+q)
E=sp.sqrt(m**2+q)
assert sp.simplify(sp.diff(H,s).subs(s,0)-E*(1+b))==0
assert sp.simplify(sp.diff(H,s,2).subs(s,0)-E*(1+4*b-b*b))==0
print('HESSIAN symbolic:',sp.simplify(sp.diff(H,s,2).subs(s,0)))
for beta in [0,.1,.5,1]:
 ratio=(1+4*beta-beta*beta)/(2*(1+beta))
 assert .5-1e-12<=ratio<=1+1e-12
print('SUSCEPTIBILITY bounds [1/2,1] pass; endpoints are sharp')

# 02. Independent stationary TT rational denominator from spectral sum.
def Dspec(qm,eta,x):
 e1,e2=math.sqrt(qm+25/4),math.sqrt(qm+49/4)
 w=1;t1,t2=2.5,3.5
 chi=(qm+t1*t2)/(e1*e2)
 alpha=qm/e1**2;bd=(1-chi)/2;cs=(1+chi)/2
 eta_to_delta=eta*e1  # M^2=a=V=hbar=1
 omegaA,omegad,omegas=2*e1,e2-e1,e2+e1
 Ktilde=4*eta_to_delta*(alpha*omegaA/(omegaA**2-x)-bd*omegad/(omegad**2-x)+cs*omegas/(omegas**2-x))
 return 8+25*eta-x+4*Ktilde

def Drat(qm,eta,x):
 B=x*x-(4*qm+37)*x+36
 return 8+25*eta-x+16*eta*(2*qm/(4*qm+25-x)+(15-(2*qm+15)*x)/B)
for qm in [0,1e-3,.1,1,100]:
 for eta in [0.001,1/(2*(3*qm+25))]:
  for x in [-2,0,.5,8,16,24,200]:
   if (4*qm+25-x)==0 or abs(x*x-(4*qm+37)*x+36)<1e-8:continue
   u,v=Dspec(qm,eta,x),Drat(qm,eta,x)
   assert math.isclose(u,v,rel_tol=1e-9,abs_tol=1e-9),(qm,eta,x,u,v)
print('STATIONARY TT spectral-to-rational transformation passes across m>=0, permitted eta')

for qm in [1e-3,.1,1,10,100]:
 e1,e2=math.sqrt(qm+25/4),math.sqrt(qm+49/4)
 ud,us=(e2-e1)**2,(e2+e1)**2
 A=4*qm+25
 for frac in [.05,.45,.95,1.0]:
  eta=frac/(2*(3*qm+25))
  def D(x):return Drat(qm,eta,x)
  roots=[]
  for l,r in [(0,ud),(ud,16),(16,A),(A,us)]:
   small=(r-l)*1e-8
   left,right=l+small,r-small
   assert D(left)*D(right)<0,(qm,eta,l,r,D(left),D(right))
   root=brentq(D,left,right,xtol=1e-13)
   roots.append(root)
  assert 0<roots[0]<ud<roots[1]<16<roots[2]<A<roots[3]<us
  print('TT poles',qm,frac,':',*[round(x,7) for x in roots])
for eta in [.001,.01,.02]:
 roots=np.roots([1,-(44+25*eta),288+1140*eta])
 assert len(roots)==2 and all(float(r)>0 and abs(r.imag)<1e-9 for r in roots)
print('TT MASSLESS quadratic positive/simple over test grid')

# 03. Seven-dimensional real memory equations from direct Pauli matrices.
I=np.eye(2,dtype=complex)
sig=[np.array([[0,1],[1,0]],complex),np.array([[0,-1j],[1j,0]],complex),np.diag([1,-1]).astype(complex)]
def dot(v):return sum((v[i]*sig[i] for i in range(3)),np.zeros((2,2),complex))
def extract(X):return np.array([np.trace(sig[i]@X).real/2 for i in range(3)])
r=np.array([.4,.6,math.sqrt(.48)])
xvec=np.array([.1,-.15,(-.04+.09)/r[2]])  # r*x=0
xvec[2]=-(xvec[:2]@r[:2])/r[2]
bvec=np.array([.24,-.32,.41]);b0=.17
m0,tau1,tau2,w,h,delta=1.3,2.1,3.2,0.8,.3,.65
HA=m0*sig[0]+tau1*sig[2];HB=m0*sig[0]-tau1*sig[2];HC=m0*sig[0]+tau2*sig[2]
rB=np.array([r[0],-r[1],-r[2]])
CA=.8*I+delta/2*dot(r);CB=.8*I+delta/2*dot(rB)
XA=dot(xvec);XBC=1j*b0*I+dot(bvec)
MA=-1j*(HA@XA-XA@HA)-1j*w*h*(sig[2]@CA-CA@sig[2]);MB=-1j*(HB@XBC-XBC@HC)+1j*w*h*CB@sig[2]
xdot=2*np.cross(np.array([m0,0,tau1]),xvec)+delta*w*h*np.cross(np.array([0,0,1]),r)
b0dot=(tau1+tau2)*bvec[2]+delta*w*h*rB[2]/2
bdot=2*m0*np.cross([1,0,0],bvec)-(tau1-tau2)*np.cross([0,0,1],bvec)-(tau1+tau2)*b0*np.array([0,0,1])-delta*w*h*np.cross(rB,[0,0,1])/2
np.testing.assert_allclose(extract(MA),xdot,atol=1e-12)
np.testing.assert_allclose(np.trace(MB).imag/2,b0dot,atol=1e-12)
np.testing.assert_allclose(extract(MB),bdot,atol=1e-12)
np.testing.assert_allclose(np.dot(xdot,r)+np.dot(xvec,2*np.cross([m0,0,tau1],r)),0,atol=1e-12)
print('SEVEN-COORDINATE real memory reduction, quaternion-null force, tangency PASS')

# 04. B1 geometric-mean and source readout; check normalization of R56.
U=5.0; alpha=137.0
C=U*alpha**-7;R56=math.sqrt(U)*alpha**(-7/2)
a0=1.0*math.sqrt(C)/(4*math.pi)
a0_printed=math.sqrt((R56**2)/U)/(4*math.pi)
assert math.isclose(C,R56**2,rel_tol=1e-12)
assert not math.isclose(a0,a0_printed,rel_tol=1e-6)
assert math.isclose(a0/a0_printed,math.sqrt(U),rel_tol=1e-12)
rb=1e-9; rresp=math.sqrt(C*rb)
assert math.isclose((math.sqrt(rresp)/(4*math.pi))**2,a0*(math.sqrt(rb)/(4*math.pi)))
print('R56 owner issue: a0 correct / alternative printed = sqrt(U) =',math.sqrt(U))

# 05. Green coercivity does not imply positivity for arbitrary nonlocal quadratic boundary.
# Local Dirichlet Green is positive. Coercive PSD boundary penalty beta(u0+u1)^2 need not be.
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import spsolve
n=151;dx=1/(n-1);base=lil_matrix((n,n));rhs=np.zeros(n)
for j in range(n-1):
 local=np.array([[1,-1],[-1,1]])/dx+dx/6*np.array([[2,1],[1,2]])
 for u in [0,1]:
  for v in [0,1]:base[j+u,j+v]+=local[u,v]
rhs[:15]=dx
A=base.copy(); beta=4.0
for i,j in [(0,0),(0,n-1),(n-1,0),(n-1,n-1)]:A[i,j]+=beta
solution=spsolve(A.tocsr(),rhs)
assert min(solution)<0 and max(solution)>0
q=np.zeros(n);q[0]=1;q[-1]=1
assert beta*(q[0]+q[-1])**2>=0
print('GREEN E4 nonlocal PSD boundary: nonnegative quadratic boundary but source>=0 yields min solution=',min(solution))
# Positive local boundary countercontrol, beta u(0)^2+u(1)^2
Aloc=base.copy();Aloc[0,0]+=beta;Aloc[n-1,n-1]+=beta
spos=spsolve(Aloc.tocsr(),rhs)
assert min(spos)>0
print('GREEN positive local Robin countercontrol min=',min(spos))
# Exact continuum boundary Schur-complement control: solve -u''+u=0 on (0,1)
# with q_boundary=beta*(u(0)+u(1))^2 and positive endpoint load v(0).
# Dirichlet-to-Neumann matrix is [[coth1,-csch1],[-csch1,coth1]].
T=1/math.tanh(1); S=1/math.sinh(1)
kdiag=T+beta;koff=beta-S
continuous_u1=-koff/(kdiag*kdiag-koff*koff)
assert continuous_u1<0 and kdiag>abs(koff)
print('GREEN E4 exact continuum PSD boundary, positive boundary source -> opposite endpoint',continuous_u1)


# 06. Non-zero curl of inhomogeneous a* times local Reeb factor.
# For Phi_b=(x^2+y^2)/2, a*(x)=1+eps*x, the z curl of nu(r/a*)*(x,y) is
# -nu'(r/a*) * r * eps /(a*(x)**2) * y.
X,Y,eps=1.0,1.0,.1
r=math.hypot(X,Y); a=1+eps*X; yy=r/a
nuprime=-math.exp(-math.sqrt(yy))/(2*math.sqrt(yy)*(1-math.exp(-math.sqrt(yy)))**2)
curl=-nuprime*Y*r*eps/(a*a)
assert curl>1e-4
print('MERGER vector lift: curl(nu grad Phi_b) at (1,1) =',curl,'NOT a gradient field')

# 07. Large separation is not sufficient for bimodality with arbitrary positive weights.
D=10.0;weight=1e-30
critical=(D+math.sqrt(D**2-4))/2
Gmin=critical/(D-critical)*math.exp(D**2/2-D*critical)
assert weight<Gmin
# derivative can have only a single zero on (0,D): the stationary ratio G(x)
# has extrema at the two roots x(D-x)=1 and its local minimum is Gmin.
root_estimate=weight*D*math.exp(-D**2/2)
assert 0<root_estimate<1e-40
print('MERGER E4: Gaussian width=1, separation=10, weights 1 and 1e-30 -> ONE peak; Gmin=',Gmin)
# Equal weights by symmetry produce 2 maxima at similar D
assert 1.0>Gmin
print('MERGER positive control: comparable Gaussian sources separated by 10 widths have 2 maxima')

# 08. Right 2I rank from Molien without using the paper's character average.
def mult_2I(n):
 return sum(1 for k in [0,1] for a in range(n//12+1) for b in range(n//20+1) if 30*k+12*a+20*b==n)
def frac(L):return .5*(mult_2I(L-2)/(L-1)+mult_2I(L+2)/(L+3))
assert frac(2)==.5 and abs(frac(10)-1/26)<1e-14 and abs(frac(14)-1/26)<1e-14
print('2I TT projector fractions f2=1/2, f10=f14=1/26 PASS')

# 09. Final octet semigroup counterchecks.
for tau in [math.log(7)+.01,math.log(7)+1]:assert math.exp(-tau)-1/7<0
print('K48 instantaneous-export no-go PASS')

# 10. Local cluster density conversion from a56.
G=6.67430e-11;c=299792458.;a56=1.146e-10
C56=(4*math.pi*a56/c**2)**2
rho=c**2*C56/(8*math.pi*G)
assert 1.35e-26<rho<1.45e-26
print('CLUSTER terminal density scale =',rho,'kg m^-3')
print('ALL BATCH04 INDEPENDENT TESTS PASSED')
