"""Independent q-variable quadrature of paper6C 1378--1574, using IIID Laurent secant.
No source-dependent N7 replay script is imported; physical q is NOT K_sh.
"""
import math
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq
L = 4*math.pi**2+1/(6*math.sqrt(2)); alpha=math.exp(L); Q=8*math.sqrt(alpha); c7=math.exp(-7*L)
def logcosh(z): return abs(z)+math.log1p(math.exp(-2*abs(z)))-math.log(2)
def nplus(j,q):
    if q>=j: return 0.0
    if q<1.e-14: return (1-math.exp(-j*L))/(1+math.exp(-j*L))
    return max(0., (logcosh(j*L/2)-logcosh((j/2-q)*L))/(q*L))
def x(q): return math.exp(-L*q)
def g(q):
    a=math.exp(math.log(Q)*nplus(2,q))
    return a*(1+nplus(7,q))*(-math.expm1(-2*(7-q)*L))/(1+c7)
def moment(q,power):
    fun=lambda s:L*x(s)**power*g(s)
    cuts=[q]+[v for v in [1.,2.,3.,7.] if v>q]
    return sum(quad(fun,a,b,epsabs=4e-14,epsrel=5e-12,limit=300)[0] for a,b in zip(cuts[:-1],cuts[1:]))
def vals(q):
    xx=x(q); gg=g(q)
    F=1.+moment(q,1)
    A=c7+moment(q,2)
    B=xx*F-2*A
    eps=(B/A)**2/3
    eta=2*F*(F-xx*gg)/(3*gg*A)-4*B/(3*A)
    ns=1-6*eps+2*eta; r=16*eps
    As=2*A/F**2/(24*math.pi**2*eps)
    return dict(q=q,x=xx,F=F,A=A,B=B,eps=eps,eta=eta,ns=ns,r=r,As=As)
qe=brentq(lambda q:vals(q)['eps']-1.,.50,.68,xtol=1e-14)
def efolds(q):
    # e-fold integral transformed from x to q, with independent quadratures for F,A
    fun=lambda z:1.5*L*x(z)*vals(z)['A']*g(z)/(vals(z)['F']*vals(z)['B'])
    return quad(fun,q,qe,epsabs=1e-11,epsrel=2e-11,limit=150)[0]
qs=brentq(lambda q:efolds(q)-56,.42,.49,xtol=1e-14)
qcyc=-math.log(4*math.pi**2/Q)/L
Theta2=math.exp(-math.log(Q)/L*math.log(2/(1+math.exp(-2*L))))
print('alpha',format(alpha,'.15g'),'Q',Q)
for label,q in [('end',qe),('pivot-56',qs),('K8',.5),('native-cyclic',qcyc)]:
 print(label,'q',format(q,'.13f'),'KR',format(16*q,'.12f'),'N-to-end',format(efolds(q),'.12f'))
 if label in ('pivot-56','native-cyclic'):
  v=vals(q)
  print('  ns',format(v['ns'],'.12f'),'r',format(v['r'],'.12f'),'As',format(v['As'],'.13g'))
print('N pivot -> K8',format(efolds(qs)-efolds(.5),'.12f'))
print('N native-cyclic -> K8',format(efolds(qcyc)-efolds(.5),'.12f'))
print('theta2',format(Theta2,'.15f'),'amp times Theta2',format(vals(qs)['As']*Theta2,'.13g'))
