#!/usr/bin/env python3
"""Scoped source-release checks (not a global physical verification) for Born--Hopf v3.016."""
from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import json, math, random, re
import mpmath as mp
R=Path('/mnt/data')
P=R/'Paper00-PapersMinimal-v3_016.zip'
A=R/'Paper00-ProofChainAudits-v1_64.zip'
D=R/'Paper00-DAGAtlas-v1_149.zip'
checks=[]
def ok(name, truth, evidence=None):
    truth=bool(truth)
    checks.append({'name':name,'passed':truth,'evidence':evidence})
    if not truth: raise AssertionError(name)
    return truth
mp.mp.dps=65
with ZipFile(P) as z:
    src=z.read('Paper6A-GravityCosmology-v2_262.tex').decode()
    names=z.namelist()
    tex=[x for x in names if re.fullmatch(r'Paper\d+[A-G]-.*\.tex',x)]
    pdf=[x for x in names if re.fullmatch(r'Paper\d+[A-G]-.*\.pdf',x)]
    ok('31 matched-paper-pairs',len(tex)==len(pdf)==31 and all(t[:-4]+'.pdf' in pdf for t in tex))
    ok('only-current-VIA-pair','Paper6A-GravityCosmology-v2_261.tex' not in names and 'Paper6A-GravityCosmology-v2_262.pdf' in names)
    ok('preserved-newer-PaperIB', 'Paper1B-ExceptionalGeometry-v1_9.tex' in names)
    ok('valid-new-PDF', z.read('Paper6A-GravityCosmology-v2_262.pdf')[:4]==b'%PDF')
    ok('SI-adiabaticity-corrected', all(x in src for x in [r'\epsilon_m:=\frac{|\dot m_s|}{c\,m_s^2}',r'\epsilon_H:=|H|/(c\,m_s)',r'\epsilon_m:=|\dot m_s|/(c\,m_s^2)']))
    ok('new-proposition-formula',r'\label{p8:prop:v2262-uniform-shell-yukawa-reference}' in src and r'A(x)=\frac{3e^{-x}K_x(1)}{x^3}' in src)
    ok('open-owner-language', 'Neither formula identifies the action-owned physical source profile' in src)
    ok('all-source-labels-unique',len(re.findall(r'\\label\s*\{([^}]+)\}',src))==len(set(re.findall(r'\\label\s*\{([^}]+)\}',src))))
    ok('zip-integrity-papers',z.testzip() is None)
with ZipFile(A) as z:
    names=z.namelist()
    ok('32-latest-audit-entries',len(names)==32)
    ok('paperIB-audit-preserved',sum('Paper1B-ExceptionalGeometryProofChainAudit-v1_2.md' in n for n in names)==1)
    ok('paperVIA-current-audit',sum('Paper6A-ProofChainAudit-v1_15.md' in n for n in names)==1)
    ok('no-stale-VIA-audit',all('Paper6A-ProofChainAudit-v1_14.md' not in n for n in names))
    ok('zip-integrity-audits',z.testzip() is None)

def K(x,y): return x*y*mp.cosh(x*y)-mp.sinh(x*y)
def q_closed(x,d):
    if x==0: return 1-(1-d)**3
    return 1-K(x,1-d)/K(x,1)
def A_closed(x):
    if x==0:return mp.mpf(1)
    return 3*mp.exp(-x)*K(x,1)/x**3
rng=random.Random(262)
for i in range(240):
    x=mp.mpf(10)**mp.mpf(rng.uniform(-3,1.4)); d=mp.mpf(rng.uniform(0.001,.999))
    num=mp.quad(lambda y: y*mp.sinh(x*y)/x,[1-d,1]);den=mp.quad(lambda y: y*mp.sinh(x*y)/x,[0,1]); q=num/den
    ok('finite-m-shell-%03d'%i,abs(q-q_closed(x,d)) < mp.mpf('1e-47'))
    if i<35:
        rs=3*mp.exp(-x)*num
        ok('point-reference-%03d'%i,abs(rs-A_closed(x)*q_closed(x,d))<mp.mpf('1e-47'))
for d in (mp.mpf('0'),mp.mpf('.02'),mp.mpf('.5'),mp.mpf('1')):
    ok('massless-limit-d-'+str(d),abs(q_closed(mp.mpf('1e-15'),d)-q_closed(0,d))<mp.mpf('1e-26'))
ok('reference-at-x=1',abs(A_closed(1)-3*mp.exp(-2))<mp.mpf('1e-55'))
for i in range(80):
    # F_R=chi; M=(F-R chi)/(3 chi); M'= -F chi_R/(3chi^2)
    chi=10**rng.uniform(-5,2);F=10**rng.uniform(-3,4);R=rng.random()*F/chi*0.85
    chip=rng.uniform(-2,2)*chi;Rdot=rng.uniform(-1e5,1e5)
    c=299792458.0
    M=(F-R*chi)/(3*chi)
    Mprime=-F*chip/(3*chi**2)
    eps1=abs(Mprime*Rdot)/(2*c*M**1.5)
    eps2=(3**0.5)*F*abs(chip*Rdot)/(2*c*chi**0.5*(F-R*chi)**1.5)
    ok('SI-WKB-%02d'%i,math.isclose(eps1,eps2,rel_tol=2e-12,abs_tol=1e-15))
if D.exists():
    with ZipFile(D) as z:
        prefix='Paper00-DAGAtlas-v1_149/'
        graph=z.read(prefix+'DAG/Paper00-TheoremDAG.json')
        act=json.loads(z.read(prefix+'DAG/ActiveRelease-v1_149.json'))
        closures=json.loads(z.read(prefix+'DAG/CurrentScopedClosures-v1_149.json'))
        amap=json.loads(z.read(prefix+'DAG/CurrentSourceAnchorMap-v3_016.json'))
        manifest=json.loads(z.read(prefix+'DAG/ArtifactManifest-v1_149.json'))
        ok('paper1b-graph-preserved',sha256(graph).hexdigest()==act['canonical_graph_sha256'])
        ok('source-paired-sha',act['source_archive_sha256']==sha256(P.read_bytes()).hexdigest())
        ok('audits-paired-raw-sha',act['audits_archive_sha256']==sha256(A.read_bytes()).hexdigest())
        ok('nine-scoped-closures',len(closures['effective_current_dispositions'])==9)
        ok('VIA-current-source-anchors',amap['claims']['p8:prop:v2262-uniform-shell-yukawa-reference']['source_file']=='Paper6A-GravityCosmology-v2_262.tex')
        ok('new-current-audit',act['current_audit_reports']=='AuditsCurrent-v1_64/')
        ok('physical-guard-flags',not act['physical_REG0_incidence_verified'] and not act['full_framework_verified'] and act['new_physical_status_promotions']==0)
        table={p['path']:p['sha256'] for p in manifest['files']}
        ok('manifest-census',len(table)==manifest['file_count_excluding_self']==len(z.namelist())-1)
        for name in z.namelist():
            short=name[len(prefix):]
            if short=='DAG/ArtifactManifest-v1_149.json': continue
            if short not in table: raise AssertionError('Missing manifest entry: '+short)
            if sha256(z.read(name)).hexdigest()!=table[short]:raise AssertionError('Incorrect manifest hash: '+short)
        ok('DAG-manifest-all-file-hashes',True)
        ok('zip-integrity-DAG',z.testzip() is None)
OUTPUT=Path('/mnt/data')/'Paper00-WholeFrameworkIntegrationEvidence-v1_1.json'
OUTPUT.write_text(json.dumps({'release':'Paper00-PapersMinimal-v3_016','checks_passed':len(checks),'failed':0,'checks':checks},indent=2,default=str)+'\n')
print('PASS:',len(checks),'scoped source, math and archive checks')
