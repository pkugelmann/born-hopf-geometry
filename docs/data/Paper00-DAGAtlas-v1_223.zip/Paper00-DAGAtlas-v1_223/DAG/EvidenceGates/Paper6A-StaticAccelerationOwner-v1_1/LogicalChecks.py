#!/usr/bin/env python3
"""Exact algebraic logical nonimplication witness for BH-VIA-G-0014 (not a closure)."""
import sympy as s
from pathlib import Path
import zipfile,hashlib,json
P=Path('/mnt/data');z=zipfile.ZipFile(P/'Paper00-PapersMinimal-v3_014(1).zip')
src1=z.read('Paper6A-GravityCosmology-v2_261.tex');src2=z.read('Paper6C-TechnicalMaterial-v1_51.tex')
R=s.symbols('R',positive=True);c=s.symbols('c',positive=True); b,d=s.symbols('b d',real=True)
# Mathematical countermodel uses d>=0; ensure positivity with Sylvester criteria
H=s.Matrix([[s.sqrt(R)+d+b*b/c,b],[b,c]])
K=s.simplify(H[0,0]-H[0,1]*H[1,0]/H[1,1]);det=s.simplify(H.det())
assert s.simplify(K-(s.sqrt(R)+d))==0
assert s.simplify(det-c*(s.sqrt(R)+d))==0
assert s.simplify(K.subs(d,0)-s.sqrt(R))==0
assert s.simplify(K.subs(d,s.sqrt(R))-2*s.sqrt(R))==0
# Dirichlet-to-Neumann on half-line: for mode eigenvalue λ_H≥0,
# u(s)=f exp(-sqrt(R+λ_H)*s), negative outward derivative at s=0
lam,ss=s.symbols('lam ss',nonnegative=True);f=s.symbols('f')
u=f*s.exp(-s.sqrt(R+lam)*ss)
assert s.simplify(-s.diff(u,ss).subs(ss,0)/f-s.sqrt(R+lam))==0
assert s.simplify((-s.diff(u,ss,2)+(R+lam)*u))==0
assert 'separately stated premise (TR1)' in src1.decode()
assert 'retired as an' in src1.decode()
assert 'a restriction of the parent metric-action' in src2.decode()
result={'issue_id':'BH-VIA-G-0014','status':'OPEN_NOT_DISCHARGED','source_via_sha':hashlib.sha256(src1).hexdigest(),'source_vic_sha':hashlib.sha256(src2).hexdigest(),
 'exact_countermodel':'Schur([sqrt(R)+d+b^2/c, b; b, c])=sqrt(R)+d, d>=0','d0_matches':True,'d_sqrtR_does_not_match':True,'source_guard_retained':True,
 'checks':['Schur identity','positive-definite determinant for d>=0','matching case','nonmatching case','DtN half-line ODE','DtN conormal','VI-A TR1 conditional source','VI-A later retirement source','VI-C same-action no kernel insertion'],
 'claim':'No automatic physical operator equality follows from abstract positive Schur reduction and type ownership. Actual S_star could separately prove equality; not checked here.'}
(P/'Paper6A-StaticAccelerationOwnerGateEvidence-v1_1.json').write_text(json.dumps(result,indent=2)+'\n')
print('G0014: 9 exact/source logical checks passed; open physical-owner gate retained')
