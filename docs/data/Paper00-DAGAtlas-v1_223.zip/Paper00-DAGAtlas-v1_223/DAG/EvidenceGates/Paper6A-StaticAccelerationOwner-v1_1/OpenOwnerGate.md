# Paper VI-A — `BH-VIA-G-0014`: same-action static-acceleration owner gate (not closed)

**Gate file:** `Paper6A-StaticAccelerationOwnerGate-v1_1.md`  
**Current source:** `Paper6A-GravityCosmology-v2_261.tex` (SHA256 `b15dea7e84ed67596c77a658ca36e6cbb483b5318828bbd2c47f9594628cac1d`) and `Paper6C-TechnicalMaterial-v1_51.tex` from `Paper00-PapersMinimal-v3_014(1).zip`.  
**Issue:** `BH-VIA-G-0014`, currently **OPEN / UNDISCHARGED PHYSICAL OWNER BRIDGE**.  
**This is a diagnostic and proposed discharge equation, not a closure certificate.**

## 1. Source-proved propositions that must remain distinct

- VI-A 11463–11518: on the *separately declared comparison* `Gamma_R[u]=1/2 ∫[(∂_s u)^2+|∇_H u|^2+R u^2]`, the exact positive zero-mode DtN eigenvalue is `N_R(1)=sqrt(R)`.
- VI-A 11520–11585: converting the scalar DtN into `a(R)=c² sqrt(R)/(4pi)` identifies its coefficient with the physical total acceleration trace under `(TR1)`; VI-A 11584–11585 explicitly retains this premise.
- VI-A 12349–12373: a later source section says that `(TR1)` has been retired as a *law-level assumption*, using the static lapse acceleration identity `a_i=c² ∇_i log N`. This is mathematically correct **if** the comparison `Gamma_R` is the actual same-action lapse operator, but it cannot establish that identification by itself.
- VI-A 12511–12638: a connected regular occurring stationary branch does have the exact source-conditioned boundary Schur operator `K_48 = beta_48^* Schur_I(D_q² S_star) beta_48` under the branch and quotient assumptions. Its proof does not calculate the full parent zero-mode Hessian or prove its equality with `Gamma_R`.
- VI-C 7477–7590, theorem `p8:thm:v166-boundary-module-owner-criterion`: the physical owner map and representation parity are not equivalent to a value for the scalar Hessian stiffness. Its C2 Hom-space no-go and the later PCAD normalized `beta_48` give *type ownership* and a pullback, not the numerical equality of two distinct quadratic forms.

## 2. Exact target that would discharge the issue

Let `e_0` be the physically generated normalized scalar zero mode in the actual stationary boundary space after the constraint/gauge quotient. Let `beta_0` be its **actual** terminal owner pullback including the conormal/physical-normal Jacobian. At a fixed occurring stationary solution `q_*` define

\[
K_{\rm phys}^{(0)}(R;Y,\mathcal E)
=\langle e_0,\beta_0^*\big(H_{\partial\partial}
-H_{\partial I}H_{II}^{-1}H_{I\partial}\big)\beta_0 e_0\rangle,
\quad H=D_q^2S_\star|_{q_*}.
\]

The physical identification used to predict the absolute terminal acceleration requires **a source-proved identity on the relevant physical branch**:

\[
\boxed{K_{\rm phys}^{(0)}(R;Y,\mathcal E)=\sqrt R}
\]

in the exactly matched proper-distance/conormal normalization, together with the actual lapse variation and the physical unit-total boundary datum. The source also must show this matches the physical acceleration `a_n=c²∂_n log N` (and, for observational RAR predictions, the correct local solid-angle pushforward). A proof could instead compute the full physical acceleration observable directly without identifying it with the comparison collar, but then it would need to recover the same numerical `a_0` from that independently owned computation.

## 3. Adversarial independence witness: generic Schur descent is insufficient

Even with a fixed `R>0`, a positive two-block quadratic action and fixed pullback `beta_0=1` do not select the comparison coefficient. Choose `c>0`, `b∈R`, `δ> -sqrt(R)` and set

\[
S_δ(u,v)=\tfrac12\big[(\sqrt R+δ+b^2/c)u^2+2buv+cv^2\big].
\]

The complete Hessian is positive definite and has invertible interior block. Its unique same-action Schur descent is

\[
K_δ=(\sqrt R+δ+b^2/c)-b^2/c=\sqrt R+δ.
\]

For `δ=0`, `K_δ=sqrt R` and the comparison matches. For `δ=sqrt R`, all the same *generic* Schur, stationarity, invertibility, and type conditions remain valid, yet `K_δ=2sqrt R`. This is an **abstract logical counterexample to inferring stiffness equality from a generic Schur theorem**, not a physical alternative action proposed for Born–Hopf Geometry and not a refutation of its actual (currently unevaluated) `S_star`.

Hence ``the physical response comes from the same action'' is not alone a proof of its coefficient. The owner map's existence and the Hessian's value are mathematically distinct tasks.

## 4. Closure path without changing the theory

1. Locate the **existing** actual physical `S_star` and stationary boundary/interior Hessian for the native `S` modality; do not substitute the local `L` metric trace propagator or a second action.
2. Evaluate the scalar `e_0` boundary response after Schur-reducing *before* the terminal quotient, preserving the actual interior memory and `beta_48` conormal normalization.
3. Compare it to `sqrt(R_sel)` at the physical terminal isotropic member; if unequal, derive the true acceleration observable from the same action rather than renormalizing the comparison to fit the desired number.
4. Prove the actual solution realizes the required stationary member and normalized lapse boundary datum. Only then transfer the absolute coefficient to physical galaxy acceleration. The current status remains `G-0014 OPEN`, `BH-VIA-A-0016` undisclosed/discharged **not** certified.

The geometric dark-energy action scale `C_56/2` is a separate result: this issue principally blocks the **physical static acceleration/RAR interpretation** of the hierarchy floor, not its algebraic vacuum intercept.
