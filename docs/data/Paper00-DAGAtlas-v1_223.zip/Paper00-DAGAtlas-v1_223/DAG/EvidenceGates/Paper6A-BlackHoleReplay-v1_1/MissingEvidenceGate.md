# Paper VI-A — black-hole numerical witness replay gate (G-0013 remains OPEN)

**Artifact:** `Paper6A-BlackHoleNumericalReplayGate-v1_1.md`  
**Target:** `BH-VIA-G-0013`, `p8:prop:v2184-native-source-memory-regulator` and directly consumed corollaries/constraint buffer in `Paper6A-GravityCosmology-v2_261.tex`, lines 11864–11951.  
**Appendix:** `Paper6C-TechnicalMaterial-v1_51.tex`, lines 8094–8187, especially 8110–8149 and 8153–8185.  
**Reported, NOT reproduced:** `B_+/r_s=1.003875886570...`, `B_-/r_s=0.533282796858...`, `∫R_kk dλ = −4.940162149375...`, `½∫θ²dλ=4.940162149375...`, marginal-zero derivatives `−0.628776873258...`, `69.629429382407...`, and numerical constraint/buffer margins.  
**Status:** **OPEN_EVIDENCE_MISSING / NUMERICAL_REPLAY_UNVERIFIED**. The main paper's underlying conditional finite normal-form theory and its analytic continuous-dependence statement are not rejected.

## Direct file search

All three supplied current archives were enumerated by ZIP member path, not inferred from filenames alone:

- `Paper00-PapersMinimal-v3_014(1).zip`;
- `Paper00-DAGAtlas-v1_142.zip`;
- `Paper00-ProofChainAudits-v1_57.zip`.

None contains any of the four referenced `Paper00-BlackHoleRegulationChecks-v1_9.py`, `...-v1_10.py`, `...-v1_11.py`, `...-v1_12.py` or the declared `...-v1_12.json`. The source appendix **cites** the programs but does not present the Cauchy packet, conserved central allocation, source strength, Bloch vectors, or polynomial buffer coefficients needed to replay the output.

## Why the printed constants do not determine the claimed trajectory

The appendix specifies a free Dirac block

\[
 d=(P_z,P_\Omega,\mu_D),\quad w=(2P_z,P_\Omega,\mu_D),\quad
 \dot s_\eta={2\eta\over\hbar}d\times s_\eta,\quad
 V_3(\rho_D+p_{z,D})=\sum_\eta w\cdot s_\eta.
\]

At an illustrative admissible positive product-chart point `A=B=r_s`, using the paper's printed dimensionless parameters and `ħ=c_op=r_s=1`, take `d=(0.01,1,1)` and `w=(0.02,1,1)`. Two different **unit** Bloch initial vectors, `s^(1)=(0,1,0)` and `s^(2)=d/||d||`, have positive source energy `d·s`, but different radial enthalpy `w·s`. Equal-population opposite-sign pairs constructed with these different initial vectors therefore provide different initial source ports while sharing the three printed constants. This does **not** assert that either sample solves the complete metric constraints, or that the cited witness fails to exist. It proves only that the three constants do not specify the necessary source-state data for independent replay.

A cancellation of the two **printed rounded** Raychaudhuri integrals is an arithmetic consistency check, not a replay of the integral, signed null source port, lapse constraint, or curvature. The numbers themselves remain **reported, not certified**.

## Exact remaining certification package

Provide the actual original or independently constructed, versioned, runnable **full witness**: the complete first-jet ODE/finite-state source and all units/normalizations; initial `A,B,u,v,Φ,Π,σ` and constraint-compatible gauge/Gauss/lapse data; source-strength and finite memory coefficients; fixed event/turning-surface definitions; integration interval, tolerances and convergence scan; output signed marginal radii, derivatives, positive density, finite width/curvature, null-port sign, Raychaudhuri/lapse residuals, and full sixth-degree inward/outward buffer coefficients with positivity and endpoint checks. Verify each output using independent evaluation, not pasted prints.

If a new independently constructed member demonstrates only existence of a different permitted two-zero trajectory, record it as a **separate witness**, without claiming it reproduced the historical values. The transversality-to-open-basin implication remains a conditional theorem: it becomes an occurrence statement only after a genuine regular, constraint-compatible numerical or analytic base member has been certified.

**No DAG closure of G-0013; no imported black-hole, cosmological, or physical occurrence status promotion.**
