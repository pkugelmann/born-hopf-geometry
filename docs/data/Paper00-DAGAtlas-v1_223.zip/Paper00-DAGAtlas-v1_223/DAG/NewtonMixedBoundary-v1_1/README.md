Scoped Paper III-F mixed Dirac square and scalar boundary heat a3/a4; source v3_030; no physical Newton promotion.
