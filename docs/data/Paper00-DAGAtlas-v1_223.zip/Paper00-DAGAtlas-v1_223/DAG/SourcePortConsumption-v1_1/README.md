Bounded, source-matched Newton port consumption overlay; no physical status promotion. See Index.json, ScopedIssues.json and PortInventory.json.
