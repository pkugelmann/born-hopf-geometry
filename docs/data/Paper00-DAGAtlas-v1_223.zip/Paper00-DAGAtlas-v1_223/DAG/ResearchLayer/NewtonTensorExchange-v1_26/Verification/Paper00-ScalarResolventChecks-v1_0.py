"""Symbolic and independent numerical checks of the neutral resolvent model.

Run with Python, SymPy and mpmath. Output is deterministic JSON. The finite
matrix and dispersion tests are numerical witnesses, not continuum proofs.
"""
import json
import mpmath as mp
import sympy as sp

mp.mp.dps = 45
C, L, y, r, s, q, u = sp.symbols("C L y r s q u", positive=True)
b, c, a = 4*r, L+r, u*(1-u)
V = C*L*((L+y)*sp.log((L+y)/c)-(y-r))
slope = C*L/c*(1-b/(6*c))
tests = {}


def identity(name, lhs, rhs):
    tests[name] = bool(sp.simplify(lhs-rhs) == 0)


identity("potential_vanishes_at_reference", V.subs(y,r), 0)
identity("first_variation_is_zero", sp.diff(V,y).subs(y,r), 0)
identity("positive_orbit_second_variation", sp.diff(V,y,2), C*L/(L+y))
identity("changed_linear_term_at_origin", sp.diff(V,y).subs({y:0,r:L}), -C*L*sp.log(2))
identity("retained_quartic_coefficient", sp.diff(V,y,2).subs(y,0)/2, C/2)
identity("squared_mass_coordinate_hessian_is_kernel_zero", sp.diff(V.subs(y,s**2),s,2).subs(s,sp.sqrt(r)), C*L*b/c)
kernel_integrand = C*L*(q+b)/(c+a*q)
identity("kernel_first_derivative", sp.integrate(sp.diff(kernel_integrand,q).subs(q,0),(u,0,1)), slope)
identity("positive_mixture_decomposition", (q+b)/(c+a*q), b/c+(c-a*b)*q/(a*c*(q+c/a)))
identity("mixture_density_positive", c-a*b, L+r*(2*u-1)**2)
identity("reference_kinetic_slope", slope.subs(r,L), C/3)
identity("soft_mass_squared_differs_from_exact_pole", ((C*L*b/c)/slope).subs(r,L), 6*L)
identity("isolated_pole_below_continuum", 4*c-b, 4*L)
identity("static_scalar_exchange_has_zero_massless_residue", sp.limit(q/(C*b*L/c),q,0), 0)
identity("reference_pole_weight", (C*sp.sqrt(L/r)*sp.atan(sp.sqrt(r/L))).subs(r,L), C*sp.pi/4)

def close(x, target):
    return bool(abs(x-target) < mp.mpf("1e-30")*max(1,abs(target)))


def test_heat_average():
    # Stable evaluation at t=0 uses the remainder exp(-t*d)-1+t*d.
    y0 = mp.mpf("0.4")
    y1 = mp.mpf("1.7")
    delta = y1-y0

    def density(t):
        if abs(t*delta)<mp.mpf("1e-9"):
            rem = (t*delta)**2*sum((-t*delta)**k/mp.factorial(k+2) for k in range(6))
        else:
            rem = mp.expm1(-t*delta)+t*delta
        return mp.exp(-(1+y0)*t)*rem/t**2

    value = mp.quad(density,[0,1,mp.inf])
    target = (1+y1)*mp.log((1+y1)/(1+y0))-(y1-y0)
    return close(value,target)


def direct_green(qval, ref):
    weighted = mp.quad(lambda uval:1/(1+ref+uval*(1-uval)*qval),[0,mp.mpf("0.5"),1])
    return 1/((qval+4*ref)*weighted)


def spectral_green(qval, ref):
    pole = 1/(mp.atan(mp.sqrt(ref))/mp.sqrt(ref))
    gap = 4*(1+ref)
    # w = gap cosh(t/2)^2 yields a regular positive integrand at both endpoints.
    def continuum(t):
        energy = gap*mp.cosh(t/2)**2
        beta = mp.tanh(t/2)
        return (energy/(energy-4*ref))*(energy/(energy+qval))*beta**2/(2*(t*t+mp.pi**2))
    return pole/(qval+4*ref)+mp.quad(continuum,[0,2,20,mp.inf])


def matrix_test():
    A = mp.matrix([[1,0],[0,5]])
    B = mp.matrix([[3,1],[1,2]])
    t = mp.mpf("0.63")
    tr = lambda m: m[0,0]+m[1,1]
    X = B-A
    def value(e):
        return tr(mp.expm(-t*(A+e*X))-mp.expm(-t*A)+t*mp.expm(-t*A)*(e*X))
    tests["matrix_witness_noncommuting"] = bool(mp.norm(A*B-B*A)>0)
    tests["matrix_reference_has_zero_defect"] = close(value(0),0)
    tests["matrix_first_variation_vanishes"] = close(mp.diff(value,0),0)
    tests["matrix_second_variation_positive"] = bool(mp.diff(value,0,2)>0)
    tests["matrix_finite_shift_positive"] = bool(value(1)>0)


tests["direct_heat_average_matches_potential"] = test_heat_average()
matrix_test()
for ref in [mp.mpf("0.3"),mp.mpf(1)]:
    for qval in [mp.mpf(0),mp.mpf("0.3"),mp.mpf(3),mp.mpf(70),mp.mpf(10000)]:
        tests[f"positive_dispersion_r_{str(ref)}_q_{str(qval)}"] = close(
            direct_green(qval,ref),spectral_green(qval,ref))
assert all(tests.values()), [name for name,p in tests.items() if not p]
print(json.dumps({"scope":"optional neutral scalar model","passed":sum(tests.values()),"tests":tests},
                 sort_keys=True,indent=2))
