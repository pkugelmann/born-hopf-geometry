# A positive scalar response at the adopted reference

**Paper00-ScalarResolventRepair-v1_0 · 19 November 2026**

A modified scalar action can make the same nonzero reference an exact minimum and give its radial two-point function a positive spectral measure. This is a candidate amendment of the scalar sector of v3_041. It changes material variations. The reference-centered metric assembly by itself cannot produce the effect.

## Construction and variational domain

Paper II-A, \(\mathtt{p2a:thm:v267\text{-}heat\text{-}bregman\text{-}converse}\), constructs the heat–Bregman comparison of two Hermitian operators. III-F applies it to a constituted finite charged source as an equality test. *NewtonTensorExchange* v1_19, §3, evaluates its fixed-time neutral scalar Hessian and identifies a failure of its ultraviolet spectral sign. For the proposal here, let \(L=\Lambda_g^2>0\), let \(D_P=P(g,A,s_*)\) be the squared Dirac operator at the **fixed** reference, and let \(P=P(g,A,s)\) use the same metric, connection and domain. Define
\[
 \mathcal B_t(P,D_P)=\mathrm{Tr}\!\left[e^{-tP}-e^{-tD_P}
                  +t e^{-tD_P}(P-D_P)\right],\qquad
 \mathcal B_R=\int_0^\infty L e^{-Lt}\mathcal B_t\,dt.
\]
Use the native positive scalar action weight on this comparison. The exponential distribution has mean \(1/L\). Laplace transforming a heat operator gives \(L(L+P)^{-1}\); this motivates the average and introduces no new scale. It is an additional scalar-action choice. The cited framework results do not select that choice. On an infinite-dimensional space take the *combined* defect before the integration. The individual resolvent traces can diverge.

On a closed smooth compact four-dimensional Euclidean Dirac domain assume \(P,D_P\ge0\), \(X=P-D_P\) bounded and self-adjoint, a common domain, and \(\mathrm{Tr}\,e^{-tD_P}=O(t^{-2})\) at zero. Smooth neutral scalar fields on a fixed Dirac background satisfy the bounded-difference condition: the square contributes a scalar square and a Clifford multiplication by its covariant derivative. At each \(t>0\), with \(P_u=D_P+uX\),
\[
 \mathcal B_t=t^2\int_0^1(1-u)\,du\int_0^1
 \mathrm{Tr}(X e^{-t(1-z)P_u}X e^{-tzP_u})\,dz.
\]
In a spectral basis the quadratic form is strictly positive for \(X\ne0\). The weighted arithmetic–geometric mean bound on the two heat eigenvalues bounds the inner integral by \(\|X\|^2\mathrm{Tr}\,e^{-tP_u}\). The min–max bound \(P_u\ge D_P-\|X\|I\) gives \(\mathcal B_t=O(1)\) at zero. At large \(t\) the defining expression grows at most linearly because both nonnegative operators have trace-class heat. This proves absolute convergence and global nonnegativity for every field satisfying the hypotheses, with equality precisely when \(P=D_P\). If supports or positive multiplicities are restricted, equality holds on the tested components. This proof applies in four dimensions; extension to the full eight-dimensional heat would require its own ultraviolet prescription.

At the section \(s=s_*\), the defect and its first material variation vanish for every \(g,A\). Consequently pure metric and connection variations and their derivatives with one scalar leg vanish there, provided smooth differentiations are licensed. This permits a stationary reference in the scalar sector. A stationary spacetime also needs the chosen remaining metric, matter and boundary functionals to obey their equations there. Nonzero scalar sources in those functionals must be included. The comparison removes the relative scalar action it replaces; adding both would double count.

## Flat homogeneous radius and exact quadratic pole

Use the equal-mass primitive neutral comparison of v1_19. Write \(y=s^2=\lambda_Hh^2/2\), \(y_*=s_*^2>0\), \(C=6/\pi^2=2/\lambda_H\), and take the flat four-dimensional continuum heat density with the stated primitive scalar weight. The homogeneous potential per unit volume is
\[
 V_R(y)=CL\left[(L+y)\log\frac{L+y}{L+y_*}-(y-y_*)\right].
\]
Indeed the unintegrated density is \(Ct^{-2}[e^{-ty}-e^{-ty_*}+t e^{-ty_*}(y-y_*)]\). Two derivatives yield \(V_R''(y)=CL/(L+y)>0\), and the value and first derivative at \(y_*\) vanish. Thus \(y_*\) is the exact global homogeneous minimum. The adopted quartic comparison has \(y_*=L\). The coefficient of \(y\) at the origin then changes from \(-CL\) to \(-CL\log2\); the coefficient of \(y^2\) stays \(C/2\). These are respectively quadratic and quartic terms in \(h\). Equality of all native scalar vertices is lost.

For \(\sigma=s-s_*\), let \(q=k_E^2\), \(b=4y_*\), \(c=L+y_*\), \(a=u(1-u)\). The fixed-time Hessian is \(C(q+b)e^{-ty_*}\int_0^1e^{-taq}\,du\). Its exact average and its small-\(q\) derivative are
\[
 Q(q)=C(q+b)\bar J(q),\qquad
 \bar J(q)=\int_0^1\frac{L\,du}{c+aq},\qquad
 Q(0)=\frac{CLb}{c},\quad Q'(0)=\frac{CL}{c}\left(1-\frac{b}{6c}\right)>0.
\]
The static Hessian agrees with \(\partial_s^2 V_R\). The physical pole of this Gaussian comparison is read from \(1/Q\), not from its two-derivative expansion. For \(0<u<1\),
\[
 \frac{q+b}{c+aq}=\frac bc+\frac{c-ab}{ac}\frac{q}{q+c/a},\qquad c-ab\ge L>0 .
\]
Thus \(Q\) is a complete Bernstein function (a nonnegative constant plus a positive mixture of \(q/(q+d)\)). Its inverse has a positive mass spectral measure. Explicitly
\[
 \frac1{Q(q)}=\frac{Z_p}{q+b}+\int_{4c}^{\infty}\frac{\rho(w)}{q+w}\,dw,\quad
 Z_p=\frac{1}{C\sqrt{L/y_*}\arctan\sqrt{y_*/L}},\quad
 \rho(w)=\frac{w\beta}{2CL(w-b)\{\log^2[(1+\beta)/(1-\beta)]+\pi^2\}},
 \qquad\beta=\sqrt{1-\frac{4c}{w}} .
\]
The pole weight follows by evaluating \(\bar J(-b)\). On the cut, substituting \(2u-1=x\) gives \(\bar J(-w+i0)=2L[\log((1-\beta)/(1+\beta))-i\pi]/(w\beta)\), yielding the displayed jump. The Pick sign of \(Q\) excludes nonreal poles. Below the cut \(\bar J>0\) and \(1/Q\) tends to zero at spacelike infinity, so no other atom or constant contact enters. For \(y_*=L\), the radial mass squared is \(4L\), its residue is \(4/(\pi C)\), and the continuum starts at \(8L\). In this case \(Q'(0)=C/3\), so using the low-momentum mass estimate \(Q(0)/Q'(0)=6L\) would miss the pole.

## Observable and limitations

On the neutral comparison with one calibrated Einstein field of stiffness \(\nu=U/8\), no residual scalar–metric mixing from other terms, and separately conserved stress probes, a scalar probe \(j\) calibrated in the \(s\) coordinate contributes \(j_1j_2/Q(q)\). It is regular at \(q=0\); the tensor residue is unchanged. If a separate nonminimal term \(F'(s_*)\sigma R^{(1)}\) is retained, its mixing and the source numerator must be recomputed before using the scalar pole above. The fixed-reference cancellation in the scalar defect does not establish preservation of the complete charged scalar–vector vertices, interacting particle masses, the quantum measure, or scalar stationarity in an occupied medium. Gauge data transported with both operators do not by themselves reproduce the independent gauge action. Identifying the scalar reference, connection and mass sources on one physical branch remains necessary. This construction settles the scalar variational and positivity problem on the declared comparison. It does not constitute an empirical Higgs-pole prediction.

The companion script checks the potential, kernel, continuum reconstruction, a noncommuting matrix example and the change in the primitive scalar coefficients.
