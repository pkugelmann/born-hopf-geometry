"""Replay the unadopted scalar-repair research in DAG Atlas v1.213."""
import argparse
from graphlib import TopologicalSorter
from hashlib import sha256
import json
from pathlib import Path
import re
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile


def digest(data):
    return sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('archive', type=Path)
    parser.add_argument('--papers', type=Path, help='PapersMinimal v3.041 ZIP')
    args = parser.parse_args()
    with ZipFile(args.archive) as archive:
        roots = {n.split('/')[0] for n in archive.namelist()}
        assert len(roots) == 1
        prefix = roots.pop() + '/'
        def read(name):
            return archive.read(prefix + name)
        def record(name):
            return json.loads(read(name))
        release = record('DAG/ActiveRelease-v1_213.json')
        manifest = record(release['current_manifest'])
        certificate = record(release['current_write_certificate'])
        assert certificate['manifest_sha256'] == digest(read(release['current_manifest']))
        for name, expected in manifest['hashes'].items():
            assert expected == digest(read(name)), name
        research = record(release['current_newton_research'])
        details = record(research['verification'])
        assert not research['scalar_action_adopted'] and not research['physical_occurrence']
        assert not research['canonical_proof_edge_promotions']
        assert digest(read(research['current_report'])) == certificate['report_sha256'] == research['report_sha256']
        adopted = record(release['current_newton_physical_adoption'])
        graph = record(details['scoped_graph'])
        assert adopted['decision'] == graph['previous_metric_adoption']
        assert graph['existing_owner_guard'] == adopted['unrestricted_owner_condition']
        assert not graph['adopted_scalar_modifications'] and not graph['physical_occurrence']
        digraph = TopologicalSorter()
        idx = {k: i for i, k in enumerate(graph['topological_order'])}
        for key in graph['nodes']:
            digraph.add(key)
        for edge in graph['edges']:
            src, dst = edge['source'], edge['target']
            assert src in graph['nodes'] and dst in graph['nodes'] and idx[src] < idx[dst]
            digraph.add(dst, src)
        assert set(digraph.static_order()) == set(graph['nodes']) == set(idx)
        anchors = record(release['current_source_anchor_map'])['claims']
        source_rows = record(release['current_source_manifest'])['files']
        sources = record(details['sources'])
        for key, witness in sources.items():
            data = read(witness['source_member'])
            lines = data.decode().splitlines()
            assert digest(data) == witness['source_sha256']
            assert 1 <= witness['line_start'] <= witness['line_end'] <= len(lines)
            excerpt = '\n'.join(lines[witness['line_start']-1:witness['line_end']])
            assert excerpt == witness['excerpt'] and digest(excerpt.encode()) == witness['excerpt_sha256']
            if witness['source_kind'] == 'current_manuscript':
                row = anchors[key]
                assert witness['source_member'] == release['current_source_tree'] + row['source_file']
                assert row['source_sha256'] == witness['source_sha256']
                assert r'\label{' + key + '}' in lines[row['line']-1]
        recovered = {}
        for row in source_rows:
            data = read(release['current_source_tree'] + row['filename'])
            assert digest(data) == row['sha256']
            for i, line in enumerate(data.decode().splitlines(), 1):
                for key in re.findall(r'\\label\{([^{}]+)\}', line):
                    assert key not in recovered
                    recovered[key] = dict(source_file=row['filename'], paper=row['paper'], source_sha256=row['sha256'], line=i)
        assert recovered == anchors and len(source_rows) == 31
        if args.papers:
            assert digest(args.papers.read_bytes()) == release['source_archive_sha256']
            with ZipFile(args.papers) as papers:
                for name in papers.namelist():
                    if '/' not in name and name.endswith(('.tex', '.bib')):
                        assert papers.read(name) == read(release['current_source_tree']+name), name
        passed = {}
        for suite in details['checks']:
            with TemporaryDirectory() as work:
                script = Path(work) / Path(suite['script']).name
                script.write_bytes(read(suite['script']))
                result = subprocess.run([sys.executable, str(script)], cwd=work, capture_output=True, check=True)
                out = Path(work) / Path(suite['expected']).name
                actual = out.read_bytes() if out.is_file() else result.stdout
                assert actual == read(suite['expected']), script.name
                packet = json.loads(actual)
                tests = packet.get('checks', packet.get('tests'))
                assert tests and all(v is True for v in tests.values()), script.name
                assert len(tests) == packet.get('checks_passed', packet.get('passed'))
                passed[script.name] = len(tests)
        print(json.dumps(dict(status='PASS', suites=passed, total=sum(passed.values()), sources=len(sources),
                              manuscripts=len(source_rows), anchors=len(anchors), nodes=len(graph['nodes']),
                              edges=len(graph['edges']), scalar_action_adopted=False, empirical_identity=False)))


if __name__ == '__main__':
    main()
