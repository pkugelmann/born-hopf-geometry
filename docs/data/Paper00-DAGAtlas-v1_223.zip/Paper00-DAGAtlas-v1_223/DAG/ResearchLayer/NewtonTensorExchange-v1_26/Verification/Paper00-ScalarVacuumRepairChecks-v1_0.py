"""Reproduce the local and flat-space checks for the scalar vacuum repair.

Run with Python 3, SymPy, mpmath, NumPy and SciPy. Standard output is
the deterministic companion JSON. The matrix and quadrature examples are
checks on the displayed identities. They do not construct a physical state.
"""

import json
import math

import mpmath as mp
import numpy as np
import sympy as sp
from scipy.linalg import expm

mp.mp.dps = 60
checks = {}


def check(name, result):
    checks[name] = bool(result)
    if not checks[name]:
        raise AssertionError(name)


def exact(a, b=0):
    return sp.simplify(a - b) == 0


def close(a, b, tolerance="1e-42"):
    return abs(a-b) < mp.mpf(tolerance)


# x = Phi^2 / L on the primitive unit ray. Constants are in units of the
# heat prefactor A(g). An affine centering changes the vacuum energy only.
x = sp.symbols("x", nonnegative=True)
alpha = sp.symbols("alpha")
e = sp.E
raw = sp.exp(-x)
contact = x**3 / (3*e)
potential = raw + contact - 4/(3*e)
check("sextic_coefficient_from_stationarity",
      sp.solve(sp.diff(raw+alpha*x**3, x).subs(x, 1), alpha) == [1/(3*e)])
check("centered_value_and_gradient",
      exact(potential.subs(x, 1)) and exact(sp.diff(potential, x).subs(x, 1)))
check("strict_radial_convexity",
      exact(sp.diff(potential, x, 2), sp.exp(-x)+2*x/e)
      and sp.diff(potential, x, 2).is_positive)
h, L = sp.symbols("h L", positive=True)
check("preserves_mass_and_quartic_coefficients",
      all(exact(sp.diff(contact.subs(x, h*h/L), h, k).subs(h, 0)) for k in range(6)))
check("sextic_first_new_zero_field_vertex",
      exact(sp.diff(contact.subs(x, h*h/L), h, 6), 240/(e*L**3)))
check("potential_second_derivative_at_orbit", exact(sp.diff(potential, x, 2).subs(x, 1), 3/e))
# exp(-x) >= exp(-1)*(2-x) by the supporting tangent of the exponential.
# Spectral calculus applies the resulting scalar bound to every PSD X.
lower = (x-1)**2 * (x+2)/(3*e)
check("spectral_matrix_lower_bound_tangent_identity",
      exact(potential-lower, raw-(2-x)/e))
check("matrix_lower_bound_dominates_squared_displacement",
      exact(lower-2*(x-1)**2/(3*e), x*(x-1)**2/(3*e)))
check("metric_heat_weight_cancels_on_reference",
      exact(sp.diff(sp.symbols("A", positive=True)*potential, sp.symbols("A", positive=True)).subs(x, 1)))
# Fixed smooth constant matrices with a common covariantly constant
# scalar and compatible domain have D^2 = P + s^2 B^2. This small curved
# spectral example uses an arbitrary nontrivial positive P and a nonidentity
# positive localizer with off-diagonal entries.
P = np.array([[1.0, 0.4], [0.4, 2.0]])
B = np.array([[0.5, 0.3], [0.3, 1.3]])
B2 = B @ B
W = np.array([[1.1, 0.1, 0.17, 0.2], [0.1, 1.2, 0.12, 0.15],
              [0.17, 0.12, 1.25, 0.13], [0.2, 0.15, 0.13, 1.3]])
I2 = np.eye(2)
matrix_v = expm(-B2) + np.linalg.matrix_power(B2, 3)/(3*math.e)-4*I2/(3*math.e)
matrix_bound = (B2-I2) @ (B2-I2) @ (B2+2*I2)/(3*math.e)
check("nontrivial_matrix_functional_calculus_lower_bound",
      np.linalg.eigvalsh(matrix_v-matrix_bound).min() > -1e-12)
Ptot = np.kron(P, I2)
Btot = np.kron(I2, B2)
check("fixed_localizer_need_not_commute",
      np.linalg.eigvalsh(W).min() > 0 and np.linalg.norm(W@Btot-Btot@W) > 0.05)
check("parallel_weighted_heat_factorization",
      np.allclose(expm(-Ptot-Btot), np.kron(expm(-P), expm(-B2)), rtol=1e-13, atol=1e-14))
check("weighted_repaired_potential_positive",
      np.trace(W@np.kron(expm(-P), matrix_v)) > 0)
check("unrepaired_parallel_derivative_strict",
      -np.trace(W@Btot@expm(-Ptot-Btot)) < 0)

# Flat Euclidean radial quadratic form with u=k_E^2/L. The normalization
# multiplies the quadratic coefficient of delta s by 2 e L/A, where
# s^2/L=x. The single Duhamel contact is -2, the iterated insertion
# has matrix numerator 4+u, and the new sextic contributes +10.
u, j = sp.symbols("u j", real=True)
sextic_hessian = sp.diff(contact.subs(x, h*h/L), h, 2).subs(h, sp.sqrt(L))
check("normalized_contact_in_flat_hessian", exact(sextic_hessian*e*L, 10))
check("radial_kernel", exact(-2 + (4+u)*j + 10, 8+(4+u)*j))
check("tangent_contact_cancellation",
      exact(2*(3/(3*e))*e-2) and exact(0 + u*j, u*j))
# J(u) = integral exp[-u t(1-t)] dt on [0,1], entire and positive on the real line.
t = sp.symbols("t", real=True)
j_series = sum((-u)**n*sp.integrate((t*(1-t))**n, (t, 0, 1))/sp.factorial(n)
               for n in range(5))
kernel = 8+(4+u)*j_series
check("small_momentum_hessian_expansion",
      exact(sp.series(kernel, u, 0, 4).removeO(), 12 + u/3 - u**2/10 + u**3/84))
check("radial_two_derivative_heat_kinetic_ratio", exact((1-2*sp.Rational(1,3))/e, 1/(3*e)))
# Integration by parts gives 2u J' + (1+u/2) J = 1. The large-u
# endpoint expansion is algebraic with positive first inverse correction.
c1,c2,c3 = sp.symbols("c1 c2 c3")
j_asym = c1/u+c2/u**2+c3/u**3
ode_res = sp.expand(2*u*sp.diff(j_asym, u)+(1+u/2)*j_asym-1)
coefs = sp.solve([ode_res.coeff(u, k) for k in [0,-1,-2]], [c1,c2,c3], dict=True)[0]
check("heat_form_factor_endpoint_coefficients", coefs == {c1:2, c2:4, c3:24})
check("kernel_approaches_ten_from_above", exact(
    sp.series(8+(4+u)*j_asym.subs(coefs), u, sp.oo, 3).removeO(), 10+12/u+40/u**2))
check("bounded_inverse_excludes_positive_stieltjes",
      sp.Rational(1,12) < sp.Rational(1,10))

def form_factor(arg):
    return 2*mp.quad(lambda p: mp.exp(-arg*p*(1-p)), [0, mp.mpf("0.5")])

def response(arg):
    return 8+(4+arg)*form_factor(arg)

check("euclidean_positive_sample",
      all(response(mp.mpf(b)) > 0 for b in (0,1,4,16,64,256)))
check("endpoint_asymptotic_quadrature",
      abs(4096*(response(mp.mpf(4096))-10)-12) < mp.mpf("0.011"))
check("timelike_below_four_has_no_zero",
      all(response(-mp.mpf(b)) > 0 for b in (0,1,2,3,4)))
# For a>4, -d/da[(a-4)J(-a)] = -J(-a) -(a-4) integral t(1-t)e^(...) < 0.
# As a -> +infinity its magnitude diverges (J(-a) >= 1).
a = mp.findroot(lambda value: response(-value), (4,8))
check("timelike_root_strict_bracket", 4 < a < 12 and close(response(-a),0))
derivative = mp.diff(response,-a)
check("timelike_root_positive_inverse_residue", derivative>0)

# A gauge-singlet Majorana block can be arbitrary if the other independent
# block is zero and the whole Dirac off-diagonal is scaled. D Dagger need not
# commute with the Majorana mass. The exact proof is s H'={P_active,H}
# and cyclic trace differentiation, giving s d Tr exp(-H^2)/ds =
# -4 Tr(P_active H^2 exp(-H^2)) at cutoff one. This is a full trace test.
D = np.array([[0.8+0.2j,0.4-0.1j],[0,1.6-0.7j]])
M = np.array([[0.3,0.4],[0.4,-0.9]])
zero = np.zeros_like(M)
A = np.block([[I2,zero],[zero,zero]])
dH = np.block([[zero,D],[D.conj().T,zero]])

def fermion(s):
    return s*dH+np.block([[zero,zero],[zero,M]])

def tr_heat(s):
    finite = fermion(s)
    return np.trace(expm(-finite@finite)).real

check("majorana_example_really_noncommuting",
      np.linalg.norm((D.conj().T@D)@M-M@(D.conj().T@D))>0.1)
for s in (0.4,1.0,1.6):
    mat = fermion(s)
    mat2 = mat@mat
    ht = expm(-mat2)
    check(f"sterile_anticommutator_at_{s}", np.linalg.norm(s*dH-A@mat-mat@A)<1e-13)
    slope1 = -np.trace((mat@dH+dH@mat)@ht).real
    slope2 = -4*np.trace(A@mat2@ht).real/s
    hstep=1e-5
    finite_diff=(tr_heat(s+hstep)-tr_heat(s-hstep))/(2*hstep)
    check(f"sterile_strict_monotonicity_at_{s}",
          max(abs(slope1-slope2), abs(slope1-finite_diff)) < 5e-9 and slope2<0)

print(json.dumps({
    "checks":checks,
    "checks_passed":len(checks),
    "scope":"Fixed compatible parallel heat and the flat Euclidean radial kernel of the additional sextic model. Sterile-block comparison uses a full finite trace.",
    "timelike_pole_mass_squared_in_cutoff_units":mp.nstr(a, 25),
    "dimensionless_timelike_inverse_kernel_residue":mp.nstr(1/derivative, 25),
}, sort_keys=True, indent=2))
