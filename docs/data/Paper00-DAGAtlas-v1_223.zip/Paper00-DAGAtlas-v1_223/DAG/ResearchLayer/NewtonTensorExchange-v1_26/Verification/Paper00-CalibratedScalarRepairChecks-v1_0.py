"""Checks for the calibrated proper-time scalar potential and flat radial response.

All dimensionless momenta use u=k_E^2/L; s denotes positive timelike
mass squared in the same units in the spectral integrals. Run with Python,
mpmath, and SymPy. The sampled positive quantities complement the analytic
factorizations and spectral representation. They test this specified model.
"""
import json

import mpmath as mp
import sympy as sp


mp.mp.dps = 53
checks = {}


def check(name, result):
    checks[name] = bool(result)
    if not checks[name]:
        raise AssertionError(name)


def exact(value, expected=0):
    return sp.simplify(value-expected) == 0


def close(value, expected, eps="1e-40"):
    return abs(value-expected) <= mp.mpf(eps)*max(1,abs(expected))


x, u, z = sp.symbols("x u z", real=True)
d = 1-sp.log(2)
poly = (x-1)**2*(x+2)/3
entropy = (1+x)*sp.log((1+x)/2)-(x-1)
potential = entropy + d*poly
check("centered_polynomial", exact(poly, x**3/3-x+sp.Rational(2,3)))
check("free_coefficient_forced_by_zero_field_mass",
      exact((-1-sp.diff(entropy,x).subs(x,0))/sp.diff(poly,x).subs(x,0),d))
check("minimum_value_and_gradient_at_unit_orbit",
      exact(potential.subs(x,1)) and exact(sp.diff(potential,x).subs(x,1)))
check("preserves_native_zero_field_scalar_mass",exact(sp.diff(potential,x).subs(x,0),-1))
check("preserves_native_zero_field_scalar_quartic",exact(sp.diff(potential,x,2).subs(x,0),1))
check("strict_convexity_factorization",exact(sp.diff(potential,x,2),1/(1+x)+2*d*x))
check("positive_coefficient",0<d.evalf()<1)
check("hessian_at_unit_orbit",exact(sp.diff(potential,x,2).subs(x,1),sp.Rational(1,2)+2*d))
check("first_new_origin_scalar_vertex_is_sextic",
      exact(sp.diff(potential,x,3).subs(x,0), 2*d-1)
      and not exact(sp.diff(potential,x,3).subs(x,0), -1))
# The tangent of the entropy term at 1 vanishes. Its strict convexity gives
# entropy(x)>=0, so V(x)>=d(2/3)(x-1)^2 on the positive spectrum.
check("matrix_polynomial_lower_bound_remainder",
      exact(potential-entropy-2*d*(x-1)**2/3, d*x*(x-1)**2/3))
metric_prefactor = sp.symbols("A",positive=True)
check("metric_volume_first_and_radial_mixed_contact_vanish_at_reference",
      exact(sp.diff(metric_prefactor*potential,metric_prefactor).subs(x,1))
      and exact(sp.diff(metric_prefactor*potential,metric_prefactor,x).subs(x,1)))

D=1-mp.log(2)


def mean_entropy_integrand(t,value):
    # exp[-t] exp[-t] (exp[-(x-1)t]-1+(x-1)t) /t^2.
    delta=(value-1)*t
    if abs(delta) < mp.mpf("1e-12"):
        # Stable even for tiny quadrature nodes at the lower endpoint.
        return mp.exp(-2*t)*(value-1)**2*(
            mp.mpf("0.5")-delta/6+delta**2/24-delta**3/120+delta**4/720)
    # Factorization avoids overflow for x<1 and t large.
    if delta < -1:
        return (mp.exp(-(1+value)*t)-mp.exp(-2*t)*(1-delta))/(t*t)
    return mp.exp(-2*t)*(mp.expm1(-delta)+delta)/(t*t)


for value in (mp.mpf(0),mp.mpf("0.3"),mp.mpf(1),mp.mpf(3)):
    mean=mp.quad(lambda t:mean_entropy_integrand(t,value),[0,1,6,mp.inf])
    analytic=(1+value)*mp.log((1+value)/2)-(value-1)
    check("proper_time_mean_at_"+str(value),close(mean,analytic))

# For every b=z(1-z), the unsubtracted response equals 2 + (1-2b)u/(2+bu).
# This is a positive complete Bernstein representation; 0<=b<=1/4.
b = sp.symbols("b",positive=True)
check("complete_bernstein_kernel_decomposition",
      exact((4+u)/(2+b*u), 2+(1-2*b)*u/(2+b*u)))
check("pointwise_positive_monotonicity_expression",
      exact(sp.diff((4+u)/(2+b*u),u),(2-4*b)/(2+b*u)**2))
check("local_radial_hessian_agrees_with_potential",
      exact(2+8*d,4*sp.diff(potential,x,2).subs(x,1)))
beta=z*(1-z)
iseries=sum((-u/2)**n*sp.integrate(beta**n,(z,0,1))/2 for n in range(4))
check("small_momentum_response",
      exact(sp.series((u+4)*iseries+8*d,u,0,4).removeO(),
            2+8*d+u/3-u**2/40+u**3/420))
check("threshold_from_beta_maximum",
      exact(beta.subs(z,sp.Rational(1,2)),sp.Rational(1,4)) and exact(sp.diff(beta,z,2),-2))


def I(arg):
    arg=mp.mpf(arg)
    if arg==0:
        return mp.mpf("0.5")
    if arg>0:
        return 4*mp.atanh(mp.sqrt(arg/(arg+8)))/mp.sqrt(arg*(arg+8))
    return 4*mp.atan(mp.sqrt(-arg/(arg+8)))/mp.sqrt(-arg*(arg+8))


def inverse_response(arg):
    return 8*D+(arg+4)*I(arg)


for value in (-7,-4,0,1,4,50):
    integral=mp.quad(lambda p: 1/(2+p*(1-p)*value),[0,mp.mpf("0.5"),1])
    check(f"standard_form_factor_at_{value}",close(I(value),integral))

pole=mp.findroot(lambda mass_sq: inverse_response(-mass_sq),(5,7))
residue=1/mp.diff(inverse_response,-pole)
check("isolated_pole_with_positive_residue",4<pole<8 and residue>0 and close(inverse_response(-pole),0))
check("unique_subthreshold_pole_bracket",inverse_response(-4)>0 and inverse_response(mp.mpf("-7.999"))<0)


def density(s):
    """Positive discontinuity on s>8, in G(u)=Z/(u+a)+integral rho/(u+s)."""
    delta=mp.sqrt(1-8/s)
    c=2*(1-4/s)/delta
    qreal=8*D+c*mp.log((1+delta)/(1-delta))
    return c/(qreal*qreal+(mp.pi*c)**2)


def spectral_integrand(y,arg,n=0):
    # s=8cosh^2(y/2). No exponentially large s or cancellation even on
    # the slow logarithmic high-energy tail rho(s)~1/(2 log^2 s).
    fall=mp.exp(-y)
    sinv=fall/(2*(1+fall)**2)
    delta=mp.tanh(y/2)
    cinv=delta/(2*(1-4*sinv))
    base=delta*cinv/((y+8*D*cinv)**2+mp.pi**2)
    return base*sinv**n/(1+arg*sinv)**(n+1)


def spectral(arg,n=0):
    continuum=mp.quad(lambda y: spectral_integrand(y,arg,n), [0,1,5,20,mp.inf])
    return mp.factorial(n)*(residue/(arg+pole)**(n+1)+continuum)


for mass_sq in ("8.001","9","16","1000"):
    s=mp.mpf(mass_sq)
    check("positive_continuum_density_at_"+mass_sq,density(s)>0)
    # On the upper lip take u=-s+i0, with sqrt, atanh on their principal
    # branches. This directly checks the sign and factor of pi.
    upper=mp.mpc(-s,mp.mpf("1e-28"))
    jupper=4*mp.atanh(mp.sqrt(upper/(upper+8)))/(
        mp.sqrt(upper)*mp.sqrt(upper+8))
    upper_g=1/(8*D+(upper+4)*jupper)
    check("complex_discontinuity_at_"+mass_sq,
          close(-mp.im(upper_g)/mp.pi,density(s),"1e-23"))

kl={}
for arg in (0,1,8,100):
    observed=1/inverse_response(arg)
    reconstructed=spectral(arg)
    check(f"full_positive_spectral_reconstruction_at_{arg}",
          close(reconstructed,observed))
    kl[str(arg)] = mp.nstr(reconstructed,24)
for n in (1,2,3):
    from_response=(-1)**n*mp.diff(lambda arg:1/inverse_response(arg),mp.mpf(1),n)
    check(f"complete_monotonicity_derivative_{n}_at_one",
          from_response>0 and close(from_response,spectral(1,n)))
check("no_polynomial_contact_asymptotic", inverse_response(mp.mpf("1e24"))>inverse_response(100)>0)
print(json.dumps({
    "checks":checks, "checks_passed":len(checks),
    "threshold_mass_squared_over_L":8,
    "pole_mass_squared_over_L":mp.nstr(pole,26),
    "dimensionless_pole_residue":mp.nstr(residue,26),
    "full_positive_spectral_reconstructions":kl,
    "scope":"The specified scalar potential and fixed-flat-metric radial Euclidean response. No graviton or full-action quantum spectrum is checked."
},sort_keys=True,indent=2))
