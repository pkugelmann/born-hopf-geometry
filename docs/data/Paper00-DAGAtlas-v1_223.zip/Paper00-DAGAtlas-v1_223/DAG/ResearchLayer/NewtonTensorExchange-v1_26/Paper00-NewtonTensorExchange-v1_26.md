# Repairing the scalar vacuum and testing the resulting particle

**Paper00-NewtonTensorExchange-v1_26 · Research supplement to v3_041 · 19 November 2026**

I constructed a scalar action with an exact nonzero minimum and a positive radial two-point spectrum. It preserves the native flat zero-field scalar mass and quartic coefficients and the calibrated Newton tensor residue on the neutral Einstein branch. With the observed Newton calibration its radial particle would weigh about 30 Planck masses. Identifying this particle with the measured Higgs fails. The construction is a separate material-action proposal. The active manuscripts retain the v3_041 metric prescription.

## What can change the scalar equation

The adopted action in III-F differs from the ordinary joint action by a metric and fixed-reference functional. Its first variation in any independent material direction is therefore the ordinary one. Set $L=\Lambda_g^2=96\pi^2U$, $s^2=\lambda h^2/2$, $\lambda=\pi^2/3$ and $x=s^2/L$. On the primitive flat parallel ray the native exact scalar-dependent density is $A e^{-x}$ up to a constant, with $A=2L^2/\lambda$. The quartic example selects $v^2=2L/\lambda$, or $x=1$. The exact first derivative there is $-A/e$. A repair that preserves every material derivative is mathematically impossible on this ray.

One existing extension worth testing is an independent constant sterile Majorana matrix. In the parallel doubled Dirac representation write $H(s)=\bigl(\begin{smallmatrix}0&sY\\sY^\dagger&M\end{smallmatrix}\bigr)$, allowing arbitrary mixings and Hermitian $M$ on the right-handed block. The left projection satisfies $sH'=\{P_L,H\}$. Cyclic trace differentiation gives
$$
 \frac{d}{ds}\operatorname{Tr}e^{-H^2/L}
 =-\frac{4}{sL}\operatorname{Tr}[P_L H^2e^{-H^2/L}]<0
 \qquad (s>0,\ Y\ne0).
$$
The last trace is a squared Hilbert–Schmidt norm, strictly positive since $HP_L\ne0$. A sterile offset in this entire class cannot supply the missing force. This is a parallel, positive Euclidean heat result.

## An explicit action

Take a common closed smooth compact four-dimensional Euclidean Dirac domain, or its neutral flat per-volume limit. Put $P_0=D_0(g)^2$, $P_\Phi=(D_0+\gamma\Phi)^2$, and fix a parallel Hermitian scalar $\Phi_v^2=LI$. Then $P_*=P_{\Phi_v}=P_0+LI$. Write $X=\Phi^2/L$. Allow smooth scalar variations with bounded $P_\Phi-P_*$. Keep the native positive scalar heat weight $\eta$.

For $t>0$ define the tangent-subtracted heat trace, an operator comparison available in Paper II-A, theorem p2a:thm:v267-heat-bregman-converse,
$$
 B_t(P,P_*)=\operatorname{Tr}\big[e^{-tP}-e^{-tP_*}
                    +t e^{-tP_*}(P-P_*)\big].
$$
Previous analyses used this comparison at a single heat time. Replace the scalar-dependent part of the action on the present chart by
$$
 S_{\rm sc}=\eta\int_0^\infty Le^{-Lt}B_t(P_\Phi,P_*)\,dt
       +\eta d\,\operatorname{Tr}[e^{-P_0/L}p(X)],
 \qquad p(X)=\tfrac13(X-I)^2(X+2I),\quad d=1-\log 2 .
$$
The averaging density has mean $1/L$ and the corresponding Laplace transform is a resolvent. This is a choice of how to use the existing scale. The difference inside $B_t$ must be formed before integrating. In four dimensions Duhamel's second-order bound for a bounded operator difference is $O(t^2\operatorname{Tr}e^{-tP_*})=O(1)$ at zero. The positive operators and $e^{-Lt}$ control the large-time integral.

Trace convexity gives $B_t\ge0$. Also $p(X)\ge0$, and the positive geometric heat weight gives a nonnegative trace even when it does not commute with $X$. Both terms vanish at $\Phi_v$. Thus the reference is a **global scalar minimum at each fixed compatible metric**, including against smooth inhomogeneous matrix-field variations on this domain. Equality requires $X=I$ and $P_\Phi=P_*$, which gives parallel involutions on this Dirac chart. The radial value is unique; multiple orientations may realize it.

Along the same metric family, $S_{\rm sc}(g,\Phi_v)=0$ and $d_\Phi S_{\rm sc}(g,\Phi_v)=0$ for every $g$. Consequently the pure metric Hessian at the reference is that of the existing marked action, and the mixed scalar–metric Hessian vanishes in the chart with the reference carried fixed. Any stationary metric of the marked action that admits this family gives a stationary pair in the proposed metric–scalar sector. On a calibrated single-Einstein-pole branch the tensor exchange still gives $G_T=G_{\rm scal}$. The construction supplies no stationary solution for arbitrary occupied matter, untested boundaries or additional gauge backgrounds.

## The zero-field matching calculation

In flat space a constant scalar produces a heat density $C_0t^{-2}e^{-t s^2}$, with $A=C_0L^2$. Integration gives the following potential in units of $A$:
$$
 W(x)=(1+x)\log[(1+x)/2]-(x-1)
           +d\,(x-1)^2(x+2)/3 .
$$
The logarithmic term with its linear subtraction alone gives $W'(0)=-\log 2$. Among polynomials through degree three in $x$, the correction preserving value and slope at $1$ and curvature at $0$ is a multiple of $p(x)$. Matching the native $W'(0)=-1$ fixes $d=1-\log 2$. Then
$$
 W'(x)=\log[(1+x)/2]+d(x^2-1),\qquad
 W''(x)=(1+x)^{-1}+2dx>0 \quad(x\ge0).
$$
It follows that $W(1)=W'(1)=0$, $W''(1)>0$ and $W''(0)=1$. This preserves the coefficients of $h^2$ and $h^4$ at the origin. The higher material vertices and the energy difference between the origin and the minimum change. The numerical coefficient is fixed by the stated conditions; the averaging law and the minimal polynomial class are model choices. A positive multiple of $x^3(x-1)^2$, for example, passes all those local matching tests and changes the radial mass.

## Exact radial and tensor response on the flat chart

Set $q=k_E^2$, $u=q/L$. For a direct insertion $j\,\delta s$ at $s_*=\sqrt L$, the scalar inverse is $C_0LQ(u)$ with
$$
 Q(u)=(u+4)I(u)+8d,\qquad
 I(u)=\int_0^1\frac{dz}{2+z(1-z)u}.
$$
The two first variations of $P_\Phi$ yield the spin trace factor $q+4s_*^2$. The two flat heat kernels in the Duhamel integral give $e^{-t[s_*^2+z(1-z)q]}$ at time split $z$. The tangent subtraction cancels the term containing the second variation of $P_\Phi$. The exponential time average gives $I(u)$; the second derivative of $p(x)$ in the $s$ coordinate contributes $8d$. This uses the full flat momentum dependence. The old $Z=385$ came from the quartic action with its metric mixing and cannot be used for this new pole.

For $a=z(1-z)$, the derivative of $(u+4)/(2+au)$ is $(2-4a)/(2+au)^2$. Each such integrand sends the upper half-plane to the upper half-plane. $Q$ is strictly increasing above $-8$, with $Q(-4)>0$ and $Q(-8^+)=-\infty$, and cannot have nonreal zeros. Its inverse has one isolated particle pole below the continuum,
$$
 m_s^2=6.01860386576705\,L,\qquad
 1/Q'(-m_s^2/L)=0.507569375713676 .
$$
The $\delta s$ residue in the $q$ variable is this number divided by $C_0$. The rest of the spectrum starts at squared mass $8L$. With $w>8$, $\beta=\sqrt{1-8/w}$ and $b=2(1-4/w)/\beta$, its dimensionless density is
$$
 \rho(w)=\frac{b}{[8d+b\log((1+\beta)/(1-\beta))]^2+\pi^2 b^2}>0 .
$$
The cut dispersion integral $\int_8^\infty\rho(w)/(u+w)\,dw$ plus the isolated positive pole reconstructs $1/Q(u)$. The analytic argument uses the displayed half-plane sign and decay of $1/Q$ at infinity; a separate quadrature checks the density and residue. Positivity here concerns one exact Gaussian two-point function. The full quantum theory and higher correlators require more data.

For independently normalized direct scalar probes and conserved stresses the contributions on the neutral Einstein chart are consequently
$$
 \mathcal A_{12}(q)=\frac{T_1:T_2-T_1T_2/2}{2\nu q}
             +\frac{j_1j_2}{C_0LQ(q/L)},\qquad \nu=U/8 .
$$
The second term is finite at $q=0$. This verifies the preservation of the massless tensor residue on this branch. Identifying $j$ for actual material probes requires the material couplings of the same action.

## Physical mass and charged-source tests

In natural units the framework gives $G_{\rm scal}=1/(2\pi U)$ and $L=96\pi^2U$. If the common Newton calibration is physical, then $L=48\pi M_{\rm Pl}^2$ for the unreduced Planck mass $M_{\rm Pl}=1/\sqrt{G_N}$. The radial mass is therefore $30.1261\,M_{\rm Pl}$, about $3.68\times10^{20}$ GeV. This rules out identifying this pole directly with the measured roughly $125$ GeV Higgs. Paper V-B has a separate finite Higgs mass coordinate. Connecting it to a physical pole is a separate dynamical assertion. [CODATA, fundamental constants](https://physics.nist.gov/cuu/pdf/JPCRD2022CODATA.pdf) · [Particle Data Group, gauge and Higgs boson tables](https://pdg.lbl.gov/2024/download/db2024.pdf)

The ordinary unbroken gauge kernel for a probe commuting with the full-rank primitive mass has a multiplier $e^{-s^2/L}$ at fixed inputs on the positive single-heat chart. Stabilizing $s_*^2=L$ alone leaves a factor $1/e$ relative to the zero-field value if this ordinary gauge response is retained. Alternatively, taking a jointly varying charged reference and comparator can change the mixed scalar–gauge vertices. The neutral result cannot settle either physical charge normalization or Higgs couplings.

One explicit **local charged comparison** illustrates the difference. In a patch $h>0$ write the canonical doublet as $\sqrt2 H=hn$, $n^\dagger n=1$. Assign the proposed neutral functional to the radial coordinate and retain the original angular kinetic term $h^2|D n|^2/2$, independent gauge term and Yukawa mass term. At constant $h=v$, zero gauge field and constant orientation, the angular term has zero value and first variation; its mass derivative supplies a definite nonzero vector vertex. With no other mixing and canonical primitive $h$, $s=h/\sqrt{C_0}$, the normalized scalar pole overlap with that bare vertex is $\sqrt{0.5075693757}\simeq0.71244$. This is a choice of a charged effective action on the patch, not an identity for the original exact charged Dirac heat. Its vector poles, common scale, thresholds and global extension still require their own derivation.

## Negative controls and scope

- The simpler correction $A x^3/(3e)$ added to the single-time heat already makes $x=1$ a strict scalar minimum. Its normalized exact flat radial inverse is $8+(u+4)\int_0^1e^{-uz(1-z)}dz$. It tends to $10+12/u+O(u^{-2})$ on the positive axis. Consequently its inverse approaches its limiting constant from below, which is incompatible with a positive Stieltjes propagator plus a constant contact. An exact minimum and positive Euclidean Hessian did not suffice.
- The companion document derives the time-averaged comparison before the polynomial correction. That intermediate model has a positive spectrum but changes the flat zero-field mass coefficient. The correction calculated here fixes that mismatch.
- This is a research proposal with a proven stationary scalar configuration and testable neutral two-point response. The original metric adoption alone has no material term capable of making this repair. The absolute-mass comparison prevents claiming observational Higgs closure even in the amended model.

Primary source anchors are III-F p3f:def:v3041-adopted-metric-assembly, p3f:thm:v250-exact-parallel-scalar-heat and p3f:prop:v251-primitive-canonical-scalar-packet, II-A p2a:thm:v267-heat-bregman-converse, and III-G p3g:prop:v3041-centered-radial-pole. The verification archive contains the executable tests for the single-time negative control, the initial time-averaged comparison and the calibrated repair above. No constitutional theorem or physical particle identification is promoted.
