Current-source Newton physical projection review. Exact finite identities are not physical occurrence. Local lemmas are overlay-only.
