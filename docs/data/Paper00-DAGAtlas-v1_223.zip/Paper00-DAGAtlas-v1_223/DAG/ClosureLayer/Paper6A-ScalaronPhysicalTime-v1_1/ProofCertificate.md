# Paper VI-A — scoped mathematical closure: physical-time scalaron WKB normalization

**Issue:** `BH-VIA-G-0004`  
**Disposition:** `LOCAL_MATH_CLOSED` for the *historically challenged original corollary only*. The later WKB uses listed below have **not** been certified by this closure.  
**Source:** `Paper6A-GravityCosmology-v2_261.tex` (SHA-256 `b15dea7e84ed67596c77a658ca36e6cbb483b5318828bbd2c47f9594628cac1d`) inside `Paper00-PapersMinimal-v3_014(1).zip`; 17,460 source lines.  
**Prior audit:** `Paper6A-RigorousAuditBatch02-v1_2.md` on historical v2.253, `BH-VIA-G-0004`, original source span 4068–4116.  
**Current source anchors:** exact trace 4087–4119; corollary `p8:cor:lower-scalaron-matter-like-average` 4121–4141.  
**Proof scope:** physical-time frequency and dimensionless adiabatic controls; *not* global physical scalaron abundance, stopping or cosmological occurrence.

## 1. Original failure and source-matched correction

The audited `m_s^2=(F-R\chi)/(3\chi)` is a curvature-scale square with SI dimension `[length]^{-2}`. The linearized scalar trace has time derivative and restoring operator of the schematic form

\[
\ddot\phi+3H\dot\phi+c^2m_s^2\phi=0.
\]

The original `\dot\Theta=m_s`, `\epsilon_H=H/m_s`, `\epsilon_m=|\dot m_s|/m_s^2` are not physical-time formulas unless the dots and `H` are explicitly rewritten in length-time `x^0=ct`. The current Paper VI-A v2.261 corollary supplies the **correct physical-time** data:

\[
\boxed{\omega_s=c\,m_s,\quad
\epsilon_H=\frac{|H|}{c\,m_s},\quad
\epsilon_m=\frac{|\dot m_s|}{c\,m_s^2}.}
\]

It explicitly says that dots denote physical-time derivatives, `m_s` has inverse-length units, and retains local-well residence, WKB smoothness, and nonvanishing restoring curvature. Hence the *historical equation-level* mathematical issue is repaired without creating a new friction mechanism.

## 2. Independent mathematical verification

**Type check.** With `[H]=T^{-1}`, `[m_s]=L^{-1}`, `[\dot m_s]=L^{-1}T^{-1}` and `[c]=LT^{-1}`, all three displayed quantities have the required types: `[\omega_s]=T^{-1}`, `[\epsilon_H]=[\epsilon_m]=1`. The historical ratios in SI have unmatched dimensions.

**Exact constant-mass control.** When `H=0`, `\phi=\cos(cm_st)` exactly solves `\ddot\phi+c^2m_s^2\phi=0`; the old unqualified `\cos(m_st)` has residual `(c^2-1)m_s^2\cos(m_st)` when read with `c` as a formal factor. For constant `H` and `m_s`, the exact damped frequency is `\sqrt{c^2m_s^2-9H^2/4}`, so `cm_s` is the leading frequency in the protected adiabatic regime; it is not being claimed as an exact frequency for arbitrary `H`.

**General normal form.** Setting `u=a^{3/2}\phi` transforms the homogeneous linearized equation **exactly** to

\[
\ddot u+\left(c^2m_s^2-\tfrac32\dot H-\tfrac94H^2\right)u=0.
\]

The source requires the usual WKB smoothness; `\epsilon_H` and `\epsilon_m` alone are not asserted sufficient if `\dot H` or other higher derivatives are uncontrolled.

**Clock transformation.** For `x^0=ct`, `H_x=H_t/c`, `(dm_s/dx^0)=(\dot m_s)/c`. Thus the dimensionless natural-unit formulae `|H_x|/m_s` and `|dm_s/dx^0|/m_s^2` agree exactly with the corrected SI formulae. This uses no additional physical hypothesis.

**Check evidence.** `Paper6A-ScalaronTimeClosureChecks-v1_1.py` passes **27 exact/source/type test classes**, including the general normal form, and **400 randomized time-reparameterization cases**. The reproducible output is `Paper6A-ScalaronTimeClosureEvidence-v1_1.json`.

## 3. Explicit source-wide boundary (not discharged by this local closure)

The present manuscript also contains later statements using unsubscripted `\epsilon_m=|\dot m_s|/m_s^2` or `\epsilon_H=H/m_s`:

- `p8:cor:v2178-scalaron-coherent-envelope`, lines **8327–8351**, writes the ratios without `c`, but displays the physical-time equation with `c^2m_s^2` and a phase containing `cm_s`.
- `p8:cor:v2119-running-mass-diagnostic`, lines **10440–10485**, writes `|\dot m_s|/m_s^2` and its curvature-derivative formula in a locally stated WKB time convention. Its derivative identity `d(m_s^2)/dR=-F\chi_R/(3\chi^2)` is exact; the SI-time epsilon requires an extra `1/c` if dots mean physical-time derivatives.
- `D15`, lines **5772–5805**, is within an earlier section using `\hbar=c=1` for dimensionless gravitational calculations (stated near line 5630); its dimensionless numerical history should **not** be converted to SI just by inserting `c` in printed numbers. Its history data and claimed precision have not been independently replayed here.

These later uses require a **clock-convention reconciliation**: either explicitly use length-coordinate `x^0=ct` for all of their dots, or restore `c` consistently in the adiabatic ratios when using seconds. This certificate does not silently propagate `LOCAL_MATH_CLOSED` to the later corollaries, and does not assert that their WKB remainder, amplitude, numerical history or physical application has been verified.

For physical seconds, the correct running-mass diagnostic is

\[
\boxed{\epsilon_m^{\rm SI}=\frac{\sqrt3\,F|\chi_R|\,|\dot R|}{2c\sqrt\chi(F-R\chi)^{3/2}},\quad
\epsilon_{m,Q}^{\rm SI}=\frac{\sqrt3(\log\alpha)F|\chi_R|R|\dot Q_D|}{2c\sqrt\chi(F-R\chi)^{3/2}}.}
\]

This follows directly from `M=m_s^2=(F-R\chi)/(3\chi)` and `F_R=\chi`; it is a **derived normalization reconciliation**, not a new mass law.

## 4. Retained DAG guards / cross-paper impact

- The local-well, nonzero-restoring-curvature and smooth WKB hypotheses are **still required** (`BH-VIA-A-0005` in the historical audit).
- The exact nonperturbative force law, terminal susceptibility limit, and source-energy identity were never dependent on the malformed phase ratio and are unchanged.
- No proof that any actual cosmological solution traverses an adiabatic local well is supplied; K16 finite production, K48 cold matter and dark-energy occurrence remain conditional.
- `NEWTON_WHOLE_ACTION`, physical normalization of `U`, and `COSMO_OCCURRENCE` are not promoted.
- Older source-bound audit history and all other historical issues are preserved; only a *current scoped overlay* records this local mathematical closure.

**Verdict:** the historically challenged corollary is `LOCAL_MATH_CLOSED`; **global physical-time consistency across all later VI-A WKB uses remains unverified** and is an explicit residual scope gate.
