#!/usr/bin/env python3
"""Scoped E1/E2/E3/E4 verification of BH-VIA-G-0004 original WKB corollary.

Current paper VI-A v2.261 is immutable. Later unexamined WKB uses are
explicitly left outside this local closure. Requires sympy.
"""
from pathlib import Path
import json, hashlib, zipfile, random, math
import sympy as sp

P=Path('/mnt/data')
ARCH=P/'Paper00-PapersMinimal-v3_014(1).zip'
FILE='Paper6A-GravityCosmology-v2_261.tex'
OUT=P/'Paper6A-ScalaronTimeClosureEvidence-v1_1.json'
ISSUE='BH-VIA-G-0004'
SOURCE_SHA='b15dea7e84ed67596c77a658ca36e6cbb483b5318828bbd2c47f9594628cac1d'
checks=[]
def check(tag, truth, details=None):
    ok=bool(truth)
    checks.append({'id':tag,'passed':ok,'details':details})
    if not ok: raise AssertionError(f'{tag}: {details}')
with zipfile.ZipFile(ARCH) as z:
    check('E0-SOURCE-ZIP-CRC',z.testzip() is None)
    dat=z.read(FILE)
source=dat.decode()
lines=source.splitlines()
check('E0-SOURCE-SHA256',hashlib.sha256(dat).hexdigest()==SOURCE_SHA)
check('E0-SOURCE-LENGTH',len(lines)==17460)
block='\n'.join(lines[4120:4142]); oscillator='\n'.join(lines[4085:4119]);coherent='\n'.join(lines[8326:8351]);running='\n'.join(lines[10438:10486])
check('E1-LOCAL-COROLLARY-LABEL','\\label{p8:cor:lower-scalaron-matter-like-average}' in block)
check('E1-LOCAL-EPSILON-H','\\epsilon_H:=|H|/(c m_s)' in block)
check('E1-LOCAL-EPSILON-M','\\epsilon_m:=|\\dot m_s|/(c m_s^2)' in block)
check('E1-LOCAL-PHASE','\\dot\\Theta=\\omega_s(t)=c\\,m_s(t)' in block)
check('E1-LOCAL-PHYSICAL-TIME-SPECIFIED','dots denote physical-time derivatives' in block)
check('E1-LOCAL-WKB-REGULARITY','ordinary WKB smoothness' in block)
check('E1-NONLINEAR-TRACE-C2','\\ddot F+3H\\dot F+\\frac{c^2}{3}' in oscillator)
check('E1-LATER-COHERENT-MIXED-C','\\epsilon_H=H/m_s' in coherent and 'c^2m_s^2\\delta F' in coherent)
check('E1-LATER-RUNNING-DIAGNOSTIC-MISSING-C','\\epsilon_m:=\\frac{|\\dot m_s|}{m_s^2}' in running)

# Dimension bookkeeping (exponents (length, time)), with SI constants.
units={'c':(1,-1),'m_s':(-1,0),'H':(0,-1),'dot_m':(-1,-1),'omega_s':(0,-1)}
def mult(*objects):return tuple(map(sum, zip(*(units[o] for o in objects))))
check('E2-FREQUENCY-DIM',mult('c','m_s')==units['omega_s'])
check('E2-DAMPING-DIM',units['H']==(0,-1))
check('E2-EPS-H-DIM',mult('c','m_s')==units['H'])
check('E2-EPS-M-DIM',units['dot_m']==(units['c'][0]+2*units['m_s'][0],units['c'][1]+2*units['m_s'][1]))
check('E2-OLD-EPS-H-UNTYPED',units['H'] != units['m_s'])
check('E2-OLD-EPS-M-UNTYPED',units['dot_m']!=(-2,0))

# Independent exact equation, harmonic frequency, and time variable conversion.
t,c,m,H,phi=sp.symbols('t c m H phi', positive=True, real=True)
old_y=sp.cos(m*t); right_y=sp.cos(c*m*t)
check('E3-EXACT-CM-ODE',sp.simplify(sp.diff(right_y,t,2)+(c*m)**2*right_y)==0)
old_res=sp.trigsimp(sp.diff(old_y,t,2)+(c*m)**2*old_y)
check('E4-OLD-FREQUENCY-FAILS',sp.simplify(old_res-m*m*(c*c-1)*sp.cos(m*t))==0)
omega=sp.sqrt(c*c*m*m-sp.Rational(9,4)*H*H)
y=sp.exp(-sp.Rational(3,2)*H*t)*sp.cos(omega*t)
check('E3-DAMPED-EXACT-SOLUTION',sp.simplify(sp.diff(y,t,2)+3*H*sp.diff(y,t)+(c*m)**2*y)==0)
check('E3-DAMPED-WKB-FREQUENCY-ASYMPTOTIC',sp.limit(omega/(c*m),H,0)==1)
# For a time-dependent a(t), u=a^(3/2)phi has the exact effective frequency.
a=sp.Function('a')(t);u=sp.Function('u')(t);mass2=sp.Function('M2')(t)
phivar=u/a**sp.Rational(3,2);Hvar=sp.diff(a,t)/a
expr=sp.diff(phivar,t,2)+3*Hvar*sp.diff(phivar,t)+c*c*mass2*phivar
expected=sp.diff(u,t,2)+(c*c*mass2-sp.Rational(3,2)*sp.diff(Hvar,t)-sp.Rational(9,4)*Hvar**2)*u
check('E3-EXACT-LOCAL-WKB-NORMAL-FORM',sp.simplify(a**sp.Rational(3,2)*expr-expected)==0)
# source's exact derivative of squared mass is independent of time units.
R,F,chi,chi_R,dR=sp.symbols('R F chi chi_R dR', positive=True)
M=(F-R*chi)/(3*chi)
# derivative in chain F_R=chi, chi_R=chi_R
DM=sp.simplify(sp.diff(M,R)+sp.diff(M,F)*chi+sp.diff(M,chi)*chi_R)
check('E3-MASS-DERIVATIVE',sp.simplify(DM+F*chi_R/(3*chi**2))==0)
formal_eps=sp.simplify(sp.sqrt(3)*F*chi_R*dR/(2*c*sp.sqrt(chi)*(F-R*chi)**sp.Rational(3,2)))
through_M=sp.simplify(abs(1)*F*chi_R*dR/(6*chi**2*c*M**sp.Rational(3,2)))
check('E3-PHYSICAL-TIME-DIAGNOSTIC-CORRECTION',sp.simplify(formal_eps-through_M)==0)
# For R=C_6*alpha^(-Q), dot R=-(log alpha)*R*dot Q
C6,alpha,Q,dQ=sp.symbols('C6 alpha Q dQ', positive=True)
converted=sp.simplify(formal_eps.subs(dR,sp.log(alpha)*R*dQ))
check('E3-OCTET-CHAIN-RULE',sp.simplify(converted-formal_eps*sp.log(alpha)*R*dQ/dR)==0)

rng=random.Random(20261115)
stress=[]
for i in range(400):
    c0=10**rng.uniform(-2,3);m0=10**rng.uniform(-3,2);H0=10**rng.uniform(-8,-2)*(c0*m0)
    alpha0=10**rng.uniform(-7,-2)  # per-time rate for m=e^(alpha*t)
    t0=rng.uniform(-4,4)
    mass=m0*math.exp(alpha0*t0)
    omega_phys=c0*mass
    Hgeom=H0/c0
    epsH=abs(H0)/omega_phys
    epsm=abs(alpha0*mass)/(c0*mass*mass)
    dmass_dgeom=alpha0*mass/c0
    epsm_geo=abs(dmass_dgeom)/(mass**2)
    check_num=math.isclose(epsH,abs(Hgeom)/mass,rel_tol=1e-12) and math.isclose(epsm,epsm_geo,rel_tol=1e-12)
    if not check_num:raise AssertionError(f'time-change stress {i}')
    stress.append(check_num)
check('E3-400-RANDOM-TIME-UNIT-MEMBERS',all(stress),{'members':len(stress)})

result={
 'issue_id':ISSUE,'current_local_status':'LOCAL_MATH_CLOSED_ORIGINAL_COROLLARY_ONLY',
 'source_archive':ARCH.name,'source_file':FILE,'source_sha256':hashlib.sha256(dat).hexdigest(),
 'original_claim_source_lines':[4087,4141],
 'later_source_not_promoted':{'coherent_envelope_lines':[8327,8351], 'running_mass_diagnostic_lines':[10440,10485], 'historical_rank_two_lines':[5772,5805]},
 'checks':checks, 'test_count':len(checks), 'passed':sum(x['passed'] for x in checks),
 'random_time_reparam_cases':len(stress),
 'physical_time_normalization':{'omega':'c*m_s','eps_H':'abs(H)/(c*m_s)','eps_m':'abs(dm_s/dt)/(c*m_s^2)'},
 'later_formula_reconciliation':'NEEDED: downstream c=1 convention explicit or physically restore all c factors; no global WKB certification',
 'independent_impact':'no physical occurrence or dark-matter abundance conclusion',
}
assert result['passed']==result['test_count']
OUT.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(f"{ISSUE}: {len(checks)}/{len(checks)} exact+source+dimension classes passed; {len(stress)} random time-reparam tests. Later usage NOT certified.")
