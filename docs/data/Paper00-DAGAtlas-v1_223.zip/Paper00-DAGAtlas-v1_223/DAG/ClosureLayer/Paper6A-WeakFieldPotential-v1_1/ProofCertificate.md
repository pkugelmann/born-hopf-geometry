# Paper VI-A — scoped mathematical closure of BH-VIA-G-0005

**Certificate:** `Paper6A-WeakFieldPotentialClosure-v1_1.md`  
**Disposition:** `LOCAL_MATH_CLOSED` for the **historically challenged dimensional/normalization subclaim only**.  
**Source of record:** `Paper00-PapersMinimal-v3_014(1).zip`, `Paper6A-GravityCosmology-v2_261.tex`, SHA-256 `b15dea7e84ed67596c77a658ca36e6cbb483b5318828bbd2c47f9594628cac1d`.  
**Historical source:** Paper VI-A `v2_253`, historical audit `BH-VIA-G-0005` (`p8:thm:smooth-solar-system-screening-ppn`, original lines 4540–4573).  
**Current source anchors:** theorem lines **4563–4635**, metric potential equation `p8:eq:smooth-ppn-potentials` lines **4605–4614**, restricted PPN ratio `p8:eq:smooth-ppn-gamma` lines **4615–4626**, proof lines **4637–4676**.  
**Assessment:** targeted source repair and independent replay, not a source-wide theorem audit or physical Solar System prediction.

## 1. Exact challenged step and current resolution

The historical source defined the surface potential as `Phi_B = G M_B / (c^2 r_B)` (dimensionless), but juxtaposed `G M_B / (F_env r)` and `varrho_env r^2 / 24` in the same metric potential. In SI, the former has units L²/T², whereas the latter is dimensionless. Thus that particular expression was not a well-typed metric-potential equation.

The **current** theorem explicitly uses dimensionless Jordan-frame metric potentials

\[
\begin{aligned}
\Psi(r)&=-\frac{G M_B}{F_{\rm env}c^2 r}\left(1+\frac{\varepsilon_B(r)}3\right)-\frac{\varrho_{\rm env}r^2}{24},\\
\Phi(r)&=-\frac{G M_B}{F_{\rm env}c^2 r}\left(1-\frac{\varepsilon_B(r)}3\right)+\frac{\varrho_{\rm env}r^2}{24},
\end{aligned}
\]
with `F_env = F_{2|7}(varrho_env)` dimensionless, `varrho_env` a curvature L⁻², and `epsilon_B` a source fraction. These are the **existing, printed** current-source equations, not replacement source mathematics introduced during the audit.

## 2. Independent E2 dimensional proof

Using dimension vectors `(length, mass, physical seconds)`,

\[
[G]=(3,-1,-2),\quad [M_B]=(0,1,0),\quad [c]=(1,0,-1),\quad [r]=(1,0,0),
\quad [\varrho_{\rm env}]=(-2,0,0),\quad[F]=[\varepsilon_B]=(0,0,0).
\]

Therefore

\[
\left[\frac{GM_B}{F_{\rm env}c^2r}\right]=(0,0,0),\qquad
[\varrho_{\rm env}r^2]=(0,0,0).
\]

Multiplying both entire potentials by `c²` converts them to specific-energy potentials with identical SI dimension L²/T². Omitting the factor `c²` **only from the Newton term** produces the original invalid sum. No change to the background-curvature coefficient is needed to repair this dimensional inconsistency.

## 3. Independent E3 mathematical consequences, with explicit scope

Define `A(r)=GM_B/[F_env c² r]`, `B(r)=varrho_env r²`, and `e(r)=epsilon_B(r)`. Then `Psi=-A(1+e/3)-B/24` and `Phi=-A(1-e/3)+B/24`. Removing the non-`1/r` ambient curvature component before taking the ratio gives

\[
\gamma_{\rm PPN}^{(1/r)}=\frac{1-e/3}{1+e/3}
=\frac{3-e}{3+e},\qquad
\left|\gamma_{\rm PPN}^{(1/r)}-1\right|=\frac{2e}{3+e}
\le\frac{2e}{3-e}\quad(0\le e\le1).
\]

For `e=0`, the **`1/r`** sector has `gamma=1`, and when additionally `B=0`, both potentials reduce to the same dimensionless Newton potential. For `e=1`, `gamma=1/2`, the expected unscreened metric-`f(R)` 1/r comparison result. The sum of the two displayed full potentials is `-2A`, while their difference contains a `-B/12` contribution. Accordingly the ratio of the *full* potentials is **not** the restricted `1/r` `gamma` when `B != 0`. The current theorem states this distinction explicitly.

The `e` entering this formula is **not** determined by the thin-shell width proxy. The current theorem defines it conditionally through an action-owned positive radial source integral with Yukawa weight `sinh(ms)/(ms)`. Its hypothesis `0<=J_act<=J_uns` ensures a fraction between zero and one, if those physical sources actually exist as assumed. The independent mathematics of source positivity is not an unconditional physical-source existence proof.

## 4. E4 adversarial and numerical controls

- Historical counterexample: without `c²` in the Newton term, that term has dimensions L²/T² and cannot be added to the dimensionless ambient curvature term. This is independent of numerical values.
- Positive control: the current source restores `c²` exactly where required for dimensionless metric perturbations.
- Ambient-background counterexample: even with zero scalar charge, a nonzero `B` makes `Phi/Psi` differ from the restricted `1/r` ratio, so unrestricted full-ratio PPN identification would be invalid. The source *does not* make that stronger claim.
- Deterministic source-anchor, exact symbolic, dimension-vector, and conditionality checks: **42/42 passed**.
- SI numerical reconstructions from randomly chosen positive radii, masses, scalar fractions and signed small curvatures: **400/400 passed**, using a fixed reproducible random seed and the current `c` and `G` values merely as test constants. These tests check algebraic self-consistency, not observed Solar System constraints.

Reproduction: `Paper6A-WeakFieldPotentialClosureChecks-v1_1.py`; results: `Paper6A-WeakFieldPotentialClosureEvidence-v1_1.json`.

## 5. Exact DAG consequences, and explicit exclusions

**Close only:** `BH-VIA-G-0005` as a current-source repaired **local mathematical units/readout inconsistency**. Retain the original historical audit as an unmodified record of the older source error. Add a scoped current-disposition layer and link to the independent evidence.

**Not closed or promoted:**

1. `BH-VIA-G-0006`: actual action-owned radial source/unscreened comparison, Yukawa charge and thin-shell physical matching; the theorem's integral is a conditional definition, not source realization.
2. `BH-VIA-G-0014`: static acceleration source-owner Hessian and physical readout.
3. `NEWTON_WHOLE_ACTION`: physical normalization of the full gravitational and matter action; the `G` used in the weak-field comparison has not independently been identified with the native parameter by this check.
4. `COSMO_OCCURRENCE`, `BH-VIA-G-0013`, or other cosmic/strong-field realization gates.
5. Direct comparison to Cassini/ephemeris/laboratory bounds, selection of a physical environment `varrho_env`, or proof that a specific body is screened.
6. The complete theorem `p8:thm:smooth-solar-system-screening-ppn`, including construction of its action-owned source and scalar-to-metric matching, is **not** globally recertified by this dimensional closure.

`BH-VIA-A-0006` may be discharged **only as to its old convention/units objection**, not as to independent scalar-source or physical-owner hypotheses. No axiom, screening coefficient, inferred matter distribution, or new derived physical prediction is added.

## 6. Artifact provenance

The source paper is unchanged. The active ProofChainAudits report is updated by a prefixed scoped addendum, preserving its earlier content. The DAG gains an indexed closure certificate, typed evidence links and a **current scoped** disposition without overwriting the canonical historical proof claims or promoting whole-framework states. All previous seven scoped mathematical closures remain preserved.
