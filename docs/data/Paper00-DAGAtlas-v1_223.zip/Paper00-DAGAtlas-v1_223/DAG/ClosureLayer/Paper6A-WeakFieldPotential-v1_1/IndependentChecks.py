#!/usr/bin/env python3
"""Source-anchored scoped G-0005 PPN weak-field *dimensional* closure checks.

Does not verify the action-owned radial source, screen state, physical PPN value,
Newton whole-action matching, or occurrence of stable scalar backgrounds.
"""
from __future__ import annotations
import hashlib, json, math, random, re, zipfile
from pathlib import Path
import sympy as sp
P=Path('/mnt/data')
PAP=P/'Paper00-PapersMinimal-v3_014(1).zip'
SOURCE='Paper6A-GravityCosmology-v2_261.tex'
EXPECTED_SHA='b15dea7e84ed67596c77a658ca36e6cbb483b5318828bbd2c47f9594628cac1d'
AUD=P/'Paper00-ProofChainAudits-v1_61.zip'
EVID=P/'Paper6A-WeakFieldPotentialClosureEvidence-v1_1.json'
checks=[]
def record(tag, status, note=None):
    checks.append({'id':tag,'passed':bool(status),'note':note})
    if not status:raise AssertionError((tag,note))
with zipfile.ZipFile(PAP) as z:
    src_bytes=z.read(SOURCE);src=src_bytes.decode('utf-8');lines=src.splitlines()
source_sha=hashlib.sha256(src_bytes).hexdigest()
record('E0-source-exact-SHA',source_sha==EXPECTED_SHA,source_sha)
record('E0-source-long-enough',len(lines)>17000,len(lines))
with zipfile.ZipFile(AUD) as z:
    historical=z.read('Paper00-ProofChainAudits-v1_61/Paper6A-ProofChainAudit-v1_12.md').decode('utf-8')
record('E0-historical-original-objection','BH-VIA-G-0005' in historical)
start=src.index('\\label{p8:thm:smooth-solar-system-screening-ppn}')
end=src.index('\\end{theorem}',start)
thm=src[start:end]
proof_end=src.index('\\end{proof}',end)
proof=src[end:proof_end]
for k,token in enumerate([
 r'\Phi_B:=\frac{GM_B}{c^2r_B}',
 r'\varrho_{\rm env}\in\mathscr V_{2\mid7}',
 r'\label{p8:eq:smooth-screening-epsilon}',
 r'\frac{GM_B}{F(\varrho_{\rm env})c^2r}',
 r'-\frac{\varrho_{\rm env}r^2}{24}',
 r'+\frac{\varrho_{\rm env}r^2}{24}',
 r'\label{p8:eq:smooth-ppn-gamma}',
 r'\gamma_{\rm PPN}^{(1/r)}(r)',
 r'|\varrho_{\rm env}|r^2\ll1',
 ]):record('E1-source-theorem-token-%02d'%(k+1),token in thm,token)
for k,token in enumerate([
 'inside with action-owned right-hand',
 'spherical source',
 'provided',
 'boundary-excursion proxy',
 'not a proven',
 ]):record('E1-source-proof-guard-%02d'%(k+1),token in proof,token)
# Unit vectors (length, mass, physical seconds) for SI 
G=(3,-1,-2);M=(0,1,0);r=(1,0,0);c=(1,0,-1);rho=(-2,0,0);F=(0,0,0)
def mul(*vs):return tuple(sum(v[i] for v in vs) for i in range(3))
def pow_(v,n):return tuple(x*n for x in v)
newton=mul(G,M,pow_(c,-2),pow_(r,-1),pow_(F,-1))
ambient=mul(rho,pow_(r,2))
old_newton=mul(G,M,pow_(r,-1),pow_(F,-1))
record('E2-Newton-term-dimensionless',newton==(0,0,0),newton)
record('E2-background-term-dimensionless',ambient==(0,0,0),ambient)
record('E2-surface-potential-dimensionless',newton==(0,0,0))
record('E4-historical-mismatch-reproduced',old_newton==(2,0,-2) and old_newton!=ambient,old_newton)
record('E2-c2-phys-potential-same-SI',mul(newton,pow_(c,2))==mul(ambient,pow_(c,2))==(2,0,-2))
record('E2-mass-dimension-invariant',mul(rho,pow_(r,2))==(0,0,0))
# symbolic PPN 1/r ratio, difference, bounds and limiting regimes
A,eps,B=sp.symbols('A eps B', real=True); Fsym=sp.symbols('F',positive=True)
psi=-A*(1+eps/3)-B/24
phi=-A*(1-eps/3)+B/24
psis=-A*(1+eps/3)
phis=-A*(1-eps/3)
gamma=sp.simplify(phis/psis)
record('E3-gamma-from-1overr',sp.simplify(gamma-(3-eps)/(3+eps))==0)
record('E3-exact-gamma-residual',sp.simplify(gamma-1+2*eps/(3+eps))==0)
record('E3-upper-envelope-difference',sp.simplify(2*eps/(3-eps)-2*eps/(3+eps)-4*eps**2/(9-eps**2))==0)
record('E3-no-charge-gr-limit',sp.simplify(gamma.subs(eps,0)-1)==0)
record('E3-full-potentials-GR-when-epsBzero',sp.simplify(psi.subs({eps:0,B:0})+A)==0 and sp.simplify(phi.subs({eps:0,B:0})+A)==0)
record('E3-unscreened-PPN-limit',sp.simplify(gamma.subs(eps,1)-sp.Rational(1,2))==0)
record('E3-ambient-cancels-in-sum',sp.simplify(psi+phi+2*A)==0)
record('E3-background-does-not-cancel-in-difference',sp.simplify(psi-phi+2*A*eps/3+B/12)==0)
record('E4-full-potential-ratio-not-gamma',sp.simplify(phi/psi-gamma)!=0)
record('E3-slope-gamma-in-charge',sp.simplify(sp.diff(gamma,eps)+6/(3+eps)**2)==0)
# Exact positive Yukawa suppression for m >=0, r>=r_B on source interval
m,s,rr=sp.symbols('m s rr',positive=True)
record('E3-Yukawa-kernel-at-zero',sp.limit(sp.sinh(m*s)/(m*s),m,0)==1)
record('E3-Yukawa-positive-series',sp.simplify(sp.series(sp.sinh(m*s)/(m*s),m,0,6).removeO() - (1+m*m*s*s/6+m**4*s**4/120))==0)
# E4 explicit in-domain guard check that unrestricted full ratio can differ despite 1/r GR
full_ratio=sp.simplify((phi/psi).subs({eps:0,A:sp.Rational(1,1000),B:sp.Rational(1,100)}))
record('E4-background-no-full-ratio-identification',full_ratio != 1 and gamma.subs(eps,0)==1,str(full_ratio))
# Four hundred deterministic numeric controls: physical SI G,c and valid weak fields
rng=random.Random(20261115); stress=400; maxerr=0
G_SI=6.67430e-11;c_SI=299792458.
for k in range(stress):
    radius=10.**rng.uniform(5,13)
    aval=10.**rng.uniform(-10,-5)
    Bval=rng.uniform(-1,1)*10.**rng.uniform(-13,-7)
    fval=10.**rng.uniform(-.25,.25)
    epsval=rng.random()
    Mval=aval*c_SI**2*radius/G_SI
    Rval=Bval/radius**2
    Acalc=G_SI*Mval/(fval*c_SI**2*radius)
    Ps=-Acalc*(1+epsval/3)-Rval*radius**2/24
    Ph=-Acalc*(1-epsval/3)+Rval*radius**2/24
    ref_Ps=-aval/fval*(1+epsval/3)-Bval/24
    ref_Ph=-aval/fval*(1-epsval/3)+Bval/24
    gg=(1-epsval/3)/(1+epsval/3)
    target=(3-epsval)/(3+epsval)
    er=max(abs(Ps-ref_Ps),abs(Ph-ref_Ph),abs(gg-target))
    maxerr=max(maxerr,er)
    if not (er<2e-15 and abs(Ps)<1e-4 and abs(Ph)<1e-4 and 0<=epsval<=1 and 0<gg<=1 and abs(gg-1)<=2*epsval/(3-epsval)+1e-15):
        raise AssertionError(('E3-E4 randomized',k,er))
record('E3-SI-reconstruction-400-members',stress==400 and maxerr<2e-15,{'cases':stress,'max_absolute_error':maxerr})
record('E4-comparison-kinematics-guards', 'after separating the ambient' in thm and 'ratio of the full two potentials' in thm)
record('E4-action-owned-source-not-supplied-by-profile','conditional on the action-owned source' in thm)
record('E4-physical-GR-condition-not-certified','sufficient conditional GR-recovery' in thm)
record('E4-numerical-observation-separate','ephemeris and laboratory bounds remain downstream' in thm)
record('E4-distinct-charge-gap-G0006','it is \\emph{not} by itself the' in thm and 'integrated exterior scalar charge' in thm and 'can estimate a shell thickness' in thm)
result={
 'issue_id':'BH-VIA-G-0005','current_local_status':'LOCAL_MATH_CLOSED_HISTORICAL_DIMENSION_SCOPE',
 'source_file':SOURCE,'source_sha256':source_sha,'source_lines':{'theorem':[4563,4635],'potentials':[4605,4614],'scope':[4615,4634]},
 'passed':sum(c['passed'] for c in checks),'test_count':len(checks),
 'random_weak_field_cases':stress,'max_random_absolute_error':maxerr,
 'proof':'G*M/(F*c^2*r) dimensionless; R_env*r^2 dimensionless; c^2 multiplying both yields consistent m^2/s^2 physical potential',
 'not_promoted':['BH-VIA-G-0006','BH-VIA-G-0014','NEWTON_WHOLE_ACTION','COSMO_OCCURRENCE','action-owned Yukawa scalar source','observational solar-system limits','whole-paper PPN theorem verification'],
 'checks':checks,
}
EVID.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print('G-0005 scoped weak-field units:',result['passed'],'/',result['test_count'],'class checks; ',stress,'random cases. source=',source_sha)
