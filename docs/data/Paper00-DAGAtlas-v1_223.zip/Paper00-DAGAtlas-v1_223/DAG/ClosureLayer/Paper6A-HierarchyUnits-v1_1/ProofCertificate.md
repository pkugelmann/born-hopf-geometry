# Paper VI-A — `BH-VIA-G-0003` local hierarchy-units/readout closure certificate

**Certificate file:** `Paper6A-HierarchyUnitsClosure-v1_1.md`  
**Current source:** `Paper6A-GravityCosmology-v2_261.tex` in `Paper00-PapersMinimal-v3_014(1).zip`  
**Source SHA256:** `b15dea7e84ed67596c77a658ca36e6cbb483b5318828bbd2c47f9594628cac1d`  
**Earlier audited source:** `Paper6A-GravityCosmology-v2_253.tex`  
**Target issue:** `BH-VIA-G-0003` (`NORMALIZATION_OR_READOUT`, historical `MODERATE`)  
**New disposition:** **`LOCAL_MATH_CLOSED`**; no physical scale/action-owner promotion.

## 1. Claim and historical defect

The earlier VI-A table and figure attributed numerical curvature values (in m^-2) to the root wavenumber coordinate `\mathcal R_8` or `\mathcal R_{16}` (which must be in m^-1), confusing the root, raw curvature, and carrier-aligned Born midpoint. The current source explicitly distinguishes these coordinates in `p8:rem:v2211-hierarchy-units` (lines 2740–2764) and in the corrected `p8:fig:hierarchy_corrected` and `p8:tab:geometric-outputs` (lines 2766–2869 and 3040–3126).

### Typed mathematical proof

Let `U>0` have physical dimension L^-2, and `alpha>0` be dimensionless. On each integer shell K=8j, define

\[
\mathcal R_{8j}=\sqrt U\,\alpha^{-j/2},\qquad
C_{8j}=U\alpha^{-j},\qquad
C^B_{8j}=U\alpha^{-j/2},\qquad
\mathcal I_{8j}=U^2\alpha^{-j}.
\]

Then by positive functional calculus,

\[
\mathcal R_{8j}^2=C_{8j},\qquad
(C^B_{8j})^2=U C_{8j}=\mathcal I_{8j},\qquad
C^B_{8j}=\sqrt U\,\mathcal R_{8j},
\]

with units L^-1, L^-2, L^-2, L^-4 respectively. Distinct coordinates may have numerically coincident values (e.g. `C^B_16=C_8`), but they cannot be identified across different physical dimensions. Adjacent integer shells satisfy root and midpoint ratios `alpha^-1/2`, whereas raw curvature and action-density ratios are `alpha^-1`.

### Source number reconstruction

Use the source's printed 3-digit normalization `U=6.09e68 m^-2` and `alpha=exp(4pi^2+1/(6sqrt(2)))=1.571958279122504...e17`:

| Symbol | K=8 | K=16 | Unit |
|---|---:|---:|---|
| `\mathcal R_K` | `6.224265917700624e25` | `1.569884244782998e17` | m^-1 |
| `C_K` | `3.874148621424959e51` | `2.464536542017883e34` | m^-2 |
| `C^B_K` | `1.536019697285097e60` | `3.874148621424959e51` | m^-2 |

These agree with the current source's approximate figures `6.22e25`, `1.57e17` for roots and `1.54e60`, `3.87e51` for midpoints at their stated precision. Using an unrounded U calculated from standard c, hbar, and G changes some last displayed digits (e.g. root K=8 to `6.22558e25`); this is reference rounding, not an additional hierarchy parameter.

## 2. Independent evidence

**Executable:** `Paper6A-HierarchyUnitsClosureChecks-v1_1.py`  
**Evidence:** `Paper6A-HierarchyUnitsClosureEvidence-v1_1.json`.

- E0 source identity and E1 current-source label/code-point verification.
- E2 typed dimensions and analytic exponent identities.
- E3 exact relative identities across j=0..7, normalized table/figure numerical readouts and action-density relations.
- E4 counterfactual type conflation and 300 deterministic positive-scale parameter stress cases.
- **50/50 evidence classes pass; 300/300 parameter stress members pass.**

## 3. Strict scope and remaining conditions

`BH-VIA-G-0003` is closed **only** as a normalization/readout mismatch in the current source. The hierarchy symbols and their units now agree; no mathematical claim about physical action selection is inferred from this check. In particular:

1. The separate `U=(3/pi) K_p` same-action owner and the measured Newton coupling still require their independent source/physical normalization certificates (`CELL_{K->U}`, `NEWTON_WHOLE_ACTION`).
2. A typed physical event/observation at any rung requires its own source-to-observable constructor; dimensional consistency is not a proof of an actual physical history.
3. This certificate neither closes `BH-VIA-G-0014` (DtN-to-physical Schur/lapse acceleration) nor `BH-VIA-G-0013` (unreplayed black-hole numerical history).
4. Historical issue origin is preserved, and no canonical global theorem or physical status is promoted without a full source-matched review.

**DAG disposition:** append a namespaced *current-source mathematical closure* for `BH-VIA-G-0003` with an exact proof/evidence edge to the current remark, figure, and table. Keep the original audit issue and all physical guards visible.
