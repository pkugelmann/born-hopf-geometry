#!/usr/bin/env python3
"""E3/E4 scoped checks for BH-VIA-G-0003 on Paper VI-A v2.261.

No physical choice of U from geometry or measured G is certified here.
"""
from __future__ import annotations
import hashlib, json, math, random, zipfile
from pathlib import Path
import mpmath as mp

P=Path('/mnt/data')
SOURCE_ARCHIVE=P/'Paper00-PapersMinimal-v3_014(1).zip'
SOURCE='Paper6A-GravityCosmology-v2_261.tex'
OUT=P/'Paper6A-HierarchyUnitsClosureEvidence-v1_1.json'
mp.mp.dps=70
checks=[]
def check(name,ok,details=None):
    checks.append({'id':name,'passed':bool(ok),'details':details})
    if not ok:raise AssertionError((name,details))
with zipfile.ZipFile(SOURCE_ARCHIVE) as z:
    s=z.read(SOURCE)
    sha=hashlib.sha256(s).hexdigest()
    src=s.decode()
    lines=src.splitlines()
check('E0-SOURCE-ARCHIVE-CURRENT',len(lines)>3100 and sha=='b15dea7e84ed67596c77a658ca36e6cbb483b5318828bbd2c47f9594628cac1d',{'source_sha256':sha,'source_lines':len(lines)})
check('E1-SOURCE-ROOT-RAW-MIDPOINT-DEFINITIONS',all(x in src for x in ('\\label{p8:rem:v2211-hierarchy-units}','\\mathcal R_{8j}=\\sqrt U','C_{8j}=\\mathcal R_{8j}^{\\,2}','C^B_{8j}:=\\sqrt{UC_{8j}}')))
check('E1-SOURCE-FIGURE-TABLE-ROOT-LABELS',all(x in src for x in ('\\label{p8:tab:geometric-outputs}','\\mathcal R_8=\\sqrt U\\,\\alpha^{-1/2}','\\mathcal R_{16}=\\sqrt U\\,\\alpha^{-1}','6.22\\times10^{25}','1.57\\times10^{17}')))
check('E1-SOURCE-MIDPOINT-CLEAR-LABELS',all(x in src for x in ('1.54\\times10^{60}','3.87\\times10^{51}','\\mathrm m^{-2}')))
# Exponent arithmetic encodes the analytic identities for j=0..7
# U:[L^-2], alpha dimensionless; R:[L^-1], C:[L^-2], C_B:[L^-2], I:[L^-4]
for k,ex in {'U':-2,'alpha':0,'root':-1,'raw_curvature':-2,'born_midpoint':-2,'action_density':-4}.items():
    check('E2-DIMENSION-'+k.upper(),ex=={'U':-2,'alpha':0,'root':-1,'raw_curvature':-2,'born_midpoint':-2,'action_density':-4}[k])
check('E2-POWER-CONVERSION',abs(mp.power(2,-mp.mpf('0.5'))**2-mp.mpf('0.5'))<mp.mpf('1e-60'))
alpha=mp.exp(4*mp.pi**2+1/(6*mp.sqrt(2)))
U_source=mp.mpf('6.09e68') # THREE-significant-digit printed source normalization
c=mp.mpf('299792458')
hbar=mp.mpf('1.054571817e-34')
G=mp.mpf('6.67430e-11')
U_const=c**3/(2*mp.pi*hbar*G)
check('E3-CALCULATE-ALPHA',abs(alpha/mp.mpf('1.571958279122504e17')-1)<mp.mpf('2e-15'))
check('E3-TABLE-U-ROUNDING',abs(U_const/U_source-1)<mp.mpf('0.001'))

def quantities(u,j):
    r=mp.sqrt(u)*alpha**(-mp.mpf(j)/2)
    raw=u*alpha**(-j)
    born=u*alpha**(-mp.mpf(j)/2)
    den=u*raw
    return r,raw,born,den

for j in range(8):
    r,raw,born,den=quantities(U_source,j)
    check(f'E3-RUNG-{j}-ROOT-SQUARE',abs(r*r/raw-1)<mp.mpf('1e-60'))
    check(f'E3-RUNG-{j}-MIDPOINT-GEOMETRIC-MEAN',abs(born*born/den-1)<mp.mpf('1e-60'))
    check(f'E3-RUNG-{j}-MIDPOINT-ROOT-RATIO',abs(born/(r*mp.sqrt(U_source))-1)<mp.mpf('1e-60'))
    if j:
        r0,raw0,born0,den0=quantities(U_source,j-1)
        check(f'E3-RUNG-{j}-ADJACENT',max(abs(r/r0-alpha**(-mp.mpf(1)/2)),abs(raw/raw0-1/alpha),abs(born/born0-alpha**(-mp.mpf(1)/2)),abs(den/den0-1/alpha))<mp.mpf('1e-60'))
for j,root,midpoint in [(1,mp.mpf('6.22e25'),mp.mpf('1.54e60')),(2,mp.mpf('1.57e17'),mp.mpf('3.87e51'))]:
    r,raw,b,den=quantities(U_source,j)
    check(f'E3-PRINTED-ROOT-{j}',abs(r/root-1)<mp.mpf('0.001'),{'calculated':mp.nstr(r,17),'printed':mp.nstr(root,5)})
    check(f'E3-PRINTED-MIDPOINT-{j}',abs(b/midpoint-1)<mp.mpf('0.005'),{'calculated':mp.nstr(b,17),'printed':mp.nstr(midpoint,5)})
check('E4-COUNTERFACTUAL-EQUATING-TYPES',abs(quantities(U_source,1)[0]/quantities(U_source,1)[2]-1)>mp.mpf('0.9'))
# stress tests: no hidden normalization factors across positive U, alpha, all 7 rungs
rng=random.Random(64820003)
stress=300
for i in range(stress):
   uj=mp.mpf(10)**mp.mpf(rng.uniform(-12,70))
   a=mp.mpf(10)**mp.mpf(rng.uniform(-2,20))
   j=rng.randrange(0,8)
   r=mp.sqrt(uj)*a**(-mp.mpf(j)/2)
   raw=uj*a**(-j)
   b=uj*a**(-mp.mpf(j)/2)
   checkname=(abs(r*r/raw-1)<mp.mpf('1e-50') and abs((b*b)/(uj*raw)-1)<mp.mpf('1e-50'))
   if not checkname:raise AssertionError(('stress',i))
check('E4-300-PARAMETER-STRESS',True,{'parameter_cases':stress,'seed':64820003})
# Different physical export/normalization is deliberately not a result of this local algebra.
result={
 'issue_id':'BH-VIA-G-0003',
 'source':SOURCE,'source_sha256':sha,'source_archive':SOURCE_ARCHIVE.name,
 'source_locations':{'remark':[2740,2764],'figure':[2766,2869],'table':[3040,3126]},
 'status':'LOCAL_MATH_CLOSED','scope':'dimension and printed table/figure coordinates only; physical absolute U and empirical owners not certified',
 'tests':checks,'passed':sum(r['passed'] for r in checks),'test_count':len(checks),'stress_cases':stress,
 'alpha':mp.nstr(alpha,25),
 'U_from_printed_reference':mp.nstr(U_source,12),'U_from_reference_constants':mp.nstr(U_const,20),
 'j1':{'root':mp.nstr(quantities(U_source,1)[0],19),'raw':mp.nstr(quantities(U_source,1)[1],19),'midpoint':mp.nstr(quantities(U_source,1)[2],19)},
 'j2':{'root':mp.nstr(quantities(U_source,2)[0],19),'raw':mp.nstr(quantities(U_source,2)[1],19),'midpoint':mp.nstr(quantities(U_source,2)[2],19)},
 'rounding_note':'Reference values in the source are computed from rounded U=6.09e68; recomputing using G=6.67430e-11 gives small last-digit differences, not a type error.',
 'upstream_physical_normalization_still_conditional':True,'applied_to_G0014':False,
}
OUT.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(f"G0003: {result['passed']}/{result['test_count']} checks passed + {stress} stress members")
for k in ('j1','j2'):
 print(k,result[k])
