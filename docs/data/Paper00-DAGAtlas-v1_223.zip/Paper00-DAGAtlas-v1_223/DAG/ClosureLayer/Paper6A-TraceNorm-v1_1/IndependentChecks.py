#!/usr/bin/env python3
"""Independent finite-dimensional E3/E4 controls for BH-VIA-G-0010.

Targets Paper6A-GravityCosmology-v2_261.tex, lines 8591–8665.
No code result proves chart coverage, physical history or empirical threshold.
Runs self-contained with numpy only; outputs named JSON evidence in same directory.
"""
import json, math
from pathlib import Path
import numpy as np

OUT = Path(__file__).with_name('Paper6A-TraceNormClosureEvidence-v1_1.json')
rng = np.random.default_rng(20261115)
TOL = 5e-11
checks=[]

def check(name, passed, detail, n=1):
    checks.append({'name':name, 'passed':bool(passed), 'details':detail, 'cases':int(n)})
    assert passed, name + ': ' + str(detail)

def rho_from_w(w):
    v=w @ w.conj().T
    return v/np.trace(v)

def hermitian(n):
    z=rng.normal(size=(n,n))+1j*rng.normal(size=(n,n))
    return (z+z.conj().T)/2

def norm2(x):
    return float(np.linalg.norm(x,2))

def rownorm(x):
    return float(np.max(np.sum(np.abs(x),axis=1)))

# E4: historic incorrect comparison must remain demonstrably FALSE.
H=np.array([[1,1],[1,-1]],complex)/math.sqrt(2)
check('E4-old-B_le_K-false-Hadamard',abs(norm2(H)-1)<TOL and abs(rownorm(H)-math.sqrt(2))<TOL and rownorm(H)>norm2(H)+0.3,
      {'spectral_norm':norm2(H),'max_abs_row_sum':rownorm(H),'K_single_word':1})
# A non-Hermitian operator cannot inherit the single-basis row inequality by this proof.
NON=np.array([[1.,0.],[1.,0.]])
check('E4-Hermitian-domain-essential',abs(rownorm(NON)-1)<TOL and abs(norm2(NON)-math.sqrt(2))<TOL,
      {'matrix':NON.tolist(),'spectral_norm':norm2(NON),'max_abs_row_sum':rownorm(NON)})

# E3: row route, word route and positive trace-one state, all same sample q.
row_count=word_count=state_count=0
worst={'row':0,'word':0,'state':0,'full':0}
for n in [2,3,4,5,7]:
    for _ in range(80):
        # The same retained chart at q; arbitrary Hermitian complete insertions.
        A=hermitian(n); B=hermitian(n)
        state=rho_from_w(rng.normal(size=(n,n))+1j*rng.normal(size=(n,n)))
        n0=float(rng.uniform(0.01,2)); v0=float(rng.uniform(0.02,2))
        n_q=n0+float(rng.uniform(0,3)); v_q=v0+float(rng.uniform(0,3))
        U=float(rng.uniform(0.1,7)); kappa=float(rng.uniform(0.1,7))
        th=(A+B/n_q)/v_q
        s=kappa*np.trace(state@th).real/(3*U)
        bnd_row=kappa/(3*U*v0)*(rownorm(A)+rownorm(B)/n0)
        if norm2(A)>rownorm(A)+TOL or norm2(B)>rownorm(B)+TOL:
            raise AssertionError('Hermitian row norm domination failed')
        row_count+=1; worst['row']=max(worst['row'],norm2(A)-rownorm(A),norm2(B)-rownorm(B))
        check_state=(abs(s)<=bnd_row+TOL and abs(np.trace(state@th).imag)<TOL)
        if not check_state: raise AssertionError('state/row trace bound failed')
        state_count+=1; worst['state']=max(worst['state'],abs(s)-bnd_row)
        # Word route: explicit coefficients and individual Hermitian words;
        # representation A = c1 W1 + c2 W2.
        c1=complex(rng.normal(),rng.normal());c2=complex(rng.normal(),rng.normal())
        W1=hermitian(n); W2=(A-c1*W1)/c2
        # W2 may not be Hermitian individually; it needs only bounded norm.
        K_A=abs(c1)*norm2(W1)+abs(c2)*norm2(W2)
        K_B=norm2(B) # single word
        bnd_word=kappa/(3*U*v0)*(K_A+K_B/n0)
        if norm2(A)>K_A+TOL or abs(s)>bnd_word+TOL:
            raise AssertionError('word route failed')
        word_count+=1; worst['word']=max(worst['word'],norm2(A)-K_A)
        worst['full']=max(worst['full'],abs(s)-min(bnd_row,bnd_word))
check('E3-Hermitian-row-route',row_count==400,{'matrix_dimensions':[2,3,4,5,7],'seed':20261115,'worst_violation':worst['row']},row_count)
check('E3-positive-state-full-trace-route',state_count==400,{'worst_violation':worst['state'],'tested_noncommuting_sources':True},state_count)
check('E3-independent-word-operator-route',word_count==400,{'worst_violation':worst['word']},word_count)

# E3: local frame rotation may enlarge row bound but never invalidates it.
U0=hermitian(4)
Q,_=np.linalg.qr(rng.normal(size=(4,4))+1j*rng.normal(size=(4,4)))
rot=Q.conj().T@U0@Q
check('E3-local-unitary-frame-domain',abs(norm2(rot)-norm2(U0))<TOL and norm2(U0)<=min(rownorm(U0),rownorm(rot))+TOL,
      {'operator_norm_invariant':norm2(U0),'row_original':rownorm(U0),'row_rotated':rownorm(rot)})

# E3: normalized two-mode CAR operators are contractions.
# One-mode a = |0><1| ; a_1 = a \otimes I ; a_2 = Z \otimes a.
a=np.array([[0,1],[0,0]],complex); Z=np.diag([1,-1]);I=np.eye(2)
a1=np.kron(a,I);a2=np.kron(Z,a)
ident=np.eye(4)
for i,ai in enumerate((a1,a2)):
    check(f'E3-CAR-mode-{i+1}',norm2(ai)<=1+TOL and
          np.allclose(ai.conj().T@ai + ai@ai.conj().T,ident),
          {'annihilation_norm':norm2(ai),'CAR_anticonmutator_identity':True})
for left,right in [(a1,a2),(a1.conj().T,a2),(a2.conj().T,a1),(a2,a1.conj().T)]:
    check('E3-CAR-monomial-contraction',norm2(left@right)<=1+TOL,{'norm':norm2(left@right)})

# E4: bosonic truncated annihilator has norm sqrt(n-1), not a CAR contraction.
n=5
b=np.zeros((n,n),complex)
for k in range(1,n):b[k-1,k]=math.sqrt(k)
check('E4-boson-contact-unbounded-growth-guard',abs(norm2(b)-2)<TOL,
      {'finite_n':5,'bosonic_norm':norm2(b),'CAR_bound_1_not_transferable':True})

# E3: positive trace-one hypothesis is essential to a uniform one-operator bound.
sigma=np.diag([2.,-1.]);A2=np.diag([1.,-1.])
check('E4-nonpositive-normalized-state-not-licensed',abs(np.trace(sigma)-1)<TOL and
      abs(np.trace(sigma@A2))>norm2(A2),
      {'state_min_eigenvalue':-1,'expectation':float(np.trace(sigma@A2).real),'norm':norm2(A2)})

report={'issue':'BH-VIA-G-0010','claim':'p8:prop:v2188-trace-coefficient-certificate',
        'authoritative_source':'Paper6A-GravityCosmology-v2_261.tex:8591-8665',
        'verdict':'PASS_SCOPE_LOCAL_MATH_ONLY',
        'tests':checks,'all_passed':all(c['passed'] for c in checks),
        'random_cases':row_count, 'note':'Finite matrix checks and adversarial counterexamples only; no physical chart, numerical 1e18 ceiling, or source trajectory certified.'}
OUT.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'all_passed':report['all_passed'],'test_classes':len(checks),
                  'random_case_count':row_count,'evidence_file':str(OUT)},indent=2))
