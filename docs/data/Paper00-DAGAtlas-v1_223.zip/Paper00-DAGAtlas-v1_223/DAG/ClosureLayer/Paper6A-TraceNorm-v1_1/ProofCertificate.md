# Born–Hopf Geometry VI-A — closure certificate for `BH-VIA-G-0010`

**Artifact:** `Paper6A-TraceNormClosure-v1_1.md`  
**Verdict:** **CLOSED WITHIN CLAIMED MATHEMATICAL SCOPE** for the historical norm-comparison defect; **physical first-K48 execution remains OPEN**.  
**Current source:** `Paper6A-GravityCosmology-v2_261.tex`, SHA256 `b15dea7e84ed67596c77a658ca36e6cbb483b5318828bbd2c47f9594628cac1d`, current `.tex` lines **8591–8665**.  
**Exact target:** `p8:prop:v2188-trace-coefficient-certificate` (finite row-sum and normalized-word bounds).  
**Older issue origin:** `BH-VIA-G-0010`, VI-A v2.253 lines 8531–8559, recorded as `INCORRECT_STEP / NORMALIZATION_OR_READOUT`, `MODERATE`, `OPEN` in the historical VI-A audit layer.  
**Protocol discipline:** Claim-matched source check and independent finite-dimensional proof, not a global Paper VI-A re-audit and not a physical history construction.

## A. Original gap certificate and claim actually under review

**Old invalid edge:** with \(B_a\) the supremum of *maximum absolute row sums*, the old proposition inferred \(B_a\le\sup\sum_\alpha |c_{a\alpha}| b_{a\alpha}\) from \(\|W_{a\alpha}\|_2\le b_{a\alpha}\). Spectral/operator-norm information does not bound the row sum in this direction.

**Exact in-domain counterexample:** the Hermitian word
\[
H=2^{-1/2}\begin{pmatrix}1&1\\1&-1\end{pmatrix}
\]
obeys \(\|H\|_2=1\) but \(\|H\|_{\infty,\mathrm{row}}=\sqrt2\). It can occupy a singleton compact chart with positive \(N,\mathcal V\). Thus the old comparison fails even for a single normalized Hermitian word with \(c=1,b=1\). The counterexample is retained; it is not discarded by reinterpreting the original bound.

**Current repaired statement (v2.261, 8591–8665):** The manuscript explicitly distinguishes a row-sum certificate \(B_a\) from an independent operator/word certificate \(K_a\), and states **no** \(B_a\le K_a\) relation. The sourced observable/claim is a *state-uniform sufficient bound* on the complete finite ordinary stress-trace insertion, **not** actual numerical attainment of the first-K48 comparison threshold.

## B. Exact imported proof chain checked

1. `p8:prop:v2185-c06-e6-functional-ports`: the complete homogeneous source insertion includes **all** field, connection, projector, derivative, central and remainder contacts. The trace has the specified finite source expectation form, not a partial source.
2. `p8:prop:v2186-c06-finite-trace-norm-route` (VI-A 8512–8555): on the actual retained finite carrier,
   \[
   \widehat\Theta(q)=\mathcal V(q)^{-1}(\mathcal O_N(q)+N(q)^{-1}\mathcal O_\xi(q)),\qquad
   \mathcal S_T(q)=\frac\kappa3\operatorname{Tr}(\sigma(q)\widehat\Theta(q)).
   \]
   Source state \(\sigma(q)\) is positive trace-one; \(N,\mathcal V>0\); \(U>0\).
3. `p8:prop:v2188-trace-coefficient-certificate` (VI-A 8591–8665): retain **complete Hermitian** insertions on a compact chart \(\mathscr C\), \(N(q)\ge N_0>0\), \(\mathcal V(q)\ge V_0>0\), and a finite local orthonormal-frame cover. Separate alternative routes: \(B_N,B_\xi\) from matrix row sums, or \(K_N,K_\xi\) from a fully specified bounded finite word expansion.
4. `p8:cor:v2185-c06-first-k48-split` and `p8:prop:v2189-c06-one-sided-first-hit`: if the resulting bound separately meets the **already established, same-domain** stopping inequality, finite transverse first-K48 reach follows under that comparison's regularity/trajectory assumptions. No unconditional reach is imported into this certificate.

## C. Independent analytic proof

Fix \(q\in\mathscr C\). For a finite Hermitian matrix \(A\), take an eigenpair \(Ax=\lambda x\) with \(|\lambda|=\|A\|_2\) and a component \(i\) of maximal \(|x_i|>0\). Then
\[
|\lambda|\,|x_i|\le\sum_j |A_{ij}|\,|x_j|\le
 \left(\max_k\sum_j |A_{kj}|\right)|x_i|,
\]
so, in **every** selected orthonormal frame,
\[
\|A\|_2\le b_A(q):=\max_i\sum_j |A_{ij}(q)|.
\]
For any density \(\sigma\succeq0\) with \(\operatorname{Tr}\sigma=1\), spectral decomposition and convexity give \(|\operatorname{Tr}(\sigma A)|\le\|A\|_2\). Thus, since \(N^{-1}\le N_0^{-1}\), \(\mathcal V^{-1}\le V_0^{-1}\),
\[
\begin{aligned}
\left|\frac{\mathcal S_T(q)}{U}\right|&\le\frac{\kappa}{3U\mathcal V(q)}\bigl(\|\mathcal O_N(q)\|_2+N(q)^{-1}\|\mathcal O_\xi(q)\|_2\bigr)\\
&\le\frac{\kappa}{3UV_0}\left(B_N+\frac{B_\xi}{N_0}\right).
\end{aligned}
\]
The bound is uniform in \(q\) and in all positive trace-one states. The finite cover's frame selection cannot invalidate it because the inequality holds in every frame; the bound uses the maximum where several frames overlap.

For the **independent word route**, suppose the *complete* insertion has a specified finite expansion \(\mathcal O_a(q)=\sum_\alpha c_{a\alpha}(q)W_{a\alpha}(q)\), with \(\|W_{a\alpha}(q)\|_2\le b_{a\alpha}(q)\). Triangle inequality yields
\[
\|\mathcal O_a(q)\|_2\le\sum_\alpha|c_{a\alpha}(q)|b_{a\alpha}(q)\le K_a.
\]
Substitution in the *first* line of the preceding bound yields
\[
\boxed{\left|\frac{\mathcal S_T}{U}\right|\le\frac{\kappa}{3UV_0}\left(K_N+\frac{K_\xi}{N_0}\right).}
\]
No step compares \(B_a\) and \(K_a\). In a normalized **finite CAR** representation \(a_i^\dagger a_i\) and \(a_i a_i^\dagger\) are projections, so \(\|a_i\|=\|a_i^\dagger\|\le1\); submultiplicativity gives norm \(\le1\) for every monomial. This assertion is not transferred to truncated/unbounded bosonic source words.

**Result:** Both claimed inequalities are proved under the source's *existing* finite Hermitian, positive-state, compact chart and complete-insertion hypotheses. The specific old missing condition `BH-VIA-A-0013` (row-sum certificates for each word) is not required for the **new operator-norm route**; it remains as historical explanation of why the former route failed, not as a newly proved physical input.

## D. Independent E3 / E4 verification

Executable `Paper6A-TraceNormClosureChecks-v1_1.py`, producing `Paper6A-TraceNormClosureEvidence-v1_1.json`, passed **14 test classes** (including 400 reproducible random complete-insertion/state samples over dimensions 2,3,4,5,7): both norm routes, positive state expectations, unitary frame invariance, explicit 2-mode CAR contracts; adversarial controls retain the old Hadamard failure, a non-Hermitian row-norm failure, a non-positive trace-one pseudo-state failure, and the failure of the CAR norm-one shortcut for bosonic truncated annihilators. Numerical tests are corroboration of—not substitutes for—the analytic proof above.

## E. Precise disposition / effects on DAG

| Object | Effective disposition | Why |
|---|---|---|
| Historical `BH-VIA-G-0010` invalid edge in VI-A v2.253 | Retained as valid **historical counterexample** | Old assertion \(B_a\le K_a\) is false and remains false |
| Current `p8:prop:v2188-trace-coefficient-certificate`, v2.261 | **LOCAL_MATH_CLOSED** | Two *independent* source-printed sufficient bounds, fully proved above |
| Historical auxiliary `BH-VIA-A-0013` | **NOT CONSUMED BY REPAIRED WORD ROUTE** | Missing row-norm bound is no longer required for operator-norm estimate |
| Actual physical trace operator/contacts and \(N_0,V_0,\mathscr C\) | **OPEN_APPLICATION** | Need fully specified physical owner and bound evaluated on actual coupled chart |
| Actual \(\kappa M_\Theta/(3U)\le10^{18}\) or sharper signed first-hit comparison | **OPEN_APPLICATION** | No numerical sup or same-action trajectory certified |
| `NEWTON_WHOLE_ACTION`, `COSMO_OCCURRENCE`, terminal stopping/late de-Sitter history | **UNCHANGED / OPEN** | This proof supplies only a finite-state source-bound mechanism |

No current paper edit is necessary: the repaired statement is already in the supplied `.tex`. This is a **claim-specific re-audit and mathematical issue closure**, not a global whole-paper claim promotion, and it does **not** change the predicted dark-energy value or imply its physical realization.
