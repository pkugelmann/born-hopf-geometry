#!/usr/bin/env python3
"""Independent E1/E2/E3/E4 replay of BH-VIA-G-0006's historical factor-three defect.

Scope: conditional radial Green/Yukawa integration and source-fraction mathematics,
NOT source-state occurrence, scalar-to-metric normalization, or Solar-System tests.
Reads Paper VI-A from the supplied frozen PapersMinimal archive.
"""
from __future__ import annotations
import json, hashlib, zipfile, math, random
from pathlib import Path
import sympy as S
import mpmath as mp
P=Path('/mnt/data')
ARCH=P/'Paper00-PapersMinimal-v3_014(1).zip'
SRC='Paper6A-GravityCosmology-v2_261.tex'
EXPECTED_SHA='b15dea7e84ed67596c77a658ca36e6cbb483b5318828bbd2c47f9594628cac1d'
OUT=P/'Paper6A-ThinShellChargeClosureEvidence-v1_1.json'
mp.mp.dps=60
checks=[]
def chk(name,test,extra=None):
    passed=bool(test)
    checks.append(dict(id=name,passed=passed,details=extra))
    if not passed: raise AssertionError(f'{name} :: {extra}')
with zipfile.ZipFile(ARCH) as z:
    chk('E0-ARCHIVE-CRC',z.testzip() is None)
    source_bytes=z.read(SRC)
    sh=hashlib.sha256(source_bytes).hexdigest();src=source_bytes.decode()
    chk('E0-EXACT-CURRENT-SOURCE-SHA',sh==EXPECTED_SHA,sh)
    numbered=src.splitlines()
    chk('E1-THIN-SHELL-THEOREM-LABEL',r'\label{p8:thm:smooth-solar-system-screening-ppn}' in src)
    chk('E1-ACTION-OWNED-GUARD',r'\mathcal J_{\rm act}' in src and r'\mathcal J_{\rm uns}' in src)
    chk('E1-YUKAWA-EQUATION',r'\frac{\sinh(ms)}{ms}' in src)
    chk('E1-SHELL-EXACT-SOURCE',r'1-\left(1-\frac{\Delta r}{r_B}\right)^3' in src)
    chk('E1-OLD-PROXY-REJECTED','integrated exterior scalar charge' in src and 'not a proven' in src)
    chk('E1-METRIC-MATCHING-CONDITIONAL','provided' in '\n'.join(numbered[4666:4675]))
    chk('E1-ACTION-TRACE-SOURCE',r'\label{p8:eq:v251-scalaron-force-potential}' in src and r'\label{p8:eq:v251-exact-nonlinear-scalaron-equation}' in src)
R, d, a, m, x, s, J, c, kappa=S.symbols('R d a m x s J c kappa',positive=True)
U=S.symbols('U',positive=True)
H=lambda y:y*S.cosh(y)-S.sinh(y)
weight=S.sinh(m*s)/(m*s)
primitive=(m*s*S.cosh(m*s)-S.sinh(m*s))/m**3
chk('E2-WEIGHT-PRIMITIVE',S.simplify(S.diff(primitive,s)-s**2*weight)==0)
volume_all=S.integrate(s**2,(s,0,R))
volume_shell=S.integrate(s**2,(s,R*(1-d),R))
q0=S.factor(volume_shell/volume_all)
chk('E2-MASSLESS-EXACT',S.simplify(q0-(1-(1-d)**3))==0)
chk('E2-THIN-SHELL-FACTOR-THREE',S.simplify(S.diff(q0,d).subs(d,0)-3)==0)
chk('E2-FINITE-SHELL-EXACT',S.simplify((primitive.subs(s,R)-primitive.subs(s,R*(1-d)))/primitive.subs(s,R) - (1-H((1-d)*m*R)/H(m*R)))==0)
chk('E2-H-LOW-MASS-SERIES',S.series(H(x),x,0,7).removeO()==x**3/S.Integer(3)+x**5/S.Integer(30))
chk('E2-MASSLESS-LIMIT',S.simplify(S.limit(1-H((1-d)*x)/H(x),x,0)-q0)==0)
chk('E2-D-THIN-LIMIT',S.simplify(S.limit((1-H((1-d)*x)/H(x))/d,d,0)-x**2*S.sinh(x)/H(x))==0)
chk('E2-D-THIN-LOW-MASS-LIMIT',S.limit(x**2*S.sinh(x)/H(x),x,0)==3)
chk('E2-YUKAWA-OUTSIDE-ODE',S.simplify((S.diff(S.exp(-m*s)/s,s,2)+2/s*S.diff(S.exp(-m*s)/s,s)-m**2*S.exp(-m*s)/s).expand())==0)
chk('E2-SURFACE-FORM-FACTOR',S.simplify(3*S.exp(-x)*H(x)/x**3 -3*S.exp(-x)*(x*S.cosh(x)-S.sinh(x))/x**3)==0)
chk('E2-SURFACE-FORM-FACTOR-MASSLESS',S.limit(3*S.exp(-x)*H(x)/x**3,x,0)==1)
chk('E4-SURFACE-FORM-FACTOR-X1',S.simplify((3*S.exp(-x)*H(x)/x**3).subs(x,1)-3*S.exp(-2))==0)
# Same-action trace relation is formal: J_eff=-kappa*deltaT/3 - nonlinear W remainder/c².
F0,y=S.symbols('F0 y',real=True)
W0,W1,W2,W3=S.symbols('W0 W1 W2 W3',real=True)
Wprime=W1+W2*(y-F0)+W3*(y-F0)**2/2
nl=S.simplify(Wprime-W1-W2*(y-F0))
chk('E2-TRACE-NONLINEAR-REMAINDER',S.simplify(nl-W3*(y-F0)**2/2)==0)
chk('E2-TRACE-LINEAR-MASS-IDENTITY',S.simplify((W2/c**2)*(y-F0)-W2*(y-F0)/c**2)==0)
# Explicit counterexample: identical center-surface scalar excursion but differing exterior charge.
# m=0 source functions J_1=A, J_2=(10 A/3)(s/R)^2, J_uns=10 A/3.
A=S.symbols('A',positive=True)
j1=A;j2=10*A*s**2/(3*R**2);juns=10*A/3
D=lambda f:S.integrate(f*(s-s**2/R),(s,0,R))
Q=lambda f:S.integrate(f*s**2,(s,0,R))
chk('E4-IDENTICAL-BOUNDARY-EXCURSION',S.simplify(D(j1)-D(j2))==0)
chk('E4-EXCURSION-CORRECT',S.simplify(D(j1)-A*R**2/6)==0)
chk('E4-DIFFERENT-CHARGES',S.simplify(Q(j1)-A*R**3/3)==0 and S.simplify(Q(j2)-2*A*R**3/3)==0)
chk('E4-BOUNDARY-Q1',S.simplify(Q(j1)/Q(juns)-S.Rational(3,10))==0)
chk('E4-BOUNDARY-Q2',S.simplify(Q(j2)/Q(juns)-S.Rational(3,5))==0)
chk('E4-SOURCE-ORDER',S.simplify(juns-j1)>0 and S.simplify((juns-j2).subs(s,R))==0)
# Direct numeric radial integration of Green function, random positive source kernels
rng=random.Random(101115); random_cases=300; q_cases=300; surface_cases=100
max_error=mp.mpf('0')
for _ in range(random_cases):
    rr=mp.mpf(str(10**rng.uniform(-1,1))); mm=mp.mpf(str(10**rng.uniform(-2,1)));p=mp.mpf(str(rng.uniform(.3,2)))
    frac=mp.mpf(str(rng.uniform(0,1)))
    # smooth source act=frac * uns, uns ~ 1+(s/R)^2
    fn=lambda t: t**2*(1+(t/rr)**2)*mp.sinh(mm*t)/(mm*t)
    den=mp.quad(fn,[0,rr]);num=frac*mp.quad(fn,[0,rr])
    ratio=num/den
    err=abs(ratio-frac);max_error=max(max_error,err)
    if err>mp.mpf('1e-48'):raise AssertionError(('positive radial source integral',err))
chk('E3-RADIAL-POSITIVE-SOURCE-CASES',True,f'{random_cases} cases max absolute err={mp.nstr(max_error,6)}')
for _ in range(q_cases):
    xx=mp.mpf(str(10**rng.uniform(-3,2))); dd=mp.mpf(str(rng.uniform(0.00001,.95)))
    h=lambda z:z*mp.cosh(z)-mp.sinh(z)
    # stable numerical quadrature for small x and small d, to avoid subtraction of H values
    direct=mp.quad(lambda t:t**2*mp.sinh(xx*t)/(xx*t),[1-dd,1])/mp.quad(lambda t:t**2*mp.sinh(xx*t)/(xx*t),[0,1])
    closed=1-h(xx*(1-dd))/h(xx)
    if abs(direct-closed)>mp.mpf('5e-48'):raise AssertionError(('Yukawa exact shell',xx,dd,abs(direct-closed)))
    if not (mp.mpf('0')<closed<mp.mpf('1')):raise AssertionError('not a charge fraction')
    qzero=1-(1-dd)**3
    if closed+mp.mpf('1e-48')<qzero:raise AssertionError(('finite mass must weight shell more',xx,dd))
chk('E3-FINITE-MASS-SHELL-REPLAY',True,f'{q_cases} exact-vs-direct high precision cases')
for _ in range(surface_cases):
    xx=mp.mpf(str(10**rng.uniform(-2,2)))
    aa=3*mp.exp(-xx)*(xx*mp.cosh(xx)-mp.sinh(xx))/xx**3
    aa2=3*mp.exp(-xx)*mp.quad(lambda t:t**2*mp.sinh(xx*t)/(xx*t),[0,1])
    if abs(aa-aa2)>mp.mpf('5e-48') or not 0<aa<1:raise AssertionError(('finite size matching factor',xx,aa,aa2))
chk('E3-YUKAWA-SURFACE-FACTOR-REPLAY',True,f'{surface_cases} cases')
check_count=len(checks)
obj={
 'issue_id':'BH-VIA-G-0006','status':'HISTORICAL_INTEGRATION_MATH_CLOSED__PHYSICAL_OWNER_OPEN',
 'source_archive':ARCH.name,'source_file':SRC,'source_sha256':sh,
 'source_span':[4563,4676], 'source_labels':['p8:thm:smooth-solar-system-screening-ppn','p8:eq:smooth-screening-epsilon'],
 'passed':sum(1 for c1 in checks if c1['passed']),'test_count':check_count,'checks':checks,
 'randomized_positive_source_cases':random_cases,'randomized_finite_mass_shell_cases':q_cases,'randomized_yukawa_surface_factor_cases':surface_cases,
 'exact_massless_q':'1-(1-d)^3=3d-3d^2+d^3',
 'finite_mass_q':'1-[x(1-d)cosh(x(1-d))-sinh(x(1-d))]/[x cosh(x)-sinh(x)]',
 'uniform_unscreened_reference_form_factor':'A(x)=3 exp(-x)[x cosh(x)-sinh(x)]/x^3',
 'finite_size_witness':'A(1)=3 exp(-2) != 1',
 'same_boundary_excursion_counterexample':'at m=0, J1=A, J2=(10A/3)(r/R)^2, Juns=10A/3 have D1=D2=A R^2/6 but q1=0.3 and q2=0.6',
 'formal_action_owned_raw_trace_source':'J_eff= -kappa deltaT/3-[Wprime(F)-Wprime(Fenv)-Wdoubleprime(Fenv) deltaF]/c^2 on static weak-field patch',
 'not_proved':['actual finite matter Hilbert trace profile','source positivity/order for the selected on-shell background','linearized canonical scalar normalization','finite-size Yukawa reference-to-Newton amplitude matching','physical screening existence','ephemeris constraints','NEWTON_WHOLE_ACTION','COSMO_OCCURRENCE']
}
OUT.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
print('PASS',check_count,'E1/E2/E3/E4 classes +',random_cases+q_cases+surface_cases,'numerical cases; historical factor-three math repaired; physical owner open')
