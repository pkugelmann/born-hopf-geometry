# Paper VI-A — `BH-VIA-G-0006` historical thin-shell charge integration: scoped mathematical closure

**Certificate:** `Paper6A-ThinShellChargeClosure-v1_1.md`  
**Target source:** `Paper00-PapersMinimal-v3_014(1).zip` → `Paper6A-GravityCosmology-v2_261.tex`  
**Source SHA-256:** `b15dea7e84ed67596c77a658ca36e6cbb483b5318828bbd2c47f9594628cac1d`  
**Current anchor:** `p8:thm:smooth-solar-system-screening-ppn`, lines 4563–4676; `p8:eq:smooth-screening-epsilon`, lines 4590–4604; proof, lines 4637–4676.  
**Original audited issue:** `BH-VIA-G-0006`, in source `Paper6A-GravityCosmology-v2_253.tex`, with factor-of-three counterexample for identifying a shell-width proxy with the exterior scalar charge.  
**Verification:** `Paper6A-ThinShellChargeClosureChecks-v1_1.py`, evidence `Paper6A-ThinShellChargeClosureEvidence-v1_1.json`.  
**Disposition:** **The historical source *integration/charge-factor defect* is mathematically closed within the current paper's conditional linearized radial-source domain. The physical action-owned body/source realization and scalar-to-metric reference normalization remain OPEN.** This is *not* a full `p8:thm:smooth-solar-system-screening-ppn` physical verification.

## 1. Exact failure and repaired source statement

The original proof conflated a boundary excursion / fractional shell thickness

\[\vartheta_B=\frac{|F(\varrho_{\rm env})-F(\varrho_{\rm in})|}{2\Phi_B}\]

with the **integrated exterior scalar charge**, incorrectly suppressing its leading shell-mass factor. For a uniform-density sphere of radius \(R=r_B\) with active shell thickness \(\Delta=dR\), the active source fraction at \(m=0\) is

\[
q_B(0)=\frac{\int_{R-\Delta}^{R}s^2 J_0\,ds}{\int_0^Rs^2J_0\,ds}
=1-(1-d)^3=3d-3d^2+d^3.
\]

Therefore \(q_B\sim3d\), not \(d\). Since the universal metric-\(f(R)\) scalar coupling is \(2\beta^2=1/3\), the leading **potential** correction is \(q_B/3\sim d\), subject to the explicit exterior scalar-to-metric normalization. Current v2.261 **does not** identify \(q_B\) with \(\vartheta_B\); the old factor-of-three step has been replaced by an action-sourced radial source fraction.

## 2. Green-kernel derivation (E2/E3)

Consider the stated regular spherical scalar equation on the weak-field domain

\[(\nabla^2-m^2)\phi=-\mathcal J,\quad m\ge0,\qquad \mathcal J\ge0\quad\text{supported in }[0,R].\]

With the decaying exterior condition, the fundamental Yukawa kernel is \(G_m(x,y)=e^{-m|x-y|}/(4\pi|x-y|)\). Its radial angular integration gives exactly

\[
\phi(r)=\frac{e^{-mr}}{r}\int_0^R s^2\mathcal J(s)\frac{\sinh(ms)}{ms}\,ds,\qquad r\ge R,
\]

where \(\sinh(ms)/(ms)\to1\) at \(m=0\). On the source's stated comparison class \(0\le\mathcal J_{\rm act}\le\mathcal J_{\rm uns}\), with the unscreened integral strictly positive, the **source-fraction ratio**

\[
q_B^{\rm act}(m)=\frac{\int_0^R s^2\mathcal J_{\rm act}(s)w_m(s)ds}{\int_0^R s^2\mathcal J_{\rm uns}(s)w_m(s)ds},\quad w_m(s)=\frac{\sinh(ms)}{ms},
\]

satisfies \(0\le q_B^{\rm act}\le1\) without introducing a fitted charge coefficient. The positivity conclusion is an *if-the-sources-exist* theorem, not a derivation of the actual source state.

### Exact arbitrary-mass shell formula — additional deduction

For a common positive constant source \(J_0\), with \(\mathcal J_{\rm act}=J_0\mathbf1_{[R-\Delta,R]}\) and \(\mathcal J_{\rm uns}=J_0\mathbf1_{[0,R]}\), put \(x=mR\) and \(d=\Delta/R\). Since

\[
\int s^2\frac{\sinh(ms)}{ms}\,ds=\frac{ms\cosh(ms)-\sinh(ms)}{m^3},
\]

we get, exactly for \(x>0\),

\[
\boxed{q_B(x,d)=1-\frac{x(1-d)\cosh[x(1-d)]-\sinh[x(1-d)]}{x\cosh x-\sinh x}.}
\]

Its \(x\to0\) limit is precisely \(1-(1-d)^3\); for \(d\downarrow0\) at fixed \(x>0\),

\[
q_B(x,d)=d\frac{x^2\sinh x}{x\cosh x-\sinh x}+O(d^2),
\]

whose coefficient tends to 3 as \(x\to0\). The Yukawa weight increases with radius (because \(x\cosh x-\sinh x>0\) for \(x>0\)), so a fixed outer shell gets at least its massless fraction: \(q_B(x,d)\ge1-(1-d)^3\), with strict inequality for \(x,d>0\) and \(d<1\). For \(d=0.01\), \(q_B(0,d)=0.029701\) and \(q_B(1,d)=0.03157775256\ldots\).

## 3. Formal same-action trace owner (conditional analytic strengthening)

The paper already defines \(F=f_R\), \(\mathcal W'(F)=c^2[2f-FR]/3\), and the metric-\(f(R)\) trace equation. On a static weak-field patch, subtracting an on-shell constant exterior environment from

\[3\Box F+FR-2f=\kappa T\]

and using \(m^2=\mathcal W''(F_{\rm env})/c^2\) yields the exact formal identity in that approximation

\[
(\nabla^2-m^2)\delta F=-\mathcal J_{\rm eff},\qquad
\boxed{\mathcal J_{\rm eff}=-\frac{\kappa}{3}\delta T-\frac{1}{c^2}\left[\mathcal W'(F)-\mathcal W'(F_{\rm env})-\mathcal W''(F_{\rm env})\delta F\right].}
\]

Here \(T\) must be the *actual same-action Hilbert trace* and \(\delta F=F-F_{\rm env}\). This identifies a canonical **formal source expression** without adding an independent scalar-charge parameter. The nonlinear remainder cannot be dropped for a physically screened interior unless the relevant linearization and bounds are proved. In particular, \(\mathcal J_{\rm eff}\ge0\), \(\mathcal J_{\rm eff}\le\mathcal J_{\rm uns}\), regularity and the actual matter-body solution do not follow from the formal identity. Nor does this identity alone normalize the canonical scalar \(\phi\) used in the displayed PPN potentials.

## 4. E4 controls: boundary proxy is noninjective; finite-size Yukawa matching is nonautomatic

**Endpoint-counterexample in the same radial PDE class (\(m=0\)).** Set \(R>0\), \(A>0\), with \(\mathcal J_{\rm uns}=10A/3\), and compare

\[\mathcal J_1(r)=A,\qquad \mathcal J_2(r)=\frac{10A}{3}\left(\frac rR\right)^2,\quad 0\le r\le R.\]

Both satisfy \(0\le\mathcal J_i\le\mathcal J_{\rm uns}\). For the regular decaying Poisson solution, the center-to-surface scalar excursion is

\[\phi(0)-\phi(R)=\int_0^R\mathcal J(s)\left(s-\frac{s^2}{R}\right)ds.\]

It is **identically \(AR^2/6\)** for both, yet the normalized exterior charges are

\[q_1=\frac{3}{10},\qquad q_2=\frac35.\]

Thus, even in an admissible regular nonnegative radial-source class, the same boundary excursion cannot determine the integrated charge without an additional physical profile/owner certificate. This is a logical diagnostic; it is **not** a purported pair of exact Born–Hopf material-body solutions.

**Finite-size normalization.** For a uniform unscreened sphere of radius \(R\), normalized by its zero-mass integrated source, the Yukawa exterior strength compared to a point-source Newton coefficient has an extra surface factor

\[\boxed{A(x)=\frac{3e^{-x}[x\cosh x-\sinh x]}{x^3},\quad x=mR.}\]

In particular \(A(0)=1\), but \(A(1)=3e^{-2}\approx0.4060058497\ne1\). Therefore the source-fraction ratio \(q_B^{\rm act}\) does *not*, by itself, show that the potential correction relative to \(GM_B/(F_{\rm env}c^2r)\) has the displayed coefficient \(q_B^{\rm act}e^{-m(r-R)}\) for an arbitrary finite-radius reference. The current paper explicitly conditions the PPN step on the **same-action exterior scalar-to-metric normalization** (lines 4668–4675); this condition remains necessary. The finite-size factor is a derived diagnostic, not an inserted phenomenological coefficient.

## 5. DAG disposition

| Exact consumption | Status | Why |
|---|---|---|
| Old shell-width-to-charge factor | **LOCAL_MATH_CLOSED** | Current exact radial integral gives leading \(q_B=3d\) |
| Finite-m Green fraction and positivity bound | **VERIFIED within stated source class** | Kernel integration, \(0\le J_{\rm act}\le J_{\rm uns}\) |
| Explicit action-trace source operator | **FORMALLY DERIVED, CONDITIONAL** | Trace variation supplies operator expression; no on-shell body source supplied |
| Source fraction → metric correction amplitude | **OPEN PHYSICAL MATCHING** | Actual reference and finite-size normalization required |
| Actual screened body / environment solution | **OPEN PHYSICAL OCCURRENCE** | Same-action Hilbert trace and solved radial field not identified |
| Measured \(\gamma_{\rm PPN}\) / Newton parameter | **OPEN OBSERVABLE** | `NEWTON_WHOLE_ACTION` and ephemeris comparisons remain independent |

**Audit registry instruction:** Record a scoped mathematical closure of the *historical integration defect* for `BH-VIA-G-0006`, but preserve the **same-ID physical-source/metric-matching subobligation** as explicitly open; do not label the complete theorem, physical screening or all of `G-0006` unconditionally closed. Preserve earlier eight scoped mathematical fixes; retain `BH-VIA-G-0013`, `BH-VIA-G-0014`, `NEWTON_WHOLE_ACTION`, and `COSMO_OCCURRENCE` open.

## 6. Reproducibility

The supplied checker verifies source-file SHA and source anchors; exact Yukawa primitive, Green outside ODE, massless and finite-m shell fractions, small-m and thin-shell limits, raw trace algebra, positivity cases, unequal-charge/same-excursion counterexample, and finite-radius reference factor. It executes **32 passing source/symbolic/adversarial check classes and 700 numeric cases**. These are mathematical tests, not physical measurements or a source-state realization. Original TeX and source archive are unmodified.
