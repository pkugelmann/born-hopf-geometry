# Paper VI-A — scoped vacuum-density normalization closure (G-0008)

**Artifact:** `Paper6A-VacuumNormalizationClosure-v1_1.md`  
**Source of truth:** `Paper00-PapersMinimal-v3_014(1).zip`, `Paper6A-GravityCosmology-v2_261.tex` SHA256 `b15dea7e84ed67596c77a658ca36e6cbb483b5318828bbd2c47f9594628cac1d`.  
**Historical audit:** `Paper00-ProofChainAudits-v1_57.zip`, `Paper6A-ProofChainAudit-v1_8.md` (`BH-VIA-G-0008`, historical v2.253 line 7187-7192).  
**Precise current source:** `p8:eq:hs-lambda-infty`, lines 7260–7270; prior native coefficients lines 604, 5636, 6293, 6481, 13145; action reference at 13145.  
**Result:** **LOCAL_MATH_CLOSED** *for the exact native gravitational-density normalization and its H1/H2 conditional usage*. The old numerical/typographical mismatch has been corrected **in the existing source**. No physical normalization or occurrence status is changed.

## Precise question

The former horizon branch printed a density proportional to `C56/(2 κ²)` while earlier defining the native coupling `κ=M^-2`. With the same symbol and coefficient, this would disagree with `ρ_Λ=M² C56/2`. The source-corrected equation uses the unambiguous `κ_grav=M^-2` and `ρ_∞=C56/(2 κ_grav)`.

## Proof from the owned terminal affine action

Work in the paper's natural-unit convention. For the active affine Einstein representative, write

\[
 S_{\rm grav}={M^2\over2}\int \sqrt{-g}\,[R_g-C_{56}]\,d^4x,
 \quad M^2>0,\quad \kappa_{\rm grav}=M^{-2},\quad C_{56}>0.
\]

For an arbitrary compactly supported inverse-metric variation, suppressing boundary terms,

\[
 \delta S_{\rm grav}={1\over2}\int\sqrt{-g}\,
 \Big[M^2G_{\mu\nu}+{M^2C_{56}\over2}g_{\mu\nu}\Big]\delta g^{\mu\nu}d^4x.
\]

Use the source-paper stress convention `δS_m = -½∫√(-g) T_μν δg^{μν}`. Stationarity yields

\[
 G_{\mu\nu}+{C_{56}\over2}g_{\mu\nu}=M^{-2}T_{\mu\nu}
 =\kappa_{\rm grav}T_{\mu\nu}.
\]

Writing `T^Λ_μν = -ρ_Λ g_μν` in the form `G=κ_grav(T+T^Λ)` fixes

\[
 \boxed{\Lambda_\infty=C_{56}/2,\quad
 \rho_\infty=\Lambda_\infty/\kappa_{\rm grav}
 ={M^2C_{56}\over2}={U C_{56}\over8}}.
\]

The last equality uses the paper's **already defined** `M²=U/4` on this branch; it does not establish the absolute SI calibration of `U` or the physical whole-action identification. If an independent writer denotes the *same coupling* by `κ_conv²`, then `C56/(2 κ_conv²)` is valid **only when** `κ_conv²=κ_grav`; treating the paper's `κ_grav` as that symbol and squaring it again is invalid. The historical expression would differ by a factor `M²`.

## Independent checks and adversarial control

`Paper6A-VacuumNormalizationClosureChecks-v1_1.py` / `Paper6A-VacuumNormalizationClosureEvidence-v1_1.json`: 21 named checks pass, including exact symbolic action/coupling identities and wrong-square counteridentity, current-source quotation existence, independent input ZIP and script inventory, 300 wide-scale positive-`M,C` numerical checks and a source-packet underdetermination example used only for **G-0013**. The proof is algebraic; random tests are regressions, not a substitute.

## DAG interface and dispositions

- **CLOSED locally:** `BH-VIA-G-0008` at the `p8:eq:hs-lambda-infty` normalization step, for the active affine action and source convention. Historic v2.253 issue remains in archival provenance.
- The historic inference condition `BH-VIA-A-0011` is not consumed by the repaired native expression. The alternate conventional symbol is a notational alias, not a distinct physical coupling.
- **Still conditional:** (H1) marginal-sphere selector and (H2) minimal bilinear interface for the *time-dependent horizon-supported response*. This local density coefficient does not prove either. Full physical `NEWTON_WHOLE_ACTION`, common-source absolute SI normalization, action selection, `COSMO_OCCURRENCE`, first-K48 stopping and black-hole collapse realization remain open.
- **Not closed:** `BH-VIA-G-0013` numerical black-hole witness; see `Paper6A-BlackHoleNumericalReplayGate-v1_1.md` for the separate missing-data certificate.
- **No new premise or observational fit:** the repair invokes only the already-constituted action coefficient, its metric variation and the stress convention.
- **No whole-paper re-audit:** independent source-specific local verification only. Preserved prior closures `BH-VIA-G-0010/0011/0012`; all others remain as before.
