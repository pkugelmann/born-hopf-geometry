#!/usr/bin/env python3
"""Source-matched local G-0008 mathematical check and G-0013 evidence-gate checks.
No historical numerical BH trajectory is reconstructed or claimed verified.
"""
import hashlib, json, math, random, zipfile
from pathlib import Path
import sympy as sp

ROOT=Path('/mnt/data')
PAPERS=ROOT/'Paper00-PapersMinimal-v3_014(1).zip'
ATLAS=ROOT/'Paper00-DAGAtlas-v1_142.zip'
AUDITS=ROOT/'Paper00-ProofChainAudits-v1_57.zip'
SOURCE='Paper6A-GravityCosmology-v2_261.tex'
APPENDIX='Paper6C-TechnicalMaterial-v1_51.tex'
ROOT_EVIDENCE=ROOT/'Paper6A-VacuumNormalizationClosureEvidence-v1_1.json'
checks=[]
def check(n, ok, detail=''):
    checks.append({'name':n,'passed':bool(ok),'detail':str(detail)})
    if not ok: raise AssertionError(f'{n}: {detail}')

M,C=sp.symbols('M C',positive=True,real=True)
k=1/M**2
Lambda=C/2
rho=Lambda/k
check('algebra_absolute_density',sp.simplify(rho - M**2*C/2)==0)
check('coupling_identity',sp.simplify(k*rho-Lambda)==0)
check('curvature_density_formula',sp.simplify((C/(2*k))/(M**2*C/2)-1)==0)
check('native_M_squared_equals_U_over_four',sp.simplify((sp.symbols('U')/4)*C/2-sp.symbols('U')*C/8)==0)
check('wrong_square_is_not_identity',sp.simplify(C/(2*k*k)-rho)!=0)
check('wrong_square_factor',sp.simplify((C/(2*k*k))/rho -M**2)==0)

with zipfile.ZipFile(PAPERS) as z:
    src=z.read(SOURCE)
    ap=z.read(APPENDIX)
    check('paper_source_and_appendix_present',bool(src) and bool(ap))
    code=src.decode(); app=ap.decode()
    check('corrected_horizon_vacuum_equation_present',r'\rho_\infty=\frac{C_{56}}{2\kappa_{\rm grav}}' in code)
    check('corrected_native_coupling_declared',r'\kappa_{\rm grav}:=M^{-2}' in code)
    check('explicit_native_Einstein_coefficient',r'M^2=U/4' in code)
    check('affine_terminal_action_present',r'M^2(R_g-C)/2' in code or r'\frac{M^2}{2}(R_g-C)' in code)
    check('BH_reference_scripts_cited_in_source',all(f'Paper00-BlackHoleRegulationChecks-v1\\_{i}.py' in app for i in (9,10,11)))
    check('BH_reference_json_cited_in_source',r'Paper00-BlackHoleRegulationChecks-v1\_12.json' in app)
    s_sha=hashlib.sha256(src).hexdigest(); a_sha=hashlib.sha256(ap).hexdigest()

ref=[f'Paper00-BlackHoleRegulationChecks-v1_{i}.py' for i in (9,10,11,12)]+['Paper00-BlackHoleRegulationChecks-v1_12.json']
missing={}
for f in [PAPERS,ATLAS,AUDITS]:
    with zipfile.ZipFile(f) as z:
        names=z.namelist()
        matches=[name for name in names if any(name.endswith(r) for r in ref)]
        missing[f.name]=matches
        check(f'BH_executables_absent_in_{f.name}',len(matches)==0, 'No supplied historical executable/JSON bytes')

# Test only source-data underdetermination, NOT compatibility with full Cauchy/constraint packet.
pz=sp.Rational(1,100);pom=sp.Integer(1);mass=sp.Integer(1)
d=sp.Matrix([pz,pom,mass]);w=sp.Matrix([2*pz,pom,mass])
s1=sp.Matrix([0,1,0]);s2=d/sp.sqrt(d.dot(d))
check('both_Bloch_initializations_unit',sp.simplify(s1.dot(s1)-1)==0 and sp.simplify(s2.dot(s2)-1)==0)
check('both_finite_initial_source_energies_positive',d.dot(s1)>0 and float(d.dot(s2))>0)
h1=sp.simplify(2*w.dot(s1));h2=sp.simplify(2*w.dot(s2))
check('same_printed_k_nu_mu_allow_distinct_enthalpy',float(abs(h1-h2))>0.5,(str(h1),str(h2)))
check('same_printed_k_nu_mu_allow_distinct_source_energy',float(abs(2*d.dot(s1)-2*d.dot(s2)))>0.5)

rng=random.Random(20261115)
for _ in range(300):
    mm=10**rng.uniform(-5,5)
    cc=10**rng.uniform(-10,10)
    native=mm*mm*cc/2
    by_k=cc/(2*(mm**-2))
    if not math.isclose(native,by_k,rel_tol=1e-12,abs_tol=0):
        raise AssertionError('Numeric action-to-coupling mismatch')
check('300_numeric_M_and_C_cases',True)

out={
 'target_math_issue':'BH-VIA-G-0008',
 'math_status':'LOCAL_MATH_CLOSED_ON_CURRENT_SOURCE',
 'still_open_numerical_issue':'BH-VIA-G-0013',
 'BH_numerical_status':'OPEN_EVIDENCE_MISSING',
 'source_archive':PAPERS.name,
 'source_file':SOURCE,
 'source_sha256':s_sha,
 'appendix_file':APPENDIX,
 'appendix_sha256':a_sha,
 'all_passed':all(c['passed'] for c in checks),
 'test_class_count':len(checks),
 'random_numeric_cases':300,
 'missing_executables':ref,
 'searches_performed':missing,
 'Bloch_pair_example':{'w_dot_both_s1':str(h1),'w_dot_both_s2':str(h2),'w_dot_both_s2_approx':float(h2),'note':'Shows numerical seed not fixed by three printed constants; not evidence that either seed satisfies complete source/metric constraints'},
 'verified_action_algebra':'S=(M^2/2) ∫ sqrt(-g) (R-C) -> G+(C/2)g=M^-2 T; rho_vac=M^2 C/2=C/(2 kappa_grav)',
 'physical_action_owner':'NOT_PROVED_BY_LOCAL_NORMALIZATION',
 'checks':checks,
}
ROOT_EVIDENCE.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:out[k] for k in ['target_math_issue','math_status','still_open_numerical_issue','BH_numerical_status','test_class_count','random_numeric_cases','all_passed','source_sha256']},indent=2))
