#!/usr/bin/env python3
"""Independent, scoped checks for BH-VIA-G-0011 in current Paper VI-A.

This proves no physical occurrence or global tensor observable. It verifies
specified local conformal/clock identities and reproduces old counterexample.
"""
from __future__ import annotations
import hashlib, json, math, random, zipfile
from pathlib import Path
import sympy as sp

ROOT=Path(__file__).resolve().parent
PAPERS=ROOT/'Paper00-PapersMinimal-v3_014(1).zip'
ATLAS=ROOT/'Paper00-DAGAtlas-v1_140.zip'
OUT=ROOT/'Paper6A-ConformalFrameClosureEvidence-v1_1.json'
SOURCE='Paper6A-GravityCosmology-v2_261.tex'
EXPECTED='b15dea7e84ed67596c77a658ca36e6cbb483b5318828bbd2c47f9594628cac1d'
checks=[]
def check(name, predicate, details=None):
    ok=bool(predicate)
    checks.append({'check':name,'passed':ok,'details':details})
    if not ok: raise AssertionError(f'FAILED: {name}: {details}')

with zipfile.ZipFile(PAPERS) as z:
    raw=z.read(SOURCE)
    sha=hashlib.sha256(raw).hexdigest()
    lines=raw.decode().splitlines()
check('exact-current-source-sha256',sha==EXPECTED,sha)
block='\n'.join(lines[11281:11317])
check('source-has-corrected-Hubble-one-form',r'H_E\,dt_E=H_J\,dt_J+\tfrac12\,d\ln F' in block)
check('source-retains-constant-F-only-exception',r'dF=0' in block and 'only' in block)
check('source-retains-unmodified-tensor-momentum',r'P_h^E=' in block and r'=P_h^J' in block)
check('source-retains-unmodified-tensor-generator',r'A_L^J=' in block and r'=\sqrt F\,A_L^E' in block)
check('source-does-not-confuse-Dirac-Hamiltonian-with-Hubble',r'\mathsf H_Ddt' in block)
with zipfile.ZipFile(ATLAS) as z:
    issues=json.loads(z.read('Paper00-DAGAtlas-v1_140/DAG/AuditLayer/Paper6A-v1_1/GapRegistry.json'))['items']
    issue=[i for i in issues if i.get('id')=='BH-VIA-G-0011']
check('historical-source-bound-open-issue-registered',len(issue)==1 and issue[0]['status']=='UNRESOLVED')
check('historical-inferred-dF-condition-captured',issue[0]['condition_ids']==['BH-VIA-A-0014'])

# E3 symbolic: t is the Jordan coordinate, dt_E/dt_J = sqrt F(t).
t=sp.symbols('t',real=True)
a=sp.Function('a')(t)
F=sp.Function('F')(t)
HEdtJ=sp.diff(sp.log(sp.sqrt(F)*a),t)
HJdtJ=sp.diff(sp.log(a),t)
fix=sp.diff(sp.log(F),t)/2
check('E3-exact-logarithmic-derivative',sp.simplify(HEdtJ-HJdtJ-fix)==0)
check('E3-incorrect-old-unqualified-equality',sp.simplify(HEdtJ-HJdtJ-fix)==0 and sp.simplify(HEdtJ-HJdtJ)!=0)

A,J,MM,lam,doth=sp.symbols('A J M lam doth',positive=True)
aE=sp.sqrt(J)*A
PE=MM**2*aE**3/4*(doth/sp.sqrt(J))
PJ=MM**2*A**3*J/4*doth
check('E3-invariant-tensor-canonical-momentum',sp.simplify(PE-PJ)==0)
AE=sp.Matrix([[0,aE**(-3)],[-aE*lam,0]])
AJ=sp.Matrix([[0,1/(A**3*J)],[-A*J*lam,0]])
check('E3-generator-lapse-conformal-intertwiner',all(sp.simplify(v)==0 for v in AJ-sp.sqrt(J)*AE))

# E4 adverse test: positive time-dependent F=exp(2bt), a=exp(ht).
b,h=sp.symbols('b h',real=True,nonzero=True)
a0=sp.exp(h*t)
F0=sp.exp(2*b*t)
wrong=sp.simplify(sp.diff(sp.log(sp.sqrt(F0)*a0),t)-sp.diff(sp.log(a0),t))
check('E4-historical-nonconstant-F-counterexample',sp.simplify(wrong-b)==0,repr(wrong))
check('E3-constant-F-positive-control',sp.simplify(sp.diff(sp.log(sp.sqrt(J)*a0),t)-sp.diff(sp.log(a0),t))==0)

# A rich finite family tests the metric time conversion, tensor momentum,
# generator, and covariance Lyapunov equation under the same clock change.
rng=random.Random(20261115)
n_cases=600
n_wrong_observed=0
max_err=0.
for i in range(n_cases):
    h0=rng.uniform(-2,2)
    k0=rng.uniform(-.5,.5)
    b0=rng.uniform(-1,1)
    c0=rng.uniform(-.5,.5)
    x=rng.uniform(-1,1)
    L=rng.randint(2,40)
    m=rng.uniform(.1,6)
    dhdt=rng.uniform(-5,5)
    aJ=math.exp(h0*x+k0*x*x)
    Fc=math.exp(2*b0*x+c0*x*x)
    aE=math.sqrt(Fc)*aJ
    hJ=h0+2*k0*x
    half_dlnF=b0+c0*x
    hE=(hJ+half_dlnF)/math.sqrt(Fc)
    err=abs(hE*math.sqrt(Fc)-hJ-half_dlnF)
    max_err=max(max_err,err)
    assert err<1e-12
    if abs(half_dlnF)>1e-3:
        assert abs(hE*math.sqrt(Fc)-hJ)>1e-3
        n_wrong_observed+=1
    PE=m*m*aE**3/4*(dhdt/math.sqrt(Fc))
    PJ=m*m*aJ**3*Fc/4*dhdt
    assert math.isclose(PE,PJ,rel_tol=2e-13,abs_tol=1e-13)
    AE=((0.,aE**-3),(-aE*L*(L+2),0.))
    AJ=((0.,1/(aJ**3*Fc)),(-aJ*Fc*L*(L+2),0.))
    for r in range(2):
        for c in range(2):
            assert math.isclose(AJ[r][c],math.sqrt(Fc)*AE[r][c],rel_tol=5e-13,abs_tol=1e-12)
    # Arbitrary symmetric covariance: clock change uses the same generator.
    cc=(rng.uniform(.1,3),rng.uniform(-1,1),rng.uniform(.1,3))
    C=((cc[0],cc[1]),(cc[1],cc[2]))
    def cov_der(G):
        return tuple(tuple(sum(G[r][k]*C[k][j]+C[r][k]*G[j][k] for k in range(2)) for j in range(2)) for r in range(2))
    cj=cov_der(AJ)
    ce=cov_der(AE)
    for r in range(2):
        for c in range(2):
            assert math.isclose(cj[r][c],math.sqrt(Fc)*ce[r][c],rel_tol=6e-13,abs_tol=5e-10)
check('E3-E4-600-positive-varying-F-finite-cases',True,{'cases':n_cases,'max_hubble_oneform_residual':max_err})
check('E4-old-equality-fails-across-nonconstant-cases',n_wrong_observed>550,{'counterexamples':n_wrong_observed})

# Positive F is the domain guard; F=0 is excluded, so never use it as a
# countermodel for the target theorem.
check('source-domain-guard-explicit',r'F=f_R>0' in block)
result={
  'issue_id':'BH-VIA-G-0011',
  'current_source':SOURCE,
  'source_sha256':sha,
  'source_span':[11282,11317],
  'branch':'homogeneous positive-C1-conformal-F and aJ, smooth shared TT h; frame clock transformation only',
  'tests':checks,
  'test_class_count':len(checks),
  'finite_parameter_samples':n_cases,
  'old_unqualified_formula_counterexamples_in_samples':n_wrong_observed,
  'analytic_proof_is_primary':True,
  'all_passed':all(x['passed'] for x in checks),
  'physical_occurrence_certified':False,
  'global_theorem_promotion':False,
}
OUT.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'all_passed':result['all_passed'],'classes':len(checks),'finite_samples':n_cases,'old_counterexamples':n_wrong_observed,'source_sha256':sha},indent=2))
