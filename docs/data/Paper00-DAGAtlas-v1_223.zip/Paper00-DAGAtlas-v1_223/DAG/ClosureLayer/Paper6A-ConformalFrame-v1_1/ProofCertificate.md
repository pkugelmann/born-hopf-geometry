# Paper VI-A — conformal-frame Hubble one-form closure

**Certificate ID:** `BH-VIA-G-0011` (scoped mathematical issue only)  
**Certificate file:** `Paper6A-ConformalFrameClosure-v1_1.md`  
**Current authoritative source:** `Paper00-PapersMinimal-v3_014(1).zip` → `Paper6A-GravityCosmology-v2_261.tex`  
**Source SHA-256:** `b15dea7e84ed67596c77a658ca36e6cbb483b5318828bbd2c47f9594628cac1d`  
**Source location:** `p8:sec:tensor-frame-ledger`, lines **11282–11317**, particularly 11286–11316  
**Historical issue source:** `Paper6A-GravityCosmology-v2_253.tex`, lines 11083–11108, as registered in `DAG/AuditLayer/Paper6A-v1_1/GapRegistry.json`  
**Basis:** `Paper00-ProofChainAuditProtocol-v1_1` plus source-first scoped mathematical verification under `Paper00-RigorousVerificationDAGWorkProtocol-v2_4`; not a new full-paper audit.

## Claim, type, and boundary

The historical issue `BH-VIA-G-0011` challenges the *unqualified* identity
\(H_E\,dt_E=H_J\,dt_J\) on a time-dependent homogeneous conformal frame.
The current source replaces that claim by the exact **Hubble one-form** identity
\[
\boxed{H_E\,dt_E=H_J\,dt_J+\tfrac12\,d\ln F},
\quad
 a_E=\sqrt F\,a_J,\quad dt_E=\sqrt F\,dt_J,\quad F=f_R>0.
\]
The claim is local to a homogeneous, positive, differentiable conformal factor, a positive differentiable Jordan scale factor, and the stated clock relation. It is **not** a statement that a physical frame is selected or that the scalaron reaches the terminal branch.

## Source-matched independent proof (E1/E3)

Assume \(a_J,F\in C^1(I)\) and \(a_J>0,F>0\) on the interval \(I\). These are the chart regularity conditions for the logarithms; the source explicitly states the positive factor and homogeneous conformal relation. Because \(dt_E/dt_J=\sqrt F>0\), the Einstein time is a valid local monotone clock. For either frame \(H\,dt=d\ln a\). Therefore
\[
\begin{aligned}
H_E\,dt_E
 &= d\ln a_E
 = d\ln(\sqrt F\,a_J)\\
 &= d\ln a_J+\tfrac12 d\ln F
 = H_J\,dt_J+\tfrac12 d\ln F.
\end{aligned}
\]
No assumption \(dF=0\) is used. The *previous* unqualified identity holds precisely where \(dF=0\). Hence the historical inferred guard `BH-VIA-A-0014` (constant conformal factor to justify the old step) is **not consumed** by the corrected theorem; its registry entry is preserved as historical provenance, not deleted or globally discharged.

The same source also asserts the **independent** frame-invariance of the canonical tensor momentum. With \(h_E=h_J=h\), and \(M\) fixed,
\[
\begin{aligned}
P_h^E&=\frac{M^2a_E^3}{4}\frac{dh}{dt_E}
=\frac{M^2(F^{3/2}a_J^3)}4\frac1{\sqrt F}\frac{dh}{dt_J}
=\frac{M^2a_J^3F}4\frac{dh}{dt_J}=P_h^J.
\end{aligned}
\]
In canonical variables \(q_T=Mh/2\), \(p_T=2P_h/M\), the generators are
\[
 A_L^E=\begin{pmatrix}0&a_E^{-3}\\-a_E\lambda_L&0\end{pmatrix},\qquad
 A_L^J=\begin{pmatrix}0&(a_J^3F)^{-1}\\-a_JF\lambda_L&0\end{pmatrix}.
\]
Substituting \(a_E=\sqrt F\,a_J\) gives \(A_L^J=\sqrt F\,A_L^E\), with no derivative of \(F\) required. Thus \(d z/dt_J=A_L^J z\) follows from \(d z/dt_E=A_L^E z\), and the same holds for the covariance transport with the same prepared root state, on the stated free quadratic domain. **The Hubble scalar and the Dirac Hamiltonian \(\mathsf H_D\) are different objects:** the source explicitly avoids equating them, and retains \(m_E=m_J/\sqrt F\) on its specified minimally coupled half-density Dirac branch. No full Dirac source state is constructed by this local identity.

## Adversarial check (E4) and positive controls

Let \(a_J=e^{ht_J}\) and \(F=e^{2bt_J}\) with \(b\ne0\). Then
\[
H_E\,dt_E=(h+b)\,dt_J,
\qquad H_J\,dt_J=h\,dt_J,
\qquad \frac12d\ln F=b\,dt_J.
\]
The *historical* equality fails, while the corrected equation holds identically. For \(b=0\) the old equality becomes valid. The momentum and tensor-generator identities remain true even for \(b\ne0\): they do not consume the broken step.

The executable independent verification script, `Paper6A-ConformalFrameClosureChecks-v1_1.py`, uses exact symbolic differentiation and matrix algebra; it also runs **600** deterministic finite parameter samples of positive, varying \(F\) and positive scale factors, checking the corrected Hubble identity, momentum identity, generator transformation, and covariance clock change. The old formula fails in **600** of these 600 sampled time-dependent parameter states. Evidence JSON: `Paper6A-ConformalFrameClosureEvidence-v1_1.json` (17 passing check classes). The symbolic proof above, not sampling, discharges the mathematical identity.

## Audit adjudication and typed DAG propagation

- **Effective current scoped disposition:** `LOCAL_MATH_CLOSED` for `BH-VIA-G-0011`; the historical `OPEN`/`UNRESOLVED` finding remains valid for the **old** source version. It is retained verbatim in the immutable historical audit layer.
- **Claim boundary:** `p8:sec:tensor-frame-ledger`, Hubble one-form and the explicitly linked canonical tensor clock transformations only. It is not a new proof of physical frame, source covariance under interactions, tensor occupation, scalaron endpoint or dark energy.
- **Condition inheritance:** old inferred `BH-VIA-A-0014` is no longer required for this target (only for the superseded unqualified equality). The current result consumes `F>0`, `a_J>0`, `C^1` regularity, and the stated conformal relation, all printed or standard local analytic chart guards.
- **Issue dependency:** the verified historical impact index lists no cross-paper descendants proved to use this failed step; therefore **no cross-paper or whole-framework status promotion** is made. Current native tensor covariance remains conditional on its own root/clock/source premises.
- **Unchanged physical gates:** `NEWTON_WHOLE_ACTION`, `COSMO_OCCURRENCE`, actual root state and complete real Dirac source evolution, terminal scalaron stopping, causal-cap and cyclic lineage, and the observed dark-energy prediction are untouched.
- **No paper edits** and **no new axiom or physical branch selection**. All prior mathematical closure evidence for `BH-VIA-G-0010` remains active.

**Conclusion:** This is a genuine source-matched closure of one moderate **local mathematical correctness** issue; it does **not** close a global cosmological occurrence or physical dark-energy gap.
