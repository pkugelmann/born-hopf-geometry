#!/usr/bin/env python3
"""Current-source scoped independent G-0009 verification.
Certifies the algebraic equivalence only for M(a)>0 on H1/H2 positive Y branch.
Does not certify actual physical H1/H2 or cosmic occurrence.
"""
import hashlib, json, math, random, zipfile
from pathlib import Path
import sympy as sp
import mpmath as mp

P=Path('/mnt/data')
SRC_Z=P/'Paper00-PapersMinimal-v3_014(1).zip'
DAG_Z=P/'Paper00-DAGAtlas-v1_143.zip'
AUD_Z=P/'Paper00-ProofChainAudits-v1_58.zip'
SOURCE='Paper6A-GravityCosmology-v2_261.tex'
OUT=P/'Paper6A-PhantomCrossingClosureEvidence-v1_1.json'
checks=[]
def check(name,test,detail=''):
    ok=bool(test)
    checks.append({'name':name,'passed':ok,'detail':str(detail)})
    if not ok: raise AssertionError(f'{name} FAILED {detail}')

beta,Y,M,theta=sp.symbols('beta Y M theta',positive=True,real=True)
Gth=1+beta*(1+2*theta-3*theta**2)
G=sp.simplify(Gth.subs(theta,1/Y))
G_theta=sp.diff(Gth,theta).subs(theta,1/Y)
F=Y-M-G
D=Y**2+G_theta
Fp=sp.diff(F,Y)
yp=-3*M/Fp
ThetaPrime=-yp/Y**2
Gprime=sp.simplify(sp.diff(G,Y)*yp)
wplus=sp.factor(-Gprime/(3*G))
quoted=-M*G_theta/(G*D)

check('kernel_polynomial_literal',sp.simplify(G-(1+beta*(1+2/Y-3/Y**2)))==0)
check('kernel_support_factorization',sp.expand(Gth-(1+beta*(1-theta)*(1+3*theta)))==0)
check('kernel_theta_derivative',sp.simplify(G_theta-2*beta*(1-3/Y))==0)
check('implicit_equation_derivative',sp.simplify(Fp-(1+G_theta/Y**2))==0)
check('Y_prime_from_dust',sp.simplify(yp-(-3*M*Y**2/D))==0)
check('theta_prime_from_dust',sp.simplify(ThetaPrime-3*M/D)==0)
check('conservation_EOS_exact',sp.simplify(wplus-quoted)==0)
check('w_minus_one_zero_factorization',sp.simplify(wplus/(-M*G_theta/(G*D))-1)==0)
check('nonzero_beta_crossing_theta',sp.solve(sp.Eq(sp.diff(Gth,theta),0),theta)==[sp.Rational(1,3)])
check('G_at_crossing',sp.simplify(G.subs(Y,3)-(1+4*beta/3))==0)
Mcross=sp.simplify((Y-G).subs(Y,3))
check('M_crossing_condition',sp.simplify(Mcross-(2-4*beta/3))==0)
check('vacuum_root_Y1',sp.simplify(F.subs({Y:1,M:0}))==0)
check('vacuum_theta_1',sp.simplify((1/Y).subs(Y,1)-1)==0)
check('vacuum_Gtheta_nonzero',sp.simplify(G_theta.subs(Y,1)+4*beta)==0)
check('vacuum_w_equal_minus_one',sp.simplify(quoted.subs({M:0,Y:1}))==0)
# Transverse crossing derivative on the positive-matter parametric FLRW branch.
# dM/d ln a=-3M; Y'=(-3M)/Fp. At crossing, Gtheta=0.
Dln_M=-3*M
Dln_wplus=sp.diff(quoted,Y)*yp+sp.diff(quoted,M)*Dln_M
slopestar=sp.simplify(Dln_wplus.subs({Y:3,M:Mcross}))
slopetarget=2*beta*Mcross**2/(9*(1+4*beta/3))
check('positive_matter_transverse_crossing_slope',sp.simplify(slopestar-slopetarget)==0)

with zipfile.ZipFile(SRC_Z) as z:
    check('papers_zip_crc',z.testzip() is None)
    raw=z.read(SOURCE)
    source_sha=hashlib.sha256(raw).hexdigest()
    txt=raw.decode()
    lines=txt.splitlines()
    check('exact_source_sha',source_sha=='b15dea7e84ed67596c77a658ca36e6cbb483b5318828bbd2c47f9594628cac1d')
    check('current_source_H1_explicit',r'\tag{H1}' in txt)
    check('current_source_H2_explicit',r'\tag{H2}' in txt)
    check('current_source_positive_matter_scope',r'w_{\rm DE}=-1\quad(M(a)>0)' in txt)
    check('current_source_vacuum_exception',r'At the separately allowed vacuum endpoint \(M=0\)' in txt)
    check('current_source_crossing_label',r'\label{p8:eq:hs-crossing-geometric}' in txt)
    check('current_source_corrected_location',r'\label{p8:eq:hs-crossing-geometric}' in '\n'.join(lines[7430:7445]))

with zipfile.ZipFile(DAG_Z) as z:
    check('DAG_input_crc',z.testzip() is None)
    p='Paper00-DAGAtlas-v1_143/'
    gaps=json.loads(z.read(p+'DAG/GapRegistry.json'))
    check('issue_in_open_historical_registry','BH-VIA-G-0009' in gaps['Paper6A_final']['issue_ids'])
    check('issue_not_yet_in_local_math_closures','BH-VIA-G-0009' not in gaps['current_scoped_dispositions_v1_143']['mathematically_closed'])
    check('earlier_local_closures_preserved',set(gaps['current_scoped_dispositions_v1_143']['mathematically_closed'])=={'BH-VIA-G-0010','BH-VIA-G-0011','BH-VIA-G-0012','BH-VIA-G-0008'})
with zipfile.ZipFile(AUD_Z) as z:
    check('audits_input_crc',z.testzip() is None)
    a=z.read('Paper00-ProofChainAudits-v1_58/Paper6A-ProofChainAudit-v1_9.md').decode()
    check('historical_0009_exact_obligation_present','BH-VIA-G-0009' in a and 'M(a)>0' in a)

mp.mp.dps=55
bv=mp.sqrt(mp.pi)/(48*mp.sqrt(2))
check('fixed_beta_between_zero_and_quarter',0<bv<mp.mpf('0.25'))
check('Fprime_lower_bound_strict',1-4*bv>0)
check('M_cross_positive',2-4*bv/3>0)
check('vacuum_G_is_one',abs((1+bv*(1+2-3))-1)<mp.mpf('1e-49'))

def g(y):return 1+bv*(1+2/y-3/y**2)
def gt(y):return 2*bv*(1-3/y)
def Dfun(y):return y*y+gt(y)
def ffun(y,m):return y-m-g(y)
def solve_y(m):
    # Valid for all m>=0 since F(1)=-m and F(m+2)>=0.
    if m==0:return mp.mpf(1)
    lo=mp.mpf(1); hi=m+2
    for _ in range(220):
        mid=(lo+hi)/2
        if ffun(mid,m)>0:hi=mid
        else:lo=mid
    return (lo+hi)/2

def wp(m):
    y=solve_y(m)
    return -m*gt(y)/(g(y)*Dfun(y)),y

rng=random.Random(26091115)
N=450
max_res=mp.mpf(0)
for i in range(N):
    m=mp.power(10,mp.mpf(rng.uniform(-9,9)))
    w,y=wp(m)
    res=abs(ffun(y,m)); max_res=max(max_res,res)
    assert y>1 and y<m+2
    assert Dfun(y)>0 and g(y)>0
    assert (w<0)==(y>3) and (w>0)==(y<3)
check('random_450_positive_branch_sign_and_residual',max_res<mp.mpf('1e-40'),'max root equation residual '+str(mp.nstr(max_res,7)))

# Demonstrate old unqualified iff fails within allowed model.
wv,yv=wp(mp.mpf(0))
check('adversarial_vacuum_endpoint_w_equals_minus_one',wv==0 and yv==1)
check('adversarial_vacuum_endpoint_theta_not_third',mp.mpf(1)/yv!=mp.mpf(1)/3)
ms=2-4*bv/3
wc,yc=wp(ms)
check('positive_matter_exact_crossing_numeric',abs(yc-3)<mp.mpf('1e-50') and abs(wc)<mp.mpf('1e-50'))
check('crossing_slope_numeric_positive',2*bv*ms**2/(9*(1+4*bv/3))>0)
for d in [mp.mpf('0.000001'),mp.mpf('0.001'),mp.mpf('0.01')]:
    wbefore,ybefore=wp(ms*(1+d))
    wafter,yafter=wp(ms*(1-d))
    assert ybefore>3>yafter and wbefore<0<wafter
check('crossing_changes_sign_both_sides',True)
# Test numerical differentiation against source EOS on finite log-matter domain.
for _ in range(80):
    m=mp.power(10,mp.mpf(rng.uniform(-3,4)))
    w,y=wp(m); h=mp.mpf('0.00000001')
    lp=mp.log(g(solve_y(m*mp.exp(-3*h))))
    lm=mp.log(g(solve_y(m*mp.exp(3*h))))
    wfd=-(lp-lm)/(6*h)
    assert abs(wfd-w)<mp.mpf('3e-14')*(1+abs(w))
check('80_high_precision_finite_difference_EOS_checks',True)

result={
 'issue_id':'BH-VIA-G-0009',
 'scope':'LOCAL_MATH_CLOSED on M(a)>0 physical horizon branch, conditional on H1/H2, positive beta, dust and conservation; old full M>=0 equivalence false',
 'source_archive':SRC_Z.name,'source':SOURCE,'source_sha256':source_sha,'source_lines':[7344,7443],
 'source_label':'p8:eq:hs-crossing-geometric',
 'beta_approx':mp.nstr(bv,20),
 'M_cross_approx':mp.nstr(ms,20),
 'transverse_crossing_slope_approx':mp.nstr(2*bv*ms**2/(9*(1+4*bv/3)),20),
 'evidence_class_count':len(checks),'independent_positive_matter_random_cases':N,
 'finite_difference_high_precision_cases':80,
 'old_iff_counterexample':{'M':'0','Y':'1','Theta_A':'1','w_DE':'-1','G_theta':'-4 beta'},
 'earlier_condition':'BH-VIA-A-0012 (M>0; retained as necessary scope guard, not discharged physically)',
 'no_global_physical_status_promotion':True,
 'unresolved':['H1 marginal support selector','H2 bilinear transport interface','same-action physical owner','COSMO_OCCURRENCE','NEWTON_WHOLE_ACTION','BH-VIA-G-0013 numerical BH replay'],
 'all_passed':all(v['passed'] for v in checks),'checks':checks,
}
OUT.write_text(json.dumps(result,indent=2,sort_keys=True,ensure_ascii=False)+'\n')
print(json.dumps({k:result[k] for k in ('issue_id','source','source_sha256','evidence_class_count','independent_positive_matter_random_cases','finite_difference_high_precision_cases','M_cross_approx','transverse_crossing_slope_approx','all_passed')},indent=2))
