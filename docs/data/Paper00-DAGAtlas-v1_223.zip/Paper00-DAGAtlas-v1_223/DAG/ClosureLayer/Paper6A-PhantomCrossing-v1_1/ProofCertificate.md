# Paper VI-A — geometric phantom-crossing scope closure

**Certificate:** `Paper6A-PhantomCrossingClosure-v1_1.md`  
**Issue:** `BH-VIA-G-0009` — source-level missing positive-matter guard, not a failure of the conditional horizon response itself.  
**Source of truth:** `Paper00-PapersMinimal-v3_014(1).zip` / `Paper6A-GravityCosmology-v2_261.tex`, SHA256 `b15dea7e84ed67596c77a658ca36e6cbb483b5318828bbd2c47f9594628cac1d`.  
**Current source anchors:** (H1) lines 7188–7222; (H2) and `G_A` lines 7226–7254; physical positive branch `p8:lem:physical-horizon-branch` lines 7344–7387; EOS and geometric crossing `p8:eq:hs-crossing-geometric` lines 7389–7443.  
**Historical finding:** `Paper6A-ProofChainAudit-v1_9.md`, `BH-VIA-G-0009`, original v2.253 lines 7353–7362, condition `BH-VIA-A-0012`.  
**Scope-limited verdict:** **LOCAL_MATH_CLOSED** for the repaired equivalence *on the explicitly stated positive-matter branch*. The earlier M≥0 equivalence is false, but was **not** reasserted in the current source. No physical H1/H2 owner or dark-energy occurrence claim is promoted.

## Source claim, assumptions, and the exact logical distinction

The latest source defines

\[
 \beta_A=\frac{\sqrt\pi}{48\sqrt2}>0,\quad
 M(a)=\mu_m a^{-3}\ge0,\quad
 \Theta_A=\frac1Y,\quad Y\ge1,\quad
 G_A(\Theta)=1+\beta_A(1+2\Theta-3\Theta^2).
\]

The source's **mathematical** horizon branch satisfies `Y=M+G_A(1/Y)` and derives the EOS from the separately assumed conserved late effective fluid. This entire branch is conditional on the quasilocal support selector **(H1)** and minimal bilinear interface **(H2)**, with positive `a`, `rho_infty`, and the stated dust continuity. Neither H1 nor H2 is proved physical by this certificate. The fixed \(\beta_A\) is nonzero; taking \(\beta_A=0\) is outside the asserted nondegenerate crossing formula.

The latest source's exact conclusion is

\[
 \boxed{M(a)>0\quad\Longrightarrow\quad
 \bigl(w_{\rm DE}=-1\iff\Theta_A=1/3\iff R_A=R_{A,\infty}/\sqrt3\bigr).}
\]

This must **not** be widened to \(M(a)\ge0\) without an explicit disjunct. On that larger allowed branch the exact equivalent statement is

\[
 \boxed{w_{\rm DE}=-1 \iff \bigl[M(a)=0\bigr]\ \text{or}\ \bigl[\Theta_A=1/3\bigr],}
\]

where the \(\Theta_A=1/3\) case itself is necessarily positive-matter for the fixed \(\beta_A\). The current paper explicitly gives the endpoint exception rather than asserting the larger formula.

## E1: exact source-proof replay

Define \(F(Y)=Y-M-G_A(1/Y)\). The source calculates

\[
 F(1)=-M\le0,\quad F(\infty)=+\infty,\quad
 F_Y=1+\frac{G_\Theta}{Y^2}
 =1+\frac{2\beta_A(Y-3)}{Y^3}\ge1-4\beta_A>0
 \quad(Y\ge1),
\]

using \(\beta_A=\sqrt\pi/(48\sqrt2)<1/4\). Hence the physical \(Y\ge1\) root is unique. For \(M>0\) the root is strictly \(Y>1\); for \(M=0\) it is precisely \(Y=1\). Furthermore

\[
 G_A(\Theta)=1+\beta_A(1-\Theta)(1+3\Theta)\ge1\quad(0<\Theta\le1),
 \qquad Y^2+G_\Theta=Y^2F_Y>0.
\]

Dust conservation gives \(dM/d\ln a=-3M\). Implicit differentiation yields

\[
 \frac{dY}{d\ln a}=-\frac{3MY^2}{Y^2+G_\Theta},\quad
 \frac{d\Theta_A}{d\ln a}=\frac{3M}{Y^2+G_\Theta}.
\]

Therefore, with \(\rho_{\rm DE}=\rho_\infty G_A(\Theta_A)\), and with the declared effective-fluid conservation identity,

\[
 w_{\rm DE}+1=-\frac13\frac{d\ln\rho_{\rm DE}}{d\ln a}
 =-\frac{M G_\Theta}{G_A(Y^2+G_\Theta)}
 =-\frac{2\beta_A M(1-3/Y)}{G_A(Y^2+G_\Theta)}.
\]

Because the denominator is strictly positive, for the fixed nonzero \(\beta_A\) and \(M>0\): \(w_{\rm DE}=-1\) precisely when \(1-3/Y=0\), i.e. \(Y=3\), \(\Theta_A=1/3\), and \(R_A=R_{A,\infty}/\sqrt3\) by the source definition \(\Theta_A=(R_A/R_{A,\infty})^2\) and positive radius. No other zero exists for positive matter.

### E4 admissible endpoint countermodel to the *historical*, unqualified formula

Set \(M=0\). The unique source-allowed root is \(Y=1\), so \(\Theta_A=1\), \(G_A=1\), and the EOS reads \(w_{\rm DE}+1=0\). Hence \(w_{\rm DE}=-1\) while \(\Theta_A\ne1/3\). This is an endpoint solution *inside the source domain*, not an invented external cosmology. Its explicit treatment at current source lines 7432–7435 repairs the old missing guard.

### Positive crossing and its transverse direction (independent E3 consequence)

The source implicit equation at \(Y=3\) gives

\[
 M_* =3-G_A(1/3)=2-\frac43\beta_A
 =1.9651857184079027708\ldots>0.
\]

For \(M>0\), \(Y\) increases strictly with \(M\); with \(dM/d\ln a=-3M\), it decreases strictly with expanding \(a\). The crossing of \(Y=3\) is transverse whenever the physical branch passes \(M_*\). In particular, differentiating the exact expression *on that branch* gives the positive slope

\[
 \left.\frac{d(w_{\rm DE}+1)}{d\ln a}\right|_{M=M_*}
 =\frac{2\beta_A M_*^2}{9\bigl(1+4\beta_A/3\bigr)}
 =0.021654640201149656603\ldots>0.
\]

This slope is an independent derived consequence of the already specified conditional equation, **not** a proof that the occurring universe traverses the crossing. It predicts a phantom-to-nonphantom local direction in the source-defined expanding dust member.

## E3 independent checks

`Paper6A-PhantomCrossingClosureChecks-v1_1.py` / `Paper6A-PhantomCrossingClosureEvidence-v1_1.json` independently checked the exact source text, positive branch and endpoint guards; the algebraic Jacobian, dust derivative and EOS identity; the nonvanishing denominator and kernel; the crossing mass and transverse derivative; 450 deterministically seeded nonzero matter values over nine orders of magnitude in either direction, the exact zero-matter counterexample, positive-matter crossing perturbations, and 80 high-precision EOS finite differences. **41/41 verification classes passed**, with all 450 random positive-matter cases and 80 finite-difference cases passing. Numerical sampling supplements, and does not replace, the analytic argument.

## DAG scope and still-open obligations

- **CLOSED locally:** `BH-VIA-G-0009`, solely the scope defect in `p8:eq:hs-crossing-geometric` on the latest source. Historic v2.253 audit provenance is retained. The separate current formula's positive-matter guard is explicit and indispensable.
- **Retain `BH-VIA-A-0012`:** \(M(a)>0\) is an actual **SCOPE_GUARD** for the equivalence, not something magically discharged by this proof. The no-matter endpoint remains a valid distinct case. Earlier conditions (H1), (H2), branch positivity, conservation and nonzero \(\beta_A\) are inherited, not reintroduced as physical axioms.
- **Not proved:** physical preference for the quasilocal marginal support (H1), microscopic same-action derivation of the bilinear interface (H2), absolute Newton owner, actual positive-matter history on the branch, `COSMO_OCCURRENCE`, or `NEWTON_WHOLE_ACTION`. No extra scalar field, Hubble normalization, new source port or free parameter is inserted.
- **Unrelated open issue retained:** `BH-VIA-G-0013` numerical black-hole replay remains `OPEN_EVIDENCE_MISSING`, as certified in the prior release. Earlier independently closed `G-0008/0010/0011/0012` remain closed locally.
- **Audit coverage:** targeted source-matched mathematical verification; **not** a fresh global review of VI-A or cross-paper propagation. The main mathematical source archive is unchanged.
