#!/usr/bin/env python3
"""Exact E2/E3/E4 closure controls for BH-VIA-G-0012, source v2.261.

Reconstructs the D4/Hurwitz 24-cell, association relations, and all spectral
idempotents. Does not infer a physical galaxy-to-shell projection.
"""
from __future__ import annotations
import hashlib
import itertools
import json
import random
import zipfile
from pathlib import Path
import sympy as sp

ROOT=Path('/mnt/data')
PAPERS=ROOT/'Paper00-PapersMinimal-v3_014(1).zip'
TARGET='Paper6A-GravityCosmology-v2_261.tex'
SOURCE_B='Paper1B-ExceptionalGeometry-v1_8.tex'
EVIDENCE=ROOT/'Paper6A-ShellEigenchannelClosureEvidence-v1_1.json'
checks=[]
def check(name,cond,detail=None):
    checks.append(dict(name=name,passed=bool(cond),detail=detail))
    if not cond: raise AssertionError(name + (': '+str(detail) if detail else ''))

def sha(data): return hashlib.sha256(data).hexdigest()

with zipfile.ZipFile(PAPERS) as z:
    source=z.read(TARGET)
    paper_b=z.read(SOURCE_B)
    loc=source.decode().splitlines()
    ib=paper_b.decode().splitlines()
check('source_correct_version_and_hash',sha(source)=='b15dea7e84ed67596c77a658ca36e6cbb483b5318828bbd2c47f9594628cac1d')
check('current_proposition_anchor',r'\label{p8:prop:shell-algebra-nonterminal-rar}' in '\n'.join(loc[10040:10090]))
check('source_includes_missing_invariant_channel',r'1^n' in '\n'.join(loc[10040:10090]))
check('source_restricts_three_factors_to_mean_zero','mean-zero sector' in '\n'.join(loc[10040:10090]))
check('actual_upstream_I_B_owner',r'\label{p1:prop:math-twentyfourcell-bose-mesner}' in '\n'.join(ib[7890:7950]))

# 8 coordinate vertices and 16 half-coordinate vertices of 2T in R^4.
V=[]
for i in range(4):
    for sign in (-1,1):
        v=[sp.Integer(0)]*4
        v[i]=sp.Integer(sign)
        V.append(tuple(v))
V.extend(tuple(sp.Rational(sign,2) for sign in eps)
         for eps in itertools.product((-1,1),repeat=4))
check('24_distinct_unit_vertices',len(V)==24 and len(set(V))==24 and
      all(sum(c*c for c in v)==1 for v in V))

inner=[sp.Rational(1),sp.Rational(1,2),sp.Rational(0),sp.Rational(-1,2),sp.Rational(-1)]
relations=[]
for q in inner:
    mat=sp.Matrix(24,24,lambda i,j: int(sum(V[i][k]*V[j][k] for k in range(4))==q))
    relations.append(mat)
I,Ap,A0,Am,Api=relations
J=sp.ones(24,24)
check('relation_partition_exact',sum(relations,sp.zeros(24))==J and I==sp.eye(24))
check('valencies_1_8_6_8_1',all(tuple(sum(M[i,j] for j in range(24)) for M in relations)==(1,8,6,8,1) for i in range(24)))
check('all_relations_symmetric',all(M==M.T for M in relations))
check('all_relations_commute',all(B*C==C*B for B in relations for C in relations))
check('nearest_neighbor_adj_0_1_degree_8',all(Ap[i,i]==0 and sum(Ap[i,j] for j in range(24))==8 for i in range(24)))

observed=Ap.eigenvals()
expected={sp.Integer(8):1,sp.Integer(4):4,sp.Integer(0):9,sp.Integer(-2):8,sp.Integer(-4):2}
check('independent_exact_characteristic_spectrum',observed==expected,
      {str(k):v for k,v in observed.items()})
check('characteristic_multiplicities_total_24',sum(observed.values())==24)
T=Ap/8
lam=[sp.Rational(1),sp.Rational(1,2),sp.Rational(0),sp.Rational(-1,4),sp.Rational(-1,2)]
check('normalized_spectrum_exact',{sp.Rational(k,8):v for k,v in observed.items()}==dict(zip(lam,[1,4,9,8,2])))

# Exact primitive spectral projectors derived independently, not copied from source.
projectors={}
for eigen in lam:
    num=sp.eye(24)
    denom=sp.Integer(1)
    for other in lam:
        if other==eigen:continue
        num=num*(T-other*sp.eye(24))
        denom*=eigen-other
    projectors[eigen]=sp.simplify(num/denom)
check('spectral_projectors_complete',sum(projectors.values(),sp.zeros(24))==sp.eye(24))
check('all_projectors_hermitian_idempotent',all(P==P.T and P*P==P for P in projectors.values()))
check('all_projectors_orthogonal',all(projectors[a]*projectors[b]==sp.zeros(24) for a in lam for b in lam if a!=b))
check('projector_ranks_match_multiplicities',all(sp.trace(projectors[e])==m for e,m in zip(lam,[1,4,9,8,2])))
check('eigenchannel_actions_exact',all(T*projectors[e]==e*projectors[e] for e in lam))

P1=projectors[sp.Integer(1)]
Pzero=projectors[sp.Integer(0)]
check('invariant_constant_projector',P1==J/24)
check('constant_channel_factor_one_for_all_n',T*P1==P1 and T**7*P1==P1)
check('rank9_null_after_one_step',T*Pzero==sp.zeros(24) and T**17*Pzero==sp.zeros(24))
check('rank9_matches_explicit_upstream_relation_idempotent',Pzero==(3*sp.eye(24)-A0+3*Api)/8)
check('full_n_step_factors_exact', all(T**n==(P1+sp.Rational(1,2)**n*projectors[sp.Rational(1,2)]
                            +sp.Rational(-1,4)**n*projectors[sp.Rational(-1,4)]
                            +sp.Rational(-1,2)**n*projectors[sp.Rational(-1,2)]) for n in [1,2,3,5,12]))

# Mean-zero only: subtract invariant 24-cell average before comparing.
mean_zero_projection=sp.eye(24)-P1
check('mean_zero_commutes',T*mean_zero_projection==mean_zero_projection*T)
check('mean_zero_no_unit_eigenchannel',mean_zero_projection*P1==sp.zeros(24))
check('mean_zero_full_factor_formula',all(T**n*mean_zero_projection==
   sp.Rational(1,2)**n*projectors[sp.Rational(1,2)]+sp.Rational(-1,4)**n*projectors[sp.Rational(-1,4)]+
   sp.Rational(-1,2)**n*projectors[sp.Rational(-1,2)] for n in [1,2,3,7]))

# Adversarial witness: the old factor list without 1^n contradicts T^n 1=1.
ones=sp.ones(24,1)
check('old_full_operator_exhaustiveness_fails',
      any((T**n*ones != sp.zeros(24,1) and
        (sp.Rational(1,2)**n*projectors[sp.Rational(1,2)] +
         sp.Rational(-1,4)**n*projectors[sp.Rational(-1,4)] +
         sp.Rational(-1,2)**n*projectors[sp.Rational(-1,2)])*ones==sp.zeros(24,1))
         for n in (1,2,5)))

# Finite exact synthetic response vectors: decomposition is algebraic, not a halo fit.
rng=random.Random(241215)
samples=128
for _ in range(samples):
    v=sp.Matrix([rng.randint(-9,9) for i in range(24)])
    # Use rational arithmetic and exact P1 mean decomposition.
    ref=T**2*v
    cand=(P1+sp.Rational(1,4)*projectors[sp.Rational(1,2)]+
          sp.Rational(1,16)*projectors[sp.Rational(-1,4)]+
          sp.Rational(1,4)*projectors[sp.Rational(-1,2)])*v
    if ref!=cand: raise AssertionError('synthetic_vector_decomposition')
check('128_exact_synthetic_vector_decompositions',True,{'tested':samples})

result={
    'issue_id':'BH-VIA-G-0012',
    'source_file':TARGET,
    'source_sha256':sha(source),
    'source_claim':'p8:prop:shell-algebra-nonterminal-rar',
    'source_span':[10038,10087],
    'actual_upstream_mathematical_source':f'{SOURCE_B}:7904-7934',
    'upstream_label':'p1:prop:math-twentyfourcell-bose-mesner',
    'test_class_count':len(checks),
    'all_passed':all(t['passed'] for t in checks),
    'independent_exact_24x24_spectrum':{str(k):int(v) for k,v in observed.items()},
    'finite_exact_synthetic_vector_trials':samples,
    'tests':checks,
    'physical_projection_certified':False,
    'source_attribution_typo_in_v2_261': 'The introductory attribution says Paper I-A, but the controlling proposition is in Paper I-B.',
}
EVIDENCE.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:result[k] for k in ('issue_id','test_class_count','all_passed','independent_exact_24x24_spectrum','finite_exact_synthetic_vector_trials','actual_upstream_mathematical_source','physical_projection_certified')},indent=2))
