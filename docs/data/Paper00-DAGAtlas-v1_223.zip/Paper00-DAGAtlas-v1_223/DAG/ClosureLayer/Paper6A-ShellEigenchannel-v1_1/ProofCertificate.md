# Paper VI-A — invariant 24-cell shell eigenchannel closure certificate

**Certificate:** `Paper6A-ShellEigenchannelClosure-v1_1.md`  
**Issue:** `BH-VIA-G-0012` — minor historical `INCORRECT_STEP / MISSING_CONDITION`  
**Exact root:** `p8:prop:shell-algebra-nonterminal-rar`  
**Current source:** `Paper6A-GravityCosmology-v2_261.tex`, lines 10038–10087  
**Source SHA256:** `b15dea7e84ed67596c77a658ca36e6cbb483b5318828bbd2c47f9594628cac1d`  
**Controlling upstream math:** `Paper1B-ExceptionalGeometry-v1_8.tex`, lines 7904–7934, proposition `p1:prop:math-twentyfourcell-bose-mesner`.  
**Audit provenance:** original issue refers to `Paper6A-GravityCosmology-v2_253.tex`, lines 9851–9884, and is preserved historically.

## Current scoped mathematical disposition

**`LOCAL_MATH_CLOSED`, for the missing invariant eigenchannel and its quantifier scope only.** The current source explicitly includes `1^n` among all nonzero spectral factors of the full 24-cell nearest-neighbour walk and restricts the three nonconstant factors to the mean-zero shell subspace. A physical exact-RAR-to-shell projector and the static-response physical owner premises are **not** certified by this mathematical repair.

## Exact theorem and types

Let `X=2T` denote the 24 vertices of the unit Hurwitz 24-cell and `C^X` its full complex function space. Let `A_+` be the real symmetric 24×24 adjacency matrix for vertex inner product `1/2`, with each row summing to eight. Define the normalized walk `T=A_+/8`. Its complete spectrum and eigenspace ranks are

| eigenvalue of T | rank |
|:--|--:|
| 1 | 1 |
| 1/2 | 4 |
| 0 | 9 |
| -1/4 | 8 |
| -1/2 | 2 |

Write `E_1`, `E_{1/2}`, `E_0`, `E_{-1/4}`, `E_{-1/2}` for the mutually orthogonal spectral idempotents (the subscripts denote eigenvalues, not dimensionality). Then for **every integer `n >= 1`**

\[
\boxed{T^n=E_1+2^{-n}E_{1/2}+(-1/4)^nE_{-1/4}+(-1/2)^nE_{-1/2}.}
\]

Here `E_1 = J/24` is the rank-one projector onto constants. The rank-nine zero eigenspace satisfies `T^n E_0=0` for all `n >= 1`. Consequently on `C^X_0={v:\sum_{x\in X}v(x)=0}` alone, the invariant term vanishes and the **three nonconstant factors are exhaustive**. No mean-zero condition is imposed on the full walk theorem.

## Independent proof (E3)

1. Generate the exact root/vertex set `X` using the 8 coordinate unit vectors `±e_i` and 16 half-coordinate vectors `(±1/2, ±1/2, ±1/2, ±1/2)`. Every vertex has squared norm one. Join two distinct vertices iff their Euclidean inner product equals `1/2`. This constructs the finite source claim without importing its claimed spectral table.
2. Exhaustive exact integer adjacency calculation gives regular degree 8, symmetric adjacency and eigenvalue/multiplicity table `8^(1), 4^(4), 0^(9), (-2)^(8), (-4)^(2)`. This independently rederives the Paper I-B values and, by division by eight, the displayed normalized spectrum.
3. For each distinct eigenvalue λ, form the exact Lagrange polynomial projector `E_λ=∏_{μ ≠ λ}(T-μ I)/(λ-μ)`. Exact `24×24` rational matrix operations verify `E_λ^2=E_λ`, `E_λ E_μ=0` if λ≠μ, `∑_λ E_λ=I`, `TE_λ=λE_λ`, and projector trace equal to stated multiplicity.
4. The constant vector `1` is an eigenvector with eigenvalue one because the graph is eight-regular. Its eigenspace rank is one, so `E_1=J/24`. Applying the spectral theorem to `T^n` gives the full formula. On mean-zero vectors, `E_1 v=0`; on the zero-eigenspace, `T^n E_0=0` for all `n>=1`.

These are finite exact calculations and elementary spectral theorem steps, with no limiting or numerical tolerances.

## Adversarial check (E4) and boundary

**Historical invalid inference:** omitting `1^n` while listing all surviving channels on the **full** `C^X`. The valid witness `v=1` has `T^n v=v` for every `n >= 1`. However, all other nonzero eigenspace projectors annihilate `v`, and a sum containing only `2^{-n}`, `(-1/4)^n`, and `(-1/2)^n` gives zero on it. Thus the old unqualified list is false. The repaired current formula includes its invariant term; the reduced list is true exactly when restricted to mean-zero vectors.

The source text's conditional hypothesis—an **occurring physical RAR response having been projected to an isotropic, sector-local shell decomposition on the selected Hurwitz support**—remains unproved. This audit certifies the consequent algebra **given that projection**. It does not construct a physical galaxy halo shell map, derive a second acceleration law, improve the static-response owner premises SC1/TR1/R1/R2, establish cosmic dark-matter abundance, or advance `COSMO_OCCURRENCE` or `NEWTON_WHOLE_ACTION`.

## Source-attribution observation (not part of closed issue)

Paper VI-A v2.261 writes that **“Paper I-A gives”** the 24-cell spectral values. In the current supplied paper corpus the controlling source proposition is **Paper I-B**, `p1:prop:math-twentyfourcell-bose-mesner` (lines 7904–7934); the underlying full joint table also resides in Paper I-B's technical theorem. Thus the mathematical source exists and is independently confirmed, but the narrative upstream paper attribution remains an editorial/citation clean-up item. The separate stray word **“and,”** at VI-A line 10075 also remains editorial only. Neither is silently repaired in the original `.tex`.

## Evidence and limits

- Independent executable: `Paper6A-ShellEigenchannelClosureChecks-v1_1.py`, based on exact SymPy rational arithmetic.
- Machine evidence: `Paper6A-ShellEigenchannelClosureEvidence-v1_1.json`.
- **29/29 independent classes passed**, including full 24×24 spectral projectors, upstream projector identity, integer `n` tests, the invalid-old-formula counterexample, and 128 exact rational synthetic vector projections.
- This targeted certificate updates only `BH-VIA-G-0012` effective local mathematical status. The historical audit finding remains immutable. `BH-VIA-G-0010` and `BH-VIA-G-0011` retain their previous scoped closures. This is not a whole-paper re-audit or a physical occurrence proof.
