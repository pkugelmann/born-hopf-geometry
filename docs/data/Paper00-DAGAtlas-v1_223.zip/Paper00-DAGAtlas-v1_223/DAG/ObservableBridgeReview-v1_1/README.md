Observable source bridge review v1_1. All 11 source-line links are E1 semantic provenance, not canonical material edges. Physical status unchanged. Use main report.
