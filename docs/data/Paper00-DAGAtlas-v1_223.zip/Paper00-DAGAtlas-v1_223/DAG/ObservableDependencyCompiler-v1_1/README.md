# Observable Dependency Compiler v1_1

This **non-promoting** layer is based on current v3_029 TeX source anchors, the v1_160 material-edge ledger, the v1_161 combined graph index, and existing proof-route records. It does not assert a new proof, condition discharge, physical source selection, or calibration.

## Files

- `Index.json`: current input paths, coverage summary and four open observable-frontier certificates.
- `Targets.json`: one record per distinct source target (53); each includes exact current file/label/statement/proof hash anchors, available material ancestry, proof-route records with local AND/OR scope, explicit direct conditions, nonmaterial E1 links, candidate calibration term locators, and physical-occurrence firewall.
- `Families.json`: 28 family membership and evidence-index coverage; the 13 family-specific historical physical frontiers are retained with explicit source-vintage and nonpromotion status.
- `ConditionImpact.json`: evidence-limited direct condition use and material-ancestry target reach. **Never** interpret this as all conditions being conjoined across alternative routes.
- `Validation.json`: source-hash checks, reanchoring changes, and 11 separate source-E2 cache edges excluded from reviewed material traversal.
- `DAG/Paper00-ObservableAtlas-v1_17.json`: source-only reanchoring of the 54 existing observable target occurrences.

## Coverage at v1_171

- 28 families, 54 target occurrences, 53 distinct targets; all 54 current TeX labels validated by exact source hash and label line.
- 33 of 54 target occurrences have material graph incidence, and 33 have an exact combined proof-route record; overlap is not assumed to be complete.
- Five distinct targets have neither an exact route record nor material incidence; **this is an indexing observation, not a claim of missing mathematical proof**.
- The combined graph cache has 11 extra source-E2 R2 edges not present in `CombinedMaterialEdges-v1_160.json`; these are recorded in `Validation.json` and deliberately **not** added to certified material ancestry.
- Current exact source `\ref` occurrences are captured as NONMATERIAL source-reference candidates for all targets, with current label resolution where available. This supplements (and does NOT promote) historical source E1 references.
- Calibration keywords are *source locators only*. No automatic parameter-fit / prediction status is assigned.

## Query usage

Run `python Paper00-ObservableDependencyCompiler-v1_1.py query --atlas Paper00-DAGAtlas-v1_171.zip --summary`, or use `--target <exact target ID>`, `--family <observable:...>`, or `--condition <canonical condition ID>`. Use `--compact` for concise JSON. The query utility reads the ZIP directly; no extraction necessary.

## Evidence boundaries

(1) `SOURCE_ANCHORED` is not `PROVED`. (2) An explicit historical route is not current-source reverified E3/E4; source files and statuses are preserved verbatim. (3) Proof traversal uses reviewed combined material ledger edges, not citation-only/E1 or source-E2 cache-only edges. (4) AND inputs are route-local. Alternative branches remain distinct; source scope guards are text and cannot be mechanically discharged. (5) Observable families are readout classes, not certificates of actual experimental occurrence. (6) Missing route/material entries cannot be treated as mathematical counterexamples or proof gaps.
