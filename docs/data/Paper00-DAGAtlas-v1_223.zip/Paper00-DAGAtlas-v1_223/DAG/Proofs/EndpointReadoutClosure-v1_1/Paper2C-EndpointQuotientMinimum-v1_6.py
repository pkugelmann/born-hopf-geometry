#!/usr/bin/env python3
"""Independent endpoint quotient / protected rank and positive refinement replay.

No physics beyond the constituted 15-dim Paper II-C carrier is assumed.
See Paper2C-EndpointQuotientMinimum-v1_2.md for exact algebraic proof.
"""
import numpy as np

R = 1.0
r0 = np.sqrt(3.0)
N = 4
pairs = [(i, j) for i in range(N) for j in range(i+1, N)]

sigma1 = np.array([[0, 1], [1, 0]], dtype=complex)
sigma2 = np.array([[0,-1j],[1j,0]], dtype=complex)
sigma3 = np.array([[1, 0],[0,-1]], dtype=complex)
I2 = np.eye(2, dtype=complex)
I4 = np.eye(4, dtype=complex)
gammas = [np.kron(sigma1, I2), np.kron(sigma2, I2),
          np.kron(sigma3, sigma1), np.kron(sigma3, sigma2)]
chi = gammas[0] @ gammas[1] @ gammas[2] @ gammas[3]


def wedge(n):
    """C^4 -> Lambda^2 C^4, v -> n wedge v."""
    J = np.zeros((6,4), dtype=complex)
    for r, (i,j) in enumerate(pairs):
        J[r,i] = -n[j]
        J[r,j] = n[i]
    return J


def geometric_seed(n):
    n = np.asarray(n, dtype=float)
    P = np.outer(n,n)
    J = wedge(n)
    Q = J@J.conj().T
    a, b = 2/np.sqrt(3), 4*np.sqrt(2)/(3*np.sqrt(3))
    T = np.zeros((11,11), dtype=complex)
    T[0,0] = 1
    T[0,1:5] = a*n
    T[1:5,0] = a*n
    T[1:5,1:5] = (5/6)*I4+(2/3)*P
    T[1:5,5:11] = b*J.conj().T
    T[5:11,1:5] = b*J
    T[5:11,5:11] = 0.5*np.eye(6)+Q
    return T


def coordinate_g(a):
    n = np.eye(4)[a]
    X = np.zeros((11,11), dtype=complex)
    J = wedge(n)
    X[0,1:5] = R*n/2
    X[1:5,0] = R*n/2
    X[1:5,5:11] = np.sqrt(2)*R*J.conj().T/3
    X[5:11,1:5] = np.sqrt(2)*R*J/3
    return X


def native(G,S):
    M = np.zeros((15,15),dtype=complex)
    M[:11,:11] = G
    M[11:,11:] = S
    return M


def herm_basis(dim):
    ans = []
    for i in range(dim):
        A = np.zeros((dim,dim),dtype=complex)
        A[i,i] = 1
        ans.append(A)
    for i in range(dim):
        for j in range(i+1,dim):
            A = np.zeros((dim,dim),dtype=complex)
            A[i,j] = A[j,i] = 1
            ans.append(A)
            B = np.zeros((dim,dim),dtype=complex)
            B[i,j] = 1j; B[j,i] = -1j
            ans.append(B)
    assert len(ans) == dim*dim
    return ans


def coords(M):
    """137 independent real coordinates of the native M_11 + M_4 Hermitian algebra."""
    v = []
    for A in (M[:11,:11],M[11:,11:]):
        d = A.shape[0]
        v.extend(A.diagonal().real)
        for i in range(d):
            for j in range(i+1,d):
                v.extend([A[i,j].real,A[i,j].imag])
    return np.asarray(v,dtype=float)


def orth_add(M, Q, tol=1e-9):
    v = coords(M)
    original = np.linalg.norm(v)
    if original == 0: return False
    for q in Q: v -= q*np.dot(q,v)
    for q in Q: v -= q*np.dot(q,v)  # double-orthogonalization
    if np.linalg.norm(v) < tol*original: return False
    Q.append(v/np.linalg.norm(v))
    return True


def min_supported_eigenvalue(M):
    ev = np.linalg.eigvalsh(M)
    ev = ev[ev > 1e-8]
    return float(ev.min())


def main():
    assert np.allclose(chi,chi.conj().T)
    assert np.allclose(chi@chi,I4)
    assert all(np.allclose(g@g,I4) for g in gammas)
    assert all(np.allclose(gammas[i]@gammas[j]+gammas[j]@gammas[i],np.zeros((4,4)))
               for i in range(4) for j in range(i+1,4))
    ns = [s*np.eye(4)[a] for a in range(4) for s in (1,-1)]
    E = []
    for n in ns:
        gamma_n = sum(n[a]*gammas[a] for a in range(4))
        G = geometric_seed(n)/8
        S = (I4 + gamma_n)/8
        E.append(native(G,S))
        eigenG = np.linalg.eigvalsh(G)
        eigenS = np.linalg.eigvalsh(S)
        assert eigenG.min() > 0
        assert np.sum(eigenS > 1e-8) == 2
        assert np.all(eigenS > -1e-10)
    assert np.linalg.norm(sum(E)-np.eye(15)) < 1e-12
    for a in range(4):
        X = native(coordinate_g(a),r0*gammas[a]/4)
        assert np.linalg.norm(sum(r0*n[a]*Ei for n,Ei in zip(ns,E))-X) < 1e-12

    Q=[]
    assert all(orth_add(Ei,Q) for Ei in E)
    assert len(Q)==8
    hG=herm_basis(11)
    hS=herm_basis(4)
    local = [[] for _ in E]
    for i in range(len(E)):
        for j in range(i,len(hG),len(E)):
            local[i].append(native(hG[j],np.zeros((4,4))))
        n=ns[i]
        P=(I4+sum(n[a]*gammas[a] for a in range(4)))/2
        for H in hS:
            local[i].append(native(np.zeros((11,11)),P@H@P))
    assert len(Q)==8
    chosen=[[] for _ in E]
    # round-robin effects so the refinement does not concentrate in one support
    for ix in range(max(map(len,local))):
        for i in range(len(E)):
            if ix < len(local[i]) and orth_add(local[i][ix],Q):
                chosen[i].append(local[i][ix])
    assert len(Q)==136, f'Local native rank is {len(Q)} not 136'
    assert sum(map(len,chosen))==128
    allchildren=[]; childpositions=[]
    for i, parent in enumerate(E):
        k = len(chosen[i]); D=k+1
        norms = [np.linalg.norm(H,ord=2) for H in chosen[i]]
        bound = max(1.,sum(norms))
        epsilon = min_supported_eigenvalue(parent)/(4*D*bound)
        F0 = parent/D - epsilon*sum(chosen[i],start=np.zeros((15,15),dtype=complex))
        children = [F0] + [parent/D+epsilon*H for H in chosen[i]]
        assert all(np.linalg.eigvalsh(F).min()>-1e-12 for F in children)
        assert np.linalg.norm(sum(children)-parent)<1e-12
        allchildren.extend(children)
        childpositions.extend([r0*ns[i]]*len(children))
    assert len(allchildren)==136
    assert np.linalg.norm(sum(allchildren)-np.eye(15))<1e-11
    for a in range(4):
        X=native(coordinate_g(a),r0*gammas[a]/4)
        assert np.linalg.norm(sum(x[a]*F for x,F in zip(childpositions,allchildren))-X)<1e-11
    # Contrasts can be recovered analytically from the family of F_i; the
    # numerical SVD here is an additional check on the 136 actual children.
    Z=np.stack([coords(F) for F in allchildren],axis=1)
    sv=np.linalg.svd(Z,compute_uv=False)
    assert sv[-1] > 1e-10*sv[0], f'Contrast frame is ill-conditioned: {sv[-1]/sv[0]}'
    assert all(abs(np.trace(F[11:,11:]@chi)) < 1e-9 for F in allchildren)
    print('Parent count: ',len(E))
    print('Parent rank:  ',8)
    print('Protected local support codimension: ',1)
    print('Geometric local Hermitian dimension: ',121)
    print('Native local Hermitian dimension: ',len(Q))
    print('Contrasts: ',sum(map(len,chosen)))
    print('Refined effects: ',len(allchildren))
    print('Min/Max frame singular values: ',round(float(sv[-1]),13),round(float(sv[0]),13))
    print('PASS: positive 136-effect exact-moment endpoint quotient POVM')




def rank_of_operators(matrices):
    return int(np.linalg.matrix_rank(np.stack([coords(m) for m in matrices],axis=1),tol=1.e-9))


def geometric_parents_7():
    """Exact source Paper II-C 4 axial + 3 trine geometric parents."""
    a=np.array([2/9,3/8,4/27,1/5,1/5,1/2,10/27,10/27,0,0,0],float)
    sw=np.array([0,2,1,3,4,5,8,9,6,7,10],int)
    b=a[sw]
    d=np.ones(11)-a-b
    ns=[np.array(x,float) for x in ( [1,0,0,0],[-1,0,0,0],[0,1,0,0],[0,-1,0,0])]
    ns += [np.array([0.,0.,np.cos(2*np.pi*j/3),np.sin(2*np.pi*j/3)]) for j in range(3)]
    ge=[]
    for i,n in enumerate(ns):
        Y=sum(n[a]*coordinate_g(a) for a in range(4))
        if i<2:
            G=(np.diag(a)+(1 if i==0 else -1)*coordinate_g(0)/r0)/2
        elif i<4:
            G=(np.diag(b)+(1 if i==2 else -1)*coordinate_g(1)/r0)/2
        else:
            G=(np.diag(d)+2*Y/r0)/3
        ge.append(G)
    return ns,ge


def refine_protected(parents,ns):
    """Construct independent positive tagged refinements with 15 protected contrasts."""
    Q=[]
    assert all(orth_add(E,Q) for E in parents)
    assert len(Q)==len(parents)
    chosen=[[] for _ in parents]
    zG=np.zeros((11,11),complex)
    for i,(n,E) in enumerate(zip(ns,parents)):
        P=(I4+sum(n[a]*gammas[a] for a in range(4)))/2
        for h in herm_basis(4):
            H=native(zG,P@h@P)
            if orth_add(H,Q):
                chosen[i].append(H)
    assert len(Q)==len(parents)+15
    children=[];childpos=[]
    for i,(E,n) in enumerate(zip(parents,ns)):
        k=len(chosen[i]);D=k+1
        norms=[np.linalg.norm(H,ord=2) for H in chosen[i]]
        eps=min_supported_eigenvalue(E)/(4*D*max(1,sum(norms)))
        child=[E/D-eps*sum(chosen[i],start=np.zeros((15,15),complex))]
        child.extend([E/D+eps*H for H in chosen[i]])
        assert all(np.linalg.eigvalsh(F).min()>-1e-12 for F in child)
        assert np.linalg.norm(sum(child)-E)<1e-10
        children.extend(child);childpos.extend([r0*n]*D)
    assert len(children)==len(parents)+15
    assert rank_of_operators(children)==len(children)
    assert np.linalg.norm(sum(children)-np.eye(15))<1e-10
    for a in range(4):
        X=native(coordinate_g(a),r0*gammas[a]/4)
        assert np.linalg.norm(sum(x[a]*F for x,F in zip(childpos,children))-X)<1e-10
    return children


def exterior_rep(R):
    """Natural geometric O(4) action on C + C^4 + Lambda^2 C^4."""
    U=np.zeros((11,11),dtype=complex)
    U[0,0]=1
    U[1:5,1:5]=R
    for ii,(a,b) in enumerate(pairs):
        for jj,(c,d) in enumerate(pairs):
            U[5+ii,5+jj]=R[a,c]*R[b,d]-R[a,d]*R[b,c]
    return U


def check_finite_symmetries(ns7,gg,ns8,parents8):
    R4=np.eye(4)
    R4[:2,:2]=[[0,-1],[1,0]]
    theta=2*np.pi/3
    R3=np.eye(4)
    R3[2:,2:]=[[np.cos(theta),-np.sin(theta)],[np.sin(theta),np.cos(theta)]]
    for R in (R4,R3):
        U=exterior_rep(R)
        for n,G in zip(ns7,gg):
            x=R@n
            j=next(j for j,v in enumerate(ns7) if np.linalg.norm(x-v)<1e-8)
            assert np.linalg.norm(U@G@U.conj().T-gg[j])<1.e-9
    # Q8 inversion and even-coordinate cyclic permutation in SO(4)
    RI=-np.eye(4)
    R3cycle=np.eye(4)
    R3cycle[:3,:3]=[[0,0,1],[1,0,0],[0,1,0]]
    for R in (RI,R3cycle):
        U=exterior_rep(R)
        for n,E in zip(ns8,parents8):
            j=next(j for j,v in enumerate(ns8) if np.linalg.norm(R@n-v)<1.e-8)
            assert np.linalg.norm(U@E[:11,:11]@U.conj().T-parents8[j][:11,:11])<1.e-9
    print('PASS: exact-support C4 x C3 and Q8 A4 x inversion covariance')


def support_rank_check():
    ns8=[s*np.eye(4)[a] for a in range(4) for s in (1.,-1.)]
    parents8=[]
    for n in ns8:
        G=geometric_seed(n)/8
        S=(I4+sum(n[a]*gammas[a] for a in range(4)))/8
        parents8.append(native(G,S))
    assert rank_of_operators([native(E[:11,:11],np.zeros((4,4))) for E in parents8])==8
    assert rank_of_operators(parents8)==8
    children23=refine_protected(parents8,ns8)
    ns7,gg=geometric_parents_7()
    assert min(float(np.linalg.eigvalsh(G).min()) for G in gg)>-1.e-10
    assert np.linalg.norm(sum(gg)-np.eye(11))<1e-10
    assert rank_of_operators([native(G,np.zeros((4,4))) for G in gg])==7
    ww=[1/8]*4+[1/6]*3
    parents7=[]
    for n,G,w in zip(ns7,gg,ww):
        S=w*(I4+sum(n[a]*gammas[a] for a in range(4)))
        parents7.append(native(G,S))
    assert np.linalg.norm(sum(parents7)-np.eye(15))<1e-10
    assert rank_of_operators(parents7)==7
    children22=refine_protected(parents7,ns7)
    check_finite_symmetries(ns7,gg,ns8,parents8)
    print('Seven-support geometric rank:',7,' protected tagged optimum:',len(children22))
    print('Quaternion-axis geometric rank:',8,' protected tagged optimum:',len(children23))
    print('PASS: source seven-parent and Q8 eight-parent minimal protected refinements')


if __name__ == '__main__':
    main()
    support_rank_check()


def check_arbitrary_effect_seven_position_rank_theorem():
    """Independent finite arithmetic & representation replay of the v1_4 exact proof.

    This validates the source constants and group averaging reduction.  The
    no-go for arbitrary effects is the analytic Cauchy/positive-cubic proof
    in the companion Markdown, NOT inferred from sampling/SVD.
    """
    import sympy as sp
    from fractions import Fraction as F
    ns, effects = geometric_parents_7()
    assert len(effects) == 7
    # K is the group generated by independent sign flips on the axial
    # directions and the order-three rotation / reflection of the trine.
    C = np.eye(4)
    theta=2*np.pi/3
    C[2:,2:] = [[np.cos(theta),-np.sin(theta)],
                [np.sin(theta),np.cos(theta)]]
    Rfl = np.diag([1.,1.,1.,-1.])
    group=[]
    for aa in (1.,-1.):
        for bb in (1.,-1.):
            for k in (0,1,2):
                for eps in (0,1):
                    g=np.diag([aa,bb,1.,1.]) @ np.linalg.matrix_power(C,k)
                    if eps: g=g@Rfl
                    group.append(g)
    assert len(group)==24
    for g in group:
        U=exterior_rep(g)
        assert np.linalg.norm(U@U.conj().T-np.eye(11)) < 1e-12
        for a in range(4):
            L=U @ coordinate_g(a) @ U.conj().T
            T=sum(g[b,a]*coordinate_g(b) for b in range(4))
            assert np.linalg.norm(L-T) < 2e-12
        for n,G in zip(ns,effects):
            rotated=g@n
            j=next(j for j,m in enumerate(ns)
                   if np.linalg.norm(m-rotated)<1e-10)
            assert np.linalg.norm(U@G@U.conj().T-effects[j]) < 2e-12
    # A random complex-Hermitian 11x11 operator averaged over K is
    # diagonal, with repeated entries precisely on the three 2D irreps.
    rng=np.random.default_rng(20261120)
    Z=rng.standard_normal((11,11))+1j*rng.standard_normal((11,11))
    Z=(Z+Z.conj().T)/2
    avg=sum(exterior_rep(g)@Z@exterior_rep(g).conj().T for g in group)/24
    assert np.linalg.norm(avg-np.diag(np.diag(avg)))<3e-13
    for i,j in [(3,4),(6,7),(8,9)]:
        assert abs(avg[i,i]-avg[j,j])<3e-13

    # Verify exact resource entries of Paper II-C's pre-existing seven-parent
    # witness and all principal-minor premises of the new general theorem.
    a=[F(2,9),F(3,8),F(4,27),F(1,5),F(1,5),F(1,2),
       F(10,27),F(10,27),F(0),F(0),F(0)]
    perm=[0,2,1,3,4,5,8,9,6,7,10]
    b=[a[i] for i in perm]
    d=[1-a[i]-b[i] for i in range(11)]
    assert all(q>=0 for q in a+b+d)
    # [e0,u1,u2,u3,w12,w13,w23,w34] = [0,1,2,3,5,6,8,10]
    assert a[0]*a[1]>=F(1,12)
    assert b[0]*b[2]>=F(1,12)
    assert d[0]*d[3]>=F(1,3)
    assert a[3]*a[6]>=F(2,27)
    assert d[1]*d[6]>=F(8,27)
    assert b[3]*b[8]>=F(2,27)
    assert d[2]*d[8]>=F(8,27)
    assert a[2]*a[5]>=F(2,27)
    assert b[1]*b[5]>=F(2,27)
    assert a[1]-a[2]>=a[3]>0
    assert b[2]-b[1]>=b[3]>0
    assert a[5]>a[3] and b[5]>b[3]
    # The v1_4 global positive-cubic certificate is *exact*.
    c,z=sp.symbols('c z', positive=True)
    P=729*c**3-513*c**2+104*c-4
    assert sp.simplify(27*P.subs(c,z/27)-((z-2)*(z-7)*(z-10)+32))==0
    # On z>2 the three intervals z<7, 7<=z<=10, z>10 prove
    # (z-2)(z-7)(z-10)+32>=min(32,14)>0; verification
    # below checks the relevant exact elementary bounds.
    assert (sp.Rational(10)-2)*sp.Rational(9,4) == 18
    assert (32-18)>0
    print('PASS: 24-element K geometric transport and diagonal commutant')
    print('PASS: exact seven-support resource minors and opposite/concordant order')
    print('PASS: exact positive cubic identity; arbitrary-effects 7-rank proof certificate')


if __name__ == '__main__':
    check_arbitrary_effect_seven_position_rank_theorem()


def verify_radon_clifford_unrestricted_six_no_go():
    """Verify the explicit positive dual witness for representative six-designs.

    The global no-go is the *symbolic exterior-algebra identity* in the
    accompanying manuscript. These floating-point examples do not certify
    the universal quantifier, but independently challenge implementation
    errors in the witness formula and strict spectral coefficients.
    """
    # From Paper II-C's spherical weighted design, a 5x6 frame with rows
    # [sqrt(w); 2 sqrt(w)*n] is Parseval and has one-dimensional kernel t.
    # The parameter sets below obey norm(t)=1 and t dot sqrt(w)=0 exactly.
    test_vectors = [
        ('equal 3+3', np.r_[np.sqrt([1/6]*3), -np.sqrt([1/6]*3)]),
        ('unequal 3+3 A', np.r_[np.sqrt([.10,.18,.22]), -np.sqrt([.10,.18,.22])]),
        ('unequal 3+3 B', np.r_[np.sqrt([.01,.02,.47]), -np.sqrt([.01,.02,.47])]),
        ('two-level 2+4', np.r_[np.sqrt([3/8]*2), -np.ones(4)/4]),
    ]
    for name,t in test_vectors:
        w=(1-t*t)/5
        u=np.sqrt(w)
        assert abs(np.dot(t,t)-1)<2e-14 and abs(np.dot(t,u))<2e-14
        # Make four orthonormal rows completing u,t to an O(6) matrix.
        _,_,vh=np.linalg.svd(np.vstack([u,t]),full_matrices=True)
        f=vh[2:,:]
        n=(f/(2*u)).T  # six unit vectors in R^4
        assert np.max(np.abs(np.sum(n*n,axis=1)-1))<2e-13
        assert np.linalg.norm(w@n)<2e-13
        assert np.linalg.norm(np.einsum('i,ia,ib->ab',w,n,n)-np.eye(4)/4)<2e-13
        c=t*u
        assert abs(c.sum())<2e-13 and np.linalg.norm(c@n)<2e-13
        P=np.flatnonzero(c>0);M=np.flatnonzero(c<0)
        mu=c[P]/c[P].sum(); nu=-c[M]/(-c[M]).sum()
        assert abs(mu.sum()-1)<2e-13 and abs(nu.sum()-1)<2e-13
        assert np.linalg.norm(mu@n[P]-nu@n[M])<2e-13

        # All test matrices are real symmetric, but the exact theorem
        # excludes arbitrary COMPLEX Hermitian correction H as well.
        Z=[np.zeros((11,11),dtype=float) for i in range(6)]
        for ii,i in enumerate(P):
            for jj,j in enumerate(M):
                ni,nj=n[i],n[j]
                d=1-ni@nj
                assert d>1e-10, 'duplicate cross-sign labels'
                v=ni-nj
                wedge_ij=wedge(ni).real@nj
                x=np.r_[-d,v,wedge_ij]
                y=np.r_[+d,v,wedge_ij]
                Ti=np.vstack((-ni.reshape(1,4),np.eye(4),-wedge(ni).real))
                Tj=np.vstack((-nj.reshape(1,4),np.eye(4),-wedge(nj).real))
                assert np.linalg.norm(x-Ti@v)<3e-13
                assert np.linalg.norm(y-Tj@v)<3e-13
                q=mu[ii]*nu[jj]/d
                Z[i]+=q*np.outer(x,x)
                Z[j]+=q*np.outer(y,y)
        balance=sum(Z[i] for i in P)-sum(Z[j] for j in M)
        assert np.linalg.norm(balance)<1e-10
        margin=[]
        for i in range(6):
            ni=n[i]
            Ti=np.vstack((-ni.reshape(1,4),np.eye(4),-wedge(ni).real))
            assert np.linalg.norm(Ti.T@Ti-2*np.eye(4))<1e-12
            Pi=Ti@Ti.T/2
            assert np.linalg.norm(Pi@Z[i]@Pi-Z[i])<2e-11
            assert np.linalg.eigvalsh(Z[i]).min()>-2e-11
            Ci=np.eye(11)+4/r0*sum(ni[a]*coordinate_g(a).real for a in range(4))
            eig=np.linalg.eigvalsh(Ti.T@Ci@Ti/2)
            target=np.array([1-2/np.sqrt(3)]+[1-4*np.sqrt(2)/(3*np.sqrt(3))]*3)
            assert np.linalg.norm(np.sort(eig)-np.sort(target))<3e-13
            q=float(np.trace(Ci@Z[i]))
            assert q<-1e-9
            margin.append(w[i]/abs(c[i])*q)
        # This is a Farkas objective: it would be >=0 for any PSD
        # geometric effects, but is strictly <0 because H cancels.
        gap=sum(margin)
        assert gap<-0.01
        print('PASS: Radon-Clifford',name,
              ' witness balance',round(float(np.linalg.norm(balance)),13),
              ' negative dual objective',round(float(gap),9))
    import sympy as sp
    # Exact strict spectral margin checks: 4>3 and 32>27.
    assert sp.simplify(1-2/sp.sqrt(3))<0
    assert sp.simplify(1-4*sp.sqrt(2)/(3*sp.sqrt(3)))<0
    print('PASS: symbolic strict negativity and unrestricted six-outcome dual proof premises')


if __name__ == '__main__':
    verify_radon_clifford_unrestricted_six_no_go()


def verify_sharp_universal_geometric_rank_six_radius():
    """Numerical replay of the new exact *universal* dual identities.

    Tests kernel positivity, balance, trace/moment formula, H cancellation,
    the optimized sharp radius, zero-c nodes, and coincident support nodes.
    The independent symbolic lemma in v1_6.md supplies the universal proof.
    """
    import sympy as sp

    rng = np.random.default_rng(20261120)
    geomY = np.array([coordinate_g(j).real for j in range(4)])
    a = 2*np.sqrt(2)/3
    r6 = np.sqrt(34)/3
    s, t = 3*np.sqrt(2)/np.sqrt(17), 4/np.sqrt(17)
    assert abs(s*s-sp.Rational(18,17))<1e-14
    assert abs(t*t-sp.Rational(16,17))<1e-14
    assert abs(4*(s+a*t)/(2+s*s+t*t)-r6)<1e-14

    sq = sp.sqrt
    ss,tt = 3*sq(2)/sq(17),4/sq(17)
    aa=2*sq(2)/3
    assert sp.simplify(ss**2+tt**2-2) == 0
    assert sp.simplify(4*(ss+aa*tt)/(2+ss**2+tt**2)-sq(34)/3)==0
    assert sp.simplify(sq(34)/3-sq(3))>0
    assert sp.simplify(2-sq(34)/3)>0

    def kernel(n, p, s, t):
        d = 1.0-float(n@p)
        if d<1e-10:
            # Coincident convention; any deterministic real unit tangent.
            j=int(np.argmin(np.abs(n)))
            v=np.eye(4)[j]-n[j]*n
            v/=np.linalg.norm(v)
            z=np.r_[0., v, -t*(wedge(n).real@v)]
            return 2*np.outer(z,z)
        v=n-p
        z=np.r_[-s*d, v, t*(wedge(n).real@p)]
        return np.outer(z,z)/d

    def nullframe(A):
        u, sing, vh=np.linalg.svd(A, full_matrices=True)
        rank=int(np.sum(sing>1e-11))
        return vh[rank:].T

    def test_random_case(n, c, r):
        count=len(n)
        A=np.vstack((np.ones(count),n.T))
        assert np.linalg.norm(A@c)<1e-11
        pos=np.flatnonzero(c>1e-10)
        neg=np.flatnonzero(c<-1e-10)
        C=sum(c[pos]); assert C>1e-9 and len(neg)>0
        mu=c[pos]/C
        nu=-c[neg]/C
        m=mu@n[pos]
        assert np.linalg.norm(m-nu@n[neg])<2e-11
        D=[]
        for i in range(count):
            opposite, weights=(neg,nu) if c[i]>=-1e-11 else (pos,mu)
            D_i=sum((w*kernel(n[i],n[j],s,t) for j,w in zip(opposite,weights)),
                    start=np.zeros((11,11)))/C
            assert np.linalg.eigvalsh(D_i).min()>-2e-11
            D.append(D_i)
        D=np.array(D)
        assert np.linalg.norm(np.einsum('i,ijk->jk',c,D))<4e-10
        for i in range(count):
            trace_pred=(2+s*s+t*t+(t*t-s*s)*float(n[i]@m))/C
            y_pred=(-R*(s+a*t)*n[i]+R*(s-a*t)*m)/C
            assert abs(np.trace(D[i])-trace_pred)<1e-9
            actual=np.array([np.trace(geomY[j]@D[i]) for j in range(4)])
            assert np.linalg.norm(actual-y_pred)<1e-9
        # Synthesize a non-positive test family with correct zero/first
        # moments to verify the dual identity without falsely assuming
        # that the forbidden positive family exists.
        alpha=np.linalg.lstsq(A,np.eye(5)[0],rcond=None)[0]
        beta=np.stack([
            np.linalg.lstsq(A,np.eye(5)[j+1]/r,rcond=None)[0]
            for j in range(4)],axis=1)
        H=rng.normal(size=(11,11))+1j*rng.normal(size=(11,11))
        H=(H+H.conj().T)/2
        G=[alpha[i]*np.eye(11)
           +sum(beta[i,j]*geomY[j] for j in range(4))
           +c[i]*H
           for i in range(count)]
        assert np.linalg.norm(sum(G)-np.eye(11))<4e-11
        for j in range(4):
            assert np.linalg.norm(sum(r*n[i,j]*G[i] for i in range(count))-geomY[j])<4e-11
        lhs=sum(np.trace(G[i]@D[i]).real for i in range(count))
        rhs=(2+s*s+t*t-4*R/r*(s+a*t))/C
        assert abs(lhs-rhs)<2e-9, (lhs,rhs)
        return float(lhs)

    # Explicit kernel balance and trace--moment identities for arbitrary
    # asymmetric, rotated directions; includes self-pairing.
    for _ in range(15):
        n=rng.normal(size=4);n/=np.linalg.norm(n)
        p=rng.normal(size=4);p/=np.linalg.norm(p)
        for q in (p,n):
            K=kernel(n,q,s,t)
            assert np.linalg.eigvalsh(K).min()>-2e-11
            assert abs(np.trace(K)-(2+s*s+t*t+(t*t-s*s)*(n@q)))<1e-10
            moment_pred=R*(-(s+a*t)*n+(s-a*t)*q)
            moment=np.array([np.trace(geomY[j]@K) for j in range(4)])
            assert np.linalg.norm(moment-moment_pred)<1e-10

    for count in (6,7,10):
        n=rng.normal(size=(count,4))
        n/=np.linalg.norm(n,axis=1)[:,None]
        K=nullframe(np.vstack((np.ones(count),n.T)))
        c=K@rng.normal(size=K.shape[1])
        c/=np.linalg.norm(c)
        forbidden=test_random_case(n,c,r0)
        threshold=test_random_case(n,c,r6)
        assert forbidden<-.01 and abs(threshold)<1e-9
        if count>6:
            # Induce precisely one coefficient c_i=0 within the nullspace.
            c=K[:,0]-K[:,1]*(K[0,0]/K[0,1])
            c/=np.linalg.norm(c)
            assert abs(c[0])<1e-12
            assert test_random_case(n,c,r0)<-.01
            assert abs(test_random_case(n,c,r6))<1e-9

    n=rng.normal(size=(7,4));n/=np.linalg.norm(n,axis=1)[:,None]
    n[-1]=n[0]  # Coincident labels can belong to opposite c-sign classes.
    K=nullframe(np.vstack((np.ones(7),n.T)))
    c=K@rng.normal(size=K.shape[1]);c/=np.linalg.norm(c)
    assert test_random_case(n,c,r0)<-.01
    assert abs(test_random_case(n,c,r6))<1e-9

    # The source-proved sharp six-outcome *positive* construction, including
    # native spinor compression (not just the geometric projection).
    A=np.diag(np.array([.5,9/17,9/17,8/17,8/17,1,.5,.5,.5,.5,0]))
    B=np.eye(11)-A
    ns=[]; Geffects=[]; full=[]
    for plane,resource in ((0,A),(2,B)):
        for j in range(3):
            theta=2*np.pi*j/3
            n=np.zeros(4)
            n[plane]=np.cos(theta);n[plane+1]=np.sin(theta)
            Y_n=sum(n[k]*geomY[k] for k in range(4))
            gamma_n=sum(n[k]*gammas[k] for k in range(4))
            G=(resource+2*Y_n/r6)/3
            S=(I4+(r0/r6)*gamma_n)/6
            assert np.linalg.eigvalsh(G).min()>-1e-12
            assert np.linalg.eigvalsh(S).min()>-1e-12
            ns.append(n); Geffects.append(G); full.append(native(G,S))
    assert np.linalg.norm(sum(Geffects)-np.eye(11))<5e-12
    assert np.linalg.norm(sum(full)-np.eye(15))<5e-12
    for aidx in range(4):
        X=native(geomY[aidx],r0*gammas[aidx]/4)
        assert np.linalg.norm(sum(r6*ns[i][aidx]*full[i] for i in range(6))-X)<5e-12
    spectrum=np.linalg.svd(np.stack([G.reshape(-1) for G in Geffects],axis=1),compute_uv=False)
    assert spectrum[-1]>1e-10*spectrum[0]
    print('PASS: exact symbolic optimized \u221a34/3 radial certificate')
    print('PASS: full 11x11 dual-kernel checks (6/7/10 labels, zero coefficients, collisions)')
    print('PASS: geometric rank 6 and native PSD six-orthogonal-trine saturation at r6')


if __name__ == '__main__':
    verify_sharp_universal_geometric_rank_six_radius()
