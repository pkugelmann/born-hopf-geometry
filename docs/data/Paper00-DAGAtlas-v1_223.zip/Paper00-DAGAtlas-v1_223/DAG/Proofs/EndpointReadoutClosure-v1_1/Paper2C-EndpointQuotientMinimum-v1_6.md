# Paper II-C — Exact minimal endpoint quotient readout

**Research supplement v1_6 — 20 November 2026**  
**Current status:** v1_2 proves the sharp 136-effect endpoint quotient bound; v1_3–v1_4 prove fixed-support protected readout results; v1_5 proves the unrestricted six-outcome endpoint no-go; **v1_6 strengthens that result to an exact, universally sharp radius threshold for geometric rank six, completing the entire native localization outcome-count phase diagram and fixing the unrestricted endpoint protected-readout minimum at 22**. The canonical TeX/PDF, DAG and proof-chain audit archives remain unchanged pending integration. Sections 8–18 retain historical OPEN-status language for provenance; the v1_6 results and final ledger supersede those intermediate statements.  
**Current upstream sources:** `Paper1A-Geometry-v5_180.tex`, `Paper2C-ReciprocalLocalization-v2_172.tex`, especially `p2c:thm:v255-seven-outcome-attainment`, `p2c:thm:v354-unique-protected-obstruction`, and `p2c:thm:v354-exact-native-rank`.

## Result

**Theorem (sharp 136-outcome endpoint bound).** On the native carrier
\[
\mathcal H_D=\underbrace{\bigl(\mathbb C\oplus\mathbb C^4\oplus\Lambda^2\mathbb C^4\bigr)}_{\mathcal H_G,\,\dim=11}\oplus\underbrace{\mathbb C^4}_{\mathcal H_S},
\]
with the intrinsic coordinate tuple \(X_a^D\) and radius \(r_0=\sqrt3R_{\mathrm{mom}}\), the smallest number of effects in any finite normalized exact-first-moment POVM whose real effect span is the full endpoint chiral hyperplane
\[
\mathcal V_0=\{H\in(M_{11}(\mathbb C)\oplus M_4(\mathbb C))_{\mathrm{sa}}:\operatorname{Tr}(H(0\oplus\chi))=0\}
\]
is exactly
\[\boxed{N_{\min}^{\mathrm{endpoint\ quotient}}=136}.\]
The outcome convention permits multiple passively tagged effects assigned the same endpoint position, as in Paper II-C. This is a **mathematical POVM capability theorem**, not physical detector occurrence or GP2 source selection.

The existing source theorem proved \(136\le N_{\min}\le141\). The construction below replaces its 14 rank-deficient parents by **eight full-geometric-support parents**. The 8-point support is the quaternion-unit group \(Q_8=\{\pm1,\pm i,\pm j,\pm k\}\), a 16-cell within the 24-cell and 600-cell vertex set displayed in Paper I-A. Its use here is a legitimate *same Euclidean shape* of eight coordinate-readout directions, not a physical identification of outcome space with the momentum 600-cell. The 11-dimensional exterior-degree operator carrier belongs to the **current Paper II-C construction**; it should **not** be attributed as an already-derived 11-dimensional physical representation in Paper I-A.

## Exact native effects

Write \(R=R_{\mathrm{mom}}\), \(r_0=\sqrt3R\), \(V=\mathbb C^4\), \(W=\Lambda^2V\), and use the ordered orthonormal real gauge of `p2c:thm:v255-seven-outcome-attainment`. For unit \(n\in\mathbb R^4\), define
\[
L_n=|e_0\rangle\langle n|+|n\rangle\langle e_0|,
\qquad
J_n:V\to W,\quad J_n(v)=n\wedge v,
\qquad
B_n=J_n+J_n^\dagger.
\]
Here \(L_n\) and \(B_n\) act by zero outside the indicated adjacent exterior degrees. Define projections \(P_n=|n\rangle\langle n|\) on \(V\) and \(Q_n=J_nJ_n^\dagger\) on \(W\) (rank three).

The previously constituted intrinsic geometric coordinate is
\[
Y(n):=\sum_a n_a P_GX_a^DP_G
=\frac R2 L_n+\frac{\sqrt2R}{3}B_n.
\]
Set
\[
a=\frac2{\sqrt3},\qquad b=\frac{4\sqrt2}{3\sqrt3},
\]
and define the positive geometric seed on \(\mathbb C\oplus V\oplus W\):
\[
T(n)=
\begin{pmatrix}
1 & a\langle n| & 0\\
a|n\rangle & \frac56I_V+\frac23P_n & bJ_n^\dagger\\
0 & bJ_n & \frac12I_W+Q_n
\end{pmatrix}.
\]
For the eight unit directions
\[
\mathcal N=\{+e_1,-e_1,+e_2,-e_2,+e_3,-e_3,+e_4,-e_4\},
\]
assign position \(x_n=r_0n\) and define native effects
\[
\boxed{E_n=G_n\oplus S_n,\qquad
G_n=\tfrac18T(n),\quad
S_n=\tfrac18\bigl(I_4+\gamma(n)\bigr),\quad
\gamma(n)=\sum_a n_a\gamma_a.}
\]
The four Hermitian \(\gamma_a\) anticommute, square to identity and give the protected coordinate \(X_a^S=(r_0/4)\gamma_a\), as in Paper II-C.

## Verification (exact, not numerical)

**1. Strict positivity and support.** For each unit \(n\), the decompositions
\[
V=\mathbb Cn\oplus n^\perp,\qquad
W=(n\wedge n^\perp)\oplus\Lambda^2n^\perp
\]
block-diagonalize \(T(n)\) into one scalar/longitudinal \(2\times2\) block, three transverse/vector–wedge \(2\times2\) blocks, and three \(1\times1\) blocks:
\[
\begin{pmatrix}1&a\\a&3/2\end{pmatrix},\qquad
\begin{pmatrix}5/6&b\\b&3/2\end{pmatrix}\ \text{(three copies)},
\qquad [1/2]\ \text{(three copies)}.
\]
Both \(2\times2\) blocks have positive diagonal entries and exactly positive determinants
\[
\det_1=\frac32-\frac43=\boxed{\frac16},\qquad
\det_2=\frac54-\frac{32}{27}=\boxed{\frac7{108}}.
\]
Thus \(G_n\succ0\) on all eleven geometric dimensions. Meanwhile
\(S_n=\tfrac14P_+(n)\) is positive of **rank two**, with \(P_+(n)=(I+\gamma(n))/2\). Therefore \(E_n\) is strictly positive on its **13-dimensional native support**.

**2. Normalization.** By antipodality, odd terms \(L_n,B_n,\gamma(n)\) cancel in \(\sum_n E_n\). The constant scalar block gives 1. On \(V\),
\[
\frac14\sum_{a=1}^4\left(\frac56I_V+\frac23P_{e_a}\right)=I_V.
\]
For every wedge basis vector \(e_a\wedge e_b\), exactly two of the four \(Q_{e_c}\) act as one, hence \(\sum_cQ_{e_c}=2I_W\), so
\[
\frac14\sum_{c=1}^4\left(\tfrac12I_W+Q_{e_c}\right)=I_W.
\]
Finally \(\sum_n S_n=I_4\). Therefore \(\boxed{\sum_n E_n=I_{15}}\).

**3. Exact first moments.** Again by antipodality, all even terms cancel in the signed differences. For every \(a\),
\[
\sum_{n\in\mathcal N}x_{na}G_n
=\frac{r_0}{8}\bigl(T(e_a)-T(-e_a)\bigr)
=\frac{r_0a}{4}L_{e_a}+\frac{r_0b}{4}B_{e_a}
=\frac R2L_{e_a}+\frac{\sqrt2R}{3}B_{e_a}=Y_a.
\]
Similarly \(\sum_nx_{na}S_n=(r_0/4)\gamma_a=X_a^S\). Thus
\(\boxed{\sum_nx_{na}E_n=X_a^D}\) for all four coordinates.

**4. Eight independent parents.** Suppose \(\sum_a (u_aE_{+e_a}+v_aE_{-e_a})=0\). The scalar/vector cross-block of the geometric compression implies \(u_a-v_a=0\) individually for all \(a\). Writing \(c_a=u_a=v_a\), the scalar block implies \(\sum_ac_a=0\). The vector diagonal block then gives
\(\sum_a c_a[(5/6)I_V+(2/3)P_{e_a}]=(2/3)\operatorname{diag}(c_1,c_2,c_3,c_4)=0\), hence all \(c_a=0\). So the eight native effects are independent: \(b=8\).

**5. Full 136-dimensional local support.** One geometric effect already has full rank 11, so its locally supported Hermitian directions span all \(M_{11}(\mathbb C)_{\mathrm{sa}}\), dimension \(121\). The eight protected directions with equal weights \(w_n=1/8\) satisfy
\(\sum w_nn=0\) and \(\sum w_nnn^T=I_4/4\). By the existing exact theorem `p2c:thm:v354-unique-protected-obstruction`, their locally supported Hermitian span is precisely \(\chi^\perp\), dimension \(15\). Thus the total locally supported native real span has dimension
\[d=121+15=\boxed{136}.\]

**6. Sharp 136-effect refinement.** Apply the positive supported-refinement lemma already proved in `p2c:thm:v354-exact-native-rank`: from \(m\) parent effects of rank \(b\) spanning a locally supported \(d\)-dimensional space, one obtains \(m+d-b\) positive, same-position tagged children that span the latter space. With \(m=b=8\), \(d=136\), this gives \(8+136-8=136\) outcomes. Explicitly select 128 locally supported Hermitian contrasts \(H_{n,j}\) extending the 8 parents to a basis of \(\mathcal V_0\). For each parent with \(k_n\) contrasts, define
\[
F_{n,0}=\frac{E_n}{k_n+1}-\varepsilon\sum_{j=1}^{k_n}H_{n,j},\quad
F_{n,j}=\frac{E_n}{k_n+1}+\varepsilon H_{n,j}\quad(1\le j\le k_n).
\]
All children have position \(x_n\). For sufficiently small positive \(\varepsilon\), positivity holds **on the original native support** because the parent is strictly positive there. Their sum is \(E_n\), preserving normalization and first moments; their span contains each \(E_n\) and every \(H_{n,j}\). The number is \(\sum_n(k_n+1)=128+8=136\).

**7. Optimality.** Every endpoint effect is orthogonal to \(\widetilde\chi=0\oplus\chi\), and the target space has real dimension 136. The span of \(N\) operators has dimension at most \(N\). Thus \(N\ge136\) for any endpoint quotient-tomographic POVM. Combined with step 6, **\(N=136\) is sharp**.

## Source patch / proof-chain impact

- **Replace the upper bound** in the statement of `p2c:thm:v354-exact-native-rank`: “a 141-outcome POVM” → “a 136-outcome POVM”, and the interval \([136,141]\) → the equality \(N_{\min}=136\). Retain the existing proof of \(D_{\max}(r_0)=136\), which is still valid.
- **Append steps 1–7** as the sharp-attainment construction in the theorem proof (alternatively a new corollary directly after the theorem), and update `p2c:rem:v355-endpoint-physical-firewall` to say exact minimum 136.
- **Retire only the specific endpoint outcome-count obligation**, if present in the active DAG/audit ledger. Do not retire the separate 6-vs-7 minimal-position question, 21-vs-22 protected-direct-readout question, or any physical owner/occurrence/GP3 action condition.
- **Paper I-A provenance:** its literal \(Q_8\) unit-quaternion vertices and \(2I\) 600-cell support contain the eight axes, while the **operator** input is the separately constituted \(\Lambda^0\mathbb C^4\oplus\Lambda^1\mathbb C^4\oplus\Lambda^2\mathbb C^4\) carrier and intrinsic Clifford tuple in **Paper II-C**. Paper I-A motivates the exact quaternionic eight-axis support, but that provenance is not a proof of an obligatory or physically selected readout. The argument does not select \(Q_8\) as a physical detector support or as a unique subgroup mechanism.

## Independent executable replay

`Paper2C-EndpointQuotientMinimum-v1_3.py` constructs the eight \(15\times15\) native block-diagonal effects, verifies positivity, normalization, all four exact first moments (within numerical error), parent independence, protected rank 15, and explicitly chooses and constructs **136 positive refined effects** with full real rank 136. The paper proof above uses exact rational determinant margins and finite-dimensional linear algebra; numerical replay is a secondary check.

**Remaining boundary:** This does not derive a GP2-selected measurement apparatus, a frequency law, or channel dynamics; those requirements are distinct from the now-sharp mathematical endpoint count.


## v1_2 independent verification record (20 November 2026)

**E1 — source-level replay.** Current manuscript `Paper2C-ReciprocalLocalization-v2_172.tex` explicitly gives (i) the ordered native 11+4 carrier and the exact two geometric coordinate coefficients in theorem `p2c:thm:v255-seven-outcome-attainment`; (ii) the protected endpoint design theorem `p2c:thm:v354-unique-protected-obstruction`; and (iii) the supported positive refinement lemma inside `p2c:thm:v354-exact-native-rank`. The proposed eight parents use those **same** input objects; they are not substituted Standard Model or detector-specific effects.

**E3 — independent construction/replay.** A separate script from the supplement builds the 15-by-15 matrices with explicit complex Clifford gamma matrices and a wedge map `n∧v`, constructs the 8 parents, checks normalization/moments, establishes real rank 136 for all locally supported native directions, selects 128 independent supported contrasts, and constructs the 136 children with positive eigenvalues and unchanged exact moments within floating-point precision. The executable reports `PASS`; its floating-point test is supplementary to the preceding exact block-determinant, moment, span and refinement proof.

**E4 — direct failure-mode challenges.** (a) Avoid conflating an existence certificate with a canonical source-selected detector: the `Q_8` support is a **choice** of coordinate directions. (b) Preserve the native **block-diagonal** algebra `M_11⊕M_4`, not the ambient `M_15`; otherwise the 136 count is wrong. (c) Preserve **rank-two** protected supports: perturbations in the 15-dimensional chiral direction are forbidden. (d) Positivity of the refined effects must be checked **on each parent support**; the exact strict margins `1/6` and `7/108` are what license this. (e) No statement about an optimal **distinct-position** count follows: the 136 children are passively distinguished tags at eight positions.

**Precise evidence boundary.** The exact algebraic proof plus independent matrix replay justify a new sharp *mathematical endpoint-quotient outcome-count* theorem. A fully protocol-compliant global DAG/audit status change still requires a canonical source patch, DAG dependency and issue reconciliation, plus archive consistency/integrity checks. All other open mathematical optimization and physical occurrence gates are unchanged.

---

# v1_3 extension — Paper I-A finite rotations, protected-readout rank and the 6/7–21/22 connection

**Date:** 20 November 2026. **Type:** new exact finite-dimensional mathematics over the same constituted Paper II-C coordinate operator; no physical measurement occurrence. This extension retains the original v1_2 136-effect endpoint theorem unchanged. The current Paper II-C source still prints both unrestricted intervals `6–7` and `21–22`; this extension **does not silently close** either interval.

## 8. A necessary rank-six geometry for 21 protected outcomes

Define the real 15-dimensional *pure protected endpoint target*
\[
\mathcal T:=\{0_G\oplus T:\ T=T^\dagger,\ \operatorname{Tr}(T\chi)=0\}\subset (M_{11}\oplus M_4)_{\rm sa}.
\]
For an endpoint native POVM \(E_i=G_i\oplus S_i\), write
\(\mathcal W=\operatorname{span}_{\mathbb R}\{E_i\}\) and
\(g=\dim \operatorname{span}_{\mathbb R}\{G_i\}\).

**Rank theorem.** If \(\mathcal T\subset\mathcal W\), then
\[
\boxed{N\ge\dim\mathcal W=g+15.}
\]
At \(r_0=\sqrt3 R<2R\), every exact-first-moment native POVM has \(g\ge6\). Hence any 21-outcome full protected-quotient readout has **exactly** \(g=6\) and 21 linearly independent effects.

*Proof.* The endpoint Clifford support theorem gives \(\operatorname{Tr}(S_i\chi)=0\) for each effect. The compression map \(\pi_G:\mathcal W\to\operatorname{span}\{G_i\}\) has kernel contained in \(\mathcal T\). Since the hypothesis contains all of \(\mathcal T\), the kernel is precisely \(\mathcal T\). Rank-nullity gives \(\dim\mathcal W=g+15\), and \(\dim\mathcal W\le N\).

The geometric identity and four first moments make \(I_G,Y_1,\ldots,Y_4\) elements of \(\operatorname{span}\{G_i\},\) so \(g\ge5\). If \(g=5\), write each geometric effect as \(G_i=\alpha_i I_G+Y(\beta_i)\). Since the minimum eigenvalue of \(Y(\beta_i)\) is \(-R\|\beta_i\|/2\), positivity requires \(\alpha_i\ge R\|\beta_i\|/2\). Normalization gives \(\sum_i\alpha_i=1\), and four first moments yield \(\sum_i x_{ia}\beta_{ib}=\delta_{ab}\). Therefore
\[
4=\sum_i x_i\cdot\beta_i\le r\sum_i\|\beta_i\|
\le (2r/R)\sum_i\alpha_i=2r/R,
\]
forcing \(r\ge2R\), contrary to \(r=r_0\). Hence \(g\ge6\). At \(N=21\) the upper bound \(g\le6\) proves the claim. This is a **rank obstruction**, not a construction of 21 effects.

**Positive-refinement converse in the parent-preserving class.** Let \(m\) endpoint parent effects be linearly independent, let their geometric rank be \(g\), and suppose their protected compressions are strictly positive on each saturated rank-two \(P_+(n_i)\) support. The weighted design theorem `p2c:thm:v354-unique-protected-obstruction` makes the locally supported pure protected span equal \(\mathcal T\). The supported-refinement lemma used in `p2c:thm:v354-exact-native-rank` then gives exactly \(g+15\) tagged positive children spanning \(\mathcal W+\mathcal T\): choose \(g+15-m\) supported pure protected contrasts outside \(\mathcal W\) and split the \(m\) independent parents. In particular,
\[
\boxed{m=7,\quad \operatorname{rank}\{E_i\}=7,\quad g=6
\quad\Longrightarrow\quad N_{\rm protected}=21.}
\]
The additional rank-two *full-support* condition matters: the protected equality theorem alone constrains support inclusion, not strict positivity for arbitrary endpoint parents.

**Link to the localization minimum.** If a native endpoint six-effect POVM exists, the existing six-outcome rigidity theorem `p2c:thm:vGC18-six-endpoint-rigidity` establishes full-rank protected effects \(S_i=2w_iP_+(n_i)\) with \(w_i>0\). Geometric rank five is excluded by the previous paragraph, and geometric rank cannot exceed six. The six parents are therefore independent, have \(g=6\), and supported refinement yields 21 protected-readout effects. Thus
\[
\boxed{N_{\min}^{\rm localization}(r_0)=6\ \Longrightarrow\
N_{\min}^{\rm protected}(r_0)=21.}
\]
The reverse implication has not been established: seven parents with independent native effects but geometric rank six could also produce 21 after refinement. A no-go for *all* rank-six geometric endpoint POVMs would settle both open questions, but the symmetry-specific no-gos below are not such a global theorem.

## 9. Exact no-go for rank six on the natural seven-position rotation orbit

Consider the *fixed* seven directions of `p2c:thm:v255-seven-outcome-attainment`:
\[
\mathcal Q_7=\{e_1,-e_1,e_2,-e_2,q_0,q_1,q_2\},\qquad
q_j=\cos(2\pi j/3)e_3+\sin(2\pi j/3)e_4.
\]
Let \(C_4\) rotate the \((e_1,e_2)\)-plane by \(\pi/2\), and \(C_3\) rotate the orthogonal \((e_3,e_4)\)-plane by \(2\pi/3\). These are commuting, **orientation-preserving** Euclidean rotations; their natural actions on \(\mathbb C\oplus\mathbb C^4\oplus\Lambda^2\mathbb C^4\) are the scalar, vector and exterior-square actions, and lift to the round \(\operatorname{Spin}(4)\) geometry described in Paper I-A. No subgroup is promoted to a physical apparatus selector.

**Theorem (seven independent geometric parents).** Every positive, normalized, exact-first-moment **\(C_4\times C_3\)-equivariant** geometric POVM on the seven directions \(\mathcal Q_7\) has
\[
\boxed{\dim_{\mathbb R}\operatorname{span}\{G_q:q\in\mathcal Q_7\}=7.}
\]
Consequently, any native endpoint tagged POVM whose *seven coarse geometric position totals* satisfy this covariance and whose effect span contains all of \(\mathcal T\) needs at least
\[\boxed{N\ge7+15=22.}\]
The source seven-parent construction has these rotations, full rank-two protected supports and a 22-effect supported refinement, so **22 is sharp within this specified symmetry-preserving coarse-parent class**.

### Proof: group-induced diagonal resource dichotomy

Let \(r_0=\sqrt3R\), and define pair and trine resources
\[
A:=G_{+e_1}+G_{-e_1},\quad
B:=G_{+e_2}+G_{-e_2},\quad
D:=G_{q_0}+G_{q_1}+G_{q_2},\quad A+B+D=I_G.
\]
The exact coordinate moments **uniquely** force
\[
G_{\pm e_1}=\tfrac12(A\pm Y_1/r_0),\qquad
G_{\pm e_2}=\tfrac12(B\pm Y_2/r_0),\qquad
G_{q_j}=\tfrac13(D+2Y(q_j)/r_0).
\]
These equations do not assume diagonal effects. Under \(C_4\), \(A\leftrightarrow B\) and \(D\mapsto D\). Under \(C_3\), each of \(A,B,D\) is invariant.

Let \(\Delta\) retain only diagonal entries in the native ordered exterior basis
\((e_0,u_1,u_2,u_3,u_4,w_{12},w_{13},w_{14},w_{23},w_{24},w_{34})\).
Each \(Y_a\) has zero diagonal; the four \(Y_a\) are independent and lie in the span of the seven effects. Rank-nullity therefore gives
\[
\dim\operatorname{span}\{G_q\}\ge
4+\dim\operatorname{span}\{a,b,d\},\quad
 a=\Delta A,\ b=\Delta B,\ d=\Delta D=\mathbf 1-a-b.
\]
The quarter-turn acts on these diagonal vectors as an involution \(\tau\), with \(b=\tau a\) and \(\tau\mathbf1=\mathbf1\). If the three diagonal resource vectors had span at most two, then **either** \(a=b\), **or** \(a+b=c\mathbf1\) for some real \(c\): if \(a,b\) are dependent, involutivity and nonnegative scalar entries force equality; if independent, \(\mathbf1\in\operatorname{span}\{a,b\}\) and applying \(\tau\) twice to a relation \(b=\alpha\mathbf1+\beta a\) forces \(\beta=-1\). Both alternatives contradict positivity, as follows.

**Case I: \(a=b\).** \(C_3\) invariance makes the two vector diagonals in the trine plane equal and likewise makes the two wedge diagonals \(w_{13},w_{14}\) equal. Equality \(a=b=\tau a\) makes the two axial vector diagonals equal and the mixed wedges \(w_{13},w_{23}\) equal. Put
\[
p=2a_{e_0},\qquad q=2a_{u_1},\qquad
s=2a_{w_{13}},\qquad h=2a_{u_3}.
\]
All lie in \([0,1]\) since \(D=I_G-A-B\succeq0\). The scalar–vector and vector–bivector \(2\times2\) principal minors of \(A\pm Y_1/r_0\succeq0\) give
\[
pq\ge\frac13,\qquad hs\ge\frac8{27}.
\]
For \(D+2Y(e_3)/r_0\succeq0\), the corresponding \(2\times2\) principal minors give
\[
(1-p)(1-h)\ge\frac13,\qquad
(1-q)(1-s)\ge\frac8{27}.
\]
The off-diagonal entries of \(D\) in the two displayed principal blocks vanish because a \(C_3\)-invariant scalar cannot couple to the nontrivial trine-plane rotation representation; thus these bounds remain valid even for *nondiagonal* resource matrices. The plus/minus pair likewise supplies the bounds for \(A\) even with complex off-diagonal entries.

The first and third inequalities imply \(q\ge 1/(3p)\) and \(h\le1-1/[3(1-p)]\), hence
\[
h+1-q\le2-\frac13\left(\frac1p+\frac1{1-p}\right)
\le\frac23.
\]
But by Cauchy–Schwarz and the second and fourth inequalities,
\[
\sqrt{h+1-q}\ge\sqrt{hs}+\sqrt{(1-q)(1-s)}
\ge2\sqrt{\frac8{27}},
\]
so \(h+1-q\ge32/27>2/3\), a contradiction.

**Case II: \(a+b=c\mathbf1\).** Then \(d=(1-c)\mathbf1\). Invariance under \(C_4\) forces
\(a_{e_0}=a_{w_{12}}=c/2\), and writing \(x=a_{u_1}\) gives \(a_{u_2}=c-x\). The positive \(A\pm Y_1/r_0\) principal minors on \((e_0,u_1)\) and \((u_2,w_{12})\) require
\[
\frac c2 x\ge\frac1{12},\qquad
\frac c2(c-x)\ge\frac2{27},
\quad\Longrightarrow\quad c^2\ge\frac{17}{54}>\frac14.
\]
On the other hand, \(C_3\) invariance makes the \((e_0,u_3)\) off-diagonal entry of \(D\) vanish. Positivity of \(D+2Y(e_3)/r_0\) requires
\[
(1-c)^2\ge\frac13,\qquad 1-c\ge0,
\quad\Longrightarrow\quad c\le1-\frac1{\sqrt3}<\frac12,
\]
contradicting \(c^2>1/4\). Therefore \(\operatorname{span}\{a,b,d\}\) has dimension three. Adding the four independent zero-diagonal \(Y_a\) gives geometric rank at least seven, and there are exactly seven parents. QED.

**Scope:** This excludes rank-six geometry *when the seven coarse position totals obey the finite \(C_4\times C_3\) rotation covariance*. It does **not** exclude an asymmetric seven-parent geometry on those labels, other seven-point spherical designs, nor arbitrary six-outcome exact readout. Averaging an arbitrary noncovariant POVM can increase its geometric span, so symmetry averaging is **not** a valid way to extend the theorem to the unrestricted minimum.

## 10. Quaternion-unit eight-parent cost: sharp 23 with finite round symmetry

For \(\mathcal N=\{\pm e_a:1\le a\le4\}\), let the rotation subgroup \(A_4\) act by even permutations of the four coordinate axes, and let \(-I_4\in SO(4)\) perform central inversion. Both preserve this eight-position set and come from the round \(\operatorname{Spin}(4)\) action, not from a new physical symmetry postulate. The unit-quaternion identification \((e_1,e_2,e_3,e_4)\leftrightarrow(1,i,j,k)\) places \(\mathcal N\) in Paper I-A's \(Q_8\subset2T\subset2I\) reference geometry.

**Theorem (eight geometric parents).** Every positive exact-first-moment eight-axis geometric POVM whose **coarse position totals** are covariant under the even-permutation action and central inversion has geometric real rank eight. Hence any tagged refinement of such totals spanning \(\mathcal T\) needs at least \(8+15=23\) effects. The strictly positive eight parents already constructed in v1_2 admit a 23-effect positive supported refinement, so
\[
\boxed{N^{Q_8\text{-symmetric parent refinement}}_{\rm protected}=23.}
\]

*Proof.* Define \(A_a=G_{+e_a}+G_{-e_a}\); then \(\sum_aA_a=I_G\) and
\(G_{\pm e_a}=\tfrac12(A_a\pm Y_a/r_0)\). The four resource matrices \(A_a\) furnish a quotient of the real four-point permutation representation of \(A_4\), which decomposes as its trivial one-dimensional representation and irreducible three-dimensional standard representation. The nonzero total \(\sum_a A_a=I_G\) excludes the trivial representation from the kernel. Thus either all \(A_a\) are equal or they are independent. Equality would force \(A_a=I_G/4\) and make \(A_a\pm Y_a/r_0\) nonpositive because \(\|Y_a\|/r_0=1/(2\sqrt3)>1/4\). Therefore the \(A_a\) are independent.

Central inversion acts on \(\mathcal H_G\) by \(U_{-I}=\operatorname{diag}(1,-I_4,I_6)\). Covariance makes every \(A_a\) inversion even while each \(Y_a\) is inversion odd. The four \(Y_a\) are independent, and their span intersects the even four-dimensional resource span only at zero. Hence the eight parents have geometric rank eight. The eight concrete v1_2 parents also have full geometric rank 11 on each individual support and full protected rank two; the supported-refinement theorem supplies 15 pure protected contrasts and \(8+15=23\) positive children. QED.

**Interpretation:** The eight quaternionic axes are optimal for the *different* goal of complete 136-dimensional endpoint quotient tomography, because their geometric effects already have full individual support and are linearly independent. This does not imply economy for the smaller 15-dimensional protected-only target. Here the symmetries *cost* an extra outcome relative to the seven-parent \(C_4\times C_3\) realization.

## 11. Independent executable evidence and audit handoff

The companion `Paper2C-EndpointQuotientMinimum-v1_3.py` reproduces the v1_2 136-effect theorem and additionally:

- reconstructs the source seven-parent geometry *exactly as defined* by `p2c:thm:v255-seven-outcome-attainment`, with full 15-dimensional native parent effects;
- verifies the seven geometric effects have rank seven, are positive, normalize and reproduce the exact first moments;
- checks the finite \(C_4\times C_3\) rotation covariance on the 11-dimensional natural exterior carrier;
- performs an explicit positive refinement to exactly 22 effects with the full 15 pure protected target directions;
- checks the eight quaternionic-axis geometric parent rank eight and the corresponding finite even-permutation/inversion covariance;
- constructs a positive 23-effect protected readout refining the eight quaternion-axis parents;
- checks moment preservation, parent-sum preservation, real linear independence and positivity of both refined families.

Floating-point matrix calculations corroborate the exact arguments; the **rank lower bounds** above come from exact representation theory and rational determinant inequalities, not numerical SDP failure. The earlier searches for asymmetric six-outcome POVMs or rank-six seven-parents returned negative numerical feasibility margins on the *tested* designs, but those experiments do not justify universal exclusions and are **not** promoted to DAG closure status.

**Ledger:** `BH-IIC-G-004` has the v1_2 exact mathematical 136 proof pending canonical/DAG/audit integration. `BH-IIC-G-002` remains OPEN globally (six vs seven). `BH-IIC-G-003` remains OPEN globally (21 vs 22). This v1_3 extension proves **sharp restricted endpoint counts** 22 and 23 under the specifically stated finite symmetry and coarse-parent conditions and exhibits an exact rank-six common frontier. No actual detector occurrence, GP2 action owner, decay vertex, or physical frequency law is inferred.


---

# v1_4 extension — arbitrary-effects seven-position rank rigidity

**Date:** 20 November 2026. **New exact theorem:** the seven-position support of Paper II-C has **geometric rank seven without a covariance hypothesis**, and hence the sharp protected-readout cost **22 for *any* tagged native POVM supported on exactly these seven positions**. This strengthens v1_3 §9, which required the coarse geometric POVM to be $C_4\times C_3$-covariant. This theorem does **not** prove the unrestricted six-versus-seven localization outcome minimum or the unrestricted 21-versus-22 protected outcome minimum for other supports.

## 12. Theorem and reduction

**Theorem (unrestricted effects, fixed seven-position rank).** Set $r=\sqrt3R$, $R=R_{\rm mom}>0$, let $Y_a$ be the intrinsic eleven-dimensional geometric tuple constituted in `p2c:thm:v255-seven-outcome-attainment`, and fix the seven distinct positions
\[
\mathcal Q_7=\{e_1,-e_1,e_2,-e_2,q_0,q_1,q_2\},\qquad
q_j=\cos(2\pi j/3)e_3+\sin(2\pi j/3)e_4.
\]
For **every** family $G_q\succeq0$ in $M_{11}(\mathbb C)$ satisfying
\[
\sum_{q\in\mathcal Q_7}G_q=I_G,\qquad
\sum_q rq_aG_q=Y_a\quad(a=1,\dots,4),
\]
with no symmetry, diagonal, commutativity, or source-occurrence assumption on the original effects, one has
\[
\boxed{\dim_{\mathbb R}\operatorname{span}\{G_q:q\in\mathcal Q_7\}=7.}
\]
It follows that a native exact-first-moment tagged POVM with all labels in $r\mathcal Q_7$ and with **all fifteen pure protected chiral-quotient directions** in its real effect span requires at least $7+15=22$ effects. The pre-existing exact 22-effect construction on this support attains the count. Thus
\[
\boxed{N_{\mathrm{protected},\,\operatorname{supp}\subseteq r\mathcal Q_7}=22,}
\]
where the subscript denotes the specified *position-support class*, **not** the unrestricted endpoint minimum.

**Proof, Step 1 (resource inversion).** Let $A=G_{e_1}+G_{-e_1}$, $B=G_{e_2}+G_{-e_2}$ and $D=\sum_jG_{q_j}=I_G-A-B$. The five moment identities determine all seven effects:
\[
G_{\pm e_1}=\tfrac12(A\pm Y_1/r),\qquad
G_{\pm e_2}=\tfrac12(B\pm Y_2/r),\qquad
G_{q_j}=\tfrac13(D+2Y(q_j)/r).
\]
Thus their real span is exactly $\operatorname{span}_{\mathbb R}\{I_G,Y_1,\ldots,Y_4,A,B\}$; $I_G,Y_1,\dots,Y_4$ are independent.

If the rank were at most six, the images of $A,B$ modulo the five-dimensional space $\mathcal L=\operatorname{span}\{I_G,Y_1,\dots,Y_4\}$ would span at most one dimension. Either $A\in\mathcal L$, or $B\in\mathcal L$, or else
\[
\boxed{B=\alpha A+\beta I_G+Y(v)}\tag{12.1}
\]
for some real $\alpha,\beta$ and $v\in\mathbb R^4$.

**Proof, Step 2 (averaging which preserves the rank-six relation).** Let
\[
K=C_2^{(1)}\times C_2^{(2)}\times D_3\subset O(4)
\]
be generated by independent coordinate sign flips $e_1\mapsto-e_1$, $e_2\mapsto-e_2$, and the dihedral symmetries of the trine plane $\operatorname{span}(e_3,e_4)$. Every element of $K$ preserves $\mathcal Q_7$, and importantly it preserves **each** of the three resource *sets* $\{\pm e_1\}$, $\{\pm e_2\}$, $\{q_0,q_1,q_2\}$ separately. Let $U(O)=1\oplus O\oplus\Lambda^2O$ on $\mathcal H_G$. Then
\[
U(O)Y(v)U(O)^*=Y(Ov).
\]
Conjugate and permute the original POVM by every $O\in K$ and average. This retains positivity, normalization, all four first moments, and the group totals become $\bar A=\lvert K\rvert^{-1}\sum_O U(O)AU(O)^*$ and similarly $\bar B$. Since the only $K$-fixed vector of $\mathbb R^4$ is zero, (12.1) survives as
\[
\boxed{\bar B=\alpha\bar A+\beta I_G.}\tag{12.2}
\]
If $A\in\mathcal L$ or $B\in\mathcal L$, the corresponding average is just a scalar multiple of $I_G$.

The eight $K$-isotypic geometric pieces are pairwise inequivalent:
\[
\mathbb Ce_0,\ \mathbb Cu_1,\ \mathbb Cu_2,\ \operatorname{span}(u_3,u_4),\
\mathbb Cw_{12},\ \operatorname{span}(w_{13},w_{14}),\
\operatorname{span}(w_{23},w_{24}),\ \mathbb Cw_{34}.
\]
The two-dimensional $D_3$ standard representation has scalar commutant. Hence $\bar A,\bar B,\bar D$ are diagonal and constant on each listed two-dimensional piece. This diagonalization is a *necessary averaged representative of a hypothetical rank-six original*, not a covariance assumption on the original POVM. In the rest of the proof omit the bars.

**Proof, Step 3 (strict opposed axial ordering).** Write, for each basis state $t$, $a_t=\langle t,At\rangle$, $b_t=\langle t,Bt\rangle$, $d_t=1-a_t-b_t$. For convenience use
\[
\begin{array}{c|cccccccc}
\text{state}&e_0&u_1&u_2&u_3&w_{12}&w_{13}&w_{23}&w_{34}\\\hline
\text{abbrev.}&0&x&y&v&z&p&q&h
\end{array}
\]
(the $u_4,w_{14},w_{24}$ components share the respective $v,p,q$ diagonal values).
Every $a_t,b_t,d_t$ is nonnegative and $a_t+b_t+d_t=1$.

From positive $2\times2$ principal minors of $A\pm Y_1/r$, $B\pm Y_2/r$, and $D+2Y(e_3)/r$,
\[
a_0a_x\ge\tfrac1{12},\quad b_0b_y\ge\tfrac1{12},\quad d_0d_v\ge\tfrac13.\tag{12.3}
\]
Cauchy–Schwarz across the three resource colors yields
\[
\sqrt{a_0a_x}+\sqrt{b_0b_y}+\sqrt{d_0d_v}
\le\sqrt{(a_0+b_0+d_0)(a_x+b_y+d_v)}
=\sqrt{a_x+b_y+d_v},
\]
while the left side is at least $1/(2\sqrt3)+1/(2\sqrt3)+1/\sqrt3=2/\sqrt3$. Thus
\[
\boxed{a_x+b_y\ge a_v+b_v+\tfrac13.}\tag{12.4}
\]
Similarly the four principal minors for $A$ on $(u_3,w_{13})$, $D$ on $(u_1,w_{13})$, $B$ on $(u_3,w_{23})$, and $D$ on $(u_2,w_{23})$ give
\[
a_va_p\ge\tfrac2{27},\quad d_xd_p\ge\tfrac8{27},\qquad
b_vb_q\ge\tfrac2{27},\quad d_yd_q\ge\tfrac8{27}.
\]
Since $a_p+d_p\le1$ and $b_q+d_q\le1$, two-color Cauchy–Schwarz gives
\[
\boxed{a_x+b_x\le a_v+\tfrac13,\qquad a_y+b_y\le b_v+\tfrac13.}\tag{12.5}
\]
Subtracting (12.5) from (12.4), respectively,
\[
\boxed{a_x-a_y\ge a_v>0,\qquad b_y-b_x\ge b_v>0.}\tag{12.6}
\]
Strictness follows directly from $a_va_p\ge2/27$ and $b_vb_q\ge2/27$. In particular, neither $A$ nor $B$ can be a scalar after averaging; therefore neither original resource can belong to $\mathcal L$.

**Proof, Step 4 (strict *concordant* wedge ordering).** We claim
\[
\boxed{a_z>a_v,\qquad b_z>b_v.}\tag{12.7}
\]
It suffices by axis-swap symmetry of the inequalities to prove the first. Suppose $a_z\le a_v=:c$. The $A$ minor on $(u_2,w_{12})$ forces $a_y a_z\ge2/27$, hence $a_y\ge2/(27c)$. The $B$ minor on $(u_1,w_{12})$ gives $b_xb_z\ge2/27$, hence $b_x\ge2/27$ since $b_z\le1$. By (12.6), $a_x\ge a_y+c$. Consequently
\[
d_x=1-a_x-b_x\le \frac{25}{27}-c-\frac2{27c}.\tag{12.8}
\]
The $A$ minor on $(u_3,w_{13})$ and the $D$ minor on $(u_1,w_{13})$ give $a_p\ge2/(27c)$ and $d_p\ge8/(27d_x)$. Because $a_p+d_p\le1$ and $d_x>0$,
\[
c>\frac2{27},\qquad
 d_x\ge\frac{8c}{27c-2}.\tag{12.9}
\]
Together (12.8) and (12.9) demand
\[
c+\frac2{27c}+\frac{8c}{27c-2}\le\frac{25}{27},
\]
which after multiplication by the strictly positive $27c(27c-2)$ is
\[
P(c):=729c^3-513c^2+104c-4\le0.\tag{12.10}
\]
But for $z=27c>2$ there is the exact identity
\[
\boxed{27P(c)= (z-2)(z-7)(z-10)+32>0.}\tag{12.11}
\]
For $2<z\le7$ or $z\ge10$ the cubic product is nonnegative. For $7\le z\le10$,
$(z-7)(10-z)\le9/4$ and $z-2\le8$, so the product is at least $-18$, making the right side at least $14$. Contradiction. The argument with the two coordinate axes exchanged proves $b_z>b_v$.

**Proof, Step 5 (rank-six contradiction).** Equation (12.2) would imply
\[
b_y-b_x=\alpha(a_y-a_x),\qquad b_z-b_v=\alpha(a_z-a_v).
\]
Equation (12.6) forces $\alpha<0$, whereas (12.7) forces $\alpha>0$. This contradiction rules out rank six. As there are exactly seven effects, the geometric rank is seven.

**Protected cost.** If $N$ tagged native effects have all labels in $r\mathcal Q_7$ and span the $15$ pure protected quotient directions $\mathcal T$, their coarse geometric position totals form a seven-position exact POVM (possibly with zero totals; zero would contradict the rank theorem). The geometric compression of the native effect span has rank at least seven, and its kernel includes $\mathcal T$. Rank–nullity gives $N\ge7+15=22$. The source seven-parent construction with rank-two protected supports attains this via positive supported refinement. QED.

## 13. Status, limitations and reconciliation

- **Proved without covariance:** Every *geometric* endpoint POVM using these **specified seven directions**, no matter how asymmetric its effects, has seven linearly independent coarse effects. Consequently **22 is exact for any tagged protected-quotient readout on this same seven-position support**.
- **Not proved:** The unrestricted seven-support geometric-rank minimum over *other* spherical weighted designs, the unrestricted endpoint six-versus-seven localization question, the global 21-versus-22 protected question, or a physically selected/occurring apparatus. The prior equal-weight, antipodal, and fourfold-degenerate six-point exclusions in the current Paper II-C source remain intact.
- **DAG/audit:** This supersedes the *covariance restriction* of the v1_3 §9 result but does not retire `BH-IIC-G-002` or `BH-IIC-G-003`. The canonical Paper II-C TeX/PDF and release/audit archives remain unchanged until a separate integration/reverification operation.
- **Paper I-A provenance:** The finite orthogonal exterior-action geometry is used to form an averaging group on the **constituted Paper II-C geometric carrier**. No assertion is made that Paper I-A alone selects a physical POVM, defines this $11$-dimensional carrier, or imposes a detector covariance principle.
- **Independent check:** The v1_4 executable replays the earlier 136-, 22-, and 23-effect constructions, verifies source-seven support and new reflection/trine covariance of the averaging subgroup, and checks the exact rational two-by-two determinants, inequalities, and cubic identity with symbolic arithmetic. The proof itself is the exact argument above, not a claim that numerical search establishes universal infeasibility.

---

# v1_5 extension — universal Radon–Clifford obstruction: endpoint minimum is seven

**Date:** 20 November 2026. **New result:** exact, unrestricted six-outcome no-go on the *constituted* Paper II-C native coordinate tuple at the optimal endpoint radius. No finite symmetry, antipodal configuration, equal protected weights, rotationally invariant effects, reality of the unknown correction matrix, or physical apparatus selection is assumed. The proof is algebraic: the separate numerical replay is only an implementation check.

## 14. Negative exterior-geometric subspaces

Normalize $R=R_{\rm mom}>0$ and $r_0=\sqrt3R$. On
$\mathcal H_G=\mathbb C\oplus V\oplus\Lambda^2V$ with $V=\mathbb C^4$, the original Paper II-C coordinate tuple has
\[
Y(n)=\frac R2\bigl(|e_0\rangle\langle n|+|n\rangle\langle e_0|\bigr)
+\frac{\sqrt2R}{3}(J_n+J_n^*),\qquad J_n(v)=n\wedge v.
\]
For every real unit $n\in S^3$, let
\[
C(n)=I_{11}+\frac4{r_0}Y(n),\qquad
T_n(v)=(-n\cdot v,\ v,\ -n\wedge v)\in \mathbb R\oplus\mathbb R^4\oplus\Lambda^2\mathbb R^4.
\]
If $v=an+v_\perp$, $v_\perp\perp n$, then the two components of $T_n(v)$ are mutually orthogonal eigenvectors of $Y(n)$ with eigenvalues $-R/2$ and $-\sqrt2R/3$, respectively. In particular,
\[
\begin{split}
\lVert T_n(v)\rVert^2&=2\lVert v\rVert^2,\\
\langle T_n(v),C(n)T_n(v)\rangle
&=2\left[\left(1-\frac2{\sqrt3}\right)a^2
+\left(1-\frac{4\sqrt2}{3\sqrt3}\right)\lVert v_\perp\rVert^2\right]<0
\quad(v\ne0).
\end{split}\tag{14.1}
\]
The strictness follows exactly from $4>3$ and $32>27$. Thus the four-dimensional real subspace $\mathcal N(n)=\operatorname{ran}T_n$ is **strictly negative** for $C(n)$. All statements extend to complex Hermitian matrices because the real test vectors are legitimate complex test vectors. This simultaneously uses the scalar–vector and vector–two-form channels: keeping only either channel destroys the full four-dimensional negative-subspace mechanism.

## 15. Radon–exterior positive-witness identity

**Lemma (two equal-barycenter ensembles).** Suppose $\{n_i:i\in P\}$ and $\{n_j:j\in M\}$ are finite, nonempty collections of unit vectors in $\mathbb R^4$, with strictly positive probability weights $\mu_i,\nu_j$ such that
\[
\sum_{i\in P}\mu_i=\sum_{j\in M}\nu_j=1,\qquad
\sum_{i\in P}\mu_i n_i=\sum_{j\in M}\nu_j n_j=:m,
\]
and with $n_i\ne n_j$ across the two collections. For each $i\in P$, $j\in M$ put
\[
 d_{ij}=1-n_i\cdot n_j>0,\qquad v_{ij}=n_i-n_j,\qquad k_{ij}=n_i\wedge n_j,
\]
\[
 \xi_{i\mid j}=T_{n_i}(v_{ij})=(-d_{ij},v_{ij},k_{ij}),\qquad
 \xi_{j\mid i}=T_{n_j}(v_{ij})=(+d_{ij},v_{ij},k_{ij}).
\]
Define positive matrices
\[
 Z_i^+=\sum_{j\in M}\frac{\mu_i\nu_j}{d_{ij}}
 |\xi_{i\mid j}\rangle\langle\xi_{i\mid j}|,\qquad
 Z_j^-=\sum_{i\in P}\frac{\mu_i\nu_j}{d_{ij}}
 |\xi_{j\mid i}\rangle\langle\xi_{j\mid i}|.
\]
Each $Z_i^+$ and $Z_j^-$ is nonzero, positive semidefinite, and supported on the corresponding negative subspace $\mathcal N(n_i)$ or $\mathcal N(n_j)$. Nevertheless,
\[
\boxed{\sum_{i\in P}Z_i^+=\sum_{j\in M}Z_j^-.}\tag{15.1}
\]
**Proof.** For $z=(v,k)\in V\oplus\Lambda^2V$ and $d>0$,
\[
|(-d,z)\rangle\langle(-d,z)|-|(+d,z)\rangle\langle(+d,z)|
=-2d\bigl(|e_0\rangle\langle z|+|z\rangle\langle e_0|\bigr).
\]
Multiply by $\mu_i\nu_j/d_{ij}$ and sum all cross pairs. The scalar–vector cross term is proportional to
\[
 \sum_{ij}\mu_i\nu_j(n_i-n_j)=m-m=0,
\]
and the scalar–two-form cross term to
\[
 \sum_{ij}\mu_i\nu_j(n_i\wedge n_j)=m\wedge m=0.
\]
The vector/two-form block, scalar diagonal and every other block already agree **pair by pair**. This proves (15.1), with no averaging group or commutativity hypothesis. $\square$

**Corollary (signed correction impossibility).** Under the lemma's hypotheses, there is no Hermitian $H\in M_{11}(\mathbb C)$ that is strictly positive on all $\mathcal N(n_i)$ for $i\in P$ and strictly negative on all $\mathcal N(n_j)$ for $j\in M$. Indeed $\operatorname{Tr}(HZ_i^+)>0$ and $\operatorname{Tr}(HZ_j^-)<0$ would contradict the exact equality (15.1). This is the reusable **Radon–Clifford sign-separation obstruction**.

## 16. Theorem: every six-outcome endpoint POVM is impossible

**Theorem (sharp unrestricted native localization outcome count).** Let $X_a^D=Y_a\oplus(r_0/4)\gamma_a$ be the exact native Paper II-C coordinate tuple and allow any finite normalized positive-operator-valued measure with labels $x_i\in\overline B^4(r_0)$, exact first moments $\sum_i x_{ia}E_i=X_a^D$, and no measurement-covariance or subgroup-support assumptions. Then no such POVM has six or fewer nonzero effects. The already established seven-effect construction attains the radius and the count; hence
\[
\boxed{N_{\min}^{\mathrm{native\ localization}}(r_0)=7.}\tag{16.1}
\]

**Proof.** Five or fewer outcomes are excluded by `p2c:cor:v226-five`. Suppose six exist. Native central pinching to $E_i=G_i\oplus S_i$ preserves positivity, normalization, and all first moments. The endpoint protected equality and the five-plus-one argument of `p2c:thm:vGC18-six-endpoint-rigidity` force all six protected compressions to be nonzero, each $x_i=r_0n_i$ with $\lVert n_i\rVert=1$, and a positive spherical weighted two-design
\[
 \sum_iw_i=1,\quad \sum_iw_i n_i=0,\quad
 \sum_iw_i n_in_i^T=\frac14 I_4,\qquad w_i>0.
\]
An exact duplicate $n_i=n_j$ would allow the two effects to be combined into a forbidden five-effect endpoint POVM. Thus the six $n_i$ are distinct.

The $5\times6$ Parseval frame with columns $\sqrt{w_i}(1,2n_i)^T$ has a unit one-dimensional null vector $t$, giving
\[
 \sum_i t_i\sqrt{w_i}=0,\qquad \sum_i t_i\sqrt{w_i}n_i=0.
\]
Write $c_i=t_i\sqrt{w_i}$. Geometric normalization and moments, by inversion of this five-row frame, imply **for one and the same Hermitian $H$**
\[
 \boxed{G_i=w_iC(n_i)+c_iH,\qquad
 C(n_i)=I_G+\frac4{r_0}Y(n_i).}\tag{16.2}
\]
If $c_i=0$ for any $i$, then $G_i=w_iC(n_i)$ is not positive by (14.1), immediately impossible. Thus every $c_i\ne0$. Let $P=\{i:c_i>0\}$, $M=\{j:c_j<0\}$. Both are nonempty since $\sum_i c_i=0$. With
\[
 h=\sum_{i\in P}c_i=-\sum_{j\in M}c_j>0,\qquad
 \mu_i=c_i/h,\qquad \nu_j=-c_j/h,
\]
the previous equations imply $\sum_P\mu_i n_i=\sum_M\nu_jn_j$. Apply Lemma 15.1 to obtain positive nonzero $Z_i^+,Z_j^-$ with the same total $Z$ and supports in the respective strictly negative subspaces.

For $i\in P$, positivity of (16.2) gives
\[
 c_i\operatorname{Tr}(HZ_i^+)\ge
 -w_i\operatorname{Tr}(C(n_i)Z_i^+)>0
 \quad\Longrightarrow\quad \operatorname{Tr}(HZ_i^+)>0.
\]
For $j\in M$, where $c_j<0$, the same inequality gives
\[
 c_j\operatorname{Tr}(HZ_j^-)\ge
 -w_j\operatorname{Tr}(C(n_j)Z_j^-)>0
 \quad\Longrightarrow\quad \operatorname{Tr}(HZ_j^-)<0.
\]
Summing the first inequalities says $\operatorname{Tr}(HZ)>0$, and the second says $\operatorname{Tr}(HZ)<0$. Contradiction. The known seven-outcome construction `p2c:thm:v255-seven-outcome-attainment` gives the matching upper bound. $\square$

**Explicit dual certificate.** One can combine all six positivity constraints linearly to eliminate the unknown $H$ entirely:
\[
 0\le \sum_{i=1}^6\frac{\operatorname{Tr}(G_iZ_i)}{|c_i|}
 =\sum_{i=1}^6\frac{w_i}{|c_i|}\operatorname{Tr}(C(n_i)Z_i)<0,
\]
where $Z_i=Z_i^+$ or $Z_i^-$ according to sign. In detail, if $s_{ij}=n_i\cdot n_j$, each cross-pair contribution to the right-hand side equals
\[
 2\mu_i\nu_j\left(\frac{w_i}{c_i}+\frac{w_j}{|c_j|}\right)
 \left[\left(1-\frac2{\sqrt3}\right)(1-s_{ij})
 +\left(1-\frac{4\sqrt2}{3\sqrt3}\right)(1+s_{ij})\right],
\]
which is strictly negative because $s_{ij}<1$, $1+s_{ij}\ge0$, and both spectral coefficients are negative. This exposes the no-go as a finite **positive semidefinite Farkas certificate**, rather than a failed numerical optimizer.

## 17. Boundary, consequences and source reconciliation

| Endpoint obligation | Status after v1_5 | Exact scope |
|---|---|---|
| `BH-IIC-G-002`: 6 vs 7 native localization outcomes | **Mathematically CLOSED: 7** | Arbitrary six-position geometries, unequal weights and complex Hermitian corrections excluded; source's seven construction attains 7 |
| `BH-IIC-G-003`: 21 vs 22 protected quotient effects | **OPEN: 21 or 22** | Any hypothetical 21-effect realization must have geometric effect-span rank six and at least seven nonzero distinct positions; six-position route is now excluded |
| `BH-IIC-G-004`: 136 vs 141 full endpoint quotient tomography | **Mathematically CLOSED: 136** | Existing v1_2 eight-parent exact construction, retaining all earlier qualifications |

- **What v1_5 *does* close:** the unrestricted **minimum number of endpoint native localization effects**, exactly seven. The result is not a search across a few high-symmetry supports: the Radon–exterior identity covers *every* feasible six-point weighted design via its one-dimensional Parseval nullspace.
- **What it does *not* close:** an endpoint readout with 21 tagged effects at **seven or more** distinct positions, whose geometric operator span is six-dimensional. The known seven-position support has geometric rank seven by v1_4; other seven-or-more-position supports remain to be examined. Numerical nonfeasibility of the tested five-protected-simplex-plus-two-geometric-only family is not a universal theorem and is not promoted to an obstruction.
- **Physics scope:** no mathematical existence/nonexistence claim here supplies a GP2-selected apparatus, a physical detector occurrence, an outcome frequency law, or a decay mechanism. The forbidden count and sharp count are *conditional on the already constituted native position tuple and exact-first-moment POVM interpretation*.
- **Paper I-A contribution and correct ownership:** the proof exploits $S^3$ directions, $\operatorname{Spin}(4)$-compatible exterior algebra, and the wedge pairing $n\wedge v$. The operator coefficients and eleven-dimensional geometric sector are **Paper II-C inputs**, not an autonomous 11D construction imposed by Paper I-A. The decisive new identity $m\wedge m=0$ is an elementary *native geometric* closure and does not assume an empirical Standard Model mechanism.
- **Canonical source patch (proposed, not silently applied):** insert `Paper2C-SixOutcomeRadonCliffordNoGo-v1_1.tex` following `p2c:thm:gc20-antipodal-free-six`; update the theorem statement of `p2c:thm:v255-seven-outcome-attainment` and nearby outcome-count corollaries from `$6\le N_{\min}\le7$` to `$N_{\min}=7$` at $r_0$; reconcile all later historical "six-outcome remains open" remarks. Retain the source's geometric seven-parent proof and prior fixed-support no-gos as valid narrower results. Update the DAG and audit record for `BH-IIC-G-002` only **after** canonical integration and independent protocol verification. The protected 21/22 gate is not retired.

## 18. Independent verification replay

The companion `Paper2C-EndpointQuotientMinimum-v1_5.py` retains the earlier positive 136-, 22-, and 23-effect tests and seven-position rank checks. It adds direct matrix tests of (15.1) for the equal three-plus-three frame, unequal matched three-plus-three frames, and a two-plus-four frame. It reconstructs each $n_i$ from a legitimate $5\times6$ Parseval frame, checks $\sum c_i=\sum c_i n_i=0$, builds all $Z_i$ explicitly as nonnegative sums of rank-one matrices, verifies $\sum_P Z_i^+=\sum_M Z_j^-$ within rounding, and evaluates the strictly negative dual objective. The source proof is exact and does not depend on the floating-point tests.

---

# v1_6 extension — universally sharp geometric rank-six radius and complete endpoint counts

**Date:** 20 November 2026. **Proof status:** exact algebraic theorem, independently replayed using explicit $11\times11$ matrices and independent random finite spherical designs, including zero resource coefficients and coincident labels. **Source status:** research supplement and proposed LaTeX insertion only; canonical papers, DAG and proof-chain audits have not yet been patched. This extension **supersedes the intermediate radial bound and OPEN protected-readout status** mentioned in v1_5 and the older sections.

## 19. Two-parameter positive exterior kernel

Set $R=R_{\mathrm{mom}}$, write $V=\mathbb R^4$, $\mathcal H_G=\mathbb C\oplus\mathbb C^4\oplus\Lambda^2\mathbb C^4$, and recall the constituted geometric operators
\[
Y(u)=\frac R2 L_u+\frac{\sqrt2R}{3}(J_u+J_u^*),
\qquad J_u(v)=u\wedge v.
\]
For any real $s,t\ge0$ and unit $n,p\in S^3$ with $n\ne p$, set $d=1-n\cdot p>0$, $v=n-p$, $k=n\wedge p$, and define the positive rank-one matrix
\[
\boxed{K_{s,t}(n,p)=\frac1d
\left|(-sd,\ v,\ tk)\right\rangle
\left\langle(-sd,\ v,\ tk)\right|.}\tag{19.1}
\]
The partner $K_{s,t}(p,n)$ is the rank-one matrix of $(+sd,v,tk)/\sqrt d$ (equivalent up to an overall sign to the direct formula with $p-n$). Consequently,
\[
K_{s,t}(n,p)-K_{s,t}(p,n)
=-2s\bigl(|e_0\rangle\langle (v,tk)|+|(v,tk)\rangle\langle e_0|\bigr).\tag{19.2}
\]
This equality is **exact at the operator level**, including all scalar/vector, scalar/two-form, vector/two-form and form/form entries. If $\mu$ and $\nu$ are any two positive probability distributions on the unit sphere with a common barycenter $m$, equation (19.2) gives
\[
\boxed{\sum_{i,j}\mu_i\nu_j K_{s,t}(n_i,p_j)
=\sum_{i,j}\mu_i\nu_j K_{s,t}(p_j,n_i)}\tag{19.3}
\]
because $\sum\mu_i\nu_j(n_i-p_j)=0$ and
$\sum\mu_i\nu_j(n_i\wedge p_j)=m\wedge m=0$.

**Coincident labels need no exclusion.** For $n=p$, choose any unit $v\perp n$ and define
\[
K_{s,t}(n,n)=2\left|(0,v,-t\,n\wedge v)\right\rangle
\left\langle(0,v,-t\,n\wedge v)\right|.\tag{19.4}
\]
This is positive, paired identically on the two sides of (19.3), and has the same trace/coordinate pairings as the continuous off-diagonal limits. Different tangent choices may yield different matrices, but the needed pairings are independent of that choice. Thus (19.3) is valid for *arbitrary* finitely supported distributions, including shared atoms.

Two exact identities hold for every unit $n,p\in S^3$, including the coincident convention:
\[
\boxed{\operatorname{Tr}K_{s,t}(n,p)
=2+s^2+t^2+(t^2-s^2)(n\cdot p),}\tag{19.5}
\]
\[
\boxed{\operatorname{Tr}\!\left[Y(u)K_{s,t}(n,p)\right]
=R\left[-\left(s+\frac{2\sqrt2}{3}t\right)u\cdot n
+\left(s-\frac{2\sqrt2}{3}t\right)u\cdot p\right].}\tag{19.6}
\]
To prove (19.5), use $\|n-p\|^2=2d$ and $\|n\wedge p\|^2=1-(n\cdot p)^2$. For (19.6), the scalar–vector cross term is $-sR(n\cdot v)(u\cdot v)$, and the vector–two-form term is
$-\frac{2t\sqrt2R}{3}[(u\cdot n)\|v\|^2-(u\cdot v)(n\cdot v)]$; insert $n\cdot v=d$ and divide by $d$. The analogous expression for $K(p,n)$ follows by interchange. **No standard particle operator or empirical coupling is used.**

## 20. Universal geometric rank-six lower radius

**Theorem (sharp spectral rank-six radius).** On the *geometric* $11$-dimensional sector alone, consider any finite normalized positive POVM $(x_i,G_i)$ with exact first moments
\[
\sum_iG_i=I_G,\qquad \sum_i x_{ia}G_i=Y_a\quad(a=1,\ldots,4),\qquad \|x_i\|\le r.
\]
If its real geometric effect span has dimension $g\le6$, then
\[
\boxed{r\ge r_6:=\frac{\sqrt{34}}3R.}\tag{20.1}
\]
The bound is sharp, because the geometric compressions of the existing native six-orthogonal-trines POVM in `p2c:thm:v266-six-trines` have $g=6$ at $r=r_6$. The theorem permits arbitrary numbers of outcomes, arbitrary positions in the ball, arbitrary Hermitian nondiagonal effects, and no covariance or protected-sector assumption.

**Proof, Step 1 (reduce to spherical labels).** Any effect assigned a point $x_i/r$ strictly inside the unit ball can be split into two proportional positive effects assigned antipodal unit directions with the same barycenter. This preserves normalization, all four moments, and the *real geometric effect span*. Thus it suffices to prove the claim for $x_i=rn_i$, $\|n_i\|=1$, allowing repeated labels.

**Step 2 (rank five).** The five matrices $I_G,Y_1,\ldots,Y_4$ are independent and lie in the real span of the effects, so $g\ge5$. For $g=5$, write $G_i=\alpha_i I_G+Y(\beta_i)$. Positivity and the exact spectral minimum of $Y(u)$ yield $\alpha_i\ge (R/2)\|\beta_i\|$, while the first moments yield $\sum_i x_i\cdot\beta_i=4$. Therefore
\[
1=\sum_i\alpha_i\ge\frac R2\sum_i\|\beta_i\|
\ge\frac{2R}{r},\quad\text{i.e. }r\ge2R>r_6.
\]
Hence only $g=6$ needs the new witness.

**Step 3 (one extra geometric resource).** Choose any Hermitian $H\notin\mathcal L:=\operatorname{span}_{\mathbb R}\{I_G,Y_1,\ldots,Y_4\}$ completing the six-dimensional real effect span. Every effect has unique real coefficients
\[
G_i=\alpha_i I_G+Y(\beta_i)+c_iH,
\quad\beta_i\in\mathbb R^4.
\]
The five moment equations imply
\[
\begin{array}{lll}
\sum_i\alpha_i=1,&\sum_i\alpha_i n_i=0,&
\sum_i\beta_i=0,\\
\sum_i n_i\beta_i^T=I_4/r,&\sum_i c_i=0,&\sum_i c_i n_i=0.
\end{array}\tag{20.2}
\]
Not every $c_i$ can vanish since $g=6$. Their positive and negative sign classes $P,M$ are therefore both nonempty. Let
\[
C=\sum_{i\in P}c_i=-\sum_{j\in M}c_j>0,\qquad
\mu_i=c_i/C,\quad\nu_j=-c_j/C,
\]
so the two distributions share the same barycenter
$\sum_{i\in P}\mu_in_i=\sum_{j\in M}\nu_j n_j=m$.

**Step 4 (positive dual witnesses, including $c_i=0$).** Using (19.1)–(19.4), define
\[
D_i=\begin{cases}
\displaystyle\frac1C\sum_{j\in M}\nu_jK_{s,t}(n_i,n_j),&c_i\ge0,\\
\displaystyle\frac1C\sum_{j\in P}\mu_jK_{s,t}(n_i,n_j),&c_i<0.
\end{cases}\tag{20.3}
\]
Each $D_i\succeq0$. Indices with $c_i=0$ simply use the first line. Equation (19.3) shows that the unknown Hermitian correction cancels:
\[
\boxed{\sum_i c_iD_i=0.}\tag{20.4}
\]
The same-barycenter identities (19.5)–(19.6) give, for **every** $i$ regardless of sign or zero coefficient,
\[
\operatorname{Tr}D_i=\frac{2+s^2+t^2+(t^2-s^2)(n_i\cdot m)}C,
\]
\[
\operatorname{Tr}[Y(u)D_i]=\frac RC\left[-\left(s+\frac{2\sqrt2}{3}t\right)(u\cdot n_i)
+\left(s-\frac{2\sqrt2}{3}t\right)(u\cdot m)\right].\tag{20.5}
\]

**Step 5 (universal positive-trace contradiction).** Since $G_i,D_i\succeq0$, each $\operatorname{Tr}(G_iD_i)\ge0$. Expand with (20.2), (20.4), and (20.5). All unknown matrix directions and barycenter terms cancel, leaving
\[
\boxed{0\le\sum_i\operatorname{Tr}(G_iD_i)
=\frac1C\left[2+s^2+t^2
-\frac{4R}{r}\left(s+\frac{2\sqrt2}{3}t\right)\right]}\tag{20.6}
\]
for **every** $s,t\ge0$. Define $a=2\sqrt2/3$ and $u=(s,t)$. Elementary Cauchy–Schwarz and one-variable maximization give
\[
\max_{s,t\ge0}\frac{4(s+at)}{2+s^2+t^2}
=\sqrt2\sqrt{1+a^2}=\frac{\sqrt{34}}3,
\]
attained *exactly* at
\[
\boxed{s=\frac{3\sqrt2}{\sqrt{17}},\quad
 t=\frac4{\sqrt{17}},\quad s^2+t^2=2.}\tag{20.7}
\]
Thus (20.6) forces $r\ge\sqrt{34}R/3$. The existing two-trine six-outcome construction attains this radius; since $r_6<2R$, its six geometric effects have rank exactly six (not five). This proves sharpness. $\square$

**A geometric explanation of $\sqrt{34}$.** The spectral threshold is
\[
\frac{r_6^2}{R^2}=2\left[1+\left(\frac{2\sqrt2}{3}\right)^2\right]
=\frac{34}9.
\]
It combines the scalar/vector and vector/two-form couplings of the constituted exterior geometry via the *norm* of the pair $(1,2\sqrt2/3)$, rather than adding phenomenological correction weights. The earlier $s=t=1$ witness generated the slightly weaker arithmetic threshold $(1+2\sqrt2/3)R$. Optimizing the two native amplitudes precisely accounts for the residual $R(1-2\sqrt2/3)$ and reaches the known six-trine radius.

## 21. Corollaries: all three previously discussed endpoint count gaps are now sharp

**Corollary A (global six-outcome localization radius and full count function).** Any native POVM with six or fewer nonzero effects has geometric effect span $\le6$ and must therefore have $r\ge r_6$. Combining this lower bound with the existing exact protected radius $r_0=\sqrt3R$, the existing seven-outcome rule, the existing six-orthogonal-trines rule at $r_6$, and the existing five-outcome threshold $2R$ gives the full **unrestricted, native, exact-first-moment** phase diagram
\[
\boxed{N_{\min}(r)=\begin{cases}
\text{infeasible},&0<r<\sqrt3R,\\
7,&\sqrt3R\le r<\sqrt{34}R/3,\\
6,&\sqrt{34}R/3\le r<2R,\\
5,&r\ge2R.
\end{cases}}\tag{21.1}
\]
There is no remaining intermediate-radius six-versus-seven count ambiguity in the constituted operator model. The new theorem also proves that **the sharp geometric rank-six radius is identical to the previously constructed six-outcome radius**, independent of any finite outcome subgroup.

**Corollary B (global sharp 22-effect protected quotient).** At the endpoint $r_0=\sqrt3R<r_6$, Theorem 20 gives a **global** geometric effect-span lower bound $g\ge7$ for every normalized exact-first-moment native POVM, regardless of its number or choice of positions. If its full native real effect span contains the pure protected $15$-dimensional target
\[
\mathcal T=\{0_G\oplus T:T=T^*,\ \operatorname{Tr}(T\chi)=0\},
\]
then the native endpoint chirality obstruction implies that the kernel of geometric compression on the effect span is exactly $\mathcal T$. Rank-nullity yields
\[
N\ge \dim\operatorname{span}\{E_i\}=g+15\ge7+15=22.
\]
The existing exact positive 22-effect tagged refinement in `p2c:cor:v354-protected-22` realizes equality. Consequently
\[
\boxed{N_{\min}^{\mathrm{endpoint\ protected\ quotient}}=22.}\tag{21.2}
\]
This removes the formerly open 21-effect possibility **for all geometric supports**, not just the fixed seven-position set or finite-covariant POVMs.

**Corollary C (full endpoint quotient tomography).** The v1_2 full-span 136-effect construction and its dimension lower bound are unchanged:
\[
\boxed{N_{\min}^{\mathrm{endpoint\ full\ quotient}}=136.}\tag{21.3}
\]
The three readout goals are distinct: seven is the minimum for exact coordinates, 22 for the 15 pure protected quotient directions, and 136 for the complete native endpoint quotient hyperplane.

## 22. Implementation and provenance handoff

| Obligation | Mathematical outcome | Scope | Integration |
|---|---|---|---|
| `BH-IIC-G-002` | **CLOSED: 7 at $r_0$; complete $N_{\min}(r)$ phase diagram** | Arbitrary finite native POVM / coordinate labels in a radius-$r$ ball | Proposed source patch; canonical DAG/audit updates pending |
| `BH-IIC-G-003` | **CLOSED: 22 protected quotient effects at $r_0$** | Complete pure 15D protected chiral-quotient span | Proposed source patch; canonical DAG/audit updates pending |
| `BH-IIC-G-004` | **CLOSED: 136 full quotient effects at $r_0$** | Entire 136D chiral hyperplane in the native algebra | Existing v1_2 proof; canonical DAG/audit updates pending |

**Source ownership:** `Paper1A-Geometry-v5_180.tex` supplies the round $S^3$, $\operatorname{Spin}(4)$, and exterior/Hopf geometric background. The *constituted $11$-dimensional operator and coefficients* belong to `Paper2C-ReciprocalLocalization-v2_172.tex`, primarily `p2c:thm:v255-seven-outcome-attainment` and `p2c:thm:v266-six-trines`. The new proof discovers an unexploited **positive Radon–exterior witness** on those native objects. It makes no assertion that Paper I-A by itself forces a measurement or that the $600$-cell must be a physical detector; neither Standard Model decay vertices nor empirical branching weights enter.

**Recommended manuscript integration:** Insert the source-ready `Paper2C-UniversalGeometricRank6Radius-v1_1.tex` immediately after `p2c:thm:v266-six-trines` and before `p2c:cor:v266-outcome-count`; use its global geometric-rank theorem and corollaries to update the interval in `p2c:thm:v255-seven-outcome-attainment`, the ambiguous middle branch of `p2c:cor:v266-outcome-count`, and the protected minimum in `p2c:cor:v354-protected-22`. Retain prior narrower no-gos as valid historical proofs. Merge the separate v1_2 136 theorem into `p2c:thm:v354-exact-native-rank`. When canonical source compilation and DAG/audit reconciliation are completed, only then mark the matching proof obligations as canonically resolved.

**Evidence boundary:** All three are mathematical **POVM existence/minimality** theorems conditioned on the native operators and first moments already constituted in Paper II-C. They do not establish occurrence of a GP2-selected instrument, the Born-frequency law for physical measurement, the full framework's foundational geometry-to-operator inevitability, or a particle-decay model. Do not propagate these closure labels to those distinct downstream obligations.

**Verification:** The v1_6 executable retains prior 136-, 22-, and 23-effect construction checks and adds direct floating-point evaluations of (19.3), (19.5), (19.6), (20.4), and the sharp dual identity (20.6) on random six-, seven-, and ten-position direction sets. It tests a zero coefficient and coincident directions explicitly, verifies the optimized $s^2=18/17$, $t^2=16/17$, and checks the vanishing dual scalar at $r_6=\sqrt{34}R/3$. The universal proof itself is exact algebra, not numerical search.
