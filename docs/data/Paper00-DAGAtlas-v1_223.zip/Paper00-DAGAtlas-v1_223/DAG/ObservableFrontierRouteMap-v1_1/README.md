Current source-anchored E1 physical frontier to observable proof-route scope mapper. Canonical graph/proofs/physical status UNCHANGED. See standalone report and Index.json.
