# Planck curvature / Newton normalization — framework v3.036

**Status:** source integrated; 91/91 scoped algebra/finite arithmetic checks; exact paper sources compiled. No independent exhaustive E3/E4 audit of all four papers.

The existing geometric retraction $P_+/48$ yields the pure metric coefficient $U/8$ exactly. The common raw action yields $12U$. The new V-A trace-two bound excludes a fixed positive trace-two insertion from retaining the original weak kinetic trace; the new III-F propositions exclude pure field reparametrization and regular analytic gapped Schur mechanisms in their stated scope. Neither proves a physical sector-aware map exists.

The earliest still open physical match is the original III-F `p3f:prop:v2211-newton-owner-matching`. VI-A's tensor-source equation is the conditional scalar representative; VI-B's absolute observable calibrations inherit that condition. The affine terminal root $2C_{56}$ is outside the restricted affine branch, whereas III-F's active metric-$f(R)$ source-free vacuum lies in $(2C_{56},3C_{56})$. No physical FLRW action/history promotion.

**Source SHA-256** is in `SourceAnchors.json`; the complete source-version snapshot is `Sources-v3_036/`.
