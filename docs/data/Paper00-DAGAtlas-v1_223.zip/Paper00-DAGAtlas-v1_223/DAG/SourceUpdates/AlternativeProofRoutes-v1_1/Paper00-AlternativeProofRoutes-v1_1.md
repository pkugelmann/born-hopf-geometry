# Born–Hopf Geometry — Alternative Proof Routes and Certified-Bypass Scout

**Artifact:** `Paper00-AlternativeProofRoutes-v1_1.md`  
**Scope:** search and independent mathematical checks, **not** a one-paper audit or a DAG status update.  
**Inputs:** `Paper00-DAGAtlas-v1_158(1).zip`, `Paper00-PapersMinimal-v3_020(1).zip`, `Paper00-ProofChainAudits-v1_70(1).zip`; the rigorous verification protocol v2.4 was used as a semantic guard, not activated as a single-paper audit.  
**Authority:** current `.tex` source in PapersMinimal v3.020; older audit-route ledgers are candidate/trace records unless claim matched to the current source.

## 1. What was searched

The active release reports `DAG/CombinedProofRoutes-v1_158.json` and `DAG/CombinedMaterialEdges-v1_158.json`. The route ledger contains **5,398 current records**, **4,942 distinct nonnull targets**, and **281 targets with more than one recorded route**. Of the repeated targets, **272** have `p1b:`, `p1c:`, or `p1d:` prefixes and primarily reproduce historical/current source-layer carry-forward; **6** are `p12:` multi-obligation targets; **3** are `p3a:`/`p3d:` mathematical alternative-case groups. These groupings alone are **not** logical OR evidence.

The wider sweep then inspected all **35 registered audit indices**. **33** expose a parseable standard route array, yielding **7,791 local route records** and **860 locally repeated target groups**. These records overlap the combined ledger, include historical source-frozen audits, and must **not** be added to 5,398. The HurwitzHadron audit index and the Paper2B SourceUpdates index do not provide the standard sidecar needed by the scanner. Source-v3.020 changed-paper `E3/E4` re-certification is pending for some layers: the search does not silently upgrade it.

Method: group by **exact typed target**, inspect candidate route `AND_inputs`, source/audit scope, branch and issue provenance, distinguish alternative *proofs* from alternative *hypotheses* and different *subclaims*, and verify source equations at current labels. Never infer `OR` from multiple incoming proof edges (a single proof can require all of them).

## 2. Existing source-matched alternatives

| Claim/source locator | Recorded route IDs / distinct inputs | Adjudication |
|---|---|---|
| **II-B**, normalized full trace, `Paper2B-MomentumCarrier-v2_144.tex:1948–2037` | `BH-IIB-B2-ROUTE-TRACE-TRACIAL`: compact unitary carrier + **tracial state**. `BH-IIB-B2-ROUTE-TRACE-FULLU`: compact unitary carrier + **full U(V)-invariance**. | **Same conditional result, two valid sufficient certificates**. Full unitary invariance implies traciality for a state on `End(V)`; they are not independent axiomatic roots. Neither compact group invariance alone nor irreducible-sector invariance on a reducible carrier fixes all weights. |
| **II-B/II-F**, exceptional core support handoff, `Paper2B:1895–1916`, `Paper2F-TechnicalMaterial-v1_67.tex:1145–1190` | `BH-IIB-B2-ROUTE::p2:cor:neutral-level-one-handoff::core_handoff::via_resolution` (point resolution plus licensed core constructor and domain bridge), and `...::direct_occurrence` (direct core-constructor occurrence). | **Genuine physical-input OR** under separately proved antecedents; not two derivations from G0 alone, and neither chooses an embedded/labelled 2T member. |
| **II-A**, compact Lie operation parent, `Paper2A-GeometricConstitution-v3_222.tex:8409–8442` | `BH-IIA-ROUTE-B47-LIE-PORT-001`: faithful finite affine port; `BH-IIA-ROUTE-B47-LIE-INDEPENDENT-001`: separately supplied compact-Lie certificate. | **Two input routes** to the conditional parent result. The second assumes what the first constructs; not unconditional compact-Lie closure from bare G0. |
| **II-A**, generated exact solution moduli and common observable, `Paper2A:4044–4099` plus theorem `p2a:thm:generated-exact-solution-moduli` | `BH-IIA-ROUTE-B10-COMMON-001`: readout constant on a nonempty complete GP3 survivor family; `BH-IIA-ROUTE-C234-ORDER-ISO-001`: stronger whole-comparison graph-order isomorphism requiring preservation/reflection. | **Useful bypass of unnecessary strong condition for a weaker observable**. Does **not** prove the stronger order isomorphism or select a surviving member. |
| **II-B**, GP2 support/level vs universal endpoint, `Paper2B:1873–1916` | Source distinguishes `\mathcal G^{car}_{\Sigma_p}\cong\mathcal H_1,\ m_p=1` from the stronger every-endpoint one-copy theorem `p2b:thm:momentum-carrier-rigidity`. | **Scope-safe downstream bypass**: claims consuming only generated type support and level need not import universal GP3 endpoint multiplicity-one. Not an alternate proof of universal rigidity. |
| **V-A**, charged source applications, `Paper5A-FiniteMatterGeometry-v3_211.tex:3255–3294` | Exact tagged free-return/kinetic test **or** interacting source-visible Schur pole/rank test. | Two sufficient *application tests with different physical outputs*. The pole route does not need the stronger free-response identity, but no pole is certified without the actual action and source. |
| **VII-B**, conditional continued-pole theorem, `Paper7B-QCDReadouts-v1_159.tex:4285–4334` | `P7B-B05-ROUTE-4247`, source records a holomorphic-route separation from `p11:thm:schur-real-part-sheets-residues`. | **Valid mathematical bypass** *conditional on* already holomorphic continued `D_L^{II},D^{II}`, local uniform convergence, and an isolated simple zero. It does not prove the missing physical cut-to-sheet continuation. |

**Avoid misclassifying:** `p3a:v251:thm:shared-second-jet` has two explicitly flagged same-conclusion alternatives labelled `REAL_VARIANCE` and `COMPLEX_VARIANCE` (`Paper3A:5548–5593`). They apply the **same argument in different carrier cases**, not two independent proofs over the same domain. `p3d:thm:v173-fixed-depth-laurent-excess-jet` has separate `EXJET7` and stronger `EXCHAR7` records (`Paper3D:2571–2700`), which are nested tests, not independent source evaluations. Some `p12:` duplicated targets separate correct spectral or physical subclauses from blocked or invalid shortcuts; the latter never counts as a proof alternative.

The VII-C route ledger additionally labels four issue-specific `bypass_of` cases (`BH-VIIC-G-0005`, `BH-VIIC-G-0008`, and the pair `BH-VIIC-G-0009/0010`), but the source-preserving bypass route is only scoped to the corresponding claim. This is **not** evidence that each parent issue is resolved globally.

## 3. New independent mathematical replays (not yet DAG-registered)

### A. II-B faithful module and 15-state capacity: direct matrix-unit proof

**Exact source:** `Paper2B-MomentumCarrier-v2_144.tex:3085–3168`, `p2b:thm:v352-minimal-faithful`, `p2b:thm:v352-capacity-euler`, `p2b:cor:v352-three-stage-capacity`. The input is the **already constituted abstract algebra** `A=\bigoplus_i M_{d_i}(\mathbb C)`; no argument below constructs it from G0.

Let `e_{ab}^{(i)}` be matrix units. In a finite-dimensional faithful unital *-representation, the projections `P_a^{(i)}=\pi(e_{aa}^{(i)})` are pairwise orthogonal, and the partial isometries `\pi(e_{ab}^{(i)})` make their nonzero ranges unitarily equivalent. Thus the ranks are a common positive integer `m_i`. The central projection for block `i` is their sum, so `\dim H_i=d_im_i`. Choosing a basis of `\operatorname{ran}P_1^{(i)}` and transporting it with each `\pi(e_{a1}^{(i)})` explicitly constructs

\[
H\simeq\bigoplus_i\mathbb C^{d_i}\otimes\mathbb C^{m_i},\quad
\pi(A)\simeq\bigoplus_i M_{d_i}(\mathbb C)\otimes I_{m_i}.
\]

An operator commuting with all matrix units must be `\bigoplus_i I_{d_i}\otimes B_i`, giving the claimed commutant and the iff condition `\pi(A)'=Z(\pi(A))` precisely at `m_i=1`. The lower bound `\dim H\ge\sum_i d_i`, and uniqueness of the equality case, follow directly. This **avoids importing the irreducible-representation classification as an unexplained starting point** (although it uses the same elementary matrix-unit structure).

Independent checks on the same abstract algebra compute `C_1(A)=\sum_i d_i` by single-POVM distinguishability, and `\chi(\mathcal P(A))=\sum_i\chi(\mathbb{CP}^{d_i-1})=\sum_i d_i` by finite pure-state topology. These are distinct calculation channels to one number, but **share** the block sizes `d_i` and thus cannot independently select the algebra.

| Abstract algebra | Block sizes | `dim A` | `dim H_min = C_1 = χ(P(A))` |
|---|---|---:|---:|
| `A_kin` | 1,2,2,4,3,3 | 43 | **15** |
| `A_D` | 11,4 | 137 | **15** |
| `A_full` | 15 | 225 | **15** |

**Verdict:** independently replayed *mathematical* theorem at preconstituted algebra scope; no new GP2 constitution or physical state capacity-rate claim.

### B. III-A shared Schur second jet: variational first-order proof

**Exact source:** `Paper3A-GeneratedDynamics-v1_176.tex:5520–5593`, `p3a:v251:thm:shared-second-jet`. The original proof differentiates `V=\sum_i\Delta_i^*C_i\Delta_i` twice. A separate route starts with the constrained quadratic optimization itself.

For a fixed retained vector `x`, complete each sector quadratic as

\[
Q_i(x,y;q)=x^*K_i(q)x+(y+L_i(q)x)^*C_i(q)(y+L_i(q)x),
\qquad L_i=C_i^{-1}B_i^*.
\]

If the interior `y` is shared, its optimizer is `y_*(q)=-\bar L(q)x`, where `\bar L=(\sum C_i)^{-1}\sum C_iL_i`. Independently minimized sectors would attain `\sum_i x^*K_ix`; their common-interior excess is

\[
x^*V(q)x=\sum_i\|C_i(q)^{1/2}(L_i(q)-\bar L(q))x\|^2.
\]

At `q_0`, suppose all `L_i(q_0)=L_0`. Along `q(t)=q_0+tv`, the positive matrices are `C_i(t)=C_i(0)+O(t)` and the sector slopes are `L_i(t)=L_0+tD_vL_i+O(t^2)`. Consequently, to **first order**, the shared optimizer has slope `M_v=(\sum C_i(0))^{-1}\sum C_i(0)D_vL_i`, and its residual is `tT_{i,v}x+O(t^2)` with `T_{i,v}=D_vL_i-M_v`. Therefore

\[
V(q_0+tv)=t^2\sum_iT_{i,v}^*C_i(q_0)T_{i,v}+o(t^2).
\]

Polarization gives the theorem's mixed second-jet formula

\[
D^2V(q_0)[v,w]=\sum_i(T_{i,v}^*C_iT_{i,w}+T_{i,w}^*C_iT_{i,v}),
\]

and strict positivity implies vanishing iff the first derivatives of all sector slopes match. This route **does not differentiate the full variance formula twice**; it derives the quadratic jet from the shared minimization and linearized stationary equations. It shares the same complete-square identity and positivity premise, so it is independent computational verification, **not** a bypass of those axioms.

**Exact symbolic control:** with scalar `C_1=2+q`, `C_2=3-q`, `L_1=1+2q+q²`, `L_2=1-q+3q²`, the direct Schur block and weighted-variance forms are identically equal, `V(0)=V'(0)=0`, and the computed second derivative is **`V''(0)=108/5`**, matching `2\sum_i C_i(0)T_i^2` exactly. The check uses changing `C_i`, so nonzero `D C_i` is tested.

**Verdict:** independent, exact, conditional mathematical proof/check of the already stated theorem; does not prove actual sector compatibility or a physical mass Hessian.

### C. VII-B isolated pole and residue limit: contour proof

**Exact source:** `Paper7B-QCDReadouts-v1_159.tex:4285–4334`, `p11:thm:isolated-resonance-pole-residue-limit`. The source proof uses Rouché's theorem, null-vector perturbation, and derivative convergence. An independent route uses the argument principle plus contour residues, avoiding the null-vector continuity step entirely.

Let `F_L(z)=\det D_L^{II}(z)` and `F(z)=\det D^{II}(z)`. On the specified contour `\partial U`, `F` is nonzero. Holomorphic local-uniform matrix convergence implies uniform convergence of `F_L,F_L'` and `D_L^{-1}` on that contour (the latter by continuity of inversion on invertible matrices). The integer

\[
N_L=\frac{1}{2\pi i}\oint_{\partial U}\frac{F_L'(z)}{F_L(z)}\,dz
\]

converges to the analogous winding number for `F`, which equals **one**; since each `N_L` is an integer, `N_L=1` eventually. Thus exactly one simple zero exists inside. Its location is recovered directly from the first logarithmic moment,

\[
s_{p,L}=\frac1{2\pi i}\oint_{\partial U}z\frac{F_L'(z)}{F_L(z)}\,dz\longrightarrow s_p.
\]

The inverse matrices have exactly one simple pole inside. Its **matrix** residue is the contour integral

\[
R_L=\frac1{2\pi i}\oint_{\partial U}(D_L^{II}(z))^{-1}\,dz
\longrightarrow\frac1{2\pi i}\oint_{\partial U}(D^{II}(z))^{-1}\,dz=R.
\]

At a simple determinant zero, `rank D(s_p)=r-1` (otherwise its adjugate vanishes and the derivative of the determinant would be zero). The identity `D^{-1}=\operatorname{adj}(D)/\det D` yields the source's rank-one matrix residue `R=v_pw_p^\dagger/(w_p^\dagger D'(s_p)v_p)`. Therefore the source expression converges even without first choosing continuous phases for null vectors; the matrix residue is phase invariant.

**Finite control:** `D_\varepsilon(z)=\begin{pmatrix}z-1/2-\varepsilon&1\\\varepsilon&z+1\end{pmatrix}` converges holomorphically to `D_0`. On a small disk around `z=1/2` the limiting pole is isolated, with residue `R_0=\begin{pmatrix}1&-2/3\\0&0\end{pmatrix}`. For `\varepsilon=1/L`, the matrix-residue infinity-norm differences at `L=20,100,1000` are about **0.06639, 0.01448, 0.001478**, respectively, agreeing with convergence.

**Verdict:** independent mathematical proof at the already-holomorphic stated domain. Neither proof supplies the channel-local continuation from the physical cut nor the extra S-matrix package, both explicitly guarded in the source and historical audit.

## 4. Where the DAG can gain real robustness

1. **Normalize proof-route identity across local layers and consolidated exports.** Source-matched alternative routes for II-B normalized trace and core handoff are present in registered local audit layers but absent as distinct exact targets in the combined route ledger. Preserve `AND` inside each, `OR` across them, original guarded scopes, and source/current-version provenance. An apparent lack of OR in the combined layer is therefore not a proof of nonexistence.
2. **Represent proof-equivalent numerical witnesses separately from conditionally sufficient branches.** The triple fifteen-state invariant, for example, is a multi-invariant confirmation under one *shared* algebra, not three independent G0 derivations.
3. **Find downstream conditional-bypass leverage.** In the combined reviewed material index, `p2:thm:momentum-host-H1` has **148** recorded descendants while `p2b:thm:momentum-carrier-rigidity` has **8**. This difference motivates checking which observables actually consume only the generated H1 support / `m_p=1`; it does **not** mean all 148 are certified without any other conditions.
4. **Prioritize true independent checks of theorem owners** for which an external mathematical technique exists (matrix units vs representation classification, constrained minimization vs Hessian differentiation, contour argument vs null-vector perturbation). Maintain `E3` source/version proof scope and an `E4` adversarial control before integrating an `ALTERNATIVE_ROUTE` in the official DAG.

## 5. Explicit negative findings and constraints

- None of the three mathematical replays removes a physical-occurrence gate, an unverified construction of the abstract test algebra, or the need for a source/action correspondence. They cannot upgrade global physical claims.
- The III-A real/complex versions are **carrier cases**, not independent same-domain proofs.
- The III-D `EXJET_7` and `EXCHAR_7` tests are **nested** (stronger implies weaker), not independent evaluations.
- In VII-C, issue-specific source bypasses do not globally invalidate the corresponding gap registry roots; stronger physical claims retain their own conditions.
- The input archive is **unchanged**. The accompanying JSON is a *scout ledger* (not new canonical DAG authority), and the scripts only reproduce metadata and mathematical controls. The source provenance and all original audit statuses are retained without promotion.

## 6. Bundle contents and repeatability

- `Paper00-AlternativeProofRoutes-v1_1.md`: source-matched findings and proofs (this report).
- `Paper00-AlternativeProofRoutes-v1_1.json`: route IDs, guard metadata, exact source label, current `.tex` SHA-256, aggregate counts and caveats.
- `Paper00-AlternativeProofRoutes-v1_1.py`: standard-library registered-audit and combined-ledger scanner; source locators recovered from current `.tex`.
- `Paper00-AlternativeProofRoutesCheck-v1_1.py`: SymPy/Numpy exact controls for the three mathematical examples.

No DAG ZIP or audit ZIP was rewritten because this request was to **search**, and full global integration would require a separate source-bound adjudication against all affected existing route semantics.
