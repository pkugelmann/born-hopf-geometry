#!/usr/bin/env python3
"""Non-promoting alternative-proof-route scout for a supplied Born-Hopf DAG ZIP.

Requires only Python standard library. It inventories routes and emits source-verified
candidate pointers; no candidate is promoted to a certified physical proof.
Example:
 python Paper00-AlternativeProofRoutes-v1_1.py --atlas /path/DAGAtlas.zip --papers /path/PapersMinimal.zip --out scout.json
"""
import argparse, collections, hashlib, json, pathlib, zipfile

CANDIDATE_SPECS = [
  {"claim":"p2:thm:no-insertion-finite-trace-weight::CONCLUSION::normalized_full_trace","kind":"SOURCE_OR_CERTIFICATES", "source_label":"p2:thm:no-insertion-finite-trace-weight","source_file_prefix":"Paper2B-", "route_ids":["BH-IIB-B2-ROUTE-TRACE-TRACIAL","BH-IIB-B2-ROUTE-TRACE-FULLU"], "restriction":"Traciality and full-U(V) invariance are alternate sufficient checks; the latter is not a weaker assumption."},
  {"claim":"p2:cor:neutral-level-one-handoff::CONCLUSION::core_handoff", "kind":"SOURCE_CONDITIONAL_OR", "source_label":"p2:cor:neutral-level-one-handoff", "source_file_prefix":"Paper2B-", "route_ids":["BH-IIB-B2-ROUTE::p2:cor:neutral-level-one-handoff::core_handoff::via_resolution","BH-IIB-B2-ROUTE::p2:cor:neutral-level-one-handoff::core_handoff::direct_occurrence"], "restriction":"Requires its route-specific occurrence or core constructor and domain bridge; does not select a marked 2T member."},
  {"claim":"p2:thm:gp1-gp2-compact-natural-alternatives", "kind":"SOURCE_CONDITIONAL_OR", "source_label":"p2:thm:gp1-gp2-compact-natural-alternatives", "source_file_prefix":"Paper2A-", "route_ids":["BH-IIA-ROUTE-B47-LIE-PORT-001","BH-IIA-ROUTE-B47-LIE-INDEPENDENT-001"], "restriction":"An independent compact-Lie certificate is separately supplied, not generated from weaker G0 alone."},
  {"claim":"p3a:v251:thm:shared-second-jet:SECOND_JET_FORMULA", "kind":"CARRIER_BRANCH_NOT_INDEPENDENT_PROOF", "source_label":"p3a:v251:thm:shared-second-jet", "source_file_prefix":"Paper3A-", "route_ids":["BH-IIIA-ROUTE-B5-0176:SECOND_JET_FORMULA:REAL_VARIANCE","BH-IIIA-ROUTE-B5-0176:SECOND_JET_FORMULA:COMPLEX_VARIANCE"], "restriction":"Real and complex carrier variants share one mathematical proof; not independent same-domain proof routes."},
  {"claim":"p3d:thm:v173-fixed-depth-laurent-excess-jet", "kind":"STRONGER_WEAKER_HYPOTHESIS_NOT_INDEPENDENT", "source_label":"p3d:thm:v173-fixed-depth-laurent-excess-jet", "source_file_prefix":"Paper3D-", "route_ids":["BH-IIID-ROUTE-0070","BH-IIID-ROUTE-EXCHAR7-INTERVAL"], "restriction":"EXCHAR7 is stronger than EXJET7. Neither condition is automatically an evaluated physical Ward defect."},
  {"claim":"p11:thm:isolated-resonance-pole-residue-limit", "kind":"HOLMORPHIC_BYPASS_CONDITIONAL", "source_label":"p11:thm:isolated-resonance-pole-residue-limit", "source_file_prefix":"Paper7B-", "route_ids":["P7B-B05-ROUTE-4247"], "restriction":"Assumes the sheet-domain holomorphy and norm convergence as stated; does not prove physical analytic continuation."},
  {"claim":"p5:cor:v2168-charged-source-application-routes", "kind":"DIFFERENT_APPLICATION_TESTS", "source_label":"p5:cor:v2168-charged-source-application-routes", "source_file_prefix":"Paper5A-", "route_ids":["ROUTE-VA-B2-077"], "restriction":"Free-response and interacting pole tests do not establish identical physical claims."},
  {"claim":"p2a:thm:generated-exact-solution-moduli", "kind":"WEAKER_OBSERVABLE_ROUTE", "source_label":"p2a:thm:generated-exact-solution-moduli", "source_file_prefix":"Paper2A-", "route_ids":["BH-IIA-ROUTE-B10-COMMON-001","BH-IIA-ROUTE-C234-ORDER-ISO-001"], "restriction":"A common readout can be established without proving the stronger graph order isomorphism; these are not proofs of the same full theorem."},
  {"claim":"p2b:cor:v352-three-stage-capacity", "kind":"THREE_INVARIANT_CHECKS", "source_label":"p2b:cor:v352-three-stage-capacity", "source_file_prefix":"Paper2B-", "route_ids":[], "restriction":"Minimum faithful module, single-POVM distinguishability and Euler characteristic share an already constituted abstract algebra; not independent constitutional selection."},
]

def source_file_list(p):
 return sorted(n for n in p.namelist() if n.endswith('.tex') and '/' not in n)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--atlas',required=True);ap.add_argument('--papers',required=True);ap.add_argument('--out',required=True);o=ap.parse_args()
 with zipfile.ZipFile(o.atlas) as az, zipfile.ZipFile(o.papers) as pz:
  roots={n.split('/')[0] for n in az.namelist()}; root=next(k for k in roots if k.startswith('Paper00-DAGAtlas-'))
  def aj(f):return json.loads(az.read(root+'/'+f))
  active=aj('DAG/ActiveRelease-v1_158.json');rel=active['release']
  central=aj(active['current_proof_routes'])['current'];registered=aj(active['current_registered_audit_layers'])['all_registered_audit_layers']
  targetmap=collections.defaultdict(list)
  for r in central:
   if r.get('target'):targetmap[r['target']].append(r.get('id'))
  duplicated={t:v for t,v in targetmap.items() if len(v)>1}
  historic={t:v for t,v in duplicated.items() if t.startswith(('p1b:','p1c:','p1d:'))}
  p12={t:v for t,v in duplicated.items() if t.startswith('p12:')}
  math={t:v for t,v in duplicated.items() if t.startswith(('p3a:','p3d:'))}
  local=[];route_sidecars=[];unavailable=[];srcs=source_file_list(pz)
  for index in registered:
   d=aj(index);paths=[v for k,v in d.get('sidecars',{}).items() if isinstance(v,str) and v.endswith('.json') and 'route' in k.lower()]
   paths=[path for path in paths if root+'/'+path in az.namelist()]
   if not paths:
    fallback=index.rsplit('/',1)[0]+'/ProofRoutes.json'
    if root+'/'+fallback in az.namelist():paths=[fallback]
   if not paths:unavailable.append(index);continue
   for path in paths:
    d=aj(path);li=(d if isinstance(d,list) else next((d[k] for k in ('routes','items','current','proof_routes') if isinstance(d.get(k),list)), None))
    if not isinstance(li,list):unavailable.append(index+' -> '+path+' (non-list format)');continue
    rowlist=[r for r in li if isinstance(r,dict)]
    route_sidecars.append({'file':path,'n':len(rowlist)})
    for row in rowlist:local.append({'index':index,'file':path,**row})
  locmap=collections.defaultdict(list)
  routeidmap=collections.defaultdict(list)
  for r in local:
   if r.get('target'):locmap[r['target']].append(r.get('id'))
   if r.get('id'):routeidmap[r['id']].append(r)
  localduplicates={k:v for k,v in locmap.items() if len(v)>1}
  candidates=[]
  for item in CANDIDATE_SPECS:
   it=item.copy()
   src=next((f for f in srcs if f.startswith(it['source_file_prefix'])),None)
   it['source_file']=src
   if src:
    data=pz.read(src);txt=data.decode('utf8',errors='replace');lines=txt.splitlines();targ='\\label{'+it['source_label']+'}'
    it['source_line']=next((i+1 for i,t in enumerate(lines) if targ in t),None)
    it['source_sha256']=hashlib.sha256(data).hexdigest()
   it['registered_routes']=[{'id':rid,'local_records':[{'index':q['index'],'target':q.get('target'),'status':q.get('status'), 'and_inputs':q.get('and_inputs',q.get('AND_inputs',q.get('and_guards',[])))} for q in routeidmap.get(rid,[])], 'combined_record_found':any(q.get('id')==rid for q in central)} for rid in it['route_ids']]
   candidates.append(it)
  report={'protocol':'SCOUT_ONLY_NO_STATUS_PROMOTION', 'atlas_archive':pathlib.Path(o.atlas).name,'papers_archive':pathlib.Path(o.papers).name,'active_release':rel,'source_tree':active.get('source_tree'), 'counts':{'combined_route_records':len(central),'combined_unique_targets':len(targetmap),'combined_repeated_target_groups':len(duplicated),'combined_historical_source_carryover_groups':len(historic),'combined_p12_multiscope_groups':len(p12),'combined_math_candidate_groups':len(math),'registered_audit_indices':len(registered),'parseable_local_proof_route_files':len(route_sidecars),'local_route_records_parsed':len(local),'local_repeated_target_groups':len(localduplicates),'unavailable_or_nonstandard':len(unavailable)}, 'local_parse_limits':unavailable,'candidate_cases':candidates,'qualification':'The repeated-target counts are metadata counts, not proofs of logically independent routes; E3 status requires mathematical replay at current source and no automatic OR inference from two edges.'}
  pathlib.Path(o.out).write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
  print(json.dumps(report['counts'],indent=2));print('wrote',o.out)

if __name__=='__main__':main()
