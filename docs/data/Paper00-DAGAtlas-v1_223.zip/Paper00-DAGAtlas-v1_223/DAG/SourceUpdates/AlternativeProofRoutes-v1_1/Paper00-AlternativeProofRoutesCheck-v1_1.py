#!/usr/bin/env python3
"""Independent exact checks for three route-scout cases (mathematical scope only)."""
from sympy import Matrix, Rational, Symbol, diff, simplify, solve, N
import numpy as np

# II-B: three abstract algebra realizations with distinct dimensions.
stages={"A_kin":[1,2,2,4,3,3], "A_D":[11,4], "A_full":[15]}
for name,d in stages.items():
    hmin=sum(d);algebra_dim=sum(x*x for x in d);euler=sum(d)
    # The POVM distinguishability bound and CP Euler result both sum d_i.
    assert hmin==15 and euler==15
    print("II-B",name,"minH",hmin,"C1",sum(d),"chi",euler,"dimA",algebra_dim,"center",len(d))

# III-A: exact common Schur reduction and first-order variational second jet.
q=Symbol('q'); C1=2+q;C2=3-q;L1=1+2*q+q**2;L2=1-q+3*q**2
weighted=simplify((C1*L1+C2*L2)/(C1+C2))
V=simplify(C1*(L1-weighted)**2+C2*(L2-weighted)**2)
K1,K2=5,7
A1=K1+C1*L1**2;A2=K2+C2*L2**2
Kcommon=simplify(A1+A2-(C1*L1+C2*L2)**2/(C1+C2))
assert simplify(Kcommon-(K1+K2)-V)==0
assert V.subs(q,0)==0 and diff(V,q).subs(q,0)==0
w=Rational(1,5);T1=2-w;T2=-1-w
vsecond=diff(V,q,2).subs(q,0)
assert vsecond==2*(2*T1**2+3*T2**2)==Rational(108,5)
print('III-A','V0=0','Vprime0=0','Vsecond0=',vsecond,'exact Schur-V identity=PASS')

# VII-B: holomorphic 2x2 inverse-propagator family, exact residue by adjugate/det'.
z,epsilon=Symbol('z'),Symbol('epsilon');a=Rational(1,2)
D=Matrix([[z-a-epsilon,1],[epsilon,z+1]]);det=simplify(D.det());roots=solve(det,z)
Rlimit=np.array([[1.,-2/3],[0.,0.]])
for size in [20,100,1000]:
    e=Rational(1,size)
    zz=min([complex(N(rt.subs(epsilon,e))) for rt in roots],key=lambda v:abs(v-.5))
    resid=np.array((D.adjugate()/diff(det,z)).subs({epsilon:e,z:zz}).evalf(),dtype=complex)
    err=np.linalg.norm(resid-Rlimit,ord=np.inf)
    assert err < 2/size
    print('VII-B','L',size,'pole',zz.real,'residue_err_inf',float(err))
print('All independent finite/symbolic checks passed; no physical continuation claimed.')
