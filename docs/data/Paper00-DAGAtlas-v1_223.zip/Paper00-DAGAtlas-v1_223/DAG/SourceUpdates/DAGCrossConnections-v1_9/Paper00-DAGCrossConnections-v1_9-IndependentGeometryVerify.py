#!/usr/bin/env python3
"""Independent geometric falsification/reconstruction of CC18 claims.
Builds the 600 tetrahedral facets as K4 cliques in the H4 root graph,
then matches these geometrical centres to the separate double-coset blocks.
Does NOT import/reuse the v1.8 verification programs.
No physical realization is inferred.
"""
import itertools as it
import json
import math
import numpy as np
from scipy.spatial import cKDTree
from scipy.special import sph_harm_y, eval_legendre
from scipy.linalg import svdvals

phi=(1+math.sqrt(5))/2
roots=[]
for axis in range(4):
 for sign in (-1,1):
  v=np.zeros(4);v[axis]=sign;roots.append(v)
for sig in it.product((-1,1), repeat=4):
 roots.append(np.asarray(sig,dtype=float)*0.5)
for order in it.permutations(range(4)):
 if sum(order[i]>order[j] for i in range(4) for j in range(i+1,4)) % 2:continue
 for sig in it.product((-1,1), repeat=3):
  v=[0,sig[0]/2,sig[1]*phi/2,sig[2]/(2*phi)]
  roots.append(np.array([v[k] for k in order]))
G=np.asarray(roots)
assert G.shape==(120,4) and max(abs(np.sum(G*G,axis=1)-1))<1e-13

# EXTERNAL geometry test: enumerate all tetrahedral facets from graph cliques.
D=G@G.T
adj=np.isclose(D,phi/2,atol=1e-12)
np.fill_diagonal(adj,False)
assert set(adj.sum(axis=1))=={12}
cliques=[]
for a in range(120):
 nbr=[b for b in np.flatnonzero(adj[a]) if b>a]
 for b,c,d in it.combinations(nbr,3):
  if adj[b,c] and adj[b,d] and adj[c,d]:cliques.append((a,b,c,d))
assert len(cliques)==600, len(cliques)
centers=np.array([G[list(C)].sum(axis=0) for C in cliques]);centers/=np.linalg.norm(centers,axis=1)[:,None]
assert len({tuple(np.round(v,10)) for v in centers})==600

def qprod(a,b):
 a=np.asarray(a);b=np.asarray(b)
 x,y,z,t=np.moveaxis(a,-1,0);u,v,w,s=np.moveaxis(b,-1,0)
 return np.stack((x*u-y*v-z*w-t*s, x*v+y*u+z*s-t*w,
                  x*w-y*s+z*u+t*v, x*s+y*w-z*v+t*u),axis=-1)
H=G[:24]
qU=np.array([1/math.sqrt(2),1/math.sqrt(2),0,0])
# Source double coset, independent of geometrically generated clique-centres
outer=qprod(qprod(G[:,None,:],qU),G[None,:,:]).reshape((-1,4))
rows=cKDTree(centers).query(outer,k=1)
assert max(rows[0])<1e-12
assert len(set(rows[1]))==600

# Direct construction of 5 right H cosets and 5 left H cosets.

def get_coset_reps(left=True):
 reps=[];claimed=set()
 for v in G:
  if tuple(np.round(v,9)) in claimed:continue
  reps.append(v)
  orbit=qprod(v,H) if left else qprod(H,v)
  claimed.update(tuple(np.round(q,9)) for q in orbit)
 assert len(reps)==5 and len(claimed)==120
 return np.array(reps)
leftrep=get_coset_reps(True);rightrep=get_coset_reps(False)
block=np.full(600,-1,dtype=int)
for a,aa in enumerate(leftrep):
 for b,bb in enumerate(rightrep):
  orbit=qprod(qprod(qprod(aa,H),qU),bb)
  dist,ix=cKDTree(centers).query(orbit)
  assert max(dist)<1e-12 and np.all(block[ix]<0) and len(set(ix))==24
  block[ix]=5*a+b
assert np.all(block>=0) and set(np.bincount(block))=={24}

def hopf(q):
 # Equivalent to q*i*q^{-1}; real coordinate formulas, without quaternion multiplication.
 w,x,y,z=np.moveaxis(q,-1,0)
 return np.stack((1-2*(y*y+z*z),2*(x*y+w*z),2*(x*z-w*y)),axis=-1)

vsky=hopf(G);fsky=hopf(centers)
# This new code counts rounded geometric directions, NOT coset-constructed sky points.
V={}
for q in vsky:
 k=tuple(np.round(q,9));V[k]=V.get(k,0)+1
F={}
for q in fsky:
 k=tuple(np.round(q,9));F[k]=F.get(k,0)+1
assert len(V)==30 and set(V.values())=={4}
assert len(F)==150 and set(F.values())=={4}
assert set(V).issubset(F)
assert all(abs(np.linalg.norm(z)-1)<1e-9 for z in F)
weighted=np.r_[np.full(120,1/504),np.full(600,2/1575)]
sky=np.r_[vsky,fsky]

# Harmonic orthogonality is an independent check of S^2 degree-nine exactness.
def spherical(V,ell):
 azimuth=np.arctan2(V[:,1],V[:,0]);colat=np.arccos(np.clip(V[:,2],-1,1)); colat=np.where(np.abs(1-np.abs(V[:,2]))<1e-12, np.where(V[:,2]>0,0.,math.pi), colat)
 return np.sqrt(4*np.pi)*np.column_stack([sph_harm_y(ell,m,colat,azimuth) for m in range(-ell,ell+1)])
Y=np.concatenate([spherical(sky,l) for l in range(10)],axis=1)
C=(np.sqrt(weighted)[:,None]*Y[:,:25])
frame_err=np.max(abs(C.conj().T@C-np.eye(25)))
leak_err=np.max(abs(C.conj().T@(np.sqrt(weighted)[:,None]*Y[:,25:36])))
harm_means={str(l):float(np.max(np.abs(weighted@spherical(sky,l)))) for l in range(1,10)}
assert frame_err<1e-10 and leak_err<1e-10 and max(harm_means.values())<1e-10
l10_witness=float(weighted@eval_legendre(10,np.clip(sky[:,0],-1,1)))
assert abs(l10_witness-104975/1376256)<1e-10

# Chamber means via the newly enumerated facet-centre order.
Bm=np.zeros((25,600));Bm[block,np.arange(600)]=1/24
FY=np.concatenate([spherical(fsky,l) for l in range(7)],axis=1)
R=Bm@FY
Z=np.ones((5,5))/5;W=np.eye(5)-Z
P0=np.kron(Z,Z);Pa=np.kron(Z,W)+np.kron(W,Z);Pc=np.kron(W,W)
rank_and_spec={}
for l in range(7):
 X=R[:,l*l:(l+1)**2]
 s=svdvals(X)
 rank_and_spec[str(l)]={'rank':int(sum(s>1e-8)),'singular_values':[float(x) for x in s if x>1e-8]}
assert [rank_and_spec[str(l)]['rank'] for l in range(7)]==[1,0,0,4,4,0,5]
for l in (3,4):
 assert np.max(abs(svdvals(R[:,l*l:(l+1)**2])[:4]**2-525/64))<1e-10
 assert np.linalg.norm((np.eye(25)-Pc)@R[:,l*l:(l+1)**2])<1e-10
assert np.linalg.norm(R[:,9:16].conj().T@R[:,16:25])<1e-10
sing6=svdvals(R[:,36:49])
assert abs(sing6[0]**2-1934075/262144)<1e-9
assert np.max(abs(sing6[1:5]**2-3473925/1048576))<1e-9
L6=R[:,36:49]
assert np.max(abs(svdvals(Pc@L6)[:4]**2-170625/1048576))<1e-9
pa6=svdvals(Pa@L6)
assert abs(pa6[0]**2-1576575/262144)<1e-9
assert np.max(abs(pa6[1:5]**2-825825/262144))<1e-9
assert abs(svdvals(P0@L6)[0]**2-89375/65536)<1e-9

# Exact paper I-B 10 axes, explicitly copied from the mathematical source, not from v1.8 code.
raw_axes=np.array([[1,1,1],[1,1,-1],[1,-1,1],[1,-1,-1],
 [1/phi,-phi,0],[phi,0,-1/phi],[0,1/phi,-phi],
 [0,1/phi,phi],[phi,0,1/phi],[1/phi,phi,0]],dtype=float)
axes=raw_axes/math.sqrt(3)
assert max(abs(np.linalg.norm(axes,axis=1)-1))<1e-14
T=np.mean(eval_legendre(6,np.clip(fsky@axes.T,-1,1)),axis=1)
F6=np.mean(eval_legendre(6,np.clip(fsky@vsky.T,-1,1)),axis=1)
assert max(abs(F6-9*T/16))<1e-10
Tregs=Bm@T
Tmat=Tregs.reshape(5,5)
assert max(abs(Tmat[:,0]-11/144))<1e-10
assert max(abs(Tmat[:,1:]+451/9216).flatten())<1e-10
assert np.linalg.norm(Pc@Tregs)<1e-10
assert abs(np.mean(Tregs)+55/2304)<1e-10
# Exact source T6 norm via the addition theorem, using the ten source axes.
Tnorm2=float(np.mean(eval_legendre(6,np.clip(axes@axes.T,-1,1)))/13)
assert abs(Tnorm2-11/1053)<1e-12
# A sharp, explicit counterexample to SU(3) covariance of the given channel.
X=np.array([[0,1j,0],[-1j,0,0],[0,0,0]])
U=np.exp(-1j*math.pi/6)*np.diag([1j,1,1]); assert abs(np.linalg.det(U)-1)<1e-14;UXU=U@X@U.conj().T
assert np.linalg.norm(UXU.imag)<1e-14
# channel is 1/2 on X in i so(3), 1/10 on UXU in Sym_0(R^3).
cov_defect=np.linalg.norm((1/10)*UXU-(1/2)*(U@X@U.conj().T))/np.linalg.norm(UXU)
assert abs(cov_defect-0.4)<1e-15
print(json.dumps({'proof_scope':'independent geometry enumeration and fixed-source algebra, not physical realization',
 'geometrical_clique_facets':len(cliques),'source_centers_match_geometry_maxdist':float(max(rows[0])),
 'projected_distinct_vertices':len(V),'projected_distinct_facets':len(F),'projected_overlap':len(set(V)&set(F)),
 'sky_degree9_harmonic_mean_errors':harm_means,'ell10_witness':l10_witness,
 'Y4_frame_isometry_maxerr':float(frame_err),'degree5_leakage_maxerr':float(leak_err),
 'chamber_ranks_and_singular_values':rank_and_spec,
 'ell3_ell4_cross_norm':float(np.linalg.norm(R[:,9:16].conj().T@R[:,16:25])),
 'T6_orbit_ratio_maxerr':float(max(abs(F6-9*T/16))),
 'T6_register_first_col_mean':float(np.mean(Tmat[:,0])),
 'T6_register_other_col_mean':float(np.mean(Tmat[:,1:])),
 'T6_source_norm2':Tnorm2,
 'ell6_P0_squared_singular':'89375/65536',
 'ell6_Pa_squared_singular':['1576575/262144','825825/262144 (x4)'],
 'ell6_Pc_squared_singular':'170625/1048576 (x4)',
 'SU3_covariance_counterexample_relative_norm':float(cov_defect)},indent=2))
