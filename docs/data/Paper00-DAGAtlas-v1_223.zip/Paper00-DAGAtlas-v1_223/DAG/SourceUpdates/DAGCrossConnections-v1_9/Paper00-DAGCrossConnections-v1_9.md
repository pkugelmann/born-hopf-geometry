# Born–Hopf Geometry — DAG Cross-Connections: Independent Derivation and Verification v1.9

**Date:** 16 November 2026. **Scope:** independent mathematical verification and strengthening of `Paper00-DAGCrossConnections-v1_8`, without source-paper edits, canonical DAG changes, physical realization claims, or proof-chain audit status promotion.

**Authoritative files:** `Paper00-PapersMinimal-v3_018.zip`, `Paper00-DAGAtlas-v1_151(1).zip`, and `Paper00-ProofChainAudits-v1_65.zip`. The directly relevant `.tex` files I-B, I-C, IV-A, IV-B, VI-B, and VII-B are **byte-identical** between `PapersMinimal-v3_017` and `v3_018`; the current supplied files were reopened and used. The available audit/work protocols are `Paper00-RigorousVerificationDAGWorkProtocol-v2_4` and `Paper00-ProofChainAuditProtocol-v1_1`. Because the user requested verification of a cross-paper research supplement rather than a one-paper audit, the single-paper protocol does not authorize marking this supplement E3/E4-certified.

**Overall verdict:** N01–N06 survive the independent calculations at their **explicit auxiliary mathematical scopes**. Their physical-observable bridges remain unproved. The new result **N07** completely splits the degree-six harmonic readout into `P0`, `Pa`, and `Pc` sectors with exact rational squared response strengths.

## 0. Evidence and scope rules

- **Source theorem used:** always cite the source-labeled theorem and retain its proposed/comparison status. Source-integrated mathematical modules marked `CC12`, `CC13`, `CC17` remain mathematical inputs and are not thereby granted a physical owner.
- **Independent exact character test:** `...-IndependentExactCubature.py` generates 120 root quaternions in `Q(√5)` and checks the `SU(2)` character multiplicities and the unique degree-12 cancellation. This independently challenges the strongest imported cubature premise.
- **Independent geometry test:** `...-IndependentGeometryVerify.py` enumerates the 600 tetrahedral facets *as four-cliques of the H4 vertex graph*, not as the imported double coset, then identifies those centres against the coset block partition and recomputes all sky/rank/template results. It has a separate 10-axis construction directly from the printed source list.
- **Independent nonet test:** `...-IndependentNonetVerify.py` constructs all twenty rank-one `3×3` matrices from the source's signed ten-axis list and recovers the complete Gram and channel spectra.
- **Exact chamber block pair-sum test:** `...-ExactBlockVerify.py`, brought forward from the prior supplement for a second exact arithmetic route, checks the `Q(√5)` block pair sums, 150-node weights, rational template values and degree-ten witness. Its relationship to the v1.8 code is disclosed; it is not counted as a genuinely independent implementation.
- **What is not proved:** a physically occurring 600-chamber Markov clock, a sky transfer/instrument, a hadronic Lindbladian, the identification of comparison `SU(3)` with physical color, or measured decay poles/widths. The supplied audits remain unchanged.

## N00. Imported S³ vertex–facet degree-19 cubature: independent exact precursor verification

**Owner:** I-B `p1b:thm:cc17-facet-double-coset`, `p1b:thm:cc17-positive-vertex-facet-19`; earlier `2I` Molien and Hurwitz twin results.

Let `I=2I`, `H=2T`, `u=(1+i)/√2`, `V=I`, `F=IuI`, and

\[
\nu=\frac5{21}\frac1{120}\sum_{v\in I}\delta_v+\frac{16}{21}\frac1{600}\sum_{f\in F}\delta_f.
\]

**Independent geometric check.** Generate the standard 120 `H4` unit roots, join each pair with dot product `φ/2`, and list every vertex 4-clique. There are exactly 600 such cliques. Their normalized tetrahedral-centroid vectors coincide to numerical precision with the separately enumerated double-coset `IuI` (maximum coordinate-space nearest-centre distance `2.58×10^-16`). This verifies that the double coset and actual 600-cell tetrahedral facet-centres agree, without assuming that identification.

**Independent exact character check.** In the `SU(2)` irrep of index `n` the character is the Chebyshev polynomial `U_n(Re q)`. Average over all 120 `I` elements. Odd `n` vanish by the central `q↦−q` involution. The exact `Q(√5)` arithmetic gives, for even `n≤20`,

\[
 m_I(n)=\frac1{120}\sum_{g\in I}U_n(\Re g)
 =\begin{cases}1,&n=0,12,20,\\0,&n=2,4,6,8,10,14,16,18.\end{cases}
\]

The unique nonconstant fixed line through degree 19 is the index-12 line. On it the source-twist overlap is exactly

\[
 \frac1{120}\sum_{g\in I}U_{12}(\Re(gu))=-\frac5{16}.
\]

Consequently the Fourier transform of `ν` on that line vanishes:

\[
 \frac5{21}+\frac{16}{21}\left(-\frac5{16}\right)=0.
\]

All other nontrivial representations up to `n=19` have no `I`-fixed line, hence their weighted transforms vanish. Peter–Weyl therefore establishes the source's **degree-19 scalar polynomial exactness**, not merely a numerical check on S². At `n=20` the twisted character average is `31/64`, so the character witness is

\[
 \frac5{21}+\frac{16}{21}\frac{31}{64}=\frac{17}{28}\ne0,
\]

confirming sharpness of that particular degree-19 rule. This proof uses exact arithmetic and standard representation theory; no cosmological physical interpretation is inserted.

## N01. Hopf 720→150 degree-nine cubature and its isometric sky frame

**Source:** I-B `p1b:thm:cc17-positive-vertex-facet-19`; `p1b:thm:cc17-facet-double-coset`.

For `π_i(q)=q i q^{-1}`, each component is a homogeneous degree-two real polynomial on the unit quaternions. Therefore `p∈P_9(S²)` pulls back to a polynomial of degree at most 18 on `S³`; Haar measure on `S³` pushes forward under `π_i` to normalized area measure on `S²`. N00 gives

\[
 \int_{S²}p\,d\omega=\frac1{504}\sum_{q\in I}p(\pi_iq)
 +\frac2{1575}\sum_{q\in IuI}p(\pi_iq).
\]

The exact field enumeration shows `|π(I)|=30`, `|π(F)|=150`, every fibre has multiplicity four within its own set, and `π(I)⊂π(F)`. The inclusion can also be understood from `u i u^{-1}=i`: `π(g)=π(gu)` for each `g∈I` and `gu∈IuI`. Thus the 150 distinct nodes carry positive weights

| Class | Node count | Per-node weight |
|---|---:|---:|
| Vertex and facet shared | 30 | `4/504+8/1575=41/3150` |
| Facet-only | 120 | `8/1575` |

The weights sum exactly to one. For the marked zonal polynomial `P_10(n·i)`, the exact finite weighted sum is `104975/1376256 ≠ 0`. Hence the asserted degree-nine *strength* is sharp in the source-marked orientation.

Let `Y_{lm}` be orthonormal for probability-area measure `dω`. For the 150 nodes `z_r` and weights `w_r`, `S_{r,lm}=√w_r Y_{lm}(z_r)` satisfies

\[
 S^\dagger S=I_{25}\quad(0\le\ell\le4),
\]

since the product of any two degree-≤4 harmonics is a polynomial of degree ≤8. The `\ell=5 → \ell≤4` cross-Gram is also exactly zero (degree ≤9). Numerically, an independently generated 720-point frame has maximum identity error `6.67×10^-16` after robust polar-angle evaluation at the poles. *It is an amplitude-sampling frame; this equation does not assert a physical coherent instrument.*

## N02. Chamber block harmonic selection, ranks and degree-three/four orthogonality

**Sources:** I-B `p1:thm:v366-chamber-transporter-complement`, `p1b:cor:cc17-register-lowband-blindness`, `p1b:thm:cc17-facet-double-coset`.

With the 25 ordered 24-element blocks `B_ab`, define

\[
 R_\ell:\mathcal H_\ell(S²)\to\mathbb C^{25},\qquad
 (R_\ell f)_{ab}=\frac1{24}\sum_{q\in B_{ab}}f(\pi_iq).
\]

The same-marked left `2I` action permutes the five row labels as the `A5` representation `1⊕4`, leaving the five right labels untransformed. On input the `A5` decomposition is `H1=3`, `H2=5`, `H3=3'⊕4`, `H4=4⊕5`, `H5=3⊕3'⊕5`, `H6=1⊕3⊕4⊕5`. The input components not isomorphic to `1` or `4` therefore lie in `ker R_l`. The `24`-element five-design additionally forces degrees 1 and 2 to zero, consistent with this selection.

| `ℓ` | Dim input | Rank `R_ℓ` | Reason |
|---:|---:|---:|---|
| 0 | 1 | 1 | constant survives; singular value 5 |
| 1 | 3 | 0 | no `1` or `4`; degree-two S³ pullback |
| 2 | 5 | 0 | no `1` or `4`; degree-four S³ pullback |
| 3 | 7 | 4 | `4` survives, `3'` killed |
| 4 | 9 | 4 | `4` survives, `5` killed |
| 5 | 11 | 0 | no `1` or `4` even though S³ pullback degree ten |
| 6 | 13 | 5 | `1⊕4` survives; `3⊕5` killed |

The row and column marginals of the `ℓ=3,4` outputs vanish by the vertex-orbit eleven-design or, equivalently, by absence of `A5` invariants through degree five; thus `im R3, im R4⊂Pc=Y⊗Y`. Right multiplication by the Hurwitz quaternion `j` permutes the five columns and changes `π_i(qj)=−π_i(q)`. It acts by `−1` on the odd degree-three and by `+1` on the even degree-four images. As these are orthogonal eigenspaces of an orthogonal permutation, `R3†R4=0` exactly.

For `P_l` the Legendre polynomial define the ordered pair count `C_l,j=Σ_{q,r∈B_0j} P_l(π_i(q)·π_i(r))`. The exact field values are

| `ℓ` | `C_l,0` | `C_l,j`, `j=1,..,4` | `||R_l||²_HS` |
|---:|---:|---:|---:|
| 3 | 0 | 135 | `525/16` |
| 4 | 336 | 21 | `525/16` |
| 6 | 72 | `1773/64` | `21125/1024` |

Indeed the addition theorem with probability-normalized harmonics yields

\[
 \|R_\ell\|_{HS}^2=\frac{5(2\ell+1)}{24^2}
  (C_{\ell,0}+4C_{\ell,1}).
\]

For `ℓ=3,4` Schur's lemma makes the four nonzero squared singular values equal; they are exactly `(525/16)/4=525/64`. These pass the independent facet-clique SVD. The cumulative image rank for `ℓ≤4` is `1+4+4=9`, not 25, despite `dim ⊕_{ℓ=0}^4 H_ℓ=25`. No observed sky projection is implied.

## N03. Exact comparison dynamics on the selected harmonic signals

**Source:** I-B `p1b:thm:v16-register-resolvent`, `p1b:thm:cc13-register-memory`, `p1b:cor:cc13-relaxation`.

Define `Z=J5/5`, `Y=I5−Z`, `P0=Z⊗Z`, `Pa=Z⊗Y+Y⊗Z`, `Pc=Y⊗Y`. The exact mathematical compressed return from the 600-state face-walk is

\[
 M(t)=P_0+e^{-5t/4}P_a+f_c(t)P_c,
\]

\[
 f_c(t)=\left(\frac12+\frac{3}{4\sqrt{21}}\right)e^{(-9+\sqrt{21})t/8}
 +\left(\frac12-\frac{3}{4\sqrt{21}}\right)e^{(-9-\sqrt{21})t/8}.
\]

Since N02 proves `R3=Pc R3`, `R4=Pc R4`, we have **without a new parameter**

\[
 M(t)R_3=f_c(t)R_3,\qquad M(t)R_4=f_c(t)R_4.
\]

The coarse resistor/Markov closure instead multiplies these signals by `e^{-15t/16}`. In the centered-hidden two-level block the generator is

\[
 L_c=\begin{pmatrix}-15/16&5\sqrt3/16\\5\sqrt3/16&-21/16\end{pmatrix}.
\]

Consequently the two returns have identical value and derivative at time zero, but their second derivatives differ by the square of the hidden coupling, `75/256`, proving

\[
 f_c(t)-e^{-15t/16}=\frac{75}{512}t^2+O(t^3).
\]

This is an exact **comparison-operator** discrimination. A physical timescale, same-action generator and physical readout owner are absent.

## N04. Paper VI-B `T6`: exact orbit identity, block image, and cancellation

**Sources:** I-B `p1:thm:v285-ten-axis-quadrupole-exact-sequence`, VI-B `p6b:prop:v322-angular-six`, I-B `p1b:thm:cc17-positive-vertex-facet-19`.

The ten source projective axes `u_a` define `T6(n)=1/10 Σ_a P6(n·u_a)`. Their source norm is `||T6||²=11/1053`. Define the Hopf-vertex zonal average `F6(n)=1/120 Σ_{g∈I}P6(n·π_i(g))`. Both are in the unique one-dimensional `A5`-invariant degree-six line. Their exact values at `i` are `T6(i)=11/144`, `F6(i)=11/256`, so

\[
 \boxed{F_6=\frac9{16}T_6.}
\]

Exact arithmetic gives the row-independent block image with `b=0` as the marked coset `H`:

\[
 R(T_6)_{ab}=\begin{cases}11/144,&b=0,\\-451/9216,&b=1,2,3,4.\end{cases}
\]

In a form revealing the projector components,

\[
 \boxed{R(T_6)=-\frac{55}{2304}\mathbf1_{25}+
 \frac{77}{3072}\mathbf1_5\otimes(4,-1,-1,-1,-1).}
\]

The first term belongs to `P0` and the second to `Z⊗Y⊂Pa`; the `Pc` projection is zero. Thus

\[
 M(t)R(T_6)=-\frac{55}{2304}\mathbf1_{25}+
 e^{-5t/4}\frac{77}{3072}\mathbf1_5\otimes(4,-1,-1,-1,-1).
\]

The global facet zonal average is

\[
 G_6(n)=\frac1{600}\sum_{f\in F}P_6(n\cdot\pi_i(f))
 =-\frac{45}{256}T_6(n),
\]

as follows by uniqueness of the invariant degree-six line and the exact value `G6(i)=−55/4096`. Together with `F6=(9/16)T6`, the weighted 720 cubature cancels that harmonic globally:

\[
 \frac5{21}\frac9{16}T_6+\frac{16}{21}\left(-\frac{45}{256}\right)T_6=0.
\]

Its *local* 25-block response is nevertheless nonzero. This distinguishes integrated and resolved mathematical readouts; it does not infer a cosmic transfer function.

## N07 [NEW]. Complete exact degree-six projector-sector split

**Sources:** N02, N04, I-B `p1b:cor:cc13-relaxation`. This is a strengthening introduced by the present check, not previously a distinct v1.8 node.

The `A5` decomposition `H6=1⊕3⊕4⊕5` and the row `1⊕4` selection imply that only the unique invariant line and one four-dimensional line can survive. Their positivity will be certified by the exact response strengths below.

For the invariant input `T6`, use `||T6||²=11/1053`. The `P0` contribution is the square of the common mean in 25 coordinates divided by this norm:

\[
 \left.\|P_0R_6\|_{HS}^2\right|_{\mathbf1}
 =\frac{25(55/2304)^2}{11/1053}
 =\boxed{\frac{89375}{65536}}.
\]

The `Pa` invariant contribution is the squared length of the column contrast divided by the same norm:

\[
 \left.\|P_aR_6\|_{HS}^2\right|_{\mathbf1}
 =\boxed{\frac{1576575}{262144}}.
\]

Their sum gives the invariant squared singular value

\[
 \boxed{s_{\mathbf1}^2=\frac{1934075}{262144}}.
\]

For the four-dimensional input, compare the mean degree-six harmonic coefficient vectors of each 120-point row orbit `a u I` with the overall 600-point facet average. The addition theorem gives the coefficient-vector norm identity

\[
 \sum_{m=-6}^6|\mu(Y_{6m})|^2
 =13^2\left\|\int P_6(n\cdot z)\,d\mu(z)\right\|_{L^2(S²,d\omega)}^2.
\]

The row orbit average is a rotation of `F6=(9/16)T6`; the global average is `G6=−45/256 T6`. Thus

\[
 \| (Y\otimes Z)R_6\|_{HS}^2
 =25\cdot13^2\left[\left(\frac9{16}\right)^2
                      -\left(\frac{45}{256}\right)^2\right]\frac{11}{1053}
 =\frac{825825}{65536}.
\]

`Y⊗Z` selects a rank-four channel and `Z⊗Y` selects the invariant `Pa` channel; by Schur their per-direction squared singular strengths are

\[
 \boxed{s_{P_a,\mathbf4}^2=\frac{825825}{262144}},\qquad
 \boxed{s_{P_a,\mathbf1}^2=\frac{1576575}{262144}}.
\]

The exact `ℓ=6` addition-theorem pair counts from N02 give

\[
 \|R_6\|_{HS}^2=\frac{21125}{1024}.
\]

Subtracting the `P0`, invariant `Pa` and rank-four `Pa` contributions and dividing the remaining `Pc` trace by four gives

\[
 \boxed{s_{P_c,\mathbf4}^2=\frac{170625}{1048576}}>0.
\]

Hence the *full* nonzero singular-value spectrum of `R6†R6` is exactly

\[
 \boxed{\frac{1934075}{262144}\quad(1\text{ time}),\qquad
 \frac{3473925}{1048576}\quad(4\text{ times}).}
\]

The eight remaining input dimensions form the kernel. Both `Pa` and `Pc` receive the nontrivial `A5` four-space, while the invariant source excites `P0⊕Pa` only. In particular, the *generic surviving* degree-six angular input has a **mixed one-rate and two-rate memory return**:

\[
 \boxed{M(t)R_6=P_0R_6+e^{-5t/4}P_aR_6+f_c(t)P_cR_6,}
\]

and each of the three pieces is explicitly nonzero on the appropriate source subspace. The exact rational sector strengths above are independently tested against numerical `P0/Pa/Pc` singular values. This is a new mathematical cross-paper result; it is not a measured sky damping law.

## N05. Nonet `A5` versus `SU(3)` and universal Lüders twirl

**Sources:** I-B `p1:thm:cc12-directed-coherent-gram`, II-C `p2c:thm:cc12-twenty-complex-povm`, IV-B `p4b:thm:cc17-directed-nonet-luders`, VII-B `p11:thm:v159-nonet-jordan-lie-structure`.

Build the 20 signed unit axes `n_ij` from the ten printed source axes and signs, and define the rank-one complex projectors

\[
 H_{ij}=\frac12(I-n_{ij}n_{ij}^{T}+iA(n_{ij})),\quad
 A(n)v=n\times v.
\]

An independent explicit `20×20` Gram computation gives exactly the nonzero spectrum `20/3` once, `10/3` three times, `2/3` five times, with eleven zeros. The projectors sum to `(20/3)I`, so the Lüders channel

\[
 \Phi(X)=\frac3{20}\sum_{i\ne j}H_{ij} X H_{ij}
\]

is CPTP, unital and entanglement breaking, and acts on `Herm3(C)=1⊕3⊕5` by eigenvalues `1`, `1/2`, `1/10`. This reconstructs the source's conditional auxiliary operator without presupposing its spectrum.

**Concrete covariance counterexample.** Choose

\[
 X=i(E_{12}-E_{21})\in i\mathfrak{so}(3),\qquad
 U=e^{-i\pi/6}\operatorname{diag}(i,1,1)\in SU(3).
\]

Then `UXU†=−(E12+E21)` is in the symmetric traceless quintet. Hence

\[
 \Phi(UXU^\dagger)=\tfrac1{10}UXU^\dagger
 \ne U\Phi(X)U^\dagger=\tfrac12 UXU^\dagger.
\]

The normalized covariance defect is exactly `2/5`. Thus **full SU(3) conjugation covariance is impossible for this channel**, even though the comparison space admits the Lie algebra `su(3)` under the distinct source-chosen Jordan/Lie isometry. The source requires only `A5` covariance.

**Universal Haar-twirl theorem.** For *any* rank-one normalized Lüders channel in dimension `d` with `Σ_k w_kP_k=I_d` and `rank P_k=1`, its superoperator trace is

\[
 \operatorname{Tr}_{HS}\Phi=\sum_k w_k(\operatorname{tr}P_k)^2
 =\sum_k w_k=d.
\]

The `SU(d)` twirl of the superoperator has eigenvalue one on the scalar identity and a common `p` on the irreducible traceless adjoint, giving

\[
 1+(d^2-1)p=d\quad\Longrightarrow\quad
 \boxed{p=\frac1{d+1}}.
\]

Therefore its explicit operator is

\[
 \boxed{\overline\Phi(X)=\frac{X+\operatorname{tr}(X)I_d}{d+1}.}
\]

At `d=3` the nonet channel twirls to `(X+tr(X)I_3)/4`, which does *not* retain the distinct `3/5` channel eigenvalues. The depolarizing channel has normalized Choi partial transpose eigenvalue `(1-(d+1)p)/d²` on antisymmetric vectors. At any `p>1/(d+1)` it is NPT and cannot be entanglement breaking; equality is entanglement breaking because the Haar twirl is an average of rank-one measure-and-prepare maps. Thus `1/(d+1)` is the sharp *positive-parameter depolarizing* entanglement-breaking boundary. In dimensions `3,25,36,385`, the factors are respectively `1/4,1/26,1/37,1/386` whenever the corresponding normalized rank-one POVM hypotheses are present. No physical twirling, color gauge ownership or meson bath is identified.

## N06. 385-dimensional scalar evaluation: amplitude information versus POVM probabilities

**Source:** I-C `p1c:thm:cc17-720-shell-projectors`; IV-A `p4a:prop:cc13-angular-povm` for the analogous angular construction.

The scalar `S³` harmonics through degree nine have dimension

\[
 d=\sum_{n=0}^9(n+1)^2=385.
\]

The 720-node source quadrature has exact inner-product strength for products of band harmonics through `n=9`, therefore defines an isometric complex sampling map `S:C^385→C^720`, `S†S=I385`. Coherent samples `y=Sψ` reconstruct the amplitude vector `ψ=S†y`, provided the complex phases are available.

The same isometric frame defines 720 positive rank-one POVM effects `E_z=|s_z⟩⟨s_z|` (weighted evaluation row `s_z`), satisfying `Σ_zE_z=I385`. Their probabilities on general density operators are 720 real numbers constrained to sum to one. The real vector space of traceless Hermitian operators has dimension `d²−1=148224`, whereas the normalized outcome probability deviations have dimension at most `720−1=719`. Hence the probability map's null space has real dimension **at least**

\[
 \boxed{148224-719=147505}.
\]

The POVM cannot be informationally complete on arbitrary mixed states, despite the amplitude-frame isometry. These are mathematically distinct data modalities; the latter does not follow from observed probabilities alone. No 720-outcome physical detector is claimed.

## 8. Explicit non-closures and potential falsification

1. **Sky physical ownership:** no source-defined action-to-25-block observational transfer, observer orientation, visibility window or noise law follows from exact cubature. Degree-six `T6` is a *geometric template*.
2. **Time/process owner:** `M(t)` is the exact comparison walk on 600 chamber centres, not a particle decay generator. The rational rates refer to dimensionless comparison time; no physical clock or particle pole is supplied.
3. **Nonet owner:** an `su(3)` Lie-algebra *comparison* does not imply full physical color `SU(3)` covariance of this auxiliary Lüders channel. The explicit `2/5` obstruction is a test only if such covariance were independently demanded of that same operator.
4. **Independent proof controls:** the 150 fibre multiplicities were verified exactly in the inherited arithmetic route and via independent geometric enumeration with numerical precision; all data in the latter are mathematically derived from source coordinates. A fully formal proof assistant certificate of every pair-count identity, and independent adversarial E4 of all downstream claims, have not been supplied.
5. **No canonical updates:** v1.9 only updates the *research supplement*. The supplied 31 papers, DAG Atlas v1.151, and proof-chain audit archive v1.65 are not altered. Candidate edges remain typed mathematical proposals with physical boundary gates open.

## 9. Evidence inventory

| Test | Independent method | Observed output |
|---|---|---|
| Source I-B 19-cubature | Exact `SU(2)` `U_n` character sums in `Q(√5)` | `m_I(n)=0` except `m_I(12)=1`; twisted overlap `−5/16`; sharp witness `17/28` |
| Facet geometry | 120-vertex dot-product graph, K4 clique census | 600 facet cliques; all centroids match `IuI` |
| Hopf fibre reduction | Independent facet-centre numerical projection | 30 vertex directions, 150 facet directions, 30 overlaps, multiplicities four |
| Sky harmonic rule | `Y_lm` direct weighted sums | Degree 1–9 means ≤`3.1e−16`; 25-column frame error ≤`6.7e−16` |
| Chamber ranks | 25×(2ℓ+1) direct harmonic matrices, ℓ=0..6 | `1,0,0,4,4,0,5` |
| `ℓ=3,4` singular values | Field pair sums plus independent SVD | each four values `√525/8`; cross-Gram ≈`5.61e−15` |
| `T6` match and blocks | Source ten literal axes, independent facet centres | `F6=(9/16)T6`, exact rational 25-block image |
| Full `ℓ=6` sector split | New projector algebra; independent SVD | all four exact squared response strengths reproduced |
| Nonet coherence | 20 rank-one source projectors assembled independently | Gram `20/3`, `10/3×3`, `2/3×5`; channel `1,.5×3,.1×5` |
| Explicit SU3 witness | Constructed `SU(3)` conjugation mixing `3` to `5` | normalized violation `2/5` |
| Quantum sampling bound | Hermitian dimension counting | POVM null dimension ≥147505 |

**Conclusion.** No arithmetic or logical counterexample to N01–N06 was found within their stated auxiliary mathematical scopes; N00 independently verifies the imported cubature source to degree 19, and N07 is a new exact strengthening. This is not evidence that any particle decay or CMB multipole has been physically predicted. The first essential unresolved bridge is an **already-owned physical readout/generator/clock**, not another finite-geometric identity.
