#!/usr/bin/env python3
"""Independent exact character proof check of the *source* S3 19-cubature.
Only arithmetic in Q(sqrt(5)), no imports from v1.8 verification programs.
The n-th SU(2) character is U_n(Re q), and for even n this is
an integer polynomial in (Re q)^2.
"""
import itertools as it
from fractions import Fraction as F
from collections import OrderedDict

# Pairs (a,b) denote a + b sqrt(5), both rational.
def k(a=0,b=0):return F(a),F(b)
def plus(x,y):return x[0]+y[0],x[1]+y[1]
def neg(x):return -x[0],-x[1]
def minus(x,y):return plus(x,neg(y))
def mul(x,y):return x[0]*y[0]+5*x[1]*y[1],x[0]*y[1]+x[1]*y[0]
def sc(x,r):return x[0]*r,x[1]*r

def chr_even(n,t):
 assert n%2==0
 if n==0:return k(1)
 minus1=k(-1);a=k(1);b=plus(sc(t,4),minus1)
 for _ in range(2,n//2+1):
  a,b=b,minus(mul(plus(sc(t,4),k(-2)),b),a)
 return b

pts=[];z=k(0);o=k(1)
for d in range(4):
 for s in (-1,1):
  v=[z]*4;v[d]=k(s);pts.append(tuple(v))
for signs in it.product((-1,1),repeat=4):pts.append(tuple(k(F(s,2)) for s in signs))
for perm in it.permutations(range(4)):
 if sum(perm[i]>perm[j] for i in range(4) for j in range(i+1,4))%2:continue
 for signs in it.product((-1,1),repeat=3):
  v=[z, k(F(signs[0],2)), k(F(signs[1],4),F(signs[1],4)), k(F(-signs[2],4),F(signs[2],4))]
  pts.append(tuple(v[j] for j in perm))
assert len(pts)==len(set(pts))==120

# Re(q u) = (q_0-q_1)/sqrt(2), so its square lies in Q(sqrt(5)).
results={}
for n in range(0,22,2):
 avI=k();avIU=k()
 for q in pts:
  avI=plus(avI,chr_even(n,mul(q[0],q[0])))
  dif=minus(q[0],q[1]);avIU=plus(avIU,chr_even(n,sc(mul(dif,dif),F(1,2))))
 avI=sc(avI,F(1,120));avIU=sc(avIU,F(1,120))
 results[str(n)]={'binary_icosahedral_character_multiplicity':str(avI),
                  'icosahedral_twisted_character_trace':str(avIU)}
 if n in (2,4,6,8,10,14,16,18): assert avI==k(0), (n,avI)
 if n==12: assert avI==k(1) and avIU==k(F(-5,16)),(n,avI,avIU)
 if n==20: assert avI==k(1) and avIU==k(F(31,64)),(n,avI,avIU)
# Odd n vanish by q -> -q, which preserves both I and IuI.
assert plus(sc(k(1),F(5,21)),sc(k(F(-5,16)),F(16,21)))==k(0)
assert plus(sc(k(1),F(5,21)),sc(k(F(31,64)),F(16,21)))==k(F(17,28))
print('EXACT_19_CUBATURE_CHARACTER_CHECK_PASS')
for n,val in results.items():print(n,val)
