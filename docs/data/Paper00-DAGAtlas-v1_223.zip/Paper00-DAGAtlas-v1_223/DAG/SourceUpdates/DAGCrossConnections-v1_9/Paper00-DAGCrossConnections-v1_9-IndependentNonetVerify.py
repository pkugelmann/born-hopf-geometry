#!/usr/bin/env python3
"""Independent reconstruction of source 20 rank-one coherent qutrit effects.
Checks the Gram and 1, 1/2, 1/10 spectrum from literal source axes.
No meson dynamics or color-gauge identification is implied.
"""
import numpy as np
from itertools import combinations
import json
phi=(1+np.sqrt(5))/2
edges=list(combinations(range(1,6),2))
raw=np.array([[1,1,1],[1,1,-1],[1,-1,1],[1,-1,-1],
              [1/phi,-phi,0],[phi,0,-1/phi],[0,1/phi,-phi],
              [0,1/phi,phi],[phi,0,1/phi],[1/phi,phi,0]],dtype=float)/np.sqrt(3)
eps=[-1,1,1,-1,1,-1,1,-1,1,-1]
directed=[]
for (a,b),u,s in zip(edges,raw,eps):
 directed.extend(((a,b,s*u),(b,a,-s*u)))
assert len(directed)==20

def crossmatrix(v):
 x,y,z=v
 return np.array([[0,-z,y],[z,0,-x],[-y,x,0]],float)
Ps=[]
for a,b,n in directed:
 P=(np.eye(3)-np.outer(n,n)+1j*crossmatrix(n))/2
 assert np.linalg.norm(P.conj().T-P)<1e-12 and np.linalg.norm(P@P-P)<1e-12
 assert abs(np.trace(P)-1)<1e-12
 Ps.append(P)
S=sum(Ps)
assert np.linalg.norm(S-(20/3)*np.eye(3))<1e-12
Gram=np.array([[np.trace(x@y).real for y in Ps] for x in Ps])
es=np.linalg.eigvalsh(Gram)[::-1]
assert max(abs(es[:1]-20/3))<1e-12
assert max(abs(es[1:4]-10/3))<1e-12
assert max(abs(es[4:9]-2/3))<1e-12
assert max(abs(es[9:]))<1e-12
# Its physical Hilbert-Schmidt-superoperator spectrum is 3/20 times Gram's nonzero eigenvalues.
chanes=3/20*es[:9]
assert max(abs(chanes-np.r_[1,[.5]*3,[.1]*5]))<1e-12

# Explicit SU(3) covariance obstruction: imaginary antisymmetric -> real symmetric.
X=np.array([[0,1j,0],[-1j,0,0],[0,0,0]])
U=np.exp(-1j*np.pi/6)*np.diag([1j,1,1]);assert abs(np.linalg.det(U)-1)<1e-12

def Phi(x):return sum((3/20)*P@x@P for P in Ps)
B=U@X@U.conj().T
assert np.linalg.norm(Phi(X)-X/2)<1e-12
assert np.linalg.norm(Phi(B)-B/10)<1e-12
delta=np.linalg.norm(Phi(B)-U@Phi(X)@U.conj().T)/np.linalg.norm(B)
assert abs(delta-2/5)<1e-12
print(json.dumps({'source_axes':10,'directed_projections':20,
 'max_povm_norm_error':float(np.linalg.norm(S-(20/3)*np.eye(3))),
 'gram_nonzero_spectrum':list(map(float,es[:9])),
 'luders_channel_nonzero_spectrum':list(map(float,chanes)),
 'explicit_SU3_conjugation_defect':float(delta)},indent=2))
