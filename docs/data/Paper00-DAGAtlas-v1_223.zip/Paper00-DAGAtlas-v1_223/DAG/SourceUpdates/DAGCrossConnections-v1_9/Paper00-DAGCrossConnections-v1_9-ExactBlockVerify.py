#!/usr/bin/env python3
"""Exact algebraic controls for Born--Hopf DAG cross-connections v1.9.
Constructs Q(sqrt(5)) quaternions and Hopf angular orbit sums, with
no physical occurrence or globally validated E3/E4 claim.
Standard library only. Exact rational arithmetic throughout.
"""
from fractions import Fraction as Fr
from collections import Counter
import itertools
from dataclasses import dataclass
@dataclass(frozen=True)
class K:
 a:Fr
 b:Fr
 def __init__(self,a=0,b=0):object.__setattr__(self,'a',Fr(a));object.__setattr__(self,'b',Fr(b))
 def __add__(x,y):
  if not isinstance(y,K):y=K(y)
  return K(x.a+y.a,x.b+y.b)
 __radd__=__add__
 def __neg__(x):return K(-x.a,-x.b)
 def __sub__(x,y):return x+-y if isinstance(y,K) else x+K(-y)
 def __rsub__(x,y):return K(y)-x
 def __mul__(x,y):
  if not isinstance(y,K):y=K(y)
  return K(x.a*y.a+5*x.b*y.b,x.a*y.b+x.b*y.a)
 __rmul__=__mul__
 def __truediv__(x,y):
  if isinstance(y,K):
   norm=y.a*y.a-5*y.b*y.b
   return K((x.a*y.a-5*x.b*y.b)/norm,(x.b*y.a-x.a*y.b)/norm)
  return K(x.a/Fr(y),x.b/Fr(y))
 def __pow__(x,p):
  v=K(1)
  for _ in range(p):v*=x
  return v
 def __repr__(x):return f'{x.a}+{x.b}sqrt5'
zero=K();one=K(1);half=K(Fr(1,2));phih=K(Fr(1,4),Fr(1,4));phiin=K(Fr(-1,4),Fr(1,4))
q=[]
for i in range(4):
 for s in (-1,1):
  v=[zero]*4;v[i]=K(s);q.append(tuple(v))
for signs in itertools.product((-1,1),repeat=4):q.append(tuple(K(Fr(s,2)) for s in signs))
for p in itertools.permutations(range(4)):
 if sum(p[i]>p[j] for i in range(4) for j in range(i+1,4))%2:continue
 for signs in itertools.product((-1,1),repeat=3):
  v=[zero,K(signs[0])*half,K(signs[1])*phih,K(signs[2])*phiin]
  q.append(tuple(v[k] for k in p))
assert len(set(q))==120
H=q[:24]
def qmul(a,b):
 w,x,y,z=a;W,X,Y,Z=b
 return (w*W-x*X-y*Y-z*Z,w*X+x*W+y*Z-z*Y,w*Y-x*Z+y*W+z*X,w*Z+x*Y-y*X+z*W)
ind={v:i for i,v in enumerate(q)}
L=[-1]*120;R=[-1]*120
for i in range(120):
 if L[i]<0:
  lab=max(L)+1
  for h in H:L[ind[qmul(q[i],h)]]=lab
 if R[i]<0:
  lab=max(R)+1
  for h in H:R[ind[qmul(h,q[i])]]=lab
areps=[q[L.index(i)] for i in range(5)]
breps=[q[R.index(i)] for i in range(5)]

def dot(x,y):return sum((a*b for a,b in zip(x,y)),zero)
def cross(x,y):return (x[1]*y[2]-x[2]*y[1],x[2]*y[0]-x[0]*y[2],x[0]*y[1]-x[1]*y[0])
def rotate(q,v):
 w=q[0];r=q[1:]
 d=dot(r,r);r1=dot(r,v);c=cross(r,v)
 return tuple((w*w-d)*v[i]+2*r1*r[i]+2*w*c[i] for i in range(3))
def Ru(v):return (v[0],-v[2],v[1])
e1=(one,zero,zero)
vertices=[rotate(g,e1) for g in q]
def facet_block(a,b):return [rotate(a,rotate(h,Ru(rotate(b,e1)))) for h in H]

def Pl(l,x):
 if l==0:return one
 if l==1:return x
 last=one;cur=x
 for n in range(1,l):cur,last=((2*n+1)*x*cur-n*last)/(n+1),cur
 return cur

def f6(v):return sum((Pl(6,dot(v,x)) for x in vertices),zero)/120
for j in range(5):
 arr=facet_block(areps[0],breps[j]); val=sum((f6(v) for v in arr),zero)/24
 print('exact_f6_block',(0,j),val, 'rational',val.b==0)
 if j==0:assert val==K(Fr(11,256))
 else:assert val==K(Fr(-451,16384))
# exact harmonic pair counts and trace
for j in range(5):
 arr=facet_block(areps[0],breps[j]);hist=Counter(dot(x,y) for x in arr for y in arr)
 for l in [1,2,3,4,5]:
  z=sum((cnt*Pl(l,x) for x,cnt in hist.items()),zero)
  if j==0 and l in [3,4]:print('H_0_for_l',l,z)
  if j==1 and l in [3,4]:print('H_1_for_l',l,z)
  assert z.b==0
print('EXACT_FIELD_PASS')

# New exact checks: Hopf-pushed degree-nine cubature is sharp, first
# ico-degree-six template is the same one-dimensional A5 invariant.
vertices_ell10_mean=sum((Pl(10,dot(e1,v)) for v in vertices),zero)/120
facets_ell10_mean=sum((Pl(10,dot(e1,v)) for a in areps for b in breps
                        for v in facet_block(a,b)),zero)/600
hopf_ell10_alias=K(5)*vertices_ell10_mean/21 + K(16)*facets_ell10_mean/21
assert hopf_ell10_alias == K(Fr(104975,1376256))
assert f6(e1)==K(Fr(11,256))
# source ten-axis T6: 4 axes with x^2=1/3, two with x^2=phi^2/3,
# two with x^2=phi^{-2}/3, two with x^2=0.
phi=K(Fr(1,2),Fr(1,2)); invphi=phi-K(1)
def evenLegendreSix_xsq(t):return (231*t**3-315*t**2+105*t-5)/16
T6_i=(4*evenLegendreSix_xsq(K(Fr(1,3)))+
      2*evenLegendreSix_xsq((phi**2)/3)+
      2*evenLegendreSix_xsq((invphi**2)/3)+
      2*evenLegendreSix_xsq(K()))/10
assert T6_i==K(Fr(11,144))
assert f6(e1)==(K(Fr(9,16))*T6_i)
# Q^*Q nonzero singular values for degrees 3,4 from A5-isotypic
# multiplicity four and the exact total Hilbert--Schmidt traces.
traces={}
for ell in range(7):
 hist0=Counter(dot(x,y) for x in facet_block(areps[0],breps[0])
                            for y in facet_block(areps[0],breps[0]))
 hist1=Counter(dot(x,y) for x in facet_block(areps[0],breps[1])
                            for y in facet_block(areps[0],breps[1]))
 s0=sum((cnt*Pl(ell,z) for z,cnt in hist0.items()),zero)
 s1=sum((cnt*Pl(ell,z) for z,cnt in hist1.items()),zero)
 tr=(2*ell+1)*5*(s0+4*s1)/576
 assert tr.b==0
 traces[ell]=tr.a
assert traces[3]==traces[4]==Fr(525,16)
assert traces[5]==0
assert traces[6]==Fr(21125,1024)
T6_blocks=[K(Fr(16,9))*(sum((f6(v) for v in facet_block(areps[0],breps[j])),zero)/24)
           for j in range(5)]
assert T6_blocks==[K(Fr(11,144))]+[K(Fr(-451,9216))]*4
T6_mean=sum(T6_blocks,K())/5
assert T6_mean==K(Fr(-55,2304))
# Weighted vertex/facet integration cancels the degree-six sky alias.
v_mean=f6(e1)
f_mean=(sum((sum((f6(v) for v in facet_block(areps[0],breps[j])),zero)/24
                for j in range(5)),zero))/5
assert f_mean==K(Fr(-55,4096))
assert K(5)*v_mean/21+K(16)*f_mean/21==K()
# Hopf fibres collapse the 720 S3 nodes to precisely 150 distinct
# sky directions. This count and weights are certified over Q(sqrt(5)),
# not inferred from rounded floating-point coordinates.
from collections import Counter
vsky=Counter(vertices)
fsky=Counter(v for a in areps for b in breps for v in facet_block(a,b))
assert len(vsky)==30 and set(vsky.values())=={4}
assert len(fsky)==150 and set(fsky.values())=={4}
assert set(vsky).issubset(fsky)
skyweights={v:Fr(vsky[v],504)+Fr(2*fsky[v],1575) for v in fsky}
from collections import Counter as Count
skymults=Count(skyweights.values())
assert skymults=={Fr(41,3150):30,Fr(8,1575):120}
assert sum(skyweights.values())==1
print('exact_150_sky_compression',dict((str(k),v) for k,v in skymults.items()))
# SU(d) Haar twirl of any normalized rank-one Lüders channel:
# superoperator trace d -> traceless eigenvalue (d-1)/(d²-1).
from json import dumps
su_twirl={str(d):str(Fr(d-1,d*d-1)) for d in (3,25,36,385)}
assert su_twirl=={'3':'1/4','25':'1/26','36':'1/37','385':'1/386'}
print(dumps({'version':'Paper00-DAGCrossConnections-v1_9',
 'exact_checks_passed':True,
 'T6_Hopf_orbit_ratio':'9/16',
 'T6_block_values':[str(x.a) for x in T6_blocks],
 'T6_block_mean':str(T6_mean.a),
 'sky_degree10_alias':str(hopf_ell10_alias.a),
 'hopf_unique_sky_nodes':150,
 'sky_node_classes':{'shared_vertex_facet':{'count':30,'weight_per_node':'41/3150'},'facet_only':{'count':120,'weight_per_node':'8/1575'}},
 'sky_degree10_witness_direction':'quaternion i axis',
 'chamber_singular_eigenvalue_ell3_ell4':'525/64 (multiplicity 4 each)',
 'chamber_gram_traces_by_degree':{str(k):str(v) for k,v in traces.items()},
 'SUd_twirl_depolarization_factor':su_twirl,
 'scope':'exact auxiliary mathematical identities; physical occurrence and E3/E4 pending'},indent=2))
