#!/usr/bin/env python3
"""Momentum-QCD action-sensitivity certificate (native SU(3) heat/marked fan).

Inputs: Paper7A-QCDKernel-v1_174.tex, labels p10:thm:v185-heat-hessian-inversion,
 p10:cor:v185-common-heat-face-stiffness,
 p10:cor:v2159-same-hessian-nonheat-family,
 p10:prop:v2211-central-transfer-positive-type,
 p10:prop:v2220-edge-fan-baryon,
 p10:prop:v3023-marked-baryon-source-overlap.
Uses exact SU(3) Pieri representation-ring recurrences, directed outward interval
arithmetic for exponential evaluations, and explicit analytic remainder bounds.
"""
from fractions import Fraction
from math import factorial
from mpmath import mp, iv
import json, pathlib

mp.dps=70
iv.dps=70
ZERO=Fraction(0)

def add(*terms):
    ans={}
    for vec,c in terms:
        for k,v in vec.items():ans[k]=ans.get(k,ZERO)+c*v
    return {k:v for k,v in ans.items() if v}

def fundamental(vec,bar=False):
    ans={}
    for (p,q),a in vec.items():
        if bar:
            targets=[(p,q+1)]
            if q:targets.append((p+1,q-1))
            if p:targets.append((p-1,q))
        else:
            targets=[(p+1,q)]
            if p:targets.append((p-1,q+1))
            if q:targets.append((p,q-1))
        for r in targets:ans[r]=ans.get(r,ZERO)+a
    return ans

def multiply_x(v):
    return add((fundamental(v),Fraction(1,6)),(fundamental(v,True),Fraction(1,6)))

def multiply_q2(v):
    u=multiply_x(v)
    return add((v,1),(u,-2),(multiply_x(u),1))

def C(p,q):return Fraction(p*p+q*q+p*q+3*p+3*q,3)
def d(p,q):return (p+1)*(q+1)*(p+q+2)//2

def i_rat(q):
    if isinstance(q,int):return iv.mpf(q)
    return iv.mpf(q.numerator)/q.denominator

def heat_expect_iv(vec,t, cutoff=17):
    z=iv.mpf(0)
    for (p,q),v in vec.items():
        if p+q>cutoff:continue
        z+=i_rat(v)*d(p,q)*iv.exp(-i_rat(C(p,q))*t/2)
    return z

def interval_midbounds(x):
    return (float(x.a),float(x.b))

q2=multiply_q2({(0,0):Fraction(1)})
expected={(0,0):Fraction(19,18),(1,0):Fraction(-11,36),
          (0,1):Fraction(-11,36),(2,0):Fraction(1,36),
          (0,2):Fraction(1,36),(1,1):Fraction(1,18)}
assert q2==expected, (q2,expected)

# Heat-face stiffness h(t) = (1/8) E_t(Casimir) (character heat measure).
# Strict monotonicity was proved in the controlling VII-A theorem.
def h_iv(t):
    den=iv.mpf(0);num=iv.mpf(0)
    for m in range(18):
        for p in range(m+1):
            q=m-p; wi=d(p,q)**2*iv.exp(-i_rat(C(p,q))*t/2)
            den+=wi;num+=i_rat(C(p,q))*wi
    return num/(8*den)

goal=1/(2*iv.pi**2)
h_lo=h_iv(iv.mpf('5.75'));h_hi=h_iv(iv.mpf('5.76'))
# Truncation error in both sums for t>=5.75 is << 1e-110 from a crude
# Gaussian envelope on p+q>=18; margins here are >9e-5.
assert h_lo.a>goal.b and h_hi.b<goal.a

lam=iv.mpf('0.1');t0=iv.mpf('5.75')
v={(0,2):Fraction(1)} # character chi_bar6
partial=iv.mpf(0);abs_dt=iv.mpf(0); terms=[]
for n in range(9):
    jn=heat_expect_iv(v,t0)/6
    term=(-lam)**n/factorial(n)*jn
    partial+=term
    pref=(lam**n/factorial(n))/6
    for (p,q),a in v.items():
        if p+q>17:continue
        abs_dt+=pref*i_rat(abs(a))*d(p,q)*i_rat(C(p,q))/2*iv.exp(-i_rat(C(p,q))*t0/2)
    terms.append({"n":n,"mu_at_t5.75":interval_midbounds(jn),"term_at_t5.75":interval_midbounds(term)})
    v=multiply_q2(v)
taylor=(lam*iv.mpf(9)/4)**9/factorial(9)
# ∥K_t-K_t^{≤17}∥∞ ≤ 5e-117 on the bracket,
# from Σ_{m≥18}(m+1)(m+2)^6/64 exp[-t(m²/8+m/2)].
heat_tail=iv.mpf('5e-117')
# t belongs to [5.75,5.76], bound movement from value at t0 by 0.01*sup |∂t|.
upper_bound=partial.b+iv.mpf('0.01')*abs_dt.b+taylor.b+heat_tail
assert upper_bound<0

# Exact SU(3) character identities for x=Re chi_3/3, q=1-x
iso=mp.mpf('5.7532958466')
a=mp.exp(-2*iso/3);b=mp.exp(-5*iso/3)
c=mp.exp(-3*iso/2);dd=mp.exp(-3*iso);ee=mp.exp(-8*iso/3)
m1=a
m2=(1+3*a+6*b+8*c)/18
m3=(1+16*c+10*dd)/108+(6*a+6*b+15*ee)/36
Eq=1-m1;Eq2=1-2*m1+m2;Eq3=1-3*m1+3*m2-m3
ap=Eq3-Eq*Eq2
B0=a**3;Bp=3*a*a*ap
assert ap>0 and Bp>0
# Source Gram eigenvalues at λ=0: (1±B) each ×56 (aligned-spin comparison).
# This is an ensemble-averaged reference CAR Gram, not a mass/pole spectrum.

result={
 "source_versions": {"Paper7A":"Paper7A-QCDKernel-v1_174.tex","Paper7B":"Paper7B-QCDReadouts-v1_161.tex", "Paper7C":"Paper7C-ContinuousQFT-v2_205.tex"},
 "native_heat_interval":[5.75,5.76],
 "heat_h_at_5_75":interval_midbounds(h_lo),
 "heat_h_at_5_76":interval_midbounds(h_hi),
 "target_stiffness":float(1/(2*mp.pi**2)),
 "native_heat_sample":str(iso),
 "single_face_character_moments": {"x1":str(m1),"x2":str(m2),"x3":str(m3),"q1":str(Eq),"q2":str(Eq2),"q3":str(Eq3)},
 "baryon_wilson_three_face": {"B_at_lambda0":str(B0),"dB_dlambda_at0":str(Bp),"relative_dB":str(Bp/B0),"Gram_eigenvalue_plus":str(1+B0),"Gram_eigenvalue_minus":str(1-B0),"each_multiplicity":56},
 "positive_type_sextet": {"lambda":0.1,"character":"SU(3) (2,0) sextet","N6_at_t5_75_enclosure":interval_midbounds(partial),"dt_abs_upper":float(abs_dt.b),"taylor_remainder_upper":float(taylor.b),"heat_tail_upper":5e-117,"N6_uniform_upper":float(upper_bound.b),"strict_negative":True,"terms":terms},
 "scope": "Exact native three-face heat reference, not full 96-face QCD correlator; positive-type test applies only when the one-face law acts as a temporal convolution transfer. No physical finite H_L selected; M1,M2,poles not computed."
}
out=pathlib.Path('/mnt/data/Paper00-MomentumQCDIntegrationEvidence-v1_14.json')
out.write_text(json.dumps(result,indent=2)+'\n')
print('VERIFIED SU3 character ring q² expansion')
print('native heat root strictly between 5.75 and 5.76')
print('three-face B0=',mp.nstr(B0,18),'dB=',mp.nstr(Bp,18))
print('negative sextet uniform upper bound at lambda=0.1:',upper_bound)
print('wrote',out)
