import numpy as np
N=192
j=np.arange(N)
theta=2*np.pi*j/N
T,P=np.meshgrid(theta,theta,indexing='ij')
z1=np.exp(1j*T);z2=np.exp(1j*P);z3=np.exp(-1j*(T+P))
e1=z1+z2+z3;e2=np.conj(e1)
vand=(abs(z1-z2)**2*abs(z2-z3)**2*abs(z3-z1)**2)/6
m=12;h=[np.ones_like(e1),e1]
for n in range(2,m+1):h.append(e1*h[-1]-e2*h[-2]+h[-3] if n>=3 else e1*h[1]-e2)
def chi(p,q):
 a=p+q;b=q
 return h[a]*h[b]-(h[a+1]*h[b-1] if b>0 else 0)
t=5.7532958466
K=np.zeros_like(e1,complex)
for p in range(6):
 for q in range(6-p):
  D=(p+1)*(q+1)*(p+q+2)/2
  Cas=(p*p+q*q+p*q+3*p+3*q)/3
  K+=D*np.exp(-t*Cas/2)*chi(p,q)
K=K.real
print('integral Haar weight',vand.mean(),'integral heat',np.mean(vand*K),'Kmin,max',K.min(),K.max())
x=np.real(e1)/3; qq=1-x
for lam in [0,0.001,0.01,0.02,0.04,0.05,0.1,0.2,0.5,1.0]:
 w=vand*K*np.exp(-lam*qq**2)
 z=w.mean()
 a=np.mean(w*x)/z
 eig6=np.mean(w*np.real(chi(2,0)))/z/6
 eig8=np.mean(w*np.real(chi(1,1)))/z/8
 print('%7.3f Z=%.10f a=%.11f c6=%.10f c8=%.10f  W=%.11f'% (lam,z,a,eig6,eig8,a**3))
