#!/usr/bin/env python3
"""Born–Hopf mathematical 600-cell/Hurwitz return-mode and Clifford comparison.

Independent exact integer/rational checks and bounded Clifford/Cartan numerical checks.
Never identifies the comparison hopping operator with a physical decay operator.
Requires numpy and sympy; run from any directory.
"""
import itertools, math, json, csv, collections
from pathlib import Path
import numpy as np
import sympy as sp

OUT=Path(__file__).resolve().parent
#!/usr/bin/env python3
"""Independent exact Z[phi] 600->24 Hurwitz two-step identity and sourced Cartan-link bridge.
Mathematical only. Does not declare physical transitions or vertex states.
"""
import numpy as np

# All vector coordinates are (a+b phi)/2, phi^2=phi+1.
z=(0,0);half=(1,0);big=(0,1);small=(-1,1)
vs=[]
for j in range(4):
 for s in [-1,1]:
  v=[z]*4;v[j]=(2*s,0);vs.append(tuple(v))
for ss in itertools.product([-1,1],repeat=4): vs.append(tuple((s,0) for s in ss))
def parity_perm(t):return sum(t[i]>t[j] for i in range(4) for j in range(i+1,4))%2
for perm in itertools.permutations(range(4)):
 if parity_perm(perm): continue
 v0=(z,half,big,small)
 for ss in itertools.product([-1,1],repeat=3):
  v=[v0[t] for t in perm];k=0
  for a in range(4):
   if v[a]!=z:v[a]=(v[a][0]*ss[k],v[a][1]*ss[k]);k+=1
  vs.append(tuple(v))
assert len(vs)==len(set(vs))==120
lookup={v:i for i,v in enumerate(vs)}
def add(x,y):return (x[0]+y[0],x[1]+y[1])
def neg(x):return (-x[0],-x[1])
def mul(x,y):return (x[0]*y[0]+x[1]*y[1],x[0]*y[1]+x[1]*y[0]+x[1]*y[1])
def phi_mul(x):return (x[1],x[0]+x[1])
def dot(x,y):
 a,b=0,0
 for xi,yi in zip(x,y):
  aa,bb=mul(xi,yi);a+=aa;b+=bb
 return a,b

def quatmul(x,y):
 a,b,c,d=x;e,f,g,h=y
 raw=(add(add(add(mul(a,e),neg(mul(b,f))),neg(mul(c,g))),neg(mul(d,h))),
      add(add(add(mul(a,f),mul(b,e)),mul(c,h)),neg(mul(d,g))),
      add(add(add(mul(a,g),neg(mul(b,h))),mul(c,e)),mul(d,f)),
      add(add(add(mul(a,h),mul(b,g)),neg(mul(c,f))),mul(d,e)))
 assert all(p%2==0 and q%2==0 for p,q in raw)
 return tuple((p//2,q//2) for p,q in raw)
A=np.zeros((120,120),dtype=np.int64)
for i,x in enumerate(vs):
 for j,y in enumerate(vs):
  if i!=j and dot(x,y)==(0,2):A[i,j]=1
assert int(A.sum()//2)==720 and np.all(A.sum(axis=1)==12)
H=vs[:24];remain=set(range(120));cosets=[]
while remain:
 i=min(remain);co=sorted(lookup[quatmul(vs[i],h)] for h in H)
 assert len(co)==24 and len(set(co))==24 and set(co)<=remain
 cosets.append(co);remain-=set(co)
assert len(cosets)==5
M=np.zeros_like(A)
I=np.eye(120,dtype=np.int64)
A2=A@A
pair_records=[]
for co in cosets:
 coarr=np.array(co)
 assert np.all(A[np.ix_(co,co)]==0)
 nat=np.array([[int(i!=j and dot(vs[i],vs[j])==(2,0)) for j in co] for i in co],dtype=np.int64)
 assert np.all(nat.sum(axis=1)==8)
 assert np.array_equal(A2[np.ix_(co,co)],12*np.eye(24,dtype=np.int64)+3*nat)
 M[np.ix_(co,co)]=nat
 for i in co:
  for j in co:
   if j<=i or not M[i,j]:continue
   mid=np.flatnonzero((A[i]!=0)&(A[:,j]!=0)).tolist()
   assert len(mid)==3
   # Exact vector identity sum r = phi (q+q') in Z[phi].
   for a in range(4):
    left=(sum(vs[r][a][0] for r in mid),sum(vs[r][a][1] for r in mid))
    assert left==phi_mul(add(vs[i][a],vs[j][a])),(i,j,mid,a,left)
   pair_records.append((i,j,mid))
assert len(pair_records)==480 and np.all(M.sum(axis=1)==8)

# --- Exact five-coset return operators, mode projectors, and resolvent certificates.
print('Exact 600-cell reconstruction:', len(vs),'vertices,',int(A.sum()//2),'edges,',len(cosets),'Hurwitz cosets')
SH=['same', 'positive_half','zero','negative_half','antipode']
DTS=[(4,0),(2,0),(0,0),(-2,0),(-4,0)]
SHELL_EXPECTED={
 0:[12,3,0,0,0],
 1:[60,27,8,0,0],
 2:[420,225,92,18,0],
 3:[3024,1845,952,342,12],
}
EIG_MULT={8:1,4:4,0:9,-2:8,-4:2}
MOMENTS={8:[36,324,2916,26244],4:[24,168,1248,9024],0:[12,44,236,1132],-2:[6,6,6,6],-4:[0,0,0,0]}
MODES={
 8:{'poly':[-9,1],'rational':'36/(x-9)'},
 4:{'poly':[-24,-4,1],'rational':'24(x+3)/(x^2-4x-24)'},
 0:{'poly':[-16,-16,-1,1],'rational':'4x(3x+8)/(x^3-x^2-16x-16)'},
 -2:{'poly':[-1,1],'rational':'6/(x-1)'},
 -4:{'poly':[],'rational':'0'},
}
all_mode_projectors=[]
coset_rows=[]
for im,co in enumerate(cosets):
 co=np.array(co,dtype=int);o=np.array(sorted(set(range(120))-set(co)),dtype=int)
 N=M[np.ix_(co,co)];B=A[np.ix_(co,o)];C=A[np.ix_(o,o)]
 assert np.array_equal(B@B.T,12*np.eye(24,dtype=np.int64)+3*N)
 assert np.array_equal(C.sum(axis=1),9*np.ones(96,dtype=int))
 # A24 is a 5-eigenvalue distance-polynomial algebra in this marked graph.
 assert np.count_nonzero((N-8*np.eye(24,dtype=np.int64))@(N-4*np.eye(24,dtype=np.int64))@N@(N+2*np.eye(24,dtype=np.int64))@(N+4*np.eye(24,dtype=np.int64)))==0
 local_shells=[]
 for term in DTS:
  local_shells.append(np.array([[int(dot(vs[a],vs[b])==term) for b in co] for a in co],dtype=np.int64))
 assert [int(a.sum(axis=1)[0]) for a in local_shells]==[1,8,6,8,1]
 assert np.array_equal(sum(local_shells),np.ones((24,24),dtype=np.int64))
 C2=C@C;C3=C2@C
 CP=[np.eye(96,dtype=np.int64),C,C2,C3]
 return_moments=[]
 for k,Ck in enumerate(CP):
  R=B@Ck@B.T
  assert np.array_equal(R,sum((v*X for v,X in zip(SHELL_EXPECTED[k],local_shells)),start=np.zeros((24,24),dtype=np.int64)))
  return_moments.append(R)
 projectors={}
 SN=sp.Matrix(N.tolist())
 for lam in [8,4,0,-2,-4]:
  e=sp.eye(24)
  for mu in [8,4,0,-2,-4]:
   if mu!=lam:e=e*(SN-mu*sp.eye(24))/(lam-mu)
  den=sp.ilcm(*[int(sp.denom(t)) for t in e])
  F=np.array((den*e).tolist(),dtype=np.int64)
  assert np.array_equal(F@F,den*F)
  assert int(np.trace(F)//den)==EIG_MULT[lam]
  for j,R in enumerate(return_moments):
   assert np.array_equal(F@R,MOMENTS[lam][j]*F)
   assert np.array_equal(R@F,MOMENTS[lam][j]*F)
  P=MODES[lam]['poly']
  if P:
   poly=np.zeros((96,96),dtype=np.int64)
   for k,c in enumerate(P):poly+=int(c)*CP[k]
   assert np.count_nonzero(poly@B.T@F)==0,(im,lam)
  else: assert np.count_nonzero(B.T@F)==0
  projectors[lam]=(F,den)
 # Central inversion parity. Dark rank two is EVEN, not spinorial parity-odd.
 J=np.zeros((24,24),dtype=np.int64)
 for k,q in enumerate(co):
  j=list(co).index(lookup[tuple(neg(x) for x in vs[q])]);J[k,j]=1
 assert np.array_equal(J@N,N@J)
 for lam,(F,den) in projectors.items():
  trJ=int(np.trace(J@F))//den
  assert trJ == (EIG_MULT[lam] if lam in [8,0,-4] else -EIG_MULT[lam])
 assert sum(int(np.trace(F))//d for F,d in projectors.values())==24
 coset_rows.append({'coset':im,'shell_counts':[1,8,6,8,1],'return_moments':SHELL_EXPECTED, 'native_eigen_multiplicities':EIG_MULT,'complement_degree':9,'rank_B':22,'central_even_dark_dim':2})
 if im==0:
  first={'co':co,'o':o,'N':N,'B':B,'C':C,'projectors':projectors}
 print('Verified exact matrix returns and mode recurrences: coset',im)

# Independent check of complete return spectral formulas at two resolvent points.
co=first['co'];o=first['o'];B=first['B'];C=first['C']
for xx in [20.,31.]:
 K=B@np.linalg.solve(xx*np.eye(96)-C,B.T)
 rational={
 8:36/(xx-9),
 4:24*(xx+3)/(xx**2-4*xx-24),
 0:4*xx*(3*xx+8)/(xx**3-xx**2-16*xx-16),
 -2:6/(xx-1), -4:0.,
 }
 KR=np.zeros((24,24),float)
 for lam,(F,d) in first['projectors'].items():KR+=rational[lam]*(F/d)
 assert np.max(np.abs(K-KR))<2e-12
# Coherent quotient closure: P-uniform and Q-uniform span an exact 2x2 space.
u=np.ones(24)/math.sqrt(24);v=np.ones(96)/math.sqrt(96)
assert np.max(np.abs(B@v-6*u))<1e-12
assert np.max(np.abs(B.T@u-6*v))<1e-12
assert np.max(np.abs(C@v-9*v))<1e-12

# --- Independent right-Q8 orbit quotient, linked (unmarked) to S3Network v1_20.
Q8=vs[:8]
remain=set(range(120));axes=[]
while remain:
 i=min(remain);cells=sorted(lookup[quatmul(vs[i],h)] for h in Q8)
 assert len(set(cells))==8 and set(cells)<=remain
 axes.append(cells);remain-=set(cells)
assert len(axes)==15
qaxis=np.zeros((15,15),dtype=np.int64)
coset_of={int(q):m for m,co in enumerate(cosets) for q in co}
groups=[coset_of[ax[0]] for ax in axes]
for i,ax in enumerate(axes):
 for j,bx in enumerate(axes):
  v=A[np.ix_(ax,bx)].sum(axis=1)
  assert len(set(v))==1
  qaxis[i,j]=int(v[0])
  assert qaxis[i,j]==int(groups[i]!=groups[j])
assert collections.Counter(groups)==collections.Counter({0:3,1:3,2:3,3:3,4:3})
assert np.count_nonzero((qaxis-12*np.eye(15,dtype=np.int64))@(qaxis+3*np.eye(15,dtype=np.int64))@qaxis)==0
assert np.trace(qaxis)==0 and np.trace(qaxis@qaxis)==180
# 12,-3,0 multiplicities 1,4,10 from 15, trace0, trace of square180.
# Character cancellation uses three Q8 quotient classes inside each marked H.
for co in cosets:
 co=set(co)
 Qparts=[set(ax) for ax in axes if set(ax)<=co]
 assert len(Qparts)==3
 for r in sorted(set(range(120))-co):
  counts=tuple(sum(int(A[q,r]) for q in p) for p in Qparts)
  assert counts==(1,1,1)
print('Verified 15-axis K33333 quotient and 5x3 exact Q8-character cancellations')

# --- Exact Gaussian-integer Cartan middle-layer Gram spectrum on H=2T.
# At s=1/2: B_2 B_2^* = 12 I48 + beta T, beta=3/2+sqrt(5)/10,
# T = A_H\otimes I2 + diag(rho(q))(A_H\otimes I2)diag(rho(q))^*,
# and G=2T is an integer Gaussian matrix.
hidx=list(range(24));assert hidx==list(cosets[0])
N=first['N']
TR=np.zeros((48,48),dtype=np.int64);TI=np.zeros((48,48),dtype=np.int64)
for k,q in enumerate(hidx):
 for l,r in enumerate(hidx):
  if not N[k,l]:continue
  rbar=(vs[r][0],)+tuple(neg(x) for x in vs[r][1:])
  rel=quatmul(vs[q],rbar)
  assert all(b==0 for a,b in rel)
  a,b,c,d=[x[0] for x in rel]
  # 2 rho(q)rho(r)^* has exact Gaussian-integer entries.
  real=np.array([[a,-c],[c,a]],dtype=np.int64)
  imag=np.array([[-d,-b],[-b,d]],dtype=np.int64)
  TR[2*k:2*k+2,2*l:2*l+2]=2*np.eye(2,dtype=np.int64)+real
  TI[2*k:2*k+2,2*l:2*l+2]=imag
assert np.array_equal(TR,TR.T) and np.array_equal(TI,-TI.T)
Id=np.eye(48,dtype=np.int64)
def cmul(U,V):
 a,b=U;c,d=V
 return(a@c-b@d,a@d+b@c)
T=(TR,TI);pol=(Id,np.zeros_like(Id))
for root in [-12,-4,8,24]:pol=cmul(pol,(TR-root*Id,TI))
assert np.count_nonzero(pol[0])==np.count_nonzero(pol[1])==0
traces=[];Tk=(Id,np.zeros_like(Id))
for k in range(4):
 traces.append(int(np.trace(Tk[0])));assert int(np.trace(Tk[1]))==0
 Tk=cmul(Tk,T)
assert traces==[48,0,4608,46080]
Vand=sp.Matrix([[v**k for v in [-12,-4,8,24]] for k in range(4)])
mult=list(Vand.inv()*sp.Matrix(traces))
assert mult==[8,24,12,4]
print('Verified exact middle Cartan 48x48 Gram eigenvalues and multiplicities')

# --- Bounded direct SU2 reconstructions for all five cosets at 0,1/2,1.
phi=(1+math.sqrt(5))/2
V=np.array([[(a+b*phi)/2 for a,b in v] for v in vs])
paulis=[np.array([[0,1],[1,0]],complex),np.array([[0,-1j],[1j,0]],complex),np.diag([1.,-1.]).astype(complex)]
Eye2=np.eye(2, dtype=complex)
def rho(q):return q[0]*Eye2-1j*sum(q[k+1]*paulis[k] for k in range(3))
Gs=[rho(q) for q in V]
angle600=math.pi/5;angle24=math.pi/3
kappa=math.sqrt(3)/2+math.sqrt(15)/30
beta=(15+math.sqrt(5))/10
assert abs(beta-math.sqrt(3)*kappa)<1e-14

def link(i,j,s,theta):
 R=Gs[i]@Gs[j].conj().T
 return math.cos(s*theta)*Eye2+math.sin(s*theta)/math.sin(theta)*(R-math.cos(theta)*Eye2)
for idx,co in enumerate(cosets):
 co=np.array(co);out=np.array(sorted(set(range(120))-set(co)))
 for s in ([0.,.5,1.] if idx==0 else [.5]):
  bs=np.zeros((48,192),complex)
  for iq,q in enumerate(co):
   for jr,r in enumerate(out):
    if A[q,r]:bs[2*iq:2*iq+2,2*jr:2*jr+2]=link(q,r,s,angle600)
  G=bs@bs.conj().T
  assert abs(float(np.trace(G).real)-576.)<1e-9
  eig=np.linalg.eigvalsh(G)
  if s==.5:
   expected=[]
   for v,m in [(3-3/math.sqrt(5),8),(9-1/math.sqrt(5),24),(18+2/math.sqrt(5),12),(30+6/math.sqrt(5),4)]:expected.extend([v]*m)
   assert np.max(np.abs(eig-np.sort(expected)))<2e-12
   if idx==0:assert np.max(np.abs(G-(12*np.eye(48)+beta*(TR+1j*TI)/2)))<3e-12
  else:
   expected=[]
   for v,m in [(0,4),(6,16),(12,18),(24,8),(36,2)]:expected.extend([v]*m)
   assert np.max(np.abs(eig-np.sort(expected)))<2e-12
print('Verified native-profile Cartan comparison dark dimensions: 6 -> 2 -> 6 for full SU3 chart')

# --- Exact-basis Clifford grade obstruction and curvature insertion control.
G4=[np.kron(paulis[0],paulis[k]) for k in range(3)]+[np.kron(paulis[1],np.eye(2))]
G5=G4[0]@G4[1]@G4[2]@G4[3]
assert np.max(np.abs(G5@G5-np.eye(4)))<1e-12
E4=np.eye(4,dtype=complex)
def nvec(a,b,theta):
 r=Gs[a]@Gs[b].conj().T
 return np.array([(.5j*np.trace(r@paulis[k])).real/math.sin(theta) for k in range(3)])
def gamman(n):return sum(n[k]*G4[k] for k in range(3))
def S(n):return G5@(gamman(n)-E4)
def K(n):return n[2]*(G4[0]@G4[1])+n[0]*(G4[1]@G4[2])+n[1]*(G4[2]@G4[0])
mu=1/math.sqrt(5)
bcoef=phi*math.sqrt(3)/(3*math.sin(math.pi/5))
ccoef=math.sqrt(3)/3-math.sqrt(15)/15
alpha=1+mu;optim=-(alpha+bcoef)/2
residual2=2*(alpha-bcoef)**2+4*ccoef**2
# Exactly all 480 native links: pair_records computed by original geometry above.
for i,j,mid in pair_records:
 n=nvec(i,j,angle24)
 ns1=[nvec(i,r,angle600) for r in mid]
 ns2=[nvec(r,j,angle600) for r in mid]
 assert max(abs(np.dot(v,w)-mu) for v,w in zip(ns1,ns2))<2e-12
 assert np.linalg.norm(sum((v+w for v,w in zip(ns1,ns2)),start=np.zeros(3))/3-bcoef*n)<2e-12
 assert np.linalg.norm(sum((np.cross(v,w) for v,w in zip(ns1,ns2)),start=np.zeros(3))/3-ccoef*n)<2e-12
 T0=sum((S(v)@S(w) for v,w in zip(ns1,ns2)),start=np.zeros((4,4),complex))/3
 T5=sum((S(v)@G5@S(w) for v,w in zip(ns1,ns2)),start=np.zeros((4,4),complex))/3
 assert np.linalg.norm(T0-((1-mu)*E4-ccoef*K(n)))<2e-12
 assert np.linalg.norm(T5-G5@(alpha*E4-bcoef*gamman(n)+ccoef*K(n)))<2e-12
 assert abs(np.vdot(S(n),T0))<2e-12
 assert abs(np.vdot(S(n),T5)/np.vdot(S(n),S(n))-optim)<2e-12
 assert abs(np.linalg.norm(T5-optim*S(n))**2-residual2)<3e-12
print('Verified Clifford grade obstruction and nonzero Gamma5-on-site residue on 480 links')

# --- Source-owned native 864x864 clock kernel: exact C3 character leakage.
# Full Hurwitz spatial stencil and closing clock transporter are sourced in
# Paper VII-A/VII-D. This is *not* a 600-cell physical Hamiltonian or decay.
FwdSpin=.5*G5@(G4[3]-E4)
assert abs(np.linalg.norm(FwdSpin,'fro')**2-2)<1e-12
Echar=first['projectors'][-4][0]/first['projectors'][-4][1]
assert np.max(np.abs(Echar@Echar-Echar))<1e-12
assert abs(np.trace(Echar)-2)<1e-12
PS=np.kron(Echar,np.eye(12))
Proj=np.kron(np.eye(3),PS)
Hfull=np.zeros((864,864),complex)
Eye3=np.eye(3,dtype=complex)
def block(t,q):return slice(((t*24+q)*12),((t*24+q+1)*12))
for t,s in enumerate([0.,.5,1.]):
 for qi,q in enumerate(hidx):
  Hfull[block(t,qi),block(t,qi)]+=np.kron(3*G5,Eye3)
  for rj,r in enumerate(hidx):
   if not N[qi,rj]:continue
   nativespin=.375*S(nvec(q,r,angle24))
   U=np.eye(3,dtype=complex);U[:2,:2]=link(q,r,s,angle24)
   Hfull[block(t,qi),block(t,rj)]+=np.kron(nativespin,U)
  temporal=np.eye(3,dtype=complex)
  if t==2:temporal[:2,:2]=Gs[q]
  fwd=np.kron(FwdSpin,temporal)
  Hfull[block(t,qi),block((t+1)%3,qi)]+=fwd
  Hfull[block((t+1)%3,qi),block(t,qi)]+=fwd.conj().T
assert np.linalg.norm(Hfull-Hfull.conj().T,'fro')<1e-10
source_spatial_leak=[]
for t in range(3):
 h=Hfull[t*288:(t+1)*288,t*288:(t+1)*288]
 source_spatial_leak.append(float(np.linalg.norm(h@PS-PS@h@PS,'fro')**2))
assert max(source_spatial_leak)<1e-20
source_clock_leak=[]
for t in range(3):
 h=Hfull[t*288:(t+1)*288,((t+1)%3)*288:(((t+1)%3)+1)*288]
 source_clock_leak.append(float(np.linalg.norm(h@PS-PS@h@PS,'fro')**2))
assert max(abs(source_clock_leak[0]),abs(source_clock_leak[1]),abs(source_clock_leak[2]-8))<1e-9
native_leak2=float(np.linalg.norm(Hfull@Proj-Proj@Hfull@Proj,'fro')**2)
native_comm2=float(np.linalg.norm(Hfull@Proj-Proj@Hfull,'fro')**2)
assert abs(native_leak2-16)<1e-8 and abs(native_comm2-32)<1e-8
# Untwisted central-sign benchmark from the v1_3 native kernel for source fidelity.
neg_index=[]
for i,q in enumerate(hidx):
 minus=tuple(neg(x) for x in vs[q]);neg_index.append(hidx.index(lookup[minus]))
pindex=np.concatenate([np.arange((t*24+neg_index[q])*12,(t*24+neg_index[q]+1)*12) for t in range(3) for q in range(24)])
assert abs(np.linalg.norm(Hfull[np.ix_(pindex,pindex)]-Hfull,'fro')**2-768)<1e-8
# Exact Q8 character obstruction to P_char diag_q rho(q) P_char:
# each right-Q8 coset within H contains +/- pairs, hence sum_q rho(q)=0.
q8parts=[set(ax) for ax in axes if set(ax)<=set(hidx)]
assert len(q8parts)==3
for ax in q8parts:
 for j in range(4):
  assert tuple(map(int,np.sum([[vs[q][j][0],vs[q][j][1]] for q in ax],axis=0)))==(0,0)
D_rho=np.zeros((48,48),complex)
for i,q in enumerate(hidx):D_rho[2*i:2*i+2,2*i:2*i+2]=Gs[q]
Pdouble=np.kron(Echar,np.eye(2))
assert np.linalg.norm(Pdouble@D_rho@Pdouble,'fro')<1e-12
assert abs(np.linalg.norm((np.eye(48)-Pdouble)@D_rho@Pdouble,'fro')**2-4)<1e-10
print('Verified native 864x864 regulator: spatial C3 conservation, closing-clutch leakage^2=16, commutator^2=32')

# --- Native three-slice nonunitary half-profile path average.
assert kappa<1 and kappa>0
singular=[kappa,kappa,1]
assert abs(kappa*kappa-(23+3*math.sqrt(5))/30)<1e-14
# A common scalar multiplier cannot make both kappa and 1 into singular value 1.

result={
 'artifact':'Paper00-GeometricTransitionCompiler-v1_4',
 'source_freeze':'Paper00-PapersMinimal-v3_025(1).zip; Paper00-S3StructureNetwork-v1_20(1).zip; Paper00-GeometricTransitionCompiler-v1_3',
 'mathematical_scope':'exact finite graph and Clifford comparison; 600-edge gauge links are comparison extensions, not native physical QCD',
 'graph':{'600_vertices':120,'edges':720,'cosets':5,'Q8_axis_orbits':15,'Q8_quotient':'K_{3,3,3,3,3}','Q8_quotient_eigen_multiplicities':{'12':1,'-3':4,'0':10}},
 'return_shells':{str(k):dict(zip(SH,v)) for k,v in SHELL_EXPECTED.items()},
 'native_24_eigen_multiplicities':{str(k):v for k,v in EIG_MULT.items()},
 'mode_coupling_squared':{str(k):12+3*k for k in EIG_MULT},
 'mode_resolvent_functions_F_lambda(x)':{str(k):MODES[k]['rational'] for k in MODES},
 'dark_modes':{'per_coset':2,'all_5_cosets':10,'central_sign_even':True,'Q8_quotient_nontrivial_characters':True},
 'source_uniform_coset_two_level_A_matrix':[[0,6],[6,9]],
 'Cartan_middle_Gaussian_integer_2T_eigenvalues':[-12,-4,8,24],
 'Cartan_middle_Gaussian_integer_2T_multiplicities':list(map(int,mult)),
 'Cartan_middle_Gram_doublet_eigenvalues':['3-3/sqrt(5)','9-1/sqrt(5)','18+2/sqrt(5)','30+6/sqrt(5)'],
 'Cartan_full_SU3_comparison_dark_dimensions_0_half_1':[6,2,6],
 'Cartan_trace_invariant_total_SU3_gram':864,
 'Cartan_kappa':kappa,
 'Cartan_kappa_squared_exact':'(23+3*sqrt(5))/30',
 'Clifford_mu_exact':'1/sqrt(5)',
 'Clifford_b_exact':'phi*sqrt(3)/(3*sin(pi/5))',
 'Clifford_c_exact':'(5*sqrt(3)-sqrt(15))/15',
 'Clifford_onsite_chirality_best_native_coefficient':optim,
 'Clifford_onsite_chirality_min_HS_residual_squared':residual2,
 'native_864_source_character_projector_rank':int(round(float(np.trace(Proj)))),
 'native_864_spatial_character_leakage_squared':source_spatial_leak,
 'native_864_directed_temporal_character_leakage_squared':source_clock_leak,
 'native_864_total_character_leakage_squared':native_leak2,
 'native_864_character_commutator_HS_squared':native_comm2,
 'native_864_untwisted_sign_symmetry_defect_squared':768,
 'source_status':'NO physical 600-cell Hamiltonian, parent/daughter Fock state map, hadron width or material DAG-edge promotion',
}
(OUT/'Paper00-600HurwitzReturnChecks-v1_4.json').write_text(json.dumps(result,indent=2)+'\n')
with (OUT/'Paper00-600HurwitzReturnShells-v1_4.csv').open('w',newline='') as f:
 wr=csv.writer(f);wr.writerow(['return_length','same','inner_dot_plus_half','inner_dot_zero','inner_dot_minus_half','antipode'])
 for k,v in SHELL_EXPECTED.items():wr.writerow([k+2,*v])
with (OUT/'Paper00-600HurwitzModeResponses-v1_4.csv').open('w',newline='') as f:
 wr=csv.writer(f);wr.writerow(['native_adjacency_eigenvalue','dimension','cross_coset_HS_strength_squared','rational_F_lambda_x','central_sign'])
 for k,m in EIG_MULT.items():wr.writerow([k,m,12+3*k,MODES[k]['rational'],'even' if k in [8,0,-4] else 'odd'])
np.savez_compressed(
 OUT/'Paper00-600HurwitzReturnMatrices-v1_4.npz',
 adjacency_600=A.astype(np.int8),
 hurwitz_adjacency_all_five=M.astype(np.int8),
 five_cosets=np.asarray(cosets,dtype=np.int16),
 q8_axes=np.asarray(axes,dtype=np.int16),
 q8_axis_quotient=qaxis.astype(np.int8),
 middle_cartan_T2_real=TR.astype(np.int16),
 middle_cartan_T2_imag=TI.astype(np.int16),
)
print('PASS: exact integer geometry, Q8 quotient, spectral resolvents, Gaussian-integer Cartan gram, Clifford obstruction, source-native clock leakage')
