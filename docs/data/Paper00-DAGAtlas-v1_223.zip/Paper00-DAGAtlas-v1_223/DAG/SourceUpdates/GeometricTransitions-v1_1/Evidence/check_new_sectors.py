"""Independent finite-sector checks of the v3_027 IV-B corollary; mathematical, not physical."""
import sympy as s
H=s.Matrix([[0,1,0],[1,0,1],[0,1,0]])
assert H[0,2]==0 and (H**2)[0,2]==1
nstar=next(n for n in range(1,3) if (H**n)[0,2]!=0)
assert nstar==2
amp=s.exp(-s.I*s.Symbol('t')*H)
p=s.simplify(amp[0,2]*s.conjugate(amp[0,2]))
t=s.Symbol('t',real=True)
assert s.simplify(p.subs({'t':t}).series(t,0,6).removeO()-t**4/4)==0
H2=s.diag(1,2,3);assert all((H2**k)[0,2]==0 for k in range(3))
print('PASS: three-site indirect n*=2, leading probability t^4/4, all-time separated diagonal control')
