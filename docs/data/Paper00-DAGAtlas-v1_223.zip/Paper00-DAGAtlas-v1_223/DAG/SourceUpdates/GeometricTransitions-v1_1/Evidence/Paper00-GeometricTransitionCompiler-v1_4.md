# Born–Hopf Geometry — Coherent Hurwitz return modes, Cartan lifting, and Clifford obstruction

**Research artifact:** `Paper00-GeometricTransitionCompiler-v1_4.md`  
**Supplied mathematical source freeze:** `Paper00-PapersMinimal-v3_025(1).zip` (Paper I-B `Paper1B-ExceptionalGeometry-v1_14.tex`, Paper VII-A `Paper7A-QCDKernel-v1_175.tex`, Paper VII-D `Paper7D-TechnicalMaterial-v1_55.tex`, Paper IV-B `Paper4B-QuantumResponse-v1_52.tex`, Paper V-C `Paper5C-InteractionResponse-v2_178.tex`), `Paper00-S3StructureNetwork-v1_20(1).zip`, and prior comparison `Paper00-GeometricTransitionCompiler-v1_3`.  
**DAG reference:** `Paper00-DAGAtlas-v1_166(1).zip` (no modification).  
**Verdict:** exact finite **geometric/matrix** theorems and negative controls. Nothing below identifies a 600-cell hopping Hamiltonian, a physical hadron state, a Fock transition, a gauge-invariant particle decay, or a decay width.

## 1. Scope and the source-defined observable

Paper I-B's five-coset theorem `p1b:thm:v3023-five-coset-adjacency` establishes the 120-vertex 600-cell nearest graph and disjoint five left Hurwitz `2T` cosets. Paper VII-A's `p10:thm:v199-exact-cartan-links` supplies **native links on 24-cell edges**, and `p10:thm:v199-native-unit-component` a three-layer 864-dimensional clutched Hermitian regulator. Paper IV-B `p4:thm:finite-resonance-reduction` supplies a finite Schur identity without an irreversible width; Paper V-C `p5c:def:v365-decay-source-contract` requires complete parent-to-daughter-multiset Fock channels before claiming physical decays. These source boundaries are preserved.

The v1_3 comparison derived the exact two-step 600→24 return, the three-slice Cartan *polar* bridge, the native Clifford tangent reconstruction, and non-inheritance of the untwisted central-sign selection rule by the native 864×864 clock kernel.

The present follow-on asks what those connections imply **when one retains all 96 intermediate vertices and their 600-cell edges**, and whether Clifford edge-word composition actually yields the native spin/Wilson word. We also connect the resulting exact cancellation subspace to the pre-existing marked 15-axis Q8 quotient in `S3StructureNetwork-v1_20`.

## 2. First theorem: complete non-flat intermediate returns

Fix one left Hurwitz coset `C` of 24 vertices and let `P` select it, `Q=I-P` its 96-vertex complement. For `A=A_600`, write

\[
A=\begin{pmatrix}0&B\\B^\dagger&C_Q\end{pmatrix},\quad B\in\{0,1\}^{24\times96},\quad C_Q\in\{0,1\}^{96\times96}.
\]

Use `N=A_24` for the 24-cell native nearest adjacency, and denote the further 24-cell shell matrices `Z`, `D`, `J`: `Z_{qr}=1` when `Re(q^{-1}r)=0`, `D_{qr}=1` when `Re(q^{-1}r)=-1/2`, and `J_{qr}=1` at antipodes (`-1`). Their row sums are respectively `6,8,1`; `N` has row sum `8`.

**Exact integer return identities, valid in all five cosets:**

\[
\begin{aligned}
BB^\dagger &=12I+3N,\\
BC_QB^\dagger&=60I+27N+8Z,\\
BC_Q^2B^\dagger&=420I+225N+92Z+18D,\\
BC_Q^3B^\dagger&=3024I+1845N+952Z+342D+12J.
\end{aligned}
\tag{R1}
\]

The verifier reconstructs all vertices as exact half-integer `Z[φ]` quaternionic coordinates and checks every coefficient in all five 24×24 matrices. The complement graph is **9-regular**, hence `||C_Q||=9`. For the conditional scalar-hopping comparison `H=gA` (or a complementary uniform shift `Δ`), the energy-dependent Schur self-energy is

\[
\boxed{\Sigma(z)=g^2 B[(z-\Delta)I-gC_Q]^{-1}B^\dagger.}\tag{R2}
\]

Let `x=z-Δ`. Its absolutely convergent series for `|x|>9|g|` begins

\[
\Sigma(z)=\frac{g^2}{x}(12I+3N)+\frac{g^3}{x^2}(60I+27N+8Z)
+\frac{g^4}{x^3}(420I+225N+92Z+18D)+\cdots .
\tag{R3}
\]

At fourth order the `D` shell enters, and at fifth order the antipodal `J` shell. For `g>0` and real `x>12g`, all entries in the return expansion are nonnegative, and every shell has positive return amplitude by the displayed orders. Hence **the full scalar-hopping Schur reduction is not the native nearest-only 24-cell stencil**, even though the *first* nontrivial return reconstructs it exactly. This is a no-go for the *unmodified scalar comparison*, not a refutation of the actual native QCD action.

## 3. Second theorem: five exact mode-resolved return functions

The native Hurwitz adjacency has spectrum

\[
\operatorname{spec}(N)=\{8^{(1)},4^{(4)},0^{(9)},(-2)^{(8)},(-4)^{(2)}\}.
\]

Let `E_λ` be its exact rational spectral projectors. Then every return moment in (R1), and indeed the complete resolvent, acts by a **scalar** on each `E_λ` subspace. Define

\[
B(xI-C_Q)^{-1}B^\dagger=\sum_\lambda F_\lambda(x)E_\lambda.
\tag{R4}
\]

The five exact rational functions are:

| `λ` | rank | `||B†ψ_λ||²` for normalized `ψ_λ` | `F_λ(x)` |
|---:|---:|---:|---|
| 8 | 1 | 36 | `36/(x−9)` |
| 4 | 4 | 24 | `24(x+3)/(x²−4x−24)` |
| 0 | 9 | 12 | `4x(3x+8)/(x³−x²−16x−16)` |
| −2 | 8 | 6 | `6/(x−1)` |
| −4 | 2 | **0** | **0** |

For a physical dimensional coupling `g` in this *comparison*, `Σ_λ(z)=g F_λ((z−Δ)/g)` when `g≠0`. The formulas are rational identities on their resolvent domains; the `−4` result is identically zero.

**All-orders certificate, not a finite-series guess:** for each `λ`, the exact integer/rational verifier checks `(p_λ(C_Q))B†E_λ=0`, with

\[
\begin{array}{c|l}
\lambda &p_\lambda(t)\\\hline
8&t-9\\
4&t^2-4t-24\\
0&t^3-t^2-16t-16\\
-2&t-1\\
-4&B^\dagger E_{-4}=0\quad\text{instead}
\end{array}
\]

Together with exact first `deg p_λ` moments and `E_λ` invariance, these recurrences establish (R4) at **all orders**. An independent dense resolvent check at `x=20,31` confirms the identities numerically but is not the proof.

The uniform coset vector `u=1_24/√24` couples to the uniform complement vector `v=1_96/√96` with `Bu_Q=6u` (`Bv=6u`, `B†u=6v`, `C_Qv=9v`). Thus the coherent uniform sector is an **exact** 2×2 reduction

\[
A|_{\operatorname{span}(u,v)}=\begin{pmatrix}0&6\\6&9\end{pmatrix},
\qquad\operatorname{spec}=\{12,-3\},
\]

with the exact uniform-mode self-energy `36g²/(z−9g)` at `Δ=0`. The flat-intermediate-energy analogy is exact **only on this selected coherent subspace**, not on arbitrary vertex preparations.

## 4. Third theorem: ten strictly compactly supported scalar dark modes

From `BB†=12I+3N`, every normalized `λ`-mode has

\[
\|B^\dagger\psi_\lambda\|^2=12+3\lambda.
\tag{D1}
\]

In particular `B†E_{−4}=0`. Since `PAP=0`, each of the two `λ=−4` vectors in one Hurwitz coset, extended by zero to the other 96 vertices, is an **exact zero eigenvector of A_600**, not merely an initially suppressed mode. The five disjoint cosets therefore supply a ten-dimensional **exact compactly supported kernel** of the 120×120 adjacency. They lie in the central-sign-even subspace.

**Independent group-theoretic derivation.** Inside the marked `2T`, the normal subgroup `Q8` has index 3: `2T/Q8≅C3`. The 24-cell nearest set `Re(h)=1/2` contains exactly four group elements in each nontrivial quotient class. For either nontrivial one-dimensional quotient character `χ_±(h)=ω^{±k(h)}`, with `ω³=1` and `1+ω+ω²=0`, native adjacency gives `Nχ_±=−4χ_±`. More strongly, every outside 600-cell vertex has exactly **one** neighbor in each of the three `Q8` quotient classes of the chosen coset, so `B†χ_±=0` by the direct sum `1+ω+ω²=0`. The verifier tests all `96×5` external-vertex class counts as exact integers. Since `−1∈Q8`, these modes are **central-sign even**, not the odd spinorial content.

**S³ network cross-check.** Subdivision of five disjoint Hurwitz cosets into three right-`Q8` orbits apiece gives an exact **15-axis quotient** with adjacency `K_{3,3,3,3,3}` and quotient spectrum `12^(1),(-3)^(4),0^(10)`. This agrees with the **unmarked graph** of `Paper00-S3StructureNetwork-v1_20/data/q8_hopf_e8_bridge_v120_instance.json`. The network's left/right `Q8` markings are distinct and related by quaternion inversion; no identity of marked fibre maps or automatic physical E8 channel is asserted.

## 5. Fourth theorem: the three-slice Cartan comparison lifts four dark directions

Use the source global Cartan map `g(q)=diag(ρ(q),1)` extended mathematically to *all 600-cell nearest edges* as in v1_3. Let `\mathcal B_s` be the resulting 24-to-96 edge-coupling matrix on site×color (24×3 source states to 96×3 complement states). Its squared Hilbert–Schmidt norm is **864 for every** `s`, since there are 288 directed source-to-complement 600 edges and every link is unitary in three colors.

At the endpoint profiles `s=0,1`, the link family is respectively the identity and a pure-gauge endpoint product, so the cross-coset rank is `3 rank(B)=66` and its source-side nullity is `72−66=6`.

At the **actual middle source profile** `s=1/2`, the two-color 48×48 Gram matrix obeys

\[
G_{1/2}^{(2)}=12I_{48}+\beta T,
\quad\beta=\frac{15+\sqrt5}{10},
\quad T=N\otimes I_2+D_\rho(N\otimes I_2)D_\rho^\dagger,
\tag{C1}
\]

where `D_ρ=diag(ρ(h))` for the 24 Hurwitz sites. The v1_3 three-path equality fixes `G_{qq'}=3κ U_{qq'}^{24}(1/2)` on the 8 native neighbors and zero elsewhere, with `κ=(√3/2)+(√15/30)` and `β=√3κ`. In the marked Hurwitz coset, **`2T` is an exact Gaussian-integer Hermitian 48×48 matrix**. Its integer polynomial certificate is

\[
\boxed{(2T+12I)(2T+4I)(2T-8I)(2T-24I)=0,}
\tag{C2}
\]

with exact traces `tr[(2T)^k]=(48,0,4608,46080)` for `k=0,1,2,3`. Consequently the eigenvalues of `2T` are `−12 (8), −4 (24), 8 (12), 24 (4)`, with multiplicities in parentheses. This proves the **exact** middle two-color squared singular spectrum:

\[
\boxed{
\begin{array}{c|c}
3-3/\sqrt5&8\\
9-1/\sqrt5&24\\
18+2/\sqrt5&12\\
30+6/\sqrt5&4
\end{array}}
\tag{C3}
\]

In particular the smallest is **strictly positive**. Therefore the middle two-color operator has full row rank 48; the untouched third color retains the scalar `B` rank 22. The total comparison nullity is **2**, versus **6** at each endpoint:

\[
\boxed{\dim\ker\mathcal B_s^\dagger:\quad6\ (s=0),\quad2\ (s=1/2),\quad6\ (s=1).}
\tag{C4}
\]

`2T` is a *matrix name* in (C2), not the group `2T` elsewhere. For the four other left Hurwitz cosets the spectrum follows by SU(2) left multiplication conjugacy, and bounded eigenspectrum checks confirm each. Note the rank change redistributes spectral coupling strength while keeping `tr(\mathcal B_s\mathcal B_s†)=864` fixed. These are comparison-operator rank statements; the two-color/third-color distinction is a fixed Cartan presentation and has **not** been promoted to physical color-singlet state selection.

At the middle slice, the averaged three-path **color** transporter from v1_3 has singular values `(κ,κ,1)` and determinant `κ²=(23+3√5)/30≠1`. No **single overall scalar** can transform it into the native unitary SU(3) link; the *unitary polar step is mathematically essential*. Such a nonlinear path assembly is not automatically supplied by a linear Schur complement.

## 6. Fifth theorem: a Clifford-grade obstruction to naive edge-word composition

Use Paper VII-A's native Clifford matrices `Γ_a=σ_1⊗σ_a (a=1,2,3)`, `Γ_4=σ_2⊗I`, `Γ_5=Γ_1Γ_2Γ_3Γ_4`. Remove the native scalar factor `3/8` and write the **native spin/Wilson word**

\[
S(n)=\Gamma_5(\Gamma\!\cdot n-I_4).
\]

For any two mathematical 600-cell edge tangents `n_1,n_2`, the product `S(n_1)S(n_2)` lies in Clifford grades `0,1,2`. The target `S(n)` lies in grades `3,4`. Hence

\[
\boxed{\operatorname{tr}_{\rm spin}[S(n)^\dagger S(n_1)S(n_2)]=0}
\tag{W1}
\]

**for every pair of unit tangents**, before path averaging or color weighting. As a result, a two-edge sum with a **spin-scalar intermediate propagator** cannot produce the native spin/Wilson word by scalar normalization, even if the scalar paths, SU(3) link polar factors and tangents have been reconstructed. This is an obstruction to that **particular comparison construction**, not to the actual native regulator.

A more demanding control inserts the existing chirality matrix at the intermediate site. On each native edge let `n` be the native tangent, and define the oriented spatial bivector

\[
K(n)=n_3\Gamma_1\Gamma_2+n_1\Gamma_2\Gamma_3+n_2\Gamma_3\Gamma_1.
\]

For the three exactly counted intermediates, the relative-angle and path-sum identities give the **universal exact constants**

\[
\mu=n_1\cdot n_2=\frac1{\sqrt5},\qquad
b=\frac{\varphi\sqrt3}{3\sin(\pi/5)},\qquad
c=\frac{5\sqrt3-\sqrt{15}}{15}>0.
\]

The ordered averages of the two natural spin words are then

\[
\begin{aligned}
T_0&=\frac13\sum_r S(n_{qr})S(n_{rq'})=(1-\mu)I-cK(n),\\
T_5&=\frac13\sum_r S(n_{qr})\Gamma_5 S(n_{rq'})
=\Gamma_5[(1+\mu)I-b(\Gamma\cdot n)+cK(n)].
\end{aligned}
\tag{W2}
\]

`T_0` is exactly Hilbert–Schmidt orthogonal to the native `S(n)`. `T_5` has a nonzero native projection, but also an unavoidable **bivector remainder**, since `c>0`. With `a=1+μ`, the best scalar multiple of `S(n)` in the Hilbert–Schmidt norm is `k_*S(n)`, where

\[
\boxed{k_*=-\tfrac12(a+b),\qquad
\|T_5-k_*S(n)\|_F^2=2(a-b)^2+4c^2\approx0.44781258846248>0.}
\tag{W3}
\]

The residual norm is approximately `0.6691880068`. Thus even supplementing a flat intermediate propagator with just scalar and constant `Γ_5` pieces cannot exactly reproduce the native word under the equal-path assembly at `s=0,1`. The **full actual source** may of course contain higher Clifford paths, nontrivial intermediate resolvents, action-specific projections or counterterms; those were **not** excluded by this local comparison test.

The verifier checks (W1)–(W3) on all **480** geometrically native edges and checks the exact Gaussian-integer Cartan certificate independently. A zero scalar-block overlap is an exact grade identity, while the bounded floating checks are used only for the angular constants and reconstructed operators.

## 7. Sixth theorem: the *source-owned* 864×864 native regulator has a precisely localized character leakage

This result differs from the mathematical 600-edge extensions above: here the matrix is **exactly the native three-clock-layer spin/color Hurwitz regulator** defined in Paper VII-A (`p10:thm:v199-native-unit-component`, native Wilson/Dirac stencil) and Paper VII-D, as reconstructed in the prior v1_3 source verifier.

Let `E_char=E_{−4}` be the real, rational rank-two site projector in (D1), onto the nontrivial one-dimensional `2T/Q8` character modes. On the native space

\[
\mathcal H_*=\mathbb C^{3}_{\rm clock}\otimes\ell^2(2T)\otimes\mathbb C^4_{\rm spin}\otimes\mathbb C^3_{\rm color},
\quad\dim\mathcal H_*=864,
\]

define the **mathematical chart test projector**

\[
\Pi=I_3\otimes E_{\rm char}\otimes I_4\otimes I_3,\qquad\operatorname{rank}\Pi=72.
\tag{N1}
\]

**Spatial conservation.** Every native right-frame Cartan link is constructed from `ρ(q)ρ(r)†`. For any right Hurwitz multiplication `h∈2T`,

\[
\rho(qh)\rho(rh)^\dagger=\rho(q)\rho(r)^\dagger.
\]

The native link and its Clifford tangent are unchanged on the transported native edge `qh→rh`. The native sitewise spatial Wilson/Dirac operator therefore commutes with the right regular `2T` action (acting only on site labels), at **every Cartan profile s**. As `χ_±` are separate one-dimensional right-`2T` characters, the spatial operator preserves the corresponding site projectors tensored with spin/color identity. The independent source's sitewise `3Γ_5` diagonal and the two interior identity temporal links preserve them as well. The verifier independently reconstructs the three 288×288 native spatial blocks and finds cross-projection squared norms numerically below `6×10⁻30` (a bounded machine confirmation of the exact group proof).

**Closing-clutch leakage.** The native last-to-first clock block contains the sitewise transporter

\[
\mathcal G=\operatorname{diag}_{q\in2T}\bigl(\rho(q)\oplus 1\bigr).
\]

For the `ρ(q)` two-color block, the character compression vanishes **exactly**:

\[
\boxed{(E_{\rm char}\otimes I_2)\,\operatorname{diag}_{q\in2T}\rho(q)\,(E_{\rm char}\otimes I_2)=0.}
\tag{N2}
\]

Indeed, matrix elements are weighted sums of the group representation `ρ(q)` by products of characters `χ_a^*χ_b`, which factor through `2T/Q8`. Every `Q8` coset is closed under `q→−q`, hence `\sum_{q\in Q8}ρ(q)=0` and the sum over each of the three cosets vanishes. All `2×2` character compressions in the nontrivial color doublet are therefore zero. The untouched third-color component `1` remains inside `E_char`.

The two-color source rank is `2 site characters × 2 colors=4`, so the squared norm **leaking out of** the character test subspace under `\mathcal G` is exactly `4`. The source closing fermion spin factor is

\[
F=\tfrac12\Gamma_5(\Gamma_4-I_4),\qquad\|F\|_F^2=2.
\]

One directed closing temporal block therefore contributes `2×4=8` to the Hilbert–Schmidt leakage. The Hermitian conjugate orientation contributes another `8`. All other blocks preserve `Π`. Thus

\[
\boxed{\|(I-\Pi)H_*\Pi\|_F^2=16,\qquad\|[H_*,\Pi]\|_F^2=32.}
\tag{N3}
\]

The complete **source-owned 864×864** complex Hermitian matrix is also reconstructed directly and passes these identities numerically to `10⁻8`; its separately sourced untwisted quaternionic sign-defect benchmark `||JH_*J-H_*||_F²=768` is recovered, cross-checking the build against v1_3. The `16` and `32` are **exact algebraic consequences of the source stencil and group projector**, not fitted numerical constants.

**Scope.** The mathematical chart projector is not a licensed gauge-invariant physical hadron or decay projector. The result says that the native finite QCD regulator preserves the Hurwitz characters **spatially** but that its actual temporal clutch couples their two-color components to complementary regulator sectors. It does not provide a Fock parent/daughter process, a width, CP violation, or a stable particle. A nontrivial physical selection law would need the operator's correct gauge-covariant test projector and the physical action/current/complete-channel map.

## 8. What the framework can and cannot conclude

### Exact, framework-compatible mathematical results

1. The 600-cell equal-edge **comparison** has non-nearest Hurwitz return shells by orders three, four and five; no generic reduction to the native eight-neighbor stencil.
2. Its five Hurwitz adjacency modes possess exact rational Schur response functions, and its ten `Q8/C3` character modes are compactly supported zero modes of the full scalar graph.
3. The `S3StructureNetwork-v1_20` five-triple/15-axis quotient gives a second proof of precisely the ten-dimensional dark subspace, subject to left/right marking discipline.
4. The three **actual native Cartan profile values** make the **extended 600-cell link comparison** change source-side nullity `6→2→6` while preserving the overall squared Hilbert–Schmidt coupling norm.
5. Direct composition of two native-form Clifford/Wilson link words is grade-incompatible with a native one-edge word for a flat spin-scalar intermediate propagator; even one constant chirality insertion leaves an exact positive residual.
6. **On the actual 864-dimensional native regulator**, right-Hurwitz spatial invariance exactly preserves the nontrivial `Q8/C3` characters, while the closing clock clutch generates squared character leakage `16` and commutator norm squared `32`.

### Open physical source certificates (not silently discharged)

- `SOURCE_600_EDGE`: a genuine **same-action** 600-cell-edge gauge/Clifford operator, or an already-licensed nonlocal equivalent—not merely a mathematical extension of the Cartan map.
- `SOURCE_RESOLVENT`: the actual spin/color/clock intermediate operator and its resolvent, **not** `gA_600` or a scalar `Δ` assumed for convenience. It must account for the higher-order return shells and the Clifford-grade remainder if a native local stencil is asserted.
- `SOURCE_PATH_ASSEMBLY`: demonstration that the action uses the three-path coherent weights, tangent assembly and non-linear unitary polar projection, or an alternate already-source-owned route that produces identical observables.
- `STATE_MAP`: the actual parent and complete daughter-multiset state/projector packet in the correctly charged, antisymmetrized Fock carrier; Q8-axis labels, five cosets, or QCD color blocks do **not** constitute particle species or physical decay channels by themselves.
- `PHYSICAL_WIDTH`: source-owned transition matrix elements, spectral residues, open-channel / limiting-absorption or measurement interface and measured branching/width map. The finite Hermitian comparison graph has only real spectrum and recurrences.

A decisive follow-on computation should therefore form the **full source-owned Fock transition block** and its Clifford/filter/resolvent decomposition, and test whether its physical channel amplitudes see these `C3` cancellation modes or whether the native gauge/spin vertex lifts them. The goal is the observable channel, not reproduction of a conventional mechanism by analogy.

## 9. Reproduction and audit provenance

Run after extraction:

```bash
OPENBLAS_NUM_THREADS=1 python Paper00-VerifyGeometricTransitionCompiler-v1_4.py
```

The single self-contained verifier reconstructs 120 exact `Z[φ]` vertices, five Hurwitz cosets, all second-to-fifth-order 24×24 integer return matrices, all 5×5 exact native spectral-projector and complement-Krylov annihilator certificates, the 15-axis quotient, all `96×5` three-way `Q8` neighbor cancellations, the exact Gaussian-integer polynomial and traces for the 48×48 middle-layer Cartan matrix, bounded SU(2) link Gram checks for all five cosets, the 480-link Clifford controls, and the full source-owned 864×864 native spin/color/clock kernel with exact character-projection leakage.

Generated artifacts:

- `Paper00-600HurwitzReturnChecks-v1_4.json`: exact result metadata and numerical constants.
- `Paper00-600HurwitzReturnShells-v1_4.csv`: the first four return moment shell coefficients.
- `Paper00-600HurwitzModeResponses-v1_4.csv`: five mode strengths and rational functions.
- `Paper00-600HurwitzReturnMatrices-v1_4.npz`: exact 120-vertex adjacency, five native cosets, 15-axis quotient, integer middle Cartan certificate matrices.
- `Paper00-VerifyGeometricTransitionCompiler-v1_4.py`: independently executable proof/replay code.

The current canonical TeX papers, QCD source operators, S³ Network and global proof-DAG archives were **not** modified or promoted in this mathematical research run. No external decay data were fitted or claimed to be explained.
