# Framework v3.029 — Paper II-A GP3 Matter Propagation Integration

**Release:** `Paper00-PapersMinimal-v3_029.zip` / `Paper00-DAGAtlas-v1_170.zip`  
**Date:** 17 November 2026  
**Change origin:** GP3 propagation proposal v1.1, checked against current v3.028 paper sources and DAG v1.169.

## Integrated original theorem statements

The existing G0, GP1–GP3, primitive $S^1/S^3$, level-one $m_p=1$, and all prior matter statements and issue records are preserved. Two paper roots changed: `Paper2F-TechnicalMaterial-v1_67.tex` → `v1_68` and `Paper5A-FiniteMatterGeometry-v3_212.tex` → `v3_213`. A new cross-reference macro root `Macros-v2_182.tex` binds both updates. The full papers ZIP contains 31 TeX+PDF pairs, while untouched macro generations are retained when older paper sources still import them.

Six new theorem/remark anchors were added:

- `p2:rem:v329-matter-gp3-whole-owner`: whole-candidate trace guard.
- `p5:thm:v329-matter-factor-envelope`: abstract $M_{12}(\mathbb C)\oplus M_{36}(\mathbb C)$, complex dimension 1,440, faithful finite representation classes $(k_\ell,k_C)$.
- `p5:prop:v329-matter-process-descent`: finite Hermitian basis / single positive heat-time process-descent criterion, restricted to specified operations.
- `p5:prop:v329-solder-anomaly-commoncopy`: conditional equal common $k$ on a complete physical unit-solder and anomaly-free local-QFT candidate class.
- `p5:rem:v329-commonparent-higgs`: the single canonical coordinate doublet type depends on the actual common generated parent, not equality of two independent copy-space dimensions.
- `p5:prop:v329-commoncopy-heat-gauge-routing`: ordinary additive trace absolute terms scale with common $k$, while $\sin^2\theta_W(\mu_h)=3/8$ and the one-loop differences survive common replication, with fixed action/thresholds.

## DAG propagation

`DAG/SourceUpdates/GP3MatterOwner-v1_1/Index.json` registers the six source claims, 18 witness-anchored AND proof-use edges, two new *conditional* source-local scope guards (not axioms), exact replay evidence and the existing two open GP3 issue origins. The core theorem DAG contains a backward-compatible `graph_layers` index entry. The existing material/route indices have not been silently upgraded; the new links are proof-route guarded and declared as a source update.

The 31-paper anchor map has **14,034 unique labels**: all 14,028 previous labels plus 6 new ones, no duplicates. The Paper II-F and V-A PDFs were recompiled with bibliographies; the unchanged 29 PDFs are preserved.

## Focused checks and scope

Original proposal script: **99 focused checks PASS**. Integrated current-source/DAG replay: **73 focused checks PASS**. Algebra, multiplicity equations, trace scaling, weak-angle invariance, one-loop slope differences and source-label provenance are checked. The new material is not independently audited to full protocol E3/E4 on all downstream observable routes.

## Outstanding physical frontiers

- `BH-VA-G-0001` remains OPEN: actual physical matter multiplicity-one and the generated full-signature GP3 comparator are not certified. In particular, 48 is the canonical abstract representation dimension and not a universal physical one-copy proof.
- `BH-IIB-STRUCTURED-RIGIDITY-001` remains OPEN: independent whole-momentum-carrier rigidity is not implied by the matter algebra.
- Physical source-incidence of the full Clifford/solder operator grammar and the complete set of downstream test/process owners is not globally established.
- The common-copy predictions apply only to the same-owner unnormalized-trace, unchanged scalar/vector, fixed threshold branch. Ordinary-trace absolute quantities are copy-sensitive.

This is an integrated source-and-DAG **framework update**, not a theorem that $k=1$, not a universal physical event-realization proof, and not a full 31-paper re-audit.
