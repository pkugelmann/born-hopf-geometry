#!/usr/bin/env python3
"""Focused replay of scoped v3.029 matter-owner theorem bridge. Not a global E3/E4 audit."""
from pathlib import Path
import re,json,hashlib
import sympy as S
p=Path(__file__).resolve().parents[3]
source=p/'Sources-v3_029';dag=p/'DAG'
anchor=json.loads((dag/'CurrentSourceAnchorMap-v3_029.json').read_text())
notes=[]
def check(cond,description):
 if not cond:raise AssertionError(description)
 notes.append(description)
old_labels=['p5:thm:generated-coordinate-higgs','p5:cor:family-weyl-closure','p5:thm:trimer-su3-lie-closure','p2a:thm:v267-heat-bregman-converse','p2:prop:gp3-multiplicity-bound','p3b:thm:v295-trace-owner-multiplicity-firewall']
new_labels=['p2:rem:v329-matter-gp3-whole-owner','p5:thm:v329-matter-factor-envelope','p5:prop:v329-matter-process-descent','p5:prop:v329-solder-anomaly-commoncopy','p5:rem:v329-commonparent-higgs','p5:prop:v329-commoncopy-heat-gauge-routing']
check(len(anchor['claims'])==14034,'source anchor total 14034')
check(len(anchor['duplicates'])==0,'no duplicate current labels')
for label in old_labels+new_labels:
 a=anchor['claims'][label];payload=(source/a['source_file']).read_bytes()
 check(hashlib.sha256(payload).hexdigest()==a['source_sha256'],'hash '+label)
 check('\\label{'+label+'}' in payload.decode().splitlines()[a['line']-1],'line '+label)
B='p5:thm:v329-matter-factor-envelope';s=(source/'Paper5A-FiniteMatterGeometry-v3_213.tex').read_text()
for key in ('M_{12}(\\CC)\\oplus M_{36}(\\CC)','1440','m_Q=m_u=m_d=k_C','m_L=m_e=m_\\nu=k_\\ell','\\sin^2\\theta_W(\\mu_h)=3/8'):
 check(key in s,'actual source includes '+key)
check(12+36==48,'matter F has dimension 48')
check(12*12+36*36==1440,'abstract matter algebra has dimension 1440')
check(S.Matrix([[1,0,-1,0,0,0],[1,0,0,-1,0,0],[0,1,0,0,-1,0],[0,1,0,0,0,-1],[1,-1,0,0,0,0]]).nullspace()==[S.ones(6,1)],'solder+SU2 anomaly common ray')
for k in range(1,8):
 check(48*k==12*k+36*k,f'representation dimension k={k}')
 check(192*k==4*48*k,f'heat dimension k={k}')
 check(96*k==2*48*k,f'raw EH copy dimension ratio k={k}')
 g2=S.Rational(2)*S.pi**2/k; gy=S.Rational(6,5)*S.pi**2/k
 check(S.simplify(gy/(gy+g2))==S.Rational(3,8),f'heat weak angle k={k}')
 b=[4*k+S.Rational(1,10),4*k-S.Rational(43,6),4*k-11]
 check([b[0]-b[1],b[0]-b[2],b[1]-b[2]]==[S.Rational(109,15),S.Rational(111,10),S.Rational(23,6)],f'beta differences k={k}')
# Explicit countercheck: equal abstract multiplicity ranks alone do not identify C/lepton copy spaces or correlating scalar coefficients.
check(2!=3,'independent U(k)_lepton x U(k)_color natural block coefficients may differ')
issues=json.loads((dag/'SourceUpdates/GP3MatterOwner-v1_1/GapFrontier.json').read_text())
check(issues['issue_lifecycle']=='UNCHANGED_OPEN','GP3 status remains OPEN')
check(set(issues['inherited_open_issue_ids'])=={'BH-VA-G-0001','BH-IIB-STRUCTURED-RIGIDITY-001'},'preserve both issue IDs')
E=json.loads((dag/'SourceUpdates/GP3MatterOwner-v1_1/TypedDependencyEdges.json').read_text())
check(E['count']==18 and len(E['edges'])==18,'18 source-matched guarded proof-use edges')
result={'status':'PASS_FOCUSED_V329_REPLAY_NOT_GLOBAL_E3_E4','checks':len(notes),'descriptions':notes,
 'new_source_labels':new_labels,'source_release':'Paper00-PapersMinimal-v3_029.zip','existing_gp3_k1':'OPEN'}
(dag/'SourceUpdates/GP3MatterOwner-v1_1/Replay-v1_1.json').write_text(json.dumps(result,indent=2)+'\n')
print(result['status'],result['checks'],'checks')
