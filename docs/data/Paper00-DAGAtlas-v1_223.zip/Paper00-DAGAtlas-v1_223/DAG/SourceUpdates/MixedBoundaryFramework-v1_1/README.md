Source-anchored framework update for III-E/III-F v3.031. Explicit scope: ordinary unmarked Euclidean heat and fixed bag collars; physical Newton is OPEN. New canonical material edges: 0.
