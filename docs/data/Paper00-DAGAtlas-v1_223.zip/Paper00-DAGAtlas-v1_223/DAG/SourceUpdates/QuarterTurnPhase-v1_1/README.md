# Quarter-turn source/metric scope — v1.1

Source release: `Paper00-PapersMinimal-v3_030.zip`. Added four source statements in Paper I-B, III-E and III-F; no change to capped $f_c(R)$. The rooted imaginary-coherence and smooth-phase sampling counterexample are exact finite mathematical statements. The heat two-jet cancellation is conditional on unmarked signed-factorization, including the full metric/source contact.

The native rooted-to-cap port map and non-co-rotating signed receiver are **not** demonstrated; the selected physical depth transport, cosmological dark matter abundance, RAR and lensing do not follow. Audit history is not reopened or promoted. The typed edges are a scoped source integration, not a blanket verification of the framework.

