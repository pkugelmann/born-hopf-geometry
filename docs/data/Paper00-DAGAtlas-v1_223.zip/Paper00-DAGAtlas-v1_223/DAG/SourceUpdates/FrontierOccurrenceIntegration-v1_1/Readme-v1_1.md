# Paper III-F / II-C / IV-A scalar occurrence and test-algebra source integration v1.1

**Current source:** PapersMinimal v3.067; **parent:** v3.066. 19 exact source labels in three updated papers. Mathematical source claims include explicit antecedents. The canonical graph, its historical audits and all physical occurrence/issue statuses remain frozen.

This is a **source-matched index** and a collection of candidate domain/proof routes, not the result of the rigorous single-paper multi-agent audit protocol. It does not identify current mathematical scalar field solutions with actual events, nor a finite harmonic test algebra with physical apparatus. The sharp scalar test-frontier occurrence remains separately open.

See `SourceAnchorDelta-v3_067.json`, `SourceDigestIndex-v3_067.json`, `SourceUseRoutes-v1_1.json`, `StatusAndConditions-v1_1.json`, `OpenObligations-v1_1.json`.
