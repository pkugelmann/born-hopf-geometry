# R² marked source transport integration — v1.1

This source update registers four new Paper II-A / III-E / III-F labels and eleven exact mathematical proof-use/scope edges, within their stated conditional constructors. It does **not** promote occurrence of the current capped gravitational action in the native Dirac operator, assign a physical cosmological constant, or reopen GP1–GP3.

The fixed-reference cap returns `-R_s²/b(R)²`. Determinant-normalized and positive-isometric source sections return `-R_s²` but are **not** equivalent marked currents. The scalar two-jet discriminator is `(B² s)''(0) = 0` (running) versus `-B_I² d` (frozen), for `d=1-B_U/B_I`. Distinguishing two frozen marked currents requires actual complete source probes.

Sources: Paper2A v3.224, Paper3E v1.198, Paper3F v1.265; mathematical checks are local E2/finite replay, not full E3/E4.
