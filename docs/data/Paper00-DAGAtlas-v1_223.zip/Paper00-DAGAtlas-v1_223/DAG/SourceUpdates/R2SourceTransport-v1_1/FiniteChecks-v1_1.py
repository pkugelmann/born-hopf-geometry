"""Symbolic checks for the proposed R2 source-transport discriminator.
Does not verify occurrence in a native gravitational action.
"""
import sympy as sp
R, Rs, c, BI, BU, rho = sp.symbols('R Rs c BI BU rho', positive=True)
u = sp.symbols('u', real=True)
X = sp.Matrix([[0, 1], [1, 0]])
I2 = sp.eye(2)
T = sp.kronecker_product(I2 + u*X, I2 - u*X)
b = 1-u**2
assert sp.factor(T.det()-b**4)==0
assert sp.factor(sp.trace(T.inv())-4/b**2)==0
jd = rho*b*sp.eye(4)
jfix = rho*sp.eye(4)
assert sp.factor(sp.trace(jfix.T*T.inv()*jfix)-4*rho**2/b**2)==0
assert sp.factor(sp.trace(jd.T*T.inv()*jd)-4*rho**2)==0
assert sp.simplify(jd.T*T.inv()*jd-rho**2*sp.eye(4)) != sp.zeros(4)
# The metric-isometric transported covector j_iso=rho*T^{1/2}
# exists for |u|<1. Its Gram is rho^2 I, by positive square-root functional calculus.
# Taylor jets of u(R) and b(R) at R=0.
x = R/Rs
t = x/(1+sp.sqrt(1+x**2))
bR = 1-c**2*t**2
assert sp.simplify(bR.subs(R, 0)-1)==0
assert sp.simplify(sp.diff(bR,R).subs(R,0))==0
assert sp.simplify(sp.diff(bR,R,2).subs(R,0)+c**2/(2*Rs**2))==0
B = BI*bR
frun = R*sp.Symbol('P') + B*R**2 - Rs**2/bR**2
ffrozen = R*sp.Symbol('P') + B*R**2 - Rs**2
assert sp.simplify(sp.diff(frun,R,2).subs(R,0) - (2*BI-c**2))==0
assert sp.simplify(sp.diff(ffrozen,R,2).subs(R,0) - 2*BI)==0
srun = Rs**2/bR**2
sfrozen = Rs**2
assert sp.simplify(sp.diff(B**2*srun,R,2).subs(R,0))==0
assert sp.simplify(sp.diff(B**2*sfrozen,R,2).subs(R,0) + BI**2*c**2)==0
assert sp.simplify(sp.diff(rho*bR,R,2).subs(R,0) + rho*c**2/(2*Rs**2))==0
# First jet of the positive square root at the identity: (T^1/2)'=T'/2.
Ts_1 = sp.diff(T,u).subs(u,0)
assert Ts_1 == sp.kronecker_product(X,I2)-sp.kronecker_product(I2,X)
assert sp.simplify(sp.diff(t,R).subs(R,0)-1/(2*Rs)) == 0
print('ALL SYMBOLIC COMPARISON CHECKS PASS')
