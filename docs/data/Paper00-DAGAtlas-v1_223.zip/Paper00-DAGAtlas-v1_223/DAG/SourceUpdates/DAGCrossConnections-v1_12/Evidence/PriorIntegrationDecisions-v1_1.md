# Born–Hopf Geometry — Cross-DAG integration decisions v1.1

**Decision only — NO canonical archive updates.** Prepared from the uploaded `Paper00-PapersMinimal-v3_018.zip`, `Paper00-DAGAtlas-v1_154(1).zip`, `Paper00-ProofChainAudits-v1_67(1).zip`, `Paper00-CrossDAGFrameworkIntegration-v1_1.md`, and cross-connection research notes v1.1–v1.12. The latest mathematical research release is v1.12; version numbers refer to *research notes*, not to proved main-paper claims. Follow the two user-provided proof-chain verification protocols.

## Executive decision

**Do not re-insert v1.1–v1.7.** Those results are integrated in the source version `Paper00-PapersMinimal-v3_017`, carried into v3_018, with 24 modules and 95 new source labels, across 11 papers. Their current proof status is paper- and label-dependent, not global. Paper I-B v1.10 now has a complete source-disposition audit of 506/506 formal objects (341 VERIFIED, 7 VERIFIED-CONDITIONAL, 43 REPRODUCED, 115 FORMALIZED), with 2 scoped open issue roots. Other changed papers' historical audit files may refer to older source hashes and cannot be treated as current re-audits.

**Most important unintegrated findings** are from v1.8–v1.12. Integrate their general, finite mathematical theorems with source-accurate assumptions, and keep expensive exact certificates, orbit enumerations and numerical tests in reproducibility appendices. Never promote a comparison source to a physical QCD/gravity/cosmological occurrence.

## Priority A — New source theorems to adjudicate and add first

| Theme / research | Intended source owner | Precise reusable content | Downstream consumers | Certification caveat |
|---|---|---|---|---|
| One-core Markov quotients (v1.8) | Paper I-B | Full 600-state chamber walk strongly lumps to each five-state left/right core process; the 25-state pair observation alone retains 16-mode memory | Paper IV-B, source/observer response | Abstract continuous-time adjacency generator; no physical clock |
| Hopf incidence and 16-dimensional blind sector (v1.8) | I-B, II-D | 60 left + 60 right ten-fibre orbits on 600 facets; pair of phase-blind marginal readouts rank 9 and kernel `P_c` rank 16 | II-D, IV-A/B | Needs verified chosen Hopf convention; no physically actualized measurement |
| First full register harmonic frame and stable hybrid inversion (v1.8) | I-B to I-C | Gram at harmonic degree 12: `325/256 P0 + 3003/1024 Pa + 325/4096 Pc`; exact inversion; Hopf-marginal+degree-six hybrid completeness | I-C, III-B, IV-A/B | Audit exact Gram/normalization and operator domains |
| 72-base degree-nine and charge-resolved 720-node sampler (v1.8) | II-D, I-C | Positive 72-point `S²` degree-nine rule, 10 fibre-DFT blocks summing to 385, and *fixed-support optimality* polynomials | II-D, III-B, VI-B (comparison) | Base map is auxiliary; sky/readout bridge remains conditional |
| Directed-pair classical Markov kernel (v1.8) | IV-B / VII-B comparison | 20-state positive reversible kernel with spectrum `1,1/2,1/10,0` and uniform core marginals after one step | IV-B, VII-B | Do not call physical meson decay rates |
| Degree-six chamber intensity / degree-12 invariant (v1.9) | I-C | `sum_{16} |f_{6,a}|² = 16+12 C12`; second construction of first nonconstant 2I invariant | I-C, III-B/C | Verify exact frame normalization and left/right group actions |
| Degree-eight/twelve interference / degree-20 invariant (v1.9) | I-C | Exact cross-harmonic extraction of `C20`, 16-dimensional vertex alias and facet separation, 48-dimensional sampled frame | I-C, III-B | Audit exact constants and identity of paired modules |
| Hopf–Petersen quartic complement (v1.9) | III-C | Geometric identity between five-frame quartic Hopf average and 16-mode intensity | III-C, spectral source comparisons | Equality of mathematical observables only; not a conserved physical energy |
| Two-sided memory charge factorization (v1.9) | II-D, IV-B | `41=1+8+16×2`, two-sided `Z5×Z5` Fourier charges and two-pole return in joint sector | IV-B | Charged *comparison* sectors; no particle rates |
| Klein invariant root construction (v1.11) | I-B; link to II-D | `F12`, Hessian `H20`, Jacobian `T30`, relation `T²=H³+1728F⁵`; zero sets reconstruct `12+20+30` angular nodes | II-D, IV-A, VI-B | Classical invariant theory; distinguish new *framework connection* from classical algebra |
| Degree-60 matrix-valued invariant threshold (v1.11) | I-B | `dim(V60^{2I})=2`; full 2×2 Fourier block, rather than scalar character trace, required for integration | I-B, I-C computational interface | Essential guard against false numerical cubature certification |
| Positive degree-61 cubature and band-30 compiler (v1.12) | I-B theorem / I-C corollary | Exact positive 19-double-orbit 60,000-node rule through degree 61; 10,416-mode exact scalar sample image; first error at degree 62 | III-B spectral calculus; IV-A mathematical operators | Exact certificate and source audit; **scalar** only, not gauge/Dirac/whole-action |

## Priority B — Consolidate as corollaries, tools or appendices

| Topic | Owner | Placement decision |
|---|---|---|
| Degree-23, 29, 31, 35 positive cubatures (v1.10), degree-39, 41 (v1.11) | I-B appendix / I-C computational reference | Retain as smaller lower-cost quadrature options and monotone exactness ladder; do **not** proliferate independent foundational principles |
| Degree-24 four-skeleton no-go and degree-19/degree-nine fixed-support optimality | I-B/I-C, II-D | Include as decisive **scope/optimality** propositions to prevent overclaiming exactness |
| General convex-hull orbit-moment construction with multiplicity-aware matrix constraints | I-B main theorem / reference algorithms | Include as general mathematical method; distinguish existence of some positive cubature from an explicit minimal construction |
| Heat-smoothed error asymptotic and first surviving invariant for each rule | I-B/I-C, III-B application notes | Include norm specification (`L²→C`) and heat/time/radius units; never transfer automatically to spin/gauge spectra |
| Degree-complement harmonic selection rule and `2O–2I` versus heat no-go (v1.9) | I-C/III-B | Corollary and obstruction: permitted mixing is not guaranteed nonzero, and finite averaging is not one full heat step |
| Rational/algebraic exact group and positivity certificates (v1.10–v1.12) | Reproducibility annex / source-linked DAG | Store full 19×19 matrix, basis, rational inverse witness, orbit hashes, results; papers should give theorem and short proof |

## Priority C — Already in the current paper sources (do not duplicate)

- I-B: 20-directed-core coherent Gram; 600-cell memory; 120-point harmonic sampling; alternating exceptional symmetrization; exact heat-cubature comparisons; 720-point degree-19 vertex/facet positive rule.
- I-C: nine-mode reciprocal Grassmannian and spin comparison; 120-sample scalar spectral compiler; chamber graph versus continuum harmonic Galerkin coefficients and leakage.
- II-C/II-D: 20-outcome qutrit reconstruction/condition number; 14-probe chiral completion; order-ten binary-icosahedral Hopf Fourier sampling.
- III-B/III-C: scalar Galerkin nonlinear vertex compiler; sixfold moment hierarchy, Clifford source comparison.
- IV-A/B: positive evaluation POVMs; conditional twenty-projector channel; exact 41-state linear memory model belongs in I-B.
- VI-B: low-multipole comparison and closed FLRW differential/five-redshift null relations.
- VII-B/C: `1+3+5` Jordan algebra / eight-dimensional `su(3)` comparison and triplet Gram; finite joint energy–charge polytope, charge fan, real and complex temperature bounds, information-geometric inverse stability, conditional continuum zero-pinching obstruction.

**Audit caution:** Inclusion in a compiled source and a 34/34 local numerical/symbolic replay does not give all 11 modified papers a newly reviewed global proof chain. Use current paper version/hash and status per theorem; I-B has been re-reviewed in the latest v1.67 audit, but many other active audit reports remain source-frozen historical references.

## Remain comparison-only, or exclude from claimed physical derivation

1. Do not identify the matrix algebra on twenty directed core pairs with *physical* flavor `SU(3)` or a QCD meson nonet without an action-preserving source map.
2. Do not interpret the `1/2, 1/10` classical/quantum channel eigenvalues or the `(-9±sqrt21)/8` chamber memory poles as meson decay rates or physical time scales.
3. Do not interpret cubic algebraic invariants as fitted mass formulas; `3+4+1` dimensional decomposition alone does not enforce physical flavor multiplets, mass degeneracies or widths.
4. Do not infer actual gauge, gravity, spinorial or interacting-QCD spectral actions from scalar `S³` cubature; identify operator/source preservation before transfer.
5. Do not claim a measured cosmic `H(z)` model, reheating dynamics or physical quantum measurement because a finite comparison has an exact consistency/null identity.
6. Avoid promoting classical Klein invariant theory itself as a *novel mathematical discovery*; what is new within this framework is its identified source path to the existing 62-point icosahedral design and chamber modes.
7. Do not add a new GP principle, a preferred Hopf axis by fiat, or a physical particle carrier from representation-count coincidences.

## Recommended source and DAG integration sequence (only if user requests an update)

1. **Source-freeze:** choose v3.018 paper names, source hashes, and the newest atlas + proof-chain audit archives. Inventory the v1.8–v1.12 first-origin claims and deduplicate against integrated v1.1–v1.7 source labels.
2. **I-B & I-C first:** verify and integrate matrix-moment threshold, Klein-root/62-point bridge, degree-61 theorem plus finite band-30 operator; preserve full computational certificate as provenance.
3. **Register and Hopf bridges next:** add v1.8 exact Markov marginals, Hopf incidence, stable harmonic frame, and v1.9 `C12/C20` quadratic synthesis with explicit source domains.
4. **Specific consumers:** then add II-D/IV-B charge/memory consequences and III-C Petersen complement with exact imported labels; only add III-B and VI-B comparison corollaries in their correct scope.
5. **Typed DAG:** each new result gets a source claim node with exact hypotheses, `PROVED_SOURCE` vs `RESEARCH_PENDING_E3_E4` vs `PHYSICAL_INTERFACE_OPEN`, and typed material/candidate edges. An imported auxiliary comparison never becomes an unconditional physical-observable edge by graph reachability.
6. **Independent replay:** E1 proof replay and separate E3/E4 adversarial controls for every new theorem/consumer, exact certificates and checksum replays, LaTeX compilation and source-anchor validation, no duplicate current paper versions in ZIP releases.

## Overall assessment

**Top mathematical priorities:** (i) exact low/high exceptional invariant and Klein/62-point bridge; (ii) positive matrix-aware degree-61 cubature and band-30 scalar operator; (iii) five-core/Hopf/register and 16-dimensional hidden-sector readout; (iv) sharp aliasing/optimality/no-go conditions. **Top potential physical frontier:** source-preserving action map from one of these established geometric responses to an explicitly named observable, rather than a postulated particle occurrence.

No canonical sources, DAG edges or proof audits have been modified to produce this decision report.
