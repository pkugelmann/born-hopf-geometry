#!/usr/bin/env python3
"""Replay exact positivity from supplied finite moments and rational inverse, using only standard library."""
from pathlib import Path
from fractions import Fraction as F
from math import isqrt
import json
p=Path(__file__).resolve().parent
C=json.loads((p/'degree61_exact_certificate.json').read_text())
q=lambda x:F(*map(int,x))
A=[[(q(C['orbit_exact_moments'][j]['moments'][i]['a']),q(C['orbit_exact_moments'][j]['moments'][i]['b'])) for j in range(19)] for i in range(19)]
R=[[q(x) for x in row] for row in C['rational_inverse_R']]
assert len(A)==len(R)==19
slo=q(C['sqrt5_bounds']['lo']);shi=q(C['sqrt5_bounds']['hi'])
assert slo*slo<5<shi*shi
def upper(x,y):
 lo=x+y*(slo if y>=0 else shi)
 hi=x+y*(shi if y>=0 else slo)
 return max(abs(lo),abs(hi))
eps=F(0)
for i in range(19):
 row=F(0)
 for j in range(19):
  ar=(F(1) if i==j else F(0))-sum(R[i][k]*A[k][j][0] for k in range(19))
  br=-sum(R[i][k]*A[k][j][1] for k in range(19))
  row+=upper(ar,br)
 eps=max(eps,row)
err=eps*max(abs(R[i][0]) for i in range(19))/(1-eps)
assert eps< F(1,10**7) and err<F(1,10**7)
assert min(R[i][0] for i in range(19))>err>0
assert eps==q(C['inverse_residual_infinity_upper'])
assert err==q(C['weight_error_upper'])
print('EXACT POSITIVITY REPLAY PASS; ||I-RA||inf<=',float(eps),'weight error <=',float(err))
