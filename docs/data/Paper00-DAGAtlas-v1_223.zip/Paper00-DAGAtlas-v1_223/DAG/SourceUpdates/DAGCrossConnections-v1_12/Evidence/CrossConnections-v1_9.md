# Born–Hopf Geometry — Cross-Paper DAG Discovery Research v1.9

**Research status:** NEW mathematical deductions and finite certificates, **not a framework update**.  
**Source snapshot:** `Paper00-PapersMinimal-v3_017(1).zip` (31 current TeX/PDF pairs); `Paper00-DAGAtlas-v1_150(1).zip`; historical audits `Paper00-ProofChainAudits-v1_64.zip`. Both v3.017 paper ZIP editions were inspected for differing content: their relevant Paper I-B, Paper I-C and Paper III-B mathematical TeX bodies agree; some other files and PDF build metadata differ. The archive bytes are not merged or modified.  
**Proof status:** Paper-source premises are cited below. New results are demonstrated mathematically and accompanied by an independent exact `Q(sqrt(5))` check plus a numerical operator check. They have not been separately promoted under the E3/E4 protocol. No physical action, E-scale coupling, CMB transfer, or hadron decay law is created.

## 0. Discovery thesis

The 600-cell facet centres have multiple **already constituted mathematical uses**: a 600-state chamber adjacency; 25 Hurwitz-register cells; scalar degree-six, eight and twelve harmonic readouts; binary-icosahedral character averaging; a 720-point positive degree-nineteen design; and selected left/right Hopf actions. The DAG lets these readouts be composed without assuming they are the same operator or physical event.

A single register correlation module, the **16-dimensional real `4_L ⊗ 4_R` representation** of `I_L × I_R`, can be embedded in scalar harmonic degrees 6, 8 and 12. The squared and cross products of these embeddings supply the first two scalar `2I` invariants, in degrees **12 and 20**, with exact rational/radical coefficients. A separate Hopf lift of Paper III-B/C's existing Petersen sextic gives a positive complementary identity with the same degree-twelve invariant.

### Fixed notation and exact imported premises

- `I = 2I` is the 120-element binary icosahedral subgroup of `SU(2)=S³`; `H=2T⊂I` has 24 elements. Let `u=(1+i)/√2`, `V=I` and `F=IuI` (600 normalized tetrahedral facet centres).
- The 600 facets carry 25 equal-size registers `B_ab` (`a,b∈{1,…,5}`), each with 24 points. Let `S: ℝ²⁵→ℝ⁶⁰⁰` be the normalized incidence isometry. Put `Z=J₅/5`, `Y=I₅−Z`, `P₀=Z⊗Z`, `Pₐ=Z⊗Y+Y⊗Z`, `P_c=Y⊗Y`. Their ranks are 1, 8, 16.
- `𝓗_n` is the real scalar harmonic shell of degree `n` on Haar-probability round `S³`, with reproducing kernel `K_n(q,r)=(n+1)U_n(q·r)`. Define `T_n = ev_{F,n}* S` (where `ev_{F,n}f=(f(c)/√600)_{c∈F}`), equivalently
  
  `b_n(q)_{ab} := (T_n e_ab)(q) = (n+1)/120 Σ_{c∈B_ab} U_n(q·c)`.
- Imported source and v1.8 results: `T₆*T₆ = (7/16)P_c`, `T₈*T₈ = (9/16)P_c`, `T₁₂*T₁₂ = (325/256)P₀+(3003/1024)Pₐ+(325/4096)P_c`. The degree-12 relation is a v1.8 *research* result, not an audited canonical theorem.
- Let `C_n(q)=|I|⁻¹Σ_{g∈I} U_n(Re(g⁻¹q))`, for `n=12,20`. The source Molien series states that `I` has exactly one invariant line in degrees 12 and 20 and no nontrivial invariant in lower positive degrees. `C_n(1)=1`; `C₁₂(u)=−5/16`, `C₂₀(u)=31/64`.
- On the shared 16-dimensional register domain `P_cℝ²⁵`, introduce its canonically **matched** isometric harmonic embeddings
  
  `U₆=(4/√7)T₆P_c`, `U₈=(4/3)T₈P_c`, `U₁₂=(64/(5√13))T₁₂P_c`.

All cross-harmonic identities below require the same orthonormal register basis in all `U_n`; independently changing the bases would alter the cross contractions.

## 1. First selection rule: the degree-12 harmonic barrier

For `V_n=Sym^n(C²)` and the same subgroup `I`, the group-invariant intertwiner space is

`Hom_I(V_n,V_m) ≅ (V_n* ⊗ V_m)^I`, and the SU(2) Clebsch–Gordan decomposition is `V_n*⊗V_m = ⊕_{j=0}^{min(n,m)} V_{n+m−2j}`.

If `n≠m`, this tensor product contains no spin-zero term. As the first nonconstant `I` invariant is `V₁₂`, a necessary condition for a nonzero `I`-equivariant coupling is `n+m≥12` and `n+m` even. Accordingly, the first *allowed* higher partners of `n=3,4,5` are `m=9,8,7`, respectively. This constrains the face-graph harmonic mixing because its adjacency commutes with `I_L×I_R` and the degree-`n≤5` sampled modules are irreducible.

**Important:** “allowed” does not mean the coefficient is nonzero or that the graph preserves/equals a continuum harmonic operator. The source already demonstrates strictly positive leakage at degrees 3–5, but only these representation restrictions are new here.

## 2. Exact quadratic synthesis of the first icosahedral invariant

For any common orthonormal register basis `e_α`, `α=1,…,16`, write `f_{n,α}=U_ne_α` and define

`ρ_n(q)=Σ_α |f_{n,α}(q)|²`, `D_nm(q)=Σ_α f_{n,α}(q) overline(f_{m,α}(q))`.

These are independent of a **simultaneous** change of register basis. Since `P_c ≅ 4_L⊗4_R` is a real irreducible `I_L×I_R` module, `ρ_n` and `D_nm` are bi-`I` invariant. Their coordinate-polynomial degree is at most `2n` or `n+m` respectively. They are therefore confined to the finite Molien-invariant harmonic lines below that degree.

**New exact identities:**

\[
\boxed{\rho_6(q)=16+12C_{12}(q),\qquad \rho_8(q)=16+20C_{12}(q).}
\]

**Proof:** `ρ₆` and `ρ₈` are bi-`I` invariant polynomials of degrees 12 and 16. Up to degree 16 the only invariant scalar shells are the constant and degree 12, while Haar orthonormality gives their constant term `16`. The explicit 24-point Hurwitz sums at `q=1` give `b₆(1)_{aa}=−7/5`, `b₆(1)_{a≠b}=7/20`, and `b₈(1)_{aa}=9/5`, `b₈(1)_{a≠b}=−9/20`. Consequently `ρ₆(1)=28` and `ρ₈(1)=36`. Since `C₁₂(1)=1`, the displayed coefficients follow. Every finite number follows from exact rational arithmetic in the 600-member coset, not a fit.

The Riesz-representative harmonic already present in Paper I-C is `h₁₂=13C₁₂` (norm² 13). Thus a **new** realization of that already-existing harmonic is

\[
\boxed{h_{12}(q)=\frac{13}{12}(\rho_6(q)-16).}
\]

It is not a new origin theorem claiming that Paper I-C failed to derive `h₁₂`: it is a different explicit construction from the chamber-correlated sextic.

A direct pointwise consistency relation is `5(ρ₆−16)=3(ρ₈−16)`. At each `v∈V`, `(ρ₆,ρ₈)=(28,36)`; at each `c∈F`, `(ρ₆,ρ₈)=(49/4,39/4)`.

## 3. Exact cross-harmonic interference generates degrees 12 and 20

The following new matched-basis contractions hold **pointwise for every `q∈S³`**:

\[
\boxed{D_{6,8}=-4\sqrt{63}\,C_{12},\qquad D_{6,12}=-4\sqrt{91}\,C_{12},}
\]

\[
\boxed{D_{8,12}=\sqrt{13}\left(\frac{84}{17}C_{12}+\frac{120}{17}C_{20}\right).}
\]

**Proof:** Each cross term has zero Haar mean, because its factors have different round harmonic degrees. The degree budgets are 14, 18, and 20. Molien leaves exactly the `C₁₂` line in the first two and the `C₁₂,C₂₀` lines in the third. At `q=1`, the matched Hurwitz register sums yield `b₁₂(1)_{aa}=0`, `b₁₂(1)_{a≠b}=−65/64`, and contractions `b₆Pc b₈=−63/4`, `b₆Pc b₁₂=−455/64`, `b₈Pc b₁₂=585/64`. Thus the normalized cross values at the identity are `−4√63`, `−4√91`, and `12√13`. At the facet centre `q=u`, exact rational quaternion sums yield `b₈(u)^TP_cb₁₂(u)=2925/2048`, hence `D₈,₁₂(u)=(15/8)√13`. As `C₁₂(u)=−5/16`, `C₂₀(u)=31/64`, the unique two-equation solution is `84/17` and `120/17`. The accompanying exact-Q(√5) script replays all 600 coset sums.

These formulas supply a *recursive invariant extractor*, with no new source assumption:

\[
\boxed{C_{12}=\frac{\rho_6-16}{12},\qquad
C_{20}=\frac{17}{120\sqrt{13}}D_{8,12}-\frac7{10}C_{12}.}
\]

The appearance of `C₂₀` precisely at `8+12=20` explains a new **operator-level** failure of the degree-nineteen cubature, not just the previously known polynomial degree cutoff.

## 4. Two-orbit frame duality and a mathematically optimal alias repair

Each of the two node sets `V=I` and `F=IuI` is invariant under both left and right `I` actions. For each matched `4⊗4` carrier, its uniform node-sampling Gram must be scalar by Schur's lemma. For the combined 32-dimensional harmonic space `W₆⊕W₈`, in the matched register basis, the exact *per-orbit* Gram blocks are

\[
\boxed{G_V=\frac14\begin{pmatrix}7&-\sqrt{63}\\-\sqrt{63}&9\end{pmatrix}\otimes I_{16},\qquad
G_F=\frac1{64}\begin{pmatrix}49&5\sqrt{63}\\5\sqrt{63}&39\end{pmatrix}\otimes I_{16}.}
\]

`spec(G_V)={4,0}`: the 120 vertices see only 16 of these 32 directions. In fact

\[
\boxed{f_{8,x}(v)=-\frac3{\sqrt7}f_{6,x}(v)\quad\forall v\in V.}
\]

`spec(G_F)={21/16,1/16}`: the 600 facets alone reconstruct all 32 harmonic directions, with condition number `√21` of the sampling map and worst-case inverse singular value `4` in the chosen mean-square normalization.

The canonical positive 720-node weights eliminate the alias *exactly*:

\[
\boxed{\frac5{21}G_V+\frac{16}{21}G_F=I_{32}.}
\]

This is a new explicit demonstration that the 600 tetrahedral facet centres are not redundant decorations: they supply precisely the information missed by the 120 vertices in these harmonic sectors.

### Beyond band nine: a certified 48-dimensional comparison frame

Let `W₁₂,c=im(U₁₂)` denote only the correlated `4⊗4` part of degree 12. The 720-point weighted sample Gram on `W₆⊕W₈⊕W₁₂,c` is exactly

\[
\boxed{G_{720}^{(6,8,12)}=
\begin{pmatrix}
1&0&0\\0&1&\frac{15\sqrt{13}}{56}\\0&\frac{15\sqrt{13}}{56}&\frac{2795}{1792}
\end{pmatrix}\otimes I_{16}.}
\]

The upper two cross terms vanish by the degree-nineteen design (`6+8=14`, `6+12=18`). Only `8+12=20` aliases. The last diagonal entry follows from exact intensity values `ρ₁₂,c(v)=52` and `ρ₁₂,c(c)=4225/256` for vertices and facet centres. The remaining `2×2` determinant is exactly `7865/12544>0`. Thus **all 48 selected harmonic modes are recoverable** from the 720 nodes, although the full scalar band through degree 12 is not isometrically sampled. The Gram condition number of the associated evaluation map is approximately `2.88618`.

The nonzero weighted mean of the cross interference is

\[
\boxed{\nu_{720}(D_{8,12})=\frac{30\sqrt{13}}7\ne0
\quad\text{while}\quad \int_{S^3}D_{8,12}\,d\mu=0.}
\]

This is a concrete first degree-20 interaction witness for downstream finite spectral compilers.

## 5. Exact Hopf/Petersen/quartic-frame complementarity

Paper III-B's Petersen sextic `H₆^P` is the `A₅`-invariant spherical harmonic of degree 6. Paper III-C independently proves, on the unit `S²`, the five-conjugate-octahedral-frame squared-quartic identity

\[
B_8(v)=\sum_{i=1}^{5}Q_i(v)^2=\frac{16}{105}+\frac9{10}H_6^P(v),
\]

where one aligned fivefold axis `n` satisfies `H₆^P(n)=−32/189`. Mark the standard Hopf map `π_n(q)=q n q⁻¹`. A degree-six base harmonic lifts to a degree-twelve scalar harmonic on the round `S³` (`12·14=4·6·7=168`). Right `I` averaging of this lift is bi-`I` invariant; by the one-dimensional invariant line it must be `a C₁₂`. At `q=1`, its average equals `H₆^P(n)` by `A₅` invariance. Thus:

\[
\boxed{P_I^R(H_6^P\circ\pi_n)=-\frac{32}{189}C_{12},}
\]

\[
\boxed{P_I^R(B_8\circ\pi_n)=\frac{16}{105}(1-C_{12}).}
\]

Combining the latter with `ρ₆=16+12C₁₂` gives the positive complementary sum rule

\[
\boxed{\rho_6(q)+\frac{315}{4}\,P_I^R(B_8\circ\pi_n)(q)=28.}
\]

This is a **new exact cross-paper bridge** between the five-octahedral quartic-frame response and the sixteen-degree-six chamber-register harmonics. Both terms are nonnegative. It does not identify the scalar comparison with a physical `E₃₆` action or conserved mass-energy.

As an additional downstream consequence of the existing double-exceptional symmetrizer (`c₁₂²=11/32`), with `P_I^R, P_O^R` acting on the same right regular scalar representation, the bi-`I` Petersen lift obeys

\[
\boxed{(P_I^R P_O^R P_I^R)^k P_I^R(H_6^P\circ\pi_n)
=-\frac{32}{189}\left(\frac{11}{32}\right)^k C_{12}\qquad(k\ge0).}
\]

This describes convergence of finite mathematical symmetrizations, **not** a physical relaxation time.

## 6. Two-sided Hopf-charge factorization of the 41-state memory return

Choose `h∈I` of quaternion order ten, with `h⁵=−1∈H`. Left and right multiplication by `h` preserve `F=IuI` and permute the five left and five right core labels by independent five-cycles. This was verified by explicit action on **all 600 facets**, not inferred from dimensions.

On the complexified register space, a Fourier basis `e_{a,b}`, `a,b∈Z₅`, diagonalizes both five-cycles. It splits as

- `a=b=0` (one stationary mode),
- exactly one of `a,b` zero (eight additive modes),
- `a,b≠0` (all **sixteen** correlated modes, one copy of each joint nonzero charge).

The order-ten Hopf phases on the 600 facets restrict on registers to order-five phases; the corresponding fibre-frequency residues are even modulo ten, `2a,2b ∈{2,4,6,8}` for the correlated modes. All sixteen are present in the degree-six harmonic image `W₆` with identical squared Gram strength `7/16`.

With the already imported exact 41-state realization of the 600-chamber comparison walk, each correlated charge has **the same** hidden-observable two-state generator

\[
Q_c=\begin{pmatrix}-15/16&5\sqrt3/16\\5\sqrt3/16&-21/16\end{pmatrix},
\quad\lambda_\pm=\frac{-9\pm\sqrt{21}}8.
\]

The normalized observable return factor is

\[
f_c(t)=\left(\frac12+\frac3{4\sqrt{21}}\right)e^{\lambda_+t}
+\left(\frac12-\frac3{4\sqrt{21}}\right)e^{\lambda_-t}.
\]

Thus the 41-state minimal *linear* observable realization splits into `1` stationary + `8` additive + `16×2` correlated hidden/visible states. This is a **two-sided finite-charge selection law for a comparison walk**, not a physical particle lifetime or identified Hopf-time evolution.

## 6a. A positivity bound and an exact two-mode smoothing no-go

The two matched vectors in the 16-dimensional correlation register fibre have pointwise Gram

\[
\mathcal G(q)=\begin{pmatrix}16+12C_{12}(q)&-4\sqrt{63}C_{12}(q)\\-4\sqrt{63}C_{12}(q)&16+20C_{12}(q)\end{pmatrix}\succeq0.
\]

Its determinant is `256(1−C₁₂)(1+3C₁₂)`. Therefore

\[
\boxed{-\frac13\le C_{12}(q)\le1\quad\text{for every }q\in S^3.}
\]

This is a strictly stronger **proven** bound than `|C₁₂|≤1` from its unitary matrix-coefficient realization. Numerical multistart minimization on 40 random directions attained `−5/16` at facet-related directions but this **does not prove** that `−5/16` is the global minimum. A sharp extremality proof remains a valid separate research problem.

The existing aligned `2O`–`2I` alternating symmetrizer has nonconstant eigenvalues `11/32` on the degree-12 `I`-invariant line and `95/128` on degree 20. If a common round scalar heat time `t` reproduced these on both lines, it would simultaneously require

\[
\frac{t}{R^2}=\frac{\log(32/11)}{168}=0.006356194\ldots,
\qquad \frac{t}{R^2}=\frac{\log(128/95)}{440}=0.000677621\ldots,
\]

which is impossible. Thus the finite exceptional symmetrizer may be matched **on the observable degree-12 line alone**, but cannot be identified with one round-sphere heat step on both of the first two exceptional modes. This is a source-respecting two-observable test, not an interpretation of the finite averaging iteration as physical time.

## 7. What is genuinely new, and what remains unproved

**New mathematical deductions in v1.9:** degree-complement mixing criterion; rank-six/eight quadratic invariant synthesis; matched interference formulas including the exact `C₂₀` extractor; vertex alias and facet correction; 48-mode beyond-band exact positive frame; Hopf lift of the Petersen sextic to the `C₁₂` line; positive squared-quartic complement; finite-symmetrizer attenuation; and charge-resolved decomposition of the 41-state memory model.

**Not new and not reopened:** existence of the Petersen harmonic `H₆^P`, Paper I-C's degree-twelve harmonic `h₁₂`, the original 600-cell graph, the `E_n` protected hierarchy, G0/GP1–GP3, or the physical-source action ownership criteria. These appear as **imported premises**, with their original scopes intact.

**Frontier (explicitly open):** a same-owner source/action map identifying the analytic Hopf/Petersen readout with protected `E₃₆` or another physical observer source. Merely sharing the sextic, the `4⊗4` module, or its squared norm is insufficient. A physical decay/thermal/sky consequence would require an observable transfer with its own coefficients and normalization.

## 8. Verification and provenance

The accompanying exact checker generates all 120 quaternion vertices in `Q(√5)`, all 600 distinct facet centres, the complete 25-register assignment, exact `U₆,U₈,U₁₂` sums at a vertex and facet, and the rational contractions needed above. It separately recovers `C₁₂(u)=−5/16`, `C₂₀(u)=31/64` without floating point. The numerical checker independently reconstructs the 720-node values, frame Grams, invariant densities, Petersen Hopf average, and two-sided order-ten actions. They are **local executable certificates**, not a complete E3/E4 audit of the upstream papers.

The research archive contains only v1.9 additions and references to the already delivered v1.8 research. No canonical papers, DAG source registry, certified edges, audit statuses or prior ZIPs are updated in this release.
