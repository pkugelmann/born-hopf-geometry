# Born–Hopf Geometry — Cross-Paper DAG Research Supplement v1.8

**Date:** 15 November 2026  
**Status:** NEW, RESEARCH-ONLY MATHEMATICAL RESULTS. Neither papers nor canonical DAG nor audits were updated.  
**Frozen source corpus:** `Paper00-PapersMinimal-v3_017.zip` (`d01063dc99ebe2dc9e96cabae6a0b8098eea6196c0184fdaebb8b8c4400822f9`).  
**Frozen DAG:** `Paper00-DAGAtlas-v1_150.zip` (`efc742bbb68e8392906901b48c386b68c95a6ca21a8f84a14f52985c69023162`).  
**Frozen audits:** `Paper00-ProofChainAudits-v1_64.zip` (`99c9155eb8ff64395939bb9a6520772566e51939a10d87cbc47a7eec11056339`).  
**Verification method:** direct reading of the five relevant current paper sources and proposed earlier theorem modules; two independent finite constructions (exact quaternions in `Z[sqrt(5)]` and numerical matrix controls), exhaustive 625-block arithmetic for the new 25-register identity, exact 600-node adjacency/intertwining, exact 72-Hopf-base orbit enumeration, exact Legendre moments, and a 20-state Markov control. Compilation smoke test of five proposed source modules succeeded. **This is not a full independent E1/E3/E4 proof-chain audit of the revised papers.**

## Executive discoveries

The DAG's unusually productive junction is the shared geometry of the **600 tetrahedral facet centres**. They already support a 600-chamber four-neighbour graph, a 25-register double-coset partition, a positive 720-node spherical nineteen-design when combined with 120 vertices, and selected order-ten Hopf actions. The new deductions below use *the same fixed set*, not a newly postulated physical mechanism.

1. **Markov marginals, non-Markov joint:** both individual five-core labels are strongly Markov-lumpable from the complete 600-state chain, while the 25-pair observed return retains its exact 16-dimensional nondivisible memory.
2. **Dual Hopf quotient and a hidden 16-sector:** the 600 facet centres also form 60 left and 60 right ten-point Hopf orbits. Each orbit meets exactly five different chamber registers, twice each. The two independent fibre averages together measure only the nine-dimensional `1+4+4` additive sector; the sixteen-dimensional correlated sector is invisible to either phase-blind Hopf quotient.
3. **Exact full-register spectral recovery:** degree six and eight harmonics see only the 16 correlation directions. The first scalar harmonic degree to see all 25 chamber registers is **twelve**. Its exact Gram has strictly positive, rational eigenvalues, enabling a sharp inverse and error bound. The two kinds of information can also be recovered from a hybrid readout consisting of the two Hopf-base marginals and a degree-six harmonic readout.
4. **72-node Hopf base cubature and 385-mode charged frame:** the 720-node spherical nineteen-design descends to a positive 72-node spherical nine-design on `S²`. Its ten length-ten fibre-DFT blocks recover all 385 scalar `S³` modes through degree nine, including aliased charges.
5. **Support-optimality without a positivity assumption:** an explicit degree-20 scalar polynomial vanishes at *every one* of the 720 nodes but has integral 17. Thus no reassignment of weights (even signed) can improve degree nineteen on this fixed support. An analogous degree-ten obstruction proves degree nine is best possible on the 72 projected bases, for any weights.
6. **Auxiliary 20-state Markov dynamics from the directed nonet:** the twenty core-pair projectors induce a reversible Markov matrix with exact `1, 1/2, 1/10, 0` spectrum, and its first step enforces uniform incoming and outgoing five-core marginals for **arbitrary** initial laws.

No physical time, particle lifetime, scalar-to-CMB sky map, actual QCD transition, preferred Hopf direction, or new GP axiom is inferred.

## 1. Five-core strong lumping and a joint-only memory sector

**Existing sources** (Paper I-B v1.10): `p1:thm:v366-chamber-transporter-complement`, `p1b:thm:v16-register-resolvent`, `p1b:thm:cc13-register-memory`, `p1b:thm:cc14-no-time-local-markov`.

Let `A` be the 4-regular 600-by-600 facet-face adjacency and let `U_L,U_R` pull back functions on a single core label. The source proves that constant chamber functions have adjacency eigenvalue 4, while additive centred register arrays `a_i+b_j` are adjacency eigenvectors with eigenvalue -1. Therefore, without assuming a block-uniform initial law,

\[
\boxed{ A U_L = U_L(J_5-I_5),\qquad A U_R=U_R(J_5-I_5). }
\]

This was also checked **for every one of the 600 chambers using exact algebraic adjacency** (not numerical closeness). The continuous-time unit-rate chamber walk `Q=A/4-I` has two exact five-core Markov quotients, each with

\[
Q_5=\frac{J_5-5I_5}{4},\qquad
P_5(t)=\frac{J_5}{5}+e^{-5t/4}\left(I_5-\frac{J_5}{5}\right).
\]

Every other core is reached at rate `1/4` from the current core. This holds for **arbitrary initial chamber distributions** and is stronger than a statement about time-evolved block-uniform preparations.

Now write `Z=J5/5`, `Y=I5-Z` and the source 25-register projectors

\[
P_0=Z\otimes Z,\quad P_a=Z\otimes Y+Y\otimes Z,\quad P_c=Y\otimes Y,
\qquad \operatorname{rank}(P_0,P_a,P_c)=(1,8,16).
\]

For the exact registered-return family,

\[
M(t)=P_0+e^{-5t/4}P_a+f_c(t)P_c.
\]

The row and column marginal maps kill `P_c`; their stacked rank is nine, with kernel exactly the 16-dimensional `P_c` subspace. The `P_c` branch has a genuine Volterra memory and strictly negative time-local *register-only* intermediate transitions. **Therefore two exact Markov marginals coexist with a non-Markovian joint return.** It does not follow that the joint *physical* process is a quantum open system.

## 2. The exact 25-register ↔ 60 Hopf-fibre incidence

**Inputs:** the marked 2I/H facet double-coset theorem `p1b:thm:cc17-facet-double-coset` and the mathematical order-ten Hopf convention of Paper II-D `p2d:thm:cc14-hopf-120`. The chosen order-ten group `C10` acts freely on the 600 facets from either the left or right.

The complete exact-quaternion enumeration shows that there are exactly **60 ten-point left orbits** and **60 ten-point right orbits**. Each ten-point fibre contains two facets from each of five different 24-point registers; a 24-point register appears in twelve fibres. For left orbits, all five registers share the same **right** core label; the right orbits have fixed **left** core label.

For each family let `B` be its 25-by-60 binary register-to-fibre incidence matrix (entry 1 iff the intersection has two facets). Then

\[
\boxed{B_LB_L^T=12 J_5\otimes I_5,\qquad
B_RB_R^T=12 I_5\otimes J_5.}
\]

Both incidence matrices have rank exactly five. Their normalized fibre-averaging maps are `C_L=B_L^T/5`, `C_R=B_R^T/5`; hence

\[
\boxed{C_L^TC_L+C_R^TC_R
=\frac{24}{5}P_0+\frac{12}{5}P_a+0P_c.}
\]

The **combined two-sided Hopf-base measurement has rank nine** and condition number `sqrt(2)` on the nine observable directions. Its kernel is exactly the 16-dimensional correlated register sector. This is the algebraic meaning of the statement that the memory coordinates cannot be recovered from the two phase-blind Hopf marginals.

The result also gives a selection rule: for any scalar harmonic degree `n`, the signed harmonic synthesis of `x` in `im(P_c)` is orthogonal to **both** continuous Hopf-charge-zero test spaces. Indeed, each individual fibre sum of its ten register values is zero. Thus any proposed physical map from this correlation sector to a Hopf-basic observable requires a nontrivial phase-sensitive transfer; it cannot simply identify the two constructions.

## 3. The first full 25-register harmonic frame is at degree twelve

**Inputs:** Paper I-B's actual 600 facets, 25 blocks, 2T design, `U_n` scalar reproducing kernels, the ranks `1+8+16`, and the degree-six/eight frame lemma already integrated from v1.7.

With 600 facet centres `c` and `S=U/sqrt(24)`, define

\[
(K_n)_{cd}=\frac{n+1}{600}U_n(c\cdot d),\qquad B_n=S^T K_n S.
\]

The new exact algebra gives

\[
\boxed{B_6=\frac7{16}P_c,\quad B_8=\frac9{16}P_c,\quad B_{10}=0,}
\]
\[
\boxed{B_{12}=\frac{325}{256}P_0+
\frac{3003}{1024}P_a+
\frac{325}{4096}P_c.}
\]

All nonconstant degrees 1–5 are invisible, odd degrees are invisible by antipodality, and at degree 10 all entries vanish. The eight additive directions `P_a` first become visible at degree twelve; **all 25 directions are visible in degree twelve alone.**

The degree-twelve proof can be made entirely rational. The complete 25-by-25 Gram has four orbit types determined by whether two block labels match in the left or right index. The exact entries are:

| Pair of registers | Degree-12 entry |
|---|---:|
| Both indices equal | `26/25` |
| Exactly one index equal | `39/100` |
| Neither index equal | `-18499/102400` |

Diagonalization under `1+4+4+16` gives eigenvalues `325/256` (multiplicity 1), `3003/1024` (multiplicity 8) and `325/4096` (multiplicity 16). These fractions are not best fits: every one of the 625 block-pair sums was recomputed in the ring `Z[sqrt(5)]`, with all four orbit classes verified.

Let `T12=E12* S`, where `E12` is normalized scalar point evaluation from the continuous `S³` degree-12 harmonic space. Then `T12* T12=B12` and **exact reconstruction** is

\[
\boxed{x=B_{12}^{-1}T_{12}^*T_{12}x,\qquad
B_{12}^{-1}=\frac{256}{325}P_0+
\frac{1024}{3003}P_a+
\frac{4096}{325}P_c.}
\]

The noise amplification of this inverse is sharply bounded by `64/sqrt(325) ≈ 3.5501`. The degree-12-only condition number is `sqrt(12012/325) ≈ 6.0795`. Adding the *orthogonal harmonic readouts* for degrees 6 and 8 increases the correlation eigenvalue to `4421/4096` and improves the condition number to `sqrt(12012/4421) ≈ 1.6483`.

**A more efficient complementary readout** combines the two Hopf fibre-average maps with degree six alone:

\[
\boxed{C_L^TC_L+C_R^TC_R+T_6^*T_6
=\frac{24}{5}P_0+\frac{12}{5}P_a+\frac7{16}P_c>0.}
\]

This is full-rank at spectral degree six, with exact condition number `sqrt(384/35) ≈ 3.3123`. The two Hopf marginals recover the additive information, while degree six recovers the correlated information. It is a mathematical joint-measurement theorem, not an apparatus actually constituted by GP1–GP3.

**Dynamical consequence.** For the transfer traces `R_n(t)=Tr_{H_n}(T_n M(t) T_n*)`,

\[
\boxed{R_6(t)=7f_c(t),\qquad R_8(t)=9f_c(t),}
\]
\[
\boxed{R_{12}(t)=\frac{325}{256}(1+f_c(t))
+\frac{3003}{128}e^{-5t/4}.}
\]

They provide an *exact inverse witness* for the two different register relaxation laws. These are mathematical transfer traces, not thermal or sky correlators.

## 4. Seventy-two base points, ten Hopf-charge blocks, and an optimality obstruction

The vertex–facet union is the known positive **720-point spherical 19-design** on `S³`, with per-node weights `1/504` and `2/1575` for the 120 vertices and 600 facets. Marking an order-ten fibre subgroup gives twelve vertex fibres and sixty facet fibres. An exact quaternion computation confirms 72 distinct Hopf base points, ten nodes per fibre.

The induced `S²` measure has weights

\[
\boxed{w_V=\frac5{252}\ \text{per 12 vertex bases},\qquad
w_F=\frac4{315}\ \text{per 60 facet bases}.}
\]

Because the Hopf projection `S³ -> S²` is quadratic in quaternion coordinates, every base polynomial of degree at most nine pulls back to an `S³` polynomial of degree at most eighteen. Thus this is a **positive spherical 9-design on exactly 72 nodes**.

The exact scalar degree-nine `S³` band contains 385 modes. Performing a unitary 10-point DFT independently on each of the 72 Hopf fibres gives ten orthogonal sample-projector blocks, all with 72 rows and respective ranks

\[
\boxed{(25,40,33,46,37,48,37,46,33,40),\qquad\text{sum}=385.}
\]

This is a substantial upgrade from v1.4's 12-fibre/91-mode sampler: charge aliases caused by ten samples along an individual fibre are separated globally by the 72 base positions, exactly and without loss of rank.

**The support really has sharp finite strength.** For a chosen fivefold base axis `n`, exact Legendre moments give:

| Zonal harmonic | 12 vertex bases | 60 facet bases | Weighted 72-rule |
|---|---:|---:|---:|
| `P6(n·x)` | `11/25` | `-11/80` | `0` |
| `P10(n·x)` | `247/1875` | `7657/120000` | **`4199/52500`** |

The first alias at degree ten is nonzero. There is a still stronger statement: the same 72-node support cannot be reweighted into a degree-ten spherical cubature **even allowing signed weights**. Let

\[
a_\ell(x)=\frac1{12}\sum_{v\in V_{12}}P_\ell(v\cdot x),\quad
H_6=\frac{25}{11}a_6,\quad H_{10}=\frac{1875}{247}a_{10}.
\]

The two normalized icosahedral invariant harmonics take values `(1,-5/16)` and `(1,31/64)` on the vertex and facet base orbits. Consequently

\[
\boxed{q_{10}(x)=17+11H_6(x)-28H_{10}(x)}
\]

vanishes at all 72 support points but has spherical integral `17`. Any exact fixed-node quadrature fails on it, regardless of its weights.

The parent `S³` support has an analogous exact obstruction. Define

\[
C_n(q)=\frac1{120}\sum_{g\in2I}U_n(\operatorname{Re}(gq)),\quad n=12,20.
\]

The binary-icosahedral character averages take values `(1,-5/16)` and `(1,31/64)` on the 120 vertices and 600 facet centres. Then

\[
\boxed{Q_{20}(q)=17+11C_{12}(q)-28C_{20}(q)}
\]

vanishes at all 720 points while its Haar integral is `17`. This proves **the degree-19 rule is optimal for this fixed 720-node support, for every choice of weights**. It does *not* obstruct using different nodes or larger support.

## 5. New finite Markov law for the directed core-pair nonet

Condition on the existing mathematical twenty-projector construction (`p1:thm:cc12-directed-coherent-gram`), which is integrated as a scoped comparison and **does not establish an occurring QCD meson source**. With its rank-one projectors `H_ij`, define

\[
\boxed{K_{ij,kl}=\frac3{20}\operatorname{Tr}(H_{ij}H_{kl})
=\frac3{80}(1+n_{ij}\cdot n_{kl})^2.}
\]

This is a symmetric, doubly stochastic, nonnegative, positive semidefinite *classical* transition matrix. The Gram theorem immediately gives

\[
\boxed{\operatorname{spec}K=\{1^{(1)},(1/2)^{(3)},(1/10)^{(5)},0^{(11)}\}.}
\]

Each of the five outgoing four-projector core sets satisfies `sum_{j != i} H_ij=(4/3)I`. Hence **for any initial twenty-component probability law**, not merely one obtainable from a qutrit density matrix,

\[
\boxed{\sum_{j\ne i}(Kp)_{ij}
=\sum_{j\ne i}(Kp)_{ji}=\frac15.}
\]

The first Markov step instantly discards all eleven null directions and gives exactly uniform one-core marginals. Subsequent nonconstant modes relax with the exact eigenvalues `1/2` and `1/10`. Directed-pair transitivity yields the return-probability law

\[
\boxed{(K^k)_{aa}=\frac{1+3\,2^{-k}+5\,10^{-k}}{20},\qquad k\ge1.}
\]

The new chain and the 600-chamber example are deliberately **contrasting**: the 20-state chain is genuinely Markovian and instantly loses its one-core label, whereas the 600-state chain has one-core Markov quotients but a non-Markovian joint pair readout. This is a finite geometry/measurement comparison, not a derivation of meson decay widths.

## 6. DAG impact and source/claim types

| Proposed mathematical result | Actual current source owners | Downstream where it is consumable | Missing physical premise |
|---|---|---|---|
| Strong core lumpability | I-B source `v16-register-resolvent`; `cc14-no-time-local-markov` | I-B discrete dynamics; IV-B finite channels | Physical time and generated source/observer |
| Dual Hopf incidence and hidden 16 | I-B `cc17-facet-double-coset`; II-D `cc14-hopf-120` | II-D Hopf-charge comparisons; IV-B memory readout | Preferred physical Hopf circle; phase-sensitive physical coupling |
| Full degree-12 register inversion | I-B facet coordinates; I-C scalar spectral kernel | I-C/III-B scalar test operators; IV-B linear response | Action-owned mode/readout map |
| Hybrid `9+16` completeness | Core/Hopf incidence + degree-six Gram | II-D/IV-A measurement calculus | Actualized joint apparatus |
| 72-node base rule and 385-band DFT | I-B `cc17-positive-vertex-facet-19`; II-D charge normalization | II-D; III-B scalar tests; VI-B conditional angular comparisons | Observer/sky pushforward; no automatic CMB predictions |
| Fixed-support polynomial obstructions | I-B Molien/degree-12 and degree-20 overlaps | I-C/III-B certified sampling limits | None for mathematical no-go; physical consumers must respect sampling scope |
| Core-uniform directed Markov chain | I-B `cc12-directed-coherent-gram`; II-C `cc12-twenty-complex-povm` | IV-B; VII-B auxiliary nonet response | QCD action/source ownership and physical time/measurement |

**Status discipline.** All source results are read in their exact mathematical roles. New results are proposed source-ready theorems with runnable algebraic certificates, not canonical theorem nodes. Dependencies must be audited before promotion, and no claim about G0, GP1–GP3, physical mass, finite-QFT continuum limit or observational universe was altered.

## 7. Verification, limitations and next research steps

- **Exact algebraic controls:** 120 binary-icosahedral quaternions; 600 distinct facets; order-ten left/right Hopf orbits; 625/625 register-pair Gram class certificates; `n=0,6,8,10,12` exact harmonic sums; strict rational rank-25 at degree twelve; full 600-by-600 exact face adjacency with both strong lumping identities; rank-five incidence matrices and rank-nine joined quotient; exact 72 base points with 10 preimages each; exact Legendre moments and the degree-ten obstruction.
- **Independent numerical check:** the twenty directed-core projectors give a doubly stochastic reversible Markov matrix with the exact source-predicted spectrum and one-step uniform core marginals.
- **No model inflation:** the `S³` degree-twelve sampled harmonic Gram is not a proof that face-walk dynamics equals the scalar round Laplacian. Neither finite chain is a physical meson decay law. The two Hopf-circle directions are marked mathematical choices, not new GP-derived preferred axes. A probability sum rule on auxiliary channels is not an observed branching ratio.
- **Source quality:** the five proposed `.tex` modules compile together in a separate six-page mathematical smoke-test PDF. Compilation is a syntax check, not an independent mathematical correctness certificate.
- **Research-only release:** the ZIP carries the previous 24 latest-version research modules and five new modules, with exact-source validation scripts and a typed proposed dependency map. It does **not** overwrite `PapersMinimal-v3_017`, `DAGAtlas-v1_150`, or the v1.64 audit archive.

Potential next use: derive the entire **two-sided Hopf-charge spectrum** of the 16 correlation modes at the first visible scalar degree six, then compare its spectral poles with the 41-state minimal memory realization. This is a source-anchored mathematical next step, *not* yet a physical decay bridge.
