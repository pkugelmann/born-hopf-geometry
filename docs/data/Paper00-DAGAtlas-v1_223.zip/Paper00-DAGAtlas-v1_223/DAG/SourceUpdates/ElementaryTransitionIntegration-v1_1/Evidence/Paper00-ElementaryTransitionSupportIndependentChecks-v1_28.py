#!/usr/bin/env python3
"""Independent verification of Born--Hopf Elementary Transition Support v1_27.

Independent routes: A5 character-ring calculations, exact rational directed-pair
algebra, explicit rather than transported target-spin SU(2) generators, and
cross-package identity of the cubic W3 with the saved W56 decuplet component.

No physical Born 240x56 embedding or QCD action occurrence is assumed here.
Does not execute or import the v1_27 checker and does not overwrite it.
"""
from __future__ import annotations
import itertools
import json
import math
from pathlib import Path
import numpy as np
import sympy as sp

ROOT=Path(__file__).resolve().parent
mat=dict(np.load(ROOT/'Paper00-FiveCoreCubicIntertwiner-v1_27.npz'))

# Exact A5 character table, classes 1A, 2A, 3A, 5A, 5B.
r=sp.Rational
phi=(1+sp.sqrt(5))/2
phib=(1-sp.sqrt(5))/2
chi={
 '1':(1,1,1,1,1),
 '3':(3,-1,0,phi,phib),
 '3prime':(3,-1,0,phib,phi),
 '4':(4,0,1,-1,-1),
 '5':(5,1,-1,0,0)
}
chi={name:tuple(sp.sympify(x) for x in values) for name,values in chi.items()}
sizes=tuple(map(sp.Integer,(1,15,20,12,12)))
def mul(a,b):return tuple(sp.simplify(a[i]*b[i]) for i in range(5))
def ip(a,b):return sp.simplify(sum(sizes[i]*a[i]*b[i] for i in range(5))/60)
def decomp(ch):
    vals={name:ip(ch,v) for name,v in chi.items()}
    assert all(x.is_Integer for x in vals.values()), vals
    return {name:int(x) for name,x in vals.items()}
# Independently derive Sym^2 and Sym^3 from power-map character formulas.
p2=(0,0,2,4,3)
p3=(0,1,0,4,3)
c=chi['3']
sym2=tuple(sp.simplify(sp.Rational(1,2)*(c[i]**2+c[p2[i]])) for i in range(5))
sym3=tuple(sp.simplify(sp.Rational(1,6)*(c[i]**3+3*c[i]*c[p2[i]]+2*c[p3[i]])) for i in range(5))
assert decomp(sym2)=={'1':1,'3':0,'3prime':0,'4':0,'5':1}
assert decomp(sym3)=={'1':0,'3':1,'3prime':1,'4':1,'5':0}
# Pair fixed-point character and reversal even/odd from permutation cycle types.
nfixed=(5,1,2,0,0)
pair=tuple(n*(n-1) for n in nfixed)
even=(10,2,1,0,0)
odd=tuple(pair[i]-even[i] for i in range(5))
assert decomp(pair)=={'1':1,'3':1,'3prime':1,'4':2,'5':1}
assert decomp(even)=={'1':1,'3':0,'3prime':0,'4':1,'5':1}
assert decomp(odd)=={'1':0,'3':1,'3prime':1,'4':1,'5':0}
co=tuple(chi['3'][i]+chi['5'][i] for i in range(5))
cd=tuple(chi['3'][i]+chi['3prime'][i]+chi['4'][i] for i in range(5))
full=tuple(2*co[i]+4*cd[i] for i in range(5))
assert decomp(full)=={'1':0,'3':6,'3prime':4,'4':4,'5':2}
assert ip(cd,mul(co,co))==11
assert ip(cd,mul(co,chi['3']))==4
inv_8=11
inv_3=4
# Min A5 fiber dimension for the specified (1+4) core5 tensor product:
# each irrep of dimension >=3 contributes precisely one flavor triplet, while
# the trivial irrep contributes none. Thus 6 triplets require at least 6*3=18.
core5=tuple(chi['1'][i]+chi['4'][i] for i in range(5))
triplet_from_irrep={name:ip(mul(core5,ir),chi['3']) for name,ir in chi.items()}
assert triplet_from_irrep=={'1':0,'3':1,'3prime':1,'4':1,'5':1}
assert all(ip(mul(core5,chi['3']),ir)*6 >= ip(full,ir) for ir in chi.values())
min_fiber=18

# Exact rational 20-pair orientation algebra: independent of geometry data and the
# archived v1_27 code. Does not rely on floating projector traces.
labels=[(a,b) for a in range(5) for b in range(5) if a!=b]
A=sp.zeros(20,5);B=sp.zeros(20,5)
for j,(aa,bb) in enumerate(labels):
 A[j,aa]=r(1,2)
 B[j,bb]=r(1,2)
P=A*A.T;Q=B*B.T
K=P*Q-Q*P
assert K**3+r(15,256)*K==sp.zeros(20)
Pori=-r(256,15)*K**2
assert Pori**2==Pori
assert Pori.rank()==8
assert sp.trace(K*K)==-r(15,32)

# Independently verify the saved numerical cubic W3, its canonically normalized
# five-core augmentation, and saved 56-state unitary.
norm=np.linalg.norm
W=mat['cubic_W'];Pstd=mat['five_core_augmentation']; Hbasis=mat['physical_spin_basis']
W56=mat['physical_56_to_fivecore_chart']
err_cubic=float(norm(W@W.conj().T-Pstd))
err_unitary=float(norm(W56.conj().T@W56-np.eye(56)))
assert err_cubic<1e-12 and err_unitary<1e-12

# The v1_27 cubic W3 and its 56-state chart were constructed with *separate*
# maps. Extract the highest-spin decuplet cubic component in a canonical 10-state
# flavor occupation basis and compare it directly to W3. No icosahedral group
# average / quaternion geometry code is imported.
occs3=list(itertools.combinations_with_replacement(range(3),3))
occs6=list(itertools.combinations_with_replacement(range(6),3))
E=np.eye(56)[:,[occs6.index(x) for x in occs3]]
Hd=Hbasis[:,16:26]
Wd=mat['decuplet_reduced_intertwiner'];Tdc=mat['decuplet_cubic_basis']
W_from_56=Tdc@Wd[6:,:]@Hd.conj().T@E
phase=np.vdot(W,W_from_56)/np.vdot(W,W)
err_bridge=float(norm(W_from_56-phase*W))
assert abs(abs(phase)-1)<1e-12 and err_bridge<1e-12

# Adversarial SU2 check: compare with externally specified target ladder matrices
# rather than with W S W† itself (the latter would be a tautological test).
occi={tuple(x.count(i) for i in range(6)):j for j,x in enumerate(occs6)}
def dgamma(T):
 out=np.zeros((56,56),complex)
 for col,seq in enumerate(occs6):
  n=[seq.count(k) for k in range(6)]
  for a in range(6):
   for b in range(6):
    if not n[b] or abs(T[a,b])<1e-14:continue
    nn=n.copy()
    if a==b: amp=n[b]
    else:
     amp=math.sqrt(n[b]*(n[a]+1))
     nn[b]-=1;nn[a]+=1
    out[occi[tuple(nn)],col]+=amp*T[a,b]
 return out
pauli=[np.array([[0,1],[1,0]],complex)/2,
       np.array([[0,-1j],[1j,0]],complex)/2,
       np.diag([.5,-.5]).astype(complex)]
Ss=[dgamma(np.kron(p,np.eye(3))) for p in pauli]
def spin(j):
 d=int(2*j+1);m=[j-i for i in range(d)]
 jp=np.zeros((d,d),complex)
 for idx in range(1,d):
  x=m[idx];jp[idx-1,idx]=math.sqrt((j-x)*(j+x+1))
 jm=jp.conj().T
 return ((jp+jm)/2,(jp-jm)/(2*1j),np.diag(m))
sp8=spin(.5);sp10=spin(1.5)
spin_errors=[]
for axis in range(3):
 target=np.zeros((56,56),complex)
 target[:16,:16]=np.kron(sp8[axis],np.eye(8))
 target[16:,16:]=np.kron(sp10[axis],np.eye(10))
 e=float(norm(W56@Ss[axis]-target@W56))
 spin_errors.append(e)
 assert e<1e-12

# Identity of the orientation quarter-turn in the *stored* bridge maps.
He=np.asarray(sp.I*16/sp.sqrt(15)*K).astype(complex)
Je=mat['cubic_to_even_orientation'];Jo=mat['cubic_to_odd_orientation']
err_qturn=float(norm(He@Je+1j*Jo))
err_qturn2=float(norm(He@Jo-1j*Je))
err_qorth=float(norm(Je.conj().T@Jo))
assert max(err_qturn,err_qturn2,err_qorth)<1e-12
# Direct physical axial pair blocks are zero: test via exact character projectors
# already supplied in v1_27 archive.
Poct=mat['pair_octet_8'];Pdec=mat['pair_decuplet_6']
block_errors=[float(norm(Poct@He@Poct)),float(norm(Pdec@He@Pdec)),float(norm(Poct@He@Pdec))]
assert max(block_errors)<1e-12

out={
 'input_version':'v1_27','independent_checker_version':'v1_28',
 'sym2_icosahedral_decomposition':decomp(sym2),
 'sym3_icosahedral_decomposition':decomp(sym3),
 'directed_pairs_decomposition':decomp(pair),
 'even_pairs_decomposition':decomp(even),
 'odd_pairs_decomposition':decomp(odd),
 'source_56_icosahedral_decomposition':decomp(full),
 'invariants_decuplet_to_octet_plus_octet':inv_8,
 'invariants_decuplet_to_octet_plus_triplet':inv_3,
 'rank5_port_min_fiber_dimension_A5_only':min_fiber,
 'exact_rational_ori_projector_rank':int(Pori.rank()),
 'exact_rational_K_squared_trace':str(sp.trace(K*K)),
 'numerical':{
  'cubic_5_by_10_row_Gram_residual':err_cubic,
  'W56_unitarity_residual':err_unitary,
  'W56_decuplet_cubic_bridge_relative_phase':{'real':float(np.real(phase)),'imag':float(np.imag(phase))},
  'W56_decuplet_cubic_bridge_residual':err_bridge,
  'independent_target_spin_generator_residuals':spin_errors,
  'oriented_quarter_turn_residuals':[err_qturn,err_qturn2,err_qorth],
  'direct_pair_axial_blocks':[float(x) for x in block_errors]
 },
 'verdict':{
  'finite_representation_results':'VERIFIED',
  'source_action_endpoint_identity':'NOT_ESTABLISHED',
  'physical_mass_poles_or_decay_widths':'NOT_ESTABLISHED',
  'original_v1_27_SU2_test':'TAUTOLOGICAL_BUT_INDEPENDENT_TARGET_TEST_PASSES'
 }
}
(ROOT/'Paper00-ElementaryTransitionSupportIndependentVerification-v1_28.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
