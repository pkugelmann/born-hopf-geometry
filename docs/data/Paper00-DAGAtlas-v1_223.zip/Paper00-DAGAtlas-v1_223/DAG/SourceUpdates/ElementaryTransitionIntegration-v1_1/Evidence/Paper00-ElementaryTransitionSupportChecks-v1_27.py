#!/usr/bin/env python3
"""Born-Hopf v1_27. Exact five-core cubic and 56-state endpoint tests.

Reads original S3StructureNetwork v1_41 (120 quaternion vertices).
The v1_26 finite oriented-core operator is reconstructed from 20 pairs.
No observed hadron masses or decay
widths are used. Each geometric statement is checked directly.
Physical action occurrence and current coefficients are not certified.
"""
from __future__ import annotations
from numpy.linalg import norm
import numpy as np, json, zipfile, itertools, math
from pathlib import Path
R=Path(__file__).resolve().parent
with zipfile.ZipFile(R/'Paper00-S3StructureNetwork-v1_41(1).zip') as z:
 data=json.loads(z.read(next(k for k in z.namelist() if k.endswith('exceptional_600cell_instance.json'))))
sq5=math.sqrt(5)
q=np.array([[(a+b*sq5)/4 for a,b in v['qcoords']] for v in data['vertices']],float)
H=list(data['tetrahedral_core_vertex_ids'])
def mul(x,y):
 a,b,c,d=x;A,B,C,D=y
 return np.array([a*A-b*B-c*C-d*D,a*B+b*A+c*D-d*C,a*C-b*D+c*A+d*B,a*D+b*C-c*B+d*A])
def conj(x):return x*np.array([1,-1,-1,-1])
def rot(g):return np.column_stack([mul(mul(g,np.r_[0.,np.eye(3)[j]]),conj(g))[1:] for j in range(3)])
def act(g,i):
 p=mul(mul(g,q[i]),conj(g)); overlap=q@p; idx=int(np.argmax(overlap)); assert overlap[idx]>1-1e-9;return idx
cores=sorted(set(tuple(sorted(act(g,h) for h in H)) for g in q)); assert len(cores)==5
cs={c:i for i,c in enumerate(cores)}
perms=[];rots=[]
for g in q:
 perm=[]
 for c in cores:
  im=tuple(sorted(act(g,h) for h in c));perm.append(cs[im])
 perms.append(perm);rots.append(rot(g))
# Symmetric cubic occupancy basis in (C3)^⊗3
sym_occ=list(itertools.combinations_with_replacement(range(3),3));assert len(sym_occ)==10
B=np.zeros((27,10)); idx={occ:k for k,occ in enumerate(sym_occ)}
for cols,occ in enumerate(sym_occ):
 triples=sorted(set(itertools.permutations(occ)))
 for tri in triples:B[np.ravel_multi_index(tri,(3,3,3)),cols]=1/math.sqrt(len(triples))
assert np.linalg.norm(B.T@B-np.eye(10))<1e-14
# contraction trace to rank1 spin (totally symmetric T_{iik})
L=np.zeros((3,10))
for k in range(3):
 for a in range(3):L[k]+=B[np.ravel_multi_index((a,a,k),(3,3,3))]
P_h=np.eye(10)-L.T@np.linalg.inv(L@L.T)@L
assert np.linalg.norm(P_h@P_h-P_h)<1e-12 and round(np.trace(P_h))==7
Ds=[]; Pg=[]
for rotg,perm in zip(rots,perms):
 D=B.T@np.kron(np.kron(rotg,rotg),rotg)@B
 assert np.linalg.norm(D@D.T-np.eye(10))<4e-12
 Ds.append(D)
 P=np.zeros((5,5));P[perm,np.arange(5)]=1;Pg.append(P)
Pstd=np.eye(5)-np.ones((5,5))/5
# seed into xyz from stabilizer of first core, corresponds to tetrahedral cubic harmonic
seed=np.zeros((5,10));seed[0,sym_occ.index((0,1,2))]=1
stabilizer=[j for j,perm in enumerate(perms) if perm[0]==0]
assert len(stabilizer)==24   # 12 tetrahedral rotations, each with ± binary lift
assert max(np.linalg.norm(Ds[j]@seed[0]-seed[0]) for j in stabilizer)<1e-12
W=sum((Pg_g@seed@Dg.T for Pg_g,Dg in zip(Pg,Ds)),np.zeros((5,10)))/len(q)
W=Pstd@W@P_h
scale=np.trace(W@W.T)/4
print('cubic scale',scale,'rank',np.linalg.matrix_rank(W),'Wnorm',np.linalg.norm(W))
W=W/math.sqrt(scale)
assert np.linalg.norm(W@W.T-Pstd)<2e-11
P4harm=W.T@W
assert np.linalg.norm(P4harm@P4harm-P4harm)<2e-11
for j in range(0,120,7):
 assert np.linalg.norm(Pg[j]@W-W@Ds[j])<3e-11
assert np.linalg.norm(W@L.T)<2e-11
# core cubic row sources a tight simplex of harmonic cubics
print('cube row Gram=',np.round(W@W.T,7),'harmonic7 rank',np.trace(P_h),'all true')
# Sym^2 representative check: no A5 four at quadratic order. class-character projector on n=10 cube.
C4=np.zeros((10,10))
for perm,D in zip(perms,Ds):C4+=(4/120)*(sum(perm[i]==i for i in range(5))-1)*D
assert np.linalg.norm(C4-P4harm)<2e-11
# induced even and odd directed-pair irreps from characters
pairs=[(a,b) for a in range(5) for b in range(5) if a!=b]; pairind={v:i for i,v in enumerate(pairs)}
Rev=np.zeros((20,20))
for i,(a,b) in enumerate(pairs): Rev[pairind[(b,a)],i]=1
Pa={k:np.zeros((20,20)) for k in ['3','3p','5']}
for rotg,perm in zip(rots,perms):
 Dpair=np.zeros((20,20))
 for i,(a,b) in enumerate(pairs):Dpair[pairind[(perm[a],perm[b])],i]=1
 tr=np.trace(rotg); tr2=np.trace(rotg@rotg)
 ch3=tr;ch5=(tr**2+tr2)/2-1
 # for 5-cycles, 3prime= other triplet; general use class character fivefold via root 3' relation
 # 3+3prime character at classes follows wedge2 standard4, character of wedge²permStd = .5*(chi4(g)^2-chi4(g²))
 c4=sum(perm[i]==i for i in range(5))-1
 perm2=[perm[perm[i]] for i in range(5)]
 c4g2=sum(perm2[i]==i for i in range(5))-1
 c3sum=(c4*c4-c4g2)/2
 ch3p=c3sum-ch3
 for k,ch in [('3',ch3),('3p',ch3p),('5',ch5)]:Pa[k]+=({'3':3,'3p':3,'5':5}[k]/120)*ch*Dpair
for k,p in Pa.items():
 print('pair projector',k,round(np.trace(p),7),'reversal sign even',np.linalg.norm(Rev@p-((-1 if k in ('3','3p') else 1)*p)))
 assert np.linalg.norm(p@p-p)<5e-11
 assert np.linalg.norm(p-p.T)<5e-11
 # verify that p_3 and p_3p are odd; p5 even
 assert np.linalg.norm(Rev@p-((-1 if k in ('3','3p') else 1)*p))<5e-11
print('P3/P3p cross=',np.linalg.norm(Pa['3']@Pa['3p']))
# consistency of canonical octet and decuplet flavor carriers
Oct=Pa['3']+Pa['5'];Dpair=Pa['3']+Pa['3p']
assert np.linalg.norm(Oct@Oct-Oct)<1e-11 and round(np.trace(Oct))==8
assert np.linalg.norm(Dpair@Dpair-Dpair)<1e-11 and round(np.trace(Dpair))==6
# decuplet flavor10 is isomorphic to pair odd6 + 5core cubic4 (as abstract A5 reps)
print('PASS all cubic-fiber, 20-pair and A5 equivariance tests')
pa=Pa; pstd=Pstd
np.random.seed(20261120)
# symmetric cube for 6 components, using established Sym^3(C2 x C3) occupation basis
occs=list(itertools.combinations_with_replacement(range(6),3))
B6=np.zeros((216,56))
for col,occ in enumerate(occs):
 triples=set(itertools.permutations(occ))
 for tri in triples:B6[np.ravel_multi_index(tri,(6,6,6)),col]=1/math.sqrt(len(triples))
assert norm(B6.T@B6-np.eye(56))<1e-13
occ_n=[tuple(p.count(k) for k in range(6)) for p in occs]
occ_idx={n:i for i,n in enumerate(occ_n)}
def dgamma(mat):
 out=np.zeros((56,56),complex)
 for j,n in enumerate(occ_n):
  for aa in range(6):
   for b in range(6):
    if n[b]==0 or abs(mat[aa,b])<1e-13:continue
    nn=list(n);nn[b]-=1;nn[aa]+=1
    amp=n[aa] if aa==b else math.sqrt(n[b]*(n[aa]+1))
    out[occ_idx[tuple(nn)],j]+=amp*mat[aa,b]
 return out
sx=np.array([[0,1],[1,0]],complex)/2
sy=np.array([[0,-1j],[1j,0]],complex)/2
sz=np.diag([.5,-.5]).astype(complex)
S=np.array([dgamma(np.kron(s,np.eye(3))) for s in [sx,sy,sz]])
S2=sum(s@s for s in S)
P8=(3.75*np.eye(56)-S2)/3
P10=np.eye(56)-P8
print('spin sources projector',np.trace(P8),np.trace(P10),norm(P8@P8-P8))
Sminus=S[0]-1j*S[1]
diagz=np.real(np.diag(S[2]))
def top_basis(which,spin_z,rank):
 inds=np.where(np.isclose(diagz,spin_z))[0]
 proj=(P8 if which=='oct' else P10)[np.ix_(inds,inds)]
 vals,U=np.linalg.eigh(proj)
 keep=U[:,vals>.5]
 assert keep.shape[1]==rank,(which,keep.shape)
 res=np.zeros((56,rank),complex);res[inds,:]=keep
 return res
Ho=top_basis('oct',.5,8)
Hd=top_basis('dec',1.5,10)
Ho2=Sminus@Ho
D1=Sminus@Hd/math.sqrt(3)
D2=Sminus@D1/2
D3=Sminus@D2/math.sqrt(3)
Hbasis=np.column_stack([Ho,Ho2,Hd,D1,D2,D3])
assert norm(Hbasis.conj().T@Hbasis-np.eye(56))<1e-10
print('spin factor complete',Hbasis.shape)
# Target pair and core reduced icosahedral reps
P_oct=pa['3']+pa['5'];P_dec6=pa['3']+pa['3p']
def eigbasis(P,r):
 evals,U=np.linalg.eigh(P)
 res=U[:,evals>.5]
 assert res.shape[1]==r
 return res
To=eigbasis(P_oct,8);Tdp=eigbasis(P_dec6,6);Tdc=eigbasis(pstd,4)
# representative rotations unique A5 elements (q,+-q share same rotation and core perm)
indices=[];seen=set()
for i,perm in enumerate(perms):
 key=tuple(perm)
 if key not in seen:indices.append(i);seen.add(key)
assert len(indices)==60
rs=[];rtos=[];rtds=[]
for gi in indices:
 rotg,perm=rots[gi],perms[gi]
 R6=np.kron(np.eye(2),rotg)
 symg=B6.T@np.kron(np.kron(R6,R6),R6)@B6
 assert norm(symg.T@symg-np.eye(56))<1e-11
 src_o=Ho.conj().T@symg@Ho
 src_d=Hd.conj().T@symg@Hd
 Ppair=np.zeros((20,20));Pc=np.zeros((5,5))
 for i,(x,y) in enumerate(pairs):Ppair[pairind[(perm[x],perm[y])],i]=1
 Pc[perm,np.arange(5)]=1
 tar_o=To.T@Ppair@To
 tar_dp=Tdp.T@Ppair@Tdp
 tar_dc=Tdc.T@Pc@Tdc
 tar_d=np.zeros((10,10));tar_d[:6,:6]=tar_dp;tar_d[6:,6:]=tar_dc
 rs.append((symg,src_o,src_d)); rtos.append(tar_o);rtds.append(tar_d)
for srcs,tars in [(np.array([e[1] for e in rs]),np.array(rtos)),(np.array([e[2] for e in rs]),np.array(rtds))]:
 n=srcs.shape[1]
 seed=np.random.randn(n,n)
 inter=sum(t@seed@s.T for t,s in zip(tars,srcs))/60
 U,svals,Vh=np.linalg.svd(inter)
 w=U@Vh
 print('intertwiner dim',n,'singvals',np.round(svals,8),'max err',max(norm(t@w-w@s) for t,s in zip(tars,srcs)))
 assert min(svals)>1e-5
 assert max(norm(t@w-w@s) for t,s in zip(tars,srcs))<1e-10
 if n==8:Wo=w
 else:Wd=w
# Physical 56 -> core geometry 56, ordered oct spin2, dec spin4
W56=np.zeros((56,56),complex)
start=0
for w in [Wo,Wo,Wd,Wd,Wd,Wd]:
 d=w.shape[0];W56[start:start+d,start:start+d]=w;start+=d
W56=W56@Hbasis.conj().T
assert norm(W56.conj().T@W56-np.eye(56))<1e-10
max56_equiv=0.0
for i,(symg,src_o,src_d) in enumerate(rs):
 tar=np.zeros((56,56))
 st=0
 for mat in [rtos[i],rtos[i],rtds[i],rtds[i],rtds[i],rtds[i]]:
  n=len(mat);tar[st:st+n,st:st+n]=mat;st+=n
 max56_equiv=max(max56_equiv,float(norm(tar@W56-W56@symg)))
 assert max56_equiv<1e-9
print('PASS full 56-state A5 and SU2 intertwiner, norm',norm(W56.conj().T@W56-np.eye(56)))
# physical SU2 spin matrices in target have standard ladder structure automatically.
for s in S:
 j=W56@s@W56.conj().T
 assert norm(j@j.conj().T-(W56@s@s.conj().T@W56.conj().T))<1e-10
# module-space target oct/flavor 8, dec/flavor 10 exact
print('target Pauli-geometry 2x8 plus4x10 =',2*8+4*10)

# Additional dynamics and representation-selection checks.
# Rebuild the oriented 20-pair parent directly, no auxiliary files required.
U20=np.zeros((20,5));V20=np.zeros((20,5))
for j,(aa,bb) in enumerate(pairs):
    U20[j,aa]=.5;V20[j,bb]=.5
Pout=U20@U20.T;Pin=V20@V20.T
Kori=Pout@Pin-Pin@Pout
Hori=1j*16/math.sqrt(15)*Kori
Pori=-256/15*(Kori@Kori)
assert norm(Kori@Kori@Kori+15/256*Kori)<1e-12
assert norm(Pori@Pori-Pori)<1e-12
ori_norms={
  'octet':float(norm(P_oct@Hori@P_oct)),
  'decuplet_pair':float(norm(P_dec6@Hori@P_dec6)),
  'cross':float(norm(P_oct@Hori@P_dec6)),
}
assert max(ori_norms.values())<1e-12

lam=np.array([
 [[0,1,0],[1,0,0],[0,0,0]],
 [[0,-1j,0],[1j,0,0],[0,0,0]],
 np.diag([1,-1,0]),
 [[0,0,1],[0,0,0],[1,0,0]],
 [[0,0,-1j],[0,0,0],[1j,0,0]],
 [[0,0,0],[0,0,1],[0,1,0]],
 [[0,0,0],[0,0,-1j],[0,1j,0]],
 np.diag([1,1,-2])/math.sqrt(3)],complex)
pauli=[2*sx,2*sy,2*sz]
G=[dgamma(np.kron(p/2,L/2)) for p in pauli for L in lam]
Cg=sum((g@g for g in G),np.zeros((56,56),complex))
assert norm(Cg-19/4*P8-7/2*P10)<1e-10
WtCg=W56@Cg@W56.conj().T
P8_t=np.diag(np.r_[np.ones(16),np.zeros(40)])
P10_t=np.eye(56)-P8_t
assert norm(WtCg-19/4*P8_t-7/2*P10_t)<1e-10
cross_strength=sum(norm(P8@g@P10)**2 for g in G)
assert abs(cross_strength-40)<1e-10

# Symmetry multiplicity / three-core selection theorem, exact character algebra.
import sympy as sp
phi=(1+sp.sqrt(5))/2;phi2=(1-sp.sqrt(5))/2
chars={
 '1':[1,1,1,1,1],
 '3':[3,-1,0,phi,phi2],
 '3prime':[3,-1,0,phi2,phi],
 '4':[4,0,1,-1,-1],
 '5':[5,1,-1,0,0]
}
orders=[1,15,20,12,12]
def inner(u,v):return sp.simplify(sum(orders[i]*u[i]*sp.conjugate(v[i]) for i in range(5))/60)
def tens(u,v):return [u[i]*v[i] for i in range(5)]
# 3⊗3 = 1 ⊕ 3 ⊕ 5; Sym²3=1⊕5; Sym³3=3⊕3prime⊕4.
for pch in [chars['3'], [chars['1'][i]+chars['5'][i] for i in range(5)]]:
 assert inner(pch,chars['4'])==0
sym3char=[sum(chars[x][i] for x in ('3','3prime','4')) for i in range(5)]
assert inner(sym3char,chars['4'])==1
H56_char=[2*(chars['3'][i]+chars['5'][i])+4*sym3char[i] for i in range(5)]
assert [inner(H56_char,chars[k]) for k in chars]==[0,6,4,4,2]
# Pair20 rank-five outgoing port is 1⊕4. Its tensor product with a minimal
# 18-dimensional fiber (six copies of 3) contains the full 56-state module.
core5char=[chars['1'][i]+chars['4'][i] for i in range(5)]
prod5x3=tens(core5char,chars['3'])
assert {k:inner(prod5x3,chars[k]) for k in chars}=={'1':0,'3':1,'3prime':1,'4':1,'5':1}
assert all(6*inner(prod5x3,chars[k])>=inner(H56_char,chars[k]) for k in chars)
# Nonredundant flavor target: octet 8 from pair (3+5); decuplet 10 from (3+3prime)+cubic 4.
assert int(round(np.trace(P_oct)))==8 and int(round(np.trace(P_dec6)))==6


# Canonical cubic four -> two oriented fourfold auxiliary channels.
We=math.sqrt(2/3)*(U20+V20)@Pstd
Wo_odd=math.sqrt(2/5)*(U20-V20)@Pstd
Ho=Hori
Je=We@W
Jo=Wo_odd@W
assert norm(Je.conj().T@Je-P4harm)<1e-11
assert norm(Jo.conj().T@Jo-P4harm)<1e-11
assert norm(Je.conj().T@Jo)<1e-11
assert norm(Ho@Je+1j*Jo)<1e-11
assert norm(Ho@Jo-1j*Je)<1e-11
for k in range(120):
    perm=perms[k]
    Ppair_g=np.zeros((20,20))
    for j,(aa,bb) in enumerate(pairs):
        Ppair_g[pairind[(perm[aa],perm[bb])],j]=1
    assert norm(Ppair_g@Je-Je@Ds[k])<1e-11
    assert norm(Ppair_g@Jo-Jo@Ds[k])<1e-11
for zv in [2.,3.14+0.2j]:
    resol=np.linalg.inv(zv*np.eye(20)-Ho)
    assert norm(Je.conj().T@resol@Je-zv/(zv*zv-1)*P4harm)<1e-11
    assert norm(Jo.conj().T@resol@Je+1j/(zv*zv-1)*P4harm)<1e-11

char_oct=[chars['3'][i]+chars['5'][i] for i in range(5)]
char_dec=[chars['3'][i]+chars['3prime'][i]+chars['4'][i] for i in range(5)]
assert inner(char_dec,tens(char_oct,char_oct))==11
assert inner(char_dec,tens(char_oct,chars['3']))==4
assert inner(chars['3'],tens(chars['4'],chars['4']))==1
assert inner(chars['5'],tens(chars['4'],chars['4']))==1

payload={
 'source':'S3StructureNetwork v1_41, PapersMinimal v3_065; prior v1_26 oriented-core port',
 'result':'explicit 56-state A5 x Spin(3) intertwiner through five-core pair and cubic carriers',
 'checks':{
  'cubic_four_rank':int(np.linalg.matrix_rank(W)),'cubic_Gram_max_residual':float(norm(W@W.T-Pstd)),
  'cubic_equivariance_max_residual':float(max(norm(Pg[j]@W-W@Ds[j]) for j in range(120))),
  'physical_56_isometry_residual':float(norm(W56.conj().T@W56-np.eye(56))),
  'a5_equivariance_full56_max_residual':max56_equiv,
  'octet_decuplet_gram_residual':float(norm(WtCg-19/4*P8_t-7/2*P10_t)),
  'axial_octet_decuplet_total_squared_strength':cross_strength,
  'oriented_parent_direct_physical_block_norms':ori_norms,
  'minimal_native_fiber_dimension_for_rank5_core_port':18,
  'cubic_orientation_quarter_turn_residual':float(norm(Ho@Je+1j*Jo)),
  'A5_trilinear_invariants_dec_to_oct_pseudoscalar_octet':11,
  'A5_trilinear_invariants_dec_to_oct_pion3':4
 },
 'status':{
  'five_core_cubic_irrep_unique':True,'explicit_A5_spin_SU2_isometry':True,
  'physical_Born_action_selects_chart':False,'physical_mass_poles_determined':False,
  'oriented_parent_alone_is_physical_axial_vertex':False
 },
 'note':'The 56-state map is an exact representation-level intertwiner. Inter-irrep phases and Born-transport occurrence remain open.'
}
(R/'Paper00-ElementaryTransitionSupportVerification-v1_27.json').write_text(json.dumps(payload,indent=2,default=str)+'\n')
np.savez_compressed(R/'Paper00-FiveCoreCubicIntertwiner-v1_27.npz',
    cubic_W=W, harmonic_projector=P_h, cubic_four_projector=P4harm,
    five_core_augmentation=Pstd, pair_projector_3=Pa['3'],
    pair_projector_3prime=Pa['3p'],pair_projector_5=Pa['5'],
    pair_octet_8=P_oct,pair_decuplet_6=P_dec6,
    octet_target_basis=To, decuplet_pair_basis=Tdp,
    decuplet_cubic_basis=Tdc, octet_reduced_intertwiner=Wo,
    decuplet_reduced_intertwiner=Wd, physical_56_to_fivecore_chart=W56,
    physical_spin_basis=Hbasis, cubic_to_even_orientation=Je,
    cubic_to_odd_orientation=Jo, source_octet_projector=P8,
    source_decuplet_projector=P10)
print('PASS v1_27: cubic, full 56-state isometry, A5-spin covariance, axial Gram, oriented-parent obstruction')
