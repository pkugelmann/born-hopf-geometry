# Born–Hopf Geometry — Framework Source Integration v1_1

**Paper release:** `Paper00-PapersMinimal-v3_024.zip` (three revised papers, 31 TeX sources total).  
**DAG release:** `Paper00-DAGAtlas-v1_165.zip`.  
**Source baseline:** `Paper00-PapersMinimal-v3_023(1).zip`; mathematical evidence: semantic audits v1_7 and v1_8.  
**Scope:** finite-source mathematical theorem integration, without changing G0 or GP1–GP3 or closing a physical charged-source condition.

## Published results and destinations

| Current source | Source label | Mathematical content | Status boundary |
|---|---|---|---|
| Paper5A-FiniteMatterGeometry-v3_212.tex | `p5:cor:v3024-primitive-hierarchy-defect` | `Delta_hier(lambda I_3)=4/9` and nonzero scalar invariance | Fixed-chart identity; no native noncentral contraction |
| Paper5A-FiniteMatterGeometry-v3_212.tex | `p5:cor:v3024-rooted-identity-separation` | `||R-lambda I||_HS >= sqrt(2)|lambda|` for zero-defect `R`; sharp with degenerate equality | Not a physical energy barrier |
| Paper5B-TerminalSpectrum-v5_201.tex | `p6:thm:v3024-rooted-hopf-nearest-source` | Unique nearest zero-defect `T`, unique nearest unitary zero-defect `U`, sharp distances | Fixed rooted chart, not physical minimization |
| Paper5B-TerminalSpectrum-v5_201.tex | `p6:cor:v3024-commuting-hopf-control` | Commuting class `4-2sqrt(3)` versus `4-8sqrt(2)/3` | Commuting zero-defect examples still exist |
| Paper5D-TechnicalMaterial-v1_55.tex | `p6:rem:v3024-charged-source-port-diagnostic` | Check native mixed jet, root-arrow constraints, role-specific comparison ports and normalization | Certification procedure; no inferred source selection |

No existing theorem/definition was deleted or weakened. New source labels are **source-attested**; the canonical theorem DAG is unchanged pending separate full proof-route promotion. The mathematical argument is supported by 47 exact audit v1_8 and 80 audit v1_7 checks rerun on this system. This is **not** an independent full-paper E3/E4 audit of the revised 31-paper corpus.

## Imported and inherited open conditions

- `p5:def:v228-hierarchy-origin` (`Cert_hier`): source-incidence occurrence, not discharged.
- `BH-VA-G-0007`: native chiral comparison operator and its physical owner, not discharged.
- `BH-G-000113`: unique nine role-to-polar comparison source ports, not discharged.
- Actual physical source-to-rest/pole link remains a separate condition.

**No GP3-to-Hilbert–Schmidt-minimization implication is claimed.** The minimal-distance theorem characterizes already established geometric objects, not a new physical selection law.

## Build and provenance validation

- 31 source TeX files and 31 PDF outputs in the new papers bundle, plus Macros, bibliography, and xref AUX entries.
- Three changed `.tex` files were compiled successfully twice using `pdflatex`; the environment does not include `bibtex`, and the preexisting global external-reference registry still points to historical versioned roots. Some cross-paper/bibliography references therefore remain unresolved in the independently compiled PDFs; the TeX source statements and proofs are authoritative.
- 13,986 distinct source labels; exactly five additional source labels, none lost and none duplicated.
- All 54 observable target occurrences were reanchored, including 20 whose source file/line metadata changed; 54 retained byte-identical statement and immediate proof spans; 0 require independent semantic recheck.
- 5,335 material dependency edges and 5,406 combined proof-route records retained; no mathematical or physical status promotion.
- Prior audit layers, gap registry and historical source snapshots retained in the DAG Atlas.
