Source-boundary Newton correction: zero local EH/GHY a2 defect on restricted domain; full physical normalization remains open. See Findings.json and ConditionalGates.json.
