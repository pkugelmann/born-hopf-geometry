# Born–Hopf Geometry — DAG Atlas v1.217 (Paper II-C endpoint closure)

**Parent:** v1.216. **Authoritative papers:** `Paper00-PapersMinimal-v3_059.zip` with Paper II-C v2.173. **Audits:** `Paper00-ProofChainAudits-v1_80.zip`.

This release integrates exact **native mathematical POVM** optimization results, not physical detector or event occurrence. Current mathematical status of BH-IIC-G-002, G-003, G-004: **closed at their specific exact-first-moment operator scopes** (7 localization outcomes at endpoint, 22 effects for pure protected quotient, 136 effects for full endpoint quotient). The universal rank-six geometry threshold is `sqrt(34)R_mom/3` and is attained by the six orthogonal-trines at that radius.

**New canonical labels:** five Paper II-C lemma/theorem/equation anchors. **Current source labels:** 14,187, zero duplicates. Current graph source nodes and reviewed-vs-candidate links updated without replacing inherited audit proofs. **New canonical candidate proof-source references:** source-integrated/local exact replay; **new globally E3/E4-promoted material edges:** none. All retained combined material and proof-route indexes remain frozen to their previous review scopes, not globally re-derived from v3.059.

**Effective issue record:** `DAG/ReconciliationLayer/Paper00-CurrentGapDisposition-v1_6.json`; historical per-paper audit `DAG/AuditLayer/Paper2C-v1_2/` remains immutable. **Current proof source/evidence:** `DAG/SourceUpdates/EndpointReadoutClosure-v1_1/Index.json` and `DAG/Proofs/EndpointReadoutClosure-v1_1/`. **Current source map:** `DAG/CurrentSourceAnchorMap-v3_059.json`. Current release pointers and hashes: `DAG/ActiveRelease-v1_217.json` and `DAG/ArtifactManifest-v1_217.json`.

**Untouched:** 30 other current scientific manuscripts and PDF images, earlier theorem claims, original audit evidence, all G0/GP1–GP3 foundations and physical owner/occurrence gates. This is *not* a global whole-paper or whole-framework E3/E4 re-audit and not a claim of physical instrument selection or prediction.

**Archive:** one canonical graph and scoped active audit/index layers, no duplicate historical paper source trees. Historical provenance references remain historical; see `DAG/ReferenceDisposition-v1_217.json`.
