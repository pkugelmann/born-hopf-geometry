# Born--Hopf Geometry — Integrated framework changes v1_1

**Date:** 2026-11-20  
**Current scientific source:** `Paper00-PapersMinimal-v3_058.zip`  
**Current dependency atlas:** `Paper00-DAGAtlas-v1_215.zip`  
**Parent files:** `Paper00-PapersMinimal-v3_057(1).zip` and `Paper00-DAGAtlas-v1_214(1).zip`  
**Proposed-research ancestor:** `Paper00-ActionSourceDescent-v1_8.md`.

## Updated papers

- III-F -> `Paper3F-CompleteDynamics-v1_276.tex` and matching rebuilt PDF. Adopted stationary-reference all-order classical metric reduction, original-material-chart jet invariance, same-component independence, matter-vs-metric selector obstruction, and native three-role free-left action comparison test.
- V-A -> `Paper5A-FiniteMatterGeometry-v3_218.tex` and matching rebuilt PDF. Exact rooted two-contact return, positive candidate, mass-Vandermonde triangle and Hermitian-commutant rank strata, sharp restricted commuting-source error and necessary noncommutation bound.
- V-D -> `Paper5D-TechnicalMaterial-v1_58.tex` and matching rebuilt PDF. Explicit projector/matrix verification and degenerate-orientation scope.

No other paper's mathematical source or PDF was modified. Paper III-F's pre-existing exact stationary pullback and two-scalar return certificate remain credited as existing results; the v1.5 four-scalar variant remains historical optional material, not a newly introduced preferred theorem.

## DAG results

- Current `DAG/CurrentSourceAnchorMap-v3_058.json`: 14182 source labels, no duplicates.
- 23 new source-labeled graph nodes; 6770 preexisting node locators reanchored without altering their proof flags.
- 20 source-matched *candidate* dependency/context links indexed under `DAG/SourceUpdates/ActionSourceDescent-v1_1/Index.json`, not asserted as independently E3/E4-verified canonical proof-use edges.
- The existing `p5:def:v228-hierarchy-origin` condition is inherited without any new `Cert_hier` assumption node.
- The exact two-scalar acceptance test applies to a free *left* response only if the canonically normalized **actual** source return is independently evaluated and equals the geometric target. The target matrix's algebraic availability does not make it the physical source.

## Confirmed limitations

Actual action/jet occurrence, the stronger directed charged-source certificate, physical interacting pole residues, regular stationary seed realization, quantum gravitational response and the measured Newton constant remain **OPEN**. No additional G0/GP axiom, phenomenological fit, or physical coupling has been inserted. The conditional tensor coefficient comparison 96 is not presented as a measured Newton ratio.

## Verification

- Three final revised-paper PDFs compiled; zero unresolved LaTeX references or citations.
- Previous exact regression suites rerun successfully (61 + 53 + 60 checks) and independent local rooted matrix replay passed.
- Main DAG passes its JSON schema; archive graph hash and source zip SHA match the active release record.
- Independent global E3/E4 proof-chain audit still **PENDING**. Existing audit archive `Paper00-ProofChainAudits-v1_79.zip` is not rewritten or marked complete.

## Archive contract

`PapersMinimal v3_058` contains exactly one current TeX/PDF pair per 31 logical papers, plus required shared macros, bibliography, build aliases, and reproducibility inventory.  The `DAGAtlas v1_215` ZIP preserves historical proof/audit evidence for compatibility; its **current** canonical theorem graph and active-source index are unique. Historical snapshots are evidence, not additional current paper versions.
