#!/usr/bin/env python3
"""Exact finite character bridge certificate, no physical mass fits.

Runs with numpy, otherwise uses stdlib for exact Gram counts and group checks.
Built from A5 = 2I/{+-1}, H=A4 = 2T/{+-1}; doubles counting for 2I.
"""
import itertools, math, json
from collections import Counter
from fractions import Fraction
try:
    import numpy as np
except ImportError:
    np = None

D=5
id5=tuple(range(D))
def compose(p,q):return tuple(p[q[i]] for i in range(D))
def inv(p):return tuple(p.index(i) for i in range(D))
def parity(p):return (-1)**sum(p[i]>p[j] for i in range(len(p)) for j in range(i+1,len(p)))
def cycle3(a,b,c):
    x=list(id5);x[a]=b;x[b]=c;x[c]=a
    return tuple(x)
G=sorted([p for p in itertools.permutations(range(D)) if parity(p)==1]);assert len(G)==60
H=[p for p in G if p[4]==4]; assert len(H)==12
V4=[]
for p in H:
    if compose(p,p)==id5:V4.append(p)
assert len(V4)==4
u=cycle3(0,1,2)
u2=compose(u,u)
Vsets=[set(compose(powu,v) for v in V4) for powu in (id5,u,u2)]
assert all(len(v)==4 for v in Vsets) and len(set.union(*Vsets))==12
char={p:k for k,vs in enumerate(Vsets) for p in vs}
assert len(char)==12
assert all(char[compose(h,k)]==(char[h]+char[k])%3 for h in H for k in H)
# coset reps g_i with g_i(4)=i
rep={i:next(g for g in G if g[4]==i) for i in range(D)}
rep[4]=id5
r=tuple(rep[i] for i in range(D)); rinv=tuple(inv(g) for g in r)
Gindex={g:i for i,g in enumerate(G)}
# U(g) as sparse monomial: column j -> row i, exponent char(h)
def monomial(g,twist=True):
    mat=[[-1]*5 for _ in range(5)]
    for j in range(5):
        p=compose(g,r[j]); i=p[4];h=compose(rinv[i],p)
        assert h in char
        mat[i][j]=char[h] if twist else 0
    assert all(sum(x!=-1 for x in row)==1 for row in mat)
    return mat
M={g:monomial(g) for g in G}
M0={g:monomial(g,False) for g in G}
# Matrix product of complex cube roots: use exponent bookkeeping to avoid rounding
assert all(sum(1 for i in range(5) if M[g][i][j]>=0)==1 for g in G for j in range(5))
for g in G:
  for f in G:
    gf=compose(g,f);a=M[g];b=M[f];c=M[gf]
    for j in range(5):
        m=next(k for k in range(5) if b[k][j]>=0)
        i=next(k for k in range(5) if a[k][m]>=0)
        assert c[i][j]==(a[i][m]+b[m][j])%3
# In signed doubled group, count each permutation twice, yielding 120 norm
pairs=list(itertools.product(range(5), repeat=2))
# 0,1,2 counts for exponent differences, plus 'trivial untwisted' Gram
hist_tw=[];hist_cross=[];Gram0=[]
for i,j in pairs:
   row=[];cross=[];zer=[]
   for k,l in pairs:
       cnt=[0,0,0];crosscnt=[0,0,0];n0=0
       for g in G:
           a=M[g][i][j];b=M[g][k][l];b0=M0[g][k][l]
           if a>=0 and b>=0:cnt[(a-b)%3]+=2
           if a>=0 and b0>=0:crosscnt[a]+=2
           if M0[g][i][j]>=0 and b0>=0:n0+=2
       # sum n0+n1*w+n2*w**2 equal 0 iff n0=n1=n2
       assert (cnt == [24,0,0]) if (i,j)==(k,l) else (cnt[0]==cnt[1]==cnt[2])
       assert crosscnt[0]==crosscnt[1]==crosscnt[2]
       row.append(cnt);cross.append(crosscnt);zer.append(n0)
   hist_tw.append(row);hist_cross.append(cross);Gram0.append(zer)
# untwisted Gram spectral result from independent character identities
if np is not None:
    eg=np.linalg.eigvalsh(np.array(Gram0,dtype=float))
    assert np.allclose(eg, np.array([0]*8+[30]*16+[120]), atol=1e-9)
    # pair action on 10 pairs; orthogonal rank5 projector exact
pairlist=list(itertools.combinations(range(5),2));pairindex={s:i for i,s in enumerate(pairlist)}
P=[]
for S in pairlist:
    P.append([Fraction(int(S==T),1)-Fraction(len(set(S).intersection(T)),3)+Fraction(1,6) for T in pairlist])
assert all(sum(P[i][k]*P[k][j] for k in range(10))==P[i][j] for i in range(10) for j in range(10))
assert sum(P[i][i] for i in range(10))==5
# Petersen character = trace action on connected 10-pair P, equals twisted 5 char
for g in G:
    # sum_S P(S,g S) equals trace(P rho(g))
    char_pair=sum(P[pairindex[S]][pairindex[tuple(sorted(g[z] for z in S))]] for S in pairlist)
    # twisted monomial trace as cyclotomic integer
    diag=Counter(M[g][i][i] for i in range(5) if M[g][i][i]>=0)
    a=diag[0]-diag[2];b=diag[1]-diag[2]
    assert b==0 and Fraction(a,1)==char_pair
# 24-vertex Hurwitz group and edges, equivariance under left multiplication
vecs=[]
for i in range(4):
    for sign in (-2,2):
        v=[0]*4; v[i]=sign;vecs.append(tuple(v))
vecs += list(itertools.product((-1,1),repeat=4))
assert len(set(vecs))==24
V=sorted(vecs); Vindex={v:i for i,v in enumerate(V)}
def qm(q,r):
    a,b,c,d=q;e,f,g,h=r
    raw=(a*e-b*f-c*g-d*h,a*f+b*e+c*h-d*g,a*g-b*h+c*e+d*f,a*h+b*g-c*f+d*e)
    assert all(x%2==0 for x in raw)
    v=tuple(x//2 for x in raw)
    assert v in Vindex
    return v
unit=(2,0,0,0); Q8=[v for v in V if sum(x!=0 for x in v)==1];assert len(Q8)==8
uQ=(1,1,1,1)
uQ2=qm(uQ,uQ)
Qcosets=[set(qm(uu,q) for q in Q8) for uu in (unit,uQ,uQ2)]
assert len(set.union(*Qcosets))==24 and all(len(v)==8 for v in Qcosets)
chQ={v:k for k,vs in enumerate(Qcosets) for v in vs}
assert all(chQ[qm(x,y)]==(chQ[x]+chQ[y])%3 for x in V for y in V)
edges=[(V[i],V[j]) for i in range(24) for j in range(i+1,24) if sum(V[i][k]*V[j][k] for k in range(4))==2]
assert len(edges)==96
edgeidx={frozenset(e):i for i,e in enumerate(edges)}
notseen=set(range(96));orbits=[]
while notseen:
    seed=edges[min(notseen)]
    orb={edgeidx[frozenset((qm(h,seed[0]),qm(h,seed[1])))] for h in V}
    assert len(orb)==24
    orbits.append(orb);notseen-=orb
assert len(orbits)==4
oriented_edges=[(q,r) for q in V for r in V if q!=r and sum(q[k]*r[k] for k in range(4))==2]
assert len(oriented_edges)==192
ornindex={e:i for i,e in enumerate(oriented_edges)}
seen=set();oriorbits=[]
for k,e in enumerate(oriented_edges):
    if k in seen:continue
    orb={ornindex[(qm(h,e[0]),qm(h,e[1]))] for h in V}
    assert len(orb)==24
    seen|=orb;oriorbits.append(orb)
assert len(oriorbits)==8
# H-Fourier source per orbit: coefficient of h.e is omega^{-character(h)} / sqrt(24)
# character group confirms exact eigen-covariance; eigenspaces have one chi per regular orbit
seed=oriented_edges[min(oriorbits[0])]
for k in V:
    for h in V:
        # left k maps coefficient index h to kh, phase changes by character(k)
        assert chQ[qm(k,h)]==(chQ[k]+chQ[h])%3
res={
  'groups':{'A5':60,'A4':12,'2I':120,'2T':24,'A4_char_kernel':len(V4),'Hurwitz_char_kernel':len(Q8)},
  'coset_monomial_rep_dim':5,
  'twisted_25_coefficients':25,
  'twisted_coefficient_gram':'24 I_25 (exact exponent counts over 2I)',
  'untwisted_25_register_gram_eigenvalues':{'120':1,'30':16,'0':8},
  'twisted_untwisted_cross_gram':'0 (exact exponent counts)',
  'Petersen_rank5_projector_trace':str(sum(P[i][i] for i in range(10))),
  'Petersen_char_equals_twisted_char':True,
  'Hurwitz_undirected_edges':len(edges),
  'Hurwitz_undirected_edge_orbits':len(orbits),
  'Hurwitz_oriented_edges':len(oriented_edges),
  'Hurwitz_oriented_edge_orbits':len(oriorbits),
  'independent_formal_chi_orbit_modes':len(oriorbits),
  'physical_coupling_fixed':False,
  'mass_curvature_derived':False
}
if __name__=='__main__':
    import pathlib
    out=pathlib.Path(__file__).with_name('Paper00-HadronScaleTest-v1_7-results.json')
    out.write_text(json.dumps(res,indent=2)+'\n')
    print(json.dumps(res,indent=2))
# Additional explicit intertwiner from the C3-twisted quintet to Petersen pair module
if np is not None:
    omega=np.exp(2j*np.pi/3)
    def U5(g):
        out=np.zeros((5,5),complex)
        for i in range(5):
            for j in range(5):
                k=M[g][i][j]
                if k>=0:out[i,j]=omega**k
        return out
    def Upair(g):
        out=np.zeros((10,10),complex)
        for j,S in enumerate(pairlist):
            i=pairindex[tuple(sorted(g[z] for z in S))]
            out[i,j]=1
        return out
    # eigenprojection of the H=A4 character onto 10-pair representation
    Qchi=sum((omega**(-char[h]))*Upair(h) for h in H)/12
    assert np.linalg.norm(Qchi@Qchi-Qchi)<1e-12
    assert abs(np.trace(Qchi)-1)<1e-12
    seed=np.eye(10,dtype=complex)[:,0]
    v=Qchi@seed
    assert np.linalg.norm(v)>1e-8
    v=v/np.linalg.norm(v)
    J=np.column_stack([Upair(g)@v for g in r])
    Pnum=np.array([[float(p) for p in row] for row in P])
    assert np.linalg.norm(J.conj().T@J-np.eye(5))<1e-12
    assert np.linalg.norm(J@J.conj().T-Pnum)<1e-12
    for g in G:
        assert np.linalg.norm(Upair(g)@J-J@U5(g))<1e-12
    res['Petersen_pair_intertwiner_isometry_verified']=True
    res['Petersen_pair_intertwiner_max_error']=float(max(np.linalg.norm(Upair(g)@J-J@U5(g)) for g in G))
    outpath=__import__('pathlib').Path(__file__).with_name('Paper00-HadronScaleTest-v1_7-intertwiner.csv')
    with outpath.open('w') as out:
        out.write('pair,'+','.join('coset_%s'%i for i in range(5))+'\n')
        for S,row in zip(pairlist,J):
            out.write('%s,'%(''.join(str(t) for t in S)) + ','.join('%.12g%+.12gj'%(z.real,z.imag) for z in row)+'\n')
    if __name__=='__main__':
        out=__import__('pathlib').Path(__file__).with_name('Paper00-HadronScaleTest-v1_7-results.json')
        out.write_text(json.dumps(res,indent=2)+'\n')
        print('Quintet->Petersen equivariant isometry certified:', res['Petersen_pair_intertwiner_max_error'])
# Generic-link witness: one SU(3) link with U=diag(exp(iθ), exp(-iθ), 1), all others I.
# This changes W_e from 1 to (1+2 cos θ)/3 on every other oriented edge of a triangle containing the chosen link.
# Thus nonzero C3 Fourier components prove that the existing gauge-invariant fan observable admits χ, not just the formal edge module.
special=edges[0]
a,b=special
rs=[r for r in V if r not in special and sum(a[k]*r[k] for k in range(4))==2 and sum(b[k]*r[k] for k in range(4))==2]
assert len(rs)==3
affected={frozenset((a,r)) for r in rs}|{frozenset((b,r)) for r in rs}
assert len(affected)==6
fourier=[]
for orb in oriorbits:
    seed=oriented_edges[min(orb)]
    n=[0,0,0]
    for h in V:
        edge=frozenset((qm(h,seed[0]),qm(h,seed[1])))
        if edge in affected:n[chQ[h]]+=1
    # For nonzero theta, contribution proportional (n0+n1 w^(-1)+n2 w^(-2))
    # zero iff n0=n1=n2
    fourier.append(n)
assert any(n[0]!=n[1] or n[1]!=n[2] for n in fourier)
res['SU3_one_link_fan_Fourier_witness_phase_counts']=fourier
res['SU3_one_link_fan_has_nonzero_chi']=True
if __name__=='__main__':
    out=__import__('pathlib').Path(__file__).with_name('Paper00-HadronScaleTest-v1_7-results.json')
    out.write_text(json.dumps(res,indent=2)+'\n')
    print('single-link baryon fan nonzero χ witness phase counts',fourier)
# Exact color-determinant check, not merely a combinatorial edge-fan proxy.
# SU(3) diagonal link diag(-1,-1,+1) and its inverse on one undirected edge;
# all other links are identity. Any oriented edge has exactly 3 adjacent triangles.
su3_special=(-1,-1,1);unitlink=(1,1,1)
def getlink(p,q):
    return su3_special if frozenset((p,q))==frozenset(special) else unitlink
from itertools import permutations as iperms
Ws=[]
for p,q in oriented_edges:
    third=[u for u in V if u not in (p,q) and sum(p[k]*u[k] for k in range(4))==2 and sum(q[k]*u[k] for k in range(4))==2]
    assert len(third)==3
    A=[]
    for u in third:
        X=getlink(q,u);Y=getlink(u,p)
        A.append(tuple(X[k]*Y[k] for k in range(3)))
    w=Fraction(sum(math.prod(A[k][perm[k]] for k in range(3)) for perm in iperms(range(3))),6)
    ref=Fraction(-1,3) if frozenset((p,q)) in affected else Fraction(1,1)
    assert w==ref
    Ws.append(w)
assert Ws.count(Fraction(-1,3))==12
# Exact χ Fourier sum of (1/24)^1/2 weighted gauge-invariant W_e.
Sq=Fraction(0,1)
for orb in oriorbits:
    e=oriented_edges[min(orb)]
    cnt=[Fraction(0) for _ in range(3)]
    for h in V:
        he=(qm(h,e[0]),qm(h,e[1]))
        cnt[chQ[h]]+=Ws[ornindex[he]]
    # |a+bω+cω²|² = a²+b²+c²-ab-bc-ca
    a,b,c=cnt
    Sq+=(a*a+b*b+c*c-a*b-b*c-c*a)/24
assert Sq==Fraction(4,9)
res['one_link_SU3_exact_color_determinant_fourier_norm_squared']=str(Sq)
res['one_link_SU3_color_determinant_nontrivial_edge_values']=Ws.count(Fraction(-1,3))
if __name__=='__main__':
    out=__import__('pathlib').Path(__file__).with_name('Paper00-HadronScaleTest-v1_7-results.json')
    out.write_text(json.dumps(res,indent=2)+'\n')
    print('exact W_e Fourier χ norm squared:',Sq)
