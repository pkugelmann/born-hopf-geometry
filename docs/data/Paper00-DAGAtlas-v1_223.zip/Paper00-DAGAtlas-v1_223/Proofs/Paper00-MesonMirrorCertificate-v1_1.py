#!/usr/bin/env python3
"""Exact canonical-form certificate: v2_327 two-core mirror / spin algebra.

The script RECONSTRUCTS the actual 15 Petersen-edge half-turn columns from
the exact 10 Hopf-axis coordinates in Paper I-A, checks all 10 two-core
X-block singular spectra and then verifies the normalized projector, graded
transport and tensor-spin spectrum in exact SymPy arithmetic. No QCD map
or physical hadron mass is asserted.

Run: python3 Paper00-MesonMirrorCertificate-v1_1.py
"""
import json
from itertools import combinations
import sympy as sp

# Rebuild the exact Paper I-A ten Hopf-axis coordinates in Q(sqrt(5)).
rt5=sp.sqrt(5)
phi=(1+rt5)/2
pinv=1/phi
coords={
 (1,2):(1,1,1),(1,3):(1,1,-1),(1,4):(1,-1,1),(1,5):(1,-1,-1),
 (2,3):(pinv,-phi,0),(2,4):(phi,0,-pinv),(2,5):(0,pinv,-phi),
 (3,4):(0,pinv,phi),(3,5):(phi,0,pinv),(4,5):(pinv,phi,0)
}
axes={a:sp.Matrix(x)/sp.sqrt(3) for a,x in coords.items()}
edges=[(a,b) for a,b in combinations(sorted(axes),2) if set(a).isdisjoint(b)]
assert len(edges)==15
columns=[]
for a,b in edges:
    dot=sp.simplify(axes[a].dot(axes[b]))
    assert dot in (rt5/3,-rt5/3)
    sign=int(sp.sign(dot))
    columns.append(sp.simplify(sp.Rational(3,2)*sign*axes[a].cross(axes[b])))
K15=sp.Matrix.hstack(*columns)
K15sig=K15.applyfunc(lambda x: sp.simplify(x.subs(rt5,-rt5)))
assert sp.simplify(K15*K15.T)==5*sp.eye(3)
assert sp.simplify(K15sig*K15sig.T)==5*sp.eye(3)
assert sp.simplify(K15*K15sig.T)==sp.zeros(3)
D15=sp.simplify((K15.T*K15-K15sig.T*K15sig)/5)
assert D15.eigenvals()=={sp.S(1):3,sp.S(-1):3,sp.S(0):9}
certified_pairs=[]
for m,n in combinations(range(1,6),2):
    aa=[i for i,(a,b) in enumerate(edges) if m not in a+b]
    bb=[i for i,(a,b) in enumerate(edges) if n not in a+b]
    assert len(aa)==len(bb)==3 and set(aa).isdisjoint(bb)
    assert D15.extract(aa,aa)==sp.zeros(3)
    assert D15.extract(bb,bb)==sp.zeros(3)
    Xm=D15.extract(aa,bb)
    assert sp.simplify(Xm*Xm.T).eigenvals()=={sp.Rational(3,20):2,sp.S(0):1}
    assert sp.simplify(Xm.T*Xm).eigenvals()=={sp.Rational(3,20):2,sp.S(0):1}
    if (m,n)==(1,2):
        assert sp.simplify(Xm*Xm.T)==sp.Matrix([
           [sp.Rational(1,10),-sp.Rational(1,20),-sp.Rational(1,20)],
           [-sp.Rational(1,20),sp.Rational(1,10),-sp.Rational(1,20)],
           [-sp.Rational(1,20),-sp.Rational(1,20),sp.Rational(1,10)]])
    certified_pairs.append([m,n])

c = sp.sqrt(sp.Rational(3,20))
X=sp.diag(c,c,0)
Z=sp.zeros(3)
D=sp.Matrix.vstack(sp.Matrix.hstack(Z,X),sp.Matrix.hstack(X,Z))
P_m=sp.diag(1,1,1,0,0,0)
P_n=sp.diag(0,0,0,1,1,1)
G=P_m-P_n
Q=sp.simplify(sp.Rational(20,3)*(D*D))
U=sp.simplify(sp.sqrt(sp.Rational(20,3))*D)
I6=sp.eye(6)
assert Q==Q.T and Q*Q==Q
assert Q.rank()==4 and (P_m*Q).rank()==2 and (P_n*Q).rank()==2
assert U*U==Q and U*Q==U and Q*U==U
assert G*U+U*G==sp.zeros(6)
assert G*Q-Q*G==sp.zeros(6)
assert D.eigenvals()=={c:2,-c:2,sp.S(0):2}
assert U.eigenvals()=={sp.S(1):2,sp.S(-1):2,sp.S(0):2}
assert G*G==I6

sx=sp.Matrix([[0,1],[1,0]])
sy=sp.Matrix([[0,-sp.I],[sp.I,0]])
sz=sp.diag(1,-1)
T=sum((sp.kronecker_product(s,s) for s in (sx,sy,sz)),sp.zeros(4))
assert T.eigenvals()=={sp.S(-3):1,sp.S(1):3}
assert T*sp.eye(4)==T and T.H==T
assert sp.trace(T)==0 and sp.trace(T*T)==12

I4=sp.eye(4)
S=sp.kronecker_product(Q,T)
J=sp.kronecker_product(U,I4)
assert S.eigenvals()=={sp.S(-3):4,sp.S(1):12,sp.S(0):8}
assert J.eigenvals()=={sp.S(-1):8,sp.S(1):8,sp.S(0):8}
assert sp.trace(J*S)==0
assert sp.trace(J*J)==16
assert sp.trace(S*S)==48

# Symbolic trace and spectral factors, using the exact simultaneously reducing
# mirror parity / spin eigen-decomposition.
a,b,k=sp.symbols('a b k', real=True)
M=a*sp.eye(24)+b*J+k*S
spectrum={a:8,a+b-3*k:2,a-b-3*k:2,a+b+k:6,a-b+k:6}
assert sp.expand(sp.trace(M)-24*a)==0
assert sp.expand(sp.trace((M-a*sp.eye(24))**2)-(16*b*b+48*k*k))==0
assert M.eigenvals()==spectrum

# A finite Hamiltonian compression that *does* leak:
K=sp.Matrix([[1,0,2,0],[0,3,0,1],[2,0,4,0],[0,1,0,5]])
iota=sp.Matrix([[1,0],[0,1],[0,0],[0,0]])
P=iota*iota.T
Ke=iota.T*K*iota
B=(sp.eye(4)-P)*K*iota
remainder=sp.simplify(iota.T*K*K*iota-Ke*Ke)
assert remainder==B.T*B==sp.diag(4,1)

output={
 'release':'Paper00-PapersMinimal-v2_327',
 'proven_input':'Paper I-A exact 10-axis coordinates, recomputed all Petersen-edge K columns',
 'graph_petersen_edges':len(edges),
 'core_pairs_exactly_certified':certified_pairs,
 'projector_rank':int(Q.rank()),
 'per_core_active_rank':2,
 'per_core_dark_rank':1,
 'U_eigenvalues':{'-1':2,'0':2,'1':2},
 'spin_eigenvalues':{'-3':1,'1':3},
 'projector_spin_eigenvalues':{'-3':4,'0':8,'1':12},
 'conditional_24_spectrum':{
  'a':8,'a+b-3k':2,'a-b-3k':2,'a+b+k':6,'a-b+k':6
 },
 'second_centered_trace':'16*b^2+48*k^2',
 'explicit_leakage_counterexample':[[4,0],[0,1]],
 'physical_hadron_mass_prediction':'NONE',
 'spin_coefficient_origin':'NOT_DERIVED',
 'embedding_into_real_HL':'NOT_ESTABLISHED',
 'status':'EXACT_PETERSEN_AXIS_AND_CANONICAL_SPIN_CERTIFICATE_NO_PHYSICAL_POLE'
}
with open('Paper00-MesonMirrorCertificate-v1_1-output.json','w') as f:
 json.dump(output,f,indent=2)
print(json.dumps(output,indent=2))
