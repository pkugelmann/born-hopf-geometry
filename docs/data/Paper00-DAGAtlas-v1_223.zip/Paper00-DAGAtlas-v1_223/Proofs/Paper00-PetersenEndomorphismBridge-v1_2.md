# Pre-update theorem certificate: Petersen edge cochains, the five-core contrast space, and finite-incidence visibility

**Status (Framework v2.339):** exact finite mathematics; conditional on a selected/occurring embedded binary-icosahedral support when interpreted in Born–Hopf Geometry. This is an integrated *manuscript-level finite bridge*, not a claim of new literature mathematics or a physical particle identification. **Framework sources checked:** latest provided minimal archive v2.338, especially Paper I-A v5.150 and Paper V-B v5.178. The v2.339 archive integrates this certificate in Paper I-A, II-E, II-F and V-B.

## 1. Two distinct 25-dimensional objects

Let \(I=2I\) be the binary icosahedral group (order 120), let \(G=I/\{\pm1\}\cong A_5\), and let \(\Omega=\{1,2,3,4,5\}\) be its permutation set of the five binary tetrahedral cores. Define the *25 incidence registers*
\[
\mathcal R_{ij}:=\{g\in I:\pi(g)(j)=i\},\qquad 1\le i,j\le5.
\]
They are 24-element coset translates, **not** the ten cyclic intersections \(\mathcal A_{\{i,j\}}=H_i\cap H_j\cong C_6\), and **not** the distinct 25-dimensional rank-25 \(\mathbf5\otimes\mathbf5\) coefficient increment established later in Paper V-B. Put \(B:\mathbb R^{5\times5}\to\mathbb R^{120}\) by \((BM)(g)=\sum_{j=1}^5M_{\pi(g)(j),j}\). Write \(J=\mathbf1\mathbf1^T\), \(P=J/5\), and \(Q=I-P\). The existing incidence calculation proves
\[
B^*B=24 I_{25}+6(J-I)\otimes(J-I)=120(P\otimes P)+30(Q\otimes Q).
\]
Thus \(\operatorname{rank}B=17\), \(\ker B=(P\otimes Q)\oplus(Q\otimes P)\) (dimension 8), and its image is the sum of the global constant line and \(V\otimes V\), where \(V=\mathbf1^\perp\subset\mathbb R^5\) has dimension four. These results already appear in Paper V-B; no new discovery is claimed for them.

## 2. Canonical diagonal split: 17 = 1 + 1 + 15

Under **diagonal** \(A_5\) conjugation, \(V\otimes V\cong\operatorname{End}(V)\) and
\[
\operatorname{End}(V)=\mathbb R I_V\oplus\mathfrak{sl}(V),\qquad 16=1+15.
\]
Equivalently, for a real \(5\times5\) matrix \(M\), its canonical traceless doubly centered component is
\[
\boxed{T(M)=QMQ-\frac{\operatorname{tr}(QMQ)}4 Q.}
\]
It has rank 15 as a linear projection, commutes with all simultaneous five-label permutations, and is perpendicular to both the global constant register and the extra diagonal-invariant \(\chi_4\) character line. As an \(A_5\)-module,
\[
\mathfrak{sl}(V)=\operatorname{Sym}^2_0(V)\oplus\Lambda^2V
\cong(\mathbf4\oplus\mathbf5)\oplus(\mathbf3\oplus\mathbf3').
\]
The real oriented Petersen-edge cochains carry exactly the same \(\mathbf4\oplus\mathbf5\oplus\mathbf3\oplus\mathbf3'\) representation. **Representation equivalence alone does not specify a unique intertwiner**; the next construction supplies one from the already fixed five-label Euclidean simplex structure.

## 3. Explicit 15-edge ↔ traceless-4×4 operator map

Let the ten vertices of the Petersen graph be 2-subsets \(A=\{i,j\}\subset\Omega\), with an edge \(e=(A\to B)\) when \(A\cap B=\varnothing\). Write \(e_i\) for the standard basis of \(\mathbb R^5\). Set
\[
 d_A=e_i-e_j,\quad v_A=e_i+e_j-\tfrac25\mathbf1,\quad
 S_e=d_A d_A^T-d_B d_B^T,\quad
 K_e=v_Av_B^T-v_Bv_A^T.
\]
The choice of order \(i,j\) inside a pair is irrelevant: \(d_A d_A^T\) is independent of that order. Reversing the directed Petersen edge sends both \(S_e\) and \(K_e\) to their negatives. Each \(S_e\) is a symmetric trace-free endomorphism of \(V\), and each \(K_e\) is skew-symmetric on \(V\). All constructions commute with \(S_5\), when orientations are transformed with the usual signs.

Let \(W_P=C^1(P;\mathbb R)\cong\mathbb R^{15}\) be the oriented Petersen-edge space, and use the standard Hilbert–Schmidt product on \(\operatorname{End}(V)\). Define \(S:W_P\to\operatorname{Sym}^2_0(V)\) and \(K:W_P\to\mathfrak{so}(V)\) by \(S|e\rangle=S_e\), \(K|e\rangle=K_e\). Let \(\partial:W_P\to\mathbb R^{10}\) be the graph boundary, and let \(P_4,P_5,P_6\) denote the mutually orthogonal spectral projectors on edge cochains onto \(\mathbf4,\mathbf5,\mathbf3\oplus\mathbf3'\), respectively. Then the **exact Gram identities** are
\[
\boxed{S^*S=25P_4+4P_5,\qquad K^*K=4P_6,\qquad S^*K=0.}
\]
Consequently \(\Phi:=S+K\) is a bijective \(S_5\)-intertwiner \(W_P\xrightarrow{\sim}\mathfrak{sl}(V)\) with
\[
\boxed{\Phi^*\Phi=25P_4+4(I-P_4),\qquad
U:=\Phi\left(\tfrac15 P_4+\tfrac12(I-P_4)\right),\qquad U^*U=I_{15}.}
\]
In particular the fifteen explicit matrices \(U_e=U|e\rangle\) form an **orthonormal real Hilbert–Schmidt basis of \(\mathfrak{sl}(V)\)**. They are constructed without fitting to hadron masses or inserting a 15-dimensional sector by dimension-matching.

### Proof of the two Gram eigenvalues

Let \(D:\mathbb R^{10}\to\operatorname{Sym}^2(V)\) send the 2-subset \(A\) to \(d_Ad_A^T\). The Petersen adjacency matrix \(A_P\) has eigenvalues \(3^{(1)},1^{(5)},(-2)^{(4)}\). Inner products give \(D^*D=3I+J-A_P\), and \(\partial\partial^T=3I-A_P\). Since \(S=D\partial\), the two nonzero singular-square values are \((3-1)^2=4\) on the five-dimensional vertex space and \((3-(-2))^2=25\) on the four-dimensional vertex space. Thus \(\mathrm{rank}S=9\).

For \(K\), the sum of its three oriented outgoing columns at any Petersen vertex \(A\) vanishes, since \(\sum_{B\cap A=\varnothing}v_B=-2v_A\), hence \(K\partial^T=0\). Therefore \(K\) kills the nine-dimensional gradient space. The \(S_5\)-representation \(\Lambda^2 V\) is irreducible of real dimension six, so the nonzero \(S_5\)-equivariant operator \(KK^*\) is scalar there. Each \(\|K_e\|_{HS}^2=8/5\), giving \(\mathrm{tr}(KK^*)=15(8/5)=24\); the scalar is \(24/6=4\). Thus \(K^*K=4P_6\). The mixed term vanishes because symmetric and skew matrices are orthogonal.

## 4. Exact graph-to-matrix symmetric pair

The graph Hodge decomposition now has a native finite matrix-algebra interpretation:
\[
\underbrace{\mathrm{im}\,\partial^T}_{9=4+5}
\xrightarrow{\ U\ }\operatorname{Sym}^2_0(V),\qquad
\underbrace{\ker\partial}_{6=3+3'}
\xrightarrow{\ U\ }\mathfrak{so}(V).
\]
Under the ordinary matrix commutator, these spaces obey
\[
[\mathfrak{so}(V),\mathfrak{so}(V)]\subseteq\mathfrak{so}(V),\quad
[\mathfrak{so}(V),\operatorname{Sym}^2_0(V)]\subseteq\operatorname{Sym}^2_0(V),\quad
[\operatorname{Sym}^2_0(V),\operatorname{Sym}^2_0(V)]\subseteq\mathfrak{so}(V).
\]
This is the Cartan/symmetric-pair decomposition \(\mathfrak{sl}_4(\mathbb R)=\mathfrak{so}(4)\oplus\operatorname{Sym}^2_0(\mathbb R^4)\). The Hodge star on oriented \(V\) further decomposes \(\mathfrak{so}(4)=\mathfrak{so}(3)_+\oplus\mathfrak{so}(3)_-\), which become \(\mathbf3\oplus\mathbf3'\) under \(A_5\). This establishes an exact algebraic **comparison**, not an asserted physical gauge group or Lie-algebra action on the level-one complex momentum carrier \(H_1\).

## 5. Surviving 15-mode projector on the 120-element support

The 15-space is **incidence-visible**: it lies in \(Q\otimes Q\), perpendicular to \(\ker B\), and therefore survives the normalized finite-incidence map. Define
\[
 F_e(g):=\frac{1}{\sqrt{30}}\sum_{j=1}^5 (U_e)_{\pi(g)(j),j},\quad g\in2I.
\]
Then \(\sum_{g\in2I}F_e(g)F_f(g)=\delta_{ef}\). The group-function projector \(\Pi_{15}=\sum_e|F_e\rangle\langle F_e|\) has the independent, basis-free formula
\[
\boxed{\Pi_{15}(g,h)=\frac{4\chi_4(\pi(g)^{-1}\pi(h))-\chi_4(\pi(g))\chi_4(\pi(h))}{120},}
\]
where \(\chi_4(\sigma)=\#\operatorname{Fix}(\sigma)-1\) is the character of the five-point standard representation. This is the rank-16 \(\mathbf4\)-coefficient projector minus its normalized diagonal-conjugation character line. The projector is invariant under diagonal conjugation, not under arbitrary independent left-right translations.

On the diagonal, this gives an **exact source-stratum profile**:

| \(A_5\) permutation type | \(2I\) lift count | \(\chi_4\) | \(\Pi_{15}(g,g)\) | total diagonal trace |
|:--|--:|--:|--:|--:|
| identity (central \(\pm1\)) | 2 | 4 | 0 | 0 |
| double transpositions | 30 | 0 | \(2/15\) | 4 |
| three-cycles | 40 | 1 | \(1/8\) | 5 |
| five-cycles | 48 | −1 | \(1/8\) | 6 |
| **Total** | **120** | — | — | **15** |

Thus the basis-independent fifteen-mode projector vanishes at both central group elements, while its trace contributions across the three noncentral strata are exactly **4 + 5 + 6 = 15**. These are *projector leverage/participation weights*, not masses or probabilities of a physical measurement without a separately licensed state and readout.

## 6. GP2/GP3 scope and update decision

1. This bridge is a **new explicitly constructed map in the present archive** connecting the prior rank-17 five-core incidence and the prior 15-dimensional oriented Petersen edge module. It does not identify the distinct 25-dimensional five-irrep coefficient increment, the 15-complex-dimensional Spin(4) momentum carrier \(H_1\), or the 24-cell Bose–Mesner 15-block.
2. Its existence as an \(S_5\)-equivariant mathematical comparison does not automatically make \(\Phi\), the matrix commutator, a new source action, or a particle/Higgs/Yukawa readout GP2-licensed. A same-owner constructor/witness is required before interpreting any of them as physical.
3. The projector \(\Pi_{15}\) **does** descend through \(B\); in contrast the rank-one single-cell exclusion operation giving \(24/25\) in the orthogonal label carrier generally does **not** descend. These must not be conflated.
4. The universal Paper II-B GP3 multiplicity-one theorem is still conditional: neither \(W_P\cong\mathfrak{sl}(V)\) nor its finite incidence visibility is the missing whole-candidate structured-comparison certificate for \(H_p\cong H_1\).
5. **Integration status:** incorporated in v2.339: exact bridge in Paper I-A (mathematical atlas), a typed/conditional visibility export in Paper II-F/II-E, and a pointer in Paper V-B, with DAG edges and an explicit no-mass/no-gauge firewall. GP3 proof gating is intact.

**Verification:** `Paper00-PetersenEndomorphismBridge-v1_2.py` proves the rational matrix ranks, Gram formulas, projector idempotency, orthonormalization and group-stratum diagonal values, and checks the signed oriented-edge character across all 60 elements of \(A_5\).
