"""Source-scoped independent mathematical controls for BH VI-B repair batch 8.
No claim that numerical tests establish physical occurrence of the external optical clock or scalaron distributions.
"""
import math, json, random, hashlib
from pathlib import Path
import mpmath as mp
import sympy as sp
import numpy as np
from scipy.optimize import brentq

random.seed(12211013)
mp.mp.dps = 60
checks=[]
def chk(name, condition, detail=''):
    result=bool(condition)
    checks.append({'name':name,'passed':result,'detail':detail})
    if not result: raise AssertionError(name+' '+detail)

def ratio(t,chi): return math.sqrt(t)*math.sin(chi)/math.sin(t*chi)
def eps(t,chi): return .5-t*chi/math.tan(t*chi)
def fr(t): return t**(-.5)
# Closed fixed-radius optical geometry and independent evaluation
for (chi,t) in [(math.pi/6,2),(.04,1.7),(.3,2),(.5,1.5),(.8,.75),(.15,.2),(.75,2),(.9,1.2)]:
    assert t*chi < math.pi
    rd=1.414213562373095; radius=3.3; z=.88
    DM0=radius*math.sin(chi); DMT=radius*math.sin(t*chi)
    obs0=rd*(1+z)/DM0; obsT=math.sqrt(t)*rd*(1+z)/DMT
    chk(f'optical direct distance {t=:.2f} {chi=:.3f}', abs(obsT/obs0-ratio(t,chi))<2e-13)
# finite curvature vs flat test and exact independent square-root ratio
chi=math.pi/6;t=2
chk('optical spherical example exactly sqrt(2/3)',abs(ratio(t,chi)-math.sqrt(2/3))<1e-14)
chk('optical spherical example differs from flat',abs(ratio(t,chi)-fr(t))>.1)
for (t,chi) in [(1.2,.2),(1.4,.9),(1.65,.8),(2.0,.3),(2.4,.4),(3.,.7)]:
    chk(f'optical closed correction above flat {t} {chi}',ratio(t,chi)>fr(t))
# derivative in log T independently finite differenced at T=1
for chi in [.03,.15,.4,.7,1.,1.5,1.9,2.2]:
    h=1e-5
    f=(math.log(ratio(math.exp(h),chi))-math.log(ratio(math.exp(-h),chi)))/(2*h)
    chk(f'optical d log response {chi}',abs(f-eps(1,chi))<2e-9)
# multivariate and asymptotic series
for t in [.4,.75,1.5,2,2.25]:
    chi=1e-3
    first=fr(t)*(1+(t*t-1)*chi*chi/6)
    chk(f'optical second-order asymptotic {t}', abs(ratio(t,chi)-first)<4e-13)
# exact angular derivative sign-change location
root=brentq(lambda x: eps(1,x),.1,1.55)
chk('optical critical chi located',1.15<root<1.18,f'root={root}')
chk('optical sensitivity negative before root',eps(1,math.pi/6)<0)
chk('optical sensitivity positive after root',eps(1,math.pi/2)>0)
# full radius homothety vs fixed radius
for t in [.2,.8,1.25,1.7,2.5]:
    chi=.22; radius=5.; DC=radius*chi
    # under full homothety all length/radius scale linearly
    DM1=radius*math.sin(DC/radius)
    DMT=t*radius*math.sin(t*DC/(t*radius))
    chk(f'optical full radius homothety {t}',abs(math.sqrt(t)*DM1/DMT-fr(t))<1e-13)
# continuous flux law on the actual f_RR positive continuous-interface branch
for v in [-3.,-2e-4,-1e-12,0.,.2,4.5]:
    chi_pos=.3
    chk(f'K16 positive continuous Hessian allows rate {v}',math.isclose(chi_pos*v,chi_pos*v,abs_tol=1e-16))
chk('K16 nonzero transverse negative rate contradicts old zero claim',-1.0!=0 and (.3*(-1.0)==.3*(-1.0)))
# If non-equal Hessians but imposed C1, only zero rate matches
chk('K16 unequal Hessian generic forces zero C1 rate',(.3-.4)*1.0!=0 and (.3-.4)*0.0==0)
# Curvature-band inverse clock asymptotics, C1 crossing with quadratic jet
v=-.8;accel=.23
# R(t)=C2+v*t+accel*t*t; near t=0 inverse analytic with correct root
inv=lambda d:(-v-math.sqrt(v*v+4*accel*d))/(2*accel) # check root near 0? for v negative, -v=0.8; sqrt(v^2+4a d), ->0 at 0
for delta in [1e-2,1e-3,1e-4,1e-5]:
    duration=abs(inv(delta)-inv(-delta))
    approx=2*delta/abs(v)
    chk(f'K16 transverse-band inverse {delta}',abs(duration/approx-1)<3.0*(delta**2))
# weighted elasticity: symbolic 2 var with nonconstant logistic partition
x,y,k1,k2,beta,gamma=sp.symbols('x y k1 k2 beta gamma',positive=True)
# avoid exponential: phi=x/(1+x*y), not guaranteed positive for all positive x,y; use w=x*y/(1+x*y)
A=x**2*y**3; phi=x*y/(1+x*y)
F=sp.factor(A*phi); M=sp.factor(A*(1-phi))
chk('abundance F+M exact monomial',sp.simplify(F+M-A)==0)
for z,exponent in [(x,2),(y,3)]:
    E=lambda G:sp.cancel(z*sp.diff(G,z)/G)
    weighted=sp.cancel((F/A)*E(F)+(M/A)*E(M))
    chk(f'abundance weighted elasticity constant for {z}',sp.simplify(weighted-exponent)==0)
    chk(f'abundance unequal component elasticities {z}',sp.simplify(E(F)-E(M))!=0)
# exact positive 1D counterexample, derivatives at x=1
F1=x**2/(1+x);M1=x/(1+x);A1=F1+M1
chk('abundance 1D counterexample exact A=x',sp.simplify(A1-x)==0)
chk('abundance 1D unequal F elasticity',sp.simplify((x*sp.diff(F1,x)/F1).subs(x,1)-sp.Rational(3,2))==0)
chk('abundance 1D unequal M elasticity',sp.simplify((x*sp.diff(M1,x)/M1).subs(x,1)-sp.Rational(1,2))==0)
# double check decomposition with arbitrary smooth positive r(x) and nonmonomial A(x)
for xx in [.12,.4,1.1,3.4,8.9]:
    total=xx*(1+xx**.6);r=1/(1+xx)
    ff=total*r; mm=total*(1-r)
    chk(f'abundance positive partition {xx}',ff>0 and mm>0 and abs(ff+mm-total)<1e-12)
# source-label and exact source checks
w=Path(__file__).parent
source=(w/'Paper6B-CosmologyReadouts-v1_201.tex').read_text()
old=(w/'Paper6B-CosmologyReadouts-v1_200.tex').read_text()
import re
rx=r'\\label\s*\{([^}]+)\}'
oldlabels=set(re.findall(rx,old)); newlabels=re.findall(rx,source)
chk('source no duplicate labels',len(newlabels)==len(set(newlabels)))
chk('source zero old labels lost',oldlabels.issubset(set(newlabels)))
newset=set(newlabels)-oldlabels
expected={'p9:eq:v1201-transverse-k16-band-clock','p9:eq:v1201-curved-damping-ratio','p9:eq:v1201-curved-damping-sensitivity','p9:eq:v1201-homogeneous-positive-partitions'}
chk('source exact four new labels',newset==expected,str(newset))
chk('source old optional observer branch remains external','external' in source[source.find('Exact closed-curvature optical response'):source.find('Exact closed-curvature optical response')+1300])
# Imported specific theorem evidence also remains in current peer manuscript
p6a=(w/'Paper6A-GravityCosmology-v2_256.tex').read_text()
p3f=(w/'Paper3F-CompleteDynamics-v1_257.tex').read_text()
chk('source imported VI-A transverse rate less than zero',r'\boxed{H>0,\qquad \dot F<0,\qquad \dot R<0}' in p6a)
chk('source imported III-F continuous positive Hessian',r'\chi=f_{RR}>0' in p3f and r'[\chi]_{\Sigma_2}=0' in p3f)
results={'scope':'Mathematical VI-B repair batch 8; external T is not native; no actual cosmic abundance partition established','total':len(checks),'passed':sum(c['passed'] for c in checks),'checks':checks,'critical_chi':root,'spherical_T2_chipi6':ratio(2,math.pi/6),'flat_T2':fr(2),'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'new_labels':sorted(newset)}
out=w/'Paper00-ObservableRepairBatch8-v1_1-results.json'
out.write_text(json.dumps(results,indent=2)+'\n')
print('CHECKS',results['passed'],'/',results['total'])
print('Critical chi',root,'Closed ratio',ratio(2,math.pi/6),'flat ratio',fr(2))
print('New labels',sorted(newset))
