#!/usr/bin/env python3
"""Exact A5 F40 right/left shell <-> skew-core mirror gluing certificate.

Only finite graph/quaternion data.  No physical source, GP3 change, color
embedding, QCD Hamiltonian, or observed mass is asserted.

Run beside Paper00-PetersenHodgePlucker-v1_10-verify.py and v1_11-verify.py.
Requires sympy. The predecessor certificates also run and are rechecked.
"""
from __future__ import annotations
import collections
import csv
import json
from pathlib import Path
import runpy
import sympy as S

HERE = Path(__file__).resolve().parent
base = runpy.run_path(str(HERE/'Paper00-PetersenHodgePlucker-v1_11-verify.py'))
N=base['N']; T_R=base['T_R']; T_L=base['T_L']; A=base['A']
P_Z=base['P_Z']; P_skew=base['P_anti']
Aico=base['Aico']; Ant=base['Ant']; arcs=base['arcs']
shell=base['shell']; permaction=base['permaction']
assert N.shape==(60,21) and (T_R.shape,T_L.shape,A.shape)==((12,60),(12,60),(20,60))

# Use only the shell group action on five cores to define K.
K=S.zeros(20,12)
dist_counts=collections.Counter()
for a,(i,j) in enumerate(arcs):
    for k,g in enumerate(shell):
        p=permaction[g]; t=i; d=0
        while t!=j:
            t=p[t]; d+=1
        assert 1<=d<=4
        K[a,k]=S.Rational(5-2*d,40)
        dist_counts[d]+=1
assert dict(dist_counts)=={1:60,2:60,3:60,4:60}

# The antipodal shell operator is inversion on the set of twelve fivefold rotations.
Odd=(S.eye(12)-Ant)/2
assert (Aico*Odd)==(Odd*Aico)
assert Aico*Aico*Odd == 5*Odd
assert K*Odd==K and P_skew*K==K
assert K.T*K == (5*S.eye(12)+Aico)*Odd/40
assert (P_skew*A - K*(T_R-T_L))*N==S.zeros(20,21)
assert Odd*(T_R+T_L)*N==S.zeros(12,21)
print('PASS 1: cyclic-distance K entries all 240, and exact Hodge mirror gluing')

# Closed-form inverse between the six-dimensional antipodal-odd and skew-balanced spaces.
Kinv=2*(5*S.eye(12)-Aico)*K.T
assert Kinv*K==Odd
assert K*Kinv==P_skew
assert K.rank()==6
print('PASS 2: two-sided exact Hodge inverse, rank 6 and golden ratio conditioning')

# 23 explicit linear constraints on 44 raw samples (u in R12, v in R12, w in R20).
# Output order: 2 shell means + 5 arrow rows + 4 arrow cols + 6 shell inversion
# equations + 6 skew chord equations (a spanning star on five vertices).
C=S.zeros(23,44)
C[0,0:12]=S.ones(1,12)
C[1,12:24]=S.ones(1,12)
for r in range(5):
    for a,(i,j) in enumerate(arcs):
        if i==r: C[2+r,24+a]+=1
for c in range(4):
    for a,(i,j) in enumerate(arcs):
        if j==c: C[7+c,24+a]+=1
inverse_pairs=[]
for k in range(12):
    matching=[h for h in range(12) if Ant[k,h]==1]
    assert len(matching)==1
    h=matching[0]
    assert k!=h
    if k<h:
        inverse_pairs.append((k,h))
assert len(inverse_pairs)==6
for row,(k,h) in enumerate(inverse_pairs, start=11):
    C[row,k]=1;C[row,h]=-1
    C[row,12+k]=1;C[row,12+h]=-1
chords=[(i,j) for i in range(1,5) for j in range(i+1,5)]
assert len(chords)==6
for row,(i,j) in enumerate(chords,start=17):
    a=arcs.index((i,j));b=arcs.index((j,i))
    C[row,24+a]=S.Rational(1,2)
    C[row,24+b]=-S.Rational(1,2)
    for k in range(12):
        C[row,k]-=K[a,k]
        C[row,12+k]+=K[a,k]
M=S.Matrix.vstack(T_R,T_L,A)
R=M*N
assert R.rank()==21
assert C.rank()==23
assert C*R==S.zeros(23,21)
# Hence ker(C)=im(R) exactly: dimension 44-23=21 and containment holds.
print('PASS 3: 23 independent necessary-and-sufficient channel constraints')

# Native Euclidean cycle frame; its MINIMAL polynomial has five distinct roots.
G=N.T*N
F=G.inv()*(R.T*R)
z=S.Symbol('z')
fpoly=(z-1)*(z*z-12*z+31)*(z*z-8*z+6)
assert S.expand(F.charpoly(z).as_expr())==S.expand((z-1)**5*(z*z-12*z+31)**3*(z*z-8*z+6)**5)
F2=F*F;F3=F2*F;F4=F2*F2
Fminus=(F4-21*F3+153*F2-453*F+506*S.eye(21))/186
assert F*Fminus==S.eye(21) and Fminus*F==S.eye(21)
# Explicit Euclidean data projector Pi=R(R^T R)^{-1}R^T. Do not form
# Pi as a dense 44x44 matrix: full-column rank and the factorization prove
# Pi^2=Pi and Pi*=Pi. Their complements yield the 23 constraints above.
assert R.T*R == G*F
assert (R.T*R)*Fminus*G.inv()==S.eye(21)
print('PASS 4: exact degree-4 rational polynomial reconstruction inverse')

# Direct eigenspace dimensions and singular-gain invariants.
assert S.trace(Odd)==6 and S.trace(P_skew)==6
assert (K.T*K - (S.Rational(1,8)*Odd+S.Rational(1,40)*Aico*Odd))==S.zeros(12)
# Norm gains on the +sqrt5/-sqrt5 icosahedral triplets:
# (5+-sqrt5)/40, hence ratio of singular values = (1+sqrt5)/2.
phi=(1+S.sqrt(5))/2
assert S.simplify(((5+S.sqrt(5))/(5-S.sqrt(5))) - phi**2)==0
print('PASS 5: triplet singular gains and exact golden-ratio condition number')

with (HERE/'Paper00-F40MirrorGluing-v1_1-K.csv').open('w',newline='') as fout:
    writer=csv.writer(fout)
    writer.writerow(['arrow/shell']+[f'shell_{k}' for k in range(12)])
    for a,(i,j) in enumerate(arcs):
        writer.writerow([f'{i+1}->{j+1}']+[str(K[a,k]) for k in range(12)])
with (HERE/'Paper00-F40MirrorGluing-v1_1-C23.csv').open('w',newline='') as fout:
    writer=csv.writer(fout)
    writer.writerow(['constraint']+[f'R_{k}' for k in range(12)]+[f'L_{k}' for k in range(12)]+[f'arrow_{i+1}_{j+1}' for i,j in arcs])
    for r in range(23):
        writer.writerow([r+1]+[str(C[r,k]) for k in range(44)])
result={
  'status':'PASS exact finite mathematics; no physical source/action asserted',
  'baseline':'Paper00-PapersMinimal-v2_345(1).zip',
  'symbolic_arithmetic':'sympy rational; sqrt5 only in closed-form spectral formula',
  'cycle_dimension':21,'raw_channel_dimension':44,
  'compatibility_constraint_rank':23,
  'K_shape':[20,12],'K_rank':6,
  'K_distance_histogram':{str(k):v for k,v in sorted(dist_counts.items())},
  'K_entries':sorted({str(v) for v in K}),
  'K_nonnzero_singular_squared':'(5+sqrt(5))/40 (x3), (5-sqrt(5))/40 (x3)',
  'K_condition_number':'(1+sqrt(5))/2',
  'K_inverse':'2*(5*I12-A_ico)*K.T on skew-balanced arrow space',
  'frame_minimal_polynomial':str(S.expand(fpoly)),
  'frame_inverse':'(F^4-21F^3+153F^2-453F+506I)/186',
  'frame_eigenvalues':'1(x5), 6+sqrt5(x3),6-sqrt5(x3),4+sqrt10(x5),4-sqrt10(x5)',
  'physical_nonclaims':['no 2I occurrence proved','no SU3 singlet source','no actual QCD H_L coupling','no hadron mass poles']
}
(HERE/'Paper00-F40MirrorGluing-v1_1-results.json').write_text(json.dumps(result,indent=2)+'\n')
print('ALL NEW F40 MIRROR GLUING CERTIFICATES PASSED')
