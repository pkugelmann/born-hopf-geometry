# Born–Hopf Geometry: minimal Petersen repair of the F40 ↔ twisted-25 module gap

**Research proof v1_1 — 7 November 2026.**  **Baseline:** `Paper00-PapersMinimal-v2_345(1).zip`.

**Status:** exact, finite, representation-theoretic closure. This note and certificate do **not** revise the 30 canonical papers, bibliography, or theorem DAG and do not claim physical `2I` actualization, a color-singlet QCD embedding, GP3 selection, or a hadron mass pole.

## 1. The overlooked compatibility obstruction

Write `G=A5=2I/{±1}`. The v2_344 twisted Hurwitz coefficient space is the complete matrix-coefficient carrier of the unique 5-dimensional, center-even irreducible representation `V5`:

\[
 \mathcal T_{25}=\operatorname{End}(V_5)\quad (\dim=25).
\]

For the **diagonal conjugation** action `g·X=ρ5(g)Xρ5(g)^{-1}`, its character on the `A5` classes `(1,2A,3A,5A,5B)` is the squared five-character `(25,1,1,0,0)`. The real/complex representation decomposition is

\[
 \boxed{\mathcal T_{25}\cong\mathbf1\oplus\mathbf3\oplus\mathbf3'\oplus 2\mathbf4\oplus2\mathbf5.}\tag{1}
\]

The v2_345 theorem `p1:thm:v345-f40-edge-regular` yields the F40 cycle module

\[
 \boxed{\mathcal Z=\ker\partial_{40}\cong\mathbf3\oplus\mathbf3'\oplus3\mathbf5,\quad\dim\mathcal Z=21.}\tag{2}
\]

Its character is `(21,1,-3,1,1)`; it follows from the 60-edge regular module, minus two 20-vertex modules (stabilizer `C3`), plus the connected-graph constant. By real/complex Schur orthogonality and semisimplicity,

\[
 \boxed{\max_{L\in\operatorname{Hom}_{A_5}(\mathcal Z,\mathcal T_{25})}\operatorname{rank}L
  =3+3+2\cdot5=16.}\tag{3}
\]

**Theorem (sharp equivariant no-go).** No `A5`-equivariant linear map from all 21 F40 cycle modes to the twisted rank-25 coefficient carrier is injective. Every such map has a kernel of dimension at least five, and the bound is attained. This is a *symmetry-multiplicity* obstruction, not an ordinary dimension-counting obstruction; `25 > 21` does not help. It applies to the specified diagonal `A5` action, not to arbitrary symmetry-breaking maps or physical sources that have not been constructed.

## 2. Unique minimal additive representation type: an existing Petersen quintet

The ten unordered pairs of five core labels form the Petersen vertex module `\mathbb R^{\binom{5}{2}}`. Its `A5` character is `(10,2,1,0,0)`, giving

\[
\mathbb R^{10}_{\rm pair}\cong\mathbf1\oplus\mathbf4\oplus\mathbf5.
\]

Let `A_P` be the Petersen adjacency on these ten unordered pairs. Its spectrum is `3` (multiplicity 1), `1` (multiplicity 5), and `−2` (multiplicity 4). Thus the existing **canonical** rank-five projector is

\[
\boxed{P_{\mathrm P,5}=-\frac{(A_P-3I)(A_P+2I)}6.}\tag{4}
\]

**Theorem (minimal additive repair).** Among modules `W` for which there is an `A5`-equivariant injection

\[
 \mathcal Z\longrightarrow\mathcal T_{25}\oplus W,
\]

the minimal possible real dimension is `dim W=5`, necessarily with `W≅5`. The already present Petersen eigenspace `W=im(P_{P,5})` attains this bound:

\[
 \boxed{\mathcal Z\hookrightarrow\operatorname{End}(V_5)\oplus\operatorname{im}(P_{\mathrm P,5})\quad\text{equivariantly},}\tag{5}
\]

because the codomain contains one `3`, one `3′`, and **three** `5`s. The embedding is not unique merely from the representation types: the three isotypic quintet directions admit nontrivial mixing. The *existence and minimal extra representation type* are exact, whereas identifying a privileged physical coupling still requires the same-action source.

**No new constitutional axiom and no new independent geometric irrep is required.** This is a repair using the Petersen quintet already present in the atlas, not a postulated extra physical particle multiplet.

## 3. Explicit native 21-mode readout (constructive, not just an existence theorem)

Use the exact `v2_345` intrinsic maps from F40 oriented edges, restricted to its cycle space:

- `T_R,T_L : Z → R^12`, respectively right and left fivefold quaternion quotient histograms;
- `A: Z → R^20`, the directed five-core arrow histogram;
- `P_anti` the skew, doubly-balanced arrow projector, of dimension 6.

Let `Ant` be antipodal permutation on the 12-element fivefold shell, and `J_12` the all-ones matrix. The unique `5`-isotypic projector of the 12-point shell action is

\[
 \boxed{P_{\mathcal S,5}=\tfrac12(I_{12}+\mathrm{Ant})-\tfrac1{12}J_{12}.}\tag{6}
\]

For a directed arrow histogram `Y=(Y_ij)`, define its symmetric unordered-pair projection

\[
 (J_{\rm pair}Y)_{\{i,j\}}=\tfrac12(Y_{ij}+Y_{ji}).\tag{7}
\]

On cycle inputs, row and column sums of `Y=Az` vanish. Hence `y=J_pair Az` satisfies `∑_{j≠i} y_{ij}=0`. For any unordered pair `{i,j}`,

\[
 (A_Py)_{ij}=\sum_{\{k,l\}\cap\{i,j\}=\varnothing}y_{kl}=y_{ij},
\]

because the total pair sum and both row sums vanish. Therefore `y∈im(P_{P,5})`; the map has rank five (as independently verified in v2_345).

Define the entirely native reduced readout

\[
\boxed{\mathcal M z=\begin{pmatrix}
 P_{\mathcal S,5}(T_R+T_L)z\\
 P_{\mathcal S,5}(T_R-T_L)z\\
 J_{\rm pair}Az\\
 P_{\rm anti}Az
\end{pmatrix}.}\tag{8}
\]

Its four output images have respective dimensions `5`, `5`, `5`, and `6`. The first three span the three quintet multiplicity directions, and the last represents `3⊕3′`. The `v2_345` three-native-readout theorem implies (and the appended exact integer-matrix certificate independently checks) that

\[
\boxed{\operatorname{rank}(\mathcal M|_{\mathcal Z})=5+5+5+6=21.}\tag{9}
\]

Thus `(8)` is **lossless and has exactly 21 effective coordinates**. Although stored in redundant 12+12+10+20 coordinate charts, its image is 21-dimensional. In particular, the `J_pair A` channel is an explicit, native realization of the previously missing fifth-dimensional Petersen sector.

The inverse on the cycle subspace exists canonically relative to the fixed Euclidean metrics:

\[
 \boxed{z=(\mathcal M^*\mathcal M|_{\mathcal Z})^{-1}\mathcal M^*\mathcal M z,\quad z\in\mathcal Z,}
\]

or, for supplied compatible readout data `d=Mz`,

\[
 z=(\mathcal M^*\mathcal M|_{\mathcal Z})^{-1}\mathcal M^*d.
\]

This is mathematical reconstruction; it does **not** assert the projected histograms are physically implemented POVMs.

## 4. Consequences and boundaries

1. **A5-invariant linear scalar no-go.** `Z` contains no trivial representation, hence `Hom_A5(Z,1)=0`. No nonzero `A5`-invariant scalar can be obtained *linearly from the cycle input alone*. This forbids a universal first-order scalar correction based solely on an unbroken, equivariant F40 cycle coordinate. It does not forbid a bilinear matter–cycle coupling or broken-`A5` matrix element.
2. **The first nontrivial scalar cycle-only response can be quadratic.** For real `Z=3⊕3′⊕3·5`, invariant symmetric bilinear forms have dimension `1+1+6=8`: one on `3`, one on `3′`, and a symmetric `3×3` form on quintet multiplicities. The geometry does not determine those physical coefficients.
3. **Existing mathematical atlas closes the missing representation type.** The v2_344 twisted `25` and v2_345 F40 `21` must not be equated by dimensional analogy. The corrected comparison uses an additional **already available** Petersen `5` projector.
4. **The outstanding physical gap is now narrower.** To claim a hadron readout one must still exhibit the actual `SU(3)`-singlet embedding, source matrix, action coefficient, leakage calculation, and energy poles of `H_L`. This result does not supply any of those.

## 5. Reproducible certificate

Run `python Proofs/Paper00-F40ModuleClosure-v1_1.py` with the existing `Paper00-PetersenHodgePlucker-v1_10-verify.py` and `...v1_11-verify.py` in the same directory. It checks the A5 character decompositions with exact `Q(√5)` arithmetic, the sharp rank bound, the Petersen rank-five spectral projector, all v2_345 exact F40 source matrices, the proposed symmetric-arrow identification and the new `rank 21` reduced readout.

**Proposed manuscript ownership, if integrated later:** main theorem in Paper I-A; exact certificate in I-C; comparison-readout corollary in II-C; symmetry-source firewall and no linear scalar claim in VII-A/B; theorem DAG with explicit mathematical versus physical typing.
