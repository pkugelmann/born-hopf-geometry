# Paper00 — Native two-source Petersen–Clifford bridge — v2_337

**Status:** Exact finite geometry and representation-theoretic source-eligibility results; **no physical hadron mass prediction**, no new same-action matrix entries, and no RG-running or phenomenological mass fitting. The canonical papers, macro, bibliography, and DAG have **not** been modified.

**Authoritative baseline:** `Paper00-PapersMinimal-v2_327.zip` (the latest supplied self-contained archive). Extends standalone `Paper00-NativeMesonEnergy-v2_336.md`. Independent exact certificate: `Paper00-NativeMesonBridge-v2_337.py`; results in `Paper00-NativeMesonBridge-v2_337-results.json`.

## I. The observable-driven problem

We seek the *source-owned* rest-energy poles of pion and kaon ground states, including their charged/neutral splitting, without importing quark-mass RG running or using measured meson masses to choose a coefficient. The formal issue is whether the five-core/Petersen geometry can provide (i) typed two-constituent source channels, (ii) a compatible map to the actual matter/color-singlet space, and (iii) a determined finite energy operator. This note derives (i) as a finite geometric candidate, identifies new representation-level bridges in (ii), and proves that (iii) does **not** follow from these constructions alone.

The owning baseline claims already distinguish a geometric Petersen packet from an action-owned physical mass source: Paper V-A, `p5:thm:v321-rooted-3plus12-matter`; Paper V-C, `p5c:prop:v321-petersen-color-arrows` and `p5c:prop:v321-petersen-no-automatic-insertion`; Paper III-F, `p3f:cor:v319-petersen-response-owner`; Paper VII-A, `p10:def:v323-action-incidence-test` and `p10:thm:v327-compression-leakage-pythagoras`; Paper VII-B, `p11:prop:v327-no-automatic-meson-spectrum`.

## II. One oriented two-core source: no A5 scalar; one rooted A4 scalar

Let `W=R^5` be the five-core label space and `U=Λ²W`, dimension 10, with canonical basis `e_ij=e_i∧e_j`. On the orientation-preserving five-core group `A5`,

\[
U \cong V_4\oplus V_3\oplus V_{3'},\qquad \dim U=4+3+3=10.
\]

There is no `A5`-fixed vector: `Hom_A5(U,1)=0`. Thus no nonzero **A5-invariant linear scalar readout** of one oriented pair exists. Fix root `r`; its stabilizer is `A4`. Restriction yields

\[
\boxed{U\downarrow_{A_4}=\mathbf1\oplus3\,\mathbf3.}
\]

There is exactly one rooted invariant unit vector

\[
w_r=e_r\wedge\frac12\sum_{j\ne r}e_j\in U,
\qquad \|w_r\|=1.
\]

For all five roots, these vectors obey the regular-simplex identities

\[
\boxed{\langle w_r,w_s\rangle=\begin{cases}1&r=s,\\-1/4&r\ne s,\end{cases}
\quad \sum_r w_r=0,\quad \sum_r|w_r\rangle\langle w_r|=\frac54 P_4.}
\]

Here `P4` is the exact four-dimensional Hodge/Petersen projector of v2_336. In particular `P4 w_r=w_r` and `S w_r=0`: the *unique* rooted scalar is blind to both signed Petersen Hodge triplets. Merely selecting a root cannot obtain unequal positive masses from their ± signs.

**Certificate:** averages of all 60 signed two-core permutation matrices and of the 12 root-stabilizer matrices are respectively the zero projector and `|w_r><w_r|`; all five simplex identities and Hodge identities are exact integer/rational matrix equalities.

## III. Exact deficit relative to the existing rooted matter comparison

Paper V-A's sourced **comparison** module satisfies

\[
Q\otimes G\downarrow_{A_4}\cong\operatorname{Reg}(A_4)
=\mathbf1\oplus\mathbf1'\oplus\mathbf1''\oplus3\,\mathbf3,
\]

whereas the one-pair module contains only `1⊕3·3`. Therefore

\[
\boxed{\text{formal missing A4 representations}=\mathbf1'\oplus\mathbf1''.}
\]

This is an equality of representation types, **not** subtraction of physical states or proof of any missing particle. The space of possible complex `A4` intertwiners from `U` to `Q⊗G` has dimension

\[
\dim_{\mathbb C}\operatorname{Hom}_{A_4}(U,Q\otimes G)
=1^2+3^2=\boxed{10}.
\]

Even at the comparison level, symmetry alone cannot choose one of these maps; the compatible isometric maps contain a phase and a `U(3)` multiplicity ambiguity. The genuine color-gauge and same-action compatibility is a separate obligation (Paper V-C).

## IV. The missing cyclic phase channels occur at quadratic order

Fix root `0`, so the four complementary cores are `1,2,3,4`. For a real oriented pair amplitude `x=∑_{i<j}x_ij e_ij`, define

\[
q_1=x_{12}x_{34},\qquad
q_2=-x_{13}x_{24},\qquad
q_3=x_{14}x_{23}.
\]

Every root-preserving `A4` transformation **permutes** `(q1,q2,q3)` by the cyclic quotient `A4/V4≅C3`. Exactly four `A4` elements induce each of the three cyclic permutations; tested directly against all twelve signed-pair matrices. The discrete Fourier modes

\[
\begin{aligned}
q_0&=(q_1+q_2+q_3)/\sqrt3,\\
q_\omega&=(q_1+\omega^2q_2+\omega q_3)/\sqrt3,\\
q_{\bar\omega}&=(q_1+\omega q_2+\omega^2q_3)/\sqrt3,
\quad \omega=e^{2\pi i/3}
\end{aligned}
\]

transform as `1⊕1'⊕1''`. Therefore the **two missing irreducible types first occur in a degree-two, rooted, geometry-defined source**; they do not occur at degree one. For a real amplitude, `q_baromega=conj(q_omega)`, so the phase conjugates have equal squared strength. This is a conditional mirror/charge-conjugacy **capacity**, not a proof of physical charge or parity.

The sharp normalization bound is

\[
\boxed{|q_\omega|=|q_{\bar\omega}|\le \frac{\|x\|^2}{2\sqrt3}.}
\]

The triangle inequality and `|ab|≤(|a|²+|b|²)/2` prove it. Equality is attained by an equal-amplitude superposition of two disjoint pair-basis labels lying in the selected complement. A single basis pair and any two basis pairs sharing a core have all three `q` values zero. Hence this nonlinear phase source detects genuine disjoint-pair coherence, not arbitrary particle labels.

### Rooted Pfaffian non-decomposability test

The scalar Fourier member is the rooted four-dimensional Pfaffian:

\[
q_0=\frac{1}{\sqrt3}\operatorname{Pf}(x|_{\{1,2,3,4\}}).
\]

All five rooted Pfaffians form the canonical five-vector

\[
\boxed{\mathcal P(x)=*_5(x\wedge x)\in\mathbb R^5.}
\]

For real `x∈Λ²R5`, skew-normal form gives `x=s1 e12+s2 e34` after an orthogonal change of frame. It follows that

\[
\|\mathcal P(x)\|=2|s_1s_2|\le s_1^2+s_2^2=\|x\|^2.
\]

Equality requires balanced orthogonal planes, `|s1|=|s2|`; `P(x)=0` iff `rank(x)≤2`, i.e. `x` is a decomposable two-form (including zero). Thus the map exactly distinguishes a single-plane pair assembly from coherent rank-four pair occupancy **without masses**. For `(e01+e23)/sqrt2`, `P(x)=e4` and the bound is saturated. These claims were checked by a covariant five-component implementation under all 60 `A5` transformations.

## V. The full antisymmetric two-source space is three Petersen Clifford-edge modules

A two-source *alternating* amplitude belongs to `Λ²U`, of dimension `C(10,2)=45`. Its basis elements are `e_A∧e_B`, where `A,B` are distinct two-subsets of five labels. They divide by intersection:

* **Disjoint:** `A∩B=∅`, 15 basis elements — precisely the fifteen Petersen edges.
* **Overlap:** `|A∩B|=1`, 30 basis elements — divided by which of the five cores is shared, each root contributing a 6D `Λ²R4`.

Each rooted 6D overlap module has an orientation-induced four-dimensional Hodge star `*_r`, with `*_r²=1` and 3D eigenspaces of either sign. The sum of the five such stars commutes with the full `A5` action and splits the 30D overlap module as `15+15`. Combined with the disjoint 15D module:

\[
\boxed{\Lambda^2(\Lambda^2\mathbb R^5)=E_{15}\oplus O_{15}^{+}\oplus O_{15}^{-},\qquad 45=15+15+15.}
\]

The three projectors are `P_D` (disjoint), `(P_O+C)/2`, `(P_O−C)/2`, where `P_O=I−P_D` and `C=⊕_r *_r` on the overlapping sector and zero on the disjoint sector. Their ranks are each 15; they are pairwise orthogonal, self-adjoint idempotents and commute with all 60 `A5` matrices. The complement involution has spectrum `(+1)^15, (-1)^15, 0^15`.

**Stronger exact representation theorem:** Each of the three 15D sectors is `A5`-isomorphic to the *same* signed Petersen-edge carrier `W_P` already established in Paper V-A:

\[
\boxed{E_{15}\cong O_{15}^{+}\cong O_{15}^{-}
\cong \operatorname{Ind}_{A_4}^{A_5}(\mathbf3)
\cong\mathbf3\oplus\mathbf3'\oplus\mathbf4\oplus\mathbf5.}
\]

The character of **each** sector is 15 on the identity, −1 on the fifteen double transpositions, and zero on all twenty 3-cycles and twenty-four 5-cycles. The exact character check was performed for all sixty group elements. This representation identity follows independently because each of the three sectors consists of five rooted tetrahedral 3D modules, permuted transitively by `A5`.

This is a new bridge *within the framework*. It is not an assertion that the exterior algebra or A5 character table is new to mathematics, and the **three equivalent modules are not three experimentally established meson families**.

## VI. A concrete geometry-native two-source map to the Petersen edge carrier

For two independent oriented pair amplitudes `x,y∈U`, define

\[
\boxed{[\mathsf J(x,y)]_{\{A,B\}}
=x_Ay_B-x_By_A,\qquad A\cap B=\varnothing,}
\]

with an oriented edge convention. This is the orthogonal restriction of `x∧y` to the disjoint 15D sector. It is alternating, and its 15-coordinate output is surjective. When all pair orientations are tracked, its `A5` edge representation differs from Paper V-A's chosen oriented-Petersen-edge convention only by a **fixed diagonal Levi-Civita sign gauge**:

\[
D_{\rm edge}^{\rm pair}(g)=E_\varepsilon
D_{\rm edge}^{\rm PaperVA}(g)E_\varepsilon,
\qquad E_\varepsilon=\operatorname{diag}\varepsilon_{mijkl}.
\]

This was checked for all sixty `A5` elements. It gives a fully explicit equivariant bilinear bridge from oriented two-core source amplitudes to the previously established five local Clifford triples.

With `r` an actual selected root, the fifteen edge directions split into the rooted Clifford triple `V_r` and the other twelve directions. The **latter** form the free transitive `A4` orbit already identified in Paper V-A:

\[
\boxed{P_{12,r}\mathsf J:\Lambda^2 U\twoheadrightarrow
W_{P,r}^{(12)}\cong\operatorname{Reg}(A_4)\cong Q\otimes G}
\]

**as abstract `A4` representations**. The first arrow is explicit and surjective of rank 12. The last isomorphism is a known *representation comparison* and is not a fixed physical color-/weak-/family-compatible map. This resolves a source **capacity** question, not the actual same-action physical embedding.

An independent **symmetric** quadratic map supplies the cyclic phase channels in Section IV. These should not be confused with the *antisymmetric signed edge* module in this section; having equal dimensions does not make them identical physical operators.

## VII. The simplest resulting interaction operator fails as a mass operator

On normalized antisymmetric two-source amplitudes, the disjoint-edge map `J:Λ²U→R15` is a partial isometry:

\[
\boxed{JJ^\dagger=I_{15},\qquad
J^\dagger J=P_D,\qquad
\operatorname{Spec}(P_D)=\{1^{(15)},0^{(30)}\}.}
\]

On the ordered `U⊗U` source it has unnormalized `JJ†=2I15`, with normalization fixed by antisymmetrization. Therefore the simplest canonical positive contact `J†J` selects *which channels can interact* but produces only one nonzero value. Any shared rest-energy map of this projector alone would give a single nonzero mass and no charged-neutral or pion-kaon hierarchy. Multiplying by `E32`, `E36`, or `E40` cannot fix this structural deficiency.

Allowing all self-adjoint `A5`-equivariant operators on the two-source carrier also does not fix masses: the complete 45D decomposition contains **three copies of each** `3,3',4,5` irreducible representation. Thus its commutant is

\[
\operatorname{End}_{A_5}(\Lambda^2 U)
\cong M_3(\mathbb C)^{\oplus4},\qquad
\dim_{\mathbb C}=36.
\]

Generic equivariant Hermitian operators can have twelve distinct levels (three for each of four irreducible types). Having *enough* possible levels is not a prediction: their values depend on an action that has not been selected. The apparent 25/2 pion/kaon squared-mass ratio from v2_336 is consequently **not** derived by this bridge.

### Clifford contraction of the rooted three-axis output

The isometric rooted identification `V_r≅Im(H)` permits a **candidate** quaternionic Clifford contraction of the three-vector output `v=P_{V_r} J(x,y)`. With the conventional anti-Hermitian Pauli presentation `c(v)=i(v1 σ1+v2 σ2+v3 σ3)`, one has the exact relations

\[
\boxed{\operatorname{tr}c(v)=0,\quad c(v)^2=-\|v\|^2I_2,\quad c(v)^\dagger c(v)=\|v\|^2I_2.}
\]

Thus an isolated scalar **linear trace** of the proposed two-source Clifford output vanishes; its first nonzero self-contracted scalar is `||v||²`, quartic in the underlying constituent amplitudes `x,y`. An *actual* action-owned background Clifford direction could also yield a lower-degree mixed contraction, so this is not a theorem that every possible meson interaction must be quartic. It instead identifies the precise scalar contacts whose coefficients and same-action occurrence must be checked. This distinguishes an algebraically available Clifford map from a generated physical vertex.

## VIII. Four exact coherent two-label Hodge fingerprints

For any two different basis pair labels `A,B`, normalized coherent states `(e_A±e_B)/sqrt2` give **exactly four** sorted projector-response signatures `(P4,P+,P−)`:

| Pair relation and phase class | `P4` | `P+` | `P−` | Number of the 90 oriented-sign cases |
|---|---:|---:|---:|---:|
| Share one core, channel A | 1/5 | 2/5 | 2/5 | 30 |
| Share one core, channel B | 3/5 | 1/5 | 1/5 | 30 |
| Disjoint, orientation + | 2/5 | `(3+sqrt5)/10` | `(3−sqrt5)/10` | 15 |
| Disjoint, orientation − | 2/5 | `(3−sqrt5)/10` | `(3+sqrt5)/10` | 15 |

Every row sums to one. The disjoint-channel ratio is `[(3+sqrt5)/(3−sqrt5)]=φ^4`, where `φ=(1+sqrt5)/2`. Its square-root amplitude ratio is `φ²`. These are exactly geometry-native response signatures, but **do not assign** observed mesons or their masses.

## IX. Explicit physical status and the only valid next action test

**Derived and verified:** the first linear-scalar obstruction; the unique rooted scalar and five-root simplex; the missing comparison irreps; the quadratic `C3` phase source; the five-dimensional Pfaffian rank discriminator; the three full 15D two-source sectors; the exact equivariant map to Paper V-A's signed edge packet; the rank-12 rooted regular comparison; and the projector/contact no-go.

**Not derived:** an actual observed two-constituent state, physical `SU(3)`-compatible `J_r` into `H_{L,sing}`, a native energy/clock coefficient multiplying the new source, a source-owned interaction Hessian/transfer, a nonzero hadron source residue, and masses of `pi0, pi±, K±, K0`. Paper VII-A's compiled `H_L` is a *typed family of finite matrices*: the currently supplied archive still leaves the relevant physical quark-source member and gauge/strong execution interfaces to be evaluated. It is invalid to promote the just-built geometric `J` or `P_D` into a physical term merely because it is natural. We do not import RG running to fill this gap.

The precise next calculation is to locate the *actual* two-source mixed jet in the frozen Born–Hopf action; test its contraction against `J` and the rooted twelve-channel comparison; evaluate the exact color-singlet receiver and physical state; retain the leakage

\[
B_{\rm leak}=(I-\iota\iota^\dagger)(H_L-E_0)\iota;
\]

then compute full resolvent poles and residues on that same action. Zero leakage is not assumed. If the mixed jet vanishes, the sourced term is absent and the proposed meson mechanism is falsified **at this order**; if nonzero, its coefficient, spin/charge sector, and mass normalization must be read directly from the same source rather than chosen to fit observed masses.

**Current conclusion:** the first nontrivial **geometry-native two-source-to-matter representation bridge** is now explicit. The mass program has moved past a pure dimension analogy, but the physical source-action incidence and rest-energy eigenvalues remain open. Canonical updates should integrate only the exact geometry after an owner/DAG audit; no mass claim is established.
