#!/usr/bin/env python3
"""Independent certificate for three typed Born--Hopf mathematical closures.
Baseline: Paper00-PapersMinimal-v2_347(1).zip, with earlier standalones
Paper00-TwistedHarmonicAlias-v1_1 and Paper3G-BornMeronHodge-v1_1.
These checks are not a proof of any physical source or action coupling.
Requires sympy, mpmath, numpy; uses exact algebra for finite checks.
"""
from __future__ import annotations
import json, math
from collections import defaultdict
from pathlib import Path
import sympy as sp
import mpmath as mp
import numpy as np
from numpy.polynomial.hermite_e import hermeroots, hermeval
from sympy.physics.wigner import clebsch_gordan, wigner_3j
ROOT=Path(__file__).resolve().parent

# (1) invariant tensor spaces of spin two restricted to 2I/A5.
sizes=[1,15,20,12,12]
chars=[5,1,-1,0,0]
def fixed_dim(k):
    assert k>=1
    return sum(w*c**k for w,c in zip(sizes,chars))//60
mult={2:1}
components=[]
for k in range(1,5):
    dSU=mult.get(0,0)
    dG=fixed_dim(k)
    d6=mult.get(6,0)
    assert dG-dSU==d6, (k,dG,dSU,d6)
    assert sum((2*j+1)*m for j,m in mult.items())==5**k
    components.append(dict(tensor_degree=k,continuous_invariants=dSU,
        finite_2I_invariants=dG,defect_rank=dG-dSU,spin6_multiplicity=d6))
    new=defaultdict(int)
    for j,m in mult.items():
        for J in range(abs(j-2),j+3):new[J]+=m
    mult=dict(new)
assert [x['defect_rank'] for x in components]==[0,0,1,6]
assert [x['continuous_invariants'] for x in components]==[0,1,1,5]
# Explicit test of cubic Wigner-3j and quartic 5-channel CG couplings.
x=sp.Symbol('x')
p2=sp.legendre(2,x)
assert sp.integrate(p2**3,(x,-1,1))/2==wigner_3j(2,2,2,0,0,0)**2==sp.Rational(2,35)
cg_quartic=sum(clebsch_gordan(2,2,J,0,0,0)**4/sp.Integer(2*J+1) for J in range(5))
assert sp.simplify(cg_quartic-sp.integrate(p2**4,(x,-1,1))/2)==0
assert cg_quartic==sp.Rational(3,35)

# (2) Full Born-meron zeta/heat spectral response.
mp.mp.dps=50
zeta3=mp.zeta(3)
def meron_zeta(s,r=1):
    # Euler-binomial analytically continued expression for n>=2 scalar/exact sum.
    aa=mp.zeta(2*s-2)-1
    for k in range(1,80):
        aa+=mp.rf(s,k)/mp.factorial(k)*(mp.zeta(2*s+2*k-2)-1)
    bb=mp.zeta(2*s-2)-mp.zeta(2*s)
    return 2*mp.power(r,2*s)*(aa+bb)
meron=[]
for r in [mp.mpf('1'),mp.mpf('2.1')]:
    z0=meron_zeta(0,r)
    der=mp.diff(lambda s:meron_zeta(s,r),0)
    expected=-2*mp.log(r)+2*mp.log(2)-2*zeta3/(mp.pi**2)
    assert abs(z0+1)<mp.mpf('1e-40')
    assert abs(der-expected)<mp.mpf('1e-40')
    det=mp.exp(-der)
    det_closed=r*r/4*mp.exp(2*zeta3/(mp.pi**2))
    assert abs(det-det_closed)<mp.mpf('1e-40')
    meron.append(dict(r=str(r),zeta_zero=str(z0),zeta_prime_zero=mp.nstr(der,42),
            det_prime=mp.nstr(det,42),abs_error=mp.nstr(abs(det-det_closed),5)))

# Exact elementary telescoping formula for the convergent correction in A'(0).
N=sp.symbols('N',integer=True,positive=True)
for n in [2,3,5,11]:
    lhs=sp.N(sum(j*j*sp.log(1-sp.Rational(1,j*j)) for j in range(2,n+1)),40)
    rhs=sp.N(2*sp.loggamma(n)-sp.log(2)-(2*n-1)*sp.log(n)+n*n*sp.log(1+sp.Rational(1,n)),40)
    assert abs(lhs-rhs)<sp.Float('1e-35')
series_correction=mp.nsum(lambda k:(mp.zeta(2*k-2)-1)/k,[2,mp.inf])
assert abs(series_correction-(mp.mpf(3)/2-mp.log(mp.pi)))<mp.mpf('1e-45')
for u in [mp.mpf('0.25'),mp.mpf('0.5'),mp.mpf('1.3')]:
    trace=1+2*sum(n*n*mp.exp(-u*(n*n-1))+(n*n-1)*mp.exp(-u*n*n) for n in range(2,120))
    theta=lambda a:mp.jtheta(3,0,mp.exp(-a))
    theta_trace=-(1+mp.exp(u))*mp.diff(theta,u)-theta(u)
    assert abs(trace-theta_trace)<mp.mpf('1e-42')
# Extract first coefficients from the exact modular-theta expression.
u=sp.Symbol('u')
local=sp.series((1+sp.exp(u))/2-u,u,0,8).removeO()
coeff=[sp.expand(local).coeff(u,k) for k in range(8)]
assert coeff==[sp.Integer(1),-sp.Rational(1,2)]+[sp.Rational(1,2*math.factorial(k)) for k in range(2,8)]

# (3) Full truncated-oscillator vacuum quadrature law.
q=sp.Symbol('q')
cutoff=[]
for cap in range(1,8):
    J=sp.zeros(cap+1)
    for i in range(cap):J[i,i+1]=J[i+1,i]=sp.sqrt(i+1)
    cp=sp.factor(J.charpoly(q).as_expr())
    assert sp.expand(cp-sp.hermite_prob(cap+1,q))==0
    # The endpoint Stieltjes numerator is the ASSOCIATED Hermite polynomial.
    associated0,associated1=sp.Integer(1),q
    for n in range(2,cap+1):
        associated0,associated1=associated1,sp.expand(q*associated1-n*associated0)
    numerator=(q*sp.eye(cap+1)-J).adjugate()[0,0]
    assert sp.expand(numerator-associated1)==0
    for k in range(1,cap+1):
        assert sp.simplify((J**(2*k))[0,0]-sp.factorial2(2*k-1))==0
    first=(J**(2*cap+2))[0,0]-sp.factorial2(2*cap+1)
    assert first==-sp.factorial(cap+1)
    cutoff.append(dict(N=cap,characteristic=str(cp),
        resolvent_numerator=str(sp.factor(numerator)),
        first_nonGaussian_order=2*cap+2,first_cumulant_normalized=str(first)))
# Root/weight formula independent verification using eigensystems.
for cap in range(1,9):
    coefs=np.zeros(cap+2);coefs[-1]=1
    roots=hermeroots(coefs)
    cnum=np.zeros(cap+1);cnum[-1]=1
    weights=np.array([math.factorial(cap)/((cap+1)*hermeval(t,cnum)**2) for t in roots])
    J=np.zeros((cap+1,cap+1))
    for i in range(cap):J[i,i+1]=J[i+1,i]=math.sqrt(i+1)
    eigenvals,vec=np.linalg.eigh(J)
    assert np.max(np.abs(eigenvals-roots))<1e-10
    assert np.max(np.abs(vec[0,:]**2-weights))<1e-10
    assert min(weights)>0 and abs(sum(weights)-1)<1e-10
# Independent two-mode noncancellation: N=1, N=2, c=(2,1), sigma=1.
J1=sp.Matrix([[0,1],[1,0]])
J2=sp.Matrix([[0,1,0],[1,0,sp.sqrt(2)],[0,sp.sqrt(2),0]])
Q=2*sp.kronecker_product(J1,sp.eye(3))+sp.kronecker_product(sp.eye(2),J2)
zero=sp.zeros(6,1);zero[0]=1
m2=(zero.T*(Q**2)*zero)[0]
m4=(zero.T*(Q**4)*zero)[0]
kap4=m4-3*m2*m2
assert sp.simplify(kap4+2*2**4)==0  # only N=1 contributes at order 4

result={
    'status':'PASS', 'baseline':'Paper00-PapersMinimal-v2_347(1).zip',
    'mathematical_scope_only':True,
    'closure_A':dict(icosahedral_tensor_invariants=components,
        spin2_cubic_wigner_square='2/35',spin2_quartic_CG_example='3/35',
        rank3_defect=1,rank4_defect=6),
    'closure_B':dict(meron=meron,
        all_order_heat_coefficients='c0=1,c1=-1/2,ck=1/(2*k!) for k>=2',
        determinant_exact='r^2/4 * exp(2*zeta(3)/pi^2)',
        zeta_derivative_exact='-2*log(r)+2*log(2)-2*zeta(3)/pi^2'),
    'closure_C':dict(oscillator=cutoff,
        vacuum_weights='N!/((N+1)*He_N(x_j)^2), x_j zero of He_(N+1)',
        resolvent='sigma^-1 * AssocHe_N(z/sigma)/He_(N+1)(z/sigma)',
        multimode_N1_N2_first_cumulant='-32',
        independent_modes_first_nonGaussian='-m!*sum((c_a*sigma_a)^(2m)) at m=min(N_a+1) for nonzero coefficients'),
    'physical_nonclaims':['no actual 2I source selected','no physical meron functional determinant incidence or coefficient',
        'no actual occupation cap or quadrature measurement selected','no hadronic pole or new particle mass']
}
path=ROOT/'Paper00-MultiGapClosures-v1_1-results.json'
path.write_text(json.dumps(result,indent=2)+'\n')
print('PASS: ranks (0,0,1,6); exact SU2 cubic/quartic vertex examples')
print('PASS: complete Born-meron zeta derivative/determinant, theta and all heat coefficients')
print('PASS: 1..7 finite Hermite Jacobi moments/resolvent and 1..8 Gauss weights')
print('PASS: two-mode noncancellation witness')
print('unit-radius determinant:',meron[0]['det_prime'])
print('results:',path)
