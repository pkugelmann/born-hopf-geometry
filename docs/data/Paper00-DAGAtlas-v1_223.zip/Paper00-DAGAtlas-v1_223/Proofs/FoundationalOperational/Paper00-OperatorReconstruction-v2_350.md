# Born–Hopf Geometry — Operator Reconstruction and Covariant Bridge Closures

**Delta:** `Paper00-OperatorReconstruction-v2_350`  
**Inspected baseline:** `Paper00-PapersMinimal-v2_349(1).zip`, especially Papers II-A/II-B and the prior foundational note `v2_349`.  
**Status:** exact finite-dimensional mathematical closures; no claim that bare G0 already selects physical multiplicity, or that unlicensed bridge operations physically occur. This supplement is not merged into the 30-paper source release.

## 1. Canonical minimum faithful carrier theorem (new unconditional algebraic result)

**Theorem A.** Let `A = ⊕_{i=1}^r M_{d_i}(C)` be a finite-dimensional unital complex C*-algebra, with its central minimal projections `p_i`. Every faithful finite-dimensional unital *-representation is unitarily equivalent to

`π(A) = ⊕_i [M_{d_i}(C) ⊗ I_{m_i}]` on `H = ⊕_i (C^{d_i} ⊗ C^{m_i})`, where all `m_i ≥ 1`. Consequently

`dim_C H ≥ Σ_i d_i`,

with equality precisely when all `m_i=1`. The equality-case representation is unique up to unitary equivalence (with the algebra's labeled central blocks preserved). Its commutant equals the algebraic center represented on the module:

`π_min(A)' = ⊕_i C I_{d_i} = Z(π_min(A))`.

Conversely for a faithful representation the latter commutant equality forces all `m_i=1`, since `π(A)' = ⊕_i [I_{d_i} ⊗ M_{m_i}(C)]`.

**Proof.** The restriction to each simple summand is a direct sum of copies of its unique irreducible defining representation; unital faithfulness requires at least one copy of each. The dimension inequality and uniqueness follow immediately. Computing matrix commutants blockwise gives the stated equality criterion. QED.

**Born–Hopf application.** For the six-block `A_kin = C ⊕ M₂ ⊕ M₂ ⊕ M₄ ⊕ M₃ ⊕ M₃`, the **minimum faithful carrier is exactly 15-dimensional**, with decomposition `1+2+2+4+3+3`. Separately, for `A_D=M₁₁⊕M₄`, the minimum faithful carrier has `11+4=15` dimensions, and for `M₁₅` the unique unital module has dimension 15 at minimum. Thus each generated algebra level has the **same uniquely reconstructed minimal faithful Hilbert dimension 15**:

| Algebra | Algebra dimension | Minimum faithful Hilbert dimension | Commutant dimension on minimal carrier |
|:--|--:|--:|--:|
| `A_kin` | 43 | 15 | 6 |
| `A_D` | 137 | 15 | 2 |
| `M₁₅` | 225 | 15 | 1 |

**What closes.** The 15 is **not an arbitrary numerical presentation choice** once the six full matrix summands are available: it is intrinsic to the abstract finite observable algebra, up to canonical unitary equivalence. The normalized finite trace on this minimum module has fixed central weights `d_i/15`, as a derived *canonical construction*, not as a universal empirical trace-selection law.

**Remaining firewall.** The existence of this minimal faithful representation does **not** imply that every GP1/GP2-admissible *physical* representation uses it. Such a claim requires the universal GP3 whole-candidate comparison. It is mathematically wrong to conflate the unique minimal representation with the uniqueness of physical occurrence.

## 2. Bridge rank cannot be obstructed by a small coupling (new closure)

**Theorem B.** For `A_D=M_{11}(C)⊕M_4(C)` on `H=G⊕S`, let `B:S→G` be any nonzero (possibly rank-one) linear map. Then

`C*(A_D, [0 B; 0 0], [0 0; B* 0]) = M_{15}(C)`.

**Proof.** Choose any nonzero entry `b_{ab}`. Multiplying `B` by matrix units of `M₁₁` and `M₄` isolates a nonzero `|g_a><s_b|`; further matrix-unit multiplication generates every `|g_i><s_j|`, and adjoints give reverse directions. Together with the existing diagonal matrix units they generate `M₁₅`. QED.

The coupling need not be invertible, full rank, numerically normalized, or generic. **One nonzero cross-sector matrix element suffices.** In this exact sense the closure from 137 to 225 is stable under all nonzero couplings, with a sharp exceptional locus `B=0`.

## 3. Classification of all Spin(4)-covariant geometric–spinorial bridges (new closure)

For `Spin(4)=SU(2)_L×SU(2)_R`, write irreducibles as `(j_L,j_R)`. Use the sector decomposition from Paper II-B:

`G=E₀⊕E₁⊕K₊⊕K₋ = (0,0) ⊕ (1/2,1/2) ⊕ (1,0) ⊕ (0,1)`,  
`S=S₊⊕S₋ = (1/2,0) ⊕ (0,1/2)`.

Because all SU(2) irreducibles are self-dual, the complex off-diagonal bridge representation `Hom(G,S)≅S⊗G*` decomposes exactly as

`Hom(G,S) ≅ 3(1/2,0) ⊕ 3(0,1/2) ⊕ 2(1,1/2) ⊕ 2(1/2,1) ⊕ (3/2,0) ⊕ (0,3/2)`.

The dimension check is `3·2+3·2+2·6+2·6+4+4=44=11·4`.

**Theorem C (no invariant bridge).** `Hom(G,S)^{Spin(4)}=0`; there is **no nonzero Spin(4)-invariant constant bridge** from the 11-dimensional geometric sector to the 4-dimensional spinorial sector. QED, since no `(0,0)` occurs in the decomposition, equivalently their irreducible types are disjoint.

**Theorem D (minimum covariant port).** A nonzero bridge *family* transforming covariantly under Spin(4) has smallest possible irreducible transformation dimension **two**, in either `(1/2,0)` or `(0,1/2)` chiral type. A simple explicit canonical family is

`T_+(s)=|s><e₀| ∈ Hom(E₀,S₊)`, `s∈S₊`,

where `e₀` is the (phase-ambiguous but invariant-line) trivial-sector vector. The **whole two-dimensional operator subspace** `Hom(E₀,S₊)` is canonical and Spin(4)-stable; choosing a particular `s≠0` is not canonical. Adjoining this covariant family and adjoints to `A_D` generates `M₁₅` by Theorem B.

**Interpretation for the framework:** The correct target need not be an invariant numerical B, which the symmetry forbids. It can be an intrinsically defined **covariant doublet of coupling operators**, without picking a preferred spinor or breaking Spin(4). If and only if a frozen GP2 constructor generates such a family as a physical operation, the 137→225 algebra completion is promotion-ready. Mathematical availability alone is not occurrence.

## 4. Exact parity restriction on bridges

Under the diagonal central element `z_D=(-1,-1)∈Spin(4)`, all geometric `G` irreps have parity `+1` and both spinor `S` irreps have parity `-1`. Consequently every cross-sector map `B:G↔S` is **odd**:

`U(z_D) B U(z_D)^{-1} = -B`.

This yields a useful converse: any operation algebra generated solely by elements even under `z_D` remains block diagonal in the decomposition `G⊕S` and **cannot** close `A_D` to `M₁₅`. An odd operation is necessary; by Theorem B a single nonzero off-diagonal odd operation is also sufficient given full `A_D`. Thus the missing geometric–spinorial bridge is a precise **Z₂-odd constructor obligation**, not a vague request for more dynamics.

Note: there can be parity-odd operators inside a larger Hilbert space or relative to other parities; the equivalence here is for `End(G⊕S)` with `z_D` acting as `+I_G⊕-I_S`.

## 5. Exact dependence and next proof obligation

- **Closed as pure mathematics:** uniquely reconstructed smallest faithful 15-dimensional carrier; the nested commutant-dimension ladder `6→2→1`; any nonzero bridge generates the full matrix algebra; full irreducible classification of possible bridges; no invariant constant bridge; two-component minimal covariant bridge; precise diagonal-center parity test.
- **Closed relative to the archived generated observable algebras:** existence of one canonical, minimum-capacity realization consistent with the 43/137/225 ladder. All these constructions can be used without choosing unmarked multiplicity copies.
- **Not closed:** universal GP3 selection of minimum capacity among all exact physical implementations; chronological licensing/physical occurrence of the spinor-valued bridge; bare G0 selection of a nonabelian momentum role; actual measured mass/source predictions.

**Highest-priority constructive question:** Does the existing GP2 grammar license the *whole* natural inter-sector operator subspace `Hom(E₀,S₊)`, or a nonzero part of it, as a generated operation (not merely as a representation-theoretic vector space)? If yes, Paper II-C/IV-A obtains the full 225-dimensional algebra and faithful Spin(4) adjoint symmetry without adding a symmetry-breaking spinor selection. If not, the no-omission rule does not allow it to be silently inserted.

## 6. Verification

`Paper00-OperatorReconstruction-v2_350-verify.py` checks the representation and dimension identities, the Clebsch–Gordan decomposition, central parity, and generation of the full 225-dimensional matrix-unit algebra by a rank-one bridge.
