from collections import Counter
from fractions import Fraction as F

kin=[1,2,2,4,3,3]
assert sum(kin)==15 and sum(d*d for d in kin)==43
assert 11+4==15 and 11**2+4**2==137 and 15**2==225
assert [len(kin),2,1]==[6,2,1]

G=[(F(0),F(0)),(F(1,2),F(1,2)),(F(1),F(0)),(F(0),F(1))]
S=[(F(1,2),F(0)),(F(0),F(1,2))]

def su2(a,b):
    return [F(k,2) for k in range(int(2*abs(a-b)),int(2*(a+b))+1,2)]

R=Counter((a,b) for x,y in G for u,v in S for a in su2(x,u) for b in su2(y,v))
wanted=Counter({(F(1,2),F(0)):3,(F(0),F(1,2)):3,
                (F(1),F(1,2)):2,(F(1,2),F(1)):2,
                (F(3,2),F(0)):1,(F(0),F(3,2)):1})
assert R==wanted,(R,wanted)
assert sum(k*(2*a+1)*(2*b+1) for (a,b),k in R.items())==44
assert (F(0),F(0)) not in R
assert min(int((2*a+1)*(2*b+1)) for a,b in R)==2

# The central diagonal z=(-1,-1) acts + on G and - on S.
assert all((2*(a+b)).numerator%2==0 for a,b in G)
assert all((2*(a+b)).numerator%2==1 for a,b in S)

# A rank-one cross bridge, together with both full diagonal matrix algebras,
# generates all off-diagonal units through left/right multiplication.
pairs={(i,j) for i in range(11) for j in range(11)} | {(i,j) for i in range(11,15) for j in range(11,15)}
pairs|={(i,j) for i in range(11) for j in range(11,15)}
pairs|={(j,i) for i in range(11) for j in range(11,15)}
assert len(pairs)==225
print('Verified: minimum faithful dimensions; commutants; 44-dim bridge decomposition; central parity; rank-one completion to 225 matrix units.')
