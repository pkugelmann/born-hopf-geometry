#!/usr/bin/env python3
"""Finite checks for Paper00-ObservableTopologyAndCovariantTransfer-v2_351.
Verifies examples; the Markdown supplement contains the complete proofs.
"""
import math
import numpy as np

sizes = {
    "kin": (1, 2, 2, 4, 3, 3),
    "coord": (11, 4),
    "full": (15,),
}
for label, dims in sizes.items():
    cap = sum(dims)
    algdim = sum(d*d for d in dims)
    betti = tuple(sum(d > k for d in dims) for k in range(max(dims)))
    euler = sum(betti)
    assert cap == euler == 15
    assert (algdim, betti[0]) == {"kin": (43, 6), "coord": (137, 2), "full": (225, 1)}[label]
    print(f"{label}: algebra dimension={algdim}, capacity=Euler={cap}, even-Betti={betti}")
assert abs(math.log2(15)-3.9068905956085187)<1e-14

m,n=11,4
N=m+n
Pg=np.diag([1.0]*m+[0.0]*n).astype(complex)
Ps=np.eye(N,dtype=complex)-Pg
I=np.eye(N,dtype=complex)
r,s=4.0,11.0   # bistochastic exact condition 11*r == 4*s
assert m*r==n*s

def gen(rho):
    # Equivalent to the sum over 88 GKSL jump operators.
    pG=float(np.trace(Pg@rho).real)
    pS=float(np.trace(Ps@rho).real)
    return (s/m)*pS*Pg + (r/n)*pG*Ps - 0.5*((r*Pg+s*Ps)@rho+rho@(r*Pg+s*Ps))

# Direct matrix-unit Lindblad verification, to rule out sign/normalization errors.
Vs=[]
for a in range(n):
    for b in range(m):
        v=np.zeros((N,N),dtype=complex);v[m+a,b]=math.sqrt(r/n);Vs.append(v)
for b in range(m):
    for a in range(n):
        v=np.zeros((N,N),dtype=complex);v[b,m+a]=math.sqrt(s/m);Vs.append(v)
assert len(Vs)==2*m*n==88
Q=sum((v.conj().T@v for v in Vs),np.zeros((N,N),dtype=complex))
assert np.allclose(Q,r*Pg+s*Ps)

def gen_explicit(rho):
    return sum((v@rho@v.conj().T for v in Vs), np.zeros((N,N),dtype=complex)) - 0.5*(Q@rho+rho@Q)

rng=np.random.default_rng(1351)
A=rng.normal(size=(N,N))+1j*rng.normal(size=(N,N))
rho=A@A.conj().T;rho=rho/np.trace(rho)
rho_even=Pg@rho@Pg+Ps@rho@Ps
assert np.allclose(gen(rho),gen_explicit(rho),atol=1e-12)
assert np.allclose(np.trace(gen(rho)),0,atol=1e-12)
assert np.allclose(Pg@gen(rho_even)@Ps,0,atol=1e-12)
pG=np.trace(Pg@rho_even).real
pS=np.trace(Ps@rho_even).real
assert np.allclose(np.trace(Pg@gen(rho_even)), -r*pG+s*pS)
assert np.allclose(np.trace(Ps@gen(rho_even)), r*pG-s*pS)

# Basis independence and U(11)xU(4) covariance.
def rndunit(n):
    z=rng.normal(size=(n,n))+1j*rng.normal(size=(n,n))
    q,t=np.linalg.qr(z)
    return q @ np.diag(np.conj(np.diag(t))/np.maximum(np.abs(np.diag(t)),1e-100))
U=np.zeros((N,N),dtype=complex);U[:m,:m]=rndunit(m);U[m:,m:]=rndunit(n)
assert np.allclose(gen(U@rho@U.conj().T),U@gen(rho)@U.conj().T,atol=1e-12)

# Unique stationary density and Schr picture unitality.
stationary=(s/(r+s))/m*Pg+(r/(r+s))/n*Ps
assert np.allclose(gen(stationary),0,atol=1e-12)
assert np.allclose(gen(I),0,atol=1e-12)
assert np.allclose(np.trace(Pg@stationary),m/N)
assert np.allclose(np.trace(Ps@stationary),n/N)

# Complete operator-mode check, including 120/15 traceless and 88 off-diagonal dimensions.
Xg=np.zeros((N,N),dtype=complex);Xg[0,0]=1;Xg[1,1]=-1
Xs=np.zeros((N,N),dtype=complex);Xs[m,m]=1;Xs[m+1,m+1]=-1
Y=np.zeros((N,N),dtype=complex);Y[0,m]=1
Ydag=Y.conj().T
assert np.allclose(gen(Xg),-r*Xg)
assert np.allclose(gen(Xs),-s*Xs)
assert np.allclose(gen(Y),-(r+s)/2*Y)
assert np.allclose(gen(Ydag),-(r+s)/2*Ydag)
Z=Pg/m-Ps/n
assert np.allclose(gen(Z),-(r+s)*Z)
assert (1+1+(m*m-1)+(n*n-1)+2*m*n)==N*N==225
print("GKSL: 88 jump operators, exact 11/4 stationarity, U(11)xU(4) covariance, full 225-mode dimension check: PASS")

# Non-bistochastic counterexample: same covariant structure, different equilibrium.
r2,s2=2.,3.
pG_star=s2/(r2+s2)
assert not np.isclose(pG_star,11/15)
print("Without bistochasticity, geometric 11/4 equilibrium is NOT forced: PASS")
print("ALL v2_351 finite checks PASS")
