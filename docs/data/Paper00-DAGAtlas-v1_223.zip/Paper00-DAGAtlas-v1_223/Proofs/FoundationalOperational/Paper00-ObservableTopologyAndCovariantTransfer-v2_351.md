# Born–Hopf Geometry — Observable Capacity, Pure-State Topology, and Covariant Central Transfer

**Research supplement:** `Paper00-ObservableTopologyAndCovariantTransfer-v2_351`  
**Source examined:** `Paper00-PapersMinimal-v2_349(1).zip`, especially Papers II-A, II-B, II-C, II-D, IV-A, and `Paper00-OperatorReconstruction-v2_350`.  
**Integration status:** Standalone exact mathematical supplement; **not merged** into 30-paper release, and does not assert an unproved G0 process occurrence or universal GP3 multiplicity-one.

## Executive theorem and scope

A key gap can be closed at the **observable** rather than hidden Hilbert-implementation level. On every algebra stage of the existing canonical level-one ladder, the smallest faithful carrier dimension, perfect one-shot distinguishability capacity, and Euler characteristic of the abstract pure-state space agree and equal **15**, even with arbitrary multiplicity-amplified representations of the same observable algebra. This replaces a weaker representation-dependent count with a basis-free, operationally definable invariant, without pretending to certify universal GP3 multiplicity one.

A second, conditional but exact dynamics closure constructs the complete **block-isotropic, two-rate, covariant** quantum Markov family on `M_11(C) ⊕ M_4(C)`. It changes the central populations without requiring any central-odd *observable*. Its exact relaxation spectrum has multiplicities **1, 1, 120, 15** on the even algebra, and additionally **88** central-odd off-diagonal operator directions in a full-matrix mathematical dilation. The often-quoted 11:4 equilibrium weight is obtained **if and only if** the model semigroup is bistochastic (provided both rates positive). Neither transition rates nor bistochasticity are consequences of G0/GP1–GP3 alone.

### Notation and source frontier

For an already constituted finite complex observable algebra

`A = ⊕_{i=1}^r M_{d_i}(C)`, with `d_i >= 1`,

write `S(A)` for the full normalized positive linear-functional state role, `P(A)` for its weak-* pure-state subspace, and `C_1(A)` for the maximum number of states with a **single** algebraic POVM that discriminates them all with certainty. These are **role-level** quantities; performance of an experiment or preparation of a specified state needs a G0 occurrence token. `dim_min(A)` is the minimum faithful representation dimension.

## Theorem 1 — Operational capacity equals minimum faithful dimension

For every finite-dimensional complex unital C*-algebra,

`C_1(A) = dim_min(A) = Σ_i d_i`.

**Proof.** In each `M_{d_i}` summand choose an orthonormal basis and define the `d_i` vector states supported there; the rank-one coordinate projectors form, across all blocks, a single POVM with precisely `Σ d_i` outcomes that perfectly distinguishes these states. Conversely suppose `ρ_1,...,ρ_N` and effects `e_1,...,e_N >=0`, `Σ e_j=1`, satisfy `tr(ρ_i e_j)=δ_ij`. Because `0<=e_j<=1`, positivity and `tr[ρ_i(1-e_i)]=0` imply `e_i=1` on the support of `ρ_i`. For `j ≠ i`, `tr(ρ_j e_i)=0` gives `e_i=0` on the support of `ρ_j`. As `e_i` is Hermitian, the nonzero supports of distinct `ρ_i` must be mutually orthogonal. Their ranks sum to at most `Σ_i d_i`. Finally finite Wedderburn representation theory gives `dim_min(A)=Σ_i d_i`, with one copy of each irreducible. QED.

This is an **algebraic maximum** for licensed state/effect roles, not a statement that an actual apparatus discriminates every mathematical state. For arbitrary amplified representations `π(A)=⊕_i(M_{d_i} ⊗ I_{m_i})`, the same algebra has `C_1(A)=Σ_i d_i` even when the underlying Hilbert dimension is `Σ_i d_i m_i > Σ_i d_i`. If multiplicity-resolving effects are independently licensed then the observable algebra has been enlarged, and the capacity must be recomputed for that **different algebra**.

**Corollary 1.** The maximum perfectly distinguishable single-shot classical alphabet has `15` symbols and information content `log_2(15)=3.9068905956085187` bits on all three Born–Hopf algebra stages. This is a role-level operational *maximum*, not a derived physical bit-rate, stochastic measurement outcome, detector efficiency, or universally attained empirical capacity.

## Theorem 2 — Pure-state Euler characteristic equals operational capacity

For the above `A`,

`P(A) ≅ ⨆_{i=1}^r CP^{d_i-1}`

as a disjoint union of compact complex projective manifolds, in the canonical homeomorphism class. Consequently

`χ(P(A)) = Σ_i χ(CP^{d_i-1}) = Σ_i d_i = C_1(A) = dim_min(A)`.

**Proof.** Each pure state of a direct sum restricts to precisely one central simple summand: a nontrivial convex combination across two central blocks would not be extremal. The pure states of `M_d(C)` are exactly the rank-one projectors, whose projective rays form `CP^{d-1}`. A standard CW decomposition of `CP^n` has exactly one even-dimensional cell in dimensions `0,2,...,2n`, so `χ(CP^n)=n+1`. Euler characteristic is additive under finite disjoint union; use Theorem 1. QED.

For the framework's existing algebras:

| Algebra | Pure-state space `P(A)` | `dim_C(A)` | `b_0(P(A))` | `χ(P(A))` | `C_1(A)` |
|---|---|---:|---:|---:|---:|
| `A_kin = C ⊕ M_2 ⊕ M_2 ⊕ M_4 ⊕ M_3 ⊕ M_3` | `CP^0 ⨆ 2 CP^1 ⨆ 2 CP^2 ⨆ CP^3` | 43 | 6 | 15 | 15 |
| `A_D = M_11 ⊕ M_4` | `CP^10 ⨆ CP^3` | 137 | 2 | 15 | 15 |
| `A_full = M_15` | `CP^14` | 225 | 1 | 15 | 15 |

The **full even Betti vectors** (where entry `k` means `b_{2k}`, and all odd Betti numbers vanish) are:

* kinematic: `(6, 5, 3, 1)`;
* coordinate: `(2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1)` for `k=0,...,10`;
* full: fifteen ones for `k=0,...,14`.

Thus the topology changes dramatically, but Euler characteristic and perfect-discrimination capacity remain fixed at 15. The algebra inclusions `A_kin ⊂ A_D ⊂ A_full` **do not imply inclusions of their pure-state spaces**: a pure state on a larger algebra can restrict to a mixed state on the smaller algebra. This prevents a tempting but false geometric claim.

**Chronological scope.** The first stage follows from the frozen six-type/algebra content. The coordinate and full stages are exact on their *separately specified algebra domains*; the full stage is not automatically physically constituted merely because the algebra `M_15` is mathematically available. For the level-one momentum seed, `C_1(A_kin)=15` is unconditional relative to the currently claimed generated test algebra, **without** a universal GP3 comparison certificate.

## Theorem 3 — Exact covariant, parity-even central-population transfer on `M_11 ⊕ M_4`

Let `G=C^11`, `S=C^4`, `A_D=End(G) ⊕ End(S)`, and let `r,s>0` be **supplied** positive rates. For block-diagonal density operators `ρ=ρ_G ⊕ ρ_S`, denote `p_G=Tr ρ_G` and `p_S=Tr ρ_S` and define the *Schrödinger-picture* linear generator

```
L_{r,s}(ρ)_G = -r ρ_G + (s/11) (Tr ρ_S) I_G,
L_{r,s}(ρ)_S = -s ρ_S + (r/4)  (Tr ρ_G) I_S.
```

Then:

1. `exp(t L_{r,s})` is a trace-preserving completely positive (CPTP) semigroup on the state space of the direct-sum algebra for all `t>=0`. It is covariant under **all** independent unitary rotations `U(11) × U(4)`, hence under the native `Spin(4)` representation.
2. The physical even algebra `A_D` is preserved under the dual process. Its population dynamics closes exactly:

   `dot p_G = -r p_G + s p_S`, `dot p_S = r p_G - s p_S`.

   For density states `p_G+p_S=1`,

   `p_G(t) = s/(r+s) + [p_G(0)-s/(r+s)] exp[-(r+s)t]`.

3. There is a unique stationary density state,

   `ρ_* = [s/(r+s)] I_G/11 ⊕ [r/(r+s)] I_S/4`.

4. The semigroup is **bistochastic** (trace preserving and **Schrödinger-unital** `exp(tL)(I_15)=I_15`) if and only if `11 r = 4 s`. In precisely this condition,

   `p_G^*=11/15`, `p_S^*=4/15`.

   Without the extra bistochastic/detailed-balance condition, the stationary ratio is `p_G^*/p_S^* = s/r`, and the geometric dimensions alone do **not** select it.

**Proof.** Give an explicit Lindblad dilation on the mathematical full matrix algebra `M_15`, with orthonormal bases `g_b` of `G` and `s_a` of `S`:

`V_{ab} = sqrt(r/4) |s_a><g_b|` for `a=1..4, b=1..11`,

`W_{ba} = sqrt(s/11) |g_b><s_a|` for `b=1..11, a=1..4`.

Define `L_full(ρ) = Σ VρV† + Σ WρW† - 1/2 { Σ V†V + Σ W†W, ρ }`. The gain terms produce `(r/4) p_G I_S` and `(s/11) p_S I_G`; the loss operator is `r P_G+s P_S`. The block-diagonal algebra is invariant, and the restriction is exactly the stated `L_{r,s}`. Hence the semigroup is CPTP, and the operators are **dilation witnesses**, not an assertion that the individual odd `V,W` are licensed observable fields or tests. Invariance follows because each sum is the basis-independent completely depolarizing transfer between two blocks. The two-state Markov equation integrates to the display; the traceless parts of `ρ_G` and `ρ_S` decay at rates `r,s`, yielding unique stationarity for `r,s>0`. Finally `L_full(I_15)=(4s/11-r)P_G+(11r/4-s)P_S`, which vanishes exactly when `11r=4s`. QED.

**The distinction that matters for the framework.** A dynamical channel between sector populations **does not mathematically require** a central-odd *effect* or a physical full-carrier `M_15` event algebra. The process map is already well-defined on `A_D`, and all its observables can remain even. But an actual nonzero `r` or `s`, their values, and the occurrence of the Markov process remain **G0/DYN inputs**. An odd *operator family in a dilation* is not automatically a physically actual odd field/test. This theorem is not a free derivation of population mixing from GP1–GP3.

## Theorem 4 — Complete relaxation-mode spectrum and the 88-mode diagnostic

On the complex vector space `A_D=M_11 ⊕ M_4` (complex dimension 137), the generator in Theorem 3 is diagonalizable and has the **invariant subspace** decomposition

| Eigenvalue | Subspace | Complex dimension |
|---|---|---:|
| `0` | unique equilibrium line | 1 |
| `-(r+s)` | central population imbalance | 1 |
| `-r` | traceless `M_11` directions | `11^2-1=120` |
| `-s` | traceless `M_4` directions | `4^2-1=15` |

The modes add to `1+1+120+15=137`. Rates may coincide; in that case combine coincident eigenspace multiplicities.

The **same explicitly stated Lindblad dilation** on `M_15` acts on the central-odd off-diagonal rectangular sectors `Hom(G,S) ⊕ Hom(S,G)` as multiplication by `-(r+s)/2`. There are exactly `2*11*4=88` such additional complex directions. The complete 225-dimensional dilation therefore has formal decay-spectrum structure

`0^(1), [-(r+s)]^(1), [-r]^(120), [-s]^(15), [-(r+s)/2]^(88)`.

**Proof.** Decompose each block as `ρ_G=(p_G/11)I_G + X_G`, `Tr X_G=0`, and `ρ_S=(p_S/4)I_S+X_S`, `Tr X_S=0`. Then `dot X_G=-r X_G`, `dot X_S=-s X_S` and the central two-by-two population matrix is `[[-r,s],[r,-s]]`, with eigenvalues `0` and `-(r+s)`. For an off-diagonal block `Y:G→S`, the jump-gain terms vanish because they are of the form `V(P_G ρ P_G)V†` or `W(P_S ρ P_S)W†`, whereas the anti-commutator contributes `-(r+s)Y/2`. Its adjoint has the same rate. QED.

**Readout significance.** One specified block-isotropic channel has an exact four-sector relaxation signature in the even algebra and an 88-mode coherence sector visible only on an enlarged *operator or field* domain. No actually observed rates or poles follow from this mathematical model. The occurrence of the integer `120` as `11^2-1` is **not** evidence for any additional physical binary-icosahedral group `2I` link.

## Theorem 5 — No central-odd bridge from central-even operator words

Let `Γ=I_G ⊕ (-I_S)` on `H=G⊕S`, and let `B_even={T∈End(H): ΓTΓ=T}=End(G)⊕End(S)`. Every element obtained from an even seed family by a finite word of addition, scalar multiplication, multiplication, commutators, adjoints, inversion (when defined), and continuous functional calculus remains even. Consequently no such word can supply a nonzero geometric–spinorial off-diagonal bridge.

**Proof.** Conjugation `Θ(T)=ΓTΓ` is a unital involutive `*`-automorphism. Its fixed-point algebra `B_even` is closed under the listed `*`-algebraic operations and functional calculus. Every cross-sector operator is in the `(-1)`-eigenspace of `Θ`; hence a nonzero cross-sector bridge is excluded from the fixed algebra. QED.

The prior v2_350 result that a two-component covariant spinor bridge **exists mathematically** is consistent with this theorem: it uses the **odd spinor type as input** and a cross-type operator constructor, not only even algebra words. The only candidate promotion to a GP2-physical bridge must therefore prove an independently licensed **odd-target constructor** or a suitable new process/test occurrence. More even-coordinate recursion cannot achieve the missing operator parity. This exact impossibility localizes the chronological interface but does not assert that the framework must add an axiom.

## Status and proposed proof ownership

**Unconditionally mathematical, relative to constituted algebra:** Theorems 1–2. They give a new, multiplicity-independent **operational capacity and pure-state Euler witness**. The 15-dimensional **operational** content is closed; the universal **hidden Hilbert-carrier multiplicity-one** obligation of Paper II-B remains open.

**Exact conditional process construction and spectral classification:** Theorems 3–4. They reduce the `11/4` population problem to an explicit `r,s` generator and an iff bistochasticity criterion, and avoid mistakenly equating population transfer with observing an odd field. They do not claim an occurring physical process or rates.

**Unconditional parity-grammar obstruction:** Theorem 5. It rules out even-only closure as a source of a physical odd bridge and clarifies the GP2 constructor obligation.

**Potential paper placement if later integrated:** II-B/II-C for Theorems 1–2; IV-A/IV-C for Theorems 3–4; II-D/IV-A for Theorem 5. Update the theorem DAG only after verifying constructor provenance, source scope, and existing labels. This note **does not** modify the 30 original paper sources or theorem DAG.

## Reproducibility

`Paper00-ObservableTopologyAndCovariantTransfer-v2_351-verify.py` deterministically checks the dimension/Euler/Betti/capacity identities and the full 15×15 GKSL construction, covariance, population law, central and off-diagonal eigenmode actions, stationarity, and bistochasticity. Computational checks verify the **finite instance**; the general mathematical proofs above remain the proof owner.

## Mathematical precedence / novelty boundary

The ingredients are standard mathematics, not claimed to be new general theorems: finite-dimensional C*-algebras have matrix-summand decompositions, their simple-block pure-state spaces are complex projective spaces, and quantum Markov semigroups with invariant states are extensively studied. Background examples include **"From the Jordan Product to Riemannian Geometries on Classical and Quantum States"** (2020, https://pmc.ncbi.nlm.nih.gov/articles/PMC7517174/) and **E. A. Carlen and J. Maas, "Gradient flow and entropy inequalities for quantum Markov semigroups with detailed balance"** (2017, https://doi.org/10.1016/j.jfa.2017.05.003). The new research contribution **relative to the inspected Born–Hopf source** is the explicit three-stage constant-capacity/Euler connection and the exact native `11⊕4` population-transfer/relaxation classification, with its strict typed physical boundary. Whether this particular combination exists in earlier external literature has not been exhaustively surveyed.
