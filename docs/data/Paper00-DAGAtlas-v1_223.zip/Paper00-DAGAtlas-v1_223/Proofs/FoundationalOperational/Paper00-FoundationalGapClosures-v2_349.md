# Born–Hopf Geometry: Foundational Gap Closures and Observable-Exact Boundaries

**Research delta:** `Paper00-FoundationalGapClosures-v2_349`  
**Baseline inspected:** `Paper00-PapersMinimal-v2_348(1).zip` (7 November 2026)  
**Status:** independently checked mathematical research note; **not yet merged** into the 30 TeX papers, their PDFs, or the source-anchored theorem DAG. No physical-occurrence or pole-mass closure is claimed.

## 0. Scope: what “unconditional” must mean

A mathematical consequence may be unconditional **relative to an already constituted role**, yet not unconditional from bare G0. We keep three levels separate:

1. **Pure mathematics (M):** a theorem for specified round three-manifolds, finite modules, or algebras.
2. **Generated-structure consequence (GS):** an M theorem whose hypotheses are outputs of constructors genuinely licensed by the frozen GP2 grammar, with correct temporal ownership.
3. **Physical-response consequence (PR):** a GS theorem with an actual G0 occurrence, same-action source, specified response or readout, and (if appropriate) a pole map.

No M theorem is silently promoted to GS; no GS theorem is silently promoted to PR.

The baseline Paper II-B explicitly retains a universal GP3 multiplicity-one gap: six Spin(4) types and `m_p=1` follow at the GP2 support level, while `dim_C H_p=15` for *every* physical endpoint requires a separate whole-candidate comparison certificate. Paper II-C already derives `A_kin` and the intrinsic 11+4 algebra in their licensed mathematical domains. This note does **not** claim to have independently resolved universal GP3 multiplicity-one.

## 1. Foundational non-implication from bare G0

**Theorem 1 (bare nontriviality does not select the primitive role).** Let G0 be only the assertion that at least one nontrivial distinguishable geometric structure exists. Without an additional derivation of the identity-rooted local-reapplication/connectedness/order-swap signature of the strong `Geo_R` predicate, G0 together with finiteness/boundedness, exactness/faithfulness, and role-relative leastness does not force an occurring noncommutative momentum branch or fix its compact global parent.

**Proof.** A circle with its rotation comparisons is a nontrivial compact, bounded, connected, exact and faithful *abelian* geometric comparison structure. A finite two-point metric space with its transposition comparison is likewise a nontrivial finite bounded exact and faithful role when the primitive role grammar does not require connected local generation. Thus neither noncommutativity nor the existence of a specific second role is a logical consequence of bare geometric nontriviality. The GP3 order is defined **within a predeclared role signature**; minimization of candidates for that signature cannot manufacture the occurrence of a different signature. QED.

**Consequence.** The existing strong `Geo_R` predicate is load-bearing. Proving it follows from bare G0 and GP1–GP3 would be a genuine upstream closure; simply renaming its content as G0 would be a hidden new assumption. This is a **no-go** about unconditionality, not a proposal to add a physical principle.

## 2. Scalar and spinor tests of the SU(2) / SO(3) globalization

**Theorem 2 (complete A1 globalization alternatives).** Every connected global integration of the Lie algebra `su(2)` is, up to isomorphism, either `SU(2)` or `SO(3) = SU(2)/{±1}`. The underlying round Riemannian manifolds are respectively `S³(R)` and `RP³(R)` with their locally isometric quotient metrics.

**Proof.** The simply connected integration is `SU(2)`; connected integrations are quotients by discrete central subgroups. Its center is exactly `{±1}`. QED.

**Theorem 3 (unconditional scale-free scalar-cover discriminator).** For the round metrics,

| Quantity | `S³(R)` | `RP³(R)` |
|---|---:|---:|
| First positive eigenvalue of `-Δ` | `3/R²` | `8/R²` |
| Complex multiplicity of that eigenspace | 4 | 9 |
| `λ_first / Scal(g)` | `1/2` | `4/3` |

**Proof.** Homogeneous scalar harmonics of degree `k` on `S³` have eigenvalue `k(k+2)/R²` and dimension `(k+1)²`. Under the antipodal involution, degree `k` acquires sign `(-1)^k`, so functions on the quotient retain only even degrees. Thus `k=1` is present on `S³` and absent on `RP³`; the first nonconstant quotient eigenspace is `k=2`. Both local round metrics have scalar curvature `6/R²`, yielding the ratios. QED.

**Theorem 4 (two-sided Killing-spinor obstruction).** On round `S³(R)` there are complex two-dimensional lowest Killing-spinor spaces for each Killing constant `+1/(2R)` and `-1/(2R)` (with the corresponding Dirac eigenvalues, up to the Dirac sign convention). For either one of the two spin structures on round `RP³(R)`, exactly one of those two signs survives descent, and the opposite sign is absent. Hence a **single constituted spinor bundle** with both lowest Killing-spinor signs excludes `RP³` among A1 globalizations.

**Proof.** Lift spinors to `S³`; deck transformations act by `±1` depending on the spin structure. The two lowest Killing-spinor representations have opposite central parity for a fixed deck lift. Its invariant spinors therefore come from exactly one representation. This matches the explicit projective-space Dirac-spectrum result of Kling–Schueth (2022, Remarks 2.6 and associated spectral calculation) and the projective Killing-spinor classification in Ammann's work. QED.

**Chronological firewall.** These two discriminators are M-level **without any additional physical hypothesis**. To promote them to a *primitive* GP2 globalization selector, the scalar `E1` spectral comparison or two-sign spinor-port condition must already be a licensed, occurrence-bearing `Geo_R` test **before** selecting the global cover. Deriving `E1`, `S+`, and `S-` only after choosing `SU(2)` would make a purported earlier selection circular. This note does not hide that obligation.

References: J. Kling & D. Schueth, *On the Dirac Spectrum of Homogeneous 3-Spheres*, J. Geom. Anal. 32, 275 (2022), https://doi.org/10.1007/s12220-022-00997-x ; B. Ammann, *The first eigenvalue of the Dirac operator in a conformal class*, projective-space example, https://ammann.app.uni-regensburg.de/preprints/rome05/rome05.pdf .

## 3. General central-sign/bridge-graph theorem

Let `H = ⊕_{i∈I} H_i` and `A_0 = ⊕_i End(H_i)`, each vertex algebra acting on its distinct Hilbert summand. For each undirected edge `i—j` of a finite graph Γ, adjoin at least one nonzero operator `B_{ij}: H_j → H_i` and its adjoint. Let `A_Γ` be the unital complex `C*`-algebra generated by `A_0` and these edges.

**Theorem 5 (exact graph completion).** If Γ has connected components `C`, then

`A_Γ = ⊕_{C∈π₀(Γ)} End(⊕_{i∈C} H_i)`, and

`dim_C(A_Γ) = Σ_C (Σ_{i∈C} dim_C H_i)²`.

**Proof.** Each vertex algebra contains every rank-one matrix unit on its block. From any nonzero matrix element of an edge `B_ij`, multiplication on the left and right by vertex matrix units isolates any desired rank-one off-diagonal map between the two vertices. Multiplication along a graph path constructs arbitrary off-diagonal matrix units between all vertices of a connected component. No generator couples different components. Hence the algebra on each component is a full matrix algebra and the displayed direct sum is exact. QED.

**Theorem 6 (central-sign detection criterion).** Suppose a central group element `z` acts on each `H_i` by a scalar sign `ε_i ∈ {±1}`. Then `Ad(U(z))` is trivial on `A_Γ` **if and only if** every edge connects equal signs, equivalently `ε_i` is constant on each connected component of Γ.

**Proof.** Conjugating an off-diagonal `i—j` block by `U(z)` multiplies it by `ε_i ε_j`. The vertex algebras are always fixed. Thus any unequal-sign edge is a witness of nontrivial conjugation; if all edges connect equal signs, the sign is constant on each component and conjugation fixes its entire full matrix algebra. QED.

Theorems 5–6 are exact finite-dimensional statements and require neither a carrier normalization nor a physical detector. The graph is built **only from actually generated nonzero typed bridges** when making a GS claim. Graph edges cannot be inferred merely from a representation-theoretic possibility.

## 4. Application to the six-type level-one module

Take the pairwise inequivalent `Spin(4)` irreps in the canonical mathematical module

`H₁ = E₀ ⊕ S+ ⊕ S− ⊕ E₁ ⊕ K+ ⊕ K−`,

with dimensions `(1,2,2,4,3,3)`. Write the central elements

`z_L=(-1,1)`, `z_R=(1,-1)`, `z_D=(-1,-1)`. The action signs are:

| Sector | Dimension | `z_L` | `z_R` | `z_D` |
|---|---:|:---:|:---:|:---:|
| `E₀=(0,0)` | 1 | + | + | + |
| `S+=(1/2,0)` | 2 | − | + | − |
| `S−=(0,1/2)` | 2 | + | − | − |
| `E₁=(1/2,1/2)` | 4 | − | − | + |
| `K+=(1,0)` | 3 | + | + | + |
| `K−=(0,1)` | 3 | + | + | + |

The intrinsic nonzero coordinate edges are

`E₀—E₁`, `E₁—K+`, `E₁—K−`, `S+—S−`.

Every edge is **odd under the separate** `z_L` and `z_R` but **even under** `z_D`. Equivariance therefore gives for *every* nonzero intrinsic vector coordinate `X_a^D`:

`U(z_L) X_a^D U(z_L)^*= -X_a^D`,  
`U(z_R) X_a^D U(z_R)^*= -X_a^D`,  
`U(z_D) X_a^D U(z_D)^*= +X_a^D`.

The baseline's fixed-radius coefficients `(sqrt(2)R/3, sqrt(2)R/3, sqrt(3)R/4)` are strictly positive for `R>0`, so the four graph edges are indeed nonzero in the canonical `C_D` branch.

**Theorem 7 (complete effective symmetry ladder).** On the canonical 15-dimensional module, the following three generated algebra stages have exact central kernels and effective conjugation groups:

| Test algebra | Complex algebra dimension | Kernel of `Spin(4)` conjugation | Effective group |
|---|---:|---|---|
| `A_kin = C ⊕ M₂ ⊕ M₂ ⊕ M₄ ⊕ M₃ ⊕ M₃` | **43** | `(±1,±1)` (all four central elements) | `SO(3)_L × SO(3)_R` |
| `A_D = M₁₁ ⊕ M₄` | **137** | `{(1,1), (-1,-1)}` | `SO(4)` |
| `A_full = M₁₅` | **225** | `{(1,1)}` | `Spin(4)` |

**Proof.** The graph theorem supplies dimensions 43, `11²+4²=137`, and `15²=225`. For `A_kin`, the independent `K+` and `K−` adjoint representations force any conjugation-trivial element to have both factors central; every central element acts blockwise by scalars, hence lies in the kernel. For `A_D`, the presence of the trivial `E₀` block in its full geometric `M₁₁` algebra forces any scalar action on this block to be `+1`; its `E₁` subrepresentation is the faithful vector representation of `SO(4)` and its kernel in `Spin(4)` is precisely the diagonal center. For `M₁₅`, any scalar representation of `Spin(4)` must be `+1` because of `E₀`, then must be trivial on each of the faithful chiral fundamental reps `S+` and `S−`; thus both group factors are the identity. QED.

**Corollary 7a (one-operator full-algebra criterion).** Any nonzero `B: C⁴ → C¹¹`, added with `B*` to the complete internal `M₁₁ ⊕ M₄` algebra, generates `M₁₅` and reduces the central kernel from `Z₂` to `{1}`. The increase of complex algebra dimension is **88**, since `225−137 = 2·11·4`.

**Scope.** This is a closure of the *algebraic content* and its faithful symmetry action for the canonical one-copy module. That a particular `B` belongs to the physical frozen grammar or to an actual action is **not** proved. The result identifies a single testable missing owner, rather than declaring a new particle or physical odd interaction.

**Corollary 7b (perfect finite distinction of the left center).** In the geometric 11-dimensional block, choose unit vectors `e₀∈E₀` and `u∈E₁`. Let `ψ±=(e₀±u)/sqrt(2)`, and let `P+=|ψ+><ψ+|`. Both density preparations and the effect are mathematical elements of the finite `M₁₁` state/effect system. The left central operation sends `ψ+` to `ψ−`, and

`Tr(P+ |ψ+><ψ+|)=1`, whereas `Tr(P+ U(z_L)|ψ+><ψ+|U(z_L)^*)=0`.

Thus the two operations are *potentially perfectly distinguishable within the generated algebra*. The appearance of an actual preparation, action, and effect is separately typed G0 data. The diagonal-label-center blindness of the special sectorwise homogeneous POVM does not contradict this statement, because its label center is `z_D`, not `z_L`.

## 5. Why normalized observables cannot close universal multiplicity-one

**Theorem 8 (common-amplification no-go).** Let `A` be any of the abstract finite test algebras above in its canonical representation on `H₁`, and for any integer `k≥1` define

`H_k = H₁ ⊗ C^k`, `j_k(a)=a⊗I_k`, `U_k(g)=U₁(g)⊗I_k`.

For every finite noncommutative *-polynomial `p` of algebra observables,

`Tr_{H_k}(p(j_k(a₁),...,j_k(a_n)))/(15k) = Tr_{H₁}(p(a₁,...,a_n))/15`.

Moreover every state on `H_k` has exactly the same one-time statistics on `j_k(A)` as its multiplicity partial trace on the original algebra; every original algebra state admits a maximally mixed multiplicity lift. For any process grammar whose Heisenberg adjoints preserve `j_k(A)`, the whole finite adaptive state/effect protocol descends as well.

**Proof.** The amplified evaluation of any *-polynomial is `p(a₁,...,a_n)⊗I_k`. Its ordinary trace is `k` times the canonical trace, which cancels the `k` in the normalization. The remaining assertions are the partial-trace identity and the exact Heisenberg-invariance criterion already established in Paper II-B's observable quotient theorem and Paper II-C's process descent theorem. QED.

**Corollary 8a (sharp central-weight obstruction).** Let arbitrary positive sector multiplicities be `m_i`, with type dimensions `d_i=(1,2,2,4,3,3)`. The normalized tracial weights are

`w_i = d_i m_i / Σ_j d_j m_j`.

The equalities `w_i=d_i/15` for all six sectors hold **if and only if** all `m_i` are equal to a common integer `k≥1`. They do **not** imply `k=1`.

**Proof.** Since every `d_i>0`, the six equalities imply `m_i = (Σ_j d_j m_j)/15` independently of `i`. Conversely common `k` cancels. QED.

Therefore **no amount of normalized algebraic trace data alone** can prove that the universally occurring Hilbert carrier has 15 rather than 30, 45, ... dimensions. An absolute rank/capacity witness, an independently fixed operation or source sensitive to multiplicities, or a fully proved GP3 whole-candidate comparison is necessary. Existing exact defects from Paper II-B (`Δ_dim`, `Δ_com`, `Δ_χ`) remain useful only when their corresponding **unnormalized** values are independently established.

## 6. Direct consequence for proposed mass sources (scoped no-go)

**Proposition 9 (coordinate-compatible invariant finite mass source).** On the canonical one-copy `H₁`, let a constant Hermitian mass-like source `M` commute with the whole intrinsic algebra `A_D=M₁₁⊕M₄`. Then

`M = μ_g I₁₁ ⊕ μ_s I₄`, with `μ_g,μ_s ∈ R`.

In particular it has at most two eigenvalues and its singular values have at most two distinct magnitudes. No nine-way fermion mass splitting can be the singular spectrum of such a *constant, fully coordinate-compatible* source.

**Proof.** The commutant of `M_n(C)` acting irreducibly on `C^n` consists of scalar operators. Direct-sum block preservation gives precisely the two displayed scalars. QED.

This is **not** a no-go for physical mass poles arising from an action-generated energy-dependent self-energy, noncommuting response, or a differently typed field space. It identifies which simple source strategy cannot produce the desired observable. On amplified carriers, the full commutant includes multiplicity-space matrices; the two-scalar result requires either the one-copy module or a separately justified multiplicity-blind source.

## 7. Priority ledger and proposed mathematical ownership

| Priority | Missing or improved link | Mathematical result here | Unconditional physical closure? | Intended proof owner |
|---|---|---|---|---|
| P0 | bare G0 → strong local role and noncommuting occurrence | no-implication/countermodels | **No**: new occurring role not deduced | Paper II-A |
| P1 | local A1 → global SU(2) | exhaustive two covers; exact scalar and spinor separation; explicit finite left-center witness | **Not until chronological constructor licensing is proved** | Papers II-A/II-B |
| P2 | 6-type support → universal multiplicity one | normalized amplification sharp no-go | **No**: full GP3 comparison outstanding | Paper II-B |
| P3 | 43 → 137 → 225 action/test algebra and central faithfulness | exact connected-graph theorem, kernels, one-bridge completion | **Algebraically yes; bridge physical occurrence no** | Papers II-C/IV-A |
| P4 | invariant source → differentiated physical masses | exactly two source scalars under full `A_D` compatibility | **No**: same-action response/pole owner needed | Papers V-A/V-B |

The highest-value **next derivation** is not a numerical fit: either (a) prove the first-harmonic/coordinate comparison belongs to the *primitive* GP2 grammar in a cover-independent way, which would promote the SU(2)/SO(3) spectral test into a chronological selector, or (b) produce a universally generated role-faithful GP3 comparison for all momentum implementations, including multiplicity-sensitive tests and processes. If (a) cannot be done without relying on already selected SU(2), that gap must remain explicitly open. If (b) cannot be done because extra copy-sensitive operations are GP2-admissible, the physical Hilbert multiplicity cannot be claimed unconditional.

## 8. Reproducibility and what is not claimed

Run `python Paper00-FoundationalGapClosures-v2_349-verify.py` from a directory containing this note and script. It uses NumPy and the Python standard library. The deterministic script checks:

- the six type dimensions and exact 43/137/225 algebra-dimension ladder;
- all central parity vectors and four intrinsic coordinate edges;
- the central kernel sequence of 4, 2, 1 elements on the three algebras;
- explicit 15-dimensional center-odd coordinate and a state/effect discrimination of 1 versus 0;
- common-amplification invariance of normalized trace words;
- scalar-cover eigenvalue/curvature ratios.

The script does **not** computationally prove the external classification of Killing spinors; that theorem is cited above. No calculation in this note demonstrates an actually occurring experiment, universal GP3 multiplicity one, an action-generated cross-component bridge, or a physical Standard Model pole mass. The original `v2_348` PDF/TeX/DAG release remains unchanged.
