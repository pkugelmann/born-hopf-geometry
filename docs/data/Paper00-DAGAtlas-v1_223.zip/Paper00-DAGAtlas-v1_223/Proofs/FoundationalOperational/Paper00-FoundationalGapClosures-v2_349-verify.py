#!/usr/bin/env python3
"""Exact finite certificates for Born--Hopf gap-closure research delta v2_349.

The global spinor-Killing statement is a mathematical theorem cited in the
accompanying note, not a finite computation certified by this script.
This script verifies the finite representation, graph, central-sign,
projector and normalized-amplification claims.
"""
import json
from fractions import Fraction
import numpy as np

S = [
    ("E0", Fraction(0), Fraction(0)),
    ("S+", Fraction(1,2), Fraction(0)),
    ("S-", Fraction(0), Fraction(1,2)),
    ("E1", Fraction(1,2), Fraction(1,2)),
    ("K+", Fraction(1), Fraction(0)),
    ("K-", Fraction(0), Fraction(1)),
]
NAMES = [n for n, _, _ in S]
D = [(int(2*l)+1)*(int(2*r)+1) for _, l, r in S]
assert D == [1,2,2,4,3,3]
assert sum(D) == 15
assert sum(d*d for d in D) == 43
S_L = {n: (-1)**int(2*l) for n,l,r in S}
S_R = {n: (-1)**int(2*r) for n,l,r in S}
S_D = {n:S_L[n]*S_R[n] for n in NAMES}
CENTERS = {"1":{n:1 for n in NAMES}, "zL":S_L,"zR":S_R,"zD":S_D}
EDGES = [("E0","E1"),("E1","K+"),("E1","K-"),("S+","S-")]


def components(edges):
    seen=set()
    adjacency={n:set() for n in NAMES}
    for a,b in edges:
        adjacency[a].add(b); adjacency[b].add(a)
    cc=[]
    for n in NAMES:
        if n in seen: continue
        stack=[n];seen.add(n);comp=[]
        while stack:
            u=stack.pop();comp.append(u)
            for v in sorted(adjacency[u]):
                if v not in seen:
                    seen.add(v);stack.append(v)
        cc.append(comp)
    return cc


def algebra_dim(edges):
    return sum(sum(D[NAMES.index(n)] for n in comp)**2 for comp in components(edges))


def center_kernel(edges):
    return [name for name,sgn in CENTERS.items()
            if all(sgn[a]==sgn[b] for a,b in edges)]

assert algebra_dim([])==43
assert algebra_dim(EDGES)==11**2+4**2==137
assert algebra_dim(EDGES+[("E0","S+")])==225
assert set(center_kernel([]))=={"1","zL","zR","zD"}
assert set(center_kernel(EDGES))=={"1","zD"}
assert center_kernel(EDGES+[("E0","S+")])==["1"]
assert all(S_L[a]*S_L[b]==-1 and S_R[a]*S_R[b]==-1
           and S_D[a]*S_D[b]==1 for a,b in EDGES)

# 15x15 exact-integer central characters and a center-odd coordinate edge.
indices={};offset=0
for n,d in zip(NAMES,D):
    indices[n]=list(range(offset,offset+d));offset+=d
central_matrices={}
for cent,sgn in CENTERS.items():
    central_matrices[cent]=np.diag([sgn[n] for n in NAMES for _ in indices[n]])
character={c:int(np.trace(M)) for c,M in central_matrices.items()}
assert character=={"1":15,"zL":3,"zR":3,"zD":7},character

a,b=indices["E0"][0],indices["E1"][0]
X=np.zeros((15,15),dtype=np.int64)
X[a,b]=1; X[b,a]=1
for c in ("zL","zR"):
    U=central_matrices[c]
    assert np.array_equal(U@X@U,-X)
U=central_matrices["zD"]
assert np.array_equal(U@X@U,X)
plus=np.zeros(15);plus[a]=plus[b]=1/np.sqrt(2)
projector=np.outer(plus,plus)
psi_after=central_matrices["zL"]@plus
prob_identity=float(plus@projector@plus)
prob_center=float(psi_after@projector@psi_after)
assert abs(prob_identity-1)<1e-14
assert abs(prob_center-0)<1e-14

# Common amplification preserves ALL normalized polynomial trace words.
A=np.diag(np.arange(1,16,dtype=float))
B=np.zeros((15,15));B[indices["E0"][0], indices["E1"][0]]=1
B=B+B.T
for k in (1,2,3,5):
    for C in (A, B, A@B, A@B@A, np.eye(15)+A@A+B@B):
        Ck=np.kron(C,np.eye(k))
        assert np.isclose(np.trace(Ck)/(15*k),np.trace(C)/15)
    wm=[d*k/(15*k) for d in D]
    assert all(abs(w-d/15)<1e-14 for w,d in zip(wm,D))

# Matching all six normalized central weights forces equal positive integer
# multiplicities, but never proves that their common value is one.
for k in (1,2,7):
    m=[k]*6
    weights=[d*x/sum(d0*x0 for d0,x0 in zip(D,m)) for d,x in zip(D,m)]
    assert all(abs(w-d/15)<1e-14 for w,d in zip(weights,D))
assert Fraction(3,6)==Fraction(1,2)
assert Fraction(8,6)==Fraction(4,3)
assert 2**2==4 and 3**2==9

out={
 "status":"PASS",
 "checked_scopes":["six Spin(4) irreps","coordinate-edge connectivity",
                   "central parity kernels","43/137/225 block dimensions",
                   "explicit center-distinguishing density/effect",
                   "common-amplification normalized-trace no-go",
                   "S3/RP3 first-scalar-eigenvalue ratio arithmetic"],
 "sector_dimensions": dict(zip(NAMES,D)),
 "central_signs": {c:v for c,v in CENTERS.items()},
 "center_characters":character,
 "coordinate_graph_edges":EDGES,
 "observable_stages":[
     {"stage":"kinematic","components":components([]),"algebra_dimension":algebra_dim([]),"central_kernel":center_kernel([]),"effective_group":"SO(3)_L x SO(3)_R"},
     {"stage":"intrinsic coordinate","components":components(EDGES),"algebra_dimension":algebra_dim(EDGES),"central_kernel":center_kernel(EDGES),"effective_group":"SO(4)"},
     {"stage":"cross-component bridge","components":components(EDGES+[("E0","S+")]),"algebra_dimension":algebra_dim(EDGES+[("E0","S+")]),"central_kernel":center_kernel(EDGES+[("E0","S+")]),"effective_group":"Spin(4)"}],
 "distinguishing_probabilities":{"identity":round(prob_identity,12),"left_center":round(prob_center,12)},
 "first_scalar_eigenvalue_over_scalar_curvature":{"S3":"1/2","RP3":"4/3"},
 "global_cover_and_physical_occurrence_claimed":False,
 "universal_GP3_multiplicity_one_claimed":False
}
if __name__=="__main__":
    print(json.dumps(out,indent=2,ensure_ascii=False))
