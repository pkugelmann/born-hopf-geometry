# Paper VII — Repaired derivation statements and exact certificates

**Repair addendum v1_1** — reviewed against `Paper00-PapersMinimal-v2_349` with source files `Paper7A-QCDKernel-v1_156.tex`, `Paper7B-QCDReadouts-v1_141.tex`, `Paper7C-ContinuousQFT-v2_189.tex`, `Paper7D-TechnicalMaterial-v1_38.tex`. This addendum **does not amend** those source files; it supplies replacements and strengthened claims for a subsequent version-controlled integration. Results marked **exact** need only their stated finite algebraic inputs. Results marked **conditional** explicitly identify a physical/interface certificate.

## 1. Fixed-carrier Hurwitz geometry: an exact low-band alternative to mesh convergence

### Theorem H1 (24-point five-design and exact scalar frame) — exact

Put

\[
 V_H=\{\pm e_i:1\le i\le4\}\cup\{(s_1,s_2,s_3,s_4)/2:s_i=\pm1\}\subset S^3.
\]

The uniform atomic measure on these 24 points integrates exactly all restrictions of real polynomials on \(\mathbb R^4\) of total degree at most five. In particular,

\[
\frac1{24}\sum_{q\in V_H}q_iq_j=\frac{\delta_{ij}}4,\qquad
\frac1{24}\sum_{q\in V_H}q_iq_jq_kq_l=
\frac{\delta_{ij}\delta_{kl}+\delta_{ik}\delta_{jl}+\delta_{il}\delta_{jk}}{24}.
\]

**Proof.** Central inversion removes all odd moments. Of the 24 vertices, 8 have one axial coordinate \(\pm1\) and the other 16 have each coordinate \(\pm1/2\). The resulting second moment is \(1/4\), diagonal fourth moment \(1/8\), and mixed fourth moment \(1/24\), matching the uniform sphere. Permutation/sign symmetry accounts for all monomials through degree five. Thus the complete polynomial moment functionals agree. If \(\mathcal B_2=\mathcal Y_0\oplus\mathcal Y_1\oplus\mathcal Y_2\), \(\dim\mathcal B_2=1+4+9=14\); the product of two elements of \(\mathcal B_2\) is a polynomial of degree at most four. Consequently the sampling map \(S:\mathcal B_2\to\mathbb C^{24}\), with normalized \(24^{-1}\sum\) inner product, is an exact isometry. \(\square\)

**Scope:** \(\mathcal B_2\) is an **auxiliary scalar harmonic comparison subspace** of dimension 14; it must not be identified silently with the separate 15-dimensional physical \(\mathcal H_1\), or with a spinorial representation.

### Theorem H2 (exact sampled scalar Laplacian on \(\mathcal B_2\)) — exact

Let \(A_H\) be the adjacency matrix of the Hurwitz 24-cell, \((A_H)_{q,q'}=1\) iff \(\langle q,q'\rangle=1/2\). For a vertex \(q\), its eight neighbors are \(q'_a=q/2+(\sqrt3/2)u_a\), with \(u_a\in T_qS^3\), \(\sum_a u_a=0\) and \(\sum_a u_au_a^T=(8/3)(I-qq^T)\). Hence

\[
\sum_{q'\sim q}q'=4q,\qquad
\sum_{q'\sim q}q'q'^T=2I_4.
\]

These identities imply \(A_HS f=8Sf\) on constants, \(A_HSf=4Sf\) on degree-one harmonics, and \(A_HSf=0\) on trace-free harmonic quadratics. Define

\[
 L_H:=\frac1{R^2}\left(\frac{A_H^2}{16}-\frac32A_H+8I\right).
\]

On \(\mathcal B_2\), the round Laplacian has eigenvalues \(\ell(\ell+2)/R^2\) for \(\ell=0,1,2\). The polynomial in \(A_H\) takes the respective values 0, 3 and 8 at \(A_H=8,4,0\). Therefore

\[
\boxed{L_H S f=S(-\Delta_{S^3(R)})f\quad(f\in\mathcal B_2).}
\]

The exact full adjacency spectrum is \(8^{(1)},4^{(4)},0^{(9)},(-2)^{(8)},(-4)^{(2)}\); the identity is asserted **on \(S\mathcal B_2\)** only. It is an exact fixed-shell interpolation, not an \(m_p\)-flow, nor a Dirac identity. \(\square\)

### Theorem H3 (quantitative spinorial stencil remainder) — exact bound, nonconvergent at fixed shell

Take the original spinorial nearest-neighbor stencil with each neighboring spinor parallel-transported back to the base frame:

\[
 (D_{H,0}S\psi)(q)=\frac3{8\ell_H}\sum_{a=1}^8c(u_a)\,P_{q\leftarrow q'_a}\psi(q'_a),\quad
 \ell_H=\pi R/3.
\]

In a geodesic Taylor expansion, the constant term vanishes by \(\sum u_a=0\). The linear term is \(c(e_i)\nabla_{e_i}\psi\) by cubic second-moment isotropy. The quadratic term vanishes because the cube is invariant under \(u\mapsto-u\), so all rank-three directional moments vanish. The integral Taylor remainder gives

\[
\boxed{\|(D_{H,0}S\psi)(q)-(SD_{S^3}\psi)(q)\|
\le \frac{\ell_H^2}{2}\sup_{a,\,0\le s\le\ell_H}
\|\nabla_{\dot\gamma_a}^3\psi(\gamma_a(s))\|.}
\]

Here \(\psi\in C^3\) is in a smooth local spin frame and the Clifford multiplication has unit operator norm on unit tangent vectors. Since \(\ell_H/R=\pi/3\) remains fixed, **the bound is not a convergence claim**. To obtain exact low-band spinorial reproduction, specify the native spinor subspace \(\mathcal B_D\), sample its orthonormal basis, and compute the finite residual \(\mathcal E_D=D_HS_{\mathcal B_D}-S_{\mathcal B_D}D_{\mathcal B_D}\). The test \(\mathcal E_D=0\) is finite and decidable; without it, no exact Dirac claim is made.

## 2. Color realization and local gauge projection

### Theorem C1 (typed color algebra) — exact relative to imported Paper V-A color ownership

The axis-selected cube link has two three-element trimer supports \(T_+\sqcup T_-\). On \(C=\mathbb C^{T_+}\),

\[
 \operatorname{End}_0(C)\cong\mathfrak{sl}_3(\mathbb C),\quad
 \mathfrak{su}(C)=\{X\in\operatorname{End}_0(C):X^\dagger=-X\}
\]

has **real** dimension eight, and its complexification is \(\mathfrak{sl}_3(\mathbb C)\) with \(A_2\) root decomposition \(2+6\). The finite vertex figure **realizes** the color module selected in Paper V-A; the count of three points does not independently prove the uniqueness of the full physical gauge group. The color center \(Z(SU(3))=\mathbb Z_3\) is separate from the outer \(S_3\) triality of \(D_4\).

### Theorem C2 (gauge-local Gauss projector) — exact on a supplied full link/matter Hilbert space

Let \(G=SU(3)\), \(\mathcal H= L^2(G^{E_H},d\mu_H)\otimes\mathcal H_{\mathrm{matter}}\). The product vertex gauge group \(\mathcal G_H=G^{V_H}\) acts on oriented links by \(U_{pq}\mapsto g_pU_{pq}g_q^{-1}\) and on matter in its assigned local color representation. Product Haar measure makes this action unitary. Define

\[
 P_{\mathrm{Gauss}}=\int_{G^{V_H}}\mathcal U(\{g_v\})\prod_vdg_v.
\]

Then \(P_{\mathrm{Gauss}}=P_{\mathrm{Gauss}}^\dagger=P_{\mathrm{Gauss}}^2\) and its range is precisely the gauge-invariant Hilbert subspace. If the chosen finite Hamiltonian commutes with every \(\mathcal U(\{g_v\})\), it commutes with this projector and preserves the physical Gauss subspace. The one-copy global Haar singlet projector is a weaker condition and must not be confused with this vertexwise projection. This theorem fixes the **projection**, not a new dynamical coefficient or a physical Hamiltonian uniquely from geometry.

## 3. Whole-family Hamiltonian, source responses and exact Schur identities

### Theorem S1 (functorial QCD family) — exact relative to imported finite owners

For any supplied upstream quark mass family \(\mathcal M_q\), the constructor

\[
 M\longmapsto P_{\mathrm{Gauss}}\big(H_{\rm YM}+H_q[M]+H_{\rm int}\big)P_{\mathrm{Gauss}}
\]

defines a finite Hermitian family whenever the three entries are well-defined Hermitian matrices and gauge invariant. This entails **no new independent quark mass selector** and justifies retiring `G34` as a separate *selector*. It does not prove that every coefficient or a unique physical mass member is supplied by these axioms alone. Numerical execution imports the actual Paper V source member and RG/threshold transport; it does not select the mass by hadron fitting.

### Theorem S2 (precise source grammar) — exact for the stated operator dictionary

Let \(H\) be finite Hermitian and \(\{O_a\}\) a specified dictionary of bounded gauge-invariant operators. For time-dependent sources define

\[
 Z_\beta[J]=\mathrm{Tr}\,\mathcal T_\tau\exp\!\left[-\int_0^\beta\left(H-\sum_aJ_a(\tau)O_a\right)d\tau\right].
\]

Its functional derivatives give the corresponding time-ordered thermal insertions. More generally, for a nonlinear Hermitian source member \(H(J)\), put \(H_a=\partial_aH\) and \(H_{ab}=\partial_a\partial_bH\). With \(\rho=e^{-\beta H}/Z\),

\[
 \partial_a W=-\beta\langle H_a\rangle,\qquad
 \partial_a\partial_bW=-\beta\langle H_{ab}\rangle+\beta^2\mathcal C_{\rho}^{\rm Duhamel}(H_a,H_b),
\]

where \(\mathcal C_\rho^{\rm Duhamel}(A,B)=\int_0^1\mathrm{Tr}(\rho^{1-s}\delta A\rho^s\delta B)\,ds\). The contact term \(-\beta\langle H_{ab}\rangle\) cannot be dropped. An arbitrary off-diagonal form factor requires the relevant operator and spectral projectors; a single static scalar partition function does not contain all observable matrix elements.

For orthogonal \(P,Q=I-P\) and \(z\notin\operatorname{spec}(QHQ)\), the Feshbach matrix

\[
 H_{\rm eff}(z)=PHP+PHQ(z-QHQ)^{-1}QHP
\]

obeys the exact resolvent-block identity

\[
 P(z-H)^{-1}P=(z-H_{\rm eff}(z))^{-1}
\]

where both sides exist. On a finite isolated Hermitian carrier its poles are real; **physical scattering resonance widths** require a separately specified open-channel or continuum boundary-value limit. The source grammar is complete for observables explicitly represented in its finite operator dictionary; it does not automatically establish PDFs, collider scattering, or every conceivable downstream measurement.

### Theorem S3 (gap separation) — exact finite statement, conditional continuum statement

A representation-theoretic empty support interval \(\mathbf1_{(E_{56},E_{40})}(H_{\rm car})=0\) is an algebraic assertion about a **different operator** from the finite Yang–Mills Hamiltonians. Positive finite gaps \(\gamma_L>0\) alone do not imply a uniform continuum gap (counterexample \(H_L=\operatorname{diag}(0,L^{-1})\)). If \(H_L-E_{0,L}\ge\gamma_*(I-P_{0,L})\) uniformly and the vacuum-centered transfer quadratic forms converge on a dense cyclic family to the limiting vacuum-centered semigroup, the spectral theorem gives \(\operatorname{spec}(H)\cap(0,\gamma_*)=\varnothing\) on the generated physical Hilbert space. The uniform estimate and compatible vacuum projection are independent analytic certificates; they do not follow from the native carrier support interval.

## 4. Three-face baryonic geometry and flux: exact separation of observables

### Theorem B1 (face incidence, polarized determinant) — exact

Each of the 96 Hurwitz edges belongs to exactly three of the 96 triangular faces. For three fundamental Wilson transports with common endpoints,

\[
 \mathcal E(A,B,C)=\frac16\epsilon_{abc}\epsilon_{a'b'c'}A_{aa'}B_{bb'}C_{cc'}
 =\langle\epsilon/\sqrt6,(A\otimes B\otimes C)\epsilon/\sqrt6\rangle.
\]

Thus for unitary \(A,B,C\), \(|\mathcal E(A,B,C)|\le1\). For all three equal, \(\mathcal E(U,U,U)=\det U=1\); **not** for distinct transports. Indeed \(\mathcal E(A,I,I)=\operatorname{tr}A/3\), which at \(A=\operatorname{diag}(-1,-1,1)\in SU(3)\) equals \(-1/3\ne\det A\). The native three-path amplitude is therefore nonconstant and gauge-invariant when its three paths have the required matched endpoints; its spin dependence comes from the specified spin–color transport coefficients, not from the scalar determinant alone.

### Theorem B2 (separate gauge-face observable and exact Haar benchmark) — exact on the stated reference measure

For \(U\in SU(3)\), let \(z(U)=\operatorname{tr}U/3\), \(F(U)=|z(U)|^2-\mathrm{Re}\,z(U)\), \(D_e=\sum_{f\supset e}F(U_f)\), and \(\mathcal F_H=96^{-1}\sum_fF(U_f)\). Then

\[
 -\frac14\le F(U)\le\frac32,\quad
 -\frac34\le D_e\le\frac92,\quad
 -\frac14\le\mathcal F_H\le\frac32.
\]

The first lower bound follows from \(F=|z-1/2|^2-1/4\); the upper bound follows from \(|z|\le1\) and \(\mathrm{Re}\,z\ge-1/2\) in \(SU(3)\). The edge-fan bounds are sharp for independently programmable face holonomies in the original finite link realization. By \(\chi_3\chi_{\bar3}=1+\chi_8\),

\[
 F(U)=\frac{1+\chi_8(U)}9-\frac{\chi_3(U)+\chi_{\bar3}(U)}6.
\]

Character orthogonality gives \(\mathbb EF=1/9\), \(\operatorname{Var}(F)=1/81+2/36=11/162\). For independent Haar links, distinct face holonomies are pairwise independent because the faces have exclusive edge factors. Hence

\[
 \boxed{\mathbb E_{\mathrm{Haar}}\mathcal F_H=\frac19,\quad
 \operatorname{Var}_{\mathrm{Haar}}(\mathcal F_H)=\frac{11}{15552}.}
\]

These are benchmarks of \(\mathcal F_H\), **not** values of baryon energies or of the polarized determinant itself. Under \(H(\lambda)=H+\lambda\mathcal F_H\), Feynman–Hellmann gives \(E'_j(0)=\langle\psi_j,\mathcal F_H\psi_j\rangle\) for simple isolated branches. For degenerate blocks the first derivatives are eigenvalues of the compressed perturbation \(P_j\mathcal F_HP_j\), not an arbitrary basis expectation.

## 5. Nuclear ranks: exact quotient arithmetic versus actual cumulative shell closure

### Theorem N1 (Gram quotient) — exact if the actual map passes its test

Let \(S_r\) be the **actual** nuclear source map, \(G_r=S_r^*S_r\), and \(\mathcal L_r^\sigma\) the selected oriented forbidden face in the inherited degree-\(r\) space \(\mathcal B_r\). If

\[
 S_r\mathcal L_r^\sigma=0,\qquad
 G_r\ge g_r P_{(\mathcal L_r^\sigma)^\perp},\quad g_r>0,
\]

then \(\ker S_r=\mathcal L_r^\sigma\) and

\[
 d_r:=\operatorname{rank}S_r=\dim\mathcal B_r-\dim\mathcal L_r^\sigma
=(1,4,10,14,25,41,63)_r.
\]

Twofold CAR occupancy gives **capacity of that individual rank-\(d_r\) image** equal to \(2d_r=(2,8,20,28,50,82,126)\). This is exactly the theorem already present in Paper VII-B on its Gram-passing branch.

**Crucial additional issue:** \(\mathcal N_r=\mathcal B_r/\mathcal L_r^\sigma\) is explicitly degree-\(r\), not a cumulative degree-at-most-\(r\) space. If these degree spaces are independent shells, their cumulative twofold counts are

\[
 2\sum_{s=0}^rd_s=(2,10,30,58,108,190,316),
\]

**not** the desired magic-number sequence. Matching \(2d_r\) to experimentally cumulative magic numbers needs a new native cumulative-space/spectral-counting identification.

### Theorem N2 (correct physical shell-closure certificate) — conditional, directly testable

Let \(h_{\rm nuc}^{(1)}\) be the actual gauge-reduced one-body nuclear response Hamiltonian in a **common** one-body Hilbert space. For each \(r\), require a physical level \(\lambda_r\) lying in a genuine spectral gap, and

\[
 \boxed{\operatorname{rank}\mathbf1_{(-\infty,\lambda_r)}(h_{\rm nuc}^{(1)})=d_r,
 \quad \operatorname{dist}(\lambda_r,\operatorname{spec}h_{\rm nuc}^{(1)})>0.}
\]

Then the actual ordered, doubly occupied levels close at \(N_r=2d_r\). Equivalently, construct nested native occupied spaces \(V_0\subset V_1\subset\cdots\subset V_6\) with \(\dim V_r=d_r\), and prove that the actual Hamiltonian realizes them as ordered spectral subspaces. Their incremental orbital degeneracies must be \((1,3,6,4,11,16,22)\). Abstract existence of inclusions from dimension monotonicity is not an acceptable native proof: they must arise from the actual source/Hamiltonian maps.

## 6. Physical null generator and LO light-ray sum rules

### Theorem L1 (exact commutator) — exact relative to the native longitudinal symmetry

If the actual same-owner longitudinal Hopf/Cartan generator satisfies \([H_L,P_{H,L}]=0\), then \(P_{\rm phys,L}^+=(H_L/c_{\rm op}+P_{H,L})/\sqrt2\) commutes with \(H_L\) and all its spectral projections preserve the Hamiltonian block. No equality to a free Fock fraction operator is needed. This establishes conserved sectors, **not** positivity of \(P^+\), a well-defined null Wilson-line bilocal, distribution support, or a partonic interpretation by itself.

### Theorem L2 (conditional physical PDF sum rules) — exact after Ward/renormalization certificates

If the supplied gauge-invariant Wilson-line bilocals have controlled light-ray limits and Mellin interchange; if the renormalized \(n=1\) and \(n=2\) local operators coincide in the *same physical representation* with the flavor Noether charges and the full renormalized Belinfante stress tensor (including contacts, zero modes and mixing); and if the distributions have the stated support, then the charge and momentum sum rules follow from the corresponding forward Ward matrix elements without `LF-REPL`. Each hypothesis is an observable certificate, not a new primitive structure.

### Theorem L3 (correct LO singlet fixed point) — exact for the specified perturbative evolution

With fixed \(n_f\) active light flavors and \(N_c=3\), the leading-order second-moment evolution obeys

\[
\frac{d}{d\ln\mu^2}\binom QG
=\frac{\alpha_s}{2\pi}
\begin{pmatrix}-16/9&n_f/3\\16/9&-n_f/3\end{pmatrix}\binom QG.
\]

The zero eigenvector has ratio \(Q:G=3n_f:16\), giving \(Q_*=3n_f/(16+3n_f)\), \(G_*=16/(16+3n_f)\). For \(n_f=3\), \(Q_*=9/25\), \(G_*=16/25\). The nonzero eigenvalue is \(-25/9\) and the corresponding LO Ji total-angular-momentum fixed point is \((J_q,J_g)=(9/50,8/25)\). The draft's alternative \(9/17\) is not a second scheme; it is algebraically erroneous. Since the framework retains a finite physical UV ceiling, the \(\mu\to\infty\) interpretation is a **formal fixed point of the imported evolution**, not automatically a physically accessible asymptotic regime.

## 7. Fixed-UV continuum: the genuine reconstruction theorem

### Theorem Q1 (weak-* state and inherited bounded identities) — exact after a common algebra is constructed

Let \(\mathfrak A\) be a fixed unital cylinder/quasilocal \(C^*\)-algebra with compatible unital positive representation maps into finite Born–Hopf sectors, and \(\omega_L\) normalized states pulled back to \(\mathfrak A\). The state space of \(\mathfrak A\) is weak-* compact; therefore a convergent subnet \(\omega_{L_\beta}\to\omega_\alpha\) exists. If a common positive-time subalgebra and reflection are supplied and **each actual finite state** is reflection positive on this fixed test algebra, the cluster state is reflection positive as well. Every exact *bounded word identity* that is genuinely represented on the common algebra passes to this cluster in expectation. This is a positive bounded-algebra limit, not by itself a Wightman field theorem.

### Theorem Q2 (OS/Wightman conditional handoff) — conditional

To assert ordinary local OS/Wightman fields, additionally prove a common Euclidean Schwinger distribution hierarchy with corrected uniform regularity/growth conditions, full flat \(E(4)\) covariance including time-space mixing, graded permutation symmetry, reflection positivity, suitable vacuum/cluster requirements, compatible source-field limits, and the locality-support relation. The relevant Osterwalder–Schrader reconstruction then yields a positive-energy Hilbert-space/field representation. Native spatial symmetry and a positive Hamiltonian are insufficient by themselves to establish full Euclidean covariance or exact spacelike commutativity. A weak-* limit does not supply unbounded field domains, mixed-moment convergence, or the missing locality map.

### Theorem Q3 (fixed-band no-go for naive canonical point locality; operational bound) — exact on the stated free comparison model

For the canonical free spatial Fourier cutoff \(|k|\le\Lambda\),

\[
\delta_\Lambda(r)=\frac{\sin\Lambda r-\Lambda r\cos\Lambda r}{2\pi^2r^3}\ne0
\]

on an open set of positive separations. For supports separated by distance at least \(d>0\),

\[
\boxed{\left|\iint \bar f(x)\delta_\Lambda(|x-y|)g(y)\,dx\,dy\right|
\le \frac{1+\Lambda d}{2\pi^2d^3}\,\|f\|_1\|g\|_1.}
\]

The estimate is finite and detector-relevant but does not tend to zero simply by increasing \(R_x\) at fixed \(\Lambda\). The theorem rules out inferring exact point locality for this **canonical comparison field**; it does **not** rule out a distinct, natively derived Born–Hopf observable net. The physically relevant alternative target is a derived quantitative leakage bound for actual detector observables at specified separations and resolutions.

### Theorem Q4 (genuine QFT identity transfer) — conditional

Suppose a finite Ward/contact/anomaly identity \(I_L=0\) is represented as an equality of **ordered** correlation distributions and the complete terms converge jointly, with source contact terms and normalization controlled, on a common dense test domain. Then the limiting correlations satisfy \(I=0\). To conclude a limiting **operator** identity, its matrix elements must vanish on a dense invariant domain (a cyclic GNS vacuum alone is not a separating vector for every operator). In the physical quotient the operator then vanishes on that domain. This is stronger and more precise than claiming that all polynomial correlation identities automatically turn into operator equalities.

## 8. Wedderburn and CCR: two complementary exact statements

### Theorem W1 (finite selector commutant) — exact

For any supplied selector \(C^*\)-algebra \(\mathcal B_S\subseteq\operatorname{End}(\mathcal H_C)\),

\[
\mathcal H_C\cong\bigoplus_\alpha V_\alpha\otimes M_\alpha,\qquad
\mathcal B_S'\cap\operatorname{End}(\mathcal H_C)
\cong\bigoplus_\alpha I_{V_\alpha}\otimes\operatorname{End}(M_\alpha).
\]

This is exhaustive for finite operators commuting with **those supplied selectors**. It does not preclude new large-volume collective excitations, superselection sectors, or emergent symmetries whose definition involves the entire refinement family.

### Theorem W2 (two levels of CCR recovery) — exact

For the truncated oscillator on \(\mathcal F_N=\operatorname{span}\{|0\rangle,\dots,|N\rangle\}\),

\[
[a_N,a_N^*]=I-(N+1)|N\rangle\langle N|.
\]

Thus \((N+1)\omega_N(|N\rangle\langle N|)\to0\) is **equivalent only to convergence of the commutator's expectation** to one. It is not a regularity theorem: the pure states \(|N-1\rangle\) have zero top-level defect but unbounded mean occupation.

There is a stronger unconditional operator result on the *standard nested occupation system*: embed \(\mathcal F_N\) into \(\ell^2(\mathbb N_0)\). For every finite-support vector \(\psi\), the truncated \(a_N,a_N^*\) agree exactly with the canonical \(a,a^*\) for all sufficiently large \(N\). The CCR therefore holds on the inductive finite-particle core without any state-limit hypothesis. This is an algebraic regular Fock presentation, not a statement that an arbitrary actual physical state sequence converges to it.

For **physical state convergence**, a sufficient check is: (i) a common mean-number bound \(\sup_N\mathrm{Tr}(\rho_N\mathsf N)<\infty\) after these embeddings, (ii) convergence of every fixed finite matrix element of \(\rho_N\), and (iii) the top-boundary defect tends to zero if the commutator expectation is also desired. The energy/number bound supplies uniform tail tightness; the finite-block convergence and tail bound give trace-norm convergence to a density matrix \(\rho\). Consequently \(\mathrm{Tr}(\rho_N W(z))\to\mathrm{Tr}(\rho W(z))\) uniformly in \(z\), and the limiting Weyl state is regular. These are sufficient, not claimed necessary.

## 9. Repair-status ledger and next actual operator certificates

| Component | Repaired theorem status | Remaining physical certificate |
| --- | --- | --- |
| 24-cell cubature and scalar Laplacian \(\ell\le2\) | **Exact; independently checked** | Match auxiliary scalar band to actual 15-carrier as needed |
| Free spinor stencil | Exact finite \(C^3\) error bound | Native spinor band and residual \(\mathcal E_D\) |
| SU(3) trimer | Exact local realization of imported carrier | No second color-selector assertion |
| Local Gauss projector | Exact on link/matter gauge representation | Verify the actual Hamiltonian's local invariance |
| QCD family and source calculus | Exact on supplied matrices/dictionary | Physical source matching, ordered-source completeness and observable extraction |
| Baryonic three-face invariant | Exact polarized determinant and flux reference | Interacting baryon spectral response |
| Nuclear ranks | Exact Gram-conditional per-degree capacities | **Cumulative spectral counting and gaps** |
| PDF charge and momentum | Ward-conditional, independent of `LF-REPL` | Native light-ray, operator mixing and zero-mode residue limits |
| DGLAP fixed fractions | Exact fixed-\(n_f\) LO evolution | RG-scale/UV domain for physical interpretation |
| Bounded continuum state | Weak-* exact after common \(C^*\)-algebra | Full OS hierarchy and locality |
| Fixed-band point locality | Exact comparison obstruction and leakage bound | Distinct native operational locality certificate |
| Wedderburn | Exact relative finite commutant | No unrestricted continuum-exhaustiveness claim |
| CCR | Exact finite-particle core; physical state limit conditional | Occupation tightness and boundary defect |
| Pure-glue continuum gap | Conditional uniform spectral transfer | \(\inf_L\gamma_L>0\) and dense semigroup compatibility |

**Verification:** `Paper00-PaperVIIRepairProofs-v1_1.py` tests all 126 four-variable monomials through degree five, exact 24-cell adjacency spectrum and incidence, the 14-dimensional sampled harmonic sector, its exact Laplacian intertwiner, a rational polarized-determinant counterexample, Haar variance arithmetic, the DGLAP eigenvector, and the shell/CCR distinctions. JSON output is `Paper00-PaperVIIRepairProofs-v1_1-results.json`. Exact verification of these algebraic claims does **not** verify the physical source owners or discharge the outstanding analytic certificates.
