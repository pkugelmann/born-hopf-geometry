# Paper00 — Petersen–600-Cell Exact Incidence and Transport Bridge

**Version:** `Paper00-Petersen600CellBridge-v1_6`  
**Status:** mathematical finite-geometry/combinatorial certificates established; physical decay interpretation explicitly unproved  
**Source framework:** `Paper00-PapersMinimal-v2_370.zip`, especially `Paper1A-Geometry-v5_167.tex`, `Paper3C-ProtectedHierarchy-v1_179.tex`, `Paper3F-CompleteDynamics-v1_256.tex`, `Paper5C-InteractionResponse-v2_170.tex`, `Paper7A-QCDKernel-v1_165.tex`, and `Paper7B-QCDReadouts-v1_150.tex`  
**Exact executable certificate:** `Paper00-Petersen600CellIncidence-v1_7.py` (pure Python, standard library only). Earlier internal version references mark the historical stage of a subsection, not the current verification command.

## 1. Purpose and mathematical scope

The 600-cell's vertex set is the binary icosahedral group \(2I\subset \mathrm{Sp}(1)\), with 120 unit-quaternion vertices and 720 shortest edges. The ordinary Petersen graph \(P=KG(5,2)\) is **not** a subgraph of the 600-cell 1-skeleton: a complete exact search of its potential embeddings, allowing additional ambient edges, finds none. The correct stronger structural relation is an induced **dodecahedral double cover** and an induced **total graph** carrying the entire Petersen vertex/edge incidence after inversion quotient.

The existing framework already owns the five conjugate \(H_i\cong2T\), ten \(C_{ij}=H_i\cap H_j\cong C_6\), intrinsic Petersen adjacency, signed Hodge modules, 15 quaternionic flux axes, and geometric mean \(E_{36}=\sqrt{E_{32}E_{40}}\). This note supplies *additional shortest-edge and electrical-network identifications* and does **not** replace those claims.

## 2. Exact finite shells and first graph theorem

Let \(\varphi=(1+\sqrt5)/2\). The unit-quaternion 600-cell graph joins \(q,r\in2I\) precisely when

\[
\operatorname{Re}(q^{-1}r)=\frac\varphi2,\qquad
\ell_{\mathrm{edge}}=\sqrt{2-\varphi}=\varphi^{-1}.
\]

The **order-six shell**

\[
D=\{q\in2I:\operatorname{Re}q=1/2\},\qquad |D|=20,
\]

can be written \(q=1/2+w\) with \(|w|=\sqrt3/2\). Put \(w=(\sqrt3/2)u\), \(|u|=1\). For \(q,r\in D\), the edge condition becomes

\[
u\cdot v=\sqrt5/3.\]

The 20 directions \(u\) are a regular dodecahedron's vertices, and this is their nearest-neighbor relation. Thus the **induced** graph on \(D\) is the dodecahedral graph \(D_{20}\), with 20 vertices, 30 edges, degree 3.

Quaternion inversion acts on this shell as \(q=1/2+w\mapsto q^{-1}=1/2-w\). It is the dodecahedral antipodal involution. The quotient has ten vertices, fifteen edges, degree 3, adjacent common-neighbor count 0 and nonadjacent count 1, hence

\[
\boxed{D_{20}/(q\sim q^{-1})\cong P_{10}.}
\]

This supplies an *edge-preserving 2-to-1 covering map*, not a ten-vertex Petersen subgraph of the 600-cell.

## 3. The 30 order-four vertices are the dodecahedral line graph

Let

\[
Z=\{z\in2I:\operatorname{Re}z=0\},\quad |Z|=30.
\]

For each dodecahedral edge \(e=\{q,r\}\) with \(q=1/2+w\), \(r=1/2+z\), define the *imaginary midpoint*

\[
\mu_e=\frac{w+z}{\varphi}.
\]

The exact identities \(|w|^2=|z|^2=3/4\), \(w\cdot z=\sqrt5/4\) imply \(|\mu_e|=1\). The exact \(\mathbb Q(\sqrt5)\) coordinate computation places \(\mu_e\) inside \(Z\). The map \(e\mapsto\mu_e\) is a bijection between the thirty dodecahedral edges and thirty order-four quaternions. It obeys

\[
\{e,f\}\text{ share a dodecahedral endpoint}
\iff \mu_e\sim_{600}\mu_f.
\]

Thus the **induced** order-four graph is

\[
\boxed{600[Z]\cong L(D_{20}),}
\]

the 30-vertex, 60-edge, degree-4 icosidodecahedral graph.

Moreover, for \(q\in D\), \(z\in Z\), the original 600-cell has an edge \(q\sim_{600}z\) iff \(z=\mu_e\) for one of the three dodecahedral edges incident to \(q\). There are precisely 60 cross-shell edges. Consequently

\[
\boxed{600[D\cup Z]\cong T(D_{20}),}
\]

where \(T\) is the *total graph* (vertices, edge-vertices, vertex/edge incidences and edge/edge shared-endpoint adjacencies). This is an **induced 50-vertex, 150-edge, 6-regular subgraph**.

Quaternion inversion preserves the entire induced graph; it sends \(D\) to opposite dodecahedral vertices and \(Z\) to \(\pm\) pairs. Therefore

\[
\boxed{T(D_{20})/(q\sim q^{-1})\cong T(P_{10}).}
\]

The quotient has \(10+15=25\) vertices, 75 edges and degree six. Its 10 vertex-type nodes are the projective \(C_6\) axes; its 15 edge-type nodes are projective order-four half-turn axes. Each original edge-pair in the double cover maps to a quotient edge. This is a **genuine nearest-neighbor realization of the entire Petersen incidence system via quotient**, not a Petersen embedding.

### The 20 local tetrahedral faces

For each \(q\in D\), let \(e_1,e_2,e_3\) be its three dodecahedral edges. The four quaternions

\[
\{q,\mu_{e_1},\mu_{e_2},\mu_{e_3}\}
\]

are pairwise nearest neighbors in the 600-cell; they span a regular tetrahedral cell. These are exactly the twenty 4-cliques of the induced 50-node total graph. Under inversion they occur in ten pairs.

## 4. Quaternion/Clifford frame at each dodecahedral edge

Given an edge's imaginary parts \(w,z\), define

\[
\boxed{m=\frac{w+z}{\varphi},\qquad
 d=\varphi(w-z),\qquad k=2w\times z.}
\]

Each is a **unit pure imaginary quaternion belonging to \(2I\)**. They are mutually orthogonal, and multiplication gives

\[
m^2=d^2=k^2=-1,\qquad md=-k,\qquad dm=k.
\]

Hence they produce a genuine \(Q_8=\{\pm1,\pm m,\pm d,\pm k\}\) inside \(2I\). The pair of inverse dodecahedral edges has the same **projective** triad of three order-four axes. All 15 Petersen edges yield precisely **five distinct \(Q_8\) subgroups**, each occurring for exactly three Petersen edges. The certificate directly computes that every such \(Q_8\) has a normalizer of size 24 in \(2I\): these normalizers are precisely the five conjugate \(2T\) cores.

For a Petersen edge \(e=(ij\mid kl)\) with unused label \(m\), its triad belongs to \(Q_8(H_m)\). Thus for a Petersen vertex \(ij\), its three directly incident order-four midpoint channels lie in the **three complementary** tetrahedral cores

\[
\boxed{C_{ij}\longleftrightarrow\{Q_8(H_m):m\notin\{i,j\}\}.}
\]

In particular, none of the nearest order-four channels from \(C_{ij}\) lies in its two parent cores \(H_i,H_j\). This is a *finite-geometric nearest-neighbor selection rule*. No claim is made that these are already physical decay channels.

### Transverse trimer

For a chosen endpoint \(q=1/2+w\) let \(u=2w/\sqrt3\) and \(m_e\) denote its three incident midpoint vertices. Then

\[
u\cdot m_e=\varphi/\sqrt3,\qquad
\sum_{e\ni q}\left(m_e-\frac\varphi{\sqrt3}u\right)=0.
\]

The three projected vectors each have squared norm \(1/(3\varphi^2)\) and mutual angle \(120^\circ\). Their quarter-turns in \(u^\perp\) are the normalized cross-product flux vectors \(k_e=\sqrt3\varphi\,u\times m_e\), up to the chosen orientation of the incidence edge. Thus Paper I-A's transverse \(A_2\) trimer has a **literal 600-cell tetrahedral-face construction**.

## 5. Even/odd Petersen cover spectrum

Choose one lift of each of the ten antipodal dodecahedral vertex pairs. Every Petersen edge receives a sign \(s_{ij}=+1\) when the two chosen lifts are adjacent in the dodecahedron, and \(-1\) otherwise. Its \(10\times10\) signed adjacency \(S\) satisfies

\[
S^3=5S,\qquad\operatorname{Spec}S
=\{(\sqrt5)^3,0^4,(-\sqrt5)^3\}.
\]

The 12 Petersen pentagons have six positive and six negative signed holonomies. The even deck sector has adjacency \(A_P\) with spectrum \(3^1,1^5,(-2)^4\), and the odd sector has signed adjacency \(S\). Thus the actual dodecahedral graph spectrum is their union. This reproduces and concretizes the already-owned signed Petersen/Hopf theorem; it is not asserted as a new representation-theoretic discovery.

## 6. Parameter-free resistance calculation on the 25-node quotient

All original shortest edges have equal chord length \(\varphi^{-1}\). To isolate topology, assign each quotient edge unit conductance; multiplying all conductances by a constant rescales all resistances uniformly.

Let \(A\) be the \(10\times10\) Petersen adjacency and \(B\) the unsigned \(10\times15\) vertex-edge incidence (each column has two ones). The total-graph adjacency is

\[
A_T=\begin{pmatrix}A&B\\B^T&B^TB-2I_{15}\end{pmatrix}.
\]

The 25-node Laplacian \(L_T=6I_{25}-A_T\) gives after eliminating the 15 channel nodes:

\[
L_{10}=6I_{10}-A-B(8I_{15}-B^TB)^{-1}B^T.
\]

Use the framework's Petersen projectors \(P_4\) and \(P_5\) with ranks four and five:

\[
\boxed{L_{10}=\frac{55}{7}P_4+4P_5.}
\]

The two effective-resistance classes are

\[
R_{\rm adjacent}=\frac{37}{110},\qquad
R_{\rm nonadjacent}=\frac{23}{55}.
\]

This is **only the induced 50-node graph / 25-node quotient**. It is not the response of the full 600-cell with its other shells available for propagation.

## 7. Full 600-cell resistance network: exact coefficients

To retain all 720 nearest edges, apply quaternion inversion to the full 120-vertex graph. There are two fixed points (\(\pm1\)) and 59 two-vertex orbits, giving a 61-vertex quotient. Every quotient edge represents **two** original edges, so division by the common multiplicity 2 yields exactly 360 unit-conductance quotient edges. The ten projective \(C_6\) axes form the boundary nodes; the remaining 51 vertices are free to conduct.

The exact Dirichlet-to-Neumann Schur complement is

\[
\boxed{L^{\rm full}_{10}=\frac{2520}{181}P_4+\frac{25200}{2551}P_5.}
\]

The corresponding full-network effective resistances are

\[
\boxed{R_{\rm adjacent}=\frac{2057}{12600},\qquad
R_{\rm nonadjacent}=\frac{32}{175}.}
\]

An exact \(\mathbb Q\)-arithmetic inverse of the 51-node interior block certifies this; the results are not floating-point fits. The full-vs-truncated differences show why the external shells cannot be silently discarded when proposing a physical kernel.

### Axis-to-channel resistances in the *full* 61-node quotient

For the ten \(C_6\) axis boundary orbits and the fifteen projective order-four axis orbits, the full-network resistance classes are:

| Relation of C6 axis \(v\) to Petersen edge/channel \(e\) | Pairs | Resistance |
|:--|--:|:--|
| \(v\) is one endpoint of \(e\) | 30 | \(25087/151200\) |
| \(v\) is adjacent to one endpoint of \(e\) | 60 | \(28279/151200\) |
| \(v\) is crossed with \(e\), orbit A | 30 | \(28867/151200\) |
| \(v\) is crossed with \(e\), orbit B | 30 | \(29203/151200\) |

The crossed case occurs when \(e=(ij\mid kl)\) and \(v\) takes one index from each of \(ij\) and \(kl\). Its four possible \(v\) labels split into two \(A_5\)-orbits (two crossed matchings), each occurring twice for each \(e\). Their **exact** resistance difference is

\[
\boxed{\Delta R=\frac1{450}.}
\]

The two crossed orbits are exchanged by odd permutations of the five abstract core labels; an odd permutation does not act as a symmetry of the marked icosahedral \(A_5\) realization. This is a finite geometric A5-orbit distinction; it has **not** yet been identified with physical chirality, CP, mirror conversion, or a decay-rate asymmetry.

## 8. Radial/angular 600-cell shell routing

With the identity selected as reference, the real-part conjugacy-angle shell counts are

| Angle \(\theta=\arccos\operatorname{Re}(q)\) | Count | Quaternion order class |
|:--|--:|:--|
| \(0^\circ\) | 1 | Identity |
| \(36^\circ\) | 12 | Order 10 |
| \(60^\circ\) | 20 | Order 6 |
| \(72^\circ\) | 12 | Order 5 |
| \(90^\circ\) | 30 | Order 4 |
| \(108^\circ\) | 12 | Order 10 |
| \(120^\circ\) | 20 | Order 3 |
| \(144^\circ\) | 12 | Order 5 |
| \(180^\circ\) | 1 | Central \(-1\) |

For a vertex of order six (\(\theta=60^\circ\)), its 12 immediate neighbors split **exactly** into four triples: three at \(36^\circ\), three at \(60^\circ\), three at \(72^\circ\), and three at \(90^\circ\). This identifies a genuine angular routing structure *before* any mass/energy assignment. Graph angle, physical energy, and protected Clifford hierarchy labels must remain distinct until connected by an authorized operator theorem.

## 9. Physical connection and missing theorem

The existing framework has the two anchored active configurations

\[
(A^{\rm even},2T)\mapsto E_{32},\qquad
[C_6\curvearrowright E_3]\mapsto E_{40}
\]

and its same-owner off-diagonal midpoint

\[
\mathscr E_H(S_u(v))=E_{36}S_u(v),\qquad E_{36}=\sqrt{E_{32}E_{40}}.
\]

The new graph theorem furnishes a **candidate geometric support/routing selector** for these off-diagonal transitions, including the three non-parent-core nearest-neighbor channels and the full-lattice conductance response. It does **not** identify those channels with individual elementary particles, nor promote resistance to a decay amplitude.

A physical theorem would still need to demonstrate, on the same action-owned carrier: (i) how the 10 axis fibers and 15 quaternion channels embed without double counting the overlapping 2T subgroups; (ii) which hermitian/source operator inherits the graph support and its normalized conductances; (iii) conservation of charge/color/angular momentum and possible parity/CP phases; (iv) how measured/derived mass differences enter the on-shell phase space; and (v) source-to-pole residues and branching widths. A static resistance is a DC geometry invariant; quantum widths require an on-shell matrix element and phase-space measure. In particular, the exact \(1/450\) split is **not** yet a physical branching-ratio prediction.

**Suggested next mathematical test:** construct an equivariant, source-owned lift of the 10-to-15 incidence \(B\), with fibers typed by the existing \(Q_4,Q_5,S_u\) operators, and verify that its full 600-cell resolvent reproduces the exact four-class static response without introducing independently fitted channel weights. The observable to pursue is the resulting relative spectral residue/transition strength, not the reproduction of a preferred standard decay mechanism.

## 10. Verification and established background

Run:

```bash
python Paper00-Petersen600CellIncidence-v1_4.py
```

The certificate uses exact \(\mathbb Q(\sqrt5)\) coordinate arithmetic for 600-cell adjacency and quaternion multiplication, and rational Gaussian elimination for both resistor networks. It checks all 120 vertices, 720 edges, 147600 oriented five-cycle candidates for the no-Petersen-subgraph claim; the D20/icosidodecahedral/total-graph identifications; 20 tetrahedral cliques; five Q8 groups and their size-24 normalizers; the signed cover; 9 angular shell routing; and both truncated and full resistance results.

Related **established** mathematical observations (not claimed as discoveries of this note):

- Dodecahedral graph antipodal quotient is Petersen: D. A. Waller, *Double covers of graphs* (2009), https://www.cambridge.org/core/journals/bulletin-of-the-australian-mathematical-society/article/double-covers-of-graphs/4C6C74E71345E1C2C1048853BF638F4D
- Icosidodecahedral graph is the line graph of the dodecahedron: Wolfram MathWorld, https://mathworld.wolfram.com/IcosidodecahedralGraph.html
- Unit-quaternion 600-cell and pure imaginary icosian polytope background: J. Baez, *Icosidodecahedron from D6*, https://blogs.ams.org/visualinsight/2015/01/01/icosidodecahedron-from-projected-d6-root-polytope/

**Scope firewall:** These are group/graph/circuit results conditional on the selected \(2I\) realization. They do not prove a unique realized particle mass, observable hadronic decay amplitude, or extra Clifford hierarchy level. They do not identify the 15 Petersen edges with the independent 15-dimensional level-one momentum carrier merely by dimension agreement.


---

# Version 1.2 extension — complete Q8-angle classification, full boundary transfer and a Clifford tensor source

The following theorems are **new calculations relative to v1.1**. They extend—not supersede—the source-typed Petersen, Hodge, Galois and `E_{36}` theorems in Papers I-A, III-C and V-B. They use the same 600-cell coordinates and five-core marking as the previous sections.

## 11. The four axis-to-channel relations are four exact angular orbits

Let \(u\) be one of the ten unoriented projective \(C_6\) axes, and let \(e\) be one of the fifteen unoriented Petersen edges represented by its midpoint order-four axis \(m_e\). There are \(150\) ordered axis–channel incidences. Write \(\varphi=(1+\sqrt5)/2\) and let the 600-cell quotient graph be the **61-orbit graph under quaternion inversion** (not quotient by the central sign).

| Relation | Number over all ten axes | Per axis | \(|u\cdot m_e|\) | Quotient distance |
|---|---:|---:|---:|---:|
| Incident to \(e\) | 30 | 3 | \(\varphi/\sqrt3\) | 1 |
| Near (adjacent to an endpoint) | 60 | 6 | \(1/\sqrt3\) | 2 |
| Cross B | 30 | 3 | \((\varphi-1)/\sqrt3\) | 2 |
| Cross A | 30 | 3 | \(0\) | 3 |

The classes are \(A_5\)-stable: the squared quaternionic inner product selects them without choosing axis representatives or channel signs. The cross classes are **inequivalent geometric angular orbits**. Their difference is **not** by itself a physical parity or CP asymmetry.

### Exact shortest-walk expansion

Let \(A_{61}\) be the unit-weight adjacency of the complete 61-node quotient. For any axis \(u\) and midpoint channel \(m_e\) in a specified row class, the walk coefficients \((A_{61}^n)_{u,m_e}\) are:

| Relation | \(n=1\) | \(n=2\) | \(n=3\) |
|---|---:|---:|---:|
| Incident | 1 | 5 | 53 |
| Near | 0 | 3 | 27 |
| Cross B | 0 | 1 | 21 |
| Cross A | 0 | 0 | 16 |

For \(|t|<1/12\), the combinatorial resolvent \((I-tA_{61})^{-1}\) has the convergent expansion \(\sum_{n\ge0}t^n A_{61}^n\). Thus Cross B first appears at \(t^2\), Cross A at \(t^3\). This is a **graph-locality** hierarchy. \(t\) is *not* identified with a physical propagator coefficient or scattering time.

## 12. Full-network 25-terminal Kron transfer theorem

Start with **all** 120 unit-quaternion 600-cell vertices and 720 nearest edges. Identify inversion-orbits, giving 61 quotient vertices and 360 unit-conductance links after division by the uniform lift multiplicity two. Keep as terminals the ten \(C_6\) axes and the fifteen order-four midpoint axes. Eliminate the other 36 vertices by the Dirichlet-to-Neumann Schur complement:

\[
L_{25}=L_{BB}-L_{BI}L_{II}^{-1}L_{IB},
\qquad B=10_{C_6}\sqcup15_{C_4},\quad |I|=36.
\]

Define the nonnegative **unoriented scalar** axis-to-midpoint coupling block \(C=-L_{25}[C_6,C_4]\in\mathbb R^{10\times15}\). The entries take exactly four values:

\[
\boxed{
\begin{array}{c|c|c}
\text{class}&\text{multiplicity}&C_{u,e}\\ \hline
\text{incident}&30&352396/289425\\
\text{near}&60&133/1135\\
\text{cross B}&30&33688/289425\\
\text{cross A}&30&5086/289425
\end{array}}
\]

All weights are positive because paths through eliminated vertices mediate nonlocal conductance. The exact \(10\times10\) Gram has the already-owned Petersen vertex projectors \(P_0=J/10\), \(P_4\), \(P_5\):

\[
\boxed{CC^{\mathsf T}=
\frac{777600}{51529}P_0+P_4+\frac{961776}{180625}P_5.}
\]

Hence \(\operatorname{rank}(C)=10\) and \(\dim\ker C=5\). This is a response theorem for the **unoriented permutation module of the fifteen midpoint channels**, not a theorem about the distinct **oriented flux cochain representation**. The two modules must not be silently identified.

Eliminating the fifteen midpoint terminals as well reproduces Section 7:

\[
L_{10}^{\mathrm{full}}=\frac{2520}{181}P_4+\frac{25200}{2551}P_5.
\]

Equivalently the complete-graph reduced conductances on the ten axes are

\[
g_{\rm Petersen-adj}=\frac{954072}{461731},\qquad
 g_{\rm Petersen-nonadj}=\frac{331632}{461731},\qquad
\frac{g_{\rm adj}}{g_{\rm nonadj}}=\frac{1893}{658}.
\]

These are **static** electrical response coefficients under unit-graph-conductance normalization; no quantum source strength or decay width follows by squaring them without an action-owned amplitude theorem.

## 13. Exact complete quaternionic frame overlap theorem

For a dodecahedral edge with imaginary endpoint parts \(w,z\), set the unit \(Q_8\) frame

\[
m_e=(w+z)/\varphi,\qquad d_e=\varphi(w-z),\qquad k_e=2w\times z.
\]

Let \(u\) be any of the ten normalized axis directions and define

\[
a=\frac12+\frac{\sqrt5}{6}=\frac{\varphi^2}{3},
\qquad b=\frac12-\frac{\sqrt5}{6}=\frac{\varphi^{-2}}3,
\qquad \frac ab=\varphi^4.
\]

Then the **complete list** of squared frame overlaps is

\[
\boxed{
\begin{array}{c|ccc|c}
\text{class}&(u\cdot m_e)^2&(u\cdot d_e)^2&(u\cdot k_e)^2&\#(u,e)\\ \hline
\text{incident}&a&b&0&30\\
\text{near}&1/3&1/3&1/3&60\\
\text{cross B}&b&0&a&30\\
\text{cross A}&0&a&b&30
\end{array}}
\]

The three anisotropic cases are **cyclic permutations of \((a,b,0)\)**, and the near case is exactly isotropic in the orthonormal quaternionic triad. The squared overlaps sum to one in every row. The ratio of nonzero directional **intensities** in the anisotropic cases is \(\varphi^4\), and the ratio of their absolute **amplitudes** is \(\varphi^2\), if a source coupling is defined by the corresponding scalar products. No physical source has yet been shown to use that coupling.

The flux vector \(k_e\) is transverse to the incident axis, whereas \(m_e\) is predominantly axial. Conversely for the two crossed classes the dominant axis alignment cycles from \(k\) to \(d\). This is an exact explanation of the directional distinction: it is rooted in the internal \(Q_8\) frame, not in a conjectural replacement of 600-cell edges by Petersen edges.

## 14. Full-rank, equivariant quadrupole–quaternion tensor source

Let \(V_3=\operatorname{Im}\mathbb H\), and let \(V_5=\operatorname{Sym}^2_0(V_3)\) with trace inner product. For the ten axes define \(Q_v=u_vu_v^{\mathsf T}-I_3/3\), as in Paper I-A. For each **oriented** Petersen edge \(e=(v,w)\), define

\[
\boxed{\Phi(e)=(Q_v+Q_w)\otimes k_e\in V_5\otimes V_3.}
\]

This is well-defined under independent sign choices for projective axis lifts: \(Q_v\) does not change, and the signed edge flux \(k_e\) is invariant under the endpoint gauge choices. Reversing edge orientation changes \(k_e\to-k_e\), as required for an oriented cochain. Under \(A_5\), tensors transform by the standard quadrupole \(V_5\) and quaternion-imaginary \(V_3\) actions. Thus \(\Phi\) is a concrete \(A_5\)-equivariant linear map.

**Theorem (full tensor spectral decomposition).** In the Euclidean trace-times-dot metric on \(V_5\otimes V_3\), its Gram operator is

\[
\boxed{
\Gamma=\Phi^\dagger\Phi
=\frac29\Pi_4+\frac{20}{9}\Pi_5+\frac43\Pi_3+\frac{32}{9}\Pi_{3'}.
}
\]

The ranks of the four orthogonal projectors are respectively \((4,5,3,3)\), and all eigenvalues are strictly positive. Consequently \(\Phi\) is invertible between the fifteen-dimensional real oriented-edge space and the fifteen-dimensional tensor space:

\[
\mathbb R^{15}_{\mathrm{oriented\ edges}}\xrightarrow[\cong]{\,\Phi\,}V_5\otimes V_3.
\]

In representation language this realizes the identity

\[
\mathbf5\otimes\mathbf3\cong\mathbf4\oplus\mathbf5\oplus\mathbf3\oplus\mathbf3'.
\]

**Exact proof/certificate.** By Paper I-A, \(\langle Q_v,Q_w\rangle\) equals \(2/3\) on the diagonal, \(2/9\) on adjacent Petersen axes and \(-2/9\) on nonadjacent distinct axes. Thus

\[
\Gamma_{ef}=\left(\sum_{x\in\partial e}\sum_{y\in\partial f}
 \langle Q_x,Q_y\rangle\right)(k_e\cdot k_f).
\]

The executable verification constructs all 225 entries using exact \(\mathbb Q(\sqrt5)\) arithmetic and checks equality with the four projector expression. It separately proves that \(\Phi\) has nonzero determinant under both ring reductions modulo 41, \(\sqrt5\mapsto+13,-13\), giving determinant residues \(23\) and \(18\). (The residue calculation uses a fixed, explicit rational coordinate basis of \(V_5\otimes V_3\) and is an additional nondegeneracy certificate, not the normalization of the Gram spectrum.)

Unlike scalar incidence \(\partial^{\mathsf T}\), which annihilates the \(\mathbf3\oplus\mathbf3'\) flux sector, \(\Phi\) supplies a **nondegenerate tensor realization of all four sectors**. This does not claim that the existing physical Hessian or the Paper III-C tangent source has automatically adopted \(\Phi\) as its transition vertex.

## 15. Mirror-odd inter-core interference and local-core blindness

Write \(\Gamma^\sigma\) for the Galois-conjugate Gram under the fixed \(\sqrt5\to-\sqrt5\) representation. The exact decomposition is

\[
\Gamma-\Gamma^\sigma=\frac{20}{9}(\Pi_{3'}-\Pi_3).
\]

The fifteen edges partition into five labeled triples, one for each normalizer \(Q_8\lhd2T\). Within any such triple \(i\), the Gram compression is

\[
P_i\Gamma P_i=\frac{16}{9}P_i,
\qquad P_i(\Pi_{3'}-\Pi_3)P_i=0.
\]

Thus each local core supports an orthogonal triple of tensor columns of squared norm \(16/9\), and no *single-core quadratic measurement* can distinguish \(\mathbf3\) from \(\mathbf3'\), consistent with Paper V-B's exact local-mirror no-go.

Across the \(90\) edge pairs from **different** cores, the matrix entries of \(\Pi_{3'}-\Pi_3\) are exactly

\[
\begin{array}{c|ccc}
\text{value}&-\sqrt5/10&0&+\sqrt5/10\\\hline
\text{number of cross-core pairs}&30&30&30.
\end{array}
\]

For a pair \(e,f\) realizing the positive cross-core entry and the normalized coherent combinations \(\psi_\pm=(e\pm f)/\sqrt2\),

\[
\langle\psi_\pm,(\Pi_{3'}-\Pi_3)\psi_\pm\rangle
=\pm\frac{\sqrt5}{10},
\qquad
\langle\psi_\pm,(\Gamma-\Gamma^\sigma)\psi_\pm\rangle
=\pm\frac{2\sqrt5}{9}.
\]

These are **finite geometric interference observables**, not physical CP asymmetries. The required source must prepare or couple coherently to distinct core edges; local incoherent source intensities erase this signed contrast.

## 16. Source-owned tangent trine and a conditional observable sum rule

At each selected axis \(u\), its three oriented incident flux vectors \(k_1,k_2,k_3\in V_u=u^\perp\) form a real \(A_2\) tight frame:

\[
\sum_jk_j=0,\quad k_i\cdot k_j=-\frac12\ (i\neq j),
\qquad \sum_jk_jk_j^{\mathsf T}=\frac32 I_{V_u}.
\]

For a nonzero **real** tangent source \(t\in V_u\), define an explicitly specified **candidate linear channel readout**

\[
a_j=k_j\cdot t,
\quad p_j=\frac{a_j^2}{\sum_i a_i^2}.
\]

The readout is a trine frame measurement, \(p_j=\frac23\cos^2(\theta-2\pi j/3)\), where \(\theta\) is the (not yet action-selected) tangent orientation. It necessarily obeys

\[
\boxed{\sum_jp_j=1,\qquad \sum_jp_j^2=\frac12,\qquad 0\le p_j\le\frac23.}
\]

**Proof:** the tight frame implies \(\sum_ja_j=0\) and \(\sum_j a_j^2=3\|t\|^2/2\). For any three real numbers with zero sum, \(\sum_j a_j^4=\tfrac12(\sum_j a_j^2)^2\). Division by \((\sum a_j^2)^2\) gives the second identity. The endpoint bound follows from the tight-frame normalization. A source aligned with \(k_1\) gives \((2/3,1/6,1/6)\); one perpendicular to \(k_1\) gives \((0,1/2,1/2)\). For a mixed real tangent source, the attainable probabilities lie in the convex disk, yielding \(1/3\le\sum p_j^2\le1/2\).

**Status:** These become physical branching-ratio constraints only after an action theorem identifies the detected triple with the three outgoing \(Q_8\) channels, selects the real linear tangent readout and establishes compatible normalization/phase-space corrections. In particular, allowing long-range 600-cell transfer, complex phases, or unequal final-state kinematics changes the observable formula. Paper III-C's already-owned \(S_u\) source and \(E_{36}\) response may provide the needed tangent amplitude scale, but do **not** by themselves select the above channel readout or the orientation \(t\).

## 17. Type firewall and prioritized physical proof obligations

1. **Scalar-unoriented versus Clifford-oriented.** The \(10\times15\) Kron block \(C\) acts on midpoint-axis projective **unoriented** labels. The \(15\)-cochain flux and tensor map \(\Phi\) use an **oriented** module with \(\mathbf4\oplus\mathbf5\oplus\mathbf3\oplus\mathbf3'\). A product such as \(\Phi C^{\mathsf T}\) requires an explicitly constructed equivariant typed identification; it is not licensed merely by equality of dimensions.
2. **No automatic action coupling.** \(\Phi\), the local trine map, electrical conductance, and walk resolvents are mathematically distinct choices. The realized action must determine its Hessian, source-to-edge map, phase/sign data and physical normalization. Group covariance alone does not select them.
3. **Protected scale placement.** Existing Paper III-C owns \(E_{32}\), \(E_{40}\), and the same-owner off-diagonal \(E_{36}=\sqrt{E_{32}E_{40}}\). The new bridge fixes geometric support and comparison norms, not a new level \(E_{36}\) particle. An undirected graph does not supply a decay arrow; on-shell masses, charges, phase space and the actual interaction operator must select energetically permitted transitions.
4. **First nontrivial target observable.** A measured, kinematically corrected three-mode branching triple would test the local trine sum rule **if** its physical channel labels can be established. A two-core coherent interference observable could instead test the \(\mathbf3/\mathbf3'\) Galois contrast. The two are distinct; the second cannot be extracted from the first by fitting a scalar resistance.

**Audit status:** All displayed v1.2 finite-geometry, tensor-Gram, local-frame, combinatorial-walk and rational-Schur identities are executable exact certificates in the accompanying v1.4 script. They are **conditional finite mathematical results** for the selected \(2I\) realization. The source-owned physical decay theorem and any comparison to measured particle widths remain open.


---

# Version 1.3 extension — canonical contraction into the existing protected off-diagonal Clifford source

## 18. Natural contraction theorem: the new tensor reconstructs the old flux operator

Recall the \(A_5\)-equivariant tensor isomorphism \(\Phi(e)=(Q_v+Q_w)\otimes k_e\) from Section 14, with \(Q_v=u_vu_v^{\mathsf T}-I_3/3\). Consider the \(SO(3)\)-natural contraction

\[
c:\operatorname{Sym}^2_0(V_3)\otimes V_3\longrightarrow V_3,
\qquad c(Q\otimes k)=Qk.
\]

The \(SO(3)\) tensor decomposition is \((\ell=2)\otimes(\ell=1)=(\ell=1)\oplus(\ell=2)\oplus(\ell=3)\) with dimensions \(3+5+7=15\). The \(\ell=1\) receiver appears once, so its equivariant contraction is unique up to a scalar; the ordinary tensor contraction fixes that scalar convention.

**Exact theorem.** For an edge \(e=(v,w)\), the normalized quaternionic cross-product flux \(k_e\) is perpendicular to \(u_v,u_w\). Consequently

\[
Q_vk_e=-\frac13k_e,\quad Q_wk_e=-\frac13k_e
\quad\Longrightarrow\quad
\boxed{c\circ\Phi=-\frac23K.}
\]

Here \(K:\mathbb R^{15}_{\rm oriented}\to V_3\) is the existing exact icosahedral flux map of Paper I-A. This identity is independently certified on all fifteen edges by exact \(\mathbb Q(\sqrt5)\) arithmetic. It removes the need to *postulate* a new edge-to-imaginary-quaternion contraction: the canonical contraction of the new tensor map gives exactly the old action-compatible geometry.

The representation-theoretic qualifier is essential:

\[
K\Pi_3=K,\qquad K\Pi_{3'}=K\Pi_4=K\Pi_5=0.
\]

The new tensor \(\Phi\) is nondegenerate on the entire \(15\)-dimensional edge domain, but its **ordinary \(SO(3)\)-natural contraction** accesses only the ordinary \(\mathbf3\) flux summand. To read out \(\mathbf3'\) requires an additional Galois or marked-core mirror operator (such as the already constructed \(J_i\) in Paper I-A). Full tensor invertibility does **not** automatically produce an ordinary physical mirror coupling.

## 19. Exact typed comparison with the Paper III-C \(E_{36}\) transition

On the existing Paper III-C carrier, the available normalized real-tangent source is

\[
S_u:V_u=u^\perp\to\operatorname{End}_{\mathbb R}\Cl(0,3),
\quad\tau_8(S_u(v)^\dagger S_u(w))=\frac14\langle v,w\rangle.
\]

The owned positive balanced response acts by \(\mathscr E_H(S_u(v))=E_{36}S_u(v)\) with \(E_{36}=\sqrt{E_{32}E_{40}}\). Let \(P_u=I_3-uu^{\mathsf T}\). The composite

\[
\boxed{\mathcal J_u:=\mathscr E_H\circ S_u\circ P_u\circ c\circ\Phi
=-\frac23E_{36}S_u\circ P_u\circ K}
\]

is **mathematically typed** and has no adjustable geometric coefficient. It maps an oriented Petersen edge source into the already-existing off-diagonal Clifford operator envelope. The assertion is a **comparison operator**, not yet the theorem that this is a vertex of the action-owned physical matter interaction.

Its exactly normalized source-metric Gram and diagonal are

\[
\boxed{
\langle\mathcal J_u(e),\mathcal J_u(f)\rangle_{\tau_8}
=\frac{E_{36}^2}{9}\,k_e^{\mathsf T}P_u k_f,
\qquad
\|\mathcal J_u(e)\|^2_{\tau_8}
=\frac{E_{36}^2}{9}\left[1-(u\cdot k_e)^2\right].}
\]

The composite has rank two for each axis because \(K\) has rank three, \(P_u\) has rank two and the source metric is nondegenerate on \(V_u\). By Paper I-A's tight-frame identity \(KK^{\mathsf T}=5I_3\), its total fifteen-channel Hilbert–Schmidt/source-metric squared norm is

\[
\boxed{
\sum_{e=1}^{15}\|\mathcal J_u(e)\|^2_{\tau_8}
=\frac{E_{36}^2}{9}\operatorname{tr}(P_uKK^{\mathsf T})
=\frac{10}{9}E_{36}^2.}
\]

This holds for **every** \(C_6\) axis \(u\); it is a genuine normalized all-channel source-comparison invariant.

### Four exact contributions to the invariant

Insert Section 13's full \(Q_8\) overlap table into the displayed diagonal norm. Since \(1-(u\cdot k_e)^2\) is the tangent norm squared, the complete sum decomposes as

\[
\boxed{
\frac{9}{E_{36}^2}
\left(\sum_{e\in\text{class}}\|\mathcal J_u(e)\|^2_{\tau_8}\right)
=\begin{cases}
3,&\text{3 incident edges},\\
4,&\text{6 near edges},\\
\varphi^{-2},&\text{3 Cross-B edges},\\
\varphi^{2},&\text{3 Cross-A edges}.
\end{cases}}
\]

Indeed \(\varphi^2+\varphi^{-2}=3\), so the four terms sum to \(10\). Normalized purely as **geometric source-strength shares** (not physical branching fractions), the four shares are

\[
\boxed{
(3/10,\ 4/10,\ \varphi^{-2}/10,\ \varphi^2/10)
\approx(0.3000,0.4000,0.0382,0.2618).}
\]

This decomposition makes the two mechanisms mathematically separable. The Cross-A channels have substantial **transverse Clifford source strength** but the smallest full-network **scalar conductance** and greater graph distance; the Cross-B channels display the opposite tradeoff. No physical rule yet justifies multiplying those static responses to obtain an on-shell amplitude.

### The existing orbital derivative gives a second, fixed scale normalization

Paper III-C also owns, on the same real-tangent block,

\[
[J_v,H_{\mathrm{car}}]=(E_{32}-E_{40})S_u(v)
=\bigl(\alpha_{\mathrm{hier}}^{1/8}-\alpha_{\mathrm{hier}}^{-1/8}\bigr)
\mathscr E_H(S_u(v)).
\]

Replacing the balanced comparison by this *existing* orbit derivative leaves **all geometric channel ratios unchanged** and multiplies every channel amplitude by the common signed factor

\[
\frac{E_{32}-E_{40}}{E_{36}}
=\alpha_{\mathrm{hier}}^{1/8}-\alpha_{\mathrm{hier}}^{-1/8}.
\]

This distinction supplies an exact normalization bridge between the balanced operator and its orbit derivative. It does not make the graph directed or identify \(E_{32}\), \(E_{40}\) with particular unstable-particle pole masses.

## 20. Final status after v1.3

- **Closed in finite geometry:** the 600-cell-induced dodecahedral/Petersen quotient; full 25-terminal and 10-terminal static network responses; all 150 midpoint-angle and \(Q_8\)-triad overlap classes; the fifteen-dimensional equivariant tensor isomorphism; its four exact Gram eigenvalues and mirror-odd inter-core interference; the uniquely normalized contraction \(c\Phi=-2K/3\); and the complete \(E_{36}\)-scaled comparison-source norm \(10E_{36}^2/9\).
- **Explicitly conditional:** the three-channel trine intensity law is a consequence of a specified real linear tangent readout, not an established identity for experimentally measured branching fractions. The \(\mathbf3'\) mirror ratio requires a separately typed mirror source/receiver.
- **Not closed:** the realized interaction action's actual vertex and Hessian/pole residues, physical particle/channel identification, final-state charge/spin/color conservation constraints, open channels and phase-space factors. The mathematical \(\mathcal J_u\) is a strong candidate with correct carrier typing, but an action theorem must show whether it is *the* interaction readout rather than a possible equivariant composite.

**Reproduction:** execute `python Paper00-Petersen600CellIncidence-v1_4.py`. All v1.3 extensions are checked in pure Python using rational and quadratic-number arithmetic; no fits or floating-point input are used in the certificates.

# Version 1.4 extension — alternating full-600-cell transfer, cover Hodge decomposition and signed Clifford response

**Research extension, 2026-11-12.** Predecessor `Paper00-Petersen600CellBridge-v1_3.md`; independent exact verification extends `Paper00-Petersen600CellIncidence-v1_5.py`. The current source corpus consulted is `Paper00-PapersMinimal-v2_370.zip`, especially Paper I-A v5.167, Paper III-C v1.179, Paper III-F v1.256, Paper V-C v2.170 and Paper VII-A v1.165. These are finite-graph and operator-comparison deductions; the physical interaction action is **not** modified or claimed to have selected these couplings.

## 21. The complete 600-cell transfer has one alternating five-core contribution

Work with the 61-node inversion quotient of the full 600-cell using one unit conductance per quotient edge and all 360 edges, the normalization fixed in Section 7. Retain ten order-six projective axes and fifteen pure-imaginary order-four channel axes as terminals. Integrate out the remaining 36 nodes by the exact Laplacian Schur complement as in Section 12. Let

- \(B\in\mathbb R^{10\times15}\) be the **unsigned** incidence matrix of the Petersen graph (columns have two entries 1); \(B B^{\mathsf T}=A+3I=6P_0+P_4+4P_5\), where \(P_0=\mathsf J_{10}/10\).
- \(C\in\mathbb Q^{10\times15}\) be the positive axis-to-channel off-diagonal response of the full 25-terminal Dirichlet-to-Neumann matrix; its entry is the negated axis-to-channel Laplacian entry.
- \(D\in\mathbb R^{10\times15}\) be the **crossing-sign matrix** defined by \(D_{ue}=0\) for incident and near configurations, \(+\tfrac12\) for crossed B, and \(-\tfrac12\) for crossed A. Here the labels are the exact quaternionic-angle classes of Section 13, and choosing the opposite convention sends \(D\mapsto-D\).

**New exact decomposition theorem.** All 150 entries of the full-600-cell response satisfy

\[
\boxed{\displaystyle
 C=\left(\frac{360}{227}P_0+P_4+\frac{489}{425}P_5\right)B
       +\frac{42}{425}D.}
\tag{21.1}
\]

Furthermore,

\[
\boxed{D B^{\mathsf T}=0,\qquad D D^{\mathsf T}=3P_5.}
\tag{21.2}
\]

*Proof.* The four exact full-network entries previously verified in Section 12 are \(c_{\rm inc}=352396/289425\), \(c_{\rm near}=133/1135\), \(c_{\rm crossB}=33688/289425\) and \(c_{\rm crossA}=5086/289425\). Their crossing difference is \(42/425\). The displayed RHS of (21.1) is checked identically for every \((u,e)\). Independently, multiplication of the explicit 0, \(\pm\tfrac12\) matrix gives \(DB^{\mathsf T}=0\) and \(DD^{\mathsf T}=3P_5\). The latter are fully exact rational identities, not numerical fits. \(\square\)

The full abstract Petersen graph has automorphism group \(S_5\). Reconstruct its five core labels intrinsically as the five maximal independent four-sets of its ten vertices, then induce the permutation on its fifteen edges. Exhaustive verification for all \(120\) permutations gives

\[
\boxed{D_{\pi u,\pi e}=\operatorname{sgn}(\pi)D_{ue},\quad\pi\in S_5.}
\tag{21.3}
\]

Hence \(D\) is the *alternating five-core transfer tensor*, preserved by the actual \(A_5\) action and reversed by odd abstract core relabelings. The full embedded geometry distinguishes the two crossed configurations, whereas \(T(P_{10})\) does not. This is a geometric handedness relative to the chosen \(2I\) embedding; **it is not a theorem of parity, CP, or time-reversal breaking in the physical action**.

## 22. An exact five-dimensional incidence-dark response and tilt angle

Since the Petersen graph is nonbipartite, \(B\) has rank ten and its nullspace \(\mathcal N_B=\ker B\subset\mathbb R^{15}\) has dimension five. Let its orthogonal projector be

\[
P_{\mathcal N_B}=I_{15}-B^{\mathsf T}(BB^{\mathsf T})^{-1}B.
\]

The rank-five identity (21.2) strengthens to

\[
\boxed{D^{\mathsf T}D=3P_{\mathcal N_B}.}
\tag{22.1}
\]

Consequently, for every \(x\in\mathcal N_B\),

\[
 Bx=0,\qquad Cx=\frac{42}{425}Dx,\qquad
 \boxed{\|Cx\|^2=\frac{5292}{180625}\|x\|^2.}
\tag{22.2}
\]

**Interpretation:** the full 600-cell, unlike bare Petersen incidence, gives an injective, isotropically scaled transfer of *all five* incidence-dark channel combinations into the \(P_5\) quadrupole axis space. "Dark" is relative to the unsigned incidence map \(B\), **not** darkness under every physical source or under \(C\).

More precisely, define two orthogonal coisometries with target \(P_5\mathbb R^{10}\):

\[
U_B=\frac12P_5B,\qquad U_D=\frac1{\sqrt3}D,
\qquad U_B U_B^{\mathsf T}=U_D U_D^{\mathsf T}=P_5,
\quad U_B U_D^{\mathsf T}=0.
\]

Then the five-dimensional response has the *fixed* two-component decomposition

\[
\boxed{
P_5C=\frac{978}{425}U_B+\frac{42\sqrt3}{425}U_D.}
\tag{22.3}
\]

The two coefficients give

\[
\boxed{\tan\theta_{\rm geom}=\frac{7\sqrt3}{163},\quad
\sin^2\theta_{\rm geom}=\frac{147}{26716},\quad
\cos^2\theta_{\rm geom}=\frac{26569}{26716}.}
\tag{22.4}
\]

Thus \(\theta_{\rm geom}\approx 4.253972319^\circ\). Let \(P_{\ker C}\) be the orthogonal projector onto the five-dimensional kernel of \(C\). The five principal angles between \(\ker C\) and \(\ker B\) are identical:

\[
\boxed{P_{\mathcal N_B}P_{\ker C}P_{\mathcal N_B}
=\frac{26569}{26716}P_{\mathcal N_B}.}
\tag{22.5}
\]

For independent cross-check, \(CB^{\mathsf T}=\tfrac{2160}{227}P_0+P_4+\tfrac{1956}{425}P_5\) and

\[
CC^{\mathsf T}=\frac{777600}{51529}P_0+P_4+
\frac{961776}{180625}P_5,
\]

as in Section 12. The \(P_5\) coefficient splits as \(961776=956484+5292=978^2+3(42)^2\). All comparisons concern a **specified unit-edge harmonic network**, not a physical mass mixing angle or rate prediction.

## 23. The full dodecahedral cover has six ordinary cycles plus five twisted cycles

The induced \(D_{20}\) has twenty vertices and thirty edges, and is connected, so \(\beta_1=30-20+1=11\). Quaternion inversion \(\iota:q\mapsto q^{-1}\) acts freely on these vertices and edges, commutes with the induced \(A_5\) conjugation, and decomposes the oriented chain complex into two parity sectors:

| Parity of dodecahedral chain | \(\dim C_0\) | \(\dim C_1\) | \(\operatorname{rank}\partial\) | \(\dim\ker\partial\) |
|---|---:|---:|---:|---:|
| \(\iota=+1\) | 10 | 15 | 9 | 6 |
| \(\iota=-1\) | 10 | 15 | 10 | 5 |

The even chain is the ordinary oriented Petersen chain; its kernel is the two flux triplets of Paper I-A. The odd chain is a *twisted* oriented-edge chain with no zero-dimensional homogeneous vertex mode; its kernel is the additional irreducible five-dimensional cycle representation. Therefore

\[
\boxed{H_1(D_{20};\mathbb R)
  = (\mathbf3\oplus\mathbf3')_{+}\oplus\mathbf5_{-}.}
\tag{23.1}
\]

**Independent character test.** For the conjugation action of \(A_5\cong 2I/\{\pm1\}\), the character values on the identity, order-2, order-3 and the two order-5 classes are:

| Module | Identity | Order 2 | Order 3 | Order 5A | Order 5B | Irreducible content |
|---|---:|---:|---:|---:|---:|---|
| Even vertices | 10 | 2 | 1 | 0 | 0 | \(\mathbf1\oplus\mathbf4\oplus\mathbf5\) |
| Odd vertices | 10 | −2 | 1 | 0 | 0 | \(\mathbf3\oplus\mathbf4\oplus\mathbf3'\) |
| Either oriented edge parity | 15 | −1 | 0 | 0 | 0 | \(\mathbf3\oplus\mathbf3'\oplus\mathbf4\oplus\mathbf5\) |
| **Unsigned fifteen half-turn axes** | 15 | 3 | 0 | 0 | 0 | \(\mathbf1\oplus\mathbf4\oplus2\mathbf5\) |

The last row supplies a sharp **scalar-to-Clifford no-go**:

\[
\operatorname{Hom}_{A_5}
  (\mathbb R^{15}_{\rm unsigned},\mathbf3\oplus\mathbf3')=0.
\tag{23.2}
\]

Thus a *global unmarked linear* \(A_5\)-equivariant map from scalar, unoriented order-four-axis potentials alone cannot drive either Clifford flux triplet. The oriented edge/cover structure or an explicit marked source is indispensable. A fixed marked Hopf axis lowers the symmetry and can permit additional typed maps; (23.2) is not a blanket physical interaction no-go.

**Distinction of the two fives:** the twisted \(\mathbf5_-\subset H_1(D_{20})\) and the scalar \(\ker B\subset\mathbb R^{15}_{\rm unsigned}\) are *isomorphic as abstract* \(A_5\) representations, but the present computation does **not** assert an identity or a canonical intertwiner between them.

## 24. A signed 600-cell-derived propagator separates the Clifford mirrors exactly

The signed Petersen adjacency \(S\) is reconstructed from the dodecahedral double cover and obeys \(S^3=5S\). Its eigenvalues are \(\sqrt5\) (multiplicity three), \(0\) (multiplicity four), and \(-\sqrt5\) (multiplicity three). The Laplacian for antipodal-*odd* vertex potentials on the induced dodecahedron is

\[
L_-=3I_{10}-S.
\]

Unlike the even sector it is invertible, with the exact polynomial inverse

\[
\boxed{L_-^{-1}=\frac13 I_{10}+\frac14 S+\frac1{12}S^2.}
\tag{24.1}
\]

The underlying real-part/imaginary-coordinate geometry gives \(\tilde U=[w_v]\in\mathbb Q(\sqrt5)^{3\times10}\), where \(q_v=\frac12+w_v\), \(\tilde U\tilde U^{\mathsf T}=\frac52 I_3\). The normalized quaternionic flux matrix \(K\in\mathbb Q(\sqrt5)^{3\times15}\) has \(KK^{\mathsf T}=5I_3\). Their Galois partners satisfy mixed-orthogonality identities. Define the *distinguished Galois-symmetric comparison map*

\[
\boxed{\mathcal W=\frac{\sqrt2}{5}
\bigl(\tilde U^{\mathsf T}K
 +(\tilde U^\sigma)^{\mathsf T}K^\sigma\bigr):
\mathbb R^{15}_{\rm oriented}\to\mathbb R^{10}_{\rm signed}.}
\tag{24.2}
\]

Then \(\mathcal W^{\mathsf T}\mathcal W=\Pi_3+\Pi_{3'}\), and \(\mathcal W\) is an isometry on the six-dimensional flux subspace into the odd ten-axis space. Composing with the *specified* signed graph Green operator yields a fully explicit comparison response:

\[
\boxed{
\mathcal R_-:=\mathcal W^{\mathsf T}L_-^{-1}\mathcal W
=\frac{3+\sqrt5}{4}\Pi_3+
 \frac{3-\sqrt5}{4}\Pi_{3'}.}
\tag{24.3}
\]

Thus on the ordinary and mirror flux eigenspaces the ratio is exactly

\[
\boxed{\frac{r_3}{r_{3'}}=
\frac{3+\sqrt5}{3-\sqrt5}
=\frac{7+3\sqrt5}{2}\approx6.854101966.}
\tag{24.4}
\]

The mirror difference is

\[
\boxed{\mathcal R_- -\mathcal R_-^\sigma
=\frac{\sqrt5}{2}(\Pi_3-\Pi_{3'}).}
\tag{24.5}
\]

This agrees structurally with the Paper VII-A source distinction: a **single** tetrahedral core has zero compression of \(\Pi_3-\Pi_{3'}\), whereas a coherent **two-core** source can detect the difference. Combining with Paper VII-A's \(\|P_{m,n}(\Pi_3-\Pi_{3'})P_{m,n}\|=\sqrt{3/20}\), the maximal two-core mirror-difference expectation in this explicitly defined comparison is

\[
\boxed{\frac{\sqrt5}{2}\sqrt{\frac3{20}}=\frac{\sqrt3}{4}.}
\tag{24.6}
\]

**Conditions:** (24.3) is a mathematical signed-Laplacian Green-response construction. The equal-normalization choice in (24.2) is distinguished by isometry and Galois symmetry, but the physical action is *not* known to select it. \(A_5\) equivariance alone permits independent coefficients on \(\mathbf3\) and \(\mathbf3'\). Thus neither (24.4) nor (24.6) is asserted as a measured mirror or decay branching ratio.

## 25. Important refinement: the old \(E_{36}\) comparison has rank **two**, not fifteen

The previous \(\mathcal J_u=-\frac23E_{36}S_uP_uK\) remains correctly typed, with the existing Paper III-C source metric. Its Gram is

\[
G_u=\mathcal J_u^\dagger\mathcal J_u
=\frac{E_{36}^2}{9}K^{\mathsf T}P_uK.
\]

Because \(KK^{\mathsf T}=5I_3\) and \(P_u\) is a rank-two projector,

\[
\boxed{G_u^2=\frac{5E_{36}^2}{9}G_u,
\quad\operatorname{Spec}G_u
=\{(5E_{36}^2/9)^{(2)},\ 0^{(13)}\}.}
\tag{25.1}
\]

Summing over the ten projective axes, which satisfy \(\sum_u uu^{\mathsf T}=(10/3)I_3\), gives

\[
\boxed{\sum_{u=1}^{10}G_u
=\frac{100E_{36}^2}{27}\Pi_3.}
\tag{25.2}
\]

**Essential interpretive correction:** Section 19's 15 positive diagonal channel norms are **not fifteen independently active decay amplitudes**. They are diagonal entries of a rank-two Gram matrix for a fixed Hopf axis; coherent combinations cancel across a 13-dimensional kernel. Even combining all ten axes accesses only the ordinary \(\mathbf3\) flux space. The physically distinct flux modes and the possible mirror receiver require the action's own source typing, not just counting geometric labelled channels.

## 26. What is and is not now closed

**Established under the explicitly stated finite-graph models:** the full-600-cell four-orbit scalar transfer; its \(S_5\)-alternating splitting, the five-dimensional scalar incidence-dark response and exact \(4.254^\circ\) geometric tilt; the 11-dimensional dodecahedral cycle-space parity resolution \(6+5\); the full character-based obstruction to *unmarked scalar* triplet injection; the normalized signed-graph \(\mathbf3/\mathbf3'\) Green-response ratio; and the sharp rank-two character of \(\mathcal J_u\). All are independently checked in exact rational or \(\mathbb Q(\sqrt5)\) arithmetic in v1.5 of the verifier, with no fitted particle data.

**Not established:** that the physical action picks the unit-edge resistor Laplacian, the normalized map \(\mathcal W\), the crossing transfer \(C\), a particular signed-versus-unsigned port, or the finite comparison \(\mathcal J_u\) as an interaction vertex. The underlying framework explicitly distinguishes these capacities from source ownership: see Paper III-C Theorems `p3c:thm:v179-clifford-projector-tangent` and `p3c:thm:v179-balanced-hierarchy-response`, Paper III-F Corollary `p3f:cor:v319-petersen-response-owner` and Proposition `p3f:prop:v338-no-unique-two-core-mass-map`, Paper V-C Propositions `p5c:prop:v321-petersen-no-automatic-insertion` and `p5c:prop:v338-intertwiner-ambiguity`, and Paper VII-A Definition `p10:def:v323-action-incidence-test`.

The **next physical verification target** is specific: take the existing action-owned finite source/interaction, construct its actual first and second source jets on the already constituted matter, color, chirality and spin ports, and evaluate whether its restricted matrix elements contain the alternating \(D\), signed \(\mathbf3/\mathbf3'\) Green response, or \(\mathcal J_u\). If the corresponding source embedding is not reducing for the physical Hamiltonian, compute the full regulated Schur resolvent and pole residues rather than substituting eigenvalues of a geometric comparison matrix. A reversible resistor network by itself cannot select the time-oriented \(E_{40}\to E_{32}\) decay arrow, identify final states, or provide on-shell phase-space factors.

**Reproduction:** `python Paper00-Petersen600CellIncidence-v1_5.py` (standard-library only, total baseline and extension execution about seven seconds in the author's verification container). The script also replays the predecessor v1.4 checks. No current framework TeX or existing DAG ZIP was edited by this research extension.

---

# Version 1.5 extension — a complete local 600-cell–Clifford complex and its finite-source spectral readout

**New status:** exact finite-geometry and finite-carrier comparison theorems verified against framework v2.370. This extension **does not** create a physical decay vertex or promote geometric flux receivers into new physical degrees of freedom. The preceding v1.4 results remain unchanged; source/current-script filenames in preceding historical sections may refer to prior certificates.

## 27. Source integrity and the actual open question

The authoritative current framework is `Paper00-PapersMinimal-v2_370.zip`. Paper III-C, Theorems `p3c:thm:v179-clifford-projector-tangent` and `p3c:thm:v179-balanced-hierarchy-response`, establish:

\[
S_u(v)=|vu\rangle\langle u|+|u\rangle\langle vu|,
\quad \tau_8(S_u(v)^\dagger S_u(w))=\tfrac14 v\cdot w,
\]
\[
H_{\rm car}=E_0Q_0+E_{32}Q_4+E_{40}Q_5+E_{56}Q_7,
\quad \mathscr E_H(S_u(v))=E_{36}S_u(v),
\quad E_{36}=\sqrt{E_{32}E_{40}}.
\]

In this source, **\(H_{\rm car}\) is a protected carrier grading**; treating it as a physical Hamiltonian additionally consumes the same-owner energy/unit map and dynamics. The unperturbed grading has no \(Q_4\leftrightarrow Q_5\) mixing. It is therefore not legitimate to call \(E_{36}\) a finite decay width or infer spontaneous decay merely from the existence of \(S_u\).

The existing action boundary is explicit in Paper III-F `p3f:cor:v319-petersen-response-owner` and `p3f:prop:v338-no-unique-two-core-mass-map`, Paper V-C `p5c:prop:v321-petersen-no-automatic-insertion` and `p5c:prop:v338-intertwiner-ambiguity`, Paper VII-A `p10:def:v323-action-incidence-test`, and the current Paper VII-B `p11:prop:v366-hurwitz-decay-residue-gate`. A physical decay is a **directed parent-to-daughter-multiset hyperedge** with same-action Fock/current states, pole residues and kinematic support, not an undirected nearest-neighbor edge.

The new, solvable mathematical question is this: *Which local or global transition comparisons are uniquely dictated by the existing Petersen/600-cell geometry, and which observable combinations remain fixed even before the physical insertion is supplied?*

## 28. Unique local projective trimer map

Let \(u\) be a **projective (unoriented)** \(C_6\) axis. Its three nearest order-four channel axes in the 600-cell carry outgoing unit quaternionic flux vectors \(k_{u,1},k_{u,2},k_{u,3}\) satisfying

\[
\sum_{j=1}^3k_{u,j}=0,
\qquad k_{u,j}\cdot k_{u,\ell}
 =\begin{cases}1,&j=\ell,\\-\tfrac12,&j\ne\ell.\end{cases}
\tag{28.1}
\]

The stabilizer of the projective axis in \(A_5\) is \(D_3\cong S_3\), lifted to twelve unit quaternions inside \(2I\). Its action permutes the three incident channel labels, and its natural action on \(V_u=u^\perp\) is the irreducible real tangent representation. The local representation characters, in classes \(1,C_3,C_2\), are \((3,0,1)\) on the three scalar channel labels and \((2,-1,0)\) on the tangent plane. Therefore

\[
\boxed{\dim_\mathbb R\operatorname{Hom}_{D_3}(\mathbb R^3,V_u)
 =\frac{3\cdot2+2(0)(-1)+3(1)(0)}6=1.}
\tag{28.2}
\]

The explicit map \(F_u(x)=\sum_jx_j k_{u,j}\) is indeed equivariant under **all twelve lifted stabilizer elements**; the verifier checks the actual quaternion conjugations for all ten axes. Thus it spans this intertwiner space. If the ten-axis family is \(A_5\)-covariant and the action on local scalar channels is restricted to nearest incidence, transitivity of the ten axes forces the same overall coefficient at every axis. It does *not* determine that scalar coefficient or require the physical action to insert the map.

**Role-sensitive qualification:** retaining only the oriented axis stabilizer \(C_3\), rather than the full projective \(D_3\), gives
\(\dim_{\mathbb R}\operatorname{Hom}_{C_3}(\mathbb R^3,V_u)=2\). The second map is a quarter-turn of the first. Full projective covariance eliminates that extra continuous local angle. Across all fifteen unoriented order-four axes, the restricted \(C_3\) scalar module is five regular 3-orbits, giving real Hom dimension ten. These are *different* symmetry contracts, not inconsistent counts.

## 29. Global ten-axis trimer map and exact singular values

Let \(\mathcal E\) denote the fifteen **scalar/unoriented projective order-four channel labels** and let \(\mathcal V=\bigoplus_{u\in\mathcal P}V_u\) denote the ten-axis **bundle of tangent comparisons**, of total real dimension 20. This is a mathematical direct sum of source comparisons, *not ten independently occupied physical Clifford carriers*. Use the outward edge conventions \(k_{u,e}\) from the 600-cell, with \(k_{u,e}=-k_{v,e}\) at the two endpoints \(u,v\) of an edge. Define

\[
\boxed{F:\mathbb R^{15}_{\rm scalar}\longrightarrow\mathcal V,
\quad (Fx)_u=\sum_{e\ni u}x_e k_{u,e}.}
\tag{29.1}
\]

For each fixed \(u\), the local \(3\times3\) Gram has diagonal 1 and off-diagonal \(-1/2\). Two different edge columns can meet in at most one vertex of the simple Petersen graph. Thus with \(B\) the **unsigned** Petersen vertex–edge incidence matrix,

\[
\boxed{F^\dagger F=3I_{15}-\frac12 B^\mathsf TB.}
\tag{29.2}
\]

Since \(BB^\mathsf T=3I_{10}+A_\mathcal P\), the Petersen adjacency spectrum \(3^{(1)},1^{(5)},(-2)^{(4)}\), and \(\operatorname{rank}B=10\) imply

\[
\boxed{\operatorname{Spec}(F^\dagger F)
=\{0^{(1)},1^{(5)},(5/2)^{(4)},3^{(5)}\}.}
\tag{29.3}
\]

The kernel proof is elementary and independent: \(F_u x=0\) implies that the three scalars incident to \(u\) are equal, because the only linear relation among the trimer vectors is their equal sum. The Petersen graph is connected, so these local equalities propagate along edges. Consequently

\[
\boxed{\ker F=\mathbb R\mathbf1_{15},\quad\operatorname{rank}F=14.}
\tag{29.4}
\]

The \(\mathbf5\) previously called *incidence-dark* (\(\ker B\)) is **not** dark to the trimer tangent source:

\[
\boxed{\|Fx\|^2=3\|x\|^2\quad(x\in\ker B).}
\tag{29.5}
\]

This is the largest singular response of \(F\). Compare the full scalar-network Kron map \(C\) from Section 22, whose squared response on the same abstract scalar-channel subspace is \(5292/180625\) under its **different** unit-conductance output norm. The two coefficients cannot be interpreted as relative physical transition rates: \(C\) and \(F\) have differently typed codomains and norms. The robust statement is that scalar incidence darkness does *not* imply tangent-source darkness.

## 30. The full five-core mirror readout and exact mirror cancellation

Reuse, without reselecting, the source-owned mirror matrices of Paper I-A:

\[
J_i=\frac34U_i^\sigma U_i^\mathsf T:\mathbf3\to\mathbf3',
\quad \sum_{i=1}^{5}J_i=0,
\quad T_{ij}=J_i+J_j.
\tag{30.1}
\]

Each axis \(u=ij\) is assigned \(T_u=T_{ij}\). Define two direct-sum tangent readouts

\[
M_3(t)=\sum_{u=1}^{10}t_u\in\mathbf3,
\qquad
M_{3'}(t)=\sum_{u=1}^{10}T_ut_u\in\mathbf3',
\quad M=(M_3,M_{3'}).
\tag{30.2}
\]

For each Petersen edge \(e=(u,v)\), exact quaternionic coordinates give the **mirror edge-compatibility identity**

\[
\boxed{k_{u,e}=-k_{v,e},\qquad
T_uk_{u,e}=-T_vk_{v,e}.}
\tag{30.3}
\]

The second equation is a genuine mixed result: it uses both the 600-cell edge cross products and Paper I-A's independent Galois-marked core matrices \(J_i\). It has been checked with exact \(\mathbb Q(\sqrt5)\) arithmetic on all fifteen edges after deriving \(J_i\) directly from the marked four-axis stars, via
\(J_i=\sum_{u\in H_i}w_u^\sigma w_u^\mathsf T\) for \(u=2w_u/\sqrt3\). Consequently

\[
\boxed{M_3F=M_{3'}F=0.}
\tag{30.4}
\]

Let \(P_u=I-uu^\mathsf T\), so \(M_3^\dagger v=(P_uv)_u\) and \(M_{3'}^\dagger w=(P_uT_u^\mathsf Tw)_u\). The exact 600-cell sum and mirror polar theorem give

\[
\sum_uP_u=\frac{20}{3}I_3,\quad
\sum_uT_uP_u=0,\quad
\sum_uT_uP_uT_u^\mathsf T=\frac53I_{3'}.
\tag{30.5}
\]

Thus

\[
\boxed{MM^\dagger=
\begin{pmatrix}
\frac{20}{3}I_3&0\\0&\frac53I_{3'}
\end{pmatrix}.}
\tag{30.6}
\]

This is *not* a physical mirror coupling ratio; it is the fixed norm of two explicitly selected geometric readout maps. It proves \(\operatorname{rank}M=6\) and permits exact orthogonal receiver projectors

\[
\boxed{P^{\mathcal V}_3=\frac3{20}M_3^\dagger M_3,
\qquad P^{\mathcal V}_{3'}=\frac35M_{3'}^\dagger M_{3'},
\quad P^{\mathcal V}_{\mathrm{loc}}=I_{\mathcal V}-P^{\mathcal V}_3-P^{\mathcal V}_{3'}.}
\tag{30.7}
\]

These three projectors are pairwise orthogonal, and \(P^{\mathcal V}_{\mathrm{loc}}\) is exactly the 14-dimensional image of \(F\).

## 31. The new exact geometric sequence

Equations (29.4), (30.4) and (30.6) imply \(\dim\ker M=20-6=14=\operatorname{rank}F\), so \(\operatorname{im}F=\ker M\). The resulting **completely explicit finite exact sequence** is

\[
\boxed{
0\longrightarrow\mathbb R
\overset{\mathbf1}{\longrightarrow}
\mathbb R^{15}_{\rm unoriented\ C_4}
\overset{F}{\longrightarrow}
\bigoplus_{10\ C_6\ \mathrm{axes}}V_u
\overset{(M_3,M_{3'})}{\longrightarrow}
\mathbf3\oplus\mathbf3'
\longrightarrow0.}
\tag{31.1}
\]

The corresponding representation decomposition is

\[
\boxed{
\bigoplus_{u=1}^{10}V_u\cong
(\mathbf4\oplus\mathbf5\oplus\mathbf5)_{\operatorname{im}F}
\oplus (\mathbf3\oplus\mathbf3')_{\rm complementary}.}
\tag{31.2}
\]

The \(\mathbf4\oplus 2\mathbf5\) part is the image of \(\mathbb R^{15}_{\rm unsigned}\cong\mathbf1\oplus\mathbf4\oplus2\mathbf5\) modulo its uniform line; the two inequivalent 3-spaces are the mirror readout quotient. Thus this exact sequence is a **parallel structure** to the already-owned Paper I-A oriented-edge Hodge sequence \(0\to\mathbb R\to\mathbb R^{10}\to\mathbb R^{15}_{\rm oriented}\to\mathbf3\oplus\mathbf3'\to0\). Their equal terminal representations do not identify their scalar and oriented input modules or imply new physical excitations.

A finite-geometric selection rule follows: **no purely local scalar trimer input of the form \(Fx\) has a nonzero global ordinary or mirror readout \(M_3\) or \(M_{3'}\)**. A physical source that actually populates a nonzero receiver must be action-owned and cannot be fabricated merely by choosing \(x\) in the 15 scalar channel slots. This is a theorem about these specified geometric maps, not a universal physical no-go.

## 32. Normalized \(E_{36}\) lift and two distinct rank questions

For the mathematically legitimate direct sum of source comparison spaces (not of physical carriers), define

\[
\mathcal J_{\rm loc}(x)
=-\frac23E_{36}\bigl(S_u((Fx)_u)\bigr)_{u=1}^{10}.
\tag{32.1}
\]

Using the actual III-C source metric separately in each fibre,

\[
\boxed{\mathcal J_{\rm loc}^\dagger\mathcal J_{\rm loc}
=\frac{E_{36}^2}{9}\left(3I_{15}-\frac12 B^\mathsf TB\right),}
\tag{32.2}
\]

with spectrum

\[
\boxed{\left\{0^{(1)},
(E_{36}^2/9)^{(5)},
(5E_{36}^2/18)^{(4)},
(E_{36}^2/3)^{(5)}\right\}.}
\tag{32.3}
\]

For one axis with only its three incident labels, the local Gram equals

\[
G_{u,3}=\frac{E_{36}^2}{9}
\begin{pmatrix}1&-\tfrac12&-\tfrac12\\
-\tfrac12&1&-\tfrac12\\-\tfrac12&-\tfrac12&1\end{pmatrix},
\qquad
\operatorname{Spec}G_{u,3}=\{0,(E_{36}^2/6)^{(2)}\}.
\tag{32.4}
\]

There is **no conflict** with the previous rank-two fixed-axis \(\mathcal J_u=-\frac23E_{36}S_uP_uK\) of Section 25. The former includes *all fifteen* globally oriented flux labels incident or not at the fixed axis; the new \(\mathcal J_{\rm loc}\) uses only the three locally incident scalar channel labels **at each of ten different geometric axes** and takes values in a 20-dimensional comparison bundle. One is a fixed-axis rank-two map; the other a globally supported rank-fourteen comparison family. Neither count is a number of independent particle decay modes.

## 33. Exactly what the protected carrier can predict about a finite two-point response

**Conditional dynamical experiment:** complexify the already existing finite real Clifford carrier and *suppose* the protected positive grading \(H_{\rm car}\) is taken as the self-adjoint generator of time translation, with the same-owner energy/unit contract. Let \(\Delta=E_{40}-E_{32}\). Decompose

\[
S_u(v)=T_u^{\mathrm{Cl}}(v)+T_u^{\mathrm{Cl}}(v)^\dagger,
\qquad T_u^{\mathrm{Cl}}(v)=|vu\rangle\langle u|.
\]

(Here \(T_u^{\mathrm{Cl}}\) is the **Clifford transition block**, *not* the mirror-core map \(T_u=J_i+J_j\) of (30.1).) Then

\[
[H_{\rm car},T_u^{\mathrm{Cl}}(v)]=\Delta T_u^{\mathrm{Cl}}(v),
\qquad [H_{\rm car},[H_{\rm car},S_u(v)]]=\Delta^2S_u(v).
\tag{33.1}
\]

For the previously defined fixed-axis comparison \(\mathcal J_u(e)=-(2/3)E_{36}S_u(P_uk_e)\), its Heisenberg evolution is exactly a superposition of the two frequencies \(\pm\Delta/\hbar\). With \(\tau_8=\mathrm{Tr}/8\),

\[
\boxed{
\tau_8\bigl(\mathcal J_u(e;t)\mathcal J_u(f;0)\bigr)
=\frac{E_{36}^2}{9}\,(k_e\cdot P_uk_f)
\cos(\Delta t/\hbar).}
\tag{33.2}
\]

Its 15-channel spectral measure has only two delta-supported lines and a rank-two positive semidefinite coefficient matrix. Summing its diagonal yields the exact time-dependent sum rule

\[
\boxed{\sum_{e=1}^{15}
\tau_8(\mathcal J_u(e;t)\mathcal J_u(e;0))
=\frac{10}{9}E_{36}^2\cos(\Delta t/\hbar).}
\tag{33.3}
\]

For an actual **specified Gibbs comparison state** \(\rho_\beta=Z_\beta^{-1}e^{-\beta H_{\rm car}}\) on the eight-dimensional carrier,

\[
Z_\beta=4e^{-\beta E_0}+e^{-\beta E_{32}}+2e^{-\beta E_{40}}+e^{-\beta E_{56}},
\]

\[
\boxed{
\operatorname{Tr}\bigl(\rho_\beta\mathcal J_u(e;t)\mathcal J_u(f;0)\bigr)
=\frac{4E_{36}^2}{9Z_\beta}(k_e\cdot P_uk_f)
\left[e^{-\beta E_{40}}e^{i\Delta t/\hbar}
+e^{-\beta E_{32}}e^{-i\Delta t/\hbar}\right].}
\tag{33.4}
\]

The spectral-line weight ratio is \(e^{-\beta\Delta}\), under the displayed sign convention. This is an elementary finite-source detailed-balance identity. The **dynamical frequency is \(|E_{40}-E_{32}|/\hbar\), not \(E_{36}/\hbar\)**; \(E_{36}\) sets the specified balanced source amplitude. The formula does not add a spontaneous decay rate, linewidth, physical bath, or detector.

In particular, since \(H_{\rm car}\) is block-diagonal in \(Q_4,Q_5\),

\[
\boxed{Q_5e^{-itH_{\rm car}/\hbar}Q_4=0\quad\forall t.}
\tag{33.5}
\]

Thus **the unperturbed carrier has zero \(Q_4\to Q_5\) transition probability**, despite its off-diagonal comparison/detection capacity.

For completeness, a *conditional externally inserted* Hermitian probe
\(H_{\lambda,x}=H_{\rm car}+\lambda\mathcal J_u(x)\), with real \(x\), couples one tangent direction and leaves one tangent direction dark. With \(g=(2/3)|\lambda|E_{36}\|P_uKx\|\), the exact coherent transition probability is

\[
\boxed{P_{4\to5}(t)=\frac{4g^2}{\Delta^2+4g^2}
\sin^2\!\left(\frac{t}{2\hbar}\sqrt{\Delta^2+4g^2}\right).}
\tag{33.6}
\]

This is **Rabi oscillation, not irreversible decay**; \(\lambda\) is an unselected probe coupling. A physical linewidth requires the actual interaction, open channels/continuum or a controlled effective-environment limit and its source-to-pole residues. Paper VII-B already requires the full Schur self-energy if the physical source embedding leaks.

## 34. Robust complex-tangent trine observable

The local real-source identity \(\sum_jp_j^2=1/2\) from Section 16 remains true for every real tangent direction and under the unique projective \(D_3\)-equivariant local linear map, regardless of its overall coefficient. A complex quantum source is more general and need not obey that sharp equality.

Let \(\rho\) be a normalized positive \(2\times2\) density matrix on \(V_u\otimes\mathbb C\), and define an explicit three-effect local trine measurement

\[
M_j=\frac23|k_{u,j}\rangle\langle k_{u,j}|,
\quad\sum_jM_j=I_2,
\quad p_j=\operatorname{Tr}(\rho M_j).
\tag{34.1}
\]

Using a local orthonormal real tangent basis write \(\rho=\frac12(I+s_1\sigma_z+s_2\sigma_x+s_3\sigma_y)\). A real trine is insensitive to \(s_3\), and the three probabilities obey

\[
\boxed{\sum_jp_j^2=\frac13+\frac{s_1^2+s_2^2}{6},
\quad \frac13\le\sum_jp_j^2\le\frac12.}
\tag{34.2}
\]

For a pure complex tangent amplitude, \(s_1^2+s_2^2+s_3^2=1\), so

\[
\boxed{\sum_jp_j^2=\frac12-\frac{s_3^2}{6}.}
\tag{34.3}
\]

The real linearly polarized case has \(s_3=0\) and sum-of-squares \(1/2\); a circularly polarized pure source has \(|s_3|=1\), giving uniform \((1/3,1/3,1/3)\) and sum-of-squares \(1/3\). General mixed sources satisfy (34.2). **A measured corrected triple could probe this invariant only if the action and detector select precisely the three local trine effects, with charge, phase-space and interference issues controlled.** The three branching probabilities of arbitrary particle decays are not automatically such a POVM.

## 35. What the theory development has now fixed and what a true decay computation still needs

**Closed mathematical results:**

1. The projective-axis stabilizer is genuinely \(D_3\) with twelve quaternion lifts; the nearest-neighbor local tangent map is unique up to one real scalar under that symmetry. The oriented \(C_3\) contract has two real intertwiners.
2. The global 15-channel to ten-tangent-bundle map \(F\) has rank 14, with a one-dimensional uniform kernel and exact eigenvalues \(0,1,5/2,3\) at multiplicities \(1,5,4,5\).
3. The existing Paper I-A Galois core operators produce an explicit *six-dimensional* ordinary-and-mirror quotient \(M\), with \(MF=0\) and \(MM^\dagger=\mathrm{diag}(20I/3,5I/3)\), yielding the finite exact sequence (31.1).
4. The current Paper III-C source normalization fixes all norms of the displayed **mathematical comparison map**, and if its carrier grading is employed as a Hamiltonian it has only the two Bohr frequencies \(\pm(E_{40}-E_{32})/\hbar\), not a spontaneous linewidth.
5. The local trine probability invariant is sharp for real sources and admits the exact complex-polarization extension (34.2)–(34.3).

**Not supplied by this derivation:** an action-selected global coefficient, an actual Fock-parent/daughter map, a source-preserving color/gauge/chirality/spin embedding, nonzero source and detector residues, a valid directed decay channel, or a finite/infinite-volume controlled width. The current Paper V-C and VII-B source contracts must own all these before any decay branching fraction is asserted.

**Next concrete action test:** for a specified physical parent/daughter pole and source owner, compute the derivative of the actual source-functional or full finite Hamiltonian matrix element restricted to the `C6 -> three complementary Q8 channels` bundle. The necessary selection question is whether that jet (a) respects projective \(D_3\), (b) is locally supported as in (28.1), and (c) matches the existing \(S_u\) under the same carrier and source metric. If it does, *all relative local three-channel geometry is then fixed up to one action-produced scalar*; calculate the complete on-shell pole residues and phase-space factors rather than fitting three independent channel strengths. If it does not, the precise operator terms breaking these conditions should be measured as failures of this comparison model—not silently discarded.

## 36. Verification scope and command

The appended `v16_source_spectral_certificates`, `v16_d3_certificates` and `v16_global_exact_sequence_certificates` checks run after all earlier v1.5 predecessor checks in one deterministic pure-Python script:

```bash
python Paper00-Petersen600CellIncidence-v1_6.py
```

The new exact checks include all ten stabilizers and their 12 quaternion lifts, all 15 mirror edge compatibility equations, all local trimer Gram matrices, the two 3-by-3 receiver Gram blocks, the full 15-by-15 exact global source Gram and its complete \(1+4+5+5\) eigenspace resolution. The spectral/Gibbs/Rabi checks use exact finite-carrier matrix algebra and rational test energies; their displayed general-time formulas follow symbolically from the stated two-level operator blocks. No source ZIP, framework TeX or DAG archive was modified; this remains a separate, noncanonized theory-development note.

## 37. A canonical finite Hodge comparison — and a sharp action-uniqueness obstruction

The exact complex (31.1) permits the **mathematically defined** (unit-coefficient) Hodge operator on its middle, twenty-dimensional tangent space,

\[
L_{\mathcal V}^{\rm geom}=FF^\dagger+M^\dagger M.
\tag{37.1}
\]

Because \(MF=0\), its two summands act on orthogonal subspaces. Using (29.3) and (30.6), its spectrum is completely fixed:

\[
\boxed{\operatorname{Spec}L_{\mathcal V}^{\rm geom}=
\{1^{(5)},(5/2)^{(4)},3^{(5)},(5/3)^{(3)},(20/3)^{(3)}\}.}
\tag{37.2}
\]

There is **no zero mode** on the middle tangent bundle: this is the Hodge-Laplacian version of exactness, not a new physical mass-gap theorem. The receiver eigenvalues \(20/3,5/3\) are geometric normalization constants for the particular maps \(M_3,M_{3'}\). Writing (37.1) with unit coefficients is a canonical *comparison convention*, not an insertion into the Born–Hopf spectral action.

More generally, even unmarked global \(A_5\) covariance does not by itself select a unique self-adjoint tangent-bundle Hessian. From (31.2),

\[
\operatorname{End}_{A_5}(\mathcal V)\simeq
\mathbb R\oplus\mathbb R\oplus\mathbb R\oplus M_2(\mathbb R),
\]

so the **real self-adjoint invariant quadratic-response space has dimension six**: one coefficient each on \(\mathbf3,\mathbf3',\mathbf4\), and a symmetric \(2\times2\) matrix on the two copies of \(\mathbf5\). Hence the uniqueness in Section 28 is restricted to the declared *nearest-neighbor, fibrewise, projective-axis-equivariant local source map*. It does not force the full physical propagator, quadratic action or pole spectrum. The physical action must supply those remaining coefficients through the actual source/kinetic/Hessian jets and proper representation-to-particle incidence.

---

# Version 1.6 extension — inverse Clifford reconstruction and rooted A4 leakage

**Status:** exact finite-geometry derivations and executable Q(sqrt(5)) certificates, checked on framework v2.370. **Physical source/Hessian and decay-width insertion remain open.** All v1.5 claims are retained. The cumulative executable is `Paper00-Petersen600CellIncidence-v1_7.py`.

## 38. The Petersen graph is reconstructed by minimal-support compatibility

Retain the exact geometric complex from Section 31, in particular the ten projective axes \(u\), the tangent bundle \(\mathcal V=\bigoplus_u V_u\), the geometric source map \(F\), and the two readouts
\[
M_3t=\sum_ut_u,\qquad M_{3'}t=\sum_uT_ut_u,
\quad T_{ij}=J_i+J_j,\quad \operatorname{im}F=\ker M.
\]
Here the symbols \(u,v\) denote unit imaginary axes and \(T_u\) acts from the ordinary to the mirror real 3-space. Given distinct axes \(u,v\), let \(\mathcal V_{\{u,v\}}\) consist of tangent configurations supported only at those two axes. The first readout vanishes precisely when \(t_v=-t_u\), with \(t_u\in V_u\cap V_v=\mathbb R(u\times v)\) (projective axes are nonparallel). The second vanishes exactly when
\[
\boxed{(T_u-T_v)(u\times v)=0.}\tag{38.1}
\]
The exact finite \(2I\) coordinate certificate checks the condition for all \(45=\binom{10}{2}\) pairs: it holds on the 15 Petersen edges and fails on the 30 nonedges. Therefore
\[
\boxed{u\sim_{KG(5,2)}v\ \Longleftrightarrow\ \dim\bigl(\mathcal V_{\{u,v\}}\cap\ker M\bigr)=1,}\tag{38.2}
\]
and the dimension is zero otherwise. The Petersen graph is recoverable from the **minimal-support Clifford compatibility test**, without using adjacency as an input to (38.1). This is a geometric statement; a minimal-support pair is not an assertion of a physical one-to-one decay channel.

## 39. Exact canonical inverse on all ten tangent fibres

Let \(B\in\mathbb R^{10\times15}\) be the unsigned Petersen incidence matrix, \(X=B^\mathsf TB\), and \(G=F^\dagger F=3I_{15}-X/2\). The eigenvalues of \(X\) are \(6^{(1)},4^{(5)},1^{(4)},0^{(5)}\). Hence its zero-mean Moore--Penrose inverse is the rational polynomial
\[
\boxed{
G^+=-\frac1{450}(X-6I_{15})(13X^2-2X+25I_{15}).}
\tag{39.1}
\]
It has eigenvalues \(0,1,2/5,1/3\) on the indicated spectral spaces, respectively. The exact \(\mathbb Q(\sqrt5)\) certificate verifies all four Penrose identities and
\[
\boxed{FG^+F^\dagger=P_{\mathrm{loc}}
=I_{\mathcal V}-\frac3{20}M_3^\dagger M_3-\frac35M_{3'}^\dagger M_{3'}.}
\tag{39.2}
\]
For any **typed mathematical tangent source** \(t\in\mathcal V\), its canonical projected channel-amplitude reconstruction and orthogonal residual are
\[
\boxed{\widehat x=G^+F^\dagger t,\qquad
\widehat t=F\widehat x,\qquad \mathbf1^\mathsf T\widehat x=0,}
\tag{39.3}
\]
\[
\boxed{\|t-\widehat t\|^2
=\frac3{20}\|M_3t\|^2+\frac35\|M_{3'}t\|^2.}
\tag{39.4}
\]
Consequently \(t\) comes *exactly* from local three-channel incidence iff both receiver readouts vanish, and (39.3) then gives its unique channel amplitudes modulo the uniform all-ones kernel. This is a parameter-free geometry-internal diagnostic, not an inference from measured branching fractions absent a source-to-tangent map.

**Single-axis corollary.** For a nonzero \(t\) supported in a single fibre \(V_u\), the Paper I-A polar identity \(T_u^\mathsf TT_u|_{V_u}=I/4\) gives
\[
\boxed{\|P_{\mathrm{loc}}t\|^2=\tfrac7{10}\|t\|^2,\quad
\|P_3t\|^2=\|P_{3'}t\|^2=\tfrac3{20}\|t\|^2.}
\tag{39.5}
\]
Thus no nonzero one-fibre source is wholly in \(\operatorname{im}F\); its geometric receiver projections carry equal 15% squared norm. A two-axis flux supported on the endpoints of a Petersen edge can instead have both receiver projections zero. These are geometric norm decompositions, not physical probability partitions.

## 40. A5-invariant action-response no-go survives all equivariant propagation

Over real \(A_5\) modules,
\[
\mathcal V=(\mathbf4\oplus\mathbf5\oplus\mathbf5)_{\mathrm{loc}}\oplus(\mathbf3\oplus\mathbf3')_{\mathrm{rec}}.
\]
Both summands are sums of inequivalent irreducibles. Therefore every \(A_5\)-equivariant linear map \(H:\mathcal V\to\mathcal V\) is block diagonal with respect to this split, and in particular
\[
\boxed{M H F=0,\qquad M f(H)F=0}
\tag{40.1}
\]
for any defined polynomial, analytic functional calculus, or resolvent \(f(H)=(z-H)^{-1}\) on a regular chart. This is a Schur-lemma theorem, independent of the **six** permitted real self-adjoint quadratic-response coefficients. If the complete (possibly larger) action Hessian, external embedding and elimination all preserve \(A_5\) covariance, its Schur-complement/return kernel also intertwines \(A_5\), and the same restricted response selection rule survives. This does *not* assert that the current physical action has unbroken \(A_5\): a marked tetrahedral root is an explicit and relevant symmetry reduction.

The real self-adjoint \(A_5\)-commutant on \(\mathcal V\cong\mathbf3\oplus\mathbf3'\oplus\mathbf4\oplus2\mathbf5\) has dimension \(1+1+1+3=6\). On a fixed root its \(A_4\) restriction becomes
\[
\boxed{\mathcal V|_{A_4}=\mathbf1\oplus2\mathbf2_{\mathbb R}\oplus5\mathbf3,}
\tag{40.2}
\]
using \(\mathbf4\downarrow_{A_4}=\mathbf1\oplus\mathbf3\), \(\mathbf5\downarrow_{A_4}=\mathbf2_{\mathbb R}\oplus\mathbf3\), and \(\mathbf3,\mathbf3'\downarrow_{A_4}=\mathbf3\). The real self-adjoint commutant dimension is now
\[
\boxed{1+\dim_\mathbb R\operatorname{Herm}_2(\mathbb C)+\dim_\mathbb R\operatorname{Sym}_5(\mathbb R)=1+4+15=20.}
\tag{40.3}
\]
Thus \(A_4\) permits but does not uniquely determine new mixing between the receiver triplets and local trimer modes. This is consistent with the actual rooted comparison capacities and non-insertion firewalls in Papers V-A and V-C.

## 41. Canonical geometric rooted projector and exact rank-six mixing

For one of the five conjugate tetrahedral cores \(H_m\simeq 2T\), define the **geometric root mask** \(R_m\) as the orthogonal projector onto the four tangent fibres whose \(C_6\) axes lie in \(H_m\). Thus \(\mathrm{rank}R_m=8\). It is \(A_4\)-equivariant for the marked core, but not \(A_5\)-equivariant. Define
\[
\boxed{C_m=P_{\mathrm{rec}}R_mP_{\mathrm{loc}}:\mathcal V_{\mathrm{loc}}\to\mathcal V_{\mathrm{rec}}.}
\tag{41.1}
\]
Use normalized isometric receiver embeddings
\[
U_3=\sqrt{3/20}\,M_3^\dagger,\qquad U_{3'}=\sqrt{3/5}\,M_{3'}^\dagger,\qquad U=(U_3,U_{3'}),
\quad U^\dagger U=I_6.
\]
The exact core-star identities of the 600-cell and Paper I-A are, for the four axes \(u\in H_m\),
\[
\boxed{\sum_{u\in H_m}P_u=\frac83I_3,\quad
\sum_{u\in H_m}T_uP_uT_u^\mathsf T=\frac23I_{3'},\quad
\sum_{u\in H_m}P_uT_u^\mathsf T=\frac13J_m^\mathsf T.}
\tag{41.2}
\]
They hold for all five marked cores by independent \(\mathbb Q(\sqrt5)\) computation. Hence the receiver compression is
\[
\boxed{A_m=U^\dagger R_mU=
\begin{pmatrix}\frac25I_3&\frac1{10}J_m^\mathsf T\\\frac1{10}J_m&\frac25I_3\end{pmatrix},\qquad
\operatorname{Spec}(A_m)=\left\{\left(\tfrac12\right)^{(3)},\left(\tfrac3{10}\right)^{(3)}\right\}.}
\tag{41.3}
\]
Since \(R_m^2=R_m\), the receiver leakage covariance is
\[
C_mC_m^\dagger=U(A_m-A_m^2)U^\dagger,\quad
A_m-A_m^2=\begin{pmatrix}\frac{23}{100}I_3&\frac1{50}J_m^\mathsf T\\\frac1{50}J_m&\frac{23}{100}I_3\end{pmatrix}.
\]
Therefore
\[
\boxed{\operatorname{rank} C_m=6,\qquad
\operatorname{Spec}_{>0}(C_mC_m^\dagger)
=\{(1/4)^{(3)},(21/100)^{(3)}\}.}
\tag{41.4}
\]
The singular values are \(1/2\) and \(\sqrt{21}/10\), each triple, with squared ratio \(25/21\). These are uniquely fixed for **this explicitly specified root projection**, not all \(A_4\)-equivariant action Hessians.

## 42. Five-root zero-sum and frame-variance identities

Each projective \(C_6\) axis belongs to two of the five \(2T\) stars, so
\[
\sum_{m=1}^5R_m=2I_\mathcal V.
\]
It follows immediately that the root-mixing maps obey a coherent zero-sum law,
\[
\boxed{\sum_{m=1}^5 C_m=0.}\tag{42.1}
\]
In contrast, their squared response does not cancel. Using (41.3), \(\sum_mJ_m=0\), and the explicit projectors,
\[
\boxed{\sum_{m=1}^5C_mC_m^\dagger=\frac{23}{20}P_{\mathrm{rec}}.}\tag{42.2}
\]
This is isotropic on the full six-dimensional receiver; for equally weighted incoherent root alternatives the average squared covariance is \(23P_{\mathrm{rec}}/100\). It must not be interpreted as a probability for physical root occupancy without a state/preparation measure.

The stronger source-side identity, verified entrywise over \(\mathbb Q(\sqrt5)\) in the 30-coordinate tangent realization, is
\[
\boxed{\sum_{m=1}^5C_m^\dagger C_m
=\frac3{10}FF^\dagger-\frac3{20}P_{\mathrm{loc}}.}
\tag{42.3}
\]
The right-hand side vanishes on the \(\mathbf3\oplus\mathbf3'\) receiver and is strictly positive on \(\operatorname{im}F\), with spectrum
\[
\boxed{(3/20)^{(5)},\ (3/5)^{(4)},\ (3/4)^{(5)}.}
\tag{42.4}
\]
Thus \(\bigcap_m\ker(C_m|_{\operatorname{im}F})=\{0\}\): every nonzero local geometric source leaks to the global receiver for at least one root. This is an injective five-root analysis **frame**, not five physical decay vertices.

## 43. A concrete same-action pass/fail diagnostic

The source-owned Paper III-C balanced Clifford source is well-defined, but Papers III-F/V-C/VII-A/VII-B still do not insert the root mask (41.1) as a physical interaction. The correct next computation is to obtain a **same-action** projected source/kinetic/complete-Hessian cross block \(D_m(z):\mathcal V_{\mathrm{loc}}\to\mathcal V_{\mathrm{rec}}\) after a licensed, source-preserving physical embedding, with actual full Schur return when the carrier is not reducing. It is then possible to test the *specific hypothesis* \(D_m(z)=g_m(z)C_m\) by a geometric residual rather than merely equating dimensions.

Because \(\|C_m\|_{\mathrm{HS}}^2=3(1/4+21/100)=69/50\), define
\[
\boxed{g_m(z)=\frac{50}{69}\operatorname{Tr}(C_m^\dagger D_m(z)),\qquad
\mathcal E_m(z)=D_m(z)-g_m(z)C_m.}
\tag{43.1}
\]
With the natural complex Hilbert--Schmidt convention, \(\|\mathcal E_m\|_{\mathrm{HS}}^2=\|D_m\|_{\mathrm{HS}}^2-(50/69)|\operatorname{Tr}(C_m^\dagger D_m)|^2\ge0\). Therefore \(\mathcal E_m=0\) is an exact, inspectable criterion for whether the actual operator uses this geometric rooted mixing direction (up to its action-determined coefficient). **Do not fit** \(g_m\) to measured rates and then call it a geometric derivation; its numerical value must come from the same physical action and state/kinetic normalization.

If \(K_0\) is an unbroken \(A_5\)-equivariant self-adjoint tangent kernel and a hypothetical rooted perturbation \(\lambda R_m\) is inserted for a mathematical response test, then \(P_{\mathrm{rec}}(z-K_0)^{-1}P_{\mathrm{loc}}=0\). The leading off-diagonal resolvent term is
\[
\boxed{\lambda\,P_{\mathrm{rec}}(z-K_0)^{-1}C_m(z-K_0)^{-1}P_{\mathrm{loc}}+O(\lambda^2),}
\tag{43.2}
\]
for \(z\) away from the spectrum. Its geometric channel norm is controlled by \(\|C_m\|=1/2\). This is a **conditional mathematical perturbation**, not an action-selected physical rate. The physical source may break \(A_5\) in different ways or may not admit this tangent-bundle reduction at all.

## 44. Verification and status

Run the cumulative standalone script:

```bash
python Paper00-Petersen600CellIncidence-v1_7.py
```

The added v1.7 certificate constructs every \(2I\) axis, all five native core-mirror matrices, the exact tangent projectors and \(15\)-edge flux map. It verifies every two-axis support test (45 cases), all Moore--Penrose equations, the complete \(30\times30\) orthogonal Hodge projector identity, the single-axis 70/15/15 norm decomposition, all five rooted compression matrices, and the coherent/variance five-root matrix identities. All predecessor v1.6 certificates are also rerun; the total test succeeds. No original framework paper, DAG or audit ZIP has been altered.

**Interpretation:** the mathematical source pathway is now quite restrictive: an unmarked \(A_5\) source cannot feed receiver triplets via equivariant propagation, whereas a specified rooted core provides an explicit rank-six geometry-defined coupling, with a zero-sum five-root frame and exact strength spectrum. A measured decay width, mirror transition or action-owned source coupling has **not** been deduced. This result identifies a finite, evaluable action-jet hypothesis and its exact nonfit diagnostic, not a completed particle decay model.
