# Born–Hopf Geometry — Twisted 24-cell → Petersen-25 bridge and baryon-source eligibility

**Version:** `Paper00-HadronScaleTest-v1_7`  
**Date:** 2026-11-07  
**Source archive:** `Paper00-PapersMinimal-v2_341(1).zip`, especially Paper I-A `Paper1A-Geometry-v5_153.tex`, Paper V-B `Paper5B-TerminalSpectrum-v5_181.tex`, Paper VII-A `Paper7A-QCDKernel-v1_153.tex`, Paper VII-B `Paper7B-QCDReadouts-v1_138.tex`.  
**Prior research:** `Paper00-HadronScaleTest-v1_6.md`.  
**Status:** exact finite character construction and exact nonzero **gauge-invariant three-face observable** witness. No physical QCD pole, flavor-dependent coupling, or mass curvature derived. No update to the canonical papers/DAG.

## 1. Target and previously established obstruction

At matched light-flavor sextet indices `qqQ, qsQ, ssQ`, the observable is

\[
K_{Q,J}=M_{qqQ,J}-2M_{qsQ,J}+M_{ssQ,J}.
\]

The preceding v1_6 result shows that the untwisted five-core/25-register coefficient carrier has rank 17, orthogonal to the rank-25 Petersen coefficient sector. Its normalized positive pair indicators have a 25-sector weight of `1/2`, leading to the `1/50` vs `1/25` normalization ambiguity. The Paper VII color determinant does not itself identify a physical coupling between its 24-cell source and the Petersen sector.

This note asks the **observable-first** question: Is there a construction from the *already present* Hurwitz `2T` character data which (i) yields the entire Petersen-25 sector without a projection/renormalization choice and (ii) occurs nontrivially in the existing gauge-invariant baryon-flux observable? The answer is **yes for mathematical eligibility**, **not yet for physical baryon masses**.

## 2. Order-three character already present in Hurwitz 24-cell

Let

\[
G=2I,\qquad H=2T\subset G,\qquad [G:H]=5,
\]

and let `Q8` be the quaternion subgroup of `H`. The group fact already recorded in Paper I-A is

\[
H/Q_8\cong C_3.
\]

Fix one of its two nontrivial unitary characters:

\[
\chi:H\to\{1,\omega,\omega^2\},\quad
\omega^3=1,\quad\omega\ne1,\qquad
\bar\chi=\chi^{-1}.
\]

Both are trivial on the central `−1`, so the induced representations below factor through `A5`.

**Proposition 1 (exact induced quintet).**

\[
\boxed{\operatorname{Ind}_{2T}^{2I}\chi\cong\mathbf5},
\]

with `5` the unique degree-five real irreducible of `A5` (complexified). Either conjugate character induces an equivalent degree-five representation, not a second distinct 25-sector.

**Proof.** In `A4=H/{±1}` the nontrivial characters are `1′,1″` with kernel `V4`. Restricting `A5` irreps to `A4` gives

\[
\begin{array}{c|c}
A_5\text{ irrep}&\text{restriction to }A_4\\\hline
\mathbf1&\mathbf1\\
\mathbf3,\mathbf3'&\mathbf3\\
\mathbf4&\mathbf1\oplus\mathbf3\\
\mathbf5&\mathbf3\oplus\mathbf1'\oplus\mathbf1''.
\end{array}
\]

This follows from the `A5` character values `(5,1,−1,0,0)` on identity, double-transposition, 3-cycle, and two 5-cycle classes. By Frobenius reciprocity, `1′` is contained once only in the restriction of `5`; since `Ind` has dimension `[G:H]=5`, the induction is exactly `5`. The central-odd `2I` irreps cannot contain a center-even `χ` by central-character orthogonality. ∎

## 3. The phase-twisted 25 core registers are an exact orthogonal basis

Choose left-coset representatives `g_1,…,g_5` of `G/H`. Define `25` functions on `G`:

\[
F_{ij}(g)=
\begin{cases}
\chi(g_i^{-1}gg_j),& g_i^{-1}gg_j\in H,\\
0,&\text{otherwise}.
\end{cases}
\tag{1}
\]

For a fixed `g`, the `5×5` matrix `U_χ(g)=[F_{ij}(g)]` is monomial with a single `1,ω,ω²` phase in each row and column. It is the induced representation from Proposition 1.

**Theorem 2 (rank-25 repair).** The exact `2I` counting-normalized Gram identity is

\[
\boxed{\sum_{g\in2I} F_{ij}(g)\overline{F_{kl}(g)}
 =24\,\delta_{ik}\delta_{jl}.}\tag{2}
\]

Therefore, with `F: C^25 → C^120` the coefficient map,

\[
\boxed{F^\dagger F=24I_{25},\quad
\operatorname{rank}F=25,\quad
\Pi_{25}=\frac1{24}FF^\dagger.}\tag{3}
\]

The central projector has its pre-existing atlas kernel

\[
\boxed{(\Pi_{25})_{g,h}=
\frac1{24}\chi_5(g^{-1}h).}\tag{4}
\]

**Proof.** Matrix-coefficient Schur orthogonality for a 5-dimensional unitary irrep of order `120` gives `120/5=24` times the Kronecker deltas. The sum of normalized coefficient outer products is the central rank-25 irrep-coefficient projector. The induced quintet is real-equivalent, hence `χ5(g^{-1}h)=χ5(gh^{-1})` in this character kernel. ∎

In contrast, replacing `χ` by the trivial character gives the ordinary five-point permutation representation `1⊕4` and

\[
\operatorname{Spec}(F_{\rm untwisted}^\dagger F_{\rm untwisted})
=\{120^{(1)},30^{(16)},0^{(8)}\}.
\]

The *full* twisted and untwisted coefficient spaces are orthogonal:

\[
F_\chi^\dagger F_{\rm untwisted}=0.
\]

Thus the v1_6 statement `Π25 B5=0` is not contradicted: it applies to the **untwisted** carrier. The new `C3`-twisted carrier selects precisely the complementary block.

**Normalized source consequence.** Every individual twisted coefficient `Fij/√24` is a unit vector **entirely** in `Π25`, so, for the already defined geometric incidence transfer `T_u`,

\[
\left\|T_u \frac{F_{ij}}{\sqrt{24}}\right\|^2
=\frac1{25}.
\]

There is no `1/50` projection fraction in this *specific* geometric source class. This is not a physical energy shift; the physical map and source norm are still uncomputed.

## 4. Explicit intertwiner into the original Petersen ten-pair module

Let `V10=C[binom({1,…,5},2)]`. For its `A5` permutation representation `ρ10`, define the previously derived rank-five Petersen projector

\[
P(S,T)=\delta_{ST}-\frac{|S\cap T|}{3}+\frac16.
\]

Restrict to `H=A4` and let

\[
Q_\chi=\frac1{12}\sum_{h\in A4}\overline{\chi(h)}\rho_{10}(h).
\]

This is an orthogonal **rank-one** projector supported inside `im P`. Choose any pair basis vector `e_S` for which `Qχ e_S≠0`, and put `v=Qχ e_S/||Qχ e_S||`. Let `g_i` be the same coset representatives and define

\[
\boxed{J e_i=\rho_{10}(g_i)v.}\tag{5}
\]

Then the exact intertwining and isometry identities are

\[
\boxed{\rho_{10}(g)J=J U_\chi(g),\qquad
J^\dagger J=I_5,\qquad JJ^\dagger=P.}\tag{6}
\]

Frobenius reciprocity guarantees that the nonzero `A5`-intertwiner space is one-dimensional over `C`, so `J` is unique up to a global phase once the root `χ` and coset conventions are fixed. The attached CSV records one explicitly normalized `10×5` choice; its equivariance residual is below `1.2×10^−15` numerically. This is a direct, constructive **Hurwitz-C3 → Petersen-quintet** isometry.

## 5. Native Paper VII-A gauge-invariant three-face character modes

Paper VII-A already defines, for every oriented Hurwitz edge `e=(p,q)` with its three incident triangular faces,

\[
W_e=\frac16\epsilon_{abc}\epsilon_{a'b'c'}
(A_1)_{aa'}(A_2)_{bb'}(A_3)_{cc'},\quad
A_i=U_{q r_i}U_{r_i p}.
\]

Its gauge invariance and polarization are established in `p10:prop:v2220-edge-fan-baryon`.

The Hurwitz 24 vertices form the left regular `H`-set. Edge adjacency is preserved by quaternionic multiplication. The certificate enumerates `96` unoriented and `192` oriented edges; left `H` acts freely on oriented edges, producing eight orbits of size 24 (four if directions are forgotten).

Choose one representative `e_a` of each oriented orbit and form the **existing-observable** Fourier projections

\[
\boxed{W_{\chi,a}(U)=\frac1{\sqrt{24}}
\sum_{h\in H}\overline{\chi(h)}\,W_{h e_a}(U),
\quad a=1,\ldots,8.}\tag{7}
\]

Each term is gauge invariant. Under the shell relabeling action of `H`, `Wχ,a` transforms by `χ`; under an `H`-invariant gauge ensemble its one-point expectation vanishes, but this symmetry does **not** require its two-point response to vanish. The eight formal orbit-source directions need not remain independent as operators after physical constraints and dynamics; the representation-space multiplicity is exactly eight.

### A nonzero witness using the actual SU(3) determinant

Select one undirected Hurwitz edge and put a single nontrivial link

\[
U=\operatorname{diag}(e^{i\theta},e^{-i\theta},1)\in SU(3),
\]

with all other links the identity and the inverse on its reversed orientation. For any oriented edge `e`, the three-face determinant equals `1`, except for the twelve orientations of the six other edges in the three triangles touching the marked link, where

\[
W_e=t(\theta)=\frac{\operatorname{tr}U}{3}
=\frac{1+2\cos\theta}{3}.
\]

This follows by exactly contracting the two epsilon tensors with the diagonal link matrices, and it is verified in the certificate for `θ=π` using rational arithmetic. The nontrivial `χ`-phase counts in the eight orbits are

\[
(0,0,0),\;(1,0,1),\;(1,0,1),\;(0,1,1),
\;(1,0,1),\;(0,1,1),\;(0,1,1),\;(0,0,0).
\]

Consequently the exact source norm for this gauge configuration is

\[
\boxed{\sum_{a=1}^{8}|W_{\chi,a}(U)|^2
=\frac{(1-\cos\theta)^2}{9}.}\tag{8}
\]

In particular at `θ=π` it is `4/9`, and it is nonzero for every sufficiently small nonzero `θ` (provided the action's admissible gauge domain contains the corresponding near-identity link configurations). This shows the **existing gauge-invariant polarized color determinant is not identically killed by the nontrivial H-character projector.** It does not assert that this test link is a realized QCD vacuum or a physical baryon source residue. Individual link admissibility in the compiled `A_{L,adm}` must be checked at execution.

## 6. Flavor and physical-source constraints — what this does *not* derive

1. **Flavor is not the character.** The finite character `χ` is a mode of the Hurwitz-shell symmetry, not a strange-quark flavor eigenvalue. The same permitted character constructions can be attached to `qq`, symmetric `qs`, or `ss` operators. Pure representation theory does **not** choose only `ss` or derive `N_s(N_s−1)/2` as its coupling. In particular the color determinant is flavor blind.
2. **Source and action are different.** Fourier projection of the existing `W_e`, or a similarly weighted local baryon interpolating operator from the Paper VII-A source dictionary, changes which mode is probed; it does **not** change `H_L` or establish the mixing matrix element to physical baryon eigenstates. The physical mass-source member, normalized vacuum and full `SU(3)` transport remain typed execution inputs.
3. **Five-coset induction is not automatically five realized physical shells.** The `2I` 600-cell is a mathematical comparison carrier and its five twisted cosets do not become part of the selected 24-cell physical action merely because `Ind_H^G χ` exists.
4. **The transfer eigenvalue is not an energy coefficient.** Even for a source supported exactly in `Π25`, a self-energy/Schur term at a physical pole `z` depends on the actual coupling amplitude and auxiliary resolvent:

\[
\Sigma_{\chi}(z)=-V_{\chi}^\dagger
[Q_\chi(H_L-z)Q_\chi]^{-1}V_{\chi}.
\]

   A hypothetical `Vχ=αT_u J` and scalar positive gap `Δ−z` gives `−|α|²/[25(Δ−z)]` on the selected channel, **not** automatically `−E36/25`. Neither `α`, `Δ` nor the flavor selection is fixed here.
5. **Spin/flavor statistics do not select `ss` alone.** The symmetric light-flavor sextet includes `qq`, `qs`, and `ss`. The color-antisymmetric determinant plus Pauli exchange symmetry permits suitable orbital and spin states in each. A flavor-dependent physical assembly current is needed for nonzero curvature; attaching an equal twist-induced correction to all three makes the second difference vanish.

## 7. The executable next dynamical test

The next required *actual* Paper VII calculation is now more specific:

**(a)** Use one fully specified `H_L` and physical mass-source member, with the native gauge-singlet baryon operators for three matched spin/flavor sextet states.  
**(b)** On the 24-cell shell compute, before any hadron-mass comparison, the `χ`- and `χ̄`-Fourier-resolved source two-point matrices, including source overlaps and all eight oriented-edge orbit labels if the three-face source is used.  
**(c)** Check whether those nontrivial source modes have a **nonzero connected two-leg contribution** in the same-action baryon mass-curvature observable

\[
K=-\lim_{t\to\infty}\partial_t
\log\frac{C_{qq}(t)C_{ss}(t)}{C_{qs}(t)^2}.
\]

**(d)** Only if this coupling is demonstrably nonzero and appropriately flavor selective, use the normalized intertwiner `J` and the twisted coefficient projector `(3)` to match the physical response to the rank-25 Petersen transport. Measure the physical source amplitude and resolvent, rather than setting them to `E36` and `1/25` by hand.  
**(e)** Test several matched charm/bottom and spin/charge families; the effective pole shift must be computed at the pole, not from a zero-energy substitute.

The finite `2T`/`2I` and polarized determinant calculations in this note have **finished the mathematical representation bridge**. They have not closed steps (a)–(e).

## 8. Reproducibility

Run

```
python Paper00-HadronScaleTest-v1_7-certificate.py
```

The test constructs all 60 `A5` permutations and 12 `A4` point-stabilizer elements, establishes the character group law and monomial representation, verifies *every* twisted Gram entry by **exact counts** in `Z[ω]`, verifies orthogonality to the untwisted coefficient carrier, and checks its Gram eigenvalue/rank profile. It verifies the rank-five Petersen projector using Python `Fraction`, constructs the explicit `10×5` intertwiner, and checks all 60 intertwining equations to numerical precision. It independently constructs the integer Hurwitz quaternions, enumerates all 96/192 edges and their free H-orbits, checks the exact `SU(3)` polarized color determinant on every oriented edge at `θ=π`, and obtains the exact `4/9` Fourier norm.

**What is established:** an explicit complete, orthogonal `25`-register twisted realization of the rank-25 Petersen coefficient sector, and a nonzero `C3` mode of an already defined gauge-invariant color-determinant observable.  
**What is not established:** a flavor-selected physical interaction, the coefficient `−E36/25`, or a computed hadron pole.  
**Update status:** research certificate only; Papers I, V, VII, Bib, macro and DAG unchanged.
