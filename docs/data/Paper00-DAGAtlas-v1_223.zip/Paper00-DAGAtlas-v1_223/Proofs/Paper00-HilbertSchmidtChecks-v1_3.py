#!/usr/bin/env python3
"""Born-Hopf HS consequences v1_3: source-matched finite mathematical controls.

No physical Hamiltonian, clock, decay width or action is inferred.
The full normalized 2I spectrum was already established in Paper I-B; this is an independent numerical/integer replay.
- 600-cell nearest-neighbor graph from exact Q(sqrt5)/4 coordinates;
- exact integer adjacency polynomial and 25-dimensional character projector;
- exact spectral multiplicities from integer traces;
- weighted 24+32+32+32 quotient and 600-cell incidence consequences;
- independent floating-point reconstruction of the five marked-core tangent operators
  from Paper I-B's ten-axis quaternionic frame, with exact target rational values;
- algebraic Gram/pseudoinverse and Feshbach spectral-weight checks.

Requires numpy, sympy; scipy is not required.
"""
from __future__ import annotations
import json
from itertools import permutations,product,combinations
from pathlib import Path
import numpy as np
import sympy as sp

checks={}
def test(name, passed, **other):
    checks[name]={"passed":bool(passed),**other}
    if not passed:raise AssertionError(f'FAILED: {name}: {other}')

# Each quaternion coordinate is (a+b sqrt(5))/4.
Z=(0,0); V=[]
for k in range(4):
    for sign in (-1,1):
        q=[Z]*4;q[k]=(4*sign,0);V.append(tuple(q))
for signs in product((-1,1),repeat=4):
    V.append(tuple((2*s,0) for s in signs))
base=[Z,(2,0),(1,1),(-1,1)]
for p in permutations(range(4)):
    if sum(p[i]>p[j] for i in range(4) for j in range(i+1,4))%2:continue
    ordered=[base[p[i]] for i in range(4)]
    for signs in product((-1,1),repeat=3):
        it=iter(signs)
        V.append(tuple((0,0) if a==Z else tuple(s*x for x in a) for a in ordered for s in ((1,) if a==Z else (next(it),))))
test('600-cell exact 120 coordinates',len(V)==len(set(V))==120)

def qdot16(u,v):
    # dot = (A+B sqrt(5))/16
    return (sum(a*c+5*b*d for (a,b),(c,d) in zip(u,v)),
            sum(a*d+b*c for (a,b),(c,d) in zip(u,v)))

n=120
A=np.zeros((n,n),dtype=np.int64)
char=np.zeros((n,n),dtype=np.int64)
for i in range(n):
    for j in range(n):
        dot=qdot16(V[i],V[j]);
        if i!=j and dot==(4,4):A[i,j]=1
        # U_4(q dot r) is integer on the nine allowed 2I classes
        if dot in ((16,0),(-16,0)):cc=5
        elif dot in ((8,0),(-8,0)):cc=-1
        elif dot==(0,0):cc=1
        else:
            if dot not in ((4,4),(-4,-4),(4,-4),(-4,4)):
                raise AssertionError(f'Unexpected quaternion pair scalar {dot}')
            cc=0
        char[i,j]=cc

test('600-cell 12-regular 720-edge',np.array_equal(A,A.T) and np.all(A.sum(axis=1)==12) and A.sum()==1440)
test('600-cell triangle number 1200',np.trace(A@A@A)==7200)

z=sp.symbols('z')
p=(z-12)*(z-3)*z*(z+2)*(z+3)*(z*z-6*z-36)*(z*z-4*z-16)
coeffs=[int(c) for c in sp.Poly(p,z).all_coeffs()]
I=np.eye(n,dtype=np.int64)
H=coeffs[0]*I
for c in coeffs[1:]:H=H@A+c*I
test('600-cell exact degree-nine polynomial annihilation',not H.any(),polynomial=str(sp.expand(p)))
traces=[n];power=I
for k in range(1,9):
    power=power@A
    traces.append(int(np.trace(power)))

gold=sp.sqrt(5)
roots=[12,3,0,-2,-3]
paired=[[3+3*gold,3-3*gold],[2+2*gold,2-2*gold]]
mult_matrix=sp.Matrix([[sp.expand(sum(x**k for x in rs)) for rs in ([[t] for t in roots]+paired)] for k in range(7)])
mult=list(mult_matrix.inv()*sp.Matrix(traces[:7]))
expect=[1,16,25,36,16,4,9]
test('600-cell exact spectral multiplicities from moments',mult==expect,multiplicities=[int(x) for x in mult],trace_moments=traces)

test('twisted25 exact character projector',
     np.array_equal(char@char,24*char) and not (A@char).any() and int(np.trace(char))==600)
qcoef=[int(c) for c in sp.Poly(sp.div(p,z)[0],z).all_coeffs()]
N=qcoef[0]*I
for c in qcoef[1:]:N=N@A+c*I
test('twisted25 = adjacency-polynomial zero projector',np.array_equal(N,5184*char))

# The paper's 600x120 tetrahedron/vertex incidence identity T^T T = 20I+5A
# implies L_600 =16I-(1/5)T^T T by ordinary algebra.
test('600 incidence-derived Laplacian identity',
     np.array_equal(5*(12*I-A),80*I-(20*I+5*A)))

# Existing source's equitable partition 24+32+32+32: independently check
# quotient self-adjointness under vertex-count weighting, spectral roots,
# and 96 interstratum edges per pair. NOT an independent enumeration of the C_i.
Q=np.array([[0,4,4,4],[3,3,3,3],[3,3,3,3],[3,3,3,3]],dtype=np.int64)
w=np.array([24,32,32,32],dtype=np.int64)
D=np.diag(w)
test('equitability detailed balance and complete K4 96-edge quotient',
    np.array_equal(D@Q,Q.T@D) and np.all((D@Q)[np.triu_indices(4,1)]==96))
test('equitable quotient exact adjacency spectrum 12,-3,0,0',
     sp.Matrix(Q).charpoly().as_expr()==sp.expand((sp.Symbol('lambda')-12)*(sp.Symbol('lambda')+3)*sp.Symbol('lambda')**2))
for xx in ([0.,1.,-2.,3.], [2.3,-0.4,7.5,1.0]):
    x=np.array(xx)
    graph_energy=float(x@(D@(12*np.eye(4)-Q))@x)
    K4_energy=float(96*sum((x[i]-x[j])**2 for i in range(4) for j in range(i+1,4)))
    test(f'quotient 96-K4 energy for {xx}',abs(graph_energy-K4_energy)<1e-9)

# Independent numerical reconstruction of the paper's exact 5 marked-core
# leakage operators on a 30-coordinate ambient storage of 20D tangents.
phi=(1+np.sqrt(5.0))/2
iv=(np.sqrt(5.0)-1)/2
raw=[(1,1,1),(1,1,-1),(1,-1,1),(1,-1,-1),
     (iv,-phi,0),(phi,0,-iv),(0,iv,-phi),(0,iv,phi),
     (phi,0,iv),(iv,phi,0)]
vec=np.array(raw,dtype=float).T
# Use exact Q(sqrt5) automorphism formula rather than the manual list above.
# raw {phi=(1+s)/2, iv=(s-1)/2}; conjugate phi=(1-s)/2, iv=(-1-s)/2.
phic=(1-np.sqrt(5.0))/2;ivc=(-1-np.sqrt(5.0))/2
sig_raw=[(1,1,1),(1,1,-1),(1,-1,1),(1,-1,-1),
         (ivc,-phic,0),(phic,0,-ivc),(0,ivc,-phic),
         (0,ivc,phic),(phic,0,ivc),(ivc,phic,0)]
vec_sigma=np.array(sig_raw,dtype=float).T
labels=list(combinations(range(5),2))
Js=[]
for m in range(5):
    cols=[i for i,ij in enumerate(labels) if m in ij]
    Js.append((vec_sigma[:,cols]@vec[:,cols].T)/4.0)
P=[]
for j in range(10):P.append(np.eye(3)-np.outer(vec[:,j],vec[:,j])/3.0)
PV=np.zeros((30,30));M=np.zeros((6,30))
for j,(a,b) in enumerate(labels):
    PV[3*j:3*j+3,3*j:3*j+3]=P[j]
    M[:3,3*j:3*j+3]=P[j]
    M[3:,3*j:3*j+3]=(Js[a]+Js[b])@P[j]
Linv=np.diag([3/20]*3+[3/5]*3)
Prec=M.T@Linv@M
Ploc=PV-Prec
Cm=[]
for m in range(5):
    R=np.zeros((30,30))
    for j,ij in enumerate(labels):
        if m in ij:R[3*j:3*j+3,3*j:3*j+3]=P[j]
    Cm.append(Prec@R@Ploc)
G5=np.array([[np.sum(Ci*Cj) for Cj in Cm] for Ci in Cm])
G5_target=(69/40)*(np.eye(5)-np.ones((5,5))/5)
test('5-core exact rational Gram target (numerical independent reconstruction)',
     np.max(np.abs(G5-G5_target))<1e-12,max_error=float(np.max(np.abs(G5-G5_target))))
test('five-core cancellation',np.linalg.norm(sum(Cm))<1e-12)
W=sum(C.T@C for C in Cm)
eig=np.linalg.eigvalsh(W)
positive=eig[eig>1e-9]
test('5-core source leakage mode strengths 3/20 3/5 3/4',
     np.max(np.abs(np.sort(positive)-np.array([.15]*5+[.6]*4+[.75]*5)))<1e-12,
     positive_eigenvalues=np.round(positive,10).tolist())
# For the HS projection of any 6x14/common-owner off-diagonal block K onto span C_m:
# Pi_C K = (40/69) sum_m <C_m,K> C_m, as rank(G5)=4.
RNG=np.random.default_rng(20261116)
K=Prec@RNG.standard_normal((30,30))@Ploc
b=np.array([np.sum(C*K) for C in Cm])
Kproj=(40/69)*sum(x*C for x,C in zip(b,Cm))
res=K-Kproj
test('5-core HS inverse/projection/energy identity',
     abs(sum(b))<1e-12 and abs(np.sum(K*K)-np.sum(Kproj*Kproj)-np.sum(res*res))<1e-11
     and abs(np.sum(Kproj*Kproj)-(40/69)*np.sum(b*b))<1e-11)

# Feshbach integrated spectral weight: finite receiver Hamiltonian with broadened poles.
a=np.array([1.2,-.7,.5,-1.,.0]);a-=a.mean()
Kc=sum(float(am)*C for am,C in zip(a,Cm))
test('5-core amplitude Dirichlet formula',
     abs(np.sum(Kc*Kc)-(69/200)*sum((a[i]-a[j])**2 for i in range(5) for j in range(i+1,5)))<1e-11)
# The spectral-weight theorem is analytic; independently verify its finite
# eigenbasis decomposition for two distinct receiver Hamiltonians and η values.
for seed in (32,57):
    rr=np.random.default_rng(seed).standard_normal((30,30))
    HR=Prec@((rr+rr.T)/2)@Prec
    ew,U=np.linalg.eigh(HR)
    weights=np.sum((Kc.T@U)**2,axis=0)
    lhs=float(weights.sum())    # each Lorentzian integrates to 1 for every η>0
    rhs=float(np.sum(Kc*Kc))
    test(f'Feshbach full-line integrated spectral weight seed {seed}',
        abs(lhs-rhs)<1e-11,
        total_weight=lhs)

outfile=Path(__file__).with_name('Paper00-HilbertSchmidtChecksResults-v1_3.json')
summary={'artifact':outfile.name, 'source':'Paper00-PapersMinimal-v3_026.zip',
         'scope':'mathematical checks only; no physical action/decay certificate',
         'checks':checks,'passes':sum(v['passed'] for v in checks.values()),
         'failed':[k for k,v in checks.items() if not v['passed']]}
outfile.write_text(json.dumps(summary,indent=2))
print(json.dumps({'passes':summary['passes'],'failed':summary['failed'],'artifact':str(outfile)},indent=2))
