#!/usr/bin/env python3
"""Exact finite certificate for the Born--Hopf Petersen/Kneser closure.

Dependencies: Python 3 and NumPy. All incidence, projector, and Hodge
identities use signed integer matrices. The group action is enumerated
without floating point. No physical mass assertion is made.

Run: python3 Paper00-KneserClosure-v1_1.py
"""
from __future__ import annotations
from itertools import combinations, permutations
from math import comb
import json
import numpy as np


def parity(p):
    return (-1) ** sum(p[i] > p[j] for i in range(len(p)) for j in range(i + 1, len(p)))


def compose(p, q):
    return tuple(p[q[i]] for i in range(len(p)))


def inverse(p):
    return tuple(p.index(i) for i in range(len(p)))


def order(p):
    curr = tuple(range(len(p)))
    for j in range(1, 100):
        curr = compose(curr, p)
        if curr == tuple(range(len(p))):
            return j
    raise AssertionError('finite group order not found')


def fivefold_axis_action():
    """A5 acts by conjugation on its six Sylow-5 subgroups."""
    group = [p for p in permutations(range(5)) if parity(p) == 1]
    identity = tuple(range(5))
    sylows = set()
    for g in group:
        if order(g) != 5:
            continue
        subgroup = {identity}
        x = identity
        for _ in range(4):
            x = compose(x, g)
            subgroup.add(x)
        assert len(subgroup) == 5
        sylows.add(frozenset(subgroup))
    sylows = sorted(sylows, key=lambda s: repr(sorted(s)))
    assert len(group) == 60 and len(sylows) == 6
    actions = {}
    for g in group:
        gi = inverse(g)
        image = tuple(sylows.index(frozenset(compose(compose(g, x), gi)
                            for x in subgroup)) for subgroup in sylows)
        actions[g] = image
    assert len(set(actions.values())) == 60
    return group, sylows, actions


def orbits_on_subsets(actions, size, k):
    left = set(combinations(range(size), k))
    out = []
    while left:
        seed = min(left)
        orbit = {tuple(sorted(a[i] for i in seed)) for a in actions.values()}
        assert orbit <= left
        out.append(orbit)
        left -= orbit
    return sorted(out, key=lambda O: (len(O), min(O)))


def hodge_signed_odd_graph(k):
    """On Lambda^k(R^(2k+1)), S = *(c wedge -), B=i_c."""
    n = 2 * k + 1
    cols = list(combinations(range(n), k))
    rows = list(combinations(range(n), k - 1))
    col_index = {x: j for j, x in enumerate(cols)}
    row_index = {x: i for i, x in enumerate(rows)}
    N = len(cols)
    B = np.zeros((len(rows), N), dtype=np.int64)
    S = np.zeros((N, N), dtype=np.int64)
    for j, subset in enumerate(cols):
        for pos, _ in enumerate(subset):
            B[row_index[subset[:pos] + subset[pos + 1:]], j] = (-1) ** pos
        for missing in set(range(n)) - set(subset):
            t = tuple(sorted(subset + (missing,)))
            comp = tuple(v for v in range(n) if v not in t)
            i = col_index[comp]
            wedge_sign = (-1) ** sum(x < missing for x in subset)
            seq = t + comp
            hodge_sign = parity(seq)
            S[i, j] = wedge_sign * hodge_sign
    assert np.array_equal(S.T, ((-1) ** k) * S)
    assert np.array_equal(B @ S, np.zeros_like(B))
    identity = np.eye(N, dtype=np.int64)
    assert np.array_equal(B.T @ B + ((-1) ** k) * (S @ S), n * identity)
    assert np.array_equal(S @ S @ S, ((-1) ** k) * n * S)
    # Hermitian Dirac completion (with i*S for skew odd-k matrices).
    H = S.astype(np.complex128) * (1j if k % 2 else 1)
    D = np.block([[np.zeros((B.shape[0], B.shape[0]),dtype=complex),
                   B.astype(complex)], [B.T.astype(complex), H]])
    target = np.block([[B @ B.T, np.zeros((B.shape[0], N),dtype=np.int64)],
                       [np.zeros((N,B.shape[0]),dtype=np.int64), n*np.eye(N,dtype=np.int64)]])
    assert np.array_equal(D, D.conj().T)
    assert np.array_equal(D @ D, target.astype(complex))
    assert int(np.count_nonzero(S)) == N * (k + 1)
    # This is the unsigned adjacency of the odd graph KG(2k+1,k).
    for i, a in enumerate(cols):
        for j, b in enumerate(cols):
            assert (S[i, j] != 0) == (len(set(a) & set(b)) == 0)
    assert np.linalg.matrix_rank(B) == comb(2 * k, k - 1)
    assert np.linalg.matrix_rank(S) == comb(2 * k, k)
    return B, S, cols


def signed_gauge_equivalence(target, source):
    """Return epsilon and a diagonal gauge s with target=eps*G source G."""
    N = target.shape[0]
    assert np.array_equal(target != 0, source != 0)
    for factor in (1, -1):
        gauge = [None] * N
        gauge[0] = 1
        changed = True
        while changed:
            changed = False
            for i in range(N):
                if gauge[i] is None:
                    continue
                for j in range(N):
                    if source[i, j] and gauge[j] is None:
                        gauge[j] = int(gauge[i] * factor * target[i, j] * source[i, j])
                        changed = True
        if all(g is not None for g in gauge):
            G = np.diag(np.array(gauge, dtype=np.int64))
            if np.array_equal(target, factor * G @ source @ G):
                return factor, gauge
    raise AssertionError('signed matrices not gauge-equivalent up to sign')


def triangle_local_boundary(face, pair):
    a, b, c = face
    return {(a, b): 1, (a, c): -1, (b, c): 1}[tuple(pair)]


def main():
    group, sylows, actions = fivefold_axis_action()
    orbit_sizes = {k: [len(O) for O in orbits_on_subsets(actions, 6, k)]
                   for k in range(7)}
    assert orbit_sizes == {0:[1], 1:[6], 2:[15], 3:[10,10], 4:[15], 5:[6], 6:[1]}
    two_orbits = orbits_on_subsets(actions, 6, 3)
    pairs5 = list(combinations(range(5), 2))
    stab_pair = [g for g in group if tuple(sorted(g[i] for i in pairs5[0])) == pairs5[0]]
    assert len(stab_pair) == 6
    maps = []
    hodge_B, hodge_S, hodge_labels = hodge_signed_odd_graph(2)
    assert hodge_labels == pairs5
    closure = []
    for orbit in two_orbits:
        # Each orbit is a 2-(6,3,2) design on the six fivefold-axis labels.
        pair_counts = {p: sum(set(p) <= set(face) for face in orbit)
                       for p in combinations(range(6), 2)}
        assert set(pair_counts.values()) == {2}
        for v in range(6):
            link_edges = [tuple(sorted(set(face) - {v}))
                          for face in orbit if v in face]
            assert len(link_edges) == 5 and len(set(link_edges)) == 5
            degrees = {x: sum(x in e for e in link_edges)
                       for x in range(6) if x != v}
            assert set(degrees.values()) == {2}
            # A simple 2-regular graph on five vertices is C5.
        # The dual graph on ten triangular faces is Petersen.
        FACES = sorted(orbit)
        dual = np.zeros((10, 10), dtype=np.int64)
        for i, t in enumerate(FACES):
            for j, u in enumerate(FACES):
                if i != j and len(set(t) & set(u)) == 2:
                    dual[i, j] = 1
        assert np.array_equal(dual @ dual, 2 * np.eye(10, dtype=np.int64) - dual + np.ones((10,10), dtype=np.int64))
        fixed = [face for face in orbit if all(tuple(sorted(actions[g][x] for x in face)) == face for g in stab_pair)]
        assert len(fixed) == 1
        anchor = fixed[0]
        face_map = {}
        for pair in pairs5:
            targets = {tuple(sorted(actions[g][i] for i in anchor)) for g in group
                       if tuple(sorted(g[i] for i in pairs5[0])) == pair}
            assert len(targets) == 1
            face_map[pair] = next(iter(targets))
        assert set(face_map.values()) == orbit
        pedges = [(p,q) for p in pairs5 for q in pairs5
                  if p < q and not (set(p) & set(q))]
        assert len(pedges) == 15
        assert all((len(set(face_map[p]) & set(face_map[q])) == 2) ==
                   (not (set(p) & set(q)))
                   for p in pairs5 for q in pairs5 if p != q)
        # Each Petersen edge goes to exactly one K6 edge of the triangulation.
        projected_k6_edges = [tuple(sorted(set(face_map[p]) & set(face_map[q])))
                              for p,q in pedges]
        assert set(projected_k6_edges) == set(combinations(range(6), 2))
        # Edge/facet signed incidences: every local triangle has boundary zero.
        edge_index = {p:i for i,p in enumerate(pairs5)}
        F = np.zeros((15, 6), dtype=np.int64)
        boundary = np.zeros((10, 15), dtype=np.int64)
        signed = np.zeros((10,10), dtype=np.int64)
        for ei, (p,q) in enumerate(pedges):
            aa, bb = projected_k6_edges[ei]
            F[ei,aa] = 1
            F[ei,bb] = -1
            tp = triangle_local_boundary(face_map[p], (aa,bb))
            tq = triangle_local_boundary(face_map[q], (aa,bb))
            pi,qi = edge_index[p],edge_index[q]
            boundary[pi,ei] = tp
            boundary[qi,ei] = tq
            signed[pi,qi] = signed[qi,pi] = -tp*tq
        assert np.array_equal(boundary @ F, np.zeros((10,6),dtype=np.int64))
        assert np.array_equal(F.T @ F, 6*np.eye(6,dtype=np.int64) - np.ones((6,6),dtype=np.int64))
        assert np.array_equal(boundary @ boundary.T, 3*np.eye(10,dtype=np.int64) - signed)
        assert np.array_equal(signed @ signed @ signed, 5*signed)
        assert np.linalg.matrix_rank(boundary) == 10
        assert np.linalg.matrix_rank(F) == 5
        # Twisted cycle projector = root tight-frame projector.
        P_tw_num = F @ F.T
        assert np.array_equal(P_tw_num @ P_tw_num, 6*P_tw_num)
        assert np.array_equal(boundary @ P_tw_num, np.zeros((10,15),dtype=np.int64))
        factor,gauge = signed_gauge_equivalence(signed, hodge_S)
        maps.append((face_map, signed, factor, gauge))
        closure.append({'anchor_five_core_pair': [1,2],
                        'anchor_fivefold_axis_triangle': [a+1 for a in anchor],
                        'signed_Hodge_factor': factor,
                        'twisted_kernel_dim': 5,
                        'face_map': {f'{p[0]+1}{p[1]+1}': [x+1 for x in face_map[p]] for p in pairs5}})
    assert {maps[0][2],maps[1][2]} == {1,-1}
    assert all(set(maps[0][0][p]) == set(range(6))-set(maps[1][0][p]) for p in pairs5)
    # Odd graph signed Hodge series: exact integer identities up to k=4.
    hodge_checks = []
    for k in range(1,5):
        B, S, cols = hodge_signed_odd_graph(k)
        n = 2*k+1
        nullity = comb(2*k,k-1)
        split = comb(2*k,k)//2
        assert len(cols) == comb(n,k)
        hodge_checks.append({'k': k, 'n': n, 'graph': f'KG({n},{k})',
                             'vertices': len(cols), 'degree': k+1,
                             'signed_zero_multiplicity': nullity,
                             'positive_and_negative_multiplicity_each': split,
                             'spectral_nonzero_magnitude': f'sqrt({n})',
                             'signed_matrix_type': 'symmetric' if k%2==0 else 'skew-symmetric'})
    # Full (untwisted) Johnson/Kneser spectrum in representative cases.
    unsigned_checks = []
    for n,k in [(5,2), (6,2), (7,3), (9,4)]:
        subsets = list(combinations(range(n),k))
        a = np.array([[int(not (set(p)&set(q))) for q in subsets] for p in subsets],dtype=np.int64)
        expected = []
        for j in range(k+1):
            lam = (-1)**j * comb(n-k-j, k-j)
            multiplicity = comb(n,j) - (comb(n,j-1) if j else 0)
            expected.extend([lam]*multiplicity)
        assert len(expected) == len(subsets)
        actual = np.linalg.eigvalsh(a)
        assert np.allclose(actual,np.array(sorted(expected)),atol=1e-8)
        unsigned_checks.append({'graph': f'KG({n},{k})', 'eigenvalue_multiplicity':
                               {str(lam): expected.count(lam) for lam in sorted(set(expected))}})
    # No A5 transitive seven- or nine-point orbit (orbit-stabilizer).
    assert 60 % 7 != 0 and 60 % 9 != 0
    print(json.dumps({'certificate':'PASS', 'framework_branch':'one marked 2I, A5',
       'six_label_subset_orbits':orbit_sizes,
       'two_complementary_projective_planes':closure,
       'signed_Hodge_odd_graph_tests':hodge_checks,
       'unsigned_Kneser_spectrum_tests':unsigned_checks,
       'physical_particle_poles':'NOT_DERIVED',
       'seven_label_transitive_A5_orbit':'IMPOSSIBLE'},indent=2,sort_keys=True))

if __name__ == '__main__':
    main()
