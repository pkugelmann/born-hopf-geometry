"""Born--Hopf native two-source bridge v2_337.

Exact five-core/A5 and rooted-A4 representation tests, and an
A5-equivariant bilinear Petersen-edge transfer. The script does not
claim or fit physical hadron masses.
"""
import itertools, json
from collections import Counter
from pathlib import Path
import numpy as np
import sympy as sp

N = 5
PAIR = list(itertools.combinations(range(N), 2))
PAIR_ID = {p: i for i, p in enumerate(PAIR)}
EDGES = [(a, b) for a in range(10) for b in range(a+1,10)
         if set(PAIR[a]).isdisjoint(PAIR[b])]
assert len(EDGES) == 15
EDGE_ID = {ab: i for i, ab in enumerate(EDGES)}

PERMS = list(itertools.permutations(range(N)))
def sign_perm(p):
    return (-1)**sum(p[i]>p[j] for i in range(len(p)) for j in range(i+1,len(p)))
A5 = [p for p in PERMS if sign_perm(p)==1]
A4 = [p for p in A5 if p[0]==0]
assert len(A5)==60 and len(A4)==12

# A5 on the oriented 2-core label carrier, and on the 10 UNoriented labels.
def pair_mats(p):
    signed=sp.zeros(10); unsigned=sp.zeros(10)
    for a,(i,j) in enumerate(PAIR):
        raw=(p[i],p[j]); sign=1 if raw[0]<raw[1] else -1
        dst=PAIR_ID[tuple(sorted(raw))]
        signed[dst,a]=sign
        unsigned[dst,a]=1
    return signed,unsigned

# Existing Petersen edge module: oriented endpoint exchange on *unoriented*
# vertices; the second map is the subrepresentation of exterior^2 of the
# oriented 2-core module. The two are intertwined by an explicit diagonal sign.
def edge_mats(p):
    signed=sp.zeros(15); original=sp.zeros(15)
    for e,(a,b) in enumerate(EDGES):
        i,j=PAIR[a];k,l=PAIR[b]
        pa=(p[i],p[j]); pb=(p[k],p[l])
        sa=1 if pa[0]<pa[1] else -1
        sb=1 if pb[0]<pb[1] else -1
        aa=PAIR_ID[tuple(sorted(pa))];bb=PAIR_ID[tuple(sorted(pb))]
        orient=1 if aa<bb else -1
        dest=EDGE_ID[tuple(sorted((aa,bb)))]
        original[dest,e]=orient
        signed[dest,e]=orient*sa*sb
    return signed,original

# Levi-Civita source gauge for every Petersen edge.
EPS=[]
for a,b in EDGES:
    i,j=PAIR[a]; k,l=PAIR[b]
    missing=list(set(range(N))-{i,j,k,l})
    assert len(missing)==1
    EPS.append(int(sp.LeviCivita(missing[0],i,j,k,l)))
assert set(EPS)=={-1,1}
EPMAT=sp.diag(*EPS)

# The natural A5-equivariant projection from the exterior square of the
# *oriented pair module* to the Petersen edge submodule, 45 -> 15.
def wedge_to_edges(x,y):
    return sp.Matrix([x[a]*y[b]-x[b]*y[a] for a,b in EDGES])

r=0
# Root-invariant singlet w_r=e_r ^ (sum_{j != r} e_j)/2.
def root_vector(root):
    out=sp.zeros(10,1)
    for idx,(i,j) in enumerate(PAIR):
        if i==root: out[idx]=sp.Rational(1,2)
        elif j==root: out[idx]=-sp.Rational(1,2)
    return out
W=sp.Matrix.hstack(*[root_vector(i) for i in range(5)])
assert W.T*W==(5*sp.eye(5)-sp.ones(5,5))/4
assert W*sp.ones(5,1)==sp.zeros(10,1)

# Hodge/Petersen signed operator, as in v2_336.
S=sp.zeros(10)
for a,(i,j) in enumerate(PAIR):
    for b,(k,l) in enumerate(PAIR):
        missing=list(set(range(5))-{i,j,k,l})
        if len(missing)==1:
            S[a,b]=sp.LeviCivita(missing[0],i,j,k,l)
assert S**3==5*S
P4=sp.eye(10)-S**2/5
Pplus=(S**2/5+S/sp.sqrt(5))/2
Pminus=(S**2/5-S/sp.sqrt(5))/2
assert P4**2==P4 and Pplus**2==Pplus and Pminus**2==Pminus
assert P4*W==W and S*W==sp.zeros(10,5)
assert W*W.T==sp.Rational(5,4)*P4

# Group equivariance and existence/absence of invariant root scalar.
for g in A5:
    U,U0=pair_mats(g)
    V,V0=edge_mats(g)
    # Gauge equivalence of oriented-pair wedge and existing graph edge module.
    assert V==EPMAT*V0*EPMAT
    # Verify the 15 selected coefficients are an exact intertwiner:
    xx=sp.Matrix(range(1,11)); yy=sp.Matrix([i*i+1 for i in range(10)])
    assert wedge_to_edges(U*xx,U*yy)==V*wedge_to_edges(xx,yy)
    for root in range(5):
        assert U*W[:,root]==W[:,g[root]]
for g in A4:
    U,_=pair_mats(g)
    assert U*W[:,0]==W[:,0]
# Full A5 invariant vector projection is zero; rooted A4 invariant is rank one.
AvgA5=sum((pair_mats(g)[0] for g in A5),sp.zeros(10))/60
AvgA4=sum((pair_mats(g)[0] for g in A4),sp.zeros(10))/12
assert AvgA5==sp.zeros(10)
assert AvgA4==W[:,0]*W[:,0].T

# A4 character: 10 at identity, -2 for double transpositions, +1 3-cycles.
# This is 1 + 3 copies of the real tetrahedral three-dimensional irrep.
char_by_order={}
for g in A4:
    if all(g[i]==i for i in range(5)): order=1
    elif all(g[g[i]]==i for i in range(5)): order=2
    else: order=3
    chi=int(sp.trace(pair_mats(g)[0]))
    assert chi=={1:10,2:-2,3:1}[order]
    char_by_order.setdefault(order,[]).append(chi)
assert {i:len(arr) for i,arr in char_by_order.items()}=={1:1,2:3,3:8}
# Hom_A4(U, Q tensor G), given V_A's regular representation:
# U=1+3*(3); Reg(A4)=1+1'+1''+3*(3) => 1 + 9 = 10 dimensions.
hom_dim=1*1+3*3

# The symmetric quadratic map on the 6 non-root oriented pair amplitudes.
# Signs are the Pfaffian signs of the rooted four-element complement.
def q_sym(z):
    ab=lambda i,j:z[PAIR_ID[(i,j)]]
    return sp.Matrix([ab(1,2)*ab(3,4),-ab(1,3)*ab(2,4),ab(1,4)*ab(2,3)])
xx=sp.symbols('x0:10', real=True); Q=q_sym(xx)
three_perms=[]
for g in A4:
    U,_=pair_mats(g)
    Qout=q_sym(U*sp.Matrix(xx))
    perm=[]
    for qval in Qout:
        m=[j for j,v in enumerate(Q) if sp.expand(qval-v)==0]
        assert len(m)==1
        perm.append(m[0])
    assert sorted(perm)==[0,1,2]
    three_perms.append(tuple(perm))
assert len(set(three_perms))==3  # C3 quotient of A4
assert Counter(three_perms)=={(0,1,2):4,(1,2,0):4,(2,0,1):4}
# Fourier phases carry the missing 1' and 1'' characters.
# For real amplitudes these have strictly equal intensity.
w=sp.Rational(-1,2)+sp.sqrt(3)*sp.I/2
q0=(Q[0]+Q[1]+Q[2])/sp.sqrt(3)
qomega=(Q[0]+w**2*Q[1]+w*Q[2])/sp.sqrt(3)
qomegabar=(Q[0]+w*Q[1]+w**2*Q[2])/sp.sqrt(3)
assert sp.simplify(qomega-sp.conjugate(qomegabar))==0

# 2-source basis test: 15 Petersen edges produce 15 different nonzero outputs.
edge_outputs=[]
for a in range(10):
    for b in range(a+1,10):
        ea=sp.eye(10)[:,a]; eb=sp.eye(10)[:,b]
        z=wedge_to_edges(ea,eb)
        if set(PAIR[a]).isdisjoint(PAIR[b]):
            assert (z.T*z)[0]==1
            edge_outputs.append(z)
        else:
            assert z==sp.zeros(15,1)
assert len(edge_outputs)==15
assert sp.Matrix.hstack(*edge_outputs).rank()==15

# Root r retains 3 graph-edge directions; restricted character 3,-1,0.
root_edges=[e for e,(a,b) in enumerate(EDGES) if 0 not in set(PAIR[a])|set(PAIR[b])]
assert len(root_edges)==3
for g in A4:
    V0=edge_mats(g)[1]
    for e in root_edges:
        assert all(V0[j,e]==0 for j in range(15) if j not in root_edges)
    if all(g[i]==i for i in range(5)): order=1
    elif all(g[g[i]]==i for i in range(5)):order=2
    else:order=3
    assert int(sp.trace(V0.extract(root_edges,root_edges)))=={1:3,2:-1,3:0}[order]

# Coherent pair 1/sqrt(2)(e_a +- e_b) has precisely four exact Hodge
# fingerprints. Counts: 30, 30, 15, 15 among 90 ± combinations.
patterns=Counter()
for a in range(10):
 for b in range(a+1,10):
  for phase in (-1,1):
   vv=(sp.eye(10)[:,a]+phase*sp.eye(10)[:,b])/sp.sqrt(2)
   weights=tuple(sp.simplify((vv.T*P*vv)[0]) for P in (P4,Pplus,Pminus))
   patterns[weights]+=1
assert len(patterns)==4
assert sorted(patterns.values())==[15,15,30,30]

# Sharp universal symmetric quadratic phase bound for ||x||=1:
# |qomega| <= (|x12*x34| + |x13*x24| + |x14*x23|)/sqrt3
#           <= 1/(2 sqrt3), equality for a single coherent disjoint pair.
z=(sp.eye(10)[:,PAIR_ID[(1,2)]]+sp.eye(10)[:,PAIR_ID[(3,4)]])/sp.sqrt(2)
qtest=q_sym(z)
assert qtest==sp.Matrix([sp.Rational(1,2),0,0])
assert sp.simplify(((qtest[0]+w**2*qtest[1]+w*qtest[2])/sp.sqrt(3))*2*sp.sqrt(3))==1
# All three q components vanish for pure pair vectors or overlapping-basis
# two-pair superpositions.
for a in range(10):
 assert q_sym(sp.eye(10)[:,a])==sp.zeros(3,1)
for a in range(10):
 for b in range(a+1,10):
  if not set(PAIR[a]).isdisjoint(PAIR[b]):
   zz=(sp.eye(10)[:,a]+sp.eye(10)[:,b])/sp.sqrt(2)
   assert q_sym(zz)==sp.zeros(3,1)

# Exact double-exterior representation and 45 = 15 + 15 + 15 decomposition.
WEDGES=list(itertools.combinations(range(10),2))
WEDGE_ID={w:i for i,w in enumerate(WEDGES)}
DISJOINT=[i for i,(a,b) in enumerate(WEDGES)
          if set(PAIR[a]).isdisjoint(PAIR[b])]
OVERLAP=[i for i,(a,b) in enumerate(WEDGES)
         if len(set(PAIR[a])&set(PAIR[b]))==1]
assert len(DISJOINT)==15 and len(OVERLAP)==30
PD=sp.diag(*[int(i in DISJOINT) for i in range(45)])
PO=sp.eye(45)-PD

def rooted_wedge_basis_coefficient(i,j,k):
    """e_(ij) wedge e_(ik) relative to the sorted 45D wedge basis."""
    aa=PAIR_ID[tuple(sorted((i,j)))]
    bb=PAIR_ID[tuple(sorted((i,k)))]
    sign=(1 if i<j else -1)*(1 if i<k else -1)*(1 if aa<bb else -1)
    return WEDGE_ID[tuple(sorted((aa,bb)))],sign

# Root-local Hodge star on each 6D overlap-pair summand.
COMPL=sp.zeros(45)
for col,(a,b) in enumerate(WEDGES):
    shared=set(PAIR[a])&set(PAIR[b])
    if len(shared)!=1: continue
    root=next(iter(shared))
    j=next(iter(set(PAIR[a])-{root}))
    k=next(iter(set(PAIR[b])-{root}))
    _,s1=rooted_wedge_basis_coefficient(root,j,k)
    l,m=sorted(set(range(5))-{root,j,k})
    row,s2=rooted_wedge_basis_coefficient(root,l,m)
    COMPL[row,col]=s1*sp.LeviCivita(root,j,k,l,m)*s2
assert COMPL==COMPL.T and COMPL**2==PO and COMPL.trace()==0
Poverplus=(PO+COMPL)/2
Poverminus=(PO-COMPL)/2
assert PD+Poverplus+Poverminus==sp.eye(45)
for PP in (PD,Poverplus,Poverminus):
    assert PP==PP.T and PP**2==PP and PP.trace()==15
assert PD*Poverplus==sp.zeros(45)
assert Poverplus*Poverminus==sp.zeros(45)

def exterior_squared_oriented_pair_matrix(g):
    UU,_=pair_mats(g)
    mat=sp.zeros(45)
    for col,(a,b) in enumerate(WEDGES):
        aa=next(r for r in range(10) if UU[r,a])
        bb=next(r for r in range(10) if UU[r,b])
        s=(1 if aa<bb else -1)*UU[aa,a]*UU[bb,b]
        mat[WEDGE_ID[tuple(sorted((aa,bb)))],col]=s
    return mat

# Every one of the three 15-dimensional sectors has the exact character
# of the same A5 signed Petersen edge module from Paper V-A.
class_ledger={}
for gg in A5:
    DD=exterior_squared_oriented_pair_matrix(gg)
    assert DD*COMPL==COMPL*DD
    ch_edge=sp.trace(edge_mats(gg)[1])
    assert all(sp.trace(PP*DD)==ch_edge
               for PP in (PD,Poverplus,Poverminus))
    # Class ledger only: cycle-type, not 5A/5B separation (all traces zero).
    seen=set();cycle_lengths=[]
    for v in range(5):
        if v not in seen:
            w=v;n=0
            while w not in seen:
                seen.add(w);n+=1;w=gg[w]
            cycle_lengths.append(n)
    cycle_key=str(tuple(sorted(cycle_lengths,reverse=True)))
    class_ledger[cycle_key]=[int(ch_edge),class_ledger.get(cycle_key,[0,0])[1]+1]
assert dict(sorted(class_ledger.items()))=={
    '(1, 1, 1, 1, 1)':[15,1],
    '(2, 2, 1)':[-1,15],
    '(3, 1, 1)':[0,20],
    '(5,)':[0,24]}

# The actual two-source disjoint-pair map, normalized on the exterior-square
# input, is a PARTIAL ISOMETRY with squared singular values 1 (x15), 0 (x30).
# It can select channels but cannot by itself split pion/kaon rest energies.
raw_Petersen_disjoint_map=sp.zeros(15,45)
for row,wedge in enumerate(EDGES):
    raw_Petersen_disjoint_map[row,WEDGE_ID[wedge]]=1
assert raw_Petersen_disjoint_map*raw_Petersen_disjoint_map.T==sp.eye(15)
assert raw_Petersen_disjoint_map.T*raw_Petersen_disjoint_map==PD

# Canonical 5D Pfaffian/non-decomposability source P(x)=star(x wedge x).
# The 5 components are all root-complement 4D Pfaffians, with the
# exterior-square normalization: balanced orthogonal pairs give ||P||=1.
def pfaffian_five_vector(x):
    out=[]
    for root in range(5):
        aa,bb,cc,dd=sorted(set(range(5))-{root})
        get=lambda i,j:x[PAIR_ID[(i,j)]]
        pf=get(aa,bb)*get(cc,dd)-get(aa,cc)*get(bb,dd)+get(aa,dd)*get(bb,cc)
        out.append(2*sp.LeviCivita(root,aa,bb,cc,dd)*pf)
    return sp.Matrix(out)

source_x=sp.Matrix([2*i-7 for i in range(10)])
for gg in A5:
    UU,_=pair_mats(gg)
    perm5=sp.zeros(5)
    for i in range(5):perm5[gg[i],i]=1
    assert pfaffian_five_vector(UU*source_x)==perm5*pfaffian_five_vector(source_x)

# A simple, normalized rank-2 bivector yields zero Pfaffians.
# Choose a=(e0+e2)/sqrt2, b=(e1+e3)/sqrt2, x=a wedge b.
a5=(sp.eye(5)[:,0]+sp.eye(5)[:,2])/sp.sqrt(2)
b5=(sp.eye(5)[:,1]+sp.eye(5)[:,3])/sp.sqrt(2)
xsimple=sp.Matrix([a5[i]*b5[j]-a5[j]*b5[i] for i,j in PAIR])
assert (xsimple.T*xsimple)[0]==1
assert pfaffian_five_vector(xsimple)==sp.zeros(5,1)

# Balanced orthogonal 2-plane superposition is rank 4 and maximizes P.
xbalanced=(sp.eye(10)[:,PAIR_ID[(0,1)]]+sp.eye(10)[:,PAIR_ID[(2,3)]])/sp.sqrt(2)
assert (xbalanced.T*xbalanced)[0]==1
pfbal=pfaffian_five_vector(xbalanced)
assert pfbal==sp.eye(5)[:,4]
assert (pfbal.T*pfbal)[0]==1
# The sharp general inequality ||P(x)|| <= ||x||^2 follows from the
# orthogonal two-block normal form x=s1 e12+s2 e34, so ||P||=2|s1*s2|
# <= s1^2+s2^2=||x||^2. Rank 2 iff P=0, rank 4 iff P!=0.
assert sp.simplify(pfaffian_five_vector(sp.Matrix(xx))[0]-2*sum(Q))==0

# NOTE: the 15D SIGNED edge channel (alternating between two sources)
# differs from the 15D UNSIGNED quadratic channel; they should not be
# silently identified as physical source/color degrees of freedom.
patterns_txt=[{'weights':list(map(str,p)),'count':n} for p,n in sorted(patterns.items(),key=lambda z:(-z[1],str(z[0])))]
result={
 'status':'Exact finite geometry / no same-action meson Hamiltonian or mass spectrum derived',
 'baseline':'Paper00-PapersMinimal-v2_327.zip',
 'A5_order':len(A5),'root_A4_order':len(A4),
 'pair_carrier_dimension':10,'petersen_edge_carrier_dimension':15,
 'A5_oriented_pair_irreps':'4+3+3prime',
 'root_A4_pair_irreps':'1+3+3+3',
 'root_A4_comparison_QtensorG_irreps':'1+1prime+1doubleprime+3+3+3',
 'missing_linear_rooted_irreps':['1prime','1doubleprime'],
 'Hom_A4_oriented_pair_to_QtensorG_complex_dimension':hom_dim,
 'linear_A5_scalar_invariants':int(sp.trace(AvgA5)),
 'root_A4_scalar_invariants':int(sp.trace(AvgA4)),
 'root_frame_gram':'(5*I5-J5)/4',
 'root_frame_operator':'(5/4)*P4',
 'petersen_bilinear_edges':15,
 'petersen_bilinear_map_rank':15,
 'rooted_signed_edge_char_by_order':{'1':3,'2':-1,'3':0},
 'rooted_symmetric_quadratics':'x12*x34,-x13*x24,x14*x23',
 'rooted_quadratic_permutation_A4_quotient':'C3, each of 3 actions appears 4 times',
 'quadratic_phase_characters':'1+1prime+1doubleprime',
 'quadratic_phase_magnitude_max_unit_source':'1/(2 sqrt(3))',
 'phase_conjugacy_for_real_input':'|qomega|^2=|qomegabar|^2',
 'coherent_two_label_Hodge_patterns':patterns_txt,
 'root_pure_pair_Hodge_triplet_weight':0,
 'two_source_antisymmetric_dimension':45,
 'two_source_15_plus_15_plus_15':True,
 'each_15A5_irreps':'4+5+3+3prime',
 'A5_characters_by_cycle_type':class_ledger,
 'overlap_hodge_involution_spectrum':{'1':15,'-1':15,'0':15},
 'Petersen_disjoint_contact_spectrum':{'1':15,'0':30},
 'Pfaffian_five_source':'P(x)=star_5(x wedge x)',
 'Pfaffian_source_vanishes_iff':'rank of real 2-form <=2 (decomposable)',
 'Pfaffian_source_norm_bound':'||P(x)|| <= ||x||^2, equality for balanced orthogonal 2-planes',
 'Pfaffian_balanced_test':list(map(str,pfbal)),
 'has_physical_embedding':False,
 'has_action_derived_energy_operator':False,
 'has_ground_state_mass_predictions':False,
}
out=Path('/mnt/data/Paper00-NativeMesonBridge-v2_337-results.json')
out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print('ALL EXACT CERTIFICATES PASSED')
print('A5 invariant dim', result['linear_A5_scalar_invariants'],'A4 rooted invariant dim',result['root_A4_scalar_invariants'])
print('Bilinear map rank',15,'Hom complex dimension',hom_dim)
print('Double exterior 45 = 15 + 15 + 15; one rank-15 contact projector')
print('Pfaffian star(x wedge x): exact A5 covariance, rank-2 zero, rank-4 norm-one certificate')
print('Four Hodge fingerprints', patterns_txt)
print('Result file:',out)
