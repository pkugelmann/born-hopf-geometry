#!/usr/bin/env python3
"""Born–Hopf v2_333: exact Petersen occupancy couplings and fusion projectors.

Finite algebra only. No particle masses, empirical data, fitting, or physical
Hamiltonian are used. Run with NumPy and SymPy installed.

Work on A5 (60 points), unitarily equivalent to the center-even part of the
2I (120 points) function carrier. All matrix certificates use integer
arithmetic; SymPy is used only for rational spectral multiplicities.
"""
from collections import Counter
from fractions import Fraction
from itertools import combinations, permutations
import numpy as np
import sympy as sp

N=5
G=[p for p in permutations(range(N))
   if sum(p[i]>p[j] for i in range(N) for j in range(i+1,N))%2 == 0]
assert len(G)==60

def mul(p,q): return tuple(p[q[k]] for k in range(N))
def inv(p): return tuple(p.index(k) for k in range(N))
def cycle(p):
    seen=set(); lengths=[]
    for i in range(N):
        if i in seen: continue
        j=i; length=0
        while j not in seen:
            seen.add(j); length+=1; j=p[j]
        lengths.append(length)
    return tuple(sorted(lengths))

ch5={(1,1,1,1,1):5,(1,2,2):1,(1,1,3):-1,(5,):0}
ch4={(1,1,1,1,1):4,(1,2,2):0,(1,1,3):1,(5,):-1}
ch33={(1,1,1,1,1):6,(1,2,2):-2,(1,1,3):0,(5,):1}
rel=[[cycle(mul(inv(g),h)) for h in G] for g in G]
C=np.array([[ch5[c] for c in row] for row in rel], dtype=np.int64)
C4=np.array([[ch4[c] for c in row] for row in rel], dtype=np.int64)
C33=np.array([[ch33[c] for c in row] for row in rel], dtype=np.int64)
assert np.array_equal(C@C,12*C)
assert int(np.trace(C))==300  # P25=C/12, rank 25
I=np.eye(60,dtype=np.int64)

pairs=list(combinations(range(5),2))
def mask_for(pair,overlap):
    s=set(pair)
    return np.array([int(len(s&{g[pair[0]],g[pair[1]]})==overlap)
                     for g in G],dtype=np.int64)

def multiplicities_from_minpoly(A,roots):
    """Exact multiplicities, given verified minimal-polynomial roots."""
    x=sp.Symbol('x'); mom=[60]
    for k in range(1,len(roots)):
        mom.append(int(np.trace(np.linalg.matrix_power(A,k))))
    result={}
    for lam in roots:
        p=sp.Poly(sp.prod((x-mu)/(lam-mu) for mu in roots if mu!=lam),x)
        result[lam]=sp.factor(sum(p.nth(k)*mom[k] for k in range(len(roots))))
        assert result[lam].is_Integer and result[lam]>=0
    assert sum(result.values())==60
    return result

# The three marked-occupancy indicators leak from the 25 into 17 and 18.
# Character projectors are P1=J/60, P4=C4/15,
# P(3+3')=C33/20, P5=C/12.
expected={
    2:(Fraction(1,20),Fraction(3,5),Fraction(3,5),Fraction(5,4)),
    0:(Fraction(1,20),Fraction(6,5),Fraction(3,2),Fraction(11,4)),
    1:(Fraction(1,5),Fraction(9,5),Fraction(3,2),Fraction(7,2)),
}
for overlap in (2,0,1):
    ix=np.flatnonzero(mask_for(pairs[0],overlap))
    c=C[np.ix_(ix,ix)]
    ell1=Fraction(int(c.sum()),720)
    ell4=Fraction(int(np.sum(c*C4[np.ix_(ix,ix)])),180)
    ell33=Fraction(int(np.sum(c*C33[np.ix_(ix,ix)])),240)
    retained=Fraction(int(np.sum(c*c)),144)
    leakage=ell1+ell4+ell33
    assert (ell1,ell4,ell33,leakage)==expected[overlap]
    assert leakage+retained == Fraction(5*len(ix),12)
    print(f'Occupancy {len(ix)*2:3d} (2I): into 1={ell1}, 4={ell4}, '
          f'3+3prime={ell33}, total leakage={leakage}')

# For each pair S construct the rank-8 protected projector Q_S exactly.
# From the prior proven R_overlap spectrum {1^8,(3/4)^4,(1/3)^9,(1/4)^4},
# Q_S = 8 (R-3P/4)(R-P/3)(R-P/4).
# With R = C D C / 144, Q_S=L_S/36 for integer matrix L_S:
# 72 L_S = C D C D C D C - 16 C D C D C + 75 C D C - 108 C.
Ls=[]
for pair in pairs:
    d=mask_for(pair,1)
    CD=C*d[None,:]
    B=CD@C
    E=(CD@(C*d[None,:]))@C
    F=(CD@(C*d[None,:])@(C*d[None,:]))@C
    K=F-16*E+75*B-108*C
    assert np.all(K%72==0)
    L=K//72
    assert np.array_equal(L,L.T)
    assert np.array_equal(L@L,36*L)
    assert np.array_equal(C@L,12*L)
    assert np.array_equal(L@C,12*L)
    assert np.array_equal(d[:,None]*L,L)  # functions entirely on overlap set
    assert int(np.trace(L))==36*8
    Ls.append(L)
print('Ten Q_S=L_S/36 are exact rank-8 projectors supported on 72-strata')

# Fusion-frame operator T=sum Q_S. Integer F=18 T = sum L_S/2.
Lsum=sum(Ls)
assert np.all(Lsum%2==0)
F=Lsum//2
roots=[0,36,45,60,135]
poly=I.copy()
for k in roots:
    poly=poly@(F-k*I)
assert not np.any(poly)
ms=multiplicities_from_minpoly(F,roots)
assert ms=={0:36,36:10,45:4,60:6,135:4}
chi=np.array([ch5[cycle(g)] for g in G],dtype=np.int64)
assert np.array_equal(C@chi,12*chi)
assert not np.any(F@chi)
print('F=18T exact spectrum:',ms)
print('Restricted 25-spectrum T: 0(1), 2(10), 5/2(4), 10/3(6), 15/2(4)')
print('Kernel within 25 is exactly the invariant character line chi5')

# Petersen graph reappears as the Hilbert–Schmidt overlap graph of Q_S.
# Tr(Q_S Q_T)=Tr(L_S L_T)/1296; 18*Gram = 89 I_10 + A_P + 55 J_10.
A=np.array([[int(i!=j and len(set(pairs[i])&set(pairs[j]))==0)
             for j in range(10)] for i in range(10)],dtype=np.int64)
J=np.ones((10,10),dtype=np.int64); I10=np.eye(10,dtype=np.int64)
Gscaled=np.array([[int(np.trace(Ls[i]@Ls[j]))//72
                   for j in range(10)] for i in range(10)],dtype=np.int64)
assert np.array_equal(A@A,2*I10-A+J)
assert np.array_equal(Gscaled,89*I10+A+55*J)
print('18 Gram(Q_S) = 89 I + A_Petersen + 55 J: EXACT')

# Principal angle squares of two protected 8-planes:
# overlap-one pairs: {1^2, (1/4)^4, (1/36)^2};
# Petersen-adjacent/disjoint pairs: {1^3, (1/9)^1, 0^4}.
for j,expected_roots,expected_mult in [
  (1,[0,36,324,1296],{0:52,36:2,324:4,1296:2}),
  (7,[0,144,1296],{0:56,144:1,1296:3}),
]:
    Nprod=Ls[0]@Ls[j]@Ls[0]
    assert np.all(Nprod%36==0)
    Z=Nprod//36  # Z=1296 Q_S Q_T Q_S
    poly=I.copy()
    for lam in expected_roots:
        poly=poly@(Z-lam*I)
    assert not np.any(poly)
    assert multiplicities_from_minpoly(Z,expected_roots)==expected_mult
    print(f'Pair {pairs[0]} & {pairs[j]} intersection size '
          f'{len(set(pairs[0])&set(pairs[j]))}: exact eigenvalues (scaled) '
          f'{expected_mult}')
print('All v2_332 certificates included')

# v2_333: recovery of the original Petersen quadrupole projector.
# Here Gscaled=18 Gamma, with Gamma_{ST}=Tr(Q_S Q_T).
Pquad6=4*I10+2*A-J    # 6 times Paper I-A's rank-5 P_Petersen
assert np.array_equal(2*Gscaled-174*I10-111*J, Pquad6)
# Therefore P_Petersen = 6 Gamma - 29 I_10 - (37/2) J_10.
print('Original Petersen 5D quadrupole projector recovered EXACTLY from 8-plane overlaps')

# v2_333: inversion (g -> g^-1) grading of the fusion-frame spectrum.
Uinv=np.zeros((60,60),dtype=np.int64)
gindex={g:i for i,g in enumerate(G)}
for i,g in enumerate(G): Uinv[i,gindex[inv(g)]]=1
assert np.array_equal(Uinv@F,F@Uinv)
# Spectral projectors via the exact integer minimal polynomial of F.
x=sp.Symbol('x')
trace_moments=[int(np.trace(Uinv@np.linalg.matrix_power(F,k))) for k in range(5)]
signatures={}
for lam in roots:
    p=sp.Poly(sp.prod((x-mu)/(lam-mu) for mu in roots if mu!=lam),x)
    signatures[lam]=sp.factor(sum(p.nth(k)*trace_moments[k] for k in range(5)))
assert signatures=={0:12,36:10,45:4,60:-6,135:-4}
# The zero eigenspace is 35 dimensions outside P5 and one within P5.
# Under inversion, P5 has (15 even,10 odd), and outside has (23 even,12 odd).
assert int(np.trace(Uinv@C))==12*(15-10)
assert int(np.trace(Uinv))==16
print('Within 25, T symmetric: 0(1), 2(10), 5/2(4); '
      'antisymmetric: 10/3(6), 15/2(4): EXACT')

# The full unmarked conjugacy-class source algebra (v2_331) is generated by
# P5-compressed indicators of the five A5 conjugacy classes. T is central in it.
g5=next(g for g in G if cycle(g)==(5,))
class5a={mul(mul(h,g5),inv(h)) for h in G}
class5b={g for g in G if cycle(g)==(5,) and g not in class5a}
assert len(class5a)==len(class5b)==12
class_masks=[np.array([int(cycle(g)==cy) for g in G],dtype=np.int64)
             for cy in [(1,1,1,1,1),(1,2,2),(1,1,3)]]
class_masks.extend([
 np.array([int(g in class5a) for g in G],dtype=np.int64),
 np.array([int(g in class5b) for g in G],dtype=np.int64)])
assert np.array_equal(sum(class_masks),np.ones(60,dtype=np.int64))
for d in class_masks:
    compressed=C@np.diag(d)@C
    assert np.array_equal(F@compressed, compressed@F)
print('Fusion-frame T commutes with ALL FIVE compressed class-indicator generators: EXACT')
print('ALL v2_333 EXACT CERTIFICATES PASSED')
