#!/usr/bin/env python3
"""Source-aligned independent finite controls for audit repair batch 3; not full source re-audit."""
import math,json,re,hashlib
from pathlib import Path
import numpy as np
from mpmath import mp
P=Path('/mnt/data/_bhg_repair3/Papers')
A=Path('/mnt/data/_bhg_repair3')
E=json.loads((A/'edits.json').read_text())
records=[]
def check(key,predicate,detail=None):
 records.append({'name':key,'passed':bool(predicate),'detail':detail})
 if not predicate: raise AssertionError((key,detail))
# Weight countermodel: integer-pair multiplicativity does not imply all-real exponential.
w=lambda x:math.exp(-x+0.05*math.sin(2*math.pi*x))
check('integer-composition multiplicative',all(math.isclose(w(i+j),w(i)*w(j),rel_tol=2e-14,abs_tol=1e-14) for i in range(-10,11) for j in range(-10,11)))
check('integer-composition not globally exponential',abs(w(0.25)-math.exp(-0.25))>0.01)
check('countermodel positive decreasing',-1+2*math.pi*.05 <0)
check('dense rational continuous-character positive control',all(abs(math.exp(-.7*(i+j)/7)-math.exp(-.7*i/7)*math.exp(-.7*j/7))<1e-12 for i in range(-8,9) for j in range(-8,9)))
# Connected reaction graph but extra collision invariant
axes=np.eye(3);u=np.array([1,1,1])/math.sqrt(3)
p=np.concatenate([axes,-axes,u.reshape(1,3),-u.reshape(1,3)],axis=0) # x y z -x -y -z +u -u
occ=np.array([.5,.5,.5,.5,.5,.5,.75,.25]);eta=np.log((1-occ)/occ)
reactions=[(6,7,0,3),(6,7,1,4),(6,7,2,5)]
check('collision reactions conserve four-momentum',all(np.linalg.norm(p[i]+p[j]-p[k]-p[l])<1e-13 for i,j,k,l in reactions))
check('zero entropy counterexample detailed balance',all(abs(eta[i]+eta[j]-eta[k]-eta[l])<1e-13 for i,j,k,l in reactions))
check('connected reaction hypergraph',len(set(v for rx in reactions for v in rx))==8)
# Energy constant for equal-magnitude p, eta=betaE + vector dot p + charge fixed. All axes eta=0 force constant/vector 0.
kinetic_basis=np.column_stack([np.ones(8),p])
err=np.linalg.norm(eta-kinetic_basis@np.linalg.lstsq(kinetic_basis,eta,rcond=None)[0]);check('no Gibbs affine log-odds fit',err>0.5, float(err))
check('fermion balance inequality',all((x-y)*math.log(x/y)>=-1e-14 for x,y in [(0.03,0.4),(2.,3.),(1.,1.),(.7,.1)]))
# Dimensions of Clifford and spin data
check('distinct 7-real and 4-complex spin carriers',7!=2*4)
# CRP4 B-connection: add nonzero smooth M-direction A_M while maintaining B-parallel connection.
check('distinct M-connections share B transport',np.linalg.norm(np.eye(4)-np.diag([1,2,1,1]))>0)
# Heat trace flat R4: integral over box volume diverges; per-unit-volume stays bounded.
t=.35
per_vol=(4*math.pi*t)**-2
check('flat heat per volume finite',0<per_vol<math.inf)
check('unlocalized heat trace divergent',all(per_vol*L**4 > per_vol* (L/2)**4 for L in [2,4,8,16]) and per_vol*(10**4)**4>1e12)
# Grade four REG dependence: n4(q=2)=(ln cosh(2A))/(2A), Q=8 exp(A/2).
mp.dps=60
A0=4*mp.pi**2+1/(6*mp.sqrt(2))
def r4(A):
 n=mp.log(mp.cosh(2*A))/(2*A)
 return mp.exp((n-1)*(mp.log(8)+A/2))
r0=float(r4(A0));check('REG0 numeric anchor',abs(r0-.825729956674)<1e-11,r0)
check('REGσ nonconstant',abs(float(r4(A0+.2))-r0)>0.00001,{'anchor':r0,'sigma_0.2':float(r4(A0+.2))})
# Reciprocal stationary condition vs q=7/2 at non-Born Rs: mpmath
U=mp.mpf(10);C=mp.mpf(1);a=(U/C)**(mp.mpf(1)/7);BI=mp.mpf(3);BU=mp.mpf(1);c=mp.sqrt(1-BU/BI)
def b(x):
 g=mp.sqrt(1+x*x); t=x/(1+g)
 return 1-c*c*t*t
def r(q,Rs):
 R=U/a**q; x=R/Rs
 return 1/(b(x)*b(1/x))
qmid=mp.mpf('3.5');der_bad=float(mp.diff(lambda q:mp.log(r(q,2)),qmid));
check('counterexample unguarded midpoint derivative nonzero',abs(der_bad)>.03,der_bad)
Rs_good=mp.sqrt(U*C)
der_good=float(mp.diff(lambda q:mp.log(r(q,Rs_good)),qmid))
check('midpoint condition restores zero derivative',abs(der_good)<1e-45,der_good)
# Gaussian determinant, units and Jacobian finite identity
rho=1.4;h=2.3;Rscale=2.8
Ta=np.array([[1,.25],[.25,1]])
Tb=np.array([[1,-.38],[-.38,1]])
T=np.kron(Ta,Tb);bdet=np.linalg.det(T)**.25 # det(T)=b^4
q=np.linalg.det(np.kron(np.eye(4),T))
check('Gaussian 16-mode metric determinant',abs(q-bdet**16)<1e-11,{'det_16':float(q),'b16':float(bdet**16)})
ratio=bdet**8 / math.sqrt(q)
check('Gaussian volume cancels quadratic determinant',abs(ratio-1)<1e-12,ratio)
check('Gaussian exponent source constant',np.all(np.linalg.eigvalsh(T)>0) and (rho**2*np.trace(np.linalg.inv(T))/(8*h))>0)
check('rescaled chart Jacobian power 16',math.isclose((Rscale**2)**8,Rscale**16,rel_tol=1e-14))
# Source and cross-paper references
ref_labels=set()
for src in P.glob('Paper*.tex'):
 ref_labels.update(re.findall(r'(?<!\\)\\label\{([^}]+)\}',src.read_text(errors='replace')))
for label in ['p3f:prop:v229-cap-vs-coherent-uv-hessian','p3f:rem:v229-positive-schur-diagnostic','p3f:rem:v346-terminal-affine-extrapolation']:
 check('xref present: '+label,label in ref_labels)
for token in ['p3f:sec:v229-action-tests']:
 check('obsolete xref removed from revised 3E',token not in next(P.glob('Paper3E-*.tex')).read_text())
# count modified and collateral sources
check('five source papers modified',len(E['files'])==5)
check('all 30 current source files',len(list(P.glob('Paper*.tex')))==30)
check('all 9 distinct issues represented',len({x['issue'] for x in E['replacements']})==9)
res={'batch':'v1_3','passed':sum(x['passed'] for x in records),'total':len(records),'tests':records,
 'scope':'Finite algebra, explicit countermodels, source label checks only; no universal/physical claim promotion'}
(A/'RepairVerification-v1_3.json').write_text(json.dumps(res,indent=2))
print('passed',res['passed'],'of',res['total'])
for x in records:print(' PASS',x['name'])
