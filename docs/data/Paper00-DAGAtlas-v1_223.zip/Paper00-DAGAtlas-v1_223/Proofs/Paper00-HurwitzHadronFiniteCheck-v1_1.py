#!/usr/bin/env python3
"""Paper00-HurwitzHadronFiniteCheck-v1_1.py
Independent exact arithmetic (Q(sqrt(5))) finite 600-cell and Hurwitz incidence.
Input: marked H4 / 2T unit vertices.  No physical Hamiltonian assumed.
The 25-register chamber partition U is intentionally NOT certified here.
"""
import itertools
import json
import numpy as np

# Encode x=(a+b sqrt(5))/4 as (a,b), so all dot products have /16.
ZERO=(0,0)
def mul(p,q):
 a,b=p; c,d=q
 return (a*c+5*b*d,a*d+b*c)
def plus(p,q):return (p[0]+q[0],p[1]+q[1])
def neg(p):return (-p[0],-p[1])
def dot16(v,w):
 x=ZERO
 for a,b in zip(v,w):x=plus(x,mul(a,b))
 return x

def rank_mod(mat,p=101):
 a=(mat.astype(np.int64)%p).copy();m,n=a.shape;r=0
 for c in range(n):
  if r>=m:break
  loc=np.flatnonzero(a[r:,c])
  if not len(loc): continue
  i=r+int(loc[0]);a[[r,i],:]=a[[i,r],:]
  a[r,c:]=a[r,c:]*pow(int(a[r,c]),-1,p)%p
  js=np.flatnonzero(a[r+1:,c])+r+1
  if len(js):a[js,c:]=(a[js,c:]-a[js,c,None]*a[r,c:])%p
  r+=1
  if r==n:break
 return r

vertices=[]
for i in range(4):
 for sign in (-1,1):
  x=[ZERO]*4;x[i]=(4*sign,0);vertices.append(tuple(x))
for signs in itertools.product((-1,1),repeat=4):
 vertices.append(tuple((2*sign,0) for sign in signs))
for perm in itertools.permutations(range(4)):
 # 12 alternating permutations
 inversions=sum(perm[i]>perm[j] for i in range(4) for j in range(i+1,4))
 if inversions%2:continue
 for a,b,c in itertools.product((-1,1),repeat=3):
  entries=[ZERO,(2*a,0),(b,b),(-c,c)]
  vertices.append(tuple(entries[perm[i]] for i in range(4)))
assert len(vertices)==120 and len(set(vertices))==120
assert all(dot16(v,v)==(16,0) for v in vertices)

pairs=np.zeros((120,120),dtype=np.bool_)
for i in range(120):
 for j in range(i+1,120):
  if dot16(vertices[i],vertices[j])==(4,4):pairs[i,j]=pairs[j,i]=True
assert all(pairs.sum(axis=1)==12)
near=[set(np.flatnonzero(pairs[i])) for i in range(120)]
tetras=[]
for a in range(120):
 for b in sorted(x for x in near[a] if x>a):
  for c in sorted(x for x in near[a]&near[b] if x>b):
   for d in sorted(x for x in near[a]&near[b]&near[c] if x>c):
    tetras.append((a,b,c,d))
assert len(tetras)==600 and len(set(tetras))==600
T=np.zeros((600,120),dtype=np.int8)
for k,t in enumerate(tetras):T[k,list(t)]=1
assert np.array_equal(T.T@T,20*np.eye(120,dtype=np.int64)+5*pairs.astype(np.int64))
assert rank_mod(T)==120

# 24 Hurwitz unit quaternions = axes 8 + all 16 sign-halves.
H=vertices[:24]
edge=[]
for a in range(24):
 for b in range(a+1,24):
  if dot16(H[a],H[b])==(8,0):edge.append((a,b))
assert len(edge)==96
E=set(edge)
faces=[]
for a,b,c in itertools.combinations(range(24),3):
 if (a,b) in E and (a,c) in E and (b,c) in E:faces.append((a,b,c))
assert len(faces)==96
parts=[]
for v in H:
 if any(x[0] in (-4,4) for x in v):parts.append(0)
 else:parts.append(1 if sum(x[0]<0 for x in v)%2==0 else 2)
assert all({parts[v] for v in t}=={0,1,2} for t in faces)
which={e:i for i,e in enumerate(edge)}
M=np.zeros((96,96),dtype=np.int8)
for i,t in enumerate(faces):
 for a,b in itertools.combinations(t,2):M[which[(a,b)],i]=1
assert np.all(M.sum(axis=0)==3) and np.all(M.sum(axis=1)==3)
A=M.T@M-3*np.eye(96,dtype=np.int64)
assert np.all(np.diag(A)==0) and np.all(A.sum(axis=0)==6)
L=6*np.eye(96,dtype=np.int64)-A
assert np.array_equal(M.T@M+L,9*np.eye(96,dtype=np.int64))
assert rank_mod(M)==73
result={
    'claim_ids':['p1:thm:v365-600-cell-incidence','p1:thm:v365-hurwitz-face-laplacian'],
    'method':'exact Q(sqrt(5)) coordinate comparisons and modular Gaussian elimination over F_101',
    'vertex_count':len(vertices),'tetrahedron_count':len(tetras),
    'degree_600_vertex':int(pairs.sum(axis=1)[0]),
    'rank_T_mod_101':rank_mod(T),
    'TtT':'20I120+5Avert',
    'hurwitz_vertices':len(H),'hurwitz_edges':len(edge),'hurwitz_faces':len(faces),
    'face_graph_degree':int(A.sum(axis=0)[0]),'rank_M_mod_101':rank_mod(M),
    'nullity_M_real_from_S3_cell_chain':23,
    'MtM_plus_L':'9I96',
    'unverified_in_this_run':['25-chamber complement U','192-oriented Haar source orthogonality','physical SU(3) action-to-fan map'],
    'status':'PASS exact finite incidence (not E4 physical proof)',
}
print(json.dumps(result,indent=2))
