#!/usr/bin/env python3
"""Framework v2.339: exact five-core/Petersen/sl4 bridge (not a physics fit)."""
import itertools
from collections import Counter
import sympy as sp
n=5
E=sp.eye(n)
ones=sp.ones(n,1)
Q=E-ones*ones.T/n
b=[E[:,i] for i in range(n)]
verts=list(itertools.combinations(range(n),2))
edges=[(A,B) for a,A in enumerate(verts) for B in verts[a+1:] if set(A).isdisjoint(B)]
assert len(edges)==15
S_mats=[]
K_mats=[]
for A,B in edges:
    dA=b[A[0]]-b[A[1]];dB=b[B[0]]-b[B[1]]
    vA=b[A[0]]+b[A[1]]-sp.Rational(2,5)*ones
    vB=b[B[0]]+b[B[1]]-sp.Rational(2,5)*ones
    S=dA*dA.T-dB*dB.T
    K=vA*vB.T-vB*vA.T
    assert Q*S*Q==S and Q*K*Q==K and sp.trace(S)==0
    S_mats.append(S);K_mats.append(K)
S=sp.Matrix.hstack(*[M.reshape(25,1) for M in S_mats])
K=sp.Matrix.hstack(*[M.reshape(25,1) for M in K_mats])
assert S.rank()==9 and K.rank()==6 and sp.Matrix.vstack(S,K).rank()==15
assert S.T*K==sp.zeros(15,15)
assert S.T*S==sp.Matrix(S.T*S) and K.T*K==sp.Matrix(K.T*K)
assert (S.T*S).eigenvals()=={sp.Integer(25):4,sp.Integer(4):5,sp.Integer(0):6}
assert (K.T*K).eigenvals()=={sp.Integer(4):6,sp.Integer(0):9}
Phi=S+K
G=Phi.T*Phi
assert G.eigenvals()=={sp.Integer(25):4,sp.Integer(4):11}
P4=(G-4*sp.eye(15))/21
assert P4*P4==P4 and sp.trace(P4)==4
T=Phi*(sp.Rational(1,5)*P4+sp.Rational(1,2)*(sp.eye(15)-P4))
assert T.T*T==sp.eye(15)
# Verify full signed conjugation covariance for generating transposition and five-cycle.
edgelook={frozenset(pair):i for i,pair in enumerate(edges)}
for p in [(1,0,2,3,4),(1,2,3,4,0)]:
    P=sp.zeros(5)
    for i,ni in enumerate(p):P[ni,i]=1
    for j,(A,B) in enumerate(edges):
        AA=tuple(sorted(p[i] for i in A));BB=tuple(sorted(p[i] for i in B))
        k=edgelook[frozenset((AA,BB))]
        eps=1 if edges[k]==(AA,BB) else -1
        assert P*S_mats[j]*P.T==eps*S_mats[k]
        assert P*K_mats[j]*P.T==eps*K_mats[k]
# Enumerate A5; binary lift doubles every permutation in the incidence carrier.
def even(p):return sum(p[i]>p[j] for i in range(5) for j in range(i+1,5))%2==0
G60=[p for p in itertools.permutations(range(5)) if even(p)]
assert len(G60)==60
B=sp.zeros(60,25)
for a,p in enumerate(G60):
    for j in range(5):B[a,5*p[j]+j]=1
B120gram=2*B.T*B
assert B120gram.eigenvals()=={sp.Integer(120):1,sp.Integer(30):16,sp.Integer(0):8}
# Compare oriented Petersen and traceless-End(V) characters on every A5 element.
for p in G60:
    char_e=0
    for j,(A,Bb) in enumerate(edges):
        AA=tuple(sorted(p[i] for i in A));BB=tuple(sorted(p[i] for i in Bb))
        k=edgelook[frozenset((AA,BB))]
        if j==k:char_e += 1 if edges[k]==(AA,BB) else -1
    chi4=sum(p[i]==i for i in range(5))-1
    assert char_e==chi4*chi4-1
# Full diagonal projector finite-stratum check: group coefficient values for T columns.
strata=Counter()
profile={}
for p in G60:
    fix=sum(p[i]==i for i in range(5))
    vals=sp.Matrix([sum(T[5*p[j]+j,k] for j in range(5)) for k in range(15)])
    leverage=sp.cancel((vals.T*vals)[0]/30)
    assert leverage==sp.Rational(16-(fix-1)**2,120)
    profile.setdefault(fix,set()).add(leverage)
    strata[fix]+=2
assert strata==Counter({5:2,1:30,2:40,0:48})
assert profile=={5:{sp.S(0)},1:{sp.Rational(2,15)},2:{sp.Rational(1,8)},0:{sp.Rational(1,8)}}
assert sum(strata[fix]*next(iter(profile[fix])) for fix in strata)==15
print('PASS: Gram 120^1,30^16,0^8; Phi Gram 25^4,4^11; S rank9; K rank6')
print('PASS: S5-equivariant 15-operator construction; orthonormal sl4 basis; A5 character')
print('PASS: 2I source strata (count,rank15 leverage):')
for fix in [5,1,2,0]:print(' fixed',fix,':',strata[fix],next(iter(profile[fix])))
print('PASS: exact rank15 trace sum = 15')

# Character-kernel identity for all 60x60 pairs (each is doubled in 2I).
N=B*T
Gmat=N*N.T/30
for a,p in enumerate(G60):
    p_inv={j:i for i,j in enumerate(p)}
    chi_p=sum(p[i]==i for i in range(5))-1
    for c,q in enumerate(G60):
        chi_q=sum(q[i]==i for i in range(5))-1
        relative_fix=sum(p_inv[q[i]]==i for i in range(5))
        pred=sp.Rational(4*(relative_fix-1)-chi_p*chi_q,120)
        assert Gmat[a,c]==pred
print('PASS: all 3,600 entries of the 2I doubled-character projector kernel')
