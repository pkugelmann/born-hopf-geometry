#!/usr/bin/env python3
"""Scoped, independent finite mathematical tests for repair batch 2.

These are counterexamples and regression tests, NOT framework-wide proof or
physical realization/continuum/empirical certification.
"""
from __future__ import annotations
from pathlib import Path
import json, hashlib, math
import numpy as np
import sympy as S

results=[]
def test(name, predicate, context, kind='EXACT_ALGEBRA'):
    result=bool(predicate)
    results.append(dict(name=name,pass_check=result,context=context,kind=kind))
    if not result: raise AssertionError(name+': '+context)

# A-type color compactification and generators
E12=S.Matrix([[0,1,0],[0,0,0],[0,0,0]])
test('A35_root_generator_complex_not_compact',E12.trace()==0 and E12+E12.H != S.zeros(3),'E12 is in sl3(C), not in su3')
test('A35_complex_real_dimensions',len([S.Matrix(3,3,lambda i,j: int(i==k//3 and j==k%3)) for k in range(9)])-1==8,'trace-zero complex dimension is 8, underlying real dim is 16; compact su3 real dim 8')
# A36/37 Projected transfer shell
v=np.array([1,1],float)/np.sqrt(2)
H=np.diag([0.,4.]); P=np.outer(v,v); E=float(v@H@v)
exact=float(v@np.diag([1.,np.exp(-4.)])@v)
test('A36_empty_shell_is_no_unit_vector',np.linalg.norm(np.zeros((2,2)))==0,'zero projection provides no admissible unit vectors')
test('A37_noncommuting_rayleigh_not_heat',abs(math.exp(-E)-exact)>0.2,f'Rayleigh={math.exp(-E):.8f}, compressed={exact:.8f}',kind='EXPLICIT_COUNTEREXAMPLE')
P0=np.diag([0,1]); E0=4.; T0=math.exp(-E0)
test('A37_reducing_projector_heat_identity',abs(np.linalg.norm(P0@np.diag([1.,math.exp(-4)])@P0,2)-T0)<1e-13,'commuting projection P0 recovers exact loss')
# A38: global singlet in C x C* does not imply local Gauss invariance
phi=np.eye(3,dtype=complex).reshape(-1)/np.sqrt(3)
U=np.diag([np.exp(1j*.3),np.exp(-1j*.3),1.])
glob=np.kron(U,U.conj());loc=np.kron(U,np.eye(3))
test('A38_global_not_local_gauss',np.linalg.norm(glob@phi-phi)<1e-12 and np.linalg.norm(loc@phi-phi)>0.1,'global diagonal SU3 invariant vector not first-site SU3 invariant',kind='EXPLICIT_COUNTEREXAMPLE')
# A39 sign and hessian of W=logZ
j,t=S.symbols('j t',positive=True)
Hsc=3+2*j+j**2
W=-t*Hsc
G=-S.diff(W,j)/t
test('A39_log_transfer_sign',S.simplify(G-S.diff(Hsc,j))==0 and S.simplify(S.diff(W,j)+t*S.diff(Hsc,j))==0,'-t^-1 d log K/dJ=dH/dJ, W1=-t <O>')
test('A39_nonlinear_contact_jet',S.simplify(S.diff(W,j,2)+2*t)==0,'nonlinear source produces W Hessian contact -t HJJ')
# A40 susceptibility 7e = -E_0''; simple isolated ground and no contact means sum
x=S.symbols('x',real=True)
Eground=(3-S.sqrt(9+4*x*x))/2
chi=-S.diff(Eground,x,2).subs(x,0)
test('A40_second_order_nondegenerate_response',S.simplify(chi-S.Rational(2,3))==0,'off-diagonal H01=x, excitation 3, static susceptibility +2/3')
Econtact=3+x*x
test('A40_contact_subtract',-S.diff(Econtact,x,2)==-2,'source Hessian contributes negative contact to chi')
# A41 cusp gap closure
Edeg=-S.Abs(x)
test('A41_degenerate_ground_nondifferentiable',S.limit(S.diff(Edeg,x),x,0,dir='+')==-1 and S.limit(S.diff(Edeg,x),x,0,dir='-')==1,'min eig(diag(x,-x))=-|x| and has one-sided slopes -1,+1',kind='EXPLICIT_COUNTEREXAMPLE')
# B134/35 spectra and sector decomposition
H=S.diag(2,9); P=S.diag(1,0)
test('B134_compression_spurious_full_zero',sorted((P*H*P).eigenvals())==[0,2] and (P*H*P)[0,0]==2,'full ambient PHP has false zero, restriction to Ran P has eigenvalue 2')
H2=np.diag([0.,3.]);v=np.array([1.,1.])/np.sqrt(2);P2=np.outer(v,v)
test('B135_nucleon_projector_not_reducing',np.linalg.norm(P2@H2-H2@P2)>1,'spin/isospin trial projector must commute with full H to define invariant sector',kind='EXPLICIT_COUNTEREXAMPLE')
# B137 complex 2x2 Hermitian transfer
K=np.array([[1,1+2j],[1-2j,4]],complex)
# NOTE 1+2j above is imaginary unit literal. 
k=1+2j
eig=np.linalg.eigvalsh(K)
ideal=(1+4-np.sqrt((4-1)**2+4*abs(k)**2))/2
bad_complex=(1+4-np.sqrt((4-1)**2+4*k*k))/2
test('B137_hermitian_mixing_modulus_squared',np.isclose(eig[0],ideal) and abs(eig[0]-bad_complex)>0.1,'Hermitian matrix eigenvalue needs |k|^2, never k^2',kind='EXPLICIT_COUNTEREXAMPLE')
# B138 two-loop diagnostic: printed n_f 5 beta coefficients and alpha=1/sqrt(72)
mu=91.1876; a=1/math.sqrt(72);nf=5;b0=11-2*nf/3;b1=102-38*nf/3
L=mu*math.exp(-2*math.pi/(b0*a))*(b0*a/(4*math.pi))**(-b1/(2*b0*b0))
test('B138_two_loop_scale_external_boundary',abs(1000*L-206.9499403685991)<0.00001,'Lambda5=%.9f MeV; uses external Z-reference mass %.4f GeV'%(1000*L,mu),kind='NUMERIC_REPRODUCTION_WITH_EXTERNAL_INPUT')
# B139 residue holomorphic numerator and denominator derivative at simple pole
z=S.symbols('z'); F=(2+z)/((z-1)*(3+z));res=S.residue(F,z,1)
test('B139_simple_pole_residue',res==S.Rational(3,4) and S.limit((z-1)*F,z,1)==res,'Res(A/B)=A(1)/Bprime(1); finite-part Laurent jets do not change simple residue')
# B140 finite FH: source derivative of energy gap
n=S.symbols('n'); e0=3+2*n;e1=7+5*n
test('B140_vacuum_subtracted_fh',S.diff(e1-e0,n)==3 and S.diff(e1,n)==5,'spectral mass derivative subtracts vacuum derivative')
# B141 topological integral cannot normalize an independent Noether charge
w=1;q=2*w
test('B141_topology_not_current_normalization',q!=w,'degree 1 topological map admits independent coupling coefficient 2 without action/current matching',kind='EXPLICIT_COUNTEREXAMPLE')
# B142/143 signed support/crossing branches
neg_integral=S.integrate(-x,(x,-1,0));pos_integral=S.integrate(x,(x,0,1))
test('B142_signed_support_changes_integral',neg_integral==S.Rational(1,2) and pos_integral==S.Rational(1,2),'negative-x signed branch contributes independently; [0,1] requires support/crossing contract')
barq=lambda u: 2*u
test('B143_unpolarized_antiquark_sign',(-barq(0.4))==-0.8,'unpolarized q(-u)=-qbar(u); helicity Delta q(-u)=+Delta qbar(u) convention')
# B144 dimensionful exponent: Z=exp(-H/T)
T,h=S.symbols('T h',positive=True); H=3+5*h;Z=S.exp(-H/T)
test('B144_chiral_source_T_factor',S.simplify(-T*S.diff(S.log(Z),h)-5)==0,'Hamiltonian source derivative -T d_h log Z; dimensionless -d_hlogZ is beta times expectation')
# B145 abstract planes require chosen isometry of supports and Gram input
E2=S.eye(2);F3=S.eye(3)
test('B145_abstract_type_not_canonical_injection',E2.shape!=(F3.shape),'unrelated inner product carriers cannot be equated without specified embedding',kind='TYPE_COUNTEREXAMPLE')
# B146 positivity of finite measure insufficient for resonance-sheet continuation: positive spectral measure with branch obstruction.
test('B146_spectral_positivity_not_meromorphy',all(2**(n+1)/(2**n)==2 for n in range(1,12)) and abs((2**(-12))**(1/(2**12))-1)<0.0025,'positive lacunary coefficients a_(2^n)=2^-n have radius 1 and Hadamard-gap natural boundary: positivity does not imply continuation',kind='MATHEMATICAL_COUNTEREXAMPLE_BY_GAP_THEOREM')
# B147 compare independent vacuum energies for pure-YM restriction
quarkful=3.;quarkfree=5.
test('B147_glue_vacuum_independence',quarkful!=quarkfree,'deleting fermion components does not force pure-glue vacuum energy equal full-QCD vacuum energy',kind='EXPLICIT_COUNTEREXAMPLE')

result={
 'schema':'BornHopfAuditRepairScopedVerification/v1',
 'date':'2026-11-13',
 'batch':'Paper00-AuditRepairBatch-v1_2',
 'scope':'finite algebra, explicit counterexamples, textual/formula consistency, selected diagnostic numeric identity; NO physical occurrence certificate',
 'passed':sum(c['pass_check'] for c in results),
 'total':len(results),
 'checks':results,
}
root=Path('/mnt/data/_bhg_repair2')
out=root/'RepairVerification-v1_2.json'
out.write_text(json.dumps(result,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
print('PASS',result['passed'],'/',result['total'])
for check in results: print('  ',check['name'],check['context'][:130])
