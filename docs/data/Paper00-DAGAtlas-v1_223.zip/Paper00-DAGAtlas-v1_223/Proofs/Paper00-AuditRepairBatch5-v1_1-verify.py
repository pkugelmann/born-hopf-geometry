#!/usr/bin/env python3
"""Finite exact controls for repair batch 5. Scope: identities and counterexamples,
not independent E3 audit, constructor occurrence, or physical prediction."""
import json, hashlib, re
from pathlib import Path
from sympy import (symbols, Rational as R, Matrix, eye, sqrt, simplify, diff,
                   integrate, exp, I, sin, cos, conjugate, pi, diag)

root=Path(__file__).resolve().parent.parent
source_root=root/'Sources-v2_376'
tests=[]
def check(name, condition, note=''):
    ok=bool(condition)
    tests.append({'test':name,'passed':ok,'note':note})
    if not ok: raise AssertionError(name)

def eq(a,b): return simplify(a-b)==0

u,c,x = symbols('u c x', positive=True)
h_right=(x*x+u*c)/(u+c)
h_left=c
check('JUNC01 continuity at C',eq(h_right.subs(x,c),h_left))
check('JUNC02 left derivative zero',eq(diff(h_left,x),0))
check('JUNC03 right derivative',eq(diff(h_right,x).subs(x,c),2*c/(u+c)))
check('JUNC04 positive bulk Hessian', eq(diff(h_right,x,2),2/(u+c)))
check('JUNC05 positive Dirac jump',eq(diff(h_right,x).subs(x,c),2*c/(u+c)))
check('JUNC06 terminal constant Hessian zero',eq(diff(h_left,x,2),0))
# Exact weak distribution test with a compactly supported C^1 test function.
U,C=R(2),R(1)
phi=x*x*(3-x)**2
wp=-integrate((2*x/(U+C))*diff(phi,x),(x,C,3))
rhs=integrate((2/(U+C))*phi,(x,C,3))+(2*C/(U+C))*phi.subs(x,C)
check('JUNC07 integration by parts distribution', eq(wp,rhs))
check('JUNC08 polynomial glue no value jump',eq(h_right.subs({x:C,u:U,c:C}),C))

Q=symbols('Q',positive=True)
a,b=symbols('a b',real=True)
check('PORT01 positive character multiplicative',eq(Q**(a+b),Q**a*Q**b))
check('PORT02 character unit',eq(Q**R(1),Q))
check('PORT03 first actual protected carrier grade', set((2,3,4)).intersection({4,5,6})=={4})
Rvar=symbols('Rvar',positive=True)
check('PORT04 Born map involution',eq(U*C/(U*C/Rvar),Rvar))
check('PORT05 fixed point',eq((U*C/Rvar).subs(Rvar,sqrt(U*C)),sqrt(U*C)))

# Counterexample uses a nonscalar gauge kinetic metric on an exact raw stabilizer.
J=Matrix([[1,1]]); B=Matrix([[3]])
Qhalf=diag(2,1); Qminus=diag(R(1,2),1)
M=Qminus*J.T*B*J*Qminus
raw=Matrix([1,-1]); transported=Qhalf*raw
check('GAUGE01 raw stabilizer null',J*raw==Matrix([0]))
check('GAUGE02 canonical null transported',M*transported==Matrix([0,0]))
check('GAUGE03 canonical rank one',M.rank()==1)
check('GAUGE04 raw vector not generally canonical null',M*raw!=Matrix([0,0]))
check('GAUGE05 raw Gram kernel',J.T*B*J*raw==Matrix([0,0]))
check('GAUGE06 positive Gram', all(ev>=0 for ev in M.eigenvals().keys()))
check('GAUGE07 canonical dimension retained', len(M.nullspace())==len(J.nullspace())==1)
# Stationary invariant O(2) scalar potential: orbit tangent is a null Hessian.
y=symbols('y',real=True); t=symbols('t',real=True)
V=(x*x+y*y-1)**2
Hess=Matrix([[diff(V,x,2),diff(V,x,y)],[diff(V,y,x),diff(V,y,2)]])
Hess_at=Hess.subs({x:1,y:0}); Jorb=Matrix([0,1])
Bhhalf=diag(2,3); Bhminus=diag(R(1,2),R(1,3))
check('GAUGE08 Ward stationary scalar orbit zero',Hess_at*Jorb==Matrix([0,0]))
check('GAUGE09 scalar whitening commutes with Ward null',Bhminus*Hess_at*Bhminus*Bhhalf*Jorb==Matrix([0,0]))

up=R(2,3); down=R(-1,3)
flavors=[up,down,down,up,down,up]
for nf, expected in [(3,2),(4,R(10,3)),(5,R(11,3)),(6,5)]:
    check('CURRENT01 photon n_f='+str(nf),eq(3*sum(q*q for q in flavors[:nf]),expected))

# Massless full EW counterexample at sin^2(theta_W)=1/4, chi_Z=4/3.
# g_L=v+a, g_R=v-a (vector/axial convention).
s2=R(1,4);chi=R(4,3)
def couplings(charge,T3):
    v=T3-2*charge*s2; axial=T3
    return [v+axial,v-axial]
g_e=couplings(-1,-R(1,2));g_mu=g_e
G={'up':couplings(up,R(1,2)), 'down':couplings(down,-R(1,2)), 'mu':g_mu}
def F(charge,g):
    return sum(((-1)*charge+chi*ge*gf)**2 for ge in g_e for gf in g)/4
Fu=F(up,G['up']); Fd=F(down,G['down']); Fmu=F(-1,g_mu)
check('CURRENT02 exact up neutral weight',eq(Fu,R(46,81)))
check('CURRENT03 exact down neutral weight',eq(Fd,R(22,81)))
check('CURRENT04 exact muon neutral weight',eq(Fmu,R(10,9)))
check('CURRENT05 full ratio differs from photon six-flavor',eq(3*(3*Fu+3*Fd)/Fmu,R(34,5)))
check('CURRENT06 full ratio not 5', not eq(3*(3*Fu+3*Fd)/Fmu,5))
check('CURRENT07 photon limit',eq(sum(((-1)*up)**2 for _ in range(4))/4,up**2))

# Heisenberg charge derivative with explicit Planck units and a noncommuting Q.
hbar=R(2); H=diag(0,3); Obs=Matrix([[0,1],[1,0]])
rho=Matrix([[1,-I],[I,1]])/2
comm=H*Obs-Obs*H
D_direct=(I/hbar)*(rho*comm).trace()
Ut=diag(1,exp(-I*3*t/hbar))
rhot=Ut*rho*Ut.conjugate().T
D_evolved=diff((rhot*Obs).trace(),t).subs(t,0)
check('CHARGE01 unit-typed commutator identity',eq(D_direct,D_evolved))
check('CHARGE02 hbar omission demonstrably wrong',not eq(I*(rho*comm).trace(),D_evolved))
check('CHARGE03 Hermitian charge derivative real',eq(simplify(conjugate(D_direct)),D_direct))

tex3=source_root/'Paper3D-RunningResponse-v1_160.tex'
tex5=source_root/'Paper5C-InteractionResponse-v2_172.tex'
check('SOURCE01 current source 3D exists',tex3.is_file())
check('SOURCE02 current source 5C exists',tex5.is_file())
s3=tex3.read_text();s5=tex5.read_text()
check('SOURCE03 glued formula label',r'\label{p3d:eq:laurent-trace-glued-representative}' in s3)
check('SOURCE04 neutral-current label',r'\label{p7v2:eq:inclusive-neutral-current-born}' in s5)
check('SOURCE05 canonical whitened map explicit',r'Q_\rho^{1/2}\mathfrak g_h' in s5)
check('SOURCE06 charge has physical hbar',r'\frac{i}{\hbar}[H_{\rm phys},Q]' in s5)

payload={'scope':'finite exact mathematical checks and source assertions; not a physical implementation, complete theorem re-audit, or independent agent evidence',
         'test_count':len(tests),'passed':sum(t['passed'] for t in tests),'tests':tests}
out=Path(__file__).with_name('Paper00-AuditRepairBatch5-v1_1-results.json')
out.write_text(json.dumps(payload,sort_keys=True,indent=2)+'\n')
print('Scoped controls',payload['passed'],'/',payload['test_count'])
print('Results',out)
