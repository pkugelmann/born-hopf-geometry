#!/usr/bin/env python3
"""Born-Hopf F40 research-only exact verification, v1_11.

Requires sympy and the accompanying v1_10 verifier in the same directory.
No papers, canonical DAG, or physical Hamiltonians are edited/defined.
"""
from __future__ import annotations
import itertools as it
import runpy
from collections import Counter
from pathlib import Path
import sympy as sp

prior = runpy.run_path(str(Path(__file__).with_name('Paper00-PetersenHodgePlucker-v1_10-verify.py')))
V=prior['V']; E=prior['E']; pair=prior['pair']; pe=prior['pe']
q=prior['q']; quat_mul=prior['mult']; conjugate=prior['conjugate']; norm=prior['normalize']
shell=prior['shell']; quot=prior['quot']; T_R=prior['T']; P_Z=prior['Pcycle']
B=prior['B']; N=prior['N']; perms=prior['perms']; parity=prior['parity']; act=prior['act']
Aico=prior['Aico']; Ant=prior['Ant']; ei=prior['ei']; r=sp.sqrt(5)
assert len(E)==60 and len(shell)==12 and N.shape==(60,21)

# For each directed F40 edge, find the omitted fifth core of its underlying Petersen edge.
miss=[]
for v,w in E:
    remaining=set(range(5))-set(pair[v[0]])-set(pair[w[0]])
    assert len(remaining)==1
    miss.append(remaining.pop())
assert all(Counter(miss[e] for e,g in enumerate(quot) if g==h)==Counter(range(5)) for h in shell)
assert len({(quot[e],miss[e]) for e in range(60)})==60
print('PASS 1: F40 edges biject with 12 fivefold elements times 5 omitted core labels')

# Recover the action on the five actual conjugate tetrahedral cores from quaternion conjugation.
q3={(a,eta):norm(q[(a,eta,1)]) for a in range(10) for eta in (-1,1)}
reverse={u:a for (a,eta),u in q3.items()}
permaction={}
for g in shell:
    axmap={}
    for a in range(10):
        gg=norm(quat_mul(quat_mul(g,q3[a,1]),conjugate(g)))
        assert gg in reverse
        axmap[a]=reverse[gg]
    image=[]
    for i in range(5):
        intersection=set(range(5))
        for a in range(10):
            if i in pair[a]: intersection &=set(pair[axmap[a]])
        assert len(intersection)==1
        image.append(next(iter(intersection)))
    assert sorted(image)==list(range(5))
    seen=[]; j=0
    for _ in range(5):
        seen.append(j);j=image[j]
    assert len(set(seen))==5 and j==0
    permaction[g]=tuple(image)
assert len(permaction)==12
counts=Counter((i,perm[i]) for perm in permaction.values() for i in range(5))
assert len(counts)==20 and set(counts.values())=={3}
core_shell=sp.zeros(5)
for perm in permaction.values():
    for i in range(5):core_shell[perm[i],i]+=1
assert core_shell==3*(sp.ones(5)-sp.eye(5))
assert core_shell.eigenvals()=={sp.Integer(12):1,sp.Integer(-3):4}
print('PASS 2: shell elements act as 5-cycles; uniform shell core walk =3(J-I)')

# Actual A5 equivariance and regularity of the 60-edge group action.
identity=tuple(range(5)); even=[p for p in perms if parity(p)==1]
assert len(even)==60
shell_indices={g:i for i,g in enumerate(shell)}
for p in even:
    inverse=tuple(p.index(i) for i in range(5))
    fixed=0
    for e,(v,w) in enumerate(E):
        image=(act(v,p),act(w,p)); e2=ei[image]
        fixed+=(e2==e)
        assert miss[e2]==p[miss[e]]
        assert permaction[quot[e2]]==tuple(p[permaction[quot[e]][inverse[i]]] for i in range(5))
    assert fixed==(60 if p==identity else 0)
assert all({act(v,p) for p in even}=={w for w in V if w[2]==v[2]} for v in (V[0],V[-1]))
print('PASS 3: all 3,600 A5 edge incidences; 60-edge regular A5-set')

# Left quaternion quotient is equally native, with the same 12-element shell.
left=[norm(quat_mul(q[w],conjugate(q[v]))) for v,w in E]
assert set(left)==set(shell) and Counter(Counter(left).values())==Counter({5:12})
T_L=sp.zeros(12,60)
for e,g in enumerate(left):T_L[shell_indices[g],e]=1
assert T_L*T_L.T==5*sp.eye(12)
for p in even:
    for e,(v,w) in enumerate(E):
        e2=ei[act(v,p),act(w,p)]
        # The same 5-core permutation conjugates both left and right quotients.
        assert permaction[left[e2]]==tuple(p[permaction[left[e]][p.index(i)]] for i in range(5))
print('PASS 4: left and right quotient maps are shell-valued, 5-to-1 and A5-equivariant')

# Directed core-transition readout, indexed by the 20 ordered core pairs.
arcs=[(i,j) for i in range(5) for j in range(5) if i!=j]
arc_idx={v:i for i,v in enumerate(arcs)}
A=sp.zeros(20,60)
for e,g in enumerate(quot):
    i=miss[e];j=permaction[g][i]
    A[arc_idx[i,j],e]=1
assert A*A.T==3*sp.eye(20)
# Row- and column-balanced core transitions form an 11-dim space.
rows=sp.zeros(10,20);flip=sp.zeros(20)
for col,(i,j) in enumerate(arcs):
    rows[i,col]=1;rows[5+j,col]=1;flip[arc_idx[j,i],col]=1
assert rows.rank()==9 and (rows*A*N)==sp.zeros(10,21)
Q=sp.Matrix.hstack(*rows.nullspace()); assert Q.shape==(20,11)
P_bal=Q*(Q.T*Q).inv()*Q.T
assert (A*N).rank()==11
P_sym=(P_bal+flip*P_bal)/2;P_anti=(P_bal-flip*P_bal)/2
assert P_sym.rank()==5 and P_anti.rank()==6
assert A*P_Z*A.T==2*P_sym+P_anti
print('PASS 5: directed core response = doubly balanced 5 + (3+3prime), squared gains 2 and 1')

# Two-sided quotient interference on the twelve-element icosahedral shell.
C=T_R*P_Z*T_L.T
C_formula=-sp.Rational(9,4)*sp.eye(12)+Aico/2+Ant/4-sp.ones(12)/24
assert C==C_formula and C==C.T
assert T_L*P_Z*T_L.T==T_R*P_Z*T_R.T
sum_resp=(T_R+T_L)*P_Z*(T_R+T_L).T
diff_resp=(T_R-T_L)*P_Z*(T_R-T_L).T
assert sum_resp==sp.eye(12)+Ant-sp.ones(12)/6
assert diff_resp==10*sp.eye(12)-2*Aico
assert sum_resp.rank()==5 and diff_resp.rank()==11
print('PASS 6: left+right suppresses Hodge mirror; left-right contrast retains mirrors')

# All three native readouts together resolve exactly the 21-dimensional cycle space.
for M in (T_R,T_L,A):assert (M*N).rank()==11
for U,V2 in ((T_R,T_L),(T_R,A),(T_L,A)):
    assert (sp.Matrix.vstack(U,V2)*N).rank()==16
M3=sp.Matrix.vstack(T_R,T_L,A)
assert (M3*N).rank()==21
frame=(N.T*N).inv()*N.T*M3.T*M3*N
z=sp.Symbol('z')
assert sp.factor(frame.charpoly(z).as_expr())==(z-1)**5*(z*z-12*z+31)**3*(z*z-8*z+6)**5
assert sp.simplify(frame.det())==sp.Integer(31**3*6**5)
print('PASS 7: native triple reconstruction, frame (z-1)^5(z^2-12z+31)^3(z^2-8z+6)^5')

# The physically important same-cell block no-go follows without assuming H_L.
# In a subgroup H=2T, every quaternion has scalar part 0, +/-1/2 or +/-1;
# the shell scalar part (sqrt(5)-1)/4 does not occur. Thus gH is disjoint
# from H for any g in the shell, and no g fixes a coset xH (all are 5-cycles).
assert all(sp.simplify(g[0]-(r-1)/4)==0 for g in shell)
assert sp.simplify((r-1)/4-sp.Rational(1,2))!=0
assert sp.simplify((r-1)/4)!=0
print('PASS 8: shell has no same-core action on one 2T cell (group coset obstruction)')
print('ALL V1_11 RESEARCH CERTIFICATES PASSED; no physical QCD embedding constructed')
