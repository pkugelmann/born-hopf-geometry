#!/usr/bin/env python3
"""Independent finite/counterexample checks for BHG audit-repair batch 4.
Not a full theorem audit or a native physical-constructor certificate.
"""
from pathlib import Path
import json,hashlib,re,math
import numpy as np
from scipy.linalg import fractional_matrix_power
import mpmath as mp
ROOT=Path(__file__).parent
PAP=ROOT/'Paper00-PapersMinimal-v2_375'
checks=[]
def ck(name,ok,details=''):
 checks.append(dict(name=name,passed=bool(ok),detail=str(details)))
 if not ok:raise AssertionError(name+': '+str(details))
def tex(prefix):return next(PAP.glob(prefix+'*.tex')).read_text()
# IV-C truncated CCR and occupation-margin proof check.
def ann(N):
 a=np.zeros((N+1,N+1))
 for n in range(1,N+1):a[n-1,n]=np.sqrt(n)
 return a
N=8;a=ann(N);ad=a.T;Q=np.diag([1.]*5+[0.]*(N-4));nn=np.diag(np.arange(N+1))
ck('4C-102: total occupation margin keeps degree-four CCR identity',
 np.linalg.norm(Q@(a@a@ad@ad-ad@ad@a@a-(4*nn+2*np.eye(N+1)))@Q)<1e-10)
N=2;a=ann(N);ad=a.T;qq=np.diag([0.,1.,0.]);nn=np.diag(np.arange(N+1))
ck('4C-102 E4: compressed elementary defect is zero',np.linalg.norm(qq@(a@ad-ad@a-np.eye(N+1))@qq)<1e-10)
ck('4C-102 E4: higher CCR commutator fails at same compression',np.linalg.norm(qq@(a@a@ad@ad-ad@ad@a@a-(4*nn+2*np.eye(N+1)))@qq)>1)
ck('4C-102 source has intermediate-word condition', 'intermediate occupation excursions' in tex('Paper4C') and 'd_N' in tex('Paper4C'))
# m=1, ell(t)=1+|t| has positive freq not C1 at 0.
for t in [-0.1,0,0.1]:ck(f'4C-103: positive non-C1 frequency at t={t}',1+abs(t)>0)
lplus=(math.sqrt(1+1e-5)-1)/1e-5;lminus=(1-math.sqrt(1+1e-5))/1e-5
ck('4C-103 E4: non-differentiable frequency despite positive continuous Hessian',abs(lplus-lminus)>0.9)
ck('4C-103 C3-C1 input implies C1 omega', 'm\\in C^3(I)' in tex('Paper4C') and '\\ell\\in C^1(I)' in tex('Paper4C'))
# smooth nonautonomous unitary whose angle approaches nonzero limit, so no large-t recurrence
v=lambda t:np.exp(1j*math.pi/4*(1-math.exp(-t)))
ck('4C-104 E4: finite nonautonomous unitary has no remote recurrence',all(abs(v(t)-1)>0.4 for t in range(2,100)))
# density matrix of coherent path superposition and path-diagonal detector
rho=np.array([[0.5,0.5],[0.5,0.5]],dtype=complex)
E_diag=np.diag([1.,0.]);E_cross=np.array([[0.5,0.5],[0.5,0.5]])
ck('4C-105 E4: coherent state has nonzero offdiagonal path block',abs(rho[0,1])>0.49)
ck('4C-105 E4: diagonal detector has zero observed interference',abs(rho[0,1]*E_diag[1,0]+rho[1,0]*E_diag[0,1])<1e-12)
ck('4C-105 E3: other effect detects same coherence',abs(rho[0,1]*E_cross[1,0]+rho[1,0]*E_cross[0,1])>0.49)
# N=1 finite quadrature cumulant Q = c_1 X_1 + c_2 X_2, X_i +/-sigma
c1,c2=1.0,-2.0
var=c1*c1+c2*c2
moment4=c1**4+c2**4+6*c1*c1*c2*c2
ck('4C-106 E3: independent two-mode fourth cumulant is -2 sum c^4',abs(moment4-3*var*var+2*(c1**4+c2**4))<1e-12)
ck('4C-106 E4: zero coefficients give zero cumulants',abs(0.0)<1e-12 and 'not all zero' in tex('Paper4C'))
# III-C true flow-depth semantics: qsp = 7(1-exp(-tau))
qsp=lambda t:7*(1-math.exp(-t))
ck('3C-002 E4: flow time 1 is not depth 1',abs(qsp(1)-1)>3)
for j in range(1,7):
 tj=-math.log(1-j/7)
 ck(f'3C-002 E3: depth hit tau_{j}',abs(qsp(tj)-j)<1e-12)
alpha=math.exp(1.8);w=0.35;hchi=lambda q:alpha**(-w*q)
for j in range(1,7):
 tj=-math.log(1-j/7)
 ck(f'3C-002 E3: evaluated neutral character at tau_{j}',abs(hchi(qsp(tj))-hchi(j))<1e-12)
for j in range(1,7):
 ck(f'3C-002 E3: reflection J({j}) = 8-{j}',abs(hchi(j)*hchi(8-j)-hchi(4)**2)<1e-12)
ck('3C-001: nonexhaustive altered determinant measure accounted for','determinant/field measure' in tex('Paper3C') and 'not an exhaustive classification' in tex('Paper3C'))
ck('3C-003: local PCAD does not certify physical same-action source','does not independently' in tex('Paper3C') and 'conditional \\(K_{48}\\) Hessian' in tex('Paper3C'))
# V-B scalarized vs momentum curvatures
R=2.4;Kp=6/R**2; U=18/(math.pi*R**2)
ck('5B-112 E3: U=(3/pi)Kp',abs(U-(3/math.pi)*Kp)<1e-12)
ck('5B-112 E4: U != Kp',abs(U-Kp)>0.01)
ck('5B-112 E3: MP radius formula agrees on guarded cell branch',abs(8*math.sqrt(U)-8*math.sqrt(18/math.pi)/R)<1e-12)
# V-B charged Koide REG0 roots
mp.mp.dps=50
d=1/mp.sqrt(72);cl=mp.mpf('0.5')-2*d*d-mp.mpf(2)/3*d**3+mp.mpf(1)/4*d**4+mp.mpf(1)/8*d**5
C=1+cl;q=mp.mpf(9)/5+mp.mpf(3)/2*d**3;A8=(14+mp.mpf(1)/12)/8
B=A8*(4*mp.pi**2+1/(6*mp.sqrt(2)))
def F(delta,B=B):
 u=mp.exp(-B/2*(1/(C-delta)-1/(C+delta)))
 v=mp.exp(-B/2*(1/(C+q*delta**2)-1/(C+delta)))
 vm=2*(1+u)-mp.sqrt(3*(u*u+4*u+1))
 return v-vm
roots=[mp.findroot(F,(mp.mpf('.125314766'),mp.mpf('.125314769'))),mp.findroot(F,(mp.mpf('.377358233'),mp.mpf('.377358235')))]
for k,(got,exp) in enumerate(zip(roots, [mp.mpf('.125314767527813'),mp.mpf('.377358234148415')]),1):
 ck(f'5B-114 E3: REG0 root {k} reproduced',abs(got-exp)<mp.mpf('1e-11'),mp.nstr(got,24))
 ck(f'5B-114 E3: REG0 root {k} transverse',abs(mp.diff(F,got))>1,mp.nstr(mp.diff(F,got),15))
ck('5B-114: theorem scope anchored to REG0', 'at the anchored' in tex('Paper5B') and 'no two-root assertion' in tex('Paper5B'))
# V-B physical current polar distortion
Umat=np.eye(3)
E=Umat@np.array([[1,0,0],[1,1,0],[0,0,1]],dtype=float)
Gram=E.conj().T@E;W=E@fractional_matrix_power(Gram,-0.5)
ck('5B-115 E4: polar unitary remains an isometry',np.linalg.norm(W.conj().T@W-np.eye(3))<1e-12)
ck('5B-115 E4: polar normalizer changes unprotected muon ray',np.linalg.norm(W[:,1]-np.array([0,1,0]))>0.3)
ck('5B-115 E3: polar example column equals (-e+2mu)/sqrt5',np.linalg.norm(W[:,1]-np.array([-1,2,0])/np.sqrt(5))<1e-10)
E2=Umat@np.diag([2.,3.,4.]);W2=E2@fractional_matrix_power(E2.T@E2,-0.5)
ck('5B-115 E3: diagonal role Gram preserves incidence rays',np.linalg.norm(W2-Umat)<1e-12)
# V-B quark flow: beta=0 and nonzero gamma; beta=-a^2 and gamma=0.3 a
ck('5B-117 E4: stationary coupling permits running mass',abs(math.exp(-0.3*0.5)-1)>0.1)
a1=0.2;dt=0.5;a2=a1/(1+a1*dt);g=0.3
mscale=(1+a1*dt)**(-g);mchange=(a2/a1)**g
ck('5B-117 E3: dlogmu and coupling-variable RGE integrals agree when beta!=0',abs(mscale-mchange)<1e-12)
# Remaining source and label safeguards.
vb=tex('Paper5B')
ck('5B-111 raw tuple corrected Hcomp',r'\mathsf H_{\rm comp})' in vb and 'historical structural/comparison subtuple' in vb)
ck('5B-110 admissible membership not automatically inferred','No unverified physical half-line' in vb)
ck('5B-116 radical now historical only','no certified replacement' in vb and 'historical comparison' in vb)
ck('5B-117 beta nonzero guard','\\beta_S^{(n_f)}(a)\\neq0' in vb)
# Historical 3-paper label sets unchanged.
old=Path('/mnt/data/_bhg_repair3/Paper00-PapersMinimal-v2_374')
for id in ['Paper3C','Paper4C','Paper5B']:
 olds=next(old.glob(id+'*.tex')).read_text();news=tex(id)
 oa=re.findall(r'\\label\s*\{([^}]+)\}',olds);na=re.findall(r'\\label\s*\{([^}]+)\}',news)
 ck(f'{id}: unchanged current source label set and multiplicities',sorted(oa)==sorted(na),f'{len(oa)} labels')
result={'schema':'BHG_REPAIR4_SCOPED_CHECKS_V1','status':'PASS','passed':sum(x['passed'] for x in checks),'total':len(checks),'checks':checks,'scope':'finite independent E3/E4 controls + E0 source guards; not source-wide verification, no physical constructor occurrence certificate'}
file=ROOT/'Paper00-AuditRepairBatch4-v1_1-results.json';file.write_text(json.dumps(result,indent=2,default=str));print(f'PASS {len(checks)}/{len(checks)} scoped controls => {file}')
