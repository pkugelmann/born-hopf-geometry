from pathlib import Path
import math, numpy as np, random, json, sympy as sp, hashlib
root=Path('/mnt/data/_k48bound')
src=(root/'Paper6A.tex').read_text()
assert 'Paper VI-A v2.255' in src
out=src.replace('% Framework v2.377, Paper VI-A v2.255:', '% Framework v2.378, Paper VI-A v2.256:', 1)
out=out.replace('\\date{Version 2.255 --- 13 November 2026 \\\\ Framework v2.377}', '\\date{Version 2.256 --- 13 November 2026 \\\\ Framework v2.378}',1)
assert out!=src
needle='''\end{proof}

\paragraph{Physical application scope.}
These are closed mathematical proof steps on their stated native domains.'''
assert src.count(needle)==1,src.count(needle)
addition=r'''\end{proof}

\begin{corollary}[Sharp occupation-independent coherent-pair contact ceiling]
\label{p8:cor:v2256-k48-pair-contact-ceiling}
On the exact Dirac-pair domain of
Proposition~\ref{p8:prop:v2189-c06-CAR-upper}, for any rest mass
$m>0$, momentum magnitude $p\ge0$ and $E=\sqrt{p^2+m^2}$, the
least affine contact $b_1$ obeys the \emph{sharp, momentum-uniform} bound
\[
 \boxed{0\le b_1(p,m)\le\beta_*m,\qquad
 \beta_*:=\frac{\sqrt5-1}{2\sqrt{2+\sqrt5}}
 =0.3002831060\ldots.}
\]
Equality on the right holds at
\[
 \frac p m=\sinh\!\left(\frac12\log(2+\sqrt5)\right)
 =0.7861513778\ldots.
\]
Consequently, for any finite family of independently represented,
graded-even coherent Dirac-pair blocks on its admitted CAR carrier,
\[
 \boxed{\Theta_{\rm pair}=\sum_j T_{{\rm exc},j}
 \ \preceq\ H_{\rm pair}+\beta_*\sum_jm_j I,\qquad
 H_{\rm pair}:=\sum_j H_{{\rm exc},j}\succeq0.}
\]
The inequality holds for \emph{every} positive trace-one density
operator, including coherent and correlated pair states, without
computing any occupations. Massless blocks have the zero continuous
contact limit and may be included with $m_j=0$.

If the \emph{actual complete} action-owned homogeneous trace
insertion admits the stated exact decomposition on a retained chart,
\[
 \mathcal V\widehat\Theta
 =\Theta_{\rm pair}+\Theta_{\rm rem},
\]
with all scalar, projector, metric-derivative, connection, central,
interaction and remainder contacts included in the Hermitian
$\Theta_{\rm rem}$, its one-sided source obeys
\[
 \boxed{\frac{\mathcal S_T(q)}{U}
 \le\frac{\kappa}{3U\mathcal V(q)}
 \left(\operatorname{Tr}(\sigma(q)H_{\rm pair}(q))
 +\beta_*\sum_jm_j(q)
 +\lambda_{\max}(\Theta_{\rm rem}(q))\right).}
\]
If a finite supremum of this right side satisfies the one-sided stopping
criterion of Proposition~\ref{p8:prop:v2189-c06-one-sided-first-hit}
then applies on the same certified regular continuation domain.
This is a reduced \emph{conditional} first-hit execution certificate,
not a decomposition or numerical cap proved for the full occurring
K16/K48 source.
\end{corollary}
\begin{proof}
For $m>0$ write $p=m\sinh t$, $E=m\cosh t$, $t\ge0$.
The exact affine bound from the preceding proposition becomes
\[
 \frac{b_1}{m}=\frac{\sinh t}{\cosh t\,e^t}
 =\frac{y^2-1}{y(y^2+1)},\qquad y=e^t\ge1.
\]
Its derivative is
\[
 \frac{d}{dy}\frac{y^2-1}{y(y^2+1)}
 =-\frac{y^4-4y^2-1}{y^2(y^2+1)^2}.
\]
The unique critical point on $y\ge1$ is
$y=\sqrt{2+\sqrt5}$. The function vanishes at $y=1$ and at
infinity, so this point is its global maximum, with value
$\beta_*$. The sharp one-pair quadratic-form inequality of the
preceding proposition therefore yields
$T_{{\rm exc},j}\preceq H_{{\rm exc},j}+\beta_*m_jI$.
Adding inequalities on the admitted finite product carrier proves
the paired estimate without an independence assumption on the
\emph{state}; independence is required only for the operator-block
decomposition. Adding the unmodified Hermitian remainder, dividing
by the positive volume and taking positive-state expectations proves
the final source bound. There is no claim that the full physical
trace insertion has already been factored into these pair blocks.
\end{proof}

\begin{remark}[Size of the generated direct packet at K16, not a later-history bound]
\label{p8:rem:v2256-k48-direct-packet-diagnostic}
The exact direct boundary-packet normalization
$\rho_{\partial,16}=\Xi_{8\to16}\mathcal I_{16}$,
$\mathcal I_{16}=U^2\alpha^{-2}$ and the natural-unit identity
$\kappa U=4$ give
\[
 \boxed{\frac{\kappa\rho_{\partial,16}}{3U}
 =\frac43\Xi_{8\to16}\alpha^{-2}
 \le\frac43\alpha^{-2}
 \simeq5.396\times10^{-35}.}
\]
Under a separately established ordinary fluid realization with
$0\le p\le\rho/3$ this also bounds its \emph{instantaneous}
positive trace contribution at K16. The numerical comparison with
the conservative $10^{18}$ source ceiling is a scale diagnostic;
it neither bounds the complete contact/source operator nor transports
the K16 packet energy along the coupled sourced history. The
potentially sign-positive later exchange, coherent pair contact and
full $\Theta_{\rm rem}$ remain the first-K48 execution frontier.
\end{remark}

\paragraph{Physical application scope.}
These are closed mathematical proof steps on their stated native domains.'''
out=out.replace(needle, addition, 1)
assert out.count(r'\label{p8:cor:v2256-k48-pair-contact-ceiling}')==1
assert out.count(r'\label{p8:rem:v2256-k48-direct-packet-diagnostic}')==1
# file name with per-paper W increments by one
f=root/'Paper6A-GravityCosmology-v2_256.tex'
f.write_text(out)
# tests independent algebra + matrix spectrum
checks=[]
def check(name,x):
 checks.append((name,bool(x)))
 if not x: raise AssertionError(name)
Y=sp.symbols('Y',positive=True)
expr=(Y*Y-1)/(Y*(Y*Y+1))
check('derivative identity', sp.simplify(sp.diff(expr,Y)+(Y**4-4*Y**2-1)/(Y**2*(Y**2+1)**2))==0)
beta=(math.sqrt(5)-1)/(2*math.sqrt(2+math.sqrt(5)))
y_star=math.sqrt(2+math.sqrt(5))
p_star=(y_star-1/y_star)/2
check('exact maximum beta',abs(float(expr.subs(Y,y_star))-beta)<1e-14)
check('unique ystar >1',y_star>1)
check('maximum momentum',abs(p_star-0.7861513777574234)<1e-11)
for m,p in [(0.01,0.0),(1,0.0),(1,1e-12),(1,p_star),(1,1e3),(100,0.3),(100,100),(1,1e8)]:
 E=math.hypot(m,p)
 A=m*m/E; B=m*p/E
 H=np.diag([0,E,E,2*E])
 T=np.diag([0,A,A,2*A]);T[0,3]=B;T[3,0]=B
 # explicit spectrum and positive semidefinite eigenvalues of bound
 b=A-E+math.hypot(A-E,B)
 check(f'pair b1 exact m={m:g},p={p:g}', b<=beta*m+3e-12*max(1,m))
 check(f'pair affine PSD m={m:g},p={p:g}', np.linalg.eigvalsh(H+beta*m*np.eye(4)-T).min()>-3e-8*max(1,m))
 check(f'energy PSD m={m:g},p={p:g}',np.linalg.eigvalsh(H).min()>=-1e-14)
# 3 pair tensor test with correlated state and Hermitian remainder
I=np.eye(4)
ops=[]
for m,p in [(1,p_star),(.35,0.7),(3,20)]:
 E=math.hypot(m,p);A=m*m/E;B=m*p/E
 T=np.diag([0,A,A,2*A]);T[0,3]=B;T[3,0]=B
 H=np.diag([0,E,E,2*E]);ops.append((m,T,H))
L=np.zeros((64,64)); Htot=np.zeros((64,64)); mass_sum=0
for k,(m,T,H) in enumerate(ops):
 def lift(M):
  a=[I,I,I];a[k]=M
  return np.kron(np.kron(a[0],a[1]),a[2])
 L+=lift(T);Htot+=lift(H);mass_sum+=m
check('3-pair sharp operator certificate',np.linalg.eigvalsh(Htot+beta*mass_sum*np.eye(64)-L).min()>-1e-10)
rng=np.random.default_rng(20261113)
for k in range(12):
 u=rng.normal(size=64)+1j*rng.normal(size=64);u/=np.linalg.norm(u)
 check(f'correlated pure-state witness {k+1}', (u.conj()@(L@u)).real <= (u.conj()@(Htot@u)).real+beta*mass_sum+1e-10)
alpha=1.571958279122504e17
s_dir=4/(3*alpha**2)
check('direct packet ratio',abs(s_dir-5.395810710493451e-35)<1e-46)
v0=1.91412e-6; D=8.09e-35
scrit=v0*v0/(4*D)
check('comparison threshold scale',1.1e22<scrit<1.2e22)
# Explicit failure if a positive unbounded remainder omitted
R=np.diag([1e30,0,0,0]);m,p=1,p_star;E=math.hypot(m,p);A=m*m/E;B=m*p/E
T=np.diag([0,A,A,2*A]);T[0,3]=B;T[3,0]=B;H=np.diag([0,E,E,2*E])
check('remainder cannot be erased',np.linalg.eigvalsh(H+beta*m*np.eye(4)-(T+R)).min()<-1e20)
# exact sharpness: upper eigenvalue b1 at pstar
m=1;p=p_star;E=math.hypot(m,p);A=m*m/E;B=m*p/E
b=A-E+math.hypot(A-E,B)
check('beta sharp eigenvalue',abs(b-beta)<1e-13)
results={'date':'2026-11-13','scope':'mathematical pair certificate only; full K48 physical operator not evaluated','tests':len(checks),'passed':sum(x[1] for x in checks),'checks':dict(checks),'numeric':{'beta_star':beta,'p_over_m_at_max':p_star,'direct_packet_source_upper':s_dir,'first_hit_historical_half_stop_ceiling_with_hstar_omitted':scrit},'source_sha256':hashlib.sha256(out.encode()).hexdigest()}
(root/'Paper00-K48BoundBatch7-v1_1-results.json').write_text(json.dumps(results,indent=2))
(root/'Paper00-K48BoundBatch7-v1_1-verify.py').write_text(Path(__file__).read_text())
print('PASS',results['passed'],'/',results['tests'],'beta',beta,'direct',s_dir,'scrit',scrit,'source',f)
