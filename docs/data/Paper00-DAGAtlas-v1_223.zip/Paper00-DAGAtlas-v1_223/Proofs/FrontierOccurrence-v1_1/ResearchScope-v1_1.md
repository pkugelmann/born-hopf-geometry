# Research verifier scope v1.1

Source baseline PapersMinimal v3.067; previously researched v1.5 exact scalar comparison and finite-coordinate results. Executable mathematical identity checks: PASS (separate run with `OPENBLAS_NUM_THREADS=1`). Does **not** certify current source graphs at E3/E4, physical source selection, apparatus, or G0/GP2 occurrence.
