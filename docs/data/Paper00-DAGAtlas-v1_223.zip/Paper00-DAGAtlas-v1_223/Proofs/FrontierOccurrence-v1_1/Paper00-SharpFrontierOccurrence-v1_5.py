#!/usr/bin/env python3
"""Exact-formula/numerical replay of the coordinate-generated finite scalar test algebra.
The 120-vertex 600-cell is used only as the degree-11 cubature representation.
No test-token occurrence, detector model, or physical cutoff is assumed.
"""
import itertools
import numpy as np


def vertices_600cell():
    phi = (1+np.sqrt(5))/2
    v = []
    for a in range(4):
        for sg in [-1, 1]:
            p = np.zeros(4); p[a] = sg; v.append(p)
    for sg in itertools.product([-1,1], repeat=4):
        v.append(np.array(sg, dtype=float)/2)
    for p in itertools.permutations(range(4)):
        inversions = sum(p[i]>p[j] for i in range(4) for j in range(i+1,4))
        if inversions%2: continue
        for sg in itertools.product([-1,1], repeat=3):
            q = np.zeros(4)
            q[p[1]]=sg[0]/2
            q[p[2]]=sg[1]*phi/2
            q[p[3]]=sg[2]/(2*phi)
            v.append(q)
    a = np.array(v)
    assert a.shape==(120,4)
    assert np.allclose(np.sum(a*a,axis=1),1,atol=1e-13)
    assert len({tuple(np.round(q,12)) for q in a})==120
    return a


def harmonic_basis(vertices, max_k):
    gram=vertices@vertices.T
    u=[np.ones_like(gram),2*gram]
    for k in range(2,max_k+1):
        u.append(2*gram*u[-1]-u[-2])
    Q=[]
    for k in range(max_k+1):
        Ek=((k+1)/120)*u[k]
        w,v=np.linalg.eigh(Ek)
        assert np.count_nonzero(w>0.5)==(k+1)**2
        Q.append(v[:,w>0.5])
        assert np.linalg.norm(Ek@Ek-Ek)<2e-11
    combined=np.hstack(Q)
    assert np.linalg.norm(combined.T@combined-np.eye(combined.shape[1]))<1e-10
    return Q


def verify():
    vertices=vertices_600cell()
    basis=harmonic_basis(vertices,5)
    for K in range(1,6):
        Q=np.hstack(basis[:K+1]); dim=Q.shape[1]
        top=(K+1)**2; start=dim-top
        T=[Q.T@(vertices[:,j,None]*Q) for j in range(4)]
        S=sum(t@t for t in T)
        Htop=np.zeros((dim,dim)); Htop[start:,start:]=np.eye(top)
        c=(K+2)/(2*(K+1))
        leak=np.eye(dim)-S
        err=np.linalg.norm(leak-c*Htop)
        assert err<2e-11,(K,err)
        assert abs(np.trace(leak)-(K+1)*(K+2)/2)<2e-10
        assert abs(2*(1-c)/(2*c-1)-K)<1e-11
        prev=(K)**2
        connect=np.hstack([t[start:,start-prev:start] for t in T])
        sv=np.linalg.svd(connect,compute_uv=False)
        assert len(sv)==top and sv[-1]>0.1
        assert np.max(abs(sv**2-K/(2*(K+1))))<2e-11
        # Matrix-algebra induction: if the lower corner is already full,
        # the rank-top connecting words force all top/lower matrix units.
        radius=2.7
        SX=radius**2*S
        ew=np.linalg.eigvalsh(SX)
        ratio=ew[0]/ew[-1]
        inferred_K=2*ratio/(1-2*ratio)
        inferred_radius=np.sqrt(ew[-1])
        assert abs(inferred_K-K)<2e-10
        assert abs(inferred_radius-radius)<2e-10
        print('K',K,'dim',dim,'top',top,'leakage',round(c,12),
              'trace',round(float(np.trace(leak)),12),
              'max identity residual',f'{err:.3e}',
              'coupling min singular',round(float(sv[-1]),12))
    # A sparse Spin(4)-invariant frontier with a missing degree is reducible:
    Qs=np.hstack([basis[0],basis[1],basis[3]])
    d01=5
    Ts=[Qs.T@(vertices[:,j,None]*Qs) for j in range(4)]
    split=max(np.linalg.norm(T[:d01,d01:]) for T in Ts)
    assert split<2e-13
    # Inverse fixed-scale sharp-frontier consistency: level/radius histories
    # are readout inputs; this does not generate their physical occurrence.
    from math import floor, sqrt
    LF=1.7
    for a in (1.4,2.1,3.6,4.0,9.0):
        k=max(1,floor(sqrt(1+(a*LF)**2)-1))
        high=sqrt((k+1)*(k+3))/a
        assert LF<high+1e-12
        if k>=2:
            low=sqrt(k*(k+2))/a
            assert low-1e-12<=LF
    for n in range(2,9):
        entry_radius=sqrt(n*(n+2))/LF
        assert abs(sqrt(n*(n+2))/entry_radius-LF)<1e-12
    print('Sparse {0,1,3} shell gap: exactly disconnected, max edge residual',f'{split:.3e}')
    print('PASS: boundary shell, finite Toeplitz algebra, intrinsic K/radius readout, sparse-gap obstruction')



def verify_v13():
    """Check boundary Lie commutators, UCP links, POVM rank and blind spaces.

    The analytic proof is in the companion Markdown. This numerical replay
    uses the EXACT source 600-cell vertex coordinates (floating realization)
    as degree-11 cubature; it does not import observed physical data.
    """
    rng=np.random.default_rng(8421)
    vs=vertices_600cell()
    modes=harmonic_basis(vs,5)
    
    def cheb_u_derivative(k,t):
        if k==0: return np.zeros_like(t)
        lo=np.ones_like(t);dlo=np.zeros_like(t)
        hi=2*t;dhi=2*np.ones_like(t)
        if k==1: return dhi
        for n in range(2,k+1):
            new=2*t*hi-lo
            dnew=2*hi+2*t*dhi-dlo
            lo,dlo,hi,dhi=hi,dhi,new,dnew
        return dhi
    
    def continuous_harmonic_frame(k,N):
        # The 600-cell harmonics are reconstructed at arbitrary S3 points
        # via their band-limited spherical reproducing kernels.
        xx=rng.normal(size=(N,4))
        xx/=np.linalg.norm(xx,axis=1)[:,None]
        t=xx@vs.T
        un=[np.ones_like(t),2*t]
        for j in range(2,k+1): un.append(2*t*un[-1]-un[-2])
        return np.hstack([(j+1)/120 * un[j]@modes[j]
                          for j in range(k+1)])

    for K in range(1,6):
        Q=np.hstack(modes[:K+1]); D=Q.shape[1]; d=(K+1)**2
        T=[Q.T@(vs[:,a,None]*Q) for a in range(4)]
        top=modes[K]; derivative=cheb_u_derivative(K,vs@vs.T)
        cas=np.zeros((D,D)); maxerr=0
        for a in range(4):
            for b in range(a+1,4):
                comm=T[a]@T[b]-T[b]@T[a]
                kernel=((K+1)/120) * derivative * (
                    vs[:,a,None]*vs[None,:,b] - vs[:,b,None]*vs[None,:,a])
                L=top.T@kernel@top
                expected=np.zeros((D,D))
                expected[-d:,-d:]=L/(2*(K+1))
                maxerr=max(maxerr,float(np.linalg.norm(comm-expected)))
                if (a,b)==(0,1):
                    assert abs(np.linalg.norm(comm,ord=2)-K/(2*(K+1)))<1e-10
                cas+=-comm@comm
        P=np.zeros((D,D));P[-d:,-d:]=np.eye(d)
        leak=np.eye(D)-sum(X@X for X in T)
        c=(K+2)/(2*(K+1)); q=K*(K+2)/(4*(K+1)**2)
        assert maxerr<2e-11
        assert np.linalg.norm(leak-c*P)<2e-11
        assert np.linalg.norm(cas-q*P)<2e-11
        assert np.linalg.norm(cas-K/(2*(K+1))*leak)<2e-11
        if K<5:
            big=np.hstack(modes[:K+2]); Tbig=[big.T@(vs[:,a,None]*big)
                                            for a in range(4)]
            prod=sum(B[:D,:]@B[:,:D] - A@A
                     for A,B in zip(T,Tbig))
            assert np.linalg.norm(prod-c*P)<2e-11
        print(f'Boundary K={K}: Lie commutator residual {maxerr:.2e}, '
              f'Casimir coefficient {q:.12f}, CP defect {c:.12f}')

    for K in range(1,5):
        DD=(2*K+1)*(2*K+2)*(4*K+3)//6
        DK=(K+1)*(K+2)*(2*K+3)//6
        E=continuous_harmonic_frame(K,DD+25)
        # For real evaluation vectors e(x), rank of continuous POVM effects
        # is the rank of their real HS Gram |<e(x),e(y)>|^2.
        gram=(E@E.T)**2
        eig=np.linalg.eigvalsh(gram)
        rank=int(np.count_nonzero(eig>1e-9*eig[-1]))
        assert rank==DD, (K,rank,DD)
        blind=DK*DK-rank
        persistent=sum((k+1)**2*((k+1)**2-1)//2
                       for k in range(K+1))
        assert blind>=persistent
        print(f'Evaluation K={K}: dim={DK}, one-shot rank={rank}, '
              f'blind={blind}, f(Laplacian)-persistent >= {persistent}')

    # The rank-one Lüders Markov factorization is a symbolic identity:
    # sqrt(D|psi><psi|)=sqrt(D)|psi><psi|, so all repeated initial-state
    # effects are positive multiples of the FIRST evaluation effect.
    # Numerical check at k=2 using normalized coherent evaluation vectors.
    K=2; Q=np.hstack(modes[:K+1]); D=Q.shape[1]
    # Discrete 600-cell POVM (weights 1/120); each evaluation vector has norm 1 in Q-row units.
    psi=Q*np.sqrt(120/D)
    assert np.max(abs(np.sum(psi*psi,axis=1)-1))<1e-12
    x,y=5,37
    pstate=np.zeros((D,D));pstate[0,0]=1
    ex=D*np.outer(psi[x],psi[x]);ey=D*np.outer(psi[y],psi[y])
    sx=np.sqrt(D)*np.outer(psi[x],psi[x])
    pair=np.trace(sx@pstate@sx@ey)
    product=np.trace(pstate@ex)*D*abs(psi[x]@psi[y])**2
    assert abs(pair-product)<1e-12
    print('PASS: v1_3 finite Toeplitz Lie/Casimir, CP-nesting no-go, '
          'complete POVM blind ranks and Lüders factorization')

if __name__ == '__main__':
    verify()      # cumulative v1_2 checks
    verify_v13()  # new v1_3 checks


# ---- v1_4: exact analytical Lie-generation theorem, with independent finite replay ----

def _skew_control_lie_rank(Bs, tol=1.e-8):
    """Real Lie-closure by repeated ad-actions of the original controls.
    Reports dimension; not used to claim physical Hamiltonian occurrence.
    """
    d=Bs[0].shape[0]
    upper=np.triu_indices(d,1)
    Q=[]; matrices=[]
    def extend(A):
        v=A[upper].copy()
        # Two modified Gram-Schmidt passes for stable rank detection.
        for _ in range(2):
            if Q:
                Z=np.stack(Q)
                v-=Z.T@(Z@v)
        scale=np.linalg.norm(v)
        if scale<tol:return False
        v/=scale
        Q.append(v)
        C=np.zeros((d,d));C[upper]=v
        matrices.append(C-C.T)
        return True
    for B in Bs:extend(B)
    i=0
    while i<len(matrices):
        F=matrices[i]
        for B in Bs:extend(B@F-F@B)
        i+=1
    return len(Q)


def _hermitian_flat(X):
    d=X.shape[-1]
    u=np.triu_indices(d,1)
    return np.concatenate((np.diagonal(X,axis1=-2,axis2=-1).real,
                            np.sqrt(2)*X[...,u[0],u[1]].real,
                            np.sqrt(2)*X[...,u[0],u[1]].imag),axis=-1)


def verify_v14():
    V=vertices_600cell()
    harmonics=harmonic_basis(V,5)
    # The parity gauge maps each iT_a to a REAL skew generator.
    for K,expected in ((1,10),(2,91),(3,435)):
        Q=np.hstack(harmonics[:K+1]);d=Q.shape[1]
        T=[Q.T@(V[:,j,None]*Q) for j in range(4)]
        parity=np.concatenate([np.full((k+1)**2,k%2) for k in range(K+1)])
        w=np.where(parity==0,1.,1j)
        B=[(1j*w[:,None]*C*w.conj()[None,:]).real for C in T]
        assert all(np.linalg.norm(C+C.T)<2.e-11 for C in B)
        dimension=_skew_control_lie_rank(B)
        assert dimension==expected==d*(d-1)//2
        print(f'PASS v1_4 Lie K={K}: full so({d}), dimension {dimension}')

    # Primitive K=1: exact analytic basis (1, 2u1, ..., 2u4).
    sample=np.column_stack([np.ones(len(V)),2*V])
    assert np.linalg.norm(sample.T@sample/120-np.eye(5))<1.e-12
    T=[]
    for a in range(1,5):
        A=np.zeros((5,5));A[0,a]=A[a,0]=.5;T.append(A)
    # A pi pulse has its exact two-by-two submatrix -i*sigma_x.
    pulses=[np.eye(5,dtype=complex)]
    for a in range(1,4):
        P=np.eye(5,dtype=complex)
        P[0,0]=P[a,a]=0
        P[0,a]=P[a,0]=-1j
        pulses.append(P)
    ranks=[];arrays=[]
    for U in pulses:
        transformed=sample@U.T
        effects=np.einsum('ni,nj->nij',transformed,transformed.conj())
        arrays.append(_hermitian_flat(effects))
        ranks.append(int(np.linalg.matrix_rank(np.vstack(arrays),tol=1.e-9)))
    assert ranks==[14,21,24,25],ranks
    print('PASS v1_4 exact primitive pulse structure: ranks',ranks)

    # One positive finite 600-cell vertex yes/no effect suffices with
    # sufficiently many SO(5) controls, whereas parity-binned +/- sites
    # never distinguish the imaginary antisymmetric sector.
    x=sample[0]
    W=np.diag([1,1j,1j,1j,1j]);v=W@x
    E=np.outer(v,v.conj())/120.
    opposite=sample[np.argmin(np.linalg.norm(V+V[0],axis=1))]
    paired=np.outer(v,v.conj())+np.outer(W@opposite,(W@opposite).conj())
    assert np.linalg.norm(paired.imag)<1.e-12
    rng=np.random.default_rng(60221)
    one=[];binned=[]
    for _ in range(28):
        O,R=np.linalg.qr(rng.normal(size=(5,5)))
        if np.linalg.det(O)<0:O[:,0]*=-1
        one.append(_hermitian_flat(O@E@O.T))
        binned.append(_hermitian_flat(O@paired@O.T))
    assert np.linalg.matrix_rank(one,tol=1.e-9)==25
    assert np.linalg.matrix_rank(binned,tol=1.e-9)==15
    assert np.linalg.eigvalsh(np.eye(5)-E).min()>0
    print('PASS v1_4 one oriented binary effect orbit rank=25; antipodal-binned orbit rank=15')

    # Exact per-setting parity capacity; numerical random-group upper witnesses
    # only, not source-owned control histories or symbolic minimal certificates.
    from math import ceil
    for K in range(1,6):
        d=(K+1)*(K+2)*(2*K+3)//6
        even=sum((2*k+1)**2 for k in range(K+1))
        odd=sum((2*k+2)**2 for k in range(K))
        assert even+odd==(2*K+1)*(2*K+2)*(4*K+3)//6
        necessary=max(ceil((d*(d+1)//2-1)/(even-1)),
                      ceil((d*(d-1)//2)/odd))
        assert necessary=={1:3,2:5,3:8,4:13,5:19}[K]
        print(f'PASS v1_4 K={K} generic-setting necessary lower bound {necessary}')
    for K,needed in [(2,5),(3,8)]:
        Q=np.hstack(harmonics[:K+1]);d=Q.shape[1]
        parity=np.concatenate([np.full((k+1)**2,k%2) for k in range(K+1)])
        w=np.where(parity==0,1.,1j)
        state=Q*w[None,:]
        rng=np.random.default_rng(981 if K==3 else 27)
        frames=[]
        for _ in range(needed):
            O,_=np.linalg.qr(rng.normal(size=(d,d)))
            z=state@O.T
            E=np.einsum('ni,nj->nij',z,z.conj())
            frames.append(_hermitian_flat(E))
        sv=np.linalg.svd(np.vstack(frames),compute_uv=False)
        assert len(sv)>=d*d and sv[d*d-1]>1.e-6
        print(f'NUMERIC v1_4 K={K}: {needed} Haar-generic POVM settings rank {d*d}; '
              f'last singular={sv[d*d-1]:.7g}')
    print('PASS v1_4 Lie-control / oriented tomography / parity-inversion results')

if __name__=='__main__':
    verify_v14()

def verify_v14_action_hessian():
    """Exact rational cubic/quartic source Hessian on the F2 comparison;
    source parameters are illustrative rational mathematical witnesses ONLY.
    """
    from fractions import Fraction
    from math import isqrt
    import sympy as sp
    p = sp.symbols('u0:4')
    c=sp.Rational(1,5)
    q=[-sp.Rational(3,10),-sp.Rational(1,10),sp.Rational(3,20),sp.Rational(1,4)]
    assert sum(q)==0
    h=c+p[0]+sum(q[i]*p[i]**2 for i in range(4))
    potential_hessian=5+6*h+3*h*h

    def monomial_moment(exponents):
        if any(t%2 for t in exponents):return sp.Integer(0)
        num=sp.Integer(1)
        for t in exponents:
            for j in range(1,t,2):num*=j
        for j in range(sum(exponents)//2):num/=4+2*j
        return num
    def integ(poly):
        f=sp.Poly(sp.expand(poly),*p)
        return sp.factor(sum(coef*monomial_moment(exp)
                             for exp,coef in f.terms()))
    f=[sp.Integer(1)]+[2*x for x in p]
    H=sp.Matrix([[integ(f[i]*potential_hessian*f[j]) for j in range(5)]
                 for i in range(5)])+sp.diag(0,3,3,3,3)
    target=sp.Matrix([[sp.Rational(11386,1600),sp.Rational(5280,1600),0,0,0],
                      [sp.Rational(5280,1600),sp.Rational(16269,1600),0,0,0],
                      [0,0,sp.Rational(15373,1600),0,0],
                      [0,0,0,sp.Rational(16343,1600),0],
                      [0,0,0,0,sp.Rational(16759,1600)]])
    assert H==target

    # Rational enclosure of both algebraic eigenvalues using integer square roots.
    F=Fraction
    s_scale=10**12
    n=135357289
    lo=isqrt(n*s_scale*s_scale)
    assert lo*lo<=n*s_scale*s_scale<(lo+1)*(lo+1)
    slo=F(lo,s_scale); shi=F(lo+1,s_scale)
    lambdas=[(F(27655,1)-shi)/3200,(F(27655,1)-slo)/3200]
    eig_bounds=[((F(27655,1)-shi)/3200,(F(27655,1)-slo)/3200)]
    eig_bounds += [(F(15373,1600),F(15373,1600)),
                   (F(16343,1600),F(16343,1600)),
                   (F(16759,1600),F(16759,1600)),
                   ((F(27655,1)+slo)/3200,(F(27655,1)+shi)/3200)]
    assert all(ell>0 and hhi>=ell for ell,hhi in eig_bounds)
    assert all(eig_bounds[j][1]<eig_bounds[j+1][0] for j in range(4))

    # Purely integer/rational interval isolation of positive sqrt-eigenvalues
    # and all ten positive Bohr gaps. No floating-root comparisons are used.
    w_scale=10**10
    def root_bound(q):
        k=isqrt(q.numerator*w_scale*w_scale//q.denominator)
        assert F(k,w_scale)**2<=q<F(k+1,w_scale)**2
        return F(k,w_scale),F(k+1,w_scale)
    freq_bounds=[]
    for eiglo,eighi in eig_bounds:
        ll=root_bound(eiglo)[0]; hh=root_bound(eighi)[1]
        freq_bounds.append((ll,hh))
    assert all(freq_bounds[j][1]<freq_bounds[j+1][0] for j in range(4))
    gap_bounds=[]
    for j in range(5):
        for i in range(j):
            gap_bounds.append((freq_bounds[j][0]-freq_bounds[i][1],
                               freq_bounds[j][1]-freq_bounds[i][0],i,j))
    gap_bounds.sort(key=lambda x:x[0])
    assert len(gap_bounds)==10
    assert all(gap_bounds[j][1]<gap_bounds[j+1][0] for j in range(9))
    print('EXACT v1_4 action: rational 5x5 Hessian, five positive simple frequencies, '
          'ten disjoint positive-gap intervals')

    # Independent 120-node cubature replay, plus one-setting time-evolution
    # diagonal-intensity criterion: the two mixed basis functions and
    # u2/u3/u4 have independent square functions.
    V=vertices_600cell();basis=np.column_stack([np.ones(120),2*V])
    Q=np.diag(np.array([float(x) for x in q]))
    hN=float(c)+V[:,0]+np.einsum('ni,ij,nj->n',V,Q,V)
    hessian=5+6*hN+3*hN*hN
    KN=basis.T@(hessian[:,None]*basis)/120+np.diag([0,3,3,3,3])
    exactN=np.array(H,dtype=float)
    assert np.linalg.norm(KN-exactN)<3.e-13
    lam,psi=np.linalg.eigh(KN)
    assert np.min(lam)>0
    intensities=(basis@psi)**2
    assert np.linalg.matrix_rank(intensities,tol=1.e-9)==5
    assert np.abs(KN[0,1])>1 and np.linalg.norm(KN[1:2,2:])<1.e-12
    print('PASS v1_4 same-action quartic source Hessian; F1 source-only triple degeneracy '
          'and F2 background positive-frequency tomography witness')

if __name__=='__main__':
    verify_v14_action_hessian()


# v1_5: independent mathematical scalar nonlinear cascade and cubature checks
#!/usr/bin/env python3
"""Exact independent checks for native quartic scalar harmonic cascade.
Mathematical frozen-round scalar comparison only; NO physical occurrence inferred.
"""
from itertools import product, permutations, combinations
from fractions import Fraction
from dataclasses import dataclass
import sympy as sp
import numpy as np

x=sp.symbols('x')
u=sp.symbols('u0:4')
A,L,M,V,B=sp.symbols('A L M V B',nonzero=True)
U=lambda k,zz: sp.chebyshevu(k,zz)

# Exact first nonlinear leakage from a dipole, independent of spectral gap/mass.
assert sp.simplify(u[0]**2 - (sp.Rational(1,4)+ (u[0]**2-sp.Rational(1,4))))==0
assert sp.expand(u[0]**3-U(3,u[0])/8-u[0]/2)==0
assert sp.expand(U(2,x)**3-(U(0,x)+3*U(2,x)+2*U(4,x)+U(6,x)))==0

# P_6 of the quartic force for the exact prior v1_4 rational witness.
h=(sp.Rational(1,5)+u[0] -sp.Rational(3,10)*u[0]**2-sp.Rational(1,10)*u[1]**2
   +sp.Rational(3,20)*u[2]**2+sp.Rational(1,4)*u[3]**2)

def sphere_mean(p):
    pol=sp.Poly(sp.expand(p),*u)
    acc=sp.S.Zero
    for e,c in pol.terms():
        if any(x%2 for x in e):continue
        n=sum(e)//2
        acc+=c*sp.prod(sp.rf(sp.Rational(1,2),j//2) for j in e)/sp.rf(2,n)
    return sp.factor(acc)
assert sphere_mean(U(6,u[0])**2)==1
witness=sphere_mean(U(6,u[0])*h**3)
assert witness == -sp.Rational(81,70000), witness
assert sphere_mean(U(6,u[0])*h)==0
assert sphere_mean(U(6,u[0])*h*h)==0
assert sphere_mean(U(6,u[0])*U(2,u[0])**3)==1

# Independently evaluate the 120-cell alias from exact conjugacy-shell heights.
phi=(1+sp.sqrt(5))/2
samples=[(sp.S.One,1),(phi/2,12),(sp.Rational(1,2),20),(1/(2*phi),12),
         (sp.S.Zero,30),(-1/(2*phi),12),(-sp.Rational(1,2),20),(-phi/2,12),(-sp.S.One,1)]
raw120=sp.simplify(sum(c*U(6,t)*U(2,t)**3 for t,c in samples)/120)
assert raw120==2,raw120
# Degree 12 is outside the 120-node 11-design but inside 720-node 19-design.

# Explicit constructive 720-node numerical check without external geometry files.
phif=float(phi)
vs=[]
for aa in range(4):
 for sg in (-1,1):
  p=np.zeros(4);p[aa]=sg;vs.append(p)
for signs in product((-1,1),repeat=4):vs.append(np.array(signs,dtype=float)/2)
for perm in permutations(range(4)):
 if sum(perm[i]>perm[j] for i in range(4) for j in range(i+1,4))%2:continue
 for s in product((-1,1),repeat=3):
  p=np.zeros(4);p[perm[1]]=s[0]/2;p[perm[2]]=s[1]*phif/2;p[perm[3]]=s[2]/(2*phif);vs.append(p)
vs=np.asarray(vs);assert vs.shape==(120,4)
adj=np.isclose(vs@vs.T,phif/2,atol=1e-11)
facets=[]
for i in range(120):
 ns=[int(j) for j in np.flatnonzero(adj[i]) if j>i]
 for j,k,l in combinations(ns,3):
  if adj[j,k] and adj[j,l] and adj[k,l]:facets.append((i,j,k,l))
assert len(facets)==600
cs=np.array([vs[list(f)].sum(axis=0) for f in facets]);cs/=np.linalg.norm(cs,axis=1)[:,None]
fn=lambda ar:np.polynomial.chebyshev.chebval(ar, [0]) if False else None
# Recurrence evaluation of U_k.
def unum(k,t):
 p0=np.ones_like(t)
 if k==0:return p0
 p1=2*t
 for m in range(2,k+1):p0,p1=p1,2*t*p1-p0
 return p1
raw120_numeric=np.mean(unum(6,vs[:,0])*unum(2,vs[:,0])**3)
weighted720=np.sum(unum(6,vs[:,0])*unum(2,vs[:,0])**3)/504 + (2/1575)*np.sum(unum(6,cs[:,0])*unum(2,cs[:,0])**3)
assert abs(raw120_numeric-2)<1e-12
assert abs(weighted720-1)<2e-12,(raw120_numeric,weighted720)

# Exact pure-dipole leading time-Taylor recursion, in associated graded ring.
# With h(t,u)=sum_n t^{2n} h_n(u), the highest spatial polynomial degree
# of h_n is 2n+1 and is independent of mass/radius/cubic v term.
nmax=7
b=[sp.S.One]
for n in range(nmax):
 s=sum(b[i]*b[j]*b[n-i-j] for i in range(n+1) for j in range(n-i+1))
 b.append(sp.factor(s/((2*n+2)*(2*n+1))))
assert b[:5]==[1,sp.Rational(1,2),sp.Rational(1,8),sp.Rational(3,80),sp.Rational(7,640)]
assert all(t>0 for t in b)

# Independent full polynomial PDE recursion at a=1, A=2, lambda=1,
# mass=5, v=1: checks highest coefficients despite lower-degree competition.
mass=sp.Integer(5);lam=sp.Integer(1);vc=sp.Integer(1);av=sp.Integer(1);amp=sp.Integer(2)
hseries=[amp*x]
def lap(f):return sp.expand((1-x*x)*sp.diff(f,x,2)-3*x*sp.diff(f,x))
for n in range(5):
 sq=sum(hseries[i]*hseries[n-i] for i in range(n+1))
 cube=sum(hseries[i]*hseries[j]*hseries[n-i-j]
          for i in range(n+1) for j in range(n-i+1))
 hn=sp.expand((av*lap(hseries[n])-mass*hseries[n]-3*lam*vc*sq-lam*cube)/((2*n+2)*(2*n+1)))
 hseries.append(hn)
 assert sp.Poly(hn,x).degree()==2*n+3
 assert sp.Poly(hn,x).LC() == (-1)**(n+1)*b[n+1]*lam**(n+1)*amp**(2*n+3)

# Sharp linear instability threshold, not the test-frontier occurrence theorem.
mu=sp.symbols('mu',positive=True)
a=sp.symbols('a',positive=True)
for k in range(1,7):
 assert sp.solve(sp.Eq(k*(k+2)/a**2-mu**2,0),a)==[sp.sqrt(k*(k+2))/mu]

print('PASS: source v1_4 F2 Hessian example has full E6 residual',witness)
print('PASS: exact E6 U2^3 force coefficient 1; 120-node alias',raw120,'720-node',weighted720)
print('PASS: all 600 tetrahedral facets constructed and 720-node weighted source check')
print('PASS: pure dipole cubic harmonic cascade coefficients',b)
print('PASS: exact full wave-PDE Taylor recursion through temporal order 10')
print('PASS: sharp action-Hessian tachyonic shell threshold k(k+2)/a^2<mu^2')
print('SCOPE: finite quartic local scalar action on frozen round branch; mathematical, not physical occurrence')
