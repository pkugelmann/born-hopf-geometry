# Born–Hopf Geometry — Petersen occupancy leakage, protected 8-planes, and recovered overlap graph

**Version:** `v2_333`  
**Date:** 2026-11-06  
**Status:** Finite representation-theoretic statements proved by character algebra and an independent exact integer-matrix certificate. **No hadron masses or physical Hamiltonian derived.** This research note does **not** modify the canonical papers or DAG.

**Baseline:** `Paper00-PapersMinimal-v2_325(1).zip`, alongside `Paper00-PetersenIncidence-v2_330.md` and `Paper00-PetersenResponse-v2_331.md`.

**Source anchors:** Paper I-A `p1:thm:petersen-angular-quadrupole`; Paper V-B `p6:thm:cell-incidence`, `p6:thm:incidence-spectrum`; Paper VII-B `p11:prop:v323-actual-hadron-spectrum-criterion`, `p11:def:hadronic-eigenvalue-problem`. To reproduce, run `python Paper00-PetersenCouplings-v2_333.py` (NumPy and SymPy). The certificate uses 60-element `A5`, equivalent to the center-even half of the 120-element `2I` carrier. All asserted algebraic identities and spectral multiplicities are checked with exact integers/rationals, not tolerance-based numerical fits.

## 1. The invariant 17 + 25 + 18 decomposition

The center-even finite-function carrier admits the full orthogonal decomposition

\[
\mathcal H^+_{120}\cong\mathbb C[A_5]
=\mathcal H_{17}\oplus\mathcal H_{25}\oplus\mathcal H_{18},
\]

where `17 = 1²+4²`, `25 = 5²`, and `18 = 3²+(3')²`. The middle part is the five-dimensional irrep's matrix-coefficient space. With `C[g,h]=χ5(g⁻¹h)` on `A5`, its orthogonal projector is

\[
P_5=C/12,\qquad C^2=12C,\qquad\operatorname{tr}P_5=25.
\]

On the full `2I` carrier the corresponding kernel is `χ5(π(g)⁻¹π(h))/24` and vanishes on the 60 center-odd modes.

The other central coefficient projectors on `A5` are `P_1=J/60`, `P_4=K_4/15`, `P_{3\oplus3'}=K_{33}/20`, where `K_4[g,h]=χ4(g⁻¹h)` and `K_{33}[g,h]=(χ3+χ3')(g⁻¹h)`.

## 2. The fundamental obstruction to isolated 25-sector local occupancy

For any function `f:G→C` write `M_f` for diagonal multiplication by `f` on `C[G]`. Then

\[
\boxed{[P_5,M_f]=0\iff f\ \text{is constant}.}
\]

**Proof.** Matrix entries of the commutator are `(f(h)-f(g))P_5[g,h]`. On `A5`, `P_5[g,h]` is nonzero whenever `g⁻¹h` is a three-cycle (character `−1`). Since three-cycles generate `A5`, these equalities force `f` constant. On `2I`, `P_5[g,-g]=5/24` also forces `f(g)=f(-g)`, reducing the rest to the `A5` argument. Conversely, scalar multiplication commutes with every projector. □

This is a **no-go for treating nonuniform *diagonal* occupancy as an isolated 25-sector Hamiltonian**, not a no-go for all conceivable native transfer operators. Group convolutions commute with central `P_5` but are a different operator type.

## 3. Exact coupling strengths into the 17 and 18 sectors

For a marked two-subset `S`, define diagonal occupancy selectors `D_12`, `D_36`, `D_72` by the relationship between `S` and `gS`: same, disjoint, and overlap in one element. Their supports in `2I` have sizes `12, 36, 72` (or `6,18,36` in `A5`).

Define the squared Hilbert–Schmidt coupling into an orthogonal sector `V` by

\[
\mathcal L_{r\to V}=\|P_V D_r P_5\|_{\rm HS}^2
=\operatorname{tr}(P_5D_rP_VD_rP_5).
\]

These are dimensionless, basis-independent geometric norms—not physical transition probabilities, amplitudes, masses or rates. All values are **exact**:

| 2I stratum | Into `1` | Into `4` | Into `3` | Into `3′` | Into original `17` | Into remaining `18` | Total outside `25` |
|---|---:|---:|---:|---:|---:|---:|---:|
| 12 | 1/20 | 3/5 | 3/10 | 3/10 | **13/20** | **3/5** | **5/4** |
| 36 | 1/20 | 6/5 | 3/4 | 3/4 | **5/4** | **3/2** | **11/4** |
| 72 | 1/5 | 9/5 | 3/4 | 3/4 | **2** | **3/2** | **7/2** |

For an indicator `D_r²=D_r`, with `R_r=P_5D_rP_5|_{\operatorname{im}P_5}`,

\[
\| (I-P_5)D_rP_5\|_{\rm HS}^2
=\operatorname{tr}(R_r-R_r^2).
\]

The v2_331 spectra give the table's total-leakage values independently: `5/4`, `11/4`, `7/2`. The individual targets use the character-projector trace formula. For an `A5` stratum `X`, e.g.,

\[
\mathcal L_{X\to 4}
=\frac1{180}\sum_{g,h\in X}\chi_5(g^{-1}h)\chi_4(g^{-1}h),
\]

and similarly `1/720` with `χ1` and `1/240` with `χ3+χ3′`. The script verifies all entries exactly using integer sums and `fractions.Fraction`.

**A universal 3/3′ mirror rule.** For **any** diagonal Hermitian local source `M_f` (not just the three indicators),

\[
\boxed{\|P_3 M_f P_5\|_{\rm HS}^2
=\|P_{3'} M_f P_5\|_{\rm HS}^2.}
\]

Indeed, `χ3−χ3′` is supported only on the two five-cycle conjugacy classes, while `χ5` vanishes on both classes; consequently `χ5(χ3−χ3′)=0` pointwise. This is a trace-level coupling equality; it does **not** claim equal state-by-state masses or an experimentally observed isospin splitting.

## 4. A genuinely protected 8-plane for each Petersen marking

The prior exact compressed spectrum of the 72-selector is

\[
\operatorname{Spec}(R_{72})
=\{1^{(8)},(3/4)^{(4)},(1/3)^{(9)},(1/4)^{(4)}\}.
\]

Let `W_S` be its eigenspace of eigenvalue `1` within `im P5`. For `v∈W_S`, positivity of `D_72` yields `D_72 v=v`. Hence, because `D_12+D_36+D_72=I`, `D_12v=D_36v=0`. Thus `W_S` is exactly an **eight-dimensional simultaneous invariant subspace of P5 and the entire three-selector occupancy algebra**.

This is the only nonzero such subspace lying entirely in `im P5`: `R_12` and `R_36` have no eigenvalue `1`, so there are no `P5`-vectors supported entirely in either of their strata. The other 17 dimensions of `im P5` are not simultaneously reducing for all three diagonal selectors.

The spectral projector `Q_S` onto `W_S` is an explicitly computable **rational polynomial** in the geometric compression:

\[
\boxed{Q_S=8(R_{72}-\tfrac34P_5)(R_{72}-\tfrac13P_5)
(R_{72}-\tfrac14P_5).}
\]

The formula acts on all `C[A5]` with `P5=0` on the complement. Define `C` as above and let `D=D_72`. An integer certificate is

\[
Q_S=\frac{L_S}{36},\quad
72L_S=CDCDCDC-16CDCDC+75CDC-108C.
\]

Then directly, for each of the ten pairs,

\[
L_S^\mathsf T=L_S,\quad L_S^2=36L_S,\quad
CL_S=12L_S,\quad DL_S=L_S,\quad
\operatorname{tr}L_S=288.
\]

So each `Q_S` is provably an orthogonal rank-8 projector supported entirely on the overlap stratum. No floating-point diagonalization is involved.

## 5. Ten protected 8-planes collectively resolve exactly 24 dimensions

Form their positive fusion-frame operator

\[
T=\sum_{|S|=2}Q_S.
\]

The following is an **exact spectral identity**:

\[
\boxed{
\operatorname{Spec}(T|_{\mathcal H_{25}})=
\{0^{(1)},2^{(10)},(5/2)^{(4)},(10/3)^{(6)},(15/2)^{(4)}\}.
}
\]

As a reproducible exact certificate, `F=18T` is an integer `60×60` matrix and satisfies

\[
\boxed{F(F-36I)(F-45I)(F-60I)(F-135I)=0.}
\]

Spectral multiplicities on the *60-dimensional* carrier are `{0:36,36:10,45:4,60:6,135:4}`. The program obtains them from the integer traces `tr F^k` for `k=0,...,4` using exact Lagrange spectral projectors. The additional 35 zero modes are outside `im P5`.

The unique zero direction *within* the Petersen 25-sector is its conjugation-invariant character vector `χ5`:

\[
P_5\chi_5=\chi_5,\qquad T\chi_5=0,\qquad
\boxed{\operatorname{span}_{S}W_S
=\mathcal H_{25}\cap\chi_5^\perp.}
\]

Therefore

\[
25=1+24,\qquad \operatorname{rank}T=24.
\]

This 24 is canonically the traceless coefficient space `End₀(V5)`, not automatically the geometric 24-cell as a physical object. It is a new operator-level derivation, not a particle count.

## 6. Petersen graph reconstructed from overlaps of the 8-planes

For two distinct pair markings `S,T`, there are two possible relationships: intersection in one core (nonadjacent Petersen vertices), or disjoint pairs (adjacent vertices). The principal-angle spectra of their protected subspaces are *exact*:

| Relation | `cos² θ` principal-angle eigenvalues on `W_S` | Intersection dimension |
|---|---|---:|
| `|S∩T|=1` (nonadjacent) | `1` (×2), `1/4` (×4), `1/36` (×2) | 2 |
| `S∩T=∅` (adjacent) | `1` (×3), `1/9` (×1), `0` (×4) | 3 |

These follow from exact integer polynomial identities for `Z=1296 Q_SQ_TQ_S` on the 60 carrier. In the two cases, respectively,

- `Z(Z-36I)(Z-324I)(Z-1296I)=0` with multiplicities `(52,2,4,2)`;
- `Z(Z-144I)(Z-1296I)=0` with multiplicities `(56,1,3)`.

The `A5` action is transitive on each relation class, so one representative of each suffices. The script checks the polynomial identities, exact traces, and resulting multiplicities.

Even more compactly, the Hilbert–Schmidt Gram matrix

\[
\Gamma_{ST}=\operatorname{tr}(Q_SQ_T)
\]

satisfies

\[
\Gamma_{SS}=8,\quad
\Gamma_{ST}=\begin{cases}
28/9,& S\cap T=\varnothing,\\
55/18,& |S\cap T|=1,
\end{cases}
\]

and therefore

\[
\boxed{18\Gamma=89I_{10}+A_{\rm Petersen}+55J_{10}.}
\]

Equivalently,

\[
\boxed{A_{\rm Petersen}=18\Gamma-89I_{10}-55J_{10}.}
\]

This is a **second, internal realization of the Petersen graph**, reconstructed solely from the overlap of canonical eight-dimensional subspaces of the 120-element carrier, instead of from ten Hopf axes or labeled 2-subsets. Its Gram eigenvalues are `107/3` (×1), `5` (×5), `29/6` (×4), all strictly positive. The exact integer check is `tr(L_S L_T)=10368` on diagonal, `4032` on Petersen edges, `3960` on nonedges.

## 7. Important mass-spectrum boundary and next input

For `H=D_r` alone, the **full** spectrum on `C[A5]` is simply `{0,1}` with multiplicities given by the support size. The fractional eigenvalues of `P5 D_r P5` are **principal-angle responses** of two subspaces, and are *not* additional physical levels of that full occupancy operator. The off-sector couplings computed above are exactly what restores the full binary spectrum.

For any actual finite QCD Hamiltonian restricted to a center-even carrier, write the **block decomposition**, with `P=P5`, `Q=I-P`, as

\[
H=\begin{pmatrix}A & K^\dagger\\K&B\end{pmatrix},\quad
A=PHP,\quad K=QHP,\quad B=QHQ.
\]

Outside `spec B`, the correct pole condition is the Schur-complement equation

\[
\boxed{\det\big(\mu-A-K^\dagger(\mu-B)^{-1}K\big)=0.}
\]

Thus eigenvalues of `A` alone are generally not full eigenvalues when `K≠0`. For `H=D_r`, `K^\dagger K=R_r-R_r²` is already completely known by v2_331. For the physical `H_L`, the present archive does not provide the required source-owned embedding into this finite 120-carrier nor its full matrix elements. One must not manufacture those entries by assigning meson masses or arbitrary coefficients.

**Operational next target:** derive the *typed* source/transfer map from the Paper VII-A color-singlet Hamiltonian into the 120-element carrier, test central parity, compute its `17↔25↔18` (and potentially center-odd) off-block couplings, and obtain the lowest poles with physical interpolator residues. This is exactly the unresolved physical criterion in Paper VII-B. Until those ingredients exist, these exact results are geometric selection and mixing laws, **not a ground-state meson mass prediction**.

## 8. Independence and reproduction

- No empirical particle masses, `E_32`, `E_36`, or `E_40` enter any proof or script.
- Matrix certificates use integer equality, arithmetic divisibility and exact rational traces; no numerical eigenvalue detection is needed.
- The claims are conditional only on the established `2I→A5` geometry, its five-core and Petersen pair representation, and their finite coefficient kernels.
- The standard background is finite-group character orthogonality, rank projections, Schur complements and principal-angle geometry. The formulas above are **derived specializations for this exact incidence construction**, not claims of a new general representation theory.
- Canonical papers, bibliography, macros, and the theorem DAG are unchanged.

## 9. v2_333 completion: the original Hopf-axis quadrupole is recovered

Paper I-A identifies the five-dimensional Petersen quadrupole idempotent on the ten pair labels as

\[
P_{\mathrm{Hopf},5}=\frac{4I_{10}+2A_{\mathrm P}-J_{10}}6,
\]

with rank 5. In Section 6 we independently derived the ten-by-ten Gram kernel `Γ` from the **rank-eight protected subspaces inside the 120-element function carrier**:

\[
18\Gamma=89I_{10}+A_{\mathrm P}+55J_{10}.
\]

Eliminating the adjacency gives the new exact intertwining relation

\[
\boxed{P_{\mathrm{Hopf},5}
=6\Gamma-29I_{10}-\tfrac{37}{2}J_{10}.}
\]

Thus the *same five-dimensional Petersen spectral projector* is recovered by linear algebra from two very different constructions: the Hopf-axis quadrupole Gram in Paper I-A and the 25-sector protected eight-plane overlaps. This is an equality of operators **on the ten pair-label space**; it is not a canonical identification of a ten-dimensional axis vector space with the actual 120-dimensional function carrier.

Because `A_P` has eigenvalues `3(1), 1(5), -2(4)`, the Gram eigenvalues are exactly

\[
\operatorname{Spec}\Gamma
=\{(107/3)^{(1)},5^{(5)},(29/6)^{(4)}\},
\]

providing an independent positive-definiteness check. The accompanying script verifies the projector equality as a **literal integer matrix identity**, with no floating-point input.

## 10. Inversion grading of the new fusion-frame spectrum

The involution `J_inv f(g)=f(g⁻¹)` commutes with every marked overlap selector `D_72,S`, the rank-25 projector `P5`, each `Q_S`, and their sum `T`. On `End(V5)`, it is transposition. Consequently

\[
\begin{aligned}
\operatorname{Sym}^2(V_5)&\cong\mathbf1\oplus\mathbf4\oplus2\mathbf5 &&(15),\\
\bigwedge^2(V_5)&\cong\mathbf3\oplus\mathbf3'\oplus\mathbf4 &&(10).
\end{aligned}
\]

The exact `T` eigenvalues separate by inversion:

| Inversion | `T` spectrum | Dimension |
|---|---|---:|
| Even/symmetric | `0(1), 2(10), 5/2(4)` | 15 |
| Odd/antisymmetric | `10/3(6), 15/2(4)` | 10 |

The corresponding **active traceless 24** therefore separates as `14` inversion-even and `10` inversion-odd. The script verifies these signatures by exact trace calculations using the Lagrange spectral projectors of the integer matrix `F=18T`. Physical parity or charge conjugation is **not** thereby established; `g↦g⁻¹` is a finite-group inversion grading.

An additional compatibility identity now holds:

\[
\boxed{[T,P_5M_{\mathcal C}P_5]=0}
\]

for every indicator `M_𝒞` of an `A5` conjugacy class `𝒞` (five classes). Thus `T` lies in the **center of the nine-dimensional unmarked compressed class-source algebra** derived in v2_331: it commutes even with the orientation-sensitive operator distinguishing the two five-cycle classes. This is checked exactly on all five generating class indicators.

The center property explains why `T` has only five distinct eigenvalues even though its complete 25-sector carries richer noncommutative marked responses. The ten covariant choices of `S` are **one symmetry orbit, not ten independent particle species**.

### Updated status

The new material in v2_333 is (i) exact 17↔25↔18 occupancy coupling norms and a `3/3′` mirror equality; (ii) a canonical protected 8-plane for every Petersen vertex; (iii) a rank-24 fusion frame with an exact rational spectrum; (iv) a reconstruction of Petersen adjacency and the original Hopf-axis quadrupole projector from these subspace overlaps; and (v) an inversion-graded, central unmarked response operator. All results are verified finite algebra. None supplies the physical color-singlet finite Hamiltonian or the meson ground-state pole spectrum.
