# Born–Hopf Geometry: exact F40 Hodge-mirror gluing and 44-channel compatibility

**Research proof v1_1 — 7 November 2026.**  **Baseline:** `Paper00-PapersMinimal-v2_345(1).zip`, with source labels `p1:thm:v345-f40-edge-regular`, `p1:thm:v345-f40-triple-frame`, and `p1:prop:v345-f40-balanced-mirror`. **Status:** finite mathematical proof, reproducible exact certificate, no changes to the 30 canonical papers or theorem DAG. This closes a **geometric consistency / channel-gluing** gap; it does not claim an actual QCD source, an observed hadron mass, or physical selection of the `2I` branch.

## 1. Previously unresolved question

On the 40-vertex, 60-oriented-edge cubic graph `F40`, the real cycle space `Z=ker ∂` has dimension 21. The v2_345 maps

\[
  T_R,T_L:\mathcal Z\to \mathbb R^{12},\qquad
  A:\mathcal Z\to\mathbb R^{20},\qquad
  \mathcal R z=(T_Rz,T_Lz,Az)
\]

have individual rank 11, paired rank 16, and joint rank 21. Thus the raw output has **44 entries constrained to a 21-dimensional linear image**, but the current manuscripts do not give a direct combinatorial characterization of its **23 consistency relations**, nor an explicit formula interchanging the six mirror modes in the quaternion shell and the six mirror modes in the core-arrow space.

## 2. Exact Hodge-mirror transport law

Let `S` denote the twelve-element fivefold quaternionic shell, with induced five-core permutations `p_g`. Let `d_g(i,j)∈{1,2,3,4}` be the unique exponent such that `p_g^{d_g(i,j)}(i)=j`, for distinct core labels `i,j∈{1,2,3,4,5}`. Define the rational 20-by-12 matrix

\[
\boxed{K_{(i,j),g}=\frac{5-2d_g(i,j)}{40}.}\tag{1}
\]

Its 240 entries are exactly 60 occurrences each of `3/40`, `1/40`, `−1/40`, `−3/40`. Let `P_skew` denote the orthogonal projector onto the balanced skew-off-diagonal five-core arrow space `B_skew`, of dimension six. Then:

**Theorem 1 (explicit, exact six-mode mirror-gluing operator).** For every `z∈Z`,

\[
\boxed{P_{\rm skew} Az=K(T_R-T_L)z.}\tag{2}
\]

`K` maps the antipodal-odd six-plane of the icosahedral shell *isomorphically* onto the skew balanced-arrow six-plane. Both spaces are, as `A5` representations, `3⊕3′`. In particular, the arrow Hodge modes are not independent extra modes after right/left shell contrast has been supplied. Their precise compatibility is given by (2).

### Derivation and exact finite certificate

Let `Ant` denote the permutation of the twelve-shell by quaternion inversion (`g↔g^{-1}`), let `A_ico` be icosahedral adjacency, and define `P_odd=(I−Ant)/2`. From the v2_345 native quaternionic identities,

\[
\begin{aligned}
 P_{\rm odd}(T_R+T_L)|_Z&=0,\\
 (T_R-T_L)P_Z(T_R-T_L)^T&=10I-2A_{\rm ico},\\
 A_{\rm ico}^2P_{\rm odd}&=5P_{\rm odd}.
\end{aligned}\tag{3}
\]

Therefore the inverse of the shell-contrast Gram on the odd six-plane is

\[
 (10I-2A_{\rm ico})^{-1}P_{\rm odd}
  =\frac{5I+A_{\rm ico}}{40}P_{\rm odd}.\tag{4}
\]

The arrow skew map and shell-contrast map have the same `A5` irreducible support, each containing a single `3` and `3′`. Their kernels on `Z` are thus the common `3·5` isotypic subspace. The exact transfer can consequently be written

\[
 K=P_{\rm skew}AP_Z(T_R-T_L)^T\,
 \frac{5I+A_{\rm ico}}{40}P_{\rm odd}.\tag{5}
\]

This formula proves (2) by orthogonal reconstruction on the six-plane. Under simultaneous even five-core relabeling, `(i,j,g)` is classified by `d_g(i,j)`; each of the four values is a single `A5` orbit of 60 triples. Inversion gives `d_{g^{-1}}(i,j)=5-d_g(i,j)` and changes the sign of the odd-shell kernel, leaving only the two coefficients for distances 1 and 2 to evaluate. Exact rational evaluation of the fixed graph incidence matrices in (5) yields `3/40` and `1/40`; hence (1). **The included certificate also checks all 240 entries independently**, and checks (2) on a full 21-column cycle-space basis.

**Corollary 1 (two-sided inverse and golden conditioning).** On the odd shell and skew-arrow spaces:

\[
\boxed{K^TK=\frac{5I+A_{\rm ico}}{40}P_{\rm odd},}\qquad
\boxed{K^{-1}=2(5I-A_{\rm ico})K^T.}\tag{6}
\]

The full matrix identities are `K^{-1}K=P_odd` and `KK^{-1}=P_skew`. Its two singular-value squares are `(5±sqrt(5))/40`, each with multiplicity three, yielding the exact condition number

\[
\boxed{\kappa(K)=\sqrt{\frac{5+\sqrt5}{5-\sqrt5}}=\frac{1+\sqrt5}{2}=\varphi.}\tag{7}
\]

This is a geometric transfer ratio **not a hadron mass ratio or coupling constant**.

## 3. Necessary and sufficient test for any proposed 44-channel packet

Consider *arbitrary* raw arrays

\[
 u=(u_g)_{g\in S}\in\mathbb R^{12},\quad
 v=(v_g)_{g\in S}\in\mathbb R^{12},\quad
 w=(w_{ij})_{i\ne j}\in\mathbb R^{20}.
\]

**Theorem 2 (exact compatibility criterion; 23 constraints).** The arrays arise from **one and the same** F40 cycle,

\[
 (u,v,w)=(T_Rz,T_Lz,Az)\quad\text{for a unique }z\in Z,
\]

if and only if the following hold:

1. **Shell conservation, 2 independent equations:** `Σ_g u_g=Σ_g v_g=0`.
2. **Directed-arrow balance, 9 independent equations:** `Σ_{j≠i} w_ij=0` for all five `i`, and `Σ_{i≠j} w_ij=0` for any four of the five `j` (the omitted fifth column follows from the first nine equations).
3. **Right/left inversion parity, 6 independent equations:** `u_g+v_g=u_{g^{-1}}+v_{g^{-1}}` for one `g` in each of the six inversion pairs.
4. **Skew-arrow Hodge gluing, 6 independent equations:** for the six *chords* `2≤i<j≤5`,

\[
 \boxed{\frac{w_{ij}-w_{ji}}2
   =\sum_{g\in S}\frac{5-2d_g(i,j)}{40}(u_g-v_g).}\tag{8}
\]

Here labels are one-based. Balance extends these six chord equations uniquely to all ten unordered core pairs, as the four spanning-star arrow values are determined by flow conservation.

**Proof.** The included exact integer/rational certificate forms the 23×44 matrix `C_23` specified by these equations and the 44×21 native readout matrix `R` on a basis for `Z`. It verifies

\[
  \operatorname{rank}(C_{23})=23,\qquad
  \operatorname{rank}(R)=21,\qquad
  C_{23}R=0.\tag{9}
\]

Therefore `im R⊆ker C_23`, while `dim ker C_23=44−23=21=dim im R`. Hence these spaces are equal, and the cycle is unique by full-column rank. This is an exact finite proof of **necessity and sufficiency**, not just a collection of suggestive conditions.

The 23 constraints split as **11 intra-channel constraints** (two shell means and nine arrow balances), plus **12 cross-channel constraints** (six antipodal parity conditions and six Hodge-gluing equations). These cross-relations detect mode-misaligned or spurious triples even when each channel separately looks admissible.

## 4. Closed-form reconstruction without numerical inversion

The existing v2_345 Euclidean frame operator `F=R*R` on the 21-cycle space has spectral factors

\[
 \chi_F(x)=(x-1)^5(x^2-12x+31)^3(x^2-8x+6)^5.
\]

All five distinct roots are positive, so its minimal polynomial is

\[
 m_F(x)=x^5-21x^4+153x^3-453x^2+506x-186.
\]

A direct consequence of `m_F(F)=0` is the **exact rational inverse formula**

\[
 \boxed{F^{-1}=
 \frac{F^4-21F^3+153F^2-453F+506I}{186}.}\tag{10}
\]

Thus `z=F^{-1} R* (u,v,w)` for compatible data, and

\[
 \boxed{\Pi_{44}=R F^{-1}R^*}\tag{11}
\]

is the canonical orthogonal 44-channel compatibility projector, with rank 21 and nullity 23. Any proposed raw triple `d` is geometrically valid if and only if `Π_44 d=d`; the 23 sparse constraints of Theorem 2 avoid constructing this dense projector.

The inverse (10) uses **only rational coefficients** despite the individual spectral roots containing square roots of five and ten. This removes any numerical eigensolver, arbitrary eigenbasis choice, or fit from the finite reconstruction.

## 5. Framework implications and strict status

- **Paper I-A / I-C:** Insert Theorem 1 as a native F40 `A5`-equivariant Hodge-gluing identity and Theorem 2 as the exact 23-equation consistency test; include the reproducible finite certificate.
- **Paper II-C:** A three-readout comparison packet can be validated *before* interpreting it as a physical test. It provides a precisely delimited 21-dimensional image; it is not asserted that its 44 outputs are physical POVM outcomes.
- **Paper VII-A/B:** Any candidate action-selected source proposing simultaneous `T_R`, `T_L`, and `A` channels must obey the 23 equations **if** those channels genuinely derive from a common F40 cycle. This supplies a sharp consistency test against independently chosen source coefficients. It does **not** create the needed color-singlet isometry, source coefficient, Hamiltonian coupling, or correlator poles.
- **Constitutional status:** G0 and GP1–GP3 are unchanged. The `2I` geometry remains conditional where the prefix has not established occurrence.
- **No physical claims:** No QCD mass gap, numerical hadron mass, quark-mass RG replacement, lifetime, cross-section, or actualized baryon pole follows from these finite identities.

## 6. Reproducibility

The companion package contains the two unmodified v2_345 F40 research verification scripts (`v1_10`, `v1_11`) and `Paper00-F40MirrorGluing-v1_1-verify.py` with exact integer and rational matrix checks, a `20×12` explicit `K` CSV, the `23×44` explicit constraint CSV, and JSON plus terminal verification output. Run:

```
python Paper00-F40MirrorGluing-v1_1-verify.py
```

Run in that directory with Python and SymPy installed. All new and inherited exact checks pass. No canonical files or theorem DAG entries have been edited.
