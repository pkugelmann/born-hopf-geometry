#!/usr/bin/env python3
"""Born–Hopf 2I/Petersen full finite-incidence operator, exact v2_334.

Checks the full 120-dimensional, center-even/odd decomposition, the 60D
symbolic secular factorization for a pair-preserving occupancy stratum, and
H=S3 left-right symmetry of marked operators. No hadron mass fitting.
"""
from collections import Counter
from fractions import Fraction
from itertools import permutations
import numpy as np
import sympy as sp

G=[p for p in permutations(range(5)) if sum(p[i]>p[j] for i in range(5) for j in range(i+1,5))%2==0]
assert len(G)==60
ix={g:i for i,g in enumerate(G)}
def mul(a,b): return tuple(a[b[j]] for j in range(5))
def inv(a): return tuple(a.index(j) for j in range(5))
def shape(g):
    seen=set(); lengths=[]
    for k in range(5):
        if k in seen: continue
        j=k; n=0
        while j not in seen:
            seen.add(j); n+=1; j=g[j]
        lengths.append(n)
    return tuple(sorted(lengths))
I=np.eye(60,dtype=np.int64)
chr={
    '1':{(1,1,1,1,1):1,(1,2,2):1,(1,1,3):1,(5,):1},
    '4':{(1,1,1,1,1):4,(1,2,2):0,(1,1,3):1,(5,):-1},
    '5':{(1,1,1,1,1):5,(1,2,2):1,(1,1,3):-1,(5,):0},
    '3+3p':{(1,1,1,1,1):6,(1,2,2):-2,(1,1,3):0,(5,):1}
}
C={key:np.array([[char[shape(mul(inv(g),h))] for h in G] for g in G],dtype=np.int64) for key,char in chr.items()}
# Projectors P1=C1/60; P4=C4/15; P5=C5/12; P33=C33/20.
assert np.array_equal(C['1']+4*C['4']+5*C['5']+3*C['3+3p'],60*I)
for key,n,d in [('1',60,1),('4',15,16),('5',12,25),('3+3p',20,18)]:
    assert np.array_equal(C[key]@C[key],n*C[key])
    assert int(np.trace(C[key]))==n*d

# Full pair-incidence kernel, in the normalized even-parity A5 representation.
K=2*(C['1']+C['4']+C['5'])
assert np.array_equal(K,2*C['1']+2*C['4']+2*C['5'])
assert (int(np.trace(K)),int(np.trace(K@K)))==(1200,43200)
assert {x:int(np.linalg.eigvalsh(K).round().tolist().count(x)) for x in [0,24,30,120]}=={0:18,24:25,30:16,120:1}
assert np.array_equal(K@C['5'],24*C['5'])
# Lift K to 120 functions on 2I (with two indistinguishable central lifts).
J2=np.ones((2,2),dtype=np.int64)
K120=np.kron(K//2,J2)
assert all(x in (0,1,2,10) for x in np.unique(K120))
assert np.all(np.diag(K120)==10)
assert np.array_equal(K120.sum(axis=1),120*np.ones(120,dtype=np.int64))
assert np.array_equal(K.sum(axis=1),120*np.ones(60,dtype=np.int64))

S={0,1}
def overlap(g): return len(S & {g[0],g[1]})
D={r:np.array([int(overlap(g)==r) for g in G],dtype=np.int64) for r in (2,0,1)}
assert [int(D[r].sum()) for r in (2,0,1)]==[6,18,36]
assert np.array_equal(D[2]+D[0]+D[1],np.ones(60,dtype=np.int64))
H=[g for g in G if overlap(g)==2]
assert len(H)==6
for a in H:
    # Invariance of K and marked double-coset classes under H x H.
    L=np.array([ix[mul(inv(a),g)] for g in G],dtype=np.int64)
    R=np.array([ix[mul(g,a)] for g in G],dtype=np.int64)
    assert np.array_equal(K[np.ix_(L,L)],K)
    assert np.array_equal(K[np.ix_(R,R)],K)
    for r in (2,0,1):
        assert np.array_equal(D[r][L],D[r])
        assert np.array_equal(D[r][R],D[r])

# Exact all-sector coupling norms ||Pi_A D Pi_B||_HS².
P={'17':(C['1']+4*C['4'],60),'25':(C['5'],12),'18':(C['3+3p'],20)}
expect={
    2:[[Fraction(57,100),Fraction(13,20),Fraction(12,25)],
       [Fraction(13,20),Fraction(5,4),Fraction(3,5)],
       [Fraction(12,25),Fraction(3,5),Fraction(18,25)]],
    0:[[Fraction(53,20),Fraction(5,4),Fraction(6,5)],
       [Fraction(5,4),Fraction(19,4),Fraction(3,2)],
       [Fraction(6,5),Fraction(3,2),Fraction(27,10)]],
    1:[[Fraction(7),Fraction(2),Fraction(6,5)],
       [Fraction(2),Fraction(23,2),Fraction(3,2)],
       [Fraction(6,5),Fraction(3,2),Fraction(81,10)]]
}
for r in (2,0,1):
    marked=np.flatnonzero(D[r]); ab=np.ix_(marked,marked)
    for ia,a in enumerate(P):
        A,an=P[a]
        for ib,b in enumerate(P):
            B,bn=P[b]
            val=Fraction(int(np.sum(A[ab]*B[ab])),an*bn)
            assert val==expect[r][ia][ib]
    print('D stratum',2*len(marked),'full 3x3 coupling squared norms',expect[r])

# Exact restriction of each G-irrep projector to the pair stabilizer H=S3.
# E_T, E_sign and E_std are the three central minimal isotypic projectors
# of the regular S3 representation on C[H] with ranks 1, 1 and 4.
hi=np.array([ix[h] for h in H],dtype=np.int64)
sgn=np.array([+1 if h[0]==0 else -1 for h in H],dtype=np.int64)
ET=np.ones((6,6),dtype=np.int64) # /6
ES=np.outer(sgn,sgn)             # /6
Estd=6*np.eye(6,dtype=np.int64)-ET-ES # /6
weights={
    '1':[Fraction(1,10),Fraction(0),Fraction(0)],
    '4':[Fraction(2,5),Fraction(2,5),Fraction(1,5)],
    '5':[Fraction(1,2),Fraction(0),Fraction(1,2)],
    '3+3p':[Fraction(0),Fraction(3,5),Fraction(3,10)]
}
for key,den in [('1',60),('4',15),('5',12),('3+3p',20)]:
    A=sp.Matrix(C[key][np.ix_(hi,hi)])/den
    B=sum((sp.Rational(w.numerator,w.denominator)*sp.Matrix(E)/6 for w,E in zip(weights[key],[ET,ES,Estd])),sp.zeros(6))
    assert A==B, key
print('H=S3 restrictions and their resolvent spectral weights: EXACT')

# Stabilizer restriction multiplicities for irreps 1,3,3prime,4,5 of A5.
# H classes: identity(1), involutions(3), order-three elements(2).
resChars={'1':(1,1,1),'3':(3,-1,0),'3prime':(3,-1,0),'4':(4,0,1),'5':(5,1,-1)}
S3Chars={'triv':(1,1,1),'sign':(1,-1,1),'standard':(2,0,-1)}
res={a:{b:sum(n*x*y for n,x,y in zip((1,3,2),cs,hs))//6 for b,hs in S3Chars.items()} for a,cs in resChars.items()}
assert res=={'1':{'triv':1,'sign':0,'standard':0},'3':{'triv':0,'sign':1,'standard':1},'3prime':{'triv':0,'sign':1,'standard':1},'4':{'triv':1,'sign':1,'standard':1},'5':{'triv':1,'sign':0,'standard':2}}
labels=list(S3Chars)
M=np.array([[sum(res[r][a]*res[r][b] for r in res) for b in labels] for a in labels],dtype=np.int64)
assert np.array_equal(M,np.array([[3,1,3],[1,3,3],[3,3,7]]))
assert int(np.array([1,1,2])@M@np.array([1,1,2]))==60
print('Full HxH symmetry multiplicity matrix:', M.tolist())

# Resolvent determinant lemma: K has levels 120,30,24,0; D_same has rank 6.
z,t=sp.symbols('z t')
gT=sp.Rational(1,10)/(z-120)+sp.Rational(2,5)/(z-30)+sp.Rational(1,2)/(z-24)
gS=sp.Rational(2,5)/(z-30)+sp.Rational(3,5)/z
gE=sp.Rational(1,5)/(z-30)+sp.Rational(1,2)/(z-24)+sp.Rational(3,10)/z
qT=(z-120)*(z-30)*(z-24)-t*(z**2-138*z+3024)
qS=z*(z-30)-t*(z-18)
qE=z*(z-30)*(z-24)-t*(z**2-36*z+216)
for g,q in [(gT,qT),(gS,qS),(gE,qE)]:
    assert sp.factor(1-t*g)==sp.factor(q/(sp.denom(sp.cancel(g))))

# Full even-char polynomial has pinned 43 eigenvalues and 17 coupled eigenvalues.
chiEven=z**13*(z-30)**10*(z-24)**20*qT*qS*qE**4
chiOdd=z**54*(z-t)**6
assert sp.degree(chiEven,z)==60 and sp.degree(chiOdd,z)==60
# Direct diagonalization numerical independent check for three nontrivial source strengths.
for strength in (1,7,24):
    target=[0.]*13+[30.]*10+[24.]*20
    for q,m in ((qT,1),(qS,1),(qE,4)):
        roots=np.roots([float(x) for x in sp.Poly(q.subs(t,strength),z).all_coeffs()])
        assert np.max(np.abs(np.imag(roots)))<1e-8
        target.extend(np.real(roots).tolist()*m)
    actual=np.linalg.eigvalsh(K+strength*np.diag(D[2]))
    assert len(target)==60 and np.max(np.abs(np.sort(actual)-np.sort(target)))<1e-7
    print(f't={strength}: complete 60x60 spectrum equals factored secular polynomials; max err={np.max(np.abs(np.sort(actual)-np.sort(target))):.2g}')
# Verify the full 120D lift and its center-odd 0/t levels.
tval=7
full=K120+tval*np.kron(np.diag(D[2]),np.eye(2,dtype=np.int64))
even=np.linalg.eigvalsh(K+tval*np.diag(D[2]))
expect120=np.sort(np.concatenate([even,np.zeros(54),np.repeat(tval,6)]))
assert np.max(np.abs(np.linalg.eigvalsh(full)-expect120))<1e-7
print('Full 120x120 two-central-lift matrix passes numerical eigenvalue check')

# The six-dimensional source resolvent has three exact scalar channels.
for zz,tt in ((201,7),(251,24)):
    src=np.linalg.inv(zz*np.eye(60)-K-tt*np.diag(D[2]))[np.ix_(hi,hi)]
    scores=[]
    for g in (gT,gS,gE):
        gv=float(g.subs(z,zz))
        scores.append(gv/(1-tt*gv))
    rhs=sum(v*E/6 for v,E in zip(scores,(ET,ES,Estd)))
    assert np.max(np.abs(src-rhs))<1e-11
print('Restricted six-dimensional source resolvent and positive spectral-pole formulas VERIFIED')
print('EXACT character, rank, 3x3 coupling, HxH reduction and symbolic secular factorization VERIFIED')
print('q_triv =',sp.expand(qT))
print('q_sign =',sp.expand(qS))
print('q_standard =',sp.expand(qE))
print('Full 120D determinant = chiEven *',chiOdd)
