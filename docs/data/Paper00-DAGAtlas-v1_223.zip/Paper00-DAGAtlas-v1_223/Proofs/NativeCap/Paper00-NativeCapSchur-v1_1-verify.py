#!/usr/bin/env python3
"""Exact independent finite algebra checks for Framework v2.353.
This proves mathematical model identities only, not native physical incidence.
"""
from pathlib import Path
import json
import sympy as S
x,c,Rs,u,rho,q,eps=S.symbols('x c R_s u rho q epsilon', real=True,
                                   nonzero=True)
G=S.sqrt(1+x*x)
t=x/(1+G)
B_I,B_U=S.symbols('B_I B_U',positive=True)
checks={}
checks['half_boost_scalar_identity'] = bool(S.simplify((1-c*c*t*t) - (1-c*c+2*c*c/(1+G)))==0)
I=S.eye(2); Z=S.zeros(2); Gch=S.diag(1,1,-1,-1)
chi=(Z.row_join(I)).col_join(I.row_join(Z))
P=(S.eye(4)+chi)/2
L=(S.eye(4)+u*Gch).inv()
checks['projector_transverse'] = P*Gch*P==S.zeros(4)
checks['inverse_square'] = S.simplify(S.trace(P*L*P*L)-2/(1-u*u)**2)==0
J=S.sqrt(2)*rho*P
F=S.factor(-S.trace((J+q*Gch)*L*(J+q*Gch)*L)/8)
F_expected=-(rho*rho-2*S.sqrt(2)*rho*u*q+(1+u*u)*q*q)/(2*(1-u*u)**2)
checks['mixed_source_polynomial']=S.simplify(F-F_expected)==0
checks['mixed_jet_value']=S.simplify(S.diff(F,q,u).subs({q:0,u:0,rho:Rs/2})*c/(2*Rs)-c/(2*S.sqrt(2)))==0
# Compare true original four-port inverse with chiral superoperator spectrum.
X=S.Matrix([[0,1],[1,0]]); Mplus=I+u*X;Mminus=I-u*X
T=S.kronecker_product(Mplus,Mminus)
Tin=S.simplify(T.inv());
checks['cap_fourport_inverse_trace']=S.simplify(S.trace(Tin)-4/(1-u*u)**2)==0
spec=dict([(S.factor(val),mult) for val,mult in Tin.eigenvals().items()])
checks['cap_spectral_multiplicities']=sorted(spec.values())==[1,1,2]
# Schur complement of normalized positive 2+2 operator, with arbitrary constant 2x2 orthogonal transport.
U=S.Matrix([[0,-1],[1,0]])
K=(I.row_join(u*U)).col_join((u*U.T).row_join(I))
Ki=S.simplify(K.inv())
checks['schur_projected_inverse']=S.simplify(Ki[:2,:2] - I/(1-u*u))==S.zeros(2)
checks['schur_mixed_orientation']=S.simplify(Ki[:2,2:] + u*U/(1-u*u))==S.zeros(2)
checks['trace_nonidentifiability']=S.simplify((1+eps)+(1-eps)-2)==0
# Differentiated target from c*t(x) for x=R/Rs
R=S.symbols('R',real=True)
r=R/Rs
uu=c*r/(1+S.sqrt(1+r*r))
b=1-uu*uu
checks['cap_reference_slope']=S.simplify(S.diff(b,R).subs(R,0))==0
checks['cap_reference_second_derivative']=S.simplify(S.diff(b,R,2).subs(R,0)+c*c/(2*Rs*Rs))==0
# Even heat source: sample real self-adjoint chiral matrix D_phi and exact trace invariance.
m,phi,beta=S.symbols('m phi beta',real=True)
D0=S.Matrix([[0,1],[1,0]])*m
GG=S.diag(1,-1)
Dphi=D0+phi*GG
checks['interior_parity_operator']= GG*Dphi*GG==-(D0-phi*GG)
checks['interior_parity_square']= S.simplify((Dphi*Dphi).trace().subs(phi,-phi)-(Dphi*Dphi).trace())==0
assert all(checks.values()), {k:v for k,v in checks.items() if not v}
out={'framework':'v2_353','status':'PASS','scope':'finite positive comparison; not native physical action identification',
     'checks':checks,'checks_passed':sum(map(bool,checks.values())),
     'native_boundary_incidence_proved':False,'native_tensor_source_identity_proved':False,
     'physical_cosmological_history_selected':False}
(root:=Path(__file__).resolve().parent)
(root/'Paper00-NativeCapSchur-v1_1-results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
