# Native cap boundary-Schur mathematical certificate — v1_1 (framework v2.353)

**Scope:** Exact finite-dimensional algebra and necessary common-action tests. The existing microscopic Born–Hopf Dirac/heat action has **not** been shown to generate the four-port cap, its physical projector/source, mode-reduced boundary operator, absolute normalization, or the complete tensor-source action. No new axiom, dark-matter substance, or cosmological history has been inserted.

## Exact finite identities

Write `x=R/R_s`, `G=sqrt(1+x²)`, `t=x/(1+G)`, `c²=(B_I-B_U)/B_I`, `u=c*t`, `b=1-u²`, and `B=B_I*b`. For the positive `2x2` half-boost matrix `[[G,x],[x,G]]`, the off-diagonal/diagonal ratio of its positive square root is `t`.

On the positive `2+2` source kernel `K=[[A,C],[C†,D]]` with `D>0`, the Schur complement is `S_+=A-C D^-1 C†`. For rank-two `P_+`, normalized incoming comparison current `J=(R_s/sqrt2)P_+`, the scalar response is exactly `F=-(R_s²/16) tr(S_+^-2)`. Under `S_+=b I2`, this equals the capped stationary source `-sigma²/(8B²)` with `sigma=B_I*R_s`. If `A=D=I2`, this operator condition is equivalent to `CC†=u² I2`, giving `C=u U` for a unitary `U` when `u != 0`.

For any Hermitian involution `M` and rank-r projector `P`, `tr[P(I+uM)^-1 P(I+uM)^-1]=r/(1-u²)²` throughout an interval **iff** `PMP=0`. The conditional canonical boundary projector `P=(I+gamma_n gamma_g)/2` is transverse to `M=gamma_g` in its stated Clifford convention. This constructs an algebraic cap comparison, **not** the native source kernel.

## Short native discrimination targets

After a physically justified reference normalization `A(0)=D(0)=I2`, `C(0)=0`, native reproduction of the cap would require `A'(0)=0` and `A''(0)-2C'(0)C'(0)†=-(c²/(2R_s²)) I2`. The first condition is necessary, as is the second; together they are not sufficient for all curvature values. Full matching requires the physical source Hessian, its mixed jets, transported measure and action coefficient, plus native transverse-traceless tensor and Hilbert stress sources.

The direct identification of the cap's finite odd comparison source `q gamma_g` with an unmarked chirality-odd source in a common chirality-preserving ordinary interior heat trace is excluded by evenness of the latter. The finite comparison has nonzero mixed jet `c/(2 sqrt2)` at zero curvature and zero source, while the symmetry-preserving interior heat word has zero odd-source derivative. The conclusion is scoped to those precisely identified source coordinates and invariant domains; physical boundary and source maps may differ.

Distinct unitary mixing orientations `U(R)` give identical scalar cap returns but different mixed-probe responses. Also, `S_epsilon=b diag((1+eps)^-1/2,(1-eps)^-1/2)` obeys `tr S_epsilon^-2=2/b²` yet is not scalar when `eps != 0`. Scalar curvature jets cannot identify all native source directions.

## Independent verification

Run `python Proofs/NativeCap/Paper00-NativeCapSchur-v1_1-verify.py` from the release root. The script checks the half-boost profile, Clifford projector, inverse-square trace, exact mixed jet, native-cap model eigenvalues and Schur response, the reference curvature two-jet, and an ordinary finite chirality parity identity. Its JSON output is a record of **algebraic** verification only.

## Not discharged

1. Actual conormal-to-Dirac incidence and the physical `P_+`, transverse `M`, and source current.
2. Source normalization, internal multiplicity, `1/8` density owner and quantum integration measure.
3. Actual tangential-mode-dependent boundary operator and justified finite reduction.
4. Full native metric/TT, Hilbert matter, boundary and higher source jets.
5. Physical Cauchy histories, reheating transfer, RAR/lensing and cosmological clustering predictions.

The theorem owners are Paper III-E (finite Schur) and Paper III-F (Clifford parity), imported by VI-A and ledgered in VI-C.
