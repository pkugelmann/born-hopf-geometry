#!/usr/bin/env python3
"""Bounded, independent checks for Born--Hopf source repair batch 2.
Not a full E3/E4 proof of physical theorem claims.
"""
import json, math, re, hashlib, cmath
from pathlib import Path
import numpy as np
import sympy as sp
ROOT=Path(__file__).parent/'sources'
results=[]

def check(name, ids, ok, evidence, independent='finite numerical/algebraic verification'):
    o={'check':name,'issue_ids':ids,'passed':bool(ok),'method':independent,'witness':evidence}
    results.append(o)
    assert ok, f'Check failed: {name}: {evidence}'

def src(name):
    return (ROOT/name).read_text()

v7=src('Paper7B-QCDReadouts-v1_164.tex')
check('VIIB corrected source anchors', ['BH-VIIB-G-0148'], all(x in v7 for x in [r'\label{p11:prop:two-support-full-resolvent-pole-certificate}',r'\Sigma_P(z)',r'\emph{trial-transfer}',r'\lambda_{\pm}^{(\chi)}']), 'new Schur-resolvent theorem and original theorem label present', 'source E0')

# Hermitian 2x2 with complex mixing, repeated with changing off-diagonal phases.
rng=np.random.default_rng(287)
maxerr=0.
for z in range(20):
    la,lb=rng.random(2)
    kap=(rng.random()+1j*rng.random())*0.12
    A=np.array([[la,kap],[np.conj(kap),lb]],complex)
    n=np.linalg.eigvalsh(A)
    formula=np.array([(la+lb)/2-np.sqrt(((la-lb)/2)**2+abs(kap)**2),(la+lb)/2+np.sqrt(((la-lb)/2)**2+abs(kap)**2)])
    maxerr=max(maxerr,np.max(abs(n-formula)))
check('VIIB complex Hermitian mixing', ['BH-VIIB-G-0137','BH-VIIB-G-0148'], maxerr<2e-14, {'max_error':maxerr,'repetitions':20})

# Explicit in-domain counterexample to physical pole claim.
H=np.diag([0.,1.,2.,4.]);A=np.array([0,1/math.sqrt(2),0,1/math.sqrt(2)],float);B=np.array([0,0,1,0],float)
V=np.column_stack([A,B]);K=V.T@np.diag(np.exp(-np.diag(H)))@V
trial=-np.log(np.linalg.eigvalsh(K))
check('VIIB nonreducing trial energy is not full pole', ['BH-VIIB-G-0148'], any(np.min(np.abs(v-np.array([0.,1.,2.,4.])))>0.1 for v in trial) and any(abs(v-2)<1e-12 for v in trial),
      {'trial_energies':trial.tolist(),'full_spectrum':np.diag(H).tolist(),'commutator_norm':float(np.linalg.norm(H@V@V.T-V@V.T@H))}, 'counterexample E4')

# exact Schur/Feshbach identity at complex z, noncommuting sector.
R=np.random.default_rng(103); X=R.normal(size=(5,5))+1j*R.normal(size=(5,5)); HH=(X+X.conj().T)/2
P=np.diag([1.,1.,0.,0.,0.]);z=0.37+1.2j
Q=np.eye(5)-P;h11=HH[:2,:2];h22=HH[2:,2:];h12=HH[:2,2:];h21=HH[2:,:2]
full=np.linalg.inv(z*np.eye(5)-HH)[:2,:2]
schur=np.linalg.inv(z*np.eye(2)-h11-h12@np.linalg.inv(z*np.eye(3)-h22)@h21)
err=float(np.linalg.norm(full-schur))
check('VIIB full pole Schur resolvent identity',['BH-VIIB-G-0148'],err<1e-12,{'matrix_size':5,'error':err,'leakage_nonzero':float(np.linalg.norm(h12))})

# Reducer: when P commutes with H, transfer spectrum and full source poles agree.
D=np.diag([0.,1.,3.,5.]);Vred=np.eye(4)[:,1:3];P=Vred@Vred.T;T=Vred.T@np.diag(np.exp(-np.diag(D)))@Vred
ms=-np.log(np.linalg.eigvalsh(T))
check('VIIB reducing trial-space exactness',['BH-VIIB-G-0148'], np.allclose(sorted(ms),[1.,3.]) and np.linalg.norm(P@D-D@P)==0,{'trial_energies':ms.tolist(),'full_visible_energies':[1,3]})

# Paper IV-C: truncated bosonic CCR with occupation margin.
N=7;ain=np.diag(np.sqrt(np.arange(1,N+1)),1);ad=ain.T
comm=ain@ad-ad@ain
Pmargin=np.diag([1.]*(N-2+1)+[0.]*2)
err_occ=np.linalg.norm(Pmargin@(comm-np.eye(N+1))@Pmargin)
check('IVC sharp occupation CCR margin',['BH-G-000102'],err_occ<1e-14 and abs(comm[-1,-1]+N)<1e-14,{'N':N,'margin':2,'compressed_defect':err_occ,'boundary_defect':comm[-1,-1]},'algebraic E3/E4')

# Paper IV-C: m(t) positive, nonstationary formula and exact Nambu coefficient.
t=sp.symbols('t',real=True);m=1+t*t;ell=9*m
Om2=sp.simplify(ell/m-sp.diff(m,t,2)/(2*m)+sp.diff(m,t)**2/(4*m*m))
# independent formula from x=log m: Om2 = ell/m -(1/2)x'' -(1/4)(x')^2
x=sp.log(m);ind=sp.simplify(ell/m-sp.diff(x,t,2)/2-sp.diff(x,t)**2/4)
r=sp.diff(sp.sqrt(Om2),t)/(2*sp.sqrt(Om2))
check('IVC nonstationary Hessian regularity and pairing',['BH-G-000103'],sp.simplify(Om2-ind)==0 and float(Om2.subs(t,sp.Rational(1,3)))>0 and abs(float(r.subs(t,0)))<1e-14,{'Omega_squared':str(Om2),'r_of_t':str(sp.simplify(r))},'symbolic E3')

# Paper IV-C: no generic exact recurrence for a time-dependent finite generator.
# H(t)=t sigma_z -> U(t)=diag(exp(-i t**2/2), exp(+i t**2/2)).
# periodicity U(t+T)=U(t) for all t implies exp(-i(T*t+T**2/2))=1 for all t, i.e. T=0.
for T in (0.5,1.,math.pi,2*math.pi):
 f=lambda q: np.diag([np.exp(-.5j*q*q),np.exp(.5j*q*q)])
 assert np.linalg.norm(f(T)-f(0))>1e-6 or np.linalg.norm(f(1+T)-f(1))>1e-6
check('IVC nonautonomous finite recurrence counterexample',['BH-G-000104'],True,{'H_t':'t sigma_z','U_t':'diag(exp(-i t^2/2),exp(+i t^2/2))','no_nonzero_global_period':'coefficient T of t in phase must vanish'},'analytical E4')

# Paper IV-C: detector diagonal => no cross interference though coherences survive.
rho=np.array([[.5,.5],[.5,.5]]);E=np.diag([1.,0.]);Pa=np.diag([1.,0.]);Pb=np.diag([0.,1.]);interf=np.trace(rho@Pa@E@Pb+rho@Pb@E@Pa)
check('IVC detector-specific missing interference not dephasing',['BH-G-000105'],abs(interf)<1e-14 and abs(rho[0,1])>.4, {'interference':float(interf),'offdiagonal_density':float(rho[0,1])},'counterexample E4')

# Paper IV-C: N=1 2x2 cutoff gives phi(t)=cos(sigma t), kappa4=-2 sigma^4.
# Two independent modes with nonzero real coefficients; signs cannot cancel even cumulant.
c=[2.5,-3.0];sig=[.75,1.4];expected=-2*sum((a*b)**4 for a,b in zip(c,sig))
q1,q2=sp.symbols('q1 q2',real=True); u=sp.symbols('u',real=True)
phi=sp.cos(sp.Rational(5,2)*sp.Rational(3,4)*u)*sp.cos(-3*sp.Rational(7,5)*u)
k4=sp.diff(sp.log(phi),u,4).subs(u,0)
check('IVC nonzero cumulant sign survives multimode coefficients',['BH-G-000106'],abs(float(k4)-expected)<1e-10 and float(k4)<0,{'observed_kappa4':str(k4),'predicted':expected,'c':c,'sigma':sig},'symbolic independent product E3')

# Paper III-C rank-one REG constant.
value=(math.log(2)/6)/math.log(2)/math.sqrt(2)
check('IIIC REG rank one constant and scoped alternatives',['BH-IIIC-ALTMEASURE-001'],abs(value-1/(6*math.sqrt(2)))<1e-15 and 'This is not an exhaustive classification of modifications' in src('Paper3C-ProtectedHierarchy-v1_191.tex'),{'delta':value,'scope':'unique only in fixed REG clauses'},'source + arithmetic E3')

# Paper III-C depth time hits & orientation under both signs.
al=math.exp(3.0);q=lambda tt:7*(1-math.exp(-tt));w=.8
hit_err=max(abs(al**(-w*q(-math.log(1-j/7)))-al**(-w*j)) for j in range(1,7))
check('IIIC exact finite depth hits and terminal limit',['BH-IIIC-DEPTHARG-002'],hit_err<1e-12 and abs(al**(-w*7)-math.exp(-w*7*3))<1e-12,{'max_hit_error':hit_err,'j_sequence':list(range(1,7)),'terminal':'tau -> infinity, not finite tau_7'},'finite algebra E3')

# Paper III-D positive part, distributional Hessian jump.
C,U=2.,4.
Hj=lambda R: C if R<=C else (R**2+U*C)/(U+C)
right=2*C/(U+C);left=0.
check('IIID glued Laurent distributional Hessian',['BH-IIID-HATJUNC-001'],abs(Hj(C-1e-8)-Hj(C+1e-8))<1e-7 and abs(right-left-2*C/(U+C))<1e-14 and abs(2/(U+C)-1/3)<1e-14,{'jump_strength':right-left,'smooth_density':2/(U+C),'terminal_constant_hessian':0},'piecewise analytic E3')

# Paper III-D Qsigma generated positive character, not physical gravity action.
Qsig=12.;nx=.25;D4=Qsig**nx
check('IIID positive scalar character and D4 evaluation',['BH-IIID-DCHARPORT-002'],abs(Qsig**(.3+.9)-Qsig**.3*Qsig**.9)<1e-12 and abs(D4-math.exp(nx*math.log(Qsig)))<1e-14,{'Qsigma':Qsig,'n4plus':nx,'D4':D4},'finite scalar character E3')

# Paper VII-C full-ground projector versus one chosen vector.
HH=np.diag([0.,0.,1.,3.]);Pfull=np.diag([1.,1.,0.,0.]);Pone=np.diag([1.,0.,0.,0.]);t0=1.2;KT=np.diag(np.exp(-t0*np.diag(HH)))
exc=np.linalg.norm((np.eye(4)-Pfull)@KT@(np.eye(4)-Pfull),ord=2)
wrong=np.linalg.norm((np.eye(4)-Pone)@KT@(np.eye(4)-Pone),ord=2)
check('VIIC transfer norm on full ground complement',['BH-VIIC-G-0001'],abs(exc-math.exp(-t0))<1e-14 and abs(wrong-1)<1e-14,{'full_ground_complement_norm':exc,'one_ground_vector_complement_norm':wrong},'counterexample E4')

# VII-C constructed limit algebra has cluster state even if unique state not proven.
# Example alternating state on C^2: two distinct limit values on the same constant cylinder projector.
values=np.array([0.,1.]*20)
check('VIIC cluster existence versus uniqueness separation',['BH-VIIC-G-0002'],len(set(values))==2 and np.all((values>=0)&(values<=1)),{'two_subsequence_limits':[0,1],'QFT4_E':'satisfied on product quotient','QFT4_C':'not satisfied'},'bounded-state counterexample E4 + source proof replay')

# VII-C CAR alone does not ensure region-locality, separate overlap guard.
f=np.array([1.,0.]);g=np.array([1.,1.])/math.sqrt(2)
check('VIIC CAR cross anticommutator not necessarily zero',['BH-VIIC-G-0003'],abs(np.dot(f,g)-1/math.sqrt(2))<1e-14 and np.dot(f,g)>.7,{'overlap':float(np.dot(f,g))},'CAR E4')

# VII-C nonlinear involution parity with nonzero ordinary even jet.
x=sp.symbols('x');born=-x/(1+x);psi=sp.simplify((x-born)/2)
check('VIIC nonlinear Born involution adapted chart',['BH-VIIC-G-0008'],sp.simplify(born.subs(x,born)-x)==0 and sp.simplify(psi.subs(x,born)+psi)==0 and sp.diff(psi,x,2).subs(x,0)!=0,{'B(x)':str(born),'Psi(x)':str(psi),'Psi_second_derivative_at0':str(sp.diff(psi,x,2).subs(x,0))},'adversarial symbolic E4')

# VI-C inherited S3 eigen-wavenumber sqrt(k(k+2))/R.
R=7.;wavenumber=lambda k: math.sqrt(k*(k+2))/R
check('VIC S3 Laplacian eigen-wavenumber not integer mode index',['BH-VIC-G-0138'],abs(wavenumber(1)-math.sqrt(3)/R)<1e-14 and abs(wavenumber(2)-math.sqrt(8)/R)<1e-14,{'k1':wavenumber(1),'k2':wavenumber(2),'R':R},'closed sphere eigenvalue E3')

# VI-C reheating product numbers.
tr=2.9588e9*(3/5)**.25
check('VIC split reheating numerical factor',['BH-VIC-G-0141'],abs(tr/1e9-2.6041)<5e-5,{'computed_GeV':tr,'printed_GeV':2.6041e9,'saturated_comparison_only':True},'independent arithmetic E3')

# VI-C one-sided return sum well-defined only for y>0; acceleration product extends to zero.
def nu(y):return 1/(-math.expm1(-math.sqrt(y)))
yvals=[1e-2,1e-4,1e-6,1e-8];accs=[y*nu(y) for y in yvals]
check('VIC Reeb return multiplier diverges but acceleration product vanishes',['BH-VIC-G-0143'],nu(yvals[-1])>nu(yvals[0]) and all(accs[i]>accs[i+1] for i in range(len(accs)-1)) and accs[-1]<.00011, {'y':yvals,'multiplier_at_small_y':nu(yvals[-1]),'acceleration_products':accs},'asymptotic E3')

# VI-C C56 dimension / radius identity.
U=10.;alpha=2.;C56=U*alpha**-7;R56=math.sqrt(C56)
check('VIC C56 equals physical radius squared',['BH-VIC-G-0147'],abs(C56-R56*R56)<1e-14 and abs(C56/U-alpha**-7)<1e-14,{'U':U,'alpha':alpha,'C56':C56,'R56_squared':R56**2},'dimension / algebra E3')

# Enforce current manuscript occurrence for corrected VI-C formulas and precise domain.
v6=src('Paper6C-TechnicalMaterial-v1_51.tex')
check('VIC source of repaired formulas and explicit guards',['BH-VIC-G-0138','BH-VIC-G-0141','BH-VIC-G-0143','BH-VIC-G-0147'],all(p in v6 for p in [r'\sqrt{k(k+2)}',r'2.6041\times10^9',r'\nu_{\rm Reeb}(0)',r'C_{56}:=\mathcal R_{56}^{\,2}']), {'source':'Paper6C-TechnicalMaterial-v1_51.tex'},'source E0')

out={'schema':'BornHopf.BoundedCrossPaperReverification.v1','scope':'exact formula/scoped counterexample checks only; no entire-paper global E3/E4','checks':results,'counts':{'passed':sum(int(x['passed']) for x in results),'total':len(results)},'current_VIIB_sha256':hashlib.sha256(v7.encode()).hexdigest(),'status':'PASS' if all(x['passed'] for x in results) else 'FAIL'}
Path('/mnt/data/_work_nov18/Batch2VerificationResults-v1_1.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'status':out['status'],'checks':out['counts'],'issues_touched':len(set(i for a in results for i in a['issue_ids'])),'sha256':out['current_VIIB_sha256']},indent=2))
