# Born–Hopf Geometry: three exact mathematical closures after v2_347

**Research proof package:** `Paper00-MultiGapClosures-v1_1`  
**Date:** 7 November 2026  
**Canonical baseline:** `Paper00-PapersMinimal-v2_347(1).zip` (unchanged).  
**Prior, separate mathematical inputs:** `Paper00-TwistedHarmonicAlias-v1_1`; `Paper3G-BornMeronHodge-v1_1`; exact finite level-one and cutoff definitions in Papers I–IV.  
**Constitutional status:** G0 and GP1–GP3 are fundamental principles, unchanged; these are *conditional mathematical exports*, not new physical occurrences or assumptions.

## A. Complete finite-versus-continuous cubic and quartic invariant defect

### Theorem A1 — Exact invariant and alias ranks through quartic order

Let \(V_2\cong\mathbb C^5\) denote the spin-two irreducible of \(SU(2)\); its restriction to the binary icosahedral group \(G=2I\) descends to the unique quintet of \(A_5=G/\{\pm1\}\). For \(k=1,2,3,4\), define the two self-adjoint Haar-averaging projectors on \(V_2^{\otimes k}\):

\[
\Pi_k^G=\frac1{|G|}\sum_{g\in G}\rho_2(g)^{\otimes k},\qquad
\Pi_k^{SU(2)}=\int_{SU(2)}\rho_2(g)^{\otimes k}\,dg.
\]

They are orthogonal projectors, and \(\operatorname{ran}\Pi_k^{SU(2)}\subseteq\operatorname{ran}\Pi_k^G\). Consequently \(\Pi_k^G-\Pi_k^{SU(2)}\) is itself an orthogonal projector.

The \(A_5\) quintet character on classes \((1,2A,3A,5A,5B)\) is \((5,1,-1,0,0)\) with class sizes \((1,15,20,12,12)\). Thus for \(k\ge1\)

\[
\dim(V_2^{\otimes k})^G=\frac{5^k+15+20(-1)^k}{60}.
\]

The continuous invariants of \(V_2^{\otimes k}\) have dimensions \(0,1,1,5\), respectively, by coupling spin two repeatedly. The finite invariant dimensions are \(0,1,2,11\). Hence

| Tensor order | Continuous rank | Finite rank | Difference rank |
|---|---:|---:|---:|
| \(k=1\) | 0 | 0 | 0 |
| \(k=2\) | 1 | 1 | 0 |
| \(k=3\) | 1 | 2 | **1** |
| \(k=4\) | 5 | 11 | **6** |

The previously proved 11-design/degree-12 invariant theorem for \(2I\) implies that among integer spin sectors \(0\le J\le8\), the only \(G\)-fixed vectors lie at \(J=0\) (the continuous invariant) and at \(J=6\) (one additional invariant). Writing the standard \(SU(2)\) isotypic decomposition

\[
V_2^{\otimes k}=\bigoplus_{J=0}^{2k} M_{J,k}\otimes V_J,
\]

and letting \(v_6\) be any unit \(G\)-fixed vector in the 13-dimensional \(V_6\), the complete correction for \(k=3,4\) is

\[
\boxed{\Pi_k^G-\Pi_k^{SU(2)}
=\mathbf1_{M_{6,k}}\otimes|v_6\rangle\langle v_6|
\text{ on the spin-six summand, and }0\text{ elsewhere}.}
\]

The multiplicities are \(\dim M_{6,3}=1\) and \(\dim M_{6,4}=6\), giving the defect ranks above. This is not a conjectured extra coupling: it is the *entire* exact finite-minus-continuous averaging operator up through quartic degree.

**Character witnesses.** Setting \(f(g)=\chi_2(g)\),

\[
\int_{SU(2)} f^3=1,\quad \frac1{|G|}\sum_G f^3=2;
\qquad
\int_{SU(2)} f^4=5,\quad \frac1{|G|}\sum_G f^4=11.
\]

Thus the character examples exhibit exactly \(+1\) and \(+6\) excess invariants. The numbers count mathematical invariant contractions; they are not hadronic mass terms.

### Theorem A2 — Explicit continuum vertex tensors, no fitted coefficients

Let \(D^{(2)}_{ab}(g)\) denote Wigner spin-two matrix coefficients with \(a,b\in\{-2,-1,0,1,2\}\), and set \(u_{ab}=\sqrt5D^{(2)}_{ab}\). Normalized Haar integration yields the complete cubic coefficient tensor

\[
\boxed{\int u_{ab}u_{cd}u_{ef}\,dg
=5^{3/2}
\begin{pmatrix}2&2&2\\a&c&e\end{pmatrix}
\begin{pmatrix}2&2&2\\b&d&f\end{pmatrix}.}
\]

The complete quartic two-holomorphic/two-antiholomorphic vertex is

\[
\boxed{\begin{aligned}
&\int u_{ab}u_{cd}\overline{u_{ef}u_{gh}}\,dg\\
&=25\sum_{J=0}^{4}\frac1{2J+1}
\sum_{M,N=-J}^{J}
 C^{JM}_{2a,2c}C^{JN}_{2b,2d}
 \overline{C^{JM}_{2e,2g}C^{JN}_{2f,2h}},
\end{aligned}}
\]

where \(C\) are ordinary unit-normalized Clebsch–Gordan coefficients. For instance, the \(m=0\) matrix coefficient obeys \(\int (D^{(2)}_{00})^3dg=2/35\) and \(\int (D^{(2)}_{00})^4dg=3/35\), independently checked through Legendre-polynomial integration.

For the corresponding *raw 120-vertex* vertex tensors, add precisely the projector defect of Theorem A1 to the continuous averaging operator. The existing positive \(IJI\) degree-19 cubature instead reproduces both tensors exactly without aliasing. These are two mathematically equivalent ways to prevent an accidental new interaction coefficient caused by a substitution of measures.

**Owners, if integrated:** I-A/I-C for the tensor algebra; I-B for comparison cubature; III-B and VII-A for typed scalar/action source consistency checks. No claim that the physical action *uses* the spin-two sector or its cubic/quartic vertex.

## B. Born–meron: exact determinant and every small-time heat coefficient

### Theorem B1 — Explicit zeta determinant of the fundamental meron test

Use the **previously established** mathematical operator identity \(D_B^2\simeq\Delta_0\oplus\Delta_1\) on the round relative three-sphere \(S^3(r)\), with the single zero mode excluded in the zeta determinant. Its positive-spectrum zeta function initially converges for \(\Re s>3/2\):

\[
\zeta_B(s)=2r^{2s}\sum_{n=2}^{\infty}
\left[n^2(n^2-1)^{-s}+(n^2-1)n^{-2s}\right].
\]

Put \(A(s)=\sum_{n\ge2}n^2(n^2-1)^{-s}\) and \(B(s)=\zeta_R(2s-2)-\zeta_R(2s)\). For \(A\), the convergent binomial continuation reads

\[
A(s)=\sum_{k=0}^{\infty}\frac{(s)_k}{k!}\bigl[\zeta_R(2s+2k-2)-1\bigr].
\]

At \(s=0\), \(A(0)=-1\), \(B(0)=1/2\). Differentiating,

\[
A'(0)=2\zeta_R'(-2)-\frac32+S,\qquad
S=\sum_{k=2}^\infty\frac{\zeta_R(2k-2)-1}{k}.
\]

The last series has a closed value. Exchanging the **absolutely convergent** \(k\ge2\) tail with its \(n\ge2\) sum gives

\[
S=\sum_{n=2}^\infty\left[-n^2\log(1-n^{-2})-1\right].
\]

For every integer \(N\ge2\), exact telescoping gives

\[
\sum_{n=2}^N n^2\log(1-n^{-2})=
2\log\Gamma(N)-\log2-(2N-1)\log N+N^2\log(1+1/N).
\]

Applying Stirling to the displayed *finite* equality yields \(S=3/2-\log\pi\). Hence

\[
A'(0)=2\zeta_R'(-2)-\log\pi,\qquad
B'(0)=2\zeta_R'(-2)-2\zeta_R'(0).
\]

Using \(\zeta_R'(0)=-\tfrac12\log(2\pi)\) and \(\zeta_R'(-2)=-\zeta_R(3)/(4\pi^2)\) finally produces

\[
\boxed{\zeta_B(0)=-1,\qquad
\zeta_B'(0)=-2\log r+2\log2-\frac{2\zeta_R(3)}{\pi^2}.}
\]

By definition, \(\det{}'D_B^2=\exp[-\zeta_B'(0)]\), so

\[
\boxed{\det{}'D_B^2=\frac{r^2}{4}\exp\left(\frac{2\zeta_R(3)}{\pi^2}\right).}
\]

For a dimensionless operator \(D_B^2/\mu^2\), the determinant is \((\mu r)^2e^{2\zeta_R(3)/\pi^2}/4\). This fixes scale bookkeeping; it does not select a physical renormalization scale or loop coefficient. Unit-radius numerical value: \(0.3189545366626974069353320562255\ldots\).

### Theorem B2 — Closed all-order local heat expansion

The earlier meron-spectrum closure already gave the exact theta representation, which is **not being re-counted as a new result**:

\[
H_B(t)=\operatorname{Tr}e^{-tD_B^2}
=-(1+e^u)\Theta'(u)-\Theta(u),
\quad u=t/r^2,\quad \Theta(u)=\sum_{n\in\mathbb Z}e^{-u n^2}.
\]

Poisson summation \(\Theta(u)=\sqrt{\pi/u}\,\Theta(\pi^2/u)\) then yields, to *all algebraic orders* as \(t\downarrow0\),

\[
\boxed{
H_B(t)\sim\frac{\sqrt\pi r^3}{t^{3/2}}
\left[1-\frac{t}{2r^2}
+\sum_{k=2}^{\infty}\frac{t^k}{2k!r^{2k}}\right].}
\]

Equivalently \(c_0=1\), \(c_1=-1/2\), and \(c_k=1/(2k!)\) for every \(k\ge2\). The difference between the exact trace and its all-order algebraic expression is exponentially suppressed \(\propto e^{-\pi^2r^2/t}\), up to powers of \(t\). This is an exact *mathematical* spectral calculus for the chosen round fundamental twist; physical occurrence in Paper III's same-action trace is an independent premise, and the meron itself is a Yang–Mills saddle.

**Owner, if integrated:** III-B theorem with III-G analytical certificate; possible III-E comparison to no-insertion spectral action, only on the exact twist domain.

## C. Full finite-oscillator vacuum distribution, resolvent and multimode diagnosis

### Theorem C1 — Exact all-order probability law

Take the same finite single-mode sharp occupation truncation as Paper IV-C v2_347:

\[
a_N|n\rangle=\sqrt n|n-1\rangle,\qquad
q_N=\sigma(a_N+a_N^\dagger),\quad
\sigma^2=\frac\hbar{2\omega},\quad 0\le n\le N,\ N\ge1.
\]

Let \(\operatorname{He}_k\) be the **probabilists' Hermite** polynomials (not the physicists' convention): \(\operatorname{He}_0=1\), \(\operatorname{He}_1=x\), \(\operatorname{He}_{k+1}=x\operatorname{He}_k-k\operatorname{He}_{k-1}\). The Jacobi matrix \(q_N/\sigma\) has off-diagonals \(\sqrt1,\sqrt2,\ldots,\sqrt N\). Therefore

\[
\boxed{\det(xI-q_N/\sigma)=\operatorname{He}_{N+1}(x).}
\]

Let \(x_1,\ldots,x_{N+1}\) be its distinct real roots. The spectral measure seen by the vacuum \(|0\rangle\) is exactly

\[
\boxed{d\mu_N(x)=\sum_{j=1}^{N+1} w_j\delta_{\sigma x_j}(dx),
\qquad w_j=\frac{N!}{(N+1)\operatorname{He}_N(x_j)^2}>0,
\qquad \sum_jw_j=1.}
\]

Hence **every** vacuum Borel observable and the complete characteristic function are determined, not just the first cutoff-sensitive cumulant:

\[
\langle0|f(q_N)|0\rangle=\sum_jw_j f(\sigma x_j),\qquad
\phi_N(t)=\sum_jw_j e^{it\sigma x_j}.
\]

The endpoint resolvent has a subtlety worth explicitly preserving. Define the **associated Hermite** polynomials \(H^{[1]}_0=1\), \(H^{[1]}_1=z\), \(H^{[1]}_{n+1}=zH^{[1]}_n-(n+1)H^{[1]}_{n-1}\). Then

\[
\boxed{\langle0|(z-q_N)^{-1}|0\rangle
=\frac1\sigma\frac{H^{[1]}_N(z/\sigma)}{\operatorname{He}_{N+1}(z/\sigma)}.}
\]

The numerator is **not** the ordinary \(\operatorname{He}_N\) when \(N\ge2\). It is the characteristic polynomial of the trailing principal Jacobi submatrix. The equivalent finite continued fraction is

\[
G_N(z)=\cfrac{1}{z-\cfrac{\sigma^2}{z-\cfrac{2\sigma^2}{\ddots-\cfrac{N\sigma^2}{z}}}}.
\]

These statements follow from the orthogonal-polynomial recurrence, Christoffel–Darboux normalization and Cramer's rule for the \((0,0)\) resolvent entry. The weights are exactly the \((N+1)\)-node Gauss–Hermite weights for the normalized Gaussian measure of variance one. Consequently \(\mu_N\) integrates every polynomial of degree at most \(2N+1\) exactly as the Gaussian vacuum, agreeing with the v2_347 cutoff-moment theorem; here the **entire discrete spectral distribution and all higher moments** are newly supplied. Since the Gaussian moment problem is determinate and the second moments are uniformly bounded, \(\mu_N\) converges weakly to \(\mathcal N(0,\sigma^2)\) as \(N\to\infty\).

### Theorem C2 — Independent multimode cutoff signature cannot cancel

Let \(q_{N_a}^{(a)}\) act on independent tensor factors in the product vacuum, with real coefficients \(c_a\) and widths \(\sigma_a>0\). Set \(Q=\sum_a c_aq_{N_a}^{(a)}\). Its entire characteristic function factorizes exactly:

\[
\boxed{\phi_Q(t)=\prod_a\phi_{N_a}(c_at).}
\]

For nonzero \(c_a\), let \(m=\min_a(N_a+1)\). Then every cumulant of \(Q\) at even order \(4,6,\ldots,2m-2\) is zero, and its **first** non-Gaussian cumulant is

\[
\boxed{\kappa_{2m}(Q)=-m!\sum_{a:N_a+1=m}(c_a\sigma_a)^{2m}<0.}
\]

The proof uses cumulant additivity for independent tensor factors and the v2_347 one-mode first-defect theorem. Because the sum contains nonnegative even powers, **no relative real sign of the mode coefficients can cancel this first signal**. This gives an explicit observable criterion for the smallest present sharp occupation cutoff in this mathematical family. For an example, \(N_1=1,N_2=2,c_1=2,c_2=1,\sigma_1=\sigma_2=1\) gives \(\kappa_4(Q)=-32\), verified with an exact 6-by-6 tensor product matrix.

**Owners, if integrated:** IV-C for the full finite-quadrature spectral measure, IV-B for conditional source/measurement implications. This does **not** derive the physical cutoff, authorize a quadrature apparatus or identify the regular CCR vacuum with any chosen finite cutoff.

## Provenance, scope and exact certificate

- Theorem A strengthens the earlier twisted-harmonic sampling alias *by providing complete tensor-projector ranks and universal cubic/quartic vertex coefficients*. The 25-dimensional harmonic lift and 19-design/IJI correction were proved previously, and are not re-claimed here.
- Theorem B extends the earlier full Born–meron spectrum and theta heat trace *by evaluating the zeta determinant and all local heat coefficients*. The spectral-flow and zero-mode theorems are inherited, not new.
- Theorem C extends v2_347's first finite-cutoff moment/cumulant *to the full discrete probability law, exact resolvent and a rigorous multimode cutoff noncancellation theorem*.
- Each assertion is conditional on the exact mathematical domain used in the source. No new hypothesis is appended to G0, GP1, GP2 or GP3. In particular, choosing a \(2I\) comparison sector, a fundamental spin twist, a sharp occupation cap, or a source/measurement is **not** inferred from the formulas.
- Not established: a common-action hadron correlator, QCD running replacement, a physical four-dimensional meron gauge field, a mass pole, a physical finite occupation cap or a cosmological observable.

Run `python Paper00-MultiGapClosures-v1_1-verify.py` with SymPy, mpmath, NumPy to reproduce exact character, Clebsch–Gordan, Hermite/resolvent, full truncation moment, numerical zeta-continuation and theta-transform checks. See the `-results.json` file for verification details. The mathematical arguments above cover all orders indicated; a finite matrix check alone is not claimed as their proof.
