#!/usr/bin/env python3
"""Reproducible integer certificate: 25-coset/Petersen, 2-covers, glued Reye frames.

Finite A5 computations are used for all projective 2I labels. Each A5 element
is counted twice only in the binary-icosahedral 120 x 25 incidence matrix.
No mass or physical source operator is inferred.
"""
import itertools
import json
from collections import Counter, defaultdict
from pathlib import Path

import networkx as nx
import numpy as np

OUT = Path(__file__).with_name('Paper00-PetersenBridges-v1_3-output.json')

def even(p):
    return sum(p[i] > p[j] for i in range(len(p)) for j in range(i+1,len(p))) % 2 == 0

def compose(a, b):
    return tuple(a[b[i]] for i in range(5))

def perm_order(a):
    e=tuple(range(5)); p=e
    for k in range(1, 61):
        p=compose(a,p)
        if p==e:return k
    raise ValueError('not a permutation of order <=60')

def sign_of_sequence(p):
    return (-1) ** sum(p[i]>p[j] for i in range(len(p)) for j in range(i+1,len(p)))

S5=list(itertools.permutations(range(5)))
A5=[p for p in S5 if even(p)]
assert len(A5)==60
identity=tuple(range(5))
pairs=list(itertools.combinations(range(5),2))
order=Counter(perm_order(p) for p in A5)
assert order == {1:1,2:15,3:20,5:24}

# Five A4 cores, as subsets of the projective group A5.
cores=[{g for g in A5 if g[i]==i} for i in range(5)]
assert all(len(h)==12 for h in cores)
assert all(len(cores[i]&cores[j])==3 for i,j in pairs)
assert len(set.union(*cores))==36

# 25 coset cells C_ij = {g in 2I: overline(g)(j)=i}; lift A5 rows twice.
B=np.array([[int(g[j]==i) for i in range(5) for j in range(5)]
            for g in A5 for _ in (0,1)],dtype=np.int64)
assert B.shape==(120,25)
assert np.all(B.sum(axis=0)==24)
assert np.all(B.sum(axis=1)==5)
R=np.array([[int(i!=k and j!=l) for k in range(5) for l in range(5)]
            for i in range(5) for j in range(5)],dtype=np.int64)
G25=B.T@B
assert np.array_equal(G25,24*np.eye(25,dtype=np.int64)+6*R)
assert np.linalg.matrix_rank(B)==17
assert sorted(np.rint(np.linalg.eigvalsh(G25)).astype(int).tolist()) == [0]*8+[30]*16+[120]

# Unordered core-pair indicators v_ij=1_{Cij}+1_{Cji}.
V=np.array([[int(g[j]==i)+int(g[i]==j) for (i,j) in pairs]
            for g in A5 for _ in (0,1)],dtype=np.int64)
A=np.array([[int(not set(a)&set(b)) for b in pairs] for a in pairs],dtype=np.int64)
J=np.ones((10,10),dtype=np.int64)
G10=V.T@V
assert np.array_equal(G10,48*np.eye(10,dtype=np.int64)+12*A+12*J)
assert sorted(np.rint(np.linalg.eigvalsh(G10)).astype(int).tolist()) == [24]*4+[60]*5+[204]
assert np.array_equal(A@A,2*np.eye(10,dtype=np.int64)-A+J)

# Hodge-signed Petersen adjacency S_H = star(c wedge .) on Lambda^2 R5.
S=np.zeros((10,10),dtype=np.int64)
for b,(i,j) in enumerate(pairs):
    for a,(k,l) in enumerate(pairs):
        if set((i,j)).isdisjoint((k,l)):
            m=next(t for t in range(5) if t not in (i,j,k,l))
            S[a,b]=sign_of_sequence((m,i,j,k,l))
assert np.array_equal(S,S.T)
assert np.array_equal(S@S@S,5*S)
assert np.array_equal((S!=0).astype(np.int64),A)

# Antisymmetric coset functions a_ij = 1_{Cij} - 1_{Cji}.
C=np.array([[int(g[j]==i)-int(g[i]==j) for (i,j) in pairs]
            for g in A5 for _ in (0,1)],dtype=np.int64)
assert np.array_equal(C.T@C,12*S@S)
assert np.all(V.T@C==0)
assert np.linalg.matrix_rank(C)==6
assert sorted(np.rint(np.linalg.eigvalsh(C.T@C)).astype(int).tolist())==[0]*4+[60]*6

# S5 parity twist: wedge representation T_pi S_H T_pi^T = sgn(pi) S_H.
for p in S5:
    T=np.zeros((10,10),dtype=np.int64)
    for b,(i,j) in enumerate(pairs):
        ni,nj=p[i],p[j]
        T[pairs.index(tuple(sorted((ni,nj)))),b]=1 if ni<nj else -1
    sign=1 if even(p) else -1
    assert np.array_equal(T@S@T.T,sign*S)

# The six Sylow-5 axes, their complementary 10-triangle RP2 systems, and
# exact parity exchange under all S5 permutations via the exceptional action.
def inverse(p):
    a=[0]*len(p)
    for i,j in enumerate(p):a[j]=i
    return tuple(a)

def generated_cyclic_five(g):
    h=identity; elements=[]
    for _ in range(5):
        elements.append(h)
        h=compose(h,g)
    return frozenset(elements)

sylow5=sorted(
    {generated_cyclic_five(g) for g in A5 if perm_order(g)==5},
    key=lambda grp:tuple(sorted(grp))
)
assert len(sylow5)==6
sylow_index={grp:i for i,grp in enumerate(sylow5)}
def six_axis_action(g):
    inv=inverse(g)
    return tuple(sylow_index[frozenset(compose(compose(g,h),inv) for h in grp)]
                 for grp in sylow5)

six_actions={g:six_axis_action(g) for g in S5}
assert len(set(six_actions.values()))==120
seed=(0,1,2)
Fplus={tuple(sorted(six_actions[g][i] for i in seed)) for g in A5}
Fminus={tuple(sorted(set(range(6))-set(face))) for face in Fplus}
assert len(Fplus)==len(Fminus)==10 and not (Fplus&Fminus)
fplus={}; fminus={}
for ij in pairs:
    stabilizer=[g for g in A5 if {g[i] for i in ij}==set(ij)]
    fix_plus=[t for t in Fplus
              if all({six_actions[g][i] for i in t}==set(t) for g in stabilizer)]
    fix_minus=[t for t in Fminus
               if all({six_actions[g][i] for i in t}==set(t) for g in stabilizer)]
    assert len(fix_plus)==len(fix_minus)==1
    fplus[ij],fminus[ij]=fix_plus[0],fix_minus[0]
    assert set(fplus[ij]).isdisjoint(fminus[ij])

cross=np.array([[int(len(set(fplus[x])&set(fminus[y]))==1) for y in pairs]
                for x in pairs],dtype=np.int64)
assert np.array_equal(cross,A)
for g in S5:
    act=six_actions[g]
    for ij in pairs:
        target=tuple(sorted(g[i] for i in ij))
        image=tuple(sorted(act[i] for i in fplus[ij]))
        assert image==(fplus[target] if even(g) else fminus[target])

# Graph double covers from voltage matrices S and -A.
def cover(s):
    p=(A+s)//2; n=(A-s)//2
    return np.block([[p,n],[n,p]])
L_dod=cover(S)
L_des=cover(-A)
assert np.all(np.diag(L_dod)==0) and np.all(np.diag(L_des)==0)
assert np.array_equal(L_dod,L_dod.T) and np.array_equal(L_des,L_des.T)
assert nx.is_isomorphic(nx.from_numpy_array(L_dod),nx.dodecahedral_graph())
assert nx.is_isomorphic(nx.from_numpy_array(L_des),nx.desargues_graph())

def eigen_count(a):
    return dict(sorted(Counter(np.rint(np.linalg.eigvalsh(a)).astype(int)).items()))

def cycle5(P):
    found=set()
    for cyc in nx.simple_cycles(nx.DiGraph(nx.from_numpy_array(P))):
        if len(cyc)!=5:continue
        candidates=[]
        for c in (cyc,list(reversed(cyc))):
            for shift in range(5):candidates.append(tuple(c[shift:]+c[:shift]))
        found.add(min(candidates))
    return sorted(found)
cycles=cycle5(A)
flux=Counter(int(np.prod([S[cyc[i],cyc[(i+1)%5]] for i in range(5)])) for cyc in cycles)
assert len(cycles)==12 and flux=={1:6,-1:6}

# Reye hexagon planes in the projective A5 labels: for each core A4,
# the 16 left cosets of its four C3 subgroups are 3-line great hexagons.
planes_by_core=[]
for H in cores:
    C3={frozenset((identity,g,compose(g,g))) for g in H if perm_order(g)==3}
    assert len(C3)==4
    plans=set()
    for sub in C3:
        for g in H:
            plans.add(frozenset(compose(g,h) for h in sub))
    assert len(plans)==16 and all(len(t)==3 for t in plans)
    planes_by_core.append(plans)
all_planes=set.union(*planes_by_core)
assert len(all_planes)==70
shared_planes=Counter(len([pl for pl in planes_by_core if s in pl]) for s in all_planes)
assert shared_planes=={1:60,2:10}
core_axis_mult=Counter(sum(line in H for H in cores) for line in A5)
assert core_axis_mult=={0:24,1:15,2:20,5:1}
line_degrees=Counter()
for pl in all_planes:
    for elem in pl:line_degrees[elem]+=1
assert len(line_degrees)==36
valency=Counter(line_degrees.values())
assert valency=={4:15,7:20,10:1}
assert sum(line_degrees.values())==len(all_planes)*3==210

# v1_3: 25-cell factorization of the rank-fifteen projector, exact integer.
# Use 3000*Pi15 = 4*B*((5I-J) tensor (5I-J))*B^T - 25*chi4*chi4^T.
M5=5*np.eye(5,dtype=np.int64)-np.ones((5,5),dtype=np.int64)
centered_integer=B@np.kron(M5,M5)@B.T
chi4=np.array([sum(g[i]==i for i in range(5))-1
               for g in A5 for _ in (0,1)],dtype=np.int64)
P15_integer=4*centered_integer-25*np.outer(chi4,chi4)
chi4diff=np.array([[sum(compose(inverse(g),h)[i]==i for i in range(5))-1
                    for h in A5 for _ in (0,1)]
                   for g in A5 for _ in (0,1)],dtype=np.int64)
assert np.array_equal(centered_integer,25*chi4diff)
assert np.array_equal(P15_integer,25*(4*chi4diff-np.outer(chi4,chi4)))
assert np.array_equal(P15_integer@P15_integer,3000*P15_integer)
assert np.linalg.matrix_rank(P15_integer)==15
assert np.all(P15_integer@chi4==0)
assert np.all(P15_integer@np.ones(120,dtype=np.int64)==0)
assert np.array_equal(P15_integer@C,3000*C)

# v1_3: core-contained Reye=70, full induced Reye=80, ranks 35 and 36.
all_C3=set()
for h in A5:
    if perm_order(h)!=3:continue
    subgroup=frozenset((identity,h,compose(h,h)))
    for g in A5:
        all_C3.add(frozenset(compose(g,t) for t in subgroup))
assert len(all_C3)==200
U=set.union(*cores)
induced={p for p in all_C3 if p <= U}
assert len(induced)==80 and all_planes <= induced
order2_stars=induced-all_planes
assert len(order2_stars)==10
assert all(all(perm_order(h)==2 for h in plane) for plane in order2_stars)
U_list=sorted(U)
def reye_mat(planes):
    return np.array([[int(g in plane) for plane in sorted(planes,key=lambda q:tuple(sorted(q)))]
                     for g in U_list],dtype=np.int64)
R70=reye_mat(all_planes); R80=reye_mat(induced)
assert np.linalg.matrix_rank(R70)==35
assert np.linalg.matrix_rank(R80)==36
z=np.array([-2 if perm_order(g) in (1,2) else 1 for g in U_list],dtype=np.int64)
assert np.all(z@R70==0)
assert sum(z@R80!=0)==10

# v1_3: correct action side for left-convolution using 6 Sylow-5 axes.
# In the 6-dimensional permutation representation the nontrivial 5D
# constituent restricts to A4 as 1' + 1'' + 3. Shell average 8 3-cycles:
# eigenvalues -1/2,-1/2,0,0,0, plus 1 on the discarded constant line.
H0=cores[0]
K=np.zeros((6,6),dtype=np.int64)
for h in H0:
    if perm_order(h)==3:
        perm=six_actions[h]
        for i,j in enumerate(perm):K[j,i]+=1
assert sorted(np.linalg.eigvalsh(K).round(8))==[-4.,-4.,0.,0.,0.,8.]

results={
 'version':'Paper00-PetersenBridges-v1_3',
 'A5_element_orders':dict(order),
 'five_2T_cores_projective_axes':[len(H) for H in cores],
 'projective_axes_in_union':len(set.union(*cores)),
 'projective_axis_multiplicities_across_cores':dict(core_axis_mult),
 'coset_incidence_matrix_shape':list(B.shape),
 'coset_Gram_eigenvalues':{'120':1,'30':16,'0':8},
 'coset_incidence_rank':17,
 'antisymmetric_coset_rank':6,
 'antisymmetric_coset_Gram_identity':'C.T@C == 12*(S_H@S_H)',
 'symmetric_antisymmetric_coset_orthogonal':True,
 'six_Sylow5_axes':len(sylow5),
 'six_axis_triangles_each_RP2':len(Fplus),
 'Desargues_as_cross_RP2_incidence_verified':True,
 'S5_parity_exchange_RP2_correspondence_permutations_verified':len(S5),
 'symmetric_coset_Gram_eigenvalues':{'204':1,'60':5,'24':4},
 'symmetric_coset_Petersen_decomposition':{'trivial':1,'four':4,'five':5},
 'Hodge_signed_spectrum':'(+sqrt(5))^3, 0^4, (-sqrt(5))^3',
 'S5_parity_twist_permutations_verified':len(S5),
 'Petersen_pentagon_count':len(cycles),
 'Hodge_sign_pentagon_fluxes':{str(k):v for k,v in flux.items()},
 'positive_voltage_cover_is_dodecahedron':True,
 'all_negative_voltage_cover_is_Desargues':True,
 'dodecahedral_cover_spectrum':'3^1, sqrt(5)^3, 1^5, 0^4, (-2)^4, (-sqrt(5))^3',
 'Desargues_cover_eigenvalues':{str(k):v for k,v in eigen_count(L_des).items()},
 'Reye_each_core_axes':12,
 'Reye_each_core_hexagon_planes':16,
 'glued_unique_projective_axes':len(line_degrees),
 'glued_unique_hexagon_planes':len(all_planes),
 'glued_plane_multiplicity_by_cores':dict(shared_planes),
 'glued_line_valency_distribution':dict(valency),
 'glued_incidence_pairs':sum(line_degrees.values()),
 'P15_integral_projector_identity':'(3000*P15)^2 == 3000*(3000*P15)',
 'P15_rank':15,
 'P15_binary_factorization':'P15=1/30*B*(Q tensor Q)*B.T-chi4*chi4.T/120',
 'Reye_full_induced_hexagons':len(induced),
 'Reye_extra_mixed_core_222_hexagons':len(order2_stars),
 'Reye_core_contained_rank':int(np.linalg.matrix_rank(R70)),
 'Reye_full_induced_rank':int(np.linalg.matrix_rank(R80)),
 'core_shell_six_axis_integer_eigenvalues':[-4,-4,0,0,0,8],
 'kernel_10_action_side':'right regular (commutes with left convolution)',
 'physical_interpretation':'none; finite geometry only',
}
OUT.write_text(json.dumps(results,indent=2,sort_keys=True)+'\n')
print(json.dumps(results,indent=2,sort_keys=True))
