# Born–Hopf Geometry — Full 120-carrier Petersen operator and exact marked-source spectral reduction

**Version:** `v2_334`  
**Date:** 2026-11-06  
**Status:** Research note; exact finite incidence/operator derivations and independently checked integer/character certificates. **No physical hadron Hamiltonian or meson spectrum is derived.** Canonical papers, macro, bibliography and theorem DAG are unchanged.

**Authoritative paper baseline:** `/mnt/data/Paper00-PapersMinimal-v2_326(1).zip`. New independent research inputs: `Paper00-PetersenIncidence-v2_330.md`, `Paper00-PetersenResponse-v2_331.md`, `Paper00-PetersenCouplings-v2_333.md` and their verification programs. The earlier research notes are not themselves canonical amendments.

**Canonical anchors:** Paper I-A Petersen axes; Paper V-B the five-core incidence map and polar spectrum; Paper VII-A `p10:def:finite-qcd-compilation-datum`, `p10:eq:compiled-hamiltonian-matrix`, `p10:eq:singlet-entry-factorization`, `p10:thm:complete-schur-scalar-source`, `p10:def:v323-action-incidence-test`; Paper VII-B `p11:prop:v323-actual-hadron-spectrum-criterion`, `p11:def:hadronic-eigenvalue-problem`.

## 1. Do not confuse finite incidence with the physical QCD Hamiltonian

The exact finite regular carrier is `F=C[2I]` with dimension 120. Central inversion `g->-g` gives `F = F^+ ⊕ F^-`, with dimensions 60 and 60. On `F^+ ≅ C[A5]`, character orthogonality gives

```
F^+ = F_1 ⊕ F_4 ⊕ F_5 ⊕ F_3,3prime
   = F_17 ⊕ F_25 ⊕ F_18,
17 = 1²+4², 25=5², 18=3²+3'².
```

These are *group-function* spaces. They are not automatically color-singlet physical Fock sectors. Paper VII-A defines its actual operator at finite level `L` by

`H_L=P_sing^(L)(H_YM,L+H_q,L+H_int,L)P_sing^(L)`.

The physical operator additionally consumes a color-gauge-compatible realization/embedding of these geometric functions (or an associated one-particle module), a selected actual quark mass-operator member, RG-transported coupling, gauge action/transfer source, and the full occupation/singlet construction. None is supplied by the 120 incidence matrix alone.

## 2. An exact, canonical 120 × 120 *incidence* operator

Let `B10` be the binary-icosahedral Petersen pair-incidence map

`B10[g,(T,S)] = 1{π(g)S=T}`,

where `π:2I->A5` and `S,T` are two-element subsets of five labels. Define

`K120=B10 B10*`.

By Schur orthogonality,

`K120=120 P1 +30 P4 +24 P5`, annihilating `P_(3⊕3prime)` and `F^-`. Thus

`spec(K120)={120^1,30^16,24^25,0^78}`,

and it is positive self-adjoint and rank 42. This identity is **dimensionless** and is not an energy prediction. For functions on `A5` normalized unitarily to `F^+`,

`K(g,h)=2[1+χ4(g^-1 h)+χ5(g^-1 h)]`.

Its entries are exactly `20` on the identity relative class, `4` on double transpositions, `2` on three-cycles and `0` on five-cycles. Every row sums to 120. The full 120-element kernel is `K120=K ⊗ (J2/2)` in the permutation-lifts ordering. (Individual 120×120 entries are `10,2,1,0`.)

**Transfer obstruction.** `K120/120` is a positive semidefinite symmetric stochastic contraction with eigenvalues `1`, `1/4`, `1/5`, `0`. As it has 78 exact zeros, it cannot equal `exp[-t(H-E0)]` at finite `t>0` for any *finite self-adjoint* Hamiltonian `H`: a matrix exponential is strictly positive definite. A logarithm could be defined only on its rank-42 support; a regularization requires an additional, source-owned prescription. Thus this incidence matrix must not be silently promoted to the actual Paper VII-A transfer operator.

## 3. The exact three-stratum source family

Fix a two-core Petersen marking `S={0,1}`. Its A5 images have `|S∩gS|=2,0,1`, corresponding to 12,36,72 elements of `2I` (6,18,36 on `A5`). Let `D12,D36,D72` be their orthogonal diagonal masks. They satisfy

`D12+D36+D72=I`.

The most general diagonal source that depends *only* on this trichotomy is

`V(u)=u12 D12+u36 D36+u72 D72 = u72 I+(u12-u72)D12+(u36-u72)D36`.

Thus it has only two independent shape contrasts modulo an overall scalar shift. The full geometric family `K120+V(u)` is exact for symbolic `u`, but no particular values are sourced as physical energy coefficients.

In the `17+25+18` center-even basis its block form is

```
K^+(u) = [ K17+V17,17    V17,25        V17,18     ]
         [ V25,17        24 I25+V25,25 V25,18     ]
         [ V18,17        V18,25        V18,18     ],
K17=120 I1 ⊕ 30 I16.
```

Let `P_17=P_1+P_4`, `P_25=P_5`, `P_18=P_3+P_3prime`. Each matrix entry below is `||P_a D_r P_b||_HS²`, in the normalized 60-element `A5` realization (equivalently on the even part of `2I`):

| Original source class | 17→17 | 17↔25 | 17↔18 | 25→25 | 25↔18 | 18→18 |
|---|---:|---:|---:|---:|---:|---:|
| same pair, 12 | 57/100 | 13/20 | 12/25 | 5/4 | 3/5 | 18/25 |
| disjoint pair, 36 | 53/20 | 5/4 | 6/5 | 19/4 | 3/2 | 27/10 |
| overlap one, 72 | 7 | 2 | 6/5 | 23/2 | 3/2 | 81/10 |

All blocks indicated by positive norms are nonzero. In particular

`||[P25,D12]||_HS²=5/2`, `||[P25,D36]||_HS²=11/2`, `||[P25,D72]||_HS²=7`.

The existing Petersen-projector connectivity lemma strengthens this to the exact criterion

`[P25,V(u)]=0 iff u12=u36=u72`.

That is, any *nonconstant* diagonal pair-stratum source mixes `F25` with `F17 ⊕ F18`. The center-odd sector is nevertheless separately invariant for `K120` and these **center-even** masks. A general source-owned QCD Hamiltonian is not thereby known to preserve the same grading.

## 4. A symmetry reduction for all three marked occupancy values

Let `H=Stab_A5(S)` be the stabilizer of a two-core marking. It is isomorphic to `S3` and has order six. The three occupancy classes are H-double cosets; the scalar functions `D_r` are invariant under `g -> h_l g h_r`, with `h_l,h_r∈H`. The convolution operator `K` is left-right A5 invariant. Consequently every member `K+V(u)` commutes with left and right `H` actions.

The restrictions of A5 irreps to H (with H irreps `1`, `eps`, `2`) are:

```
1|H    = 1,
3|H    = eps ⊕ 2,
3'|H   = eps ⊕ 2,
4|H    = 1 ⊕ eps ⊕ 2,
5|H    = 1 ⊕ 2·2.
```

The `H×H`-module decomposition of `C[A5] = ⊕_ρ Vρ⊗Vρ*` therefore has multiplicity matrix

```
        right:  1  eps  2
left  1         3   1   3
      eps       1   3   3
       2        3   3   7
```

The dimension check is `Σ_(a,b) d_a d_b m_ab=60`, with `d=(1,1,2)`. Hence an arbitrary `K+V(u)` is unitarily block reducible to **nine Hermitian matrices of orders at most seven**, with external multiplicities `d_a d_b`. This is a structural reduction, not a claim of nine mass levels or a completely specified physical Hamiltonian.

## 5. An exactly solvable fully coupled source: K(t)=K+tD12

Work on the 60 center-even degrees of freedom and select only the pair-preserving mask. `D12` has rank six there. The unperturbed `K` eigenvalue projectors are `P1,P4,P5,P33` with eigenvalues `120,30,24,0`, respectively. Their restrictions to `C[H]` are simultaneously scalar on the trivial, sign and standard H irreps. The exact spectral weights of those restrictions are

| H isotypic channel | P1 (120) | P4 (30) | P5 (24) | P33 (0) | multiplicity |
|---|---:|---:|---:|---:|---:|
| trivial | 1/10 | 2/5 | 1/2 | 0 | 1 |
| sign | 0 | 2/5 | 0 | 3/5 | 1 |
| standard | 0 | 1/5 | 1/2 | 3/10 | 4 |

Within the rank-six source support the restricted resolvent `(zI-K)^-1` is therefore scalar in each of these channels:

```
g_triv(z)=1/[10(z-120)]+2/[5(z-30)]+1/[2(z-24)]
g_sign(z)=2/[5(z-30)]+3/(5z)
g_std(z)=1/[5(z-30)]+1/[2(z-24)]+3/(10z).
```

Use the rank-six determinant lemma

`det(zI-K-tD12)=det(zI-K) det_[C[H]](I6-t D12(zI-K)^-1 D12)`.

The three scalar factors are rational functions with numerators

```
q_T(z,t)=(z-120)(z-30)(z-24)-t(z²-138z+3024),
q_S(z,t)=z(z-30)-t(z-18),
q_E(z,t)=z(z-30)(z-24)-t(z²-36z+216).
```

Cancelling the unperturbed denominators proves the exact identity

`det(zI60-K-tD12)=z^13 (z-30)^10 (z-24)^20 q_T q_S q_E^4`.

Degree count: `13+10+20+3+2+4·3=60`. The **43 pinned** eigenvalues are `0^13, 30^10, 24^20` and the **17 source-coupled** eigenbranches are the roots of `q_T` (3), `q_S` (2), `q_E` (3 with multiplicity four).

On the 60 center-odd degrees, `K` vanishes and `D12` has rank six, so

`det(zI120-K120-tD12)=z^54 (z-t)^6 × z^13 (z-30)^10 (z-24)^20 q_T q_S q_E^4`.

In particular, for every `t>0` **67 zero modes** survive exactly (`13` center even + `54` center odd). This model cannot be read as a complete resolved physical hadron ground-state spectrum. The statement is a finite spectral obstruction, not a claim about the actual Paper VII-A QCD gap.

### 5a. Exact geometric-source poles, residues, and a 97-dimensional dark space

For the six-dimensional even marked-source support `C[H]=ran D12`, the *full* resolvent compresses to the trivial, sign, and standard `S3` channels:

`D12(z-K-tD12)^(-1)D12|_[C[H]] = Σ_a [g_a(z)/(1-tg_a(z))] E_a = Σ_a [N_a(z)/q_a(z,t)] E_a`,

where `E_a` are the orthogonal `S3`-isotypic projectors of ranks `1`, `1`, `4`, respectively, and

```
N_triv(z)=z²-138z+3024,
N_sign(z)=z-18,
N_std(z)=z²-36z+216.
```

For any simple root `λ` of `q_a(z,t)`, the normalized source residue is

`w_(a,λ) = N_a(λ)/(∂_z q_a)(λ,t) ≥ 0`.

Within each isotypic channel the weights sum to `1`. At `t=0`, they reproduce the exact nonzero weights in the preceding table; at nonzero `t` they redistribute continuously across the coupled roots, while the total source norm remains fixed. This is a **complete source-pole-and-residue** calculation for a native finite incidence perturbation, not a physical meson-current correlator.

**Full operator response identity.** Since `q_a(z,t)=D_a(z)-tN_a(z)`, implicit differentiation at a simple pole gives

`dλ_(a,j)/dt = N_a(λ_(a,j))/[∂_z q_a(λ_(a,j),t)] = w_(a,j)`.

By the finite Hellmann–Feynman theorem this equals `〈ψ_(a,j),D12 ψ_(a,j)〉` for a normalized corresponding eigenvector; it lies in `[0,1]`. Therefore **source-pole residue = spectral response slope** in this full coupled family. The result is not obtained by applying Hellmann–Feynman to the isolated `P25 D12 P25` compression: the complete Schur return is indispensable.

More strongly, the 43 pinned even eigenstates all lie in `ker D12`; likewise the 54 pinned center-odd states. Thus **97 eigenvectors are exactly dark to this marked geometric source**, while the remaining `17+6=23`-dimensional cyclic sector contains all eigenbranches it can excite. A scalar center-even vacuum/interpolator can impose still more selection rules. This is an operator statement, not a count of observable particles.

The factorization was checked independently by direct numerical diagonalization of the complete 60×60 matrix at `t=1,7,24`, with maximum eigenvalue mismatch below `2×10^-13`. The determinant identity and all rational coefficients follow analytically from the finite representation restrictions; the numerical diagonalization is only a cross-check.

## 6. The physical embedding and mass-pole criterion

To convert the exact geometric operator into a hadronic one, the canonical papers require a typed mapping into the **actual compiled color-singlet state space**. In particular:

1. Supply a gauge-compatible map `ι_L` from the selected geometric mode space (and its spin/flavor/occupation lift) to the finite singlet space. Its image must have an explicitly defined norm and conserved-charge labels.
2. Evaluate the source-owned physical matrix `H_L` and its actual blocks in that embedded basis. Do not assign a universal energy factor to `K` or `D_r` from particle masses.
3. Test `(I-ι_Lι_L†) H_L ι_L`; if nonzero, a compression spectrum is **not** a hadron spectrum. Keep the exact Schur return `H_eff(z)=H_PP+H_PQ(z-H_QQ)^-1 H_QP` with the inherited pole norm `Z=+∂_z[z-H_eff(z)]=I+H_PQ(z-H_QQ)^(-2)H_QP` in the resolvent convention used here.
4. Project onto actual color-singlet particle quantum-number channels and measure their lowest **vacuum-subtracted** poles with nonzero hadronic interpolator overlap; evaluate `M_h=E_h-E_0` from those poles. The geometric `120`, `30`, `24` and the source parameter `t` are not themselves MeV.
5. The mass-energy normalizations `E32,E36,E40` may be used as comparison coordinates after the physical operator member is selected; none fixes `H_L` merely through a numerical ratio.

A bare `q qbar` color-singlet subspace is generally coupled to glue and additional Fock sectors. Therefore a meson need not be an eigenvector of the `q qbar` compression; it is a pole of the coupled Hamiltonian and its source correlator.

## 7. Result and the next calculation

**Exact:** all 120 incidence entries, rank/spectrum, 17–25–18 and central-sign grading, marked three-stratum coupling norms, H×H block multiplicities, the full marked `t D12` characteristic polynomial, and the 67-zero-mode no-go. **Not derived:** a physical color-singlet realization of the 120 coefficient space, the physical source coefficients, its QCD gauge/quark Fock Hamiltonian matrix entries, meson charges/spins, and the ground-state mass spectrum.

The next meaningful step is to locate or construct a **source-owned map** from Paper I-A/Paper V-B's Petersen/Hurwitz carrier into the actual `R_q,L`, `R_qbar,L`, `R_g,L` finite modes of Paper VII-A, then compute the full physical Schur blocks and correlator poles. Further diagonalization of arbitrary geometric occupancy potentials without that port would not yet explain an observable.

## 8. Exact reproducibility

Run:

```bash
python Paper00-PetersenFullOperator-v2_334.py
```

The program constructs all 60 even permutations, exact integer A5 character matrices, their four central projectors, the full-lift incidence kernel, all three marked diagonal masks, the nine squared source-block norms, left-right pair-stabilizer invariance, the S3 restriction weights, the `S3×S3` multiplicity matrix, symbolic three-factor resolvents, full 120×120 central-lift diagonalization, exact source-resolvent formulas, and direct matrix spectrum checks. Only NumPy and SymPy are required.

Public mathematics background: standard Schur orthogonality and finite group matrix coefficients; e.g. [Rezk, *Notes on Finite Group Representations*](https://rezk.web.illinois.edu/Finite%20Group%20Reps/notes-on-finite-group-reps.pdf). These general facts are established mathematics. The precise incidence specialization and factorization here are derived in this exploratory construction; novelty in the literature is not claimed.
