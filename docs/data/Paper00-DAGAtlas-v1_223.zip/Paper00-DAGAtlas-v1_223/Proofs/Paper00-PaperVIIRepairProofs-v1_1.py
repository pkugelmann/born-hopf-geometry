#!/usr/bin/env python3
"""Exact small certificates for Paper VII repair addendum v1_1.
No floating-point thresholds, external data or fitted parameters.
"""
from itertools import product, combinations, permutations
import json
from pathlib import Path
import sympy as sp
Q=sp.Rational
V=[]
for i in range(4):
    for sign in (-1,1):
        u=[Q(0)]*4;u[i]=Q(sign);V.append(tuple(u))
for signs in product((-1,1),repeat=4):
    V.append(tuple(Q(i,2) for i in signs))
assert len(V)==len(set(V))==24
ip=lambda a,b:sum(x*y for x,y in zip(a,b))
A=sp.Matrix(24,24,lambda i,j: int(i!=j and ip(V[i],V[j])==Q(1,2)))
assert set(sum(A.row(i)) for i in range(24))=={8}
spectrum=A.eigenvals()
assert spectrum=={sp.Integer(8):1,sp.Integer(4):4,sp.Integer(0):9,sp.Integer(-2):8,sp.Integer(-4):2}
# Moment by all 4-component monomials through total degree 5.
def doublefac(k):
    if k<1:return 1
    return k*doublefac(k-2)
def sphere_moment(alpha):
    if any(x%2 for x in alpha):return Q(0)
    m=sum(alpha)//2
    return Q(sp.prod(doublefac(x-1) for x in alpha), sp.prod(4+2*j for j in range(m)))
num_monomials=0
for alpha in product(range(6),repeat=4):
    if sum(alpha)>5:continue
    empirical=sum(sp.prod(v[i]**alpha[i] for i in range(4)) for v in V)/24
    assert sp.simplify(empirical-sphere_moment(alpha))==0,(alpha,empirical,sphere_moment(alpha))
    num_monomials+=1
# Degrees 0,1,2 real spherical-harmonic evaluation columns.
cols=[sp.ones(24,1)]
cols += [sp.Matrix([v[i] for v in V]) for i in range(4)]
cols += [sp.Matrix([v[i]*v[j] for v in V]) for i,j in combinations(range(4),2)]
cols += [sp.Matrix([v[i]**2-v[3]**2 for v in V]) for i in range(3)]
S=sp.Matrix.hstack(*cols)
assert S.shape==(24,14) and S.rank()==14
for l,lo,hi in [(0,0,1),(1,1,5),(2,5,14)]:
    assert A*S[:,lo:hi]==(8-4*l)*S[:,lo:hi]
LR=(A*A/Q(16))-Q(3,2)*A+8*sp.eye(24)
for l,lo,hi in [(0,0,1),(1,1,5),(2,5,14)]:
    assert LR*S[:,lo:hi]==l*(l+2)*S[:,lo:hi]
# Edge incidence and triangular faces.
E=[(i,j) for i in range(24) for j in range(i+1,24) if A[i,j]==1]
F=[(i,j,k) for i in range(24) for j in range(i+1,24) for k in range(j+1,24) if A[i,j] and A[j,k] and A[i,k]]
assert len(E)==len(F)==96
fans={f'{i},{j}':sum((i in f and j in f) for f in F) for i,j in E}
assert set(fans.values())=={3}
# Polarized determinant contraction: W(A,I,I)=tr(A)/3 != det(A) in general.
A0=sp.diag(-1,-1,1);I=sp.eye(3)
def eps(s):
    if len(set(s))<3:return 0
    return sp.LeviCivita(*s)
def W(A,B,C):
    z=0
    for ijk in permutations(range(3)):
        for abc in permutations(range(3)):
            i,j,k=ijk; a,b,c=abc
            z+=eps(ijk)*eps(abc)*A[i,a]*B[j,b]*C[k,c]/6
    return sp.simplify(z)
assert W(A0,I,I)==Q(-1,3) and A0.det()==1 and W(I,I,I)==1
# Haar character benchmark (from SU(3) character orthogonality).
var_one=Q(1,81)+Q(2,36)
assert var_one==Q(11,162) and var_one/96==Q(11,15552)
# LO second-Mellin DGLAP fixed mode; n_f=3.
nf=3
M=sp.Matrix([[-Q(16,9),Q(nf,3)],[Q(16,9),-Q(nf,3)]])
assert M*sp.Matrix([9,16])==sp.zeros(2,1)
assert M.eigenvals()=={sp.Integer(0):1,-Q(25,9):1}
# Nuclear per-degree ranks versus cumulative ranks.
ranks=[sp.binomial(r+3,3) - (sp.binomial(r+1,2) if r>=3 else 0) for r in range(7)]
assert ranks==[1,4,10,14,25,41,63]
capacities=[2*int(k) for k in ranks]
cumulative=[2*sum(map(int,ranks[:r+1])) for r in range(7)]
assert capacities==[2,8,20,28,50,82,126]
assert cumulative==[2,10,30,58,108,190,316]
# Fock cutoff CCR defect and counterexample with near-ceiling occupancy.
for N in (2,3,6):
    a=sp.zeros(N+1)
    for n in range(1,N+1):a[n-1,n]=sp.sqrt(n)
    bd=sp.eye(N+1)-(N+1)*sp.diag(*([0]*N+[1]))
    assert a*a.H-a.H*a==bd
    if N>1:
        ket=sp.zeros(N+1,1);ket[N-1]=1
        assert (ket.H*bd*ket)[0]==1
        assert (ket.H*a.H*a*ket)[0]==N-1
out={
  'theorem_status':'exact finite algebra / no physical realization inferred',
  'vertices':24,'edges':len(E),'faces':len(F),'incident_faces_per_edge':3,
  'adjacency_eigenvalues':{str(k):int(v) for k,v in sorted(spectrum.items(),key=lambda z:-z[0])},
  'spherical_design_degree':5,'checked_monomials':num_monomials,
  'sampled_scalar_band_dimension':S.rank(),
  'scalar_laplacian_adjacency_polynomial':'(A^2/16 - 3*A/2 + 8*I)/R^2',
  'spherical_laplacian_eigenvalues_times_R2':[0,3,8],
  'polarized_determinant_counterexample':{'A':'diag(-1,-1,1)','W_A_I_I':'-1/3','det_A':1},
  'independent_Haar_face_mean':'1/9',
  'independent_Haar_face_variance':'11/162',
  'independent_Haar_shell_variance':'11/15552',
  'DGLAP_nf3_stationary_Q_G':['9/25','16/25'],
  'DGLAP_nonzero_eigenvalue':'-25/9',
  'degree_ranks':[int(x) for x in ranks],
  'twofold_per_degree_capacities':capacities,
  'twofold_graded_cumulative_capacities':cumulative,
  'CCR_counterexample':'|N-1> has boundary defect 0 but mean number N-1 -> infinity'
}
path=Path(__file__).with_name('Paper00-PaperVIIRepairProofs-v1_1-results.json')
with open(path,'w') as f:json.dump(out,f,indent=2)
print(json.dumps(out,indent=2))
