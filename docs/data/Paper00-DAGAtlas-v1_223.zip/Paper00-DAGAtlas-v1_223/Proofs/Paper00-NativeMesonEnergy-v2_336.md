# Paper00 — Native Meson Rest-Energy Investigation — v2_336

**Status:** Exact finite geometric derivations, verified rank/spectrum certificates, conditional transfer test, and explicit physical gaps. No observed hadron mass has been derived, and no mass calibration is accepted. Canonical papers, macros, bibliography, and theorem DAG are unchanged.

**Baseline:** `Paper00-PapersMinimal-v2_327.zip` (the most recent supplied self-contained archive) together with standalone research notes v2_330–335 for context. The present research uses *no QCD renormalization-group running* to generate a result. Hadron masses enter only as a posteriori numerical diagnostics.

## A. Where the archive already defines a native energy readout

Paper III-F (corollary `p3f:cor:v2168-free-clifford-dispersion`) gives, on its admitted finite free local Clifford branch, the energy symbol

\[
H_*(\mathbf p)=\begin{pmatrix}
 -c_{\mathrm{op}}\boldsymbol\sigma\cdot\mathbf p\otimes I_G & I_2\otimes T_*\\
 I_2\otimes T_*^\dagger & c_{\mathrm{op}}\boldsymbol\sigma\cdot\mathbf p\otimes I_G
\end{pmatrix},
\qquad E_r(\mathbf p)^2=c_{\mathrm{op}}^2|\mathbf p|^2+\varepsilon_r^2.
\]

Thus a properly source-owned rest symbol has a non-QCD, non-RG rest-energy readout: the positive singular values of its actual chiral zero-order block, after *same-action* kinetic normalization. It does not follow that a composite hadron rest energy equals a single such singular value. For a meson, the source-selected two-body Hessian or finite spectral response must be constructed from the same underlying action, retaining off-sector interactions.

Paper V-A already provides an *available* source family factor, but the physical source members are not fixed by mere port existence. The primitive generated comparison source `Y_*=(I_G,I_G,I_G,I_G)` has coincident chiral singular values. In particular, without a noncentral same-action meson source, a pion and kaon cannot obtain distinct rest energies from a universal incidence/color factor alone.

## B. The exact rooted cyclic three-channel source

Let `G=C^3`, `X^3=I`, `X` the cyclic permutation matrix. Paper V-A's generated rooted cell is `(I,C1,C2)` where

\[C_1=X+X^\dagger,\qquad C_2=-i(X-X^\dagger).\]

For the general Hermitian source in its linear span,

\[ R=aI+bC_1+cC_2,\quad a,b,c\in\mathbb R,\]

\[\boxed{\operatorname{Spec}(R)=\{a+2b,\ a-b+\sqrt3 c,\ a-b-\sqrt3 c\}.}\]

Exact invariants:

\[\operatorname{tr}R=3a,\quad \operatorname{tr}R^2=3a^2+6b^2+6c^2,\quad \det R=(a+2b)[(a-b)^2-3c^2].\]

The inverse map is explicit: given arbitrary **signed** eigenvalues `r0,r+,r−`, one can take `a=(r0+r++r−)/3`, `b=(2r0−r+−r−)/6`, `c=(r+−r−)/(2sqrt(3))`. Consequently all three signed levels can be fitted; geometry alone has *not* fixed them. A physical selection of `a,b,c` must be a same-action theorem, not a post-hoc ratio assignment. The positive free rest energies would be the singular values `|r0|,|r+|,|r−|` times their action-owned energy unit, not the signed levels themselves.

As an additional conditional no-go: if one naively treats `R` as a freely varying Hermitian zero-order field with only the already present quartic trace potential `tr(R^4−2Λ²R²)` and no other terms/constraints, stationary eigenvalues obey `r(r²−Λ²)=0`. Every *nonzero* singular value then has the same magnitude `Λ`. Therefore the bare symmetric quartic, by itself, cannot generate a nondegenerate family mass hierarchy. This is a statement about that restricted variational ansatz, **not** a proof that the full native action imposes it.

## C. First two-core appearance of icosahedral triplets

Let `W=R^5` carry the five-core permutation representation of `A5`. With `u=(e1+...+e5)/sqrt5`, write

\[W=\mathbb Ru\oplus V_4,\qquad V_4=u^\perp.\]

As an `A5`-module, `W=1⊕4`, so `Hom_A5(W,3)=Hom_A5(W,3')=0`: a **linear** equivariant map from the five core labels to either icosahedral 3-irrep does not exist.

At oriented pair order, however,

\[\Lambda^2 W=(u\wedge V_4)\oplus \Lambda^2V_4,\qquad \dim=4+6.\]

Since `A5` acts orientation-preservingly on `V4`, its Hodge star commutes with `A5` and splits the bivectors:

\[\boxed{\Lambda^2W\cong4\oplus3\oplus3'.}\]

Hence `Hom_A5(Λ²W,3)` and `Hom_A5(Λ²W,3')` are both one-dimensional. Two-core antisymmetric data are the **first** tensor order at which icosahedral triplets appear. This does *not* make either triplet equal to the physical color or family triple: an action-owned map is still required. It proves a precise minimal representation-theoretic capacity.

For an oriented basis pair `w_ij=e_i ∧ e_j`, contraction with `u` gives `(e_j−e_i)/sqrt5`, squared norm `2/5`. Its orthogonal complement is the simple bivector `(P e_i)∧(P e_j)` of squared norm `3/5`. In four dimensions, a simple bivector has equal self-dual and anti-self-dual squared norms. Therefore

\[\boxed{\|P_4w_{ij}\|^2=\frac25,\qquad \|P_+w_{ij}\|^2=\|P_-w_{ij}\|^2=\frac3{10}.}\]

This holds for **each** of the ten oriented pair labels. All three channel projectors are canonical from the five-core metric and orientation.

## D. Hodge star equals an oriented signed Petersen adjacency

Index the ten rows and columns by the two-element subsets `{i,j}` with ascending orientation. Define

\[
S_{(i,j),(k,l)}=\begin{cases}
\varepsilon_{mijkl},&\{i,j\}\cap\{k,l\}=\varnothing,\ \{m\}=\{1,2,3,4,5\}\setminus\{i,j,k,l\},\\
0,&\text{otherwise},
\end{cases}
\]

with an overall orientation convention. The absolute-value matrix is exactly the ordinary Petersen adjacency `A_P`. The sign is fixed by five-core orientation; it is not a phenomenological signed-edge assignment. On `Λ²W`, the operator `S/sqrt5` equals the four-dimensional Hodge star on `Λ²V4` and vanishes on `u∧V4`.

Exact identities (checked with rational/integer matrices):

\[\boxed{S^3=5S,\quad \operatorname{Spec}(S)=\{(+\sqrt5)^{(3)},(-\sqrt5)^{(3)},0^{(4)}\}.}\]

The spectral projectors are

\[\boxed{P_4=I-S^2/5,\quad P_\pm=\frac12(S^2/5\pm S/\sqrt5).}\]

Each has constant diagonal, respectively `2/5,3/10,3/10`. For an even permutation of core labels, `D(g)SD(g)^T=S`; for odd label relabeling it reverses sign. The signed operator is `A5`-equivariant but not invariant under the full orientation-reversing `S5` relabeling.

The inversion-odd ten-dimensional piece of the **different** Petersen 25 coefficient sector (research note v2_331) is `Λ²(V5)=3⊕3'⊕4`. Its orientation response has restricted eigenvalues `{0^4,(+sqrt5/6)^3,(-sqrt5/6)^3}`. These match exactly the spectrum of `S/6` above, allowing an `A5`-equivariant unitary equivalence after matching handedness, but a *particular* physical intertwiner between those two carriers has **not** been selected. This is a bridge between algebraic sectors, not a rest-mass identity.

## E. Complete center-even incidence without any fitted coefficient

The previous research built unsigned two-subset incidence `B_u : C^100→C^120`, with

\[\operatorname{Spec}(B_uB_u^\dagger)=\{120^{(1)},30^{(16)},24^{(25)},0^{(78)}\}.\]

Build the **oriented** counterpart `B_o`, with matrix entries given by the sign of the induced action on `e_i∧e_j` and duplicated for the two central lifts of each `A5` element. Its exact Gram spectrum is

\[\boxed{\operatorname{Spec}(B_oB_o^\dagger)=\{40^{(18)},30^{(16)},0^{(86)}\}.}\]

The ranks are 42 and 34, with an exact shared 16-dimensional `4⊗4` coefficient sector, so together they span **all** 60 center-even functions. On the full 120-carrier, their unweighted sum `K_+=B_uB_u†+B_oB_o†` satisfies

\[\boxed{K_+=120P_1+60P_4+24P_5+40(P_3+P_{3'}).}\]

Hence

\[\boxed{\operatorname{Spec}(K_+)=\{120^{(1)},60^{(16)},40^{(18)},24^{(25)},0^{(60)}\}.}\]

This provides a canonical **mathematical** positive incidence operator with full rank on the center-even 60-carrier. The equal raw coefficient of each Gram is a natural mathematical counting convention, **not yet proven** to be the physical source-action weight. There is still no source-owned physical Hamiltonian on the meson sector.

A conditional transfer observation: on the center-even subspace only, `T_+=K_+/120` is strictly positive, invertible and contractive, with spectral values `1,1/2,1/3,1/5` of multiplicities `1,16,18,25`. Thus for any postulated positive finite tick `τ`,

\[H_{\mathrm{formal}}=-\frac1\tau\log T_+=\frac1\tau\big[(\log2)P_4+(\log3)(P_3+P_{3'})+(\log5)P_5\big].\]

It has only four energies `0,ln2/τ,ln3/τ,ln5/τ` and is **not** yet the physical Born–Hopf transfer. On the full 120-carrier it remains singular (60 zero modes), so is not an exact finite-time exponential of any finite self-adjoint 120×120 Hamiltonian. A physical center-even/meson sector identification is separately required. The ratio of the two largest nonzero formal energy gaps is `log(5)/log(2)=2.3219`, whereas `m(K±)/m(π±)=3.5371`: a direct, common proportional-to-gap pion/kaon readout from this minimal transfer fails. It also lacks charge-state splitting.

## F. The tempting 25/2 ratio as a rigorous **test**, not a prediction

Two distinct native geometric magnitudes coexist on the five-core label space:

- The canonical primitive counting arrow `N_5:1→∑_i e_i` has norm `sqrt5` (Paper V-B terminal-mass grammar).
- The normalized selected pair `v_S=(e_i+e_j)/sqrt2` overlaps the normalized global vector `u` by `|<u,v_S>|=sqrt(2/5)`.

Therefore their *mathematical* ratio is

\[\boxed{\frac{\|N_5\|}{|\langle u,v_S\rangle|}=\frac5{\sqrt2},\quad \frac{\|N_5\|^2}{|\langle u,v_S\rangle|^2}=\frac{25}2.}\]

This furnishes a geometric origin for a number that was previously encountered only as a charged pion/kaon mass-squared coincidence. It does **not** show both magnitudes are selected as different particle rest energies by the same native action: one is a primitive norm, the other a normalized overlap, and their source/target types and normalization rules differ. An action-owned meson assembly and common energy readout must justify that comparison.

With the framework's reference `E36=219.578897 MeV`, the conditional trial would predict `m_pi=E36 sqrt(2/5)=138.873888 MeV` and `m_K=E36 sqrt5=490.993340 MeV`, versus observed charged `139.570390` and `493.677` MeV. Errors are about −0.499% and −0.544%. The **ratio** agrees to about `0.045%`, but the neutral `K0/pi0` ratio differs from `5/sqrt2` by about `4.27%`. The isospin midpoint ratio differs by `2.12%`. Without a source-derived charge distinction and correction mechanism, the coincidence is not a robust universal meson mass law.

## G. Why the next work must be an action-owned two-body source, not RG running

1. **Assemble a physical two-core pair source:** Provide a typed operator from the five-core oriented-pair space `Λ²W` into the already generated color-singlet, clocked two-constituent physical state. The `4⊕3⊕3'` projectors and `S` above are now explicit mathematical inputs. Do not assume oriented two-core state = quark–antiquark state.
2. **Compile its same-action rest-energy response:** Derive the complete bilinear / two-body Hessian, including off-block coupling, directly from the frozen finite Born–Hopf source and kinetic norm. Use poles of the full resolvent, or its validated finite-time source transfer, rather than a postulated `sqrt(eigenvalue)` mass grammar.
3. **Source-owned sector selection:** Obtain (rather than assign) which source addresses pion and kaon, and distinguish charged from neutral with the framework's existing charge/orientation data.
4. **Actual scale:** Show which already-generated clock/hierarchy energy (`E32`, `E36`, `E40` or another source-owned unit) multiplies the two-body rest pole. A counting Gram eigenvalue is dimensionless.
5. **Blind numerical benchmark:** Predict `pi0`, `pi±`, `K±`, `K0` before consulting their masses. A ratio alone does not suffice.

No QCD RG transport is needed **as an axiom** for the mathematical investigations above. Using direct finite source evolution would be a possible replacement route. However, geometry still must supply the actual source-owned physical generator; rejecting RG by itself does not determine one.

## H. Provenance, verification, and novelty boundary

- The five-core signed Petersen/Hodge construction, `S³=5S`, fixed `(2/5,3/10,3/10)` weights, exact oriented incidence spectrum, and combined center-even operator were independently constructed and checked in `Paper00-NativeMesonEnergy-v2_336.py` (JSON result companion).
- This is a new *connection within the Born–Hopf research program*, not a claim that signed Petersen graphs, Hodge-star decompositions, or the `A5` character table are unknown in mathematics. For background see Zaslavsky et al. on signed Petersen graphs (`https://people.math.binghamton.edu/zaslav/Tpapers/6sp.pdf`) and classical `A5` character theory.
- No meson-mass derivation, physical transfer, explicit same-action two-body source, or charged-neutral correction is established here.
- Canonical papers, bibliography, macros and DAG remain unchanged. Exact results are candidates for a subsequent controlled integration with appropriate ownership and semantic DAG entries.
