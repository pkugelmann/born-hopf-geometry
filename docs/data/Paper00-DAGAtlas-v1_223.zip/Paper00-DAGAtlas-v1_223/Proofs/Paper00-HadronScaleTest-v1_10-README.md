# v1_7 research package

- `Paper00-HadronScaleTest-v1_7.md`: proof and physical-ownership audit.
- `Paper00-HadronScaleTest-v1_7-certificate.py`: deterministic exact character/Gram and color-fan verification (with NumPy for the explicit intertwiner).
- `Paper00-HadronScaleTest-v1_7-results.json`: machine-readable summary of checks.
- `Paper00-HadronScaleTest-v1_7-intertwiner.csv`: normalized `10×5` A5-equivariant isometry, for one conventional seed and choice of complex root.

Source archive read but not modified: `Paper00-PapersMinimal-v2_341(1).zip`.

No mass parameters or hadron data were fitted. No paper or DAG updates are included. This package supersedes v1_6 **only for the new twisted-character bridge**; source-native curvature and its physical constraints from v1_6 remain valid.
