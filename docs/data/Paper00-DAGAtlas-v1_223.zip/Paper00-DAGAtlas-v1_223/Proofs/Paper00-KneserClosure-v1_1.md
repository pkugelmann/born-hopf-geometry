# Born–Hopf Petersen / Kneser Closure — proof and scope audit

**Release:** Paper00-KneserClosure-v1_1  
**Date:** 2026-11-06  
**Baseline:** Paper00-PapersMinimal-v2_325(1).zip  
**Status:** **Finite icosahedral Petersen–Kneser geometry closed on the explicitly stated five-core and six-axis incidence domains.** Abstract odd-Kneser generalization proved. Physical mass predictions, arbitrary higher-graph occurrence, and historical complete theorem-DAG reconciliation **not** established.

## 1. What is generated, rather than stipulated

Start from one occurring, marked binary-icosahedral subgroup `2I ⊂ SU(2)` of the framework, subject to the existing exceptional-completion and same-owner qualifications. Its projective rotation group is `A5`.

It determines:

- Five conjugate tetrahedral subgroups `2T`, with ten distinct pairwise `C6` intersections. Their unordered pairs are the vertices of `KG(5,2)` (Petersen); disjoint pairs are adjacent.
- Six Sylow-5 subgroups of `A5`, or six projective fivefold axes. Their unordered pairs give the fifteen vertices of `KG(6,2)` and its root-line representation.
- Fifteen projective order-two axes, dual to the fifteen Petersen edges and bijective with the fifteen pairs of six fivefold-axis lines.

These are *overlapping elements and incidence carriers of one 2I*, not independent particles or additively combinable masses.

## 2. New completed finite duality: two hemi-icosahedra

Enumerate the action of all 60 elements of `A5` by conjugation on its six Sylow-5 subgroups. The orbits of `k`-element subsets, `k=0,...,6`, have sizes

`1 | 6 | 15 | (10+10) | 15 | 6 | 1`.

The 20 triples split into two 10-element orbits `F+` and `F−`, exchanged by taking set complements. In one consistent labeling of the six fivefold axes:

`F+ = {123,124,135,146,156,236,245,256,345,346}`;

`F− = { {1,...,6} \ t : t ∈ F+ }`.

In each orbit, each pair occurs in exactly two triangles. Each vertex link is a five-cycle. With 6 vertices, 15 edges and 10 faces, this is a triangulated real projective plane `RP²` (the hemi-icosahedron). Each triangle system has Petersen as its dual graph, obtained by joining triangles that share an edge. Its dual adjacency satisfies `A² = 2I − A + J` exactly.

There are two explicit `A5`-equivariant identifications of the ten **core pairs** with the two ten-triangle orbits, one per orbit. For one of them:

| Core pair | Triangle on six axes |
|---|---|
| 12 | 245 |
| 13 | 156 |
| 14 | 123 |
| 15 | 346 |
| 23 | 236 |
| 24 | 146 |
| 25 | 135 |
| 34 | 345 |
| 35 | 124 |
| 45 | 256 |

The second map is obtained by taking the complementary triple in each row. Under either map **disjoint core pairs correspond exactly to triangles sharing two labels**. Thus all fifteen Petersen edges biject with the fifteen `K6` edges, i.e. unordered pairs of fivefold axes. This is a finite *incidence proof*, not a dimensional analogy.

## 3. Signed Hodge duality and mirror exchange

In the five-core label space `V=R⁵`, set `c=e₁+⋯+e₅` and

`S_H = *₅(c ∧ ·) : Λ²V → Λ²V`,  `B = ι_c : Λ²V → V`.

The signed support of `S_H` is precisely Petersen adjacency, and

`B S_H=0`,  `BᵀB + S_H² = 5 I₁₀`,  `S_H³=5 S_H`.

Its spectrum is `(+√5)³, 0⁴, (−√5)³`. The two rank-three spectral subspaces are the conjugate `A5` triplets `3` and `3′`. Their sign is reversed by orientation reversal, not by merely renaming an unsigned graph.

Orienting the two projective-plane triangle systems locally generates signed dual-graph adjacency matrices `S+`, `S−`. Exhaustive exact integer checks give diagonal `±1` matrices `G+`, `G−` satisfying

`S+ = G+ S_H G+`,  `S− = −G− S_H G−`,

with labels `+` and `−` assigned accordingly. Therefore the two complementary hemi-icosahedra reconstruct the two mirror eigenspaces of the *same* five-core Hodge operator.

For either triangle system let `F` be its 15×6 oriented `K6` edge/vertex incidence, and `∂s` the 10×15 signed dual Petersen boundary. Then

`∂s F=0`, `FᵀF=6I₆−J₆`, `∂s∂sᵀ=3I₁₀−S±`,

`dim ker ∂s=5`, `P_tw=FFᵀ/6`.

The normalized 15 root vectors `(e_a−e_b)/√2` span the sum-zero five-space of `R⁶` and have orthogonality graph `KG(6,2)`. This twisted five-dimensional module is equivariantly isometric to the existing Hopf quadrupole module `Sym²₀(R³)`. This supplies an exact route from the projective-plane boundary to the original five-dimensional Clifford quadrupole.

## 4. Universal mathematical generalization

For arbitrary `k≥1`, let `n=2k+1`, `V=Rⁿ`, `c=Σe_i`, and

`B_k=ι_c:ΛᵏV→Λᵏ⁻¹V`, `S_k=*ₙ(c∧·):ΛᵏV→ΛᵏV`.

The underlying unsigned graph of `S_k` is the **odd graph** `KG(2k+1,k)`. Its signed entries are `±1`, and it obeys the exact identities

`S_kᵀ=(−1)^k S_k`, `B_k S_k=0`,

`B_kᵀ B_k + (−1)^k S_k² = (2k+1)I`,

`S_k³=(−1)^k(2k+1)S_k`.

**Proof:** Write `c=√n e₀` and `W=e₀⊥` (dimension `2k`). Decompose `ΛᵏV=(e₀∧Λᵏ⁻¹W)⊕ΛᵏW`. On the first summand `B_kᵀB_k=nI` and `S_k=0`; on the second `B_k=0` and `S_k=√n *_W`. In middle degree, `*_W²=(−1)^kI`. The trace of `S_k` is zero, fixing the equal multiplicities.

`0` has multiplicity `C(2k,k−1)`; nonzero spectral values are `±√n` for even `k`, or `±i√n` for odd `k`, each with multiplicity `C(2k,k)/2`.

Define `H_k=S_k` for even `k` and `H_k=iS_k` for odd `k`. The Hermitian block operator

`D_k = [[0,B_k],[B_kᵀ,H_k]]`

squares to `diag(B_kB_kᵀ, nI)`, so its nonzero spectrum is `±√n` with multiplicity `C(2k,k−1)+C(2k,k)/2` each; the remaining zero multiplicity is `C(2k,k−2)`. For `k=2` this yields the previously derived 15-dimensional `−√5` (7), `0` (1), `+√5` (7) Dirac-type resolution.

For **general** unsigned `KG(n,k)`, `n≥2k`, the standard Johnson/Kneser adjacency spectrum is

`λ_j=(−1)^j C(n−k−j,k−j)` with multiplicity `C(n,j)−C(n,j−1)`, `j=0,...,k`.

This standard result is independent of the special orientation-based signed construction. The classical *generalized Petersen* family `GP(n,k)` is different and is **not** identified with `KG(n,k)`.

| Odd graph | Vertex count | Degree | Signed nonzero eigenvalues |
|---|---:|---:|---|
| `KG(3,1)` | 3 | 2 | `±i√3` (one each) |
| `KG(5,2)` | 10 | 3 | `±√5` (three each) |
| `KG(7,3)` | 35 | 4 | `±i√7` (ten each) |
| `KG(9,4)` | 126 | 5 | `±3` (35 each) |

All displayed matrices were checked exactly by integer arithmetic for `k=1,2,3,4`, and the general theorem is proved for every `k`.

## 5. The sharp *physical realization* limit

The abstract odd-graph series does **not** imply that new Hurwitz cell classes exist. The natural five- and six-label sets above are genuine `A5` orbits attached to one `2I`. The immediate next higher odd graph `KG(7,3)` would need seven homogeneous labels. Such a transitive `A5` orbit cannot exist because 7 does not divide 60; likewise a nine-label orbit cannot. Composite, nontransitive or externally marked label sets remain possible, but do not follow from the same-owner construction without additional evidence. Even if a 15-object orbit supports an abstract `KG(15,7)`, this does not mean occupied seven-tuples or physical operators are generated.

Thus the finite geometry in this *specified incidence domain* is complete: the five-core pair structure, the six-fivefold-axis pair/triangle structure, their signed Hodge operators, root quintet, and universal abstract extension all have explicit constructions and checks. **This is not a proof that all Born–Hopf geometry is complete.**

## 6. The strongest physically relevant established source result

Paper III-F's existing rank-two metric-source vertex does admit a nonzero projected `3→3′` block in the first homogeneous angular band containing both triplets (`ℓ=5`, the upper `j=9/2` coupled branch). With `κ=ℏ/(a√Vγ)`, an axial unit shear `S_x=√(3/2)(xxᵀ−I/3)` gives `C_x=P₃′d⁽⁵⁾(S_x)P₃`, where

`Tr(C_x† C_x) = 189κ²/25`.

The threefold, twofold, and fivefold source-direction transfer singular values are respectively

- `√21 |κ|/5 × (1,2,2)`;
- `3√21 |κ|/10 × (φ,1,φ⁻¹)`;
- `3√21 |κ|/5 × (1,0,0)`.

The exact norm comes from `Tr(P₃ T_z P₃′ T_z)=126`, verified independently using the 120 exact binary-icosahedral matrices in `Sym¹⁰(C²)` (see `Paper1A-Spin5MirrorCertificate-v1_1.py`). The *full*, unprojected axial operator has the same spectrum in every spatial direction by rotation covariance. These are **sector-resolved transition amplitudes, not physical mass poles**.

The precise unresolved physical statement remains the same-owner, color-gauge-compatible embedding into the finite singlet Hamiltonian, including actual occupation/source preparation, off-band mixing, and resolvent pole/residue calculations. Paper VII-A's existing incidence test explicitly requires such an embedding; it is not supplied by the graph calculation. A third source of confusion to exclude is the primitive root Clifford source, whose isolated symmetric trace-free quadratic contraction vanishes identically.

## 7. Proof certificate and paper integration

Two current paper sources were amended in the source-only research release:

- **Paper1A-Geometry-v5_148.tex:** two six-axis projective planes, canonical five/six-axis correspondence, signed-Hodge equivalence, twisted-root quintet, general odd-Kneser/Dirac theorems and explicit same-owner limit.
- **Paper3F-CompleteDynamics-v1_248.tex:** action-owned spin-five rank-two metric insertion, exact mirror-transfer block norm and axis singular values, with explicit non-pole caveat.

Both updated sources compile with `pdflatex`. A companion machine-readable `DAG/KneserClosureDelta-v2_326.json` records new labels, source lines, and local theorem dependencies. The existing historical canonical DAG remains the older frozen graph; the preceding 122 Petersen labels and the complete historical proof graph have not undergone a global semantic re-audit. It would be inaccurate to relabel that graph as synchronized. The physical chapters are not modified to insert speculative mass or color identifications.

**Reproducibility:** `python3 Paper00-KneserClosure-v1_1.py` checks 60-element `A5`, six Sylow-5 subgroups, all seven subset-size orbits, both 10-face surfaces, their dual Petersen graphs, the equivariant maps, 15-edge bijections, signed-gauge equality, twisted projector, `KG(6,2)` roots, and general Hodge/Dirac/Kneser spectra. Every finite equality in the certificate is tested on integer matrices; spectral comparison of ordinary unsigned graphs uses floating-point eigenvalue checks as an additional check only, with the analytic spectral formula stated above.

### Established external mathematics for attribution

- The standard Kneser spectrum and Johnson scheme: https://www.sciencedirect.com/science/article/am/pii/S0095895618300285
- The six Sylow-5 subgroups and faithful icosahedral action: https://www.daniellitt.com/blog/2020/12/26/the-geometry-of-the-sylow-theorems/
- The exceptional six-point action and its relation to the outer automorphism of `S6`: https://people.math.harvard.edu/~landesman/assets/outer-automorphism-exercises.pdf

**Conclusion:** The five-core Petersen graph is exceptional as a *native icosahedral realization*; the mathematical signed-Hodge recipe generalizes exactly to all odd Kneser graphs. The two hemi-icosahedra and fifteen root lines complete the finite five/six-axis duality. No additional graph is required to finish this specified combinatorial calculation. Physical spectrum predictions require a separate action-level proof.
