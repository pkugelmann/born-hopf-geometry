from pathlib import Path
sroot=Path('/mnt/data/_work_nov18/sources')
old=sroot/'Paper7B-QCDReadouts-v1_163.tex'
new=sroot/'Paper7B-QCDReadouts-v1_164.tex'
s=old.read_text()
s=s.replace('% Framework v3.026: five-core sourced spectral-weight residual and explicit physical embedding guard.', '% Framework v3.032: correct finite two-state trial-transfer versus full physical pole identification using the already-derived source-visible Schur resolvent.\n% Framework v3.026: five-core sourced spectral-weight residual and explicit physical embedding guard.',1)
s=s.replace('\\date{Version 1.163 --- 17 November 2026 \\\\ Framework source integration v3.026}', '\\date{Version 1.164 --- 18 November 2026 \\\\ Framework source integration v3.032}',1)
# If date replacement did not match, explicit
assert 'Version 1.164' in s, 'version date replacement failed'
old_thm='''  The Gram reduction therefore introduces no fit parameter.  Enlarging the trial subspace gives the usual Rayleigh--Ritz approximants; convergence to physical poles additionally requires the stated refinement/continuum hypotheses.'''
new_thm=r'''  The Gram reduction therefore introduces no fit parameter.  On nested same-channel trial spaces, the min--max principle applied to the positive transfer operator gives monotone Ritz approximants to its largest eigenvalues, hence nonincreasing trial energies at fixed transfer time.  These are Ritz values of the \emph{transfer operator}, not in general eigenvalues of a compressed Hamiltonian or poles of the full resolvent. Identification with finite-volume physical pole energies requires a reducing spectral sector or a separate source-visible full-resolvent certificate. Continuum pole claims additionally require their stated refinement/continuum hypotheses.'''
assert old_thm in s
s=s.replace(old_thm,new_thm,1)
old_proof='''Finite matrix multiplication fixes all entries before comparison.  The min--max principle gives the monotone variational control for nested subspaces of the self-adjoint Hamiltonian.  Norm/strong-resolvent convergence and isolation of the relevant eigenvalue are separate analytic hypotheses for a continuum limit.'''
new_proof=r'''Finite matrix multiplication fixes all entries before comparison.  Put $K=e^{-t(H_L-E_{0,L})}>0$. For any nested same-channel subspaces $V\subset W$ with Gram-orthogonal projectors, the Courant--Fischer formula for the compressed \emph{same} Hermitian operator $K$ gives $\lambda_j(K|_V)\leq\lambda_j(K|_W)$ for every ordinal $j\leq\dim V$, with the eigenvalues sorted decreasingly. Since $-\log(\cdot)/t$ reverses this order, the corresponding trial energies are nonincreasing under enlargement. In general $P e^{-tH_L}P\ne e^{-t P H_L P}$; the statement is not an identification of either compressed spectrum with the full pole set. If $P$ reduces $H_L$ the equality holds on $\operatorname{Ran}P$ and the full-resolvent spectral projection certifies the visible poles. Without reduction the full-resolvent test of Proposition~\ref{p11:prop:two-support-full-resolvent-pole-certificate} is necessary. Norm/strong-resolvent convergence and isolation of the relevant eigenvalue are separate analytic hypotheses for a continuum limit.'''
assert old_proof in s
s=s.replace(old_proof,new_proof,1)
# Replace specifically block from corollary begin through subsequent proof end
start=s.index('\\begin{corollary}[First two-support pole extraction]')
end=s.index('\\end{proof}',start)+len('\\end{proof}')
oldblock=s[start:end]
replacement=r'''\begin{corollary}[First two-support transfer extraction and conditional pole identification]
\label{p11:cor:first-two-support-pole-extraction}
Let a channel \(\chi\) have two non-null Gram-orthonormal native support states
\(|A\rangle,|B\rangle\).  In that basis the first nontrivial transfer block is
\begin{equation}
\label{p11:eq:first-two-support-transfer-block}
K^{(\chi)}_{AB}(t)=\begin{pmatrix}
\lambda_A&\kappa_{AB}\\
\overline{\kappa}_{AB}&\lambda_B
\end{pmatrix},
\qquad
\kappa_{AB}(t)=\langle A|\widehat K_L(t)|B\rangle .
\end{equation}
Its two exact \emph{trial-transfer} eigenvalues are
\begin{equation}
\label{p11:eq:first-two-support-eigenvalues}
\lambda_{\pm}^{(\chi)}
=\frac{\lambda_A+\lambda_B}{2}
\pm
\sqrt{\left(\frac{\lambda_A-\lambda_B}{2}\right)^2+
|\kappa_{AB}|^2},
\end{equation}
and the corresponding transfer-energy approximants (retaining the legacy
cross-reference label) are
\begin{equation}
\label{p11:eq:first-two-support-pole-masses}
M_{0,1}^{(\chi)}(t)=-t^{-1}\log\lambda_{\pm}^{(\chi)}(t) .
\end{equation}
Thus same-channel mixing lowers the lightest \emph{trial} energy and raises the
orthogonal trial partner whenever \(\kappa_{AB}\ne0\), while the shift is
computed from the native overlap, not from a tunable mixing angle.  The two
values are exact finite \emph{physical} pole energies if this non-null
support space reduces the physical \(H_L\) in its selected conserved
channel.  Without that certificate, their actual physical-pole content is
determined instead by the source-visible full resolvent of
Proposition~\ref{p11:prop:two-support-full-resolvent-pole-certificate};
a trial-transfer eigenvalue alone is not a pole assertion.
\end{corollary}
\begin{proof}
The displayed spectrum is the exact spectrum of the complex Hermitian
two-by-two compression.  A relative rephasing makes \(\kappa_{AB}\)
nonnegative real but is not needed for the formula. Positivity of the
finite transfer makes both eigenvalues positive on the non-null span.
The larger eigenvalue increases and the smaller decreases with
\(|\kappa_{AB}|\), so applying \(-t^{-1}\log\) yields the claimed trial
energy shifts. If the support projector \(P_{AB}\) commutes with \(H_L\),
then \(P_{AB}e^{-t(H_L-E_{0,L})}P_{AB}\) is the transfer of the actual
restricted Hamiltonian. Its eigenvalues are \(e^{-t(E_n-E_{0,L})}\)
for genuine full-Hamiltonian eigenvectors in that subspace, and their
nonzero spectral residues are visible to the spanning interpolators.
Without this commutation, no spectral-correlator pole bridge applies to
the two compressed eigenvalues in general.
\end{proof}

\begin{proposition}[Exact full-resolvent certification of two-support physical poles]
\label{p11:prop:two-support-full-resolvent-pole-certificate}
Let \(P=P_{AB}\) be the orthogonal projector onto the two-source support,
\(Q=I-P\), and \(\widetilde H_L=H_L-E_{0,L}I\). The exact compressed
source-visible resolvent is
\begin{equation}
\label{p11:eq:two-support-schur-pole-certificate}
P(z-\widetilde H_L)^{-1}P
=\Bigl[zP-P\widetilde H_LP-\Sigma_P(z)\Bigr]_{\operatorname{Ran}P}^{-1},
\quad
\Sigma_P(z)=P\widetilde H_LQ
\bigl[zQ-Q\widetilde H_LQ\bigr]_{\operatorname{Ran}Q}^{-1}
Q\widetilde H_LP,
\end{equation}
for \(z\) in the joint resolvent domain where the indicated inverses
exist. A real finite spectral value \(\epsilon\) is a pole in the
\(P\)-visible correlator if and only if
\(P\Pi_{\epsilon}(\widetilde H_L)P\ne0\); then its residue is precisely
\(P\Pi_{\epsilon}(\widetilde H_L)P\). In particular, the bare two-state
transfer eigenvalues do not determine full physical poles whenever the
source leaks into \(Q\). For a selected physical finite \(H_L\), the
full-resolvent computation is an exact non-fitted pole readout; it does
not independently establish that the required physical owner has been
realized or that a continuum pole limit exists.
\end{proposition}
\begin{proof}
Block inversion of \(z-\widetilde H_L\) relative to
\(\operatorname{Ran}P\oplus\operatorname{Ran}Q\) proves the Schur identity.
The finite spectral theorem gives
\(P(z-\widetilde H_L)^{-1}P=
\sum_{\epsilon}P\Pi_{\epsilon}(\widetilde H_L)P/(z-\epsilon)\).
For distinct real \(\epsilon\) there is no cancellation between
these simple pole terms, so the residue is nonzero exactly under the
stated source-visibility test. If \([P,\widetilde H_L]=0\), the leakage
term vanishes, and the transfer eigenvalues match the visible full
Hamiltonian poles. Otherwise the self-energy must be retained. This is
the two-support specialization of the previously established full
source-resolvent interface also used in
Proposition~\ref{p11:prop:v3023-mobile-2i-pole-interface}.
\end{proof}'''
s=s[:start]+replacement+s[end:]
assert len(s)>len(old.read_text())
new.write_text(s)
print('written',new,len(s),'orig',len(old.read_text()))
