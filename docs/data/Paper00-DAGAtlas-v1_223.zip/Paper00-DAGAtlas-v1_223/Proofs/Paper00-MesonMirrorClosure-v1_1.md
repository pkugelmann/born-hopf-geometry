# Meson mirror / spin diagnostic — release v2_327

**Research status:** two-core Petersen projector and partial-involution identities are exact; the proposed spin tensor block is exact as abstract linear algebra but is NOT a physical meson model until a native same-action Hamiltonian embedding, source residues and projected coefficients are computed. No hadron mass formula, constant squared gap or Koide relation is claimed.

## Mathematical results

- Two-core contrast has spectrum ±sqrt(3/20) (multiplicity two for each sign) plus two zeros. Thus Q=(20/3)D² is an orthogonal rank-four projector, with two active directions per core; U=sqrt(20/3)D has eigenvalues ±1 (two each), 0 (two). For the grading C=P_m-P_n: {C,U}=0 and [C,Q]=0. Restricted to ran(Q), C and U are two anticommuting involutions (two copies of a real rank-two Clifford pair).
- **Important correction**: Q is core block-diagonal and is only an *eligibility* projector; it is not a witness of coherence. U is the off-diagonal transport operator.
- For any isometric embedding i into a native self-adjoint gap Hamiltonian K, the positive operator identity i†K²i=(i†Ki)²+B†B holds with B=(I-ii†)Ki. Ignoring B generally corrupts a purported squared-mass formula.
- A *conditional ansatz* on (two-core six-space) × (two spin-half states, four-space) has M²=aI+bU⊗I+κQ⊗(σ₁·σ₂). Its formal spectrum is a (8), a±b−3κ (2 each), a±b+κ (6 each), and its centered second trace is 16b²+48κ². These are not computed hadronic pole positions.
- Generic coherent-vs-orthogonal support contractions follow the Gram formula. For 40+40+40 with common overlap γ, ||u₁+u₂+u₃||²=120+240γ and γ∈[-1/2,1]. Geometry alone does not set γ or physical masses.

## Observable, not postselection

Compare matched pseudoscalar/vector *ground-state* meson channels via Δ_f^(2)=M_V,f²−M_P,f² and S_f=(M_P,f²+3M_V,f²)/4. Their approximate squared gaps differ by flavor, with heavy-quarkonium counterexamples. The approximate heavy–light squared-gap regularity is established HQET phenomenology, **not a discovery** of this work. A native derivation must produce the QCD spin and color source, reducing-space/leakage certificate, residue and all coefficients without using the measured meson spectrum to select parameters.

## Release contents and owner assignment

Paper I-A v5_149 owns exact mirror/Clifford geometry. Paper VII-A v1_152 owns compression-leakage identity and conditional spin block. Paper VII-B v1_137 owns the Gram diagnostic and observable targets. Global bibliography and macros are preserved unchanged. Machine-readable source anchors and a new semantic delta are updated; the canonical theorem DAG remains the verified historical v2_316 graph and is *not* claimed fully reaudited. Run `python3 Paper00-MesonMirrorCertificate-v1_1.py` for the exact canonical-form certificate (which reconstructs the exact 15-edge Petersen matrix from the ten Paper I-A axes and checks all ten core pairs).
