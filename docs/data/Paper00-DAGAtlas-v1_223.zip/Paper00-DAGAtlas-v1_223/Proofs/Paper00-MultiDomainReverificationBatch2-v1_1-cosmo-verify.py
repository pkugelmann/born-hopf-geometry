#!/usr/bin/env python3
"""Independent bounded checks for source-edited cosmology and paper interfaces (not global physics proof)."""
from pathlib import Path
import math,cmath,hashlib,json
import numpy as np
from scipy.integrate import quad
R=Path('/mnt/data/_work_nov18/sources')
A=(R/'Paper6A-GravityCosmology-v2_263.tex').read_text(); B=(R/'Paper6B-CosmologyReadouts-v1_210.tex').read_text(); C=(R/'Paper6C-TechnicalMaterial-v1_51.tex').read_text(); G=(R/'Paper3G-TechnicalMaterial-v1_54.tex').read_text();SRC_F=(R/'Paper3F-CompleteDynamics-v1_267.tex').read_text(); V=(R/'Paper5C-InteractionResponse-v2_179.tex').read_text()
checks=[]
def ok(k, ids, condition, witness, grade='E3 algebraic local + E4 counterexample'):
 checks.append(dict(check=k,issue_ids=ids,passed=bool(condition),witness=witness,grade=grade));assert condition,k
ok('C1 crossing product not zero slope',['BH-G-000118'],(3-3)*1.7==0 and 1.7!=0 and '(\\chi_+-\\chi_-)v_{16}=0' in B,'chi+=chi-=3, nonzero slope 1.7 admitted')
ok('Cross-paper Mukhanov theorem lives VI-C',['BH-G-000120'],r'\label{p8:thm:g30a-2i-mukhanov-bridge}' in C and 'Paper~VI-C, Theorem~\\ref{p8:thm:g30a-2i-mukhanov-bridge}' in B,'VI-C current source exact label, VI-B corrected attribution','E0 source pointer')
chi=0.6;T=1.13
f=lambda t: math.sqrt(t)*math.sin(chi)/math.sin(t*chi)
d=(math.log(f(1+1e-5))-math.log(f(1-1e-5)))/(math.log(1+1e-5)-math.log(1-1e-5))
ok('Fixed S3 radius optical derivative is not flat homothety',['BH-G-000121'], abs(d-(.5-chi/math.tan(chi)))<1e-7 and abs(f(T)-T**-.5)>1e-3,{'ratio':f(T),'sensitivity':d})
act_o,ref_o,act_x,ref_x,rhonu=15.,12.,7.,1.,2.
delta=((act_o-ref_o)+(act_x-ref_x))/rhonu
ok('Reference-subtracted Neff, not absolute population sum',['BH-G-000122'], abs(delta-4.5)<1e-12 and abs((act_o+act_x)/rhonu-delta)>1,{'delta':delta,'old_spurious':(act_o+act_x)/rhonu,'source_ref_subtraction':'rho_{{\\rm ord},\\rm rel}^{\\rm ref}' in B})
ok('Locally Lipschitz ydot=y2 can blow up, full-interval existence guarded',['BH-G-000123'],(1/(1-0.9))>9 and 'solution exists' in B and 'remains inside that region' in B,{'counterexample':'dy/dt=y²; y(0)=1, y(t)=1/(1-t) diverges t→1','source_guard':True},'E4 existence counterexample')
tau=math.log(7);qsp=7*(1-math.exp(-tau));
ok('K48 final-octet independent of selected j4',['BH-G-000124'],abs(qsp-6)<1e-14 and 8*6==48 and 56-8==48 and (8-4)==4 and (8-2)==6 and 'not from reflection of the active dressing grade' in B and 'old route $j_{\\rm cDM}=J(2)=6$ is not valid' in A,{'qsp_tau48':qsp,'J2':6,'J4':4,'Q_D48':0,'Q_D56':1})
# Tr(P_W/7)=1, (P_W/7)^2=P_W/49 ≠ P_W/7.
E=np.eye(7)/7
ok('Final-octet trace remnant not occupied one-particle projector',['BH-G-000124'],abs(np.trace(E)-1)<1e-14 and np.linalg.norm(E@E-E)>0.2,{'trace':float(np.trace(E)),'projection_defect':float(np.linalg.norm(E@E-E))})
y=.8;g1=math.sqrt(5/3)*y
ok('GUT-normalized beta coefficient', ['BH-G-000126'],abs((17/20)*g1*g1-(17/12)*y*y)<1e-14 and r'\frac{17}{20}g_1^2' in B and (r'g_1=\sqrt{\frac53}' in V or r'g_1=\sqrt{\frac53}' in B),{'g1':g1,'gY':y,'coeff_gut':(17/20)*g1*g1,'coeff_Y':(17/12)*y*y})
ok('Portal reference denominators guarded',['BH-G-000128'],r'g_1(0)\ne0' in B and r'g_2(0)\ne0' in B and (1 if 2!=0 else 0)==1,{'zero_denominator_comparison':'g(0)=0 ⇒ 0/0 undefined if both vanish'})
x=.4;F=x*(1+x)/2;M=x*(1-x)/2;dF=(1+2*x)/2;dM=(1-2*x)/2
EF=x*dF/F;EM=x*dM/M;Ea=(F*EF+M*EM)/(F+M)
ok('Positive nonidentical elasticities can total homogeneous',['BH-G-000129'],abs(Ea-1)<1e-14 and abs(EF-EM)>0.5 and 'Equality of component elasticities is sufficient but' in B,{'x':x,'E_F':EF,'E_M':EM,'E_A':Ea},'E4 exact counterexample')
ok('Massive oscillator matter law is scoped as leading adiabatic',['BH-G-000130'], 'leading adiabatic order' in B and r'\langle w_X\rangle\simeq0' in B and '|\\dot H|/m_X^2' in B or r'|\dot H|/m_X^2' in B,{'H_over_m':.03,'omega_over_m':math.sqrt(1-(3*.03/2)**2)})
ok('Zero-energy material branch has undefined dp/dE',['BH-G-000131'],r'c_{s,{\rm cDM}}^2=0\quad(\mu>0)' in B and r'If \(\mu=0\)' in B,{'mu_zero_dEdzeta':0,'dpdE':'0/0 undefined'})
ok('Green kernels have no H denominator at turnaround',['BH-G-000132'],r'\dot a(s)\neq0' in B and r'H(s)>0' in B and r'H(u)>0' in B,{'H(s)=0':'1/H is undefined','regular_expanding_domain':True})
ok('Exact technical appendix anchors replace dead references',['BH-G-000124'],r'\label{p3e:cor:unique-k16-interior-action-junction}' in G and r'\label{p3f:cor:v229-actual-curvature-schur-test}' in SRC_F and r'\ref{p3f:prop:v229-radial-schur}' not in A and r'\ref{p3f:prop:v229-radial-schur}' not in B,{'A':'v2_263','B':'v1_210','III_G':'v1_54','III_F':'v1_267'},'E0 imported proof pointer')
ok('Cap same-chart mismatch no universal terminal no-go',['BH-G-000124'],r'\ref{p3f:prop:v229-cap-vs-coherent-uv-hessian}' in A and r'\label{p3f:prop:v229-cap-vs-coherent-uv-hessian}' in SRC_F and 'not establish a' in A,'Exact constrained comparator, not universal excluded physics','E0 source scope + domain replay')
output={'name':'Paper00-CosmologyGuardIndependentChecks-v1_1','tests':checks,'passed':sum(x['passed'] for x in checks),'total':len(checks),'physical_owner_promotions':0,'global_E3_E4_claim':False}
p=Path('/mnt/data/_work_nov18/CosmologyGuardChecks-v1_1.json');p.write_text(json.dumps(output,indent=2)+'\n')
print(f'COSMO CHECKS: {output["passed"]}/{output["total"]} PASS')
