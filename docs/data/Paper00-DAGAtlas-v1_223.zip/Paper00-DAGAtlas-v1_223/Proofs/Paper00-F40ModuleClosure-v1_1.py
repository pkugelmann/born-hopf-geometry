#!/usr/bin/env python3
"""F40 twisted-carrier obstruction + minimal Petersen repair.

Research certificate only, based on v2_345 F40 exact finite graph/readout
certificate. Does not construct a physical QCD action or mass pole.
Run inside the Proofs directory of Paper00-PapersMinimal-v2_345.
"""
from __future__ import annotations
import itertools
import runpy
from pathlib import Path
import sympy as s

classes=[1,15,20,12,12]
phi=(1+s.sqrt(5))/2
phibar=(1-s.sqrt(5))/2
irreps={
    '1':[1,1,1,1,1],
    '3':[3,-1,0,phi,phibar],
    '3prime':[3,-1,0,phibar,phi],
    '4':[4,0,1,-1,-1],
    '5':[5,1,-1,0,0],
}
characters={
    'End5':[25,1,1,0,0], # character square of irrep 5, diagonal A5 action
    'F40_Z':[21,1,-3,1,1], # regular edges - 2*20 vertices + 1
    'Petersen_pairs':[10,2,1,0,0]
}
expected={
    'End5':{'1':1,'3':1,'3prime':1,'4':2,'5':2},
    'F40_Z':{'1':0,'3':1,'3prime':1,'4':0,'5':3},
    'Petersen_pairs':{'1':1,'3':0,'3prime':0,'4':1,'5':1},
}
for name,chi in characters.items():
    multiplicities={key:s.simplify(sum(classes[i]*s.Integer(chi[i])*char[i] for i in range(5))/60) for key,char in irreps.items()}
    assert multiplicities==expected[name],(name,multiplicities)
rank_bound=sum(int(irreps[k][0])*min(expected['End5'][k],expected['F40_Z'][k]) for k in irreps)
assert rank_bound==16
assert expected['F40_Z']['1']==0 # no A5-invariant linear functional on F40 cycles
assert 1+1+3*(3+1)//2==8 # invariant symmetric quadratic forms: 3, 3prime, and triple 5
assert sum(int(irreps[k][0])*min(expected['End5'][k]+expected['Petersen_pairs'][k],expected['F40_Z'][k]) for k in irreps)==21
assert expected['End5']['5']+expected['Petersen_pairs']['5']==expected['F40_Z']['5']==3
print('PASS character no-go: Z=3+3prime+3*5 -> End(5)=1+3+3prime+2*4+2*5 has max rank 16')
print('PASS minimal repair: End(5) plus the existing Petersen 5 admits rank 21, extra dim 5 is necessary')

pairs=list(itertools.combinations(range(5),2))
Pidx={e:i for i,e in enumerate(pairs)}
Ap=s.zeros(10)
for i,p in enumerate(pairs):
    for j,q in enumerate(pairs):
        if not set(p)&set(q): Ap[i,j]=1
Pp5=-((Ap-3*s.eye(10))*(Ap+2*s.eye(10)))/6
assert (Ap*Pp5)==Pp5 and Pp5*Pp5==Pp5 and Pp5.T==Pp5 and Pp5.rank()==5
assert Ap.eigenvals()=={s.Integer(3):1,s.Integer(1):5,s.Integer(-2):4}
print('PASS Petersen canonical quintet P5=-(AP-3I)(AP+2I)/6')

# Verify a constructive 21-component lossless native readout via the v2_345
# exact integer matrices, rather than merely relying on abstract existence.
ctx=runpy.run_path(str(Path(__file__).with_name('Paper00-PetersenHodgePlucker-v1_11-verify.py')))
N=ctx['N']
T_R=ctx['T_R']; T_L=ctx['T_L']; A=ctx['A']
Ant=ctx['Ant']; Aico=ctx['Aico']; P_anti=ctx['P_anti']
arc_idx=ctx['arc_idx']
Ps5=(s.eye(12)+Ant)/2-s.ones(12)/12
assert Ps5*Ps5==Ps5 and Ps5.rank()==5 and Aico*Ps5==-Ps5
# Symmetric zero-row-sum balanced five-core arrow matrix is exactly
# the Petersen eigenvalue-1 quintet, via ij <-> (i->j,j->i).
J=s.zeros(10,20)
for i,(a,b) in enumerate(pairs):
    J[i,arc_idx[(a,b)]]=s.Rational(1,2)
    J[i,arc_idx[(b,a)]]=s.Rational(1,2)
assert (s.eye(10)-Pp5)*J*A*N==s.zeros(10,21)
assert (s.eye(12)-Ps5)*(T_R+T_L)*N==s.zeros(12,21)
assert (Ps5*(T_R+T_L)*N).rank()==5
assert (Ps5*(T_R-T_L)*N).rank()==5
assert (J*A*N).rank()==5
assert (P_anti*A*N).rank()==6
M=s.Matrix.vstack(Ps5*(T_R+T_L), Ps5*(T_R-T_L), J*A, P_anti*A)
assert (M*N).rank()==21
# Every output component is in a nonredundant irrep subspace:
# 5 + 5 + 5 + 6 = 21 exactly, albeit stored in 12+12+10+20 coordinates.
print('PASS compressed native F40 reconstruction: shell sum 5 + shell difference 5 + Petersen symmetric arrows 5 + Hodge skew 6 = 21')
print('PASS full rank: 21 on 21 cycles; extra quintet is a native Petersen 5 not a new independent module')
print('SCOPE: exact A5-equivariant geometric compatibility; physical SU(3) singlet embedding, same-action coupling and mass poles NOT established')
