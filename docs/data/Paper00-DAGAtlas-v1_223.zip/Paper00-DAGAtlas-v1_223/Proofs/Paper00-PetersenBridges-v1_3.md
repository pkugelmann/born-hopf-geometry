# Paper00 — Petersen coset, double-cover, and Reye bridges

**Release:** `Paper00-PetersenBridges-v1_3`  
**Baseline inspected:** `Paper00-PapersMinimal-v2_340(1).zip`, including I-A v5_152, I-B v1_123, I-C v1_64, their v2_340 rank-two and HP2 expansions, and the existing Kneser-closure certificate.  
**Scope:** exact, conditional mathematics attached to one marked binary-icosahedral subgroup `2I < SU(2)`; not a mass operator or a physical occurrence proof.  
**Status:** exact integer certificate for the integrated framework v2_341 mathematical additions. The updated sources and DAG delta are in `Paper00-PapersMinimal-v2_341.zip`; the certificate is restricted to finite mathematics.

## A. The 25 coset cells and the 17-dimensional coefficient module

Let `G=2I`, `G/{±1}=A5` and let `[5]` be the natural five-letter permutation set. Define

`C_ij={g in G : bar(g)(j)=i}` for `i,j in [5]`.

Then `C_ii=H_i≅2T`, and every `C_ij` contains exactly 24 elements. For any two cells,

- `|C_ij ∩ C_kl| = 24` if `(i,j)=(k,l)`;
- `|C_ij ∩ C_kl| = 0` if exactly one of the row or column labels coincides;
- `|C_ij ∩ C_kl| = 6` when `i≠k` and `j≠l`.

Writing `B_{g,ij}=1[g(j)=i]` and `R=(J5−I5)⊗(J5−I5)` gives the exact integer identity

`BᵀB = 24 I25 + 6 R`,

with spectrum `120^1, 30^16, 0^8`. Consequently `rank(B)=17`; the kernel is the eight-dimensional space of independent centered row and column sums. The 25 displayed cells are **not 25 linearly independent indicator functions**.

The column span is the matrix-coefficient space of the permutation representation `R^5=1⊕4` of `A5`. Consequently, as an `A5_left × A5_right` module it is `1⊠1 ⊕ 4⊠4`, dimension `1+16=17`. Under diagonal conjugation it decomposes as

`I25 = 2·1 ⊕ 4 ⊕ 5 ⊕ 3 ⊕ 3′`.

Here `I25` denotes the *image* of the 25 coset indicator functions, not the formal 25-dimensional labeling space.

## B. Two explicit coset intertwiners recover the Petersen/Hodge sectors

For each unordered pair `ij`, `i<j`, define 120-component functions

`v_ij=1_{C_ij}+1_{C_ji}` and `a_ij=1_{C_ij}−1_{C_ji}`.

Let `V` and `C` be the 120×10 matrices of the `v_ij` and `a_ij` functions. Let `A` be Petersen adjacency on 2-subsets of `[5]`, with disjoint labels adjacent, and put `J=J10`. Then the following *exact integer* identities hold:

`VᵀV = 48 I10 + 12 A + 12 J`,

`CᵀC = 12 S_H²`,

`VᵀC = 0`,

where `S_H=*_5(c ∧ ·)` on `Λ²R⁵`, with `c=(1,1,1,1,1)` and standard orientation. It has signed Petersen support, `S_H³=5 S_H`, and spectrum `(+√5)^3, 0^4, (−√5)^3`.

Hence `V` is injective; its Gram spectrum is `204^1, 60^5, 24^4` and its image realizes `1⊕5⊕4`. The antisymmetric map `C` has Gram spectrum `60^6, 0^4`, rank six and image `3⊕3′`. Its kernel is the four-dimensional oriented complete-graph gradient space, because if `b=ι_c` denotes the 5×10 exterior contraction operator, then `CᵀC=12(5I−bᵀb)=12S_H²`.

The images of `V` and `C` are orthogonal. They span 16 of the 17 dimensions; adding the global constant gives the remaining singlet. After removing the two canonical conjugation-invariant character functions `1_G` and `χ4(g)=#{fixed points of bar(g)}−1`, the remaining 15 dimensions have irreducible content `4⊕5⊕3⊕3′`, matching the **signed oriented Petersen edge module**. This is an equivariant representation equivalence, not a unique isomorphism without choices of normalization/orientation. No identification with the complex momentum module `H1` or the 15-dimensional Bose–Mesner block follows.

The signed Hodge *square* is determined by the coset intersections; its `3/3′` chiral sign requires the five-label orientation.

## C. The two Petersen covers and the six-axis projective-plane parity correspondence

For any signing `S` supported on Petersen adjacency `A`, the adjacency of its two-sheet lift is

`L(S)=½ [[A+S, A−S], [A−S, A+S]] ≃ A⊕S`.

1. `S=S_H`: `L(S_H)` is the dodecahedral graph `GP(10,2)`, with six positive and six negative five-cycle voltages; automorphism group `A5×C2` of order 120.
2. `S=−A`: `L(−A)` is the bipartite Desargues graph `GP(10,3)`, with all twelve base pentagons of voltage `−1`; automorphism group `S5×C2` of order 240. It is *not* the same signed connection as `S_H`.

The 120 wedge-representation transformations `T_π=Λ²P_π` satisfy exactly

`T_π S_H T_πᵀ = sign(π) S_H`, for all `π∈S5`.

Even permutations stabilize `S_H`, while odd permutations exchange `S_H ↔ −S_H`; they are not ordinary automorphisms of the *fixed* signed dodecahedral voltage assignment.

Now let `F+` and `F−` be the complementary ten-face triangulations of `RP²` on the six Sylow-5 axes, and use the already-established maps `f±: choose([5],2)→F±`. A direct check for every `ij,kl` yields

`|f+(ij) ∩ f−(kl)| = 1  ⇔  {i,j} ∩ {k,l} = ∅`.

Therefore **the bipartite cross-incidence graph of `F+` and `F−`, with an edge when the two triangles share exactly one of the six axes, is Desargues**. The six-axis permutation action is obtained by conjugating the six Sylow-5 subgroups. All 120 permutations of `S5` were verified to obey

`π f+(ij)=f+(πij)` for even `π`, but `π f+(ij)=f−(πij)` for odd `π`.

This is the precise geometric carrier of odd parity exchange; the dodecahedral cover remains the carrier of the **signed Hopf-axis holonomy**. The same exceptional six-point action is the classical restriction of the `S6` outer automorphism, using the duad/syntheme/pentad description; the exact bijections depend on specified labels.

## D. Gluing the five Reye configurations correctly in RP³

Each core `H_i` contains 12 antipodal quaternionic lines and 16 great regular hexagons, defining one Reye `12_4,16_3` configuration. Identify an antipodal pair of group elements upstairs with its unique element in the quotient `A5`. The `A5` element orders are `1^1, 2^15, 3^20, 5^24`.

- The five A4 point stabilizers cover `1 + 15 + 20 = 36` projective quaternionic lines: one central line shared by all five cores, fifteen order-two lines each in one core, twenty order-three lines each in two cores.
- The twenty order-three lines are the two noncentral antipodal line pairs in each of ten shared `C6` threefold-axis subgroups. Each pair of cores shares **three** RP³ lines, including the common central line; pairwise intersections cannot be counted as single projective lines.
- The 15 order-two lines correspond bijectively to Petersen edges: an element `(ij)(kl)` of `A5` is the unique order-two class fixed at the remaining label `m`, and corresponds to the disjoint-pair edge `ij—kl` in the Petersen graph.
- The remaining 24 quaternionic projective lines on the full 600-cell come from the six fivefold axes (four projective lines per axis).

The 16 Reye hexagon planes in an A4 core are the four cosets of each of its four cyclic order-three subgroups. Across the five cores, precisely ten planes are double occurrences. All other 60 planes occur once. The union of core-contained Reye planes therefore has **36 unique lines and 70 unique planes**, with total incidence `210`. **This is not the complete induced hexagon structure:** the v2_340 theorem adds ten mixed-core `(2,2,2)` hexagons, giving 80 hexagons with full rank 36 rather than rank 35 for the 70 core-contained ones. Its 70-plane line-degree distribution is:

`10^1, 7^20, 4^15`, summing `10+140+60=210=70·3`.

This is a nonregular union of Reye configurations, not a new standalone Reye `36_d70_3` configuration with uniform point degree.

## E. The nearest-shell kernel 25−15=10 does not equal the Petersen vertex representation

Paper I-A's nearest-shell convolution has `ker T_{2I}` equal to the regular matrix-coefficient block `V5⊗V5*`, dimension `25`, for the unique 5-dimensional irreducible `V5` of `A5`. The subgroup `2T` shell resolves its multiplicity factor on restriction `V5|_{A4} = χ_ω ⊕ χ_{bar ω} ⊕ 3`:

- `dim(ker T_{2I} ∩ ker T_{2T}) = 5·3 = 15`,
- `dim(ker T_{2I} ∩ (ker T_{2T})^⊥) = 5·2 = 10`.

Under the **right regular** `A5` action, which commutes with the manuscript's left-convolution operators, this last ten-dimensional space is **`V5⊕V5`**, not Petersen's `1⊕4⊕5`. Under diagonal conjugation, the fixed `2T` shell is not invariant under all of `A5`, so the purported 10-space is not automatically a diagonal `A5` module at all.

Moreover, the 17-dimensional coset indicator span belongs to the *different* regular matrix-coefficient blocks `V1⊗V1* ⊕ V4⊗V4*` and is **orthogonal** in `L²(2I)` to `ker T_{2I}=V5⊗V5*`. Thus matching the numbers `25` and `10` does not establish a spectral bridge. This is a demonstrated firewall, not an unanswered numerical pattern.

## F. Gaifullin 15-vertex/105-edge comparison

The 15-vertex `HP²` triangulation appearing in Paper I-C has a complete 1-skeleton: `f1=C(15,2)=105`. The supplied `f`-vector also has `f2=C(15,3)`, `f3=C(15,4)` and `f4=C(15,5)`, reflecting neighborliness. The 105 triangulation edges are therefore a combinatorial consequence of the 15 vertices, not an independent match to `dim Λ² W_P=105` in Paper I-B.

A chosen bijection between the triangulation's 15 vertices and the 15 Petersen edges induces a *formal* identification of two 105-element bases, but the triangulation's stated symmetry `C6×C2` does not supply the full `A5` action of the Petersen edge module. No canonical topological, spectral or physical identification follows. A short non-identification remark in Paper I-C is appropriate.

## G. Suggested manuscript placement and verification

- **Paper I-A:** theorem after the five-core/Petersen construction for coset incidences, the two Gram matrices and Reye gluing, making clear the RP³ vs RP² distinction.
- **Paper I-A 9.6:** proposition identifying Desargues as the `F+–F−` one-label-cross-incidence graph and stating the exact `S5` parity exchange.
- **Paper I-A near nearest-shell kernels:** negative comparison `V5⊕V5 ≠ 1⊕4⊕5` and coefficient-block orthogonality.
- **Paper I-B:** an optional mathematical comparison of the signed oriented 15-edge representation with the non-singlet coset module; preserve the physical/complex-carrier firewall.
- **Paper I-C:** Gaifullin comparison remark, without a claimed incidence isomorphism.
- **DAG:** record the proved identities as finite conditional 2I dependencies, not physical source nodes.

**Reproduce:** `python3 Paper00-PetersenBridges-v1_3.py`. The certificate also checks the exact rank-fifteen matrix projector and the ten missing mixed-core hexagons. It enumerates A5 and S5, builds the 120×25 coset incidence, both ten-dimensional sym/antisym images, the Hodge signing, both 20-vertex graph lifts, all 12 pentagons, the six Sylow-5 axes, both RP² triangle orbits and the parity correspondence, and every glued Reye line and plane. All displayed matrix equalities and incidence counts are exact over the integers; numeric rank/spectrum checks are secondary to these identities.

**Classical references for context:** Howard–Millson–Snowden–Vakil, *A description of the outer automorphism of S6* (https://math.stanford.edu/~vakil/files/sixjan2308.pdf); Waller, *Double covers of graphs*, Bulletin of the Australian Mathematical Society (https://www.cambridge.org/core/journals/bulletin-of-the-australian-mathematical-society/article/double-covers-of-graphs/4C6C74E71345E1C2C1048853BF638F4D); MathWorld's Desargues and dodecahedral graph entries. The coset/Hodge/graph gluings are new **cross-identifications within the current manuscript**, not asserted to be previously unpublished mathematical discoveries.

## H. v2_341-specific exact projector and integration corrections

With `Q=I5−J5/5` in binary 120-point counting convention, the centered transporter image satisfies `B(Q⊗Q)Bᵀ=χ4(g⁻¹h)=30 Π16`. Therefore the **exact** rank-fifteen coefficient projection is `Π15 = (1/30)B(Q⊗Q)Bᵀ − (1/120) χ4χ4ᵀ`; its integer clearing denominator `N=3000 Π15` obeys `N²=3000N` and has rank 15. This is compatible with Paper I-A v2_339's already constructed 15D `sl4(R)` edge isometry.

The v2_340 paper already proved: the 70 core-contained Reye planes vs 80 full induced planes, and a *separate* `A5`-equivariant vertex-set correspondence between the **unoriented** Petersen 15-edge set and the Brehm–Kühnel `A5`-triangulation. Do not revert that stronger theorem to the earlier vague non-identification claim. The Gaifullin `C6×C2` example stays different; 105 **oriented** exchange-odd states are not 105 **unoriented** simplicial edges.

The source's nearest-shell operators use **left convolution** `Tf(x)=∑f(s⁻¹x)`. Such an operator commutes with the **right regular action**, not in general the left regular action. This corrects the action-side mislabel in the v1_2 exploratory note: the ten-dimensional joint-kernel complement is `V5⊕V5` only under the commuting right action, and fixed-core diagonal conjugation need not preserve it. The v1_3 certificate checks that, on the 5D Sylow-axis representation restricted to `A4`, the eight-element core shell average has eigenvalues `(-1/2)^2, 0^3` (plus `1` on the discarded six-point constant).

All results are conditional on a marked `2I`; no carrier overlap or graph is itself a measured observable.
