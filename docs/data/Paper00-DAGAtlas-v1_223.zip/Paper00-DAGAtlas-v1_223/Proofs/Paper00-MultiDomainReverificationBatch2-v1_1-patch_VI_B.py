#!/usr/bin/env python3
"""Source-scoped Paper VI-B corrections: retired j2 route, physical owner qualification, top Yukawa gauge convention."""
from pathlib import Path
root=Path('/mnt/data/_work_nov18/sources')
s=(root/'Paper6B-CosmologyReadouts-v1_209.tex').read_text()
s=s.replace('% Current integrated source: Paper6B-CosmologyReadouts-v1_209.tex (PapersMinimal-v3_019; 16 November 2026).', '% Current integrated source: Paper6B-CosmologyReadouts-v1_210.tex (PapersMinimal-v3_032; 18 November 2026).\n% Source correction: current grade-four versus historical grade-two K48 origin, and top Yukawa RGE gauge normalization.',1)
s=s.replace(r'\date{Version 1.209 --- 16 November 2026 \\ DAG mathematical integration CC18}',r'\date{Version 1.210 --- 18 November 2026 \\ Source and DAG mathematical repair v3.032}',1)
old=r'''\begin{remark}[RGE closure]
At one loop,
\[
\frac{\beta_{y_t}}{y_t}
=\frac{1}{16\pi^2}
\left[\frac92y_t^2-\frac{17}{12}g_1-\frac94g_2^2-8g_3^2\right]+\cdots .
\]
The quantity \(D\beta_y\) is obtained by differentiating the same declared RGE
system, including the running of all couplings appearing in \(\beta_y\).  No
new portal parameter is introduced by this differentiation.
\end{remark}'''
new=r'''\begin{remark}[RGE closure and hypercharge convention]
At one loop, keeping the displayed top-Yukawa-only contribution,
\[
\frac{\beta_{y_t}}{y_t}
=\frac{1}{16\pi^2}
\left[\frac92y_t^2-\frac{17}{20}g_1^2-\frac94g_2^2-8g_3^2\right]+\cdots,
\qquad g_1^2=\frac53g_Y^2.
\]
Here \(g_1\) is the GUT-normalized hypercharge coupling of Paper~V-C,
Eq.~\eqref{p7v2:eq:g1-convention}. Equivalently the hypercharge contribution
is \(-17g_Y^2/12\). The ellipsis retains the omitted bottom-Yukawa,
lepton-Yukawa, and higher-order terms when applicable. The former expression
\(-17g_1/12\) was neither quadratic in the gauge coupling nor correct in
this normalization. The quantity \(D\beta_y\) is obtained by differentiating
the same declared RGE system, including the running of all couplings appearing
in \(\beta_y\); this does not introduce a free portal parameter.
\end{remark}'''
assert s.count(old)==1
s=s.replace(old,new,1)
a=s.index(r'\begin{theorem}[Reflected \(K=48\) onset label and double action/carrier desert]')
b=s.index(r'\begin{corollary}[Reflected onset versus native mass gap]',a)
newthm=r'''\begin{theorem}[Final-octet \(K=48\) onset and native-carrier desert]
\label{p9:thm:closed-j48-scalaron-abundance-trace}
On the active grade-four \(n_4\mid n_7\) branch of Paper~VI-A, the
homogeneous dark-response onset is inherited from the independently derived
\emph{final-octet separator}, not from reflection of the active dressing grade:
\[
 K_{\rm sh}^{\rm onset}=K_{\rm term}-8=56-8=48,
 \qquad j_{\rm cDM}:=K_{\rm sh}^{\rm onset}/8=6.
\]
Thus the same geometric hierarchy labels give
\begin{equation}
\label{p9:eq:qdm6-kdm48-map}
\boxed{
j_{\rm cDM}=6,\qquad K_{\rm cDM}=48,\qquad
C_6=U\alpha^{-6}=\alpha C_7.}
\end{equation}
The integer \(6\) here labels the \emph{separator/onset}, not the selected
ultraviolet dressing depth \(j_{\rm dress}=4\). The prior identity
\(J(2)=8-2=6\) remains a valid arithmetic identity \emph{only in the
historical grade-two comparison}; it does not prove the current dark-response
lineage, because \(J(4)=4\). The actual geometric source is Paper~VI-A's
primitive-remnant depletion and canonical H/Hopf current on \(48\le K\le56\).
At onset, in the native carrier calculus,
\begin{equation}
 \label{p9:eq:k48-native-carrier-zero}
\boxed{P_{48}^{\rm act}
 =\mathbf1_{\{6\}}(\mathcal Q_{\rm act})=0.}
\end{equation}
For comparison only, the separate historical \(n_2\mid n_7\)
source-free local jet obeys the Paper~III-E result
\begin{equation}
\label{p9:eq:k48-no-action-junction}
 \boxed{(\mathfrak f_{2\mid7}^{\rm act})''(C_6)
 =\chi_7^{\rm jet}(C_6)>0,
 \qquad C_6\notin
 \operatorname{sing\,supp}d\!\left((\widehat{\mathfrak f}_{2\mid7})'\right).}
\end{equation}
This historical jet formula is \emph{not} an action-owner assertion about
the current \(n_4\mid n_7\) branch. The final-octet geometric response
supplies neither a native \(n_6\) term nor a grade-six particle species,
rest-energy, occupation number, or physical stress tensor. Paper~IV's
absent-target theorem gives zero \emph{native quadratic production into the
absent carrier}; physical H-modality source/stress and cosmic-history
realization retain their separate occurrence conditions.
\end{theorem}

\begin{proof}
Paper~VI-A, Corollary~\ref{p8:cor:final-octet-primitive-remnant-depletion}
identifies \(Q_D=q_{\rm sp}-6=(K-48)/8\) on the final octet and shows that
its initial trace unit is not a rank-one particle. Its canonical Hopf and
homogeneous Hodge projections are Theorems~\ref{p8:thm:final-octet-canonical-hopf-descent}
and \ref{p8:thm:final-octet-flrw-hodge-dilution}. Together they locate the
onset at \(K=48\), independently of any reflected dressing rank.
The hierarchy's \(K=8j\), \(C_j=U\alpha^{-j}\) gives the displayed
coordinate identities. Paper~III-C's active carrier spectrum excludes grade
six, and Corollary~\ref{p4:cor:absent-target-production} excludes production
into that absent one-particle target. The old grade-two local Hessian and
absence of a grade-two-branch atom are \emph{only} the assertion of
Paper~III-E, Corollary~\ref{p3e:cor:unique-k16-interior-action-junction};
they are not used to establish the current grade-four source or its physical
H-modality occupation. No new dark-matter particle follows from the integer
48.\end{proof}

'''
s=s[:a]+newthm+s[b:]
s=s.replace(r'\begin{corollary}[Reflected onset versus native mass gap]',r'\begin{corollary}[Final-octet onset versus native mass gap]',1)
old=r'''% Source Paper VI-B, original line 3150
\subsection{Inherited synthesis and scope limitations}Paper~VI-B now imports the complementary Laurent branch without reinterpreting
it: \(n_2^+\) is the inflation dressing, \(n_7^+\) is the persistent
RAR-to-terminal interpolant, and both use'''
new=r'''% Source Paper VI-B, original line 3150
\subsection{Inherited synthesis and scope limitations}
Paper~VI-B retains the older complementary Laurent construction as a
\emph{historical grade-two comparison}, not as its active inflationary
owner. In that comparison \(n_2^+\) is the inflation dressing and \(n_7^+\)
is the persistent RAR-to-terminal interpolant, and both use'''
assert s.count(old)==1
s=s.replace(old,new,1)
s=s.replace('''The active nonlinear action is varied only down to \(C_7\).  There the rank-seven channel is evaluated, and the terminal theory is''','''On this historical comparison branch the nonlinear action is varied only down to \(C_7\).  There the rank-seven channel is evaluated, and its terminal theory is''',1)
s=s.replace('''The local trace kernel is
\((F_{2\mid7},\chi_{2\mid7},m_R)\) on \(\mathscr V_{2\mid7}\); in the terminal quotient''','''The historical local trace kernel is
\((F_{2\mid7},\chi_{2\mid7},m_R)\) on \(\mathscr V_{2\mid7}\); in the terminal quotient''',1)
old=r'''The protected-octet reflection gives
\(j_{\rm cDM}=J(2)=6,\ K_{\rm cDM}=48,\ C_6=\alpha C_7\) as the onset of
the final primitive-remnant transfer.'''
new=r'''The independent final-octet separator gives
\(j_{\rm cDM}=6,\ K_{\rm cDM}=56-8=48,\ C_6=\alpha C_7\) as the onset of
the final primitive-remnant transfer. The old reflected-grade-two identity
\(J(2)=6\) is not used on the active \(n_4\mid n_7\) branch.'''
assert s.count(old)==1
s=s.replace(old,new,1)
assert 'Version 1.210' in s
(root/'Paper6B-CosmologyReadouts-v1_210.tex').write_text(s)
print('written',len(s),'lines',s.count('\n')+1)
