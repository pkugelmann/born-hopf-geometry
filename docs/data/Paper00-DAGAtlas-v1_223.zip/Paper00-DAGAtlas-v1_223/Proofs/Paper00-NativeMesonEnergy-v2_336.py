"""Born–Hopf native meson-energy investigation v2_336.

Independent arithmetic/cyclic/Hodge/Petersen incidence certificates.
Only finite geometric identities, not physical hadron mass predictions.
Run: python Paper00-NativeMesonEnergy-v2_336.py
"""
import itertools
import json
from math import sqrt, log
from pathlib import Path

import numpy as np
import sympy as sp

E32 = 30984.588064
E36 = 219.578897
PION_CHARGED = 139.57039
PION_NEUTRAL = 134.9768
KAON_CHARGED = 493.677
KAON_NEUTRAL = 497.611

# Section A. Exactly generated C3 trimer ports.
X=sp.Matrix([[0,1,0],[0,0,1],[1,0,0]])
I3=sp.eye(3)
C1=X+X.T
C2=-sp.I*(X-X.T)
a,b,c=sp.symbols('a b c',real=True)
R=a*I3+b*C1+c*C2
lam=sp.symbols('lambda')
expected=(lam-a-2*b)*((lam-a+b)**2-3*c*c)
assert sp.expand(R.charpoly(lam).as_expr()-expected)==0
assert sp.simplify(sp.trace(R*R)-(3*a*a+6*b*b+6*c*c))==0
assert sp.simplify(R.det()-(a+2*b)*((a-b)**2-3*c*c))==0
assert (2*I3-C1).eigenvals()=={sp.Integer(0):1,sp.Integer(3):2}
assert (I3+C1+C2).eigenvals()=={sp.Integer(3):1,sp.sqrt(3):1,-sp.sqrt(3):1}

# Section B. Five-core Hodge star as signed Petersen adjacency.
edges=list(itertools.combinations(range(5),2))
emap={p:i for i,p in enumerate(edges)}
S=sp.zeros(10)
for row,(i,j) in enumerate(edges):
 for col,(k,l) in enumerate(edges):
  rem=set(range(5))-{i,j,k,l}
  if len(rem)==1:
   S[row,col]=sp.LeviCivita(next(iter(rem)),i,j,k,l)
assert S==S.T and S**3==5*S
assert S.eigenvals()=={sp.Integer(0):4,sp.sqrt(5):3,-sp.sqrt(5):3}
A=sp.zeros(10)
for i,x in enumerate(edges):
 for j,y in enumerate(edges):
  A[i,j]=int(set(x).isdisjoint(y))
assert S.multiply_elementwise(S)==A
assert A.eigenvals()=={sp.Integer(3):1,sp.Integer(1):5,sp.Integer(-2):4}
P6=S**2/5
P4=sp.eye(10)-P6
Pplus=(P6+S/sp.sqrt(5))/2
Pminus=(P6-S/sp.sqrt(5))/2
for P,rank,diag in [(P4,4,sp.Rational(2,5)),(Pplus,3,sp.Rational(3,10)),(Pminus,3,sp.Rational(3,10))]:
 assert P**2==P and P.T==P and P.trace()==rank
 assert all(sp.simplify(P[i,i]-diag)==0 for i in range(10))
assert P4*Pplus==sp.zeros(10) and P4*Pminus==sp.zeros(10) and Pplus*Pminus==sp.zeros(10)
assert P4+Pplus+Pminus==sp.eye(10)

# Section C. A5 action and its orientation covariance, including a parity-odd S5 test.
A5=[]
for perm in itertools.permutations(range(5)):
 parity=(-1)**sum(perm[i]>perm[j] for i in range(5) for j in range(i+1,5))
 if parity==1: A5.append(perm)
assert len(A5)==60

def oriented_rep(perm):
 D=sp.zeros(10)
 for col,(i,j) in enumerate(edges):
  im=(perm[i],perm[j]); sgn=1 if im[0]<im[1] else -1
  D[emap[tuple(sorted(im))],col]=sgn
 return D
for perm in A5:
 D=oriented_rep(perm)
 assert D*S*D.T==S
odd=(1,0,2,3,4)
assert oriented_rep(odd)*S*oriented_rep(odd).T==-S

# Section D. The complete center-even 120-carrier incidence.
# Ordered source,target label (T,S), each of which is a two-subset.
Bun=np.zeros((120,100),dtype=np.int8)
Bor=np.zeros((120,100),dtype=np.int8)
for row,perm in enumerate(A5):
 for src,(i,j) in enumerate(edges):
  target=(perm[i],perm[j])
  sign=1 if target[0]<target[1] else -1
  dest=emap[tuple(sorted(target))]
  col=dest*10+src
  Bun[2*row:2*row+2,col]=1
  Bor[2*row:2*row+2,col]=sign

def spectral_integer_ledger(B):
 K=np.asarray(B,dtype=float) @ np.asarray(B,dtype=float).T
 vals=np.linalg.eigvalsh(K)
 rounded=np.rint(vals).astype(int)
 assert np.max(np.abs(vals-rounded))<1e-7
 return K,{str(v):int(np.count_nonzero(rounded==v)) for v in sorted(set(rounded))}
Ku,du=spectral_integer_ledger(Bun)
Ko,do=spectral_integer_ledger(Bor)
Ke,de=spectral_integer_ledger(np.concatenate([Bun,Bor],axis=1))
assert du=={'0':78,'24':25,'30':16,'120':1},du
assert do=={'0':86,'30':16,'40':18},do
assert de=={'0':60,'24':25,'40':18,'60':16,'120':1},de
assert np.linalg.norm((Ku@Ko)-(Ko@Ku))<1e-6
assert np.max(np.abs(Ke-(Ku+Ko)))==0
assert np.allclose(Ke[:2,:],Ke[0:1,:])
# Even under the center: the subspace spanned by (e_{g,+}+e_{g,-})/sqrt2.
U=np.kron(np.eye(60), np.array([[1],[1]])/sqrt(2.))
Keven=U.T@Ke@U
assert np.linalg.eigvalsh(Keven)[0]>1e-6
T=Keven/120.0
assert np.max(np.linalg.eigvalsh(T))<=1+1e-10
assert np.min(np.linalg.eigvalsh(T))>0

# Section E. Candidate overlap ratio; comparison only after exact algebra.
un=sqrt(5)
u=sqrt(2/5)
ratio=un/u
assert abs(ratio*ratio-12.5)<1e-12
charged_ratio=KAON_CHARGED/PION_CHARGED
neutral_ratio=KAON_NEUTRAL/PION_NEUTRAL
mean_ratio=((KAON_CHARGED+KAON_NEUTRAL)/2)/((PION_CHARGED+PION_NEUTRAL)/2)
comparison={
    'E32_MeV':E32,'E36_MeV':E36,
    'constructed_ratio_sqrt25over2':ratio,
    'observed_charged_ratio':charged_ratio,
    'observed_neutral_ratio':neutral_ratio,
    'observed_isospin_midpoint_ratio':mean_ratio,
    'charged_ratio_relative_error_percent':100*(ratio/charged_ratio-1),
    'neutral_ratio_relative_error_percent':100*(ratio/neutral_ratio-1),
    'pi_geom_MeV':E36*u,
    'K_geom_MeV':E36*un,
    'pi_geom_minus_observed_percent':100*(E36*u/PION_CHARGED-1),
    'K_geom_minus_observed_percent':100*(E36*un/KAON_CHARGED-1),
}
res={
    'status':'exact finite geometry and conditional phenomenology, NO hadron mass predictions',
    'C3_characteristic_polynomial':str(sp.factor(R.charpoly(lam).as_expr())),
    'signed_Petersen_eigenvalues':{'0':4,'+sqrt5':3,'-sqrt5':3},
    'signed_Petersen_identity':'S^3=5*S',
    'Hodge_orthogonal_projection_diagonals':{'4':str(sp.Rational(2,5)),'3_plus':str(sp.Rational(3,10)),'3_minus':str(sp.Rational(3,10))},
    'incidence_unsigned':du,'incidence_oriented':do,'incidence_combined':de,
    'even_transfer_eigenvalues':{'1':1,'1/2':16,'1/3':18,'1/5':25},
    'even_formal_log_eigenvalues':{'0':1,'ln2':16,'ln3':18,'ln5':25},
    'ratios':comparison,
}
path=Path(__file__).with_name('Paper00-NativeMesonEnergy-v2_336-results.json')
path.write_text(json.dumps(res,indent=2,sort_keys=True)+'\n')
print('All checks passed')
print('Unsigned:',du,'Oriented:',do,'Combined:',de)
print('Signed Petersen S spec',S.eigenvals())
print('Formal even clock gaps', [0,log(2),log(3),log(5)])
print('Charged mass ratio', charged_ratio, 'constructed', ratio)
print('JSON',path)
