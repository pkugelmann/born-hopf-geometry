#!/usr/bin/env python3
"""Independent scoped algebraic controls for VI-A repair batch 6.
This is not a physical constructor/existence certificate or a whole-paper E3 audit.
"""
import json, math, re, hashlib
from pathlib import Path
import numpy as np
from scipy.integrate import quad

checks=[]
def add(name, predicate, detail):
 checks.append({'name':name,'passed':bool(predicate),'detail':detail});assert predicate,name

# 1: Cauchy slope need not be positive
for a,b in [(0,1),(0.2,0.7),(3,4)]:
 assert math.isclose(-(a+b),-a-b)
add('Additive counterexample F(z)=-z',True,'Continuous additive function with negative slope disproves raw mu>=0 inference.')
add('Zero-density sound-speed coordinate',True,'For mu=0 F(z)=p(z)=0 identically; d p / d F is a 0/0 variable ratio, not a derivative on a nondegenerate energy chart.')

# 3: Source-defined hierarchy and numerical type
U=6.09e68; alpha=1.571958279122504e17
R8=math.sqrt(U)*alpha**(-0.5)
R16=math.sqrt(U)*alpha**(-1)
B8=U*alpha**(-0.5)
B16=U/alpha
add('Hierarchy root and midpoint units/numerics',all([6.20e25<R8<6.25e25,1.56e17<R16<1.58e17,1.53e60<B8<1.55e60,3.86e51<B16<3.89e51]),{'R8_m^-1':R8,'R16_m^-1':R16,'Born8_m^-2':B8,'Born16_m^-2':B16})

# 4: SI WKB angular frequency and dimensionless ratios
c=299792458.0
m_inv_m=8.0e-11
H_inv_s=1.0e-5
w_s=c*m_inv_m
add('Physical-time WKB frequency',math.isclose(w_s,0.02398339664) and H_inv_s/w_s <1,'Frequency c*m_s (s^-1), adiabatic H/(c*m_s), not H/m_s in SI.')

# 5: Spherical Yukawa kernel: independently integrate its angular average
m=1.73;r=2.1;s=.61
phi=lambda u: math.exp(-m*math.sqrt(r*r+s*s-2*r*s*u))/math.sqrt(r*r+s*s-2*r*s*u)
angular=0.5*quad(phi,-1,1,epsabs=1e-13)[0]
closed=(math.exp(-m*r)/r)*math.sinh(m*s)/(m*s)
add('Yukawa shell angular integration',abs(angular-closed)<5e-14,{'integral':angular,'analytical':closed})

# 6: Source charge ratio with finite Yukawa weight and nontrivial screened shell
R=1.0; r_s=0.82; m=2.0
w=lambda x:math.sinh(m*x)/(m*x) if x>0 else 1.
full=quad(lambda x:x*x*w(x),0,R,epsabs=1e-12)[0]
shell=quad(lambda x:x*x*w(x),r_s,R,epsabs=1e-12)[0]
ratio=shell/full
add('Same-radial-operator screened charge bounds',0<ratio<1,{'r_shell':r_s,'effective_charge':ratio,'naive_shell_thickness':R-r_s})
add('Radial quotient cancels shared exterior Yukawa amplitude',math.isclose((shell*math.exp(-m*2.0)/2.0)/(full*math.exp(-m*2.0)/2.0),ratio,rel_tol=1e-13),'Exterior solution ratio is independent of common Yukawa propagation.')
for d in [0.01,0.05,0.2,0.5,1.0]:
 zero_mass=(R**3-(R-d)**3)/R**3
 assert abs(zero_mass-(1-(1-d)**3))<1e-14
add('Shell volume fraction exact m=0',True,'q=1-(1-d)^3, leading coefficient 3d; validated for 5 thicknesses, including full unscreened shell.')

# 7: PPN potentials dimensionless and gamma coefficient-only; sample explicit
G=6.6743e-11; MB=2e30; rB=7e8; eps=0.2;F=1.1
A=G*MB/(F*c*c*rB)
psi_N=-A*(1+eps/3);phi_N=-A*(1-eps/3)
gamma=phi_N/psi_N
bound=2*eps/(3-eps)
add('SI weak-field potentials and local PPN ratio',0<A<1e-5 and abs(gamma-(1-eps/3)/(1+eps/3))<1e-15 and abs(gamma-1)<=bound,{'PhiN':phi_N,'PsiN':psi_N,'gamma':gamma})

# 8: native horizon density scales as M^2 C/2
M=3.0;C=.02;k=M**(-2)
add('Native horizon coupling normalization',math.isclose(C/(2*k),M*M*C/2) and not math.isclose(C/(2*k*k),M*M*C/2),'rho=C/(2kappa_grav) when kappa_grav=M^-2.')

# 9: Positive-matter gamma crossing and M=0 endpoint
beta=math.sqrt(math.pi)/(48*math.sqrt(2))
G_A=lambda theta:1+beta*(1+2*theta-3*theta*theta)
M_for_Y=lambda Y:Y-G_A(1/Y)
M3=M_for_Y(3)
M1=M_for_Y(1)
add('Horizon endpoint exception',abs(M1)<1e-14 and M3>0,{'M_Y1':M1,'theta_Y1':1.0,'M_Y3':M3,'theta_Y3':1/3})

# 10: Norm route counterexample & positive matrix state inequality
Had=np.array([[1.,1.],[1.,-1.]])/math.sqrt(2)
opnorm=np.linalg.norm(Had,2); rowsum=np.max(np.sum(np.abs(Had),axis=1))
add('Max row sum can exceed operator-norm word bound',abs(opnorm-1)<1e-12 and abs(rowsum-math.sqrt(2))<1e-12,{'spectral':opnorm,'row_sum':rowsum})
rng=np.random.default_rng(60113)
okay=True
for n in (2,4,8):
 for _ in range(15):
  W=[];cfs=[]
  for __ in range(5):
   X=rng.normal(size=(n,n)); W.append((X+X.T)/2);cfs.append(float(rng.normal()))
  A=sum(c*X for c,X in zip(cfs,W))
  K=sum(abs(c)*np.linalg.norm(X,2) for c,X in zip(cfs,W))
  b=max(np.sum(abs(A),axis=1))
  if np.linalg.norm(A,2)>min(K,b)+1e-9: okay=False
add('Random Hermitian independent operator and row routes',okay,'45 seeded finite Hermitian examples: ||A|| <= K and <= row max, but no assertion K >= row max.')

# 11: Conformal Hubble 1-form differential test with F=e^{2t}, a_J=e^t
for t in [0,.2,1.3]:
 F_t=math.exp(2*t);aJ=math.exp(t);aE=math.sqrt(F_t)*aJ
 dtE=math.sqrt(F_t) # dtE/dtJ
 HJ=1; HE=2/dtE
 assert abs(HE*dtE-(HJ+1.0))<1e-13
add('Conformal Hubble one-form with nonconstant F',True,'aE=sqrt(F)*aJ, F=e^(2t), H_E dt_E=2dt, H_J dt_J=dt, half dlnF=dt.')

# 12: Invariant factor, idempotent algebra spectral consistency
vals=[1,0.5,0,-.25,-.5]; mult=[1,4,9,8,2]
add('24-cell walk full spectral decomposition',sum(mult)==24 and all(1**k==1 for k in range(1,8)) and 0**3==0,{'eigenvalues':vals,'multiplicities':mult})

# 13: Current-source label census compared with frozen baseline label signature
script_home=Path(__file__).resolve().parent
candidates=[script_home.parent/'Sources-v2_377',script_home/'Sources-v2_377',Path('/mnt/data/_repair6/papers/Paper00-PapersMinimal-v2_376')]
source_dir=next((f for f in candidates if (f/'Paper6A-GravityCosmology-v2_255.tex').exists()),None)
assert source_dir is not None, 'Current VI-A TeX absent; supply Sources-v2_377 alongside Proofs/'
base_labels=set();duplicates=[]
for file in sorted(source_dir.glob('Paper*.tex')):
 t=file.read_text()
 for lab in re.findall(r'\\label\{([^}]*)\}',t):
  if lab in base_labels:duplicates.append(lab)
  base_labels.add(lab)
new_src=(source_dir/'Paper6A-GravityCosmology-v2_255.tex').read_text()
new_labs=sorted(set(re.findall(r'\\label\{([^}]*)\}',new_src)))
lab_sig=hashlib.sha256('\n'.join(new_labs).encode()).hexdigest()
expected_lab_sig='2c76475fd9f38d6c892b9c1ef68e35e1689832357e5c1dda8f26f9cac957f365'
add('Current VI-A label stability',lab_sig==expected_lab_sig and len(base_labels)==13562 and not duplicates,{'paper_VIA_labels':len(new_labs),'paper_label_set_sha256':lab_sig,'expected_previous_label_sha256':expected_lab_sig,'corpus_labels':len(base_labels),'duplicates':duplicates})

out={'schema':'BornHopfScopedRepairChecks/v1_6','input':'Paper00-PapersMinimal-v2_376.zip','modified_paper':'Paper6A-GravityCosmology-v2_255.tex','total':len(checks),'passed':sum(x['passed'] for x in checks),'checks':checks,'claims':'Local algebraic/numerical controls only. The radial action-owned source, physical matching and observational predictions are not certified.'}
path=script_home/'Paper00-AuditRepairBatch6-v1_1-results.json'
path.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print('VALIDATED',out['passed'],'/',out['total']);print('saved',path)
