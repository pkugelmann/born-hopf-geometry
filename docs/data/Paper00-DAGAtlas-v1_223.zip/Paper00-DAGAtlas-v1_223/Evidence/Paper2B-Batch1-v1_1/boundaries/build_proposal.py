import json,re
from pathlib import Path
root=Path('/workspace/scratch/6302724ed082')
corpus=root/'work/corpus'
source='Paper2B-MomentumCarrier-v2_135.tex'
lines=(corpus/source).read_text().splitlines()
oldroot=root/'work/atlas-baseline/Paper00-DAGAtlas-v1_72/DAG/AuditLayer/Paper2A-v1_64'
old=json.loads((oldroot/'AssumptionRegistry.json').read_text())['items']
labels={}
for p in corpus.glob('*.tex'):
 for n,line in enumerate(p.read_text().splitlines(),1):
  for label in re.findall(r'\\label\{([^}]+)\}',line): labels[label]={'file':p.name,'line':n}
def loc(start,end,file=source):
 ss=(corpus/file).read_text().splitlines()
 return {'file':file,'lines':[start,end],'source_excerpt':'\n'.join(ss[start-1:end])}
existing_ids=['BH-IIA-A-B32-ROUND-001','BH-IIA-A-B33-SMOOTH-001','BH-IIA-A-B33-DERLIC-001','BH-IIA-A-B33-IMAGE-001','BH-IIA-A-B40-INTERNAL-001']
reused=[]
uses={
 'BH-IIA-A-B32-ROUND-001':[(358,364),(676,685),(785,797)],
 'BH-IIA-A-B33-SMOOTH-001':[(774,781),(1069,1076)],
 'BH-IIA-A-B33-DERLIC-001':[(987,992),(1071,1074)],
 'BH-IIA-A-B33-IMAGE-001':[(1085,1098)],
 'BH-IIA-A-B40-INTERNAL-001':[(1100,1106)]}
for id in existing_ids:
 r=next(x for x in old if x['id']==id)
 reused.append({'id':id,'reuse_existing':True,'normalized_statement':r['normalized_statement'],'origin_registry':'DAG/AuditLayer/Paper2A-v1_64/AssumptionRegistry.json','source_uses':[loc(*a) for a in uses[id]],'deduplication':'Identical typed source predicate specialized at the fixed round momentum role; no duplicate assumption node. Existing historical lifecycle text is preserved, new route use is explicit.'})
new=[]
def assumption(id,statement,category,start,end,**extra):
 new.append({'id':id,'normalized_statement':statement,'category':category,'type':'SOURCE-DECLARED SCOPED CONDITION','epistemic_status':'STIPULATED','lifecycle':'ACTIVE','first_occurrence':loc(start,end),'first_occurrence_priority':'FIRST-KNOWN in accessible framework; not absolute logical-priority assertion','canonical_aliases':[],'proved_or_discharged_by':[],'direct_prerequisites':[],'not_new_physical_principle':True,'deduplication_check':'Compared against all 158 items in active II-A AssumptionRegistry and canonical theorem nodes. No fully typed identical condition found.',**extra})
assumption('BH-IIB-A-B1-UNITARY-001','The specified GP1-finite GP2-host-faithful complex Hilbert momentum realization carries a finite-dimensional unitary representation of the derived so(4) Lie-algebra symmetry. The integration/classification theorem is in this declared representation domain.','DOMAIN',434,443,quantifiers='For any such finite unitary realization; no assertion that every abstract host action automatically has a new physical operation port.')
assumption('BH-IIB-A-B1-SECTION-LINEAR-001','The frozen real tangent-section OBJECT target has its preconstituted real vector-space addition/scalar multiplication and generated linear-subspace retention. This is not scalar-function multiplication or operation evaluation/reuse.','CONSTITUTIVE',127,130,first_formal_use=loc(1012,1020),quantifiers='For beta outputs in Gamma(TS3)_sec,obj of this fixed momentum seed only; all finite sums in that declared linear object sort.')
assumption('BH-IIB-A-B1-P1-TARGET-001','For the mathematical scalar-action comparison the specified target is P1=E0 direct-sum E1 on round S3(R), and the operation is the ordinary scalar derivation delta_X(h)=X(h), X in the ten-dimensional host conformal Lie algebra c.','DOMAIN',938,950,quantifiers='For all X in c; preservation is tested on all h in P1. No claim that a physical operation grammar selects P1.')
assumption('BH-IIB-A-B1-GRAD-EVAL-001','The explicitly ENLARGED alternative grammar licenses ordinary scalar evaluation by G=grad(x1) on the round host scalar sort.','DOMAIN',964,967,quantifiers='In this alternative grammar only; not in frozen initial momentum seed.',direct_prerequisites=['BH-IIA-A-B32-ROUND-001'])
assumption('BH-IIB-A-B1-GRAD-RETAIN-001','In the explicitly ENLARGED alternative gradient-evaluation grammar, each scalar output is retained in the scalar carrier sort.','DOMAIN',966,969,quantifiers='Every licensed G-evaluation output; not ambient membership alone.')
assumption('BH-IIB-A-B1-GRAD-REUSE-001','In the explicitly ENLARGED alternative gradient-evaluation grammar, repeated evaluation G on retained scalar outputs is licensed for every finite iteration.','DOMAIN',966,970,quantifiers='All finite n>=0; not a bounded-depth permission.')
# A condition already present for optional physical word grammar is not an input to mathematical tensor bookkeeping.
not_used=[{'id':'BH-IIA-A-B44-OPTIONAL-WORD-001','reason':'II-B 707–759 explicitly uses mathematical tensor-word classification only, so this condition is NOT added to proof ancestry for minimal-word-length.'},{'id':'BH-IIA-A-B54-CMP-I-001','reason':'Whole-structured GP3 comparison is later and not used by Batch1.'},{'id':'BH-IIA-A-B54-CMP-II-001','reason':'Not used by Batch1.'},{'id':'BH-IIA-A-B54-CMP-III-001','reason':'Not used by Batch1.'},{'id':'BH-IIA-A-PORT-001','reason':'A universal full-parent affine/Lie upgrade is not needed to prove facts of the already selected fixed SU2 round host.'}]
boundaries=[]
def boundary(id,title,start,end,history,scope,grammar,distinction,conditions):
 boundaries.append({'id':id,'title':title,'source':loc(start,end),'ordered_provenance':history,'chronological_stage':'Initial Paper-II momentum seed after II-A selected parent; no downstream coordinate/dynamics signature imported.','actual_candidate_domain':scope,'constructor_grammar':grammar,'existence_uniqueness_canonicality_realization_interpretation':distinction,'condition_ids':conditions,'allegation_adjudication':'No hidden selector/closure/refutation established by this boundary review.'})
boundary('BND-IIB-B1-ROUND-001','Single parent and its derived symmetry cover',330,355,['[FROZEN] II-A selected noncommutative primitive role','[DER] round negative-Killing ray','[DER] Isom0=SO4, universal lift Spin4','[CLASS] finite symmetry sectors'], 'The fixed relation-exact SU2=S3(R), R>0; source is not quantifying over all global topological parent candidates.', {'licensed':['constituted operation group law and identity','left/right isometries of fixed round metric','universal symmetry lift'], 'host_only':['a second momentum carrier from Spin4 product topology'],'output_retention':'Derived symmetry acts on same round carrier; finite modules are separately typed.'}, 'Existence of selected parent inherited; unique metric only up to scale; Spin4 is cover of metric symmetry, not second physical carrier.', ['BH-IIA-A-B32-ROUND-001'])
boundary('BND-IIB-B1-DESCENT-001','Spin4 integration and SO4 operator descent',434,488,['[FROZEN] fixed round host and derived symmetry algebra','[CLASS] compact finite unitary representation','[DER] central-character block descent'], 'Finite complex unitary so4 representations; arbitrary direct sums may contain both diagonal-center characters.', {'licensed':['Lie representation integration to simply connected Spin4','conjugation restricted to matching central-character blocks'],'excluded':['descent of arbitrary cross-character endomorphisms']}, 'Existence/integration classification is conditional on carrying the specified unitary symmetry. Central-odd spinor modules are allowed at Spin4 level; their full arbitrary End mixing need not descend.', ['BH-IIB-A-B1-UNITARY-001'])
boundary('BND-IIB-B1-WORD-001','Representation word degree is classification',666,760,['[FROZEN] geometric lowest spinor spaces','[CLASS] fundamental highest weights','[CLASS] mathematical tensor-word length'], 'All irreducible Spin4 modules for mathematical bookkeeping; no physical full dominant-weight monoid is asserted.', {'mathematical':['tensor words of F_L direct-sum F_R','highest-spin constituent and shell sums'],'physical_not_added':['unrestricted tensor powers','word-budget selector']}, 'Geometric spinor objects precede weight classification. The descriptor first/lowest follows round harmonic package, not GP3 minimum dimension.', ['BH-IIA-A-B32-ROUND-001'])
boundary('BND-IIB-B1-IMAGE-001','Finite section-object image and same-role inheritance',763,1110,['[FROZEN] E0,S0+,S0-,E1, gradient and bracket','[GEN] beta:E1xE1→Gamma(TS3)_sec,obj','[GEN] linear object closure or two-bracket finite surjection','[CLASS] bivector/Killing identification','[REAL] finite typed image inherits same-role carrier slot'], 'Only canonical six-dimensional Killing section-object image of constituted beta/two-bracket addition; ambient sections and full polynomial/tensor closure are excluded.', {'licensed':['E1 → gradient section objects','beta(f,g)=[grad f,grad g]','preconstituted real linear object target addition/scalar multiplication','finite-image inheritance','same-role no-splitting'], 'operation_port':'K→delta_K is distinct and only co-realized on explicitly licensed declared target; no scalar outputs recycled as new seed.','host_only':['Lambda2 classifier','ambient Gamma(TS3)','ordinary scalar multiplication']}, 'Six-dimensional mathematical image is checked in II-B; II-A conditional inheritance is applied after image eligibility. The exact generated object copy is retained; this says nothing about universal GP3 one-copy implementation.', ['BH-IIA-A-B33-SMOOTH-001','BH-IIA-A-B33-IMAGE-001','BH-IIA-A-B40-INTERNAL-001','BH-IIB-A-B1-SECTION-LINEAR-001'])
boundary('BND-IIB-B1-CONFORMAL-001','Host conformal algebra and fixed scalar action target',884,962,['[HOST] ten-dimensional conformal Lie field algebra','[CLASS] compact Spin4 module c_C','[CLASS] ordinary derivation preservation of P1'], 'Smooth ordinary vector fields X in c=Killing+grad E1; mathematical target P1 is specified, not physically selected.', {'host_only':['all ordinary smooth derivations','so(4,1) Lie classification'],'not_added':['noncompact finite-dimensional unitary physical momentum parent','conformal-density derivative substituted for ordinary X(h)']}, 'An isomorphism c≈so(4,1) and 11+4 module decomposition do not prove matrix simplicity/dimension137 of a coordinate algebra or select state/control.', ['BH-IIB-A-B1-P1-TARGET-001'])
boundary('BND-IIB-B1-GRADIENT-001','Conditional gradient-evaluation infinite tower',964,997,['[FROZEN] alternative enlarged grammar','[GEN] ordinary G scalar evaluation','[GEN] each output scalar retained','[GEN] every finite iteration licensed','[DER] unbounded polynomial degrees'], 'Alternative enlarged physical grammar only; cannot refute frozen finite momentum seed because that seed does not license scalar evaluation/reuse.', {'typed_word':'F0=x1 in scalar carrier → G(F0)=F1 retained scalar → ... → G(Fn)=Fn+1 retained scalar, n arbitrary finite','all_steps_licensed_by':['BH-IIB-A-B1-GRAD-EVAL-001','BH-IIB-A-B1-GRAD-RETAIN-001','BH-IIB-A-B1-GRAD-REUSE-001']}, 'Infinite closure is an existing conditional obstruction; it is not an unproved physical occurrence claim or gap in the base grammar.', ['BH-IIB-A-B1-GRAD-EVAL-001','BH-IIB-A-B1-GRAD-RETAIN-001','BH-IIB-A-B1-GRAD-REUSE-001'])
edges=[]
def edge(fr,to,kind,start,end,file=source,guard='Exact stated fixed-round or mathematical representation scope; no physical occurrence promotion.',route=None,review='REVIEWED_MATERIAL_USE'):
 idx=len(edges)+1
 edges.append({'id':f'BH-IIB-B1-DEP-{idx:03}','from':fr,'to':to,'kind':kind,'proof_route_id':route or f'BH-IIB-B1-ROUTE::{to}','logic_group':'AND','scope_guard':guard,'source_use_locator':loc(start,end,file),'review_status':review,'reviewed':review=='REVIEWED_MATERIAL_USE','evidence_id':'BH-IIB-B1-E1-BOUNDARY-001','statement_status_promotion':False})
edge('p2:thm:master-compact-role-allocation','p2:thm:single-su2-derived-spin4-isometries','IMPORTED_PROOF',358,364)
edge('BH-IIA-A-B32-ROUND-001','p2:thm:single-su2-derived-spin4-isometries','SCOPE_GUARD',358,364)
edge('p2:thm:single-su2-derived-spin4-isometries','p2:prop:algebra-sector-grammar','PREMISE_OF',434,440)
edge('BH-IIB-A-B1-UNITARY-001','p2:prop:algebra-sector-grammar','SCOPE_GUARD',434,443)
edge('p2:prop:algebra-sector-grammar','p2:prop:component_spectrum','PREMISE_OF',564,568)
edge('p1:thm:representation-harmonic-package','p2b:thm:seed-atomicity','IMPORTED_PROOF',696,699)
edge('p2:thm:single-su2-derived-spin4-isometries','p2b:thm:seed-atomicity','PREMISE_OF',676,679)
edge('p2b:thm:seed-atomicity','p2b:lem:minimal-word-length','PREMISE_OF',722,728,guard='Mathematical F_L,F_R types only, not physical unrestricted tensor construction.')
edge('p2b:lem:minimal-word-length','p2b:cor:word-degree-derived','PREMISE_OF',755,759)
edge('p2:def:momentum-seed-frontier','p2b:lem:canonical-bracket-image','CONSTRUCTOR_INPUT',764,781)
edge('p1:thm:quadratic-shell-conformal-killing','p2b:lem:canonical-bracket-image','IMPORTED_PROOF',850,852)
edge('p1:thm:representation-harmonic-package','p2b:lem:gradient-port','IMPORTED_PROOF',875,877)
edge('p2b:lem:canonical-bracket-image','p2b:prop:conformal-host-closure','PREMISE_OF',910,913)
edge('p2b:thm:seed-atomicity','p2b:prop:conformal-host-closure','PREMISE_OF',919,921)
edge('p2b:prop:conformal-host-closure','p2b:prop:maximal-finite-scalar-action','PREMISE_OF',938,942)
edge('BH-IIB-A-B1-P1-TARGET-001','p2b:prop:maximal-finite-scalar-action','SCOPE_GUARD',938,950)
for id in ['BH-IIB-A-B1-GRAD-EVAL-001','BH-IIB-A-B1-GRAD-RETAIN-001','BH-IIB-A-B1-GRAD-REUSE-001']:
 edge(id,'p2b:prop:gradient-evaluation-no-go','SCOPE_GUARD',964,970,guard='AND of all three explicit enlarged-grammar licenses; never applies to the frozen seed alone.')
edge('p2b:lem:canonical-bracket-image','p2b:lem:v264-two-bracket-surjection','PREMISE_OF',1022,1024)
edge('BH-IIB-A-B1-SECTION-LINEAR-001','p2b:lem:v264-two-bracket-surjection','CONSTRUCTOR_INPUT',1012,1020)
edge('p2b:lem:v264-two-bracket-surjection','p2b:rem:v264-literal-inheritance','PREMISE_OF',1048,1055)
edge('p2:lem:gp2-finite-generated-image-inheritance','p2b:rem:v264-literal-inheritance','IMPORTED_PROOF',1048,1055)
edge('p2b:lem:canonical-bracket-image','p2b:cor:bracket-image-same-carrier','PREMISE_OF',1085,1093)
edge('p2:def:gp2-generated-closure','p2b:cor:bracket-image-same-carrier','IMPORTED_PROOF',1090,1097)
edge('p2:lem:gp2-finite-generated-image-inheritance','p2b:cor:bracket-image-same-carrier','IMPORTED_PROOF',1090,1097)
edge('p2:lem:gp2-same-role-no-splitting','p2b:cor:bracket-image-same-carrier','IMPORTED_PROOF',1100,1109)
for id,a,b in [('BH-IIA-A-B33-IMAGE-001',1085,1097),('BH-IIA-A-B40-INTERNAL-001',1100,1106),('BH-IIB-A-B1-SECTION-LINEAR-001',1077,1083)]:
 edge(id,'p2b:cor:bracket-image-same-carrier','SCOPE_GUARD',a,b)
# This discharges mathematical finite-image eligibility at this specialization, not the generic condition universally.
edge('p2b:lem:canonical-bracket-image','BH-IIA-A-B33-IMAGE-001','DISCHARGES',1085,1097,guard='Only specialization Z=Killing, F=finite two-bracket composite on the declared linear section-object target. Generic F:X→Y condition is NOT universally discharged.',route='BH-IIB-B1-ROUTE-IMAGE-SPECIALIZATION')
# Forward interfaces are reviewed use links only. Their consumers stay NOT_AUDITED in this batch.
edge('p2b:cor:bracket-image-same-carrier','p2:thm:momentum-host-H1','PREMISE_OF',1142,1148,guard='Source-use mapping only; consumer outside Batch1, no verification promotion.')
edge('p2b:lem:minimal-word-length','p2:thm:m1-component','PREMISE_OF',1381,1384,guard='Source-use mapping only; consumer outside Batch1, no verification promotion.')
edge('p2:thm:momentum-host-H1','p2:thm:m1-component','PREMISE_OF',1369,1372,guard='Source-use mapping only; consumer outside Batch1, no verification promotion.')
# Compile material imported theorem witnesses: their full papers are not audit units.
imports=[]
for label,a,b in [('p2:lem:gp2-finite-generated-image-inheritance',3180,3214),('p2:lem:gp2-same-role-no-splitting',3216,3258),('p2:def:momentum-seed-frontier',5822,5867),('p2:def:gp2-generated-closure',6011,6036),('p2:thm:master-compact-role-allocation',7931,8004),('p2:thm:dependency-complete-parent-allocation',8526,8580),('p2:def:momentum-branch-specialization',8791,8831)]:
 imports.append({'id':label,'scope_checked':'Exact imported fixed-round/constructor contract, not a whole-paper audit.','source':loc(a,b,'Paper2A-GeometricConstitution-v3_212.tex'),'status':'SOURCE_CONTRACT_MATCHED'})
for label,a,b in [('p1:thm:representation-harmonic-package',1651,1682),('p1:thm:quadratic-shell-conformal-killing',2018,2105)]:
 imports.append({'id':label,'scope_checked':'Only E0/E1/k=0 spinors and finite Killing bracket image consumed in target.','source':loc(a,b,'Paper1A-Geometry-v5_163.tex'),'status':'SOURCE_CONTRACT_MATCHED','external_reference_boundary':'Spinor harmonic package is stated as imported standard reference; independent target verification should be furnished by E3 agent. This mapper does not claim a fresh proof of the cited full harmonic package.'})
proposal={'proposal_owner':'boundaries_dependencies','target':source,'batch':1,'source_span':[192,1111],'source_authority':'Paper00-PapersMinimal-v2_365.zip','new_conditions':new,'reused_conditions':reused,'explicitly_not_consumed_conditions':not_used,'boundary_records':boundaries,'typed_dependency_edges':edges,'import_contracts':imports,'candidate_issues':[],'conclusion':'No new hidden-condition, constructor-leakage, source-domain or inherited-gap allegation established. Every explicit conditional source result retains its exact stated scope. Reuse existing origin predicates; no new fundamental axiom.','integration_cautions':['Do not propagate generic DISCHARGES globally; this edge only certifies the Killing specialization. Route target can alternatively be a dedicated instantiated-condition use record.','Same-role co-realization of an induced operation remains conditional on BH-IIA-A-B33-DERLIC-001. Do not infer arbitrary physical scalar derivations.','Source-use edges to claims outside Batch1 are interface mapping only and must not increment checked-claim coverage.','Existing BH-IIB-STRUCTURED-RIGIDITY-001 and three B54 comparison conditions are carried forward unchanged; no Batch1 route consumes them.','The source author explicitly excludes automatic coordinate algebra/137 and scale/Hamiltonian/state selection. These are scope guards, not failed claims.']}
out=root/'work/proposals/boundaries/Paper2B-Batch1BoundaryDependencyProposal-v1_1.json'
out.write_text(json.dumps(proposal,indent=2,ensure_ascii=False)+'\n')
print(out)
print('new_conditions',len(new),'reused_conditions',len(reused),'boundaries',len(boundaries),'typed_edges',len(edges),'imports',len(imports),'candidate_issues',len(proposal['candidate_issues']))
