#!/usr/bin/env python3
"""Stdlib exact-rational controls of EXISTING Paper II-B first-batch claims.
Finite controls accompany, not replace, general analytic certificates.
"""
from fractions import Fraction as Q
from collections import defaultdict
from math import comb, factorial
from pathlib import Path
import json

counts=defaultdict(int)
def check(value,group):
    assert value,group
    counts[group]+=1

# Sparse exact polynomial ring Q[x0,...,x3,u0,...,u3,v0,...,v3].
class P:
    nv=12
    def __init__(self,value=0):
        self.d=value if isinstance(value,dict) else ({(0,)*self.nv:Q(value)} if value else {})
        self.d={k:Q(v) for k,v in self.d.items() if v}
    def __add__(self,b):
        b=b if isinstance(b,P) else P(b);d=dict(self.d)
        for k,v in b.d.items():d[k]=d.get(k,0)+v
        return P(d)
    __radd__=__add__
    def __neg__(self):return P({k:-v for k,v in self.d.items()})
    def __sub__(self,b):return self+-b if isinstance(b,P) else self+P(-b)
    def __rsub__(self,b):return P(b)+-self
    def __mul__(self,b):
        b=b if isinstance(b,P) else P(b);d=defaultdict(Q)
        for k,v in self.d.items():
            for h,w in b.d.items():d[tuple(a+b for a,b in zip(k,h))]+=v*w
        return P(dict(d))
    __rmul__=__mul__
    def diff(self,i):
        d={}
        for k,v in self.d.items():
            if k[i]:h=list(k);h[i]-=1;d[tuple(h)]=v*k[i]
        return P(d)
    def __eq__(self,b):return self.d==(b.d if isinstance(b,P) else P(b).d)

def var(i):
    k=[0]*12;k[i]=1;return P({tuple(k):1})
x=[var(i) for i in range(4)];u=[var(i) for i in range(4,8)];v=[var(i) for i in range(8,12)]
dot=lambda a,b:sum((c*d for c,d in zip(a,b)),P())
def bracket(F,G):return [sum((G[i].diff(j)*F[j]-F[i].diff(j)*G[j] for j in range(4)),P()) for i in range(4)]
for R in [Q(1),Q(2),Q(3)]:
    fu=dot(u,x);fv=dot(v,x)
    Gu=[u[i]-fu*x[i]*Q(1,R**2) for i in range(4)]
    Gv=[v[i]-fv*x[i]*Q(1,R**2) for i in range(4)]
    actual=bracket(Gu,Gv)
    for i in range(4):check(actual[i]==(fu*v[i]-fv*u[i])*Q(1,R**2),'symbolic_gradient_bracket')
    # Intrinsic divergence trace(P DG), modulo |x|²=R²; exact residual.
    intrinsic=sum((( (1 if i==j else 0)-x[i]*x[j]*Q(1,R**2))*Gu[i].diff(j) for i in range(4) for j in range(4)),P())
    residual=2*fu*(dot(x,x)-R**2)*Q(1,R**4)
    check(intrinsic+3*fu*Q(1,R**2)==residual,'symbolic_intrinsic_divergence')

# Exact rational matrices; Jy=-i*T, T=(Jplus-Jminus)/2, so no radicals/complex numbers.
def zero(n,m=None):return [[Q(0) for _ in range(m or n)] for _ in range(n)]
def eye(n):
    a=zero(n)
    for i in range(n):a[i][i]=Q(1)
    return a
def add(A,B):return [[a+b for a,b in zip(r,s)] for r,s in zip(A,B)]
def scale(c,A):return [[Q(c)*v for v in row] for row in A]
def sub(A,B):return add(A,scale(-1,B))
def mul(A,B):return [[sum((A[i][k]*B[k][j] for k in range(len(B))),Q(0)) for j in range(len(B[0]))] for i in range(len(A))]
def comm(A,B):return sub(mul(A,B),mul(B,A))
def trans(A):return list(map(list,zip(*A)))
def kron(A,B):return [[A[i//len(B)][j//len(B[0])]*B[i%len(B)][j%len(B[0])] for j in range(len(A[0])*len(B[0]))] for i in range(len(A)*len(B))]
spins={}
for n in range(5):
    jp=zero(n+1);jm=zero(n+1);z=zero(n+1)
    for k in range(n+1):
        z[k][k]=Q(n,2)-k
        if k:jp[k-1][k]=Q(k)
        if k<n:jm[k+1][k]=Q(n-k)
    X=scale(Q(1,2),add(jp,jm));T=scale(Q(1,2),sub(jp,jm))
    check(comm(X,T)==scale(-1,z),'su2_commutators')
    check(comm(z,X)==T,'su2_commutators')
    check(comm(z,T)==X,'su2_commutators')
    check(add(sub(mul(X,X),mul(T,T)),mul(z,z))==scale(Q(n,2)*(Q(n,2)+1),eye(n+1)),'su2_casimir')
    H=zero(n+1)
    for k in range(n+1):H[k][k]=Q(1,comb(n,k))
    check(mul(H,jp)==mul(trans(jm),H),'positive_metric_adjoint')
    spins[n]=(X,T,z)
for nl,L in spins.items():
    for nr,Rp in spins.items():
        D=[sub(kron(l,eye(nr+1)),kron(eye(nl+1),r)) for l,r in zip(L,Rp)]
        J=[add(kron(l,eye(nr+1)),kron(eye(nl+1),r)) for l,r in zip(L,Rp)]
        check(comm(D[0],D[1])==scale(-1,J[2]),'momentum_commutators')
        check(comm(J[0],D[1])==scale(-1,D[2]),'momentum_commutators')
        eig=[D[2][k][k] for k in range(len(D[2]))]
        check(max(abs(z) for z in eig)==Q(nl+nr,2),'component_norm')
        check((-1)**nl*(-1)**nr==(-1)**(nl+nr),'central_character')
        for dl in [-1,1]:
            for dr in [-1,1]:
                if nl+dl>=0 and nr+dr>=0:check((-1)**(nl+dl+nr+dr)==(-1)**(nl+nr),'coordinate_descent')

# Independent Lorentz matrix realization on ten generators, all pairwise brackets.
basis=[]
for i in range(4):
    for j in range(i+1,4):
        a=zero(4);a[j][i]=1;a[i][j]=-1;basis.append(a)
eta=eye(5);eta[4][4]=-1
for radius in [Q(1),Q(2),Q(3)]:
    def lk(A):
        a=zero(5)
        for i in range(4):
            for j in range(4):a[i][j]=-A[i][j]
        return a
    def lg(u):
        a=zero(5)
        for i in range(4):a[i][4]=a[4][i]=u[i]/radius
        return a
    U=eye(4)
    for A in basis:
        KA=lk(A)
        check(add(mul(trans(KA),eta),mul(eta,KA))==zero(5),'lorentz_signature')
        for B in basis:check(comm(KA,lk(B))==lk(sub(mul(B,A),mul(A,B))),'lorentz_killing_brackets')
        for u in U:
            Au=[sum(A[i][j]*u[j] for j in range(4)) for i in range(4)]
            check(comm(KA,lg(u))==lg([-v for v in Au]),'lorentz_mixed_brackets')
    for u in U:
        check(add(mul(trans(lg(u)),eta),mul(eta,lg(u)))==zero(5),'lorentz_signature')
        for v in U:
            skew=[[Q(v[i]*u[j]-u[i]*v[j],radius**2) for j in range(4)] for i in range(4)]
            check(comm(lg(u),lg(v))==lk(skew),'lorentz_gradient_brackets')

# Real two-form Pfaffian and Hodge-norm equality in independent integer controls.
from itertools import product
for a,b,c,d,e,f in product([-1,0,1],repeat=6):
    pf=a*f-b*e+c*d
    plus=Q((a+f)**2+(b-e)**2+(c+d)**2,2)
    minus=Q((a-f)**2+(b+e)**2+(c-d)**2,2)
    check(plus-minus==2*pf,'hodge_decomposability')
check(1*1-0*0+0*0!=0,'two_bracket_sharpness')

# Tensor recursion and independent first-appearance enumeration.
states={(0,0):1};first={(0,0):0}
for r in range(1,10):
    nxt=defaultdict(int)
    for (l,t),mult in states.items():
        for pair in [(l+1,t),(l-1,t),(l,t+1),(l,t-1)]:
            if min(pair)>=0:nxt[pair]+=mult
    for k in nxt:first.setdefault(k,r)
    states=nxt
for (l,t),r in first.items():check(r==l+t,'minimal_word_length')
for N in range(30):
    check(sum((i+1)*(N-i+1) for i in range(N+1))==comb(N+3,3),'word_shell_dimension')
    check(sum(sum((i+1)*(n-i+1) for i in range(n+1)) for n in range(N+1))==comb(N+4,4),'word_prefix_dimension')
for radius in [Q(1),Q(2),Q(3)]:
    for i in range(4):
        for j in range(4):
            ff=radius**2/4 if i==j else Q(0)
            gg=(1 if i==j else 0)-ff/radius**2
            check(gg==3*ff/radius**2,'sphere_gradient_moments')
    check((-radius**2/3)*(-3/radius**2)==1,'gradient_unitary_inverse')
    poly={1:Q(1)}
    for iteration in range(1,13):
        nxt=defaultdict(Q)
        for degree,coef in poly.items():
            if degree:nxt[degree-1]+=degree*coef;nxt[degree+1]-=degree*coef/radius**2
        poly={d:c for d,c in nxt.items() if c}
        check(max(poly)==iteration+1,'retained_gradient_degree')
        check(poly[max(poly)]==(-1)**iteration*Q(factorial(iteration),radius**(2*iteration)),'retained_gradient_leading_term')
result={'script':Path(__file__).name,'status':'PASS','assertions':sum(counts.values()),'groups':dict(counts),'range':'Source192-1111; spins0..2; radii1,2,3; tensor lengths0..9; polynomial iterations1..12','limitations':['Finite controls supplement general analytic proofs, not universal finite-search certification.','No source theorem or physical constructor is added.','The initial sympy-based version could not run because sympy is absent; this final certificate uses only Python stdlib.']}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
