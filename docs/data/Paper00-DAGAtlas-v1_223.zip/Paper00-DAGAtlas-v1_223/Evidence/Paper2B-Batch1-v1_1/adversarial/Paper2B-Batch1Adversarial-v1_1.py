"""Exact E4 finite controls for Paper II-B v2.135 lines192--1111.
Only Python standard library. General arguments/negative attacks in paired JSON.
Finite tests do not certify physical occurrence or universal representation theory.
"""
from fractions import Fraction as Q
from pathlib import Path
import itertools, json, math
O=Path(__file__).parent
checks=[]
def check(name, pred):
    assert pred,name
    checks.append(name)
class P:
 def __init__(self,d=0):
    if isinstance(d,P): self.d=d.d.copy()
    elif isinstance(d,dict): self.d={k:Q(v) for k,v in d.items() if v}
    else: self.d={(0,0,0,0):Q(d)} if d else {}
 def __add__(self,o):
    o=P(o); d=self.d.copy()
    for k,v in o.d.items(): d[k]=d.get(k,0)+v
    return P(d)
 __radd__=__add__
 def __neg__(self): return P({k:-v for k,v in self.d.items()})
 def __sub__(self,o): return self+-P(o)
 def __rsub__(self,o): return P(o)+-self
 def __mul__(self,o):
    o=P(o); d={}
    for k,v in self.d.items():
     for j,w in o.d.items():
      t=tuple(a+b for a,b in zip(k,j)); d[t]=d.get(t,0)+v*w
    return P(d)
 __rmul__=__mul__
 def diff(self,i):
    d={}
    for k,v in self.d.items():
     if k[i]:
      t=list(k); t[i]-=1; d[tuple(t)]=v*k[i]
    return P(d)
 def __eq__(self,o): return self.d==P(o).d
 def __pow__(self,n):
    z=P(1)
    for _ in range(n): z=z*self
    return z
x=[P({tuple(1 if j==i else 0 for j in range(4)):1}) for i in range(4)]
basis=[[Q(i==j) for j in range(4)] for i in range(4)]
z=[P() for _ in range(4)]
add=lambda a,b:[t+w for t,w in zip(a,b)]
scale=lambda c,a:[c*t for t in a]
dot=lambda a,b:sum(t*w for t,w in zip(a,b))
def matvec(A,v): return [dot(row,v) for row in A]
def matmul(A,B): return [[sum(a*b for a,b in zip(row,col)) for col in zip(*B)] for row in A]
def matsub(A,B): return [[a-b for a,b in zip(ra,rb)] for ra,rb in zip(A,B)]
def comm(A,B): return matsub(matmul(A,B),matmul(B,A))
def outer(a,b):return [[t*w for w in b] for t in a]
def bracket(X,Y): return [sum(Y[i].diff(j)*X[j]-X[i].diff(j)*Y[j] for j in range(4)) for i in range(4)]
As=[]
for i,j in itertools.combinations(range(4),2):
 A=[[Q(0) for _ in range(4)] for _ in range(4)]; A[i][j]=1;A[j][i]=-1;As.append(A)
def phiK(A): return [[-A[i][j] if i<4 and j<4 else Q(0) for j in range(5)] for i in range(5)]
def phiG(u,R): return [[(u[i]/R if j==4 and i<4 else u[j]/R if i==4 and j<4 else Q(0)) for j in range(5)] for i in range(5)]
for R in [Q(1),Q(2),Q(3,2)]:
 G=lambda u:add(u,scale(-1/R**2,scale(dot(u,x),x)))
 K=lambda A:matvec(A,x)
 for a,u in enumerate(basis):
  for b,v in enumerate(basis):
   C=[[e/R**2 for e in row] for row in matsub(outer(v,u),outer(u,v))]
   check(f'gradient_bracket_sign_scale_R{R}_{a}_{b}',bracket(G(u),G(v))==K(C))
   check(f'lorentz_block_GG_R{R}_{a}_{b}',comm(phiG(u,R),phiG(v,R))==phiK(C))
 for a,A in enumerate(As):
  for b,u in enumerate(basis):
   Au=matvec(A,u)
   check(f'KG_sign_R{R}_{a}_{b}',bracket(K(A),G(u))==scale(-1,G(Au)))
   check(f'lorentz_block_KG_R{R}_{a}_{b}',comm(phiK(A),phiG(u,R))==[[-e for e in row] for row in phiG(Au,R)])
 for a,A in enumerate(As):
  for b,B in enumerate(As):
   C=comm(B,A)
   check(f'KK_antihomomorphism_R{R}_{a}_{b}',bracket(K(A),K(B))==K(C))
   check(f'lorentz_block_KK_R{R}_{a}_{b}',comm(phiK(A),phiK(B))==phiK(C))
 # Scalar target mutation: x1² cannot equal affine in x1 at -R,0,R.
 check(f'scalar_quadratic_nonaffine_R{R}',R**2!=0)
 # Full first-harmonic eigenspace inverse coefficient is exactly 1.
 check(f'gradient_unitary_inverse_R{R}',(-R*R/Q(3))*(-Q(3)/R**2)==1)
 # Repeated gradient evaluation recurrence on polynomials in x1.
 F={1:Q(1)}
 for n in range(17):
  check(f'gradient_retained_degree_R{R}_{n}',max(F)==n+1)
  check(f'gradient_retained_leading_R{R}_{n}',F[n+1]==(-1)**n*Q(math.factorial(n))/R**(2*n))
  H={}
  for k,v in F.items():
   if k:
    H[k-1]=H.get(k-1,Q(0))+k*v;H[k+1]=H.get(k+1,Q(0))-k*v/R**2
  F={k:v for k,v in H.items() if v}
# Tensor-length BFS with exact fundamental Clebsch--Gordan fusion.
levels=[{(0,0)}];minimum={(0,0):0}
for n in range(1,13):
 nxt=set()
 for a,b in levels[-1]:
  nxt.add((a+1,b));nxt.add((a,b+1))
  if a:nxt.add((a-1,b))
  if b:nxt.add((a,b-1))
 levels.append(nxt)
 for z in nxt:minimum.setdefault(z,n)
for (a,b),n in sorted(minimum.items()):check(f'tensor_word_min_{a}_{b}',n==a+b)
for N in range(13):
 check(f'shell_dimension_{N}',sum((a+1)*(N-a+1) for a in range(N+1))==math.comb(N+3,3))
 check(f'prefix_dimension_{N}',sum(math.comb(n+3,3) for n in range(N+1))==math.comb(N+4,4))
for a,b in itertools.product(range(9),repeat=2):
 vals=[Q(m-n,2) for m in range(-a,a+1,2) for n in range(-b,b+1,2)]
 check(f'component_norm_{a}_{b}',max(abs(t) for t in vals)==Q(a+b,2))
 src=(-1)**(a+b)
 for da,db in itertools.product([-1,1],repeat=2):
  if a+da>=0 and b+db>=0:check(f'coordinate_central_preservation_{a}_{b}_{da}_{db}',src==(-1)**(a+da+b+db))
check('opposite_character_Hom_mutation_detected',(-1)**0*(-1)**1==-1)
for l,m in itertools.product([Q(-2),Q(-1),Q(0),Q(1),Q(3,2)],repeat=2):
 check(f'hodge_norm_difference_{l}_{m}',(l+m)**2/2-(l-m)**2/2==2*l*m)
# e12+e34 has wedge square 2vol, whereas one decomposable bivector squares to zero.
check('rank4_wedge_square_nonzero',2!=0)
result={'scope':'Paper2B v2.135 lines192--1111','assertion_count':len(checks),'all_passed':True,'checks':checks,'limits':'Finite word/spectrum bounds and radii are corroborative controls; general E4 arguments are recorded separately. No physical occurrence inferred.'}
(O/'Paper2B-Batch1AdversarialResults-v1_1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'}))
