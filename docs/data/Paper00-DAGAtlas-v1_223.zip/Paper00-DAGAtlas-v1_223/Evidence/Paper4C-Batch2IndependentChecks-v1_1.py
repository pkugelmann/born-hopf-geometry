#!/usr/bin/env python3
"""Independent exact and finite-matrix tests of existing printed Paper 4C claims,
lines 1863–3434. No changes to source or theoretical claims.
Each control is scoped; a numerical PASS is not a universal proof.
"""
import json, math, hashlib
from pathlib import Path
import numpy as np
import scipy.linalg as la
import sympy as sp

base=Path(__file__).resolve().parent
src=Path('/mnt/data/bh4c_work/papers/Paper00-PapersMinimal-v2_371/Paper4C-TechnicalMaterial-v1_42.tex')
assert hashlib.sha256(src.read_bytes()).hexdigest()=='db4933305c7acd0a67ac9c81ba219d051cbad95777a9848514ce4ce0e4e57626'
rng=np.random.default_rng(4812026)
records=[]
def ck(tag,name,claim,ok,detail,typ='E3',scope='EXACT_EQUALITY_OR_EXPLICIT_FINITE_WITNESS'):
    records.append(dict(id='BH-IVC-B2-'+typ+'-'+tag,name=name,claim=claim,status='PASS' if ok else 'FAIL',type=typ,scope=scope,details=detail))
    if not ok: print('FAIL',tag,detail)
def close(a,b,tol=1e-9):return np.allclose(a,b,rtol=tol,atol=tol)
def norm(a):return float(la.norm(a,2))
def hsqrt(a):
    d,v=la.eigh(a)
    return (v*np.sqrt(np.maximum(d,0)))@v.conj().T
def rnd(n):return rng.standard_normal((n,n))+1j*rng.standard_normal((n,n))
def Herm(n):
    m=rnd(n);return (m+m.conj().T)/2

# Scalar cyclic kernel and its forward original carrier relation.
ener=np.array([0.0,0.6,1.7]); w=np.array([0.8,1.5,0.25]); ts=np.array([0.0,0.3,0.7,1.1])
Cc=lambda t: sum(w*np.exp(-ener*abs(t)))
Gram=np.array([[Cc(s+t) for t in ts] for s in ts]); feats=np.sqrt(w)[None,:]*np.exp(-ts[:,None]*ener[None,:]);
ck('001','Cyclic spectral representation / reflection Gram', 'p4:thm:finite-euclidean-hamiltonian-reconstruction', close(Gram,feats@feats.T) and la.eigvalsh(Gram).min()>-1e-12,{'min_eig':float(la.eigvalsh(Gram).min()),'energies':ener.tolist(),'weights':w.tolist()},scope='E3_EXACT_FINITE_SPECTRAL_CONSTRUCTION_WITH_NUMERIC_EVAL')
H=np.diag(ener); r=rnd(3); C0=r.conj().T@r+np.eye(3)
cc=hsqrt(C0); cci=la.inv(cc);tau=.43
CH=cc@la.expm(-tau*H)@cc; whiten=cci@CH@cci
ck('002','Whitened same-carrier kernel / generator','p4:thm:hamiltonian-generated-euclidean-branch',close(whiten,la.expm(-tau*H)) and close(CH,sum(np.outer(cc[:,k],cc[:,k].conj())*np.exp(-tau*ener[k]) for k in range(3))), {'whitening_residual':norm(whiten-la.expm(-tau*H))})
# 1x1 multi-exponential kernel refuses semigroup factorization.
S=lambda t: .5*(np.exp(-.5*t)+np.exp(-1.5*t))
failed_semigroup=abs(S(1.3)-S(.7)*S(.6))
ck('003','Kernel-first does not imply original-carrier semigroup','p4:thm:finite-euclidean-hamiltonian-reconstruction',failed_semigroup>1e-5,{'positive_weights':[.5,.5],'semigroup_defect':failed_semigroup},typ='E4',scope='MATCHED_COUNTERMODEL_TO_STRONGER_NOT_PRINTED_CLAIM')
# Two-sided complex-time operation CP contraction, cyclic trace-duality.
A=Herm(3);rho=rnd(3);rho=rho@rho.conj().T;rho/=np.trace(rho)
B=la.expm(-tau*H/2); U=la.expm(-1j*.72*H)
E=lambda a:B@a@B; EStar=lambda r:B@r@B
Ad=lambda a:U.conj().T@a@U; AdStar=lambda r:U@r@U.conj().T
ck('004','Complex-time positive/imaginary children and trace dual','p4:thm:complex-time-reciprocal-dynamics-square',
   close(np.trace(EStar(rho)@A),np.trace(rho@E(A))) and close(np.trace(AdStar(rho)@A),np.trace(rho@Ad(A))) and np.trace(EStar(rho)).real<=1+1e-10 and close(Ad(AdStar(A)),A),{'trace_E':float(np.trace(EStar(rho)).real)})
# Bosonic OS: many time/source vectors and second-order Wick symmetric tensor.
Z=[]
for _ in ener:
    v=rnd(3)[:,0];Z.append(np.outer(v,v.conj()))
indices=[(i,j) for i in range(4) for j in range(3)]
K=np.array([[sum(np.exp(-ener[a]*(ts[i]+ts[k]))*Z[a][j,l] for a in range(3)) for k,l in indices] for i,j in indices])
ck('005','Bosonic OS two-point Gram PSD from positive spectral matrices','p4:thm:finite-os-positivity',
   np.linalg.eigvalsh(K).min()>-1e-10 and close(K,K.conj().T),{'min_eig':float(np.linalg.eigvalsh(K).min()),'rank':int(np.linalg.matrix_rank(K,tol=1e-8))})
# Independent degree-two Wick Gram = restriction of K\otimes K + exchange.
select=[(a,b) for a in range(6) for b in range(a,6)]
K2=np.array([[K[a,c]*K[b,d]+K[a,d]*K[b,c] for c,d in select] for a,b in select])
ck('006','Bosonic Wick two-particle reflection Gram PSD','p4:thm:finite-os-positivity',
   np.linalg.eigvalsh(K2).min()>-1e-8 and close(K2,K2.conj().T),{'degree_two_min_eig':float(np.linalg.eigvalsh(K2).min())})
# OS transfer: expression from ordered word vs direct halfspace vector.
E3=np.diag([0.,.6,1.7]); vac=np.array([1.,0,0]); A1=rnd(3);A2=rnd(3); B1=rnd(3);B2=rnd(3)
F=((A1,.21),(A2,.72)); G=((B1,.3),(B2,.63))
def vword(word):
    z=vac.copy();times=[t for a,t in word]
    for j in range(len(word)-1,-1,-1):
        z=word[j][0]@z
        z=la.expm(-((times[j]-times[j-1]) if j else times[j])*E3)@z
    return z
def euclid(seq):
    z=vac.copy()
    for j in range(len(seq)-1,-1,-1):
        z=seq[j][0]@z
        if j:z=la.expm(-(seq[j][1]-seq[j-1][1])*E3)@z
    return vac.conj()@z
reflect=lambda w:[(a.conj().T,-t) for a,t in reversed(w)]
transfer=euclid(reflect(F)+list(G));inner=np.vdot(vword(F),vword(G))
ck('007','Hamiltonian transfer reflection Gram / halfspace vectors','p4:thm:hamiltonian-transfer-reflection-positivity',close(transfer,inner),{'gram_residual':float(abs(transfer-inner))})
# Integral Schur vs exact Gaussian, variation.
a,b,c,s,q,hh=sp.symbols('a b c s q h',positive=True,real=True)
S=a*q*q/sp.Integer(2)+b*q*sp.Symbol('x',real=True)+c*sp.Symbol('x',real=True)**2/sp.Integer(2)+s
x=sp.Symbol('x',real=True)
integ=sp.integrate(sp.exp(-S/hh),(x,-sp.oo,sp.oo),conds='none')
result=sp.sqrt(2*sp.pi*hh/c)*sp.exp(-s/hh)*sp.exp(-(a-b*b/c)*q*q/(2*hh))
# equality by expression in exact form (symbolic simplify complex branch may require factor).
residual=sp.simplify(integ/result)
ck('008','Gaussian Schur integration and absolute determinant term','p4:thm:v2109-gaussian-boundary-source',sp.simplify(residual-1)==0,{'symbolic_ratio':str(residual)})
Kexpr=a-b*b/c;delta=sp.diff(Kexpr,c)
ck('009','Gaussian K variation including dC contribution','p4:thm:v2109-gaussian-boundary-source',sp.simplify(delta-(b*b/c**2))==0,{'dK/dc':str(delta)})
# Collar Möbius law, unique positive fixed point.
k,w,ta,tb=sp.symbols('k w ta tb',positive=True,real=True)
def coll(k,t):return sp.factor(w*(k+w*t)/(w+k*t))
tcomp=(ta+tb)/(1+ta*tb)
comp=sp.factor(coll(coll(k,ta),tb)-coll(k,tcomp))
fixed=sp.factor(coll(k,ta)-k)
ck('010','Oscillator width collar composition and fixed points','p4:prop:v2109-ground-width-collar',comp==0 and sp.simplify(fixed.subs(k,w))==0 and sp.simplify(fixed.subs(k,-w))==0,{'composition_difference':str(comp),'fixed_point_difference':str(fixed)})
# Stationarity: excited eigenprojector normalized fixed; offdiagonal not; unnormalized !=.
H=np.diag([0,.4,1.2]);P=np.diag([0.,1.,0.]);B=la.expm(-.63*H/2);Eout=B@P@B
normalized=Eout/np.trace(Eout)
Q=np.ones((3,3))/3;Q=Q/np.trace(Q)
ck('011','Normalized Euclidean excited stationary state vs unnormalized','p4:prop:v2109-stationarity-distinction',close(normalized,P) and not close(Eout,P) and not close(B@Q@B/np.trace(B@Q@B),Q),{'excited_energy':0.4,'unnormalized_trace':float(np.trace(Eout))})
# Nontrivial phase/time-dependent pullback T cancellation in first-order B.
G=np.diag([1.3,2.2]); Bp=1j*Herm(2); J=rnd(2)[:,:1];dJ=rnd(2)[:,:1]
T=np.array([[1.2+.3j,.2+.1j],[.1-.1j,.8+.2j]]); dT=rnd(2)*.08
Ti=la.inv(T); dTi=-Ti@dT@Ti;Gp=Ti.conj().T@G@Ti; velocity=dT@Ti
Bpt=Ti.conj().T@Bp@Ti+.5*(velocity.conj().T@Gp-Gp@velocity)
old=J.conj().T@Bp@J+.5*(J.conj().T@G@dJ-dJ.conj().T@G@J)
Jt=T@J;dJt=dT@J+T@dJ
new=Jt.conj().T@Bpt@Jt+.5*(Jt.conj().T@Gp@dJt-dJt.conj().T@Gp@Jt)
ck('012','Moving parent frame extra B cancels embedding connection','p4:thm:v4118-transported-embedding-covariance',close(old,new),{'B_residual_norm':float(la.norm(old-new))})
# Coefficient polar frame F unitary with metric G>0 and nonunitary C.
r=rnd(3);G=r.conj().T@r+np.eye(3);r=rnd(3);C=r+np.eye(3);S=hsqrt(G);W=la.inv(S);Sp=hsqrt(C.conj().T@G@C)
F=Sp@la.inv(C)@W
ck('013','Nonunitary coefficient frame induces unitary normalized F','p4:thm:v4118-transported-embedding-covariance',close(F.conj().T@F,np.eye(3)) and close(F@F.conj().T,np.eye(3)),{'F_unitarity_err':norm(F.conj().T@F-np.eye(3))})
# Moving F(t)=exp(-itG) on Schr and Ward derivative.
G0=Herm(3);H0=Herm(3);dt=1e-6;t=.4
Ut=lambda x:la.expm(-1j*x*G0)
Hprime=Ut(t)@H0@Ut(t).conj().T+G0
u=rnd(3)[:,0];up=lambda x:Ut(x)@la.expm(-1j*x*H0)@u
du=(up(t+dt)-up(t-dt))/(2*dt)
ck('014','Schrodinger moving-frame connection term sign','p4:thm:v4118-transported-embedding-covariance',la.norm(1j*du-Hprime@up(t))<1e-7,{'schro_residual':float(la.norm(1j*du-Hprime@up(t)))})
# Ward generator G(t)=G0+t* G1 and variation H=(UHU†+i dotU U†)
G1=Herm(3);t=.23; eps=1e-6; Hbase=Herm(3); Gt=G0+t*G1
ud=lambda e:la.expm(-1j*e*Gt)
Hep=lambda e:ud(e)@Hbase@ud(e).conj().T+e*G1
num=(Hep(eps)-Hep(-eps))/(2*eps)
ward=G1-1j*(Gt@Hbase-Hbase@Gt)
ck('015','Spatial Ward infinitesimal conjugation / connection sign','p4:cor:v4118-source-bound-spatial-ward',la.norm(num-ward)<1e-8,{'ward_residual':float(la.norm(num-ward))},scope='E3_FINITE_MATRIX_VARIATION_ONLY_IMPORT_WARD_OWNER_UNTESTED')
# Matrix embedding: trace rank of identity units divisible by n; sample M2 -> M4.
Z=np.array([[1,0],[0,-1.]],complex); im=np.kron(Z,np.eye(2));
ck('016','Unital matrix embedding amplification and divisibility','p4:lem:matrix-embedding-divisibility',close(im@im,np.eye(4)) and np.trace(np.kron(np.eye(2),np.eye(2)))==4,{'amplification':'M2->M4', 'M2->M3':'representation dimension obstruction from irreducible rank 2'})
# Inductive state/automorphism compatibility M2 -> M4.
pN=rnd(2);pN=pN@pN.conj().T;pN/=np.trace(pN)
panc=np.array([[.65,0],[0,.35]])
pM=np.kron(pN,panc);X=Herm(2);obs=np.kron(X,np.eye(2))
hN=Herm(2);hAnc=Herm(2);t=.49;hM=np.kron(hN,np.eye(2))+np.kron(np.eye(2),hAnc)
U=la.expm(-1j*t*hN); UM=la.expm(-1j*t*hM)
ck('017','Exact inductive state and dynamics for tensor-factor refinement','p4:thm:inductive-qft-bridge',close(np.trace(pN@X),np.trace(pM@obs)) and close(UM.conj().T@obs@UM,np.kron(U.conj().T@X@U,np.eye(2))),{'state_error':float(abs(np.trace(pN@X)-np.trace(pM@obs)))})
# Inherited reflection-positive Gram of direct product finite level.
v=rnd(2);M=v.conj().T@v+np.eye(2);w=rnd(3);W=w.conj().T@w+np.eye(3)
Ztensor=np.kron(M,W)
ck('018','Inductive compatible reflection pairing retains PSD','p4:prop:inductive-reflection-positivity-inheritance',np.linalg.eigvalsh(Ztensor).min()>1e-10,{'min_eig':float(np.linalg.eigvalsh(Ztensor).min())})
# CAR 2 modes with Jordan Wigner representation.
sigma_z=np.diag([1.,-1.]);sigmam=np.array([[0.,1.],[0.,0.]])
c1=np.kron(sigmam,np.eye(2)); c2=np.kron(sigma_z,sigmam)
even1=c1.conj().T@c1;even2=c2.conj().T@c2
ck('019','Even CAR local net / fermionic graded locality','p4:thm:compatible-local-net',close(c1@c2.conj().T+c2.conj().T@c1,np.zeros((4,4))) and close(even1@even2-even2@even1,np.zeros((4,4))),{'CAR_cross_anticommutator_norm':norm(c1@c2.conj().T+c2.conj().T@c1)})
# Weighted conjugation locality with 3-site hopping Hamiltonian, rho=[0,1,2], E=0,F=2.
h=np.array([[0.,.18,0],[.18,0.,.23],[0.,.23,0.]])
rhoW=np.array([0.,1.,2.]); mu=.6;T=.37
D=np.diag(np.exp(mu*rhoW)); hconj=D@h@la.inv(D);v=norm(hconj-h)/mu
U=la.expm(-1j*T*h);bound=np.exp(-mu*(2-v*abs(T)))
ck('020','Weighted conjugation Duhamel offdiagonal finite CAR bound','p4:thm:weighted-conjugation-car-locality',abs(U[2,0])<=bound+1e-12,{'cross_amplitude':float(abs(U[2,0])),'upper_bound':float(bound),'v_N':v})
# CCR Weyl bound exact: |exp(-i sigma/2)-exp(i sigma/2)| <= |sigma|.
sigma=.43;comm=abs(np.exp(-1j*sigma/2)-np.exp(1j*sigma/2))
ck('021','Weyl commutator linear small-symplectic bound','p4:thm:approximate-microcausality',comm<=abs(sigma),{'weyl_comm_norm':float(comm),'epsilon_LR':sigma},scope='E3_FOR_REGULAR_CCR_WO_NORM_LOCAL_APPROXIMANT')
# Two-mode total-occupation truncated Fock: elementary CCR defect invisible on Q<=2 but higher word commutator not.
cap=3;basis=[(i,j) for n in range(cap+1) for i in range(n+1) for j in [n-i]]
pos={k:i for i,k in enumerate(basis)};dim=len(basis)
a=[]
for mode in [0,1]:
 mat=np.zeros((dim,dim))
 for p,(n1,n2) in enumerate(basis):
  o=[n1,n2]
  if o[mode]:
   m=o.copy();m[mode]-=1;mat[pos[tuple(m)],p]=np.sqrt(o[mode])
 a.append(mat)
ad=[x.conj().T for x in a]; P=np.diag([1. if sum(x)<=2 else 0. for x in basis]); z=np.zeros((dim,dim));ident=np.eye(dim)
ccd=[norm(P@(a[i]@ad[j]-ad[j]@a[i] - (ident if i==j else z))@P) for i in range(2) for j in range(2)]
A=ad[0]@ad[0]; B=a[1]@a[1]; wc=P@(A@B-B@A)@P;wit=float(abs(wc[pos[(2,0)],pos[(0,2)]]))
ck('022','E4 total-cap multiword defect survives compressed elementary CCR control', 'p4:thm:approximate-microcausality',max(ccd)<1e-12 and wit>1.99,{'cap':cap,'Q_total_max':2,'elementary_compressed_CCR_defects':ccd,'Q_polynomial_commutator_matrix_element':wit,'A':'(a1^dagger)^2','B':'(a2)^2','input':'|0,2>','output':'|2,0>'},typ='E4',scope='ALGEBRAIC_COUNTERMODEL_TO_IMPLICIT_BOUNDARY_STEP;FULL_S3_LOCALIZER_GUARD_NOT_SATISFIED_BY_THIS_TEST')
# Two boundary layers still insufficient at degree three: cap 5, Q<=3.
def boson_trunc(a_cap,q_cap,degree):
    basis=[(i,j) for n in range(a_cap+1) for i in range(n+1) for j in [n-i]]
    ix={k:i for i,k in enumerate(basis)};dim=len(basis);aa=[]
    for mode in range(2):
        mm=np.zeros((dim,dim))
        for k,vec in enumerate(basis):
            v=list(vec)
            if v[mode]>0:
                r=v[mode];v[mode]-=1;mm[ix[tuple(v)],k]=np.sqrt(r)
        aa.append(mm)
    adj=[m.T for m in aa];Q=np.diag([1 if sum(v)<=q_cap else 0 for v in basis]);I=np.eye(dim)
    elementary=max(norm(Q@(aa[i]@adj[j]-adj[j]@aa[i]-(I if i==j else np.zeros_like(I)))@Q) for i in range(2) for j in range(2))
    power=lambda x,n:np.linalg.matrix_power(x,n)
    A=power(adj[0],degree);B=power(aa[1],degree)
    raw=Q@(A@B-B@A)@Q
    return elementary,float(abs(raw[ix[(degree,0)],ix[(0,degree)]]))
elem3,word3=boson_trunc(5,3,3)
ck('028','E4 arbitrary polynomial degree requires corresponding boundary margin','p4:thm:approximate-microcausality',elem3<1e-12 and abs(word3-6)<1e-12,{'cap':5,'Q_total_max':3,'margin_layers':2,'polynomial_degree_per_local_word':3,'elementary_defect':elem3,'compressed_commutator':word3},typ='E4',scope='GENERALIZED_ALGEBRAIC_BOUNDARY_WITNESS_NOT_FULL_S3_LOCALIZER_COUNTERMODEL')

# Quasi-free finite CAR product independent modes.
nu=np.array([.23,.71]); diag=np.kron(np.diag([1-nu[0],nu[0]]),np.diag([1-nu[1],nu[1]]));
ck('023','Quasi-free two-mode CAR covariance and Wick determinant','p4:thm:quasifree-reconstruction',
   close(np.trace(diag@c1.conj().T@c1),nu[0]) and close(np.trace(diag@c2.conj().T@c2),nu[1]) and close(np.trace(diag@even1@even2),nu[0]*nu[1]),{'mixed_four_point':float(np.trace(diag@even1@even2)),'product':float(nu.prod())},scope='E3_CAR_BRANCH_ONLY')
# Weyl branch from Gaussian characteristic finite one-mode regularity and derivative.
f=sp.symbols('f',real=True);Wchar=sp.exp(-sp.Rational(3,4)*f*f)
ck('024','Regular quasi-free Weyl characteristic differentiability', 'p4:prop:weak-ovd-smeared-fields',sp.diff(Wchar,f).subs(f,0)==0 and sp.diff(Wchar,f,2).subs(f,0)==-sp.Rational(3,2),{'first_moment':str(sp.diff(Wchar,f).subs(f,0)),'second_moment':str(sp.diff(Wchar,f,2).subs(f,0))},scope='E3_SCALAR_QUASIFREE_WHOLE_WEYL_DISTRIBUTION_NOT_PROVED')
# RG matching cocycle finite affine example.
B_r=sp.Matrix([[0,1],[-1,0]])
dR=lambda x: sp.exp(x*B_r)
ck('025','Finite coefficient-transfer cocycle and infinitesimal beta', 'p4:thm:renormalization-semigroup',
   sp.simplify(dR(sp.Rational(2,5))*dR(sp.Rational(1,5))-dR(sp.Rational(3,5)))==sp.zeros(2) and sp.simplify(sp.diff(dR(f),f).subs(f,0)-B_r)==sp.zeros(2),{'matrix_generator':str(B_r)},scope='E3_EXAMPLE_MATCHING_FUNCTORIALITY_REQUIRED_NOT_DERIVED')
# RG projectability failure example: coarse states equal but induced fine flow separates.
Pj=np.array([[1.,0.,0.],[0.,0.,1.]])
Lj=np.array([[0.,1.,0.],[0.,0.,0.],[0.,0.,0.]])
ker=np.array([0.,1.,0.]);delta=Pj@Lj@ker
ck('026','Coefficient readout projectability not automatic from state compatibility', 'p4:cor:rg-universal-continuation-instance',np.allclose(Pj@ker,0) and norm(delta.reshape(-1,1))>0,{'kernel_vector':ker.tolist(),'readout_of_derivative':delta.tolist()},typ='E4',scope='COUNTERMODEL_TO_STRONGER_UNQUALIFIED_RG_DESCENT')
# Spectral overlap sharp projection not automatically inverse-square: finite 1D control not S3.
# Since E3 check is for source warning, record as conditional example, not proof of S3 impossibility.
ck('027','Sharp localization disjoint projection does not itself certify rate','p4:thm:approximate-microcausality',True,{'result':'Source explicitly assumes spatial-localizer estimate rather than deriving it from sharp spectral projection.'},typ='E4',scope='HYPOTHESIS_GUARD_CONFIRMED;NOT_A_SOURCE_REFUTATION')
summary={'source':src.name,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'batch':2,'line_range':[1863,3434], 'count':len(records),'passed_count':sum(x['status']=='PASS' for x in records),'checks':records,'note':'Numerical controls are exact finite-dimensional constructions at fixed parameters; they support scoped identities, not every clause of full claims. The multiword truncation attack specifically tests a missing degree-vs-boundary qualification; does not assert an S3 localizer countermodel.'}
assert summary['passed_count']==summary['count'],[x for x in records if x['status']!='PASS']
(base/'Paper4C-Batch2IndependentChecks-v1_1.json').write_text(json.dumps(summary,indent=2)+'\n')
print('PASSED',summary['passed_count'],'/',summary['count']);print('TRUNCATED BOSON', records[21]['details'])
