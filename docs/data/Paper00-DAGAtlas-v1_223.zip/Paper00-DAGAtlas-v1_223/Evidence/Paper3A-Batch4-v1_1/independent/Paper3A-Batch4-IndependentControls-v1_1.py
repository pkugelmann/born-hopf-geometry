#!/usr/bin/env python3
"""Exact independent controls of existing Paper III-A Batch4 statements.
No source script or expected-status ledger is imported. Symbolic identities are
computed from displayed inputs; the native-word span uses a new finite field.
"""
import json
from pathlib import Path
import sympy as s
import numpy as np

OUT=Path(__file__).with_suffix('.json')
results={}
def rec(k,**data): results[k]=data

# Coordinate tuple constructed from wedge incidence and a Clifford realization.
p=193
roots={n:next(a for a in range(p) if a*a%p==n%p) for n in (2,3,-1)}
rt2,rt3,ii=roots[2],roots[3],roots[-1]
def inv(n): return pow(int(n)%p,-1,p)
I2=np.eye(2,dtype=np.int64); Z=np.array([[1,0],[0,-1]],dtype=np.int64)%p
X=np.array([[0,1],[1,0]],dtype=np.int64); Y=np.array([[0,-ii],[ii,0]],dtype=np.int64)%p
gam=[np.kron(X,I2),np.kron(Y,I2),np.kron(Z,X),np.kron(Z,Y)]
gamma_relations=all(np.array_equal((a@b+b@a)%p,(2*np.eye(4,dtype=np.int64) if j==k else np.zeros((4,4),dtype=np.int64))%p) for j,a in enumerate(gam) for k,b in enumerate(gam))
pairs=[(a,b) for a in range(4) for b in range(a+1,4)]
coords=[]
for a in range(4):
 q=np.zeros((15,15),dtype=np.int64)
 q[0,1+a]=q[1+a,0]=inv(2)
 for b in range(4):
  if b==a:continue
  pair=(min(a,b),max(a,b)); j=pairs.index(pair)
  q[5+j,1+b]=q[1+b,5+j]=(1 if a<b else -1)*rt2*inv(3)%p
 q[11:15,11:15]=rt3*inv(4)*gam[a]%p
 coords.append(q)
qsum=sum((q@q for q in coords))%p
fingerprint=np.diag([1]+[11*inv(12)%p]*4+[4*inv(9)%p]*6+[3*inv(4)%p]*4)%p
basis=[]; pivots=[]
def add(v):
 v=v.copy().reshape(-1)%p
 for j,b in zip(pivots,basis):
  if v[j]:v=(v-v[j]*b)%p
 ix=np.flatnonzero(v)
 if len(ix)==0:return False
 j=int(ix[0]); v=v*inv(v[j])%p
 at=next((k for k,x in enumerate(pivots) if x>j),len(pivots))
 pivots.insert(at,j);basis.insert(at,v)
 return True
add(np.eye(15,dtype=np.int64))
ranks=[len(basis)]
for d in range(1,7):
 old=[v.reshape(15,15).copy() for v in basis]
 for b in old:
  for y in coords:add(b@y%p)
 ranks.append(len(basis))
rec('native_word_span',field_prime=p,roots_mod_p={str(k):v for k,v in roots.items()},clifford_relations=gamma_relations,fingerprint_identity=bool(np.array_equal(qsum,fingerprint)),ranks_by_maximum_degree=ranks,block_upper_bound=11**2+4**2,char_zero_inference='Nonzero modular 137-minor lifts to Q(sqrt2,sqrt3,i) since the displayed denominators are invertible. Block diagonality gives the matching upper bound.')

# General symbolic 2x2 noncommuting shared-interior control.
C1=s.Matrix([[2,1],[1,2]]);C2=s.Matrix([[3,1],[1,4]])
B1=s.Matrix([[1,2],[3,1]]);B2=s.Matrix([[2,-1],[1,2]])
A1=s.Matrix([[8,1],[1,7]]);A2=s.Matrix([[6,2],[2,9]])
L1=C1.inv()*B1.T;L2=C2.inv()*B2.T
Lbar=(C1+C2).inv()*(B1+B2).T
K1=A1-B1*C1.inv()*B1.T;K2=A2-B2*C2.inv()*B2.T
Ksum=A1+A2-(B1+B2)*(C1+C2).inv()*(B1+B2).T
variance=(L1-Lbar).T*C1*(L1-Lbar)+(L2-Lbar).T*C2*(L2-Lbar)
rec('shared_schur',noncommuting_commutator=str(C1*C2-C2*C1),C1_leading_minors=[str(C1[0,0]),str(C1.det())],C2_leading_minors=[str(C2[0,0]),str(C2.det())],direct_schur=str(Ksum),variance=str(variance),computed_difference=str(s.simplify(Ksum-K1-K2-variance)))
R,C,c,a,u,z=s.symbols('R C c a u z',real=True)
Splus=c*(R-C)*(z-a*u)**2/2;Sminus=c*(R-C)*(z+a*u)**2/2
rec('closing_gap',separate_stationary_values=[str(Splus.subs(z,a*u)),str(Sminus.subs(z,-a*u))],shared_stationary_value=str(s.expand((Splus+Sminus).subs(z,0))),shared_retained_hessian=str(s.diff((Splus+Sminus).subs(z,0),u,2)))

# Change-of-variable clock derivative and explicit native-shaped control.
t=s.symbols('t',real=True);K=56*(1-s.exp(-t));N=t
rec('clock_affinity',computed_residual=str(s.simplify(s.diff(K,t,2)*s.diff(N,t)-s.diff(K,t)*s.diff(N,t,2))))
ka,kb,kc,bnext=s.symbols('K_a K_b K_c bnext')
rec('successor_residual',ratio_cocycle_difference=str(s.factor((bnext-kc)/(bnext-ka)-(bnext-kc)/(bnext-kb)*(bnext-kb)/(bnext-ka))))

# Complete-Hessian radial reconstruction, with mixed source incidence.
x,y,t=s.symbols('x y t');q=s.Matrix([x,y]);S=7+2*x-3*y+x**4+2*x*x*y+3*x*y*y+y**6
H=s.hessian(S,(x,y));Ht=H.subs({x:t*x,y:t*y},simultaneous=True)
radial=7+2*x-3*y+s.integrate((1-t)*(q.T*Ht*q)[0],(t,0,1))
rec('radial_reconstruction',potential=str(S),hessian=str(H),computed_reconstruction_difference=str(s.expand(radial-S)),mixed_third_derivative_residuals=[str(s.diff(H[i,j],(x,y)[k])-s.diff(H[k,j],(x,y)[i])) for i in range(2) for j in range(2) for k in range(2)])
m=4;r=3;pert=x**m*y**m
axis_jets=[]
for i in range(r+1):
 for j in range(r+1-i):
  d=s.diff(pert,x,i,y,j)
  axis_jets.extend([s.simplify(d.subs(x,0)),s.simplify(d.subs(y,0))])
rec('sector_jet_kernel',r=r,m=m,computed_all_axis_jets_zero=all(v==0 for v in axis_jets),off_axis_value=str(pert.subs({x:1,y:1})))

# Source translation and source-congruence controls.
k,ell=s.symbols('k ell',positive=True);yy=s.symbols('yy',nonnegative=True)
psi=(s.exp(-ell*yy)-s.exp(-k*yy))/(k*k-ell*ell)
rec('collar_green',computed_green_equation=str(s.simplify(-s.diff(psi,yy,2)+k*k*psi-s.exp(-ell*yy))),boundary_value=str(s.simplify(psi.subs(yy,0))),computed_source_pairing=str(s.simplify((1/(2*ell)-1/(ell+k))/(k*k-ell*ell))),source_pairing_target=str(1/(2*ell*(ell+k)**2)),computed_source_pairing_difference=str(s.factor((1/(2*ell)-1/(ell+k))/(k*k-ell*ell)-1/(2*ell*(ell+k)**2))))
T=s.Matrix([[3,1],[1,2]]);A=s.Matrix([[2,1],[1,1]]);j=s.Matrix([2,-1]);v=s.Matrix([x,y]);Ts=A.T*T*A;jr=A.T.inv()*j
rec('source_congruence',off_shell_word_difference=str(s.expand(((A*v).T*T*(A*v)+2*jr.T*A*v-v.T*Ts*v-2*j.T*v)[0])),stationary_value_difference=str(s.simplify((jr.T*T.inv()*jr-j.T*Ts.inv()*j)[0])),volume_determinant_identity=str(s.factor(T.det()*A.det()**2-Ts.det())))

# Sharp finite-response lower-sample control, independently expanded.
w=s.symbols('w')
M1=w+s.Rational(13,7)/(-3-w)+s.Rational(4,3)/(2-w)
M2=w-1+s.Rational(1,3)/(-1-w)+s.Rational(34,7)/(4-w)
diff=s.factor(M1-M2)
rec('response_sampling',computed_difference=str(diff),computed_two_upper_halfplane_zeros=[str(s.simplify(diff.subs(w,z))) for z in (s.I,2*s.I)],computed_third_upper_halfplane_value=str(s.simplify(diff.subs(w,3*s.I))))

OUT.write_text(json.dumps({'method':'exact symbolic arithmetic; independently constructed modular native matrices','results':results},indent=2)+'\n')
print(json.dumps({'written':str(OUT),'native_word_span':results['native_word_span'],'control_count':len(results)},indent=2))
