#!/usr/bin/env python3
"""Exact E4 controls. Not finite-sample proofs or physical occurrence certificates."""
import json, pathlib
import sympy as s
out=[]
def check(name,condition,detail):
    if not bool(condition): raise AssertionError(name)
    out.append({'id':name,'passed':True,'detail':detail,'role':'exact finite support/control, not general proof or physical witness'})
t,u,v,w=s.symbols('t u v w',real=True)
J=s.Matrix([[0,1],[0,0]])
check('finite_jordan_semigroup',s.eye(2)+(u+v)*J==(s.eye(2)+u*J)*(s.eye(2)+v*J),'Nilpotent nonnormal generator has exact exponential I+tJ and composition.')
pi=s.Matrix([[1,0]])
L=s.Matrix([[2,0],[3,4]])
a=s.symbols('a')
right=s.Matrix([1,a])
check('right_inverse_independence',(pi*L*right)[0]==2,'Any right inverse (1,a) gives the same generator 2 when ker pi is invariant.')
check('kernel_failure',(pi*J*s.Matrix([0,1]))[0]==1,'Projection of two same-fibre points differs under I+tJ for t nonzero.')
x=s.symbols('x',real=True)
K=56*(1-s.exp(-x))
check('native_clock_affinity',s.diff(K,x,2)==-56*s.exp(-x),'N=x has nonzero common-clock affinity residual.')
q=lambda z: int(s.floor(z))
check('threshold_clock_collision',q(s.Rational(3,5))==q(s.Rational(4,5)) and q(s.Rational(3,5)+s.Rational(3,10))!=q(s.Rational(4,5)+s.Rational(3,10)),'Same frozen integer cell at 0.6 and 0.8, unequal cells after common 0.3 shift.')
rA,rB,rC=s.symbols('rA rB rC',positive=True)
check('residual_cocycle',s.cancel(rC/rA-(rC/rB)*(rB/rA))==0,'Positive residual ratios cancel exactly; no rate is introduced.')
check('width8_denominator',s.Rational(16-12,16-8)==s.Rational(1,2) and s.Rational(16-8,16)!=1,'Actual width8 normalizes left endpoint to1; successor-value/trace substitution does not.')
A=s.Matrix([[0,1],[1,0]]); z=s.Matrix([1,0])
check('compression_word_defect',(z.T*A*A*z)[0]==1 and (z.T*A*z)[0]**2==0,'Nonreducing isometry compression fails multiplication; unitary premise is essential.')
f=x*x
check('nonlinear_hessian_contact',s.diff(f,x,2).subs(x,0)==2,'S(X)=X, f=x^2: pure Hessian pullback is0, full contact gives2.')
C1=s.Matrix([[2,1],[1,3]]); C2=s.Matrix([[3,0],[0,1]])
L1=s.Matrix([[1,2],[0,1]]); L2=s.Matrix([[0,1],[2,0]])
Cs=C1+C2; Bs=L1.T*C1+L2.T*C2; Lbar=Cs.inv()*(C1*L1+C2*L2)
A1=s.eye(2)+L1.T*C1*L1; A2=2*s.eye(2)+L2.T*C2*L2
Ksum=A1+A2-Bs*Cs.inv()*Bs.T
variance=(L1-Lbar).T*C1*(L1-Lbar)+(L2-Lbar).T*C2*(L2-Lbar)
check('noncommuting_shared_schur',C1*C2!=C2*C1 and Ksum-3*s.eye(2)==variance and variance.det()>0 and variance[0,0]>0,'Noncommuting positive pivots give exact positive variance; separate reductions omit it.')
eps,c,aa=s.symbols('eps c aa',positive=True)
shared=s.expand(c*eps*((v-aa*u)**2+(v+aa*u)**2)/2)
check('closing_gap_boundary',s.diff(shared.subs(v,0),u,2)==2*c*aa**2*eps,'Gap-closing control has linear shared Hessian; endpoint pivots are zero and outside uniform-gap theorem.')
y=s.symbols('y',real=True)
S=x**4+x*x*y+2*x*y*y+y**4
H=s.hessian(S,(x,y))
rad=s.integrate((1-t)*(s.Matrix([x,y]).T*H.subs({x:t*x,y:t*y},simultaneous=True)*s.Matrix([x,y]))[0],(t,0,1))
check('radial_hessian_reconstruction',s.expand(rad-S)==0,'Complete integrable polynomial Hessian reconstructs anchored action exactly.')
check('symmetric_nonintegrable_field',s.diff(y,y)!=s.diff(0,x),'H=diag(y,0) is symmetric but fails partial_y Hxx=partial_x Hyx.')
pert=x**4*y**4
axisok=True
for i in range(3):
 for j in range(3-i):
  der=s.diff(pert,x,i,y,j)
  axisok=axisok and der.subs(x,0)==0 and der.subs(y,0)==0
check('finite_axis_jet_kernel',axisok and pert.subs({x:1,y:1})==1,'r=2,m=4 diagnostic perturbation vanishes to all consumed jets on axes, changes off-axis parent; not a physical lambda.')
check('compatible_fibre_test',len({7,7})==1 and len({7,8})==2,'Same-input fibre supports factorization exactly when readouts agree; finite set is only a mathematical control.')
Z,qv=s.symbols('Z qv',nonzero=True)
At=s.Matrix([[2,1],[1,3]])
check('common_cone_cancellation',(Z*qv*At).det()==Z**2*qv**2*At.det(),'An invertible principal internal factor and nonzero common Z add no characteristic root.')
eta=s.diag(-1,1,1,1)
M=s.Matrix([[1,2,3,4],[5,6,7,8],[9,10,11,12],[13,14,15,16]])
lower=eta*M
sym=(lower+lower.T)/2; anti=(lower-lower.T)/2
lam=s.trace(eta*sym)/4; shear=sym-lam*eta
check('lorentzian_lowered_coframe',eta*M+M.T*eta==2*lam*eta+2*shear and eta*(eta*anti)+(eta*anti).T*eta==s.zeros(4),'Eta-lowered antisymmetric variation cancels; trace/shear formula exact at infinitesimal order.')
ww=s.symbols('ww')
M1=ww+s.Rational(13,7)/(-3-ww)+s.Rational(4,3)/(2-ww)
M2=ww-1+s.Rational(1,3)/(-1-ww)+s.Rational(34,7)/(4-ww)
diff=s.factor(M1-M2)
expected=(ww*ww+1)*(ww*ww+4)/((-3-ww)*(-1-ww)*(2-ww)*(4-ww))
check('finite_response_under_count',s.cancel(diff-expected)==0 and diff.subs(ww,s.I)==0 and diff.subs(ww,2*s.I)==0 and diff.subs(ww,0)!=0,'Exact rational nonidentity agrees at too few upper-half-plane points; stated degree-bound count excludes this false attack.')
print(json.dumps({'all_passed':True,'control_count':len(out),'controls':out},indent=2))
