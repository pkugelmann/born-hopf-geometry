# Paper III-A Batch 4 adversarial audit — v1_1

Actor: `/root/b4_adversarial`. Target: authoritative read-only `Paper3A-GeneratedDynamics-v1_169.tex`, source lines 4137–5305, frozen claims **BH-IIIA-C-0129–BH-IIIA-C-0170**. The wider target source was consulted only to resolve the actual signature, complete-owner and pre-action rules; exact peer imports are listed in the JSON. No paper, graph, other verifier output, PDF or theory was modified or generated. No other Batch 4 verifier outputs were read before or after the provisional attack freeze.

The JSON contains **42/42 distinct claim objects**, **46 E4 attack records**, **13 source-bound BND records**, and **18 passing exact symbolic controls**. These are adversarial dispositions, not standalone VERIFIED promotions. There is **no certified unconditional refutation and no certified physical countermodel** in this return.

## Independent provisional attacks and subsequent adjudication

**P-B4-E4-01 — C0138 joint parameter regularity.** Source 4431–4432 says that a jointly smooth parameterized parent descends jointly smoothly; the proof at 4449–4451 uses `pi_t Phi sigma`. This is correct for fixed smooth source and target quotients. If `pi_t` itself varies with the parameter, the printed hypotheses state only that each `pi_t` is individually a smooth surjective submersion. In ordinary smooth-manifold mathematics take every parent and target to be R, parent arrows to be identity, and `pi_s(x)=x+a(s)` for a step function `a`. Fibres are singleton and every individual map is a smooth diffeomorphism, but descended arrows `y+a(t)-a(s)` are not jointly continuous. This is a valid mathematical countermodel to the unrestricted moving-readout interpretation. It is **not a certified generated physical family**: no actual constructor word for that discontinuous family was found. The coordinator must determine whether the parameterized diagram fixes its quotients or supplies joint readout regularity. BND-0004 and E4-0043 record both branches.

**P-B4-E4-02 — C0129 pre-GP3 identity versus GP3 retention.** The premise at 4139–4143 places identity in the exact family defined at 3373–3385. That definition includes GP1 and joint GP2 but does not itself impose GP3 retention. The imported zero-member corollary (II-A 2184–2191) proves GP2 non-forcing; the proof at III-A 4165–4167 additionally invokes GP3 without displaying an identity-retention or comparison-invariance argument. Actual GP3 comparisons were checked in II-A 3743–3823. **No legal fixed-carrier comparison selecting a nonstationary least class was found.** Surjective intertwining, restriction and isomorphism comparisons preserve identity. An arbitrary preorder preferring motion is an invalid stronger-domain counterexample and was rejected. The result is an unresolved proof-scope obligation, **not an established counterexample to the framework's actual GP3 semantics**. BND-0001 and E4-0044 preserve this distinction.

The independent provisional candidate records above are preserved as audit history. Subsequent coordinator source adjudication **withdraws both as new canonical issues**: C0138 inherits C0137's parameterized quotient/factorization guard (4397–4400), so the unguarded moving family attacks a stronger interpretation; C0129 is the fixed-carrier no-entailment statement, and no licensed comparator against it was found. A stronger theorem that every exact identity universally survives all future GP3 comparisons is excluded. These later dispositions are not presented as the original independent verdicts.

The sole remaining bounded source-interface candidate is **P-B4-E4-03, C0140**: this pass did not recover an independent definition fixing the factor-2 normalization of `rho_16^src` at 4571. This is a missing normalization/interface certificate, not evidence that the formula is false and not a second physicality premise. The coordinator owns canonical numbering.

## Other exact scope limits

- **C0130 graph language, 4196.** Raw graph projection is an isomorphism of sets. II-A 5263–5273 explicitly withholds isomorphism of complete GP3 comparison preorders without conservative admissibility and preservation/reflection of comparisons. The common singleton readout on final survivors remains valid without the stronger certificate. E4-0045 rejects the stronger structured interpretation; this is not a refutation of common generated content.
- **C0139 literal time domain, 4463 and 4505.** An entirely negative compact host interval makes the displayed `t,h>=0` law condition vacuous even with a strict threshold crossing. This diagnostic has no licensed negative-time physical-history certificate and does not challenge the ordinary nonnegative physical-time branch. It was subsequently excluded from the admissible nonnegative physical crossing domain and remains a literal scope warning, not a physical countermodel (E4-0046, BND-0005).
- **C0140 factor 2, 4571.** The operator is algebraically self-adjoint and the tangent/projectability firewalls are explicit. The specialized `rho_16^src` normalization appeared only in its displayed local identity; an independent upstream definition fixing its factor was not located. E4 therefore does not certify that normalization and does not allege it is wrong.
- **C0166 anomalous-dimension convention.** The temporal/spatial running formula has the printed sign under `eta=-partial_log(k) log Z`, explicitly defined in VII-C 5099. The common positive factor cannot change the characteristic cone when the internal principal matrix is invertible. Singular matrices, zero factors, relative temporal/spatial changes, lower-order dispersion and different principal owners are distinct domains.

## Attack coverage and controls

Generator attacks retain norm continuity, finite carrier, complete endpoints/strict inequalities, positive-real rays and actual clock calibration. The one-ray conclusion is not treated as rate uniqueness. Structured quotient attacks distinguish set descent from topology/smoothness/computation, and global disconnected fibres from the local bracket test.

Threshold controls keep the threshold family frozen and the successor residual in one cell. The width denominator is the actual `b_(j+1)-b_j`; replacing it with a successor value or carrier trace fails the left-end normalization. A logarithmic residual coordinate does not introduce a time rate, and set conjugacy does not supply a parent process or product-coordinate smoothness.

Action controls retain every mixed block and the nonlinear chain-rule contact. Exact noncommuting positive pivots satisfy the shared-interior Schur variance identity. Separate reductions and closing-gap examples do not refute the uniformly positive shared-pivot theorem. All such freely chosen quadratic pairs remain host diagnostics, not generated physical action pairs.

Hessian controls retain every consumed direction, all third-index compatibility equations, and affine anchors. The `x^m y^m` example is invisible to each fixed finite consumed order with `m` chosen above that order; it is not one nonzero analytic perturbation invisible to all orders simultaneously. Graded coefficient and global primitive restrictions remain explicit. No candidate action is given an origin by reconstructing its own Hessian.

Compatible-family attacks do not add arbitrary actions from a common host. Proxy compression failure proves information loss in that proxy; native nondetermination needs an actual same-input, different-output pair admitted by the licensed compatible family. No such physical pair was found. The coframe and visible-response controls similarly retain the typed map, actual complete source ports, kinetic/energy frame and finite rational degree bounds. Finite response tests are supported by polynomial root counting, not by experimental finite sampling.

Run the optional exact controls from the workspace root:

```bash
python audit_batch4/proposals/adversarial/Paper3A-Batch4-AdversarialControls-v1_1.py
```

The saved `Paper3A-Batch4-AdversarialControls-v1_1.json` reports 18/18 passing checks. SymPy rational/symbolic identities are positive/negative controls for the general arguments written in the attack records. They are not evidence of physical occurrence and are not sampling proofs of unrestricted function identities.
