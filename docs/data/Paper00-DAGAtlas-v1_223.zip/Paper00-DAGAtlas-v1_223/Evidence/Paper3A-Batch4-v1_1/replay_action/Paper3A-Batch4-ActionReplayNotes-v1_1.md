# Paper III-A Batch 4 — Action and observable replay notes v1_1

E1 source/proof replay covers all 21 assigned census objects C0150–C0170, comprising 15 formal objects and six unnamed/nonformal objects, in the frozen current III-A source at lines 4783–5305. The JSON proposal contains one record per object with steps, exact consumed imports, conditions, scope and proposed replay disposition. It does not edit the canonical graph or promote E1 to independent verification.

No established mathematical defect or refutation is proposed. One minor local notation candidate is submitted for coordinator review at C0166. The source's explicit native-action/source identification conditions are preserved as conditions, not recast as mathematical gaps.

## Results that replay cleanly

- **C0150–151:** Completing the square gives the weighted, generally noncommuting Schur variance. A shared variable is solved once; independently supplied interiors give a different reduction. Total terminal zero Hessian uses positive semidefinite terminal summands. The derivative conclusion needs the printed uniform positive gap. For the gap-closing example, with `h=c(R−C)>0`, the shared reduction has Hessian `2ha²`, while the separate reductions vanish. This does not contradict the uniformly gapped theorem.
- **C0152–156:** Hessian equality throughout a connected common chart plus one value and one first-differential anchor gives action equality. The constructive radial primitive has exactly the factor `(1−t)`; its two affine anchors eliminate the full ambiguity. The C1 Hessian yields a C3 action after the two integrations. For the mixed-sector example, fix each finite jet order `r` before choosing even `m>r`. It is not a nonzero analytic perturbation invisible to all orders at once. Graded coefficients and global periods retain their separate input obligations.
- **C0157:** The five-level paragraph is a scope inventory, not a new proof that all named providers occur as physical action slots. Its uncited remote providers are not recursively re-audited in this work package; the finite identities actually consumed here retain their exact domains.
- **C0158–161:** Positive source congruence preserves the complete off-shell quadratic-plus-linear word, jets and specified finite induced measure. The normal reference translation keeps its reference energy, forced source and absolute constant. The collar map is a full form identity with a positive complement. Replacing its geometric coefficient by an independently varied off-shell flux would change the Euler equation. Alternative boundary/Schur presentations count one action contribution once. The retained primitive trace comparison preserves its graded companion and does not adopt that readout as the ordinary native action.
- **C0162–165:** The data map is surjective onto its declared image. Set fibre constancy gives a unique set factorization; physical common-value closure requires the already licensed complete nonempty compatible fibre. It neither picks an action member nor creates a category, computability certificate, target schema or occurrence. A failed compressed proxy alone does not demonstrate native nondetermination. The completion certificate records the actual target and consumed data rather than imposing a conventional physical mechanism.
- **C0166–169:** Positive common principal normalization leaves the characteristic set unchanged. Local Lorentzian coframe variation gives `δg=2λg+2S`, with the η-lowered antisymmetric part cancelling. The SO(3) restriction is `9=5+3+1`; this is kinematic representation content, not a propagated-polarization count.
- **C0170:** Clearing the two finite Hermitian response denominators leaves degree at most `N=m1+m2`; conjugate matrix zeros give the stated upper-half-plane sample count. The differentiated count follows from at most `k+1` resolvents. Minimal visible realizations are fixed polewise up to environmental unitaries; only their reducing uncoupled dark complement is invisible to the retained response. Actual density/support, complete source ports and common energy/kinetic frame remain required. Neutral central offsets cancel in commutators but persist in cross-block frequencies and absolute heat/action/global weights.

## Candidate requiring coordinator review

**C0166-ETA-NOTATION — minor TYPE_OR_DOMAIN / local notation definition.** III-A 5215–5219 introduces `η_t,η_s` without defining them locally or explicitly citing their convention. With the scalar convention `η_a=−∂log(k) log Z_a`, printed explicitly in III-F 5834, and positive differentiable temporal/spatial factors on a fixed quadratic owner,

\[
 c_Q^2=c_{\rm op}^2 Z_s/Z_t,
 \qquad
 \partial_{\log k}\log c_Q=(\eta_t-\eta_s)/2.
\]

The sign is correct under that convention. No algebraic contradiction, defect in the common-Z cone clause, or unlicensed-closure allegation is proposed. This is at most a local definition/import ambiguity in the more-general clause; the coordinator can decide whether the existing shared convention already discharges it. Its candidate certificate is in the JSON and is not assigned a canonical gap ID here.

## Bounded imported proof coverage

| Consumed source | Exact portion checked | Use |
|---|---:|---|
| III-B finite Born heat Hessian | 3708–3739 | Noncommuting heat two-jet/contact and fixed-window scope |
| III-D complete action jets | 2673–2733 | Common physical pairing, complete pullback and endpoint residual |
| I-B positive source transport | 19280–19320 | Off-shell source word, jets, finite volume/Jacobian |
| I-B positive extension and flux | 19229–19264 | Decaying extension and conjugate-flux coefficient |
| III-E cap source and volume | 4576–4665 | Complete source baseline, multiplicity and specified induced measure |
| III-E exact cap and incidence | 4667–4759 | Conditional full cap, endpoint and shared-variable incidence |
| III-F first-order cap parent | 7739–7788 | Algebraic elimination and canonical smooth non-null endpoint |
| I-B reference-Poisson defect | 19353–19398 | Complete reference/source translation and sign |
| III-F reference cap/form transport | 12602–12732 | Full energy/source/complement, fixed geometric coefficient |
| I-B primitive owner retraction | 17857–17883 | Unital invariant normalized trace |
| I-B retained primitive comparison | 19455–19486 | Trace ratio and retained graded companion |
| II-A compatible-family closure | 4038–4093 | Common image only on nonempty complete licensed surviving family |
| III-F scalar kinetic convention | 5820–5842 | Corroborates η convention only; not an explicit III-A proof citation |
| III-B Cartan split | 1587–1640 | Relative rank-four solder domain |
| I-C local coframe proposition | 19664–19700 | Exact local variation and SO(3) decomposition |
| I-B complete finite Weyl/visible realization | 18951–19055 | Response, visible poles/residues, Gram/unitary minimality and dark complement |
| I-B finite response/source jets | 22115–22227 | Exact finite sampled comparison and fixed-source jet count |
| I-B central even/odd boundary | 22376–22431 | Fixed-state neutral quotient versus odd/absolute data |

The stable `p1b:prop:local-coframe` label is currently in **Paper1C-TechnicalMaterial-v1_58.tex**. This is a current-source locator, not a source conflict. All import labels in the proposal resolve in the authoritative corpus. No whole peer paper is declared audited.

## Boundary and inheritance notes

Five source-anchored boundary records accompany the JSON: common physical action incidence; affine reconstruction versus origin; conditional cap/source transport; native compatible-fibre/readout grammar; principal/coframe/metrology typing. They separate existence, uniqueness, canonicality, physical realization and interpretation before any licensing allegation. None proposes a new physical constructor.

Existing condition **BH-IIIA-A-0041** (claim-complete action owner) is reused rather than recreated. Existing **BH-IIIA-A-0001** and **A-0003** carry physical spatial/time calibration into C0167. Other local guards in the evidence are condition-use proposals for the single assumption registrar to reconcile, not new canonical assumption declarations.

Existing **G0005 / A0063** concerns exact vector `τ` normalization in the earlier relative-solder comparison. C0168–169 use the stipulated local coframe/rank and its algebraic SO(3) decomposition. No actual source-use path demanding the disputed exact coefficient equality has been established here; automatic propagation of G0005 to these rank/variation statements would be unsupported.

The JSON and these notes are the only delivered proposal artifacts. Source hash is checked against the frozen statements, evidence IDs are unique and consecutive, all 21 assigned claim IDs are present, and required fields are populated. No supplied source, canonical graph, other agent file, theory repair or PDF was altered.
