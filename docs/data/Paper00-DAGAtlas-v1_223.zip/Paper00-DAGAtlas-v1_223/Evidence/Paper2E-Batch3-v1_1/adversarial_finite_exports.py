"""Independent exact finite E4 controls for II-E finishing batch.
All objects are rebuilt from permutation/cube/Clifford definitions;
no prior proposal, verdict or expected certificate is imported.
"""
from itertools import permutations,combinations,product
from collections import Counter
import json
import sympy as s
Q=s.Rational
N=5
ident=tuple(range(N))
def parity(p):return -1 if sum(p[i]>p[j] for i in range(len(p)) for j in range(i+1,len(p)))%2 else 1
def mul(p,q):return tuple(p[q[j]] for j in range(N))
def inv(p):return tuple(p.index(j) for j in range(N))
def order(p):
 r=ident
 for k in range(1,61):
  r=mul(r,p)
  if r==ident:return k
 raise ValueError
G=sorted(p for p in permutations(range(N)) if parity(p)==1);gix={p:i for i,p in enumerate(G)}
assert len(G)==60
ords={p:order(p) for p in G};assert Counter(ords.values())=={1:1,2:15,3:20,5:24}
pairs=list(combinations(range(N),2));pairsset=[frozenset(v) for v in pairs]
Ap=s.Matrix(10,10,lambda i,j:int(pairsset[i].isdisjoint(pairsset[j])))
edges=[(i,j) for i,j in combinations(range(10),2) if Ap[i,j]]
assert len(edges)==15
# Exact Petersen matching/edge-color obstruction and positive 4-color witness.
matchings=[]
for comb in combinations(edges,5):
 if len({i for e in comb for i in e})==10:matchings.append(comb)
assert len(matchings)==6
cycle_types=[]
for mm in matchings:
 rem=[e for e in edges if e not in mm];adj={i:[] for i in range(10)}
 for i,j in rem:adj[i].append(j);adj[j].append(i)
 unseen=set(range(10));lens=[]
 while unseen:
  todo=[unseen.pop()];comp=set(todo)
  while todo:
   u=todo.pop()
   for v in adj[u]:
    if v in unseen:unseen.remove(v);comp.add(v);todo.append(v)
  lens.append(len(comp))
 assert sorted(lens)==[5,5];cycle_types.append(lens)
colors={}
def color(k):
 if k==len(edges):return True
 e=edges[k];blocked={colors[f] for f in colors if set(e)&set(f)}
 for c in range(4):
  if c not in blocked:
   colors[e]=c
   if color(k+1):return True
   del colors[e]
 return False
assert color(0)
# Every two-subset stabilizer has faithful S3 action on its three neighbors.
for ix,A in enumerate(pairsset):
 stab=[g for g in G if frozenset(g[i] for i in A)==A]
 neigh=[j for j in range(10) if Ap[ix,j]]
 actions={tuple(neigh.index(pairsset.index(frozenset(g[k] for k in pairs[j]))) for j in neigh) for g in stab}
 assert len(stab)==len(actions)==6
# Cyclic coset incidence on projective sixty-point group.
subgroups={}
cosets={}
for k in [2,3,5]:
 hs=set()
 for g in G:
  if ords[g]!=k:continue
  h={ident};r=ident
  for j in range(1,k):r=mul(r,g);h.add(r)
  hs.add(frozenset(h))
 subgroups[k]=hs
 cosets[k]=sorted({frozenset(mul(g,h) for h in H) for g in G for H in hs},key=lambda x:sorted(x))
assert [len(cosets[k]) for k in [2,3,5]]==[450,200,72]
Ms={}
for k in [2,3,5]:
 Ms[k]=s.zeros(60)
 for c in cosets[k]:
  inds=[gix[g] for g in c]
  for i,j in product(inds,repeat=2):Ms[k][i,j]+=1
assert Ms[2]+Ms[3]+Ms[5]==30*s.eye(60)+s.ones(60)
P5=(Ms[2]-Ms[3])/12;P4=(Ms[3]-Ms[5])/15
assert P5*P5==P5 and P4*P4==P4 and P5*P4==s.zeros(60)
assert s.trace(P5)==25 and s.trace(P4)==16
U=[g for g in G if ords[g] in [1,2,3]];assert len(U)==36
Hcores=[{g for g in G if g[i]==i} for i in range(5)]
coreplanes=[c for c in cosets[3] if any(c<=H for H in Hcores)]
allplanes=[c for c in cosets[3] if c<=set(U)]
assert len(coreplanes)==70 and len(allplanes)==80
R70=s.Matrix(36,70,lambda i,j:int(U[i] in coreplanes[j]));R80=s.Matrix(36,80,lambda i,j:int(U[i] in allplanes[j]))
assert R70.rank()==35 and R80.rank()==36
zz=s.Matrix([-2 if ords[g] in [1,2] else 1 for g in U])
assert zz.T*R70==s.zeros(1,70) and zz.T*R80!=s.zeros(1,80)
# Binary transporter Gram, Hodge signing, two distinct covers, Pi15.
B60=s.Matrix(60,25,lambda n,c:int(G[n][c%5]==c//5));B=s.Matrix.vstack(B60,B60)
R=s.kronecker_product(s.ones(5)-s.eye(5),s.ones(5)-s.eye(5))
assert B.T*B==24*s.eye(25)+6*R
V=s.Matrix.hstack(*[B[:,i*5+j]+B[:,j*5+i] for i,j in pairs])
W=s.Matrix.hstack(*[B[:,i*5+j]-B[:,j*5+i] for i,j in pairs])
SH=s.zeros(10)
for i,a in enumerate(pairs):
 for j,b in enumerate(pairs):
  if set(a)&set(b):continue
  k=next(iter(set(range(5))-set(a)-set(b)))
  SH[i,j]=parity((k,*b,*a))
assert abs(SH)==Ap and SH**3==5*SH
assert W.T*W==12*SH**2 and V.T*W==s.zeros(10)
assert [B.rank(),V.rank(),W.rank()]==[17,10,6]
T=SH**2-3*s.eye(10)
assert T==(-SH)**2-3*s.eye(10) and T*T+T==6*s.eye(10)
def lift(S):return ((Ap+S).row_join(Ap-S)).col_join((Ap-S).row_join(Ap+S))/2
LD=lift(SH);LP=lift(-Ap)
x=s.symbols('x')
assert LD!=LP and LP==s.zeros(10).row_join(Ap).col_join(Ap.row_join(s.zeros(10)))
assert s.expand(LP.charpoly(x).as_expr()-(x-3)*(x-2)**4*(x-1)**5*(x+1)**5*(x+2)**4*(x+3))==0
assert s.expand(LD.charpoly(x).as_expr()-(x-3)*(x-1)**5*(x+2)**4*(x*x-5)**3*x**4)==0
chi=[sum(g[i]==i for i in range(5))-1 for g in G]
Char=s.Matrix(60,60,lambda i,j:sum(mul(inv(G[i]),G[j])[k]==k for k in range(5))-1)
cv=s.Matrix(chi);Pi60=(4*Char-cv*cv.T)/60
assert Pi60*Pi60==Pi60 and s.trace(Pi60)==15
lev={k:sorted(set(Pi60[i,i]/2 for i,g in enumerate(G) if ords[g]==k)) for k in [1,2,3,5]}
assert lev=={1:[0],2:[Q(2,15)],3:[Q(1,8)],5:[Q(1,8)]}
assert 2*sum(Pi60[i,i]/2 for i in range(60))==15
# Rational 5x5 standard representation and edge-to-sl4 isometry.
Q5=s.eye(5)-s.ones(5)/5
def permM(g):return s.Matrix(5,5,lambda i,j:int(g[j]==i))
def Zg(g):return Q5*permM(g)*Q5-Q(sum(g[i]==i for i in range(5))-1,4)*Q5
vec=lambda M:s.Matrix(list(M))
hs=lambda M,N:s.trace(M.T*N)
Es=[];Ks=[]
for i,j in edges:
 a,b=pairs[i],pairs[j]
 da=s.Matrix([int(k==a[0])-int(k==a[1]) for k in range(5)])
 db=s.Matrix([int(k==b[0])-int(k==b[1]) for k in range(5)])
 va=s.Matrix([int(k in a)-Q(2,5) for k in range(5)])
 vb=s.Matrix([int(k in b)-Q(2,5) for k in range(5)])
 Es.append(da*da.T-db*db.T);Ks.append(va*vb.T-vb*va.T)
SE=s.Matrix.hstack(*map(vec,Es));KE=s.Matrix.hstack(*map(vec,Ks))
assert SE.T*KE==s.zeros(15)
Nedge=(SE+KE).T*(SE+KE);PE4=(Nedge-4*s.eye(15))/21
assert PE4*PE4==PE4 and s.trace(PE4)==4
UU=(SE+KE)*(PE4/5+(s.eye(15)-PE4)/2)
assert UU.T*UU==s.eye(15)
# Ten 3-cycle overlaps, triangle/Petersen signed isometry.
SAs=[];KAs=[]
for a in pairs:
 triple=sorted(set(range(5))-set(a));g=list(ident)
 for i in range(3):g[triple[i]]=triple[(i+1)%3]
 g=tuple(g);z=Zg(g);zi=Zg(inv(g))
 SAs.append((z+zi)/2);KAs.append((z-zi)/2)
SM=s.Matrix.hstack(*map(vec,SAs));KM=s.Matrix.hstack(*map(vec,KAs))
GS=SM.T*SM;GK=KM.T*KM
assert GS==2*s.eye(10)-Q(3,2)*Ap+s.ones(10)/4
assert GS.rank()==9 and GK.rank()==6
assert GK*GK==Q(5,2)*GK
J=KM.T*KE
assert set(J)<=set([-1,0,1]) and J.rank()==6
assert all(sum(J[i,j]!=0 for j in range(15))==6 for i in range(10))
assert all(sum(J[i,j]!=0 for i in range(10))==4 for j in range(15))
assert (J*J.T)**2==10*(J*J.T) and (J.T*J)**2==10*(J.T*J)
# Exact conjugacy classes and class-frame matrices in ambient matrix coordinates.
classes=[];unseen=set(G)
while unseen:
 g=min(unseen);cc={mul(mul(h,g),inv(h)) for h in G};classes.append(cc);unseen-=cc
classes.sort(key=lambda c:(ords[next(iter(c))],min(c)))
frame_checks={};frames=[]
for cc in classes:
 F=s.zeros(25)
 for g in cc:
  z=vec(Zg(g));F+=z*z.T/15
 frames.append(F)
 k=ords[next(iter(cc))]
 if k==1:assert F==s.zeros(25);continue
 pol=s.expand(F.charpoly(x).as_expr())
 if k==2:expected=x**16*(x-Q(1,3))**4*(x-Q(8,15))**5
 elif k==3:expected=x**10*(x-Q(2,3))**4*(x-Q(1,15))**5*(x-Q(1,3))**6
 else:expected=x**14*(x-Q(1,5))**5*(x*x-Q(2,3)*x+Q(1,45))**3
 assert s.expand(pol-expected)==0
 frame_checks[f'order{k}_size{len(cc)}_'+str(len(frame_checks))]={'rank':F.rank(),'trace':str(s.trace(F))}
FF=sum(frames,s.zeros(25));assert FF*FF==FF and s.trace(FF)==15
phi=(1+s.sqrt(5))/2;aa=(5+2*s.sqrt(5))/15;bb=(5-2*s.sqrt(5))/15
assert s.simplify(aa/bb-phi**6)==0
# Positive controls for mathematical path closure, without any physical group claim.
def lie_dim(seed):
 basis=[];columns=s.zeros(25,0)
 def add(M):
  nonlocal columns
  v=vec(M)
  if columns.row_join(v).rank()>columns.cols:
   basis.append(M);columns=columns.row_join(v);return True
  return False
 for M in seed:add(M)
 changed=True
 while changed:
  changed=False;current=list(basis)
  for A,B in combinations(current,2):
   if add(A*B-B*A):changed=True
 return len(basis)
path_labels=[(0,1),(1,2),(2,3)];triangle_labels=[(0,1),(1,2),(0,2)]
pathdim=lie_dim([SAs[pairs.index(a)] for a in path_labels])
triangledim=lie_dim([SAs[pairs.index(a)] for a in triangle_labels])
assert pathdim==15 and triangledim==9
# Exchange-odd contrast: real tensor eigenbasis, no dimension-owner change.
ll=[1]*3+[-1]*3+[0]*9
odd_eigs=[ll[i]*ll[j] for i,j in combinations(range(15),2)]
counts=Counter(odd_eigs);assert counts=={1:6,-1:9,0:90}
for pplus,pminus in [(Q(0),Q(0)),(Q(1),Q(0)),(Q(0),Q(1)),(Q(1,4),Q(1,2))]:
 pact=pplus+pminus;c=pplus-pminus
 assert abs(c)<=pact<=1
 assert (pact+c)/2==pplus and (pact-c)/2==pminus
# Flat line connections: nontrivial holonomy despite identical zero curvature.
assert s.exp(-s.I*s.pi)==-1 and s.exp(-s.I*2*s.pi)==1
# Covariant capacity controls via exact CG decomposition, then fixed-vector tests.
geo=[(0,0),(Q(1,2),Q(1,2)),(1,0),(0,1)];sp=[(Q(1,2),0),(0,Q(1,2))]
mults=Counter()
for block in [geo,sp]:
 for a,b in block:
  for c,d in block:
   for e in [abs(a-c)+k for k in range(int(a+c-abs(a-c))+1)]:
    for f in [abs(b-d)+k for k in range(int(b+d-abs(b-d))+1)]:mults[(e,f)]+=1
caps={'K':0,'N':0,'H':0};labels={'K':0,'N':0,'H':0}
for (a,b),m in mults.items():
 js=[abs(a-b)+k for k in range(int(a+b-abs(a-b))+1)]
 fs={'K':int(a==b),'N':sum(j%2==0 for j in js),'H':len(js)}
 dim=int((2*a+1)*(2*b+1))*m
 for kind,h in fs.items():
  if h:caps[kind]+=dim;labels[kind]=max(labels[kind],(m+h-1)//h)
assert caps=={'K':65,'N':107,'H':137} and labels=={'K':8,'N':8,'H':6}
# Native protected exact-return and visibility constants.
assert Q(1,5)+Q(4,5)*Q(3,4)/4==Q(7,20)
assert Q(1,5)+Q(4,5)*1/4==Q(2,5)
assert 11**2+4**2==137 and 15**2-137==88
# Scope-control for simultaneous dense-cubature node bound and H-bi invariance.
qs=s.symbols('q0:4',real=True);qv=s.Matrix(qs)
wedgepairs=list(combinations(range(4),2))
Wq=s.Matrix(6,4,lambda row,k:qs[wedgepairs[row][0]]*int(k==wedgepairs[row][1])-qs[wedgepairs[row][1]]*int(k==wedgepairs[row][0]))
Hq=2*Wq*Wq.T-s.eye(6)
Kgeo=(s.ones(1,1).row_join((2/s.sqrt(3))*qv.T).row_join(s.zeros(1,6))).col_join(
 ((2/s.sqrt(3))*qv).row_join(Q(8,9)*s.eye(4)+Q(4,9)*qv*qv.T).row_join((4*s.sqrt(6)/9)*Wq.T)).col_join(
 s.zeros(6,1).row_join((4*s.sqrt(6)/9)*Wq).row_join(s.eye(6)+Hq/2))
sig=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-s.I],[s.I,0]]),s.diag(1,-1)]
Cs=[s.kronecker_product(sig[0],a) for a in sig]+[s.kronecker_product(sig[1],s.eye(2))]
Ksp=s.eye(4)+sum([qs[k]*Cs[k] for k in range(4)],s.zeros(4))
Kd=s.diag(Kgeo,Ksp)
monos=[1,*qs]+[qs[i]*qs[j] for i in range(4) for j in range(i,4) if (i,j)!=(3,3)]
coeffs=[]
for entry in Kd:
 for part in [s.re(entry),s.im(entry)]:
  poly=s.Poly(s.expand(part).subs(qs[3]**2,1-sum(z*z for z in qs[:3])),*qs)
  coeffs.append([poly.coeff_monomial(m) for m in monos])
entryspan=s.Matrix(coeffs).rank();assert entryspan==14
# Q8 is an admissible <=14-node unsymmetrized rule; uniform H is invariant
# with exactly24 nodes. Every left-H orbit in SU2 is free, hence size24.
qnodes=[]
for k in range(4):
 for sign in [-1,1]:
  v=[0]*4;v[k]=sign;qnodes.append(v)
assert sum([Kd.subs(dict(zip(qs,q))) for q in qnodes],s.zeros(15))/8==s.eye(15)
assert 8<=entryspan<24
# Intrinsic protected coordinates are nonzero; every nonzero weight step is +/-1.
Qhop=s.diag(0,0,1,-1)
steps=set()
for C in Cs:
 comm=Qhop*C-C*Qhop
 assert comm!=s.zeros(4)
 for i,j in product(range(4),repeat=2):
  if C[i,j]!=0:steps.add(Qhop[i,i]-Qhop[j,j])
assert steps=={-1,1}
# In the frozen chiral order Qhop acts on the right block and commutes with
# the full left SU2. Calling this same algebraic circle a left-factor subgroup
# is a label collision, while geometric left translation can name its owner.
for A in sig:
 L=s.diag(A,s.zeros(2));assert Qhop*L-L*Qhop==s.zeros(4)
result={'all_assertions_passed':True,'A5_order_counts':dict(Counter(ords.values())),
 'Petersen_perfect_matchings':len(matchings),'matching_complement_cycle_lengths':cycle_types,
 'four_edge_coloring':{str(e):c for e,c in colors.items()},
 'cyclic_coset_counts':{k:len(v) for k,v in cosets.items()},'projector_ranks':[25,16],
 'Reye_counts_ranks':{'70':[len(coreplanes),35],'80':[len(allplanes),36]},
 'binary_transporter_ranks':[17,10,6],'Pi15_rank':15,'binary_leverage':{k:list(map(str,v)) for k,v in lev.items()},
 'signed_covers':'dodecahedral versus distinct Desargues parity cover, exact charpolys checked',
 'edge_sl4_isometry':'15 exact orthonormal columns','triangle_J_rank':6,'class_frames':frame_checks,
 'mathematical_Lie_closure_controls':{'path':pathdim,'triangle':triangledim},'threecycle_frame_condition_ratio':10,'fivecycle_weight_ratio':'phi^6',
 'contrast_exchange_odd_spectrum':dict(counts),'covariant_capacities':caps,'minimal_passive_labels':labels,
 'same_curvature_circle_controls':['alpha=dtheta/2: holonomy -1','alpha=dtheta: holonomy1'],
 'protected_return_probabilities':['7/20','2/5'],
 'dense_cubature_scope_control':{'readout_band':0,'extra_functions':0,'endpoint_entry_span':entryspan,'unsym_rule_nodes':8,'H_bi_invariant_support_min':24,'simultaneous_bound_invariance':'impossible'},
 'intrinsic_Hopf_charge_steps':sorted(map(int,steps)),'frozen_chiral_circle_factor':'right'}
print(json.dumps(result,indent=2))
