"""Independent native matrices, capacities, axes and invariant-bound witness."""
import sympy as s
from itertools import combinations,permutations,product
from collections import Counter
from pathlib import Path
import json
checks=[]
def ck(n,c,r):
 if not bool(c):raise AssertionError(n)
 checks.append({'check':n,'passed':True,'result':r})
def z(M):return s.simplify(M)==s.zeros(*M.shape)
I=s.I;I2=s.eye(2);I4=s.eye(4)
sigma=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-I],[I,0]]),s.diag(1,-1)]
C=[s.kronecker_product(sigma[0],p) for p in sigma]+[s.kronecker_product(sigma[1],I2)]
Gamma=C[0]*C[1]*C[2]*C[3];twos=list(combinations(range(4),2))
def wedge(q):return s.Matrix([[q[i]*int(j==k)-q[j]*int(i==k) for k in range(4)] for i,j in twos])
Y=[]
for a in range(4):
 q=s.eye(4)[:,a];M=s.zeros(15);M[0,1+a]=M[1+a,0]=s.Rational(1,2)
 M[1:5,5:11]=s.sqrt(2)/3*wedge(q).T;M[5:11,1:5]=s.sqrt(2)/3*wedge(q)
 M[11:15,11:15]=s.sqrt(3)/4*C[a];Y.append(M)
Q=s.simplify(sum((M*M for M in Y),s.zeros(15)));PS=s.diag(*([0]*11+[1]*4));PG=s.eye(15)-PS
Hodge=s.zeros(6)
for a,pa in enumerate(twos):
 for b,pb in enumerate(twos):
  if set(pa).isdisjoint(pb):
   seq=pa+pb;Hodge[a,b]=(-1)**sum(seq[i]>seq[j] for i in range(4) for j in range(i+1,4))
B=s.diag(s.zeros(5),Hodge,s.zeros(4));S=s.diag(s.zeros(11),Gamma)
Om=s.zeros(15)
for p in permutations(range(4)):
 sign=(-1)**sum(p[i]>p[j] for i in range(4) for j in range(i+1,4))
 Om+=sign*Y[p[0]]*Y[p[1]]*Y[p[2]]*Y[p[3]]
Om=s.simplify(Om)
ck('Intrinsic quadratic fingerprint',Q==s.diag(1,*([s.Rational(11,12)]*4),*([s.Rational(4,9)]*6),*([s.Rational(3,4)]*4)),'native fingerprint exactly reproduced')
ck('Antisymmetric degree-four coordinate word',z(Om+s.Rational(34,81)*B-s.Rational(27,32)*S),'Omega4=-34 B/81+27 S/32')
ck('Separate degree-six protected and geometric chiral words',z(s.Rational(128,33)*(Q-s.Rational(4,9)*s.eye(15))*Om-S) and z(s.Rational(1458,187)*(Q-s.Rational(3,4)*s.eye(15))*Om-B),'both exact source degree-six identities')
ck('Protected population is degree-six polynomial in Q',z((Q-s.eye(15))*(Q-s.Rational(11,12)*s.eye(15))*(Q-s.Rational(4,9)*s.eye(15))/((s.Rational(3,4)-1)*(s.Rational(3,4)-s.Rational(11,12))*(s.Rational(3,4)-s.Rational(4,9)))-PS),'sector projector belongs to coordinate algebra')
ck('Protected chirality noncentrality',all(z(Gamma*c+c*Gamma) and Gamma*c-c*Gamma!=s.zeros(4) for c in C),'chi anticommutes with each invertible coordinate; centre of M4 is scalar')
# Total evenness alone does not imply membership in the native reducing algebra.
cross=s.zeros(15);cross[0,11]=cross[11,0]=1;par=PG-PS
even=s.kronecker_product(sigma[0],cross);totalpar=s.kronecker_product(sigma[2],par)
ck('Odd tensor odd is total-even but crosses native blocks',even*totalpar==totalpar*even and even*s.kronecker_product(I2,PS)!=s.kronecker_product(I2,PS)*even,'exact reducing-algebra counterexample in the stated host, not a physical constructor')
# Hopf charge steps on the current nonzero intrinsic tuple.
Qv=s.diag(sigma[1],sigma[1]);Qb=s.zeros(6)
for col,(i,j) in enumerate(twos):
 for k in range(4):
  for pair,coeff in [((k,j),Qv[k,i]),((i,k),Qv[k,j])]:
   if pair[0]==pair[1] or not coeff:continue
   row=twos.index(tuple(sorted(pair)));Qb[row,col]+=coeff*(1 if pair[0]<pair[1] else -1)
Qsp=-I*(C[0]*C[1]+C[2]*C[3])/2;QH=s.diag(s.zeros(1),Qv,Qb,Qsp)
ck('Intrinsic Hopf charge step +/-1',all(z(QH*(Y[a]+I*Y[a+1])-(Y[a]+I*Y[a+1])*QH-(Y[a]+I*Y[a+1])) and z(QH*(Y[a]-I*Y[a+1])-(Y[a]-I*Y[a+1])*QH+(Y[a]-I*Y[a+1])) for a in [0,2]),'complex coordinate components are ad(Q_H) eigenoperators of weights +/-1')
ck('Hopf mark is not automatic coordinate superselection',QH*Y[0]-Y[0]*QH!=s.zeros(15),'current nonzero intrinsic coordinates connect neighboring charge sectors')

# Native operator-system independence and repeat-readout values.
ops=[s.eye(15)]+Y+[PS,S]
cols=[s.Matrix([s.re(x) for x in M]+[s.im(x) for x in M]) for M in ops]
ck('Five/six/seven target operator independence',s.Matrix.hstack(*cols[:5]).rank()==5 and s.Matrix.hstack(*cols[:6]).rank()==6 and s.Matrix.hstack(*cols[:5],cols[6]).rank()==6 and s.Matrix.hstack(*cols).rank()==7,'dimension lower bounds 5,6,7')
ck('Directional intrinsic coordinate norm',Y[0].eigenvals()=={-s.Rational(1,2):1,s.Rational(1,2):1,-s.sqrt(2)/3:3,s.sqrt(2)/3:3,0:3,-s.sqrt(3)/4:2,s.sqrt(3)/4:2},'operator norm 1/2; covariance gives same bound for every unit direction')
r=s.symbols('r',positive=True)
ck('Repeated simplex fingerprint values',s.Rational(1,5)+4*s.Rational(3,4)/(5*4)==s.Rational(7,20) and s.Rational(1,5)+s.Rational(4,20)==s.Rational(2,5),{'intrinsic':'7/20','cone':'2/5','one_shot':'1/5'})
lam=s.symbols('lambda',positive=True);t=lam/s.sqrt(1-lam**2)
ck('Universal chirality visibility dual optimization',s.simplify((1+t*t)-(1/(1-lam*lam)))==0 and s.simplify(1/s.sqrt(1-lam*lam)-t*lam-s.sqrt(1-lam*lam))==0,'TV <= inf_t(sqrt(1+t^2)-t lambda)=sqrt(1-lambda^2), 0<lambda<1')

# Clebsch-Gordan enumeration from the original six sectors, independently of
# the table in the imported theorem.
blocks=[[(0,0),(1,1),(2,0),(0,2)],[(1,0),(0,1)]];mult=Counter()
for block in blocks:
 for a,b in block:
  for c,d in block:
   for l in range(abs(a-c),a+c+1,2):
    for rr in range(abs(b-d),b+d+1,2):mult[(l,rr)]+=1
caps={};labels={}
for J in ['K','N','H']:
 cap=0;lower=0
 for (a,b),m in mult.items():
  spins=list(range(abs(a-b),a+b+1,2))
  h=int(a==b) if J=='K' else sum(j%4==0 for j in spins) if J=='N' else sum(j%2==0 for j in spins)
  if h:cap+=(a+1)*(b+1)*m;lower=max(lower,(m+h-1)//h)
 caps[J]=cap;labels[J]=lower
ck('Covariant native capacity ranks and passive-label bounds',caps=={'K':65,'N':107,'H':137} and labels=={'K':8,'N':8,'H':6},{'capacity':caps,'minimal_labels':labels,'Hermitian_native':11**2+4**2,'off_block_extra':2*11*4})

# Exact ten-axis geometry and local tangent frames, in the source coordinate
# realization. Root sign choices are calculation gauges.
ph=(1+s.sqrt(5))/2;ip=ph-1
raw=[(1,1,1),(1,1,-1),(1,-1,1),(1,-1,-1),(ip,-ph,0),(ph,0,-ip),(0,ip,-ph),(0,ip,ph),(ph,0,ip),(ip,ph,0)]
axes=[s.Matrix(v)/s.sqrt(3) for v in raw];pair5=list(combinations(range(5),2));set5=[set(p) for p in pair5]
adj=[[not a&b for b in set5] for a in set5];norm=lambda x:s.simplify(x.dot(x))
for i,u in enumerate(axes):
 ns=[]
 for j,v in enumerate(axes):
  if adj[i][j]:ns.append(s.simplify(s.Rational(3,2)*s.sign(s.simplify(u.dot(v)))*u.cross(v)))
 N=s.Matrix.hstack(*ns);Wu=s.sqrt(s.Rational(2,3))*N
 ck('Local Petersen transverse isometry '+str(i),z(Wu*Wu.T-(s.eye(3)-u*u.T)) and z(Wu.T*Wu-(s.eye(3)-s.ones(3)/3)),'W W^T=I-uu^T; W^T W=I-J/3')
 # One tangent channel suffices after the transitive local cyclic action.
 n=ns[0];parents=[]
 for core in pair5[i]:
  frame=[]
  for j,v in enumerate(axes):
   if j!=i and core in pair5[j]:
    vv=-s.sign(s.simplify(u.dot(v)))*v
    frame.append(s.simplify(3/(2*s.sqrt(2))*(vv+u/3)))
  p=max(frame,key=lambda v:float(s.N((v.dot(n))**2)))
  if float(s.N(p.dot(n)))<0:p=-p
  parents.append(p)
 ck('Two-parent angular bisector '+str(i),all(s.simplify(p.dot(n)**2-(9+3*s.sqrt(5))/16)==0 for p in parents) and z(n.cross(parents[0]+parents[1])),'opposite parent rotations with exact squared cosine (9+3sqrt5)/16')
Jcore=[]
for core in range(5):
 Jcore.append(s.simplify(s.Rational(3,4)*sum((u.xreplace({s.sqrt(5):-s.sqrt(5)})*u.T for p,u in zip(pair5,axes) if core in p),s.zeros(3))))
ck('Two-parent polar response has an unsplit transverse doublet',all(z((Jcore[i]+Jcore[j]).T*(Jcore[i]+Jcore[j])-4*u*u.T-(s.eye(3)-u*u.T)/4) for (i,j),u in zip(pair5,axes)),'axial squared singular value4; both transverse squared singular values1/4')

# The native endpoint density used for the invariant-bound interpretation
# witness. It is already admissible on 1/3<=c<=1; use c=1/2.
def K(q):
 q=s.Matrix(q);w=wedge(q);out=s.zeros(15)
 out[0,0]=1;out[0,1:5]=2/s.sqrt(3)*q.T;out[1:5,0]=2/s.sqrt(3)*q
 out[1:5,1:5]=s.Rational(8,9)*I4+s.Rational(4,9)*q*q.T
 out[1:5,5:11]=4*s.sqrt(6)/9*w.T;out[5:11,1:5]=4*s.sqrt(6)/9*w
 out[5:11,5:11]=s.eye(6)+(2*w*w.T-s.eye(6))/2
 out[11:15,11:15]=I4+sum((q[a]*C[a] for a in range(4)),s.zeros(4))
 return out
H=[]
for a in range(4):
 for sign in [-1,1]:
  q=[0]*4;q[a]=sign;H.append(q)
H += [[s.Rational(sign,2) for sign in signs] for signs in product([-1,1],repeat=4)]
ks=[K(q) for q in H]
entryeval=s.Matrix.hstack(*[M.reshape(225,1) for M in ks])
ck('Native r=0 observable-span dimension in C82 witness',entryeval.rank()==14,{'span_dimension':14,'band':'r=0','additional_integrands':'empty'})
ck('Unaveraged Q8 positive control for C82 node bound',s.simplify(sum(ks[:8],s.zeros(15))/8)==s.eye(15),'eight positive nodes reproduce all entries of K_(1/2), within the bound fourteen')
ck('Uniform-H invariant positive control for C82 witness',len(H)==24 and s.simplify(sum(ks,s.zeros(15))/24)==s.eye(15),'uniform 24-node H rule is positive, normalized, H-bi-invariant and normalizer-conjugation invariant')
out={'kind':'E3-INDEPENDENT-EXACT','target':'Paper2E-KinematicExports-v3_130.tex','source_lines':[1958,2572],'inputs':'Explicit intrinsic coordinate and endpoint matrices, direct Clebsch-Gordan enumeration, exact ten-axis coordinates; no prior verdict flags.','checks_count':len(checks),'all_passed':True,'checks':checks,'interpretation_witness_C82':{'target':'combined unchanged <=d node bound plus added H-bi-invariance','witness':'r=0, empty F, positive degree-two native K_(1/2), observable span dimension14','obstruction':'Every nonempty finite H-left-invariant support is a union of free H-orbits and has at least |H|=24 points.','positive_control':'Uniform H with24points is fully invariant and exact.','limitation':'This does not refute separate unaveraged <=14-node existence and averaged invariant existence with a larger node count.'}}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'checks_count':len(checks),'all_passed':True}))
