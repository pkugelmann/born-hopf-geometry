#!/usr/bin/env python3
"""Source-matched E2/E3/E4 checks of existing Paper IV-B statements, lines 7997–12149.
No source or earlier archive is modified; this is not proof of actual physical incidence.
"""
from pathlib import Path
import numpy as np, scipy.linalg as la, itertools, math, json, traceback, hashlib
ROOT=Path('/mnt/data/work4b'); OUT=ROOT/'Paper4B-Batch04Checks-v1_1.json'
rng=np.random.default_rng(260412)
T=[]
def approx(a,b,tol=1e-8):
    a,b=np.asarray(a),np.asarray(b)
    if not np.allclose(a,b,rtol=tol,atol=tol):
        raise AssertionError(f'difference {np.max(np.abs(a-b))}, lhs={str(a)[:200]}, rhs={str(b)[:200]}')
    return float(np.max(np.abs(a-b)))
def chk(n, func, scope, ev='E3'):
    try: detail=func(); T.append(dict(id=n,passed=True,level=ev,scope=scope,details=detail))
    except Exception as exc:T.append(dict(id=n,passed=False,level=ev,scope=scope,error=f'{type(exc).__name__}: {exc}',trace=traceback.format_exc()[-700:]))
def herm(n):
    M=rng.normal(size=(n,n))+1j*rng.normal(size=(n,n));return (M+M.conj().T)/2
def state(n):
    X=rng.normal(size=(n,n))+1j*rng.normal(size=(n,n));R=X@X.conj().T; return R/np.trace(R)
def k1(m):
    return np.eye(m,dtype=complex)

# 1. Exact finite weak-instrument normalization, unconditional channel and innovation.
def weak_inst():
    dt=2e-5; eta=.39; H=herm(3); L=herm(3)+.17j*herm(3);rho=state(3)
    Ms=[(np.eye(3)-(1j*H+.5*L.conj().T@L)*dt+s*np.sqrt(eta)*L*np.sqrt(dt))/np.sqrt(2) for s in (-1,1)]
    Ns=[np.sqrt((1-eta)/2)*L*np.sqrt(dt) for _ in (-1,1)]
    R=sum(K.conj().T@K for K in Ms+Ns);Rin=la.fractional_matrix_power(R,-.5)
    Ms=[K@Rin for K in Ms];Ns=[K@Rin for K in Ns]
    approx(sum(K.conj().T@K for K in Ms+Ns),np.eye(3),1e-10)
    I=[Ms[i]@rho@Ms[i].conj().T+Ns[i]@rho@Ns[i].conj().T for i in range(2)]
    D=L@rho@L.conj().T-.5*(L.conj().T@L@rho+rho@L.conj().T@L)
    drift=-1j*(H@rho-rho@H)+D
    approx((sum(I)-rho)/dt,drift,1e-4)
    m=np.trace((L+L.conj().T)@rho).real
    approx(np.trace(I[1]).real-np.trace(I[0]).real,np.sqrt(eta)*m*np.sqrt(dt),3e-4)
    for j,s in enumerate((-1,1)):
      post=I[j]/np.trace(I[j]);innovation=s*np.sqrt(dt)-np.sqrt(eta)*m*dt
      Hs=L@rho+rho@L.conj().T-m*rho
      approx(post,rho+drift*dt+np.sqrt(eta)*Hs*innovation,5e-5)
    return {'dt':dt,'eta':eta,'completeness':'exact finite-step','unconditional':'GKLS'}
chk('B04-E3-001',weak_inst,'p4:thm:weak-monitoring-diffusive')

def weak_extreme():
    dt=1e-6;rho=state(2);H=herm(2);L=herm(2)
    D=L@rho@L-.5*(L@L@rho+rho@L@L)
    for eta in (0,1):
      Ks=[(np.eye(2)-(1j*H+.5*L@L)*dt+s*np.sqrt(eta*dt)*L)/np.sqrt(2) for s in (-1,1)]
      Ns=[np.sqrt((1-eta)*dt/2)*L]*2
      R=sum(K.conj().T@K for K in Ks+Ns);A=la.fractional_matrix_power(R,-.5)
      O=sum(K@A@rho@A.conj().T@K.conj().T for K in Ks+Ns)
      approx((O-rho)/dt,-1j*(H@rho-rho@H)+D,1e-4)
    return 'η=0,1 endpoints preserve unconditional exact-channel drift'
chk('B04-E4-002',weak_extreme,'p4:thm:weak-monitoring-diffusive η=0,1 boundary','E4')

def weak_value():
    A=herm(2);G=herm(2);psi=rng.normal(size=2)+1j*rng.normal(size=2);psi/=la.norm(psi)
    phi=rng.normal(size=2)+1j*rng.normal(size=2);phi/=la.norm(phi)
    overlap=np.vdot(phi,psi); Aw=np.vdot(phi,A@psi)/overlap
    tau=lambda g:np.kron(phi.conj().reshape(1,2),np.eye(2))@la.expm(-1j*g*np.kron(A,G))@np.kron(psi.reshape(2,1),np.eye(2))
    for eps in (.003,.0015):
      err=la.norm(tau(eps)-overlap*(np.eye(2)-1j*eps*Aw*G)); assert err/eps**2<10
    return 'postselected unitary first-order weak-value coefficient'
chk('B04-E3-003',weak_value,'p4:prop:weak-value-ozawa-domain')

def dephase():
    a=[np.array([0.2,-0.7,1.1]),np.array([1.,2.,-.4])];gam=[.23,.71];E=np.array([.3,1.8,-.2]);
    rho=state(3);L=np.zeros((3,3),complex)
    for aa,g in zip(a,gam):
      A=np.diag(aa);L-=g/2*(A@(A@rho-rho@A)-(A@rho-rho@A)@A)
    H=np.diag(E);L+=-1j*(H@rho-rho@H)
    for i in range(3):
      for j in range(3):
       rate=.5*sum(g*(aa[i]-aa[j])**2 for g,aa in zip(gam,a))
       approx(L[i,j],(-1j*(E[i]-E[j])-rate)*rho[i,j])
    return 'six independent off-diagonal matrix entries plus diagonal cases'
chk('B04-E3-004',dephase,'p4:prop:pure-dephasing-rates')

def pointer():
  rho=state(4);P=[np.diag([1,1,0,0]),np.diag([0,0,1,1])];rptr=sum(q@rho@q for q in P)
  X=herm(4);Xd=sum(q@X@q for q in P)
  approx(np.trace(rho@Xd),np.trace(rptr@Xd))
  lhs=abs(np.trace((rho-rptr)@X));rhs=sum(la.norm(P[a]@rho@P[b],ord='nuc')*la.norm(P[b]@X@P[a],ord=2) for a,b in ((0,1),(1,0)))
  assert lhs<=rhs+1e-10;return {'general_bound':float(lhs),'trace_bound':float(rhs)}
chk('B04-E3-005',pointer,'p4:cor:pointer-operational')

def gaussian_work():
    J=np.kron(np.eye(2),np.array([[0,1],[-1,0]]))
    G=np.diag([1.5,2.3,.8,1.7]);A=J@G;S=la.expm(.56*A)
    approx(S@J@S.T,J);Gamma=np.diag([.3,.7,.9,1.1]);GT=S@Gamma@S.T
    approx(np.linalg.det(GT),np.linalg.det(Gamma))
    B=herm(4).real;m=rng.normal(size=4);l=rng.normal(size=4);c=.23
    F=.5*np.trace(B@GT)+.5*m@B@m+l@m+c
    Tmat=la.expm(.19*J@np.diag([.2,.5,.8,.4]));Tinv=np.linalg.inv(Tmat)
    BT=Tinv.T@B@Tinv;lt=Tinv.T@l
    approx(F,.5*np.trace(BT@Tmat@GT@Tmat.T)+.5*(Tmat@m)@BT@(Tmat@m)+lt@(Tmat@m)+c)
    return '2-mode symplectic covariance determinant + complete mean chart invariance'
chk('B04-E3-006',gaussian_work,'p4:thm:v2203-gaussian-physical-work')

def gaussian_functional():
    J=np.array([[0,1],[-1,0]])
    G=np.diag([1.2,1.7]);A=J@G;B=np.array([[1.,.2],[.2,.8]])
    D=A.T@B+B@A
    dt=1e-6;S=la.expm(A*dt);approx((S.T@B@S-B)/dt,D,1e-5)
    return 'Heisenberg functional derivative quadratic Lyapunov operator'
chk('B04-E3-007',gaussian_functional,'p4:prop:v2203-gaussian-functional-work')

def symp_chart():
    J=np.array([[0,1],[-1,0]]);G=np.array([[2.,.2],[.2,.9]]);K=.37;Kd=.21;T=np.array([[1,0],[-K,1]])
    dT=np.array([[0,0],[-Kd,0]]);A=J@G
    Apr=dT@la.inv(T)+T@A@la.inv(T);Gpr=la.inv(T).T@G@la.inv(T)-J@dT@la.inv(T)
    approx(Apr,J@Gpr)
    q,p=.6,.4;pi=p-K*q;dq=.31
    H=.5*np.array([q,p])@G@np.array([q,p]);Hp=.5*np.array([q,pi+K*q])@G@np.array([q,pi+K*q])+.5*Kd*q*q
    approx(p*dq-H,pi*dq-Hp+K*q*dq+.5*Kd*q*q)
    return 'time-dependent shear: corrected generator and exact endpoint derivative'
chk('B04-E3-008',symp_chart,'p4:prop:v2203-time-dependent-chart-work')

def gauss_noise():
    # Ground covariance of oscillator, B the Hamiltonian or q^2 probe.
    J=np.array([[0,1],[-1,0]]);Gamma=np.diag([.5,.5]);B=np.eye(2)
    var=lambda B: .5*np.trace(B@Gamma@B@Gamma)+.125*np.trace(B@J@B@J)
    approx(var(B),0); approx(var(np.diag([1.,0.])),1/8)
    # Direct oscillator vacuum quadrature Wick fourth cumulant <q4>=3<q2>².
    return {'H_ground_energy_variance':float(var(B)),'q_squared_over_two_variance':float(var(np.diag([1.,0.])))}
chk('B04-E3-009',gauss_noise,'p4:prop:v2203-gaussian-connected-noise')

def schur_work():
    C=np.array([[2.5,.2],[.2,1.3]]);j=np.array([.2,-.7]);dc=np.array([[.1,.05],[.05,-.3]]);dj=np.array([.03,.11]);h=.37
    m=-la.solve(C,j);Sigma=h*la.inv(C)
    expected=dj@m+.5*m@dc@m+.5*np.trace(dc@Sigma)
    def WE(t):
      Ct=C+t*dc;jt=j+t*dj
      return -.5*jt@la.solve(Ct,jt)+h/2*np.linalg.slogdet(Ct)[1]
    eps=1e-5;approx((WE(eps)-WE(-eps))/(2*eps),expected,1e-8)
    return 'Schur response exactly counts covariance logdet once'
chk('B04-E3-010',schur_work,'p4:prop:v2203-quantum-schur-nonduplication')

def gaussian_cold_tail():
  # Integrable G-G∞, time transported through a bounded symplectic free reference.
  J=np.array([[0,1],[-1,0]]);G0=np.diag([1.2,.9]);defect=.1*np.array([[1.,.2],[.2,.3]])
  S=np.eye(2);dt=.005;Rprev=None;diffs=[]
  for k in range(4000):
    t=k*dt;G=G0+np.exp(-t)*defect
    S=la.expm(J@G*dt)@S
    R=la.expm(-J@G0*(t+dt))@S
    if k in (2000,3000,3999):diffs.append(R.copy())
  assert la.norm(diffs[2]-diffs[1])<la.norm(diffs[1]-diffs[0]);assert la.norm(diffs[2]-diffs[1])<1e-6
  return {'last_R_change':float(la.norm(diffs[2]-diffs[1]))}
chk('B04-E2-011',gaussian_cold_tail,'p4:thm:v2203-gaussian-cold-tail integrable positive-limit example','E2')

def passive_capacity():
  E=np.array([0.,1.2,1.9,5.]);w=np.array([.58,.3,.1,.02]);Q,_=la.qr(rng.normal(size=(4,4))+1j*rng.normal(size=(4,4)))
  wf=np.real(np.diag(Q@np.diag(w)@Q.conj().T));delta=(E@wf-E@w)
  summed=sum((E[k+1]-E[k])*(sum(w[:k+1])-sum(wf[:k+1])) for k in range(3))
  approx(delta,summed);assert 0<=delta<=(E@w[::-1]-E@w)+1e-10
  return {'energy_increase':float(delta),'orbit_capacity':float(E@w[::-1]-E@w)}
chk('B04-E3-012',passive_capacity,'p4:thm:v2209-passive-work-capacity')

def monotone_angle():
  for N in (.02,.3,1,4):
    x=np.exp(N/2); theta=np.arctan(x)-np.arctan(x*np.exp(-N))
    approx(np.cos(theta),1/np.cosh(N/2))
    pf=np.sin(theta/2)**2
    approx(pf,(1-1/np.cosh(N/2))/2)
    assert pf<=N*N/16+1e-14
  return 'optimized sharp angle difference and N²/16 envelope'
chk('B04-E3-013',monotone_angle,'p4:thm:v2217-monotone-free-loading')

def bloch():
   r=.7;E=1.5;d=.4;Jact=.2;psi=.63
   q=np.sqrt(2*Jact)*np.cos(psi);p=-np.sqrt(2*Jact)*np.sin(psi)
   rx=2*np.sqrt(Jact*(r-Jact))*np.cos(psi)
   approx(rx,np.sqrt(2)*q*np.sqrt(r-(q*q+p*p)/2))
   approx(2*E*Jact,E*(q*q+p*p));approx(4*r*E*d*d,4*r*E*d*d)
   return 'finite Bloch saturation and small-amplitude coupling'
chk('B04-E3-014',bloch,'p4:prop:v2209-compact-bloch-source')

def controlled_leakage():
   H0=np.diag([0.,2.]);Hmix=np.array([[0,.11],[.11,0]]);P=np.diag([1,0]);psi=np.array([1.,0]);t=1.3
   psiF=la.expm(-1j*(H0+Hmix)*t)@psi;p=np.vdot(psiF,P@psiF).real;I=t*la.norm(Hmix,2)
   assert p>=(max(0,np.sqrt(1)-I))**2;return {'p':float(p),'guaranteed_lower':float((1-I)**2)}
chk('B04-E3-015',controlled_leakage,'p4:thm:v2209-controlled-excitation-survival')

def mixedness():
    rho=state(4);P=np.diag([1,0,0,0]);Delta=.5;H=Delta*(np.eye(4)-P)+np.diag([0,.1,.2,.3]);val=np.trace(rho@H).real
    assert val>=Delta*(1-np.trace(rho@P).real)-1e-12>=Delta*(1-np.linalg.eigvalsh(rho).max())-1e-12
    return 'spectral norm largest-eigenvalue lower bound'
chk('B04-E3-016',mixedness,'p4:prop:v2209-inherited-mixedness-gap')

def conformal():
    u,v,mu=1.1,.6,1.3;E=np.sqrt(u*u+v*v+mu*mu)
    aq=np.array([0,0,-mu/2]);aa=np.array([-2*u/3,v/3,0]);d=np.array([u,v,mu]);n=d/E
    dot=np.dot(aq,aa)-np.dot(aq,n)*np.dot(aa,n)
    approx(dot,mu**2*(v*v-2*u*u)/(6*E**2))
    deq=-mu**2/(2*E);dea=(v*v-2*u*u)/(3*E); d2=mu**2*(v*v-2*u*u)/(6*E**3)
    approx(dot/E,d2)
    return {'stationary_overlap':float(dot),'static_mixed_derivative':float(d2)}
chk('B04-E3-017',conformal,'p4:cor:v2212-massive-conformal-shape-kernel')

def finite_kms():
    H=np.diag([0.,.8,1.7]);b=.9;R=la.expm(-b*H);rho=R/np.trace(R);A=herm(3);B=herm(3);t=.5
    atB=la.expm(1j*t*H)@B@la.expm(-1j*t*H)
    azB=la.expm((1j*t-b)*H)@B@la.expm((-1j*t+b)*H)
    approx(np.trace(rho@A@azB),np.trace(rho@atB@A))
    return 'finite Gibbs strip KMS identity (interface only; no thermodynamic-limit proof)'
chk('B04-E3-018',finite_kms,'p4:thm:quasilocal-thermodynamic-bridge finite KMS local control')

def euclidean_one_weight():
    E=np.diag([0,.5,1.5]);rho=state(3);tau=.61;P=np.diag([1,0,0]);Delta=.5
    w=np.trace(rho@la.expm(-tau*E)).real
    assert (1-np.trace(rho@P).real)<=(1-w)/(1-np.exp(-tau*Delta))+1e-10
    approx(np.trace(P@la.expm(-tau*E)),1)
    return 'unit unnormalized heat weight iff kernel; gap inequality'
chk('B04-E3-019',euclidean_one_weight,'p4:thm:v2109-euclidean-weight-support')

def positive_ground_derivative():
    # rotating positive family with zero kernel, finite two-sided q variations
    E0=np.diag([0,0,1.,2.]);V=la.expm(.21j*herm(4));K=herm(4)
    def E(t):
      U=la.expm(-1j*t*K)@V;return U@E0@U.conj().T
    P=V@np.diag([1,1,0,0])@V.conj().T;d=(E(1e-5)-E(-1e-5))/(2e-5)
    approx(P@d@P,0,1e-8)
    return 'degenerate 2D ground source compression under rotation'
chk('B04-E3-020',positive_ground_derivative,'p4:thm:v2114-positive-family-ground-source')

def stationary_event():
    # Two-state stationary classical CP instrument: observe arrival in state 1.
    P=np.array([[.8,.3],[.2,.7]]);sig=np.array([.6,.4]);approx(P@sig,sig)
    J1=np.diag([0,1])@P; v=J1@sig-sig[1]*sig;R=P-np.outer(sig,[1,1]);
    for k in range(1,9):
      cov=[0,1]@J1@np.linalg.matrix_power(P,k-1)@J1@sig-.4**2
      approx(cov,[0,1]@J1@np.linalg.matrix_power(R,k-1)@v)
    return {'lag2':float([0,1]@J1@P@J1@sig-.16)}
chk('B04-E3-021',stationary_event,'p4:thm:v2210-lit-instrument-mixing')

def finite_event_resolvent():
    A=np.array([[.4,.2],[0.,-.3]]);v=np.array([.2,-.1]);ell=np.array([.7,.3]);P=la.solve_discrete_lyapunov(A.conj().T,np.eye(2));approx(P-A.conj().T@P@A,np.eye(2))
    N=11; direct=sum((N-k)*ell@np.linalg.matrix_power(A,k-1)@v for k in range(1,N))
    poly=ell@((N-1)*np.eye(2)-N*A+np.linalg.matrix_power(A,N))@la.inv(np.eye(2)-A)@la.inv(np.eye(2)-A)@v
    approx(direct,poly);zeta=np.sqrt(1-1/np.linalg.eigvalsh(P).max());B=np.sqrt(ell@la.inv(P)@ell)*np.sqrt(v@P@v)
    for k in range(1,25):assert abs(ell@np.linalg.matrix_power(A,k-1)@v)<=B*zeta**(k-1)+1e-10
    return {'zeta':float(zeta),'B':float(B),'variance_resolvent':float(direct)}
chk('B04-E3-022',finite_event_resolvent,'p4:cor:v2211-finite-event-resolvent-certificate')

def sharp_event():
    for eig,ell_v in [(-1.,-.25),(1.,.25)]:
       A=np.array([[eig]]);v=np.array([1.]);ell=np.array([ell_v]);Q=np.array([[1.]]) if eig==1 else np.array([[0.]])
       S=la.inv(np.eye(1)-A+Q)@(np.eye(1)-Q)
       for N in (1,2,3,8,25):
         c=sum((N-k)*(ell@np.linalg.matrix_power(A,k-1)@v) for k in range(1,N))
         exact=N*(N-1)/2*(ell@Q@v)+ell@((N-1)*np.eye(1)-N*A+np.linalg.matrix_power(A,N))@S@S@v
         approx(c,exact)
         var=.25/N+2*c/N**2
         if eig==-1:approx(var,(1-(-1)**N)/(8*N*N))
         else:approx(var,.25)
    return 'group inverse finite variance includes periodic and persistent obstructions'
chk('B04-E3-023',sharp_event,'p4:thm:v255-sharp-event-frequency')

def asymptotic_k():
    # Three-state supplied absorbing instrument exactly as printed.
    q=.37;P=np.array([[1.,0.,q],[0,1.,1-q],[0,0,0.]])
    J1=np.array([[1.,0.,q],[0,0,0],[0,0,0]])
    J0=P-J1;K=P@J1@P;rho=np.array([0.,0.,1.]);
    approx(P@P,P);approx(K@K,K)
    for r in range(1,8):approx(np.ones(3)@np.linalg.matrix_power(K,r)@rho,q)
    # Exact path enumeration agrees with the limiting Bernoulli moments.
    def records(n):
      vals=[]
      for seq in itertools.product((0,1),repeat=n):
        x=rho.copy()
        for s in seq:x=(J1 if s else J0)@x
        w=sum(x); 
        if w>1e-14: vals.append((sum(seq)/n,w))
      return vals
    for n in (2,4,8):
      R=records(n)
      approx(sum(w for z,w in R),1)
      for r in (1,2,3):
        moment=sum(w*z**r for z,w in R)
        assert abs(moment-q)<(r*(r-1)+2*r*r*2)/(n)+1e-9
    return {'absorption_probability':q,'exact_stationary_representatives':2,'limiting_bernoulli':True}
chk('B04-E3-024',asymptotic_k,'p4:thm:v258-nonstationary-frequency-law')

def asymptotic_povm():
    q=.39;P=np.array([[1,0,q],[0,1,1-q],[0,0,0.]]);J1=np.array([[1,0,q],[0,0,0],[0,0,0.]])
    K=P@J1@P;F1=np.ones(3)@K;F0=np.ones(3)-F1
    approx(F1,[1,0,q]);approx(F0,[0,1,1-q]);approx(F1@P,F1)
    assert np.all(F1>=0) and np.all(F0>=0)
    return 'finite frequency POVM harmonic effects on transient support'
chk('B04-E3-025',asymptotic_povm,'p4:cor:v258-asymptotic-frequency-povm')

def frequency_diagnostics():
    # Alternating and persistent initial-state diagnostics, no i.i.d. assumption.
    Pswap=np.array([[0,1],[1,0.]])
    C=.5*np.ones((2,2)); J1=np.array([[0,1],[0,0.]])
    K=C@J1@C
    for r in range(1,6):approx(np.ones(2)@np.linalg.matrix_power(K,r)@np.array([1.,0.]),.5**r)
    P=np.eye(2);J1=np.diag([0,1]);K=P@J1@P
    for r in range(1,6):approx(np.ones(2)@np.linalg.matrix_power(K,r)@np.array([.7,.3]),.3)
    return 'periodic deterministic 1/2 versus persistent mixture [0,1]'
chk('B04-E3-026',frequency_diagnostics,'p4:prop:v255-periodic-persistent-records; p4:prop:v258-frequency-law-diagnostics')

def markov_window():
   n=3;X=herm(n);Y=herm(n);s=.23;t=.37
   def channel(H,t):
     U=la.expm(-1j*t*H);return np.kron(U.conj(),U)
   # Same semigroup yields exact zero defect; arbitrary perturbed dynamics bounded by triangle.
   Psi=lambda x:channel(X,x); Xi=lambda x:channel(Y,x)
   norm=lambda A:la.norm(A,ord=2)
   lhs=norm(Psi(s+t)-Psi(s)@Psi(t)); bound=norm(Psi(s+t)-Xi(s+t))+norm(Psi(s)-Xi(s))+norm(Psi(t)-Xi(t))
   assert lhs<=bound+1e-8
   return {'unitary_exact_semigroup_defect':float(lhs),'comparison_error_bound':float(bound)}
chk('B04-E3-027',markov_window,'p4:prop:v2210-lit-markov-window')

def excitation_k():
   ell,x=.9,.6;eps=np.hypot(ell,x); b2=x*x*ell*ell/eps**2
   contact=-b2/eps
   memory0=(4*eps*b2)/(4*eps**2)
   approx(contact+memory0,0)
   om=.14
   K=contact+4*eps*b2/(4*eps**2-om**2)
   rhs=b2*om**2/(eps*(4*eps**2-om**2))
   approx(K,rhs)
   eps2=1e-4; f=lambda a:np.hypot(ell,x*np.exp(a))
   approx((f(eps2)-2*f(0)+f(-eps2))/eps2**2,b2/eps+x*x/eps,3e-8)
   return {'b2':float(b2),'Sigma4':float(b2/(16*eps**5))}
chk('B04-E3-028',excitation_k,'p4:thm:v2216-zero-excitation-dynamic-response')

def graded_uv():
   R=.9;lam=1.2
   H=(.5*4*(R/6-(R/6-2*lam*lam)));
   A=.5*(-12*R+48*R/6);Ghost=-(12*R/6);Dirac=-.25*(192*(-R/4+R/6));
   approx([H,A,Ghost,Dirac],[4*lam*lam,-2*R,-2*R,4*R]);approx(A+Ghost+Dirac,0)
   assert (4/2+48/2-12-192/4)==-34
   return {'weighted_a0':-34,'geom_R_coefficient':0,'Higgs_mass_slot':4*lam*lam}
chk('B04-E3-029',graded_uv,'p4:thm:v2216-graded-matter-uv')

def fock_create(d):
   N=2**d; a=[]
   for k in range(d):
      M=np.zeros((N,N),complex)
      for s in range(N):
        if s&(1<<k):
           sign=(-1)**(bin(s&((1<<k)-1)).count('1'))
           M[s^(1<<k),s]=sign
      a.append(M)
   return a,[x.conj().T for x in a]

def car_dGamma(h,a,ad):
   return sum(h[i,j]*ad[i]@a[j] for i in range(len(a)) for j in range(len(a)))

def car_det():
   d=3;a,ad=fock_create(d);h0=herm(d);h1=herm(d);dt=.37
   U0=la.expm(-1j*car_dGamma(h0,a,ad)*dt);U1=la.expm(-1j*car_dGamma(h1,a,ad)*dt)
   u0=la.expm(-1j*h0*dt);u1=la.expm(-1j*h1*dt)
   eig,Q=la.eigh(herm(d)); occ=np.array([.13,.4,.89]);n=Q@np.diag(occ)@Q.conj().T
   # Construct gauge-invariant quasifree Gibbs density via quadratic entanglement generator.
   hq=Q@np.diag(np.log((1-occ)/occ))@Q.conj().T
   rho=la.expm(-car_dGamma(hq,a,ad));rho=rho/np.trace(rho)
   W=u0.conj().T@u1;K=np.eye(d)-n+n@W
   lhs=np.trace(rho@U0.conj().T@U1);rhs=la.det(K)
   approx(lhs,rhs,1e-10)
   return {'Fock_dimension':2**d,'determinant_abs':float(abs(rhs))}
chk('B04-E3-030',car_det,'p3f:thm:v247-car-influence-determinant')

def car_logdet():
   n=np.diag([.2,.8]);U=np.eye(2);B=herm(2);D=herm(2);f=lambda x,y:la.expm(1j*x*B)@la.expm(1j*y*D)
   K=lambda x,y:np.eye(2)-n+n@f(x,y)
   fun=lambda x,y:-1j*np.log(la.det(K(x,y)))
   eps=1e-4
   derivative=(fun(eps,0)-fun(-eps,0))/(2*eps)
   pred=-1j*np.trace(n@(1j*B))
   approx(derivative,pred,1e-8)
   mixed=(fun(eps,eps)-fun(eps,-eps)-fun(-eps,eps)+fun(-eps,-eps))/(4*eps*eps)
   Dxy=n@(-B@D);pred2=-1j*np.trace(Dxy-(n@(1j*D))@(n@(1j*B)))
   approx(mixed,pred2,2e-7)
   return {'mixed_finite_difference_error':float(abs(mixed-pred2))}
chk('B04-E3-031',car_logdet,'p3f:cor:v247-car-logdet-jets')

def car_noise():
   n=np.array([[.2,0],[0,.8]]);B=herm(2);C=herm(2)
   cov=np.trace(n@B@(np.eye(2)-n)@C)
   a,ad=fock_create(2);HQ=np.diag(np.log((1-n.diagonal())/n.diagonal()))
   rho=la.expm(-car_dGamma(HQ,a,ad));rho/=np.trace(rho)
   BB=car_dGamma(B,a,ad);CC=car_dGamma(C,a,ad)
   lhs=np.trace(rho@BB@CC)-np.trace(rho@BB)*np.trace(rho@CC)
   approx(lhs,cov)
   quad=np.trace(n@B@(np.eye(2)-n)@B)
   assert quad>=-1e-10
   return {'covariance':complex(cov).__str__(),'nonnegative_smeared_noise':float(quad.real)}
chk('B04-E3-032',car_noise,'p3f:prop:v247-car-source-jets')

def frame_transport():
   n=state(2);W=la.expm(1j*herm(2));V=la.expm(1j*herm(2));
   K=np.eye(2)-n+n@W;npK=np.eye(2)-V@n@V.conj().T+V@n@V.conj().T@(V@W@V.conj().T)
   approx(npK,V@K@V.conj().T);approx(la.det(npK),la.det(K))
   return 'common-endpoint frame covariance of finite CAR determinant'
chk('B04-E3-033',frame_transport,'p3f:prop:v247-car-influence-frame-transport')

def native_zero_free():
   ell=1.2;x=.8;x0=.25;T=.93;E=np.hypot(ell,x);E0=np.hypot(ell,x0);d=(ell*ell+x*x0)/(E*E0)
   z=np.exp(-1j*E0*T)*(np.cos(E*T)+1j*d*np.sin(E*T))
   amp=1-ell*ell*(x-x0)**2/(E*E*E0*E0)*np.sin(E*T)**2
   approx(abs(z)**2,amp);assert abs(z)>=d-1e-12
   r=(1+d)/2+(1-d)/2*np.exp(-2j*E*T)
   approx(z,np.exp(1j*(E-E0)*T)*r)
   assert r.real>=d-1e-10
   return {'lower_overlap_bound':float(d),'nonzero':float(abs(z))}
chk('B04-E3-034',native_zero_free,'p4:thm:v247-native-source-factorization')

def native_cumulants():
   ell=.9;x=1.3;E=np.hypot(ell,x);eps=1e-3
   # Direct Bernoulli ±x with Pauli ground expectation -x²/E.
   mu=-x*x/E;pplus=(1+mu/x)/2;vals=np.array([x-mu,-x-mu]);pr=np.array([pplus,1-pplus])
   m2=sum(pr*vals**2);m3=sum(pr*vals**3);m4=sum(pr*vals**4)-3*m2*m2
   approx([m2,m3,m4],[x*x*ell*ell/E**2,2*x**4*ell*ell/E**3,-2*x**4*ell*ell*(ell*ell-2*x*x)/E**4])
   return {'second':float(m2),'third':float(m3),'fourth':float(m4)}
chk('B04-E3-035',native_cumulants,'p4:cor:v247-native-source-work-cumulants')

def cyclic_response():
   X=np.array([[0,0,1],[1,0,0],[0,1,0]],complex)
   c=np.ones(3)/np.sqrt(3);P0=np.outer(c,c);Q=np.eye(3)-P0;C2=-1j*(X-X.conj().T)
   Pp=(Q+C2/np.sqrt(3))/2;Pm=(Q-C2/np.sqrt(3))/2
   ge=np.array([-1-1j,1j,1])/2; gm=np.array([2,-1+3j,-1-3j])/(2*np.sqrt(6))
   a=(2+np.sqrt(3))/4;b=(2-np.sqrt(3))/4;chi=(1-1j)/(4*np.sqrt(2))
   approx([np.vdot(ge,Pp@ge),np.vdot(gm,Pp@gm),np.vdot(ge,Pp@gm)],[a,b,chi])
   G=1.2*Pp+2.3*Pm+.9*P0
   approx(np.array([[np.vdot(ge,G@ge),np.vdot(ge,G@gm)],[np.vdot(gm,G@ge),np.vdot(gm,G@gm)]]),np.array([[a*1.2+b*2.3,chi*(1.2-2.3)],[chi.conjugate()*(1.2-2.3),b*1.2+a*2.3]]))
   return {'a':float(a),'b':float(b),'chi':str(chi),'support_ratio_b_over_a':float(b/a)}
chk('B04-E3-036',cyclic_response,'p4:v251:thm:lepton-cyclic-response')

def cyclic_noncorr():
   X=np.array([[0,0,1],[1,0,0],[0,1,0]],complex);c=np.ones(3)/np.sqrt(3);P0=np.outer(c,c);Q=np.eye(3)-P0;C2=-1j*(X-X.conj().T)
   ge=np.array([-1-1j,1j,1])/2; gm=np.array([2,-1+3j,-1-3j])/(2*np.sqrt(6))
   e2,m2,t2=.15,.42,.98;B=e2*np.outer(ge,ge.conj())+m2*np.outer(gm,gm.conj())+t2*P0
   hs=lambda C:la.norm(B@C-C@B,ord='fro')**2
   approx(hs(C2),1.5*(m2-e2)**2);approx(hs(X),.375*(m2-e2)**2)
   return {'cyclic_defect':float(hs(X))}
chk('B04-E3-037',cyclic_noncorr,'p4:v251:cor:required-noncyclic-content')

def detector_cov():
   rho=state(3);Qminus=.7*np.eye(3);Qh=herm(3);R=herm(3)/3;Qs=-Qh+Qminus+R
   m=lambda A:np.trace(rho@A).real
   cov=lambda A,B:np.trace(rho@((A-m(A)*np.eye(3))@(B-m(B)*np.eye(3))+(B-m(B)*np.eye(3))@(A-m(A)*np.eye(3)))/2).real
   lhs=cov(Qs,Qs)-cov(Qh,Qh)
   rhs=cov(R,R)-2*cov(Qh,R);approx(lhs,rhs)
   err=np.sqrt(cov(R,R));sig=np.sqrt(cov(Qh,Qh));assert abs(lhs)<=err*err+2*sig*err+1e-9
   return {'ward_residual_bound':float(err**2+2*sig*err)}
chk('B04-E3-038',detector_cov,'p4b:thm:v254-in-in-charge-detector-covariance')

def lueders():
   E1=np.diag([.2,.3,.7,.9]);E2=np.eye(4)-E1;rho=state(4)
   Ks=[la.sqrtm(E1),la.sqrtm(E2)];out=sum(K@rho@K.conj().T for K in Ks)
   approx(np.trace(out),1)
   P=np.diag([1,1,0,0]);approx(np.trace(P@out),np.trace(P@rho))
   return 'exact CP Lüders normalization and 2-sector preservation'
chk('B04-E3-039',lueders,'p4b:thm:v266-native-instrument')

def petersen_poles():
   T=np.diag([2,.5,.5]);H=np.block([[np.zeros((3,3)),T],[T,np.zeros((3,3))]])
   eig=np.linalg.eigvalsh(H);approx(eig,[-2,-.5,-.5,.5,.5,2])
   psi=np.array([np.sqrt(.3),np.sqrt(.2),np.sqrt(.5)]);a=psi[0]**2;v=np.r_[psi,np.zeros(3)];z=3.1
   G=np.vdot(v,la.solve(z*np.eye(6)-H,v))
   approx(G,z*(a/(z*z-4)+(1-a)/(z*z-.25)))
   t=.78;W=la.expm(-1j*H*t)@v
   approx(la.norm(W[3:])**2,a*np.sin(2*t)**2+(1-a)*np.sin(t/2)**2)
   return {'a':float(a),'resolvent':float(G.real)}
chk('B04-E3-040',petersen_poles,'p4b:thm:v320-chiral-auxiliary-poles')

def complement_gauge():
   T=np.diag([2,.5,.5]);H=np.block([[np.zeros((3,3)),T],[T,np.zeros((3,3))]]);Z=np.diag([1,1,1,-1,-1,-1]);Hp=Z@H@Z
   approx(Hp,-H);approx(la.eigvalsh(Hp),la.eigvalsh(H))
   v=np.array([1.,0,0,0,0,0]);t=.42;approx(abs(v@la.expm(-1j*H*t)@v)**2,abs(v@la.expm(-1j*Hp*t)@v)**2)
   return 'complement sign conjugation invariant for sector-diagonal input/effect'
chk('B04-E3-041',complement_gauge,'p4b:cor:v320-complement-phase-gauge')

def petersen_interference():
    s1,s2,delta=1,-1,.74
    amp=(s1+np.exp(1j*delta)*s2)/2
    approx(abs(amp)**2,.5*(1+s1*s2*np.cos(delta)))
    return 'Z₂ loop ratio exactly controls two-path normalized fringe'
chk('B04-E3-042',petersen_interference,'p4b:thm:v320-z2-loop-interference')

def onebody_criterion():
    d=3;a,ad=fock_create(d);D=2**d
    B=[np.eye(D)]+[ad[i]@a[j] for i in range(d) for j in range(d)]
    M=np.column_stack([x.flatten() for x in B]);Q,_=la.qr(M,mode='economic')
    O=ad[0]@a[0]@ad[1]@a[1];Y=(O.flatten()-Q@(Q.conj().T@O.flatten())).reshape(D,D);Y=(Y+Y.conj().T)/2
    approx(np.trace(Y),0);approx([np.trace(Y@x) for x in B],np.zeros(len(B)))
    eps=1/(4*D*la.norm(Y,2));rp=np.eye(D)/D+eps*Y;rm=np.eye(D)/D-eps*Y
    assert np.linalg.eigvalsh(rp).min()>0 and np.linalg.eigvalsh(rm).min()>0
    for i in range(d):
      for j in range(d):approx(np.trace(rp@ad[i]@a[j]),np.trace(rm@ad[i]@a[j]))
    assert abs(np.trace((rp-rm)@O))>1e-7
    return {'same_onebody_different_two_body':float(np.trace((rp-rm)@O).real)}
chk('B04-E3-043',onebody_criterion,'p4b:thm:v347-onebody-criterion')

def interacting_three():
    a,ad=fock_create(3); n=[ad[i]@a[i] for i in range(3)];U=.83;dt=.66;H=U*n[0]@n[1]
    A=ad[0]@a[2];B=A.conj().T;Udt=la.expm(-1j*H*dt);At=Udt.conj().T@A@Udt
    K=At@B-B@At
    approx(K,la.expm(1j*U*dt*n[1])@(n[0]-n[2]))
    def ket(s):
      v=np.zeros(8);v[int(s[::-1],2)]=1;return v
    def rhos(seq):return sum(np.outer(ket(s),ket(s)) for s in seq)/len(seq)
    r1=rhos(['110','001']);r2=rhos(['100','011'])
    # Source uses |n1 n2 n3> bit order, ket reversed to physical bit indexing.
    for i in range(3):approx(np.trace(r1@n[i]),np.trace(r2@n[i]))
    f1=np.trace(r1@K);f2=np.trace(r2@K);approx(f1,-f2)
    approx(f1,(np.exp(1j*U*dt)-1)/2)
    return {'response_1':str(f1),'response_2':str(f2)}
chk('B04-E3-044',interacting_three,'p4b:prop:v347-three-mode-response-obstruction')

def majorana_closure():
    # Jordan-Wigner Majorana word basis for d=3, quartic × quadratic commutators.
    a,ad=fock_create(3); gam=[]
    for j in range(3):gam.extend([a[j]+ad[j],1j*(ad[j]-a[j])])
    for i in range(6):approx(gam[i]@gam[i],np.eye(8))
    for i in range(6):
      for j in range(i):approx(gam[i]@gam[j]+gam[j]@gam[i],0)
    def mon(idx):
      X=np.eye(8,dtype=complex)
      for i in idx:X=X@gam[i]
      return X
    words={idx:mon(idx) for r in (0,2,4,6) for idx in itertools.combinations(range(6),r)}
    def degree(M):
      vals={idx:np.trace(W.conj().T@M)/8 for idx,W in words.items()}
      return {len(idx) for idx,v in vals.items() if abs(v)>1e-8}
    for i4 in itertools.combinations(range(6),4):
      for i2 in itertools.combinations(range(6),2):
        a4,b2=words[i4],words[i2]
        assert all(d<=4 for d in degree(a4@b2-b2@a4))
    return {'tested_quartic_vs_quadratic':15*15,'Clifford_max_degree':6}
chk('B04-E3-045',majorana_closure,'p4b:thm:v347-majorana-hierarchy')

def odd_transfer():
    Hp=herm(3);Hm=herm(2);Tmat=rng.normal(size=(3,2))+1j*rng.normal(size=(3,2))
    H=np.block([[Hp,Tmat],[Tmat.conj().T,Hm]])
    e=np.linalg.eigh(Tmat@Tmat.conj().T)[1][:,-1];r=np.outer(e,e.conj());rho=la.block_diag(r,np.zeros((2,2)))
    t=1e-4;U=la.expm(-1j*H*t);Pm=np.diag([0,0,0,1,1]);p=np.trace(Pm@U@rho@U.conj().T).real
    target=np.trace(r@Tmat@Tmat.conj().T).real
    approx(p/t**2,target,2e-3)
    approx(target,la.norm(Tmat,2)**2)
    return {'transition_coefficient':float(target)}
chk('B04-E3-046',odd_transfer,'p4b:prop:v347-odd-transfer-witness')

def krylov():
    eig=np.array([0.,.7,1.2,3.]);H=np.diag(eig)
    v=np.array([0.,1.,.6,.2]);v=v/la.norm(v);A=H[1:,1:]
    K=np.column_stack([np.linalg.matrix_power(A,k)@v[1:] for k in range(3)])
    Q,_=la.qr(K,mode='economic');Tmat=Q.conj().T@A@Q
    val=2*v[1:]@np.linalg.matrix_power(A,-3)@v[1:]
    val2=2*la.norm(v[1:])**2*np.linalg.matrix_power(Tmat,-3)[0,0]
    approx(val,val2)
    return {'inverse_cube_response':float(val),'cyclic_dimension':3}
chk('B04-E3-047',krylov,'p4b:thm:v356-current-visible-krylov')

result={'artifact':'Paper4B-Batch04Checks-v1_1.json','source':'Paper4B-QuantumResponse-v1_42.tex','source_sha256':hashlib.sha256((ROOT/'source_current/Paper4B-QuantumResponse-v1_42.tex').read_bytes()).hexdigest(),'tests':T,'passed':sum(bool(t['passed']) for t in T),'failed':sum(not t['passed'] for t in T),'important_scope_limit':'E3/E4 checks verify displayed algebraic subclaims/examples on source-admitted domains only. They neither supply physical constructors nor certify all theorems for every input.'}
OUT.write_text(json.dumps(result,indent=2,ensure_ascii=False,default=str))
print(f"TESTS: passed={result['passed']}, failed={result['failed']}")
for x in T:
 if not x['passed']:print('FAIL',x['id'],x['scope'],x['error'])
if result['failed']: raise SystemExit(1)
