# Paper IV-B Rigorous DAG Verification — Batch 01 (checkpoint)
**Artifact:** `Paper4B-RigorousBatch01-v1_1.md`  |  **Protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md`  |  **Current corpus:** framework v2.370
**Authoritative source:** `Paper4B-QuantumResponse-v1_42.tex`; SHA256 `df22fe3ff5b4cf70429e04761324b61a5d0119ac1396b9ab87313f2acc90291e`. Same contents in the supplied v1.105 Atlas source snapshot.
**Scope:** source lines 65–2240, first two main sections, up to but not including “Complete action-generated finite clock evolution.”
**Audited:** 39/227 named items, 29/176 proofs; status tally {'REPRODUCED': 11, 'FORMALIZED': 7, 'VERIFIED': 3, 'VERIFIED-CONDITIONAL': 18}. These are batch-local dispositions, **not** a full IV-B audit.
**Checks:** 14/14 executable symbolic/matrix/boundary tests passed; tests are not themselves global physical-occurrence certificates. No independently running agents were available.
**Confirmed mathematical/source-logic issues in this batch:** none. Any E3/E4 work still pending is an evidence limitation, not a demonstrated error.

## Exact source-level verification results
Finite center projection is 0/I; stationary Hessian yields symplectic-compatible complex structure; finite exact CCR impossible but vacuum/one-particle covariance remains exact; fixed vectorlike paired measure and doubled Pfaffian algebra check; finite source-pressure and constrained-energy dual hold on their stated complete physical carrier; canonical Ward defects and passive time-pullback have source-consistent conditional identities; GP1 forces a finite retained occupation set but not a numerical/generated cutoff; the same-carrier Euclidean semigroup criterion requires whitening; the primitive same-owner dispersion square root and finite Green kernels are mathematical consequences on explicitly imported scopes.

**Important firewall:** No statement in this batch proves a generic `\mathsf{1P}`, `\mathsf{STAT}`, `\mathsf{OCC}`, actual `\mathsf{DYN}`/history, Euclidean same-carrier compatibility, or physical field occurrence from finite kinematics alone. The source explicitly keeps these distinct. No previously discharged `m_p=1` or H1 theorem was reopened.

## Evidence limitations carried forward (not yet gap IDs)
- `p4:prop:native-qft-status` (`:352–402`): its ledger imports many IV-C theorems; label resolution is complete, but those external proof bodies have not been independently reaudited for this batch. Status: `REPRODUCED`.
- `p4:thm:v4106-functional-hilbert-response` through `p4:thm:v4118-homogeneous-time-ward` (`:985–1397`): E1 operator identities match the printed proofs; independently verified only selected algebraic/single-source controls, **not** the entire marked interacting metric-source constructor on all licensed branches. These claims remain `REPRODUCED`, rather than falsely `VERIFIED`.
- `p4:lem:second-order-free-collapse` (`:1783–1818`): the free-law and no-drift scopes have been checked against the actual III-E statement; the inference needs the imported smooth-parent self-adjoint local-law branch, not arbitrary finite functional calculus. Status `REPRODUCED` pending exhaustive E3.
- The existing III-F audit’s five registered issues were consulted for the actual imported labels `p3f:thm:v1148-finite-metric-constructor` and `p3f:thm:v244-stationary-physical-hessian-propagation`; no *certified* material gap path from those five issues to the two imported premises was established in this batch. A citation alone was not promoted.

## Claim-by-claim source and status census
| # | Source line | Kind | Source label | Status | E1 proof |
|--:|--:|---|---|---|:---:|
| 1 | 352 | PROPOSITION | `p4:prop:native-qft-status` | REPRODUCED | yes |
| 2 | 404 | REMARK | `p4:rem:qft-postulate-boundary` | FORMALIZED | — |
| 3 | 475 | PROPOSITION | `p4:prop:bare-algebra-one-particle-no-selector` | VERIFIED | yes |
| 4 | 494 | THEOREM | `p4:thm:stationary-positive-frequency-mode-space` | VERIFIED-CONDITIONAL | yes |
| 5 | 546 | THEOREM | `p4:thm:v245-hessian-kahler-projective-geometry` | VERIFIED-CONDITIONAL | yes |
| 6 | 651 | PROPOSITION | `p4:prop:no-exact-ccr` | VERIFIED | yes |
| 7 | 674 | THEOREM | `p4:thm:v245-finite-free-vacuum-covariance` | VERIFIED-CONDITIONAL | yes |
| 8 | 737 | PROPOSITION | `p4:prop:paired-berezin-determinant-line` | VERIFIED-CONDITIONAL | yes |
| 9 | 767 | COROLLARY | `p4:cor:v489-fixed-carrier-gauge-jacobian-cancellation` | VERIFIED-CONDITIONAL | yes |
| 10 | 792 | REMARK | `p4:rem:v489-fixed-versus-chiral-line` | FORMALIZED | — |
| 11 | 802 | THEOREM | `p4:thm:parallel-line-trivialization` | REPRODUCED | yes |
| 12 | 833 | REMARK | `p4:rem:parallel-line-chiral-firewall` | FORMALIZED | — |
| 13 | 842 | COROLLARY | `p4:cor:doubled-pfaffian-presentation` | VERIFIED | yes |
| 14 | 860 | THEOREM | `p4:thm:finite-fermion-clock-real-form` | VERIFIED-CONDITIONAL | yes |
| 15 | 908 | THEOREM | `p4:thm:finite-energy-source-certificate` | VERIFIED-CONDITIONAL | yes |
| 16 | 936 | COROLLARY | `p4:cor:finite-constrained-energy-duality` | VERIFIED-CONDITIONAL | yes |
| 17 | 985 | THEOREM | `p4:thm:v4106-functional-hilbert-response` | REPRODUCED | yes |
| 18 | 1061 | COROLLARY | `p4:cor:v4106-moving-carrier-contact` | REPRODUCED | yes |
| 19 | 1106 | THEOREM | `p4:thm:v4106-canonical-stress-ward` | REPRODUCED | yes |
| 20 | 1207 | THEOREM | `p4:thm:v4118-passive-clock-pullback` | REPRODUCED | yes |
| 21 | 1286 | THEOREM | `p4:thm:v4118-homogeneous-time-ward` | REPRODUCED | yes |
| 22 | 1343 | COROLLARY | `p4:cor:v4118-homogeneous-source-work` | REPRODUCED | yes |
| 23 | 1400 | PROPOSITION | `p4:prop:v2174-occupation-phase-moment` | VERIFIED-CONDITIONAL | yes |
| 24 | 1448 | REMARK | `UNLABELED:Paper4B:remark:1448` | FORMALIZED | — |
| 25 | 1465 | THEOREM | `p4:thm:gp1-bosonic-occupation-boundary` | VERIFIED-CONDITIONAL | yes |
| 26 | 1528 | COROLLARY | `p4:cor:occupation-cutoff-saturation` | VERIFIED-CONDITIONAL | yes |
| 27 | 1614 | DEFINITION | `p4:def:intrinsic-finite-spectral-block` | FORMALIZED | — |
| 28 | 1629 | REMARK | `p4:rem:reeb-polarization-not-time-frequency` | FORMALIZED | — |
| 29 | 1647 | LEMMA | `p4:lem:positive-frequency-generator-from-euclidean-block` | VERIFIED-CONDITIONAL | yes |
| 30 | 1728 | DEFINITION | `p4:def:minimal-uninserted-free-scalar-cover-domain` | FORMALIZED | — |
| 31 | 1783 | LEMMA | `p4:lem:second-order-free-collapse` | REPRODUCED | yes |
| 32 | 1819 | LEMMA | `p4:lem:scalar-cover-speed-normalization` | VERIFIED-CONDITIONAL | yes |
| 33 | 1858 | COROLLARY | `p4:cor:finite-inherited-operational-speed` | REPRODUCED | — |
| 34 | 1877 | THEOREM | `p4:thm:finite-one-particle-dispersion` | VERIFIED-CONDITIONAL | yes |
| 35 | 1993 | THEOREM | `p4:thm:pure-scalar-factor-representation` | VERIFIED-CONDITIONAL | yes |
| 36 | 2029 | COROLLARY | `p4:cor:stationary-free-law-dyn-law-closure` | REPRODUCED | — |
| 37 | 2048 | THEOREM | `p4:thm:stationary-quadratic-real-form-pair` | VERIFIED-CONDITIONAL | yes |
| 38 | 2140 | THEOREM | `p4:thm:v244-action-generated-schrodinger-form` | VERIFIED-CONDITIONAL | yes |
| 39 | 2206 | COROLLARY | `p4:cor:v244-generated-green-operators` | VERIFIED-CONDITIONAL | — |

## Evidence and integrity
- Every source claim object, exact LaTeX statement, proof span, source locator, resolved references, and reported E3/E4 lineage is preserved in `Paper4B-Batch01Ledger-v1_1.json`.
- Automated tests: `Paper4B-Batch01Checks-v1_1.py` with its JSON certificate. All 14 tests passed; sampled 2×2 checks are E2 controls, not independent proof of a universal identity.
- The union of source labels across all 31 TeX roots is unique; no missing IV-B `\ref`/`\eqref` labels were found. Import source scope is not established merely by name resolution.
- No source or supplied ZIP was altered. Final archive integration must take place after completing the remaining batches, with latest-only DAG and audit ZIP validation.
