#!/usr/bin/env python3
"""Reproducible E2/E3/E4 checks, Paper IV-B lines 4711--7996 (not a universal theorem oracle).
Source-first independent finite realizations; no source/ZIP modifications.
"""
import json, itertools, math, pathlib, hashlib, traceback
import numpy as np
from scipy.linalg import expm
r=np.random.default_rng(20261112)
checks=[]

def chk(cid, fn, scope, level='E3'):
    try:
        detail=fn()
        checks.append({'id':cid,'level':level,'scope':scope,'passed':True,'result':detail})
    except Exception as exc:
        checks.append({'id':cid,'level':level,'scope':scope,'passed':False,'error':repr(exc),'trace':traceback.format_exc(limit=2)})

def close(a,b,atol=1e-9):
    a,b=np.asarray(a),np.asarray(b)
    err=np.max(np.abs(a-b))
    assert err<atol, f'error={err}, {a}, {b}'
    return float(err)

def car(n):
    d=2**n; ans=[]
    for k in range(n):
        a=np.zeros((d,d),complex)
        for s in range(d):
            if s & (1<<k):
                a[s^(1<<k),s]=(-1)**((s & ((1<<k)-1)).bit_count())
        ans.append(a)
    return ans

def complex_array(dim):
    return r.normal(size=dim)+1j*r.normal(size=dim)

def herm(n):
    x=complex_array((n,n));return (x+x.conj().T)/2

def prop_block():
    p0=np.diag([1,1,0]);p1=np.eye(3)-p0
    a=herm(3); d=p0@a@p0+p1@a@p1
    close(d@p0,p0@d);close(d@p1,p1@d)
    U=expm(-.31j*d);close(U@p1,p1@U)
    assert np.linalg.norm(p0@a@p1)>1e-4
    return '2+1 projector decomposition, block dynamics and off-diagonal mixing'
chk('E3-B03-SECTOR-BLOCK',prop_block,'p4:thm:sector-compatible-observables')

def trace_weyl():
    z=np.diag(np.exp(2j*np.pi*np.arange(3)/3)); x=np.roll(np.eye(3),1,axis=0)
    for a,b in itertools.product(range(3),repeat=2):
        if (a,b)!=(0,0):close(np.trace(np.linalg.matrix_power(x,a)@np.linalg.matrix_power(z,b)),0)
    close(np.trace((x@z)@(x@z).conj().T)/3,1)
    return 'all eight nontrivial rank-3 Weyl characters are traceless'
chk('E3-B03-WEYL-TRACE',trace_weyl,'p4:prop:trace-neutral-finite-word-selection')

def tensor_family():
    v=complex_array((6,));v=v/np.linalg.norm(v);rho=np.outer(v,v.conj());red=np.einsum('iaib->ab',rho.reshape(2,3,2,3));
    for k in range(3):close(np.trace(rho@np.kron(np.eye(2),np.diag([int(i==k) for i in range(3)]))),red[k,k])
    return 'pure entangled ext(2)x family(3) reduced state/Born probabilities'
chk('E3-B03-FAMILY-PARTIAL-TRACE',tensor_family,'p4:prop:finite-family-factors')

def sector_dyson():
    H0=np.diag([.7,1.4]);V=np.array([[0,.23+.1j],[.23-.1j,0]])
    t=.6;alpha,beta=0,1
    f=-1j*V[beta,alpha]*np.expm1(1j*(H0[beta,beta]-H0[alpha,alpha])*t)/(1j*(H0[beta,beta]-H0[alpha,alpha]))
    eps=1e-5;U=expm(-1j*(H0+eps*V)*t); amp=U[beta,alpha]*np.exp(1j*H0[beta,beta]*t)/eps
    return {'difference':close(f,amp,atol=2e-6)}
chk('E3-B03-SECTOR-DYSON',sector_dyson,'p4:prop:finite-sector-transition')

def offshell():
    omega=1.4;f=lambda t:np.expm1(1j*omega*t)/(1j*omega)
    assert abs(f(10000))<=2/omega+1e-8
    assert abs(f(10000))/10000<2e-4
    return 'bounded finite detuning amplitude; long-time normalized rate tends to zero'
chk('E3-B03-FINITE-THRESHOLD',offshell,'p4:prop:finite-threshold')

def unitary_mix():
    A=herm(3);B=herm(3);_,U=np.linalg.eigh(A);_,V=np.linalg.eigh(B);W=U.conj().T@V;close(W.conj().T@W,np.eye(3));
    return 'rank-3 unitary relative diagonalization'
chk('E3-B03-FINITE-MIXING',unitary_mix,'p4:thm:finite-multiplet-mixing')

a=car(2);ad=[x.conj().T for x in a];Id=np.eye(4)

def pair(D):return sum(D[i,j]*ad[i]@ad[j] for i in range(2) for j in range(2))/2

def pair_comm():
    D=np.array([[0,.2+.4j],[-.2-.4j,0]]);E=np.array([[0,.6-.1j],[-.6+.1j,0]])
    lhs=pair(D)@pair(E).conj().T-pair(E).conj().T@pair(D)
    rhs=sum((D@E.conj().T)[i,j]*ad[i]@a[j] for i in range(2) for j in range(2))-np.trace(D@E.conj().T)*Id/2
    return {'err':close(lhs,rhs)}
chk('E3-B03-CAR-PAIR-COMM',pair_comm,'p4:lem:v2167-pair-commutator')

def pair_charge():
    D=np.array([[0,.31+.22j],[-.31-.22j,0]]);A=2*pair(D);H=(A+A.conj().T)/2
    Q=-(ad[0]@a[0]+ad[1]@a[1]);psi=np.array([1,1j,.3,.7j]);psi=psi/np.linalg.norm(psi);rho=np.outer(psi,psi.conj())
    lhs=1j*np.trace(rho@(H@Q-Q@H));rhs=-2*np.imag(np.trace(rho@A))
    dth=.00001;th=.37
    Hth=(np.exp(1j*th)*A+np.exp(-1j*th)*A.conj().T)/2
    grad=(np.exp(1j*(th+dth))*A+np.exp(-1j*(th+dth))*A.conj().T-np.exp(1j*(th-dth))*A-np.exp(-1j*(th-dth))*A.conj().T)/(4*dth)
    lhs2=1j*np.trace(rho@(Hth@Q-Q@Hth));rhs2=2*np.trace(rho@grad)
    return {'Qdot':close(lhs,rhs), 'phaseWard':close(lhs2,rhs2)}
chk('E3-B03-PAIR-CHARGE-SOURCE',pair_charge,'p4:thm:v4102-pair-charge-source')

def nambu_car_cov():
    h=np.array([[.7,.2+.13j],[.2-.13j,.35]])
    D=np.array([[0,.25-.1j],[-.25+.1j,0]])
    A=2*pair(D);H=sum(h[i,j]*ad[i]@a[j] for i in range(2) for j in range(2))+(A+A.conj().T)/2
    m=np.block([[h,D],[D.conj().T,-h.T]])
    Psi=a+ad
    for i in range(4):close(Psi[i]@H-H@Psi[i],sum(m[i,j]*Psi[j] for j in range(4)))
    psi=complex_array((4,));psi=psi/np.linalg.norm(psi);rho=np.outer(psi,psi.conj());t=.61
    U=expm(-1j*H*t);rt=U@rho@U.conj().T;um=expm(-1j*m*t)
    R=lambda rr:np.array([[np.trace(rr@Psi[j].conj().T@Psi[i]) for j in range(4)] for i in range(4)])
    close(R(rt),um@R(rho)@um.conj().T)
    q=np.diag([.2,-.6]); Q=sum(q[i,j]*ad[i]@a[j] for i in range(2) for j in range(2))
    Qm=np.block([[q,np.zeros((2,2))],[np.zeros((2,2)),-q.T]])
    close(np.trace(rt@Q),.5*np.trace(Qm@R(rt))+.5*np.trace(q))
    close(1j*np.trace(rho@(H@Q-Q@H)),np.trace((Qm@m-m@Qm)@R(rho))/(2j))
    return 'complete BdG evolution and charge trace against finite Fock dynamics'
chk('E3-B03-NAMBU-CAR-COV',nambu_car_cov,'p4:thm:v4102-finite-car-charge-propagation')

def pair_phase():
    D=np.array([[0,1],[-1,0]],complex); theta=.37;thetap=.42;a0=.8;ap=.31;conn=.15
    Delta=a0*np.exp(1j*theta)*D
    Ddt=np.exp(1j*theta)*(ap+1j*a0*(thetap-conn))*D
    lhs=np.imag(np.trace(Delta.conj().T@Ddt));rhs=np.vdot(D,D).real*a0*a0*(thetap-conn)
    return {'err':close(lhs,rhs)}
chk('E3-B03-COVARIANT-PAIR-PHASE',pair_phase,'p4:cor:v498-phase-locked-pairing-invariant')

def arbitrary_pair_dyson():
    # Arbitrary state, two noncommuting time windows; compute Dyson coefficients as matrix commutators.
    D1=np.array([[0,.41+.1j],[-.41-.1j,0]]);D2=np.array([[0,-.25+.3j],[.25-.3j,0]])
    V1=pair(D1)+pair(D1).conj().T;V2=pair(D2)+pair(D2).conj().T
    psi=complex_array((4,));psi/=np.linalg.norm(psi);rho=np.outer(psi,psi.conj())
    q=-(ad[0]@a[0]+ad[1]@a[1]);B=(D1+D2)
    C=np.array([[np.trace(rho@ad[j]@a[i]) for j in range(2)] for i in range(2)])
    F=np.array([[np.trace(rho@ad[i]@ad[j]) for j in range(2)] for i in range(2)])
    q1=-4*np.imag(np.trace(rho@pair(B)))
    q2=np.trace((2*C-np.eye(2))@B@B.conj().T).real
    # evolution U=e^-i(lambda V2)e^-i(lambda V1), λ measured on both slots with ℏ=1
    epsilon=1e-4
    f=lambda l:np.trace((expm(-1j*l*V2)@expm(-1j*l*V1))@rho@(expm(-1j*l*V1).conj().T@expm(-1j*l*V2).conj().T)@q).real
    q1num=(f(epsilon)-f(-epsilon))/(2*epsilon)
    q2num=(f(epsilon)+f(-epsilon)-2*f(0))/(2*epsilon**2)
    # Source q1 formula F_{ij}=omega(a_i†a_j†), yes
    close(q1,q1num,atol=2e-7)
    close(q2,q2num,atol=2e-6)
    close(q1,-2*np.imag(np.sum(B*F)),atol=1e-10)
    return {'linear_err':abs(q1-q1num),'quadratic_err':abs(q2-q2num)}
chk('E3-B03-PAIR-DYSON-ARBITRARY-STATE',arbitrary_pair_dyson,'p4:thm:v2167-inherited-pair-coefficients')

def pair_return():
    # 4D spatial pair, 2D embedded pair, time-dependent isometric charts.
    U0,_=np.linalg.qr(complex_array((4,4)));U1,_=np.linalg.qr(complex_array((4,4)))
    Jt=U0[:,:2];Js=U1[:,:2]
    V,_=np.linalg.qr(complex_array((4,4)))
    Dt=np.array([[0,.4+.17j],[-.4-.17j,0]]);Ds=np.array([[0,-.2+.5j],[.2-.5j,0]])
    Gt=Jt@Dt@Jt.T;Gs=Js@Ds@Js.T
    lhs=np.trace(Gt.conj().T@V@Gs@V.T)
    Vr=Jt.conj().T@V@Js
    rhs=np.trace(Dt.conj().T@Vr@Ds@Vr.T)
    return {'err':close(lhs,rhs)}
chk('E3-B03-PAIR-RETURN-ISOMETRY',pair_return,'p4:cor:v2167-returned-pair-kernel')

def stationary_quotient():
    H=np.diag([0,0,1.5]);rho=np.diag([.3,.7,0]);X=complex_array((3,3));Y=complex_array((3,3))
    inner=lambda A,B:np.trace(rho@(A.conj().T@B+B@A.conj().T))
    L=lambda A:H@A-A@H
    close(inner(X,L(Y)),inner(L(X),Y))
    null=np.zeros((3,3));null[2,2]=1
    close(inner(null,null),0);close(inner(L(null),L(null)),0)
    return 'stationary Liouvillian quotient self-adjoint and null-invariant'
chk('E3-B03-STATIONARY-QUOTIENT',stationary_quotient,'p4:prop:v2168-stationary-source-quotient')

def dynamical_fidelity():
    eps=np.array([.7,1.3]);D=np.diag(eps**2)
    # Self-adjoint cyclic source/memory realization, 2 source + 2 partner
    B=np.diag(eps)
    L=np.block([[np.zeros((2,2)),B],[B,np.zeros((2,2))]])
    Q=np.vstack([np.eye(2),np.zeros((2,2))])
    mu=lambda k:Q.T@np.linalg.matrix_power(L,k)@Q
    Xi=np.linalg.matrix_power(L,2)@Q-Q@D
    close(mu(1),0);close(Xi,0);close(mu(2),D);close(mu(4),D@D)
    z=1.7+1j*.6
    close(Q.T@np.linalg.inv(z*np.eye(4)-L)@Q,np.diag(z/(z*z-eps*eps)))
    C=np.array([[.21,.12],[.12,-.08]])
    L2=np.block([[np.zeros((2,2)),B],[B,C]])
    mu2=lambda k:Q.T@np.linalg.matrix_power(L2,k)@Q
    close(mu2(2),D);close(mu2(4)-D@D,(C@B).conj().T@(C@B))
    assert np.min(np.linalg.eigvalsh(mu2(4)-D@D))>=-1e-10
    return 'free-fidelity equivalence and positive fourth-moment leakage'
chk('E3-B03-DYNAMIC-FIDELITY',dynamical_fidelity,'p4:thm:v2168-dynamical-fidelity; p4:cor:v2168-positive-source-leakage')

def family_stationarity():
    H=np.diag([0,0,2]);K=np.array([[1.,0.,0.],[0.,-1.,0.],[0.,0.,0.]])
    pinched=K.copy()
    rho1=np.diag([.5,.5,0]);rho2=np.diag([1.,0,0]);
    close(np.trace(rho1@K),0)
    assert abs(np.trace(rho2@K))>0
    assert np.linalg.norm(pinched)>0
    return 'single stationary density trace-zero cannot replace whole stationary-family pinching test'
chk('E4-B03-FAMILY-STATIONARITY-BOUNDARY',family_stationarity,'p4:thm:v2168-stationary-family-fidelity', 'E4')

def weak_slater():
    # 2 charged modes + 2 neutral, 2x2 boson, occupied charged mode 0 only.
    f=car(4);fd=[x.conj().T for x in f];O=np.zeros((16,16));Omega=np.zeros((16,),complex);Omega[1]=1
    T1=np.array([[.3+.2j,.4],[.7j,-.2]],complex)
    T2=np.array([[-.2j,.6],[.1+.2j,.15]],complex)
    X1=herm(2)+.4j*np.array([[0,1],[-1,0]]) # Hermitian
    X2=herm(2)
    assert np.max(abs(X1-X1.conj().T))<1e-9
    vs=[]
    for T,X in ((T1,X1),(T2,X2)):
        A=sum(T[i,j]*fd[i+2]@f[j] for i in range(2) for j in range(2))
        vs.append(np.kron(A,X)+np.kron(A.conj().T,X.conj().T))
    V=np.pi*sum(vs)
    pb=np.eye(2);P=np.kron(np.outer(Omega,Omega.conj()),pb)
    exact=P@V@V@P
    Fe=np.diag([1,0]);Fn=np.zeros((2,2));Ms=[(np.eye(2)-Fn)@T@Fe for T in [T1,T2]]
    Ns=[(np.eye(2)-Fe)@T.conj().T@Fn for T in [T1,T2]]
    xs=[X1,X2]
    rhs=np.zeros((2,2),complex)
    for i,j in itertools.product(range(2),repeat=2):
        rhs+=np.trace(Ms[i].conj().T@Ms[j])*xs[i].conj().T@xs[j]
        rhs+=np.trace(Ns[i].conj().T@Ns[j])*xs[i]@xs[j].conj().T
    close(exact,np.kron(np.outer(Omega,Omega.conj()),np.pi**2*rhs))
    assert np.min(np.linalg.eigvalsh(rhs))>-1e-9
    return 'two external slots with distinct noncommuting bosonic coefficient words and mixed alpha/beta cross terms'
chk('E3-B03-WEAK-SLATER-LEAKAGE',weak_slater,'p4:v2169:b11:thm:weakslater')

def filled_chiral():
    R=np.diag([.4,1.5,2.1])@expm(1j*herm(3)*.2)
    h=np.block([[np.zeros((3,3)),R],[R.conj().T,np.zeros((3,3))]])
    w,u=np.linalg.eigh(h);Fe=u@np.diag((w<0).astype(float))@u.conj().T
    close(Fe[:3,:3],np.eye(3)/2)
    T=np.hstack([np.eye(3),np.zeros((3,3))]);Fn=np.zeros((3,3))
    eta=np.trace(T@Fe@T.conj().T@(np.eye(3)-Fn));close(eta,1.5)
    return 'filled negative-energy Dirac chiral compression equals I3/2 independent of polar unitary'
chk('E3-B03-FILLED-CHIRAL-LEAKAGE',filled_chiral,'p4:v2169:b11:thm:weakslater, filled chiral branch')

def adjacent_degree():
    a=car(2);ad=[x.conj().T for x in a];N=sum(ad[i]@a[i] for i in range(2));
    h=np.array([[.8,.3],[.3,1.1]]);H=sum(h[i,j]*ad[i]@a[j] for i in range(2) for j in range(2))+.4*ad[0]@ad[1]@a[1]@a[0]
    close(N@H,H@N)
    P=np.zeros((4,4));P[0,0]=1;q=ad[0];L=lambda X:H@X-X@H
    def resolvent(z):
        # direct 4x4^2 Liouville inverted on source
        v=q.copy();x=np.zeros((4,4),complex)
        for m in range(0,45):
            x+=v/z**(m+1);v=L(v)
        return np.trace(P@(q.conj().T@x+x@q.conj().T))
    z=3.8+2j
    target=(np.linalg.inv(z*np.eye(2)-h))[0,0]
    # direct trace expansion converges for |z|>||ad_H||; finite z bigger than eigen spacing
    close(resolvent(z),target,atol=1e-8)
    return 'empty-state response addition leg; quartic full Hamiltonian absent only on exact n=0,1 source path'
chk('E3-B03-ADJACENT-DEGREE',adjacent_degree,'p4:v2169:b12:thm:adjacentnumber; p4:v2169:b12:cor:onefermion')

def finite_flow():
    H1=np.array([[0,.23],[.23,.4]]);H2=np.array([[.8,0],[0,-.5]]);Q=np.diag([1.,-1.]);
    E=[np.eye(2),Q,np.array([[0,1],[1,0.]]),np.array([[0,-1j],[1j,0.]])]
    t=.17;rho=np.array([[.7,.12j],[-.12j,.3]]);H=.6*H1+1.2*H2
    x=np.array([np.trace(rho@k).real for k in E]);
    derivative=np.array([np.trace(rho@(1j*(H@k-k@H))).real for k in E]);
    eps=1e-6;U=expm(-1j*H*eps);new=U@rho@U.conj().T
    close((np.array([np.trace(new@k).real for k in E])-x)/eps,derivative,atol=3e-6)
    return 'complete Hermitian test-span expectation dynamics agrees with exact Schrödinger evolution'
chk('E3-B03-LEAST-CHARGE-FLOW',finite_flow,'p4:v2171:thm:flow; p4:v2171:thm:fullcharge')

def cap_ops(d,N):
    states=[t for k in range(N+1) for t in itertools.product(range(k+1),repeat=d) if sum(t)==k]
    ix={t:i for i,t in enumerate(states)};aa=[]
    for v in range(d):
        T=np.zeros((len(states),len(states)),complex)
        for t,i in ix.items():
            if t[v]:
                u=list(t);u[v]-=1;T[ix[tuple(u)],i]=np.sqrt(t[v])
        aa.append(T)
    return states,aa

def cap_comm():
    out=[]
    for N in (1,2,3):
        d=4;states,aa=cap_ops(d,N);ad=[x.conj().T for x in aa]
        # i- =0,i+ =1,j- =2,j+=3
        Xi=ad[0]+aa[1];Xj=ad[2]+aa[3]
        lhs=Xi@Xj-Xj@Xi
        P=np.diag([int(sum(x)==N) for x in states]);rhs=P@(ad[0]@aa[3]-ad[2]@aa[1])@P
        close(lhs,rhs)
        tau=np.trace(lhs.conj().T@lhs)/len(states)
        close(tau,2*N/(d+1));out.append((N,float(tau.real)))
    return {'N_and_tracenorm':out}
chk('E3-B03-CAP-COMMUTATOR',cap_comm,'p4:v2171:thm:capcommutator')

def hamiltonian_bilinear_C1():
    af=car(2);afd=[x.conj().T for x in af];Nb=2;h=herm(2);T=[herm(2),herm(2)];X=[herm(2),herm(2)]
    O=np.eye(4);B=np.eye(2)
    H=np.kron(sum(h[i,j]*afd[i]@af[j] for i in range(2) for j in range(2)),B)+np.kron(O,herm(2))
    # need consistency H_B retained separately
    HB=herm(2);H=np.kron(sum(h[i,j]*afd[i]@af[j] for i in range(2) for j in range(2)),B)+np.kron(O,HB)
    for t,x in zip(T,X):H+=np.kron(sum(t[i,j]*afd[i]@af[j] for i in range(2) for j in range(2)),x)
    j=np.array([1.,.2j]);q=sum(j[k]*afd[k] for k in range(2));q=np.kron(q,B)
    C1=H@(H@q-q@H)-(H@q-q@H)@H
    # separately calculate printed C1, including last noncommuting term
    adagv=lambda v:sum(v[k]*afd[k] for k in range(2));dg=lambda t:sum(t[k,l]*afd[k]@af[l] for k in range(2) for l in range(2))
    rhs=np.kron(adagv(h@h@j),B)
    for t,x in zip(T,X):rhs+=np.kron(adagv((h@t+t@h)@j),x)+np.kron(adagv(t@j),HB@x-x@HB)
    for alpha,beta in itertools.product(range(2),repeat=2):
        rhs+=np.kron(adagv(T[beta]@T[alpha]@j),X[beta]@X[alpha])
        rhs+=np.kron(adagv(T[alpha]@j)@dg(T[beta]),X[beta]@X[alpha]-X[alpha]@X[beta])
    return {'err':close(C1,rhs)}
chk('E3-B03-NONCOMMUTING-PORT-C1',hamiltonian_bilinear_C1,'p4:thm:v2168-bilinear-source-commutators')

def coeff_pairing():
    af=car(2);afd=[x.conj().T for x in af];v=complex_array((2,));w=complex_array((2,));F=complex_array((3,3));G=complex_array((3,3));
    O=np.kron(sum(v[i]*afd[i] for i in range(2)),F)
    P=np.kron(sum(w[i]*afd[i] for i in range(2)),G)
    psi=complex_array((12,));psi/=np.linalg.norm(psi);rho=np.outer(psi,psi.conj());
    lhs=np.trace(rho@(O.conj().T@P+P@O.conj().T))
    # a(v) means complex conjugated v; inner product v†w
    av=sum(v[i].conjugate()*af[i] for i in range(2))
    aw=sum(w[i]*afd[i] for i in range(2))
    rhs=np.vdot(v,w)*np.trace(rho@np.kron(np.eye(4),F.conj().T@G))
    rhs+=np.trace(rho@np.kron(aw@av,G@F.conj().T-F.conj().T@G))
    return {'err':close(lhs,rhs)}
chk('E3-B03-ENTANGLED-COEFF-PAIRING',coeff_pairing,'p4:prop:v2168-coefficient-pairing')

def commuting_gram():
    # commuting ports, entangled rho diagonal in their common eigenbasis
    j=np.array([1.,0.]);J=j[:,None]; h=herm(2);T=[herm(2),herm(2)]; x1=np.diag([-.3,.9]);x2=np.diag([.8,-.2]);X=[x1,x2]
    af=car(2);afd=[y.conj().T for y in af];rho0=np.eye(8)/8 # not necessarily stationary for H1 if T X coupling; use H1 Gibbs
    HF=sum(h[i,j]*afd[i]@af[j] for i in range(2) for j in range(2)); H=np.kron(HF,np.eye(2))
    for t,x in zip(T,X):H+=np.kron(sum(t[i,j]*afd[i]@af[j] for i in range(2) for j in range(2)),x)
    rho=expm(-.6*H);rho/=np.trace(rho)
    q=np.kron(sum(j[k]*afd[k] for k in range(2)),np.eye(2))
    L=lambda A:H@A-A@H
    mu1=np.trace(rho@(q.conj().T@L(q)+L(q)@q.conj().T))
    mu2=np.trace(rho@(L(q).conj().T@L(q)+L(q)@L(q).conj().T))
    m=[np.trace(rho@np.kron(np.eye(4),x)).real for x in X]
    barh=h+sum(x*t for x,t in zip(m,T))
    cov=np.array([[np.trace(rho@np.kron(np.eye(4),(x-m[i]*np.eye(2))@(y-m[k]*np.eye(2)))).real for k,y in enumerate(X)] for i,x in enumerate(X)])
    mu1expect=(J.conj().T@barh@J)[0,0]
    mu2expect=(J.conj().T@barh@barh@J)[0,0]+sum(cov[i,k]*(J.conj().T@T[i]@T[k]@J)[0,0] for i in range(2) for k in range(2))
    close(mu1,mu1expect);close(mu2,mu2expect)
    assert np.min(np.linalg.eigvalsh(cov))>=-1e-10
    return 'stationary entangled boson/fermion Gibbs state; correct covariance return without independence'
chk('E3-B03-COMMUTING-PORT-MEMORY',commuting_gram,'p4:thm:v2168-commuting-port-memory-gram')

def schur_stieltjes():
    a0=.4;C=np.diag([-1.2,.2,1.7]);b=np.array([.3,0,.7]);H=np.block([[np.array([[a0]]),b[None,:]],[b[:,None],C]])
    z=.5+.4j;direct=np.linalg.inv(z*np.eye(4)-H)[0,0]
    expected=1/(z-a0-b@np.linalg.inv(z*np.eye(3)-C)@b)
    close(direct,expected)
    ew,U=np.linalg.eigh(H)
    visible=[(ew[i],abs(U[0,i])**2) for i in range(4) if abs(U[0,i])**2>1e-9]
    assert len(visible)==3
    for pole,w in visible:
        formula=1/(1+(.3/(pole+1.2))**2+(.7/(pole-1.7))**2)
        close(w,formula)
    close(sum(w for _,w in visible),1)
    return 'm=2 coupled complement modes, one decoupled dark mode, three real positive-residue poles'
chk('E3-B03-ONE-SOURCE-STIELTJES',schur_stieltjes,'p4b:thm:v240-complete-one-source-stieltjes')

def source_weight_W():
    d0,d1=2,3;H0=np.diag([0,.2]);H1=np.diag([1.2,1.8,2.3]);rho0=np.diag([.1,.3]);rho1=np.diag([.15,.25,.2]);X=complex_array((d0,d1));Y=complex_array((d0,d1))
    W=np.kron(rho1.T,np.eye(d0))+np.kron(np.eye(d1),rho0)
    vec=lambda x:x.flatten(order='F')
    rhs=np.vdot(vec(X),W@vec(Y))
    lhs=np.trace(rho1@X.conj().T@Y)+np.trace(rho0@Y@X.conj().T)
    close(lhs,rhs)
    L=np.kron(H1.T,np.eye(d0))-np.kron(np.eye(d1),H0)
    close(W@L,L@W)
    return 'charge-sector weighted W_rho equals anticommutator pairing for nontrivial block dimensions'
chk('E3-B03-CHARGE-RESIDUE-W',source_weight_W,'p4:thm:v2168-faithful-stationary-poles')

def root_bound():
    A=np.array([[.12,.02],[.02,.5]]); B=np.array([[.7,.11],[-.2,.4]]);C=np.diag([-2.2,-1.4]);
    S=lambda z:z*np.eye(2)-A-B.T@np.linalg.inv(z*np.eye(2)-C)@B
    eps=.5;kap=np.linalg.eigvalsh(S(eps))
    from scipy.optimize import brentq
    out=[]
    for i,k in enumerate(kap):
        root=brentq(lambda z:np.linalg.eigvalsh(S(z))[i], min(eps,eps-k)-.05,max(eps,eps-k)+.05)
        assert abs(root-eps)<=abs(k)+1e-8
        out.append((float(k),float(root)))
    return {'kappa_root':out}
chk('E3-B03-REGULAR-GAP-ROOT-BOUND',root_bound,'p4:thm:v2168-regular-gap-root-bound')

def hankel_cyclic():
    T=np.diag([-1.,.3,2.]);v=np.array([1.,.5,.8]);m=lambda n:v@np.linalg.matrix_power(T,n)@v
    s=3;G=np.array([[m(i+j) for j in range(s)] for i in range(s)]);b=np.array([m(s+i) for i in range(s)])
    aa=-np.linalg.solve(G,b);res=m(2*s)-b@np.linalg.solve(G,b)
    close(res,0,atol=1e-8)
    p=np.polynomial.polynomial.Polynomial(np.r_[aa,1.]);
    close(sum(coef*np.linalg.matrix_power(T,i) for i,coef in enumerate(np.r_[aa,1.]))@v,0)
    K=np.array([[m(i+j+1) for j in range(s)] for i in range(s)])
    close(np.sort(np.linalg.eigvals(np.linalg.solve(G,K)).real),np.sort(np.linalg.eigvalsh(T)))
    return 'positive Hankel Gram, exact closure residual, eigenvalue pencil, root locations'
chk('E3-B03-HANKEL-CYCLIC-PENCIL',hankel_cyclic,'p4:v2169:b7:thm:closure; p4:v2169:b7:thm:poles')

def support_quotient():
    H=np.diag([0,1,3.]);P=np.diag([1.,1.,0.]);rho=np.diag([.25,.75,0]);q=np.array([[0,1,1],[1,0,0],[0,1,0]],complex)
    L=lambda A:H@A-A@H
    C=lambda rr,A:np.trace(rr@(A.conj().T@A+A@A.conj().T)).real
    pnorm=lambda A:C(P/2,A)
    ll=2*.25*pnorm(q);ul=2*.75*pnorm(q)
    assert ll<=C(rho,q)+1e-10<=ul
    # Inspect exact visible frequencies for P/2 and rho, whose effect is positive.
    decomp={}
    for rr in (rho,P/2):
        freqs=[]
        for i,j in itertools.product(range(3),repeat=2):
            if abs(q[i,j])>1e-10 and (rr[i,i]+rr[j,j])>1e-10:
                freqs.append(float(H[i,i]-H[j,j]))
        decomp[len(decomp)]=set(freqs)
    assert decomp[0]==decomp[1]
    return {'common_visible_frequencies':sorted(decomp[0])}
chk('E3-B03-SUPPORT-POLYNOMIAL',support_quotient,'p4:v2169:b10:thm:support')

def cyclic_intertwiner():
    T=np.diag([.8,2.]);v=np.array([1.,1.]);K=np.array([[1,.4],[0,1.7]]);T2=K@T@np.linalg.inv(K);v2=K@v
    close(T2@K,K@T);close(v2,K@v)
    p=lambda M: (M-.8*np.eye(2))@(M-2.*np.eye(2))
    close((T-.8*np.eye(2))@(T-2*np.eye(2))@v,0);close((T2-.8*np.eye(2))@(T2-2*np.eye(2))@v2,0)
    # Not isometric: Euclidean response has same poles, changed residues.
    z=1+.5j;g1=np.vdot(v,np.linalg.inv(z*np.eye(2)-T)@v);g2=np.vdot(v2,np.linalg.inv(z*np.eye(2)-T2)@v2)
    assert abs(g1-g2)>.1
    return 'same first monic polynomial under nonisometric cyclic similarity, residues different'
chk('E3-B03-CYCLIC-INTERTWINER',cyclic_intertwiner,'p4:thm:v2186-common-source-cyclic-polynomial; p4:cor:v2186-source-cyclic-residue-scope')

def scalar_centre():
    H=herm(3);q=complex_array((3,3));c=5.1
    close((H+c*np.eye(3))@q-q@(H+c*np.eye(3)),H@q-q@H)
    beta=.3;rho=lambda x:expm(-beta*x)/np.trace(expm(-beta*x));close(rho(H+c*np.eye(3)),rho(H))
    return 'full Liouvillian and normalized Gibbs state unchanged under cI'
chk('E3-B03-SCALAR-CENTRE',scalar_centre,'p4:cor:v2186-scalar-center-pole-invisibility')

def receiver_det():
    eps=np.array([.4,1.2,1.6]);nu=np.array([-.3,.8,2.1]);
    # Build unitary C via actual 3x3 Fourier unitary; formula supports any unitary
    C=np.fft.fft(np.eye(3))/np.sqrt(3);lam=.35
    H=np.block([[np.zeros((3,3)),np.diag(eps),lam*C],
                [np.diag(eps),np.zeros((3,3)),np.zeros((3,3))],
                [lam*C.conj().T,np.zeros((3,3)),np.diag(nu)]])
    z=.77+.31j
    d=z*z-eps*eps;n=z-nu;t=lam*lam*z;P=abs(C)**2
    formula=np.prod(d)*np.prod(n)
    for i,j in itertools.product(range(3),repeat=2):
        formula-=t*P[i,j]*np.prod([d[s] for s in range(3) if s!=i])*np.prod([n[k] for k in range(3) if k!=j])
        formula+=t*t*P[i,j]*d[i]*n[j]
    formula-=t**3
    return {'err':close(np.linalg.det(z*np.eye(9)-H),formula,atol=1e-8)}
chk('E3-B03-RECEIVER-NINEBLOCK-DET',receiver_det,'p4:eq:v2169-b7-d2; complete weak-receiver chart')

def interacting_pole():
    af=car(2);adf=[k.conj().T for k in af];n1=adf[0]@af[0];n2=adf[1]@af[1];eps=.8;b=1.7;g=.31
    H=eps*n1+b*n2+g*n1@n2;q=adf[0];
    P0=np.diag([1.,0,0,0]);
    # frequencies for q in independent n2 sectors
    L=lambda X:H@X-X@H
    close(L(q),(eps*np.eye(4)+g*n2)@q)
    O=(np.eye(4)-n2)@q;close(L(O),eps*O)
    A=O.conj().T@O+O@O.conj().T
    close(np.trace(P0@A),1)
    close(np.trace(A)/4,.5)
    return 'finite interaction g≠0 preserves +eps empty-state pole but creates separate faithful-state +eps+g frequency'
chk('E3-B03-INTERACTING-POLE-WITNESS',interacting_pole,'p4:eq:v2169-b7-d4')

result={'version':'Paper4B-Batch03Checks-v1_1','source':'Paper4B-QuantumResponse-v1_42.tex',
        'scope_lines':[4711,7996], 'levels':['E2','E3','E4'],
        'tests':checks,'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks)}
p=pathlib.Path(__file__).with_suffix('.json')
p.write_text(json.dumps(result,indent=2))
for x in checks:
    print(('PASS' if x['passed'] else 'FAIL'),x['id'],x.get('error',''))
print(result['passed'],'/',len(checks))
if result['failed']:raise SystemExit(1)
