# Paper IV-B — Rigorous Verification DAG Audit, Batch 04 (final source review)

**Artifact:** `Paper4B-RigorousBatch04-v1_1.md` | **Protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md` | **Framework source:** v2.371
**Source:** `Paper4B-QuantumResponse-v1_42.tex` SHA256 `11b93140dc5c53854a382763fde536862e8d979f65ba8e37c1af562b23bdab6f`. No source or supplied ZIP modified.

## 1. Review scope and verdict
- **Batch:** lines 7997–12149 inclusive; 78/78 remaining named statements and 65/65 remaining proof environments, including the remaining unnamed proofs.
- **Cumulative:** 227/227 named statements and 176/176 source proof environments across 4 bounded batches; no formal named statement unexamined.
- **Batch 4 status distribution:** {'VERIFIED-CONDITIONAL': 51, 'FORMALIZED': 9, 'REPRODUCED': 14, 'VERIFIED': 4}. There is no new established source-as-printed logical error in this section.
- **Executable independent controls:** 47/47 pass. Re-runs of earlier checks 14/14, 26/26, 32/32 pass; total 119/119 scoped checks, with limits recorded by each check.
- **Two carried-forward open issues:** `BH-G-000100` (global Euclidean exponential-weight inference from restricted multiplication) and `BH-G-000101` (Gibbs stationary characterization from mere collision-graph connectivity). Both are source-scope implications in Batch 2, not failures of every later dependent finite construction.
- **Review organization:** sequential one coordinating analyst using separately constructed E1 source replay, E2/E3 controls and adversarial boundary checks; no multiagent execution claimed.

## 2. Checked mathematical and physical interfaces
### 2.1 Continuous monitoring, Gaussian work and retained loading
- Source-exact finite weak Kraus expansion, state posterior, η=0/1 efficiency limits, pure dephasing and operational pointer algebra reproduce. Stochastic limit requires its source-declared regularity and weak-step assumptions.
- Symplectic Gaussian covariance/functional work and moving-chart terms agree; determinant Schur term cannot be independently counted twice. The cold survival theorem depends on the actual finite positivity/integrability interface, and the numerical check is a positive example, not a proof of all asymptotic regimes.
- Finite passive work, monotone sign-pair loading, Bloch force, projection leakage bound, inherited mixedness and massive free conformal-shape response checked with physical source and preparation explicitly supplied.
### 2.2 Quasilocal thermodynamics and event-frequency instruments
- The quasi-local KMS statement is a conditional theorem on a specified compatible thermodynamic subnet and explicit analytic limiting criterion; one finite KMS identity does not construct the global limiting net.
- The finite event law uses the transfer superoperator, group inverse and finite martingale decomposition. Nonstationary frequency limits need not be iid and may be random; verified absorber and periodic countercontrols preserve those distinctions.
- Uniform semigroup-window estimates, the zero-excitation dynamical Pauli response and graded heat/UV integral keep their actual domain guards; UV and cosmological physical realization are not asserted merely by a finite kernel.
### 2.3 Exact CAR determinants, detectors and interaction hierarchy
- Finite quasifree CAR determinant exact against 8×8 Fock evaluation, local logdet jets, source noise and frame transport reproduce. Nonzero determinant chart and full-band gauge transport are retained.
- The joint cyclic lepton response respects the source Paper V-A three-cycle direction; necessity of additional noncyclic source content is an exact finite commutator statement, not a license to force masses.
- Full in-in Ward residual, finite detector channel, conditional chiral Petersen pole/phase/Wilson loops, one-body arbitrary-state criterion, explicit interacting three-mode obstruction, finite Majorana hierarchy and current-visible inverse-cubic Krylov response reproduce at checked domain.
- **Observable firewall:** conditional auxiliary poles and relative phases are not demonstrated charged-particle masses; finite Ward and current spectral data require the complete admitted source. This preserves upstream constitution and source-owner selection.

## 3. Exact named result census
| # | Line | Kind | Source label | Disposition | Proof | Independent checks |
|--:|--:|---|---|---|:---:|---:|
| 150 | 8056 | THEOREM | `p4:thm:weak-monitoring-diffusive` | VERIFIED-CONDITIONAL | yes | 2 |
| 151 | 8251 | PROPOSITION | `p4:prop:weak-value-ozawa-domain` | VERIFIED-CONDITIONAL | yes | 1 |
| 152 | 8345 | PROPOSITION | `p4:prop:pure-dephasing-rates` | VERIFIED-CONDITIONAL | yes | 1 |
| 153 | 8416 | COROLLARY | `p4:cor:pointer-operational` | VERIFIED-CONDITIONAL | yes | 1 |
| 154 | 8507 | THEOREM | `p4:thm:v2203-gaussian-physical-work` | VERIFIED-CONDITIONAL | yes | 1 |
| 155 | 8551 | PROPOSITION | `p4:prop:v2203-gaussian-functional-work` | VERIFIED-CONDITIONAL | yes | 1 |
| 156 | 8585 | PROPOSITION | `p4:prop:v2203-time-dependent-chart-work` | VERIFIED-CONDITIONAL | yes | 1 |
| 157 | 8635 | THEOREM | `p4:thm:v2203-causal-mean-response-noise` | VERIFIED-CONDITIONAL | yes | 0 |
| 158 | 8673 | PROPOSITION | `p4:prop:v2203-gaussian-connected-noise` | VERIFIED-CONDITIONAL | yes | 1 |
| 159 | 8726 | COROLLARY | `p4:cor:v2203-gaussian-linear-even-parity` | VERIFIED-CONDITIONAL | yes | 0 |
| 160 | 8750 | PROPOSITION | `p4:prop:v2203-quantum-schur-nonduplication` | VERIFIED-CONDITIONAL | yes | 1 |
| 161 | 8787 | THEOREM | `p4:thm:v2203-gaussian-cold-tail` | VERIFIED-CONDITIONAL | yes | 1 |
| 162 | 8863 | THEOREM | `p4:thm:v2209-passive-work-capacity` | VERIFIED-CONDITIONAL | yes | 1 |
| 163 | 8906 | THEOREM | `p4:thm:v2217-monotone-free-loading` | VERIFIED-CONDITIONAL | yes | 1 |
| 164 | 8952 | PROPOSITION | `p4:prop:v2209-compact-bloch-source` | VERIFIED-CONDITIONAL | yes | 1 |
| 165 | 8988 | REMARK | `p4:rem:v2209-noise-energy-witness` | FORMALIZED | — | 0 |
| 166 | 9006 | THEOREM | `p4:thm:v2209-controlled-excitation-survival` | VERIFIED-CONDITIONAL | yes | 1 |
| 167 | 9054 | COROLLARY | `p4:cor:v2209-native-tail-retention` | REPRODUCED | yes | 0 |
| 168 | 9082 | PROPOSITION | `p4:prop:v2209-inherited-mixedness-gap` | VERIFIED-CONDITIONAL | yes | 1 |
| 169 | 9113 | COROLLARY | `p4:cor:v2212-massive-conformal-shape-kernel` | REPRODUCED | yes | 1 |
| 170 | 9244 | REMARK | `p4:rem:v2212-conformal-shape-scope` | FORMALIZED | — | 0 |
| 171 | 9282 | THEOREM | `p4:thm:quasilocal-thermodynamic-bridge` | REPRODUCED | yes | 1 |
| 172 | 9369 | REMARK | `p4:rem:thermo-conditionality` | FORMALIZED | — | 0 |
| 173 | 9386 | REMARK | `p4:rem:v490-local-kinetic-versus-kms` | FORMALIZED | — | 0 |
| 174 | 9404 | PROPOSITION | `p4:prop:v236-thermal-atlas` | REPRODUCED | — | 0 |
| 175 | 9431 | PROPOSITION | `p4:prop:v236-scattering-atlas` | REPRODUCED | — | 0 |
| 176 | 9455 | THEOREM | `p4:thm:v2109-finite-root-restrictions` | VERIFIED-CONDITIONAL | yes | 0 |
| 177 | 9500 | THEOREM | `p4:thm:v2114-neutral-fock-unit` | REPRODUCED | yes | 0 |
| 178 | 9546 | THEOREM | `p4:thm:v2114-positive-family-ground-source` | VERIFIED-CONDITIONAL | yes | 1 |
| 179 | 9586 | THEOREM | `p4:thm:v2109-finite-evolution-error` | VERIFIED-CONDITIONAL | yes | 0 |
| 180 | 9636 | THEOREM | `p4:thm:v2109-euclidean-weight-support` | VERIFIED | yes | 1 |
| 181 | 9672 | THEOREM | `p4:thm:v164-action-hessian-pole-owner` | REPRODUCED | — | 0 |
| 182 | 9687 | THEOREM | `p4:thm:v164-finite-gibbs-vacuum-no-thermalization` | VERIFIED-CONDITIONAL | — | 0 |
| 183 | 9764 | COROLLARY | `p4:cor:v491-fermion-factor-source-multiplication` | VERIFIED-CONDITIONAL | yes | 0 |
| 184 | 9960 | THEOREM | `p4:thm:v2210-lit-instrument-mixing` | VERIFIED-CONDITIONAL | yes | 1 |
| 185 | 10014 | COROLLARY | `p4:cor:v2211-finite-event-resolvent-certificate` | VERIFIED-CONDITIONAL | yes | 1 |
| 186 | 10083 | COROLLARY | `p4:cor:v2211-event-frequency-strong-law` | VERIFIED-CONDITIONAL | yes | 0 |
| 187 | 10125 | THEOREM | `p4:thm:v255-sharp-event-frequency` | VERIFIED-CONDITIONAL | yes | 1 |
| 188 | 10284 | PROPOSITION | `p4:prop:v255-periodic-persistent-records` | VERIFIED-CONDITIONAL | yes | 1 |
| 189 | 10343 | THEOREM | `p4:thm:v258-nonstationary-frequency-law` | VERIFIED-CONDITIONAL | yes | 1 |
| 190 | 10506 | COROLLARY | `p4:cor:v258-asymptotic-frequency-povm` | VERIFIED-CONDITIONAL | yes | 1 |
| 191 | 10559 | COROLLARY | `p4:cor:v258-stationary-frequency-recovery` | VERIFIED-CONDITIONAL | yes | 0 |
| 192 | 10586 | PROPOSITION | `p4:prop:v258-frequency-law-diagnostics` | VERIFIED-CONDITIONAL | yes | 1 |
| 193 | 10661 | PROPOSITION | `p4:prop:v2210-lit-frequency-obstructions` | VERIFIED-CONDITIONAL | yes | 0 |
| 194 | 10691 | PROPOSITION | `p4:prop:v2210-lit-markov-window` | VERIFIED-CONDITIONAL | yes | 1 |
| 195 | 10729 | THEOREM | `p4:thm:v2216-zero-excitation-dynamic-response` | VERIFIED-CONDITIONAL | yes | 1 |
| 196 | 10797 | REMARK | `p4:rem:v2216-qroot-dynamic-scope` | FORMALIZED | — | 0 |
| 197 | 10817 | THEOREM | `p4:thm:v2216-graded-matter-uv` | REPRODUCED | yes | 1 |
| 198 | 10882 | REMARK | `p4:rem:v2216-graded-matter-scope` | FORMALIZED | — | 0 |
| 199 | 10914 | PROPOSITION | `p4:prop:v2216-finite-heat-integrability` | REPRODUCED | yes | 0 |
| 200 | 10959 | REMARK | `p4:rem:v2216-finite-heat-domain` | FORMALIZED | — | 0 |
| 201 | 10986 | THEOREM | `p3f:thm:v247-car-influence-determinant` | VERIFIED | yes | 1 |
| 202 | 11041 | COROLLARY | `p3f:cor:v247-car-logdet-jets` | VERIFIED-CONDITIONAL | yes | 1 |
| 203 | 11065 | PROPOSITION | `p3f:prop:v247-car-source-jets` | VERIFIED-CONDITIONAL | yes | 1 |
| 204 | 11118 | PROPOSITION | `p3f:prop:v247-car-influence-frame-transport` | VERIFIED-CONDITIONAL | yes | 1 |
| 205 | 11151 | THEOREM | `p4:thm:v247-native-source-factorization` | VERIFIED-CONDITIONAL | yes | 1 |
| 206 | 11263 | COROLLARY | `p4:cor:v247-native-source-work-cumulants` | VERIFIED-CONDITIONAL | yes | 1 |
| 207 | 11351 | PROPOSITION | `p4:v251:prop:symmetry-transport` | REPRODUCED | yes | 0 |
| 208 | 11380 | PROPOSITION | `p4:v251:prop:finite-response-symmetry` | VERIFIED-CONDITIONAL | yes | 0 |
| 209 | 11428 | THEOREM | `p4:v251:thm:lepton-cyclic-response` | REPRODUCED | yes | 1 |
| 210 | 11493 | COROLLARY | `p4:v251:cor:required-noncyclic-content` | VERIFIED-CONDITIONAL | yes | 1 |
| 211 | 11596 | THEOREM | `p4b:thm:v254-in-in-charge-detector-covariance` | VERIFIED-CONDITIONAL | yes | 1 |
| 212 | 11641 | COROLLARY | `p4b:cor:v254-ward-operator-residual` | VERIFIED-CONDITIONAL | yes | 0 |
| 213 | 11670 | PROPOSITION | `p4b:prop:v254-same-action-angular-flux` | REPRODUCED | yes | 0 |
| 214 | 11696 | REMARK | `UNLABELED:Paper4B:remark:11696` | FORMALIZED | — | 0 |
| 215 | 11715 | THEOREM | `p4b:thm:v266-native-instrument` | REPRODUCED | yes | 1 |
| 216 | 11746 | COROLLARY | `p4b:cor:v266-quadratic-repeat` | VERIFIED-CONDITIONAL | yes | 0 |
| 217 | 11781 | THEOREM | `p4b:thm:v320-chiral-auxiliary-poles` | VERIFIED-CONDITIONAL | yes | 1 |
| 218 | 11831 | COROLLARY | `p4b:cor:v320-complement-phase-gauge` | VERIFIED-CONDITIONAL | yes | 1 |
| 219 | 11855 | THEOREM | `p4b:thm:v320-z2-loop-interference` | VERIFIED-CONDITIONAL | yes | 1 |
| 220 | 11892 | PROPOSITION | `p4b:prop:v320-source-incidence-boundary` | REPRODUCED | yes | 0 |
| 221 | 11931 | THEOREM | `p4b:thm:v347-onebody-criterion` | VERIFIED-CONDITIONAL | yes | 1 |
| 222 | 11972 | COROLLARY | `p4b:cor:v347-retarded-criterion` | VERIFIED-CONDITIONAL | yes | 0 |
| 223 | 11999 | PROPOSITION | `p4b:prop:v347-three-mode-response-obstruction` | VERIFIED | yes | 1 |
| 224 | 12032 | THEOREM | `p4b:thm:v347-majorana-hierarchy` | VERIFIED-CONDITIONAL | yes | 1 |
| 225 | 12064 | PROPOSITION | `p4b:prop:v347-odd-transfer-witness` | VERIFIED-CONDITIONAL | yes | 1 |
| 226 | 12100 | THEOREM | `p4b:thm:v356-current-visible-krylov` | VERIFIED | yes | 1 |
| 227 | 12137 | REMARK | `p4b:rem:v356-current-krylov-scope` | FORMALIZED | — | 0 |

## 4. Evidence and graph handoff
- Current corpus: 30 authoritative TeX sources; 13560 unique cross-paper labels; this batch has zero unresolved refs from source statement/proof citations.
- Named claim proofs directly attached: 65; other exact substantive proof environments in these lines: 0. All 65 classified and retained in JSON.
- `Paper4B-Batch04Ledger-v1_1.json` contains the exact current LaTeX claim statements and proof text, source positions, cross-paper label locators, per-result status and verification limitations.
- `Paper4B-Batch04Checks-v1_1.py` and result JSON retain all source-scoped computational certificates; no finite example is mispromoted to a universal or physical proof.
- This batch completes source review and transfers the two established origins plus exact boundaries to the combined global DAG and complete proof-chain audit.
