# Paper IV-B rigorous DAG verification — Batch 02 (checkpoint)
**Artifact:** `Paper4B-RigorousBatch02-v1_1.md` | **Protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md` | **Current corpus:** v2.371
**Authoritative source:** `Paper4B-QuantumResponse-v1_42.tex` | SHA256 `11b93140dc5c53854a382763fde536862e8d979f65ba8e37c1af562b23bdab6f` | All IV-B mathematics identical to Batch 1 source; only `\input{Macros-v2_173.tex}` changed to `\input{Macros-v2_174.tex}`.
**Atlas source baseline:** v1.106. **Proof-chain audit baseline:** v1.24. The source is not silently downgraded to the previous upload.
**Scope:** 2241–4710, complete main sections “Complete action-generated finite clock evolution” and “Scattering, finite-temperature and kinetic source interfaces.”
**Audited in Batch 2:** 57/227 named items, 36/176 proof environments. **Cumulative:** 96/227 named items and 65/176 proof environments.
**Verdicts this batch:** {'VERIFIED-CONDITIONAL': 27, 'REPRODUCED': 9, 'VERIFIED': 3, 'FORMALIZED': 16, 'INCONSISTENT': 2}. **Tests:** 26/26 symbolic, matrix and adversarial checks passed. Subclaim tests are not universal physical-occurrence certificates.
**Confirmed source-as-written implication issues:** 2, anchored once at the earliest defective step; do not propagate as independent defects to every subsequent reference.

## 1. Established source-logic issues (source matched, no repair or theory modification)

### BH-G-000100 — Exponential Euclidean weight rigidity: restricted multiplicativity is not a global Cauchy equation
- **Source:** `p4:thm:euclidean-weight-rigidity`, 2913–2942, proof 2937–2942. **Class:** `MISSING_CONDITION` / `LOGICAL_GAP`; **severity:** major. **Boundary:** `BND-IVB-02-001`.
- **Exact mismatch:** the premise asserts `w(x+y)=w(x)w(y)` only **when** two action values are admitted as relation-free composed subsystems, yet the conclusion claims `w(x)=e^{cx}` for *all real* x. GP2 `p2:post:GP2` constructs products of generated roles; it does not itself certify that the action-value composability relation is all of R×R or dense in the required sense.
- **Exact E4 witness:** let admitted composable action values be nonnegative integers and define `w(x)=exp(-x+sin(2πx)/20)` for all real x. It is positive, continuous, strictly decreasing, `w(0)=1`, and `w(n+m)=w(n)w(m)` for every admitted pair of integers. But `w(1)=e^{-1}` and `w(1/4)=e^{-1/4+1/20}`; no global c works. All printed premises hold on this abstract admitted-action domain, while the printed universal conclusion fails.
- **Positive control:** if the equation is available for every real pair (or a sufficient dense additive action set with the appropriate continuity extension), the printed log/Cauchy proof does yield `w=e^{cx}`.
- **Material reach:** explicit conditional import into `p4:def:generated-finite-euclidean-quantum-ray` and then `p4:cor:finite-generated-quantum-constructor` (2944–2972) in the **no independent partition-weight selector** argument. The explicitly defined finite weighted integrals remain valid whenever the exponential weight is already given. Paper VII-C `p12:thm:generated-schwinger-effective-action-closure` is **possibly affected** only; the remote branch was not globally reaudited.
- **Discharge evidence required:** source-level coverage of the actual admissible action-value pairs, or an already established upstream bridge from generated action role to sufficiently rich real action-value composition. No new axiom is proposed.

### BH-G-000101 — Local kinetic H-theorem: connected reaction graph does not classify all collision invariants
- **Source:** `p4:thm:v496-quantum-kinetic-h`, 4537–4563 (no displayed proof). **Class:** `MISSING_CONDITION` / `LOGICAL_GAP`; **severity:** moderate. **Boundary:** `BND-IVB-02-002`.
- **Verified portion:** nonnegative microreversible W implies `dot(S)_coll≥0`, since `(X−Y)log(X/Y)≥0` for X,Y>0. The zero-production **Gibbs-only conclusion** requires the missing determination of all additive collision invariants, not just one-sector graph connectedness.
- **Exact E4 witness:** one fermion species with eight equal-energy momentum cells `±ex, ±ey, ±ez, ±u`, `u=(1,1,1)/√3`; allow reversible pair reactions `(ex,−ex)↔(ey,−ey)`, `(ex,−ex)↔(ez,−ez)`, `(ex,−ex)↔(u,−u)` at positive W. These four pair configurations exhaust and **connect** the two-particle sector of fixed number 2, energy 2E, and total momentum zero. Set f=1/2 at the six axis cells, f(+u)=3/4, f(−u)=1/4. Every reaction has X=Y, so production vanishes; the single-species Gibbs ansatz would give log-odds as an affine function of p, but vanishing log-odds on ±ex, ±ey, ±ez forces that affine function to zero while the ±u log-odds equal ±log 3. Thus the printed Gibbs family does not exhaust the stationary states under the stated kinetic premises.
- **Scope:** this is an exact **abstract permitted-kernel** counterexample; it does not establish a non-Gibbs physical Standard-Model distribution or negate Paper IV finite KMS. Paper VII-C `p12:thm:v296-k16-local-kinetic` cites this interface, but actual-network invariant completeness has not yet been independently verified and is only **possibly affected**.
- **Discharge evidence required:** an actual admitted collision-invariant-completeness result (all solutions to the detailed-balance equations spanned by energy-momentum and declared species charges), beyond sector connectivity.

## 2. Separately verified finite results and explicit limits
1. **Action/clock evolution:** exact CAR graded commutator checks, finite unitary time-ordered propagation, transported projector Lax identity, and source-work/central trace calculations all agree on stated complete-word domains. The co-realization/physical propagation target remains a separate condition.
2. **KMS, quantum states, and Euclidean algebra:** finite KMS and paired determinant signs are confirmed. Haar integration ray is unique for the stipulated finite/additive owners. Coercivity is needed for exact interacting bosonic integrals. The two source-logic findings concern only specific stronger selection/equilibrium implications.
3. **Scattering and resonances:** finite-window channel contraction and leakage, finite Feshbach resolvent and real poles, conditional Møller/Cauchy convergence are consistent. An irreversible width is **not** generated by finite Hermitian evolution; the source states the reservoir/continuum condition explicitly.
4. **Thermal and internal-response readouts:** standard sphaleron factor `28/79` and entropy/photon ratio near `7.04` reproduce as imported thermal formulas; positive-frequency polarization and exact charge conservation test correctly. Actual cosmological history/initial state are not constituted by these identities.
5. **CAR fluctuation and finite EAA:** top-cutoff CCR defect, CAR source variance with non-Wick term, and one-mode EAA regulator derivative reproduce. Full mixed graded EAA proof remains `REPRODUCED` until independent full-block E3; sampled tests do not certify the whole regulator/ghost domain.

## 3. Evidence/constitutional firewall and carry-forward obligations
- The complete action generator may fix a finite flow, but does not itself supply one-body incidence, scattering channel preparations, bath, KMS history, or a continuum S-matrix. No false blanket hidden-selector issue was added.
- `p4:thm:hurwitz-link-finite-support-import` explicitly conditions on `Supp_2T` occurrence and one-particle allocation and imports Paper I-A exact graphs. Do **not** recast that conditional theorem as a new gap in the already discharged level-one momentum representation `m_p=1`.
- The two E4 witnesses target **mathematical universality quantifiers** in the printed theorems. Neither is claimed to be the actual Born-Hopf physical sector, and neither undermines the finite KMS sign or its exact trace identity.
- Proposed issue records include E/U/C/R/I typed boundaries, first-origin locators, valid positive controls, exact limits, and tentative (not incorrectly certified) remote DAG paths. Global canonical condition IDs remain unresolved until final graph merge, to avoid duplicate BH-A assumptions.
- No source file, Atlas ZIP, or existing proof-chain ZIP was modified. The DAG/audit ZIPs are final-batch deliverables and are intentionally not produced by this checkpoint.

## 4. Claim-by-claim source and status census
| # | Source line | Kind | Source label | Status | E1 |
|--:|--:|---|---|---|:---:|
| 1 | 2248 | PROPOSITION | `p4:prop:coordinate-source-work` | VERIFIED-CONDITIONAL | yes |
| 2 | 2285 | PROPOSITION | `p4:prop:spherical-free-dirac-source` | REPRODUCED | yes |
| 3 | 2338 | COROLLARY | `p4:cor:spherical-free-positive-constituent` | VERIFIED-CONDITIONAL | yes |
| 4 | 2362 | COROLLARY | `p4:cor:spherical-dirac-trace-source-work` | VERIFIED-CONDITIONAL | yes |
| 5 | 2388 | PROPOSITION | `p4:prop:spherical-dirac-retarded-kernel` | VERIFIED-CONDITIONAL | yes |
| 6 | 2433 | COROLLARY | `p4:cor:common-flow-dynamic-tests` | VERIFIED-CONDITIONAL | yes |
| 7 | 2459 | COROLLARY | `p4:cor:finite-tt-source-response` | REPRODUCED | yes |
| 8 | 2522 | THEOREM | `p4:thm:v2190-car-euler-derivation` | VERIFIED-CONDITIONAL | yes |
| 9 | 2583 | THEOREM | `p4:thm:v2190-complete-finite-propagator` | VERIFIED-CONDITIONAL | yes |
| 10 | 2619 | COROLLARY | `p4:cor:v2190-frame-constraint-transport` | VERIFIED-CONDITIONAL | yes |
| 11 | 2683 | THEOREM | `p4:thm:finite-thermal-kms-kinetic-interface` | VERIFIED | yes |
| 12 | 2726 | REMARK | `p4:rem:finite-kms-kinetic-boundary` | FORMALIZED | — |
| 13 | 2756 | THEOREM | `p4:thm:finite-channel-scattering-lsz-interface` | REPRODUCED | yes |
| 14 | 2818 | THEOREM | `p4:thm:external-fermion-line-generated-closure` | VERIFIED-CONDITIONAL | yes |
| 15 | 2873 | REMARK | `UNLABELED:Paper4B:remark:2873` | FORMALIZED | — |
| 16 | 2885 | THEOREM | `p4:thm:finite-reference-integration-ray` | VERIFIED-CONDITIONAL | yes |
| 17 | 2913 | THEOREM | `p4:thm:euclidean-weight-rigidity` | INCONSISTENT | yes |
| 18 | 2944 | DEFINITION | `p4:def:generated-finite-euclidean-quantum-ray` | FORMALIZED | — |
| 19 | 2964 | COROLLARY | `p4:cor:finite-generated-quantum-constructor` | REPRODUCED | — |
| 20 | 2974 | COROLLARY | `p4:cor:v2140-relative-determinant-weights` | VERIFIED-CONDITIONAL | yes |
| 21 | 3033 | THEOREM | `p4:thm:finite-euclidean-path-integral-status` | VERIFIED-CONDITIONAL | yes |
| 22 | 3084 | REMARK | `p4:rem:finite-interaction-versus-geometric-vertex` | FORMALIZED | — |
| 23 | 3116 | THEOREM | `p4:thm:hurwitz-link-finite-support-import` | REPRODUCED | yes |
| 24 | 3213 | COROLLARY | `p4:cor:v204-quantum-sampled-transport` | VERIFIED-CONDITIONAL | yes |
| 25 | 3249 | REMARK | `p4:rem:no-scalene-carrier-triangle` | FORMALIZED | — |
| 26 | 3255 | COROLLARY | `p4:cor:hurwitz-finite-operator-algebras` | REPRODUCED | yes |
| 27 | 3325 | THEOREM | `p4:thm:finite-gauge-constraint-closure` | VERIFIED-CONDITIONAL | yes |
| 28 | 3343 | REMARK | `p4:rem:v176-finite-gauge-noether-typing` | FORMALIZED | — |
| 29 | 3367 | PROPOSITION | `p4:prop:explicit-finite-ccr-boundary-defect` | VERIFIED | yes |
| 30 | 3394 | REMARK | `p4:rem:ccr-defect-meaning` | FORMALIZED | — |
| 31 | 3432 | THEOREM | `p4:thm:finite-wick-quasifree-calculus` | VERIFIED-CONDITIONAL | yes |
| 32 | 3513 | REMARK | `p4:rem:finite-wick-downstream-support` | FORMALIZED | — |
| 33 | 3529 | THEOREM | `p4:thm:car-source-variance` | VERIFIED | yes |
| 34 | 3575 | COROLLARY | `p4:cor:bounded-source-connected-return` | VERIFIED-CONDITIONAL | yes |
| 35 | 3601 | THEOREM | `p4:thm:v4100-exact-graded-eaa` | REPRODUCED | yes |
| 36 | 3640 | REMARK | `p4:rem:v4100-graded-eaa-scope` | FORMALIZED | — |
| 37 | 3699 | PROPOSITION | `p4:prop:framework-scattering-window` | VERIFIED-CONDITIONAL | yes |
| 38 | 3744 | REMARK | `p4:rem:scattering-smatrix` | FORMALIZED | — |
| 39 | 3785 | LEMMA | `p4:lem:derived-scattering-plateau` | VERIFIED-CONDITIONAL | yes |
| 40 | 3907 | LEMMA | `p4:lem:finite-window-scattering-cauchy-criterion` | VERIFIED-CONDITIONAL | yes |
| 41 | 3934 | THEOREM | `p4:thm:moller-bridge` | REPRODUCED | yes |
| 42 | 4129 | THEOREM | `p4:thm:finite-resonance-reduction` | VERIFIED-CONDITIONAL | yes |
| 43 | 4176 | REMARK | `p4:rem:finite-resonance-status` | FORMALIZED | — |
| 44 | 4186 | REMARK | `p4:rem:resonance-meaning` | FORMALIZED | — |
| 45 | 4232 | REMARK | `p4:rem:scattering-spectroscopy-bridge` | FORMALIZED | — |
| 46 | 4280 | THEOREM | `p4:thm:minimal-finite-temperature-seesaw-interface` | REPRODUCED | yes |
| 47 | 4430 | REMARK | `p4:rem:thermal-interface-status` | FORMALIZED | — |
| 48 | 4440 | LEMMA | `p4:lem:uniform-finite-trace-efficiency` | VERIFIED-CONDITIONAL | yes |
| 49 | 4457 | PROPOSITION | `p4:prop:sphaleron-and-photon-conversion` | VERIFIED-CONDITIONAL | yes |
| 50 | 4519 | PROPOSITION | `p4:prop:v496-depth-not-beta` | VERIFIED-CONDITIONAL | — |
| 51 | 4537 | THEOREM | `p4:thm:v496-quantum-kinetic-h` | INCONSISTENT | — |
| 52 | 4565 | REMARK | `p4:rem:v496-local-not-global-kms` | FORMALIZED | — |
| 53 | 4580 | PROPOSITION | `p4:prop:v497-internal-response-positive-frequency` | VERIFIED-CONDITIONAL | — |
| 54 | 4602 | COROLLARY | `p4:cor:v497-state-not-saturation` | VERIFIED-CONDITIONAL | — |
| 55 | 4623 | THEOREM | `p4:thm:v498-no-charge-production` | VERIFIED-CONDITIONAL | yes |
| 56 | 4665 | PROPOSITION | `p4:prop:v4103-real-pair-response-no-new-phase` | VERIFIED-CONDITIONAL | yes |
| 57 | 4694 | REMARK | `p4:rem:v4103-relative-sector-cp` | FORMALIZED | — |

## 5. Reproduction and source integrity
- **Complete claim objects:** the JSON ledger stores every theorem/lemma/proposition/corollary/definition/remark with verbatim LaTeX, statement/source line range, exact proof text and line range where present, named references and resolved latest-source locations, E2/E3/E4 proof scopes, issue records, positive and negative controls, typed constitutional boundaries.
- **Executable checks:** `Paper4B-Batch02Checks-v1_1.py` generates `Paper4B-Batch02Checks-v1_1.json`; 26/26 passed. A calculation-level E3 is identified by its actual subclaim, not promoted to an unrelated physical realization.
- **Current source index:** 30 Paper TeX roots, 13560 unique LaTeX labels, unresolved references in this batch: []. Refs are not automatically DAG material-dependency edges.
- **Provenance:** mathematical TeX statements are text-identical to v2.370, with macro input changing only to `Macros-v2_174.tex`. File SHA256 11b93140dc5c53854a382763fde536862e8d979f65ba8e37c1af562b23bdab6f.
- **Continuation:** audit source lines 4711–12149 with remaining named claims and 111 proof environments in subsequent batches; do not close the full-paper audit yet.
