#!/usr/bin/env python3
"""Independent algebra and adversarial boundary tests for Paper IV-B batch 01.
 Source: Paper4B-QuantumResponse-v1_42.tex, lines 65--2240.
 These computational controls are E2, not proofs of global physical occurrence.
"""
import numpy as np
import sympy as sp
from math import sqrt
results=[]
def record(id, ok, evidence):
    results.append({'check':id,'passed':bool(ok),'evidence':evidence})
    if not ok: raise AssertionError(id + ': ' + evidence)

# Kähler and positive frequency from quadratic Hessian, no continuum assumption.
w1,w2=sp.symbols('w1 w2', positive=True, real=True)
O=sp.diag(w1,w2); W=sp.diag(1/w1,1/w2); Z=sp.zeros(2)
G=(Z.row_join(sp.eye(2))).col_join((-O**2).row_join(Z))
J=(Z.row_join(-W)).col_join(O.row_join(Z))
S=(Z.row_join(sp.eye(2))).col_join((-sp.eye(2)).row_join(Z))
record('E3-KAHLER-J2',sp.simplify(J*J+sp.eye(4))==sp.zeros(4) and G*J==J*G and J.T*S*J==S,'Symbolic 2-mode J^2=-I, [J,G]=0, J^T S J=S for arbitrary positive independent w1,w2')
record('E3-KAHLER-POS',S*J == sp.diag(w1,w2,1/w1,1/w2),'S J positive diagonal with entries w1,w2,1/w1,1/w2')

# Exact CAR in a 2-mode finite fermion carrier; no infinite cutoff.
sm=np.array([[0,1],[0,0]],dtype=complex); sz=np.diag([1,-1]); eye=np.eye(2)
a1=np.kron(sm,eye); a2=np.kron(sz,sm); I=np.eye(4)
record('E3-CAR',all(np.allclose(a@b+b@a, np.zeros((4,4))) for a in (a1,a2) for b in (a1,a2)) and all(np.allclose(a@b.conj().T+b.conj().T@a,I if i==j else 0*I) for i,a in enumerate((a1,a2)) for j,b in enumerate((a1,a2))),'Independent exact matrix Jordan-Wigner CAR on 2 modes')

# Exact global CCR finite top defect and zero-mode covariance.
for N in (1,2,5):
 a=np.zeros((N+1,N+1),dtype=complex)
 for n in range(1,N+1): a[n-1,n]=sqrt(n)
 com=a@a.conj().T-a.conj().T@a
 assert np.allclose(com,np.eye(N+1)-(N+1)*np.diag([0]*N+[1]))
 w=1.7; h=1.4
 Q=sqrt(h/(2*w))*(a+a.conj().T)
 P=-1j*sqrt(h*w/2)*(a-a.conj().T)
 vac=np.eye(N+1)[:,0]
 record(f'E3-FINITE-CCR-VAC-N{N}',np.allclose(vac.conj()@(Q@Q)@vac,h/(2*w)) and np.allclose(vac.conj()@(P@P)@vac,h*w/2) and abs(vac.conj()@(Q@P+P@Q)@vac)<1e-12,
 f'N={N}: trace zero, top defect only, <Q^2>=h/2w, <P^2>=hw/2, anticommutator zero')

# Pfaffian full exact identity for arbitrary 2x2 D (and symbolic 3x3 by recursion).
def pf(A):
 n=A.rows
 if n==0: return sp.Integer(1)
 return sp.expand(sum((-1)**(j+1)*A[0,j]*pf(A.extract(list(range(1,j))+list(range(j+1,n)),list(range(1,j))+list(range(j+1,n)))) for j in range(1,n)))
for n in (1,2,3):
 D=sp.Matrix(n,n,lambda i,j:sp.Symbol(f'd{i}{j}'))
 A=sp.zeros(2*n); A[:n,n:]=D; A[n:,:n]=-D.T
 record(f'E3-PFAFFIAN-n{n}',sp.expand(pf(A)-(-1)**(n*(n-1)//2)*D.det())==0,'Independent Pfaffian recursive expansion equals claimed block determinant sign, symbolic generic matrix')

# Fixed finite source min eigenvalue, convexity and two finite inequalities.
H=np.array([[0,0.32],[0.32,1.8]]); O=np.array([[1.0,0.2],[0.2,-0.4]])
vals,vecs=np.linalg.eigh(H); rho=np.outer(vecs[:,0],vecs[:,0]);N=2
q=np.trace(rho@O)/N; delta=np.trace(rho@(H-vals[0]*np.eye(2)))/N
hs=np.linspace(-1,1,401)
pressure=np.array([(vals[0]-np.linalg.eigvalsh(H-h*O)[0])/N for h in hs])
convex=np.min(np.diff(pressure,2))>=-1e-8
ineq=all(pressure[i] >= hs[i]*q-delta-1e-10 and (pressure[i+1]-pressure[i])/(hs[i+1]-hs[i])>=(pressure[i]-pressure[200])/hs[i]-1e-7 for i in range(201,400))
record('E2-ENERGY',convex and ineq,'Finite 2x2 source family: pressure convex and stated variational / one-sided slope inequalities')

# Whitened same-carrier semigroup with noncommuting covariance; incorrect unwhitened requirement rejected.
h=1.0; C0=np.array([[2.0,0.6],[0.6,1.0]]); H=np.array([[2.0,0.3],[0.3,4.0]])
Ce,Cu=np.linalg.eigh(C0); C12=Cu@np.diag(np.sqrt(Ce))@Cu.T; Ci12=Cu@np.diag(1/np.sqrt(Ce))@Cu.T
He,Hu=np.linalg.eigh(H)
def eH(t):return Hu@np.diag(np.exp(-He*t))@Hu.T
def cov(t):return C12@eH(t)@C12
S1=Ci12@cov(.3)@Ci12; S2=Ci12@cov(.7)@Ci12; T1=cov(.3)@np.linalg.inv(C0)
record('E3-WHITENED-SEMIGROUP',np.allclose(S1@S2,eH(1.0)) and not np.allclose(T1,T1.T),'Noncommuting SPD C0,H: exact whitened semigroup; unwhitened T not Hermitian')

# Canonical source pullback for stationary oscillator H(t)=scalar h(t) affects generator.
t,eps=sp.symbols('t eps',real=True)
phi=t+eps*t*(1-t); scalarH=t**2+3*t+1
Hpull=sp.diff(phi,t)*scalarH.subs(t,phi)
linear=sp.diff(Hpull,eps).subs(eps,0); xi=t*(1-t)
record('E3-TIME-PULLBACK',sp.simplify(linear-(xi*sp.diff(scalarH,t)+sp.diff(xi,t)*scalarH))==0,'Exact arbitrary scalar generator example: δH=xi dotH+dotxi H')

# Finite Green jump and positive-frequency map, symbolic oscillator frequency.
t,omega=sp.symbols('t omega',positive=True)
s=sp.sin(omega*t)/omega
record('E3-GREEN-JUMP',sp.simplify(sp.diff(s,t,2)+omega**2*s)==0 and s.subs(t,0)==0 and sp.diff(s,t).subs(t,0)==1,'Retarded/advanced Green functions: homogeneous ODE and unit distributional derivative jump')

# Source amplitude warning: differential signs of normalized ground energy retained.
h=sp.symbols('h',real=True); E0=sp.sqrt(1+h*h)
p=(1-E0)/2
record('E2-ENERGY-VAC-SHIFT',sp.diff(p,h)!=0,'An h-dependent vacuum subtraction changes derivative: supports no-drop physical derivative warning')

if __name__=='__main__':
 import json, pathlib
 dest=pathlib.Path('/mnt/data/work4b/Paper4B-Batch01Checks-v1_1.json')
 dest.write_text(json.dumps({'scope':'Paper4B lines 65-2240','classification':'Symbolic exact small-sector checks E3 on stated algebra identities; finite sampled controls E2, no actualization','checks':results},indent=2))
 print('Passed',sum(x['passed'] for x in results),'/',len(results),'checks; wrote',dest)
