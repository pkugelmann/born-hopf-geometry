# Paper IV-B — rigorous verification DAG audit, Batch 03

**Artifact:** `Paper4B-RigorousBatch03-v1_1.md` | **Protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md` | **Current paper corpus:** v2.371
**Source freeze:** `Paper4B-QuantumResponse-v1_42.tex` SHA256 `11b93140dc5c53854a382763fde536862e8d979f65ba8e37c1af562b23bdab6f`. Compared with the Batch 1 initial freeze, current math is unchanged; only the macro input path switched from `Macros-v2_173.tex` to `Macros-v2_174.tex`.
**Atlas baseline:** latest supplied `Paper00-DAGAtlas-v1_107(1).zip`; **audit archive baseline:** latest supplied `Paper00-ProofChainAudits-v1_24(1).zip`. Neither was modified.

## 1. Coverage, evidence and verdict
- **Bounded source:** lines 4711–7996 (complete “Complete charged-source dynamics and transport” and “Source-cyclic resolvents and physically visible poles” sections).
- **This batch:** 53 named theorem/lemma/proposition/corollary/remark units, 46 source proof environments (44 attached to named statements, two attached to material unnamed equations); **cumulative:** 149/227 named, 111/176 proofs.
- **Verbal verdicts:** {'VERIFIED-CONDITIONAL': 40, 'FORMALIZED': 8, 'REPRODUCED': 3, 'VERIFIED': 2}. This batch contains **zero additional established source-as-printed mathematical defects**.
- **Independent E2/E3 and boundary E4 checks:** 32/32 passed. See exact check identifiers and numerical traces in `Paper4B-Batch03Checks-v1_1.json` and executable script `Paper4B-Batch03Checks-v1_1.py`. Each test is limited to the actual subclaim and domain stated by its scope.
- **Carry-forward, not newly reopened:** `BH-G-000100` Euclidean restricted-composition versus global exponential weight (major), and `BH-G-000101` kinetic graph connectivity versus complete Gibbs collision-invariant classification (moderate), both originating in Batch 2.
- **Review independence:** one coordinating analyst with separately written source replay, finite numeric/symbolic tests and adversarial boundary checks; true multi-agent parallelism was not available and is not asserted.

## 2. Distinct checked source claims and exact physical scopes

### 2.1 Sector sources and charge transport (lines 4711–5548)
- Orthogonal projector block decomposition and commuting charged sector observables are exact for the *given distinguished* `P_a`. Full trace-neutral rank-three Weyl words and family partial trace reproduce; no new physical family projector is selected by ambient matrix algebra.
- Off-diagonal transitions, time-dependent Dyson sector mixing and finite detuning thresholds satisfy the source finite-time formulas. Finite unitary evolution alone is neither an irreversible decay width nor an actual observed channel.
- The generated charged pair member retains its upstream **Paper II-A** owner-relative proof premises, including support/source occurrence; no previously established `m_p=1` or `H_1` theorem is challenged.
- Exact pair-source CAR charge transformation, normal-ordering constants and two-mode Nambu covariance evolution were checked by explicit Fock matrices. The source does not assert that this two-mode model by itself reconstructs the full physical charge-current Hamiltonian.
- Exact CAR pair commutator and arbitrary-state first/second Dyson insertions agree; no vacuum-only substitution of a generic finite state was used.

### 2.2 Fidelity, finite occupation and least charge flow (lines 5549–6669)
- Source-stationary quotient and tagged dynamical fidelity preserve complete source moments and nonnegative leakage. An explicit state-family adversarial E4 check demonstrates why one stationary state with zero response is insufficient for a full-family statement; the source correctly quantifies over the stationary family.
- The weak occupied-Slater return formula was tested with distinct noncommuting bosonic coefficient words and both cross terms. The filled chiral branch is not replaced by a vacuum estimate.
- Adjacent number sectors and finite resolvent identities, full charge continuity and the top-occupation commutator boundary reproduce under their declared Fock cutoffs; the boundary defect prevents silently imposing unrestricted CCR.
- The UV Bogoliubov and protected chiral-bilinear comparison claims explicitly import Paper IV-C and III-F physical data; they remain `REPRODUCED` at the imported physical-dynamics layer, not newly established gaps.

### 2.3 Source-visible poles and minimal polynomials (lines 6670–7996)
- Source C1 noncommuting bilinear commutators, entangled coefficient pairing, commuting-port Gram matrix and conditional charge-equivariant reductions are tested without substituting a scalar trace for a full source response.
- For a fixed full Hamiltonian H, state density ρ and physical source `q`, finite source-cyclic Stieltjes resolvents have actual visible frequencies and positive semidefinite residues; a full `H` eigenvalue with zero source residue is **not** an observable pole.
- Exact stationary support, including complete ground-state degeneracy, controls the cyclic polynomial and degree bound. The Hankel/pencil closure and common-family intertwiner criteria recover a polynomial only on the certified cyclic source span.
- A finite cyclic intertwiner can preserve pole roots without preserving residues. Central shifts `H→H+cI` are invisible to fixed-chart commutator/pole readout and normalized Gibbs densities, but not to absolute energy/stress/metric variations.
- The extra 9×9 weak-receiver determinant is an exact **conditional diagnostic** requiring additional complete-source cyclic closure, not a claim that the physical interacting electron source has exactly nine cyclic directions. The interacting two-mode witness shows precisely why source visibility depends on the actual full dynamics.

## 3. Constitutional boundary / observable firewall
- `BND-IVB-03-001` preserves source-chosen sector and representation ownership. Mathematically available `End(H)` projectors cannot self-constitute physical family sectors.
- `BND-IVB-03-002` retains **every** admitted interaction/remainder source in full `H`; the bilinear free/mass-only truncation is not a physical complete-pole certificate.
- `BND-IVB-03-003` retains actual stationary-state family and full support. A single density is not interchangeable with all admissible stationary states.
- `BND-IVB-03-004` distinguishes an algorithm for a source-visible pole from actually predicting the electron mass or a physical terminal value. Needed: actual full H, state/support, nonzero source residue and particle identification, subject to the existing source scopes.
- None of these *already explicit* conditional realization boundaries is introduced as a new constitutional axiom or incorrectly promoted to a source defect.

## 4. Named result source-anchor and status census
| # | Line | Kind | Source label | Verdict | Proof |
|--:|--:|---|---|---|:---:|
| 1 | 4766 | THEOREM | `p4:thm:sector-compatible-observables` | VERIFIED-CONDITIONAL | yes |
| 2 | 4820 | COROLLARY | `p4:cor:sector-vs-mixing-observables` | VERIFIED-CONDITIONAL | yes |
| 3 | 4841 | PROPOSITION | `p4:prop:trace-neutral-finite-word-selection` | VERIFIED-CONDITIONAL | yes |
| 4 | 4869 | REMARK | `p4:rem:trace-neutral-selection-status` | FORMALIZED | — |
| 5 | 4908 | PROPOSITION | `p4:prop:finite-family-factors` | VERIFIED-CONDITIONAL | yes |
| 6 | 4949 | COROLLARY | `p4:cor:rank-three-family-sectors` | VERIFIED-CONDITIONAL | yes |
| 7 | 4994 | PROPOSITION | `p4:prop:finite-sector-transition` | VERIFIED-CONDITIONAL | yes |
| 8 | 5021 | REMARK | `p4:rem:sector-transition-meaning` | FORMALIZED | — |
| 9 | 5060 | PROPOSITION | `p4:prop:finite-threshold` | VERIFIED-CONDITIONAL | yes |
| 10 | 5098 | REMARK | `p4:rem:effective-threshold-language` | FORMALIZED | — |
| 11 | 5117 | THEOREM | `p4:thm:finite-multiplet-mixing` | VERIFIED-CONDITIONAL | yes |
| 12 | 5175 | COROLLARY | `p4:cor:v4101-generated-pair-member-handoff` | REPRODUCED | yes |
| 13 | 5217 | REMARK | `p4:rem:v4101-exact-charge-scope` | FORMALIZED | — |
| 14 | 5240 | THEOREM | `p4:thm:v4102-pair-charge-source` | VERIFIED-CONDITIONAL | yes |
| 15 | 5295 | THEOREM | `p4:thm:v4102-finite-car-charge-propagation` | VERIFIED-CONDITIONAL | yes |
| 16 | 5348 | REMARK | `p4:rem:v4102-charge-propagation-scope` | FORMALIZED | — |
| 17 | 5360 | COROLLARY | `p4:cor:v498-phase-locked-pairing-invariant` | VERIFIED-CONDITIONAL | yes |
| 18 | 5398 | REMARK | `p4:rem:v4102-relative-phase-scope` | FORMALIZED | — |
| 19 | 5426 | LEMMA | `p4:lem:v2167-pair-commutator` | VERIFIED | yes |
| 20 | 5442 | THEOREM | `p4:thm:v2167-inherited-pair-coefficients` | VERIFIED-CONDITIONAL | yes |
| 21 | 5488 | COROLLARY | `p4:cor:v2167-returned-pair-kernel` | VERIFIED-CONDITIONAL | yes |
| 22 | 5549 | PROPOSITION | `p4:prop:v2168-stationary-source-quotient` | VERIFIED-CONDITIONAL | yes |
| 23 | 5634 | THEOREM | `p4:thm:v2168-dynamical-fidelity` | VERIFIED-CONDITIONAL | yes |
| 24 | 5681 | COROLLARY | `p4:cor:v2168-positive-source-leakage` | VERIFIED-CONDITIONAL | yes |
| 25 | 5722 | THEOREM | `p4:thm:v2168-stationary-family-fidelity` | VERIFIED-CONDITIONAL | yes |
| 26 | 5888 | THEOREM | `p4:v2169:b11:thm:normalstate` | VERIFIED-CONDITIONAL | yes |
| 27 | 5940 | REMARK | `p4:rem:v239-gibbs-support-scope` | FORMALIZED | — |
| 28 | 5981 | THEOREM | `p4:v2169:b11:thm:weakslater` | VERIFIED-CONDITIONAL | yes |
| 29 | 6173 | THEOREM | `p4:v2169:b12:thm:adjacentnumber` | VERIFIED-CONDITIONAL | yes |
| 30 | 6230 | COROLLARY | `p4:v2169:b12:cor:onefermion` | VERIFIED-CONDITIONAL | yes |
| 31 | 6370 | THEOREM | `p4:v2171:thm:fullcharge` | VERIFIED-CONDITIONAL | yes |
| 32 | 6427 | THEOREM | `p4:v2171:thm:flow` | VERIFIED-CONDITIONAL | yes |
| 33 | 6494 | THEOREM | `p4:v2171:thm:capcommutator` | VERIFIED-CONDITIONAL | yes |
| 34 | 6546 | PROPOSITION | `p4:prop:v2219-uv-bogoliubov` | REPRODUCED | — |
| 35 | 6563 | REMARK | `UNLABELED:Paper4B:remark:6563` | FORMALIZED | — |
| 36 | 6580 | COROLLARY | `p4:cor:v228-charged-bilinear` | VERIFIED-CONDITIONAL | yes |
| 37 | 6603 | PROPOSITION | `p4b:prop:v240-protected-chiral-source-splitting` | REPRODUCED | yes |
| 38 | 6624 | THEOREM | `p4b:thm:v240-complete-one-source-stieltjes` | VERIFIED-CONDITIONAL | yes |
| 39 | 6699 | THEOREM | `p4:thm:v2168-bilinear-source-commutators` | VERIFIED-CONDITIONAL | yes |
| 40 | 6755 | PROPOSITION | `p4:prop:v2168-coefficient-pairing` | VERIFIED | yes |
| 41 | 6791 | THEOREM | `p4:thm:v2168-commuting-port-memory-gram` | VERIFIED-CONDITIONAL | yes |
| 42 | 6856 | PROPOSITION | `p4:prop:v2168-equivariant-charge-reduction` | VERIFIED-CONDITIONAL | yes |
| 43 | 6934 | THEOREM | `p4:thm:v2168-faithful-stationary-poles` | VERIFIED-CONDITIONAL | yes |
| 44 | 7012 | COROLLARY | `p4:cor:v2168-support-family-visibility` | VERIFIED-CONDITIONAL | yes |
| 45 | 7057 | THEOREM | `p4:thm:v2168-regular-gap-root-bound` | VERIFIED-CONDITIONAL | yes |
| 46 | 7198 | THEOREM | `p4:v2169:b7:thm:closure` | VERIFIED-CONDITIONAL | yes |
| 47 | 7248 | THEOREM | `p4:v2169:b7:thm:poles` | VERIFIED-CONDITIONAL | yes |
| 48 | 7420 | THEOREM | `p4:v2169:b10:thm:support` | VERIFIED-CONDITIONAL | yes |
| 49 | 7637 | COROLLARY | `p4:cor:v2174-full-ground-degree-bound` | VERIFIED-CONDITIONAL | yes |
| 50 | 7715 | LEMMA | `p4:lem:v2186-exact-source-cyclic-action` | VERIFIED-CONDITIONAL | yes |
| 51 | 7756 | THEOREM | `p4:thm:v2186-common-source-cyclic-polynomial` | VERIFIED-CONDITIONAL | yes |
| 52 | 7815 | COROLLARY | `p4:cor:v2186-source-cyclic-residue-scope` | VERIFIED-CONDITIONAL | yes |
| 53 | 7837 | COROLLARY | `p4:cor:v2186-scalar-center-pole-invisibility` | VERIFIED-CONDITIONAL | yes |

## 5. Reproducibility, traceability and continuation
- The ledger contains the **verbatim current LaTeX statement**, exact span, proof (when displayed), named `\ref`/`\eqref` citations resolved to their current root file, status/reason, scoped independent check names, provisional condition boundaries and verified typed in-batch material routes. The ledger does not promote mere citations to proof edges.
- Additionally reviewed substantive unnamed response equations at `p4:eq:v2169-b7-d2`, `p4:eq:v2169-b7-d4`, with two standalone exact proof environments for `p4:eq:v2169-b11-l12` and `p4:eq:v2169-b12-n6`. All are recorded with actual source spans.
- Current source index: 30 TeX manuscripts, 13560 unique labels, unresolved referenced labels in this batch: [].
- No source, macros, bibliography, original archive, canonical DAG or proof-chain audit ZIP was edited in this checkpoint.
- **Remaining target:** lines 7997–12149, 78 named statements and 65 proof environments. Next batch begins with “Measurement histories, boundary work and retained excitation.”
- Global source condition ancestry, cross-paper impacts and latest-only canonical DAG/proof-chain ZIPs remain explicitly **reserved for final batch**.
