#!/usr/bin/env python3
"""Exact bounded controls for existing II-B claims at1112–2244; stdlib only.
General arguments and physical-source guards are recorded separately.
"""
from fractions import Fraction as F
from collections import defaultdict
from itertools import product, permutations
from math import comb
from pathlib import Path
import json
checks=defaultdict(int)
def check(ok,group):
    assert ok,group
    checks[group]+=1

def z(n,m=None):return [[F(0) for _ in range(m or n)] for _ in range(n)]
def eye(n):
    a=z(n)
    for i in range(n):a[i][i]=1
    return a
def plus(a,b):return [[v+w for v,w in zip(r,s)] for r,s in zip(a,b)]
def times(c,a):return [[c*v for v in r] for r in a]
def minus(a,b):return plus(a,times(-1,b))
def mul(a,b):return [[sum((a[i][k]*b[k][j] for k in range(len(b))),F(0)) for j in range(len(b[0]))] for i in range(len(a))]
def tr(a):return sum((a[i][i] for i in range(len(a))),F(0))
def trans(a):return list(map(list,zip(*a)))
def kron(a,b):return [[a[i//len(b)][j//len(b[0])]*b[i%len(b)][j%len(b[0])] for j in range(len(a[0])*len(b[0]))] for i in range(len(a)*len(b))]
def unit(n,i,j):
    a=z(n);a[i][j]=1;return a
T=[(0,0),(1,0),(0,1),(1,1),(2,0),(0,2)]
dims=[(a+1)*(b+1) for a,b in T]
check(dims==[1,2,2,4,3,3] and sum(dims)==15,'six_type_dimensions')
check(max(a+b for a,b in T)==2,'support_level')
# SU2 Weyl integration computed as a Laurent constant coefficient oracle.
def char_inner(n,m):
    counts=defaultdict(int)
    for a in range(-n,n+1,2):
        for b in range(-m,m+1,2):counts[a-b]+=1
    return counts[0]-counts[-2]
G=[[char_inner(a,c)*char_inner(b,d) for c,d in T] for a,b in T]
check(G==eye(6),'independent_character_gram')
for ms in product([1,2],repeat=6):
    dc=sum(d*m for d,m in zip(dims,ms))-15
    cc=sum(m*m for m in ms)-6
    coeff=[m-1 for m in ms]
    chi=sum(coeff[i]*G[i][j]*coeff[j] for i in range(6) for j in range(6))
    check(dc==sum(d*(m-1) for d,m in zip(dims,ms)),'dimension_excess')
    check(cc==sum(m*m-1 for m in ms),'commutant_excess')
    check(chi==sum((m-1)**2 for m in ms),'character_excess')
    check((dc==0)==(cc==0)==(chi==0)==all(m==1 for m in ms),'multiplicity_zero_equivalence')
# Exact weight moments from all six inequivalent modules.
weights=[F(a-2*i-b+2*j,2) for a,b in T for i in range(a+1) for j in range(b+1)]
check(len(weights)==15,'component_weight_dimension')
check(sum(w*w for w in weights)==7,'component_second_moment')
check(sum(w**4 for w in weights)==F(25,4),'component_fourth_moment')
for k in range(1,5):
    for n in range(7):check(sum(w**n for w in weights*k)/F(15*k)==sum(w**n for w in weights)/15,'normalized_replication_moments')
# Smooth-mode Gram matrices from exact isotropic moments on S3, volume normalized1.
delta=lambda a,b:F(a==b)
m2=lambda a,b:delta(a,b)/4
m4=lambda a,b,c,d:(delta(a,b)*delta(c,d)+delta(a,c)*delta(b,d)+delta(a,d)*delta(b,c))/24
for a,b in product(range(4),repeat=2):
    check(F(4,3)*(delta(a,b)-m2(a,b))==delta(a,b),'normalized_gradient_form_gram')
wedges=[(a,b) for a in range(4) for b in range(a+1,4)]
for a,b in wedges:
    for c,d in wedges:
        # P_ac P_bd−P_ad P_bc with P=I−xx^T/R².
        ip=delta(a,c)*delta(b,d)-delta(a,d)*delta(b,c)-delta(a,c)*m2(b,d)-delta(b,d)*m2(a,c)+delta(a,d)*m2(b,c)+delta(b,c)*m2(a,d)+m4(a,c,b,d)-m4(a,d,b,c)
        check(2*ip==F((a,b)==(c,d)),'normalized_wedge_form_gram')
# Signed SO4 subgroup twirl: all even sign flips kill cross entries;
# all even permutations equalize diagonals, without Haar integration.
f=[F(1),F(2),F(-1),F(3)]
def parity(p):return (-1)**sum(p[i]>p[j] for i in range(len(p)) for j in range(i+1,len(p)))
twirl=z(4);count=0
for p in permutations(range(4)):
    if parity(p)!=1:continue
    for signs in product([-1,1],repeat=4):
        if signs[0]*signs[1]*signs[2]*signs[3]!=1:continue
        v=[signs[i]*f[p[i]] for i in range(4)]
        twirl=plus(twirl,[[a*b for b in v] for a in v]);count+=1
check(times(F(1,count),twirl)==times(sum(v*v for v in f)/4,eye(4)),'finite_SO4_orbit_twirl')
# Observable quotient: two inequivalent sectors (d,m)=(2,2),(1,2).
sectors=[(2,2),(1,2)];N=sum(d*m for d,m in sectors);D=sum(d for d,m in sectors)
offs=[];h=k=0
for d,m in sectors:offs.append((h,k,d,m));h+=d*m;k+=d

def Q(a):
    b=z(D)
    for h,k,d,m in offs:
        for i,j in product(range(d),repeat=2):b[k+i][k+j]=sum(a[h+i*m+t][h+j*m+t] for t in range(m))
    return b

def jmap(a):
    b=z(N)
    for h,k,d,m in offs:
        for i,j in product(range(d),repeat=2):
            for t in range(m):b[h+i*m+t][h+j*m+t]=a[k+i][k+j]
    return b

def S(a):
    b=z(N)
    for h,k,d,m in offs:
        for i,j in product(range(d),repeat=2):
            for t in range(m):b[h+i*m+t][h+j*m+t]=a[k+i][k+j]/m
    return b

Ab=[]
for h,k,d,m in offs:
    for i,j in product(range(d),repeat=2):Ab.append(unit(D,k+i,k+j))
for a in Ab:
    check(Q(S(a))==a,'quotient_right_inverse')
    for b in Ab:check(jmap(mul(a,b))==mul(jmap(a),jmap(b)),'quotient_star_isomorphism')
    for r,s in product(range(N),repeat=2):
        rho=unit(N,r,s)
        check(tr(mul(rho,jmap(a)))==tr(mul(Q(rho),a)),'quotient_expectation_pairing')
for a in Ab:check(trans(jmap(a))==jmap(trans(a)),'quotient_star_isomorphism')
check(jmap(eye(D))==eye(N),'quotient_unit')
# Explicit invisible traceless Hermitian direction and effect witness.
E=z(N);E[0][0]=1;E[1][1]=-1
check(Q(E)==z(D) and tr(E)==0 and tr(mul(E,E))==2,'quotient_converse_witness')
eps=F(1,2*N)
rhop=plus(times(F(1,N),eye(N)),times(eps,E));rhom=minus(times(F(1,N),eye(N)),times(eps,E))
check(all(rhop[i][i]>0 and rhom[i][i]>0 for i in range(N)),'quotient_density_witness')
check(Q(rhop)==Q(rhom) and tr(mul(minus(rhop,rhom),E))==4*eps,'quotient_effect_non_descent')
# Exact process positive and negative controls on one V2⊗M2 block.
Z=[[1,0],[0,-1]];X=[[0,1],[1,0]];I=eye(2)
U=kron(X,I);C=z(4)
for v,m in product(range(2),repeat=2):C[(v^m)*2+m][v*2+m]=1
blindZ=kron(Z,I)
check(mul(trans(U),mul(blindZ,U))==times(-1,blindZ),'process_descends_control')
check(mul(trans(C),mul(blindZ,C))==kron(Z,Z),'process_non_descends_control')
# Diagonal SU2 singlet commutes with total sl2 generators; marginalsI2/2.
sing=z(4);sing[1][1]=sing[2][2]=F(1,2);sing[1][2]=sing[2][1]=F(-1,2)
Jz=times(F(1,2),Z);Jp=[[0,1],[0,0]];Jm=trans(Jp)
for A in [Jz,Jp,Jm]:
    total=plus(kron(A,I),kron(I,A))
    check(mul(total,sing)==mul(sing,total),'singlet_invariant')
marg=[[sum(sing[2*i+k][2*j+k] for k in range(2)) for j in range(2)] for i in range(2)]
check(marg==times(F(1,2),I),'singlet_nonproduct_marginal')
check(mul(sing,sing)==sing and tr(sing)==1,'singlet_pure_positive')
# Native operation-algebra connected-component arithmetic and state weights.
for d in range(1,5):
    for p in [F(0),F(1,3),F(1)]:check(11*d*p/F(11*d)+4*d*(1-p)/F(4*d)==1,'mixed_native_density_trace')
check(11*11==121 and 11*4+4*11==88 and 4*4==16,'exchange_component_dimensions')
check(sum([121,88,16])==225,'native_total_dimension')
for a,b,c in [(F(1),F(0),F(0)),(F(1,3),F(1,3),F(1,3)),(F(121,225),F(88,225),F(16,225))]:
    check(121*a/121+88*b/88+16*c/16==1,'native_density_trace')
check(F(11,15)/11==F(4,15)/4==F(1,15),'native_full_trace_fractions')
check(F(121,225)/121==F(88,225)/88==F(16,225)/16==F(1,225),'paired_native_full_trace_fractions')
# Universal GP3 implication is an order theorem, here only its exact propositional guard.
for complete,generated,proper,surplus,irreducible in product([False,True],repeat=5):
    antecedent=complete and generated and proper and irreducible
    consistency=not(complete and generated and proper and surplus and irreducible)
    if consistency:check(not antecedent or not surplus,'gp3_conditional_truth_table')
result={'script':Path(__file__).name,'status':'PASS','assertions':sum(checks.values()),'groups':dict(checks),'scope':'Existing Paper2B source1112–2244; 17 main claim targets.','limitations':['Finite controls supplement universal analytic certificates.','The GP3 truth-table control checks the conditional inference only; no comparator existence is certified.','Native algebra dimensions use source nonzero-edge and exchange hypotheses.','No physical state/preparation/test occurrence is asserted.']}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
