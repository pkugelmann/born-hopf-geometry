import json,hashlib
from pathlib import Path
root=Path('/workspace/scratch/6302724ed082')
source=root/'work/corpus/Paper2B-MomentumCarrier-v2_135.tex'
s=source.read_text(); lines=s.splitlines()
census=json.loads((root/'work/proposals/census/Paper2B-ClaimCensus-v1_1.json').read_text())['claims']
entries=[c for c in census if 1112<=c['complete_span']['start_line']<=1886]
checks={
'p2:thm:momentum-host-H1':{
 'reasoning':['E0,S+,S−,E1 are the frozen frontier objects. The separately checked same-role bracket-image corollary supplies the finite section-object types (1,0) and (0,1); retaining merely their induced operations does not discharge object typing.','The six irreducibles are inequivalent, with dimensions1,2,2,4,3,3. Their one-copy type-support representative therefore has dimension15. I-A Sym²(S+⊕S−)=(1,0)⊕(1/2,1/2)⊕(0,1) supplies a representation identity, not a physical symmetric-square constructor.','Constructor-relative no-insertion excludes higher types from unlicensed scalar multiplication and arbitrary tensor powers. The allowed gradient/bracket object words have closure in the previously established four-gradient plus six-Killing module, with the gradient image identified with E1 by its normalized port; no new type arises by their licensed brackets.','No-omission excludes every proper subset of these generated types, including E9 which lacks both adjoint object types. The theorem permits arbitrary positive unmarked implementation multiplicities and does not prove universal one-copy physical carriers.'],
 'direct_premises':['p2:def:momentum-seed-frontier','p2b:cor:bracket-image-same-carrier','p2b:lem:gradient-port','p2b:prop:conformal-host-closure','p1:prop:h1-symmetric-exterior-form'],
 'domain':'GP1-finite, GP2-exact/host-faithful realizations of the specific frozen initial momentum-seed frontier; type support only.',
 'conditions':'Already constituted seed and constructor-relative GP2 typing; no GP3 universal comparison premise.'},
'p2b:cor:v279-six-type-multiplicity-detectors':{
 'reasoning':['For exact six-type support with mλ≥1, dimH=Σdλmλ and Σdλ=15, giving Δdim=Σdλ(mλ−1). Every coefficient is positive.','Schur decomposition gives End_K(H)=⊕M_mλ(C), dimensionΣmλ²; hence Δcom=Σ(mλ²−1).','Normalized Haar character orthogonality gives ∫|Σ(mλ−1)χλ|²=Σ(mλ−1)².','Each defect is a sum of nonnegative terms; any vanishing defect forces every multiplicity1, and that condition makes all three vanish. This is a diagnostic of a specified module, not an occurring character measurement or a universal GP3 comparison.'],
 'direct_premises':['p2:thm:momentum-host-H1'],
 'domain':'Finite unitary Spin(4) modules with exactly the six types; every mλ is a positive integer; normalized Haar measure.',
 'conditions':'Exact support and specified carrier; equality of one diagnostic must independently be established.'},
'p2b:prop:v279-no-canonical-copy-selector':{
 'reasoning':['The premise gives the full U(m) symmetry on an unmarked multiplicity slot, m>1. Transitivity on complex lines rules out any line invariant under all these symmetries.','An invariant complex linear functional L with trivial target obeys L(e^{it}v)=L(v)=e^{it}L(v), forcing L=0.','A canonical one-copy projection or nonzero retraction from only the unmarked slot would require such invariant data. The obstruction does not prohibit a generated comparison between distinct complete candidates.'],
 'direct_premises':[],
 'domain':'V≠0 irreducible and unmarked M=C^m, m>1, with all I_V⊗U(M) preserving the frozen multiplicity data.',
 'conditions':'Full U(M) invariance of multiplicity-slot data, not merely absence of a written basis.'},
'p2b:thm:v293-operational-multiplicity-quotient':{
 'reasoning':['The block map j preserves multiplication, adjoint and unit and is bijective onto exactly A_bl, with inverse reading each coefficient block. It is a *-isomorphism and basis-independent in multiplicity slots.','Partial trace of each positive diagonal isotypic block is positive. Tr Qρ=Trρ=1 and Tr(ρj(a))=Tr(Qρ a) for all a.','S(σ)=⊕σλ⊗I_mλ/mλ is positive and trace1. Partial trace of I_m/m is1, so QS=Id. Thus Q is affine and onto block-diagonal density matrices without choosing a line or subspace.','For the converse, the real Hilbert–Schmidt projection onto Hermitian A_bl gives nonzero X=E−P_A E orthogonal to every Hermitian j(a), including I. Consequently TrX=0 and Q(X)=0. For 0<ε<1/(dimH·||X||op), ρ±=I/dimH±εX are density matrices with equal Q but expectation difference2εTrX²>0.','If Φ*(A_bl)⊂A_bl, the restriction conjugated by j is UCP; trace duality yields QΦ=tildeΦ Q. Conversely, all-state quotient descent implies each Hermitian Φ*(j(a)) depends only on Qρ, and the preceding effect converse forces algebra invariance. Extend by real/imaginary linearity to all a.','All state spaces in the quotient are states of A0, represented by block-diagonal densities. The theorem does not purport to preserve coherent off-block effects absent from A_bl or to generate an occurring GP3 candidate comparison.'],
 'direct_premises':['p2b:prop:v279-no-canonical-copy-selector'],
 'domain':'Finite isotypic unitary carrier with pairwise inequivalent Vλ; specified tests exactly A_bl=⊕End(Vλ)⊗I_Mλ; specified exact process UCP in Heisenberg picture.',
 'conditions':'Exact test algebra and process-invariance condition are explicit. No whole-signature/occurrence conclusion follows automatically.'},
'p2:thm:m1-component':{
 'reasoning':['The six highest-weight types have minimal tensor-word lengths0,1,1,2,2,2 by the earlier minimal-length lemma. Positive multiplicities do not change the maximum.','Thus half the maximum word length is1 for every carrier with that exact support, independently of carrier dimension, normalized states, GP3 comparison and copy selection.'],
 'direct_premises':['p2:thm:momentum-host-H1','p2b:lem:minimal-word-length'],
 'domain':'Any GP1-finite, GP2-exact realization of the frozen seed with arbitrary positive implementation multiplicities.',
 'conditions':'No additional condition beyond exact six-type support; m_p is a representation descriptor.'},
'p2b:prop:one-copy-geometric-module':{
 'reasoning':['Take each of the six inequivalent modules once. Their total complex dimension is15.','The normalized gradient port identifies the retained E1 representation with its gradient-object image; the earlier bracket formula defines the bilinear E1×E1→Killing object incidence. Their definition does not require any multiplicity-space basis.','This constructs the stated mathematical module and object diagrams. Completeness for every operation, relation and test is explicitly reserved for the later comparison certificate; no universal GP2-exact endpoint existence is inferred.'],
 'direct_premises':['p2:thm:momentum-host-H1','p2b:lem:gradient-port','p2b:lem:canonical-bracket-image'],
 'domain':'An explicit mathematical Spin(4)-equivariant one-copy carrier presentation, not yet every complete structured physical candidate.',
 'conditions':'No GP3 premise; whole-structured completeness is not asserted.'},
'p2b:rem:m8-momentum-package-scope':{
 'reasoning':['The enriched finite momentum package, its smooth parent support and its later completed reciprocal host are distinct typed objects. A finite15-dimensional module is not thereby functions on24 support points.','Finite support atlases and coordinate classes are separate descendants; this remark makes no new representation identity or physical finite-support occurrence claim.'],
 'direct_premises':['p2:thm:momentum-host-H1'],
 'domain':'Typed relationship among momentum package, smooth support and later reciprocal-host descriptions.',
 'conditions':'No hidden equality of carrier/function algebra or duplicated sphere.'},
'p2b:thm:momentum-carrier-rigidity':{
 'reasoning':['GP2 gives all six types with positive multiplicities. Premise(i) supplies a complete admissible one-copy competitor for all frozen diagrams. Premise(ii) gives a generated role-faithful comparison from each candidate toward that competitor.','Under(iii), any candidate with a surplus multiplicity has a proper comparison, contradicting the source definition of GP3 irreducibility. Therefore each multiplicity≤1, and positivity forces exactly1.','The proof uses no ungenerated invariant-line selector and establishes no uniqueness of the entire structured endpoint. It cannot discard a genuinely generated multiplicity-sensitive test: such a test must be preserved by(ii).','The three hypotheses are explicitly additional and remain the already recorded universal comparison obligation; exact support, no copy labels and operational quotient do not discharge them.'],
 'direct_premises':['p2:thm:momentum-host-H1','p2b:prop:one-copy-geometric-module','p2:post:GP3'],
 'domain':'GP3-irreducible complete GP1/GP2 structured realizations of the frozen seed satisfying all three additional comparison clauses.',
 'conditions':'Reuse BH-IIA-A-B54-CMP-I-001, BH-IIA-A-B54-CMP-II-001, BH-IIA-A-B54-CMP-III-001; existing frontier BH-IIB-STRUCTURED-RIGIDITY-001. Conditional theorem is valid.'},
'p2b:rem:gp3-structured-certificate-obligation':{
 'reasoning':['The remark correctly separates complete candidate-internal one-copy exactness(i), universal generated incidence comparison(ii) and strictness(iii). Prior object-port and type-support diagrams supply necessary components only.','Current II-F conditional multiplicity-reduction proposition also explicitly assumes a generated proper whole-candidate comparison; it does not prove it merely from unmarked multiplicity blindness.'],
 'direct_premises':['p2b:thm:momentum-carrier-rigidity','p2:prop:gp3-multiplicity-bound'],
 'domain':'Explicit currently open antecedent-discharge boundary of the universal physical-carrier statement.',
 'conditions':'Same existing three comparison conditions; no new issue or axiom.'},
'p2b:thm:canonical-retained-smooth-realization':{
 'reasoning':['The imported I-A theorem provides the same e0,u_a,w_ab definitions and phase-qualified equivalence class. Its exact integral identities are ∫<dxa,dxb>=3V/4δab and ∫<dxa∧dxb,dxc∧dxd>=V/2(δacδbd−δadδbc). The displayed constants normalize the modes.','Different form degrees and spinor slots are orthogonal in the direct-sum Hilbert model; dimensions1+4+6+2+2=15.','The form modules carry(0,0),(1/2,1/2),(1,0)⊕(0,1) and the spinors supply(1/2,0),(0,1/2). Thus they match the six one-copy support modules.','Metric musical map plus Hodge star gives an equivariant isomorphism from Killing fields to the retained two-form module, with its unitary normalization supplied by the imported model.','Schur lemma makes unitary intertwiners unique up to one phase per inequivalent irreducible. Orientation reversal exchanges the two bivector labels and changes no unordered unitary class.','This identifies the explicit one-copy mathematical model; the theorem is not an unconditional multiplicity-one assertion for all physical endpoints.'],
 'direct_premises':['p1:thm:canonical-retained-smooth-model','p2:thm:momentum-host-H1','p2b:prop:one-copy-geometric-module','p2b:lem:canonical-bracket-image'],
 'domain':'Round S3(R), R>0; natural equivariant unitary class between the one-copy generated model and explicit smooth retained-mode model.',
 'conditions':'Unmarked sector phases/orientation labels are equivalences. No coordinate-completion point, ambient lift or kinetic operator is selected.'},
'p2b:cor:momentum-seed-constituent-corealization':{
 'reasoning':['The support theorem identifies the complete nonredundant generated constituent list, with no alternative selection between spinors or adjoint types.','The upstream constituent co-realization theorem requires a frozen finite generated-constituent presentation of an occurring root composite. The declared transfer-operation root and frozen seed provide exactly that application scope.','GP2 no-omission retains each listed native constituent under the same witness, with no assertion that every vector, outcome or prepared state in a constituent occurs.'],
 'direct_premises':['p2:thm:momentum-host-H1','p2:thm:generated-constituent-corealization','p2:def:momentum-seed-frontier'],
 'domain':'Conditional on the transfer-operation root occurring in the source-defined G0 sense and the frozen generated seed presentation.',
 'conditions':'Occurrence of source root; constituent-level co-realization only.'},
'p2b:cor:physical-momentum-carrier-corealization':{
 'reasoning':['The source root occurrence and generated-role/constituent rules retain the round parent and its exact common support with one occurrence witness.','The support theorem and word-length corollary supply G^car≅H1 and m_p=1 at type-support scope.','The additional full-carrier assertion invokes precisely the three GP3 comparison hypotheses; their presence is explicit in statement and proof. No state, measurement or calibration is inferred.'],
 'direct_premises':['p2:thm:generated-role-corealization','p2:thm:generated-constituent-corealization','p2:thm:momentum-host-H1','p2:thm:m1-component','p2b:thm:momentum-carrier-rigidity'],
 'domain':'Root-relative common momentum support; separate guarded branch for every full GP3 endpoint.',
 'conditions':'Root occurrence for both branches; three existing comparison clauses only for full-carrier branch.'},
'p2b:cor:retained-smooth-realization-corealization':{
 'reasoning':['The smooth model is a presentation of already generated one-copy constituent types. Its normalization, d, metric musical map, Hodge star and lowest spectral spaces derive from the retained oriented round metric in the declared presentation sort.','The source-generated constructor/witness-transport rule requires licensed typed words with retained inputs and nonobstructed finite output, not mere ambient availability. Here the retained smooth model supplies a finite exact presentation of the same common content; unmarked sector phases do not select extra physical data.','This transports common constituent occurrence to the derived presentation without another root. Universal full physical carrier identification remains guarded by GP3 comparison, and ambient lifts/kinetic operators remain separate target sorts.'],
 'direct_premises':['p2b:thm:canonical-retained-smooth-realization','p2b:cor:physical-momentum-carrier-corealization','p2a:thm:g0-witness-transport-derived-constructor'],
 'domain':'Natural retained smooth presentation of common already-co-realized constituent content over the same oriented round parent.',
 'conditions':'Licensed parent-metric presentation words; not automatic physical occurrence of arbitrary host constructions.'},
'p2:thm:intrinsic-coordinate-sector':{
 'reasoning':['The imported scalar spectrum has lowest nonconstant level n=1, eigenvalue3/R² and4-dimensional coordinate module(1/2,1/2). Its spectral projector depends only on the intrinsic Laplacian, not a chosen axis.','The full real SO(4) orbit of a nonzero coordinate vector is its radius sphere and spans R4. Its complexification is the irreducible(1/2,1/2) representation.','For the stated faithful object-typed coordinate port and full inherited action, retaining the nonzero output together with orbit action and object-linear operations retains the entire specific one-copy image.','The conclusion does not choose a copy in an unrelated ambient multiplicity slot, assert multiplicity-freeness of all realizations, or apply to a scalar readout lacking the object port. Proper subgroup actions may leave lines invariant.'],
 'direct_premises':['p1:thm:representation-harmonic-package','p2:lem:equivariant-truncation-no-insertion'],
 'domain':'First scalar E1 of round parent; conditional later reciprocal role with nonzero faithful coordinate-object image, full Spin(4) action and object-linear retention.',
 'conditions':'Object-typed faithful port + full-group closure + linear object operations. No new endpoint multiplicity premise.'},
'p2b:prop:v281-e1-orbit-frame-certificate':{
 'reasoning':['Haar invariance implies the rank-one orbit average P_f commutes with every SO(4) action. It is self-adjoint and nonnegative.','Any invariant self-adjoint operator on the irreducible real standard representation has invariant eigenspaces, so it is a scalar identity; no overly strong real Schur scalar assumption is needed.','Trace of each orbit rank-one operator is||f||². Normalized Haar gives traceP_f=||f||², so scalar=||f||²/4>0 and rank4.','The support of the integral lies in the orbit span; full rank therefore certifies the orbit spans all E1. The Haar integral is a mathematical certificate only.'],
 'direct_premises':['p2:thm:intrinsic-coordinate-sector'],
 'domain':'Real first harmonic E1, nonzero f, orthogonal full Spin(4) action, normalized Haar and round L2 norm.',
 'conditions':'f≠0 and full inherited symmetry; no physical averaging constructor.'},
'p2b:rem:v281-subgroup-coordinate-counterexample':{
 'reasoning':['The standard embedded SO(3) rotates the first3 ambient coordinates and fixes the fourth. Thus span(x4) is a nonzero invariant1-dimensional subspace.','This is an exact counterexample to replacing full SO(4) by an unspecified proper subgroup, not a counterexample to the preceding theorem whose full-action premise it violates.'],
 'direct_premises':['p2:thm:intrinsic-coordinate-sector'],
 'domain':'Specified proper subgroup stabilizing the fourth coordinate axis.',
 'conditions':'Sharpness demonstration, outside full-group antecedent.'},
'p2:rem:integer-coordinate-stable-deferred':{
 'reasoning':['The source distinguishes integer coordinate-stable subfamily from half-integral component envelope; this is a later optional tower interface and no premise of support or m_p derivation.','The cited II-F arithmetic likewise separates sρ=1/2 floor(2ρ) from integer m=floorρ and does not claim GP1 chooses either value.'],
 'direct_premises':['p2:thm:truncation'],
 'domain':'Optional integer-coordinate tower interface, not the frozen momentum seed.',
 'conditions':'Declared optional tower/ceiling grammar only.'},
'p2:rem:legacy-lower-ideal-pointer':{
 'reasoning':['Under the declared P_sli total-weight lower-ideal package, a finite support with maximum weight s contains exactly all types of weight≤s. This is a source-hypothesis classification, not derivation of P_sli from GP2.','The weaker-signature modules E5,E7L/R,E9 have dimensions5,7,7,9; E9 includes scalar, vector and both spinors but lacks the two3-dimensional adjoint object types. These demonstrate the earlier weaker conditions were insufficient.','In the revised frozen signature the finite bracket image is independently object-typed and same-role; deleting it violates GP2 no-omission. These old models therefore are not admissible counterexamples to the current exact-support theorem.'],
 'direct_premises':['p2:thm:gp2-exact-label-complete-level-class','p2:prop:spectral-lower-ideal-sharpness','p2b:cor:bracket-image-same-carrier'],
 'domain':'Optional P_sli or superseded weaker signatures compared with current frozen momentum signature.',
 'conditions':'Package-relative classifications and exact current object-typing distinction.'},
'BH-IIB-CENSUS-U006':{
 'reasoning':['The interface ledger repeats support and m_p conclusions with explicit GP2-relative/GP3-guarded scope; it does not collapse one-copy representative dimension into a full-carrier theorem.','II-F component-spectrum truncation supplies jL+jR≤sρ for declared Pceil only. The word-budget identity supplies the multiplicity-free total-weight prefix only after declaring that word stage.','Invariant state weights require their separate hypotheses; the normalized trace is not inferred merely from symmetry. (The detailed state theorem is outside this E1A package and owned by the other batch reviewer.)','II-F protected even Clifford theorem explicitly specializes C_PI and gives real dimensions8 and7; finite exceptional support weights explicitly require Supp_2T plus constituted transitive actions. These table rows match their cited scopes.','The following selector-status list consistently separates generated common momentum content, conditional branch data, root occurrences/calibration and mathematical presentation infrastructure.'],
 'direct_premises':['p2:thm:momentum-host-H1','p2:thm:m1-component','p2b:thm:momentum-carrier-rigidity','p2:thm:truncation','p2:thm:finite-spectral-exhaustivity','p2:thm:minimal-hilbert-structural-15','p2:cor:paper1-octet-descendant-weight-closure'],
 'domain':'Summary interface ledger with explicit per-row boundaries; cited optional scopes checked only to the extent needed by those summaries.',
 'conditions':'Each table row inherits its own declared condition; rows are not an AND list of seed-selection premises.'},
'BH-IIB-CENSUS-UF-1879':{
 'reasoning':['The remark identifies level-one recovery from independently imposed P_sli and a level-one ceiling as a supplementary consistency check.','Its source wording explicitly excludes that optional selector chain from the positive derivation of support and m_p. This matches the earlier support theorem and the conditional II-F optional tower results.'],
 'direct_premises':['p2:thm:momentum-host-H1','p2:thm:m1-component','p2:thm:spex-fit-level-one'],
 'domain':'Optional tower consistency checks, not constitution of the initial momentum module.',
 'conditions':'Independent P_sli and level-one ceiling only inside the optional branch.'}
}
records=[]
for i,c in enumerate(entries,1):
 k=c['claim_id']; d=checks.pop(k)
 records.append({'id':f'EV-IIB-B2-E1A-{i:03}','evidence_level':'E1','agent':'/root/proof_replay','claim_id':k,'source_file':source.name,'statement_layer':'SOURCE-AS-PRINTED','source_locator':{'statement':c['statement_span'],'complete':c['complete_span']},'source_as_printed':c['source_as_printed'],'source_replay':'COMPLETE','status_proposal':'REPRODUCED; final VERIFIED/VERIFIED-CONDITIONAL requires independent E3 and applicable E4','new_confirmed_issue':False,**d})
assert not checks,checks
imports=[
 {'source_file':'Paper1A-Geometry-v5_163.tex','label':'p1:prop:h1-symmetric-exterior-form','lines':[8343,8393],'scope_checked':'Symmetric/exterior one-copy representation identity; no physical constructor.'},
 {'source_file':'Paper1A-Geometry-v5_163.tex','label':'p1:thm:canonical-retained-smooth-model','lines':[14738,14790],'scope_checked':'Exact mode normalization, six representation types and phase-qualified unitary class.'},
 {'source_file':'Paper2A-GeometricConstitution-v3_212.tex','label':'p2:thm:generated-constituent-corealization','lines':[2039,2097],'scope_checked':'Frozen nonredundant constituent presentation of occurring composite; no arbitrary-token occurrence.'},
 {'source_file':'Paper2A-GeometricConstitution-v3_212.tex','label':'p2:thm:generated-role-corealization','lines':[2100,2155],'scope_checked':'Finitely presented generated-role descendant under same root.'},
 {'source_file':'Paper2A-GeometricConstitution-v3_212.tex','label':'p2a:thm:g0-witness-transport-derived-constructor','lines':[2224,2298],'scope_checked':'Licensed typed constructor word, native retained inputs, declared output sort and FRC/nonobstructed branch.'},
 {'source_file':'Paper2A-GeometricConstitution-v3_212.tex','label':'p2:post:GP3','lines':[3741,3807],'scope_checked':'Generated proper whole-candidate comparison and exact irreducibility definition.'},
 {'source_file':'Paper2F-TechnicalMaterial-v1_58.tex','label':'p2:prop:gp3-multiplicity-bound','lines':[3962,4015],'scope_checked':'Comparison antecedent explicitly remains additional even with multiplicity blindness; no universal discharge.'},
 {'source_file':'Paper2F-TechnicalMaterial-v1_58.tex','label':'p2:thm:finite-spectral-exhaustivity','lines':[3693,3718],'scope_checked':'Word-budget lower-ideal identity for mathematically declared word stage.'},
 {'source_file':'Paper2F-TechnicalMaterial-v1_58.tex','label':'p2:thm:truncation','lines':[4082,4140],'scope_checked':'Declared ceiling gives allowed labels only, with half-integral/integer distinction.'},
 {'source_file':'Paper2F-TechnicalMaterial-v1_58.tex','label':'p2:thm:gp2-exact-label-complete-level-class','lines':[4534,4608],'scope_checked':'Optional P_sli package lower-ideal classification; no derivation of package from GP2.'},
 {'source_file':'Paper2F-TechnicalMaterial-v1_58.tex','label':'p2:prop:spectral-lower-ideal-sharpness','lines':[4609,4635],'scope_checked':'Weaker-signature E5/E7/E9 modules and missing current adjoint object types.'},
 {'source_file':'Paper2F-TechnicalMaterial-v1_58.tex','label':'p2:thm:minimal-hilbert-structural-15','lines':[3164,3208],'scope_checked':'Table row protected even Clifford algebra dimensions only under C_PI.'},
 {'source_file':'Paper2F-TechnicalMaterial-v1_58.tex','label':'p2:cor:paper1-octet-descendant-weight-closure','lines':[3328,3365],'scope_checked':'Table row conditional finite-support invariant weights; direct-core or core-constructor/domain-bridge and transitive actions required.'}
]
out={'target':source.name,'batch':2,'package':'E1A carrier/support and interfaces','coverage_lines':[1112,1886],'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'census_object_count':len(records),'records':records,'bounded_import_review':imports,'new_issues':[],'existing_frontier_reused':[{'issue_id':'BH-IIB-STRUCTURED-RIGIDITY-001','status':'OPEN CONDITIONAL ANTECEDENT; source theorem valid','condition_ids':['BH-IIA-A-B54-CMP-I-001','BH-IIA-A-B54-CMP-II-001','BH-IIA-A-B54-CMP-III-001'],'no_proven_impact_on':['p2:thm:momentum-host-H1','p2:thm:m1-component','p2b:prop:one-copy-geometric-module','p2:thm:intrinsic-coordinate-sector']}], 'notes':['No paper/source/DAG edits.','No new theory or gap repairs.','E1 statuses do not substitute for E3/E4 certificates.']}
(root/'work/batch2/proposals/replay_carrier/E1CarrierRecords.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('Wrote',len(records),'E1A records, no new issue proposals')
