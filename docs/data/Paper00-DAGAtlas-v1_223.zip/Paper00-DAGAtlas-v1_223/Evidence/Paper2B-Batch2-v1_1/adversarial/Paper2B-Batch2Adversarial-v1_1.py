"""Exact E4 controls of existing II-B v2.135, lines1112--2244.
Only standard library; finite controls supplement the review's general arguments.
"""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json, math
O=Path(__file__).parent; passed=[]
def chk(name,p):
 assert p,name
 passed.append(name)
def zero(n,m=None):return [[F(0) for _ in range(n if m is None else m)] for _ in range(n)]
def ident(n):
 A=zero(n)
 for i in range(n):A[i][i]=F(1)
 return A
def add(A,B):return [[a+b for a,b in zip(ra,rb)] for ra,rb in zip(A,B)]
def scale(c,A):return [[c*a for a in row] for row in A]
def mul(A,B):return [[sum(a*b for a,b in zip(row,col)) for col in zip(*B)] for row in A]
def tr(A):return sum(A[i][i] for i in range(len(A)))
def trans(A):return [list(v) for v in zip(*A)]
def outer(v):return [[a*b for b in v] for a in v]
def density(v):return scale(1/sum(t*t for t in v),outer(v))
def kron(A,B):return [[a*b for a in ra for b in rb] for ra in A for rb in B]
def blockdiag(blocks):
 n=sum(len(b) for b in blocks);A=zero(n);o=0
 for B in blocks:
  for i,row in enumerate(B):
   for j,a in enumerate(row):A[o+i][o+j]=a
  o+=len(B)
 return A
# Support-diagnostic controls under exactly all m_lambda>=1.
dims=[1,2,2,4,3,3];lengths=[0,1,1,2,2,2]
for ms in product(range(1,4),repeat=6):
 dd=sum(d*(m-1) for d,m in zip(dims,ms));dc=sum(m*m-1 for m in ms);dx=sum((m-1)**2 for m in ms)
 chk(f'detector_nonnegative_{ms}',min(dd,dc,dx)>=0)
 chk(f'detector_equivalence_{ms}',(dd==0)==(dc==0)==(dx==0)==all(m==1 for m in ms))
 chk(f'mp_independent_of_multiplicity_{ms}',max(l for l,m in zip(lengths,ms) if m)>0 and max(lengths)==2)
mutation=[0,0,1,1,2,1]
chk('missing_support_dimension15_mutation',sum(d*m for d,m in zip(dims,mutation))==15 and mutation!=[1]*6)
# Canonical quotient with both genuine multiplicity and distinct isotypic blocks.
ds=[1,2];ms=[2,2]
ns=[d*m for d,m in zip(ds,ms)];N=sum(ns);N0=sum(ds)

def j(a):
 out=[];off=0
 for d,m in zip(ds,ms):
  b=[row[off:off+d] for row in a[off:off+d]];out.append(kron(b,ident(m)));off+=d
 return blockdiag(out)
def q(rho):
 out=[];off=0
 for d,m in zip(ds,ms):
  b=zero(d)
  for i in range(d):
   for k in range(d):b[i][k]=sum(rho[off+i*m+t][off+k*m+t] for t in range(m))
  out.append(b);off+=d*m
 return blockdiag(out)
def sec(sigma):
 out=[];off=0
 for d,m in zip(ds,ms):
  b=[row[off:off+d] for row in sigma[off:off+d]];out.append(kron(b,scale(F(1,m),ident(m))));off+=d
 return blockdiag(out)
def project(A):return sec(q(A)) # Hilbert--Schmidt conditional expectation onto A_bl.
# A_bl projection uses q(A)/m on each block; sec supplies exactly this.
vecs=[[F(i==k) for i in range(N)] for k in range(N)]
vecs += [[F((i+2*k)%5-2) for i in range(N)] for k in range(1,7)]
effects=[]
for block,d in enumerate(ds):
 off=sum(ds[:block])
 for i in range(d):
  for k in range(d):
   A=zero(N0);A[off+i][off+k]=1;effects.append(A)
for t,v in enumerate(vecs):
 rho=density(v);sig=q(rho)
 chk(f'quotient_trace_{t}',tr(sig)==1)
 chk(f'canonical_section_rightinverse_{t}',q(sec(sig))==sig)
 chk(f'canonical_section_trace_{t}',tr(sec(sig))==1)
 for a,A in enumerate(effects):chk(f'all_matrix_unit_expectations_{t}_{a}',tr(mul(rho,j(A)))==tr(mul(sig,A)))
# Off-isotypic coherence and multiplicity states vanish exactly where intended.
v=[F(0)]*N;v[0]=v[2]=1;rho=density(v)
chk('inter_isotypic_coherence_discarded',q(rho)==q(project(rho)))
# Outside-algebra Hermitian effect; rho+/- around I/N have identical quotient.
E=zero(N);E[0][0]=1;E[1][1]=-1
X=add(E,scale(-1,project(E)));eps=F(1,4*N)
rplus=add(scale(F(1,N),ident(N)),scale(eps,X));rminus=add(scale(F(1,N),ident(N)),scale(-eps,X))
chk('outside_effect_same_Q',q(rplus)==q(rminus))
chk('outside_effect_separates_states',tr(mul(add(rplus,scale(-1,rminus)),E))==2*eps*tr(mul(X,X))>0)
chk('outside_effect_states_positive_diagonal',min(rplus[i][i] for i in range(N))>0 and min(rminus[i][i] for i in range(N))>0)
# Process positive and negative controls on one V2 tensor M2 block.
I2=ident(2);Z=[[F(1),F(0)],[F(0),F(-1)]]
SW=zero(4)
for a,b in product(range(2),repeat=2):SW[2*b+a][2*a+b]=1
chk('SWAP_is_unitary',mul(SW,trans(SW))==ident(4))
readout=kron(Z,I2);image=mul(mul(trans(SW),readout),SW)
chk('SWAP_moves_rep_effect_to_multiplicity',image==kron(I2,Z))
r0=density([F(1),F(0),F(0),F(0)]);r1=density([F(0),F(1),F(0),F(0)])
def partial2(r):return [[sum(r[2*a+t][2*b+t] for t in range(2)) for b in range(2)] for a in range(2)]
chk('SWAP_inputs_same_quotient',partial2(r0)==partial2(r1))
out0=mul(mul(SW,r0),trans(SW));out1=mul(mul(SW,r1),trans(SW))
chk('SWAP_outputs_different_quotient',partial2(out0)!=partial2(out1))
chk('SWAP_failure_exactly_detected_by_invariance',image!=kron(partial2(image),scale(F(1,2),I2)))
# Canonical mixed section is not rank-one copy selection.
sigma=[[F(1),F(0)],[F(0),F(0)]];mixed=kron(sigma,scale(F(1,2),I2))
chk('section_is_mixed_not_copy_projector',tr(mul(mixed,mixed))==F(1,2) and partial2(mixed)==sigma)
# Weights and moments on exact six-type support.
sectors=[(0,0),(1,0),(0,1),(1,1),(2,0),(0,2)]
weights=[]
for a,b in sectors:weights += [F(l-r,2) for l in range(-a,a+1,2) for r in range(-b,b+1,2)]
chk('onecopy_dimension',len(weights)==15)
chk('second_moment',sum(x*x for x in weights)/15==F(7,15))
chk('fourth_moment',sum(x**4 for x in weights)/15==F(5,12))
for k in range(1,8):
 for n in range(9):chk(f'normalized_moment_amplification_k{k}_n{n}',sum(x**n for x in weights*k)/(15*k)==sum(x**n for x in weights)/15)
# Haar E1 isotropic rank4 frame: finite subgroup average is an exact positive control.
f=[F(1),F(2),F(-1),F(3)];average=zero(4);count=0
# Use all signed permutation matrices with determinant+1 (SO4), 192 elements.
for perm in __import__('itertools').permutations(range(4)):
 inv=sum(perm[i]>perm[j] for i in range(4) for j in range(i+1,4));sgnp=(-1)**inv
 for signs in product([-1,1],repeat=4):
  if math.prod(signs)*sgnp==1:
   v=[signs[i]*f[perm[i]] for i in range(4)];average=add(average,outer(v));count+=1
average=scale(F(1,count),average)
chk('SO4_signed_permutation_twirl_rank4',average==scale(sum(a*a for a in f)/4,ident(4)))
# Orthonormal form normalizations from E[x_a x_b]/R²=delta_ab/4.
for a,b in product(range(4),repeat=2):chk(f'normalized_dx_{a}_{b}',F(4,3)*(int(a==b)-F(int(a==b),4))==int(a==b))
for a,b in __import__('itertools').combinations(range(4),2):chk(f'normalized_wedge_{a}_{b}',2*(1-F(1,4)-F(1,4))==1)
# Invariant states can use arbitrary sector weights; operation-algebra unitary invariance fixes only block scalars.
for p in [F(0),F(1,5),F(11,15),F(1)]:chk(f'native_mixed_normalization_{p}',11*p/11+4*(1-p)/4==1)
chk('native_paired_dimensions',121+88+16==225)
chk('native_paired_trace_weights',sum(F(n,225) for n in [121,88,16])==1)
chk('ground_vs_native_splits_are_distinct',1+14==15 and 11+4==15 and (1,14)!=(11,4))
result={'scope':'Paper2B v2.135 lines1112--2244','assertion_count':len(passed),'all_passed':True,'checks':passed,'limits':'Finite controls plus exact witnesses only. No universal GP3 comparison, physical state/preparation or measurement occurrence is certified.'}
(O/'Paper2B-Batch2AdversarialResults-v1_1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'}))
