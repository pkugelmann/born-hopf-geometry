import json, hashlib
from pathlib import Path
W=Path('/workspace/scratch/6302724ed082/work')
source=W/'corpus/Paper2B-MomentumCarrier-v2_135.tex'
census=json.loads((W/'proposals/census/Paper2B-ClaimCensus-v1_1.json').read_text())['claims']
selected=[x for x in census if 1887<=x['complete_span']['start_line']<=2244]
arguments={
'p2:cor:neutral-level-one-handoff':[
'The first handoff merely restates the earlier six-type support theorem and m_p=1 corollary at exactly their constructor-relative scope. It does not consume GP3 multiplicity-one.',
'The full physical endpoint handoff is explicitly conditional on momentum-carrier-rigidity. The generic point-resolution output is not identified with the exceptional [2T] support without the separately declared core constructor plus domain bridge or direct core occurrence.',
'The direct II-F import p2:cor:core-support-inheritance-no-duplicate-witness1138–1181 is an implication with precisely those two additional constructor/domain antecedents. Its proof transports only an orbit-level generated output, not a labelled representative.'
],
'p2:rem:paper1-truncation-data':[
'The mathematical carrier family and raw completion family are distinct sorts. The remark preserves six-type support, constituent co-realization, and the stronger universal multiplicity comparison as different statements.',
'The conditional C_PI/Clifford presentation is not used to derive momentum support. Current II-F conditional-Clifford package3091–3275 explicitly separates the raw cone R_nonnegative^3 from the later normalized nondegenerate protected invariant. No extra completion selector is asserted.'
],
'p2:thm:no-insertion-finite-trace-weight':[
'For a complex-linear functional on the full finite matrix algebra, positivity and normalization give a unique density matrix rho. Trace pairing nondegeneracy makes G-conjugation invariance equivalent to rho commuting with every U(g).',
'Schur decomposition gives End_G(V)=direct_sum I_(V_lambda) tensor End(M_lambda). Positivity is equivalent to B_lambda>=0; trace one is sum d_lambda Tr(B_lambda)=1. The statements on irreducible, multiplicity-free, and multiplicity-sensitive blocks follow by direct specialization.',
'Traciality on the FULL End(V), or invariance under the FULL U(V), makes rho scalar on V, not merely scalar within each G-isotypic block. The normalization gives rho=I/dim V. No enlargement from G to U(V) is inferred.',
'The diagonal SU2 singlet on C2 tensor C2 is invariant and pure with both reduced states I2/2, so it is not a product. For factorwise action on a tensor product of two irreducibles, the product representation is irreducible and the unique invariant density is the product of the two normalized identities.',
'The final rank-one/product-trace relation holds only when the two normalized traces are selected; it follows from Tr(A tensor B)=Tr(A)Tr(B).'
],
'p2b:prop:normalized-multiplicity-indistinguishability':[
'For every integer k>=1 and n>=0, X_k^n=X^n tensor I_k including n=0; its trace is k Tr(X^n). The denominator is the actual replicated dimension15k, so the normalized moment is exactly unchanged.',
'Using six types (0,0),(1/2,0),(0,1/2),(1/2,1/2),(1,0),(0,1), the component weights give total Tr(X²)=0+1/2+1/2+2+2+2=7 and Tr(X⁴)=0+1/8+1/8+2+2+2=25/4. Dividing by15 gives7/15 and5/12.',
'This is an observational non-converse for normalized replicated operators, not an assertion that replicas are GP3 minima, nor an occurring measurement.'
],
'p2b:rem:casimir-difference-support-diagnostic':[
'Casimir difference C_L-C_R is +2 on (1,0) and -2 on (0,1), using j(j+1). Its presence/eigenvalue support tests the adjoint types only after an observable is licensed.',
'Replication tensor I_k preserves this support, so the remark correctly separates type detection from multiplicity detection and introduces no cutoff.'
],
'p2b:cor:v233-native-invariant-states':[
'The imported I-B connected-coordinate-graph calculation assumes the specified full nonzero native support: all permitted native edges are present. Group action supplies a full matrix algebra at every irreducible vertex. Sandwiching each nonzero edge by vertex matrix units spans the rectangular Hom; products along paths fill precisely the connected components.',
'The one-factor native components have dimensions11 and4. A connected scalar position factor P_m of dimension d_m therefore gives block sizes11d_m and4d_m. On the matched enriched product the four component sizes are121,44,44,16; adjoining the specified Born exchange joins the two middle components into88.',
'Invariance under every UNITARY OF THE SPECIFIED ALGEBRA places the density in that algebra\'s commutant. Each full component is multiplicity-one, so the commutant is scalar on that component. Positivity and global trace one yield exactly rho_p and rho_(a,b,c), including boundary populations0 or1.',
'The full normalized trace has density I/(15d_m) or I/225. Matching the displayed coefficients gives p=11/15 and (a,b,c)=(121,88,16)/225. No physical preparation or population selection follows.',
'Native full-support condition is not the raw completion cone: intrinsic G02 tuple has a=R/2, b_D=sqrt(2)R/3, varrho_D=sqrt(3)R/4, all nonzero for R>0 (I-B9385–9430). Arbitrary zero-support coordinate completions would produce smaller components but are not the imported native-algebra domain.'
],
'BH-IIB-CENSUS-U007':[
'Current II-C tagged-population corollary5428–5518 constructs effects E_(j,t)=P_t E_j P_t for already generated central projectors. Positivity and sum_(j,t)E_(j,t)=I follow; summing over t recovers E_j because E_j reduces the sectors.',
'Multiplying by coordinate labels and summing preserves every native first moment; sum_j E_(j,t)=P_t reads populations. For rho_p, the untagged outcome probabilities1/N are p-independent while tagged probabilities are p/N and(1-p)/N.',
'Its operator/effect construction does not assert a performed instrument. II-B correctly preserves the occurrence requirement and nonselection of a state before measurement.'
],
'BH-IIB-CENSUS-UF-2125':[
'The canonical duality word ev(1 tensor T)coev=Tr(T) uses the identity tensor sum_i e^i tensor e_i, hence gives the ordinary trace without a preparation premise. Inserting a nontrivial B would be a different word Tr(BT), as current II-A9716–9739 explicitly states.',
'For the specified retained Levi-Civita square K_LC, eigenvalues0,3/R²,4/R²,9/(4R²) have dimensions1,4,6,4. Positivity and zero expected energy annihilate all positive-eigenvalue diagonal blocks; positivity also annihilates their off-diagonals. The kernel is the scalar line, so the unique zero-energy density is its projector.',
'Current I-A15232–15265 heat formula has excited sum S_beta=4e^(-3beta/R²)+6e^(-4beta/R²)+4e^(-9beta/(4R²)); trace distance2S/(1+S)<=28e^(-9beta/(4R²)). The proof and rate match the II-B export.',
'The I-A square-owner counterexample18759–18773 shifts D_LC by lambda I, preserving principal symbol and coordinate commutators while placing zero energy on a lowest spinor eigenspace and giving scalar energylambda²>0. Thus symbol alone does not select the preparation, exactly as II-B states.'
],
'p2b:rem:invariant-state-selector-status':[
'For the specified one-copy H1 representation, the six inequivalent irreducibles are multiplicity-free, so the invariant-state theorem leaves a simplex of six sector probabilities. Neither the representation nor normalization fixes those probabilities.',
'The zero-energy branch for the precise K_LC and a separately specified ergodic branch with uniquely fixed central weights are explicitly conditional preparation doctrines, not derived existence statements for those dynamics.',
'General trace use must identify its owner: canonical loop readout, full traciality, specified dynamics, or actual occurrence. A loop coefficient is not a maximally mixed preparation. Sector conditioning cancels a positive sector weight only inside that sector, not globally.'
],
'p2:rem:generated-test-scope':[
'On iota_lambda(A)=A tensor I_(M_lambda), trace of rho gives Tr(A)Tr(B_lambda). Since p_lambda=d_lambda Tr(B_lambda), this is p_lambda Tr(A)/d_lambda. Conditioning divides by p_lambda only when p_lambda>0.',
'The unmarked algebra direct_sum End(V_lambda) tensor I_M retains sector weights but is blind to multiplicity directions. The full End(V) can see B_lambda through nontrivial multiplicity observables; those are specifically absent from the unmarked doctrine, not silently discarded from an arbitrary candidate.',
'The current II-F3962–4034 multiplicity-bound proposition also requires an additional proper generated whole-candidate comparison, not unmarkedness alone. II-B\'s test-scope remark does not assert that such a comparison follows from normalized states.',
'Tau(I)=1 on any density, independent of carrier dimension, so normalization alone cannot recover dimensional multiplicity.'
],
'p2:rem:no-insertion-basis-neutrality':[
'On a reducible G-module the commutant contains separate scalar weights and possibly nontrivial multiplicity operators. Merely omitting a preferred basis cannot replace the constituted G action by arbitrary U(V) conjugation. The sufficient additional full-unitary hypothesis is stated, not inferred.'
],
'BH-IIB-CENSUS-U008':[
'The export repeats support/m_p=1 and the one-copy dimension15 while explicitly placing the protected Clifford claim under C_PI. Current II-F3172–3257 uses the real even basis I, six bivectors, and volume element:dimension1+6+1=8.',
'In the real Dirac representation, the seven nonscalar even basis elements have zero matrix trace and identity has nonzero trace. The trace has rank one on the8-dimensional real algebra, so its kernel has real dimension7. The algebra is Cl(0,3), noncommutative; no 15-dimensional isomorphism with the Hilbert carrier is asserted.',
'The general raw completion cone and nondegenerate normalized protected invariant remain distinct. Optional quotient/shell/Hopf or finite-support results are explicitly deferred and do not become premises of support selection.'
]
}
imports={
'p2:cor:neutral-level-one-handoff':[{'label':'p2:thm:momentum-host-H1','file':source.name,'lines':[1112,1163],'use':'Generated six-type support'},{'label':'p2:thm:m1-component','file':source.name,'lines':[1367,1385],'use':'Type-support word-length descriptor'},{'label':'p2b:thm:momentum-carrier-rigidity','file':source.name,'lines':[1436,1486],'use':'Stronger conditional endpoint handoff only'},{'label':'p2:cor:core-support-inheritance-no-duplicate-witness','file':'Paper2F-TechnicalMaterial-v1_58.tex','lines':[1138,1181],'use':'Conditional support descendant, not generic point output'}],
'p2b:cor:v233-native-invariant-states':[{'label':'p1b:der:g03:s11:sub2','file':'Paper1B-M8Geometry-v1_128.tex','lines':[10049,10077],'use':'All-nonzero support connected blocks'},{'label':'p1b:der:g03:s11:sub3','file':'Paper1B-M8Geometry-v1_128.tex','lines':[10078,10112],'use':'Specified exchange joins middle blocks'},{'label':'p1b:thm:all-level-generated-coordinates','file':'Paper1B-M8Geometry-v1_128.tex','lines':[8742,8788],'use':'Mixed scalar-position/enriched-momentum block sizes'},{'label':'p1b:der:g02:s3:sub1','file':'Paper1B-M8Geometry-v1_128.tex','lines':[9379,9433],'use':'Intrinsic native edge nonvanishing, R>0'}],
'BH-IIB-CENSUS-U007':[{'label':'p2c:cor:v2211-tagged-intrinsic-populations','file':'Paper2C-ReciprocalLocalization-v2_160.tex','lines':[5428,5518],'use':'Moment preserving central tag, p/N versus (1-p)/N'}],
'BH-IIB-CENSUS-UF-2125':[{'label':'p2a:cor:v233-loop-coefficients','file':'Paper2A-GeometricConstitution-v3_212.tex','lines':[9716,9739],'use':'Canonical specified trace readout without preparation'},{'label':'p1:cor:v233-geometric-ground-state','file':'Paper1A-Geometry-v5_163.tex','lines':[15232,15265],'use':'Owner-specific zero-energy scalar state and heat rate'},{'label':'p1:app:v233-square-owner','file':'Paper1A-Geometry-v5_163.tex','lines':[18759,18773],'use':'Same principal symbol does not fix ground space'}],
'p2:rem:generated-test-scope':[{'label':'p2:prop:gp3-multiplicity-bound','file':'Paper2F-TechnicalMaterial-v1_58.tex','lines':[3962,4034],'use':'Unmarked observable domain; additional comparison remains explicit'}],
'BH-IIB-CENSUS-U008':[{'label':'p2:thm:minimal-hilbert-structural-15','file':'Paper2F-TechnicalMaterial-v1_58.tex','lines':[3172,3257],'use':'Conditional C_PI protected real Clifford count only'}]
}
records=[]
for i,c in enumerate(selected,1):
 cid=c['claim_id']
 records.append({'id':f'EV-IIB-B2-E1B-{i:03d}','evidence_level':'E1','agent':'/root/replay_states','claim_id':cid,'statement_layer':'SOURCE-AS-PRINTED','source_file':source.name,'statement_lines':list(c['statement_span'].values()),'proof_lines':list(c['proof_span'].values()) if c['proof_span'] else None,'complete_lines':list(c['complete_span'].values()),'source_as_printed':c['source_as_printed'],'source_replay':'COMPLETE WITHIN PRINTED SCOPE','reasoning':arguments[cid],'imports':imports.get(cid,[]),'adjudication':'Source argument reproduced; final E3/E4 status is coordinator responsibility','physical_occurrence_newly_certified':False})
out={'target':source.name,'batch':2,'scope_lines':[1887,2244],'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'records':records,'candidate_issues':[],'confirmed_mathematical_defects':[], 'scope_adjudications':[{'id':'QA-IIB-B2-NATIVE-NONZERO-001','target':'p2b:cor:v233-native-invariant-states','status':'NO IN-DOMAIN DEFECT CERTIFIED; IMPORTED NONZERO NATIVE DOMAIN RETAINED','rejected_interpretation':'The corollary holds for every point of the raw coordinate-completion cone, including zero allowed edges.','actual_scope':'The specified native nonzero coordinate graph, whose I-B full-matrix block calculation requires all relevant edges nonzero; the intrinsic native point satisfies this.','boundary':'Specified represented algebra, native coordinate edges, group matrix-unit closures and Born exchange are declared data. No arbitrary completion or physical operation is generated by the algebra calculation.','required_dag_guard':'Native full-support graph / specified all-nonzero edge domain, as in imported I-B result.'}], 'not_audited':'No independent audit of imported papers; their exact needed contracts and calculations only. No PDF/source edits, new theory or repairs.'}
p=W/'batch2/proposals/replay_states/E1Records.json';p.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'written':str(p),'records':len(records),'confirmed_issues':0,'scope_notes':1}))
