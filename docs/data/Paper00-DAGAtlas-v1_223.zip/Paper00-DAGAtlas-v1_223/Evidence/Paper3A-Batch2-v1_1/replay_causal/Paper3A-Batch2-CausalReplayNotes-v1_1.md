# Paper III-A Batch 2 — causal source replay

E1 replay completed for all18 objects C0065–C0082 (source2135–2806). Clocked action/opposite variance, generated doctrine co-realization, primitive half-turn, marked joint-orbit monodromy, exact speed bound and relaxation distinction, convex envelope, determinant and polar identities, O3-equivariant determinant root, symmetric-square typing, homothety and phase-cell scale chain replay within their stated domains.

Two bounded source-scope candidates remain. C0065: the statement linking a relative m_cmp=2 comparison window to the deck-even scalar quotient has an unspecified comparison/readout domain. The quotient-only claim is supported; the complete position-band reading needs an actual typed map. No refutation is certified.

The scalar no-modulus theorem is explicitly conditional on the adopted no-scalar-metric phase datum; no claim about all larger metric theories is inferred. CAL_t fixes a period representative only at C0082. P_mc is not a native clock-action or scalar-product premise. C0080 explicitly uses an optional full-profile certification theorem under P_mc, so that cited route is material and conditional. The source summary needs a qualifier/correct native reference; its scalar torus result retains the earlier CHAR/GP2 native bypass. No scalar-role gap is alleged.

No paper/source/graph changed; no new theory or repairs.
