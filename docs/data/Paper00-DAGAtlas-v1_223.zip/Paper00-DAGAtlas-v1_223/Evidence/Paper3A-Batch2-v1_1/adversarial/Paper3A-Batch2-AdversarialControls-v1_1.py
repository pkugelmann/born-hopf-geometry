"""Exact E4 positive/mutation controls for source claims48–82; not a universal-proof oracle."""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import json,itertools
import sympy as S
groups=Counter()
def test(group,condition):
    assert bool(condition),group
    groups[group]+=1
J=S.Matrix([[0,-1],[1,0]])
A=S.Matrix([[1,1],[1,-1]])
test('primitive_pair',J.det()==1 and J.inv()==-J)
test('eigenphase_cover',A.det()==-2 and A*A==2*S.eye(2) and A.inv()==A/2)
test('eigenphase_cover',A.T*J*A==-2*J)
swap=S.Matrix([[0,1],[1,0]])
test('born_antisymplectic',swap.T*J*swap==-J)
for n,w in itertools.product(range(-12,13),repeat=2):
    even=(n+w)%2==0
    r,s=F(n+w,2),F(n-w,2)
    test('character_lattice_parity',even==(r.denominator==s.denominator==1))
    test('character_lattice_parity',(n+w)%2==((n-w)%2))
    test('deck_product',((n+w)+(n+w))%2==0)
for r,s in itertools.product(range(-8,9),repeat=2):
    n,w=r+s,r-s
    test('quotient_lattice_image',(n+w)%2==0 and (n+w)//2==r and (n-w)//2==s)
    test('quotient_axis_even',(2*r)%2==0 and (2*s)%2==0)
for m,n,mp,np in itertools.product(range(-2,3),repeat=4):
    # Product of gluing multipliers differs by the integer m*np.
    test('poincare_transition_cocycle',(m*np)%1==0)
test('not_global_torus_bicharacter',S.exp(2*S.pi*S.I*0*S.Rational(1,2))!=S.exp(2*S.pi*S.I*1*S.Rational(1,2)))
test('circle_moment_contractions',S.Matrix([[1,1]])*J==S.Matrix([[1,-1]]))
test('circle_moment_contractions',S.Matrix([[1,-1]])*J==S.Matrix([[-1,-1]]))
for N in range(-8,9):
    test('primitive_multiple_test',(N*N==1)==(abs(N)==1))
for a in [F(1,3),F(1,2),F(1),F(3,2),F(2),F(5)]:
    for T in [F(1,4),F(1),F(3),F(7,2)]:
        hbar=F(3,5);E=2*S.pi*hbar/S.Rational(T.numerator,T.denominator)
        c=2*S.pi*S.Rational(a.numerator,a.denominator)/S.Rational(T.numerator,T.denominator)
        test('calibrated_scale_chain',S.simplify(E*S.Rational(a.numerator,a.denominator)-hbar*c)==0)
        for lam in [F(1,3),F(2),F(7,2)]:
            test('reciprocal_period_presentation',(lam*T)*(F(1,lam)*F(5,7))==T*F(5,7))
            test('metric_covector_scaling',F(3,5)/(lam*a)==(F(3,5)/a)/lam)
    test('quarter_root_character',S.det(S.eye(4)*S.Rational(a.numerator,a.denominator))==S.Rational(a.numerator,a.denominator)**4)
    test('quadratic_vs_inverse_dual',S.Rational(a.numerator,a.denominator)**2==S.sqrt(S.Rational(a.numerator,a.denominator)**4))
R=S.diag(1,1,-1,-1);Omega=S.Matrix.vstack(S.Matrix.hstack(S.zeros(2),-S.eye(2)),S.Matrix.hstack(S.eye(2),S.zeros(2)))
test('cotangent_fibre_reversal',R.T*Omega*R==-Omega)
# Full-product invariant decomposition: exactly six types on each canonical auxiliary seed.
types=[(a,b) for a in range(3) for b in range(3) if a+b<=2]
test('canonical_auxiliary_commutant',len(types)==6)
test('canonical_auxiliary_commutant',len(list(itertools.product(types,types)))==36)
test('cohomology_obstruction',S.expand((1+S.Symbol('t')**3)**2).coeff(S.Symbol('t'),2)==0)
for k in range(8):
    for q in range(-k,k+1,2):test('hopf_halfturn_parity',(-1)**q==(-1)**k)
position_weights=Counter()
for k in range(3):
    for q in range(-k,k+1,2):position_weights[q]+=k+1
test('mcmp2_type_boundary',sum(position_weights.values())==14)
test('mcmp2_type_boundary',position_weights[-1]==position_weights[1]==2)
test('mcmp2_type_boundary',sum(mult for q,mult in position_weights.items() if q%2)==4)
test('scalar_deck_vs_relative_halfturn',((-1)**(0+1))!=((-1)**0))
# Exact polar witnesses for several positive diagonal metric representatives.
for hd in [(1,1,1),(1,4,9),(4,9,16)]:
    h=S.diag(*hd);hinv=h.inv()
    for pv in itertools.product(range(-2,3),repeat=3):
        p=S.Matrix(pv);pn=S.sqrt((p.T*hinv*p)[0])
        for c in [S.Rational(1,2),S.Integer(1),S.Integer(3)]:
            if pn==0:
                test('polar_zero_covector',pn==0);continue
            tau=S.Rational(2,3);xi=c*tau*hinv*p/pn
            test('polar_boundary_witness',S.simplify((xi.T*h*xi)[0]-c*c*tau*tau)==0)
            test('polar_boundary_witness',S.simplify(c*pn*tau-(p.T*xi)[0])==0)
            test('polar_below_boundary_countercheck',S.simplify((c*pn-1)*tau-(p.T*xi)[0])==-tau)
            for alpha in [S.Rational(1,3),S.Integer(2)]:
                scaled=alpha**2*h
                test('homothety_dual_norm',S.simplify(alpha*c*S.sqrt((p.T*scaled.inv()*p)[0])-c*pn)==0)
# O(3)-equivariant commutant on R+R3, using reflections and coordinate swaps.
variables=S.symbols('x0:16');M=S.Matrix(4,4,variables)
generators=[S.diag(1,-1,1,1),S.diag(1,1,-1,1),S.diag(1,1,1,-1)]
generators += [S.Matrix([[1,0,0,0],[0,0,1,0],[0,1,0,0],[0,0,0,1]]),S.Matrix([[1,0,0,0],[0,1,0,0],[0,0,0,1],[0,0,1,0]])]
sol=S.linsolve([entry for G in generators for entry in M*G-G*M],variables)
generic=S.Matrix(4,4,next(iter(sol)))
test('equivariant_centralizer',generic==S.diag(variables[0],variables[15],variables[15],variables[15]))
test('cone_automorphism_not_inclusion',S.Rational(2,1)>1 and S.Rational(1,2)<1)
boost=S.Matrix([[S.Rational(5,3),S.Rational(4,3),0,0],[S.Rational(4,3),S.Rational(5,3),0,0],[0,0,1,0],[0,0,0,1]])
lor=S.diag(1,-1,-1,-1)
test('non_equivariant_boost_outside_domain',boost.T*lor*boost==lor)
test('non_equivariant_boost_outside_domain',boost*generators[0]!=generators[0]*boost)
test('non_equivariant_boost_outside_domain',boost.det()==1 and boost!=S.eye(4))
theta=S.symbols('theta',real=True)
orbit=S.Matrix([S.cos(theta),S.sin(theta),0,0]);vel=orbit.diff(theta)
test('hopf_seed_speed',S.trigsimp((vel.T*vel)[0])==1)
test('hopf_halfturn',orbit.subs(theta,theta+S.pi)==-orbit)
result={'result':'PASS','actor':'b2_adversarial','evidence_level':'E4','assertions':sum(groups.values()),'groups':dict(groups),
    'finite_controls_not_general_proofs':True,'source':'Paper3A-GeneratedDynamics-v1_169.tex:1476–2806',
    'domain_limit':'P_x(2) odd Hopf weights are a type-boundary control. No unlicensed map into scalar Z² character algebra is silently asserted.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
