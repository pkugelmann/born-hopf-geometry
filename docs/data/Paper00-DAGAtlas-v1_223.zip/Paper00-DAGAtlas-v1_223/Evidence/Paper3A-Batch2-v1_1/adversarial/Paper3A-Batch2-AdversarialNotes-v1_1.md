# Paper III-A Batch2 — E4 review

Claims48–82 (lines1476–2806):36 adversarial records, seven exact typed boundaries, 8,922 finite exact controls passed. No certified mathematical refutation.

One TYPE_OR_DOMAIN candidate at2140–2141: the m_cmp=2 window has been defined as the complete position band P_x(2), whereas scalar deckevenness is a condition on Z² parent characters. The source needs a typed window/character comparison or symbol clarification. Complete P_x(2) has oddHopf weights from E1; that is a scope-boundary control, not a silently constructed scalarcountermodel. The preceding primitive/deck retention result remains correct. Independentadjudication required before a canonicalissue status.

Other stronger attacks fail their exact source hypotheses: diagonal in place offullproduct symmetry; arbitrary implementationmultiplicities in an auxiliary multiplicityfree model; globalreal angles in place ofcircle forms; nonprimitive phaseclasses; faster clockreparametrizations or parallelcomposition outsideCLK grammar; relaxedcurve physicaltoken promotion; generic Lorentz boosts outsideO3-equivariant centralizer; inverse-dual coefficient in place ofdirectSym²U; or scalar aspectratiometric outsideadoptednometricscalar datum.

Deliver the four Paper3A-Batch2-Adversarial* files as evidence; claims_input.json and build_e4_records.py are intermediate extraction/build files.
