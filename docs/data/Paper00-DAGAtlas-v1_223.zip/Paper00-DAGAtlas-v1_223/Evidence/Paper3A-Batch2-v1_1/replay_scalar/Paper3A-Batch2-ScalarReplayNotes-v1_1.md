# Paper III-A Batch2 — E1 scalar/phase replay

17 source objects C0048–C0064 (1476–2133) replayed. C0051 is a formal scope remark; the other16 source statements/derivations pass with their exact conditional scopes. No new source issue certified. E1 alone is not independent verification.

The vector commutant obstruction uses only its declared auxiliary one-copy comparison models and full product group. The Poincare class uses the explicitly dual I-B convention, so c_sc=-eta and positive(E,t) orientation agree. III-G supplies genuine bundle gluing and character holonomy, not a false global bicharacter.

The generator-germ result uses the already generated II-C cotangent first-symbol target, plus the scalar dual line and product splitting, subject to the imported II-A generated-role descendant contract. No mathematical canonicality-to-arbitrary-physical-output shortcut, global compact/noncompact identification or all-resolution map is accepted.

CAL_hbar is the separate source of tper*Eper=2pi hbar. The two-fold eigenphase cover has determinant-2, preserves a marked parent, and carries the correct even/odd character grading. The circle-valued moment signs follow by direct contraction.

Only exact bounded prerequisites in I-A/I-B/II-A/II-C/III-G were consulted. Later III-A degree-one descent was read solely to confirm the same integer degree arithmetic, and is not a material premise of the earlier C60 claim. The final speed/history preview in C61 belongs to C70 and must remain separate from C61 native topology/cell proofs.
