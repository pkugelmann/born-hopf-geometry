"""Exact E3 controls for existing III-A claims48–82; not universal proof by count."""
from pathlib import Path
from fractions import Fraction as F
import json, sympy as S
counts={}
def ck(group,value):
    assert bool(value),group
    counts[group]=counts.get(group,0)+1
J=S.Matrix([[0,-1],[1,0]])
A=S.Matrix([[1,1],[1,-1]])
betti=[sum(1 for i in [0,3] for j in [0,3] if i+j==k) for k in range(7)]
ck('product_cohomology',betti==[1,0,0,2,0,0,1])
ck('primitive_pairing',J.det()==1 and J.inv()==-J)
ck('eigenphase_cover',A*A==2*S.eye(2) and A.det()==-2)
ck('eigenphase_cover',A.T*J*A==-2*J)
for n in range(-8,9):
    ck('pairing_multiple',(n*J).det()==n*n)
for n in range(-12,13):
  for w in range(-12,13):
    r,s=F(n+w,2),F(n-w,2)
    ck('character_lattice',(r.denominator==s.denominator==1)==((n+w)%2==0))
    if (n+w)%2==0:ck('character_lattice',A*S.Matrix([r,s])==S.Matrix([n,w]))
    ck('deck_character',((-1)**(n+w))**2==1)
kernel=[]
for u in [F(0),F(1,2)]:
  for v in [F(0),F(1,2)]:
    if (u+v).denominator==(u-v).denominator==1:kernel.append((u,v))
ck('eigenphase_cover',kernel==[(F(0),F(0)),(F(1,2),F(1,2))])
for a in range(11):
    types=[(i,j) for i in range(a+1) for j in range(a+1-i)]
    ck('auxiliary_full_product_types',len(types)==(a+1)*(a+2)//2)
    if a==2:ck('auxiliary_full_product_commutant',len(types)**2==36)
for k in range(13):
    weights=list(range(-k,k+1,2))
    for n in weights:ck('clock_halfturn',(-1)**n==(-1)**k)
    ck('scalar_band_dimension',(k+1)*len(weights)==(k+1)**2)
# Independent mutation control for C65: full P_x(2) has odd primitive clock weights.
clock_weights={q for k in range(3) for q in range(-k,k+1,2)}
ck('mcmp2_domain_control',clock_weights=={-2,-1,0,1,2})
ck('mcmp2_domain_control',(1+0)%2==1 and 1 in clock_weights)
ck('relative_window_positive_control',all((n-n)%2==0 for n in range(-10,11)))
# Poincare lattice cocycle composition is exact modulo an integer.
for m in range(-3,4):
  for n in range(-3,4):
    for r in range(-3,4):
      for s in range(-3,4):
        ck('poincare_transition_cocycle',(m*s)%1==0)
Vplus=S.Matrix([[1,1]]);Vminus=S.Matrix([[1,-1]])
ck('circle_moment_signs',Vplus*J==S.Matrix([[1,-1]]))
ck('circle_moment_signs',Vminus*J==S.Matrix([[-1,-1]]))
# Cotangent lift preservation and fibre-reversal sign, arbitrary invertible changes.
Omega=S.zeros(8)
Omega[:4,4:]=-S.eye(4);Omega[4:,:4]=S.eye(4)
for k in range(1,9):
    B=S.Matrix([[1,k,0,0],[0,1,k+1,0],[0,0,1,k+2],[0,0,0,1]])
    C=S.diag(B,B.inv().T)
    ck('cotangent_change',C.T*Omega*C==Omega)
rev=S.diag(S.eye(4),-S.eye(4))
ck('cotangent_reversal',rev.T*Omega*rev==-Omega)
# O(3) centralizer on R direct-sum R3 has exactly two scalar blocks.
xs=S.symbols('x0:16');M=S.Matrix(4,4,xs)
generators=[S.diag(1,-1,1,1),S.diag(1,1,-1,1),S.diag(1,1,1,-1),
 S.Matrix([[1,0,0,0],[0,0,1,0],[0,1,0,0],[0,0,0,1]]),
 S.Matrix([[1,0,0,0],[0,1,0,0],[0,0,0,1],[0,0,1,0]])]
eqs=[]
for g in generators:eqs.extend(list(M*g-g*M))
coeff,_=S.linear_eq_to_matrix(eqs,xs)
ck('equivariant_centralizer',16-coeff.rank()==2)
# Pauli-matrix realization independently checks polar/bipolar algebra.
sig=[S.Matrix([[0,1],[1,0]]),S.Matrix([[0,-S.I],[S.I,0]]),S.diag(1,-1)]
c,t,E=S.symbols('c t E',real=True)
x=S.symbols('x0:3',real=True);p=S.symbols('p0:3',real=True)
H=c*t*S.eye(2)+sum((x[i]*sig[i] for i in range(3)),S.zeros(2))
K=E/c*S.eye(2)-sum((p[i]*sig[i] for i in range(3)),S.zeros(2))
ck('polar_pauli',S.expand(H.det())==c*c*t*t-sum(v*v for v in x))
ck('polar_pauli',S.simplify(S.trace(H*K)/2)==E*t-sum(x[i]*p[i] for i in range(3)))
for a in [F(1,3),F(1),F(5,2)]:
  for v in [(1,0,0),(0,-2,0),(1,2,2),(2,-3,6)]:
    norm=S.sqrt(sum(q*q for q in v));u=S.Matrix(v)/norm
    ck('polar_boundary',S.simplify(S.Rational(a)*norm-S.Rational(a)*(S.Matrix(v).dot(u)))==0)
    ck('polar_violation',S.simplify(S.Rational(a)*norm-1-S.Rational(a)*(S.Matrix(v).dot(u)))==-1)
theta=S.symbols('theta',real=True)
unitcurve=S.Matrix([S.cos(theta),S.sin(theta),0,0])
ck('hopf_unit_speed',S.simplify(unitcurve.diff(theta).dot(unitcurve.diff(theta)))==1)
ck('hopf_halfturn',unitcurve.subs(theta,S.pi)==-unitcurve.subs(theta,0))
for R in [F(1,3),F(2),F(9,2)]:
  for T in [F(1,7),F(3),F(11,2)]:
    for alpha in [F(1,5),F(2),F(7,3)]:
      for hb in [F(1,11),F(3),F(9,2)]:
        c0=2*S.pi*S.Rational(R)/S.Rational(T)
        ep=2*S.pi*S.Rational(hb)/S.Rational(T)
        ck('calibrated_scale_chain',S.simplify(ep*S.Rational(R)-S.Rational(hb)*c0)==0)
        ck('calibrated_scale_chain',S.simplify(S.Rational(alpha)*ep-c0*S.Rational(hb)/(S.Rational(R)/S.Rational(alpha)))==0)
        ck('causal_homothety',S.simplify(S.Rational(alpha)*c0/S.Rational(alpha)-c0)==0)
        ck('causal_determinant',S.det(c0*S.eye(3))==c0**3)
for a in [F(1,7),F(2),F(7,3)]:
    ck('determinant_root',S.det(S.Rational(a)*S.eye(4))==S.Rational(a)**4)
    ck('tensor_direct_square',S.Rational(a)**2==S.sqrt(S.Rational(a)**4))
result={'actor':'b2_independent','evidence_level':'E3_SUPPORTING_EXACT_CONTROLS','groups':counts,
 'assertions':sum(counts.values()),'result':'PASS',
 'limitations':['Universal arguments are in the certificate ledger, not inferred from finite counts.',
 'C65 odd character is a type/domain control of a natural lift, not a physical countermodel or unconditional refutation.',
 'Physical constructor and occurrence claims retain the source licensed grammar and imported root premises.']}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
