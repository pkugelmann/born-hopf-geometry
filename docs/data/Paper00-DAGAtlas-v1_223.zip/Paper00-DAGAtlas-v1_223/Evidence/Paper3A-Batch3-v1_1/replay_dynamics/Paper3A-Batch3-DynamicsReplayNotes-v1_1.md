# Paper III-A Batch3 — E1 dynamics replay

28 exact source objects C0101–C0128 (3318–4134) were replayed or formalized.
This pass supplies E1 only, not independent E3 or a global framework verdict.
No new source defect is certified by this bounded replay.

The continuation architecture explicitly requires an Orig-certified complete
family/quotient word; a specification alone is not that licence. GP1 exact
presentation, joint conditions, GP3 leastness and actual history tokens remain
separate. Product/fibre-product claims keep the complete joint/lift tests.

Image transport is on V0=imT, not the full ambient V. Existing C^k jets and
the transported kinetic metric retain their own domains. Moving presentation
uses its defined pullback connection, retaining the frame derivative.

Boundary-trivial reclosure reads the locally constant inherited boundary
functional as the complete inherited response of the claim-complete owner.
The weaker B=0 explicit-counterterm reading is not a valid counterexample.
VI-A15373–15425 was read only to confirm its complete-empty-cap consumer scope;
no VI-A theorem is audited. Total-derivative shifts cancel in the intrinsic
combination, while raw canonical momenta remain convention dependent.

Noether scalar invariance, rigid current identity and NoetherII local-parameter
identity are distinct clauses. On-shell/global charges/quantum Ward outputs
retain their own law, boundary, anomaly and measure domains. Regularity is
required for ideal coefficients, and quotient dynamics needs full fibre
constancy. One positive ray still permits multiple inequivalent rates.

Forward C131 finite-generator and C137/C138 projectability portions were read
only as prerequisites. Do not make them whole-paper coverage or turn the
forward reference in action transport into an unnecessary Noether premise
for elementary finite matrix identities. No action/law/source was changed.
