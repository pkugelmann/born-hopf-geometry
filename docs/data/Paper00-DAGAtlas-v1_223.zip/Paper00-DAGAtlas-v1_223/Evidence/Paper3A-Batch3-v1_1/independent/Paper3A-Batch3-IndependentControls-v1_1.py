"""Exact supporting E3 controls for existing III-A claims83–128; not a proof by counts."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import json
import sympy as s
out={'actor':'b3_independent','evidence_level':'E3_SUPPORTING_EXACT_CONTROLS','groups':{},'assertions':0}
def check(group,p):
    assert bool(p),group
    out['groups'][group]=out['groups'].get(group,0)+1;out['assertions']+=1
for hb,R,T,alpha in product([F(1),F(2),F(3,2)],[F(1),F(3),F(5,2)],[F(1),F(4),F(7,3)],[F(1),F(2),F(2,3)]):
    ep=2*s.pi*hb/T
    c=2*s.pi*R/T;rm=R/alpha
    check('normal_form',c*T/rm==2*s.pi*alpha)
    check('normal_form',ep*rm/(hb*c)==1/alpha)
    for n in range(2,12):check('gauge_energy',hb*c*n/R==n*ep)
    for k in range(10):
        check('conformal_scalar',k*(k+2)+1==(k+1)**2)
        check('conformal_scalar',(hb*c/R)**2*(k*(k+2)+1)==((k+1)*ep)**2)
    epsilon,P,theta,X=F(7,3),F(2,5),F(3,2),F(4,7)
    E=epsilon*ep;p=P*hb/rm;t=theta*T/(2*s.pi);xi=R*X
    check('normalized_evaluation',(E*t-p*xi)/hb==epsilon*theta-alpha*P*X)
    check('normalized_cones',c*t/R==theta)
    check('normalized_cones',c*(hb/rm)/ep==alpha)
for n in range(1,30):
    check('integer_clock_phase',s.exp(-2*s.pi*s.I*n)==1)
    check('spinor_clock_phase',s.simplify(s.exp(-2*s.pi*s.I*(n+s.Rational(3,2))))==-1)
    check('spinor_double_clock_phase',s.simplify(s.exp(-4*s.pi*s.I*(n+s.Rational(3,2))))==1)
for occ in product(range(5),repeat=3):
    energy=sum(n*j for n,j in zip([2,3,5],occ))
    check('bosonic_fock_recurrence',s.exp(-2*s.pi*s.I*energy)==1)
for mu2 in range(1,40):
    n=mu2+2
    check('mass_locking_complete_tower',n*n<n*n+mu2<(n+1)*(n+1))
# Cohomology exterior generators have odd degrees3,3,1,1. H2 has only the torus class.
weights=[3,3,1,1]
degree=lambda mask:sum(weights[i] for i in range(4) if mask&(1<<i))
h2=[mask for mask in range(16) if degree(mask)==2]
check('full_compact_cohomology',h2==[12])
check('full_compact_cohomology',bool(h2[0]&h2[0])) # square vanishes by repeated odd factor
for d,k in product(range(1,20),range(-5,6)):
    if d*k==1:check('primitive_cover_degree',d==1 and k==1)
for a,b in product(range(-8,9),range(1,8)):
    lam=F(a,b)
    # Character e^(i lambda theta) is single-valued iff lambda is integral.
    check('marked_clock_deck',s.simplify(s.exp(2*s.pi*s.I*s.Rational(lam.numerator,lam.denominator)))==1 if lam.denominator==1 else s.simplify(s.exp(2*s.pi*s.I*s.Rational(lam.numerator,lam.denominator)))!=1)
    if lam.denominator==1 and abs(lam.numerator)==1:check('marked_clock_faithful',lam in [F(1),F(-1)])
# The two plausible tau normalizations differ by2: rank is unaffected, exact solder is not.
I=s.eye(3);ev=2*I;phi=ev.inv().T;j=I/2;anti=I
check('relative_solder_type_control',ev*j==I)
check('relative_solder_type_control',phi*j.T.inv()==I)
check('relative_solder_type_control',phi*anti.T.inv()==I/2)
check('relative_solder_type_control',(I/2).det()!=0)
# Image-restricted operator transport, including its non-ambient identity.
T=s.Matrix([[1,0],[0,0],[0,1]]);H=s.Matrix([[2,1],[1,3]]);A=s.Matrix([[1,2],[-1,4]])
P=T*T.T;Ht=T*H*T.T
check('image_transport',T.T*T==s.eye(2))
check('image_transport',P!=s.eye(3))
for k in range(10):
    rhs=P if k==0 else Ht**k
    check('image_transport',T*H**k*T.T==rhs)
check('image_commutator',T*(H*A-A*H)*T.T==Ht*(T*A*T.T)-(T*A*T.T)*Ht)
for c,b1,b2 in product(range(1,5),range(-2,3),range(-2,3)):
    B=s.Matrix([[3,1,b1],[1,4,b2],[b1,b2,c]])
    K=B[:2,:2]-B[:2,2:3]*B[2:3,2:3].inv()*B[2:3,:2]
    U=s.Matrix([[0,1],[1,0]])
    Bt=s.diag(U,s.eye(1))*B*s.diag(U.T,s.eye(1))
    Kt=Bt[:2,:2]-Bt[:2,2:3]*Bt[2:3,2:3].inv()*Bt[2:3,:2]
    check('schur_transport',Kt==U*K*U.T)
x=s.symbols('x',real=True);Rot=s.Matrix([[s.cos(x),-s.sin(x)],[s.sin(x),s.cos(x)]])
psi=s.Matrix([x,x*x]);v=Rot*psi
nabla=Rot*s.diff(Rot.T*v,x)
check('moving_connection',s.simplify(nabla-Rot*s.diff(psi,x))==s.zeros(2,1))
check('moving_connection',s.simplify(s.diff(Rot,x).T*Rot+Rot.T*s.diff(Rot,x))==s.zeros(2))
q,z,lam=s.symbols('q z lam',real=True)
for r in range(5):check('claim_relative_jet',s.diff(z**5,z,r).subs(z,0)==0)
check('claim_relative_jet',s.diff(z**5,z,5).subs(z,0)!=0)
B=q**3+lam*q;vel=s.symbols('vel')
L=vel**2/2;Lp=L+s.diff(B,q)*vel
check('boundary_gauge',s.diff(Lp,vel)-s.diff(B,q)==s.diff(L,vel))
G=(q-lam)**2+lam
check('variational_sort',s.diff(G,q).subs(q,lam)==0)
check('variational_sort',s.diff(G,lam).subs(q,lam)==1)
y=s.symbols('y');C=y-x*x;X=[1,2*x+3*C]
check('regular_constraint_ideal',s.expand(s.diff(C,x)*X[0]+s.diff(C,y)*X[1])==3*C)
for n in range(2,20):check('singular_flat_constraint_control',2/(F(1,n)**2)==2*n*n)
q,v,a,w=s.symbols('q v a w');energy=(v*v+w*w*q*q)/2
dt=lambda f:s.diff(f,q)*v+s.diff(f,v)*a
Euler=-a-w*w*q
check('noether_I',s.expand(dt(energy)+Euler*v)==0)
v1,q2,a1,v2=s.symbols('v1 q2 a1 v2')
E1=-a1+v2;E2=-v1+q2
check('noether_II',s.expand(E1-(s.diff(E2,v1)*a1+s.diff(E2,q2)*v2))==0)
for r in [F(1,3),F(1),F(2),F(7,2)]:
    star=s.diag(-1,-2);L=s.Rational(r.numerator,r.denominator)*star
    check('one_ray_rates',L[1,1]==2*L[0,0] and L[0,0]<0)
out.update(result='PASS',limitations=[
    'General source-matched arguments are in IndependentCertificates; finite controls do not certify universal claims.',
    'C99 normalization controls distinguish possible tau maps without declaring either a source-defined physical counterexample.',
    'The clock activation attack is rejected under the printed global applicability/inactive-calibration guard.'])
Path(__file__).with_name('Paper3A-Batch3-IndependentControls-v1_1.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
