# Paper III-A Batch3 independent verification

46 source objects C0083–C0128 covered by36 certificate groups. General exact arguments are in the JSON;3,375 finite exact controls support them.

One source-definition/normalization candidate remains at C0099: tau is unassigned and the two natural transvection normalizations give full versus half Maurer–Cartan cotangent maps. The rank/isomorphism and C0100 fourth-root exponent survive; no refutation is certified.

The provisional C0090 inactive-calibration attack is rejected under the printed global applicability guards. Active clock-doctrine clauses inherit C0066's CAL_t/complete-input domain; inactive output sorts are not silently produced. Pattern-level locus existence is separate from a fixed numerical fiber.

C0087 is certified on its narrow displayed free/untwisted operators, not from stationarity plus zero Yukawa alone. Uninserted does not mean ungauged, and moving normalized Hessian/source frames retain their induced connections. The stronger input-to-operator inference is separately recorded as unestablished/outside the narrow source reading, not an in-domain spectral refutation.

Spectral results are checked for the stated free stationary operators and imported positive normalized supports. No scalar/Yukawa member or actual background is selected. Noether-I and stronger Noether-II local test families retain distinct hypotheses, and regular constraint ideal preservation is not inferred at singular constraints. Exact action transport is restricted to its image carrier and retains the moving connection.

Do not deliver build_independent_records.py; it is only an intermediate serializer.
