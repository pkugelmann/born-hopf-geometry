# Paper III-A Batch3 E1 spectral/local-interface replay

18 source objects C0083–C0100, lines2808–3309, are replayed/formalized. No source defect is certified by this E1 pass. Conditional physical input is retained as domain, not manufactured as a gap.

The coexact/scalar/Dirac frequency substitutions, bosonic Fock vacuum phase, calibrated local cone/evaluation formulas, global compact symplectic obstruction, primitive-line degree argument and fixed marked-clock descent replay exactly. The full gauge locking iff statement uses the V-C all-sufficiently-large-n spectrum clause, not a finite resonance or a whole SM stabilizer import.

C87 spectra require the intended free untwisted action-member reading. Its imported native owners are gauge-covariant and do not themselves force a free/trivial connection member. Because the main source says free stationary operator and the next remark says specified free operator, this remains a qualification watchpoint for adjudication, not a certified counterexample.

C90 must keep activation guards: no optional profile premise on native products; elapsed CLK doctrine/rates only on their CAL_t-active source domain; native calibration tokens are already appropriately typed, not arbitrary unrelated positive numbers.

C99 uses a shorthand tau without its own definition. The canonical transvection evaluation inverse and anti-diagonal identifications have different numerical factors. Both are source-defined isomorphisms; the rank4 conclusion is secure. Do not silently certify exact normalized-coframe equality beyond what the source specifies. C100 only needs rank4, positive scalar homothety and a separately supplied response H.

All exact source spans, proof-use labels, declared/consumed conditions and bounded-import limits are in the JSON. No canonical graph, paper or PDF was modified. Exclude build_records.py as intermediate.
