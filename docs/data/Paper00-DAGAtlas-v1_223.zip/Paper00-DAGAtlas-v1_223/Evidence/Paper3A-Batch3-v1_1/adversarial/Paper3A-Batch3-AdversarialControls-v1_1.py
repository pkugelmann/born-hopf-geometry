"""Exact bounded E4 controls for the already-stated Paper III-A claims83–128.
Finite controls are not universal proofs or physical occurrence certificates.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import json
import sympy as S

groups=Counter()
def check(name,p):
    assert p,name
    groups[name]+=1

# Dimensionless primitive cell and operational clock identities.
for a in [F(1,2),F(1),F(3),F(7,3)]:
 for R in [F(1,3),F(2),F(5)]:
  for T in [F(1),F(3,2),F(7)]:
   # Set 2pi symbolically to kappa; no floating phase comparison.
   kappa=F(6);h=F(5,7);Rx=a*R;c=kappa*Rx/T;E=kappa*h/T;P=h/R
   check('momentum_normal_form',c*T/R==kappa*a)
   check('momentum_normal_form',E*R/(h*c)==1/a)
   check('normalized_evaluation',E*T/h==kappa)
   check('normalized_evaluation',P*Rx/h==a)
   check('joint_calibration_positive_control',E*Rx==h*c)
for n in range(2,80):
 check('massless_clock_integer',S.exp(-2*S.pi*S.I*n)==1)
for k in range(70):
 check('conformal_scalar_affine',k*(k+2)+1==(k+1)**2)
 check('conformal_scalar_clock',S.exp(-2*S.pi*S.I*(k+1))==1)
 check('dirac_half_clock',S.exp(-2*S.pi*S.I*(S.Rational(3,2)+k))==-1)
 check('dirac_double_clock',S.exp(-4*S.pi*S.I*(S.Rational(3,2)+k))==1)
for n in range(2,25):
 for mu in [F(0),F(1,2),F(1),F(3)]:
  squared=F(n*n)+mu*mu
  check('gauge_affine_defect',squared-n*n==mu*mu)
  if mu:
   # A large tower level lies strictly between adjacent squares.
   large=100+int(mu*mu)
   check('massive_complete_tower_boundary',large*large<large*large+mu*mu<(large+1)**2)
check('finite_massive_lock_outside_complete_domain',S.sqrt(2**2+5)==3)
for occup in range(9):
 for n in range(2,15):
  check('fock_integer_excitation',S.exp(-2*S.pi*S.I*occup*n)==1)

# The primitive class cannot descend unchanged through positive degree>1.
for degree in range(1,11):
 for integer in range(-8,9):
  check('unchanged_chern_degree',(degree*integer==1)==(degree==1 and integer==1))
for rate in [F(-3),F(-1),F(-1,2),F(0),F(1,2),F(1),F(2),F(3)]:
 is_integer=rate.denominator==1
 is_faithful=is_integer and abs(rate)==1
 check('circle_deck_rate',is_faithful==(rate in [-1,1]))
 check('positive_primitive_rate',(is_faithful and rate>0)==(rate==1))

# The exact relative-solder arrow has a factor-two ambiguity until tau is defined.
eye=S.eye(3);ev=2*eye;phi=ev.T.inv();solder=S.Rational(1,2)*eye
canonical_right_inverse=ev.inv();anti_inclusion=eye
image_if_eval_inverse=phi*canonical_right_inverse.T.inv()
image_if_anti_inclusion=phi*anti_inclusion.T.inv()
check('relative_solder_control',image_if_eval_inverse==eye)
check('relative_solder_control',image_if_anti_inclusion==solder)
check('relative_solder_control',image_if_eval_inverse==2*image_if_anti_inclusion)
check('relative_solder_control',image_if_eval_inverse.det()==8*image_if_anti_inclusion.det())
check('relative_solder_rank_survives',image_if_eval_inverse.rank()==image_if_anti_inclusion.rank()==3)
for scale in [F(1,3),F(1),F(2),F(5)]:
 check('rank_four_determinant',(S.Rational(scale.numerator,scale.denominator)*S.eye(4)).det()==S.Rational(scale.numerator,scale.denominator)**4)

# Fixed image-space transport: ambient identity is deliberately not used.
T=S.Matrix([[1,0],[0,1],[0,0]])
H=S.Matrix([[2,1],[1,3]]);A=S.Matrix([[1,2],[3,5]])
P=T*T.T;Ht=T*H*T.T
check('isometric_image_transport',T.T*T==S.eye(2))
check('image_identity_not_ambient',P!=S.eye(3))
check('commutator_transport',T*(H*A-A*H)*T.T==Ht*(T*A*T.T)-(T*A*T.T)*Ht)
for power in range(1,12):
 check('image_power_transport',T*H**power*T.T==Ht**power)
x,y,z=S.symbols('x y z',real=True)
action=x*x+2*x*y+3*y*y+x**3*y
sub={x:z,y:2*z}
for order in range(1,5):
 direct=S.diff(action.subs(sub),z,order)
 directional=action
 for _ in range(order):directional=S.diff(directional,x)+2*S.diff(directional,y)
 check('action_jet_chain_rule',S.simplify(direct-directional.subs(sub))==0)
B=S.Matrix([[4,1,2],[1,5,1],[2,1,6]])
check('schur_transport',B[:2,:2]-B[:2,2:]*B[2:,2:].inv()*B[2:,:2]==S.Matrix([[S.Rational(10,3),S.Rational(2,3)],[S.Rational(2,3),S.Rational(29,6)]]))
s=S.symbols('s',real=True);Rot=S.Matrix([[S.cos(s),-S.sin(s)],[S.sin(s),S.cos(s)]])
psi=S.Matrix([s**2,1+s]);v=Rot*psi
check('moving_connection',S.simplify(Rot*S.diff(Rot.T*v,s)-Rot*S.diff(psi,s))==S.zeros(2,1))
check('moving_ordinary_derivative_mutation',S.simplify(S.diff(v,s)-Rot*S.diff(psi,s))!=S.zeros(2,1))

# Complete-owner visibility and source/variational sorting.
q,lam=S.symbols('q lam',real=True)
visible=q*q+lam*q;invisible=lam**3
for order in [1,2,3,4]:
 check('claim_complete_jet_visibility',S.diff(visible+invisible,q,order)==S.diff(visible,q,order))
check('zero_order_visibility_boundary',(visible+invisible)!=visible)
check('external_mark_not_varied',S.diff(visible,q).subs(q,-lam/2)==0)
check('external_mark_not_varied',S.diff(visible,lam).subs(q,-lam/2)==-lam/2)
boundary=S.Rational(3,2)*q*q+lam*q
raw_momentum=S.diff(boundary,q)
check('boundary_exact_shift',raw_momentum-S.diff(boundary,q)==0)

# Same-owner symmetry versus a changed retained coefficient.
R=S.Matrix([-y,x])
grad=S.Matrix([2*x,2*y])
check('noether_complete_owner',S.expand((grad.T*R)[0])==0)
anisotropic_grad=S.Matrix([2*x,4*y])
check('noether_changed_mark_control',S.expand((anisotropic_grad.T*R)[0])==2*x*y)
check('local_noether_flux_control',S.diff(-s,s)+S.diff(x,x)==0)
check('global_charge_needs_boundary',S.diff(-s,s)==-1)

# Regular ideals versus singular zero-set preservation.
C=S.Matrix([x,y]);X=S.Matrix([2*x-y,3*x+4*y]);M=S.Matrix([[2,-1],[3,4]])
check('regular_constraint_ideal',X==M*C)
check('singular_ideal_boundary',S.diff(2*x*y,x,y)==2)
check('singular_ideal_boundary',S.diff(x*x,x,y)==S.diff(y*y,x,y)==0)
# Tangency at the origin of X=(y,x) preserves {0}, but 2xy is not in (x²,y²).
check('singular_zero_set_control',S.Matrix([y,x]).subs({x:0,y:0})==S.zeros(2,1))
for r in [F(1,3),F(1),F(2),F(5)]:
 L=S.diag(-1,-2);K=S.Rational(r.numerator,r.denominator)*L
 check('positive_ray_relation',K==S.Rational(r.numerator,r.denominator)*L)
check('unequal_rates_not_selected',S.diag(-1,-2)!=S.diag(-2,-4))
# Local crossing can be unique while another distant root survives.
t=S.symbols('t',real=True);cross=t*(t-3)
check('local_crossing_scope',cross.subs(t,0)==0 and S.diff(cross,t).subs(t,0)!=0)
check('local_crossing_scope',cross.subs(t,3)==0)

result={'result':'PASS','actor':'b3_adversarial','evidence_level':'E4_SUPPORTING_CONTROLS','assertions':sum(groups.values()),'groups':dict(groups),
 'limits':['Finite controls are not universal proof or a physical countermodel.','Relative-solder factor comparison is conditional on two explicit interpretations of the otherwise unbound tau; rank4 survives.','No external initial datum, physical root-finder, new action or complete solution constructor is generated by these tests.']}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
