#!/usr/bin/env python3
"""Generate self-contained source-frozen Paper IV-C batch 1 dossier and traceable ledger.

No paper/atlas edits; this is staging, subject to later batches and final integrated DAG.
"""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import hashlib,json,re
base=Path('/mnt/data/bh4c_work');stage=base/'staging'
src=next((base/'papers').glob('*/Paper4C-*.tex'))
sc=json.loads((stage/'Paper4C-CompleteSourceCensus-v1_1.json').read_text())
ec=json.loads((stage/'Evidence/Paper4C-Batch1IndependentChecks-v1_1.json').read_text())
anchor=json.loads((base/'atlas/Paper00-DAGAtlas-v1_107/DAG/CurrentSourceAnchorMap-v2_371.json').read_text())['labels']
labels=[a for a in sc['named_claims'] if a['source_locator']['line_start']<=1862]
assert len(labels)==38
assert hashlib.sha256(src.read_bytes()).hexdigest()==sc['source_sha256']==ec['source_sha256']
statuses='''REPRODUCED
VERIFIED-CONDITIONAL
REPRODUCED
VERIFIED-CONDITIONAL
VERIFIED-CONDITIONAL
REPRODUCED
VERIFIED-CONDITIONAL
VERIFIED-CONDITIONAL
REPRODUCED
FORMALIZED
VERIFIED-CONDITIONAL
REPRODUCED
REPRODUCED
VERIFIED
REPRODUCED
VERIFIED-CONDITIONAL
REPRODUCED
REPRODUCED
FORMALIZED
VERIFIED-CONDITIONAL
FORMALIZED
VERIFIED
VERIFIED
VERIFIED
FORMALIZED
VERIFIED-CONDITIONAL
VERIFIED-CONDITIONAL
VERIFIED-CONDITIONAL
VERIFIED
VERIFIED-CONDITIONAL
VERIFIED
VERIFIED
REPRODUCED
FORMALIZED
VERIFIED-CONDITIONAL
FORMALIZED
VERIFIED-CONDITIONAL
FORMALIZED'''.splitlines()
assert len(statuses)==38
src_lines=src.read_text().splitlines()
refs=re.findall(r'\\(?:ref|eqref|autoref)\{([^}]+)\}','\n'.join(src_lines[:1862]))
missing=[x for x in sorted(set(refs)) if x not in anchor]
assert not missing
checks_by_claim={}
for x in ec['checks']:checks_by_claim.setdefault(x['claim'],[]).append(x['id'])
# Avoid turning a citation or all references into reviewed proof dependencies.
# Bind exact explicit proof-use references separately; material verification is scoped.
entries=[];edges=[]
for n,(c,status) in enumerate(zip(labels,statuses),1):
 loc=c['source_locator']; start=loc['line_start']; end=loc['line_end']
 assert anchor[c['id']]['filename']==src.name
 proof=c['proof_as_printed'] or ''
 proofrefs=list(dict.fromkeys(re.findall(r'\\(?:ref|eqref|autoref)\{([^}]+)\}', proof)))
 # These are source-proof-use candidates, not wholesale promoted certified edges.
 deps=[]
 for r in proofrefs:
  owner=anchor[r]
  typ='CANDIDATE_PROOF_USE' if r!=c['id'] else 'SELF_REFERENCE_IN_PROOF'
  witness_start=loc['proof_lines'][0] if loc['proof_lines'] else start
  dep={'from_source_label':r,'to_source_label':c['id'],'kind':typ,
       'source_owner':owner['paper'],'source_file':owner['filename'],'source_line':owner['line'],
       'consumer_proof_start_line':witness_start,'evidence_gate':'E1_SOURCE_MENTION','reviewed_material':False}
  deps.append(dep)
  edges.append(dep)
 item={'id':f'BH-IVC-B1-CL-{n:03d}','source_label':c['id'],
       'source_location':{'file':src.name,'line_start':start,'line_end':end,
                          'proof_lines':loc['proof_lines']},
       'kind':c['kind'],'source_as_printed_title':c['title'],
       'disposition':status,'source_replay':'E1_COMPLETE_FOR_EXPLICIT_LOCAL_STEP',
       'independent_evidence_ids':checks_by_claim.get(c['id'],[]),
       'E3_scope':'SCOPED_CONTROL' if checks_by_claim.get(c['id']) else 'NOT_INDEPENDENTLY_REPROVED_THIS_BATCH',
       'adversarial_evidence':'BATCH1_E4_TARGETED_DOMAIN_CHALLENGES',
       'source_proof_use_candidates':deps,
       'source_prerequisite_status':'INTERFACE_SCOPE_RETAINED' if status=='VERIFIED-CONDITIONAL' else 'NO_NEW_CONSTITUTIVE_CONDITION',
       'not_physical_occurrence_certificate':True,
       'audit_batch':1}
 entries.append(item)
# Machine-readable E4 findings, distinguishing rejected invalid attacks from findings.
e4=[
 {'id':'BH-IVC-B1-E4-001','target':'p4:thm:finite-resolution-rg-threshold-matching',
  'attack':'Treat compression V*XV as an unconditional conditional expectation.',
  'result':'REJECTED_DIFFERENT_CLAIM','replay':'The theorem explicitly requires supplied unital embeddings plus bimodularity before naming a conditional expectation; mere UCP compression is not so named.'},
 {'id':'BH-IVC-B1-E4-002','target':'p4:thm:finite-interacting-qft-calculus',
  'attack':'Assume a finite one-particle rank forces finite bosonic Fock occupation or continuum ultraviolet uniformity.',
  'result':'REJECTED_DIFFERENT_DOMAIN','replay':'Source explicitly restricts to finite Bose/Fermi Fock sector; finite bosonic occupation is additional and continuum uniformity is explicitly excluded.'},
 {'id':'BH-IVC-B1-E4-003','target':'p4:prop:v245-finite-thermal-boundary-correction',
  'attack':'Apply untruncated regular CCR at finite N, including N=0.',
  'result':'REJECTED_DIFFERENT_DOMAIN','replay':'Source includes -(N+1)P_N and exact finite truncated vacuum; N=0 checks yield zero compressed covariance, not full-CCR ground state.'},
 {'id':'BH-IVC-B1-E4-004','target':'p4:prop:intrinsic-localization-moment-transport',
  'attack':'Challenge positive lower bound for each X_a using a coordinate eigenstate.',
  'result':'REJECTED_STRONGER_THAN_SOURCE','replay':'Source bounds sum of four variances, expressly excludes a positive lower bound for each coordinate.'},
 {'id':'BH-IVC-B1-E4-005','target':'p4:thm:v4104-finite-interacting-source-response',
  'attack':'Differentiate a nonlinear source family but omit Q_ab contact or the parent second derivative.',
  'result':'REJECTED_NOT_SOURCE_ALGORITHM','replay':'Source retains full H_AB f^A_,a f^B_,b + H_A f^A_,ab; direct 2x2 finite difference matches contact plus retarded term.'},
 {'id':'BH-IVC-B1-E4-006','target':'p4:cor:v174-yang-mills-reduction-real-form-domain',
  'attack':'Promote stable physical polarization to an unconditional physically occurring Yang-Mills regulator.',
  'result':'REJECTED_STRONGER_THAN_SOURCE','replay':'Source is explicitly conditional on generated reduction and a stable finite polarization block, and disclaims regulator action and path measure.'},
 {'id':'BH-IVC-B1-E4-007','target':'p4:prop:intrinsic-localization-moment-transport',
  'attack':'Read R_p as an arbitrary independent radius unrelated to R_mom of imported Paper II-C theorem.',
  'result':'REJECTED_INHERITED_RADIUS_NOTATION','replay':'I-B defines R_p as momentum-sphere radius; II-C writes R_mom for the same compact momentum radius. Source comparison is at fixed imported carrier/scale, not independent free-radius variation. Maintain notation-watch but no demonstrated in-domain countermodel.'},
 {'id':'BH-IVC-B1-E4-008','target':'p4:cor:v261-degree-two-strengthening',
  'attack':'Conclude Gamma=2I physically occurs from exact comparison uniqueness.',
  'result':'REJECTED_STRONGER_THAN_SOURCE','replay':'Corollary explicitly says the mathematical comparison does not actualize an exceptional-group occurrence; I-B all-level design corollary states the conditional m=1,l=2 uniqueness.'},
]
conditions=[
 {'name':'m_p=1 and H1 momentum carrier','scope':'fixed upstream constituted 15-dimensional physical momentum carrier','provenance':'Paper II-B p2b:thm:momentum-carrier-rigidity','treatment':'INHERITED_ALREADY_PROVED_NO_NEW_ASSUMPTION'},
 {'name':'fixed Spin(4)-equivariant comparison','scope':'maps P_x(k) to End(H1), no multiplicativity or physical POVM selection','provenance':'Paper II-C p2c:prop:no-faithful-allband-xp-map','treatment':'SOURCE_PRINTED_SCOPED_CONDITION'},
 {'name':'sharp-frontier tau_2 physical retention','scope':'only on licensed sharp-frontier branch; first comparison event is conditional','provenance':'upstream comparison/retention branch','treatment':'INHERITED_CONDITIONAL_NOT_OCCURRENCE'},
 {'name':'coherent nested finite resolution and supplied low/high split','scope':'finite exact isometries V_NM; conditional expectation only under extra embedding+bimodule property','provenance':'Paper IV-C p4:thm:finite-resolution-rg-threshold-matching','treatment':'LOCAL_EXPLICIT_THEOREM_HYPOTHESIS_NOT_A_NEW_FRAMEWORK_AXIOM'},
 {'name':'finite Fock domain and bosonic P_gbd(occ,Nmax)','scope':'finite Bose truncation vs finite one-particle K','provenance':'IV-B p4:thm:gp1-bosonic-occupation-boundary; IV-C p4:thm:finite-second-quantization','treatment':'UPSTREAM_SCOPE_INHERITED_NO_DUPLICATION'},
 {'name':'licensed complete Hamiltonian-source second jet','scope':'norm-continuous fixed-rank finite source family, twice source differentiable, coherent frame','provenance':'IV-C p4:thm:v4104-finite-interacting-source-response','treatment':'LOCAL_EXPLICIT_HYPOTHESIS_NOT_DISCHARGED_BY_FINITE_DIMENSION'},
 {'name':'licensed CPTP state reduction and derivatives','scope':'family R_phi within admitted finite joint/reduced algebras','provenance':'IV-C p4:cor:finite-reduced-source-response','treatment':'LOCAL_EXPLICIT_HYPOTHESIS_NOT_GENERATED_BY_REDUCTION_FORMULA'},
 {'name':'stable isolated finite one-particle spectral block','scope':'positive-frequency local free law and upstream Lorentzian branch','provenance':'IV-B p4:thm:finite-one-particle-dispersion','treatment':'INHERITED_CONDITIONAL_NO_REVERSE_GP1_INFERENCE'},
 {'name':'local Yang-Mills generated gauge reduction','scope':'III-F Gauss moment-map zero quotient and separately stable physical polarization','provenance':'III-F p3f:thm:v174-generated-joint-gauge-phase-space-action','treatment':'UPSTREAM_CONDITIONAL_NO_UNCONDITIONAL_PHYSICAL_OCCURRENCE'},
]
score=Counter(statuses)
eqs=[e for e in sc['display_equations'] if e['line_start']<=1862]
batch={
 'audit':'Paper4C','batch':1,'revision':'v1_1','source_authority':'Paper00-PapersMinimal-v2_371',
 'source_file':src.name,'source_sha256':sc['source_sha256'],'source_coverage':{'start':1,'end':1862,'total_lines':sc['source_line_count'],
  'named_checked':len(entries),'named_total':sc['named_count'],'formal_results_in_batch':sum(c['kind'] in ('theorem','lemma','proposition','corollary') for c in labels),
  'named_remaining':sc['named_count']-len(entries),'display_environments_reviewed':len(eqs),'display_environments_total':sc['display_count'],
  'material_unnamed_text':'E1 reviewed sequentially for the two complete sections; not counted as independent formal named objects',
  'out_of_scope':'Paper IV-C lines 1863-10934 and remote-paper blanket verification'},
 'status_counts':dict(score), 'claimed_status_basis':'E1 local source replay + scoped E2 upstream imports; 16 E3 independent controls on a subset; E4 targeted challenges, NOT exhaustive proof-wide independent checks',
 'named_claim_ledger':entries,'source_proof_use_candidate_edges':edges,
 'source_reference_audit':{'ref_occurrences':len(refs),'unique_ref_labels':len(set(refs)),'all_present_in_current_source_map':not bool(missing),'missing':missing,
  'caveat':'locator pass only; no blanket conversion of citation into proof-use edge'},
 'independent_checks_file':'Evidence/Paper4C-Batch1IndependentChecks-v1_1.json','independent_check_count':ec['count'],
 'independent_check_passed':ec['passed_count'],'adversarial_challenges':e4,'found_issues':[],
 'canonical_condition_review':conditions,
 'controlling_imports':[
  {'owner':'I-B','labels':['p1b:thm:all-level-chiral','p1b:prop:all-level-hopf','p1b:thm:mixed-diagonal','p1b:thm:unequal-exchange','p1b:cor:all-level-design-comparison']},
  {'owner':'II-B','labels':['p2b:thm:momentum-carrier-rigidity']},
  {'owner':'II-C / II-F','labels':['p2c:prop:no-faithful-allband-xp-map','p2c:cor:optimal-povm-harmonic-kernel','p2c:thm:optimal-intrinsic-povm-radius','p2c:thm:intrinsic-total-variance','p2c:thm:complete-intrinsic-endpoint-seeds','p2e:prop:sharp-natural-2t-rank']},
  {'owner':'III-F / IV-B','labels':['p3f:thm:v174-generated-joint-gauge-phase-space-action','p4:thm:stationary-quadratic-real-form-pair','p4:thm:finite-one-particle-dispersion','p4:thm:gp1-bosonic-occupation-boundary']},
 ],
 'open_verification_gates':[{'target':'p4:cor:v260-degree-two-fourfold-characterization','gate':'Independent certification of imported first-event physical branch, beyond algebraic representation portion; source explicitly conditional'},
                            {'target':'p4:cor:v261-degree-two-strengthening','gate':'Independent E3 of Hodge transverse onset and exceptional-group exact-design uniqueness still not completed for all four items; source E2 owners located'},
                            {'target':'p4:cor:v174-yang-mills-reduction-real-form-domain','gate':'Full III-F-to-IV-B generated reduction/physical polarization proof-route audit not yet independent; do not claim realized field regulator'}],
 'batch_closure':'PARTIALLY_AUDITED_OVERALL','overall_full_audit_ready':False,
 'successor_archive_policy':'NO_DAG_ZIP_OR_AUDIT_ZIP_IN_INTERMEDIATE_BATCH; final batch only',
 'no_source_modification':True,
}
assert set(e['source_label'] for e in entries)==set(c['id'] for c in labels)
assert ec['count']==16 and ec['passed_count']==16
out=stage/'Batches/Paper4C-AuditBatch1-v1_1.json';out.write_text(json.dumps(batch,indent=2,ensure_ascii=False)+'\n')

mark=[]
mark += ["# Paper IV-C — Rigorous Verification DAG audit, Batch 1 (v1_1)",""]
mark += [f"**Controlling source:** `{src.name}` (SHA-256 `{sc['source_sha256']}`) from the supplied `Paper00-PapersMinimal-v2_371` archive.",""]
mark += ["**Source coverage:** lines **1–1,862** of 10,934, two complete sections; **38/186** named results/remarks disposed; **47/209** displayed equation/align/gather/multline environments included in sequential review. Remaining **148 named objects** and later equations are **not audited**. The first next item begins at line 1,877. No source, macro, or original archive was modified.",""]
mark += [f"**Disposition totals:** "+', '.join(f'{k} {score[k]}' for k in ('VERIFIED','VERIFIED-CONDITIONAL','REPRODUCED','FORMALIZED'))+f". **16/16** independent exact/finite-matrix controls passed; no source-matched counterexample and **0 confirmed issues** in this batch.",""]
mark += ["**Evidence semantics:** `VERIFIED` denotes locally checked mathematical identities with independent controls as applicable; `VERIFIED-CONDITIONAL` retains every source antecedent; `REPRODUCED` is E1/E2 source replay but not a claim-wide fresh E3 certificate; `FORMALIZED` is a mathematically substantive scope/boundary remark, not a proof of a new assertion. The E3 scripts probe *particular* identities, not every clause of every theorem. Several imported hypotheses remain conditional, but that alone is not a defect.",""]
mark += ["## Complete formal-source disposition (38/38)",""]
mark += ["| Line | Exact source label | Status | Direct E3 IDs |","|---:|---|---|---|"]
for c in entries:
 ids=', '.join(z.split('-')[-1] for z in c['independent_evidence_ids']) or '—'
 mark.append(f"| {c['source_location']['line_start']} | `{c['source_label']}` | {c['disposition']} | {ids} |")
mark += ["",'## Independent and adversarial correctness evidence','']
mark += ["All 16 controls were re-run against the frozen current source; each writes a reproducible named certificate in `Paper4C-Batch1IndependentChecks-v1_1.json`:",""]
for ch in ec['checks']:
 mark.append(f"- `{ch['id']}` — **{ch['name']}**: PASS (`{ch['claim']}`).")
mark += ["",'The controls include *global*, not just witness, variance minimization: the four exact invariant-branch minima are `407/576`, `1823/4608`, `4/9`, `9/16` times the common radius squared; the second block is sharp. Finite CCR/occupation tests explicitly cover the top projector, including `N=0`. The Kubo contact+retarded calculation was independently finite-differenced on a two-level system (residual below `1e-10`); the spin-1/2 recoupling 6j matrix is orthogonal to floating-point precision.','']
mark += ['## Rejected adversarial challenges (E4), without new gaps','']
for a in e4:
 mark.append(f"- `{a['id']}` targeting `{a['target']}`: **{a['result']}**. {a['replay']}")
mark += ["",'## Imported-prerequisite and condition check','']
mark += [f"**Reference integrity:** {len(refs)} cross-reference uses, {len(set(refs))} unique labels; **all** resolve to entries of the supplied `CurrentSourceAnchorMap-v2_371.json`. This is locator coverage, not an automated proof certificate. Candidate proof-use edges and their exact source owners are in the companion JSON. No citations were blindly promoted to verified material edges.",""]
for c in conditions:
 mark.append(f"- **{c['name']}** — {c['scope']}. Owner: {c['provenance']}. Disposition: `{c['treatment']}`.")
mark += ["",'## Evidence obligations still open after Batch 1','']
for g in batch['open_verification_gates']:
 mark.append(f"- `{g['target']}` — {g['gate']}")
mark += ["",'These gates keep the listed compound/imported claims at `REPRODUCED` or source-qualified conditional status. **They are not confirmed source proof gaps or counterexamples**, and no new assumption node is introduced merely because a physical occurrence or an optional external certificate is not automatic.','']
mark += ["## Archiving and continuation",'']
mark += ["The paper is **PARTIALLY_AUDITED overall (38/186)**. The next source section starts **line 1,863** (`Euclidean reflection, Gaussian boundary and finite kernel estimates`), with the next formal object at **1,877**. Continue in substantial bounded batches; do not issue the successor DAG ZIP or proof-chain audit ZIP until the final batch. The final versions reserved from the supplied inputs are `Paper00-DAGAtlas-v1_108.zip` and `Paper00-ProofChainAudits-v1_25.zip`; both must include only the latest version of each carried item.",""]
mark += ["**Interim files:** `Paper4C-AuditBatch1-v1_1.json` (statuses, candidate edges, conditional identities and E4 challenges), `Paper4C-Batch1IndependentChecks-v1_1.py/.json` (replay evidence), and `Paper4C-CompleteSourceCensus-v1_1.json` (all 186 source-printed statements, with the unaudited remainder explicitly unpromoted).",""]
md=stage/'Batches/Paper4C-AuditBatch1-v1_1.md';md.write_text('\n'.join(mark)+'\n')
print(json.dumps({'batch_md':str(md),'batch_json':str(out),'n_claims':len(entries),'statuses':dict(score),'e3_pass':ec['passed_count'],'reference_uses':len(refs),'unique_ref_labels':len(set(refs))},indent=2))
