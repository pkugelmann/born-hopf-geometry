# Paper III-A Batch 1 — adversarial review

Scope: source v1.169, lines 77–1472; E4 only.

31 exact-negation/domain attacks recorded. No certified mathematical refutation. 2,540 exact finite controls passed; these are controls, not universal-proof or physical-selection certificates.

The one adverse candidate is SOURCE_SCOPE_AMBIGUITY at the earliest introduction sentence/display lines 95–99 (boxed equality at 98), repeated in import table lines 274–275: summaries use unqualified H_p≅H1, while the precise definition and theorem distinguish generated six-type support from full endpoint multiplicity-one conditional on existing CMP(i)–(iii). Positive reading as canonical model remains valid. No new missing carrier theorem or countermodel is asserted. Root must adjudicate with E1/E3 and source scope.

All boundary/constructor allegations were checked against six BND records. Rank-two naturality failure, incomplete-band Casimir compression, unmarked Hopf-axis nonselection and numerical trace/boundary equality are invalid attacks on the actual hypotheses.

Physical reciprocal roles remain on declared intrinsic-evaluation or scalar-loop constructor domains. Full distance-profile tests need optional P_mc. Dimensionful representatives and field-owner inheritance remain separate.
