from fractions import Fraction as F
import json
import sympy as S
from pathlib import Path
nchecks=0

def check(x):
 global nchecks
 assert x
 nchecks+=1

def mul(a,b):
 w,x,y,z=a;v,p,q,r=b
 return (w*v-x*p-y*q-z*r,w*p+x*v+y*r-z*q,w*q-x*r+y*v+z*p,w*r+x*q-y*p+z*v)
q8=[(1,0,0,0),(-1,0,0,0),(0,1,0,0),(0,-1,0,0),(0,0,1,0),(0,0,-1,0),(0,0,0,1),(0,0,0,-1)]
inv=lambda a:(a[0],-a[1],-a[2],-a[3])
dot=lambda a,b:sum(x*y for x,y in zip(a,b))
for a in q8:
 for g in q8:
  for h in q8:
   check(mul(mul(a,h),g)==mul(a,mul(h,g)))
   check(mul(a,inv(mul(g,h)))==mul(a,mul(inv(h),inv(g))))
  for b in q8:
   check(dot(mul(a,g),mul(b,g))==dot(a,b))
# Wrong-order mutation: source correctly uses rho(g)rho(h)=rho(hg).
i,j=q8[2],q8[4]
check(mul(i,j)!=mul(j,i))
for num in range(-9,10):
 for den in range(1,8):
  t=F(num,den)
  check((-t)*F(-1)==t) # e->-e and t->-t leaves t e* unchanged.
  for shift in (-3,-1,0,2):
   check((t+shift-t).denominator==1)
# Scalar Born exchange uses beta^-1 beta=id, not a graph restriction.
for n in range(2,10):
 for a in range(n):
  for b in range(n):
   check((b,a)[::-1]==(a,b))
# Exact chiral SU2 controls, both signs; general proof is in E4 records.
for k in range(0,10):
 j=S.Rational(k,2);weights=[-j+m for m in range(k+1)]
 Jz=S.diag(*weights);Jp=S.zeros(k+1)
 for c,m in enumerate(weights[:-1]):Jp[c+1,c]=S.sqrt((j-m)*(j+m+1))
 Jm=Jp.T;Jx=(Jp+Jm)/2;Jy=(Jp-Jm)/(2*S.I)
 check(S.simplify(4*(Jx*Jx+Jy*Jy+Jz*Jz)-k*(k+2)*S.eye(k+1))==S.zeros(k+1))
 charges=[int(2*m) for m in weights]
 check(charges==list(range(-k,k+1,2)))
 check(all((-1)**q==(-1)**k for q in charges))
 support=set()
 for l in range(k+1):support.update(range(-l,l+1,2))
 check(support==set(range(-k,k+1)))
 # geometric multiplicity (k+1) repeats each chiral weight.
 check((k+1)*len(charges)==(k+1)**2)
# Incomplete-band compression really breaks the Casimir; invalid domain attack.
check(1 != 3)
# Rank2 basis mutation is outside rank1 theorem: transpose-inverse differs.
A=S.Matrix([[1,1],[0,1]])
check(A!=A.inv().T)
# Conjugation can reverse an oriented axis and also rotate it to a distinct torus.
check(mul(mul(q8[2],q8[4]),inv(q8[2]))==q8[5])
quarter=(S.sqrt(2)/2,S.sqrt(2)/2,0,0)
rotated=mul(mul(quarter,q8[4]),inv(quarter))
check(tuple(S.simplify(x) for x in rotated)==q8[6])
result={'test_assertions':nchecks,'passed':True,'coverage':'finite positive/mutation controls only; universal arguments and source-domain matching in adversarial ledger','source':'Paper3A-GeneratedDynamics-v1_169.tex:77-1472','claims_not_certified_by_count':True}
Path(__file__).with_suffix('.result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
