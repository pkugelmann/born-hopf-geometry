"""Finite exact E3 controls for already-stated III-A batch1 claims.
These controls corroborate general arguments; they do not certify physical occurrence.
"""
import collections,json
from fractions import Fraction
from pathlib import Path
import sympy as sp
out={'checker':'independent_math','evidence_level':'E3','checks':{},'assertions':0}
def chk(group,p):
 assert p,group
 out['checks'][group]=out['checks'].get(group,0)+1
 out['assertions']+=1
# Polynomial sl2 representation: no radicals or floating point.
for k in range(13):
 n=k+1; E=sp.zeros(n); F=sp.zeros(n)
 for r in range(n):
  if r:E[r-1,r]=r
  if r<k:F[r+1,r]=k-r
 H=sp.diag(*[k-2*r for r in range(n)])
 # Source Q_i=-2L_i in one chiral factor.
 Q=[-(E+F),sp.I*(E-F),-H]
 chk('scalar_chiral_casimir',sum((x*x for x in Q),sp.zeros(n))==k*(k+2)*sp.eye(n))
 for i in range(3):
  for j in range(3):
   chk('spectral_trace_isotropy',sp.trace(Q[i]*Q[j])==(sp.Rational(k*(k+2)*n,3) if i==j else 0))
 chk('primitive_half_turn_parity',all(((-1)**int(H[r,r]))==(-1)**k for r in range(n)))
 # positive and negative source half-integer action weights have same support.
 chk('scalar_degree_clock_support',sorted(list(H.diagonal()))==list(range(-k,k+1,2)))
for m in range(25):
 weights=collections.Counter()
 for k in range(m+1):
  for q in range(-k,k+1,2):weights[q]+=k+1
 chk('complete_position_clock_support',sorted(weights)==list(range(-m,m+1)))
 for q,d in weights.items():
  r=(m-abs(q))//2
  chk('position_clock_multiplicity_formula',d==(r+1)*(abs(q)+1+r))
 chk('complete_position_band_dimension',sum(weights.values())==(m+1)*(m+2)*(2*m+3)//6)
# Canonical rank-one comparison survives e -> -e, for arbitrary rational t mod1.
for den in range(1,17):
 for num in range(-den,den+1):
  t=Fraction(num,den)
  chk('rank_one_generator_flip',(-t)*(-1)==t)
  for shift in [-3,-1,0,2]:
   chk('rank_one_quotient_well_defined',(t+shift)%1==t%1)
# Character identities are exact exponent equalities in rational phase classes.
for den in range(1,13):
 for theta_num in range(den):
  theta=Fraction(theta_num,den)
  for n in range(-4,5):
   chk('character_inverse',(-n*theta)%1==(-(n*theta))%1)
   for m in range(-2,3):chk('character_multiplication',((n+m)*theta)%1==((n*theta)+(m*theta))%1)
# Quaternion subgroup controls, using actual S3 geodesic distance in units pi/2.
units=[(1,0,0,0),(0,1,0,0),(0,0,1,0),(0,0,0,1)]
Q8=[tuple(s*a for a in u) for u in units for s in [1,-1]]
def mult(a,b):
 w,x,y,z=a; v,p,q,r=b
 return (w*v-x*p-y*q-z*r,w*p+x*v+y*r-z*q,w*q-x*r+y*v+z*p,w*r+x*q-y*p+z*v)
def inv(a):return (a[0],-a[1],-a[2],-a[3])
def dist(a,b):
 dot=sum(x*y for x,y in zip(a,b))
 return {1:0,0:1,-1:2}[dot]
for a in Q8:
 for b in Q8:
  chk('metric_profile_sup_isometry',max(abs(dist(a,x)-dist(b,x)) for x in Q8)==dist(a,b))
  beta=lambda x:('B',inv(x))
  beta_inv=lambda x:inv(x[1])
  born=lambda x,y:(beta_inv(y),beta(x))
  ap,bp=born(a,beta(b))
  chk('born_swap_involution',born(ap,bp)==(a,beta(b)))
  chk('inversion_to_opposite',inv(mult(a,b))==mult(inv(b),inv(a)))
  for g in Q8:
   chk('right_translation_profile_identity',dist(a,mult(b,inv(g)))==dist(mult(a,g),b))
for g in Q8:
 for h in Q8:
  for a in Q8:
   # rho(g)rho(h)b_a=b_(a h g)=rho(hg)b_a.
   chk('opposite_regular_action',mult(mult(a,h),g)==mult(a,mult(h,g)))
# Canonical closure and boundary coefficient identities on general integer matrices.
for n in range(1,8):
 T=sp.Matrix(n,n,lambda i,j:(i+2)*(j-1)+i-j*j)
 psi=sp.Matrix([i*i-2 for i in range(n)])
 eps=sp.Matrix(1,n,lambda i,j:2*j+1)
 closure=sum(T[i,i] for i in range(n))
 chk('canonical_duality_trace',closure==sp.trace(T))
 chk('boundary_to_marked_trace',(eps*T*psi)[0]==sp.trace(psi*eps*T))
 # Numerical equality does not erase rank-one mark; this is a typing observation only.
 for p in [Fraction(1,2),Fraction(2),Fraction(7,3)]:
  # a=p,hbar=3,c=5/7,E*=hbar*c/a: exact coefficient identity.
  h=Fraction(3);c=Fraction(5,7);a=p;Estar=h*c/a
  chk('calibrated_kinetic_coefficient',Estar*Estar*a*a==h*h*c*c)
out['limitations']=['Finite controls support but do not replace the separately recorded universal arguments.','No countermodel or proof concerning unlicensed physical output is asserted.','Generic physical clocked-Hopf realization is a forward prerequisite beyond this batch.']
Path(__file__).with_name('Paper3A-Batch1-IndependentControls-v1_1.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
