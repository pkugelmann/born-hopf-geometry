# Paper III-A batch 1 source replay

36 formal source objects and 7 material wrappers replayed/formalized. E1 only; no independent-proof status implied.

The current formal support/endpoint distinction is correct at definitions 510–530 and theorem1146–1169. One earliest narrative-scope ambiguity at97–112 recurs at194–201,277–283,344–349,1052–1055 and1081–1083; it is not a counterexample to mp=1.

Scalar CHAR and full-profile outputs use declared frozen constructor grammars. Compact spectrum mathematics is not promoted to physical output. Native reciprocal role does not consume optional P_mc. Character support and kinetic identity reproduce exact II-D complete-band identities and their calibrations.

Detailed per-object steps, imported source labels, explicit conditions, negative checks, and limitations are in E1Replay.json.
