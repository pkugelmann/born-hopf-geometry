# Paper III-A source census

Authoritative source: `Paper3A-GeneratedDynamics-v1_169.tex` from supplied papers v2_370. This proposal freezes source objects; it makes no mathematical verdict and promotes no citation to a proof-use edge.

The denominator is 185 substantive source objects: 152 formal declarations (38 theorems, 49 corollaries, 9 lemmas, 5 propositions, 17 definitions, 30 remarks and 4 principles), plus 33 unique unnamed mathematical, calibration, domain or imported-interface units. Multi-clause results retain full exact text and need clause-specific checking; the denominator is not a count of atomic propositions. Repeated introductions, proof-ownership prose, ledger tables and conclusion summaries map to existing owners rather than being counted twice.

Batch 1 covers 47 objects, BH-IIIA-C-0001 through BH-IIIA-C-0047, ending at the doubled-vector-family corollary (1445–1471). It includes 36 formal declarations and 11 unnamed units. Batch 2 begins with BH-IIIA-C-0048, the vector symplectic-defect theorem at line 1476.

All 84 proof environments have exact formal owners. Every displayed formula is indexed with its parent source object or summary owner. Bibliography is at line 5729; there is no post-bibliography mathematical content. The shared macros and bibliography are controlling inputs and not extra audited manuscripts.

The entire mathematical body was inspected for extraction, including the forward action/jet and final Petersen sections. A source-first status remains NOT_AUDITED until the coordinator integrates claim-matched E1/E3/E4 checks. No canonical graph, paper or supplied ZIP was changed.
