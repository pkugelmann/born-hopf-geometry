#!/usr/bin/env python3
"""Build final Paper4C batch evidence and non-mutating whole-paper audit report."""
from pathlib import Path
from collections import Counter
import hashlib, json, re
B=Path('/mnt/data/bh4c_work/staging'); SRC=Path('/mnt/data/bh4c_work/papers/Paper00-PapersMinimal-v2_371/Paper4C-TechnicalMaterial-v1_42.tex')
J=lambda p:json.loads(Path(p).read_text())
W=lambda p,v:Path(p).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
census=J(B/'Paper4C-CompleteSourceCensus-v1_1.json');tex=SRC.read_text().splitlines();sha=hashlib.sha256(SRC.read_bytes()).hexdigest()
assert sha==census['source_sha256'] and len(tex)==10934 and census['named_count']==186
checks=J(B/'Evidence/Paper4C-Batch7IndependentChecks-v1_1.json');assert checks['count']==checks['pass']==56 and checks['fail']==0
status_by_index={164:'VERIFIED',165:'VERIFIED',166:'VERIFIED',167:'VERIFIED-CONDITIONAL',168:'VERIFIED',169:'VERIFIED-CONDITIONAL',170:'VERIFIED',171:'VERIFIED-CONDITIONAL',172:'VERIFIED-CONDITIONAL',173:'FORMALIZED',174:'VERIFIED-CONDITIONAL',175:'FORMALIZED',176:'VERIFIED-CONDITIONAL',177:'VERIFIED-CONDITIONAL',178:'VERIFIED',179:'FORMALIZED',180:'VERIFIED',181:'VERIFIED',182:'VERIFIED-CONDITIONAL',183:'FORMALIZED',184:'VERIFIED',185:'UNRESOLVED',186:'FORMALIZED'}
assert len(status_by_index)==23
source_guards={
164:'Supplied finite self-adjoint T0 and complete joint source columns J0; no independent physical selector.',
165:'C^k fixed pairing and self-adjoint T(q), finite-dimensional carrier, nonreal z; use all contact derivatives.',
166:'Finite positive 1-particle CAR comparison, independent spectral site energies; first-derivative path matrix.',
167:'Actual flat metric-compatible connection, fixed rank, local parallel frame, all moving-frame transport retained.',
168:'Second derivative equality for every consumed direction as a function of z; cyclicity of J0 on P0.',
169:'Two-mode CAR comparison with supplied H(q), Fock vacuum and addition tag, |q|<1.',
170:'Central shift of Hamiltonian; action/metric ports retain central contributions.',
171:'The same finite action-owned hard, soft, incoming charge insertions and canonical Ward residual when bound consumed.',
172:'Finite stationary self-adjoint H and positive density commuting with it; action-owned self-adjoint charge insertion.',
173:'Finite stationary spectral diagonal is not asymptotic soft theorem; limit interchange not established.',
174:'Supplied unit-round S2 angular comparison geometry; no physical spin-two or memory normalization.',
175:'No asymptotically flat boundary/soft charge derived from local projective null-direction sphere.',
176:'Ten marked projective Hopf axes with exact Petersen S; lifts not physical rotations or one group representation.',
177:'Imported exact T_ij=J_i+J_j pair metric; auxiliary Hilbert block, no physical energy ownership.',
178:'Ten real rank-one effects on auxiliary real 3-space, two-factor product frame; no physical instrument.',
179:'Coherent-path transport and source-owned action remain separate physical conditions.',
180:'Standard vacuum of sharp truncated a_N, N>=1, sigma>0; not arbitrary truncated quadratic ground.',
181:'Explicit matrix multiplication after compression; differs from regular CCR polynomial evaluation.',
182:'Positive symmetric real G on regular CCR representation, canonical symplectic J, principal square root.',
183:'Selected cap, preparation, quadrature source, actual physical higher-moment readout not supplied.',
184:'Standard truncated oscillator vacuum spectral measure with N>=1; finite Jacobi matrix.',
185:'Independent product-vacuum truncated modes and real coefficients; all-zero vector permitted as printed but m undefined.',
186:'Finite quadrature mathematics not apparatus occurrence; source state and detector selection remain open.'}
claim_ledger=[]
for index in range(164,187):
 row=census['named_claims'][index-1];loc=row['source_locator']; assert 10129<=loc['line_start']<=10934
 match=[v['id'] for v in checks['checks'] if v['source_claim']==row['id']]
 claim_ledger.append({'id':row['id'],'audit_record_id':f'BH-IVC-B7-CL-{index-163:03d}','source_label':row['id'],'label':row['id'],'kind':row['kind'],'source_location':loc,'source_as_printed_title':row['title'],'source_as_printed':row['source_as_printed'],'statement_layer':'SOURCE-AS-PRINTED','status':status_by_index[index],'disposition':status_by_index[index],'source_replay':'E1 proof read and types/quantifiers/domain checked; see full report and scoped controls','domain_guard':source_guards[index],'E3_E4_ids':match,'proof_as_printed':'\n'.join(tex[loc['proof_lines'][0]-1:loc['proof_lines'][1]]) if isinstance(loc.get('proof_lines'),list) and len(loc['proof_lines'])==2 else None,'issues':['BH-G-000106'] if index==185 else [],'physical_occurrence_upgraded':False})
# Source-independent exact hostile all-zero coefficient witness.
issue={'issue_id':'BH-G-000106','id':'BH-G-000106','class':'MISSING_CONDITION','secondary_class':'TYPE_OR_DOMAIN','severity':'minor','lifecycle':'OPEN','issue_status':'established_in_domain_empty_minimum','statement_layer':'SOURCE-AS-PRINTED','first_origin':{'paper':'Paper4C','theorem_id':'p4c:thm:v349-multimode-first-cumulant','step_locator':'Paper4C-TechnicalMaterial-v1_42.tex:10893-10909; proof 10917-10919','source_excerpt':'real coefficients c_a ... m=min_{c_a ne 0}(N_a+1)'},'exact_obligation':'The theorem needs at least one real coefficient c_a nonzero for m=min_{c_a !=0}(N_a+1) to be defined and for the asserted strictly negative cumulant to exist. The printed quantification allows an all-zero coefficient vector.','source_replayed':True,'independent_evidence':['IVC7-055'],'adversarial_evidence':['IVC7-056'],'in_domain_counterexample':{'number_of_modes':2,'N_1':1,'N_2':3,'sigma_1':1,'sigma_2':1,'c_1':0,'c_2':0,'Q':'0','m':'undefined (minimum of empty set)','strictly_negative_claim':'false/undefined; all connected cumulants vanish'},'constitution_boundary':None,'conditions_consumed':['Independent tensor-factor vacuum and N_a >= 1 with finite set of real c_a'],'conditions_open':['At least one c_a != 0 (not stated)'],'canonical_condition_id':'BH-IVC-A-NONZERO-COEFF-001','upstream_material_paths':[['p4c:thm:v347-first-cutoff-cumulant','p4c:thm:v349-multimode-first-cumulant:10913-10919']],'downstream_verified_paths':[],'other_papers_affected':[],'possible_unconfirmed_impacts':['A later use as a universal detector cutoff diagnostic allowing zero measured quadrature source; no source-verified downstream proof edge'],'verified_bypass_routes':['Same theorem calculation on explicitly nonzero coefficient branch (as used in its proof)'],'why_it_matters':'As-printed all-coefficient domain includes Q=0, which has no first non-Gaussian cumulant; conditional nonzero branch is algebraically correct.','resolution_requirement':'Make the nonempty support of nonzero real coefficients a theorem hypothesis, or explicitly classify the Q=0 branch; no manuscript edit in this audit.','audit_scope_limit':'Localized edge case; not a refutation of the finite Hermite law or any nonzero-coefficient cumulant formula.'}
unnamed=[
 ('IVC-B7-U-001',10131,10161,'source-state and fixed/moving pairing HS realization boundary'),
 ('IVC-B7-U-002',10189,10203,'cyclic jet recursion and higher-source derivatives'),
 ('IVC-B7-U-003',10229,10253,'resolvent-chain proof and two-sided derivative counting'),
 ('IVC-B7-U-004',10293,10297,'moving-frame contact guard'),
 ('IVC-B7-U-005',10320,10355,'all 11 second-jet derivative terms and positive necessary block argument'),
 ('IVC-B7-U-006',10403,10409,'finite versus asymptotic gravity operator boundary'),
 ('IVC-B7-U-007',10471,10482,'Cesaro stationary noise and retarded-only counterexample'),
 ('IVC-B7-U-008',10523,10531,'Ricci tracefree Hessian commutation'),
 ('IVC-B7-U-009',10549,10602,'Petersen conditional source and signed permutation enumeration'),
 ('IVC-B7-U-010',10631,10639,'singular value to resolvent/CP identities'),
 ('IVC-B7-U-011',10660,10675,'two-product real-symmetric blind space witness'),
 ('IVC-B7-U-012',10699,10703,'truncated-vs-regular CCR scope'),
 ('IVC-B7-U-013',10733,10747,'Dyck walk moment deficit and cumulant triangularity'),
 ('IVC-B7-U-014',10804,10822,'Williamson symplectic functional calculus'),
 ('IVC-B7-U-015',10877,10891,'associated Hermite numerator and Gaussian quadrature'),
 ('IVC-B7-U-016',10910,10920,'independent mode characteristic function/cumulant proof and all-zero guard')]
refs=[]
for i in range(10129,10935):
 for m in re.finditer(r'\\(?:ref|eqref|autoref|cref|Cref|pageref)\{([^{}]*)\}',tex[i-1]):refs.append({'use_line':i,'label':m.group(1)})
assert len(refs)==6 and len({x['label'] for x in refs})==6
import zipfile
z=zipfile.ZipFile('/mnt/data/Paper00-DAGAtlas-v1_108(1).zip')
source_map=J('/mnt/data/bh4c_work/atlas/finalbuild/Paper00-DAGAtlas-v1_108/DAG/CurrentSourceAnchorMap-v2_371.json')['labels']
assert all(x['label'] in source_map for x in refs)
status_counts=dict(Counter(v['status'] for v in claim_ledger))
prior=[J(B/f'Batches/Paper4C-AuditBatch{i}-v1_1.json') for i in range(1,7)]
prev=Counter()
for block in prior:
 for item in block['named_claim_ledger']:prev[item.get('status',item.get('disposition'))]+=1
allcount=prev+Counter(status_counts)
assert sum(allcount.values())==186
# Explicit source-matched typed proof dependencies in this span; no citation-only promotion.
edges=[
 ('p4:thm:v251-joint-cyclic-response','p4:thm:v251-finite-jet-cyclic-carrier',10239,'PREMISE_OF','Finite cyclic P0 reduces T0 in the C_r recursion'),
 ('p4:thm:v251-finite-jet-cyclic-carrier','paper4c:corollary:atlas-the-derivative-depth-bound-is-sharp-in-general-36af441',10263,'REQUIRES','The depth r truncation is the target of the sharpness example'),
 ('p4:thm:v251-finite-jet-cyclic-carrier','p4:cor:v251-jet-carrier-frame-covariance',10287,'REQUIRES','Parallel-frame transfer of exact k-jet theorem'),
 ('p4:thm:v251-joint-cyclic-response','p4:prop:v251-static-cyclic-jet-defect',10301,'REQUIRES','P0 is the reducing source-cyclic subspace'),
 ('p4b:thm:v254-in-in-charge-detector-covariance','p4c:prop:v254-nonsharp-ward-covariance',10413,'IMPORTED_PROOF','Same action pullback and exact charge residual identity'),
 ('p4b:cor:v254-ward-operator-residual','p4c:prop:v254-nonsharp-ward-covariance',10426,'IMPORTED_PROOF','Conditional Ward residual norm formula'),
 ('p1:thm:petersen-signed-and-flux','p4c:prop:v320-s5-signed-lift',10565,'IMPORTED_PROOF','Ten signed Hopf axes and Petersen signed adjacency'),
 ('p1:thm:petersen-subset-polar','p4c:prop:v320-transfer-proof',10607,'IMPORTED_PROOF','Exact ten pair transfer matrix metric'),
 ('p2c:thm:v318-quadrupole-tomography','p4c:prop:v320-quantum-readout-no-go',10661,'IMPORTED_PROOF','Tight frame spanning real traceless symmetric effects'),
 ('p4c:thm:v347-first-cutoff-cumulant','p4c:thm:v349-hermite-vacuum-law',10887,'PREMISE_OF','Moment degree agreement supplies cutoff side; Hermite quadrature separate finite check'),
 ('p4c:thm:v347-first-cutoff-cumulant','p4c:thm:v349-multimode-first-cumulant',10913,'PREMISE_OF','Independent-mode single cutoff cumulant values')]
edgelist=[{'id':f'BH-IVC-B7-EDGE-{k:03d}','from':a,'to':b,'kind':t,'relation':t,'proof_route_id':'BH-IVC-ROUTE-'+b,'logic_group':'AND','source_use_locator':{'file':SRC.name,'line':line},'source_witness':w,'scope_guard':source_guards.get(next((i for i in status_by_index if census['named_claims'][i-1]['id']==b),164),'Source typed domain'), 'review_status':'SOURCE_MATCHED_MATERIAL','verified_material_edge':True,'evidence_id':f'BH-IVC-B7-E1-EDGE-{k:03d}'} for k,(a,b,line,t,w) in enumerate(edges,1)]
nonpromoting=[{'from':'p4:thm:v249-source-hs-realization','to':'p4:thm:v251-joint-cyclic-response','kind':'CONSTRUCTOR_INPUT','source_line':10134,'status':'CONDITIONAL_ACTUAL_PACKET_NOT_MATHEMATICAL_LEMMA_PREMISE'}, {'from':'p4:thm:v251-finite-jet-cyclic-carrier','to':'p4:prop:v251-dark-sector-second-return','kind':'INTERPRETATION_OF','source_line':10374,'status':'EXAMPLE_CHECK_INDEPENDENT_PROOF_NOT_CONSUMED'}, {'from':'p12:rem:v254-static-noise-limit-gate','to':'p4c:thm:v254-zero-mode-no-omission','kind':'CITATION_ONLY','source_line':10494,'status':'LIMIT_GUARD_NAVIGATION_NOT_PREMISE'}]
block={'audit':'Paper4C','batch':7,'revision':'v1_1','protocol':'Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md','source_authority':'Paper00-PapersMinimal-v2_371','source_file':SRC.name,'source_sha256':sha,'source_coverage':{'start':10129,'end':10934,'line_count':806,'named_checked':23,'named_total':186,'cumulative_named_checked':186,'named_remaining':0,'material_unnamed_reviewed':len(unnamed),'display_equation_coverage':'printed equations reviewed as part of source-bound E1 proof scan'},'status_counts':status_counts,'cumulative_status_counts':dict(allcount),'named_claim_ledger':claim_ledger,'material_unnamed_steps':[{'id':x[0],'source_span':[x[1],x[2]],'source_excerpt':'\n'.join(tex[x[1]-1:min(x[1]+5,x[2])]),'review_target':x[3],'status':'SOURCE_REPLAYED'} for x in unnamed],'source_reference_audit':{'occurrences':refs,'count':len(refs),'unique_count':len({x['label'] for x in refs}),'all_resolved':True,'citations_nonpromoting':True},'source_proof_use_edges':edgelist,'nonpromoting_edges':nonpromoting,'found_issues':[issue],'carried_forward_issues_unchanged':[i['issue_id'] for d in prior for i in d['found_issues']],'independent_checks_file':'Evidence/Paper4C-Batch7IndependentChecks-v1_1.json','independent_check_count':56,'independent_check_passed':56,'E3':50,'E4':6,'adversarial_evidence':{'empty_coefficients':'IVC7-056','reconstructed_120_lifts':'IVC7-029','Petersen_readout_blind_pair':'IVC7-036','retarded_noise':'IVC7-022'},'canonical_conditions_new_candidates':['BH-IVC-A-NONZERO-COEFF-001'],'open_verification_gates':['Full conditional physical application of detector, memory and action-owned Hopf instruments not established','Historical packaged Paper4C-PetersenQuantum-v1_1-verify.py not present in provided source/DAG ZIPs; independent enumeration regenerated here','Older Batch 1/5 formalized E1 claims retain proof-wide independent evidence limits','The 128-dimensional historical charge comparison from Batch 6 remains without full input reconstruction'],'batch_closure':'FINAL_SOURCE_SCAN_COMPLETE_WITH_ONE_NEW_MINOR_DOMAIN_GUARD','all_claims_examined':True,'source_unmodified':True,'requested_final_outputs':['Paper00-DAGAtlas-v1_109.zip','Paper00-ProofChainAudits-v1_26.zip']}
W(B/'Batches/Paper4C-AuditBatch7-v1_1.json',block)
lines=['# Paper IV-C — Rigorous Verification DAG Audit, Batch 7 (v1_1)','',f'**Source:** `{SRC.name}` (SHA256 `{sha}`), 10,129–10,934 of 10,934 source lines. **Protocol:** v2.4; no source rewriting.','',f'**Named source objects:** 23/23; **cumulative:** 186/186. **Material unnamed blocks:** {len(unnamed)}. **Independent checks:** 56/56 (50 E3 constructive, six E4 adversarial), each with stated scope.','',f'**Batch dispositions:** '+', '.join(f'{k}: {v}' for k,v in status_counts.items())+'.','', '| Source line | Exact label | Status | E3/E4 controls |','|---:|---|---|---|']
for e in claim_ledger:
 lines.append(f"| {e['source_location']['line_start']} | `{e['source_label']}` | {e['status']} | {', '.join(e['E3_E4_ids']) or 'E1 source/scope replay'} |")
lines+=['','## Source-matched proof verdicts','', '**Jet-cyclic source response (10131–10396).** The self-adjoint reducing cyclic subspace preserves the full joint source residue matrix; recursive source/interaction jets return every derivative through order k on C_floor(k/2). Formal resolvent-series tests reproduce the sharp order 2r+2 escape, the exact second-jet loss factorization, its positivity-based necessity test and the two-mode CAR dark return. Static matter response does not recover central source-energy shifts. The moving-frame covariant version is conditional on the supplied flat metric connection and retained connection contacts.','', '**Ward/static noise/angular (10403–10544).** Covariance expansion with nonsharp incoming charge agrees with the IV-B residual identity. A finite stationary zero-mode Cesaro average retains positive static noise which the retarded commutator does not determine (exact two-level witness). On a *stipulated unit-round* angular sphere, the tracefree Hessian has eigenvalue (ell−1)ell(ell+1)(ell+2)/2 for ell>=2; the physical soft-charge and asymptotic-memory normalization remain separate conditions.','', '**Petersen–Hopf certificates (10547–10692).** The source ten-axis signed adjacency reproduces all 60 even and all 60 odd signed S5 lift identities in a mapped Kneser graph. Spectral projectors have dimensions 3,4,3. The pair transfer has singular values 2,1/2,1/2 and a sign-invariant diagonal resolvent/CP effect, conditional on the previously derived pair metric. Rank tests reproduce 6 real single-copy effects, 36 product effects and a positive pair of nonseparable-by-products nine-states with a 4/9 correlation distinction. No action-owned physical instrument follows from this finite comparison.','', '**Oscillator exact distribution (10696–10930).** N=1–6 truncated vacuum moments and their first negative non-Gaussian cumulant reproduce the Dyck-walk deficit; Hermite spectral weights/quadrature tested at N=1,2,3,5,7; associated-Hermite trailing minor and m=1,2,3 regular-CCR Williamson covariance tested. Gaussian ground covariance is not assigned to a truncated quadratic Hamiltonian. Multimode non-cancellation formula is valid on the nonzero-source branch, but printed theorem omits nonzero coefficient requirement.','', '## New source-bound issue','', '**BH-G-000106 — Minor, MISSING_CONDITION / TYPE_OR_DOMAIN, OPEN.** At `p4c:thm:v349-multimode-first-cumulant`, lines 10893–10919, the coefficients c_a are arbitrary real values. Choosing all c_a=0 is admitted, yet the minimum `m=min_{c_a !=0}(N_a+1)` is undefined and Q=0 has all cumulants zero, contradicting the claimed strict negativity on the full printed domain. The nonzero-support branch is independently reproduced and unaffected; evidence `IVC7-056`. Required: explicitly require a nonempty active coefficient support or separately state the Q=0 branch. No manuscript repair performed.','', '## Carried issues and evidence boundaries','', '- `BH-G-000102`: truncated-boson boundary margin in polynomial approximate microcausality — UNDER_CHALLENGE, full spatial theorem not refuted.','- `BH-G-000103`: scalar Bogoliubov differentiability — OPEN.','- `BH-G-000104`: arbitrary time-dependent finite recurrence — OPEN, ancillary statement only.','- `BH-G-000105`: double-slit interference absence does not imply dephasing — OPEN, exact Born expression unaffected.','',f'All {len(refs)} distinct explicit `ref`/`eqref` uses in this final span resolve in the current source-anchor map. These labels alone are not material proof edges. The claim-bearing PDF was not compiled; no theory was modified.','','**Classification at the end of Batch 7:** `FULLY_AUDITED_WITH_OPEN_GAPS` at source-disposition level, with the stated E3 and physical-realization evidence limits.']
(B/'Batches/Paper4C-AuditBatch7-v1_1.md').write_text('\n'.join(lines)+'\n')
print('Batch 7 built:',len(claim_ledger),'claims',len(edgelist),'material edges',len(unnamed),'unnamed',len(refs),'refs',len(checks['checks']),'checks',status_counts,'cum',dict(allcount))
