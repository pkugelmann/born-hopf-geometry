#!/usr/bin/env python3
"""Construct Batch 4 source-as-printed audit ledger, issue certificate and report.
This is a staged review: full atlas/audit archive merges are explicitly deferred.
"""
from pathlib import Path
from collections import Counter, defaultdict
import hashlib,json,re
root=Path('/mnt/data/bh4c_work');stage=root/'staging';paperroot=root/'papers/Paper00-PapersMinimal-v2_371';tex=paperroot/'Paper4C-TechnicalMaterial-v1_42.tex'
source=tex.read_text();lines=source.splitlines();hashv=hashlib.sha256(tex.read_bytes()).hexdigest()
census=json.loads((stage/'Paper4C-CompleteSourceCensus-v1_1.json').read_text()); assert hashv==census['source_sha256']
prev=json.loads((stage/'Batches/Paper4C-AuditBatch3-v1_1.json').read_text());assert prev['source_sha256']==hashv and prev['source_coverage']['end']==5219
lo,hi=5220,6900;claims=[x for x in census['named_claims'] if lo<=x['source_locator']['line_start']<=hi];assert len(claims)==22
checks=json.loads((stage/'Evidence/Paper4C-Batch4IndependentChecks-v1_1.json').read_text());assert checks['total_controls']==checks['passed']==35
statuses={
'p4:thm:projector-overlap-mixing':'VERIFIED',
'p4:thm:gap-controlled-eigenframe-mismatch':'VERIFIED',
'p4:cor:near-identity-modulus-matrix':'VERIFIED',
'p4:thm:transport-stability-projector-overlaps':'VERIFIED',
'p4:prop:cubic-commutator-invariant':'VERIFIED',
'p4:prop:rank-three-jarlskog-identity':'VERIFIED',
'p4:thm:transported-frame-constant-unitary':'VERIFIED',
'p4:cor:transport-gauge-invariance':'VERIFIED',
'p4:thm:comparison-slice-quotient':'VERIFIED',
'p4:thm:positive-block-elimination':'VERIFIED',
'p4:thm:palindromic-bch':'VERIFIED',
'p4:prop:piecewise-affine-threshold-composition':'VERIFIED-CONDITIONAL',
'p4:rem:piecewise-affine-interpretation':'FORMALIZED',
'p4:thm:unstable-pair-resonance':'VERIFIED',
'p4:thm:worked-hamiltonian-coefficients-derived':'VERIFIED-CONDITIONAL',
'p4:prop:rabi':'VERIFIED-CONDITIONAL',
'p4:rem:rabi-framework':'FORMALIZED',
'p4:prop:larmor':'VERIFIED-CONDITIONAL',
'p4:cor:truncated-oscillator':'VERIFIED-CONDITIONAL',
'p4:rem:oscillator-framework':'FORMALIZED',
'p4:prop:tunnel-splitting':'VERIFIED-CONDITIONAL',
'p4:prop:conditional-hydrogenic-spectrum':'VERIFIED-CONDITIONAL',
}
assert set(statuses)=={x['id'] for x in claims}
conditions={
'p4:thm:projector-overlap-mixing':'Fixed rank-three corner Mat(3,C), two self-adjoint simple ordered spectra, rank-one projectors; choice of physical family-sector observable is not derived by the theorem.',
'p4:thm:gap-controlled-eigenframe-mismatch':'Rank-three Hermitian A,B; ordered eigenvalue labels; strict local gap exceeds ||B-A|| for off-diagonal bound.',
'p4:cor:near-identity-modulus-matrix':'Inherited strict gap condition and E=B-A; bound is an inequality, not an identification of physical mixing angles.',
'p4:thm:transport-stability-projector-overlaps':'C1 Hermitian paths with simple spectra on interval; all named gap denominators positive.',
'p4:prop:cubic-commutator-invariant':'A,B in fixed rank-three algebra A_f=Mat(3,C); dimension-three trace factor is not a dimension-free bound.',
'p4:prop:rank-three-jarlskog-identity':'Two rank-three Hermitian simple spectra with nonzero Vandermonde factors; normalized J meaningless at a collision.',
'p4:thm:transported-frame-constant-unitary':'Same C1 rank-three projection family and both frames satisfy full Kato horizontal transport ODE, not arbitrary moving frames.',
'p4:cor:transport-gauge-invariance':'Same projector and transported ODE, common fixed sector representatives, simple spectra for normalized J.',
'p4:thm:comparison-slice-quotient':'V\u2208U(3), permitted left/right diagonal phases and permutation label changes only.',
'p4:thm:positive-block-elimination':'Finite positive full H and strictly positive heavy D with uniform inversion gap; isolated light spectral projectors require their own gap.',
'p4:thm:palindromic-bch':'Bounded finite X,Y and sufficiently small |t| for the principal matrix log; no global principal log asserted.',
'p4:prop:piecewise-affine-threshold-composition':'Each open interval has gapped rank-three Kato frames and affine reduced observable; U_r must be unitary supplied by matching/open-gap theorem or a stated interface; no sector selector is invented.',
'p4:rem:piecewise-affine-interpretation':'Derived zero defect only for continuous matched open-gap families; jump across true gap closing is not fixed without input.',
'p4:thm:unstable-pair-resonance':'Specified finite effective complex 2x2 K with conjugate offdiagonal coupling; analytic expansion only for |2v/delta_C|<1; no universal pole-response maximum.',
'p4:thm:worked-hamiltonian-coefficients-derived':'Supplied H_geom, resolved projector P and real linearly independent Hermitian T_a; named model requires residual certificate; Schur formula only at mu outside Spec(H_HH).',
'p4:prop:rabi':'Supplied exact spin-half corner and circular monochromatic drive; model coefficients must be extracted from physical channel, not forced by Pauli algebra.',
'p4:rem:rabi-framework':'Microscopic m_p=1 can host supported rank-two model, but existence and drive are not selected by M2(C).',
'p4:prop:larmor':'Given spin representation and supplied magnetic coupling H_B=-gamma B·J with constant B; not automatic coefficient derivation.',
'p4:cor:truncated-oscillator':'Explicit finite ladder of IV-A, hbar_eff>0, kappa=M omega>0; finite-position textbook comparison requires extra isometry and norm error.',
'p4:rem:oscillator-framework':'Finite oscillator is a reciprocal-position-side effective comparison, not a new microscopic exact Heisenberg CCR.',
'p4:prop:tunnel-splitting':'Exact orthonormal rank-two symmetric double-well compression, epsilon level E0 and nonnegative rephased kappa; physical well is conditional.',
'p4:prop:conditional-hydrogenic-spectrum':'Specified Coulomb form q_C, nested finite trial subspaces form-norm dense; each fixed isolated shell below essential spectrum, no uniform rate or source-selected m_x(n).'
}
check_map=defaultdict(list)
for q in checks['controls']:
    check_map[q['claim']].append(q['id'])
ledger=[]
for i,c in enumerate(claims,1):
    loc=c['source_locator']
    rec={'id':f'BH-IVC-B4-CL-{i:03d}','source_label':c['id'],'kind':c['kind'],'source_location':loc,'source_as_printed_title':c.get('title',''),'source_as_printed':c['source_as_printed'],'statement_layer':'SOURCE-AS-PRINTED','status':statuses[c['id']],'status_scope':'as printed under typed domain; E3 checks are finite scoped samples, E1 source derivation replayed','domain_guard':conditions[c['id']],'evidence_ids':check_map.get(c['id'],[]),'issue_ids':[]}
    if c['id']=='p4:cor:truncated-oscillator':rec['imported_proof_use']=['p4:thm:finite-heisenberg-contraction (Paper4A, current source 5233-5294)']
    if c['id']=='p4:thm:positive-block-elimination':rec['imported_proof_use']=['p1b:thm:schur-jets (Paper1C current source 19810ff; optional direct quadratic witness)','p1b:thm:all-order-schur (alternate cited route)']
    ledger.append(rec)
assert Counter(x['status'] for x in ledger)==Counter({'VERIFIED':12,'VERIFIED-CONDITIONAL':7,'FORMALIZED':3})
steps=[
(5223,5287,'Rank-three pair and rank-one overlap, doubly-stochastic reconstruction',None),
(5291,5380,'Exact spectral identity, Weyl ordering and gap-controlled offdiagonal bound',None),
(5382,5412,'Near-identity modulus row sums and safe denominator',None),
(5417,5524,'C1 projector differentiability, reduced resolvent and trace norm integration',None),
(5528,5601,'Rank-three cubic commutator reality, norm and perturbative bound',None),
(5605,5710,'Cubic Jarlskog Vandermonde factorization, signs and noncollision normalization',None),
(5728,5783,'Kato transported frames, fixed U3 and conjugate reduced matrices',None),
(5785,5831,'Overlap/cubic transport invariance and left/right rephasing-permutation quotient',None),
(5838,5877,'PSD full Hamiltonian, Schur positivity, norm stability and isolated light projectors',None),
(5884,5920,'Finite principal-log oddness and exact nested commutator t^3 coefficients',None),
(5927,5942,'Explicit unitary threshold matching guard; mere overlap cannot substitute',None),
(5944,6039,'Cumulative pullback, exact jump and zero-defect open-gap boundary',None),
(6041,6050,'Physical threshold and coefficient selection remains downstream, not asserted',None),
(6058,6148,'Complex pair poles, resolvent and analytic crossover domain, z dependence',None),
(6155,6172,'Exact finite rank sectors versus large-position-side templates and residual requirements',None),
(6175,6227,'Gram normal equations and energy-dependent Feshbach identity',None),
(6234,6292,'Exact Pauli basis, prescribed circular Rabi drive and carrier domain',None),
(6300,6352,'Magnetic H finite normal form and SU2 Larmor orientation',None),
(6359,6387,'Reciprocal-position positive oscillator Hessian and exact commutator-defect operator identity',None),
(6389,6439,'Explicit truncated oscillator levels, top energy and finite comparison-Weyl norm domain',None),
(6447,6489,'Derived finite potential sector, localized two-well matrix and tunnel probability',None),
(6497,6534,'Conditional Coulomb form-domain Ritz min-max and fixed-n shell formula',None),
(6536,6564,'LS coupled-spin spectrum and Hilbert-Schmidt coefficient extraction',None),
(6582,6587,'Apparatus-relative coherence definition and path projectors',None),
(6594,6611,'Aperture postselection and exact four-term POVM probability expansion',None),
(6612,6614,'Interference/coherence interpretation; necessity of dephasing is false for a general detector effect','BH-G-000105'),
(6618,6655,'Balanced Mach-Zehnder amplitudes and projective relative phase',None),
(6662,6690,'Electromagnetic line-bundle closed-loop holonomy and gauge invariance',None),
(6694,6721,'Quantum eraser selective instrument and unchanged reduced path marginal',None),
(6725,6745,'Two-spin projector noncommutativity and conditional measurement channel',None),
(6749,6779,'Singlet correlations, CHSH 2sqrt2, and no-signalling marginal',None),
(6783,6800,'Accessible observer algebra, conditioning and operational complementarity',None),
(6803,6840,'Bell-basis teleportation, four equiprobable outcomes and classical feed-forward',None),
(6844,6873,'C1 eigenline Berry connection and gauge-equivalent loop holonomy',None),
(6877,6900,'Finite tunneling transfer and unitary invariance of von Neumann entropy',None),
]
step_ledger=[{'id':f'BH-IVC-B4-ST-{i:03d}','line_range':[a,b],'description':d,'statement_layer':'SOURCE-AS-PRINTED','E1_status':'REPLAYED' if not g else 'SCOPE_OVERSTATEMENT_CONFIRMED',**({'issue_ids':[g]} if g else {})} for i,(a,b,d,g) in enumerate(steps,1)]
# Current source corpus, not historical source-anchor maps; source labels are E0 locators, not E3.
alllabels=defaultdict(list)
for f in paperroot.glob('*.tex'):
    text=f.read_text()
    for m in re.finditer(r'\\label\{([^{}]+)\}',text):alllabels[m.group(1)].append({'file':f.name,'line':text[:m.start()].count('\n')+1})
segment='\n'.join(lines[lo-1:hi]); refs=re.findall(r'\\(?:ref|eqref|autoref|pageref)\{([^{}]+)\}',segment)
resolved={s:alllabels.get(s,[]) for s in sorted(set(refs))}
ambiguous={s:ls for s,ls in resolved.items() if len(ls)!=1}
assert not ambiguous, (len(ambiguous),list(ambiguous.items())[:15]);print('REFERENCES',len(refs),'UNIQUE',len(resolved),'all resolved exactly once')
# Material edges, all source-use line locators manually replayed; no other citations promoted.
edgedata=[
('p4:thm:gap-controlled-eigenframe-mismatch','p4:cor:near-identity-modulus-matrix','REQUIRES',5403,'Offdiagonal pointwise eigenframe bound; AND'),
('p4:thm:projector-overlap-mixing','p4:cor:near-identity-modulus-matrix','REQUIRES',5411,'Doubly stochastic row-sum identity; AND'),
('p4:prop:cubic-commutator-invariant','p4:prop:rank-three-jarlskog-identity','REQUIRES',5640,'Simultaneous-unitary invariance and 3x3 cubic bound; AND'),
('p4:prop:rank-three-jarlskog-identity','p4:cor:transport-gauge-invariance','REQUIRES',5796,'Cubic normalized invariant as prior proposition; AND'),
('p4:thm:transported-frame-constant-unitary','p4:cor:transport-gauge-invariance','REQUIRES',5796,'Constant-unitary reduced matrix relation; AND'),
('p4:thm:projector-overlap-mixing','p4:cor:transport-gauge-invariance','REQUIRES',5795,'Intrinsic modulus construction; AND'),
('p4:thm:positive-block-elimination','p4:prop:piecewise-affine-threshold-composition','REQUIRES',6037,'Isolated Schur corner continuity on gap-open branch only; local alternative for zero-defect conclusion'),
('p1b:thm:schur-jets','p4:thm:positive-block-elimination','IMPORTED_PROOF',5867,'Direct source import alternative to all-order Schur and the explicit quadratic evaluation'),
('p1b:thm:all-order-schur','p4:thm:positive-block-elimination','IMPORTED_PROOF',5869,'Explicit source alternative to stationary Schur jets'),
('p4:thm:finite-heisenberg-contraction','p4:cor:truncated-oscillator','IMPORTED_PROOF',6391,'Exact truncated ladder and position-momentum definitions from IV-A'),
('p4:prop:piecewise-affine-threshold-composition','p4:rem:piecewise-affine-interpretation','INTERPRETATION_OF',6043,'Downstream interpretation only; not a theorem proof edge')]
edges=[]
for i,(up,down,rel,line,desc) in enumerate(edgedata,1):
    witness='\n'.join(lines[max(0,line-7):min(len(lines),line+7)])
    supporting_eq={'p4:thm:transported-frame-constant-unitary':'p4:eq:transported-reduced-constant-conjugation','p4:thm:projector-overlap-mixing':'p4:sec:part2-threelevel-mixing'}
    has_source_witness=(f'\\ref{{{up}}}' in witness) or (up in supporting_eq and f'\\ref{{{supporting_eq[up]}}}' in witness) or (up in supporting_eq and f'\\eqref{{{supporting_eq[up]}}}' in witness)
    assert has_source_witness or rel=='INTERPRETATION_OF' or up in ('p1b:thm:schur-jets','p1b:thm:all-order-schur'), (up,down,line)
    edges.append({'id':f'BH-IVC-B4-EDGE-{i:03d}','from':up,'to':down,'relation':rel,'proof_route':f'BH-IVC-B4-ROUTE-{down}','logic_group':'AND' if rel=='REQUIRES' else ('OR_IMPORT' if rel=='IMPORTED_PROOF' else 'NOT_MATERIAL'),'source_use_locator':f'{tex.name}:{line}','domain_guard':desc,'review_status':'SOURCE_MATCHED_MATERIAL' if rel not in ('INTERPRETATION_OF',) else 'NAVIGATION_ONLY','verified_material_edge':rel in ('REQUIRES','IMPORTED_PROOF'),'candidate_not_automatic':False})
# The source itself explicitly excludes equating P1B rank-three moment reconstruction with a required proof of overlap trace identity.
nonpromoting=[{'from':'p1b:thm:rank-three','to':'p4:thm:projector-overlap-mixing','kind':'CITATION_ONLY','source_locator':f'{tex.name}:5283-5286','reason':'IV-C proof is direct rank-one projector trace; I-B context is consistent, not indispensable.'},
{'from':'p4:thm:approximate-microcausality','to':'p4:eq:part2-double-slit','kind':'NOT_A_MATERIAL_EDGE','reason':'Quantum two-path POVM algebra does not consume bosonic truncated microcausality proof.'}]
issue={
'issue_id':'BH-G-000105','class':'INCORRECT_STEP','secondary_class':'TYPE_OR_DOMAIN','severity':'minor','lifecycle':'OPEN','issue_status':'confirmed_in_domain_counterexample_to_necessity_wording',
'first_origin':{'paper':'Paper4C','theorem_id':'p4:sec:part2-double-slit','step_locator':f'{tex.name}:6613','source_excerpt':'They disappear exactly when a dephasing channel removes the off-diagonal path blocks.'},
'statement_layer':'SOURCE-AS-PRINTED',
'exact_obligation':'The written only-if reading: if the last two double-slit probability terms vanish for a supplied detector effect E_x, a dephasing channel must have erased path coherences.',
'source_replayed':True,'independent_evidence':['BH-IVC-B4-E3-027'],'adversarial_evidence':['BH-IVC-B4-E4-028'],'constitution_boundary':None,
'conditions_consumed':['Supplied mutually orthogonal P0,P1, state rho and detector POVM effect 0<=E<=I; no extra informational-completeness of detector stipulated'],
'conditions_open':[],
'upstream_material_paths':[['P0,P1 path projector / state rho / supplied detector effect (Paper4C:6594)','p4:eq:part2-double-slit (Paper4C:6603-6611)','p4:sec:part2-double-slit (Paper4C:6613 necessity wording)']],
'downstream_verified_paths':[],
'other_papers_affected':[],'possible_unconfirmed_impacts':['Any future use of vanishing detector interference as an if-and-only-if coherence/dephasing diagnostic; no specific remote material dependency yet certified'],
'verified_bypass_routes':['Correct complete-dephasing => absent POVM cross term (E3-027); exact Born probability formula (6605-6611) survives'],
'why_it_matters':'Absence of a cross term under one allowed detector POVM does not determine whether the input retained path coherence; dephasing is sufficient but not necessary. The numerical double-slit probability identity is intact.',
'resolution_requirement':'Treat the sentence as one-way sufficiency, or prove and state extra detector-family informational-completeness/identifiability hypotheses for a necessity inference; source text is not edited by this audit.',
'audit_scope_limit':'Counterexample refutes the literal necessity claim for arbitrary supplied E_x; does not challenge the recombining detector branch when calibrated to be coherence-sensitive, nor does it challenge the algebraic probability identity.',
'counterexample_certificate':{'state':'rho=|psi><psi|, |psi>=(|0>+exp(0.4i)|1>)/sqrt(2) so |rho_01|=1/2','path_projectors':'P0=|0><0|, P1=|1><1|','detector_effect':'E_x=diag(0.7,0.3), valid 0<=E<=I','channel':'none; state remains coherent','exact_result':'Tr(rho P0 E P1)+Tr(rho P1 E P0)=0 since P0 E P1=P1 E P0=0; moreover E=|+><+| has nonzero offdiagonal detection while state (|0>+i|1>)/sqrt2 has cross terms +i/4 and -i/4 that cancel at this pixel','implication':'Vanishing cross term does not require dephasing; no source theorem used absence of cross term to certify dephasing'},
}
# Local condition ledger; do not insert duplicates as new global assumptions before final ancestry reconciliation.
condreview=[
{'name':'rank-three corner Mat(3,C)','first_known_occurrence':f'{tex.name}:4879-4883 (Batch3)','status':'INHERITED_FROM_PREVIOUS_BATCH','consumers':['p4:thm:projector-overlap-mixing','p4:prop:cubic-commutator-invariant'],'canonical_integration':'REUSE_EXISTING_SECTOR_CONDITION'},
{'name':'simple ordered spectra / nonzero eigenvalue gaps','first_known_occurrence':f'{tex.name}:5223-5235','status':'EXPLICIT_LOCAL_DOMAIN','consumers':['p4:thm:gap-controlled-eigenframe-mismatch','p4:thm:transport-stability-projector-overlaps','p4:prop:rank-three-jarlskog-identity'],'canonical_integration':'LINK_TO_FIRST_ESTABLISHED_GLOBAL_GAP_CONDITION_NOT_DUPLICATE'},
{'name':'same-rank unitary threshold matching U_r','first_known_occurrence':f'{tex.name}:5937-5942','status':'EXPLICIT_SOURCE_INTERFACE','consumers':['p4:prop:piecewise-affine-threshold-composition'],'canonical_integration':'SCOPE_GUARD_THROUGH_SINGLE_INTERFACE_NODE_NOT_PHYSICAL_SELECTOR'},
{'name':'supplied finite H_geom, rank P and named model scalar family','first_known_occurrence':f'{tex.name}:6155-6185','status':'EXPLICIT_SOURCE_INTERFACE','consumers':['p4:thm:worked-hamiltonian-coefficients-derived','p4:prop:rabi','p4:prop:larmor','p4:prop:tunnel-splitting'],'canonical_integration':'MODEL_INPUT_GUARD_NOT_FOUNDATIONAL_AXIOM'},
{'name':'Coulomb nested form-norm dense trial spaces','first_known_occurrence':f'{tex.name}:6511-6514','status':'EXPLICIT_CONDITIONAL_INTERFACE','consumers':['p4:prop:conditional-hydrogenic-spectrum'],'canonical_integration':'SCOPE_GUARD_ONLY_NO_CLAIM_THAT_GP_SELECTS_NESTING'},
{'name':'detector POVM identifies coherence (only-if claim)','first_known_occurrence':f'{tex.name}:6613','status':'UNSTATED_INFERRED_CONDITION_IF_ONLY_IF_INTENDED','consumers':['p4:sec:part2-double-slit'],'canonical_integration':'NOT_NEW_AXIOM; ISSUE BH-G-000105, NO_PROMOTION_WITHOUT_SOURCE_CERTIFICATE'}
]
# Boundary/counterexample review passes, preserves no invented GP1/2/3 selector.
review={
'five_gate_domain':'rank-three quantum sector and apparatus channel; no conventional-physics mechanism mandatory',
'constitutional_boundary':'The mathematical Mat3 corner is not a physical family-selector; the source explicitly defers it and uses GP2 matching guards for threshold unitaries. No ambient operation is promoted to physical constitutor.',
'negative_challenges':['Unmatched rank-three planes have nonunitary overlap, explicitly excluded in source at 5937-5942.','No sector gives universal Rabi/Coulomb coefficients without supplied H_geom; source explicitly calls these conditional.','Unspecified probe z gives no resonance maximum, explicitly excluded in source 6110-6114.','The Coulomb bound is for fixed isolated shells with form-dense trial spaces only.'],
'active_issue':issue['issue_id'],'completed_scope_limit':'This batch does not re-audit Paper1C, Paper4A, earlier IV-C gaps or the beyond-6900 thermodynamics/bath sections.'}
prevcounts=prev['cumulative_status_counts'];count=Counter(statuses.values()); cumulative={k:prevcounts.get(k,0)+count.get(k,0) for k in sorted(set(prevcounts)|set(count))};assert sum(cumulative.values())==116
cureqs=[x for x in census['display_equations'] if lo<=x['line_start']<=hi];assert len(cureqs)==69
batch={
'audit':'Paper4C','batch':4,'revision':'v1_1','protocol':'Paper00-RigorousVerificationDAGWorkProtocol-v2_4','source_authority':'Paper00-PapersMinimal-v2_371','source_file':tex.name,'source_sha256':hashv,
'latest_supplied_dag_input':'Paper00-DAGAtlas-v1_108(1).zip','latest_supplied_audit_input':'Paper00-ProofChainAudits-v1_25(1).zip',
'source_coverage':{'start':lo,'end':hi,'total_lines':len(lines),'named_checked':len(claims),'named_total':census['named_count'],'cumulative_named_checked':116,'cumulative_named_remaining':census['named_count']-116,'formal_results_in_batch':sum(x['kind']!='remark' for x in claims),'display_environments_reviewed':len(cureqs),'display_environments_total':census['display_count'],'material_unnamed_steps':len(steps),'material_steps_ledger':step_ledger,'out_of_scope':'Paper IV-C 6901-10934; independent full audit of imported manuscripts, source paper modifications'},
'status_counts':dict(count),'previous_cumulative_named':94,'cumulative_status_counts':cumulative,'named_claim_ledger':ledger,
'source_reference_audit':{'reference_occurrences':len(refs),'unique_reference_labels':len(resolved),'resolved_exactly_once':len(resolved),'unresolved':[],'ambiguous':[],'navigation_only_not_proof_edges':True,'reference_label_index':resolved},
'source_proof_use_edges':edges,'nonpromoting_edges':nonpromoting,
'proof_route_review':['Projector-overlap vs spectral-gap vs cubic pair invariants have separate proofs; no rank-three sector choice inferred.','Imported Paper1C Schur-jet/all-order references are alternative scope-matched sources, and the IV-C quadratic positivity argument is direct.','The continuous matched open-gap branch proves zero jump while a discontinuous/closing-gap branch retains explicitly supplied Delta; never conflate the two.','Rabi, Larmor, oscillator, tunneling and Coulomb are exact models only under their printed finite/apparatus/position-side conditions.','The Bell/teleportation and AB/Berry formulas are conditional on accessible algebra, charge-representation bundle, eigenline loop and supplied apparatus; no global Hopf = electromagnetism inference.','The double-slit mathematical probability expansion survives; only the unqualified necessity reading of dephasing is false.'],
'independent_checks_file':'Paper4C-Batch4IndependentChecks-v1_1.json','independent_check_count':checks['total_controls'],'independent_check_passed':checks['passed'],'independent_E3_count':checks['independent_E3_count'],'adversarial_E4_count':checks['adversarial_E4_count'],
'found_issues':[issue],'carried_forward_issues_unchanged':[{'id':'BH-G-000102','status':'UNRESOLVED','origin':'IV-C 3069-3072,3145-3154','source_batch':2},{'id':'BH-G-000103','status':'UNRESOLVED','origin':'IV-C 3465-3489','source_batch':3},{'id':'BH-G-000104','status':'AUXILIARY_STEP_REFUTED','origin':'IV-C 4191','source_batch':3}],
'canonical_condition_review':condreview,'boundary_review':review,
'open_verification_gates':[{'target':'p4:prop:conditional-hydrogenic-spectrum','gate':'Separate interface must supply actual form-dense trial spaces if the claim is to be physically instantiated; the conditional Ritz theorem itself is correct.'},{'target':'p4:prop:piecewise-affine-threshold-composition','gate':'Threshold matching unitary and affine coefficients require their declared source/constructor; arbitrary 3-plane overlap alone is not U(3).'},{'target':'p4:sec:part2-double-slit','gate':'Source interpretation of zero cross term as dephasing needs sufficient detector-family identifiability, absent for general POVM.'}],
'adversarial_challenges':[x for x in checks['controls'] if x['type']=='E4'],
'agent_mode':'single-run source E1 + independent finite-matrix/symbolic E3 + in-domain E4; no claim of multiple external agents','batch_closure':'BATCH_4_COMPLETE_SOURCES_UNMODIFIED_ONE_MINOR_UNNAMED_ISSUE',
'overall_full_audit_ready':False,'successor_archive_policy':'defer final integrated DAG and separate proof-chain ZIP outputs until after lines 6901–10934 are audited',
'no_source_modification':True}
bp=stage/'Batches/Paper4C-AuditBatch4-v1_1.json';bp.write_text(json.dumps(batch,indent=2,ensure_ascii=False)+'\n')
# Report for human audit; issue fully described here and in JSON.
rows='\n'.join(f'| {c["source_location"]["line_start"]} | `{c["source_label"]}` | {c["status"]} | {", ".join(q.split("-")[-1] for q in c["evidence_ids"]) or "—"} |' for c in ledger)
md=f'''# Paper IV-C — Rigorous Verification DAG audit, Batch 4 (v1_1)

**Controlling source:** `{tex.name}` from `Paper00-PapersMinimal-v2_371`; SHA-256 `{hashv}`. **Protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4`.

**Coverage:** lines **{lo}–{hi}** ({hi-lo+1:,} lines), **22/22 named claims/remarks**, **{len(steps)} material unnamed steps**, **69/69 displayed equation environments** in this bounded span by source replay E1. This does **not** mean every equation has independent E3 proof. **Cumulative:** **116/186 named** examined; **70 remaining**. The latest previous ledger (Batch 3) is retained without reclassification.

**Status breakdown:** VERIFIED 12, VERIFIED-CONDITIONAL 7, FORMALIZED 3; named UNRESOLVED 0. **Independent tests:** **35/35 PASS** (31 scoped E3 and 4 E4). E4 success sometimes means confirmation of a counterexample, not a passed original theorem.

## Named source claim ledger

| Source line | Source label | Status | Independent control numbers |
|---:|---|---|---|
{rows}

## New issue: BH-G-000105 — Interference disappearance does not require dephasing

- **Class/severity:** `INCORRECT_STEP` / `TYPE_OR_DOMAIN`, **minor**, **OPEN**, source-as-printed. **Earliest origin:** `{tex.name}:6613`, unnamed double-slit interpretation in `p4:sec:part2-double-slit`.
- **Exact source assertion:** “They disappear exactly when a dephasing channel removes the off-diagonal path blocks.” The sufficient direction (full path dephasing removes the off-diagonal terms) is correct; the converse is not valid for arbitrary allowed detector effects.
- **Exact in-domain witness (`BH-IVC-B4-E4-028`):** take `P_0=|0><0|`, `P_1=|1><1|`, coherent `|psi>=(|0>+e^{{0.4i}}|1>)/sqrt(2)` and no dephasing. For the legitimate POVM effect `E_x=diag(0.7,0.3)`, one has `P_0 E_x P_1=P_1 E_x P_0=0`. Therefore both interference terms in the displayed probability vanish even though `|rho_01|=1/2>0`. A second witness uses the recombining effect `E_x=|+><+|` and coherent input `(|0>+i|1>)/sqrt(2)`; the two nonzero complex cross terms cancel at that pixel. Hence zero detector interference alone is not equivalent to an erased coherent path state. Separate `E3-027` confirms complete dephasing is sufficient.
- **Impact:** the double-slit **four-term Born formula at lines 6603–6611 remains correct**. This is an overstatement in the prose diagnostic, not a failure of the quantum-probability calculus. No named target theorem or cross-paper result has an evidenced material path consuming the false only-if statement. Future coherence-inference claims are **POSSIBLY_AFFECTED**, not proven impacted.
- **Precise remaining obligation:** for a necessary-and-sufficient diagnosis, justify the relevant detector family’s ability to detect off-diagonal coherence; otherwise the text should assert only the sufficient dephasing direction. No source revision was made.

## Independent mathematical and physical checks

1. **Mixing geometry (5251–5710):** reconstructed `M_ij=Tr(P_i Q_j)=|V_ij|²`, exact eigenframe identity, ordered Weyl-gap bounds, C¹ derivative control, rank-three cubic anti-Hermitian trace bound, the signed Vandermonde–Jarlskog identity, and quotient rephasing/permutation sign. The rank-three algebra `A_f=Mat(3,C)` is explicitly defined upstream at source 4879–4883; no dimension-three trace factor was applied to an arbitrary higher-dimensional algebra.
2. **Transport and threshold (5728–6050):** same-P Kato frames differ by a constant U(3); norm-positive Schur block reduction and isolated-projector continuity; palindromic principal-log cubic coefficients; exact cumulative threshold jump `U^* Delta U`. Crucially, **unitary boundary identification is required**, and when the open-gap projector/observable is continuous the jump vanishes. A raw overlap of different rank-three subspaces need not be unitary (E4-015). No physical threshold selector is supplied by these identities.
3. **Resonance and finite models (6058–6564):** complex two-level poles/resolvent, binomial small-coupling domain, unique Hilbert–Schmidt model projection, energy-dependent Feshbach factorization, circular Rabi probabilities, Zeeman/Larmor sign, finite oscillator ladder/top-state deviation and commutator correction, symmetric two-well tunneling, Coulomb n=1,2 radial energies, and spin–orbit l=1,s=½ eigenvalue multiplicities. **Coulomb Ritz convergence remains expressly conditional** on an actual form-norm dense nested family; checking the energies of two target modes is not a proof that the framework supplies such a family.
4. **Finite interferometric applications (6568–6900):** the two-path Born expansion, balanced Mach–Zehnder outputs, AB holonomy under single-valued gauge changes, quantum-eraser conditional states, Stern–Gerlach noncommutativity, singlet CHSH `−2√2`, teleportation Bell expansion, and Berry holonomy under integer winding gauge changes all passed scoped controls. Electromagnetic connection vs Hopf character remains a separate supplied bundle interface, not a forced identification.

## Imported and conditional interfaces

- **Paper I-C (current file carries Paper I-B labels):** `p1b:thm:rank-three` at line 19984 is consistent with the projector overlap algebra but not a needed proof premise. `p1b:thm:schur-jets` at 19810 and `p1b:thm:all-order-schur` at 21377 are alternative Schur uses; the IV-C quadratic-form positivity calculation is direct. Neither remote paper was newly audited in full.
- **Paper IV-A:** `p4:thm:finite-heisenberg-contraction` at source line 5233 provides the exact ladder and top-boundary defect used by the IV-C oscillator corollary. A low-sublevel CCR matrix element does not become an exact full finite CCR representation.
- The stipulated rank-three sector, gapped families, threshold unitaries, finite apparatus Hamiltonians, Coulomb form-domain approximations, effective reciprocal-position model and detector/line-bundle interfaces remain typed **conditions**, not new constitutional axioms or automatic selections.
- All **{len(refs)}** explicit `\\ref`/`\\eqref` occurrences to **{len(resolved)}** distinct labels in this source span resolve **exactly once** within the current corpus. This is E0 navigation only; **{len(edges)}** individually source-reviewed edges and two nonpromoting decisions are recorded in the ledger.

## Persistent earlier issues and next batch

`BH-G-000102` (bosonic polynomial word boundary), `BH-G-000103` (scalar Bogoliubov regularity) and `BH-G-000104` (auxiliary nonautonomous recurrence overstatement) carry forward unchanged. **New distinct root:** `BH-G-000105` at line 6613. No earlier issue has been closed or propagated to an unrelated route.

**Overall:** `PARTIALLY_AUDITED` **116/186** named objects, **70 remaining**. **Next source line: 6901**, beginning entropy monotonicity, finite Landauer balance, microscopic bath, control and code calculations. The global updated DAG and the requested audit ZIP are reserved for the final batch and must retain **only the latest version of each relevant file**. The paper and supplied archives remain immutable.

**Evidence:** `Paper4C-Batch4IndependentChecks-v1_1.py/.json`; **ledger** `Paper4C-AuditBatch4-v1_1.json`.\n'''
report=stage/'Batches/Paper4C-AuditBatch4-v1_1.md';report.write_text(md)
# Batch-level independent static validation certificate.
val={'batch':4,'source_sha256':hashv,'source_file':tex.name,'source_bytes_intact':True,'previous_batch_contiguous':prev['source_coverage']['end']+1==lo,'source_coverage_contiguous':True,'named_expected':len(claims),'named_ledger':len(ledger),'named_ids_unique':len({r['source_label'] for r in ledger})==len(ledger),'statuses_sum':sum(count.values()),'cumulative_named':116,'source_named_total':186,'material_step_ledger':len(steps),'display_equations_in_batch':len(cureqs),'controls':checks['total_controls'],'control_passed':checks['passed'],'reference_unique':len(resolved),'reference_unresolved':0,'named_issues_new':[issue['issue_id']],'earlier_issues_carried': [x['id'] for x in batch['carried_forward_issues_unchanged']],'verified_links_count':sum(x['verified_material_edge'] for x in edges),'citation_promotion_prevented':True,'paper_and_archives_unmodified':True,'separate_ZIPs_deferred':True,'files_created':[str(bp),str(report)],'full_audit':False}
validation=stage/'Evidence/Paper4C-Batch4Validation-v1_1.json';validation.write_text(json.dumps(val,indent=2)+'\n')
for p in (bp,report,validation):print('WRITTEN',p, 'bytes',p.stat().st_size,'sha256',hashlib.sha256(p.read_bytes()).hexdigest())
