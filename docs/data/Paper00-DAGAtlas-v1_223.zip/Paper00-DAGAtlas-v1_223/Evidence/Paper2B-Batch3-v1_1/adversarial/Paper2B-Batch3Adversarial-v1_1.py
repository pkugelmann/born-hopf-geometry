"""Exact E4 controls for II-B v2.135 lines2245--2880; standard library.
Finite checks supplement the general exact-domain arguments in paired JSON.
"""
from fractions import Fraction as F
from pathlib import Path
from itertools import product
from math import comb
from collections import Counter
import json
O=Path(__file__).parent;checks=[]
def chk(n,p):
 assert p,n
 checks.append(n)
def Z(n):return [[F(0) for _ in range(n)] for _ in range(n)]
def I(n):
 a=Z(n)
 for i in range(n):a[i][i]=F(1)
 return a
def add(a,b):return [[x+y for x,y in zip(r,s)] for r,s in zip(a,b)]
def neg(a):return [[-x for x in r] for r in a]
def sub(a,b):return add(a,neg(b))
def mul(a,b):return [[sum(x*y for x,y in zip(r,c)) for c in zip(*b)] for r in a]
def T(a):return [list(r) for r in zip(*a)]
def prodm(arr):
 out=I(len(arr[0]))
 for a in arr:out=mul(out,a)
 return out
N=4;P=Z(N);P[0][0]=P[1][1]=1;Q=sub(I(N),P)
for n in range(2,8):
 As=[[[F(((i+1)*(j+3)+2*t+i-j)%9-4,3) for j in range(N)] for i in range(N)] for t in range(n)]
 W=prodm([P]+As+[P]);WP=prodm([mul(mul(P,A),P) for A in As]);terms=Z(N)
 for j in range(n-1):
  prefix=[mul(mul(P,A),P) for A in As[:j]]
  term=prodm(prefix+[P,As[j],Q]+As[j+1:]+[P]);terms=add(terms,term)
 chk(f'ordered_first_omission_defect_n{n}',sub(W,WP)==terms)
 # Non-Hermitian square and mixed defects on compression P firsttwo coords.
 a,b=As[:2]
 compress=lambda c:[r[:2] for r in c[:2]]
 qa=[r[:2] for r in mul(Q,a)]
 da=sub(compress(mul(T(a),a)),mul(T(compress(a)),compress(a)))
 chk(f'square_defect_Gram_nonHermitian_n{n}',da==mul(T(qa),qa))
 mixed=sub(compress(mul(a,b)),mul(compress(a),compress(b)))
 qa_star=[r[:2] for r in mul(Q,T(a))];qb=[r[:2] for r in mul(Q,b)]
 chk(f'mixed_defect_adjoint_order_n{n}',mixed==mul(T(qa_star),qb))
# Saturating n2 case; mutation dropping the dagger fails.
a=[[F(0),F(1)],[F(0),F(0)]];b=T(a)
chk('mixed_bound_saturation',mul(a,b)[0][0]==1 and a[0][0]*b[0][0]==0)
chk('mixed_bound_requires_A_adjoint',a[1][0]==0 and T(a)[1][0]==1 and b[1][0]==1)
# m=0 source-as-printed boundary control: P0=C, Q0(c)=c is multiplicative.
# This does not refute the stated linear section; no product-preservation
# property is imposed in that theorem. A universal nonmultiplicativity claim
# at every level would be false, and is kept separate from the actual bridge.
def q0(c): return [[F(c)]]
for a,b in product([F(0),F(1),F(-2),F(2,3)],repeat=2):
 chk(f'm0_scalar_section_multiplicative_control_{a}_{b}',q0(a*b)==mul(q0(a),q0(b)))
# Scalar compression at m1, Haar probability, orthonormal basis1,2x1,..2x4.
q_x=Z(5);q_x[0][1]=q_x[1][0]=F(1,2)
chk('scalar_symbol_section_x1',[r[0] for r in q_x]==[F(0),F(1,2),F(0),F(0),F(0)])
q_x2=Z(5)
for i,c in enumerate([F(1,4),F(1,2),F(1,6),F(1,6),F(1,6)]):q_x2[i][i]=c
chk('scalar_extended_compression_nonmultiplicative',q_x2!=mul(q_x,q_x))
chk('scalar_square_defect_positive_diagonal',all(sub(q_x2,mul(q_x,q_x))[i][i]>=0 for i in range(5)))
chk('Haar_positive_unital_map_nonmultiplicative',F(1,4)!=F(0)**2)
for m in range(12):
 dp=(m+1)*(m+2)*(2*m+3)//6;dh=comb(2*m+4,4)
 chk(f'scalar_full_dimension_ratio_m{m}',F(dp,dh)==F(1,2*m+1))
for r in range(13):chk(f'full_scalar_product_capacity_r{r}',sum((k+1)**2 for k in range(r+1))==(r+1)*(r+2)*(2*r+3)//6)
chk('quadratic_capacity_is9_notH2_70',10-1==9 and comb(8,4)==70)
# Enumerate complex C* defining block dimensions with representationbudget15.
solutions=[]
def partitions(n,lo=1,prefix=()):
 yield prefix
 for a in range(lo,n+1):yield from partitions(n-a,a,prefix+(a,))
seen=set()
for part in partitions(15):
 if part in seen:continue
 seen.add(part)
 if sum(n*n for n in part)==137:solutions.append(part)
chk('reverse15_137_unique_blocks',solutions==[(4,11)])
chk('reverse15_137_multiplicities_exhaust_budget',4+11==15)
# Atlas forward equations and exact inverse-square relations including zeroedges.
for R in [F(1),F(2),F(3,2)]:
 for rl,rr,rs in product([F(0),F(1,3),F(2)],repeat=3):
  q0=R*R;ql=2*rl*rl;qr=2*rr*rr;qs=4*rs*rs;qv=q0/4+F(3,2)*(rl*rl+rr*rr)
  chk(f'fingerprint_inverse_{R}_{rl}_{rr}_{rs}',q0>0 and ql/2==rl*rl and qr/2==rr*rr and qs/4==rs*rs)
  chk(f'fingerprint_relation_{R}_{rl}_{rr}_{rs}',qv==q0/4+F(3,4)*(ql+qr))
chk('q0zero_mutation_outside_Rpositive_domain',not F(0)>0)
qvals=[F(1),F(11,12),F(4,9),F(3,4)]
for i,q in enumerate(qvals):
 ps=F(864,11)*(q-1)*(q-F(11,12))*(q-F(4,9))
 chk(f'central_projector_Lagrange_at_{q}',ps==(1 if i==3 else 0))
chk('central_projector_denominator', (F(3,4)-1)*(F(3,4)-F(11,12))*(F(3,4)-F(4,9))==F(11,864))
# Exact doubled-spin Clebsch--Gordan and diagonal restriction.
def cg(a,b):return range(abs(a-b),a+b+1,2)
def tensor(A,B):
 C=Counter()
 for (a,b),m in A.items():
  for (c,d),n in B.items():
   for e in cg(a,c):
    for f in cg(b,d):C[e,f]+=m*n
 return C
Hg=Counter({(0,0):1,(1,1):1,(2,0):1,(0,2):1});Hs=Counter({(1,0):1,(0,1):1})
H=tensor(Hg,Hs)
expected=Counter({(1,0):3,(0,1):3,(2,1):2,(1,2):2,(3,0):1,(0,3):1})
chk('odd_bridge_Clebsch_Gordan',H==expected)
chk('odd_bridge_dimension44',sum((a+1)*(b+1)*m for (a,b),m in H.items())==44)
chk('odd_bridge_no_trivial_or_vector',(0,0) not in H and (1,1) not in H)
chk('odd_bridge_all_central_odd',all((a+b)%2 for a,b in H))
def restrict(A):
 C=Counter()
 for (a,b),m in A.items():
  for j in cg(a,b):C[j]+=m
 return C
chk('Hg_diag_restriction',restrict(Hg)==Counter({0:2,2:3}))
chk('Hs_diag_restriction',restrict(Hs)==Counter({1:2}))
chk('odd_diag_restriction',restrict(H)==Counter({1:10,3:6}))
# Central-even input condition: equivariance implies output = negativeoutput.
chk('nonlinear_equivariance_sign_obstruction',F(2)!=0)
# Chiral vs central grading on a minimal2d internal source.
Dw=[[F(0),F(1)],[F(1),F(0)]];G=[[-F(1),F(0)],[F(0),F(1)]];minusI=neg(I(2))
chk('internal_chiral_odd',mul(mul(G,Dw),G)==neg(Dw))
chk('internal_central_even',mul(mul(minusI,Dw),minusI)==Dw)
# Two-copy paired exchange as exact basis permutations (15² basisvectors).
def crossed(i,j):return (i<11)!=(j<11)
def K(i,j):return (j,i) if crossed(i,j) else None
images=[]
for i,j in product(range(15),repeat=2):
 out=K(i,j)
 chk(f'K2_cross_projector_{i}_{j}',(K(*out) if out else None)==((i,j) if crossed(i,j) else None))
 if out:images.append(out)
 parity=(-1 if i>=11 else 1)*(-1 if j>=11 else 1)
 chk(f'K_total_even_{i}_{j}',out is None or parity==(-1 if out[0]>=11 else 1)*(-1 if out[1]>=11 else 1))
chk('paired_exchange_rank88',len(set(images))==88)
chk('paired_exchange_not_first_population_commuting',K(0,11)==(11,0) and (0<11)!=(11<11))
# Equal block-preservingpermutation onboth carriers commuteswithflip+Qcross.
p=list(range(15));p[0],p[1]=p[1],p[0];p[11],p[12]=p[12],p[11]
for i,j in product(range(15),repeat=2):
 out=K(i,j);lhs=(p[out[0]],p[out[1]]) if out else None;rhs=K(p[i],p[j])
 chk(f'paired_diagonal_covariance_{i}_{j}',lhs==rhs)
# W5 obstruction trace factors from current exact I-A import.
chk('W5_pseudoscalar_orthogonality_control',729*6*(-F(34,81))+544*4*F(27,32)==0)
chk('W6_pseudoscalar_resolved_control',729*6*F(4,9)*(-F(34,81))+544*4*F(3,4)*F(27,32)==561)
result={'scope':'Paper2B v2.135 lines2245--2880','assertion_count':len(checks),'all_passed':True,'checks':checks,'limits':'Exact finite controls and witnesses do not certify occurrence, a universal GP3 comparison, semiclassical convergence, or an independently full audit of imported peer papers.'}
(O/'Paper2B-Batch3AdversarialResults-v1_1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'}))
