#!/usr/bin/env python3
"""E1 replay of current Paper I-A coordinate-word certificate imported by Paper II-B.
Adapted from the supplied historical Batch27 exact-matrix checker after matching
the construction to Paper1A-Geometry-v5_163.tex:20140-20306. This is E1, not
an independent E3 certificate. No physical operation occurrence is inferred.
"""
import json, itertools
from pathlib import Path
import numpy as np
P=97
I97=22
checks=[]

def mark(name,yes,detail=None):
    if not bool(yes):
        raise AssertionError(name+(': '+str(detail) if detail is not None else ''))
    checks.append(name)

def matmul(a,b):return (a@b)%P

def scal(a,n):return (a*(n%P))%P

def inv(x): return pow(int(x)%P,-1,P)

def rank_basis_insert(m, pivots, basis_vectors):
    v=np.array(m,dtype=np.int64).reshape(-1)%P
    for c in sorted(pivots):
        u=pivots[c]
        if v[c]: v=(v-v[c]*u)%P
    nz=np.flatnonzero(v)
    if not len(nz):return False
    k=int(nz[0]);v=scal(v,inv(v[k]))
    pivots[k]=v;basis_vectors.append(m.copy())
    return True

def closure(generators, mode, max_rounds=200):
    pivots={};basis=[];new=[]
    if mode=='algebra':
        ident=np.eye(15,dtype=np.int64)
        rank_basis_insert(ident,pivots,basis)
        new=[ident]
    else:
        for g in generators: rank_basis_insert(g,pivots,basis)
        new=list(basis)
    ranks=[len(basis)];steps=0
    while new and steps<max_rounds:
        candidates=[]
        for b in new:
            for g in generators:
                if mode=='algebra': trial=matmul(g,b)
                else: trial=scal((matmul(g,b)-matmul(b,g))%P,I97)
                if rank_basis_insert(trial,pivots,basis): candidates.append(trial)
        new=candidates;ranks.append(len(basis));steps+=1
    mark('closure converged '+mode,not new)
    return len(basis),ranks

# 15-dimensional 1 + 4 + 6 + 4 representation in the paper's displayed basis
pairs=list(itertools.combinations(range(4),2));pair_index={pair:idx for idx,pair in enumerate(pairs)}
root2=14;root3=10
mark('F97 sqrt2 specialization', root2**2%P==2)
mark('F97 sqrt3 specialization', root3**2%P==3)
mark('F97 imaginary specialization', I97**2%P==P-1)

def kron(a,b):return np.kron(a,b)%P
id2=np.eye(2,dtype=np.int64)
s1=np.array([[0,1],[1,0]],dtype=np.int64)
s2=np.array([[0,-I97],[I97,0]],dtype=np.int64)%P
s3=np.array([[1,0],[0,-1]],dtype=np.int64)%P
gammas=[kron(s1,id2),kron(s2,id2),kron(s3,s1),kron(s3,s2)]
id4=np.eye(4,dtype=np.int64)
for a in range(4):
    mark('Clifford square '+str(a), np.array_equal(matmul(gammas[a],gammas[a]),id4))
    for b in range(a):
        mark('Clifford anticommutation '+str(a)+','+str(b),np.count_nonzero((matmul(gammas[a],gammas[b])+matmul(gammas[b],gammas[a]))%P)==0)
coords=[]
for a in range(4):
    Y=np.zeros((15,15),dtype=np.int64)
    Y[0,1+a]=Y[1+a,0]=inv(2)
    for b in range(4):
        if a==b:continue
        ss=1 if a<b else -1
        row=5+pair_index[tuple(sorted((a,b)))]
        val=(ss*root2*inv(3))%P
        Y[row,1+b]=Y[1+b,row]=val
    Y[11:,11:]=scal(gammas[a],root3*inv(4))
    coords.append(Y)
Q=sum((matmul(Y,Y) for Y in coords),start=np.zeros((15,15),dtype=np.int64))%P
q_expected=np.diag([1]+[11*inv(12)%P]*4+[4*inv(9)%P]*6+[3*inv(4)%P]*4)%P
mark('Paper I-A Q fingerprint matches exact four eigenvalues',np.array_equal(Q,q_expected))

# P_B * on the six 2-form basis, and spinor chi.
def perm_sign(a):
    return -1 if sum(a[i]>a[j] for i in range(len(a)) for j in range(i+1,len(a)))%2 else 1
B=np.zeros((15,15),dtype=np.int64)
for (a,b),k in pair_index.items():
    c,d=[x for x in range(4) if x not in (a,b)]
    B[5+pair_index[(c,d)],5+k]=perm_sign((a,b,c,d))%P
chi=id4.copy()
for ga in gammas:chi=matmul(chi,ga)
S=np.zeros((15,15),dtype=np.int64);S[11:,11:]=chi
mark('B duality square equals PB',np.array_equal(matmul(B,B),np.diag([0]*5+[1]*6+[0]*4)%P))
mark('chirality square equals PS',np.array_equal(matmul(S,S),np.diag([0]*11+[1]*4)%P))
Om=np.zeros((15,15),dtype=np.int64)
for perm in itertools.permutations(range(4)):
    t=np.eye(15,dtype=np.int64)
    for a in perm:t=matmul(t,coords[a])
    Om=(Om+perm_sign(perm)*t)%P
om_expected=(scal(B,-34*inv(81))+scal(S,27*inv(32)))%P
mark('Paper I-A Omega4 separated B/S identity',np.array_equal(Om,om_expected))
S_rec=scal(matmul((Q-scal(np.eye(15,dtype=np.int64),4*inv(9)))%P,Om),128*inv(33))
B_rec=scal(matmul((Q-scal(np.eye(15,dtype=np.int64),3*inv(4)))%P,Om),1458*inv(187))
mark('degree-six polynomial chirality recovery',np.array_equal(S_rec,S))
mark('degree-six polynomial geometric duality recovery',np.array_equal(B_rec,B))
D=(scal(B,729)+scal(S,544))%P
trace=lambda m:int(np.trace(m)%P)
mark('degree-five pseudoscalar trace Omega vanishes',trace(matmul(D,Om))==0)
mark('degree-six pseudoscalar trace Q Omega is 561',trace(matmul(D,matmul(Q,Om)))==561%P)

# Rank of the actual coordinate-word filtration (degree <= d).
pivots={}; basis=[];new=[]
ident=np.eye(15,dtype=np.int64)
rank_basis_insert(ident,pivots,basis);new=[ident]
word_ranks=[len(basis)]
deg5basis=[]
for d in range(1,8):
    newer=[]
    for b in new:
        for y in coords:
            w=matmul(y,b)
            if rank_basis_insert(w,pivots,basis):newer.append(w)
    word_ranks.append(len(basis));new=newer
    if d==5: deg5basis=list(basis)
mark('degree-five word rank exactly 136',word_ranks[5]==136,word_ranks)
mark('degree-six word rank exactly 137',word_ranks[6]==137,word_ranks)
mark('degree-seven word rank remains 137',word_ranks[7]==137,word_ranks)
mark('137 equals 11^2+4^2',137==11**2+4**2)
mark('degree<=5 pseudoscalar is trace-orthogonal to all 136 basis words',
     len(deg5basis)==136 and all(trace(matmul(D,w))==0 for w in deg5basis))


out={'field':'F_97','current_source':'Paper1A-Geometry-v5_163.tex','import_target':'Paper2B-MomentumCarrier-v2_135.tex:p2b:cor:v226-coordinate-word-degree','evidence_level':'E1','source_as_printed_model':'Y_a geometric a=1/2,b=sqrt(2)/3; spinor sqrt(3)/4 gamma_a','checks_passed':len(checks),'check_names':checks,'word_ranks_degree_0_to_7':word_ranks,'scope':'Exact source proof replay. Modular ranks provide characteristic-zero lower bounds; the source analytic D-pseudoscalar obstruction supplies W5 upper bound136 and block decomposition supplies W6 upper bound137.'}
Path(__file__).with_name('CoordinateWordReplayResults.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'checks_passed':len(checks),'word_ranks_degree_0_to_7':word_ranks}))
