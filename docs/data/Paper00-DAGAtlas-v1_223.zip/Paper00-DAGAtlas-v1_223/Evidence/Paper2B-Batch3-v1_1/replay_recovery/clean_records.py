import json
from pathlib import Path
p=Path('work/batch3/proposals/replay_recovery/E1Records.json')
x=json.loads(p.read_text())
updates={
'BH-IIB-CENSUS-U009':{
'domain':'Conditional downstream full pointwise multiplication of retained scalar constants and degree-one coordinate harmonics on S3(R); nonnegative integer product budget r.',
'reasoning':[
'The symmetric coordinate products decompose as x_a x_b=(R²/4)δ_ab+(x_a x_b−(R²/4)δ_ab). The trace subtraction has sum_a q_aa=0 because |x|²=R²; symmetric quadratics have dimension ten minus one trace, giving nine.',
'The traceless homogeneous quadratics are the E2 scalar harmonic type of dimension nine. Constants and linear terms were already present.',
'Every polynomial of degree at most r decomposes into harmonic homogeneous pieces times powers of |x|². On the sphere those powers become constants. Coordinate monomials of degree at most r span all such restricted polynomials, so their span is the direct sum of E_l for 0≤l≤r.',
'The dimension is the sum of (l+1)², equal to (r+1)(r+2)(2r+3)/6. This is a scalar harmonic count, not a full module count: E2 has dimension nine whereas H2 has dimension binom(8,4)=70.',
'This conditional capacity calculation does not add full pointwise multiplication to the frozen linear/bracket seed or change m_p=1.',
'The closing inherited-input labels are classified by actual proof use. The harmonic argument is self-contained; universal GP3 carrier rigidity is not consumed in deriving this scalar identity, and the III-F incidence reference is contextual.'
]},
'p2b:thm:finite-covariant-classical-algebra-obstruction':{
'domain':'G acts transitively by homeomorphisms on infinite compact Hausdorff X; U is a unitary G representation on nonzero finite-dimensional complex H.',
'reasoning':[
'A unital *-homomorphism from commutative C(X) has a finite-dimensional commutative C*-image. Simultaneous diagonalization yields pi(f)=sum_j f(x_j)P_j for finitely many distinct points and nonzero orthogonal projectors summing to I. The support F is nonempty because H is nonzero and pi is unital.',
'The kernel is exactly the functions vanishing on F. Equivariance preserves that kernel. Since C(X) separates points of compact Hausdorff X, its common zero set F is G-invariant.',
'For any x in F, transitivity gives Gx=X. Thus nonempty invariant F must equal X, contradicting finiteness of F and infinitude of X.',
'A complex-linear positive map on C(X) preserves adjoints. If a finite unital covariant positive map were multiplicative on all pairs, it would be the forbidden *-homomorphism. Therefore at least one pair has a nonzero multiplicativity defect.',
'No extra group continuity or faithfulness assumption is needed for this finite-support contradiction. Spin(4) acting transitively on S3 satisfies the stated scope.'
]},
'p2b:rem:finite-covariant-defect-scope':{
'domain':'Full C(X) covariance no-go compared with specified finite test spaces, finite sampling and represented matrix algebras.',
'reasoning':[
'The obstruction forbids annihilating every multiplication defect in a finite unital realization covariant for the full round action. It permits exactness on a specified finite test space and closure under matrix multiplication.',
'Finite sampling without full group covariance lies outside the theorem. No particular POVM, state or carrier enlargement is selected.',
'The II-C coordinate POVM reference supplies the positive-map alternative while retaining its family choices. It does not identify unconstrained native tomography with a sharp-radius, exact-moment readout.'
]},
'p2b:cor:v226-coordinate-word-degree':{
'domain':'Current intrinsic coordinate class on the explicit fifteen-dimensional one-copy H1; complex unital span W_d of represented coordinate words of length at most d.',
'reasoning':[
'The current I-A model has geometric edge coefficients 1/2 and sqrt(2)/3 and spinor coefficient sqrt(3)/4. Its coordinate algebra proof constructs all matrix units in M11 direct sum M4 and excludes off-block matrices, giving dimension 137.',
'The current chirality proof gives Omega4=−(34/81)B+(27/32)S. Multiplication by Q separates B and S at degree six.',
'For D=729B+544S, orthogonal covariance makes Tr(D times word) a reflection-odd pseudotensor. Degrees zero and two admit none; degree four is proportional to epsilon with coefficient Tr(D Omega4)=0. Odd degrees vanish under central inversion. Thus nonzero D annihilates W5 and gives dimension at most 136.',
'The exact source elimination was replayed over F97 after matching the current matrices. The specialization sqrt(2)→14, sqrt(3)→10, i→22 preserves defining relations and all matrix denominators are invertible. Word ranks for degrees zero through seven are [1,5,21,69,124,136,137,137]. Nonzero modular minors give characteristic-zero lower bounds, proving W5 has dimension at least 136 and W6 at least 137.',
'Together with the analytic upper bounds this proves both exact dimensions. Degree six is an operation-word bound and does not change the representation tensor-word descriptor m_p=1. Identification with every physical endpoint still requires the existing whole-candidate GP3 certificate.'
]},
'BH-IIB-CENSUS-U010':{
'domain':'A 137-outcome informationally complete mathematical POVM on native A_D=M11(C) direct sum M4(C); separate II-C constraints when prescribed radius and first moments are asserted.',
'reasoning':[
'The current I-A tomography proof uses the 136-dimensional traceless Hermitian native space and a regular simplex with 137 vertices. For a Hilbert–Schmidt orthonormal basis F_k, B_j=sum_k v_jk F_k has operator norm at most Hilbert–Schmidt norm one. Effects E_j=(I+B_j/2)/137 are strictly positive and sum to I.',
'The probabilities are p_j=(1+eta v_j dot r)/137 with eta=1/2. The simplex frame identity gives the exact inverse rho=I/15+(136/eta)sum_j p_j B_j. The traceless measurement frame is eta²/(137·136) times I, equal to I/74528.',
'The native state space has affine dimension 136 and full relative interior at I/15. N outcome probabilities have at most N−1 independent differences, so N≥137; the displayed construction attains that bound.',
'The II-C chirality-radius interface has distinct explicit premises: exact intrinsic first moments and coordinates in radius r≥r0=sqrt(3)R. Writing normalized effect densities gives |u_i|²+v_i²≤1 and sum_i w_i x_i dot u_i=r0. Consequently sum_i w_i v_i²≤1−(r0/r)². Cauchy–Schwarz gives the printed total-variation and Fisher-information bounds.',
'At the optimal radius chirality is invisible. That radius constraint cannot silently be imposed on the native tomography POVM. The target asserts a mathematical finite-effect construction, not an occurring apparatus, preparation or outcome, and keeps outcome count separate from site, species and occupation counts.'
]}
}
for z in x['records']:
 if z['claim_id'] in updates:z.update(updates[z['claim_id']])
# Mechanical readability cleanup for short mathematical notations in remaining records.
replacements={
 'Spin4':'Spin(4)','fullSpin(4)':'full Spin(4)','compactS3':'compact S3','piunital':'pi unital','unitaryG':'unitary G','complexH':'complex H','root2':'root2',
 'scalarL2':'scalar L2','non-diagonalbundle':'non-diagonal bundle','allA':'all A','allf':'all f','forSU2':'for SU2','algebrareducing':'algebra reducing','norms.':'norms.',
 'finitesamplings':'finite sampling','matrixoperatoralgebras':'matrix operator algebras','boundedcompressionproductidentityand':'bounded compression product identity and ',
 'Currentexplicit15×15coordinateblocksandnativealgebradimension137.':'Current explicit 15 by 15 coordinate blocks and native algebra dimension 137.',
 'Ω4identity,nonzerodegree5pseudoscalarannihilatoranddegree6rankcertificate.':'Omega4 identity, nonzero degree-five pseudoscalar annihilator and degree-six rank certificate.',
 'Exact137-effectsimplexconstruction,inversionandminimalnativeoutcomecount.':'Exact 137-effect simplex construction, inversion and minimal native outcome count.',
 'Onlytheboundandoptimal-radiusblindnessneededbythetargetinterface;remoteattainmentconstructionnotindependentlyaudited.':'Only the bound and optimal-radius blindness needed by the target interface; the remote attainment construction was not independently audited.'
}
def clean(v):
 if isinstance(v,str):
  for a,b in replacements.items():v=v.replace(a,b)
  return v
 if isinstance(v,list):return [clean(a) for a in v]
 if isinstance(v,dict):return {k:clean(a) for k,a in v.items()}
 return v
x=clean(x)
p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
print('Cleaned evidence prose')
