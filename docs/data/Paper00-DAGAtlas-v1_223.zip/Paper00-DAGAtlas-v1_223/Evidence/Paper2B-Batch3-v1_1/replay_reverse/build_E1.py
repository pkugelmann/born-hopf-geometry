from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import json, hashlib
W=Path('/workspace/scratch/6302724ed082/work')
S=W/'corpus/Paper2B-MomentumCarrier-v2_135.tex'
census=json.loads((W/'proposals/census/Paper2B-ClaimCensus-v1_1.json').read_text())['claims']
selected=[x for x in census if 2627<=x['complete_span']['start_line']<=2880]
reason={
'p2b:thm:v264-algebra-rigidity':[
'Finite-dimensional complex C*-structure and a faithful unital representation in M15 give A=direct_sum M_(n_i), with represented multiplicities m_i>=1, sum n_i²=137 and sum n_i m_i=15. Unitality fixes the representation dimension rather than allowing an unused orthogonal summand.',
'If max n_i<=9, sum n_i²<=9sum n_i<=135, contradiction. No n_i>=12 is possible because its square exceeds137. If max n_i=10, the remaining defining dimensions sum to at most5, so their squared sum is at most25, smaller than37. Thus max n_i=11.',
'After n=11, the remaining total defining dimension is at most4 and the required square sum is16. Equality in sum a_i²<= (sum a_i)² forces exactly one remaining block4. The defining dimensions11+4 already consume15, so both represented multiplicities are1. This is unitary equivalence of the represented algebra only; it supplies no coordinate constructor or physical ownership.'
],
'p2b:prop:v264-quadratic-inversion':[
'Inside the source-normalized Hermitian equivariant atlas with R>0, scalar-to-vector edge is R/2, and the outgoing-returning path identities give q0=R², qL=2rL², qR=2rR², qS=4varrho², qV=R²/4+(3/2)(rL²+rR²).',
'Nonnegative reduced magnitudes make the displayed square roots single-valued. Substitute the qL and qR identities into the vector value to get qV=q0/4+(3/4)(qL+qR). Atlas existence and phase quotient are imported from the already classified forest, rather than reconstructed for arbitrary tuple types.',
'The domain includes q0>0 because R>0. The remaining qL,qR,qS can be zero; imposing positivity of those completion magnitudes would improperly strengthen the theorem. All-zero sector data are outside the declared atlas and cannot refute its scoped inversion. The sentence about nonnegative data must retain this preceding strict-radius domain.'
],
'p2b:cor:v264-central-polynomial':[
'The imported intrinsic fixed-radius fingerprint has four distinct normalized q eigenvalues1,11/12,4/9,3/4, the last on the4-dimensional spinor summand. Lagrange interpolation for the spinor projector gives the cubic polynomial p(t)=(864/11)(t-1)(t-11/12)(t-4/9).',
'The denominator p numerator at3/4 is(-1/4)(-1/6)(11/36)=11/864. Thus p(q) vanishes on the other three spectral eigenspaces and equals1 on spinors. Gamma_c=I-2P_s has signs+1 on11 and-1 on4.',
'Q_D is a quadratic coordinate word, so the cubic polynomial in q has coordinate-word degree at most6 at fixed positive R. This makes an already specified branch operator algebraically determined; it does not actualize a performed measurement.'
],
'p2b:thm:v264-odd-bridge-types':[
'All finite SU2 irreducibles are self-dual. Expand Hom(H_s,H_g)=H_g tensor H_s* for H_g=(0,0)+(1/2,1/2)+(1,0)+(0,1) and H_s=(1/2,0)+(0,1/2). Each factor uses V_j tensor V_half=V_(j-half)+V_(j+half), omitting negative spin.',
'The multiplicities are3 copies each of(1/2,0),(0,1/2),2 copies each of(1,1/2),(1/2,1),and1 each of(3/2,0),(0,3/2). Their dimensions add to6+6+12+12+4+4=44. Neither(0,0) nor(1/2,1/2) occurs.',
'A Hermitian off-block matrix is uniquely [0,A;A*,0] with A an11-by4 complex matrix, so its real dimension is2*44=88. Multiplicity3 of each half-spin type leaves three representation channels; no unique physical action coefficient is inferred.'
],
'p2b:thm:v264-central-even-no-go':[
'The center z=(-I,-I) acts+1 on H_g and-1 on H_s. It therefore acts-1 on either off-diagonal Hom direction and on O. On the input G-space V, z acts trivially by hypothesis. Equivariance alone gives F(v)=F(zv)=zF(v)=-F(v), forcing F(v)=0 over C or R, without any linearity assumption.',
'For nonzero spinorial chi orthogonal to invariant normalized e0, B_chi=|e0><chi|+|chi><e0| is self-adjoint. It sends e0 to chi and is nonzero. Both summands are off-block, so conjugating by center gives-B_chi.',
'Because e0 is invariant, conjugation by rho(g) carries B_chi to B_(rho(g)chi). This is covariance of a family with the actual chi input, not a fixed nonzero invariant one-system operator arising from central-even input alone. The source explicitly disclaims physical occurrence.'
],
'p2b:thm:v264-no-parallel-odd':[
'For the explicitly specified associated H1 bundle and inherited full SU2_diag holonomy, restrict(jL,jR) by the diagonal Clebsch-Gordan rule. The scalar and vector supply2V0+V1; two adjoints add2V1, so H_g=2V0+3V1. The two chiral halves each restrict toV_half, so H_s=2V_half.',
'The Hom restriction is(2V0+3V1) tensor2V_half=4V_half+6(V_half+V_3half)=10V_half+6V_3half, of dimension20+24=44, with no fixed-vector V0.',
'A parallel section on a connected domain is fixed by its holonomy at one fibre. The full restricted SU2_diag holonomy already has no invariant vector in the odd Hom, so every parallel odd section is zero. This does not address nonparallel sections or assert physical occurrence of the associated interaction bundle.',
'Current III-F p3f:cor:v181-full-born-holonomy10156–10173 explicitly imports full restricted SU2_diag for its generated connection. Its exact needed I-B homogeneous-connection proof704–732 gives midpoint curvature spanning su2, so no rank-one Hopf reduction is silently substituted.'
],
'p2b:prop:v264-chiral-central-distinction':[
'Current V-A protected module W=W_L direct_sum W_R is the internal half-spin representation, distinct from physical Lorentz chirality. On both half-spin summands the diagonal center acts-I. Therefore conjugation by rho_W(z) fixes every D_W in End(W), including an internally chiral-odd block.',
'An off-diagonal W_L/W_R Dirac coefficient can anticommute with the internal chiral grading while commuting with diagonal-center conjugation. Its matter owner End(W tensor Q tensor G) differs from Hom(H_s,H_g), whose center character is odd.',
'The existing V-A rooted operator D_F,geom has nonzero c(h*) tensor I_Q tensor I_G and is indeed nonzero on its stated rooted branch. The source does not refute that result; it correctly states that this incidence alone certifies neither the separate FENV odd field port nor a two-carrier exchange Hessian.'
],
'p2b:thm:v264-canonical-paired-exchange':[
'P_g and P_s are complementary orthogonal projectors of ranks11 and4 on the same specified H1 model. Q_cross=P_g tensor P_s+P_s tensor P_g is a projection of rank44+44=88. Flip F commutes with Q_cross because it exchanges the two terms; F is a self-adjoint involution.',
'Thus K=FQ_cross is self-adjoint and K²=Q_cross. Its kernel is exactly ker Q_cross and its rank is88. Diagonal rho(g) tensor rho(g) commutes with F and the central projectors, so K is diagonal-Spin4 invariant.',
'Total central grading Gamma_c tensor Gamma_c has sign-1 on both crossed sectors and commutes with K. On u_g tensor v_s, K maps to v_s tensor u_g; the first-system P_g expectation changes and the commutator is nonzero.',
'Every element of the native even factor algebra preserves P_g and P_s, so every tensor-product native even test commutes with P_g tensor I. Since K does not, it is outside that product test algebra. The assertion is valid for the named native even algebra and even for any block-preserving factor algebra.',
'The source constructs a mathematical two-copy operator only. The IV-A imported population law at3897–3947 explicitly requires an actual identified two-carrier relation-free occurrence, consumed Hamiltonian hbar*kappa*K, a dynamic token, and an actually prepared trace bath. Those conditions are not outputs of II-B K-existence.'
]
}
imports={
'p2b:prop:v264-quadratic-inversion':[{'file':'Paper1A-Geometry-v5_163.tex','label':'p1:cor:level-one-coordinate-completion-moduli','lines':[12061,12088],'scope':'Normalized Hermitian forest atlas and phase equivalence, including nonnegative magnitudes'},{'file':'Paper2C-ReciprocalLocalization-v2_160.tex','label':'p2c:thm:intrinsic-tangential-coordinate-class','lines':[1252,1305],'scope':'Raw-edge magnitude convention and outgoing-path quadratic values only'}],
'p2b:cor:v264-central-polynomial':[{'file':'Paper2C-ReciprocalLocalization-v2_160.tex','label':'p2c:thm:intrinsic-tangential-coordinate-class','lines':[1252,1305],'scope':'Already specified intrinsic fixed-radius Q_D spectrum'},{'file':'Paper1A-Geometry-v5_163.tex','label':'p1:thm:intrinsic-tangential-coordinate-class','lines':[14808,14862],'scope':'Same four distinct intrinsic spectral values'}],
'p2b:thm:v264-no-parallel-odd':[{'file':'Paper3F-CompleteDynamics-v1_253.tex','label':'p3f:cor:v181-full-born-holonomy','lines':[10156,10173],'scope':'Full restricted SU2_diag holonomy of the already generated connection'},{'file':'Paper1B-M8Geometry-v1_128.tex','label':'p1b:thm:homogeneous','lines':[703,732],'scope':'Only exact midpoint curvature/holonomy argument used by III-F'}],
'p2b:prop:v264-chiral-central-distinction':[{'file':'Paper5A-FiniteMatterGeometry-v3_199.tex','label':'p5:eq:part1-K-split','lines':[1729,1745],'scope':'Internal half-spin W representation and distinct physical Lorentz chirality'},{'file':'Paper5A-FiniteMatterGeometry-v3_199.tex','label':'p5:def:v392-rooted-geometric-finite-odd','lines':[4954,4972],'scope':'Owner End(W tensor Q tensor G) and rooted c(h*) map'},{'file':'Paper5A-FiniteMatterGeometry-v3_199.tex','label':'p5:prop:v392-rooted-member-full-rank','lines':[4974,4986],'scope':'Nonzero rooted coefficient stays valid in its actual owner'}],
'p2b:thm:v264-canonical-paired-exchange':[{'file':'Paper4A-FiniteQuantumMechanics-v4_205.tex','label':'p4:thm:v264-paired-population-law','lines':[3897,3947],'scope':'Downstream physical-owner guards only, not a premise of mathematical K existence'}]
}
records=[]
for n,c in enumerate(selected,1):
 cid=c['claim_id']
 records.append({'id':f'EV-IIB-B3-E1B-{n:03}','evidence_level':'E1','agent':'/root/replay_states','claim_id':cid,'statement_layer':'SOURCE-AS-PRINTED','source_file':S.name,'statement_lines':list(c['statement_span'].values()),'proof_lines':list(c['proof_span'].values()) if c['proof_span'] else None,'complete_lines':list(c['complete_span'].values()),'source_as_printed':c['source_as_printed'],'source_replay':'COMPLETE WITHIN PRINTED SCOPE','reasoning':reason[cid],'imports':imports.get(cid,[]),'adjudication':'Source proof reproduced; final independent/adversarial gates belong to coordinator','physical_occurrence_newly_certified':False})
checks={'interpolation_denominator':str((F(3,4)-1)*(F(3,4)-F(11,12))*(F(3,4)-F(4,9))),'odd_Hom_complex_dimension':3*2+3*2+2*6+2*6+4+4,'odd_Hermitian_real_dimension':88,'diagonal_Hom_dimension':10*2+6*4,'crossed_rank':2*11*4}
assert checks['interpolation_denominator']=='11/864'
assert checks['odd_Hom_complex_dimension']==checks['diagonal_Hom_dimension']==44
for t,expected in [(F(1),0),(F(11,12),0),(F(4,9),0),(F(3,4),1)]:
 assert F(864,11)*(t-1)*(t-F(11,12))*(t-F(4,9))==expected
out={'target':S.name,'batch':3,'scope_lines':[2627,2880],'source_sha256':hashlib.sha256(S.read_bytes()).hexdigest(),'records':records,'candidate_issues':[],'confirmed_mathematical_defects':[],'exact_replay_arithmetic':checks,'scope_adjudications':[{'target':'p2b:prop:v264-quadratic-inversion','status':'SCOPED THEOREM CHECKS; NO IN-DOMAIN REFUTATION','source_scope':'Fixed normalized atlas with R_mom>0; q0>0 inherited. qL,qR,qS nonnegative, including zero.','invalid_attack':'All-zero spectral data satisfy the displayed linear relation but cannot occur with R>0; they attack only a stronger standalone converse dropping the opening domain.','no_silent_strengthening':'No positivity assumption imposed on raw completion magnitudes and no all-nonzero graph condition required for the inverse.'},{'target':'p2b:thm:v264-canonical-paired-exchange','status':'MATHEMATICAL TWO-COPY CANDIDATE ONLY','boundary':'Fixed identified H1 tensor H1, central projectors and flip. No second carrier occurrence, process, trace-bath preparation, physical FENV or ENV effect, or action coefficient is generated.'}], 'not_audited':'No independent audit of other manuscripts, physical action/preparation occurrence, or target lines2881 onward. No new theory, source edits or PDF work.'}
p=W/'batch3/proposals/replay_reverse/E1Records.json';p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'written':str(p),'records':len(records),'confirmed_issues':0,'exact_replay_arithmetic':checks}))
