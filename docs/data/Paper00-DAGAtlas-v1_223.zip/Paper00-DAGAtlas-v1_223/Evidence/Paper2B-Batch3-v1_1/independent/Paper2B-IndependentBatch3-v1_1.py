#!/usr/bin/env python3
"""Independent exact checks of existing II-B statements2245–2880.
The native-word certificate is reconstructed from current I-A matrices.
No prior proof script or verdict is an input.
"""
from fractions import Fraction as F
from collections import defaultdict,Counter
from itertools import product,permutations
from math import comb
from pathlib import Path
import json,time
start=time.monotonic(); checks=defaultdict(int)
def check(ok,g):
    assert ok,g
    checks[g]+=1

def zero(n):return [[0]*n for _ in range(n)]
def eye(n):
    a=zero(n)
    for i in range(n):a[i][i]=1
    return a
def plus(a,b):return [[x+y for x,y in zip(r,s)] for r,s in zip(a,b)]
def scale(c,a):return [[c*x for x in r] for r in a]
def minus(a,b):return plus(a,scale(-1,b))
def mul(a,b):return [[sum(a[i][k]*b[k][j] for k in range(len(b))) for j in range(len(b))] for i in range(len(a))]
def trans(a):return list(map(list,zip(*a)))
def tr(a):return sum(a[i][i] for i in range(len(a)))
def diag(values):
    a=zero(len(values))
    for i,v in enumerate(values):a[i][i]=v
    return a
# Scalar dimension ratio and exact central interpolation.
for m in range(31):
    dim=sum((k+1)**2 for k in range(m+1))
    check(dim==F((m+1)*(m+2)*(2*m+3),6),'scalar_dimension')
    check(F(dim,comb(2*m+4,4))==F(1,2*m+1),'scalar_fraction')
for value,want in [(F(1),0),(F(11,12),0),(F(4,9),0),(F(3,4),1)]:
    val=F(864,11)*(value-1)*(value-F(11,12))*(value-F(4,9))
    check(val==want,'central_projector_polynomial')
# Exact scalar Toeplitz m1 controls: orthonormal scalar basis(1,2x_a/R).
# Each M_xa compression is a star edge R/2; evaluating on algebraic1
# recovers its retained coefficient vector. Volume normalization rescales1,
# and compensating sqrtV is shown by an exact sampleV=4.
for radius in [F(1),F(2),F(3)]:
    for a in range(4):
        T=zero(5);T[0][1+a]=T[1+a][0]=radius/2
        symbol=[T[i][0] for i in range(5)]
        wanted=[F(0)]*5;wanted[1+a]=radius/2
        check(symbol==wanted,'scalar_Toeplitz_unit_retraction')
        normalized_symbol=[x/2 for x in symbol]
        check([2*x for x in normalized_symbol]==wanted,'scalar_Toeplitz_volume_compensation')
# Source-declared raw atlas: inverse identities for nonnegative magnitudes,
# retaining strictly positive parent radius.
for radius in [F(1,2),F(1),F(2)]:
    for left,right,spin in product([F(0),F(1,3),F(1)],repeat=3):
        q0=radius**2;qL=2*left**2;qR=2*right**2;qS=4*spin**2
        qV=q0/4+F(3,2)*(left**2+right**2)
        check(qV==q0/4+F(3,4)*(qL+qR),'quadratic_atlas_constraint')
        check(qL/2==left**2 and qR/2==right**2 and qS/4==spin**2 and q0>0,'quadratic_atlas_inverse_squares')
# Exhaust all represented finite-dimensional C*block configurations atN15.
solutions=[]
def enumerate_blocks(remaining,min_n,square,blocks):
    if remaining==0:
        if square==137:solutions.append(blocks)
        return
    for n in range(min_n,remaining+1):
        if square+n*n>137:break
        for multiplicity in range(1,remaining//n+1):
            enumerate_blocks(remaining-n*multiplicity,n,square+n*n,blocks+[(n,multiplicity)])
enumerate_blocks(15,1,0,[])
# Repeated identical summands may appear in different order; normalize.
solutions=sorted(set(tuple(sorted(s)) for s in solutions))
check(solutions==[((4,1),(11,1))],'Cstar_15_137_unique')
# Independent twice-spin Clebsch-Gordan oracle.
def cg(a,b):return range(abs(a-b),a+b+1,2)
geo=[(0,0),(1,1),(2,0),(0,2)];spin=[(1,0),(0,1)]
content=Counter()
for a,b in geo:
    for c,d in spin:
        for l in cg(a,c):
            for r in cg(b,d):content[l,r]+=1
want={(1,0):3,(0,1):3,(2,1):2,(1,2):2,(3,0):1,(0,3):1}
check(dict(content)==want,'odd_bridge_CG')
check(sum(m*(l+1)*(r+1) for (l,r),m in content.items())==44,'odd_bridge_dimension')
diag_geo=Counter();diag_spin=Counter()
for a,b in geo:
    for j in cg(a,b):diag_geo[j]+=1
for a,b in spin:
    for j in cg(a,b):diag_spin[j]+=1
check(dict(diag_geo)=={0:2,2:3} and dict(diag_spin)=={1:2},'diagonal_restrictions')
diag_hom=Counter()
for a,m in diag_geo.items():
    for b,n in diag_spin.items():
        for c in cg(a,b):diag_hom[c]+=m*n
check(dict(diag_hom)=={1:10,3:6},'diagonal_no_parallel_odd')
# Generic source-projection identities on finite exact rational matrices.
P=diag([1,1,0]);Q=minus(eye(3),P)
As=[[[1,2,-1],[0,3,1],[2,-1,1]],[[0,1,2],[1,-1,0],[3,2,1]],[[2,0,1],[-1,1,2],[0,1,-2]],[[1,-1,0],[2,1,1],[1,0,2]]]
for n in [2,3,4]:
    W=P
    for A in As[:n]:W=mul(W,A)
    W=mul(W,P);WP=P
    for A in As[:n]:WP=mul(WP,mul(A,P))
    defect=minus(W,WP);rhs=zero(3)
    for j in range(n-1):
        term=P
        for A in As[:j]:term=mul(term,mul(A,P))
        term=mul(term,mul(As[j],Q))
        for A in As[j+1:n]:term=mul(term,A)
        rhs=plus(rhs,mul(term,P))
    check(defect==rhs,'ordered_word_exact_identity')
Z=[[1,0],[0,1],[0,0]]
# Rectangular helpers for isometry compression.
def mm(a,b):return [[sum(a[i][k]*b[k][j] for k in range(len(b))) for j in range(len(b[0]))] for i in range(len(a))]
compress=lambda a:mm(trans(Z),mm(a,Z))
A=As[0];B=As[1]
qaz=mm(Q,mm(A,Z))
square=minus(compress(mm(trans(A),A)),mm(trans(compress(A)),compress(A)))
check(square==mm(trans(qaz),qaz),'square_defect_gram')
mixed=minus(compress(mm(A,B)),mm(compress(A),compress(B)))
check(mixed==mm(trans(mm(Q,mm(trans(A),Z))),mm(Q,mm(B,Z))),'mixed_defect_factorization')
# D01 polynomial dimensions by restriction quotient: number of≤r monomials in4
# minus multiples of the quadratic relation degree≤r−2.
for r in range(16):
    quotient_dim=comb(r+4,4)-(comb(r+2,4) if r>=2 else 0)
    check(quotient_dim==sum((l+1)**2 for l in range(r+1)),'harmonic_product_dimensions')
check(comb(5,2)-1==9 and comb(8,4)==70,'D01_E2_vs_H2')
# Coordinate rational similarity. On exterior degrees0,1,2 rescale degree2
# bysqrt2. Thus scalar edge1/2; V<-B2/3; B<-V1/3.
wedges=[(i,j) for i in range(4) for j in range(i+1,4)]
Aints=[]
for a in range(4):
    M=zero(11);M[0][1+a]=M[1+a][0]=3 # 6Y onscalar/vector
    for j in range(4):
        if j==a:continue
        pair=tuple(sorted((a,j)));s=1 if a<j else -1;b=5+wedges.index(pair)
        M[b][1+j]=2*s;M[1+j][b]=4*s
    Aints.append(M)
# Integral Hodge star onbivectors, standardorientation.
def permutation_sign(p):return (-1)**sum(p[i]>p[j] for i in range(len(p)) for j in range(i+1,len(p)))
Hodge=zero(11)
for b,pair in enumerate(wedges):
    comp=tuple(i for i in range(4) if i not in pair)
    Hodge[5+wedges.index(comp)][5+b]=permutation_sign(pair+comp)
def sparse_right(M,gen,mod=None):
    n=len(M);out=zero(n)
    for k,row in enumerate(gen):
        for j,val in enumerate(row):
            if val:
                for i in range(n):out[i][j]+=M[i][k]*val
    if mod:
        out=[[x%mod for x in r] for r in out]
    return out

def word_integer(word):
    M=eye(11)
    for a in word:M=sparse_right(M,Aints[a])
    return M
base_trace=tr(mul(Hodge,word_integer((0,1,2,3))))
geo_coeff=F(base_trace,6**4)
# gamma5=gamma1gamma2gamma3gamma4; spin tracegamma5*word is±9/64
# exactlyfor all four distinct letters atdegree4, zero atotherdegrees≤5.
beta=-geo_coeff/F(9,64)
check(beta!=0,'word5_annihilator_nonzero')
annihilator_words=0
for degree in range(6):
    for word in product(range(4),repeat=degree):
        M=word_integer(word)
        gtrace=F(tr(mul(Hodge,M)),6**degree)
        strace=F(9,64)*permutation_sign(word) if degree==4 and len(set(word))==4 else F(0)
        check(gtrace+beta*strace==0,'word5_exact_annihilator')
        annihilator_words+=1
# Word ranks modulo a good prime. Q(i)coefficients only; theseare lowerbounds
# overC. Upperbounds:137 blockalgebra and136 exactannihilator above.
p=1009;iunit=next(i for i in range(p) if i*i%p==p-1)
inv=lambda n:pow(n%p,p-2,p)
# Quaternion Weyl blocks q1=iσ1,q2=iσ2,q3=iσ3,q4=I.
qs=[[[0,iunit],[iunit,0]],[[0,1],[-1,0]],[[iunit,0],[0,-iunit]],[[1,0],[0,1]]]
Y=[]
for a in range(4):
    M=zero(15)
    for r in range(11):
        for c in range(11):M[r][c]=Aints[a][r][c]*inv(6)%p
    # q†=-q forfirstthree, q†=q forfourth. Rescalespinchiral
    # lowerblock bysqrt3: upper3q/4, lowerq†/4.
    for r in range(2):
        for c in range(2):
            M[11+r][13+c]=3*qs[a][r][c]*inv(4)%p
            M[13+r][11+c]=(1 if a==3 else -1)*qs[a][r][c]*inv(4)%p
    Y.append(M)
slots=[(i,j) for i in range(11) for j in range(11)]+[(i,j) for i in range(11,15) for j in range(11,15)]
pivots={};literal_basis=[]
def add_word(M,word):
    vec=[M[i][j]%p for i,j in slots]
    for pivot,row in sorted(pivots.items()):
        c=vec[pivot]
        if c:vec=[(v-c*w)%p for v,w in zip(vec,row)]
    pivot=next((k for k,v in enumerate(vec) if v),None)
    if pivot is None:return False
    c=inv(vec[pivot]);pivots[pivot]=[(c*v)%p for v in vec]
    literal_basis.append((M,word));return True
add_word(eye(15),());ranks=[1]
for degree in range(1,7):
    old=list(literal_basis)
    for M,word in old:
        for a in range(4):add_word(sparse_right(M,Y[a],p),word+(a,))
    ranks.append(len(pivots))
check(ranks[5]==136,'word5_modular_lower_bound')
check(ranks[6]==137,'word6_modular_lower_bound')
check(len(slots)==137 and annihilator_words==sum(4**k for k in range(6)),'word_rank_upper_bound_dimensions')
# Explicit Qfingerprint from reconstructedcoordinates givesindependentcontrol
# on sourcecoefficients. Allentriescomparedmodp, not usedasrankupperbound.
qsum=zero(15)
for M in Y:qsum=plus(qsum,mul(M,M))
expected=[1]+[11*inv(12)%p]*4+[4*inv(9)%p]*6+[3*inv(4)%p]*4
check(all((qsum[i][j]-(expected[i] if i==j else 0))%p==0 for i in range(15) for j in range(15)),'reconstructed_coordinate_fingerprint')
# Pairedexchange actsaspartialpermutation; exact225basis mapping, nofloat.
gdim,sdim=11,4;N=15
isg=lambda a:a<11
K={a*N+b:b*N+a for a in range(N) for b in range(N) if isg(a)!=isg(b)}
check(len(K)==88,'paired_exchange_rank')
check(all(K.get(dst)==src for src,dst in K.items()),'paired_exchange_selfadjoint_square')
check(all((-1 if isg(src//N)!=isg(src%N) else 1)==(-1 if isg(dst//N)!=isg(dst%N) else 1) for src,dst in K.items()),'paired_exchange_total_parity')
check(any(isg(src//N)!=isg(dst//N) for src,dst in K.items()),'paired_exchange_individual_population')
# TensorflipcommuteswithR⊗R forarbitrarysuppliedsameR (checkedon2+1toy
# whereRpreservesg/s, generalproofin independentanalyticrecord).
R=[[0,-1,0],[1,0,0],[0,0,-1]]
for a,b,c,d in product(range(3),repeat=4):
    check(R[b][c]*R[a][d]==R[a][d]*R[b][c],'paired_exchange_diagonal_covariance_control')
result={'script':Path(__file__).name,'status':'PASS','assertions':sum(checks.values()),'groups':dict(checks),'runtime_seconds':round(time.monotonic()-start,3),'word_rank_certificate':{'prime':p,'i_mod_prime':iunit,'ranks_degree0_to6':ranks,'basis_word_count':len(literal_basis),'basis_words':[''.join(str(a+1) for a in word) or 'I' for M,word in literal_basis],'pivot_positions':sorted(pivots),'word5_annihilator_spin_coefficient':str(beta),'exact_annihilator_words_checked':annihilator_words,'logic':'modularlowerbounds136/137 + exactall-wordannihilatorupper136 atdegree5 + blockupper137 atdegree6 ⇒ exactcomplexranks136/137','source_matrix':'Paper1A-Geometry-v5_163.tex:p1:eq:v226-matrix'},'Cstar_15_137_solutions':solutions,'limitations':['Matrixwordrankproof concerns explicitone-copyintrinsicclass, not universalGP3endpointidentification.','Finiteexamplecontrols supplement universalanalyticarguments.','No physicalconstructor, performedmeasurement, process, orsecondcarrier isactualized.']}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
