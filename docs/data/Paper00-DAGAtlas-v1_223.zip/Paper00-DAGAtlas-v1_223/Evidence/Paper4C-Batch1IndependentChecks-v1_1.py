#!/usr/bin/env python3
"""Independent, repeatable exact/numerical controls for Paper IV-C source lines 1--1862.
NOT a substitute for upstream physical-occurrence proofs or claim-wide E3 on imported claims.
"""
import json, math, hashlib, re
from pathlib import Path
from fractions import Fraction
import numpy as np
from scipy.linalg import expm
from scipy.integrate import quad
from sympy import Rational, simplify
from sympy.physics.wigner import wigner_6j

root=Path('/mnt/data/bh4c_work')
src=next((root/'papers').glob('*/Paper4C-*.tex'))
s=src.read_bytes(); rec=[]
def check(code, ok, calc, claim, kind='E3_INDEPENDENT_CONTROL'):
 rec.append({'id':f'BH-IVC-B1-CHECK-{len(rec)+1:03d}','kind':kind,'name':code,'claim':claim,'passed':bool(ok),'calculation':calc})
 assert ok, (code, calc)

# Representation-theoretic identity: 15-dim H1 with two J=0, three J=1, two J=1/2 copies.
sectors=[(0,0),(Rational(1,2),Rational(1,2)),(1,0),(0,1),(Rational(1,2),0),(0,Rational(1,2))]
D=sum((2*j+1)*(2*k+1) for j,k in sectors)
spins=[]
for j,k in sectors:
 for n in range(int(2*abs(j-k)),int(2*(j+k))+1,2):spins.append(Rational(n,2))
multip={str(x):spins.count(x) for x in set(spins)}
check('spin4-H1-CG',D==15 and multip=={'0':2,'1':3,'1/2':2}, {'dimension':str(D),'diagonal_spin_multiplicities':multip},'p4:thm:angular-cutoff')
check('sym2-E1',4*5//2==1+9, {'Sym2_dim':10,'E0_plus_E2_dim':10},'p4:cor:v260-degree-two-fourfold-characterization')
def dP(k):return (k+1)*(k+2)*(2*k+3)//6
def p(k,q):
 if k<abs(q):return 0
 L=(k-abs(q))//2
 return (L+1)*(L+abs(q)+1)
def M(k):return 7*p(k,0)+6*p(k,1)+2*p(k,2)
for k in range(1,100):
 r=k//2
 expected=15*r*r+24*r+7 if k%2==0 else 15*r*r+36*r+19
 assert M(k)==expected
check('all-level-Hopf-Mk',True,{'k1':M(1),'k2':M(2),'k3':M(3),'k100':M(100),'dP2':dP(2),'asymptotic_M': '15k^2/4','mixed_denominator':'15k^3/3','ratio':'3/(4k)'},'p4:thm:v261-fixed-momentum-reciprocity-bottleneck')
check('fixed-carrier-visible-fraction', dP(2)==14 and Fraction(14,dP(100))==Fraction(84,101*102*203), {'rank_max':14,'fraction_k2':str(Fraction(14,dP(2))),'fraction_k100':str(Fraction(14,dP(100)))},'p4:thm:v260-degree-two-covariant-saturation')
check('natural-2T-intertwiner-rank', min(1,6)+2*min(2,3)==5 and 6+2*3==12 and 15-5==10, {'H1_decomp':'6*1 + 3*V2 + V3','target_decomp':'1 + 2*V2','max_rank':5,'Hom_complex_dim':12,'min_kernel':10,'V3_killed':True},'p4:prop:v260-finite-xp-interface-taxonomy')
# Exact variance from independent state vector Q,Y4 block computation.
a=np.sqrt(15)/8; b=7/8; ymean=2*a*b*np.sqrt(2)/3
qmean=(a*a)*(11/12)+(b*b)*(4/9)
val= qmean-ymean*ymean
check('variance-sharp-1823-4608', abs(val-1823/4608)<1e-14,{'exact_fraction':str(Fraction(1823,4608)),'computed':val,'Q_expectation':qmean,'Y4_expectation':ymean},'p4:prop:intrinsic-localization-moment-transport')
# Multimode weighted CCR top-boundary direct matrix for complete total occupancy.
def fock(d,N):
 from itertools import product
 return [state for state in product(range(N+1),repeat=d) if sum(state)<=N]
for N in [0,1,2,3]:
 states=fock(2,N); ix={x:i for i,x in enumerate(states)}; dim=len(states); A=[]
 for t in range(2):
  X=np.zeros((dim,dim))
  for x,ii in ix.items():
   if x[t]:
    y=list(x);y[t]-=1; X[ix[tuple(y)],ii]=np.sqrt(x[t])
  A.append(X)
 P=np.diag([int(sum(x)==N) for x in states]); I=np.eye(dim)
 for i in range(2):
  for j in range(2):
   com=A[i]@A[j].T-A[j].T@A[i]
   rhs=(I if i==j else 0)-P@((I if i==j else 0)+A[j].T@A[i])@P
   assert np.max(np.abs(com-rhs))<1e-12
 if N>0:
  w=np.diag([2.0,3.0]); number=sum(w[i,i]*(A[i].T@A[i]) for i in range(2));
  prod=sum(w[i,i]*(A[i]@A[i].T+A[i].T@A[i])/2 for i in range(2));
  claimed=number+np.trace(w)*I/2-P@(number+np.trace(w)*I)@P/2
  assert np.max(np.abs(prod-claimed))<1e-12
check('total-occupation-weighted-commutator',True,{'tested_N':[0,1,2,3],'modes':2,'frequency_weights':[2,3],'operator_identity':'checked exactly up to floating rounding'},'p4:lem:v2174-weighted-ordering-boundary')
# Truncated one-mode thermal variance for N=0,1,2,4, beta energy values.
errs=[]
for N in [0,1,2,4]:
 a=np.diag(np.sqrt(np.arange(1,N+1)),1); top=np.zeros((N+1,N+1));top[N,N]=1
 for y in [0.35,1.2,2.4]:
  x=np.exp(-y); prob=np.array([x**i for i in range(N+1)]);prob/=sum(prob)
  av_n=sum(i*prob[i] for i in range(N+1)); ptop=prob[-1]
  q=(a+a.T)/np.sqrt(2)
  direct=np.sum(prob*np.diag(q@q))
  formula=(2*av_n+1-(N+1)*ptop)/2
  errs.append(abs(direct-formula))
check('truncated-thermal-variance',max(errs)<1e-13,{'N_tested':[0,1,2,4],'beta_hbaromega':[0.35,1.2,2.4],'max_abs_residual':max(errs)},'p4:prop:v245-finite-thermal-boundary-correction')
# Graded port N extraction for two mode bosonic sublevel.
for N in range(0,5):
 states=fock(2,N);ix={x:i for i,x in enumerate(states)}; dim=len(states)
 R=np.zeros((dim,dim)); G=np.diag([sum(x) for x in states])
 for x,i in ix.items():
  if sum(x)<N:
   y=(x[0],x[1]+1);R[ix[y],i]=np.sqrt(x[1]+1)
 assert np.max(np.abs(G@R-R@G-R))<1e-12
 assert np.linalg.norm(np.linalg.matrix_power(R,N+1))<1e-12
 if N: assert np.linalg.norm(np.linalg.matrix_power(R,N))>0
check('graded-occupation-nilpotency',True,{'N_tested':[0,1,2,3,4],'result':'nilpotency index N+1 and degree commutator'},'p4:prop:v2174-graded-port-boundary')
# finite compression Schur check independent 5x5 example.
rng=np.random.default_rng(404)
K=rng.normal(size=(5,5))+1j*rng.normal(size=(5,5)); H=(K+K.conj().T)/2
z=0.7+1.3j
LL=H[:2,:2]; LH=H[:2,2:]; HH=H[2:,2:]
Sch=z*np.eye(2)-LL-LH@np.linalg.inv(z*np.eye(3)-HH)@LH.conj().T
left=np.linalg.inv(z*np.eye(5)-H)[:2,:2]
error=float(np.max(np.abs(left-np.linalg.inv(Sch))))
check('Schur-block-resolvent',error<1e-12,{'matrix_size':5,'retained_rank':2,'max_abs_residual':error},'p4:thm:finite-resolution-rg-threshold-matching')
# source response: Duhamel derivative agrees with Kubo kernel for two-level.
H0=np.array([[0.65,0.2],[0.2,-0.4]],complex);D=np.array([[0.3,0.25],[0.25,-0.1]],complex);Q=np.array([[0.5,0.12],[0.12,0.2]],complex)
rho=np.array([[0.8,0.11],[0.11,0.2]],complex)
t=0.8; eps=2e-6
F=lambda phi: float(np.trace(expm(-1j*(H0+phi*D+phi*phi*Q/2)*t)@rho@expm(+1j*(H0+phi*D+phi*phi*Q/2)*t)@(D+phi*Q)).real)
fd=(F(eps)-F(-eps))/(2*eps)
def kernel(u):
 Ut=expm(-1j*H0*t);Us=expm(-1j*H0*u); Uts=expm(-1j*H0*(t-u))
 rho_u=Us@rho@Us.conj().T
 Dhat=Uts.conj().T@D@Uts
 return float((-1j*np.trace(rho_u@(Dhat@D-D@Dhat))).real)
I=quad(kernel,0,t,epsabs=1e-12)[0]
instant=float(np.trace((expm(-1j*H0*t)@rho@expm(+1j*H0*t))@Q).real)
check('finite-retarded-response-Duhamel',abs(fd-instant-I)<2e-8, {'finite_difference':fd,'instant':instant,'retarded_integral':I,'max_abs_residual':abs(fd-instant-I),'hbar':1}, 'p4:thm:v4104-finite-interacting-source-response')
# Wigner 6j matrix orthogonality on a genuinely mixed J=1/2 triplet.
sp=Rational(1,2); mids=[0,1]
W=np.array([[float((-1)**(sp+sp+sp+sp)*np.sqrt(float((2*x+1)*(2*y+1)))*wigner_6j(sp,sp,x,sp,sp,y)) for y in mids] for x in mids]); orth=W@W.T
check('Wigner-6j-unitarity',np.max(np.abs(orth-np.eye(2)))<1e-13,{'J_A=J_B=J_C=J':str(sp),'U':W.tolist(),'max_orth_residual':float(np.max(np.abs(orth-np.eye(2))))},'p4:thm:finite-recoupling')
# Line antiunitary plus doubled real form: test positive control phases.
for phase in [0.,0.37,1.5]:
 mu=np.exp(1j*phase)*1.7;D=np.array([[0,np.conj(mu)],[mu,0]],complex);Gamma=np.diag([1,-1])
 J=lambda v: np.array([np.conj(v[1]),np.conj(v[0])])
 v=np.array([0.4+0.3j,0.6-0.1j]);
 assert np.linalg.norm(J(D@v)-D@J(v))<1e-12
 assert np.linalg.norm(J(Gamma@v)+Gamma@J(v))<1e-12
 assert np.linalg.norm(J(J(v))-v)<1e-12
check('quadratic-line-conjugate-reality',True,{'mu_phases':[0,.37,1.5],'properties':['D=D*','JD=DJ','JG=-GJ','J^2=1']},'p4:prop:faithful-conjugate-line-completion')


# Independent E3 control of the *global* sharp total-variance minimum;
# all invariant branches, not just the saturating state, are compared exactly.
from sympy import sqrt
branches=[]
for q1,q2,h in [(Rational(1),Rational(11,12),Rational(1,2)),
                 (Rational(11,12),Rational(4,9),sqrt(2)/3)]:
 aa=(q1+q2)/2; bb=(q1-q2)/2
 assert bb**2 <= 4*h**4
 branches.append(simplify(aa-h*h-bb*bb/(4*h*h)))
branches.extend([Rational(4,9),Rational(9,16)])
minimum=min(branches)
check('sharp-variance-global-four-blocks',
      minimum==Rational(1823,4608) and branches==[Rational(407,576),Rational(1823,4608),Rational(4,9),Rational(9,16)],
      {'all_branch_minima':[str(x) for x in branches],'global_minimum':str(minimum),
       'method':'exact min over all Spin(4)-covariant joint Q,Y4 blocks'},
      'p4:prop:intrinsic-localization-moment-transport')
# Exact right-diagonal singlet and full diagonal Spin(4) multiplicities on P_x(k) tensor H1.
right_1={Rational(0):6,Rational(1,2):3,Rational(1):1}
for k in range(1,41):
 right_sum=sum((ell+1)*right_1.get(Rational(ell,2),0) for ell in range(k+1))
 diag_sum=sum(int((Rational(ell,2),Rational(ell,2)) in sectors) for ell in range(k+1))
 assert right_sum==(12 if k==1 else 15)
 assert diag_sum==2
check('all-level-right-and-full-diagonal-singlets',True,
      {'right_singlet_k1':12,'right_singlet_k2_plus':15,'full_spin4_singlet':2,
       'k_checked':[1,40],'basis':'multiplicity sum over H1 irreducibles'},
      'p4:thm:v261-fixed-momentum-reciprocity-bottleneck')
# Hopf U1 spectrum and inherited normalized traces at the comparison degree.
pos2={q:p(2,q) for q in [-2,-1,0,1,2]}
assert [pos2[q] for q in [-2,-1,0,1,2]]==[3,2,4,2,3]
assert sum(pos2.values())==14
assert sum([1,3,7,3,1])==15
check('degree-two-hopf-projector-trace-mismatch',True,
      {'position_weights':[3,2,4,2,3],'position_denominator':14,
       'momentum_weights':[1,3,7,3,1],'momentum_denominator':15,
       'projector_algebra_dimension':5},
      'p4:cor:v261-degree-two-strengthening')

out={'audit':'Paper4C','source_file':src.name,'source_sha256':hashlib.sha256(s).hexdigest(),'batch':1,'source_lines':[1,1862], 'checks':rec,'count':len(rec),'passed_count':sum(i['passed'] for i in rec),'scope':'Independent algebraic and finite-matrix controls; not physical realization; not full E3 for imported I/II/III results.'}
path=root/'staging/Evidence/Paper4C-Batch1IndependentChecks-v1_1.json';path.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'source_sha256':out['source_sha256'],'checks':out['count'],'all_passed':out['count']==out['passed_count'],'out':str(path)},indent=2))
