# Paper III-E — rigorous DAG verification, batch 02

**Frozen source:** `Paper3E-GravityAction-v1_190.tex`; SHA-256 `c09e1f6c834e784d593f12827045a22b184671324c5091f2e50b12e076e3119b`.

**Source coverage:** lines **1,212–2,133**, 14/115 formal claims, 10/92 proof environments, 7/30 formal remarks. Cumulative: **28/115 claims, 20/92 proofs, 8/30 remarks** through line 2,133.

**Current verdicts:** {'FORMALIZED': 4, 'VERIFIED': 1, 'VERIFIED-CONDITIONAL': 8, 'UNRESOLVED': 1}. One new issue; the two Batch 1 issues remain open. These classifications apply to exact theorem scopes, not all external physical realizations.

## Exhaustive source-anchored formal-claim ledger

| Claim ID | Line | Source label | Outcome |
|:--|--:|:--|:--|
| BH-IIIE-C-0015 | 1335 | `p3e:def:grav-closed-occurrence` | FORMALIZED |
| BH-IIIE-C-0016 | 1367 | `p3e:def:grav-smooth-expansion-domain` | FORMALIZED |
| BH-IIIE-C-0017 | 1380 | `p3e:thm:born-orbit-eh-identification` | VERIFIED |
| BH-IIIE-C-0018 | 1508 | `p3:def:f2_rescaled` | FORMALIZED |
| BH-IIIE-C-0019 | 1527 | `p3:def:projected-grav-scalar-operator` | FORMALIZED |
| BH-IIIE-C-0020 | 1548 | `p3:lem:scalar-remnant-laplacian` | VERIFIED-CONDITIONAL |
| BH-IIIE-C-0021 | 1586 | `p3e:thm:generated-gravitational-heat-role` | VERIFIED-CONDITIONAL |
| BH-IIIE-C-0022 | 1711 | `p3e:thm:general-closed-gravitational-readout` | UNRESOLVED |
| BH-IIIE-C-0023 | 1747 | `p3e:cor:native-heat-action-constructor` | VERIFIED-CONDITIONAL |
| BH-IIIE-C-0024 | 1775 | `p3:prop:EH_from_a2` | VERIFIED-CONDITIONAL |
| BH-IIIE-C-0025 | 1827 | `p3e:thm:fixed-scalar-and-active-weights` | VERIFIED-CONDITIONAL |
| BH-IIIE-C-0026 | 1929 | `p3:thm:EH-normalization-gauge` | VERIFIED-CONDITIONAL |
| BH-IIIE-C-0027 | 2014 | `p3e:cor:grav-heat-branch` | VERIFIED-CONDITIONAL |
| BH-IIIE-C-0028 | 2068 | `p3e:cor:singleton-heat-profile-fibre` | VERIFIED-CONDITIONAL |

## E1 source replay / E3 independent assessment

- **BH-IIIE-C-0015 (1335) — FORMALIZED:** Defines d_g-sector scalar Laplacian exponential and closing map. Noncompact trace/volume is expressly a different domain, not automatic global L1.
- **BH-IIIE-C-0016 (1367) — FORMALIZED:** Sufficient compact, boundaryless smooth 4d Riemannian domain for local heat asymptotics; not inferred from finite root.
- **BH-IIIE-C-0017 (1380) — VERIFIED:** Independent change-of-variables proof of integral naturality; 1/2+1/2=1 on j_B(g); no off-diagonal or finite matrix trace equality.
- **BH-IIIE-C-0018 (1508) — FORMALIZED:** Direct integral ∫0∞e^-u du=1 yields f2=(4π)^-2; process-relative convention, not gauge or matter moment.
- **BH-IIIE-C-0019 (1527) — FORMALIZED:** Explicit hypothesis class aΔ+E with a>0 and e^-tL 1=1; a generated minimal scalar branch, not generic spinorial Dirac-square.
- **BH-IIIE-C-0020 (1548) — VERIFIED-CONDITIONAL:** Differentiate unital semigroup at t=0: L1=E=0. Constant a absorbed as t_eff=at and Λ_eff²=Λ_g²/a; no claim of rigidity of generic bundle operator.
- **BH-IIIE-C-0021 (1586) — VERIFIED-CONDITIONAL:** Given occurring root and source-stated frozen local scalar role, Δ and P_W determine strongly continuous e^-tΔ and e^-τP_W. Semigroup/generator/domain/functoriality checked; co-realization inherits II-A constructor-origin/GP1 boundary, not all physical process tokens. No generic joint-heat-origin closure of prior BH-IIIB-G-0002 asserted.
- **BH-IIIE-C-0022 (1711) — UNRESOLVED:** Ordinary A_g ∈ L1 and Tr_H A_g are valid on compact smooth or finite scalar carriers. The stated noncompact relative/trace-per-volume alternative does not entail ordinary L1; theorem does not repeat the branch guard.
- **BH-IIIE-C-0023 (1747) — VERIFIED-CONDITIONAL:** On frozen claim-complete native heat-action owner with trace-class/localized readout, composition Δ→heat semigroup→closed scalar trace meets III-A pre-action grammar; no full physical effective-action owner is inferred.
- **BH-IIIE-C-0024 (1775) — VERIFIED-CONDITIONAL:** Independent scalar 4d Seeley–DeWitt a2=R/6 positive; Born 1/2+1/2 gives single copy; ambient τ8(P0)=1/8 yields f2Λ²/48. Only GRAV-ASYM smooth expansion, not finite-m_p heat coefficient.
- **BH-IIIE-C-0025 (1827) — VERIFIED-CONDITIONAL:** Heat a0/a2 terms and ambient τ8(P0)=1/8 match; active-state endpoint eigenvalues I8/8 and P0 imply e^S/8=1 and 1/8. Vanishing terminal Hessian also consumes MRESP visibility u(C)=0; renormalized vacuum not inferred.
- **BH-IIIE-C-0026 (1929) — VERIFIED-CONDITIONAL:** Algebraic if-and-only-if for EH coefficient ONLY: f2Λ²=f2′Λ′²; rescaling profile changes a0 and higher-heat outputs, so no whole-action physical equivalence asserted.
- **BH-IIIE-C-0027 (2014) — VERIFIED-CONDITIONAL:** Exponent integral and algebra give Λg²=96π²U; cell comparison Λg Rmom=24√(3π) remains an actual-owner conditional; raw joint 96U stays separate.
- **BH-IIIE-C-0028 (2068) — VERIFIED-CONDITIONAL:** For attained λ>0 in frozen minimal heat role, F=e^-u, f2=1/(16π²), and unique Λ²=96π²λ; profile invariance is valid only on this fibre and complete generated descendant scopes.

## New open source-anchored finding

### BH-IIIE-G-0003 — TYPE_OR_DOMAIN / MISSING_CONDITION (MODERATE)

**Earliest root:** `Paper3E-GravityAction-v1_190.tex:1711-1744`, `p3e:thm:general-closed-gravitational-readout`; controlling domain `Paper3E-GravityAction-v1_190.tex:1335-1377`.

**Issue:** The theorem asserts the unlocalized positive heat operator is in ordinary trace class `L¹(H_g)` and has an ordinary full carrier trace. The preceding definition explicitly allows noncompact parents only after their own trace-per-volume or relative-trace domain is supplied. Those alternatives do not entail `Tr_H_g(e^{-tΔ})<∞` or `e^{-tΔ}∈L¹(H_g)`.

**Independent in-domain branch test:** On flat `R⁴`, the scalar heat kernel diagonal is `(4πt)^−2`; a trace per unit volume is finite, but the unlocalized ordinary trace is infinite. Compact smooth `S⁴` is the positive control: its heat eigenvalue sum is finite for every `t>0`.

**What survives:** The theorem is verified on finite windows and compact smooth parents. The Einstein–Hilbert `a₂` derivation assumes the compact four-dimensional `(GRAV-ASYM)` parent, so this new finding does not invalidate the scoped EH coefficient or heat-profile law.

**Verified material path:** `p3e:def:grav-closed-occurrence` → `p3e:thm:generated-gravitational-heat-role` → `p3e:thm:general-closed-gravitational-readout` → `p3e:cor:native-heat-action-constructor` (latter requires trace-domain correction for noncompact action). No remote-papers path certified.

**Required certificate:** Declare finite/compact ordinary trace scope, or provide an explicit noncompact localized/relative/volume trace with a correctly typed output claim; do not infer ordinary L¹ from FSRΣ notation. This is not a refutation of the compact statement.

## Already-open and inherited issues

- **BH-IIIE-G-0001 (Batch 1):** seven-real-dimensional Clifford `W` versus half-spin `W_L⊕W_R` grading-carrier type ambiguity; unchanged.
- **BH-IIIE-G-0002 (Batch 1):** unique scheme-depth B transport does not alone choose a full spacetime M connection; unchanged.
- **BH-IIIB-G-0002 (previous III-B audit):** frozen full operator-square heat process/readout origin remains a general upstream obligation. The narrower III-E scalar metric-root construction must not be used to mark the generic issue globally resolved.

## E3 exact checks and spectral positive control

- **24 exact symbolic zero reductions passed**, including `1/2+1/2`, `τ8(P0)=1/8` vs `τ8(I8)=1`, `a₂=R/6`, `Λg²=96π² U`, `Λg Rmom=24√(3π)` under CELL, semigroup/projector matrix identities, and entropy endpoint weights.
- A separate numerical E3 test used the exact unit-round `S⁴` scalar spectrum `λℓ=ℓ(ℓ+3)`, `dℓ=(2ℓ+3)(ℓ+2)(ℓ+1)/6`, yielding the expected small-time heat trace `1/(6t²)+1/(3t)+29/90+O(t)`:

| t | Observed remainder after a₀,a₂ | Expected a₄ |
|--:|--:|--:|
| 0.030 | 0.328166652 | 0.322222222 |
| 0.010 | 0.324187795 | 0.322222222 |
| 0.005 | 0.323203031 | 0.322222222 |
| 0.002 | 0.322614072 | 0.322222222 |

## E4 attacks and scope verdicts

- **Valid:** noncompact heat trace per unit volume is finite without the unlocalized operator being trace class (G-0003).
- **Out-of-domain:** adding `ξR` to the minimal scalar generator violates unit preservation; replacing the Born-diagonal metric pair by unrelated off-diagonal metrics violates the theorem’s embedding hypothesis.
- **Not a contradiction:** optional profiles with the same EH coefficient can have different bare vacuum/high-curvature outputs; the normalization theorem is deliberately EH-only.
- **Not a contradiction:** the exact fixed finite Dirac-square trace is not a four-dimensional continuum heat coefficient. The source recognizes that missing operator/effective-action port explicitly.
- **Inherited, not duplicated:** Paper III-B’s full generic native-heat output-origin gap is preserved pending a licensed constructor certificate.

## Seven remarks and unnamed clauses

- **Line 1489** (p3e:rem:v2211-finite-smooth-action-port): VERIFIED SCOPE FIREWALL: finite physical D_x,p traces are not exact 4d scalar a2 coefficients; actual operator/effective action coefficient port left independent.
- **Line 1891** (p3:rem:corner-trace-convention): VERIFIED ambient rank-one scalar projector trace 1/8 versus full scalar multiplication trace 1.
- **Line 1912** (anonymous optional enlarged-profile normalization): VERIFIED for EH coefficient only; separate normalization of distinct output a0 not inferred.
- **Line 1996** (anonymous separate origins of 6, 2pi and Newton): VERIFIED symbolic identities; measured G and scalar/joint owner matching remain separate.
- **Line 2109** (anonymous additional profile representatives): SCOPE ONLY: optional representatives deferred; no alternative profile selected.
- **Line 2115** (anonymous kinematic carrier density): VERIFIED factor 1/8 unaffected by multiplying a separate sector-density comparison after closure.
- **Line 2124** (anonymous local Born-Liouville phase volume): SCOPE ONLY: CAL_hbar and separate widths/cell needed; no state count inferred here.

## Audit boundaries and next batch

- **No paper edits or new theory.** Source-to-observable boundaries maintained: compact scalar heat coefficient ≠ raw joint coefficient ≠ exact finite momentum trace ≠ physically normalized Newton coupling. Calibration and physical action/export ports remain independent where source says so.
- **Canonical conditions:** reuses `BH-IIIB-A-0007`, `BH-IIIB-A-0008`, and `BH-IIIB-A-0013` rather than duplicating their assumptions. First-occurrence reconciliation for new explicit trace-domain/GRAV-ASYM predicates remains a final atlas-integration task.
- **Baselines:** latest supplied DAG v1.102 and ProofChainAudits v1.20; no archive edited in this batch.
- **Next source range:** lines **2,134–3,100**, beginning with operational Lorentzian signature and causal chain.

**Companion machine-readable evidence:** `Paper3E-RigorousVerificationBatch02-v1_2.json`, including all per-claim import candidates, boundary records, E3 tests, and E4 negative evidence.**
