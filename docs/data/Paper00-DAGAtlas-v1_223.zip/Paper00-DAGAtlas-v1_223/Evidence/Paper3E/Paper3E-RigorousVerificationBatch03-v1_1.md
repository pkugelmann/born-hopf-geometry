# Paper III-E — Rigorous verification, batch 03 (causal/spectral/dilation segment)

**Frozen source:** `Paper3E-GravityAction-v1_190.tex`; SHA-256 `c09e1f6c834e784d593f12827045a22b184671324c5091f2e50b12e076e3119b`.
**Corpus:** `Paper00-PapersMinimal-v2_370` (unchanged); **protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md`.

**Coverage:** lines **2,134–3,237**; **22/115** source formal claims, **19/92** proof environments, **6/30** formal remarks; **36/36** independent exact symbolic controls passed. The batch includes the complete dilation proof and complete conformal-cutoff theorem, rather than ending mid-theorem at line 3,100.

**Verdicts (this batch):** **3 VERIFIED**, **17 VERIFIED-CONDITIONAL**, **2 FORMALIZED**. No new source-supported mathematical issue was established; the previously recorded Paper III-E findings G-0001, G-0002 and G-0003 remain open and distinct. The noncompact branch of G-0003 is inherited by the readout scope in lines 2,835–2,868 but is not counted again.

## Complete source-bound claim ledger

| ID | Lines | Claim label | Verdict | Independent/core qualification |
|:--|:--|:--|:--|:--|
| BH-IIIE-C-0029 | 2157–2190 | `p3:thm:lorentzian-signature` | VERIFIED-CONDITIONAL | Solve Q=Aτ²+B|ξ|² vanishing on |ξ|=cτ: A=-Bc², B>0. The existence of every tangent sphere direction… |
| BH-IIIE-C-0030 | 2214–2269 | `p3e:thm:clock-hopf-null-ray-geometry` | VERIFIED-CONDITIONAL | Independent 2x2 Lorentz Gram calculation and quotient period cT=2πR, all exact. |
| BH-IIIE-C-0031 | 2294–2323 | `p3e:cor:null-coframe-frobenius-boundary` | VERIFIED-CONDITIONAL | Independent dual basis Gram computation and exterior-product two-term check: (±c dt∧dη+η∧dη)/2≠0; on… |
| BH-IIIE-C-0032 | 2336–2361 | `p3e:thm:positive-null-generator-components` | VERIFIED-CONDITIONAL | Independent boundary/strict-cone substitution E=c||p||+δ verifies nonnegative components and… |
| BH-IIIE-C-0033 | 2373–2390 | `p3e:def:lf-ray-geometry-package` | FORMALIZED | Type census checks N± tangent, ℓ± cotangent, γ families, p± generator germs; no cross-owner promotion. |
| BH-IIIE-C-0034 | 2392–2438 | `p3:cor:chiral-projective-null-directions` | VERIFIED-CONDITIONAL | Direct Pauli determinant and right Weyl contragredient group-automorphism computation. |
| BH-IIIE-C-0035 | 2470–2488 | `p3e:cor:projective-primal-dual-null-ray` | VERIFIED-CONDITIONAL | Independent support pairing qn(vn)=c−c=0; unique spatial unit n fixes a dual support ray. |
| BH-IIIE-C-0036 | 2490–2518 | `p3:cor:causal-scalar-principal-part` | VERIFIED-CONDITIONAL | Independent Hamilton equations, symplectic Jacobian det=1, coefficient rescaling b→ab, and Legendre… |
| BH-IIIE-C-0037 | 2549–2606 | `p3:thm:minimal-local-scalar-cone-order` | VERIFIED-CONDITIONAL | Direct principal symbol differentiation and characteristic ratio |ξ|/τ=√(b/a); independent polar… |
| BH-IIIE-C-0038 | 2643–2656 | `p3e:thm:primitive-scalar-support-ancestry` | VERIFIED-CONDITIONAL | The unique irreducible trivial real representation is the tensor-unit R; second distinguishable copy… |
| BH-IIIE-C-0039 | 2672–2700 | `p3e:thm:metric-principal-descendant-saturation` | VERIFIED-CONDITIONAL | Independent algebra comparing quadratic zero sets: proportionality forces b/a=c_op², whereas an… |
| BH-IIIE-C-0040 | 2721–2764 | `p3:def:paper-iv-finite-field-input` | FORMALIZED | Type check scalar Laplacian nonnegative, A1=0; domain separates full smooth-parent differential… |
| BH-IIIE-C-0041 | 2766–2791 | `p3:thm:p3-p4-lorentzian-chain-closure` | VERIFIED-CONDITIONAL | Independent mode substitution and exact mass shell E²=c²(ℏ²λ)+μ²c⁴. |
| BH-IIIE-C-0042 | 2815–2823 | `p3:cor:closed-lorentzian-dilation-constraint` | VERIFIED-CONDITIONAL | Independent determinant density/Jacobian square confirms no causal-field Hamiltonian used in the… |
| BH-IIIE-C-0043 | 2835–2855 | `p3:cor:wick-from-gp-constitution` | VERIFIED-CONDITIONAL | Independent distinction: a single number Tr e^(−tΔ) cannot determine a two-point correlation kernel;… |
| BH-IIIE-C-0044 | 2900–2928 | `p3:prop:spectral-gap-mass-upgrade` | VERIFIED-CONDITIONAL | Direct monotonicity of ℏ²c²λ+μ²c⁴ in λ, with positive λmin; λ=0 remains lower if included, so… |
| BH-IIIE-C-0045 | 2973–3006 | `p3e:thm:compact-haar-born-balance` | VERIFIED | Independent uniqueness of Haar and product pushforward theorem; symbolic S³ volume density… |
| BH-IIIE-C-0046 | 3023–3030 | `p3e:cor:haar-effective-balance-firewall` | VERIFIED | Independent smooth conformal rescaling g_p=c^(1/2) β_*g_x changes 4d effective volume ratio to c… |
| BH-IIIE-C-0047 | 3040–3054 | `p3e:cor:born-diagonal-effective-density-balance` | VERIFIED-CONDITIONAL | For any diffeo β, determinant density transformation gives β*dμ_β*g=dμ_g; conformal 4d off-diagonal… |
| BH-IIIE-C-0048 | 3081–3126 | `p3:thm:dilation_identity` | VERIFIED-CONDITIONAL | Independent exact determinant and positive-square calculation; explicitly test nonunit J and J=1… |
| BH-IIIE-C-0049 | 3187–3199 | `p3:cor:dilation_linear` | VERIFIED-CONDITIONAL | Independent exact symbolic substitution. The relation is linear in μx and μp with temporal scales… |
| BH-IIIE-C-0050 | 3216–3224 | `p3:thm:conformal-compactification-cutoff` | VERIFIED | Independent simple Lie algebra → compact u(N) obstruction (kernel all or injective; injective… |

## E1 replay, E3 independent checks and E4 adversarial outcomes

### 1. Exact GP1 cone and metric conformal signature, lines 2,134–2,212
The upstream Paper III-A `p3:thm:gp1-speed-calibration` at lines 2,368–2,440 bounds each generated velocity by the clock–Hopf constant, and `p3:cor:gp1-round-causal-envelope` at 2,443–2,474 uses actually licensed round isometry conjugations to attain every tangent sphere direction. The convex envelope is therefore **exactly** the full ball, not merely a ball-shaped upper bound. Paper I-C, under the Paper I-B label `p1b:prop:local-coframe`, establishes coframe/cone uniqueness. Independent check: an O(3)-invariant quadratic form `A τ²+B|ξ|²` zero on `|ξ|=cτ` forces `A=−Bc²`, up to nonzero scalar sign. Conditional only on the established `(CAUS)`/`CAL_t` domain; no field equation or measured light propagation assumed.

### 2. Clock–Hopf ray, Frobenius and chiral null directions, lines 2,214–2,489
The oriented II-D principal-to-metric normalization and III-A contragredient action make `N±=(c⁻¹∂t ± eH)/√2` well typed. Independent Gram and dual-coframe calculations verify `g(N±,N±)=0`, `g(N+,N−)=−1`, `ℓα(Nβ)=δαβ`, and `g⁻¹(ℓ±,ℓ±)=0`. A full quotient orbit turn is `s=√2 cT=√2 2πR`; neither null helix closes on the elapsed universal cover. The nonzero contact component `η∧dη` certifies the Frobenius obstruction, but the clock–Hopf 2D orbit cylinder admits local `x±` coordinates.

In the positive polar `E≥c||p||`, `|p_H|≤||p||` establishes both `p±≥0`. The upstream II-E spinor theorem supplies the left C² map and the **conjugate-dual**, not ordinary left, right action. Direct Pauli determinant and a nontrivial complex SL(2,C) right-Weyl composition test pass. This is projective local geometry, not a finite-QCD operator or a chosen physical ray; Paper VII-B explicitly consumes it only as the LF-A geometry package.

### 3. Local scalar order, undeformed principal and energy threshold, lines 2,490–2,947
An O(3)-invariant **scalar** first-order principal form has no spatial generator; the least spatially propagating scalar principal order is two. The PDE principal symbol `aω²−b|k|²` has Hamilton base speed squared `b/a`. The separately normalized positive Hamiltonian `H=(a π²+b|∇φ|²)/2` has speed squared **`ab`**, because its symbol is in a different coefficient convention; the symplectic rescaling `φ′=φ/√a, π′=√a π` reconciles the two. No inconsistent factor was found. The same-owner undeformed branch freezes the relative temporal/spatial quadratic owner, and then the characteristic front saturates `c_op`; other media may remain strictly slower.

A separately constituted neutral real tensor-unit support does **not** determine speed; II-A independently requires principal ancestry and smooth hyperbolic finite propagation. In the conservative smooth-parent free-law domain, formal selfadjointness kills real time drift, the nonnegative rest term is an explicit stability condition, and substitution on each finite eigenblock gives `E²=ℏ² c_field² λ+μ² c_field⁴`. The threshold claims concern a selected positive-gap block; the zero mode is not silently removed from every scalar spectrum.

### 4. Euclidean heat reconstruction scope, lines 2,835–2,898
The scalar heat trace is valid on the finite or compact ordinary-trace owner. A scalar trace is **not** a Euclidean quantum two-point kernel, and no automatic `(WICK_2cyc)`, `(WICK_same)`, finite reflection-positive reconstruction, or interacting infinite-volume continuation is inferred. The noncompact ordinary-L¹ issue from Batch 2 (`BH-IIIE-G-0003`) is inherited without duplication. Paper IV finite kernel reconstructions are later, conditional consumer results, not independent premises for the III-E Lorentzian sign.

### 5. Haar, Born-diagonal metric density and cubic Jacobian, lines 2,958–3,203
Haar uniqueness independently proves that a compact group isomorphism pushes normalized Haar to normalized Haar. The Born factor exchange preserves the compact product but **does not** constrain arbitrary separately chosen effective density factors. In four dimensions the III-G off-diagonal witness `g_p^(c)=c^(1/2) β_*g_x` has volume-density ratio `c`, despite unchanged compact Haar measures. On the **generated diagonal**, however, `β*dμ_{β_*g}=dμ_g` is an exact diffeomorphism identity. With `J_B` the absolute coordinate Jacobian, the two diagonal Lorentzian sector determinants give **`λ_x³ λ_t = J_B² λ_p³ λ_E`**, which reduces to the historical Jacobian-free formula only for `J_B=1`. The `μ_x=λ_x³, μ_p=λ_p³` form is linear in the two volume variables with the temporal/Jacobian coefficients held fixed.

### 6. Conformal compactification and finite unitary no-go, lines 3,206–3,237
The smooth compactification `(S³×S¹_conf)/Z₂` and its Einstein static universal cover `S³×R` are standard. Independently, a nontrivial continuous finite-dimensional unitary representation of connected noncompact simple `SO_0(2,4)` would give an injective Lie-algebra map into compact `u(N)`, which is impossible; `P U(g) P` generally violates the group product law by the omitted cross-band term `P U(g1)(I−P)U(g2)P`. Nonunitary finite algebraic conformal representations are expressly not excluded.

**Independent machine algebra:** 36 exact checks (36 zero residuals) in `Paper3E-Batch03-IndependentChecks-v1_1.json`, with reproducible script `Paper3E-Batch03-IndependentChecks-v1_1.py`. These are supplemented by theorem-level independent arguments, not represented as physical process certificates.

## E4 attack register

- **E4-IIIE-B03-001 — REJECTED-AFTER-IMPORT:** A GP1 speed bound alone might bound only an axis, not the full sphere. **Disposition:** III-A exact convex-envelope corollary consumes actual O(3) tangent isotropy and Hopf-orbit conjugates, establishes all sharp boundary directions.
- **E4-IIIE-B03-002 — PASSED-CONTROL:** Check contragredient inverse-action sign, geodesic/nonperiodic cover, and finite common quotient period. **Disposition:** Source transports oriented pair (eta0,xi0) natively; independently calculated N± periods agree, and cover clock displacement prevents closure.
- **E4-IIIE-B03-003 — FAILED-COUNTEREXAMPLE-CONFIRMS-OBSTRUCTION:** Try to find global functions x± with dx±=ell± on R×S3 despite contact curvature. **Disposition:** dell±=±deta/√2 nonzero; eta∧deta nonzero contact 3-form, and each ell wedge dell nonzero.
- **E4-IIIE-B03-004 — REJECTED-BY-SCOPE:** An O(3)-invariant first-order scalar symbol might already produce spatial fronts. **Disposition:** Scalar O(3) invariant linear symbol proportional to omega; base Hamilton projection has zero spatial component. Matrix/Dirac first-order operators are different target sort.
- **E4-IIIE-B03-005 — INVALID-OUT-OF-DOMAIN:** Take second-order scalar principal form omega²−v²|k|² with 0<v<c_op. **Disposition:** Admissible for cone-faithful medium branch, but changes temporal/spatial relative principal owner and violates explicit undeformed same-owner hypothesis.
- **E4-IIIE-B03-006 — INVALID-OUT-OF-DOMAIN:** Add stationary damping gamma partial_t, which changes dispersion. **Disposition:** Formal selfadjointness on invariant product measure is explicit and excludes any real nonzero time-drift coefficient.
- **E4-IIIE-B03-007 — SCOPE-QUALIFIER-NO-REFUTATION:** Include constant Laplace zero mode, below first nonzero eigenvalue. **Disposition:** Proposition concerns positive imported lambda_min on selected gapped block, not full spectrum bottom when zero mode retained.
- **E4-IIIE-B03-008 — VALID POSITIVE FIREWALL WITNESS:** Scale g_p=c^(1/2) beta_*g_x (c!=1) and seek Haar invariance with effective balance violation. **Disposition:** Volume density scales by c in four dimensions while normalized compact Haar remains invariant. No attack on Born-diagonal claim.
- **E4-IIIE-B03-009 — REJECTED-AS-SOURCE-ALREADY-QUALIFIED:** Use nonunit Jacobian and independent effective metrics to invalidate Jacobian-free formula. **Disposition:** Source retains J_B² explicitly and requires g_p=beta_*g_x; independent metrics are excluded.
- **E4-IIIE-B03-010 — INHERITED ISSUE BH-IIIE-G-0003:** Extend ordinary heat trace unqualified to noncompact parent. **Disposition:** Compact proof controls actual readout; general noncompact theorem already recorded unresolved in Batch 2. No duplicate issue introduction.
- **E4-IIIE-B03-011 — INVALID-OUT-OF-DOMAIN:** Use finite 2x2 Weyl representation of SL(2,C) to contradict finite conformal no-go. **Disposition:** Finite Weyl boosts and conformal representations are nonunitary; no-go concerns nontrivial exact finite-dimensional unitary action of connected noncompact simple group.
- **E4-IIIE-B03-012 — INVALID-AUTOMATIC-PROMOTION:** Identify derived null geometry automatically with a physical QCD light-front source or hadron alignment. **Disposition:** Source explicitly excludes physical operator/state/limit and Paper7B uses separate LF-A to LF-D typed packages.

## Scope and imported ancestry

The source-boundary review records four typed separation certificates (`BND-IIIE-B03-001` through `004`): operational cone/ray token, scalar principal/field occurrence, Haar/effective-density owner, and smooth conformal/finite-carrier representation. They are stored in the machine ledger. Source-verified imports were bounded to Paper III-A cone and polar, Paper I-C coframe, Paper II-D Hopf normalization, Paper II-E Weyl chiral ray, Paper II-A support/principal inheritance, and Paper III-G two technical-appendix interfaces; these peer papers have **not** been independently audited here.

**Material downstream uses confirmed (without full remote audit):** `p3:thm:lorentzian-signature` → Paper IV-A `p4:thm:three-map-bridge` at 1409–1417; `p3:thm:p3-p4-lorentzian-chain-closure` → Paper IV-B `p4:thm:finite-one-particle-dispersion` at 1957–1968; `p3e:def:lf-ray-geometry-package` → Paper VII-B `p11:def:hadronic-distribution-package` at 2390–2404. The last retains independent operator, state and limit ports. No new issue propagation from Batch 3 was established.

## Open findings and continuation

- **BH-IIIE-G-0001 (moderate):** Clifford `W_7` versus spin-grading `W_L⊕W_R` type declaration, from Batch 1; no new source contradiction here.
- **BH-IIIE-G-0002 (moderate):** CRP4 scheme–depth B connection does not by itself uniquely fix the full B×M connection, from Batch 1; no new effect established here.
- **BH-IIIE-G-0003 (moderate):** noncompact relative/volume trace does not entail ordinary unlocalized heat operator trace class, from Batch 2; restricted finite/compact heat readout remains valid and is used in this batch.

**Cumulative:** lines **1–3,237**, **50/115 formal claims**, **39/92 proofs**, **14/30 remarks**. This is **PARTIALLY AUDITED**, with 3 currently open Paper III-E findings. The total claim count includes definitions and all named proposition/theorem/corollary results. **No new gap/assumption nodes are inserted into the canonical global atlas in this intermediate batch**, avoiding duplicate first-occurrence conditions. Final merging and schema/ZIP verification remain deferred until every Paper III-E source claim has been examined.

**Next batch:** lines **3,238 onward** through the maximal complete hierarchy-response proof unit that can be finished without ending inside a theorem; target about **4,300** (adjust to proof boundary). The supplied DAG Atlas v1.102, ProofChainAudits v1.20 and papers corpus v2.370 remain unchanged.
