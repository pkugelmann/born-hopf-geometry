# Paper III-E — Rigorous verification, Batch 06 (final source slice)

**Frozen source:** `Paper3E-GravityAction-v1_190.tex` (`c09e1f6c834e784d593f12827045a22b184671324c5091f2e50b12e076e3119b`); framework v2.370.
**Lines audited:** 5612–6449; 14/14 declarations and proof environments, 7/7 remarks; 127/127 independent controls passed.
**Batch verdicts:** VERIFIED=3, VERIFIED-CONDITIONAL=11. **New issue:** `BH-IIIE-G-0007` (reference locator only).

## 1. Every formal statement and source-replayed proof

| Claim ID | Source lines | Source label | Evidence-backed status |
|---|---:|---|---|
| BH-IIIE-C-0102 | 5809–5830 | `p3e:cor:v2216-local-global-response-scope` | VERIFIED-CONDITIONAL |
| BH-IIIE-C-0103 | 5872–5886 | `p3e:prop:v319-petersen-gravity-firewall` | VERIFIED-CONDITIONAL |
| BH-IIIE-C-0104 | 5912–5930 | `p3e:thm:v346-cell-scale-independence` | VERIFIED-CONDITIONAL |
| BH-IIIE-C-0105 | 5967–5992 | `p3e:thm:v229-conormal-cap` | VERIFIED-CONDITIONAL |
| BH-IIIE-C-0106 | 6005–6017 | `p3e:cor:v229-rooted-amplitude` | VERIFIED-CONDITIONAL |
| BH-IIIE-C-0107 | 6037–6054 | `p3e:prop:v229-source-counterfamily` | VERIFIED-CONDITIONAL |
| BH-IIIE-C-0108 | 6075–6082 | `p3e:prop:v229-complete-cap-injective` | VERIFIED |
| BH-IIIE-C-0109 | 6106–6146 | `p3e:prop:v289-cap-source-ward` | VERIFIED-CONDITIONAL |
| BH-IIIE-C-0110 | 6209–6237 | `p3e:thm:v353-positive-schur` | VERIFIED-CONDITIONAL |
| BH-IIIE-C-0111 | 6248–6267 | `p3e:prop:v353-schur-jet` | VERIFIED-CONDITIONAL |
| BH-IIIE-C-0112 | 6275–6294 | `p3e:prop:v353-schur-orientation` | VERIFIED |
| BH-IIIE-C-0113 | 6320–6334 | `p3e:prop:v356-whole-action-jet-criterion` | VERIFIED |
| BH-IIIE-C-0114 | 6369–6393 | `p3e:prop:v358-finite-reduction-covariance` | VERIFIED-CONDITIONAL |
| BH-IIIE-C-0115 | 6404–6429 | `p3e:cor:v358-gaussian-newton-measure` | VERIFIED-CONDITIONAL |

### BH-IIIE-C-0102: Local source certification and global response have distinct scope
- **Source/label:** `p3e:cor:v2216-local-global-response-scope`, lines 5809–5830; proof 5831–5847.
- **E1 replay:** Two integrations fix the affine freedom from f(C)=0,f’(C)=1. Differentiating R f’−f gives R f’’ and hence P=C+∫_C^R t D2(t)χ7(t)dt. The claim does not identify the raw Laurent Euler excess with this metric Euler function. Source III-D provides a distinct non-gluing certificate.
- **E3:** 6 targeted exact/numerical controls, see machine-readable independent ledger. Controls of this sort do not alone establish physical occurrence.
- **Typed scope:** Actual EXJET7 is local; global coefficient requires owned smooth second-jet transport, endpoint/source/boundary and physical normalization.
- **Exact imported prerequisites checked:** `p3d:thm:v2216-exjet-global-obstruction`, `p3d:cor:v2216-raw-euler-nongluing`, `p3d:prop:v2216-finite-born-limits`, `p3d:thm:v2216-complete-action-jets`

### BH-IIIE-C-0103: No automatic metric, Newton, or curvature correction
- **Source/label:** `p3e:prop:v319-petersen-gravity-firewall`, lines 5872–5886; proof 5887–5894.
- **E1 replay:** Existing 15-dimensional edge representations on each marked quaternionic factor yield 225=120+105 in symmetric/antisymmetric exchange eigenspaces. Availability of this auxiliary tensor does not alter the uninserted metric/operator/physical action.
- **E3:** 2 targeted exact/numerical controls, see machine-readable independent ledger. Controls of this sort do not alone establish physical occurrence.
- **Typed scope:** The conclusion is about non-insertion, not a no-go for an independently derived sourced finite anisotropy.
- **Exact imported prerequisites checked:** `p1b:thm:petersen-factor-exchange`

### BH-IIIE-C-0104: Exact scale residual and an independent cutoff counterfamily
- **Source/label:** `p3e:thm:v346-cell-scale-independence`, lines 5912–5930; proof 5931–5942.
- **E1 replay:** From U=Λg²/(96π²), Kp=6/Rmom² and ρH=3/π, U/(ρHKp)=(Λg Rmom)²/(24√(3π))². Changing Λg→sΛg at fixed pre-port momentum data shifts the residual by 2log(s).
- **E3:** 3 targeted exact/numerical controls, see machine-readable independent ledger. Controls of this sort do not alone establish physical occurrence.
- **Typed scope:** This mathematical counterfamily is pre-port only, not an actual licensed physical cutoff variation.
- **Exact imported prerequisites checked:** No additional indispensable remote theorem beyond the stated action/definition and source hypotheses.

### BH-IIIE-C-0105: Full conormal flux realization and absolute weight
- **Source/label:** `p3e:thm:v229-conormal-cap`, lines 5967–5992; proof 5993–6003.
- **E1 replay:** For common positive K0 and GK0, constrained p0+p1=j stationary equations yield p0=j/(1+G),p1=Gj/(1+G) and positive minimum 〈j,K0^-1 j〉/[2(1+G)]. The transported source covariance commuting with UR makes the all-column norm b²γN²R²d0. Matching 2Δ requires b²γN²d0=4Δ.
- **E3:** 8 targeted exact/numerical controls, see machine-readable independent ledger. Controls of this sort do not alone establish physical occurrence.
- **Typed scope:** Inherited Paper I-B operator-domain positivity, full homothety and source-column covariance; physical b, normal operator and density remain unselected.
- **Exact imported prerequisites checked:** `p1b:prop:v229-affine-conormal`, `p1b:thm:v229-coupled-homothety`

### BH-IIIE-C-0106: Evaluated amplitude target for the rooted block
- **Source/label:** `p3e:cor:v229-rooted-amplitude`, lines 6005–6017; proof 6018–6024.
- **E1 replay:** The singlet spectral weights of the rooted positive 2x2 A block give 〈KD〉=Q_D. Paper I-B exact conormal theorem makes d0=Q_D/μ². Substitution of γN=μ/Rs into the preceding cap-amplitude target yields b_req²=4Δ Rs²/Q_D.
- **E3:** 9 targeted exact/numerical controls, see machine-readable independent ledger. Controls of this sort do not alone establish physical occurrence.
- **Typed scope:** Only on the frozen constant two-partner block with the same source, normal-bag and shared operator domain; b_req is a comparison target.
- **Exact imported prerequisites checked:** `p1b:thm:v229-conormal-response`, `p3e:thm:v229-conormal-cap`

### BH-IIIE-C-0107: Geometric anchors alone do not select the source
- **Source/label:** `p3e:prop:v229-source-counterfamily`, lines 6037–6054; proof 6055–6069.
- **E1 replay:** h is nonnegative and reciprocal; its polynomial factor has double zeros at x²=C/U and U/C. The remaining factor vanishes at x=1 and at 0,∞. The inequality [2/(1+G)]h/t² ≤ 2(1+G)(G²−2)²/G⁸≤4 gives Bε<BI for 0<ε<1/4. Nonzero h away from anchors changes B.
- **E3:** 24 targeted exact/numerical controls, see machine-readable independent ledger. Controls of this sort do not alone establish physical occurrence.
- **Typed scope:** The deformed current is a mathematically admissible comparison; physical occurrence is expressly not claimed.
- **Exact imported prerequisites checked:** `p3e:thm:v229-conormal-cap`

### BH-IIIE-C-0108: The retained inverse-square source cannot hide a coefficient mismatch
- **Source/label:** `p3e:prop:v229-complete-cap-injective`, lines 6075–6082; proof 6083–6085.
- **E1 replay:** Differentiation yields d_B[R²B−σ²/B²]=R²+2σ²/B³>0 for B>0. Hence a common complete density at fixed R and σ forces the same B.
- **E3:** 5 targeted exact/numerical controls, see machine-readable independent ledger. Controls of this sort do not alone establish physical occurrence.
- **Typed scope:** Pointwise fixed R and fixed source σ; not a statement about retuning the source or boundary.
- **Exact imported prerequisites checked:** No additional indispensable remote theorem beyond the stated action/definition and source hypotheses.

### BH-IIIE-C-0109: One-anchor differential certificate for the complete inverse-square source
- **Source/label:** `p3e:prop:v289-cap-source-ward`, lines 6106–6146; proof 6147–6161.
- **E1 replay:** The derivative of T^-1 is −T^-1 T’ T^-1, so s’=2〈j’,T^-1j〉−〈T^-1j,T’T^-1j〉. Multiplying by B² gives exact differential (B²s)’; connectedness plus one reference fixes σ². For the 4x4 port full-column trace T_s^-1=4/b² yields B²s=(BI Rs)².
- **E3:** 14 targeted exact/numerical controls, see machine-readable independent ledger. Controls of this sort do not alone establish physical occurrence.
- **Typed scope:** Valid for positive C1 B,T and C1 j on a connected interval with a reference. No physical native operator/current determination from Ward algebra.
- **Exact imported prerequisites checked:** `p3e:thm:v223-cap-source`

### BH-IIIE-C-0110: Positive two-channel Schur characterization
- **Source/label:** `p3e:thm:v353-positive-schur`, lines 6209–6237; proof 6238–6246.
- **E1 replay:** The block inverse top compression equals S_+^-1, and with J=(Rs/√2)P+ the trace is −Rs² Tr_{E+}S_+^-2/16. Rank2 S+=bI gives −Rs²/(8b²). For A=D=I, bI iff CC†=u²I, yielding unitary polar factor for u≠0.
- **E3:** 25 targeted exact/numerical controls, see machine-readable independent ledger. Controls of this sort do not alone establish physical occurrence.
- **Typed scope:** Positive Hermitian 2+2 comparison source and normalized frame; does not prove the actual Dirac DtN map equals this finite model.
- **Exact imported prerequisites checked:** `p3e:def:v223-cap-data`

### BH-IIIE-C-0111: Exact first curvature-jet target
- **Source/label:** `p3e:prop:v353-schur-jet`, lines 6248–6267; proof 6268–6273.
- **E1 replay:** Two derivatives of S=A−CD^-1C† at C(0)=0 give S’(0)=A’(0), S’’(0)=A’’(0)−2C’(0)C’(0)†. From t=R/(2Rs)+O(R³), b’’(0)=−c²/(2Rs²).
- **E3:** 2 targeted exact/numerical controls, see machine-readable independent ledger. Controls of this sort do not alone establish physical occurrence.
- **Typed scope:** Requires C² regularity through reference R=0 and the specifically justified normalization at R=0; native equality is a test.
- **Exact imported prerequisites checked:** `p3e:thm:v353-positive-schur`

### BH-IIIE-C-0112: Scalar-source non-identifiability
- **Source/label:** `p3e:prop:v353-schur-orientation`, lines 6275–6294; proof 6295–6300.
- **E1 replay:** For K_U off-diagonal uU, Schur block bI gives common scalar trace but mixed inverse block −uU/b retains U orientation. Separate Sε diagonal positive examples have identical Tr Sε^-2=2/b² while not proportional to the identity.
- **E3:** 9 targeted exact/numerical controls, see machine-readable independent ledger. Controls of this sort do not alone establish physical occurrence.
- **Typed scope:** A scalar return alone cannot identify current orientation, full response or same-source coupling.
- **Exact imported prerequisites checked:** `p3e:thm:v353-positive-schur`

### BH-IIIE-C-0113: Equivalent first-jet and action matching
- **Source/label:** `p3e:prop:v356-whole-action-jet-criterion`, lines 6320–6334; proof 6335–6344.
- **E1 replay:** On a connected open regular source chart, zero differential of S_phys−zS_J implies constant difference, and the converse follows by differentiation. The x,y example matches the EH x coefficient at z=1/96 but differs in source y curvature.
- **E3:** 1 targeted exact/numerical controls, see machine-readable independent ledger. Controls of this sort do not alone establish physical occurrence.
- **Typed scope:** One constant z and all retained variations on one connected chart; physical projection itself not generated.
- **Exact imported prerequisites checked:** `p3e:prop:v2211-whole-action-newton-certificate`

### BH-IIIE-C-0114: Exact finite reduction covariance test
- **Source/label:** `p3e:prop:v358-finite-reduction-covariance`, lines 6369–6393; proof 6394–6402.
- **E1 replay:** Differentiation under positive finite integration gives z〈S_u〉_z and Hessian z〈S_uv〉−z² Cov_z(S_u,S_v)/hbar. Differentiating the normalized expectation with respect to z gives −Cov_z(S_u,S)/hbar and the oriented integral from 1 to z.
- **E3:** 11 targeted exact/numerical controls, see machine-readable independent ledger. Controls of this sort do not alone establish physical occurrence.
- **Typed scope:** Source-independent internal measure and legal interchange; if external source-dependent density is present it contributes additional terms.
- **Exact imported prerequisites checked:** No additional indispensable remote theorem beyond the stated action/definition and source hypotheses.

### BH-IIIE-C-0115: Gaussian determinant and measure criterion
- **Source/label:** `p3e:cor:v358-gaussian-newton-measure`, lines 6404–6429; proof 6430–6435.
- **E1 replay:** Complete the Gaussian square with source-dependent positive K and common density rho(x)dy: Γ_z=z S_red+(hbar/2)ln detK−hbar ln rho+(m hbar/2)ln z + constant. Therefore dΓ_z−z dΓ_1=hbar(1−z)d ln(sqrt(detK)/rho). K=e^{x²},rho=1 yields zero first derivative but nonzero Hessian at 0.
- **E3:** 7 targeted exact/numerical controls, see machine-readable independent ledger. Controls of this sort do not alone establish physical occurrence.
- **Typed scope:** Gaussian-specific source-dependent measure, identical for all z; extra measure requirement is not a Born–Hopf physical measure selection.
- **Exact imported prerequisites checked:** `p3e:prop:v358-finite-reduction-covariance`

## 2. Formal remarks

| Lines | Remark | Disposition |
|---|---|---|
| 5896–5905 | A possible sixfold angular diagnostic, not a gravitational source | FORMALIZED-SCOPE |
| 5943–5953 | Physical owner status | FORMALIZED-SCOPE |
| 6087–6100 | What the conormal theorem establishes | SOURCE_REFERENCE_UNRESOLVED |
| 6162–6169 | Scope of the one-anchor test | FORMALIZED-SCOPE |
| 6302–6313 | Native-source firewall and dependence | FORMALIZED-SCOPE |
| 6346–6355 | Separate physical matching obligation | FORMALIZED-SCOPE |
| 6437–6446 | Physical projection remains an independent gate | FORMALIZED-SCOPE |

## 3. Source-local G-0007 certificate

- **ID:** BH-IIIE-G-0007; `DAG_COVERAGE / MISSING_EVIDENCE`; MINOR; OPEN.
- **Origin:** `Paper3E-GravityAction-v1_190.tex:6095–6099`, `p3e:rem:v229-native-selection`.
- **Exact failure:** `p3f:sec:v229-action-tests` is not defined in any `.tex` source of the authoritative `Paper00-PapersMinimal-v2_370` archive. An apparently related section `p3f:sec:v229-cap-uv-hessian` occurs at Paper III-F:9071, but cannot be substituted without checking intent and coverage.
- **E3/E4:** complete reference-label census; no proof step in the conormal flux theorem requires the dangling locator.
- **Impact:** navigability and source-matched downstream-reference certificate only; no established mathematical refutation or physical prediction effect.
- **Resolution requirement:** locate current intended Paper III-F section/results and replace/migrate the reference in an explicitly separate source-editing task. The audit leaves source unchanged.

## 4. E4 adversarial challenges

| ID | Attack | Disposition |
|---|---|---|
| E4-IIIE-B06-001 | Infer a global physical metric from local EXJET7 Hessian alone | REJECTED-BY-SOURCE |
| E4-IIIE-B06-002 | Read Petersen auxiliary 120-dimensional exchange eigenspace as a new 120-element 2I action | OUT-OF-DOMAIN |
| E4-IIIE-B06-003 | Vary cutoff s at fixed momentum and falsely claim true physical history | INVALID-PHYSICAL-PROMOTION |
| E4-IIIE-B06-004 | Assert conormal b=1 follows from unit incoming singlet | REJECTED |
| E4-IIIE-B06-005 | Retain only one conormal source column | OUT-OF-DOMAIN |
| E4-IIIE-B06-006 | Conclude finite reciprocal midpoint and endpoints determine unique source profile | VALID-COUNTERFAMILY |
| E4-IIIE-B06-007 | Use a variable physical sigma to evade injection at fixed sigma | OUT-OF-DOMAIN |
| E4-IIIE-B06-008 | One reference s and Ward only at one point imply s=σ²/B² globally | VALID-REJECTION |
| E4-IIIE-B06-009 | Scalar Schur inverse-square return determines unitary channel orientation | VALID-NONIDENTIFIABILITY |
| E4-IIIE-B06-010 | Treat C(0)=0 as sufficient to fix A(0),D(0) and Schur first jets | OUT-OF-DOMAIN |
| E4-IIIE-B06-011 | Gravity-only EH coefficient matching proves all-direction physical action equality | VALID-COUNTEREXAMPLE |
| E4-IIIE-B06-012 | Assume quantum first-jet scaling follows from classical action factor at fixed hbar | VALID-OBSTRUCTION |
| E4-IIIE-B06-013 | Treat nonexistent PaperIII-F cap-test section label as verified proof import | VALID-SOURCE-LOCATOR |
| E4-IIIE-B06-014 | Assume Gaussian first source derivative at one point ensures all jets match | VALID-HESSIAN-COUNTEREXAMPLE |
| E4-IIIE-B06-015 | Demand any continuous U(R) has an operator curvature derivative | OUT-OF-CLAIM |

## 5. Qualified downstream and upstream dependencies

- Papers III-D and I-B imports were checked only where directly used by Paper III-E. Imported source proof hypotheses retain their own domain, normal operator and density conditions.
- Earlier G-0005 is in a general cap family. This final source section explicitly restricts the conormal member to `R_s=√(UC)`; this provides a domain-specific valid route, not a retroactive unconditional proof of the earlier claim.
- Earlier G-0006 dimensional Gaussian coordinate/measure issue remains unresolved. The last finite quantum theorem independently demonstrates what additional measure information is required for a physical Newton projection.
- The raw `U_J^raw=96U` and the pre-port cell ratio do not supply a common-owner physical Newton action or observed gravitational normalization.

## 6. Audit/verification boundary

- All fourteen formal proofs were source-replayed. Independent evidence uses exact calculus, positive matrix/spectral reconstruction, counterfamilies, finite Gibbs differentiation, determinant tests and a complete cross-reference census.
- Code and JSON companion files preserve every control and result. E1, E3 and E4 are separate evidence roles conducted by one executor, not a claim of simultaneous independent-agent work.
- The complete six-batch source census and the seven issue certificates will be integrated in the versioned Atlas audit layer. The proof-chain audit ZIP contains one finished Paper3E audit file, not every intermediate batch.
