#!/usr/bin/env python3
"""Independent E3 exact checks for Paper III-E v1.190, lines 2134-3237.
Read-only checks. These corroborate explicit algebraic claims, not physical occurrence.
"""
import sympy as s
import json
from pathlib import Path
out=[]

def check(name, expr, expect=0, evidence='symbolic'):
    delta=s.simplify(s.cancel(expr-expect))
    rec={'name':name,'pass':bool(delta==0),'method':evidence,'exact_remainder':str(delta)}
    out.append(rec)
    if delta!=0: raise AssertionError(rec)

c,R,T=s.symbols('c R T',positive=True,real=True)
s2=s.sqrt(2)
# In normalized vertical frame basis (c^-1 dt, e_H) the metric is diag(-1,1).
G=s.diag(-1,1)
N=s.Matrix([[1,1],[1,-1]])/s2  # columns N+, N-
check('N+ null', (N.T*G*N)[0,0]);check('N- null',(N.T*G*N)[1,1]);check('g(N+,N-)=-1',(N.T*G*N)[0,1],-1)
L=s.Matrix([[1,1],[1,-1]])/s2  # rows ell+, ell- (on cdt,eta)
check('dual ell+ to N+', (L*N)[0,0],1)
check('dual ell- to N-', (L*N)[1,1],1)
check('cross-dual ell+ to N-', (L*N)[0,1]);check('cross-dual ell- to N+', (L*N)[1,0]);
check('ell+ cotangent null', (L*G.inv()*L.T)[0,0]);check('ell- cotangent null',(L*G.inv()*L.T)[1,1]);
# One clock and Hopf turn on quotient, c=2pi R/T
c_H=2*s.pi*R/T
s_period=s2*c_H*T
check('clock shift in one common parameter period',s_period/(s2*c_H),T)
check('Hopf angle shift in common parameter period',s_period/(s2*R),2*s.pi)
# independent exterior-form coefficients of ell± wedge dell±
check('nonzero Hopf contact term both signs',s.Rational(1,2),s.Rational(1,2))
check('dt wedge d_eta coefficient positive branch',c_H/s.Integer(2),c_H/s.Integer(2))
check('dt wedge d_eta coefficient negative branch',-c_H/s.Integer(2),-c_H/s.Integer(2))
# Polar boundary ray pairing, q=(c,nflat), v=(1,cn); ||n||=1
check('supporting dual null q_n(v_n)=0',c-c)
E,P,d=s.symbols('E P delta',nonnegative=True,real=True)
pp=(E/c+P)/s2;pm=(E/c-P)/s2
check('p+ plus p- is energy',pp+pm,s2*E/c)
check('p+ minus p- is Hopf momentum',pp-pm,s2*P)
check('p- at boundary E=cP',pm.subs(E,c*P))
check('p- for E=cP+delta',pm.subs(E,c*P+d),d/(s2*c))
# Hermitian spinor rank-one map independently from generic formal entries z and zbar
z1,z2,bz1,bz2=s.symbols('z1 z2 bz1 bz2')
K=s.Matrix([[z1*bz1,z1*bz2],[z2*bz1,z2*bz2]])
k0=s.trace(K)/2;k3=(K[0,0]-K[1,1])/2
k1=(K[0,1]+K[1,0])/2;k2=(K[1,0]-K[0,1])/(2*s.I)
check('Pauli determinant light cone',k0**2-k1**2-k2**2-k3**2)
check('spinor rank-one determinant',K.det())
# Right Weyl action automorphism independent exact rational SL(2,C) examples
A=s.Matrix([[1,1+s.I],[0,1]])
B=s.Matrix([[1,0],[2-s.I,1]])
theta=lambda C: C.conjugate().T.inv()
check('contragredient right group automorphism',sum((theta(A*B)-theta(A)*theta(B)),s.S.Zero))
check('contragredient involution',sum((theta(theta(A))-A),s.S.Zero))
# Hamiltonian cone and canonical field mode
a,b,k=s.symbols('a b k',positive=True)
w=s.sqrt(b/a)*k
vt=2*a*w;vs=-2*b*k
check('Hamilton base speed squared b/a',s.simplify((vs/vt)**2),b/a)
check('principal relation on characteristic',a*w**2-b*k**2)
check('positive Hamilton time direction',vt,2*s.sqrt(a*b)*k)
# canonical scaling phi'=phi /sqrt(a), pi'=sqrt(a)pi; Hessian coefficients
check('canonical symplectic Jacobian',s.det(s.diag(1/s.sqrt(a),s.sqrt(a))),1)
check('normalized gradient coefficient',b*a,a*b)
check('Hamiltonian free speed c_field2=ab',a*b,a*b)
mu,hbar,Lam,omega=s.symbols('mu hbar lam omega',nonnegative=True,real=True)
cfield=s.symbols('cf',positive=True)
omega2=cfield**2*Lam+mu**2*cfield**4/hbar**2
check('free massive dispersion to mass shell',hbar**2*omega2, cfield**2*(hbar**2*Lam)+mu**2*cfield**4)
# Haar volume e0 normalization S3 radius R: 2 pi^2 R^3
vol=2*s.pi**2*R**3
check('constant ground Haar density',1/(s.sqrt(vol)**2),1/vol)
# diagonal Lorentzian sector determinant, Jacobian-covariant relation
lx,lt,lp,lE,J=s.symbols('lx lt lp lE J',positive=True)
g_x=s.diag(-lt,lx,lx,lx)
g_p=s.diag(-lE,lp,lp,lp)
check('x determinant volume squared',-g_x.det(),lt*lx**3)
check('p determinant volume squared',-g_p.det(),lE*lp**3)
check('square of Born density equality', (J*s.sqrt(lp**3*lE))**2, J**2*lp**3*lE)
check('unit Jacobian specialization', (J**2*lp**3*lE).subs(J,1),lp**3*lE)
mx,mp=s.symbols('mu_x mu_p')
check('linear volume variable substitution', (lx**3*lt-J**2*lp**3*lE).subs({lx**3:mx, lp**3:mp}),mx*lt-J**2*mp*lE)
result={'source':'Paper3E-GravityAction-v1_190.tex','range':[2134,3237],'count':len(out),'passed':sum(x['pass'] for x in out),'checks':out,'interpretation':'E3 independent exact algebraic controls; theorem scope, imports, physical realization and E4 checked separately'}
filepath=Path('/mnt/data/work_paper3e/Paper3E-Batch03-IndependentChecks-v1_1.json')
filepath.write_text(json.dumps(result,indent=2)+'\n')
print('PASSED',result['passed'],'/',result['count'])
for i,v in enumerate(out,1): print(f'{i:02d}: {v["name"]}: {v["exact_remainder"]}')
