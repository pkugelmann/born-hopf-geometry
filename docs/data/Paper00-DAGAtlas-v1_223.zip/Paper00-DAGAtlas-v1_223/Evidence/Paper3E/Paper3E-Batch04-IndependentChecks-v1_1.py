#!/usr/bin/env python3
"""Independent E3 exact/precision controls for Paper III-E v1.190, lines 3238–4382.
SOURCE-READ-ONLY. Symbolic checks do not certify physical occurrence or imported ports.
"""
import json, math
from pathlib import Path
import sympy as sp
import mpmath as mp
mp.mp.dps=70
out=[]

def ck(name, expr, expected=0, scope='exact symbolic'):
    resid=sp.simplify(sp.together(expr-expected))
    status=bool(resid==0)
    out.append({'id':f'E3-IIIE-B04-{len(out)+1:03d}', 'name':name,'passed':status,'kind':scope,'residual':str(resid)})
    if not status: raise AssertionError(name+' resid='+str(resid))

def isclose(name, val, target, tolerance=mp.mpf('1e-11'), scope='high precision'):
    d=abs(val-target)
    status=bool(d<tolerance)
    out.append({'id':f'E3-IIIE-B04-{len(out)+1:03d}', 'name':name,'passed':status,'kind':scope,'residual':mp.nstr(d,28),'computed':mp.nstr(val,40),'target':mp.nstr(target,25)})
    if not status: raise AssertionError(name+' resid='+str(d))

u=sp.symbols('u',positive=True)
S=sp.log(1+7*u)-7*u*sp.log(u)/(1+7*u)
ck('entropy derivative dS/du',sp.diff(S,u),-7*sp.log(u)/(1+7*u)**2)
ck('entropy endpoint pure C',sp.limit(S,u,0,dir='+'))
ck('entropy endpoint mixed U',sp.simplify(S.subs(u,1)),sp.log(8))
ck('active fraction at C',sp.limit(sp.exp(S)/8,u,0,dir='+'),sp.Rational(1,8))
ck('active fraction at U',sp.exp(S.subs(u,1))/8,1)
ck('spectrum normalization',1/(1+7*u)+7*u/(1+7*u),1)
ck('entropy spectrum direct',-(1/(1+7*u))*sp.log(1/(1+7*u))-7*u/(1+7*u)*sp.log(u/(1+7*u)),S)
# Imposing octet multiplicative entropy-count forces kappa=1.
kappa=sp.symbols('kappa',real=True)
ck('multiplicative exponential normalized at kappa=1',sp.exp(kappa*sp.log(8)).subs(kappa,1),8)
C,U,R,a,lam=sp.symbols('C U R a lam',positive=True)
Sratio=(sp.log(R/C)/sp.log(U/C))
ck('log hierarchy u(C)=0',Sratio.subs(R,C))
ck('log hierarchy u(U)=1',Sratio.subs(R,U),1)
ck('hierarchy scale uniform log u after homothety',sp.simplify(sp.log((lam*R)/(lam*C))/sp.log((lam*U)/(lam*C))),Sratio)
# PQTI independent arithmetic; only when evaluated comparison is indeed satisfied.
alpha=sp.symbols('alpha',positive=True)
Q=8*sp.sqrt(alpha)
ck('raw-to-EH overall normalization',sp.Integer(8)*sp.Rational(1,8),1)
ck('PQTI primitive second-variation susceptibility factor',8*sp.sqrt(alpha)*sp.diff(R**2+C*U,R,2),16*sp.sqrt(alpha))
ck('PQTI corrected UV h scale',8*sp.sqrt(alpha)*sp.diff(R**2+C*U,R,2)/U,16*sp.sqrt(alpha)/U)
ck('gamma kappa family',16*lam*sp.sqrt(alpha)/(lam*U),16*sp.sqrt(alpha)/U)
# Two-root response and terminal-jet reconstruction.
g=(R**2+C*U)/((U+C)*R)
ck('reduced response calibration at C',g.subs(R,C),1)
ck('reduced response calibration at U',g.subs(R,U),1)
ck('two-root no kappa when inserted normalization',((lam/2)/(lam*(C+U)/2))*(R+C*U/R),g)
H=R*g
ck('bare two-root response Hessian',sp.diff(H,R,2),2/(U+C))
freg=R-C+(R-C)**2/(U+C)
ck('regular f(C)=0',freg.subs(R,C))
ck('regular fprime(C)=1',sp.diff(freg,R).subs(R,C),1)
ck('regular fsecond',sp.diff(freg,R,2),2/(U+C))
ck('same-action Euler/Legendre',R*sp.diff(freg,R)-freg,H)
ck('same-action endpoint Euler potential C',(R*sp.diff(freg,R)-freg).subs(R,C),C)
fsharp=R+H-2*C
shift=(fsharp-freg)
ck('sharp-minus-regular affine difference',shift,2*C/(U+C)*(R-C))
ck('sharp-minus-regular curvature Hessian',sp.diff(shift,R,2))
ck('sharp-minus-regular terminal slope',sp.diff(shift,R).subs(R,C),2*C/(U+C))
# Hessian contravariance: independent explicit 2x2 check
h11,h12,h22,a1,a2,b1,b2=sp.symbols('h11 h12 h22 a1 a2 b1 b2',real=True)
HT=sp.Matrix([[h11,h12],[h12,h22]]);A=sp.Matrix([[a1,b1],[a2,b2]])
x1,x2=sp.symbols('x1 x2',real=True); x=sp.Matrix([x1,x2])
Phi=sp.Rational(1,2)*(A*x).T*HT*(A*x)
hess=sp.hessian(Phi[0],(x1,x2))
ck('2x2 covariant Hessian pullback off diagonal',hess[0,1],(A.T*HT*A)[0,1])
ck('2x2 covariant Hessian pullback diagonal',hess[0,0],(A.T*HT*A)[0,0])
t,s=sp.symbols('t s',positive=True)
ck('Hessian scalar damping e^-tau',sp.exp(-t/2)**2,sp.exp(-t))
ck('Hessian pullback semigroup',sp.exp(-s)*sp.exp(-t),sp.exp(-(s+t)))
# Complete scale homothety. Example h(Ux)=U^-1 (x)^2, integrate exact endpoint representation.
x,c,Fc,Zc=sp.symbols('x c Fhat Zc',real=True)
# hhat(y)=y^2 yields an exact nontrivial quadrature.
y=sp.symbols('y',real=True)
frecon=U*(Fc+Zc*(x-c)+sp.integrate((x-y)*y**2,(y,c,x)))
ck('homothety reconstructed hhat=x²',sp.diff(frecon,x,2),U*x**2)
ck('homothety first derivative scale independent',sp.diff(frecon,x)/U,Zc+sp.integrate(y**2,(y,c,x)))
ck('homothety exact scaled response representative',frecon.subs(U,lam*U),lam*frecon)
# Generic terminal Cauchy problem with h(s)=s^2, directly check two integrations.
z=sp.symbols('z',real=True)
f0,f1=sp.symbols('f0 f1',real=True)
fex=f0+f1*(R-C)+sp.integrate((R-z)*z**2,(z,C,R))
ck('general Hessian reconstruction fsecond=s²',sp.diff(fex,R,2),R**2)
ck('general Hessian reconstruction terminal value',fex.subs(R,C),f0)
ck('general Hessian reconstruction terminal slope',sp.diff(fex,R).subs(R,C),f1)
ck('affine homogeneous Hessian kernel',sp.diff(f0+f1*(R-C),R,2))
# UV/IR exact moment integral: use nonconstant convex test f=R^4 + R + constant.
f=R**4+R+sp.Integer(3)
F=sp.diff(f,R);chi=sp.diff(f,R,2)
ck('M0 moment exact for nonconstant chi',sp.integrate(chi,(R,C,U)),F.subs(R,U)-F.subs(R,C))
ck('M1 moment exact for nonconstant chi',sp.integrate(R*chi,(R,C,U)),(R*F-f).subs(R,U)-(R*F-f).subs(R,C))
# A finite endpoint-jet invisible interior test shape (compactly supported C2 analogue).
upert=(R-C)**3*(U-R)**3
ck('interior perturbation value lower zero',upert.subs(R,C))
ck('interior perturbation value upper zero',upert.subs(R,U))
ck('interior perturbation slope lower zero',sp.diff(upert,R).subs(R,C))
ck('interior perturbation slope upper zero',sp.diff(upert,R).subs(R,U))
ck('interior perturbation zero moment M0',sp.integrate(sp.diff(upert,R,2),(R,C,U)))
ck('interior perturbation zero moment M1',sp.integrate(R*sp.diff(upert,R,2),(R,C,U)))
# source member f = R -C + positive Hessian integral.
ck('source TERM_f: Csp(C)=-C',freg.subs(R,C)-C,-C)
ck('source TERM_f: Cspprime(C)=0',sp.diff(freg-R,R).subs(R,C))
# Rank-four source imported formula with symbolic A=log(alpha)>0
L=sp.symbols('L',positive=True,real=True)
C4=U*sp.exp(-4*L); C2=U*sp.exp(-2*L); C7=U*sp.exp(-7*L)
q=sp.symbols('q',positive=True,real=True)
n4=(sp.log(sp.cosh(2*L))-sp.log(sp.cosh((2-q)*L)))/(q*L)
ck('n4 positive-part cutoff raw index at q=4',sp.simplify(n4.subs(q,4)))
ck('n4 midpoint at q=2',sp.simplify(n4.subs(q,2)),sp.log(sp.cosh(2*L))/(2*L))
ck('n4 derivative below/above q=4 conversion to curvature',sp.simplify(sp.diff(n4,q).subs(q,4)*(-1/(L*C4))),sp.tanh(2*L)/(4*L*C4))
ck('tanh identity used for jet jump',sp.tanh(2*L).rewrite(sp.exp),(U-C4)/(U+C4))
ck('Born midpoint sqrt(U*C4)',sp.sqrt(U*C4),C2)
ck('positive curvature log clock at C2',-sp.log(C2/U)/L,2)
ck('positive curvature log clock at C4',-sp.log(C4/U)/L,4)
chi7=sp.symbols('chi7',positive=True)
ck('third-jet jump chain-rule equivalent',chi7*sp.log(Q)*sp.tanh(2*L).rewrite(sp.exp)/(4*L*C4),chi7*(U-C4)*sp.log(Q)/(4*C4*(U+C4)*L))
A0=4*mp.pi**2+1/(6*mp.sqrt(2))
def midpoint_ratio(A):
  n=mp.log(mp.cosh(2*A))/(2*A)
  QQ=8*mp.exp(A/2)
  return mp.exp((n-1)*mp.log(QQ))
isclose('rank-four midpoint numeric on scheme zero',midpoint_ratio(A0),mp.mpf('0.82572995667438991737732847'),mp.mpf('1e-20'),'scheme-zero high precision')
# counterexample/differentiation of scope: authorized scheme-positive sigma variation.
for sig in [mp.mpf('-1'),mp.mpf('1')]:
 A=A0+sig
 ratio=midpoint_ratio(A)
 out.append({'id':f'E4-IIIE-B04-{len(out)+1:03d}', 'name':f'midpoint numerical mutates under REG sigma={sig}',
    'kind':'adversarial in-REG-positive scheme variation', 'passed':bool(abs(ratio-mp.mpf('0.8257299566743899'))>mp.mpf('1e-7')),
    'computed_D4_over_Q':mp.nstr(ratio,32),'scheme':'REG_'+str(sig),
    'warrant':'Numeric constant is not invariant as sigma varies; source must restrict numeric value to REG0 or equivalent fixed A.'})
# Same-chart second derivative, caps analytic; FLRW acceleration jet exact.
a,N,adot,addot,Ndot,Z=sp.symbols('a N adot addot Ndot Z',positive=True,real=True)
Rf=6*(addot/(a*N**2)+adot**2/(a**2*N**2)+1/a**2-adot*Ndot/(a*N**3))
ck('FLRW acceleration curvature first jet',sp.diff(Rf,addot),6/(a*N**2))
ck('FLRW acceleration curvature second jet',sp.diff(Rf,addot,2))
# Nonquadratic polynomial f(R) = R + k R^3, independent 2-variable Hessian.
k=sp.symbols('k',real=True)
fs=Rf+k*Rf**3; Lagr=2*sp.pi**2*Z*N*a**3*fs
ck('FLRW acceleration Hessian nonlinear f',sp.diff(Lagr,addot,2),72*sp.pi**2*Z*a/N**3*(6*k*Rf))
ck('FLRW acceleration Hessian for Einstein f=R',sp.diff(Lagr.subs(k,0),addot,2))
B0=sp.Function('B0')(a,adot,N,Ndot,t)
# exemplar total derivative B=a² a_dot+N²*t yields at most linear in acceleration; no 2nd derivative.
Bpoly=a**2*adot+N**2*t
Bdot=sum(sp.diff(Bpoly,x)*v for x,v in [(a,adot),(adot,addot),(N,Ndot),(t,sp.Integer(1))])
ck('first-jet total derivative has zero acceleration Hessian',sp.diff(Bdot,addot,2))
# Counterexample relevant to magnitude of numerical midpoint on scheme-positive locus, do not conflate with rank-four freeze.
positive_mutation=[r for r in out if r['kind']=='adversarial in-REG-positive scheme variation']
assert len(positive_mutation)==2 and all(r['passed'] for r in positive_mutation)
exact=[r for r in out if not r['id'].startswith('E4-')]
assert all(r['passed'] for r in exact)
result={'source':'Paper3E-GravityAction-v1_190.tex', 'line_range':[3238,4382], 'E3_exact_and_precision_controls':len(exact),
'E3_passed':sum(r['passed'] for r in exact), 'E4_scheme_mutations':len(positive_mutation),
'E4_passed':sum(r['passed'] for r in positive_mutation),'evidence':out,
'physical_limit':'Exact source algebra/precision only; active-action owner, joint-occurrence port, and remote imported claims require separately certified provenance.'}
root=Path('/mnt/data/work_paper3e')
(root/'Paper3E-Batch04-IndependentChecks-v1_1.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print('E3 PASS',result['E3_passed'],'/',result['E3_exact_and_precision_controls'],'E4 mutations',result['E4_passed'],'/',result['E4_scheme_mutations'])
print('REG0 D4/Q',mp.nstr(midpoint_ratio(A0),34),'REG+1',mp.nstr(midpoint_ratio(A0+1),34))
