# Paper III-E — Rigorous verification, batch 01 (of planned source slices)

**Frozen source:** `Paper3E-GravityAction-v1_190.tex`; SHA-256 `c09e1f6c834e784d593f12827045a22b184671324c5091f2e50b12e076e3119b`

**Coverage:** lines 1–1,211; 14/115 formal declarations, 10/92 proofs, 1/30 remarks; 17 exact E3 symbolic checks passed.

**Disposition:** {'VERIFIED': 1, 'FORMALIZED': 3, 'VERIFIED-CONDITIONAL': 7, 'UNRESOLVED': 2, 'REPRODUCED': 1}. These are batch-level verdicts, not a full-paper or upstream-corpus certification.

## Per-claim evidence ledger

| ID | Source line | Claim label | Current verdict |
|:--|--:|:--|:--|
| BH-IIIE-C-0001 | 246 | `p3e:prop:v169-analytic-reconstruction-firewall` | VERIFIED |
| BH-IIIE-C-0002 | 285 | `p3:def:causal-wick-response-hypotheses` | FORMALIZED |
| BH-IIIE-C-0003 | 419 | `p3e:prop:v2211-whole-action-newton-certificate` | VERIFIED-CONDITIONAL |
| BH-IIIE-C-0004 | 486 | `p3e:cor:typed-planck-normalization` | VERIFIED-CONDITIONAL |
| BH-IIIE-C-0005 | 706 | `p3e:thm:uniform-reg-response-bundle` | VERIFIED-CONDITIONAL |
| BH-IIIE-C-0006 | 765 | `p3e:cor:owner-typed-active-spectral-profile` | VERIFIED-CONDITIONAL |
| BH-IIIE-C-0007 | 851 | `p3e:cor:even-external-internal-grading-ancestry` | UNRESOLVED |
| BH-IIIE-C-0008 | 871 | `p3e:prop:c12-scheme-depth-closure-criterion` | VERIFIED-CONDITIONAL |
| BH-IIIE-C-0009 | 938 | `p3e:def:crp4-cross-role-positive-parent` | FORMALIZED |
| BH-IIIE-C-0010 | 963 | `p3e:thm:crp4-uniqueness` | UNRESOLVED |
| BH-IIIE-C-0011 | 1013 | `p3e:cor:crp4-c12-discharge` | VERIFIED-CONDITIONAL |
| BH-IIIE-C-0012 | 1037 | `p3e:cor:v179-response-energy-quarter-character` | VERIFIED-CONDITIONAL |
| BH-IIIE-C-0013 | 1117 | `p3e:prop:conditional-susceptibility-half-weight` | REPRODUCED |
| BH-IIIE-C-0014 | 1168 | `p3e:prop:v236-mresp-decomposition` | FORMALIZED |

## Open source-anchored issues

### BH-IIIE-G-0001 — TYPE_OR_DOMAIN (MODERATE)

**Origin:** `Paper3E-GravityAction-v1_190.tex:851-860` / `p3e:cor:even-external-internal-grading-ancestry`.

In this manuscript W is a seven-real-dimensional trace-free Cl(0,3) block at lines 112,622,629. Imported diagonal-fibre spin transport targets W_L and W_R, a half-spin direct sum of four complex (eight real) dimensions; source gives no graded identification of these non-isomorphic codomains. The standalone map and Gamma_W are therefore not well typed as printed.

**Preserved valid result:** The conditional parity-preserving spin map into W_L direct-sum W_R may be mathematically valid after explicit type naming. This is not a refutation of the Paper III-B spin theorem.

**Verified downstream check:** Paper5A-FiniteMatterGeometry-v3_202.tex:803-826 (p5:cor:chi5-visible-chirality) cites the grading ancestry

**Required certificate:** Define separate W_7 and W_spin=W_L⊕W_R, exact S_x and Gamma_Wspin and J_Delta maps with matching dimensions; replay later uses under those types.

### BH-IIIE-G-0002 — TYPE_OR_DOMAIN (MODERATE)

**Origin:** `Paper3E-GravityAction-v1_190.tex:963-1011` / `p3e:thm:crp4-uniqueness`.

A unique scheme–depth B transport does not determine the spacetime M part of a full connection on pi_M^* W*. The source specifies no M-direction ∇^M for W*, and the antecedent positive-line fourth-root theorem is a B-base statement. Thus the full B×M connection is not uniquely induced without an inherited spacetime connection or a restriction to the relative B-direction connection.

**Preserved valid result:** The unique B-direction positive root, determinant transport, and displayed B-connection are verified; an explicit local choice of full d or a separately existing M-connection would cure the scope issue, but no repair is executed in this audit.

**Verified downstream check:** Paper5D-TechnicalMaterial-v1_47.tex:2440-2476 consumes the CRP4 connection in scheme-depth B role; that B-only route is not blocked

**Required certificate:** Clarify d=d_B versus d_{B×M}; if full, identify source-certified ∇^M on W* and its frame covariance, then verify direct-sum formula.

## Evidence gates and qualified ports

- E1: source replay of all 10 self-contained proof environments in this slice; definitions and no-proof corollary separately scoped.
- E3: 17 exact zero-reduction tests (SymPy), including the 7 integer depth hits; type and physical-owner gates require additional semantic checks.
- E4: tested grading-carrier typing and non-uniqueness of unspecified M-direction connections; discarded out-of-domain counterfamilies.
- No source-proven equivalence between raw joint and scalar Newton constants has been assumed; the constant-z physical matching stays conditional.
- The CELL curvature/EH residual, actual ACD_H/CRP4 port, PQTI tensorial normalization, REG scheme evaluation, and terminal metrics are kept distinct from proved algebraic descendants.
- The current paper’s conditions are not reintroduced as global DAG assumptions until their earliest logical appearance is checked against the existing registry.

## Continuation and archive policy

The next source slice is 1,212–2,133. No archive has been modified in this batch. The final batch will emit the successor global DAG atlas and proof-chain-audits ZIP, with only the newest version of each included component.
