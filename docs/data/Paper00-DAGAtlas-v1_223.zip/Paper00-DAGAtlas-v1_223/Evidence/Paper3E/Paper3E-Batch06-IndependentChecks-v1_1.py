#!/usr/bin/env python3
"""Reproducible independent and adversarial checks of Paper3E source lines 5612-6449.
No novel Born-Hopf physical assumptions or source modifications. Deterministic controls;
symbolic checks are exact, numerical checks are stress tests not blanket proof certificates.
"""
from __future__ import annotations
import json, hashlib, re, math, zipfile
from pathlib import Path
import numpy as np
import sympy as sp
from scipy.linalg import sqrtm

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'sources'/'Paper3E-GravityAction-v1_190.tex'
results=[]
def check(name, passed, detail, kind='E3', claim=None, parameter=None):
    if isinstance(passed,np.bool_):passed=bool(passed)
    if not passed:
        print('FAIL:',name,detail)
    results.append({'id':f'{kind}-IIIE-B06-{len(results)+1:03d}', 'name':name,
                    'pass':bool(passed),'detail':str(detail),'kind':kind,'target_label':claim,
                    'parameter':parameter})

def approx(a,b,tol=1e-9): return abs(a-b) <= tol*(1+abs(a)+abs(b))
def matclose(a,b,tol=1e-9):return bool(np.linalg.norm(a-b) <=tol*(1+np.linalg.norm(a)+np.linalg.norm(b)))

R,C,U=sp.symbols('R C U',positive=True,finite=True)
Lam,radius,sym_s=sp.symbols('Lam radius s',positive=True)
# 1. Typed Laurent / Euler comparison: not conflating the two global-source roles
K=sp.Symbol('K',real=True)
f=R-C+sp.integrate((R-sp.Symbol('q'))*K,(sp.Symbol('q'),C,R))
check('Terminal second-jet integral boundary value', sp.simplify(f.subs(R,C))==0,str(f),claim='p3e:cor:v2216-local-global-response-scope')
check('Terminal second-jet integral boundary slope',sp.simplify(sp.diff(f,R).subs(R,C)-1)==0,str(sp.diff(f,R)),claim='p3e:cor:v2216-local-global-response-scope')
check('Terminal second-jet integral Hessian',sp.simplify(sp.diff(f,R,2)-K)==0,str(sp.diff(f,R,2)),claim='p3e:cor:v2216-local-global-response-scope')
check('Terminal metric Euler excess',sp.simplify((R*sp.diff(f,R)-f)-(C+sp.integrate(sp.Symbol('q')*K,(sp.Symbol('q'),C,R))))==0,'Euler source and metric Hessian paired with a single primitive',claim='p3e:cor:v2216-local-global-response-scope')
# nonconstant susceptibility, explicit integration
q=sp.symbols('q',positive=True)
Kq=(sp.Rational(5,2)*(q*q-1))/(9*q*q) # C=1 U=8 and w=5/2
F=R-1+sp.integrate((R-q)*Kq,(q,1,R))
P=R*sp.diff(F,R)-F
check('Nonconstant susceptibility exact second derivative',sp.simplify(sp.diff(F,R,2)-Kq.subs(q,R))==0,str(F),claim='p3e:cor:v2216-local-global-response-scope')
check('Nonconstant susceptibility exact Euler derivative',sp.simplify(sp.diff(P,R)-R*Kq.subs(q,R))==0,str(P),claim='p3e:cor:v2216-local-global-response-scope')

# 2. Petersen tensor dimensions and no new host metric
check('15 x 15 auxiliary exchange tensor dimension',15**2==225,'15^2=225',claim='p3e:prop:v319-petersen-gravity-firewall')
check('Symmetric and alternating dimensions',15*(15+1)//2==120 and 15*(15-1)//2==105,'120+105=225',claim='p3e:prop:v319-petersen-gravity-firewall')

# 3. Scalar cutoff/momentum residual exact algebra
rhoH=sp.Integer(3)/sp.pi
kappa=sp.Integer(6)/radius**2
root=24*sp.sqrt(3*sp.pi)
res=sp.log((Lam**2/(96*sp.pi**2))/(rhoH*kappa))
check('Momentum-cell residual exact simplification',sp.simplify(sp.expand_log(res,force=True)-2*sp.log(Lam*radius/root))==0,str(res),claim='p3e:thm:v346-cell-scale-independence')
check('CELL vanishing when and only when positive product is target',sp.simplify(res.subs(Lam,root/radius))==0,'positive scaling branch',claim='p3e:thm:v346-cell-scale-independence')
check('Cutoff scaling counterfamily exact shift',sp.simplify(sp.expand_log(res.subs(Lam,sym_s*Lam)-res,force=True)-2*sp.log(sym_s))==0,'delta=2log(s), pre-port only',claim='p3e:thm:v346-cell-scale-independence')

# 4. Conormal stationary split, full positive quadratic flux, amplitude
rng=np.random.default_rng(3203506)
for idx,G in enumerate([1.,1.4,3.5,13.]):
    M=rng.normal(size=(4,4));K0=M.T@M+np.eye(4)
    j=rng.normal(size=4)
    p0=j/(1+G);p1=G*j/(1+G)
    dual=np.linalg.inv(K0)
    energy=0.5*(p0@dual@p0+p1@(dual/G)@p1)
    check(f'Conormal stationary common inverse flux G={G}',approx(energy,float(j@dual@j/(2*(1+G)))),'full p0+p1 with no dropped source column',claim='p3e:thm:v229-conormal-cap')
    shift=rng.normal(size=4);delta=0.5*(shift@dual@shift+(shift@dual@shift)/G)
    test=0.5*((p0+shift)@dual@(p0+shift)+(p1-shift)@(dual/G)@(p1-shift))
    check(f'Conormal global positive minimizer G={G}',approx(test-energy,delta),'positive Hessian independently checked',claim='p3e:thm:v229-conormal-cap')

# rooted 2-partner upstream eigenweights and amplitude target
for idx,(mu,g,L0) in enumerate([(1.3,2.2,0.7),(2,3,1.5),(4,.7,2.0)]):
    A=np.array([[mu**2, np.sqrt(3)*g*mu/2],[np.sqrt(3)*g*mu/2,mu**2+g**2]])
    vals,vs=np.linalg.eigh(A)
    lam_m,lam_p=vals
    w_p=(mu**2-lam_m)/(lam_p-lam_m);w_m=1-w_p
    kd=vs@np.diag(np.sqrt(vals)/np.tanh(L0*np.sqrt(vals)))@vs.T
    Qd=w_p*np.sqrt(lam_p)/np.tanh(L0*np.sqrt(lam_p))+w_m*np.sqrt(lam_m)/np.tanh(L0*np.sqrt(lam_m))
    check(f'Rooted conormal spectral weights {idx}',approx(w_p,vs[0,1]**2) and approx(w_m,vs[0,0]**2),'weights of singlet basis, no scalar-only compression',claim='p3e:cor:v229-rooted-amplitude')
    check(f'Rooted conormal absolute norm {idx}',approx(kd[0,0]/mu**2,Qd/mu**2),'d0=Q_D/mu² direct matrix functional calculus',claim='p3e:cor:v229-rooted-amplitude')
    Rs=3.8;delta=.74;gamma=mu/Rs;brequ2=4*delta*Rs**2/Qd
    check(f'Rooted conormal amplitude matching {idx}',approx(brequ2*gamma**2*(Qd/mu**2),4*delta),'physical b remains external selection',claim='p3e:cor:v229-rooted-amplitude')

# 5. Counterfamily reciprocity, anchors, bound, ranges
for idx,(U0,C0,BI,BU) in enumerate([(10.,1.,3.,1.),(13.,2.,2.,.2),(7.,5.,1.1,1.)]):
    Rs=math.sqrt(U0*C0); s0=C0/U0+U0/C0; Delta=BI-BU
    def h(x):return (x*x*(x*x-1)**2/(1+x*x)**4)*((x**4-s0*x*x+1)**2/((s0+2)**2*(1+x*x)**4))
    def bc(x,eps):return BU+2*Delta*(1+eps*h(x))/(1+math.sqrt(1+x*x))
    sample=np.geomspace(0.00001,10000,111)
    check(f'Counterfamily reciprocal invariance {idx}',all(approx(h(x),h(1/x),1e-8) for x in sample),'h(x)=h(1/x)',claim='p3e:prop:v229-source-counterfamily')
    check(f'Counterfamily positive range {idx}',all(BU<bc(x,.249)<BI+1e-11 for x in sample),'BU<B_eps<=BI for eps<1/4 stress grid',claim='p3e:prop:v229-source-counterfamily')
    check(f'Counterfamily endpoint double zeros {idx}',abs(h(math.sqrt(C0/U0)))<1e-13 and abs(h(math.sqrt(U0/C0)))<1e-13 and h(1)==0,'source anchors C,U and Born midpoint',claim='p3e:prop:v229-source-counterfamily')
    check(f'Counterfamily not selected by finite anchors {idx}',max(h(x) for x in sample)>0,'in-domain positive deformation differs away anchors',kind='E4',claim='p3e:prop:v229-source-counterfamily')
    for x in [0.2,1,1.7,5]:
        G=math.sqrt(1+x*x);t=x/(1+G)
        bound=2*(1+G)*(G*G-2)**2/G**8
        ratio=(2/(1+G))*h(x)/(t*t)
        check(f'Counterfamily quantified range bound sample {idx}:{x}',ratio<=bound+1e-13 and bound<=4+1e-12,'inequality in source 6062-6066',claim='p3e:prop:v229-source-counterfamily')

# 6. Cap injectivity
for Bval in [.02,.1,1,3,15]:
    Rv=1.3; sigma=2.7
    deriv=Rv*Rv+2*sigma*sigma/Bval**3
    check(f'Complete inverse-square cap injection B={Bval}',deriv>0,'d/dB [R²B-sigma²/B²] strictly positive',claim='p3e:prop:v229-complete-cap-injective')

# 7. Exact cap source T_s and transport: 16 columns and one-anchor Ward
Rs=2.3;BI=2.8;BU=.6;c=math.sqrt(1-BU/BI)
for rv in [.0,.3,Rs,3.6,15.]:
    x=rv/Rs;G=math.sqrt(1+x*x);t=x/(1+G); b=1-c*c*t*t
    Mp=np.array([[1,c*t],[c*t,1.]])
    Mm=np.array([[1,-c*t],[-c*t,1.]])
    Ts=np.kron(Mp,Mm)
    tr=float(np.trace(np.linalg.inv(Ts)))
    det=float(np.linalg.det(Ts))
    sret=(Rs/2)**2*tr
    check(f'Complete source port positive and trace at R={rv}',np.min(np.linalg.eigvalsh(Ts))>0 and approx(tr,4/b**2) and approx(det,b**4),'4x4 tensor, all four columns and inverse-trace',claim='p3e:prop:v289-cap-source-ward')
    check(f'One-anchor inverse-square source identity R={rv}',approx(sret,(Rs/b)**2) and approx((BI*b)**2*sret,(BI*Rs)**2),'B²s constant on interval',claim='p3e:prop:v289-cap-source-ward')
    if rv>0:
        d=1.e-5
        def returns(Rvalue):
            xx=Rvalue/Rs;GG=math.sqrt(1+xx*xx);tt=xx/(1+GG);bb=1-c*c*tt*tt
            return (Rs/bb)**2, BI*bb
        sp_,Bp=returns(rv+d);sm_,Bm=returns(rv-d)
        deriv=(sp_-sm_)/(2*d); Bderiv=(Bp-Bm)/(2*d)
        check(f'One-anchor differential Ward at R={rv}',abs(deriv+2*Bderiv/(BI*b)*sret)<1.e-5,'d(s)+2Bprime/B*s=0',claim='p3e:prop:v289-cap-source-ward')

# 8. Half boost and positive Schur
for x in [0,.15,.7,2,8]:
    G=math.sqrt(1+x*x);theta=math.asinh(x); t=x/(1+G)
    Boost=np.array([[G,x],[x,G]])
    Bhalf=sqrtm(Boost)
    check(f'Positive half-boost determinant and square x={x}',np.min(np.linalg.eigvalsh(Boost))>0 and approx(np.linalg.det(Boost),1) and matclose(Bhalf@Bhalf,Boost),'det=1 and positive matrix square root',claim='p3e:thm:v353-positive-schur')
    check(f'Half-boost off-diagonal ratio x={x}',approx(Bhalf[0,1]/Bhalf[0,0],t),'t=tanh(arsinh(x)/2)',claim='p3e:thm:v353-positive-schur')
    BI,BU=3.,1.;c=math.sqrt(1-BU/BI); b=1-c*c*t*t
    check(f'Half-boost cap identity x={x}',approx(BI*b,BU+2*(BI-BU)/(1+G)),'B=BI b=BU+2Δ/(1+G)',claim='p3e:thm:v353-positive-schur')
    phi=.3+x/10.;Q=np.array([[math.cos(phi),-math.sin(phi)],[math.sin(phi),math.cos(phi)]])
    CC=(c*t)*Q
    KK=np.block([[np.eye(2),CC],[CC.T,np.eye(2)]])
    S=np.eye(2)-CC@CC.T
    Kinv=np.linalg.inv(KK)
    P=np.diag([1.,1.,0.,0.]);J=(2.3/math.sqrt(2))*P
    F=-np.trace(J@Kinv@J@Kinv)/8
    check(f'Positive block Schur inverse x={x}',matclose(Kinv[:2,:2],np.linalg.inv(S)) and np.min(np.linalg.eigvalsh(KK))>0,'full K inverse top block S^-1',claim='p3e:thm:v353-positive-schur')
    check(f'Schur current full trace formula x={x}',approx(F,-(2.3**2)/16*np.trace(np.linalg.inv(S)@np.linalg.inv(S))) and approx(F,-2.3**2/(8*b*b)),'correct rank-2 factor 1/8',claim='p3e:thm:v353-positive-schur')
    check(f'Schur mixed orientation sensitivity x={x}',matclose(Kinv[:2,2:],-CC/b),'unitary orientation is not fixed by scalar return',claim='p3e:prop:v353-schur-orientation')
for eps in [0,.2,.7,-.5]:
    b=.7
    S=np.diag([b/math.sqrt(1+eps),b/math.sqrt(1-eps)])
    check(f'Non-scalar Schur return family epsilon={eps}',approx(np.trace(np.linalg.inv(S)@np.linalg.inv(S)),2/b**2) and (eps==0 or not matclose(S,b*np.eye(2))),'same trace with distinct Schur operator',kind='E4',claim='p3e:prop:v353-schur-orientation')
# 9. First-jet target (symbolic)
rv,rs,cv=sp.symbols('rv rs cv',real=True,positive=True)
gg=sp.sqrt(1+(rv/rs)**2); tt=(rv/rs)/(1+gg);bb=1-cv**2*tt**2
check('Schur cap first curvature jet vanishes',sp.simplify(sp.diff(bb,rv).subs(rv,0))==0,'bprime(0)=0',claim='p3e:prop:v353-schur-jet')
check('Schur cap second curvature jet exact',sp.simplify(sp.diff(bb,rv,2).subs(rv,0)+cv**2/(2*rs**2))==0,'bdoubleprime(0)=-c²/(2Rs²)',claim='p3e:prop:v353-schur-jet')

# 10. Whole-action first jet: explicit two-coordinate counterexample
z=sp.Rational(1,96);x,y=sp.symbols('x y')
sj=96*x+y**2;phys=x+y**2
check('Whole-action gravity-only first-jet counterexample',sp.diff(phys,x)==z*sp.diff(sj,x) and sp.diff(phys,y,2)!=z*sp.diff(sj,y,2),'same x coefficient does not match all variations',kind='E4',claim='p3e:prop:v356-whole-action-jet-criterion')

# 11. Gibbs finite quantum covariance formulas independent finite sum
# A source-dependent linear y term on discrete 3-state spectator, with positive Z.
hbar=.8
levels=np.array([-2.,-.3,1.7]); weights=np.array([1.,2.,.7]);X=.43
# S(x,y)= x**2 + x*y + y**2/2 ; S_x=2*x+y ; S_xx=2
S=X*X+X*levels+levels**2/2
D=2*X+levels
for z0 in [.125,.5,1.,2.5]:
    gibbs=weights*np.exp(-z0*S/hbar)
    prob=gibbs/gibbs.sum();mean=lambda a:np.dot(prob,a)
    cov=lambda a,b:mean(a*b)-mean(a)*mean(b)
    def Gval(x0):
        ener=x0*x0+x0*levels+levels**2/2
        return -hbar*np.log(np.dot(weights,np.exp(-z0*ener/hbar)))
    d=1e-4
    fd=(Gval(X+d)-Gval(X-d))/(2*d)
    sd=(Gval(X+d)-2*Gval(X)+Gval(X-d))/(d*d)
    check(f'Quantum finite first differential z={z0}',approx(fd,z0*mean(D),1e-6),'finite 3-state direct Z differentiates to z <S_x>',claim='p3e:prop:v358-finite-reduction-covariance')
    check(f'Quantum finite second covariance z={z0}',approx(sd,z0*2-(z0*z0/hbar)*cov(D,D),2e-6),'direct finite Z second difference equals Hessian-covariance',claim='p3e:prop:v358-finite-reduction-covariance')
# parameter integral via deterministic Simpson/scipy quad
from scipy.integrate import quad
def average(z0,arr):
    b=weights*np.exp(-z0*S/hbar);return np.dot(b,arr)/b.sum()
def covz(z0,a,b):return average(z0,a*b)-average(z0,a)*average(z0,b)
for zz in [.125,.5,2.5]:
    lhs=average(zz,D)-average(1.,D)
    rhs=-quad(lambda q:covz(q,D,S)/hbar,1,zz,epsabs=1e-12,epsrel=1e-12)[0]
    check(f'Quantum covariance integrated obstruction z={zz}',approx(lhs,rhs,1e-10),'oriented integral matches Gamma prime/z minus Gamma1 prime',claim='p3e:prop:v358-finite-reduction-covariance')

# 12. Gaussian determinant and source-dependent density correction
for z0 in [.125,.5,2.]:
    hbar=.8
    def setup(x0,density='lebesgue'):
        k=math.exp(x0*x0)
        rho=math.sqrt(k) if density=='geometric' else 1.
        # Gaussian integral Z= rho * sqrt(2pi*hbar/(z*k)) * exp[-z*A/hbar]
        A=x0+1
        return z0*A + .5*hbar*math.log(k)-hbar*math.log(rho)+(.5*hbar)*math.log(z0)-.5*hbar*math.log(2*math.pi*hbar)
    def dGamma(zval,density):
        st=z0
        def G(x0):
            k=math.exp(x0*x0);rho=math.sqrt(k) if density=='geometric' else 1.
            return zval*(x0+1)+.5*hbar*math.log(k)-hbar*math.log(rho)+.5*hbar*math.log(zval)-.5*hbar*math.log(2*math.pi*hbar)
        eps=1e-4
        return (G(.3+eps)-G(.3-eps))/(2*eps)
    lb=dGamma(z0,'lebesgue')-z0*dGamma(1.,'lebesgue')
    gg=dGamma(z0,'geometric')-z0*dGamma(1.,'geometric')
    check(f'Gaussian Lebesgue source measure jet defect z={z0}',approx(lb,hbar*(1-z0)*.3),'rho=1 leaves log det K source derivative',claim='p3e:cor:v358-gaussian-newton-measure')
    check(f'Gaussian geometric measure cancels source defect z={z0}',approx(gg,0,1e-10),'rho=sqrt det K is sufficient for exact first jet',claim='p3e:cor:v358-gaussian-newton-measure')
check('Gaussian second-jet mismatch with K=exp(x²)',approx(.8*(1-1/96),.8*95/96),'at x=0 first defect zero, second = hbar*95/96',kind='E4',claim='p3e:cor:v358-gaussian-newton-measure')

# 13. Exact unresolved cross-paper label test against original authoritative corpus
archive=Path('/mnt/data/Paper00-PapersMinimal-v2_370(1).zip')
with zipfile.ZipFile(archive) as zzip:
    all_labels=set()
    for name in zzip.namelist():
        if name.endswith('.tex'):
            dat=zzip.read(name).decode('utf-8','replace')
            all_labels.update(re.findall(r'\\label\{([^}]+)\}',dat))
    target=SOURCE.read_text().splitlines()
    bad=[]
    for i,line in enumerate(target[5611:],5612):
        for label in re.findall(r'\\(?:ref|eqref|autoref|cref)\{([^}]+)\}',line):
            if label not in all_labels:bad.append({'line':i,'label':label})
    check('Complete final-source cross-reference census',bad==[{'line':6095,'label':'p3f:sec:v229-action-tests'}],str(bad),'E4',claim='p3e:rem:v229-native-selection')

summary={'batch':6,'source_file':SOURCE.name,'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
         'range_lines':[5612,6449],'checked':len(results),'passed':sum(x['pass'] for x in results),
         'failed':[x for x in results if not x['pass']],
         'warning':'Symbolic and stress controls are evidence for stated identities only, not proof of physical occurrence.',
         'tests':results}
(ROOT/'Paper3E-Batch06-IndependentChecks-v1_1.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'checked':summary['checked'],'passed':summary['passed'],'failed':len(summary['failed'])},indent=2))
if summary['failed']:raise SystemExit(1)
