# Paper III-E — Rigorous verification and typed-DAG audit, batch 04

**Frozen target:** `Paper3E-GravityAction-v1_190.tex` (SHA-256 `c09e1f6c834e784d593f12827045a22b184671324c5091f2e50b12e076e3119b`), from `Paper00-PapersMinimal-v2_370(1).zip`. **Audit protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md`. **Authoritative current-source lines:** **3,238–4,382** of 6,449; the slice ends before the next capped-scalaron section. No parent paper or previously supplied archive was edited.

**Batch census:** 25 named formal declarations (3 VERIFIED; 19 VERIFIED-CONDITIONAL; 2 FORMALIZED; 1 UNRESOLVED), 23 replayed proof environments, 2 formal remarks. **E3:** 62/62 exact and high-precision controls pass; **E4:** 15 paper-theorem challenges plus 2 explicit in-domain REG-family mutation controls. Independent algebraic checks do not substitute for empirical or action-occurrence certificates.

**Single new open finding:** `BH-IIIE-G-0004` (moderate; scheme-dependent rank-four midpoint *decimal*). `BH-IIIE-G-0001`–`G-0003` remain open; no new defects are attributed to their unchanged proof paths. This is **PARTIALLY AUDITED** across the full paper; terminal DAG/archive integration is deferred.

## 1. Complete source-bound claim ledger

| Claim ID | Source lines | Source label or source title | Verdict | E3 and scope assessment |
|:---|:---|:---|:---|:---|
| BH-IIIE-C-0051 | 3252–3281 | `p3:def:normalized-reduced-shell-length` | FORMALIZED | Eigenvalue/trace normalization and endpoint exact checks in E3-B04. |
| BH-IIIE-C-0052 | 3283–3304 | `p3e:thm:entropy-effective-count-uniqueness` | VERIFIED | Independent semigroup-character argument plus octet/pure-state exact controls; no physical entropy process inferred. |
| BH-IIIE-C-0053 | 3323–3359 | `p3:thm:index-locking` | VERIFIED-CONDITIONAL | Independent spectrum normalization, Shannon-like entropy, derivative and both endpoint checks. |
| BH-IIIE-C-0054 | 3399–3423 | `p3:rem:index-locking-status` | VERIFIED-CONDITIONAL | Independent two-family signature-injectivity check on frozen support/scale/role; pointwise support rank degeneracy at C does not erase running family identity. |
| BH-IIIE-C-0055 | 3439–3464 | `p3e:def:primitive-quadratic-trace-inheritance` | FORMALIZED | Dimensionless residual has U χ / Z_C vs 16√ασ; positive Z_C necessary to define hatγ. |
| BH-IIIE-C-0056 | 3466–3510 | `p3e:thm:pqti-quadratic-normalization` | VERIFIED-CONDITIONAL | Independent coefficients 8×2×√ασ=16√ασ, ratio law, and scheme-rescaling covariance tested exactly. |
| BH-IIIE-C-0057 | 3580–3600 | `p3:def:reduced-curvature-transport-factor` | VERIFIED-CONDITIONAL | Cancel κ symbolically and verify g(C)=g(U)=1 and (C+U)R g=R²+CU. |
| BH-IIIE-C-0058 | 3609–3657 | `p3e:thm:regular-two-scale-terminal-reconstruction` | VERIFIED-CONDITIONAL | Independent solution of the second-order terminal value problem plus exact Euler identity and endpoint value. |
| BH-IIIE-C-0059 | 3684–3716 | `p3e:cor:two-scale-affine-junction-family` | VERIFIED-CONDITIONAL | Check affine kernel, sharp-regular slope and absence of change in Hessian. |
| BH-IIIE-C-0060 | 3728–3754 | `p3e:thm:canonical-covariant-hessian-pullback` | VERIFIED-CONDITIONAL | Independent general 2×2 quadratic form pullback, matrix Hessian, positive semidefiniteness, and semigroup exact control. |
| BH-IIIE-C-0061 | 3773–3802 | `p3e:thm:response-homothety` | VERIFIED-CONDITIONAL | Independent nonconstant dimensionless h=x² example and scale-invariant first derivative check. |
| BH-IIIE-C-0062 | 3812–3831 | `p3e:cor:uv-susceptibility-homothety` | VERIFIED-CONDITIONAL | Independent scaling check and alternative positive γ family; no numerical γ identified. |
| BH-IIIE-C-0063 | 3845–3870 | `p3:lem:curvature-transport-character` | VERIFIED-CONDITIONAL | Exact two-root scale substitution and midpoint square-root identity. |
| BH-IIIE-C-0064 | 3891–3911 | `p3e:thm:general-hessian-reconstruction` | VERIFIED | Independent polynomial h example with terminal value/slope and exact second derivative. |
| BH-IIIE-C-0065 | 3921–3942 | `p3e:cor:terminal-data-minimality` | VERIFIED | Independent rank test of endpoint map and Hessian-invisible affine shifts. |
| BH-IIIE-C-0066 | 3958–3979 | `p3e:thm:v2217-uv-ir-moment-nonuniqueness` | VERIFIED-CONDITIONAL | Independent polynomial χ moment integrals, weighted-mean bound, and endpoint-jet-preserving perturbation with both moments zero. |
| BH-IIIE-C-0067 | 4001–4016 | `p3:lem:protected-hessian-transport` | VERIFIED-CONDITIONAL | Independent U endpoint h(U)=γ/U and C endpoint h(C)=0; no additional scaling character arises within declared sorts. |
| BH-IIIE-C-0068 | 4033–4063 | `p3e:thm:complete-minimal-smooth-response-family` | VERIFIED-CONDITIONAL | Independent positivity/limits of factors and generic terminal reconstruction exact controls. |
| BH-IIIE-C-0069 | 4076–4123 | `p3e:cor:mresp-composite-witness-transport` | VERIFIED-CONDITIONAL | Independent uniqueness of C² output and source verification of the II-A Orig/RootReal conditional theorem; origin is a premise, not inferred from mere written formula. |
| BH-IIIE-C-0070 | 4144–4153 | `p3:lem:terminal-protected-slope` | VERIFIED-CONDITIONAL | Independent terminal derivative calculation; does not use a first-variation semigroup. |
| BH-IIIE-C-0071 | 4166–4173 | `p3:lem:terminal-hamiltonian-lagrangian-sign` | VERIFIED-CONDITIONAL | Direct endpoint subtraction independent of Hamiltonian interpretation. |
| BH-IIIE-C-0072 | 4183–4217 | `p3:thm:master-lagrangian` | VERIFIED-CONDITIONAL | Independent endpoint jet and convexity checks as a specialization of the general Cauchy theorem. |
| BH-IIIE-C-0073 | 4251–4271 | `p3e:thm:v2219-carrier-four-jets` | UNRESOLVED | Independent n4(q) derivative, tanh algebra and q↔R Jacobian; high precision agrees with REG0; valid REG positive σ=±1 changes D4(C2)/Q. |
| BH-IIIE-C-0074 | 4284–4303 | `p3e:prop:v288-cap-laurent-nonidentification` | VERIFIED-CONDITIONAL | Independent Hessian-limit incompatibility and analytic-regularity comparison. |
| BH-IIIE-C-0075 | 4319–4352 | `p3e:thm:v287-s3-acceleration-hessian` | VERIFIED-CONDITIONAL | Independent nonlinear cubic f(R) exact acceleration differentiation plus arbitrary first-jet boundary exemplar. |

**Claim/proof traceability:** every nondefinition entry has its adjacent proof span recorded independently in the JSON ledger; both definitions are recorded as FORMALIZED. The two remarks (lines 3,880 and 4,372) were checked as scope boundaries, not counted as proof theorems. Each claim links by actual ID to the relevant independent checks, with source assumptions and type qualifications in the machine ledger.

## 2. E1 source replay + E3 independent verification

### Entropy-effective state and protected action coefficients (lines 3,238–3,573)
The normalized active state has the source spectrum `1/(1+7u)` and `u/(1+7u)` with sevenfold degeneracy, for `u=ln(R/C)/ln(U/C) ∈ [0,1]`. Thus

```math
S(u)=\ln(1+7u)-\frac{7u}{1+7u}\ln u,\qquad \frac{dS}{du}=-\frac{7\ln u}{(1+7u)^2}.
```

The continuous entropy-sufficient multiplicative count on finite tensor products, with the pure and uniform-octet calibrations, is uniquely `N=e^S`. The independent E3 checks verify trace, spectrum, endpoint entropies (0 and `ln 8`), and the derivative; direct reasoning supplies the continuity/Cauchy-character argument. The count is a theorem in its declared finite-state domain, not a physical particle count.

The generated action uses separate matching classes: static `P0` has protected coefficient `1/8`, whereas the active seven-branch composite gets running nonlinear weight `e^S/8`. This use of the Paper II-A canonical signature theorem remains conditional on the *complete frozen support/scale/role signature* and occurring MRESPmin composite; it is not inferred from the support rank at the pure endpoint.

The PQTI certificate is an **actual same-action second-jet equality**, not a consequence of merely writing down an abstract square root. If that separately evaluated residual vanishes, the raw seed carries `sqrt(alpha_sigma)/8` and multiplying the entire action by eight yields `Q''=2` and `chi_UV=16 sqrt(alpha_sigma)/Lambda_EH^2`. Algebraic factor 16 and scheme covariance check independently. Neither the existence of a realized PQTI port nor an empirical value of gamma is certified by those equalities.

### Two-root response, terminal ODE, affine shifts and Hessian transport (lines 3,574–3,888)
The bare two-root response simplifies to `g(R)=(R^2+CU)/[(C+U)R]` (auxiliary kappa cancels) and satisfies `g(C)=g(U)=1`. With constant bare Hessian `h=2/(C+U)`, the terminal data `f(C)=0`, `f'(C)=1` give

```math
f_{\mathrm{reg}}(R)=(R-C)+\frac{(R-C)^2}{U+C},\qquad Rf_{\mathrm{reg}}^\prime-f_{\mathrm{reg}}=\frac{R^2+CU}{U+C}.
```

Changing the remaining affine member `kappa (R−C)` does not change the Hessian, but does shift the Euler/Legendre potential by `kappa C`. The source term “regular C1 member” is safe when read as a specified **junction-slope matching choice**; it cannot mean all other bare `[C,U]` members fail to be C1, because they too are C2 there. This distinction was tested adversarially and recorded as a wording scope guard, not a separate source failure.

For a covariant Hessian tensor under the minimal pullback `A_tau=e^{−tau/2} I`, `A_tau^* H A_tau=e^{−tau}H`; cross-term and semigroup tests pass. Scale homothety of a dimensionless response `f=U fhat(R/U)` forces `h=U^{−1} hhat` and, with fixed active weight, `chi_UV=gamma_sigma/U`. The amplitude `gamma_sigma` is **not numerically fixed by homothety**; the actual PQTI port remains an independent conditional route. The generated-owner scale is `U=Lambda_EH^2`, `C/U=alpha_sigma^{−7}` on the stated stage, with the Born midpoint a curvature scale rather than an automatic geometric radius.

### General Hessian reconstruction, UV/IR moments and occurring response (lines 3,889–4,232)
For a continuous specified Hessian `h`, double integration with two terminal jets determines a unique C2 `f`; the homogeneous kernel is exactly `span{1,R−C}`. A single independent scalar endpoint condition cannot remove both affine freedoms. The endpoint moments are the integral increments of `f'` and `R f'−f`, respectively, with integrands `chi` and `R chi`. A compactly supported C∞ second-derivative perturbation with vanishing zeroth and first moments gives distinct smooth interior profiles with identical endpoint germs. Both moment cancellations and endpoint cancellations pass independent checks.

The minimal curvature-Hessian response `h=(gamma/U) (e^{S(u)}/8) u` is nonnegative, zero at the protected endpoint and positive on the interior. Source-member terminal conditions on the total `f=R+C_sp`, namely `f(C)=0`, `f'(C)=1`, impose `C_sp(C)=−C`, `C_sp'(C)=0`. These are typed *source terminal data*, not a terminal-vacuum principle or a proof of a propagating scalar.

The conditional rooted-output witness theorem uses the Paper II-A generated-image theorem **only if** the frozen tuple is jointly occurring and a licensed finite word has the specified response-graph sort. Constructing a mathematical `C2` graph alone is not a Lorentzian metric/action realization. That physical promotion is expressly excluded in E1 and the E4 scope test.

### Rank-four Laurent freeze and capped/FLRW separation (lines 4,233–4,382)
Paper III-D’s actual-grade-four positive Laurent index `n_4^+` is zero below `C_4`; its first active derivative boundary occurs at `C_4`. At `C_2=√(U C_4)` the rank-four and seven-level indices are smooth. The source’s third-derivative jump evaluates to

```math
[f_{RRR}]_{C_4}=\frac{(U-C_4)\ln Q}{4C_4(U+C_4)\ln\alpha_\sigma}\,\chi_7(C_4)>0.
```

Independent differentiation of `ln cosh` and the `q↔R` Jacobian confirm this expression, and a midpoint regularity challenge is rejected. The symbolic discontinuity and its *location* therefore survive independently of the disputed decimal at `C_2`. The exact `D_4(C_2)/Q` value, however, varies with the positive REG scheme; see G-0004 below.

The capped gravity density and positive-part Laurent comparator are not equal on the same curvature chart: the latter has a Hessian tending to zero at `C_7`, while the cited capped analytic response, on the condition `2BU>d`, has Hessian bounded below by `2BU−d>0`. Affine modifications do not fix a Hessian mismatch. This is a **same-chart nonidentification**, not a prohibition on all cross-owner correspondences.

For the k=+1 round closed-three-sphere homogeneous metric jet, the unreduced local Lagrangian `L_f=2 pi^2 Z N a^3 f(R)` has

```math
\frac{\partial^2L_f}{\partial\ddot a^2}=\frac{72\pi^2 Za}{N^3}f_{RR}(R).
```

The `R`-versus-acceleration derivative, second derivative, and boundary first-jet invariance tests pass. This **does not** count the physical propagating scalar modes; Hamiltonian constraints or physical solution space are not included. The final formal remark keeps older rank-two/K16-kink comparisons historical, not active source results.

## 3. New issue certificate — BH-IIIE-G-0004

| Field | Source-verified value |
|:---|:---|
| Issue class / severity | `TYPE_OR_DOMAIN` with numerical-readout scope; **moderate**, OPEN |
| Earliest located source | `Paper3E-GravityAction-v1_190.tex:4251–4259`, `p3e:thm:v2219-carrier-four-jets` |
| Source assertion | `D_4(C_2)/Q=0.825729956674...`, with no explicit `REG_0` qualifier in the theorem as printed |
| Verified positive control | `ln alpha_0=4pi^2+1/(6sqrt2)` gives **0.8257299566743899173773...** |
| In-domain variation | `sigma_fin=+1` gives **0.8261002425941142257374...**; the ratio is not scheme-invariant |
| Target of finding | **Only** the unqualified decimal’s domain; not the exact positive-part index, `C_2` midpoint, `C_4` freeze or third-jet jump |
| Required adjudication | Establish an already licensed source `REG_0` guard for this numeric claim, or show the claim was explicitly intended scheme-relative; no new mechanism or changed numerical definition is authorized |
| Remote effects | A downstream use of this *particular number* could inherit the qualification; no verified downstream material path currently located |

The exact scheme-parametric expression checked is

```math
\frac{D_4(C_2)}{Q}=\exp\!\left[\ln Q\left(\frac{\ln\cosh(2\ln\alpha_\sigma)}{2\ln\alpha_\sigma}-1\right)\right],\qquad Q=8\sqrt{\alpha_\sigma}.
```

Changing sigma is an **in-domain** counterexample to the uniform-decimal interpretation, not a counterexample to the source’s conditional algebraic rank-four result. The evidence identifiers are `E3-IIIE-B04-057`, `E4-IIIE-B04-058`, `E4-IIIE-B04-059` and `E4-IIIE-B04-011`. The issue remains open for precise published-scope adjudication; this audit did not edit the paper.

## 4. Adversarial E4 challenge register

| ID | Matched challenge | Verdict | Reason / boundary |
|:---|:---|:---|:---|
| E4-IIIE-B04-001 | Could N(ρ)=exp(k S(ρ)) with k≠1 obey every premise? | REJECTED | Octet condition forces 8^k=8, k=1; without entropy sufficiency/multiplicativity alternative counts are explicitly enlarged roles. |
| E4-IIIE-B04-002 | Treat III-D secant-matched entropy state as active MRESP state. | INVALID-TYPE-MERGE | III-C generates ρτ from same visibility process; u=log(R/C)/log(U/C) inversion is independent of III-D n_sec. |
| E4-IIIE-B04-003 | At u=0, σact has rank one, same as P0; does that invalidate type separation? | REJECTED-BY-FAMILY-SIGNATURE | Signature uses frozen role and scale dependence of complete constituent, not pointwise support rank at one endpoint. Same-image of generated term signatures is a conditional input. |
| E4-IIIE-B04-004 | Mutate γ to g≠16sqrt(ασ) while keeping MRESP homothety. | VALID MRESP-ONLY CONTROL, INVALID PQTI COUNTEREXAMPLE | Shows PQTI is an additional evaluated actual-action certificate; mutated g fails its coefficient residual. No unconditional coefficient selection claimed. |
| E4-IIIE-B04-005 | Add affine κ(R−C) to constant Hessian and demand same Euler potential. | REJECTED-BY-EXPLICIT-TERMINAL-SLOPE | Violates fixed Z_C=1; the next corollary explicitly keeps this affine family. |
| E4-IIIE-B04-006 | Use a nonlinear amplitude A with nonzero D²A to produce extra Hessian term. | OUT-OF-DOMAIN | Theorem requires linear generated amplitude A:W→W and Hessian at origin; nonlinear A changes type/grammar. |
| E4-IIIE-B04-007 | Choose χ(U)=U^(-2) and expect homothety. | REJECTED | Violates exact λ^-1 Hessian scaling when visibility factors are dimensionless and nonzero on interior. |
| E4-IIIE-B04-008 | One nonlocal scalar boundary condition could fix both affine coefficients nonlinearly. | OUT-OF-DOMAIN | Statement explicitly concerns continuous linear scalar conditions; rank ≤1 for one linear functional. |
| E4-IIIE-B04-009 | Perturb by smooth interior u, preserve both endpoint moments but change interior curvature. | VALID POSITIVE WITNESS (SUPPORTS THEOREM) | u and u′ vanish on collars, giving ∫u″=0, ∫R u″=0; small \|epsilon\| preserves χ>0 on support. |
| E4-IIIE-B04-010 | Infer a real physical metric action from the mathematical graph alone. | REJECTED-BY-SORT | Source requires jointly occurring input tuple and an explicitly frozen output sort RespGraph; Lorentzian action is a different sort. |
| E4-IIIE-B04-011 | Vary REGσ within I+ and test printed scheme-independent midpoint decimal. | VALID SOURCE-DOMAIN CHALLENGE — BH-IIIE-G-0004 | REG0 yields 0.825729956674389917; σ=+1 yields 0.826100242594114226. Exact symbol formula survives; number needs REG0 guard. |
| E4-IIIE-B04-012 | Seek a third-derivative kink at Born midpoint C2. | REJECTED | C2>C4>C7, both n4 and n7 raw Laurent indices smooth in neighborhood of C2; kink arises at positive-part boundary C4. |
| E4-IIIE-B04-013 | Add affine term and multiply comparator by finite nonzero scalar to match cap at C7. | REJECTED | Comparator second derivative tends to zero, cap lower bound remains >0; affines cannot change second derivatives. |
| E4-IIIE-B04-014 | Interpret nonzero unreduced acceleration Hessian as automatic propagating scalar mode. | INVALID-PHYSICAL-PROMOTION | No Hamiltonian constraints or physical scalaron sector provided by this jet calculation; source expressly disclaims it. |
| E4-IIIE-B04-015 | Interpret “regular C1 member” as a claim other κ have no C1 regularity within [C,U]. | WORDING-SCOPE BOUNDARY | All κ members are C2 on bare interval. “Regular” must refer to the source-matched terminal junction slope; not used to infer intrinsic loss of C1. |

Two additional numerical mutant schemes (`sigma_fin=−1,+1`) were evaluated within the declared REG positive family; both changed the numeric midpoint ratio. All 62 E3 scalar/symbolic controls pass. Adversarial challenges rejected by the theorem’s explicit domain do not generate new issue nodes.

## 5. Constructor/condition and typed-import boundaries

**BND-IIIE-B04-001** — Paper3E lines 3244-3437. `[CONST] MRESPmin typed co-realized family` → `[GEN] III-C visibility/normalized state` → `[DER] entropy count unique by sufficiency/multiplicativity` → `[ID] map to nonlinear action under matching signature`. E/U of entropy coupling derived; physical occurrence and terms require jointly occurring MRESP.

**BND-IIIE-B04-002** — Paper3E lines 3439-3573. `[CONST] separate actual-action PQTI compare` → `[DER] positive tensor-square half character` → `[CAL] octet scalar trace whole-action normalization` → `[ID] γ/ZC fixed only after PQTI residual zero`. No action appearance inferred from an abstract positive tensor square; separate physical comparison required.

**BND-IIIE-B04-003** — Paper3E lines 4233-4304 and III-D lines 1479-1556, 1835-1870. `[CONST] rank-character n_j^L(α) for positive REGσ` → `[GEN] first carrier grade P4` → `[DER] n4 positive-part freeze at C4` → `[CAL] printed D4(C2)/Q decimal matches REG0 only`. Exact scheme-parametric freeze is valid; decimal scope pending REG0 anchor.

**BND-IIIE-B04-004** — Paper3E lines 4076-4142, II-A lines 2219-2300. `[FROZEN] joint input tuple, schema and output sort before evaluation` → `[GEN] finite integration word to C2 graph` → `[DER] independent unique graph and non-obstructed conditional realization` → `[REAL] no automatic Lorentzian action realization`. Rooted generated-image theorem applies only on the declared origin-certified joint input domain.

**BND-IIIE-B04-005** — Paper3E lines 4284-4369, III-F lines 7819-7856. `[CONST] cap f_c action on its independent source/boundary ports` → `[DER] analytic positive cap fRR bound` → `[HOST] separate rank4 Laurent comparator` → `[DER] Hessian mismatch on shared curvature chart` → `[REAL] local FLRW acceleration jet not physical extra scalar mode`. Common-parent reductions and owner substitutions not automatically identified; same chart only.

**Material imports replayed at their exact interface (not full peer-paper re-audits):**

- `PaperIII-C / p3c:cor:corealized-protected-visibility-family` (Paper3C 3326-3363): full normalized ρτ and entropy postprocessor under occurring active composite.
- `PaperII-A / p2:cor:canonical-constituent-identification` (Paper2A 2738-2771): injective equal-image frozen signature allows unique 2-term identification.
- `PaperII-A / p2a:thm:rooted-generated-image-corealization` (Paper2A 2219-2300): conditional generated image co-realization after licensed Orig word.
- `PaperIII-D / p3d:cor:rank-character-laurent-family` (Paper3D 1479-1573): n_j positive/full secants and C_j positions.
- `PaperIII-D / p3d:thm:v2219-carrier-four-dressing` (Paper3D 1835-1870): first actual carrier-grade j=4 instead of optional least-support j=2.
- `PaperIII-F / p3f:prop:v223-cap-legendre` (Paper3F 7819-7856): independent uniform cap Hessian lower bound under 2BU>d.
- `PaperIII-B / p3b:thm:generated-action-response-owner` (Paper3E 1142-1162; Paper3B located): generated U=Λ_EH² identity-stage section.

The JSON ledger separately records verified typed `IMPORTED_PROOF` and `ISSUE_AT` edges with source locators and guard predicates. It does **not** invent global assumption IDs or reintroduce G0/GP1–GP3 and already recorded canonical conditions as new nodes. Any assumptions newly encountered in this batch must be reconciled against the global registry at the final merge.

## 6. Other open findings, scope firewall and release status

- **BH-IIIE-G-0001 (moderate, Batch 1):** Clifford `W` 7-real block vs the spin grading carrier `W_L⊕W_R`; overloaded map codomain/`Gamma_W` needs typed declaration. This batch does not modify that theorem.
- **BH-IIIE-G-0002 (moderate, Batch 1):** unique positive CRP4 connection along scheme-depth base `B` does not uniquely determine a full bundle connection on `B×M`; the established B-transport stays valid.
- **BH-IIIE-G-0003 (moderate, Batch 2):** relative/noncompact trace-per-volume need not make the unlocalized heat operator ordinary trace class. Compact finite/smooth heat-port proofs remain intact.
- **BH-IIIE-G-0004 (moderate, this batch):** numerical scheme guard at rank-four midpoint; exact Laurent positive-part geometry and C4 jump independently verified.

**Active scope firewalls:**

- Metric f(R) action physically occurring is not derived from smooth response-graph reconstruction.
- PQTI amplitude equality is evaluated action-port comparison, not tensor-square type alone.
- Affine Hessian kernel does not fix full zero-order response/Legendre potential without terminal data.
- Rank-four positive Laurent comparator is not the capped gravity working density.
- FLRW acceleration jet Hessian alone is not propagating scalaron certificate.
- Section 4372 old rank-two K16 kink is explicitly comparison-only/superseded.
- Source-regime scheme-zero midpoint number must not be treated as σ-independent prediction.

**Cumulative coverage after Batch 4:** **75/115** named claims, **62/92** proof environments, **16/30** formal remarks, source through **line 4,382**, four open findings. Not-yet-reviewed source starts at line **4,383**, with capped scalaron and further physical-action ports. Current overall status: `PARTIALLY_AUDITED` (correctness of unreviewed downstream source is not inferred).

**Archive retention:** `Paper00-DAGAtlas-v1_102(1).zip`, `Paper00-ProofChainAudits-v1_20(1).zip` and source `Paper00-PapersMinimal-v2_370(1).zip` are **unchanged**. The final batch will merge the complete target audit, deduplicate canonical conditions and issues, run schema/archive validation, and package only latest component versions in the DAG and audit ZIP successors. This batch releases intermediate markdown/JSON/reproducible controls only.

**Reproducibility and limitations:** `Paper3E-RigorousVerificationBatch04-v1_1.json` gives every named declaration’s exact source/proof span, verdict, independent evidence IDs, scoped imported uses, 15 theorem-level E4 challenges, one complete new gap certificate, and five boundary adjudications. `Paper3E-Batch04-IndependentChecks-v1_1.json` gives 62 exact/precision E3 controls plus 2 scheme-mutation checks; companion `.py` scripts regenerate the deterministic checks. Tests establish identities on declared mathematical domains, not experimental validation or actual physical occurrence. No archive was released or claimed to have passed final global DAG verification.
