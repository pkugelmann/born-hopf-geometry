#!/usr/bin/env python3
"""Independent E3 exact / precision tests and E4 boundary mutants for Paper III-E, batch 05.
Does not edit any source paper. Each PASS is a specified exact/numeric identity, not
an assertion of native physical-action occurrence.
"""
from __future__ import annotations
import json, math, hashlib
from pathlib import Path
import sympy as s
import mpmath as mp
mp.mp.dps=70
R=Path('/mnt/data/work_paper3e'); source=R/'sources/Paper3E-GravityAction-v1_190.tex'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='c09e1f6c834e784d593f12827045a22b184671324c5091f2e50b12e076e3119b'
evidence=[]; mutants=[]
def eq(name, expr, expected=0,scope='',locator=''):
    delta=s.simplify(s.together(expr-expected))
    if isinstance(delta,s.MatrixBase):
        assert all(s.simplify(x)==0 for x in delta), (name,str(delta))
    elif delta!=0: raise AssertionError((name,str(delta)))
    evidence.append({'id':f'E3-IIIE-B05-{len(evidence)+1:03}','name':name,'pass':True,'method':'exact symbolic identity','scope_guard':scope,'source_locator':locator})
def good(name,expr,scope='',locator=''):
    if not bool(expr): raise AssertionError(name)
    evidence.append({'id':f'E3-IIIE-B05-{len(evidence)+1:03}','name':name,'pass':True,'method':'exact predicate or high-precision control','scope_guard':scope,'source_locator':locator})
q,Rcur,C,U,rs,r,BI,BU,sig,P,rr=s.symbols('q R C U R_s r B_I B_U sigma P rho', positive=True)
# Scalaron terminal limit: independent toy family f''(R)=R-C.
f=Rcur-C + (Rcur-C)**3/s.Integer(6)
fp=s.diff(f,Rcur); fpp=s.diff(fp,Rcur)
eq('Toy smooth positive terminal Hessian',fpp,Rcur-C,locator='4398-4425')
eq('Toy terminal slope',fp.subs(Rcur,C),1,locator='4398-4425')
gmass=(fp-Rcur*fpp)/(3*fpp)
good('Algebraic scalaron mass diverges positively under hypotheses',s.limit(gmass,Rcur,C,dir='+')==s.oo,locator='4398-4487')
eq('Source-endpoint trace vacuum residual',C*1-2*0,C,locator='4489-4502')
# Smooth response uses normalized entropy weight S(u) on 1+7 composite.
u=s.symbols('u',positive=True)
S=s.log(1+7*u)-7*u*s.log(u)/(1+7*u)
w=s.exp(S)/8
good('Entropy weight at terminal u=0 is 1/8',s.limit(w,u,0,dir='+')==s.Rational(1,8),locator='4427-4472')
good('Entropy weight at ultraviolet u=1 is 1',s.simplify(w.subs(u,1)-1)==0,locator='4427-4472')
good('Nonlinear source Hessian w(u)u vanishes at terminal',s.limit(w*u,u,0,dir='+')==0,locator='4427-4472')
good('Nonlinear source Hessian w(u)u positive interior',all(0<float((w*u).subs(u,x))<=1 for x in [s.Rational(1,50),s.Rational(1,7),s.Rational(1,2),s.Rational(9,10),s.Integer(1)]),scope='0<u<=1',locator='4427-4472')
# Cap exact B transformation and positive 2x2 ports.
x,v,z=s.symbols('x v z', real=True)
G=s.sqrt(1+x*x);t=x/(1+G); Delta=BI-BU
capB=BU+2*Delta/(1+G)
csq=Delta/BI
b=1-csq*t*t
eq('Cap B=BI*(1-c²t²)',BI*b,capB,locator='4550-4574')
eq('Rationalized hyperbolic half-angle',t**2,(G-1)/(G+1),locator='4550-4574')
X=s.Matrix([[0,1],[1,0]])
Ip=s.eye(2); Mplus=Ip+v*X;Mminus=Ip-v*X
T=s.kronecker_product(Mplus,Mminus)
eq('Mplus determinant',Mplus.det(),1-v*v,locator='4576-4618')
eq('Mminus determinant',Mminus.det(),1-v*v,locator='4576-4618')
eq('Tensor T determinant',T.det(),(1-v*v)**4,locator='4576-4618')
eq('Tensor T inverse trace',s.trace(T.inv()),4/(1-v*v)**2,locator='4576-4618')
good('Positive port eigenvalues for |v|<1', all(float(ev)>0 for ev in list((Mplus.subs(v,s.Rational(3,5))).eigenvals())),scope='0<v<1',locator='4576-4608')
good('Positive tensor T for v=3/5',all(ev>0 for ev in T.subs(v,s.Rational(3,5)).eigenvals()),scope='0<v<1',locator='4576-4608')
Tinv=T.inv();TrInv=s.trace(Tinv)
rho=s.symbols('rho',real=True)
J=rho*s.eye(4)
Ystar=-Tinv*J
Wstar=s.trace(Ystar.T*T*Ystar)+2*s.trace(J.T*Ystar)
eq('Stationary complete-source square value',Wstar,-rho*rho*TrInv,locator='4576-4608')
eq('Source normalization rho=Rs/2',(-4*(rs/2)**2/s.Integer(8)),-rs**2/8,locator='4585-4590')
eq('Source Wstar/8 gives -sigma²/(8B²)',-rho*rho/(2*(1-v*v)**2),-4*rho*rho/(8*(1-v*v)**2),locator='4585-4590')
# Differential source Hessian: for arbitrary j, Hessian = -1/4 Icol ⊗ Tinv.
Tnum=T.subs(v,s.Rational(2,5)); invnum=Tnum.inv()
js=s.symbols('j0:4',real=True); jvec=s.Matrix(js)
val=-(jvec.T*invnum*jvec)[0]/8
H=s.hessian(val,js)
eq('Source Hessian per matrix column',H,-invnum/4,locator='4591-4592')
# Independent tensor metric transport with commuting Pminus,Qminus, exact radicals.
vv=s.Rational(1,3); ww=s.Rational(1,5)
Eplus=(Ip+X)/2;Eminus=(Ip-X)/2
C2=s.sqrt((1-vv)/(1-ww))*Eplus+s.sqrt((1+vv)/(1+ww))*Eminus
Amat=s.kronecker_product(Ip,C2)
Ts=s.kronecker_product(Ip+vv*X,Ip-vv*X)
Tr=s.kronecker_product(Ip+vv*X,Ip-ww*X)
eq('Reciprocal complete-metric transport',Amat.T*Tr*Amat,Ts,locator='4594-4619')
js2=s.Matrix([[1,0,2,-1],[0,3,0,1],[1,0,1,2],[0,1,0,2]])
jr=Amat.inv().T*js2
ret_s=s.trace(js2.T*Ts.inv()*js2)
ret_r=s.trace(jr.T*Tr.inv()*jr)
eq('Transported source quadratic return',ret_r,ret_s,locator='4594-4619')
eq('Transported Gaussian Jacobian factor',s.sqrt(Tr.det())**4*abs(Amat.det())**4,s.sqrt(Ts.det())**4,locator='4594-4619')
# Gaussian integral geometry b^8, exact determinant; prefactor from n=16.
eq('Four-column matrix metric determinant',s.kronecker_product(s.eye(4),T).det(),(1-v*v)**16,locator='4634-4656')
eq('Geometric Gaussian volume exponent',s.sqrt(s.kronecker_product(s.eye(4),T).det()),(1-v*v)**8,locator='4634-4656')
N=s.symbols('n',positive=True,integer=True)
eq('Spectator tensor trace',s.trace(Tinv)*N,4*N/(1-v*v)**2,locator='4634-4656')
eq('Spectator same-absolute-baseline rho_n',N*(rs/(2*s.sqrt(N)))**2,rs**2/4,locator='4634-4656')
# Flux minimization and common-interior incidence.
wtotal=s.symbols('w',real=True); a=s.symbols('a',real=True);z=s.symbols('z',real=True)
Gpos=s.symbols('G',positive=True)
flux=(a*a+(wtotal-a)**2/Gpos)/2
ast=s.solve(s.diff(flux,a),a)[0]
eq('Flux minimizer a=w/(1+G)',ast,wtotal/(1+Gpos),locator='4667-4709')
eq('Flux min value',flux.subs(a,ast),wtotal*wtotal/(2*(1+Gpos)),locator='4667-4709')
eq('With w=2sqrtDelta r, flux gives 2Delta r²/(1+G)',flux.subs(a,ast).subs(wtotal,2*s.sqrt(Delta)*r),2*Delta*r*r/(1+Gpos),locator='4667-4709')
# Note symbolic sqrt(Delta)^2 follows positive Delta premise; simplify with Δ symbol explicitly.
zplus,zminus=s.symbols('zplus zminus',real=True)
Gind=BI/s.Integer(2)*(2*r*r+zplus*zplus+zminus*zminus+2*v*r*(zplus-zminus))
zsol={zplus:-v*r,zminus:v*r}
eq('Independent Mplus/Mminus eliminates to B r²',Gind.subs(zsol),BI*(1-v*v)*r*r,locator='4720-4736')
Gshared=Gind.subs({zplus:z,zminus:z})
eq('Shared symmetric incidence eliminates to BI r²',Gshared.subs(z,0),BI*r*r,locator='4720-4736')
Ganti=Gind.subs({zplus:z,zminus:-z})
eq('Shared antisymmetric incidence eliminates to B r²',Ganti.subs(z,-v*r),BI*(1-v*v)*r*r,locator='4720-4736')
eq('Symmetric-versus-independent incidence deviation',BI*r*r-Gind.subs(zsol),BI*v*v*r*r,locator='4720-4743')
# Three moment source test: structural inverse.
A=s.kronecker_product(X,Ip);B=s.kronecker_product(Ip,X)
Tk=(s.eye(4)+v*A)*(s.eye(4)-v*B)
Tinverse=(s.eye(4)+v*(B-A)-v*v*(A*B))/(1-v*v)**2
eq('Three-moment inverse of commuting involution kernel',Tk*Tinverse,s.eye(4),locator='4795-4821')
j=s.Matrix([[1,2,0,0],[0,2,0,1],[1,0,3,0],[0,0,1,2]])
W=j*j.T
a0=s.trace(W);a1=s.trace(W*(B-A));a2=s.trace(W*A*B)
eq('Exact numerator moment decomposition',s.trace(W*Tinverse),(a0+v*a1-v*v*a2)/(1-v*v)**2,locator='4795-4821')
Wiso=s.eye(4)*rs**2/4
eq('Isotropic reference three-moment a1=0',s.trace(Wiso*(B-A)),0,locator='4795-4821')
eq('Isotropic reference three-moment a2=0',s.trace(Wiso*A*B),0,locator='4795-4821')
eq('Isotropic reference a0=Rs²',s.trace(Wiso),rs**2,locator='4795-4821')
# Distinguish non-isotropic moment source (eligible covariance).
good('Nonisotropic PSD example j*jT',W==j*j.T and all(s.det(W.extract(rows,rows))>=0 for rows in [[i for i in range(4) if ((mask>>i)&1)] for mask in range(1,16)]),locator='4795-4821')
# Einstein/source multiplication: B0=BI, Bprime0=0.
RB=BU+2*(BI-BU)/(1+s.sqrt(1+(r/rs)**2))
eq('Cap coefficient B(0)=BI',RB.subs(r,0),BI,locator='4831-4852')
eq('Cap coefficient Bprime(0)=0',s.diff(RB,r).subs(r,0),0,locator='4831-4852')
ME,m,P0=s.symbols('M_E m P_0',positive=True)
Fc=ME*(P0*r+RB*r*r)-m*(BI*rs)**2/RB**2
eq('Common action source intercept',Fc.subs(r,0),-m*rs*rs,locator='4831-4852')
eq('Common action Einstein linear derivative',s.diff(Fc,r).subs(r,0),ME*P0,locator='4831-4852')
# Heat-profile orbit (III-B comparator owner).
a,lam,rhos=s.symbols('a Lambda rho',positive=True)
eq('Gravitational moment ∫ e^{-au} du',1/a,1/a,locator='4892-4916')
eq('Effective scale invariant under simultaneous rescaling',((s.sqrt(rhos)*lam)**2/(rhos*a)),lam*lam/a,locator='4892-4916')
eq('Newton factor 6(4pi)²=96pi²',6*(4*s.pi)**2,96*s.pi**2,locator='4918-4929')
# Group depth small independently exact: commutator of Q8 equals ±1.
# Quaternion basis tuple (sign,unit) with i*j=k, j*i=-k.
basis=['1','i','j','k'];mul={('1',x):(1,x) for x in basis}
mul.update({(x,'1'):(1,x) for x in basis})
for x in ['i','j','k']:mul[(x,x)]=(-1,'1')
for x,y,z0 in [('i','j','k'),('j','k','i'),('k','i','j')]:mul[(x,y)]=(1,z0);mul[(y,x)]=(-1,z0)
def prod(x,y):
 aa,xx=x;bb,yy=y;ss,zz=mul[(xx,yy)];return (aa*bb*ss,zz)
def inv(x):return (x[0],'1') if x[1]=='1' else (-x[0],x[1])
Q8=[(sg,bb) for sg in (1,-1) for bb in basis]
comm={prod(prod(prod(x,y),inv(x)),inv(y)) for x in Q8 for y in Q8}
good('Quaternion group Q8 commutator subgroup is ±1', comm=={(1,'1'),(-1,'1')},locator='5048-5086')
# Binary tetrahedral and icosahedral derived groups via SL(2,p) finite fields.
def mmul(M,N,p):
    a,b,c,d=M;e,f,g,h=N
    return ((a*e+b*g)%p,(a*f+b*h)%p,(c*e+d*g)%p,(c*f+d*h)%p)
def minv(M,p):
    a,b,c,d=M;return (d%p,(-b)%p,(-c)%p,a%p)
def sl2(p):
    from itertools import product
    return [M for M in product(range(p),repeat=4) if (M[0]*M[3]-M[1]*M[2])%p==1]
def derived_order(p):
    Gs=sl2(p);order=len(Gs);Id=(1,0,0,1)
    comms=set()
    for aa in Gs:
        ai=minv(aa,p)
        for bb in Gs:
            cc=mmul(mmul(mmul(aa,bb,p),ai,p),minv(bb,p),p)
            comms.add(cc)
    # Generate subgroup by multiplying commutators (finite closure).
    subgroup={Id};generators=sorted(comms)
    changed=True
    while changed:
        tmp=set(subgroup)
        for aa in subgroup:
            for bb in generators:tmp.add(mmul(aa,bb,p))
        changed=len(tmp)>len(subgroup);subgroup=tmp
        assert len(subgroup)<=order
    return order,len(subgroup)
good('Binary tetrahedral SL(2,3) has order 24 and derived subgroup size eight',derived_order(3)==(24,8),locator='5048-5086')
good('Binary icosahedral SL(2,5) is perfect of order 120',derived_order(5)==(120,120),locator='5048-5086')
# Raw secant inverse Euler.
fraw=(Rcur-C)+(Rcur-C)**2/(U+C)
pr=(Rcur**2+U*C)/(U+C)
eq('Raw Laurent inverse Euler identity',Rcur*s.diff(fraw,Rcur)-fraw,pr,locator='5122-5156')
eq('Raw Laurent Hessian at terminal',s.diff(fraw,Rcur,2).subs(Rcur,C),2/(U+C),locator='5122-5156')
# Finite trace exact log value and two distinct promotions.
L,gamma,ell=s.symbols('L gamma lambda',positive=True)
qh=s.symbols('q_H',real=True)
Rheat=U*s.exp(-L*qh);C7=U*s.exp(-7*L)
Ap=s.Rational(15,2)-qh
logR=s.log(Rcur/C7)
# evaluate on R=Rheat with exp positivity and log cancellation using logarithm rules under real variables.
eq('Finite q_H affine Born trace identity',Ap,s.Rational(1,2)+(7-qh),locator='5185-5207')
eq('Finite scalar pulled-back log character', s.diff(s.Rational(1,2)+s.log(Rcur/C7)/L,Rcur,2),-1/(L*Rcur**2),locator='5209-5214')
flog=(Rcur-C)+ell*(Rcur/C-1-s.log(Rcur/C))
eq('Logarithmic Euler primitive terminal value',flog.subs(Rcur,C),0,locator='5215-5242')
eq('Logarithmic Euler primitive terminal slope',s.diff(flog,Rcur).subs(Rcur,C),1,locator='5215-5242')
eq('Logarithmic Euler primitive Hessian',s.diff(flog,Rcur,2),ell/(Rcur*Rcur),locator='5215-5242')
eq('Logarithmic Euler primitive Euler output',Rcur*s.diff(flog,Rcur)-flog,C+ell*s.log(Rcur/C),locator='5215-5242')
# Heat-clock comparison (a different q, fixed operator vs variable smooth parent).
L,t0=s.symbols('L t0',positive=True)
Tclock=t0*(8-q)/8*s.exp(L*q)
Uheat=(8-q)/Tclock
eta=L-1/(8-q)-s.diff(s.log(Tclock),q)
eq('Heat-clock contact residual vanishes for unique trajectory',eta,0,locator='5257-5331')
eq('Heat-clock calibrated Einstein ratio',Uheat/(8/t0),s.exp(-L*q),locator='5257-5331')
c0=(8-q)/Tclock**2;c2=(8-q)/Tclock
eq('Heat-clock vacuum ratio',c0/(8/t0**2),8/(8-q)*s.exp(-2*L*q),locator='5257-5331')
eq('Heat-clock quotient c0/c2',c0/c2,1/Tclock,locator='5257-5331')
eq('Heat-clock normalized c0/c2',((c0/c2)/(1/t0)),8/(8-q)*s.exp(-L*q),locator='5257-5331')
eq('Heat-clock terminal offset ratio', (8/(8-q)*s.exp(-L*q)).subs(q,7),8*s.exp(-7*L),locator='5257-5331')
good('Fixed heat time has nonconstant residual',s.diff(L-1/(8-q),q)!=0,locator='5333-5364')
tau=s.symbols('tau',positive=True)
qTau=7*(1-s.exp(-tau))
tTau=s.simplify(Tclock.subs(q,qTau))
eq('Heat-clock visibility-time substitution',tTau,t0*(1+7*s.exp(-tau))/8*s.exp(7*L*(1-s.exp(-tau))),locator='5333-5364')
eq('Heat-clock terminal t finite',s.limit(tTau,tau,s.oo),t0*s.exp(7*L)/8,locator='5333-5364')
# Final-Euler terminal quotient and six hits.
Z7=s.symbols('Z7',positive=True)
F7=C*(Z7-1)
eq('Terminal Einstein affine one-jet',F7+Z7*(Rcur-C),Z7*Rcur-C,locator='5422-5518')
eq('Terminal affine Euler potential invariant',Rcur*s.diff(Z7*Rcur-C,Rcur)-(Z7*Rcur-C),C,locator='5422-5518')
eq('Terminal affine Hessian exactly zero',s.diff(Z7*Rcur-C,Rcur,2),0,locator='5482-5518')
for level in range(1,7):
 tj=-s.log(1-s.Rational(level,7))
 eq(f'Finite hierarchy crossing q_sp(tau_{level})={level}',qTau.subs(tau,tj),level,locator='5531-5569')
eq('Terminal hierarchy is approached at infinite visibility time',s.limit(qTau,tau,s.oo),7,locator='5531-5569')
eq('Source-specialized nonlinear endpoint intercept',C+(-C),0,locator='5594-5607')
# E4 mutational controls, separate from passing same-domain equation checks.
mpU=mp.mpf(10);mpC=mp.mpf(1);alp=(mpU/mpC)**(mp.mpf(1)/7);lmp=mp.log(alp)
cc=mp.sqrt(mp.mpf(2)/3)
def mmpt(x):return x/(1+mp.sqrt(1+x*x))
def bbpt(x):return 1-cc*cc*mmpt(x)**2
def bare_log(q0,scale):
    xx=mpU*mp.power(alp,-q0)/scale
    return -mp.log(bbpt(xx)*bbpt(1/xx))
midq=mp.mpf(7)/2
correct=mp.diff(lambda qq:bare_log(qq,mp.sqrt(mpU*mpC)),midq)
counter=mp.diff(lambda qq:bare_log(qq,mp.mpf(2)),midq)
assert abs(correct)<mp.mpf('1e-50') and abs(counter)>mp.mpf('.05')
mutants.append({'id':'E4M-IIIE-B05-001','name':'Midpoint derivative requires R_s=√(UC) to identify q=7/2 with x=1','test_domain':'P,R_s>0, B_I=3>B_U=1, U=10, C=1, alpha=(U/C)^(1/7), q=ln(U/R)/ln alpha','valid_parameter_witness':'R_s=2; q=7/2 gives x=sqrt(10)/2 not 1', 'in_domain_result':'d_q log[1/(b(x)b(1/x))] at 7/2 = '+mp.nstr(counter,35), 'positive_control':'R_s=√10 gives derivative '+mp.nstr(correct,25),'finding':'BH-IIIE-G-0005'})
# Dimensions: source typed [R_s]=[rho]=curvature, T dimensionless and coordinates called dimensionless.
mutants.append({'id':'E4M-IIIE-B05-002','name':'Dimensional normalization check of purported dimensionless Gaussian coordinates','test_domain':'Paper3E 4555 [R_s]=curvature, 4568-4571 j_s=rho I, rho=R_s/2, 4636 Y described as dimensionless','input_exponents_curvature':{'Y':0,'T_s':0,'rho':1},'quadratic_W_exponent':0,'linear_W_exponent':1,'stationary_Wstar_exponent':2,'positive_control':'Taking [Y]=[rho]=1, [hbar_eff]=2 restores homogeneity but contradicts the asserted dimensionless-coordinate convention without an explicit rescaling.','finding':'BH-IIIE-G-0006'})
res={'protocol':'Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md','source_file':source.name,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'batch':5,'source_lines':[4383,5611],'E3_exact_and_precision_controls':len(evidence),'pass_count':sum(z['pass'] for z in evidence),'evidence':evidence,'E4_mutant_results':mutants,'limitations':['Passing checks verify displayed mathematical identities on explicit hypothesis domains, not physical-native operator or source realization.','Dimension-check mutant is a source-text scope concern, not a disproof of the numerical Gaussian integral after consistent unit normalization.']}
out=R/'Paper3E-Batch05-IndependentChecks-v1_1.json';out.write_text(json.dumps(res,indent=2,ensure_ascii=False)+'\n')
print('PASS E3',len(evidence),' E4 issue mutants',len(mutants),'->',out)
