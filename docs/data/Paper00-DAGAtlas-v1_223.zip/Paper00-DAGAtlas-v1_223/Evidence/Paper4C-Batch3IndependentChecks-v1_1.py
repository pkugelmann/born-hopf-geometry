#!/usr/bin/env python3
"""Scoped E3/E4 controls for source-printed Paper IV-C lines 3435--5219.
Mathematical countermodels are labelled to the exact printed domain. The source is immutable.
"""
from pathlib import Path
import hashlib, json, math
import numpy as np
import scipy.linalg as la
from scipy.integrate import solve_ivp
import sympy as sp

src=Path('/mnt/data/bh4c_work/papers/Paper00-PapersMinimal-v2_371/Paper4C-TechnicalMaterial-v1_42.tex')
SHA='db4933305c7acd0a67ac9c81ba219d051cbad95777a9848514ce4ce0e4e57626'
assert hashlib.sha256(src.read_bytes()).hexdigest()==SHA
rng=np.random.default_rng(420261112)
records=[]
def ck(n,name,claim,passed,details,typ='E3',scope='FINITE_EXAMPLE_NOT_UNIVERSAL_CERTIFICATE'):
    records.append(dict(id=f'BH-IVC-B3-{typ}-{n:03d}',name=name,claim=claim,type=typ,status='PASS' if bool(passed) else 'FAIL',scope=scope,details=details))
    if not passed: print('FAIL',n,details)
def norm(a):return float(la.norm(a,2))
def close(a,b,tol=1e-8):return np.allclose(a,b,atol=tol,rtol=tol)
def herm(n):
    a=rng.standard_normal((n,n))+1j*rng.standard_normal((n,n));return (a+a.conj().T)/2
# E3 1: exact nonstationary mass Hessian, m=exp(k t^2), ell=m*L.
t,k,L=sp.symbols('t k L',real=True,positive=True)
m=sp.exp(k*t*t);ell=m*L; R=sp.diff(m,t)/m
canonical=sp.simplify(ell/m-sp.diff(m,t,2)/(2*m)+(R*R)/4)
via_ibp=sp.simplify(ell/m-sp.diff(R,t)/2-R*R/4)
ck(1,'Canonical rescaling / endpoint integration by parts','p4:thm:v245-nonstationary-hessian-bogoliubov-source',sp.simplify(via_ibp-canonical)==0,{'Omega_squared':str(canonical),'raw_integrated':str(via_ibp)},scope='EXACT_SYMBOLIC_REPLAY')
# E4 2: full theorem-domain non-C1 frequency; m=1 ell=1+|t| on [-1,1].
# q(0)=1, p(0)=0 => sqrt(Omega) q has a cusp. Its one-sided real derivative is +/- 1/(4 sqrt 2) for hbar=1.
def Omeg(x):return math.sqrt(1+abs(x))
def real_a(h):
    q=solve_ivp(lambda tt,y:(y[1],-(1+abs(tt))*y[0]),[0,h],[1.,0.],rtol=1e-11,atol=1e-12).y[0,-1]
    return math.sqrt(Omeg(h)/2)*q
h=1.e-5;a0=1/math.sqrt(2)
left=(a0-real_a(-h))/h;right=(real_a(h)-a0)/h
ck(2,'In-domain nonsmooth positive Hessian refutes pointwise dot-Omega law','p4:thm:v245-nonstationary-hessian-bogoliubov-source',abs(right-left)>.2 and abs(right-1/(4*math.sqrt(2)))<1e-4 and abs(left+1/(4*math.sqrt(2)))<1e-4,{'m':'1','ell':'1+abs(t) continuous, positive','Omega':'sqrt(1+abs(t)) positive, non-differentiable at zero','left_slope_real_a':left,'right_slope_real_a':right,'source_failure':'dot Omega undefined at t=0'},typ='E4',scope='IN_DOMAIN_EXACT_ANALYTIC_COUNTEREXAMPLE_TO_POINTWISE_REGULARITY')
# E3 3: defect formula on differentiable branch.
D=sp.Function('D');nu=sp.symbols('nu',positive=True)
Om=sp.sqrt(nu**2+D(t))
repl=sp.simplify(sp.diff(Om,t)/(2*Om)-sp.diff(D(t),t)/(4*(nu**2+D(t))))
ck(3,'Differentiable affine-defect pairing formula','p4:cor:v247-defect-bogoliubov-source',repl==0,{'symbolic_residual':str(repl)},scope='EXACT_SYMBOLIC_ON_C1_DEFECT_SUBDOMAIN')
# E3 4: sigma_y diagonalization and gauge term.
sx=np.array([[0,1],[1,0]],complex);sy=np.array([[0,-1j],[1j,0]],complex);sz=np.diag([1.,-1.]);theta=.4;thp=.38;nu0=1.1;M=nu0*math.tan(theta);Om0=math.hypot(nu0,M);rot=la.expm(-.5j*theta*sy);rprime=(-.5j*thp*sy)@rot
H=nu0*sz+M*sx; lhs=rot.conj().T@H@rot-1j*rot.conj().T@rprime
rhs=Om0*sz-(thp/2)*sy
ck(4,'Two-level fermionic mass rotation and connection sign','p4:thm:v247-two-level-fermion-mixing',close(lhs,rhs),{'residual':norm(lhs-rhs)},scope='E3_EXACT_2X2_ROTATION_NUMERICAL')
# E3 5: free primitive turn, parity even interaction, exact one-turn interaction propagator.
T=2*math.pi;E=np.array([0.,1.,1.5,2.5]);PF=np.diag([1.,1.,-1.,-1.]);H0=np.diag(E)
V=herm(2);Vb=herm(2);v=la.block_diag(V,Vb)
free=lambda x:la.expm(-1j*x*H0)
VI=lambda x:free(x).conj().T@v@free(x)
one=free(T).conj().T@la.expm(-1j*T*(H0+v))
steps=800;dt=T/steps;floq=np.eye(4,dtype=complex)
for q in range(steps):floq=la.expm(-1j*dt*VI((q+.5)*dt))@floq
ck(5,'Conformal parity monodromy and Floquet interaction-unitary','p4:thm:v247-conformal-floquet',close(free(T),PF,1e-10) and close(VI(.3+T),VI(.3),1e-10) and norm(one-floq)<1e-4,{'monodromy_residual':norm(free(T)-PF),'periodic_residual':norm(VI(.3+T)-VI(.3)),'Floquet_error_800_midpoint_steps':norm(one-floq)},scope='E3_4X4_PARITY_BRANCH_AND_ODE_CONVERGENCE')
# E3 6: exact finite CAR two-mode Nambu closure incl pair term.
sm=np.array([[0,1],[0,0]],complex);zz=np.diag([1.,-1.]);ii=np.eye(2)
c1=np.kron(sm,ii);c2=np.kron(zz,sm);d1=c1.conj().T;d2=c2.conj().T
car=all(close(c@d+d@c,np.eye(4) if i==j else np.zeros((4,4))) for i,c in enumerate([c1,c2]) for j,d in enumerate([d1,d2]))
HF=1.3*d1@c1+2.1*d2@c2+.41*(d1@d2+c2@c1)
basis=np.column_stack([a.flatten() for a in (c1,c2,d1,d2)])
errs=[norm(HF@a-a@HF-(basis@np.linalg.lstsq(basis,(HF@a-a@HF).flatten(),rcond=None)[0]).reshape(4,4)) for a in [c1,c2,d1,d2]]
ck(6,'Quadratic CAR pairing remains linear in Nambu operators','p4:thm:curved-background-finite-bridge',car and max(errs)<1e-11,{'max_Nambu_projection_residual':max(errs),'CAR':car},scope='E3_EXACT_FINITE_CAR_POLYNOMIAL_IDENTITY')
# E3 7: fiber gauge covariant Schr equation sign.
GG=herm(3);HH=herm(3);u=rng.standard_normal(3)+1j*rng.standard_normal(3);tt=.27;dh=1e-6
U=lambda s:la.expm(-1j*s*GG)
psi=lambda s:U(s)@la.expm(-1j*s*HH)@u
HP=lambda s:U(s)@HH@U(s).conj().T+GG
dpsi=(psi(tt+dh)-psi(tt-dh))/(2*dh)
ck(7,'Covariant moving orthonormal frame generator connection','p4:thm:curved-background-finite-bridge',np.linalg.norm(1j*dpsi-HP(tt)@psi(tt))<1e-7,{'moving_frame_residual':float(np.linalg.norm(1j*dpsi-HP(tt)@psi(tt)))},scope='E3_MATRIX_GAUGE_FRAME_SAMPLE')
# E3 8: production density and finite trace positivity with final rank sector.
beta=rng.standard_normal((3,3))+1j*rng.standard_normal((3,3));Gamma=(beta.conj().T@beta).T; hh0=np.diag([.25,1.1,2.3]);P=np.diag([1,0,1])
chk=all(abs(np.vdot(f,Gamma@f)-np.linalg.norm(beta@np.conj(f))**2)<1e-9 for f in [rng.standard_normal(3)+1j*rng.standard_normal(3) for _ in range(4)])
ck(8,'Pullback production density / positive energy / sector trace','p4:thm:positive-production-density',chk and la.eigvalsh(Gamma).min()>-1e-10 and abs(np.trace(Gamma)-la.norm(beta,'fro')**2)<1e-9 and np.trace(hh0@Gamma).real>=0 and np.trace(P@Gamma@P).real>=0,{'min_eig_Gamma':float(la.eigvalsh(Gamma).min()),'trace':float(np.trace(Gamma).real),'energy':float(np.trace(hh0@Gamma).real)},scope='E3_GENERIC_COMPLEX_BETA_TYPECHECK')
# E3 9: zero target selector.
ck(9,'Zero final carrier projector implies zero production','p4:cor:absent-target-production',close(np.zeros((3,3))@Gamma@np.zeros((3,3)),np.zeros((3,3))),{'target':'P=0'},scope='EXACT_ALGEBRAIC')
# E3 10: profile-independent squeeze in zero-width limit.
wm=1.7;dd=.64;wp=wm*math.exp(-2*dd)
def squeeze(eps,profile):
    def fun(t,y):
        s=(t+eps/2)/eps
        ss=(3*s*s-2*s*s*s) if profile=='smoothstep' else s
        w=wm*math.exp(-2*dd*ss)
        A=np.array([[0.,1.],[-w*w,0.]])
        return (A@y.reshape(2,2)).ravel()
    sol=solve_ivp(fun,[-eps/2,eps/2],np.eye(2).ravel(),rtol=1e-11,atol=1e-12).y[:,-1].reshape(2,2)
    # canonical real to creation/annihilation maps with hbar=1
    B=lambda w:np.array([[math.sqrt(w/2),1j/math.sqrt(2*w)],[math.sqrt(w/2),-1j/math.sqrt(2*w)]])
    Bamp=B(wp)@sol@la.inv(B(wm))
    return Bamp[0,0],Bamp[0,1]
a1,b1=squeeze(.001,'linear');a2,b2=squeeze(.001,'smoothstep')
ck(10,'Sudden-layer profile-independent alpha/beta','p4:thm:profile-independent-thin-layer-squeeze',max(abs(a1-math.cosh(dd)),abs(a2-math.cosh(dd)),abs(b1+math.sinh(dd)),abs(b2+math.sinh(dd)))<.008,{'linear':{'alpha':[a1.real,a1.imag],'beta':[b1.real,b1.imag]},'smoothstep':{'alpha':[a2.real,a2.imag],'beta':[b2.real,b2.imag]},'target':{'alpha':math.cosh(dd),'beta':-math.sinh(dd)}},scope='E3_HIGH_ACCURACY_SMALL_WIDTH_ODE_TWO_PROFILES')
a3,b3=squeeze(1.0,'linear');a4,b4=squeeze(1.0,'smoothstep')
ck(11,'Finite-width profile effect correctly excluded by scope remark','p4:rem:thin-layer-squeeze-scope',abs(b3-b4)>1e-3,{'finite_width_beta_difference':float(abs(b3-b4))},typ='E4',scope='BOUNDARY_TEST_NOT_COUNTEREXAMPLE_TO_ZERO_WIDTH_THEOREM')
# E3 12: ground support positive/zero-energy state.
Hg=np.diag([0.,0.,2.]);rr=np.diag([.4,.6,0.]);rr2=np.diag([0.,0.,1.]);
ck(12,'Zero excess energy support and nonzero control','p4:thm:v2105-zero-excess-ground-support',abs(np.trace(rr@Hg))<1e-12 and abs(np.trace(rr2@Hg)-2)<1e-12,{'ker_dim':2,'ground_state_rank':2},scope='E3_PSD_TRACE_SUPPORT_SAMPLE_PLUS_SPECTRAL_IDENTITY')
# E3 13: random positive G complex structure & pure covariance, orientation explicitly as source.
GG=np.array([[2.3,.4],[.4,1.7]]);J=np.array([[0,1],[-1,0]]);ww=math.sqrt(la.det(GG));JJ=J@GG/ww;Cov=ww/2*la.inv(GG)
ck(13,'Quadratic ground J^2 and covariance determinant','p4:cor:v2105-quadratic-ground-complex-structure',close(JJ@JJ,-np.eye(2)) and close(GG@Cov,np.eye(2)*ww/2) and abs(la.det(Cov)-.25)<1e-10,{'J_square_residual':norm(JJ@JJ+np.eye(2)),'det_cov':float(la.det(Cov))},scope='E3_EXACT_2D_SYMPLECTIC_IDENTITY')
# E3 14: cosmological finite oscillator stable positive branch with fixed propagator.
g1=np.diag([1.4,2.7]); eig=la.eigvals(J@g1)
ck(14,'Positive quadratic branch gives imaginary stable oscillator frequencies','p4:thm:finite-cosmological-perturbation-bridge',np.max(np.abs(eig.real))<1e-12 and min(eig.imag)<0,{'frequencies':[complex(z).__str__() for z in eig]},scope='E3_ONE_MODE_POSITIVE_STABILITY_ONLY_NO_COSMOLOGICAL_LIMIT_VERIFIED')
# E3 15: Duhamel norm and exact CPTP branch finite 2x2 product.
H0=herm(4); VV=herm(4)*.18; tm=.7; U0=la.expm(-1j*tm*H0); UU=la.expm(-1j*tm*(H0+VV))
mat=rng.standard_normal((2,2))+1j*rng.standard_normal((2,2));rho=mat@mat.conj().T;rho/=np.trace(rho);sig=np.diag([.6,.4]);joint=np.kron(rho,sig)
output=UU@joint@UU.conj().T
rout=np.einsum('iajb->ij',output.reshape(2,2,2,2)) # axes i,a,j,b and diagonal trace? wrong: einsum 'iaja->ij'
rout=np.einsum('iaja->ij',output.reshape(2,2,2,2))
ck(15,'Finite reheating Duhamel/CPTP density transfer','p4:thm:finite-reheating-interface',norm(UU-U0)<=tm*norm(VV)+1e-11 and la.eigvalsh(rout).min()>-1e-12 and abs(np.trace(rout)-1)<1e-10,{'duhamel_lhs':norm(UU-U0),'rhs':tm*norm(VV),'output_trace':float(np.trace(rout).real)},scope='E3_MATRIX_PRODUCT_STATE_BRANCH')
# E3 16: GKLS amplitude damping restricted classical rates on diagonal algebra.
gamma=.7; l=np.array([[0,1],[0,0]],complex);pp=[np.diag([1.,0.]),np.diag([0.,1.])]
Lstar=lambda X:gamma*(l.conj().T@X@l-.5*(l.conj().T@l@X+X@l.conj().T@l))
W=np.array([[np.trace(pp[b]@Lstar(pp[a])).real for b in range(2)] for a in range(2)])
ck(16,'GKLS population invariant MASA and Markov generator signs','p4:thm:finite-reheating-interface',close(W,np.array([[0.,gamma],[0.,-gamma]])) and close(W.sum(axis=0),np.zeros(2)),{'W':W.tolist()},scope='E3_EXACT_AMPLITUDE_DAMPING_CLASSICAL_RESTRICTION')
# E4 17: arbitrary time-dependent finite unitary is NOT necessarily recurrent.
# H(t)=f(t)*sigma_x supported on (0,1), integral pi/2, then H(t)=0 for t>=1, U(t)|0>=-i|1> for all t>=1.
fint=math.pi/2;unit=la.expm(-1j*fint*sx);v0=np.array([1.,0.]);v1=unit@v0
ck(17,'Time-dependent finite Hamiltonian need not be recurrent','p4:thm:finite-reheating-interface',abs(np.vdot(v0,v1))<1e-12 and close(v1,np.array([0.,-1j])),{'H':'f(t)*sigma_x, smooth compact support (0,1), integral pi/2, zero after t=1','state_t_ge_1':'-i |1>','initial':'|0>','overlap_all_t_ge_1':0},typ='E4',scope='IN_DOMAIN_COUNTEREXAMPLE_TO_AUXILIARY_UNQUALIFIED_RECURRENCE_SENTENCE_ONLY')
# E3 18: finite response duality, order qualification.
O=herm(3);A=herm(3);ll=lambda X:np.trace(O@X);ef=np.diag([.2,.5,.8]);
ck(18,'Finite response functional trace representation/effect bound','p4:thm:finite-transfer-kernel-status',abs(ll(A)-np.trace(O@A))<1e-12 and 0<=np.trace(ef@np.eye(3)/3).real<=1,{'effect_probability_uniform_state':float(np.trace(ef)/3)},scope='FINITE_TRACE_DUALITY_AND_ORDER_SAMPLE')
# E3 19 finite Trotter product.
TT=herm(3);Vp=herm(3);t0=.4;X=la.expm(-1j*t0*(TT+Vp));Y=np.linalg.matrix_power(la.expm(-1j*t0*TT/500)@la.expm(-1j*t0*Vp/500),500)
ck(19,'Finite Trotter path-sum product to propagator','p4:thm:v244-no-independent-wave-postulate',norm(X-Y)<.01,{'trotter_error_at_n500':norm(X-Y)},scope='E3_FINITE_PRODUCT_LIMIT_ONLY_NOT_CONTINUUM')
# E3 20 isolated nondegenerate perturbation first derivative.
D0=np.diag([0.,1.4,3.3]);V=herm(3);lam=2e-5
Eplus,Uplus=la.eigh(D0+lam*V);Eminus,Uminus=la.eigh(D0-lam*V)
ED=(Eplus[0]-Eminus[0])/(2*lam)
ck(20,'Nondegenerate perturb energy first variation','p4:thm:nondeg-perturbation',abs(ED-V[0,0].real)<1e-7,{'energy_symmetric_derivative':ED,'matrix_element':float(V[0,0].real)},scope='E3_FINITE_DIFFERENCE_3X3')
# E3 21 degenerate splitting and Schur second-order.
Da=np.diag([0.,0.,2.]);V=np.array([[.3,.11,.7],[.11,-.1,-.4],[.7,-.4,1.0]]);P=np.diag([1.,1.,0]);Q=np.eye(3)-P
vals=la.eigvalsh(V[:2,:2]);lamb=1e-5;e=la.eigvalsh(Da+lamb*V)[:2]
Hsecond=lamb*V[:2,:2] -lamb*lamb*(np.outer(V[:2,2],V[2,:2])/2.)
ev2=la.eigvalsh(Hsecond)
ck(21,'Degenerate first-order splitting','p4:thm:degenerate-perturbation',max(abs(e/lamb-vals))<1e-4,{'predicted_slopes':vals.tolist(),'actual_slopes':(e/lamb).tolist()},scope='E3_DEGENERATE_3X3_EIGENVALUE_BRANCH')
ck(22,'Second-order Feshbach effective block eigenvalues','p4:cor:second-order-effective',max(abs(e-ev2))<1e-11,{'eigenvalues_actual':e.tolist(),'second_order_effective':ev2.tolist(),'max_error':float(max(abs(e-ev2)))},scope='E3_FINITE_3X3_SECOND_ORDER_MATCH')
# E3 23 Dyson positive and negative t for constant V_I and operator bound.
V=herm(3);tt=-.41;exact=la.expm(-1j*tt*V);trunc=np.eye(3,dtype=complex)
for n in range(1,12):trunc+=(-1j*tt)**n*la.fractional_matrix_power(V,n)/math.factorial(n) if False else ((-1j*tt)**n)*np.linalg.matrix_power(V,n)/math.factorial(n)
x=abs(tt)*norm(V)
ck(23,'Dyson norm series and bound for negative time','p4:thm:dyson-finite',norm(trunc-exact)<1e-8 and norm(exact-np.eye(3))<math.expm1(x)+1e-12,{'series_trunc_error':norm(trunc-exact),'bound':math.expm1(x),'norm_U_minus_I':norm(exact-np.eye(3))},scope='E3_CONSTANT_DRIVE_NEGATIVE_TIME')
# E3 24 first-order offdiagonal remainder.
V=np.array([[0.,.18],[.18,0.]]) ;tt=.7;u=la.expm(-1j*tt*V);a=u[1,0];a1=-1j*tt*V[1,0];x=tt*norm(V)
ck(24,'First-order transition amplitude and exact exponential remainder','p4:cor:first-order-transition',abs(a-a1)<=math.expm1(x)-x+1e-12,{'remainder':abs(a-a1),'upper':math.expm1(x)-x},scope='E3_CONSTANT_RESONANT_DRIVE_H0_ZERO')
# E3 25 adiabatic leakage for rotated 2-level H.
dA=np.diag([-.8,.8]);
def rotmat(s):
    z=.7*s
    return np.array([[math.cos(z),-math.sin(z)],[math.sin(z),math.cos(z)]])
def Ham(s):
    R=rotmat(s);return R@dA@R.T
p0=np.array([1.,0.]);
def leak(T):
    fun=lambda t,y:(-1j*Ham(t/T)@y)
    v=solve_ivp(fun,[0,T],p0.astype(complex),atol=1e-11,rtol=1e-10).y[:,-1]
    f=rotmat(1.)[:,1];return abs(np.vdot(f,v))
lt1=leak(50);lt2=leak(100)
ck(25,'Gapped finite adiabatic leakage O(1/T)','p4:thm:finite-adiabatic',lt1<.04 and lt2<.02 and lt2<lt1*1.5,{'leak_T50':lt1,'leak_T100':lt2},scope='E3_NUMERIC_GAPPED_ROTATING_BAND')
# E3 26 Kato generator for real rotation matrix and moving projector.
ss=.32;eps=1e-6;R=rotmat(ss);Pd=lambda s:rotmat(s)@np.diag([1.,0.])@rotmat(s).T;Pdot=(Pd(ss+eps)-Pd(ss-eps))/(2*eps);K=Pdot@Pd(ss)-Pd(ss)@Pdot;Rdot=(rotmat(ss+eps)-rotmat(ss-eps))/(2*eps)
ck(26,'Kato intertwiner / fixed projector / connection','p4:thm:transported-frame-sector',close(K@R,Rdot,1e-8) and close(R.T@Pd(ss)@R,Pd(0)),{'Kato_generator_error':norm(K@R-Rdot),'intertwining_error':norm(R.T@Pd(ss)@R-Pd(0))},scope='E3_ANALYTIC_ROTATED_PROJECTOR')
# E3 27 Weyl 3x3 trace orthogonality.
omega=np.exp(2j*math.pi/3);X3=np.roll(np.eye(3),1,axis=0);Z3=np.diag([1,omega,omega**2]);waves=[np.linalg.matrix_power(X3,a)@np.linalg.matrix_power(Z3,b) for a in range(3) for b in range(3)]
G3=np.array([[np.trace(w.conj().T@u) for u in waves] for w in waves])
ck(27,'Rank-three Heisenberg Weyl orthogonal basis','p4:prop:rank-three-weyl-basis',close(Z3@X3,omega*X3@Z3) and close(G3,3*np.eye(9)),{'Weyl_relation_error':norm(Z3@X3-omega*X3@Z3),'Gram_error':norm(G3-3*np.eye(9))},scope='E3_EXACT_FINITE_WEYL_MATRIX_CHECK')
# E3 28 A2 projector defect matrices.
Pr=[np.diag([float(i==j) for i in range(3)]) for j in range(3)];Def=[q-np.eye(3)/3 for q in Pr];alpha=[Pr[0]-Pr[1],Pr[1]-Pr[2]]
G2=np.array([[np.trace(a@b).real for b in alpha] for a in alpha]);Gs=np.array([[np.trace(a@b).real for b in Def] for a in Def])
ck(28,'Centered rank-one defects and A2 Gram','p4:cor:rank-three-a2-defect-plane',close(G2,[[2,-1],[-1,2]]) and close(Gs,np.eye(3)-np.ones((3,3))/3),{'roots':G2.tolist(),'defects':Gs.tolist()},scope='E3_EXACT_PROJECTOR_TRACE_IDENTITIES')
# E3 29 invariant C2 C3 under rotations and eigenvalue permutations.
spec=np.array([.7,2.,5.]);logs=np.log(spec);delt=logs-logs.mean();Y=herm(3);eig,U=la.eigh(Y);S=U@np.diag(spec)@U.conj().T;HH=U@np.diag(delt)@U.conj().T
x=(delt[0]-delt[1])/np.sqrt(2);y=(delt[0]+delt[1]-2*delt[2])/np.sqrt(6)
ck(29,'Log spectrum invariant quadratic/cubic Casimirs','p4:thm:local-affine-normal-form',abs(np.trace(HH@HH).real-(x*x+y*y))<1e-10 and abs(np.trace(HH@HH@HH).real-sum(delt**3))<1e-10,{'C2':float(np.trace(HH@HH).real),'C3':float(np.trace(HH@HH@HH).real)},scope='E3_EXACT_SHAPE_COORDINATE_INVARIANCE')
# E3 30: Taylor field and chart L injection.
N0=np.array([.2,-.3,.6]);NN=np.array([.203,-.294,.598]);A=np.array([[1,.4,0],[-.1,.6,.25],[0,-.6,.2]]);b=np.array([.1,.2,-.3]);v=lambda n:A@n+b+np.array([n[0]**2,n[1]*n[2],n[2]**2]);jac=A+np.array([[2*N0[0],0,0],[0,N0[2],N0[1]],[0,0,2*N0[2]]]);quad=v(NN)-v(N0)-jac@(NN-N0)
L=np.array([[1,0,0],[0,1,0],[0,0,1],[2,1,-1]],float);ell=L@NN
ck(30,'Autonomous affine first-jet quadratic remainder','p4:thm:local-affine-normal-form',np.linalg.norm(quad)<2*np.linalg.norm(NN-N0)**2,{'quad_residual':quad.tolist(),'step':float(np.linalg.norm(NN-N0))},scope='E3_EXPLICIT_C2_POLYNOMIAL_FIELD')
ck(31,'Fixed full-rank chart preserves affine Taylor form','p4:cor:chart-transfer-affine',close(L@v(NN),L@(v(N0)+jac@(NN-N0)+quad)) and np.linalg.matrix_rank(L)==3 and close(ell,L@NN),{'L_rank':int(np.linalg.matrix_rank(L))},scope='E3_INJECTIVE_4X3_AFFINE_CHART')
# E4 32: time independent dephasing GKLS not spectral-projectable without extra guard.
rr=.5;rz=np.diag([(1+rr)/2,(1-rr)/2]);rx=(np.eye(2)+rr*sx)/2;zf=sz
Ld=lambda x:zf@x@zf-x
velz=Ld(rz);velx=Ld(rx)
ck(32,'Quasi-free time-independent GKLS does not imply eigenvalue projectability','p4:cor:intervalwise-affine-normal-form',close(la.eigvalsh(rz),la.eigvalsh(rx)) and norm(velz)<1e-12 and np.trace(rx@velx).real<0,{'isospectral':True,'z_stationary':True,'x_trace_rho_Lrho':float(np.trace(rx@velx).real)},typ='E4',scope='SCOPE_GUARD_CHALLENGE_CORRECTLY_ACKNOWLEDGED_IN_PRINTED_PROOF')
# E3 33: depolarizing equivariance suffices for projectability on simple spectrum.
S1=np.diag([.19,.31,.50]);U=la.expm(1j*herm(3));S2=U@S1@U.conj().T
LL=lambda Y:np.trace(Y)*np.eye(3)/3-Y
L1=LL(S1);L2=LL(S2)
w1,vec1=la.eigh(S1);w2,vec2=la.eigh(S2)
der1=np.array([np.vdot(vec1[:,i],L1@vec1[:,i]).real for i in range(3)]);der2=np.array([np.vdot(vec2[:,i],L2@vec2[:,i]).real for i in range(3)])
ck(33,'Equivariant depolarizing spectral projectability','p4:cor:intervalwise-affine-normal-form',close(w1,w2) and close(der1,der2),{'spectrum':w1.tolist(),'derivatives_1':der1.tolist(),'derivatives_2':der2.tolist()},scope='E3_UNITARY_EQUIVARIANCE_SAMPLE')
output=Path(__file__).with_suffix('.json')
summary={'source':src.name,'source_sha256':SHA,'audited_lines':[3435,5219],'total_controls':len(records),'E3_count':sum(r['type']=='E3' for r in records),'E4_count':sum(r['type']=='E4' for r in records),'passed':sum(r['status']=='PASS' for r in records),'failed':sum(r['status']=='FAIL' for r in records),'scope_note':'Finite checks test scoped subclaims; E4 witness 002 refutes printed pointwise regularity implication; E4 witness 017 refutes only unconditional recurrence sentence, not main finite CPTP theorem. E4 witness 011 and 032 test intentionally excluded stronger conclusions.','checks':records}
output.write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
print('RESULT',summary['passed'],'/',len(records),'E3',summary['E3_count'],'E4',summary['E4_count'],'failed',summary['failed']);print('FILE',output)
if summary['failed']:raise SystemExit(1)
