#!/usr/bin/env python3
"""Build source-frozen IV-C batch 6 ledger and report, no paper or DAG ZIP edits."""
from pathlib import Path
import re, json, hashlib, zipfile
from collections import defaultdict,Counter
ROOT=Path('/mnt/data/bh4c_work')
PAPERS=ROOT/'papers'/'Paper00-PapersMinimal-v2_371'
TEX=PAPERS/'Paper4C-TechnicalMaterial-v1_42.tex'
LINES=TEX.read_text().splitlines()
START,END=8564,10128
OUT=ROOT/'staging'/'Batches'
EVID=ROOT/'staging'/'Evidence'
PREV=json.load(open(OUT/'Paper4C-AuditBatch5-v1_1.json'))
CHECK=json.load(open(EVID/'Paper4C-Batch6IndependentChecks-v1_1.json'))
assert len(LINES)==10934 and CHECK['source_lines']==[START,END]
assert hashlib.sha256(TEX.read_bytes()).hexdigest()==PREV['source_sha256']==CHECK['source_sha256']
assert CHECK['check_count']==54 and CHECK['passed_count']==54

# E1 replay summaries: explicit source theorem scope; never physical selection by arithmetic alone.
status={
'p4:lem:v2174-aux-pair-boundary':'VERIFIED-CONDITIONAL',
'p4:prop:v2174-fixed-port-intertwiners':'VERIFIED-CONDITIONAL',
'p4:cor:v2168-source-invisible-interaction':'VERIFIED-CONDITIONAL',
'p4:prop:v2168-product-unit-vertex-moment':'VERIFIED-CONDITIONAL',
'p4:prop:v2210-lit-detector-stability':'VERIFIED',
'p4:cor:v2210-lit-inclusive-soft':'VERIFIED-CONDITIONAL',
'p4:thm:v2210-lit-determinant-jets':'VERIFIED-CONDITIONAL',
'p4c:thm:v247-source-correlation-polynomial':'VERIFIED',
'p4c:cor:v247-correlation-determinant-compression':'VERIFIED',
'p4:thm:v248-current-determinant-sum':'VERIFIED-CONDITIONAL',
'p4:cor:v248-interacting-parent-error':'VERIFIED-CONDITIONAL',
'p4:lem:v248-quartic-discrete-decoupling':'VERIFIED',
'p4:cor:v248-joint-state-interacting-determinants':'VERIFIED-CONDITIONAL',
'p4:prop:v249-uniform-log-tube':'VERIFIED-CONDITIONAL',
'p4:prop:v249-paired-influence-zero':'VERIFIED-CONDITIONAL',
'p4:thm:v249-interacting-two-jet-convergence':'VERIFIED-CONDITIONAL',
'p4:cor:v249-joint-state-influence-jet-error':'VERIFIED-CONDITIONAL',
'p4:cor:v249-interacting-log-jet-error':'VERIFIED-CONDITIONAL',
'p4:thm:v249-source-hs-realization':'VERIFIED-CONDITIONAL',
'p4:lem:v249-source-state-error':'VERIFIED',
'p4:thm:v249-certified-visible-poles':'VERIFIED',
'p4:cor:v249-correlation-resolvent-bridge':'VERIFIED',
'p4:cor:v249-paired-coefficient-certification':'VERIFIED-CONDITIONAL',
}
notes={
'p4:lem:v2174-aux-pair-boundary':('In Paper II-F auxiliary pair presentation; compressed rank-one B†B commutator, degree-one dark, nilpotency cap one.','Imported auxiliary presentation is NOT the actual charged standard boson coordinate or occupation selector.','Matrix rank-one multiplication, graded creation extraction, nilpotency.'),
'p4:prop:v2174-fixed-port-intertwiners':('Fixed standard d-mode Fock ladders, actual total number and marked two-charge X,X† on complete cap-N sublevels.','Requires identical *fixed* graded ports and same χ; does not refute GP3 comparison with other constructors.','Vacuum projection polynomial, exhaustive matrix units, cap mismatch top-creator contradiction.'),
'p4:cor:v2168-source-invisible-interaction':('Number-preserving normal-ordered fermionic polynomial with ≥2 annihilators per monomial; zero/one sectors invariant.','Vacuum/one-excitation source branch is supplied; does not apply to fermion-boson vertex or general interacting state.','Every quartic term annihilates vacuum and one-fermion state; resolve on invariant sector.'),
'p4:prop:v2168-product-unit-vertex-moment':('Actual finite h, Tα, Xα and stationary product vacuum; bosonic ground has zero port means.','Realized only on stationary product-unit branch; no physical state/source selection.','First commutator hJ+vertex W; orthogonal boson unit/excitations make μ2=J†h²J+W†W.'),
'p4:prop:v2210-lit-detector-stability':('Contraction outgoing operators, coherently compared input, detector effect difference, positive calibrated flux floor.','No automatic asymptotic scattering, detector calibration or flux data.','Telescoped probabilities bounded 2η+δ, flux ratio uses pn≤1 and positive f*. '),
'p4:cor:v2210-lit-inclusive-soft':('Already licensed hard/soft tensor and soft POVM summing identity.','No IR limit, physical soft energy cut or dressing construction implied.','Linearity of trace and partial trace gives exact inclusivity even if entangled.'),
'p4:thm:v2210-lit-determinant-jets':('Nonsingular complete finite Gaussian blocks Q_a(J) with C³ and inherited relative determinant weights.','Gaussian contribution only; finite full interacting EAA / bare radiative protection not proved.','Jacobi and G′=-GQ′ prove 1/2/3-jet trace formulas; one-loop only on admitted perturbative domain.'),
'p4c:thm:v247-source-correlation-polynomial':('Complete finite quadratic CAR H=dΓh+c, any initial state ρi (not necessarily quasifree).','No quartic interaction in H; no state preparation/selection.','Expand ∧W as minors of W−I contracted with state occupied correlation tensors, including off-diagonal minors.'),
'p4c:cor:v247-correlation-determinant-compression':('Gauge-invariant quasifree state yields Rk=∧kC; generic state not determined by C.','Covariance-only reduction is restricted to supplied quasifree branch.','Exterior-power trace-sum determinant; two-state correlated vs I/4 witness has same C, different Z.'),
'p4:thm:v248-current-determinant-sum':('Actual finite CAR/boson Hermitian source with C¹ time paths, product gauge-invariant quasifree initial CAR state and arbitrary finite bosonic state.','Sliced spectral labels are coherent summation indices, not stochastic auxiliary field; no physical charged mass pole/state selected.','Spectral port expansion retains noncommuting projectors; quasifree determinant; Duhamel freeze+Lie–Trotter commutator+unitary telescope yield O(1/N).'),
'p4:cor:v248-interacting-parent-error':('Exact/sliced unitaries on same source, local nonzero log chart with ζ and εN<ζ/2.','Local chart only; no global influence log or physical source variable identification.','Gram positivity, normalization, trace bound; segment log integration gives 2ℏεN/ζ.'),
'p4:lem:v248-quartic-discrete-decoupling':('Number-preserving self-adjoint quartic polynomial on finite CAR d-mode band.','Square decomposition is algebraic rewriting of an ACTUALLY retained vertex; does not add couplings.','Vandermonde interpolation on finite subset-sum spectrum; CAR EijEkl identity and real symmetric squares.'),
'p4:cor:v248-joint-state-interacting-determinants':('Same complete sliced Hamiltonian but arbitrary fixed initial positive joint CAR-boson state.','State is supplied, not prepared; no quasifree or factorized approximation of state.','Expand exterior minors and preserve boson-valued occupied correlations Rk; trace pairing accounts for entanglement.'),
'p4:prop:v249-uniform-log-tube':('Full finite Hamiltonian uniformly Lipschitz in declared control norm, including moving-frame and central terms; positive normalized state.','Control topology must govern any derivative-dependent word; excludes global log across zero of Z.','Unitary Duhamel gives |Z−1|≤TLH||q+−q−||/ℏ; disk avoids zero and branch cut; log derivative bound.'),
'p4:prop:v249-paired-influence-zero':('Source-matched finite paired two-spin branch with ρ=I4/4 and g>0, v≠0.','Supplied-word counterexample does not select physical electron prep or coefficients.','Even σx block + two odd unchanged lines gives Z=(1+cos gT/ℏ)/2=cos²(gT/(2ℏ)); exact zeros obstruct global log.'),
'p4:thm:v249-interacting-two-jet-convergence':('Actual C² map q↦Ha into time C¹ Herm matrices, bounded M,L,C up to two source derivatives, fixed carrier.','No automatic regularity on arbitrary C¹ history balls when H depends on qdot; input assumptions explicit.','Four-by-four jet lift respects multiplication/exponentials; lifted split/freezing norms produce uniform O(1/N) bound for 0/1/2 derivatives.'),
'p4:cor:v249-joint-state-influence-jet-error':('Any source-fixed joint density, uniform finite generator and derivative bounds of preceding theorem on both branches.','Source-dependent preparation would require additional density jets, not included.','Trace product rule, unitarity, Duhamel derivative bounds b1,b2; product errors η0,η1,η2.'),
'p4:cor:v249-interacting-log-jet-error':('Previously certified local nonzero logarithm charts, matching normalization and η0<ζ/2.','Connectedness plus nonzero Z does not by itself prove global log.','r=(ZN−Z)/Z, quotient derivatives and log(1+r) two-jet chain rule.'),
'p4:thm:v249-source-hs-realization':('Actual stationary finite H,ρ and complete tagged source Q on Hilbert-Schmidt double carrier.','Pairing is actual ρ and tag, NOT canonical calculation density; stationary condition [H,ρ]=0.','Intertwining of adH with right/left sqrtρ, positive transition residue (pm+pn), canonical CAR Gram I.'),
'p4:lem:v249-source-state-error':('Two positive normalized densities and bounded source columns on identical finite carrier.','States need not commute; bound uses square-root HS and trace norm.','Sign(sqrtρ−sqrtσ) argument, triangle for doubled J.'),
'p4:thm:v249-certified-visible-poles':('Two stationary tuples on same finite carrier/frame, nonreal spectral z or common full-spectral gap, isolated full Liouvillian reference cluster.','Certifies source-visible pole only with positive residue margin and δ smaller than cluster radius; not exact physical pole equality.','Resolvent telescoping, Riesz contour homotopy, positive full spectral projectors and actual J source Gram.'),
'p4:cor:v249-correlation-resolvent-bridge':('Same finite self-adjoint Liouvillian and stationary J; spectral units ℏ=1.','All-time finite C(t) needed; finite-window value estimates alone are insufficient.','Duhamel unitary, derivative of matrix powers, finite spectral Laplace transform for Im z>0.'),
'p4:cor:v249-paired-coefficient-certification':('Two instances of already declared two-spin retained Hamiltonian, exact Gibbs at same finite beta, same canonical Q.','Only supplied finite restriction; no physical mass/pole or preparation occurrence is established.','Block norm of 2×2 even perturbation, Gibbs Duhamel Schatten bound, square-root source perturbation.'),
}
assert set(status)==set(notes)

# Extract frozen named environments with exact statement/proof texts and locators.
env_types={'theorem','lemma','proposition','corollary','remark','definition','claim','example'}
claims=[]
for i in range(START,END+1):
    ln=LINES[i-1]
    m=re.search(r'\\begin\{([a-zA-Z]+)\}',ln)
    if not m or m[1] not in env_types:continue
    env=m[1]; fin=next(j for j in range(i,len(LINES)+1) if '\\end{'+env+'}' in LINES[j-1]);
    assert fin <=END,(i,fin)
    statement='\n'.join(LINES[i-1:fin]); labels=re.findall(r'\\label\{([^{}]+)\}',statement)
    assert len(labels)>=1 and labels[0] in status,(i,labels)
    label=labels[0]
    pbegin=fin+1
    while pbegin<=min(len(LINES),fin+10) and not LINES[pbegin-1].strip():pbegin+=1
    pf=None
    if pbegin<=len(LINES) and '\\begin{proof}' in LINES[pbegin-1]:
        pend=next(j for j in range(pbegin,len(LINES)+1) if '\\end{proof}' in LINES[j-1]);pf={'start_line':pbegin,'end_line':pend,'source_as_printed':'\n'.join(LINES[pbegin-1:pend])}
    title=' '.join(re.findall(r'\\begin\{'+env+r'\}\[([\s\S]*?)\]',statement)[:1])
    title=re.sub(r'\s+',' ',title)
    n=notes[label];check_ids=[a['id'] for a in CHECK['checks'] if a['source_claim']==label]
    claims.append({'id':f'BH-IVC-B6-CLM-{len(claims)+1:03}',
       'source_label':label,'kind':env,'source_location':{'file':TEX.name,'line_start':i,'line_end':fin,'proof':{'line_start':pf['start_line'],'line_end':pf['end_line']} if pf else None},
       'source_as_printed_title':title,'source_as_printed':statement,'source_proof_as_printed':pf['source_as_printed'] if pf else None,
       'statement_layer':'SOURCE-AS-PRINTED','status':status[label],'lifecycle':'ACTIVE',
       'E1_replay':n[2],'claimed_scope':n[0],'conditions_and_physical_boundary':n[1],
       'E3_ids':[z for z in check_ids if '-E3-' in z],'E4_ids':[z for z in check_ids if '-E4-' in z],
       'not_selected_physical_realization':True if any(x in n[1].lower() for x in ['actual','physical','supplied','state','licensed']) else False,
       'issues':[],'verification_limit':'Finite check instances are corroboration of the E1 mathematical replay, not generic exhaustive automated proofs.'})
assert len(claims)==23,(len(claims),[x['source_label'] for x in claims])
assert {x['source_label'] for x in claims}==set(status)
assert [x['source_location']['line_start'] for x in claims][0]==8564
assert [x['source_location']['line_start'] for x in claims][-1]==10068

# Check all local/cross-paper references against the current paper archive (E0 only).
labels=defaultdict(list)
for path in PAPERS.glob('*.tex'):
    for i,ln in enumerate(path.read_text().splitlines(),1):
        for label in re.findall(r'\\label\{([^{}]+)\}',ln):labels[label].append({'file':path.name,'line':i})
refs=[]
for i in range(START,END+1):
 for label in re.findall(r'\\(?:ref|eqref|autoref|pageref)\{([^{}]+)\}',LINES[i-1]):refs.append({'use_line':i,'label':label,'resolved':labels.get(label,[])})
assert len(refs)==29 and len({r['label'] for r in refs})==27
assert all(len(r['resolved'])==1 for r in refs)

# Each material edge has a proof-use witness, not mere citation; no invented cross-paper ancestry.
edge_data=[
('p2b:prop:v2174-geometric-pair-presentation','p4:lem:v2174-aux-pair-boundary','IMPORTED_PROOF',8567,'Exact auxiliary pair representation on 1⊕Sym²S'),
('p4:thm:gp1-bosonic-occupation-boundary','p4:prop:v2174-fixed-port-intertwiners','CANDIDATE_LINK',8658,'Later scope comparison, NOT imported to prove matrix-unit classification'),
('p4:cor:v2140-relative-determinant-weights','p4:thm:v2210-lit-determinant-jets','IMPORTED_PROOF',9046,'Inherit actual Gaussian/Berezin relative determinant weights'),
('p4c:thm:v247-source-correlation-polynomial','p4c:cor:v247-correlation-determinant-compression','REQUIRES',9149,'Apply exterior-minor correlation polynomial on supplied quasifree branch'),
('p4c:cor:v247-correlation-determinant-compression','p4:thm:v248-current-determinant-sum','REQUIRES',9258,'Determinant of one-particle return at each coherent bosonic path'),
('p4:thm:v248-current-determinant-sum','p4:cor:v248-interacting-parent-error','REQUIRES',9299,'Same coherent sliced influence, unitary error'),
('p4:thm:v248-current-determinant-sum','p4:cor:v248-joint-state-interacting-determinants','REQUIRES',9385,'Inherit current word and sliced unitary bound; replace initial state hypothesis'),
('p4c:thm:v247-source-correlation-polynomial','p4:cor:v248-joint-state-interacting-determinants','CANDIDATE_LINK',9431,'Self-contained proof of boson-valued exterior-minor identity, not dependent on prior theorem as a separate premise'),
('p5c:prop:v248-paired-history-compiler','p4:prop:v249-paired-influence-zero','IMPORTED_PROOF',9527,'Even 2x2 and odd scalar exact finite block reduction'),
('p4:thm:v248-current-determinant-sum','p4:thm:v249-interacting-two-jet-convergence','REQUIRES',9570,'Frozen-time slicing expression and exact O(1/N) baseline'),
('p4:cor:v248-joint-state-interacting-determinants','p4:cor:v249-joint-state-influence-jet-error','REQUIRES',9574,'Exact arbitrary joint-state path trace'),
('p4:thm:v249-interacting-two-jet-convergence','p4:cor:v249-joint-state-influence-jet-error','REQUIRES',9697,'Complete value/derivative operator bounds for full unitary'),
('p4:prop:v249-uniform-log-tube','p4:cor:v249-interacting-log-jet-error','REQUIRES',9745,'Validated common nonzero logarithm chart'),
('p4:cor:v249-joint-state-influence-jet-error','p4:cor:v249-interacting-log-jet-error','REQUIRES',9754,'Error levels eta_j and derivative bounds z_j for log quotient'),
('p4:thm:v2188-moment-pencil','p4:thm:v249-source-hs-realization','CANDIDATE_LINK',9891,'The actual source pairing enables *later* application of the earlier Hankel theorem; not a premise needed for the HS realization'),
('p4:thm:v249-source-hs-realization','p4:thm:v249-certified-visible-poles','REQUIRES',9933,'Actual fixed-HS doubled source Liouvillian and residues'),
('p4:lem:v249-source-state-error','p4:thm:v249-certified-visible-poles','CANDIDATE_LINK',9936,'Optional computable eta bound: theorem itself only assumes J and Jtilde'),
('p4:thm:v249-certified-visible-poles','p4:cor:v249-correlation-resolvent-bridge','CANDIDATE_LINK',10058,'The Laplace argument independently reproduces derivative bound; not a necessary material premise'),
('p5c:thm:v248-paired-quartic-source-poles','p4:cor:v249-paired-coefficient-certification','IMPORTED_PROOF',10071,'Fixed two-spin odd source and interacting Gibbs response'),
('p4:lem:v249-source-state-error','p4:cor:v249-paired-coefficient-certification','REQUIRES',10112,'Bound eta via square-root state perturbation')]
edges=[];nonpromoting=[]
for i,(u,v,kind,line,evidence) in enumerate(edge_data,1):
  trace='\n'.join(LINES[max(0,line-4):min(len(LINES),line+6)])
  assert START<=line<=END and u in set(status)|set(labels), (u,v,line) # semantic witness manually reviewed from consumer proof scope
  if kind=='CANDIDATE_LINK':
    nonpromoting.append({'from':u,'to':v,'kind':'CITATION_ONLY','source_locator':f'{TEX.name}:{line}', 'scope':evidence})
    continue
  edges.append({'id':f'BH-IVC-B6-EDGE-{len(edges)+1:03}', 'from':u,'to':v,'relation':kind,
   'proof_route':f'BH-IVC-B6-ROUTE-{v}', 'logic_group':'AND','source_use_locator':f'{TEX.name}:{line}',
   'source_witness':evidence,'domain_guard':notes[v][0],
   'review_status':'SOURCE_MATCHED_MATERIAL','verified_material_edge':True,'candidate_not_automatic':False})

steps=[
 (8640,8657,'neutral/projective phase amplitude comparison and 2πµ_occ invariant'),
 (8658,8683,'alternate complete-sublevel quantization and conditional occupation-role scopes'),
 (8687,8717,'autonomous reversal-odd 2×2 exact matrix and phase computation'),
 (8719,8750,'trace-state zero charge source and six-mode signed charge comparison, numerical inputs not embedded'),
 (8755,8797,'frozen Ward compression identity and four-CAR interaction guard leakage'),
 (8828,8849,'native current/fermion first commutator with actual bosonic ports'),
 (8910,8935,'synthetic fourth-moment leakage and source resolvent rational function'),
 (8937,8959,'synthetic finite current vertex and shifted bosonic one-particle poles'),
 (8960,8977,'faithful family vs vacuum visibility and projected noncommuting-port caution'),
 (9071,9088,'Gaussian one-loop versus complete finite-interacting action and source transport scope'),
 (9165,9185,'arbitrary-state correlation hierarchy does not cancel a quartic interaction'),
 (9325,9338,'path labels and coherent coefficients are not stochastic fields or physical operations'),
 (9457,9466,'joint-state boson-valued hierarchy not independent preparation parameters'),
 (9552,9567,'global finite influence zero versus local normalized nonzero log charts'),
 (9785,9835,'source second-contact Duhamel terms, retarded block and derivative-dependent control topology'),
 (10116,10118,'finite two-spin source certificates do not select native mass pole or preparation'),
]
for a,b,_ in steps:assert START<=a<=b<=END
counters=Counter(status.values())
cum0=PREV['cumulative_status_counts'];cum={x:cum0.get(x,0)+counters.get(x,0) for x in sorted(set(cum0)|set(counters))};assert sum(cum.values())==163
priorissues=[]
for prevno in (2,3,4):
  pp=json.load(open(OUT/f'Paper4C-AuditBatch{prevno}-v1_1.json'))
  for gap in pp.get('found_issues',[]):priorissues.append({'id':gap['issue_id'],'source_batch':prevno,'lifecycle':gap.get('lifecycle','OPEN'),'impact_status':'NO_NEW_VERIFIED_PATH_IN_BATCH6'})
assert len(priorissues)==4 and len({q['id'] for q in priorissues})==4

register={
 'audit':'Paper4C-RigorousVerificationDAG','batch':6,'revision':'v1_1',
 'protocol':'Paper00-RigorousVerificationDAGWorkProtocol-v2_4.md',
 'source_authority':'Paper00-PapersMinimal-v2_371','source_file':TEX.name,'source_sha256':CHECK['source_sha256'],
 'latest_supplied_dag_input':'Paper00-DAGAtlas-v1_108(1).zip','latest_supplied_audit_input':'Paper00-ProofChainAudits-v1_25(1).zip',
 'source_coverage':{'line_start':START,'line_end':END,'line_count':END-START+1,'named_claims_audited':len(claims),
  'source_total_lines':len(LINES),'named_cumulative':163,'named_total':186,'named_remaining':23,
  'material_unnamed_steps_audited':len(steps),'equation_labels_audited':[v for line in LINES[START-1:END] for v in re.findall(r'\\label\{((?:p4|p4c):eq:[^{}]+)\}',line)]},
 'status_counts':dict(counters),'previous_cumulative_named':140,'cumulative_status_counts':cum,
 'named_claim_ledger':claims,'material_unnamed_steps':[{'start_line':a,'end_line':b,'description':c,'E1':'INSPECTED','independent_check_limit':'No blanket independent claim of all example input matrices.'} for a,b,c in steps],
 'source_reference_audit':{'ref_occurrences':len(refs),'unique_referenced_labels':len({r['label'] for r in refs}),
  'all_unique_in_current_corpus':True,'records':refs,'note':'E0 resolution alone does not establish a material proof edge'},
 'source_proof_use_edges':edges,'nonpromoting_edges':nonpromoting,'found_issues':[],
 'carried_forward_issues_unchanged':priorissues,
 'independent_checks_file':'Paper4C-Batch6IndependentChecks-v1_1.json','independent_check_count':54,
 'independent_check_passed':54,'E3_finite_controls':CHECK['E3_count'],'E4_controls':CHECK['E4_count'],
 'adversarial_challenges':[q for q in CHECK['checks'] if q['kind']=='E4'],
 'canonical_condition_review':[
 {'name':'auxiliary exact pair representation','first_known_occurrence':'Paper2F:2906','status':'IMPORTED_PROVED_IN_AUXILIARY_SCOPE','consumers':['p4:lem:v2174-aux-pair-boundary'],'not_physical_pair_selector':True},
 {'name':'fixed complete boson occupation cap N','first_known_occurrence':'Paper4B:1466; operational sublevel additional condition','status':'CONDITIONAL','consumers':['p4:prop:v2174-fixed-port-intertwiners'],'no_new_axiom':True},
 {'name':'licensed finite hard-soft detector factor','first_known_occurrence':'Paper4C:9014 scope','status':'CONDITIONAL','consumers':['p4:cor:v2210-lit-inclusive-soft'],'no_new_axiom':True},
 {'name':'complete Gaussian effective-action determinant','first_known_occurrence':'Paper4B:2975 relative weights','status':'CONDITIONAL','consumers':['p4:thm:v2210-lit-determinant-jets'],'no_new_axiom':True},
 {'name':'fixed initial gauge-invariant quasifree CAR state and boson density','first_known_occurrence':'Paper4C:9200-9205','status':'CONDITIONAL','consumers':['p4:thm:v248-current-determinant-sum'],'alternative_route':'arbitrary joint state in p4:cor:v248-joint-state-interacting-determinants'},
 {'name':'arbitrary supplied joint state fixed under source variations','first_known_occurrence':'Paper4C:9382-9388','status':'CONDITIONAL','consumers':['p4:cor:v248-joint-state-interacting-determinants','p4:cor:v249-joint-state-influence-jet-error'],'no_new_axiom':True},
 {'name':'uniform Lipschitz norm on complete Hamiltonian history','first_known_occurrence':'Paper4C:9470-9479','status':'CONDITIONAL','consumers':['p4:prop:v249-uniform-log-tube'],'no_new_axiom':True},
 {'name':'C2 Banach control to time C1 Hamiltonian with finite derivative envelopes','first_known_occurrence':'Paper4C:9576-9612','status':'CONDITIONAL','consumers':['p4:thm:v249-interacting-two-jet-convergence','p4:cor:v249-joint-state-influence-jet-error'],'no_new_axiom':True},
 {'name':'fixed stationary HS pairing with [H,rho]=0 and exact Q','first_known_occurrence':'Paper4C:9840-9853','status':'CONDITIONAL','consumers':['p4:thm:v249-source-hs-realization','p4:thm:v249-certified-visible-poles'],'no_new_axiom':True},
 {'name':'positive source tag residue margin and isolated full Liouvillian frequency','first_known_occurrence':'Paper4C:9930-9976','status':'CONDITIONAL','consumers':['p4:thm:v249-certified-visible-poles'],'no_new_axiom':True}
 ],
 'open_verification_gates':[
 {'target':'p4:v2171:app:fullchainchecks','gate':'The 16-dimensional time-dependent four-CAR comparison and 128-dimensional generated charge-test space are stated but input matrices/source scripts are not bundled in this TeX section; not independently reconstructed.'},
 {'target':'p4:prop:v2168-product-unit-vertex-moment','gate':'Universal all-native physical vertex realization is conditional on actual selected finite current matrices, source, boson ports and stationary state; no physical charged pole inferred.'},
 {'target':'p4:thm:v248-current-determinant-sum','gate':'Finite exact formulas and splitting argument replayed, but full physical chart is not selected by this theorem and independent numerical cases are not a general ODE proof.'},
 {'target':'p4:thm:v249-interacting-two-jet-convergence','gate':'General Banach-space C2 regularity and uniform envelopes are antecedent hypotheses; tests sample static smooth finite examples and do not establish actual source-family regularity.'},
 {'target':'p4:thm:v249-certified-visible-poles','gate':'Actual physical rho/H/Q data and isolation/residue margin must be supplied; no numerical native charged mass pole established.'}
 ],
 'prohibited_work_excluded':['No theorem repair, new axiom, physical selector or TeX edit','No global effect/observable beyond material proof routes','No PDF compilation or visual inspection'],
 'final_artifact_plan':{'next_batch_start_line':10129,'next_named_claim_start_line':10163,'remaining_named_claims':23,'final_DAG_zip_after_last_batch':True,'final_audit_zip_after_last_batch':True}
}
file_json=OUT/'Paper4C-AuditBatch6-v1_1.json';file_json.write_text(json.dumps(register,indent=2,ensure_ascii=False)+'\n')

report=f'''# Paper IV-C — Rigorous Verification DAG Audit, Batch 6 (v1_1)

**Authoritative source:** `{TEX.name}` in `Paper00-PapersMinimal-v2_371`, SHA-256 `{CHECK['source_sha256']}`. **Protocol:** v2.4 (one-paper, no theory development).

**Audited:** source lines **{START}–{END}** ({END-START+1} lines), **23** named claims; **{len(steps)}** source-matched material unnamed diagnostic/qualification blocks; **29** reference occurrences across 27 unique, unambiguous current corpus labels (navigation only). **Cumulative:** **163/186** named objects. Remaining **23** named results in lines 10,129–10,934.

**Dispositions:** {', '.join(f'{k} {v}' for k,v in counters.items())}. **Independent controls:** **54/54 PASS** (48 constructive E3 finite tests, six E4 adversarial controls); E3 finite examples do not prove universal physical occurrence. **New source-matched issues:** **0**.

## Source-bound claim dispositions

| Start | Source label | Status | Test IDs |
|---:|---|---|---|
'''
for r in claims:
    report+=f"| {r['source_location']['line_start']} | `{r['source_label']}` | {r['status']} | {', '.join(x.rsplit('-',1)[-1] for x in r['E3_ids']+r['E4_ids']) or 'source replay only'} |\n"
report+='''
## E1 mathematical proof and scoped E3/E4 conclusions

**Occupation and marked-port comparisons (8564–8685).** The rank-one auxiliary pair algebra has exact pair cap one, but it does not select the physical charged boson. Full standard truncated two-mode ladders generate every matrix unit; distinct caps cannot be intertwiners of the same graded marks. For caps 1–3 this is independently checked exactly. These are comparisons of a *fixed marked port family*; the broader GP3 comparison category is not excluded. Neutral Kähler phase/projective data do not determine an amplitude moment or maximum occupation cap.

**Finite charge and interaction diagnostics (8687–8978).** The printed reversal-odd two-state sinusoid reproduces at sampled times. The projected Ward defect identity and interacting four-CAR leakage preserve the boundary terms. For a stationary product-unit current vertex, the one-/two-commutator moments correctly retain the bosonic Gram `W†W` despite vanishing boson one-point expectation. The source fourth-moment rational witness and finite shifted poles are reproduced. The manuscript's unnamed sixteen-dimensional four-CAR/128-dimensional time-dependent charge comparison is *not independently reconstructed* because its full historical input matrices do not appear in the current source subsection; this is a bounded E3 evidence gate, **not an established error**.

**Detector and Gaussian identities (8980–9089).** Coherently compared finite detectors satisfy the printed stability/flux inequalities, and any properly normalized unresolved soft POVM disappears under the partial trace. The three Gaussian `log det` source jets pass independent numerical derivative comparison. They remain Gaussian terms only; neither the interacting effective action nor a physical scattering infrared limit is obtained automatically.

**Arbitrary-state CAR correlation polynomial (9090–9185).** Independent complex finite CAR matrices reproduce the complete exterior-minor polynomial for a general non-quasifree density. The exact determinant reduction holds on a supplied *gauge-invariant quasifree* preparation, and the correlated mixture versus maximally mixed control confirms that equal covariance need not imply equal higher influence moments.

**Full finite interacting source and certified limits (9186–9836).** Two noncommuting finite bosonic ports reproduce the coherent spectral path sum exactly. An entangled initial CAR/boson pure state verifies the boson-valued correlation hierarchy while its product-of-marginals substitution fails. The Vandermonde spectral polynomial decouples an actually retained quartic square without inventing a coupling. Finite Lie–Trotter time-dependent and source-derivative checks meet the stated norm error estimates. The printed paired interacting comparison gives `Z(T)=cos²(gT/(2ħ))`, with exact zeros at odd half-periods; accordingly only **local** normalized logarithms are licensed. The jet theorem explicitly requires the full `C²(E,C¹_t)` coefficient mapping and bounded derivative envelopes; `C¹` histories are not silently deemed sufficient for a `q̇`-dependent word.

**Stationary source poles (9837–10128).** The Hilbert–Schmidt doubled-carrier positive anticommutator response, square-root state perturbation inequality, full-Liouvillian Riesz cluster stability, upper-half-plane Laplace bridge, and paired two-spin Gibbs coefficient error survive independent finite checks. A nonzero Liouvillian gap can remain source-dark; only positive source residue margin certifies an actual visible pole. The source statement correctly preserves that distinction and does not produce a physical electron rest pole.

## Findings, conditions, and impact

No new independent source-matched counterexample or missing material theorem premise was confirmed in Batch 6. The earlier four distinct origins remain **unresolved and unchanged** (`BH-G-000102` is UNDER_CHALLENGE; the others are OPEN): `BH-G-000102` (higher-word truncated-boson microcausality margin), `BH-G-000103` (scalar Bogoliubov differentiability), `BH-G-000104` (overbroad nonautonomous recurrence statement), and `BH-G-000105` (dephasing is not necessary for one detector to show no interference). No new source-verified `BLOCKS_ROUTE` edge from these origins to the 23 Batch 6 claims was found; plausible connections must not be promoted from citations.

The conditional claims in this span retain their precise owners: auxiliary pair presentation, actual occupation cap, hard–soft factorization, Gaussian weights, supplied initial states, complete current/source Hamiltonian, Banach control regularity, stationary Hilbert–Schmidt pairing, and a positive source-pole residue margin. These are not new constitutional axioms and do not independently certify physical occurrence. Cross-paper inputs were inspected only for their imported scopes: Paper II-F auxiliary presentation; IV-B relative determinant and finite scattering; V-D paired two-spin restriction and history compiler.

**Audit state:** `PARTIALLY_AUDITED` — **163/186** named source claims. Remaining **23** named claims, first at line **10163**, after an unexamined joint-response introduction beginning at line **10129**. The requested DAG Atlas and proof-chain audit ZIP outputs are reserved for the last batch, using supplied v1_108/v1_25 as baselines and only latest per-file revisions. No source file or original ZIP was modified.

**Machine ledger:** `Paper4C-AuditBatch6-v1_1.json`. **Tests:** `Paper4C-Batch6IndependentChecks-v1_1.py/.json`.\n'''
file_md=OUT/'Paper4C-AuditBatch6-v1_1.md';file_md.write_text(report)
validation={'paper':'Paper4C','batch':6,'source_sha256':CHECK['source_sha256'],
 'source_line_range':[START,END],'source_named_env_count':len(claims),'independent_check_count':54,
 'E3':48,'E4':6,'source_ref_count':len(refs),'all_source_refs_unique':True,
 'no_new_issues':True,'unchanged_carried_issues':[r['id'] for r in priorissues],
 'cumulative_named':163,'remaining_named':23,'status_counts':dict(counters),
 'file_hashes_sha256':{x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in (file_json,file_md,EVID/'Paper4C-Batch6IndependentChecks-v1_1.py',EVID/'Paper4C-Batch6IndependentChecks-v1_1.json')},
 'release_state':'BATCH_ONLY; canonical global DAG and final audit ZIP not yet modified'}
(EVID/'Paper4C-Batch6Validation-v1_1.json').write_text(json.dumps(validation,indent=2)+'\n')
print(json.dumps({'named':len(claims),'cumulative':163,'status':dict(counters),'refs':len(refs),'material_edges':len(edges),'unnamed':len(steps),'files':[str(file_json),str(file_md)]},indent=2))
