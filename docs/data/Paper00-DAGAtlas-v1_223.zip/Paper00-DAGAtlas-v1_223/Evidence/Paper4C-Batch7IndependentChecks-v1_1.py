#!/usr/bin/env python3
"""Source-matched independent and adversarial finite checks for Paper4C final batch.
No edits to source. Numerics are bounded E3 controls, not general proofs.
"""
import itertools, math, json, hashlib, os
from collections import defaultdict
import numpy as np
import scipy.linalg as la
from numpy.testing import assert_allclose
import networkx as nx

rng = np.random.default_rng(4117)
records = []

def chk(name, claim, fn, kind='E3', scope='finite independent model; source-domain guarded'):
    try:
        res = fn()
        if res is False:
            raise AssertionError('condition returned False')
        records.append({'id':f'IVC7-{len(records)+1:03d}','name':name,'source_claim':claim,'evidence_class':kind,'status':'PASS','scope':scope,'result':str(res)[:320]})
    except Exception as e:
        records.append({'id':f'IVC7-{len(records)+1:03d}','name':name,'source_claim':claim,'evidence_class':kind,'status':'FAIL','scope':scope,'result':f'{type(e).__name__}: {e}'})

def close(a,b,rtol=1e-9,atol=1e-9):
    assert_allclose(a,b,rtol=rtol,atol=atol)
    return 'numerical matrices agree'

def herm(n):
    a=rng.normal(size=(n,n))+1j*rng.normal(size=(n,n))
    return (a+a.conj().T)/2

def rho(n):
    a=rng.normal(size=(n,n))+1j*rng.normal(size=(n,n));r=a@a.conj().T
    return r/np.trace(r)

def cyclic(T,J):
    d=len(T); cols=[]; x=J.copy()
    for i in range(d):cols.append(x);x=T@x
    U,s,_=la.svd(np.column_stack(cols),full_matrices=False)
    return U[:,:sum(s>1e-9)]

C='p4:thm:v251-joint-cyclic-response'
for n in (4,7):
    def go(n=n):
        T=herm(n); J=rng.normal(size=(n,2))+1j*rng.normal(size=(n,2));
        U=cyclic(T,J); z=1.3+0.9j
        full=J.conj().T@np.linalg.solve(z*np.eye(n)-T,J)
        small=(U.conj().T@J).conj().T@np.linalg.solve(z*np.eye(U.shape[1])-U.conj().T@T@U,U.conj().T@J)
        close(full,small);close(U.conj().T@T@(np.eye(n)-U@U.conj().T), np.zeros((U.shape[1],n)))
        return f'dim={n}, cyc={U.shape[1]}'
    chk(f'joint cyclic response n={n}',C,go)

def static_residues():
    T=np.diag([1.,1.,3.,5.]);J=rng.normal(size=(4,3))+1j*rng.normal(size=(4,3));U=cyclic(T,J)
    for energy in (1.,3.,5.):
        Pi=np.diag((np.diag(T)==energy).astype(float))
        c=J.conj().T@Pi@J
        cs=(U.conj().T@J).conj().T@(U.conj().T@Pi@U)@(U.conj().T@J)
        close(c,cs);assert np.min(np.linalg.eigvalsh(c))>=-1e-12
    return 'all cross-tag residue blocks retained and positive'
chk('cross-tag residues and positivity',C,static_residues)

T0=np.diag([1.,2.5,4.0,7.]);T1=np.diag([0.]*4)
for i in range(3):T1[i,i+1]=T1[i+1,i]=.4
J0=np.eye(4)[:,:1]
z=9.0+0.75j

def cp(path,r):
    return np.arange(r+1)

def series_response(Ts,Js,k):
    n=Ts[0].shape[0]; R=[np.linalg.inv(z*np.eye(n)-Ts[0])]
    for m in range(1,k+1):
        R.append(R[0]@sum((Ts[j]@R[m-j] for j in range(1,min(m,len(Ts)-1)+1)),np.zeros((n,n),complex)))
    val=[]
    for l in range(k+1):
        M=np.zeros((Js[0].shape[1],Js[0].shape[1]),complex)
        for i in range(l+1):
            if i>=len(Js):continue
            for j in range(l-i+1):
                if j>=len(Js):continue
                M+=Js[i].conj().T@R[l-i-j]@Js[j]
        val.append(M)
    return val

C='p4:thm:v251-finite-jet-cyclic-carrier'
full=series_response([T0,T1],[J0],8)
for r in (0,1,2):
    def go(r=r):
        ix=np.arange(r+1);a=series_response([T0[np.ix_(ix,ix)],T1[np.ix_(ix,ix)]],[J0[ix,:]],2*r+2)
        for k in range(2*r+2):close(full[k],a[k],atol=1e-11)
        assert np.max(abs(full[2*r+2]-a[2*r+2]))>1e-10
        return f'orders 0..{2*r+1} retained; first missed {2*r+2}'
    chk(f'cyclic jet depth r={r}',C,go)

C='paper4c:corollary:atlas-the-derivative-depth-bound-is-sharp-in-general-36af441'
for r in (0,1,2,3):
    def go(r=r):
        n=r+2;T=np.diag(np.linspace(2,2+n,n));B=np.zeros((n,n))
        for i in range(n-1):B[i,i+1]=B[i+1,i]=.3
        J=np.eye(n)[:,:1];F=series_response([T,B],[J],2*r+2)
        idx=np.arange(r+1);C0=series_response([T[np.ix_(idx,idx)],B[np.ix_(idx,idx)]],[J[idx,:]],2*r+2)
        for k in range(2*r+2):close(F[k],C0[k])
        assert abs((F[-1]-C0[-1])[0,0])>1e-12
        return f'n={n}, first missed coefficient at order {2*r+2}'
    chk(f'sharp depth r={r}',C,go)

C='p4:cor:v251-jet-carrier-frame-covariance'
def frame_covariance():
    n=4;T=np.diag([2.,3.,4.,5.]); J=np.eye(n)[:,:1];B=T1
    A=herm(n)*.2;U=la.expm(1j*A*.7)
    C1=cyclic(T,np.column_stack((J,B@J)))
    Cp=cyclic(U@T@U.conj().T,np.column_stack((U@J,U@B@J)))
    close(C1@C1.conj().T,U.conj().T@Cp@Cp.conj().T@U)
    return 'projectors transform by constant unitary; covariant-jet identification checked'
chk('flat connection constant-frame covariance',C,frame_covariance,scope='constant unitary gauge special case only')

def moving_frame():
    n=4;T=np.diag([2.,3.,4.,5.]); J=np.eye(n)[:,:1]; A=1j*herm(n)
    h=1e-5;Uplus=la.expm(h*A); Uminus=la.expm(-h*A)
    dp=(Uplus@T@Uplus.conj().T-Uminus@T@Uminus.conj().T)/(2*h)
    close(dp,A@T-T@A,atol=1e-9)
    return 'moving frame derivative equals connection commutator'
chk('moving-frame derivative contact not omittable',C,moving_frame,'E4')

C='p4:prop:v251-static-cyclic-jet-defect'
def jet_defect():
    n=4; T=T0.copy();A=T[:2,:2];D=T[2:,2:];J=np.eye(n)[:,:2]
    Ts=[herm(n)*.4 for _ in range(2)];Js=[rng.normal(size=(n,2))+1j*rng.normal(size=(n,2)) for _ in range(2)]
    P=np.diag([1,1,0,0]);Q=np.eye(n)-P;z=8+0.7j
    R=np.linalg.inv(z*np.eye(n)-T);Rc=np.linalg.inv(z*np.eye(2)-A);Rd=np.linalg.inv(z*np.eye(2)-D)
    def Gij(Ti,Tj,Ji,Jj,RR,JJ):
        return Ji.conj().T@RR@Jj+Jj.conj().T@RR@Ji+Ji.conj().T@RR@Tj@RR@JJ+Jj.conj().T@RR@Ti@RR@JJ+JJ.conj().T@RR@Tj@RR@Ji+JJ.conj().T@RR@Ti@RR@Jj+JJ.conj().T@RR@Ti@RR@Tj@RR@JJ+JJ.conj().T@RR@Tj@RR@Ti@RR@JJ
    i,j=0,1
    actual=Gij(Ts[i],Ts[j],Js[i],Js[j],R,J)
    comp=Gij(Ts[i][:2,:2],Ts[j][:2,:2],Js[i][:2],Js[j][:2],Rc,J[:2])
    def V(d,z):return Js[d][2:,:]+Ts[d][2:,:2]@np.linalg.inv(z*np.eye(2)-A)@J[:2]
    rhs=V(i,np.conj(z)).conj().T@Rd@V(j,z)+V(j,np.conj(z)).conj().T@Rd@V(i,z)
    close(actual-comp,rhs)
    return 'exact matrix-valued mixed second-jet defect factorization'
chk('mixed second-jet loss factorization',C,jet_defect)

def positive_necessity():
    T=np.diag([2.,3.]);J=np.array([[1.],[0.]])
    Ti=np.array([[.0,.4],[.4,.0]]);Ji=np.array([[.2],[.1]])
    z=8.0;V=Ji[1,0]+Ti[1,0]/(z-2)
    delta=2*V**2/(z-3)
    assert delta>0
    return f'real-resolvent discrepancy {delta:.8f}>0'
chk('positive real-energy discrepancy necessity',C,positive_necessity,'E4')

def sufficiency():
    T=np.diag([2.,3.]);J=np.array([[1.],[0.]])
    Ti=np.diag([.4,.8]);Ji=np.array([[.2],[0.]])
    z=8.;R=np.linalg.inv(z*np.eye(2)-T)
    # both QJi and QTiP are exactly zero; all complementary paths vanish
    assert Ji[1,0]==0 and Ti[1,0]==0
    close((J.T@R@Ti@R@Ti@R@J),np.array([[.4*.4/(z-2)**3]]))
    return 'block-guard suffices for second-jet equality'
chk('block condition sufficient',C,sufficiency)

C='p4:prop:v251-dark-sector-second-return'
def dark():
    for q in (0.0,.1,-.6):
        T=np.array([[2.,3*q],[3*q,5.]])
        val=np.linalg.inv(z*np.eye(2)-T)[0,0]
        form=(z-5)/((z-2)*(z-5)-9*q*q)
        close(val,form)
    expected=18/(z-2)**2/(z-5)
    hz=1e-4
    g=lambda q:(z-5)/((z-2)*(z-5)-9*q*q)
    close((g(hz)-2*g(0)+g(-hz))/hz**2,expected,rtol=1e-7,atol=1e-7)
    return 'exact resolvent and nonzero second derivative'
chk('dark CAR second-return finite model',C,dark)
C='Paper4C-remark-line-10387'

def central():
    H=herm(3);q=1.25;H2=H+q*q*np.eye(3)
    I=np.eye(3)
    T=np.kron(H,I)-np.kron(I,H.T)
    T2=np.kron(H2,I)-np.kron(I,H2.T)
    close(T,T2)
    assert abs((q+.01)**2 -2*q*q+(q-.01)**2-2*.01**2)<1e-11
    return 'central shift cancels in ad_H but c(q)=q² has second derivative 2'
chk('absolute center invisible to ad_H',C,central)

C='p4c:prop:v254-nonsharp-ward-covariance'
def cov(r,A,B):
    a=A-np.trace(r@A)*np.eye(len(A)); b=B-np.trace(r@B)*np.eye(len(B));
    return np.trace(r@(a@b+b@a)/2)

def ward():
    r=rho(4);Hf,Hg,Bf,Bg=[herm(4) for _ in range(4)]
    Sf,Sg=-Hf+Bf,-Hg+Bg
    close(cov(r,Sf,Sg)-cov(r,Hf,Hg),cov(r,Bf,Bg)-cov(r,Hf,Bg)-cov(r,Bf,Hg))
    return 'nonsharp 2-test symmetrized covariance identity'
chk('nonsharp covariance expansion',C,ward)

def sharp():
    r=np.diag([1.,0.,0.]); Hf,Hg,Rf,Rg=[herm(3) for _ in range(4)];qf=np.diag([2.,3.,4.]);qg=np.diag([5.,6.,7.]);
    rhs=cov(r,Rf,Rg)-cov(r,Hf,Rg)-cov(r,Rf,Hg)
    Sf=-Hf+qf+Rf; Sg=-Hg+qg+Rg
    close(cov(r,Sf,Sg)-cov(r,Hf,Hg),rhs)
    return 'incoming sharp-charge cross terms zero'
chk('sharp-charge specialization',C,sharp)

C='p4c:thm:v254-zero-mode-no-omission'
def zero_mode():
    H=np.diag([0.,0.,2.,4.]);r=np.diag([.2,.4,.1,.3]); J=herm(4);J=J-np.trace(r@J)*np.eye(4)
    P=np.array([[1,1,0,0],[1,1,0,0],[0,0,1,0],[0,0,0,1]],dtype=float)
    JD=J*P; target=np.trace(r@(JD@JD))
    # spectral integration exactly via elementary sin factor
    E=np.diag(H);Tavg=100000.0
    avg=np.zeros_like(J,dtype=complex)
    for i in range(4):
        for j in range(4):
            w=E[i]-E[j]; avg[i,j]=J[i,j] if w==0 else J[i,j]*np.sin(w*Tavg)/(w*Tavg)
    calc=np.trace(r@(avg@J+J@avg)/2)
    assert abs(calc-target)<0.005
    assert np.real(target)>=0
    return f'finite Cesaro average {np.real(calc):.5g}, stationary diagonal {np.real(target):.5g}'
chk('degenerate finite stationary-noise Cesaro retention',C,zero_mode)

def zero_psd():
    r=rho(3);r=np.diag(np.linalg.eigvalsh(r));J=[herm(3) for _ in range(4)]
    Cmat=np.array([[cov(r,A,B) for B in J] for A in J]);assert np.min(np.linalg.eigvalsh(Cmat))>=-1e-10
    return 'polarized stationary noise Gram is PSD'
chk('positive two-tag zero-mode covariance',C,zero_psd)

def retarded_no_go():
    H=np.zeros((2,2));r=np.eye(2)/2;J=np.diag([1.,-1.]);
    close(J@J-J@J,np.zeros((2,2)));close(np.trace(r@J@J),1.)
    return 'retarded commutator zero; connected noise 1'
chk('retarded-only no-go exact 2x2 example',C,retarded_no_go,'E4')

C='p4c:prop:v254-angular-spin-two-inverse'
for l in (0,1,2,3,4,7):
    def harmonic(l=l):
        lam=.5*l*(l+1)*(l*(l+1)-2)
        close(lam,.5*(l-1)*l*(l+1)*(l+2))
        if l>=2:close((2/((l-1)*l*(l+1)*(l+2)))*lam,1.)
        else:close(lam,0.)
        return f'ell={l}, eigenvalue={lam}'
    chk(f'round angular multipole ell={l}',C,harmonic)

C='p4c:prop:v320-s5-signed-lift'
phi=(1+5**.5)/2
axes=np.array([(1,1,1),(1,1,-1),(1,-1,1),(1,-1,-1),(1/phi,-phi,0),(phi,0,-1/phi),(0,1/phi,-phi),(0,1/phi,phi),(phi,0,1/phi),(1/phi,phi,0)],dtype=float)/np.sqrt(3)
G=nx.Graph();G.add_nodes_from(range(10));S=np.zeros((10,10),dtype=int)
for i,j in itertools.combinations(range(10),2):
    d=np.dot(axes[i],axes[j]);
    if abs(d)>2/3:G.add_edge(i,j);S[i,j]=S[j,i]=int(np.sign(d))
pairs=list(itertools.combinations(range(5),2));H=nx.Graph();H.add_nodes_from(pairs)
for a,b in itertools.combinations(pairs,2):
    if set(a).isdisjoint(b):H.add_edge(a,b)
map_v=next(nx.algorithms.isomorphism.GraphMatcher(G,H).isomorphisms_iter()); reverse={v:k for k,v in map_v.items()}

def exact_lift_all():
    count={1:0,-1:0}
    for perm in itertools.permutations(range(5)):
        parity=(-1)**sum(perm[i]>perm[j] for i in range(5) for j in range(i+1,5))
        ix={v:reverse[tuple(sorted(perm[i] for i in map_v[v]))] for v in range(10)}
        eps={0:1};queue=[0]
        while queue:
            v=queue.pop(0)
            for w in G[v]:
                sign=parity*S[v,w]*S[ix[v],ix[w]]*eps[v]
                if w not in eps:eps[w]=sign;queue.append(w)
                else:assert eps[w]==sign
        assert len(eps)==10
        M=np.zeros((10,10))
        for i in range(10):M[ix[i],i]=eps[i]
        close(M.T@S@M,parity*S,atol=1e-10)
        count[parity]+=1
    return f'parity-lift certified for {count[1]} even and {count[-1]} odd S5 permutations'
chk('exhaustive signed lift all 120 automorphisms',C,exact_lift_all)

def signed_eigenspaces():
    w,V=la.eigh(S);close(np.sort(w),np.sort(np.array([-np.sqrt(5)]*3+[0]*4+[np.sqrt(5)]*3)))
    Pp=.5*((S@S)/5+S/np.sqrt(5));Pm=.5*((S@S)/5-S/np.sqrt(5));P0=np.eye(10)-S@S/5
    for P in [Pp,Pm,P0]:close(P@P,P)
    close(np.trace(Pp),3);close(np.trace(Pm),3);close(np.trace(P0),4)
    return '3+4+3 projector dimensions and spectral identities'
chk('signed Petersen projectors 3+4+3',C,signed_eigenspaces)

def odd_projectors():
    perm=(1,0,2,3,4);parity=-1
    ix={v:reverse[tuple(sorted(perm[i] for i in map_v[v]))] for v in range(10)}
    eps={0:1};queue=[0]
    while queue:
        v=queue.pop(0)
        for w in G[v]:
            s=parity*S[v,w]*S[ix[v],ix[w]]*eps[v]
            if w not in eps:eps[w]=s;queue.append(w)
            else:assert eps[w]==s
    M=np.zeros((10,10))
    for i in range(10):M[ix[i],i]=eps[i]
    Pp=.5*((S@S)/5+S/np.sqrt(5));Pm=.5*((S@S)/5-S/np.sqrt(5));P0=np.eye(10)-S@S/5
    close(M.T@Pp@M,Pm);close(M.T@P0@M,P0)
    return 'odd permutation swaps +/- sqrt5, fixes zero spectral sector'
chk('odd signed automorphism swaps chiral projectors',C,odd_projectors)

C='p4c:prop:v320-transfer-proof'
def transfer():
    v=axes[0].reshape(3,1);Pa=v@v.T;Pt=np.eye(3)-Pa
    Q=np.linalg.qr(rng.normal(size=(3,3)))[0]
    T=Q@(2*Pa+.5*Pt)
    close(T.T@T,4*Pa+.25*Pt)
    K=T/2
    close(K.T@K,Pa+Pt/16)
    close(np.real_if_close(la.sqrtm(np.eye(3)-K.T@K)),np.sqrt(15)/4*Pt,atol=1e-7)
    return 'singular values [2,1/2,1/2] and two-instrument effects'
chk('transfer singular values and CP POVM',C,transfer)

def transfer_resolvent():
    v=axes[1].reshape(3,1);Pa=v@v.T;Pt=np.eye(3)-Pa;T=2*Pa+.5*Pt
    HH=np.block([[np.zeros((3,3)),T.T],[T,np.zeros((3,3))]])
    w=np.linalg.eigvalsh(HH);close(w,[-2,-.5,-.5,.5,.5,2])
    z2=2.45+.71j
    R=np.linalg.inv(z2*np.eye(6)-HH)
    close(R[:3,:3],z2/(z2*z2-4)*Pa+z2/(z2*z2-.25)*Pt)
    return 'six-pole spectrum, correct doubled resolvent and sign-invariant diagonal'
chk('six-dimensional transfer pole and resolvent',C,transfer_resolvent)

def transfer_sign():
    T=herm(3).real; Z=np.diag([1,1,1,-1,-1,-1]);H=np.block([[np.zeros((3,3)),T],[T,np.zeros((3,3))]])
    Hp=np.block([[np.zeros((3,3)),-T],[-T,np.zeros((3,3))]])
    close(Z@H@Z,Hp);close(la.det(1.5*np.eye(6)-H),la.det(1.5*np.eye(6)-Hp))
    return 'sign conjugation preserves characteristic polynomial'
chk('complementary sign is gauge for isolated CP operation',C,transfer_sign)

C='p4c:prop:v320-quantum-readout-no-go'
def effects_basis():
    F=[.3*np.outer(u,u) for u in axes];close(sum(F),np.eye(3))
    vec=np.array([f.flatten() for f in F]); assert np.linalg.matrix_rank(vec,tol=1e-10)==6
    prod=np.array([np.kron(a,b).flatten() for a in F for b in F]);assert np.linalg.matrix_rank(prod,tol=1e-10)==36
    return '10 real effects span 6; 100 products span 36'
chk('real and reciprocal effect ranks',C,effects_basis)

def readout_obstruction():
    A=np.zeros((3,3));A[0,1]=1;A[1,0]=-1
    F=[.3*np.outer(u,u) for u in axes]
    for E in F:close(np.trace(E@(1j*A)),0.)
    M=np.kron(A,A); Rp=np.eye(9)/9+M/18;Rm=np.eye(9)/9-M/18
    assert np.min(np.linalg.eigvalsh(Rp))>0 and np.min(np.linalg.eigvalsh(Rm))>0
    for E in F:
      for B in F:close(np.trace((Rp-Rm)@np.kron(E,B)),0.)
    close(np.trace((Rp-Rm)@M),4/9)
    return 'positive indistinguishable states with 4/9 correlation separation'
chk('explicit 9-state product-readout blind pair',C,readout_obstruction,'E4')

def real_history():
    A=np.zeros((3,3));A[0,1]=1;A[1,0]=-1;E=.3*np.outer(axes[0],axes[0]);K=rng.normal(size=(3,3));Ef=K.T@E@K
    close(np.trace(Ef@(1j*A)),0)
    return 'real Kraus conjugation preserves imaginary antisymmetric blind space'
chk('real Kraus history preserves real-symmetric effects',C,real_history)

C='p4c:thm:v347-first-cutoff-cumulant'
def ladder(N):
    a=np.diag(np.sqrt(np.arange(1,N+1,dtype=float)),1)
    return a+a.T

def moments(q,M):
    v=np.eye(len(q))[0];return [float(v@np.linalg.matrix_power(q,k)@v) for k in range(M+1)]

def cumulants(mom):
    K=[0.0]*len(mom)
    for n in range(1,len(mom)):
        K[n]=mom[n]-sum(math.comb(n-1,k-1)*K[k]*mom[n-k] for k in range(1,n))
    return K
for N in (1,2,3,4,5,6):
    def cutoff(N=N):
        sig=.75; Q=ladder(N)*sig;m=moments(Q,2*N+2);k=cumulants(m)
        for j in range(1,N+1):close(m[2*j],math.prod(range(1,2*j,2))*sig**(2*j),rtol=3e-8)
        close(m[-1],(math.prod(range(1,2*N+2,2))-math.factorial(N+1))*sig**(2*N+2),rtol=4e-8)
        close(k[-1],-math.factorial(N+1)*sig**(2*N+2),rtol=4e-8)
        for j in range(3,2*N+2):assert abs(k[j])<1e-6
        return f'N={N}, first cutoff cumulant at order {2*N+2}'
    chk(f'first nonGaussian cutoff cumulant N={N}',C,cutoff)

C='p4c:prop:v347-cutoff-ordering'
def cutoff_1():
    Hbar=1.3;omega=2.2;gq=.9;gp=1.7
    a=np.array([[0,1],[0,0]],complex);ad=a.conj().T
    q=np.sqrt(Hbar/(2*omega))*(a+ad);p=1j*np.sqrt(Hbar*omega/2)*(ad-a)
    h=(gq*q@q+gp*p@p)/2
    close(h,Hbar/4*(gq/omega+gp*omega)*np.eye(2))
    return 'truncated N=1 quadratic is scalar identity and degenerate'
chk('compressed polynomial ordering N=1',C,cutoff_1,'E4')

C='p4c:thm:v347-multimode-covariance'
for m in (1,2,3):
    def sympl(m=m):
        n=2*m;J=np.block([[np.zeros((m,m)),np.eye(m)],[-np.eye(m),np.zeros((m,m))]])
        K=rng.normal(size=(n,n));K=(K+K.T)/2
        S=la.expm(J@K*.15)
        close(S@J@S.T,J,atol=2e-9)
        omega=np.arange(1,m+1)+.25;G0=np.diag(np.r_[omega,omega]);G=S.T@G0@S
        D=J@G;R=la.sqrtm(-D@D);Jg=D@np.linalg.inv(R);Gam=-.5*Jg@J
        close(Jg@Jg,-np.eye(n),rtol=2e-8,atol=2e-8);close(Gam,Gam.T,rtol=2e-8,atol=2e-8)
        assert np.min(np.linalg.eigvalsh(np.real(Gam)))>0
        close(Gam@J@Gam,.25*J,rtol=3e-8,atol=3e-8)
        close(Gam,.5*np.linalg.inv(S)@np.linalg.inv(S.T),rtol=3e-8,atol=3e-8)
        if m==1:close(Gam,.5*np.sqrt(np.linalg.det(G))*np.linalg.inv(G),rtol=3e-8)
        return f'm={m}, positive symplectic-pure covariance'
    chk(f'Williamson covariance m={m}',C,sympl)

C='p4c:thm:v349-hermite-vacuum-law'
from numpy.polynomial.hermite_e import hermeval
for N in (1,2,3,5,7):
    def hermite(N=N):
        Q=ladder(N);e,V=la.eigh(Q)
        coeff=np.zeros(N+2);coeff[-1]=1
        roots=np.sort(np.polynomial.hermite_e.hermeroots(coeff))
        close(e,roots,atol=1e-9)
        coeff_n=np.zeros(N+1);coeff_n[-1]=1
        w=np.array([math.factorial(N)/((N+1)*hermeval(x,coeff_n)**2) for x in e])
        close(w,np.abs(V[0,:])**2,atol=1e-8)
        close(np.sum(w),1)
        for k in range(2*N+2):
            ref=0 if k%2 else math.prod(range(1,k,2))
            close(np.dot(w,e**k),ref,atol=2e-5,rtol=5e-8)
        return f'N={N}, exact Gaussian quadrature to degree {2*N+1}'
    chk(f'Hermite spectral nodes and Gauss weights N={N}',C,hermite)

def hermite_associated():
    for N in range(1,7):
        x=1.75+0.4j;hprev=1.;h=x
        if N==1:assoc=x
        else:
            for k in range(1,N):
                nxt=x*h-(k+1)*hprev;hprev,h=h,nxt
            assoc=h
        coeff=np.zeros(N+2);coeff[-1]=1;he=hermeval(x,coeff)
        Q=ladder(N);g=np.linalg.inv(x*np.eye(N+1)-Q)[0,0]
        close(g,assoc/he)
    return 'trailing associated-Hermite numerator, not standard He_N'
chk('Cramer resolvent uses associated Hermite polynomial',C,hermite_associated)

C='p4c:thm:v349-multimode-first-cumulant'
def multimode():
    caps=[1,1,2,3];sig=[.8,1.1,.7,1.4];c=[2.,-1.3,.2,0.]
    nmax=4;mom=[1.]+[0.]*nmax
    for N,s,a in zip(caps,sig,c):
        local=moments(ladder(N)*s*a,nmax)
        new=[sum(math.comb(k,j)*mom[k-j]*local[j] for j in range(k+1)) for k in range(nmax+1)]
        mom=new
    kap=cumulants(mom)[4];pred=-2*sum((a*s)**4 for N,a,s in zip(caps,c,sig) if N==1 and a!=0)
    close(kap,pred,atol=1e-8);assert kap<0
    return f'min cap=1, fourth cumulant={kap:.8g}<0'
chk('independent product fourth cumulant cannot cancel',C,multimode)

def real_sign():
    for s in (-1.,1.):
        m1=cumulants(moments(ladder(2)*s*1.3,6))[6]
        close(m1,-6*1.3**6)
    return 'even-power first cutoff cumulant unaffected by relative sign'
chk('no sign cancellation at sixth cumulant',C,real_sign)

def no_nonzero_case():
    coefficients=[0.,0.]
    assert not [i for i,x in enumerate(coefficients) if x!=0]
    assert min((i for i,x in enumerate(coefficients) if x!=0),default=None) is None
    return 'SOURCE-AS-PRINTED allows all c_a=0; m=min(empty set) undefined'
chk('adversarial all-zero coefficient missing guard',C,no_nonzero_case,'E4',scope='in-domain real coefficient edge case; source theorem does not require any c_a !=0')

result={'audit':'Paper4C','batch':7,'source':'Paper4C-TechnicalMaterial-v1_42.tex','scope':{'lines':[10129,10934],'named_claims':23},'evidence_semantics':'E3 finite/symbolic constructive controls, E4 targeted adversarial controls; PASS for attack means counterexample successfully reproduced, not universal theorem validated','checks':records,'count':len(records),'pass':sum(x['status']=='PASS' for x in records),'fail':sum(x['status']=='FAIL' for x in records),'E3':sum(x['evidence_class']=='E3' for x in records),'E4':sum(x['evidence_class']=='E4' for x in records)}
path=os.path.join(os.path.dirname(__file__),'Paper4C-Batch7IndependentChecks-v1_1.json')
with open(path,'w') as f:json.dump(result,f,indent=2)
print('CHECKS',result['count'],'PASS',result['pass'],'FAIL',result['fail'],'E3',result['E3'],'E4',result['E4'])
for row in records:
    if row['status']!='PASS':print(row['id'],row['name'],row['result'])
if result['fail']:raise SystemExit(1)
