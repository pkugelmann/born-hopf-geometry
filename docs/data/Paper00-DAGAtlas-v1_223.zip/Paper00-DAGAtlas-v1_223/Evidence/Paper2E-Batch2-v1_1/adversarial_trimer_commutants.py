"""Independent exact E4 controls for Paper2E batch2, lines1275-1957."""
from itertools import product
from collections import Counter
import json
import sympy as s
I=s.I
om=-s.Rational(1,2)+I*s.sqrt(3)/2
X=s.Matrix([[0,0,1],[1,0,0],[0,1,0]])
Z=s.diag(1,om,s.expand(om**2))
assert X**3==s.eye(3)
assert s.simplify(Z**3-s.eye(3))==s.zeros(3)
assert s.simplify(Z*X-om*X*Z)==s.zeros(3)
Ps=[s.diag(*[int(i==j) for i in range(3)]) for j in range(3)]
D1=Ps[0]-s.eye(3)/3;D2=Ps[1]-Ps[2]
C1=X+X.T;C2=-I*(X-X.T)
slice_basis=[s.eye(3),D1,D2,C1,C2]
vec=lambda M:s.Matrix(list(M))
realvec=lambda M:s.Matrix([s.re(x) for x in M]+[s.im(x) for x in M])
R=s.Matrix.hstack(*[realvec(M) for M in slice_basis])
assert R.rank()==5
outside=Ps[0]*X*Ps[2]+Ps[2]*X.T*Ps[0]
assert R.row_join(realvec(outside)).rank()==6
weyl=[X**a*Z**b for a,b in product(range(3),repeat=2)]
for j,A in enumerate(weyl):
 for k,B in enumerate(weyl):
  assert s.simplify(s.trace(A.conjugate().T*B)-(3 if j==k else 0))==0
matrixunits=[Ps[i]*X**a*Ps[j] for i,j,a in product(range(3),range(3),range(3))]
assert s.Matrix.hstack(*map(vec,matrixunits)).rank()==9
Ds=[P-s.eye(3)/3 for P in Ps]
assert s.Matrix(3,3,lambda i,j:s.trace(Ds[i]*Ds[j]))==s.eye(3)-s.ones(3)/3
roots=[Ps[0]-Ps[1],Ps[1]-Ps[2]]
assert s.Matrix(2,2,lambda i,j:s.trace(roots[i]*roots[j]))==s.Matrix([[2,-1],[-1,2]])
# Every real transport vector can be expressed with rho>=0; endpoints and zero.
polar_controls=[]
for c,d in [(0,0),(1,0),(-1,0),(0,1),(0,-1),(s.Rational(3,5),s.Rational(4,5))]:
 rho=s.sqrt(c*c+d*d)
 H=c*C1+d*C2
 assert H==H.conjugate().T
 if rho:
  assert s.simplify((c/rho)**2+(d/rho)**2-1)==0
 polar_controls.append([str(c),str(d),str(rho)])
# Cube link minus two antipodes is six-cycle; coordinate cyclic shift acts
# separately/free/transitively on sum+1 and sum-1 trimers.
cube=list(product([-1,1],repeat=3))
verts=[v for v in cube if abs(sum(v))==1]
adj={v:[w for w in verts if sum(x!=y for x,y in zip(v,w))==1] for v in verts}
assert len(verts)==6 and all(len(adj[v])==2 for v in verts)
for sign in [-1,1]:
 T=[v for v in verts if sum(v)==sign]
 assert len(T)==3
 v=T[0];orbit=[v,(v[1],v[2],v[0]),(v[2],v[0],v[1])]
 assert set(orbit)==set(T)
# Exact Lie-algebra commutant dimension: nullspace of commutators.
def spin(j):
 dim=int(2*j+1);ws=[j-k for k in range(dim)]
 Jz=s.diag(*ws);Jp=s.zeros(dim)
 for k,m in enumerate(ws):
  if k>0:Jp[k-1,k]=s.sqrt((j-m)*(j+m+1))
 return (Jp+Jp.T)/2,(Jp-Jp.T)/(2*I),Jz
J0=spin(s.Integer(0));Jh=spin(s.Rational(1,2));J1=spin(s.Integer(1))
def reps(sectors):
 blocks=[[],[],[],[],[],[]]
 for jl,jr in sectors:
  L=spin(jl);R=spin(jr);dl=int(2*jl+1);dr=int(2*jr+1)
  for k in range(3):
   blocks[k].append(s.kronecker_product(L[k],s.eye(dr)))
   blocks[k+3].append(s.kronecker_product(s.eye(dl),R[k]))
 return [s.diag(*b) for b in blocks]
def commdim(gens):
 n=gens[0].rows
 M=s.SparseMatrix.vstack(*[s.SparseMatrix(s.kronecker_product(s.eye(n),G)-s.kronecker_product(G.T,s.eye(n))) for G in gens])
 return n*n-M.rank()
h=s.Rational(1,2)
p=reps([(h,0),(0,h)])
unmarked_dim=commdim([p[0],p[2],p[3],p[5]])
marked_dim=commdim([p[0],p[2],p[5]])
assert unmarked_dim==2 and marked_dim==3
PL=s.diag(1,1,0,0);PR=s.eye(4)-PL;Gamma=PL-PR
QH=-2*p[5]
assert QH**2==PR and Gamma==s.eye(4)-2*QH**2
assert QH*p[3]-p[3]*QH!=s.zeros(4) # valid marked, invalid unmarked counterwitness
zL=s.diag(-1,-1,1,1);zR=s.diag(1,1,-1,-1)
assert zL==-Gamma and zR==Gamma and zL*zR==-s.eye(4)
# Lie group exponential half-turn from integer Hopf weights, separate from
# equality of generators themselves.
assert s.diag(*[s.exp(I*s.pi*q) for q in QH.diagonal()])==Gamma
assert QH!=Gamma
sectors=[(0,0),(h,0),(0,h),(h,h),(1,0),(0,1)]
f=reps(sectors)
full_marked_dim=commdim([f[0],f[2],f[5]])
assert full_marked_dim==12
multiplicities=Counter()
for jl,jr in sectors:
 for k in range(int(2*jr+1)):
  m=jr-k;multiplicities[(str(jl),str(-2*m))]+=1
assert sorted(multiplicities.values())==[1]*8+[2]
assert sum(mult*int(2*s.Rational(jl)+1) for (jl,q),mult in multiplicities.items())==15
# Weighted trace source domains: real coefficients in unmarked/marked commutants.
a,b,d,q,lam=s.symbols('a b d q lambda', real=True)
Q=a*PL+b*PR
A1=s.trace(Gamma*Q);A3=s.trace(Gamma*Q**3)
assert A1==2*(a-b) and s.expand(A3-2*(a**3-b**3))==0
assert s.expand(A1.subs(b,-a))==4*a
assert s.expand(A3.subs(b,-a))==4*a**3
# Marked zero locus imposes b+=a+d,b-=a-d: cubic is -6*a*d^2.
T=s.diag(a,a,a+d,a-d)
assert s.trace(Gamma*T)==0
assert s.expand(s.trace(Gamma*T**3))==-6*a*d*d
for aa,dd in [(0,0),(2,0),(-1,0),(0,3),(0,-2)]:
 TT=T.subs({a:aa,d:dd});assert s.trace(Gamma*TT)==0 and s.trace(Gamma*TT**3)==0
# Union not span: I+QH is a traceless-weighted linear-zero mutation, cubic nonzero.
assert s.trace(Gamma*(s.eye(4)+QH))==0
assert s.trace(Gamma*(s.eye(4)+QH)**3)==-6
for n in [0,1,2,4,9]:
 assert s.trace((q*Gamma)**(2*n+1))==0
 assert s.trace(Gamma*(q*Gamma)**(2*n+1))==4*q**(2*n+1)
# Charge normalization global vs pointwise: one global lambda fails on Q=Gamma.
assert 4*s.Rational(1,2)==2 and 4*s.Rational(1,2)**3!=2
assert list(s.polys.polytools.groebner([2*lam-1,2*lam**3-1],lam))==[1]
# Every nonzero scalar Q=tI is a pointwise common-zero control for arbitrary lambda.
t=s.symbols('t',real=True)
assert s.trace(Gamma*(lam*t*s.eye(4)))==0
assert s.trace(Gamma*(lam*t*s.eye(4))**3)==0
mode_counts={}
for m in range(7):
 value=sum((a+1)*(b+1) for a in range(2*m+1) for b in range(2*m+1-a))
 assert value==s.binomial(2*m+4,4)
 mode_counts[m]=value
result={'all_assertions_passed':True,'auxiliary_lower_ideal_count_controls':mode_counts,'trimer_real_slice_dimension':5,'outside_slice_control_increases_rank':6,
 'generated_complex_matrix_algebra_dimension':9,'weyl_operators':9,'polar_controls':polar_controls,
 'cube_link_minus_antipodes':'six-cycle with two cyclic three-point orbits',
 'protected_commutant_complex_dimensions':{'unmarked':unmarked_dim,'oriented_Hopf_marked':marked_dim},
 'fullH1_marked_commutant_complex_dimension':full_marked_dim,
 'fullH1_marked_irrep_multiplicities':{str(k):v for k,v in multiplicities.items()},
 'marked_weighted_zero_locus':'RI union RQ_H','nonspan_control_A3_I_plus_QH':-6,
 'global_charge_rescaling':'no single lambda; witness Gamma',
 'nonzero_scalar_pointwise_rescaling':'all lambda match zero traces; does not refute global statement',
 'ordinary_odd_trace_controls':[0,1,2,4,9]}
print(json.dumps(result,indent=2))
