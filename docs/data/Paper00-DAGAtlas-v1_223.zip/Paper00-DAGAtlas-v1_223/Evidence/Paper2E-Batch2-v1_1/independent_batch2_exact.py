"""Independent exact verification of Paper II-E batch-2 mathematical exports.

The inputs are source-defined objects and explicit elementary matrices. No
Atlas verdict or other reviewer's result is consumed. Finite checks complement
the general arguments in the accompanying independent.json proposal.
"""
import sympy as s
from itertools import product
from fractions import Fraction as F
from pathlib import Path
import json

checks=[]
def check(name,condition,result):
    if not bool(condition):raise AssertionError(name)
    checks.append({'check':name,'passed':True,'result':result})
def zero(A):return s.simplify(A)==s.zeros(*A.shape)

# One exact Hurwitz/cube representative, independent of physical role labels.
cube=list(product([-1,1],repeat=3))
six=[x for x in cube if abs(sum(x))==1]
adj=s.Matrix([[int(sum(a!=b for a,b in zip(x,y))==1) for y in six] for x in six])
reach=(s.eye(6)+adj)**5
check('Nonaxial cube link is one six-cycle',len(six)==6 and all(sum(adj.row(i))==2 for i in range(6)) and all(x>0 for x in reach),{'vertices':6,'degrees':[2]*6,'connected':True})
Tp=[x for x in six if sum(x)==1];Tm=[x for x in six if sum(x)==-1]
cyc=lambda x:(x[2],x[0],x[1])
check('Both trimers have free transitive cyclic action',all({x,cyc(x),cyc(cyc(x))}==set(T) for T in [Tp,Tm] for x in T),{'trimer_sizes':[len(Tp),len(Tm)]})
def qm(q,r):
    a,b,c,d=q;e,f,g,h=r
    return(a*e-b*f-c*g-d*h,a*f+b*e+c*h-d*g,a*g-b*h+c*e+d*f,a*h+b*g-c*f+d*e)
q=(F(1,2),)*4;unit=(F(1),F(0),F(0),F(0));powers=[unit]
for _ in range(6):powers.append(qm(powers[-1],q))
check('Cyclic diagonal-stabilizer lift has order six',powers[3]==tuple(-x for x in unit) and powers[6]==unit and len(set(powers[:6]))==6,{'order':6,'cube':str(powers[3])})

# Trimer operators and complete finite Weyl basis.
I=s.I;I3=s.eye(3);omega=(-1+s.sqrt(3)*I)/2
X=s.Matrix([[0,0,1],[1,0,0],[0,1,0]])
Z=s.diag(1,omega,s.expand(omega**2))
P=[s.diag(*[int(i==j) for i in range(3)]) for j in range(3)]
D1=s.diag(s.Rational(2,3),-s.Rational(1,3),-s.Rational(1,3));D2=s.diag(0,1,-1)
C1=X+X.conjugate().T;C2=-I*(X-X.conjugate().T)
check('Trimer regular representation',X**3==I3 and X.trace()==0 and (X**2).trace()==0,{'character_at_identity':3,'character_at_nonidentity':0,'irreducible_multiplicities':[1,1,1]})
slice_basis=[I3,D1,D2,C1,C2]
realcols=[s.Matrix([s.re(x) for x in B]+[s.im(x) for x in B]) for B in slice_basis]
check('First-order Hermitian slice has real dimension five',all(B==B.conjugate().T for B in slice_basis) and s.Matrix.hstack(*realcols).rank()==5,{'dimension':5,'full_Hermitian_dimension':9})
phi=s.symbols('phi',real=True)
check('Transport polar parametrization',zero(s.expand_complex(s.exp(-I*phi)*X+s.exp(I*phi)*X**2)-s.cos(phi)*C1-s.sin(phi)*C2),'C(phi)=cos(phi) C1+sin(phi) C2')
check('Finite Weyl commutator',zero(Z*X-omega*X*Z) and zero(Z**3-I3),'ZX=omega XZ; X^3=Z^3=I')
W=[X**a*Z**b for a in range(3) for b in range(3)]
gram=s.Matrix([[s.simplify(s.trace(A.conjugate().T*B)) for B in W] for A in W])
check('Nine finite Weyl operators trace-orthogonal',gram==3*s.eye(9),{'Gram':'3 I9','complex_span_dimension':9})
Ds=[p-I3/3 for p in P]
defects=s.Matrix([[s.trace(A*B) for B in Ds] for A in Ds])
check('Centered projector defect Gram',defects==s.eye(3)-s.ones(3)/3,{'diagonal':'2/3','off_diagonal':'-1/3','rank':defects.rank()})
roots=[P[0]-P[1],P[1]-P[2]]
rootgram=s.Matrix([[s.trace(A*B) for B in roots] for A in roots])
check('A2 root-plane Gram',rootgram==s.Matrix([[2,-1],[-1,2]]),{'Gram':str(rootgram)})
units=[P[i]*X**((i-j)%3)*P[j] for i in range(3) for j in range(3)]
check('Projectors and shift generate all M3',s.Matrix.hstack(*[s.Matrix(B).reshape(9,1) for B in units]).rank()==9,'P_i X^(i-j) P_j=E_ij')

# All-m dimension proof is stars-and-bars: replace factors (a+1),(b+1) by
# two compositions each, and use one slack variable for a+b<=2m.
for m in range(8):
    dim=sum((a+1)*(b+1) for a in range(2*m+1) for b in range(2*m+1-a))
    check('Auxiliary lower-ideal dimension control m='+str(m),dim==s.binomial(2*m+4,4),{'m':m,'dimension':int(dim)})

# Full level-one action in six sectors: 1, SL, SR, vector, adjL, adjR.
# Rational sl2 raising/lowering generators avoid numerical diagonalization.
E2=s.Matrix([[0,1],[0,0]]);F2=E2.T;H2=s.diag(1,-1)
E3=s.Matrix([[0,2,0],[0,0,1],[0,0,0]])
F3=s.Matrix([[0,0,0],[1,0,0],[0,2,0]]);H3=s.diag(2,0,-2)
L=[s.diag(s.zeros(1),G,s.zeros(2),s.kronecker_product(G,s.eye(2)),J,s.zeros(3)) for G,J in [(E2,E3),(F2,F3),(H2,H3)]]
R=[s.diag(s.zeros(1),s.zeros(2),G,s.kronecker_product(s.eye(2),G),s.zeros(3),J) for G,J in [(E2,E3),(F2,F3),(H2,H3)]]
Q=-R[2];charges=list(Q.diagonal())
def centralizer_dimension(gens,diagonal=None):
    n=gens[0].rows
    variables=[(i,j) for i in range(n) for j in range(n) if diagonal is None or diagonal[i]==diagonal[j]]
    rows=[]
    for G in gens:
        for i in range(n):
            for j in range(n):
                row=[(G[b,j] if i==a else 0)-(G[i,a] if j==b else 0) for a,b in variables]
                if any(row):rows.append(row)
    A=s.Matrix(rows)
    return len(variables)-A.rank(),len(variables),A.rank()
marked_dim,variables,rank=centralizer_dimension(L,charges)
check('Full H1 marked centralizer dimension by exact linear solve',marked_dim==12,{'unknowns_after_charge_restriction':variables,'constraint_rank':rank,'centralizer_dimension':marked_dim})
# Complete expected algebra basis, including the 2x2 multiplicity block.
neutral_trivial=[0,13] # scalar, and m_R=0 in right adjoint
algbasis=[]
for i in neutral_trivial:
    for j in neutral_trivial:
        B=s.zeros(15);B[i,j]=1;algbasis.append(B)
type_indices=[[1,2],[3],[4],[5,7],[6,8],[9,10,11],[12],[14]]
for inds in type_indices:
    B=s.zeros(15)
    for i in inds:B[i,i]=1
    algbasis.append(B)
check('Full H1 marked algebra is M2 plus eight scalar blocks',len(algbasis)==12 and all(B*G==G*B for B in algbasis for G in L+[Q]) and s.Matrix.hstack(*[B.reshape(225,1) for B in algbasis]).rank()==12,{'algebra':'M2(C) direct sum C^8','type_dimensions':[2,2,1,1,2,2,3,1,1]})
prot=[1,2,3,4]
Lprot=[G.extract(prot,prot) for G in L];Rprot=[G.extract(prot,prot) for G in R]
Qp=Q.extract(prot,prot);Gamma=s.diag(1,1,-1,-1);I4=s.eye(4)
unmarked_dim,_,_=centralizer_dimension(Lprot+Rprot)
marked_prot_dim,_,_=centralizer_dimension(Lprot,list(Qp.diagonal()))
check('Protected unmarked versus marked centralizers',unmarked_dim==2 and marked_prot_dim==3,{'Spin4_dimension':2,'SU2xU1_dimension':3})
check('Marked protected grading polynomial',Qp*Qp==s.diag(0,0,1,1) and Gamma==I4-2*Qp*Qp,'Q_H^2=P_R; Gamma=I-2 Q_H^2')
zL=s.diag(-1,-1,1,1);zR=-zL
check('Finite antipodal center actions',zL==-Gamma and zR==Gamma and zL*zR==-I4,'rho(zL)=-Gamma; rho(zR)=Gamma; rho(zc)=-I')
half=s.diag(*[s.simplify(s.exp(I*s.pi*q)) for q in Qp.diagonal()])
check('Half-turn grading does not equal infinitesimal generator',half==Gamma and Qp!=Gamma,'exp(i pi Q_H)=Gamma while Q_H != Gamma')
flip=s.diag(s.eye(2),s.Matrix([[0,1],[1,0]]))
a,bp,bm,d=s.symbols('a b_plus b_minus d',real=True)
Tp=s.diag(a,a,bm,bp) # basis has q=-1,+1 on the right
check('Unoriented Weyl flip identifies opposite right eigenvalues',zero(Tp*flip-flip*Tp) is False and zero((Tp*flip-flip*Tp).subs(bp,bm)),'flip invariance requires b_plus=b_minus')

# Independent polynomial trace evaluation in fixed eigenvalue matrices.
aa,bb,q=s.symbols('a_unmarked b_unmarked q',real=True)
U=s.diag(aa,aa,bb,bb)
f1=s.trace(Gamma*U);f3=s.trace(Gamma*U**3)
check('Unmarked weighted trace polynomials',s.expand(f1)==2*(aa-bb) and s.expand(f3)==2*(aa**3-bb**3),{'A1':str(f1),'A3':str(f3)})
check('Unmarked joint zero ideal',s.groebner([f1,f3],aa,bb).polys[0].as_expr()==aa-bb,'common zero locus a=b; traceless intersection is zero')
check('Traceless weighted traces',s.trace(Gamma*(q*Gamma))==4*q and s.trace(Gamma*(q*Gamma)**3)==4*q**3,'A1=4q; A3=4q^3')
marked1=s.trace(Gamma*Tp);marked3=s.trace(Gamma*Tp**3)
check('Marked weighted trace polynomials',marked1==2*a-bp-bm and marked3==2*a**3-bp**3-bm**3,{'A1':str(marked1),'A3':str(marked3)})
reduced=s.factor(marked3.subs({bp:a+d,bm:a-d}))
check('Marked real zero-locus factorization',reduced==-6*a*d*d,{'reduced_cubic':str(reduced),'zero_locus':'d=0 or a=0; scalar line union Hopf-charge line'})
check('Marked ordinary traceless restriction',s.trace(Tp.subs({bp:a+d,bm:a-d}))==4*a,'on zero locus ordinary tracelessness selects a=0, the Q_H line')
check('Union not linear span control',s.trace(Gamma*(I4+Qp))==0 and s.trace(Gamma*(I4+Qp)**3)!=0,'I and Q_H separately vanish, but I+Q_H has weighted cubic -6')
lam=s.symbols('lambda',positive=True)
normideal=s.groebner([2*lam-1,2*lam**3-1],lam)
check('No common nonzero charge rescaling of spinor/species normalization',normideal.polys[0].as_expr()==1,'2lambda=1 and 2lambda^3=1 have empty joint locus')
for n in range(5):
    check('Odd ordinary versus weighted trace control n='+str(n),s.trace((q*Gamma)**(2*n+1))==0 and s.trace(Gamma*(q*Gamma)**(2*n+1))==4*q**(2*n+1),{'odd_degree':2*n+1,'ordinary':0,'weighted':str(4*q**(2*n+1))})

# A nonabelian curvature span rules out replacing connection holonomy by an axis.
sigma=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-I],[I,0]]),s.diag(1,-1)]
t=[-I*p/2 for p in sigma]
comm=[t[0]*t[1]-t[1]*t[0],t[1]*t[2]-t[2]*t[1],t[2]*t[0]-t[0]*t[2]]
realcols=[s.Matrix([s.re(x) for x in C]+[s.im(x) for x in C]) for C in comm]
check('Homogeneous midpoint curvature spans su2',s.Matrix.hstack(*realcols).rank()==3,'three independent curvature directions; pointwise axis does not reduce connection holonomy')

out={'target':'Paper2E-KinematicExports-v3_130.tex','source_lines':[1275,1957],'kind':'E3-INDEPENDENT-EXACT','inputs':'Explicit source-defined trimer shift/projectors, six Spin4 sectors, Cartan charge, and protected grading; no Atlas verdicts or other agents outputs.','checks_count':len(checks),'all_passed':True,'checks':checks}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'all_passed':True,'checks_count':len(checks),'output':str(Path(__file__).with_suffix('.json'))}))
