"""Independent Paper III-A Batch5 E0 integrity checks, never mathematical E3.

Usage: python FILE.py CANDIDATE [--dag-zip FILE] [--audit-zip FILE]
The candidate, baseline, and supplied sources are read only. Only the report
next to this script (or --output) is written. Assertion failures exit nonzero.
"""
from pathlib import Path
import argparse
import collections
import hashlib
import json
import re
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'audit_batch5/atlas_baseline/Paper00-DAGAtlas-v1_98'
PAPERS = ROOT / 'audit_batch5/papers'
OLD_LAYER = BASE / 'DAG/AuditLayer/Paper3A-v1_4'
RELEASE = 'Paper00-DAGAtlas-v1_99'
LAYER = 'Paper3A-v1_5'
BATCH_IDS = {f'BH-IIIA-C-{n:04d}' for n in range(171, 186)}
MATERIAL_KINDS = {
    'PREMISE_OF', 'REQUIRES', 'USES-CONDITION', 'USES_CONDITION',
    'IMPORTED_PROOF', 'CONSTRUCTOR_INPUT', 'NORMALIZATION_CHOICE',
    'ALTERNATIVE_ROUTE', 'BLOCKS_ROUTE', 'CONCLUSION_CLAUSE',
}
EXCLUDED = {
    'CITATION_ONLY', 'CANDIDATE_LINK', 'SCOPE_GUARD', 'DISCHARGES',
    'PROVES', 'EVIDENCE_FOR', 'INTERPRETATION_OF', 'SCOPE_REFERENCE',
    'SCOPE_REFERENT', 'ISSUE_AT', 'SOURCE_ANNOTATION_OF',
}


def read(path):
    return json.loads(Path(path).read_text())


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def number(claim):
    return int(claim['id'].rsplit('-', 1)[1])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('candidate', type=Path)
    parser.add_argument('--dag-zip', type=Path)
    parser.add_argument('--audit-zip', type=Path)
    parser.add_argument('--output', type=Path, default=Path(__file__).with_suffix('.json'))
    args = parser.parse_args()
    root = args.candidate.resolve()
    checks, issues = {}, []

    def ck(name, value, detail=None):
        checks[name] = bool(value)
        if not value:
            issues.append({'check': name, 'details': detail})

    def paths(name, values):
        bad = [x for x in values if not isinstance(x, str) or not (root / x).exists()]
        ck(name, not bad, bad)

    try:
        old = read(BASE / 'DAG/Paper00-TheoremDAG.json')
        core = read(root / 'DAG/Paper00-TheoremDAG.json')
        ck('core_keys_preserved', set(old).issubset(core))
        ck('all_core_values_outside_graph_layers_identical',
           {k: v for k, v in old.items() if k != 'graph_layers'} ==
           {k: v for k, v in core.items() if k != 'graph_layers'})
        qrel = 'DAG/Paper00-InheritedNonmaterialEdges-v1_1.json'
        quarantine = read(BASE / qrel)
        ck('inherited_nonmaterial_provenance_240rows_byte_identical',
           len(quarantine.get('rows', [])) == quarantine.get('count') == 240
           and (BASE / qrel).read_bytes() == (root / qrel).read_bytes())
        ck('canonical_schema_byte_identical',
           (BASE / 'DAG/Paper00-TheoremDAG.schema.json').read_bytes() ==
           (root / 'DAG/Paper00-TheoremDAG.schema.json').read_bytes())
        try:
            import jsonschema
            jsonschema.validate(core, read(root / 'DAG/Paper00-TheoremDAG.schema.json'))
            ck('core_schema_valid', True)
        except Exception as exc:
            ck('core_schema_valid', False, str(exc))

        active = read(root / 'DAG/ActiveRelease-v1_99.json')
        gl = core['graph_layers']
        ck('active_release_identity', active.get('release') == RELEASE)
        ck('paired_audit_zip_identity', active.get('paired_audit_archive') == 'Paper00-ProofChainAudits-v1_17.zip')
        current = [active[k] for k in ['current_sources', 'source_manifest', 'source_anchor_map',
                   'canonical_graph', 'composite_index', 'current_single_paper_audit']]
        paths('active_current_paths_exist', current + active['registered_audit_layers'])
        paths('core_current_paths_exist', [gl[k] for k in [
            'current_source_manifest', 'current_source_anchor_map',
            'current_composite_audit_index', 'current_single_paper_audit',
            'audit_route_query', 'current_combined_graph']])
        ck('active_and_core_registered_layers_agree',
           active['registered_audit_layers'] == gl['registered_audit_layers'])
        ck('active_canonical_graph_hash', active.get('canonical_graph_sha256') == digest(root / active['canonical_graph']))
        comp = read(root / active['composite_index'])
        ck('composite_release_identity', comp.get('atlas_release') == RELEASE)
        ck('composite_current_pointers_agree',
           comp.get('current_audit_index') == active['current_single_paper_audit'] == gl['current_single_paper_audit']
           and comp.get('combined_graph') == gl['current_combined_graph'])
        ck('composite_canonical_hash', comp.get('canonical_graph_sha256') == digest(root / active['canonical_graph']))
        ck('framework_not_declared_globally_verified', comp.get('full_framework_verified') is False)
        ck('single_current_IIIA_directory',
           sorted(x.name for x in (root / 'DAG/AuditLayer').glob('Paper3A-*') if x.is_dir()) == [LAYER])
        current_iiia = [x for x in active['registered_audit_layers'] if '/Paper3A-' in x]
        ck('single_registered_current_IIIA_layer', current_iiia == [f'DAG/AuditLayer/{LAYER}/Index.json'])

        supplied = [x for x in PAPERS.iterdir() if x.suffix in ['.tex', '.bib']]
        copied = list((root / active['current_sources']).glob('*.tex')) + list((root / active['current_sources']).glob('*.bib'))
        ck('source_count_exactly32', len(supplied) == len(copied) == 32)
        bad = [x.name for x in supplied if not (root / active['current_sources'] / x.name).exists()
               or x.read_bytes() != (root / active['current_sources'] / x.name).read_bytes()]
        ck('all32_sources_byte_identical', not bad, bad)
        manifest = read(root / active['source_manifest'])
        stale = [v['file'] for v in manifest.get('roots', {}).values()
                 if digest(PAPERS / v['file']) != v['sha256']]
        ck('source_manifest_root_hashes_match', not stale, stale)

        layer = (root / active['current_single_paper_audit']).parent
        index = read(layer / 'Index.json')
        ck('layer_version_and_release', layer.name == LAYER and index.get('release') == RELEASE)
        paths('all_registered_sidecars_exist', index.get('sidecars', {}).values())
        claims = read(layer / 'AuditClaimLedger.json')['items']
        previous = read(OLD_LAYER / 'AuditClaimLedger.json')['items']
        previous_map = {c['id']: c for c in previous}
        cmap = {c['id']: c for c in claims}
        batch = [c for c in claims if c['id'] in BATCH_IDS]
        cumulative = [c for c in claims if number(c) <= 185]
        remaining = [c for c in claims if number(c) > 185]
        ck('whole_census185_unique', len(claims) == len(cmap) == 185 and set(cmap) == set(previous_map))
        ck('batch15_unique5_formal10_unnamed',
           len(batch) == 15 and sum(c.get('formal', False) for c in batch) == 5)
        ck('cumulative185_objects152_formal',
           len(cumulative) == 185 and sum(c.get('formal', False) for c in cumulative) == 152)
        ck('no_remaining_not_audited', len(remaining) == 0 and all(c['status'] != 'NOT_AUDITED' for c in claims))
        ck('cumulative185_have_dispositions', all(c['status'] != 'NOT_AUDITED' for c in cumulative))
        ck('prior170_statuses_and_lifecycles_preserved', all(
            c['status'] == previous_map[c['id']]['status'] and c.get('lifecycle') == previous_map[c['id']].get('lifecycle')
            for c in claims if number(c) <= 170))
        immutable = ['id', 'kind', 'formal', 'source_as_printed', 'line_start', 'statement_line_end', 'line_end', 'proof', 'source_file']
        ck('all185_frozen_source_objects_preserved', all(
            all(c.get(k) == previous_map[c['id']].get(k) for k in immutable) for c in claims))
        lines = (PAPERS / 'Paper3A-GeneratedDynamics-v1_169.tex').read_text().splitlines(keepends=True)
        bad = []
        for c in batch:
            if c['source_as_printed'] != ''.join(lines[c['line_start'] - 1:c['statement_line_end']]):
                bad.append((c['id'], 'statement'))
            if c.get('proof'):
                p = c['proof']
                if p['exact_text'] != ''.join(lines[p['line_start'] - 1:p['line_end']]):
                    bad.append((c['id'], 'proof'))
        ck('all15_statements_and_proofs_match_actual_source', not bad, bad)
        ck('batch_primary_source_labels_match_printed_source', all(
            c.get('source_label') is None or ('\\label{' + c['source_label'] + '}') in c['source_as_printed']
            for c in batch))
        cov = read(layer / 'CoverageAndValidation.json')
        ck('coverage_exact_cumulative_denominators',
           cov.get('substantive_claims_checked') == 185 and cov.get('substantive_claims_total') == 185
           and cov.get('formal_declarations_checked') == 152 and cov.get('formal_declarations_total') == 152)
        ck('coverage_full_with_open_gaps', (cov.get('classification') == 'FULLY_AUDITED_WITH_OPEN_GAPS' or (cov.get('classification') == 'FULLY_AUDITED' and cov.get('completion_state') == 'FULLY_AUDITED_WITH_OPEN_GAPS')) and index.get('full_target_audit') is True)
        current_census = read(layer / 'SourceCensus.json')
        census_claims = current_census.get('claims', [])
        ck('current_source_census_completion_marker',
           current_census.get('audit_classification') == 'FULLY_AUDITED_WITH_OPEN_GAPS'
           and current_census.get('status') != 'EXTRACTED_NOT_MATHEMATICALLY_AUDITED')
        ck('current_source_census185_matches_authoritative_dispositions',
           len(census_claims) == 185 and all(
               c['id'] in cmap and c.get('status') == cmap[c['id']].get('status')
               and c.get('lifecycle') == cmap[c['id']].get('lifecycle')
               for c in census_claims))
        ck('coverage_reaches_end_of_target', any(a <= 5308 and b >= 5730 for a,b in cov.get('source_lines_checked', [])) and cov.get('target_lines') == 5730)

        evidence = read(layer / 'ProofEvidenceLedger.json')['items']
        emap = {x['id']: x for x in evidence}
        ck('evidence_ids_unique', len(evidence) == len(emap))
        badrefs, gates = [], []
        for c in batch:
            refs = c.get('evidence_ids', [])
            badrefs += [(c['id'], x) for x in refs if x not in emap]
            if c['status'] in ['VERIFIED', 'VERIFIED-CONDITIONAL']:
                levels = [str(emap.get(x, {}).get('evidence_level', emap.get(x, {}).get('level', ''))) for x in refs]
                if not all(any(v.startswith(required) for v in levels) for required in ['E1', 'E3', 'E4']):
                    gates.append((c['id'], levels))
        ck('batch_evidence_references_resolve', not badrefs, badrefs)
        ck('verified_batch_claims_have_E1_E3_E4_records', not gates, gates)
        for filename in ['ProofEvidenceLedger.json', 'BoundaryRegistry.json']:
            baseline_ids = {x['id'] for x in read(OLD_LAYER / filename)['items']}
            added_ids = [x['id'] for x in read(layer / filename)['items'] if x['id'] not in baseline_ids]
            historical_relocations = {f'BH-IIIA-B2-E4-BND-{n:04d}' for n in range(1, 8)} if filename == 'BoundaryRegistry.json' else set()
            ck(filename + '_new_ids_only_IIIA_B5_or_certified_historical_relocation', all(
                (x.startswith('BH-IIIA-') and '-B5-' in x) or x in historical_relocations for x in added_ids), added_ids)
        boundary_rows = read(layer / 'BoundaryRegistry.json')['items']
        boundary_map = {x['id']: x for x in boundary_rows}
        ck('current_boundary116_ids_unique', len(boundary_rows) == len(boundary_map) == 116)
        old_boundary_rows = read(OLD_LAYER / 'BoundaryRegistry.json')['items']
        old_collisions = collections.defaultdict(list)
        for row in old_boundary_rows:
            old_collisions[row['id']].append(row)
        relocation_checks = []
        for n in range(1, 8):
            oid = f'BH-IIIA-B2-BND-{n:04d}'
            nid = f'BH-IIIA-B2-E4-BND-{n:04d}'
            original_views = old_collisions.get(oid, [])
            registrar = next((x for x in original_views if 'source_origin' in x), {})
            attack = next((x for x in original_views if 'source_clauses' in x), {})
            relocation_checks.append(bool(registrar and attack)
                and all(boundary_map.get(oid, {}).get(k) == v for k, v in registrar.items())
                and all(boundary_map.get(nid, {}).get(k) == v for k, v in attack.items() if k != 'id'))
        ck('all7_inherited_boundary_identity_relocations_lossless_and_role_matched', all(relocation_checks))
        raw_b2 = BASE / 'Evidence/Paper3A-Batch2-v1_1'
        ck('all_original_Batch2_raw_evidence_bytes_preserved', all(
            (root / p.relative_to(BASE)).is_file()
            and (root / p.relative_to(BASE)).read_bytes() == p.read_bytes()
            for p in raw_b2.rglob('*') if p.is_file()))
        old_emap = {x['id']: x for x in read(OLD_LAYER / 'ProofEvidenceLedger.json')['items']}
        argument_fields = ['steps', 'independent_argument', 'domain_and_failure_check',
                           'exact_negation_attack', 'source_as_printed', 'claim_id', 'claim_ids']
        ck('all_prior_mathematical_evidence_arguments_preserved', all(
            eid in emap and all(old_rec.get(k) == emap[eid].get(k) for k in argument_fields)
            for eid, old_rec in old_emap.items()))
        gaps = read(layer / 'GapRegistry.json')['items']
        gmap = {x['id']: x for x in gaps}
        ck('all10_issue_ids_unique_7open_3resolved',
           len(gaps) == len(gmap) == 10
           and collections.Counter(x['lifecycle'] for x in gaps) == {'OPEN': 7, 'RESOLVED': 3})
        ck('all7_prior_issue_statuses_preserved', all(
            gid in gmap and old_rec.get('lifecycle') == gmap[gid].get('lifecycle')
            and old_rec.get('issue_status') == gmap[gid].get('issue_status')
            for gid, old_rec in {x['id']: x for x in read(OLD_LAYER / 'GapRegistry.json')['items']}.items()))
        ck('boundary_identity_issue0010_resolved', gmap.get('BH-IIIA-G-0010', {}).get('lifecycle') == 'RESOLVED')
        providers = collections.defaultdict(list)
        for tex in PAPERS.glob('*.tex'):
            if tex.name.startswith('Macros-'):
                continue
            for lineno, line in enumerate(tex.read_text().splitlines(), 1):
                if not line.lstrip().startswith('%'):
                    for label in re.findall(r'\\label\{([^}]+)\}', line):
                        providers[label].append((tex.name, lineno))
        final_source = ''.join(lines[5307:])
        final_labels = set(re.findall(r'\\(?:ref|eqref|autoref|cref)\{([^}]+)\}', final_source))
        ck('all_remaining_source_references_have_one_current_provider',
           all(len(providers[x]) == 1 for x in final_labels),
           {x: providers[x] for x in final_labels if len(providers[x]) != 1})
        ck('E0_not_relabelled_E3', all(not (
            str(x.get('evidence_level', '')).startswith('E3')
            and any(z in str(x.get('source', '')).lower() for z in ['releasecheck', 'integrityreview']))
            for x in evidence))

        graph = read(root / 'DAG/CombinedGraphIndex-v1_99.json')
        mats = read(root / 'DAG/CombinedMaterialEdges-v1_99.json')['items']
        ck('batch_aliases_resolve_to_exact_canonical_ids', all(
            graph.get('aliases', {}).get(c['id']) == c.get('canonical_id', c['id'])
            and c.get('canonical_id', c['id']) in graph['nodes'] for c in batch))
        typed = read(layer / 'TypedDependencyEdges.json')['items']
        old_edge_ids = {e['id'] for e in read(OLD_LAYER / 'TypedDependencyEdges.json')['items']}
        new_edges = [e for e in typed if e['id'] not in old_edge_ids]
        ck('new_edge_ids_unique', len(typed) == len({e['id'] for e in typed}))
        ck('all_new_edge_endpoints_registered', all(e['from'] in graph['nodes'] and e['to'] in graph['nodes'] for e in new_edges))
        mid = [e['id'] for e in mats if 'id' in e]
        ck('material_edge_ids_unique', len(mid) == len(set(mid)))
        baseline_material_ids = {e['id'] for e in read(BASE / 'DAG/CombinedMaterialEdges-v1_98.json')['items']}
        added_material_ids = set(mid) - baseline_material_ids
        ck('only_new_reviewed_IIIA_B5_rows_added_to_material_index',
           added_material_ids <= {e['id'] for e in new_edges},
           sorted(added_material_ids - {e['id'] for e in new_edges}))

        new_material = [e for e in mats if e.get('id') in {x['id'] for x in new_edges}]
        ck('new_material_edge_kinds_proof_or_scoped_source_clause', all(e.get('kind') in MATERIAL_KINDS and e.get('kind') not in EXCLUDED
           and not any(w in e.get('kind', '') for w in ['SCOPE', 'CITATION', 'CANDIDATE']) for e in new_material))
        ck('new_material_endpoints_registered', all(e['from'] in graph['nodes'] and e['to'] in graph['nodes'] for e in new_material))
        ck('new_material_have_route_and_guard', all(e.get('proof_route_id') and e.get('scope_guard') for e in new_material))
        ck('new_material_have_reviewed_source_use', all(e.get('reviewed') is True and e.get('source_use_locator')
           and e.get('evidence_id') in emap for e in new_edges if e.get('kind') in MATERIAL_KINDS))
        mixed = [e.get('id') for e in mats if e.get('kind') in EXCLUDED
                 or any(w in e.get('kind', '') for w in ['SCOPE', 'CITATION', 'CANDIDATE'])]
        ck('combined_proof_index_excludes_declared_nonpromoting_kinds', not mixed, mixed[:20])
        ck('none_of240_quarantined_rows_repromoted', not ({e['id'] for e in quarantine['rows']} & set(mid)))
        forward, backward, indegree = collections.defaultdict(set), collections.defaultdict(set), collections.Counter()
        for e in mats:
            backward[e['to']].add(e['from'])
            if e['to'] not in forward[e['from']]:
                forward[e['from']].add(e['to'])
                indegree[e['to']] += 1
            indegree[e['from']] += 0
        queue = collections.deque(n for n in indegree if not indegree[n])
        seen = 0
        while queue:
            n = queue.popleft()
            seen += 1
            for v in forward[n]:
                indegree[v] -= 1
                if not indegree[v]:
                    queue.append(v)
        ck('combined_material_acyclic', seen == len(indegree), [n for n, d in indegree.items() if d][:12])
        ck('combined_forward_index_exact',
           {k: set(v) for k, v in graph.get('forward', {}).items() if v} == {k: v for k, v in forward.items() if v})
        ck('combined_backward_index_exact',
           {k: set(v) for k, v in graph.get('backward', {}).items() if v} == dict(backward))

        def reachable(start, adjacency):
            found, todo = set(), list(adjacency.get(start, []))
            while todo:
                node = todo.pop()
                if node not in found:
                    found.add(node)
                    todo.extend(adjacency.get(node, []))
            return found

        queried = {c.get('canonical_id', c['id']) for c in batch}
        ck('batch_transitive_prerequisite_index_exact', all(
            set(graph.get('prerequisites', {}).get(n, [])) == reachable(n, backward) for n in queried))
        ck('batch_transitive_descendant_index_exact', all(
            set(graph.get('descendants', {}).get(n, [])) == reachable(n, forward) for n in queried))

        ass = read(root / 'DAG/AssumptionRegistry.json')
        paths('current_condition_registry_paths_exist', ass.get('current_audit_condition_uses', {}).values())
        refs = ass.get('new_canonical_layer_references', [])
        ck('canonical_global_reference_ids_unique', len(refs) == len({x['id'] for x in refs}))
        local = read(layer / 'AssumptionRegistry.json')
        cond = local['items']
        ck('canonical_IIIA_condition_ids_unique', len(cond) == len({x['id'] for x in cond}))
        old_cond = {x['id']: x for x in read(OLD_LAYER / 'AssumptionRegistry.json')['items']}
        cond_map = {x['id']: x for x in cond}
        premise_fields = ['id', 'statement', 'normalized_statement', 'category',
                          'first_occurrence', 'epistemic_status', 'lifecycle']
        ck('all_prior_canonical_condition_meanings_and_origins_preserved', all(
            cid in cond_map and all(old_rec.get(k) == cond_map[cid].get(k) for k in premise_fields)
            for cid, old_rec in old_cond.items()))

        ck('all_local_condition_nodes_registered', all(x['id'] in graph['nodes'] for x in cond))
        routes = read(layer / 'ProofRoutes.json')['items']
        ck('route_ids_unique', len(routes) == len({x['id'] for x in routes}))
        old_route_ids = {x['id'] for x in read(OLD_LAYER / 'ProofRoutes.json')['items']}
        newroutes = [x for x in routes if x['id'] not in old_route_ids]
        ck('new_route_targets_and_inputs_registered', all(
            x.get('target') in graph['nodes'] and all(y in graph['nodes'] for y in x.get('AND_inputs', [])) for x in newroutes))
        ck('new_route_edge_references_resolve', all(all(y in {e['id'] for e in typed} for y in x.get('edge_ids', [])) for x in newroutes))
        route_map = {x['id']: x for x in routes}
        cc = [e for e in new_material if e.get('kind') == 'CONCLUSION_CLAUSE']
        ck('conclusion_clause_edges_are_only_scoped_membership', all(
            e.get('logic_group') == 'SCOPED_SOURCE_CLAUSE'
            and e['from'] == e['to'] + ':' + e.get('branch_id', '')
            and e['to'] in {x.get('canonical_id', x['id']) for x in batch}
            and route_map.get(e.get('proof_route_id'), {}).get('scoped_source_clauses') is True
            and not route_map.get(e.get('proof_route_id'), {}).get('AND_inputs')
            for e in cc))

        # Only newly allocated Paper III-A audit-function IDs use Batch5 namespace.
        # Canonical claim/condition IDs retain their established global registries.
        for fn, prefix in [('TypedDependencyEdges.json','BH-IIIA-EDGE-B5-'),
                           ('ProofRoutes.json','BH-IIIA-ROUTE-B5-')]:
            prev_ids = {x['id'] for x in read(OLD_LAYER / fn)['items']}
            cur_items = read(layer / fn)['items']
            added = [x['id'] for x in cur_items if x['id'] not in prev_ids]
            ck(fn + '_new_ids_in_B5_namespace', all(x.startswith(prefix) or x.startswith('BH-IIIA-B5-') for x in added), added)
        ck('baseline_material_records_preserved',
           all(json.loads(json.dumps(x).replace('Paper3A-v1_4/', 'Paper3A-v1_5/')) in mats
               for x in read(BASE / 'DAG/CombinedMaterialEdges-v1_98.json')['items']))
        ck('all_batch_source_locators_resolve_current_bytes', all(
            c.get('source_file') == 'Paper3A-GeneratedDynamics-v1_169.tex'
            and c.get('source', {}).get('sha256') == digest(PAPERS / c['source_file'])
            for c in batch))
        parse = []
        for path in root.rglob('*.json'):
            try:
                read(path)
            except Exception as exc:
                parse.append((str(path.relative_to(root)), str(exc)))
        ck('all_json_parse', not parse, parse[:10])

        for name, archive in [('dag', args.dag_zip), ('audit', args.audit_zip)]:
            if archive is None:
                continue
            with zipfile.ZipFile(archive) as z:
                names = z.namelist()
                ck(name + '_zip_crc', z.testzip() is None)
                ck(name + '_zip_unique_entries', len(names) == len(set(names)))
                if name == 'dag':
                    ck('dag_zip_exact_release_filename', archive.name == RELEASE + '.zip')
                    ck('dag_zip_single_current_root', {n.split('/')[0] for n in names} == {RELEASE})
                    ck('dag_zip_only_current_IIIA_layer', not any(
                        '/DAG/AuditLayer/Paper3A-' in n and f'/DAG/AuditLayer/{LAYER}/' not in n for n in names))
                    ck('dag_zip_no_nested_archive_pdf_or_pyc', not any(Path(n).suffix.lower() in ['.zip', '.pdf', '.pyc'] for n in names))
                    mismatches = []
                    for n in names:
                        if n.endswith('/'):
                            continue
                        rel = Path(*Path(n).parts[1:])
                        p = root / rel
                        if not p.is_file() or z.read(n) != p.read_bytes():
                            mismatches.append(str(rel))
                    disk = {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
                    packed = {'/'.join(Path(n).parts[1:]) for n in names if not n.endswith('/')}
                    ck('dag_zip_exact_candidate_file_set', disk == packed, {'missing': sorted(disk-packed), 'extra': sorted(packed-disk)})
                    ck('dag_zip_all_bytes_match_candidate', not mismatches, mismatches[:12])
                else:
                    ck('audit_zip_exact_filename', archive.name == 'Paper00-ProofChainAudits-v1_17.zip')
                    prior = [x for x in (ROOT / 'audit_batch5/audits_baseline').glob('*.md') if not x.name.startswith('Paper3A-')]
                    ck('audit_zip_exactly7_latest_reports', set(names) == {x.name for x in prior} | {'Paper3A-ProofChainAudit-v1_5.md'}, names)
                    for f in prior:
                        ck('prior_report_byte_identical_' + f.name, f.name in names and z.read(f.name) == f.read_bytes())
    except Exception as exc:
        ck('validator_completed_without_exception', False, repr(exc))

    result = {
        'reviewer': '/root/b5_release_review', 'evidence_level': 'E0', 'E0_not_E3': True,
        'candidate': str(root), 'checks': checks, 'issues': issues,
        'result': 'PASS' if checks and all(checks.values()) else 'FAIL',
        'scope': 'Independent release integrity only; substantive source proofs, condition identities and clause-level dependencies require the separate semantic review.',
        'archive_checks_performed': {'dag': args.dag_zip is not None, 'audit': args.audit_zip is not None},
    }
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    return 0 if result['result'] == 'PASS' else 1


if __name__ == '__main__':
    sys.exit(main())
