"""Independent executable source-clause query tests for Paper III-A Batch5.

These checks test source-matched scope expectations recorded independently by
the release reviewer. They are query/semantic review support, not E3 proofs.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('candidate', type=Path)
    a = p.parse_args()
    root = a.candidate.resolve()
    layer = root / 'DAG/AuditLayer/Paper3A-v1_5'
    claims = json.loads((layer / 'AuditClaimLedger.json').read_text())['items']
    cmap = {int(c['id'].rsplit('-', 1)[1]): c for c in claims}
    cli = root / 'Paper00-DAGQuery-v1_99.py'
    checks, results, raw = {}, [], []
    cases = []

    def cond(*nums):
        return {f'BH-IIIA-A-{n:04d}' for n in nums}

    def case(n, branch, required=(), forbidden=(), discharged=(), forbidden_open=(), reason=''):
        node = cmap[n].get('canonical_id', cmap[n]['id']) + ':' + branch
        cases.append((node, cond(*required), cond(*forbidden), cond(*discharged), cond(*forbidden_open), reason))

    case(171, 'LICENSED_LOCAL_WORD', [83, 113], [94, 116, 117], reason='Local licensed sum does not require a global atlas cocycle or response-jet regularity.')
    case(171, 'GLOBAL_SCOPE', [94, 116], reason='Global comparison retains actual transitions and period/cocycle qualifications.')
    case(172, 'FULL_HESSIAN', [113, 114, 115], [119, 120, 125], reason='Complete nonlinear pullback keeps admitted interaction regularity and the contact term, independently of Schur compatibility or Newton normalization.')
    case(172, 'ODD_COEFFICIENT_PULLBACK', [93], reason='Odd transitions are re-expanded before ordinary coefficient differentiation.')
    case(172, 'CONTACT_TERM_SCOPE', [114], reason='Total stationarity does not imply all individual Euler covectors vanish.')
    case(173, 'ANCHORED_PRIMITIVE', [90, 91, 93], [92, 115], forbidden_open=[87, 88, 89], reason='Mathematical coefficient primitive uses symmetric integrable fields and anchors, independently of physical origin or an interaction term.')
    case(173, 'FORWARD_INTEGRABILITY', [114, 115], reason='Commuting ordinary third derivatives consumes complete coefficient regularity.')
    case(173, 'PHYSICAL_ORIGIN_BOUNDARY', [92], reason='Constitutional use retains independent complete pre-action provenance.')
    case(174, 'TRANSITION_TWO_JET', [116], reason='Actual gradient/contact term and complete odd transition stay in the two-jet pullback.')
    case(174, 'TRIPLE_ASSOCIATIVITY', [116], reason='Complete two-jet cocycle is conditioned on actual transition composition.')
    case(175, 'REAL_VARIANCE', [84], [118, 85, 86, 108, 119], reason='Real pointwise Schur identity uses the actual positive shared interior, without terminal PSD, endpoint compatibility or complex type.')
    case(175, 'COMPLEX_VARIANCE', [118], [84, 85, 86, 108, 119], reason='Complex Hermitian direct algebra is distinct from the cited real-only theorem and endpoint limits.')
    case(176, 'ZERO_AND_FIRST_JET', [117, 119], [120, 85, 86, 108], reason='Common regular centres force value and first-jet defects to vanish without derivative matching or terminal positivity.')
    case(176, 'SECOND_JET_FORMULA', [117, 119], [120, 85, 86, 108], reason='The exact next-jet formula does not assume the zero criterion it computes.')
    case(176, 'SECOND_JET_IFF', [117, 119], [120, 85, 86, 108], reason='The iff criterion characterizes derivative equality, rather than assuming it.')
    case(176, 'FINITE_HS_IFF', [117, 119], [120], reason='Finite scalar zero test retains positive pivots and all finite directions, without assuming its zero conclusion.')
    case(176, 'MATCHED_DERIVATIVE_SUFFICIENCY', [117, 119, 120], reason='The positive zero-defect consequence additionally uses derivative matching.')
    case(178, 'FRAME_TRANSFORM', [119, 121], [120], reason='Moving-frame derivatives disappear at zero value defect; no derivative match is required.')
    case(178, 'CRITERION_COVARIANCE', [119, 121], [120], reason='Only the weighted criterion and retained conjugacy are frame invariant at compatibility.')
    case(179, 'LEADING_ASYMPTOTIC', [122, 123], [120], reason='Lower-jet vanishing and sufficient regularity govern the leading variance order.')
    case(179, 'ORDER_2R_DERIVATIVE', [122, 123], [120], reason='Ordinary 2r-th derivative retains its own sufficient smoothness; no finite first nonzero order is forced.')
    case(180, 'REGULAR_SCOPE', forbidden=[125, 126], reason='Regular finite-pivot scope makes no terminal scalaron or Newton normalization claim.')
    case(181, 'EXACT_EXAMPLE', forbidden=[83, 124, 125, 126, 128], forbidden_open=[84, 117, 119], reason='The exact scalar host example needs no physical occurrence or action-selection certificate.')
    case(182, 'RAW_COORDINATES', forbidden=[124, 125, 126], reason='The raw factor96 dictionary is independent of the actual final-action branch.')
    case(182, 'RAW_PHYSICAL_BRANCH', [124], [125, 126], reason='Actual raw action branch does not require a uniform normalized projection.')
    case(182, 'UNIFORM_PROJECTED_COORDINATES', [125], [124, 126], reason='Whole-action transport gives projected coordinates without already imposing scalar equality.')
    case(182, 'SCALAR_COORDINATE_EQUALITY_IFF', [125], [124, 126], reason='The numerical iff test does not assume z=1/96.')
    case(182, 'SCALAR_COORDINATE_MATCH', [125, 126], [124], reason='Actual scalar-coordinate equality requires the certified whole-action map and its normalization value.')
    case(183, 'NONIDENTIFICATION', forbidden=[127, 128], reason='Packet/momentum distinction does not require a selected two-core action term.')
    case(184, 'CORE_CANCELLATION', forbidden=[127, 128], reason='The full-packet zero sum holds before a two-core marking or physical action is supplied.')
    case(184, 'LINEAR_FUNCTIONAL_CANCELLATION', forbidden=[127, 128], reason='Linearity cancellation ranges over every real functional on the actual Hom space.')
    case(184, 'COMPLEMENT_PARITY', [127], [128], reason='Marked two-core complement parity is a mathematical branch and creates no action coefficient.')
    case(184, 'NO_ACTION_OCCURRENCE_PROMOTION', forbidden=[128], reason='No native action occurrence follows from mathematical parity.')
    case(185, 'NO_CONTINUOUS_NOETHER_PROMOTION', forbidden=[84, 118, 128], reason='Finite action firewall does not assume a positive-pivot action word or actual Petersen operator incidence.')
    case(185, 'ACTUAL_OPERATOR_COCONSUMPTION', [41, 128], [84, 85, 86, 118], reason='Generic complete-jet retention uses existing claim-complete owner closure, not a blanket positive Schur theorem.')

    def walk(value):
        if isinstance(value, dict):
            yield value
            for v in value.values():
                yield from walk(v)
        elif isinstance(value, list):
            for v in value:
                yield from walk(v)

    def run(command, node=None):
        argv = [sys.executable, str(cli), command] + ([] if node is None else [node])
        proc = subprocess.run(argv, text=True, capture_output=True)
        try:
            output = json.loads(proc.stdout)
        except Exception:
            output = {'invalid_output': proc.stdout, 'stderr': proc.stderr}
        raw.append({'argv': argv, 'exit_code': proc.returncode, 'output': output})
        return proc, output

    for node, required, forbidden, discharged, forbidden_open, reason in cases:
        proc, output = run('conditions', node)
        nodes = list(walk(output))
        occurrences = []
        for v in nodes:
            if isinstance(v.get('canonical_condition'), dict):
                occurrences.append((v['canonical_condition']['id'], v.get('propagates_as_open_assumption', True)))
            elif v.get('condition') and isinstance(v.get('canonical_record'), dict):
                # branch_local_uses is descriptive metadata; only an explicit flag
                # there asserts propagation. Canonical proof nodes above default open.
                occurrences.append((v['condition'], v.get('propagates_as_open_assumption') is True))
        found = {c for c, _ in occurrences}
        open_conditions = {c for c, active in occurrences if active}
        references = {v['already_expanded_reference'] for v in nodes if 'already_expanded_reference' in v}
        keys = {v['query_node_key'] for v in nodes if 'query_node_key' in v}
        scope_checks = {
            'CLI_exit_zero': proc.returncode == 0,
            'exact_query_identity': output.get('query') == node,
            'required_conditions_visible': required <= found,
            'forbidden_conditions_absent': not (forbidden & found),
            'route_local_discharges_not_open': discharged <= found and not (discharged & open_conditions),
            'forbidden_open_conditions_absent': not (forbidden_open & open_conditions),
            'no_cycle_references': not any(v.get('cycle_reference') for v in nodes),
            'shared_subtree_references_resolve': references <= keys,
            'no_global_reverification_claim': output.get('global_framework_reverified') is False,
        }
        checks[node] = all(scope_checks.values())
        results.append({'node': node, 'source_matched_expectation': reason, 'checks': scope_checks,
                        'required': sorted(required), 'forbidden': sorted(forbidden), 'discharged': sorted(discharged), 'forbidden_open': sorted(forbidden_open),
                        'actual_conditions': sorted(found), 'actual_open_conditions': sorted(open_conditions),
                        'stdout_sha256': hashlib.sha256(proc.stdout.encode()).hexdigest(),
                        'root_routes': [x.get('route_id') for x in output.get('ancestry', {}).get('source_proof_routes', [])]})

    # Query every whole source object as well as the decisive clause branches.
    # The parent membership route is structural aggregation, not one giant AND proof.
    whole_results = []
    layer_routes = json.loads((layer / 'ProofRoutes.json').read_text())['items']
    for n in range(171, 186):
        claim = cmap[n]
        canonical = claim.get('canonical_id', claim['id'])
        proc, output = run('conditions', claim['id'])
        expected = {b['branch_id'] for r in layer_routes if r.get('target') == canonical
                    and r.get('scoped_source_clauses') for b in r.get('conclusion_branches', [])}
        top_routes = output.get('ancestry', {}).get('source_proof_routes', [])
        actual = {b['branch_id'] for r in top_routes for b in r.get('source_conclusion_clauses', [])}
        nodes = list(walk(output))
        references = {v['already_expanded_reference'] for v in nodes if 'already_expanded_reference' in v}
        keys = {v['query_node_key'] for v in nodes if 'query_node_key' in v}
        wc = {'CLI_exit_zero': proc.returncode == 0,
              'whole_claim_exact_source_clause_set': actual == expected and bool(expected),
              'whole_claim_no_flat_AND_aggregation': all('AND_input_proofs' not in r for r in top_routes),
              'shared_references_resolve': references <= keys,
              'no_cycles': not any(v.get('cycle_reference') for v in nodes),
              'not_global_reverification': output.get('global_framework_reverified') is False}
        if n == 176:
            target = canonical + ':SECOND_JET_FORMULA'
            children = [v for v in nodes if v.get('id') == target and 'source_proof_routes' in v]
            variants = children[0]['source_proof_routes'] if children else []
            inp = [{v.get('id') for v in r.get('AND_input_proofs', [])} for r in variants]
            real, complex_ = 'BH-IIIA-C-0175:REAL_VARIANCE', 'BH-IIIA-C-0175:COMPLEX_VARIANCE'
            wc['same_formula_two_carrier_OR_routes'] = len(variants) == 2 and {real, complex_} <= set().union(*inp)
            wc['neither_carrier_variant_is_AND_of_both_types'] = all(not ({real, complex_} <= x) for x in inp)
            wc['each_variant_keeps_its_common_regular_compatible_domain'] = all({'BH-IIIA-A-0117', 'BH-IIIA-A-0119'} <= x for x in inp)
        if n == 174:
            wc['ambiguous_printed_property_remains_unresolved'] = output.get('ancestry', {}).get('source_record', {}).get('latest_source_matched_audit', {}).get('status', output.get('ancestry', {}).get('source_record', {}).get('status')) == 'UNRESOLVED' and any(v.get('id') == canonical + ':OMITTED_CONTACT_COHERENCE_AS_PRINTED' and v.get('source_record', {}).get('status') == 'UNRESOLVED' for v in nodes)
        if n == 185:
            wc['unsupported_cited_route_not_a_parent_proof_alternative'] = not any('CITED_POSITIVE_QUADRATIC' in str(v.get('route_id', '')) for v in nodes)
        checks['whole:' + claim['id']] = all(wc.values())
        whole_results.append({'claim': claim['id'], 'canonical': canonical, 'checks': wc, 'clause_branches': sorted(actual),
                              'stdout_sha256': hashlib.sha256(proc.stdout.encode()).hexdigest()})

    for command, node in [('summary', None), ('issues', None), ('impact', 'BH-IIIA-G-0008'),
                          ('impact', 'BH-IIIA-G-0009'), ('impact', 'BH-IIIA-G-0010'), ('descendants', 'BH-IIIA-A-0125')]:
        proc, output = run(command, node)
        checks[command + ':' + str(node)] = proc.returncode == 0 and 'invalid_output' not in output
        if command == 'summary':
            checks['summary:full185_152_no_unexamined_scope'] = output.get('substantive_claims_checked') == output.get('substantive_claims_total') == 185 and output.get('formal_declarations_checked') == output.get('formal_declarations_total') == 152 and output.get('completion_state') == 'FULLY_AUDITED_WITH_OPEN_GAPS' and output.get('remaining_not_audited') == 0
        if command == 'issues':
            current_issues = output.get('current_paper', {}).get('items', [])
            checks['issues:exact10_7open_3resolved'] = {x['id'] for x in current_issues} == {f'BH-IIIA-G-{n:04d}' for n in range(1, 11)} and sum(x['lifecycle'] == 'OPEN' for x in current_issues) == 7 and sum(x['lifecycle'] == 'RESOLVED' for x in current_issues) == 3


    dest = Path(__file__).with_suffix('.json')
    snapshots = dest.with_name('Paper3A-Batch5-QueryOutputs-v1_1.json')
    snapshots.write_text(json.dumps({'query_program': str(cli), 'queries': raw}, indent=2) + '\n')
    result = {'id': 'Paper3A-Batch5-QueryCheck-v1_1', 'reviewer': '/root/b5_release_review',
              'candidate': str(root), 'query_program_sha256': hashlib.sha256(cli.read_bytes()).hexdigest(),
              'result': 'PASS' if all(checks.values()) else 'FAIL', 'executable_queries': len(raw),
              'source_scoped_clause_tests': len(cases), 'whole_claim_tests': len(whole_results), 'checks': checks, 'clause_results': results, 'whole_claim_results': whole_results,
              'raw_output_file': str(snapshots), 'E0_queries_not_E3': True}
    dest.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'result': result['result'], 'executable_queries': len(raw),
                      'source_scoped_clause_tests': len(cases),
                      'failures': [r for r in results + whole_results if not all(r['checks'].values())],
                      'report': str(dest)}, indent=2))
    return 0 if result['result'] == 'PASS' else 1


if __name__ == '__main__':
    sys.exit(main())
