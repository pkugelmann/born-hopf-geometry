from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json, subprocess, hashlib

ROOT = Path('/workspace/scratch/d9e814b50b43')
W = ROOT / 'audit_batch5'
R = W / 'release/Paper00-DAGAtlas-v1_99'
L = R / 'DAG/AuditLayer/Paper3A-v1_5'
Q = R / 'Paper00-DAGQuery-v1_99.py'
O = W / 'query_outputs'
O.mkdir(exist_ok=True)
claims = json.loads((L / 'AuditClaimLedger.json').read_text())['items']
canonical = {int(c['id'].rsplit('-', 1)[1]): c.get('canonical_id', c['id']) for c in claims}
A = lambda n: f'BH-IIIA-A-{n:04d}'
node = lambda n, b: canonical[n] + ':' + b
WORD = 'BH-IIA-A-B9-FROZEN-WORD-001'
FIBRE = 'BH-IIA-A-B17-FIBRE-001'
spec = []

def add(n, b, yes=(), no=(), closed=()):
    norm = lambda s: {A(x) if isinstance(x, int) else x for x in s}
    spec.append((node(n, b), norm(yes), norm(no), norm(closed)))

add(171, 'LICENSED_LOCAL_WORD', [41, 83, 113, WORD], [62, 117, 125])
add(171, 'GLOBAL_SCOPE', [94, 116], [125, 126])
add(172, 'FULL_HESSIAN', [113, 114, 115], [119, 120, 125])
add(172, 'ODD_COEFFICIENT_PULLBACK', [93, 116], [119, 120])
add(172, 'CONTACT_TERM_SCOPE', [114], [119, 120])
add(173, 'ANCHORED_PRIMITIVE', [90, 91, 93, 87, 88, 89], [92, 115], [87, 88, 89])
add(173, 'PHYSICAL_ORIGIN_BOUNDARY', [92], [119, 125])
add(174, 'TRANSITION_TWO_JET', [116], [119, 120, 125])
add(174, 'TRIPLE_ASSOCIATIVITY', [116], [119, 120, 125])
add(174, 'OMITTED_CONTACT_HESSIAN_CONSISTENCY', [114], [119, 120])
add(175, 'REAL_VARIANCE', [84], [83, 85, 86, 108, 117, 118, 119])
add(175, 'COMPLEX_VARIANCE', [118], [83, 84, 85, 86, 108, 117, 119])
for branch in ['ZERO_AND_FIRST_JET', 'SECOND_JET_FORMULA', 'SECOND_JET_IFF', 'FINITE_HS_IFF']:
    add(176, branch, [117, 119], [85, 86, 108, 120])
add(176, 'MATCHED_DERIVATIVE_SUFFICIENCY', [117, 119, 120], [85, 86, 108])
add(178, 'FRAME_TRANSFORM', [117, 118, 119, 121], [84, 120])
add(178, 'CRITERION_COVARIANCE', [117, 118, 119, 121], [120])
add(179, 'LEADING_ASYMPTOTIC', [118, 122, 123], [117, 119, 120, 108])
add(179, 'ORDER_2R_DERIVATIVE', [118, 122, 123], [117, 119, 120, 108])
add(180, 'REGULAR_SCOPE', no=[125, 126])
add(181, 'EXACT_EXAMPLE', [84, 117, 119], [83, WORD, 124, 125, 126, 128], [84, 117, 119])
add(182, 'RAW_COORDINATES', no=[124, 125, 126])
add(182, 'RAW_PHYSICAL_BRANCH', [124], [125, 126])
add(182, 'UNIFORM_PROJECTED_COORDINATES', [125], [124, 126])
add(182, 'SCALAR_COORDINATE_EQUALITY_IFF', [125], [124, 126])
add(182, 'SCALAR_COORDINATE_MATCH', [125, 126], [124])
add(183, 'EMBEDDED_PACKET', ['BH-IIA-A-B31-OCC2I-001'], [127, 128])
add(184, 'CORE_CANCELLATION', ['BH-IIA-A-B52-MARKED2I-MATH-001'], ['BH-IIA-A-B31-OCC2I-001', 127, 128])
add(184, 'LINEAR_FUNCTIONAL_CANCELLATION', ['BH-IIA-A-B52-MARKED2I-MATH-001'], ['BH-IIA-A-B31-OCC2I-001', 127, 128])
add(184, 'COMPLEMENT_PARITY', [127], ['BH-IIA-A-B31-OCC2I-001', 128])
add(185, 'ACTUAL_OPERATOR_COCONSUMPTION', [41, 83, 128, WORD], [84, 85, 86, 108, 118])
add(185, 'CITED_POSITIVE_QUADRATIC_SPECIALIZATION', [84], [128])
add(185, 'NO_CONTINUOUS_NOETHER_PROMOTION', no=[84, 118, 128])
# Previous unresolved interfaces must not contaminate their valid bypasses.
add(99, 'RANK_FOUR_ISOMORPHISM', no=[63, 103])
add(100, 'POSITIVE_RESPONSE_ROOT', [32], [63, 103])
add(140, 'SOURCE_TANGENT_FIREWALL', no=[63, 103])
add(139, 'CLOCK_LOSS', [79, 80], [FIBRE])
add(150, 'UNIFORM_SLOPE', [83, 84, 86, 108], [85, 106])
add(163, 'STRUCTURED_FACTOR', [73, 97], [FIBRE, 98, 75])

def walk(x):
    if isinstance(x, dict):
        yield x
        for v in x.values():
            yield from walk(v)
    elif isinstance(x, list):
        for v in x:
            yield from walk(v)

def execute(command, target=None):
    data = subprocess.check_output(['python3', str(Q), command] + ([target] if target else []))
    name = command + ('--' + target.replace(':', '--') if target else '')
    (O / (name + '.json')).write_bytes(data)
    return json.loads(data), hashlib.sha256(data).hexdigest()

def test(s):
    target, yes, no, closed = s
    x, digest = execute('conditions', target)
    rows = list(walk(x))
    actual = {v['canonical_condition']['id'] for v in rows if isinstance(v.get('canonical_condition'), dict)}
    opens = {v['canonical_condition']['id'] for v in rows
             if isinstance(v.get('canonical_condition'), dict) and v.get('propagates_as_open_assumption') is not False}
    # Descriptive branch_local_uses does not assert a new open premise.
    opens |= {v['condition'] for v in rows if isinstance(v.get('canonical_record'), dict)
              and v.get('propagates_as_open_assumption') is True}
    refs = {v['already_expanded_reference'] for v in rows if 'already_expanded_reference' in v}
    keys = {v['query_node_key'] for v in rows if 'query_node_key' in v}
    checks = {'required_present': yes <= actual, 'excluded_absent': not no & actual,
              'scoped_discharges_closed': closed <= actual and not closed & opens,
              'all_shared_references_resolve': refs <= keys,
              'acyclic': not any(v.get('cycle_reference') for v in rows)}
    return {'node': target, 'required': sorted(yes), 'excluded': sorted(no), 'discharged': sorted(closed),
            'observed_conditions': sorted(actual), 'open_conditions': sorted(opens),
            'missing': sorted(yes - actual), 'leaked': sorted(no & actual),
            'checks': checks, 'pass': all(checks.values()), 'query_sha256': digest}

with ThreadPoolExecutor(max_workers=4) as pool:
    results = list(pool.map(test, spec))

checks = {}
for branch in ['ZERO_AND_FIRST_JET', 'SECOND_JET_FORMULA']:
    x, _ = execute('conditions', node(176, branch))
    routes = x['ancestry']['source_proof_routes']
    inputs = [{v['id'] for v in r['AND_input_proofs']} for r in routes]
    re, co = node(175, 'REAL_VARIANCE'), node(175, 'COMPLEX_VARIANCE')
    checks[branch + ':same_conclusion_two_OR_cases'] = len(routes) == 2 and all((re in s) != (co in s) for s in inputs)
    checks[branch + ':each_case_regular_and_compatible'] = all({A(117), A(119)} <= s for s in inputs)

x, _ = execute('conditions', canonical[185])
checks['C185_no_cited_argument_in_parent_proof'] = not any('CITED_POSITIVE_QUADRATIC' in str(v.get('route_id', '')) for v in walk(x))
summary, _ = execute('summary')
checks['full_census185_formal152'] = summary['substantive_claims_checked'] == summary['substantive_claims_total'] == 185 and summary['formal_declarations_checked'] == summary['formal_declarations_total'] == 152
checks['full_with_open_gaps_no_next_batch'] = summary['classification'] == 'FULLY_AUDITED' and summary['completion_state'] == 'FULLY_AUDITED_WITH_OPEN_GAPS' and summary['next_batch'] is None and summary['remaining_not_audited'] == 0
for gap, expected in [(8, [node(174, 'OMITTED_CONTACT_COHERENCE_AS_PRINTED')]), (9, [node(185, 'CITED_POSITIVE_QUADRATIC_SPECIALIZATION')])]:
    x, _ = execute('impact', f'BH-IIIA-G-{gap:04d}')
    checks[f'G{gap}:only_precise_branch_blocked'] = x['gap_records'][0]['directly_blocked'] == expected
    checks[f'G{gap}:no_unproved_material_impact'] = not x['material_descendants']
x, _ = execute('claim', node(174, 'INTERPRETED_TENSOR_NONASSOCIATIVITY'))
checks['stronger_interpretation_separate_from_source'] = x['status'] == 'REFUTED' and x['kind'] == 'INTERPRETED_CLAIM_NOT_SOURCE_CONCLUSION' and x['is_source_refutation'] is False
x, _ = execute('claim', 'BH-IIIA-C-0174')
checks['C174_source_ambiguous_not_refuted'] = x['status'] == 'UNRESOLVED'
gaps = json.loads((L / 'GapRegistry.json').read_text())['items']
checks['all10_issues_7open3resolved'] = len(gaps) == 10 and sum(g['lifecycle'] == 'OPEN' for g in gaps) == 7 and sum(g['lifecycle'] == 'RESOLVED' for g in gaps) == 3
out = {'result': 'PASS' if all(r['pass'] for r in results) and all(checks.values()) else 'FAIL',
       'clauses_checked': len(results), 'checks': results, 'additional_checks': checks, 'E0_not_E3': True,
       'scope': 'Actual CLI scope, alternatives, local discharge, issue and completion checks. Mathematical proofs are separate E1/E3/E4 records.'}
(W / 'query_validation.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({'result': out['result'], 'clauses_checked': len(results),
                  'failures': [r for r in results if not r['pass']], 'additional_checks': checks}, indent=2))
