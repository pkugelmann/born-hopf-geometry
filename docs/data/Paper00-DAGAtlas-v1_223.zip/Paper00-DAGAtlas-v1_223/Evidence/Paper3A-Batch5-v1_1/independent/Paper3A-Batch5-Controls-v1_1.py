#!/usr/bin/env python3
"""Exact support controls; the general arguments live in IndependentCertificates.

This script does not read verdicts, expected status fields, or any agent output.
It consumes only the explicit source coordinate representative and elementary
matrix/polynomial models inside the finite mathematical domain.
"""
import itertools
import json
from pathlib import Path
import sympy as s

OUT = Path(__file__).with_suffix('.json')
checks = []


def zero(x):
    if isinstance(x, s.MatrixBase):
        return all(s.simplify(v) == 0 for v in x)
    return s.simplify(x) == 0


def check(name, predicate, **data):
    checks.append(dict(name=name, passed=bool(predicate), **data))
    if not predicate:
        raise AssertionError(name)


x, y, t = s.symbols('x y t', real=True)
g, f, a = x+x*x, y*y, s.Symbol('a')
# Nested nonlinear coordinate changes. Both homogeneous and complete laws
# associate; only the latter gives the actual Hessian.
sg = g**6
truncated_sequential = 6*g**2*(2*g)**2*s.diff(g,x)**2
truncated_direct = 6*(g*g)*s.diff(g*g,x)**2
full_sequential = 30*g**4*s.diff(g,x)**2+6*g**5*s.diff(g,x,2)
check('truncated_tensor_pullbacks_associate', zero(truncated_sequential-truncated_direct),
      x1_truncated=str(truncated_direct.subs(x,1)), x1_actual=str(s.diff(sg,x,2).subs(x,1)))
check('complete_pullback_is_actual_hessian', zero(full_sequential-s.diff(sg,x,2)))
check('contact_omission_changes_actual_hessian', not zero(truncated_direct-s.diff(sg,x,2)))
affine = (2*(3*x+2)+1)**3
check('affine_positive_control', zero(s.diff(affine,x,2)-6*(2*(3*x+2)+1)*6**2))
# Stationary complete sum need not kill individual Euler covectors/contacts.
S1, S2 = x*x, -2*x
check('sum_stationarity_does_not_kill_sector_contact',
      s.diff(S1+S2,x).subs(x,1)==0 and s.diff(S1,x,2).subs(x,1)==2,
      outer_actions=['S1(r)=r','S2(r)=-2r'], field_maps=['iota1(x)=x^2','iota2(x)=x'],
      outer_euler_covectors=['1','-2'], pulled_back_gradients_at_one=['2','-2'],
      complete_euler_at_one='0', contact='2')

# Ordered two-generator Grassmann bilinear transforms by det(M).
M = s.Matrix([[1+x,x],[x*x,2-x]])
odd = x**6*M.det()
check('retained_odd_coefficient_has_nonzero_second_jet', not zero(s.diff(odd,x,2)),
      ordered_bilinear_coefficient=str(s.expand(odd)),
      odd_second_derivative=str(s.expand(s.diff(odd,x,2))), bosonic_second_derivative='0')

# Exact anchored Hessian reconstruction, including genuinely mixed entries.
F = 3+2*x-5*y+x*x*y+x*y*y+y**4
H = s.hessian(F,(x,y))
v = s.Matrix([x,y])
radial = 3+2*x-5*y+s.integrate((1-t)*(v.T*H.subs({x:t*x,y:t*y}, simultaneous=True)*v)[0],(t,0,1))
check('anchored_radial_reconstruction', zero(radial-F))
check('mixed_integrability', all(zero(s.diff(H[i,j],(x,y)[k])-s.diff(H[k,j],(x,y)[i]))
      for i,j,k in itertools.product(range(2),repeat=3)))

# Noncommuting positive pivots, moving weights, two background directions.
C10 = s.Matrix([[2,1],[1,3]])
C20 = s.Matrix([[4,1],[1,2]])
check('pivots_positive_noncommuting', C10.det()>0 and C20.det()>0 and not zero(C10*C20-C20*C10))
L0 = s.Matrix([[1,2],[-1,1]])
Ax = [s.Matrix([[1,0],[2,-1]]),s.Matrix([[0,2],[-1,1]])]
Ay = [s.Matrix([[2,1],[0,1]]),s.Matrix([[-1,0],[1,3]])]
Cs = [C10+x*s.Matrix([[1,0],[0,2]])+y*s.Matrix([[0,1],[1,0]]),
      C20+x*s.Matrix([[0,1],[1,0]])+y*s.Matrix([[2,0],[0,1]])]
Ls = [L0+x*Ax[i]+y*Ay[i]+x*y*s.eye(2)*(i+1) for i in range(2)]
Kis = [s.Matrix([[1+x,0],[0,2+y]]),s.Matrix([[2-y,x],[x,3]])]
As = [Kis[i]+Ls[i].T*Cs[i]*Ls[i] for i in range(2)]
Bs = [Ls[i].T*Cs[i] for i in range(2)]
Csum = Cs[0]+Cs[1]
Bsum = Bs[0]+Bs[1]
bar = Csum.inv()*(Cs[0]*Ls[0]+Cs[1]*Ls[1])
V = sum(((Ls[i]-bar).T*Cs[i]*(Ls[i]-bar) for i in range(2)),s.zeros(2))
Ksum = As[0]+As[1]-Bsum*Csum.inv()*Bsum.T
check('noncommuting_schur_variance_identity', zero(Ksum-Kis[0]-Kis[1]-V))
base = {x:0,y:0}
check('compatible_value_and_first_jet', zero(V.subs(base)) and zero(V.diff(x).subs(base)) and zero(V.diff(y).subs(base)))
Ts = []
for ds in (Ax,Ay):
    mv=(C10+C20).inv()*(C10*ds[0]+C20*ds[1])
    Ts.append([z-mv for z in ds])
for p,q in itertools.product(range(2),repeat=2):
    expected=sum((Ts[p][i].T*[C10,C20][i]*Ts[q][i]+Ts[q][i].T*[C10,C20][i]*Ts[p][i]
                  for i in range(2)),s.zeros(2))
    observed=V.diff((x,y)[p]).diff((x,y)[q]).subs(base)
    check('second_jet_%s%s'%(p,q),zero(observed-expected), exact_matrix=str(observed))
hs=sum(s.trace(Ts[p][i].T*[C10,C20][i]*Ts[p][i]) for p in range(2) for i in range(2))
check('positive_hs_mismatch_control',hs>0, exact_sum=str(hs))

# Smooth frame change at a zero defect: frame-derivative terms disappear.
U = s.Matrix([[s.cos(x),-s.sin(x)],[s.sin(x),s.cos(x)]])
W = s.Matrix([[s.cos(2*x),-s.sin(2*x)],[s.sin(2*x),s.cos(2*x)]])
D = x*s.Matrix([[1,2],[3,4]])
check('moving_frame_at_zero_defect',zero((W.T*D*U).diff(x).subs(x,0)-D.diff(x).subs(x,0)))
T0 = s.Matrix([[1,2],[3,4]])
Ur, Wr = s.Matrix([[0,-1],[1,0]]), s.Matrix([[s.Rational(3,5),s.Rational(-4,5)],[s.Rational(4,5),s.Rational(3,5)]])
check('weighted_hs_frame_invariance',zero(s.trace((Wr.T*T0*Ur).T*(Wr.T*C10*Wr)*(Wr.T*T0*Ur))-s.trace(T0.T*C10*T0)))

for r in range(1,5):
    delta=t**r/s.factorial(r)*s.Matrix([[1,2],[-1,3]])
    vv=delta.T*(C10+t*s.eye(2))*delta
    AA=s.Matrix([[1,2],[-1,3]])
    check('higher_derivative_factor_r%d'%r,zero(vv.diff(t,2*r).subs(t,0)-s.binomial(2*r,r)*AA.T*C10*AA))
check('scalar_example_K_equals_2q2',zero((x*x+x*x)-(x-x)**2/2-2*x*x), K_second_at_zero='4')
check('gap_closing_control',zero((t+t)-(t-t)**2/(2*t)-2*t), domain='t>0', endpoint_inverse_exists=False)
raw_ratio=(s.Rational(192,12)/s.Rational(1,6))
zz, UU = s.symbols('zz UU', positive=True)
graw, gscal = 1/(raw_ratio*UU), 1/UU
normalizations=s.solve(graw/zz-gscal,zz)
check('raw96_and_uniform_z',raw_ratio==96 and normalizations==[s.Rational(1,96)],
      trace_coefficient_ratio=str(raw_ratio), raw_to_scalar=str(s.simplify(graw/gscal)),
      uniform_z_for_equal_Newton=str(normalizations[0]), raw_branch_z='1')

# Full five-core packet in the fixed source Q(sqrt(5)) embedding.
rt=s.sqrt(5)
phi=(1+rt)/2
raw=[(1,1,1),(1,1,-1),(1,-1,1),(1,-1,-1),
     (1/phi,-phi,0),(phi,0,-1/phi),(0,1/phi,-phi),
     (0,1/phi,phi),(phi,0,1/phi),(1/phi,phi,0)]
pairs=list(itertools.combinations(range(1,6),2))
axes=[s.Matrix(v).applyfunc(s.simplify)/s.sqrt(3) for v in raw]
mirrors=[v.applyfunc(lambda z:s.simplify(z.xreplace({rt:-rt}))) for v in axes]
Js=[]
for i in range(1,6):
    Js.append(sum((s.Rational(3,4)*mirrors[k]*axes[k].T for k,p in enumerate(pairs) if i in p),s.zeros(3)).applyfunc(s.simplify))
check('five_core_exact_cancellation',zero(sum(Js,s.zeros(3))), matrices=[str(J) for J in Js])
check('all_core_intertwiners_orthogonal',all(zero(J.T*J-s.eye(3)) for J in Js))
for k in range(32):
    JT=sum((Js[i] for i in range(5) if k&(1<<i)),s.zeros(3))
    JC=sum((Js[i] for i in range(5) if not k&(1<<i)),s.zeros(3))
    check('subset_complement_%02d'%k,zero(JT+JC) and zero(JT.T*JT-JC.T*JC))
for i,j in itertools.combinations(range(1,6),2):
    JT=Js[i-1]+Js[j-1]
    u=axes[pairs.index((i,j))]
    check('two_core_axial_metric_%d%d'%(i,j),zero(JT.T*JT-4*u*u.T-s.Rational(1,4)*(s.eye(3)-u*u.T)))
check('ten_axis_fifteen_edge_counts', len(axes)==10 and sum(not set(a)&set(b) for a,b in itertools.combinations(pairs,2))==15)
Mcols=s.Matrix.hstack(*[(mirrors[k]*axes[k].T).reshape(9,1) for k in range(10)])
check('mirror_operator_envelope_rank',Mcols.rank()==9,rank=Mcols.rank())

result=dict(description='Independent exact finite controls, not a replacement for general arguments',
            sympy_version=s.__version__, all_passed=all(c['passed'] for c in checks),checks=checks)
OUT.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(output=str(OUT),checks=len(checks),all_passed=result['all_passed'])))
