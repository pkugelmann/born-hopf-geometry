# Paper3A Batch5 independent verification

Actor: `/root/b5_independent`. Evidence IDs: `BH-IIIA-B5-E3-0001` through
`BH-IIIA-B5-E3-0016`. The first fifteen records cover exactly
`BH-IIIA-C-0171`–`BH-IIIA-C-0185`; record 0016 checks the conclusion as a
restatement and scope census. The authoritative source hash is recorded in
the accompanying JSON. Sources and the canonical graph were not changed.

All provisional claim certificates were recorded before any other Batch5
agent verdict or output was read. The inputs were the frozen statement
objects, current source, exact imported prerequisite source, and audit
protocol. An unsolicited release-review message arrived after those
provisional certificates had been written; it caused only clarification of
the contact-control metadata. There was no import of another verifier's
mathematical verdict.

The independent general arguments are in the JSON records, with exact
domains and consumed premises. They use directional Taylor coefficients for
the full Hessian, two closed-form primitives and integral Taylor remainder
for reconstruction, direct block-Schur algebra and matrix Taylor expansion
for the positive variance jet, invariant sections and traces for moving
frames, and the multinomial Leibniz rule for the higher derivative factor.
These are checks of the existing claims, not new framework results.

The reusable SymPy script passed 71 exact checks. It includes positive
noncommuting moving 2×2 pivots, all four second background derivatives,
ordered odd-bilinear coefficient extraction, a nonlinear coordinate
composition, exact radial reconstruction, smooth moving frames, derivative
orders r=1 through 4, the scalar example and closing-gap control, and the
full source-defined five-core coordinate model. All 32 core subsets and all
ten two-core axial polar identities were tested. Finite controls support
the general arguments; they do not replace them.

One narrow source sentence requires adjudication. Source 5508–5509 says
that dropping the second/contact term generally destroys the previously
asserted triple-overlap coherence. The literal associativity reading is
false: the truncated law `H ↦ Dg* H Dg` composes exactly for every pair of
composable smooth maps. The complete law is correct and does produce the
actual scalar Hessians. For the admitted positive-chart diffeomorphisms
`g(x)=x+x²`, `f(y)=y²`, and scalar `s(z)=z³`, both truncated routes give
3456 at x=1, while the complete/actual Hessian is 4704. Thus dropping the
contact destroys agreement with actual Hessians, rather than the
associativity of the truncated transformation rule. If “coherence” is
intended to mean agreement with independently computed true scalar jets,
that intended statement is valid. The certificate keeps these readings
separate and includes a source-bound BND record, universal exact negation,
in-domain nonaffine witness, affine positive control, and independent replay.
No other mathematical defect is proposed in the fifteen objects.

The imported raw normalization is 96 on the ordinary-trace common-heat
branch, as independently checked from the exact trace-carrier coefficient
ratio `(192/12)/(1/6)`. The raw physical-action branch explicitly gives
`Gphys=Graw`; equality with the scalar coordinate requires `z=1/96` only
inside a separately certified complete uniform action transport. No
complete action map, scalaron endpoint extension, fermion pairing, physical
Petersen coefficient, or canonical unmarked 2I embedding is inferred.

Source 5308–5438 was checked as retrospective text. Its earlier theorem
anchors retain the optional full-profile premise, local rather than global
cone comparison, fixed finite homogeneous semigroup branch, complete
positive-rate quotient, same-owner front-speed ancestry, position frontier,
and distinct analytic assumptions. No new substantive theorem omitted from
the fifteen-object freeze was found there. This census is not a re-audit or
status promotion of the previous batches.

Outputs:

- `Paper3A-Batch5-IndependentCertificates-v1_1.json`
- `Paper3A-Batch5-Controls-v1_1.py`
- `Paper3A-Batch5-Controls-v1_1.json`
- `Paper3A-Batch5-Notes-v1_1.md`


## Source-use clarification after provisional freeze

`BH-IIIA-B5-E3-0017` was appended in the successor certificate artifact
`Paper3A-Batch5-IndependentCertificates-v1_2.json`. The original v1_1
certificate and notes are preserved. The original independent inputs and
provisional records remain unchanged.

For C185 the generic consumed-jet/source-mark retention rule follows from
the already printed C118→C145 claim-complete owner route. C147 supplies the
optional complete-parent reuse route when a licensed descendant and a
data-losing restriction are actually consumed. None of these generic rules
requires a positive interior pivot. They do require the actual owner and
its licensed contributions to exist on their declared variation domain.

C185 instead names C150, whose printed theorem is the narrower finite real
positive shared-interior quadratic Schur result. That citation cannot be
promoted into a generic full-action-jet retention proof edge. Its finite
quadratic specialization is valid under its actual hypotheses. The generic
C185 rule survives through the existing owner route; there is no source
theorem refutation, newly invented theorem, or extra positive-pivot
hypothesis on the generic case. The successor certificate records both
routes and their separate guards.
