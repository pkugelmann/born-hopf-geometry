"""Bounded E4 controls for frozen Paper III-A Batch 5; no source mutations.
Only exact mathematical controls are constructed. They assert no physical occurrence.
"""
from pathlib import Path
import json
import sympy as s

OUT = Path(__file__).with_suffix('.json')
x,y,t,u,z=s.symbols('x y t u z', real=True)
results=[]

def record(name, **kw):
    def ser(v):
        if isinstance(v, s.MatrixBase): return [[str(e) for e in row] for row in v.tolist()]
        if isinstance(v, (list,tuple)): return [ser(e) for e in v]
        if isinstance(v, dict): return {str(k):ser(e) for k,e in v.items()}
        if isinstance(v,s.Basic): return str(v)
        return v
    results.append({'control':name, **ser(kw)})

def zero(M): return all(s.cancel(a)==0 for a in M)
def at0(M): return M.subs({x:0,y:0})

# Contact at a stationary TOTAL action, while sector covectors do not vanish.
i1=x+x*x; i2=x
S=i1-i2
assert s.diff(S,x).subs(x,0)==0 and s.diff(S,x,2)==2
record('contact_at_total_stationarity', total_gradient=0, sector_gradients=[1,-1],
       true_hessian=2, tensor_only_hessian=0, disposition='attack on dropping contact succeeds; source retains it')

# Nonlinear odd map: theta1'=(1+x^2)theta1+x^2 theta1 theta3 theta4.
# theta2'=theta2; ordered theta1 theta3 theta4 theta2 has even reorder sign.
odd12=1+x*x; odd1234=x*x
assert s.diff(odd12,x,2)==2 and s.diff(odd1234,x,2)==2
record('nonlinear_odd_reexpansion', chart='|x|<1/2; invertible body 1+x^2',
       new_action='theta1_prime theta2_prime', old_coefficients={'12':odd12,'1234':odd1234},
       coefficient_hessians={'empty':0,'12':2,'1234':2},
       disposition='bosonic-only or frozen odd-map mutation fails; source orders reexpansion first')

# Integrability/affine anchors; annulus explicitly violates star-shaped domain.
H=s.Matrix([[y,0],[0,0]])
radial=x*x*y/s.Integer(6)
assert s.diff(H[0,0],y)-s.diff(H[1,0],x)==1
assert s.hessian(radial,(x,y))!=H
record('integrability_anchor_and_annulus_boundaries', nonintegrable_H=H,
       curl_obstruction=1, radial_formula_without_integrability=radial,
       radial_formula_hessian=s.hessian(radial,(x,y)),
       equal_hessian_unequal_anchor_example=['S0=0','S1=1+x'],
       annular_closed_form='(-y dx+x dy)/(x^2+y^2)', annular_period='2*pi',
       disposition='all counterexamples exclude an explicitly stated or imported premise')

# Triple composition including both contact terms.
g=x+x*x
f=y+y*y
comp=s.expand(f.subs(y,g))
correct=s.diff(comp,x,2)
chain=s.diff(f,y,2).subs(y,g)*s.diff(g,x)**2+s.diff(f,y).subs(y,g)*s.diff(g,x,2)
assert s.expand(correct-chain)==0
record('two_jet_composition', direct_hessian=correct, full_chain_hessian=chain,
       at_zero=correct.subs(x,0), omitted_contacts_at_zero=0,
       disposition='full composition associates; tensor-only mutation fails')

# Positive NONCOMMUTING moving pivots, 2 retained and 2 interior dimensions.
C10=s.Matrix([[2,1],[1,2]]); C20=s.diag(3,1)
C1=C10+x*s.diag(1,0)+y*s.Matrix([[0,1],[1,0]])
C2=C20+x*s.Matrix([[0,1],[1,0]])+y*s.diag(0,1)
L0=s.Matrix([[1,2],[-1,1]])
P1=s.Matrix([[1,0],[0,0]]); P2=s.Matrix([[0,1],[1,0]])
Q1=s.Matrix([[0,0],[1,-1]]); Q2=s.Matrix([[1,1],[0,1]])
L1=L0+x*P1+y*Q1; L2=L0+x*P2+y*Q2
Cs=C1+C2
Lb=Cs.inv()*(C1*L1+C2*L2)
D1=L1-Lb; D2=L2-Lb
V=D1.T*C1*D1+D2.T*C2*D2
B1=L1.T*C1; B2=L2.T*C2
A1=L1.T*C1*L1; A2=L2.T*C2*L2
Ks=A1+A2-(B1+B2)*Cs.inv()*(B1+B2).T
assert zero(Ks-V)
assert zero(at0(V)) and zero(at0(V.diff(x))) and zero(at0(V.diff(y)))
Mxs=(C10+C20).inv()*(C10*P1+C20*P2)
Mys=(C10+C20).inv()*(C10*Q1+C20*Q2)
Tx=[P1-Mxs,P2-Mxs]; Ty=[Q1-Mys,Q2-Mys]
pred_xx=2*sum((T.T*C*T for T,C in zip(Tx,[C10,C20])),s.zeros(2))
pred_xy=sum((T.T*C*R+R.T*C*T for T,R,C in zip(Tx,Ty,[C10,C20])),s.zeros(2))
pred_yy=2*sum((T.T*C*T for T,C in zip(Ty,[C10,C20])),s.zeros(2))
actual_xx=at0(V.diff(x,2)).applyfunc(s.cancel)
actual_xy=at0(V.diff(x).diff(y)).applyfunc(s.cancel)
actual_yy=at0(V.diff(y,2)).applyfunc(s.cancel)
assert zero(actual_xx-pred_xx) and zero(actual_xy-pred_xy) and zero(actual_yy-pred_yy)
certificate=s.trace((pred_xx+pred_yy)/2)
assert certificate>0
record('moving_noncommuting_positive_pivots', C1_at_zero=C10,C2_at_zero=C20,
       pivot_commutator=C10*C20-C20*C10,
       positive_neighborhood='|x|,|y|<1/10: each perturbation norm <= 2/10; base minimum eigenvalues are 1',
       schur_minus_variance_zero=True,V_at_zero=at0(V),DV_at_zero=[at0(V.diff(x)),at0(V.diff(y))],
       D2V_xx=actual_xx,D2V_xy=actual_xy,D2V_yy=actual_yy,
       formula_residuals_zero=True,finite_HS_certificate=certificate,
       disposition='noncommutation and moving weights do not defeat the source formula')

# Positive control: all slopes and derivatives common, with the same moving C_i.
commonL=L0+x*P1+y*Q1
commonLb=Cs.inv()*(C1*commonL+C2*commonL)
assert zero(commonLb-commonL)
record('equal_slope_derivative_positive_control', variance_identically_zero=True)

# The ordinary action two-jet versus background Hessian derivatives.
shared=u*u*x*x
assert s.hessian(shared,(x,u)).subs({x:0,u:0})==s.zeros(2)
assert s.diff(shared,u,2,x,2)==4
record('background_vs_ordinary_action_jet', shared_reduced_action=shared,
       ordinary_two_jet_at_origin=s.hessian(shared,(x,u)).subs({x:0,u:0}),
       retained_K=2*x*x, background_second_K_derivative=4,
       fourth_mixed_action_derivative=4,
       disposition='equal ordinary two-jets coexist with unequal second background K jets, as source says')

# Moving frames: connection terms cancel only at Delta=0.
J=s.Matrix([[0,-1],[1,0]])
W=s.Matrix([[s.cos(t),-s.sin(t)],[s.sin(t),s.cos(t)]])
Dgood=t*s.eye(2); Dbad=s.eye(2)
assert (W.T*Dgood).diff(t).subs(t,0)==s.eye(2)
assert (W.T*Dbad).diff(t).subs(t,0)==-J
record('moving_frame_boundary', compatible_Delta_derivative=s.eye(2),
       compatible_transformed_derivative=(W.T*Dgood).diff(t).subs(t,0),
       incompatible_original_derivative=s.zeros(2),incompatible_transformed_derivative=-J,
       disposition='off-compatible counterexample is valid only against an unstated extension')

# Higher-order formula under fully smooth coefficients, with variable positive weights.
for r in [1,2,3]:
    Li=t**r/s.factorial(r)
    lb=(2+t)*Li/5
    da=Li-lb; db=-lb
    vv=s.expand((2+t)*da**2+(3-t)*db**2)
    Aa=s.diff(da,t,r).subs(t,0); Ab=s.diff(db,t,r).subs(t,0)
    leading=s.simplify(2*Aa**2+3*Ab**2)
    expected=s.binomial(2*r,r)*leading
    actual=s.diff(vv,t,2*r).subs(t,0)
    assert actual==expected
    record('higher_order_r_'+str(r), variance=vv, leading_positive_matrix=leading,
           actual_derivative=actual,binomial_prediction=expected,exact=True)
# A C^2-only mutation for r=2 does not justify an ordinary fourth derivative.
# For d=t^2+t^5 sin(1/t), V=2d^2. At t!=0, (V'''-V'''(0))/t
# has leading term 48+4*cos(1/t), so no fourth derivative exists.
d=t*t+t**5*s.sin(1/t)
quot=s.diff(2*d*d,t,3)/t
lead=s.series(quot,t,0,1) if False else s.expand(quot)
record('higher_order_smoothness_boundary',
       mutation='Delta_1=t^2+t^5 sin(1/t), Delta_2=-Delta_1, C1=C2=1, with values 0 at t=0',
       regularity='Delta_i are C^2; V=2 Delta_1^2 has no ordinary fourth derivative at 0',
       quotient_exact=lead,
       disposition='not a source counterexample: source additionally requires sufficiently smooth coefficients')
record('higher_order_flat_boundary', example='Delta_1=exp(-1/t^2), Delta_2=-Delta_1, zero at 0, C1=C2=1',
       consequence='all jets vanish but V(t)>0 for t!=0',
       disposition='source does not assert existence of a finite first nonzero derivative or nonzero A_i')

# Excluded pivots: exact source-style closing-gap diagnostic and an indefinite one.
record('excluded_pivot_controls',closing_gap={'C1':'t','C2':'t','L1':'1','L2':'-1','V':'2*t','endpoint_inverse':'undefined'},
       indefinite={'C1':'2','C2':'-1','L1':'1','L2':'0','Csum':'1','V':'-2'},
       disposition='shows why endpoint/in-definite extensions are blocked; not an in-domain failure')

# Raw versus whole-action Newton normalization, and moving normalization jets.
z0=s.Rational(1,96)
raw=1+x*x; moving=(1+x*x)/96
assert s.diff(moving*raw,x,2).subs(x,0)==s.Rational(1,24)
assert s.diff(z0*raw,x,2).subs(x,0)==s.Rational(1,48)
record('normalization_branches',Gscal=1,Graw=s.Rational(1,96),Gphys_raw=s.Rational(1,96),
       z_uniform=z0,Gphys_uniform=1,matching_z0_nonconstant_map=moving,
       moving_action_Hessian_at_zero=s.Rational(1,24),constant_action_Hessian_at_zero=s.Rational(1,48),
       disposition='both branches agree with III-E; pointwise scale alone is not the certified whole-action map')

# Exact CURRENT I-A coordinates, not substitute core rotations.
rt=s.sqrt(5); ph=(1+rt)/2
pairs=[(1,2),(1,3),(1,4),(1,5),(2,3),(2,4),(2,5),(3,4),(3,5),(4,5)]
coords=[(1,1,1),(1,1,-1),(1,-1,1),(1,-1,-1),(1/ph,-ph,0),
        (ph,0,-1/ph),(0,1/ph,-ph),(0,1/ph,ph),(ph,0,1/ph),(1/ph,ph,0)]
vecs={p:s.Matrix(c).applyfunc(s.simplify)/s.sqrt(3) for p,c in zip(pairs,coords)}
Js=[]
for core in range(1,6):
    U=s.Matrix.hstack(*(vecs[p] for p in pairs if core in p))
    Us=U.applyfunc(lambda e:s.simplify(e.xreplace({rt:-rt})))
    Ji=(s.Rational(3,4)*Us*U.T).applyfunc(s.simplify)
    assert zero(Ji.T*Ji-s.eye(3))
    assert s.simplify(Ji.det())==1
    Js.append(Ji)
assert zero(sum(Js,s.zeros(3)))
for i in range(5):
    for j in range(5):
        assert s.simplify(s.trace(Js[i].T*Js[j]))==(3 if i==j else -s.Rational(3,4))
subset_checks=[]
for i in range(5):
    for j in range(i+1,5):
        pair=Js[i]+Js[j]
        comp=sum((Js[k] for k in range(5) if k not in (i,j)),s.zeros(3))
        assert zero(comp+pair) and zero(comp.T*comp-pair.T*pair)
        pol=(pair.T*pair).applyfunc(s.simplify)
        assert s.simplify(pol.det()-s.Rational(1,4))==0
        assert s.simplify(s.trace(pol)-s.Rational(9,2))==0
        subset_checks.append([i+1,j+1])
record('current_IA_core_matrix_import',coordinate_source='Paper1A-Geometry-v5_167.tex:3764-3775',
       definition_source='Paper1A-Geometry-v5_167.tex:4028-4055',core_matrices=Js,
       sum_zero=True,orthogonal_det_plus_one=True,pair_HS_inner_product='-3/4',
       all_ten_complements_even=True,checked_pairs=subset_checks,
       disposition='marked finite identities survive exact current-coordinate attack; no physical action term inferred')

# Post-freeze exact distinction: tensor congruence associates even when it is
# not the actual Hessian transformation for a nonlinear coordinate map.
Jf=s.Matrix([[1,2],[3,4]]); Jg=s.Matrix([[2,0],[1,3]]); HH=s.Matrix([[5,1],[1,2]])
left=Jg.T*(Jf.T*HH*Jf)*Jg
right=(Jf*Jg).T*HH*(Jf*Jg)
assert zero(left-right)
record('pure_congruence_associates_but_is_not_actual_hessian',
       general_identity='Dg* (Df* H Df) Dg = (Df Dg)* H (Df Dg) = D(f o g)* H D(f o g)',
       exact_matrix_residual_zero=True,nonlinear_example='s(z)=z, f(y)=y+y^2, g(x)=x+x^2',
       pure_congruence_each_composition_path_at_zero=0,
       actual_same_action_hessian_at_zero=4,
       disposition='valid attack on algebraic nonassociativity reading only; correct full actual-Hessian transport survives')

OUT.write_text(json.dumps({'evidence_level':'E4','actor':'/root/b5_adversarial',
    'scope':'Exact bounded controls of frozen C0171-C0185; examples are HOST diagnostics, not asserted physical constructors',
    'all_assertions_passed':True,'controls':results},indent=2)+'\n')
print(json.dumps({'output':str(OUT),'all_assertions_passed':True,'control_count':len(results)}))
