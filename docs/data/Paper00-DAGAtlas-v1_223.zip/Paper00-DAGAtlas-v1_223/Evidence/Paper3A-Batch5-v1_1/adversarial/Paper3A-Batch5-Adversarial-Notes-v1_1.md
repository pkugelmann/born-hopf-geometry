# Paper III-A Batch 5 adversarial evidence, v1_1

The 15 frozen objects C0171–C0185 have 24 source-bound E4 attack records and ten boundary records. No admitted-domain algebraic refutation was found. Two minor OPEN local issues are retained: G0008 concerns the final coherence-property reference in C0174; G0009 concerns the narrow citation route in C0185. This is an E4 result, not an independent declaration of theorem verification.

## Independence and scope

The attacks were fixed using only `FrozenBatchStatements.json` and the current read-only paper corpus. No other Batch 5 verdict or proposal file was read. The first 22 attacks and eight boundaries were fixed before coordinator messages supplied the two final local adjudications. Attacks 0023–0024 and BND 0009–0010 are clearly marked post-freeze source reviews, not independent initial discoveries. Current III-A lines 5439–5726 were tested; closing prose 5308–5438 was inspected for broadening of occurrence, analytic, reconstruction, process and calibration domains. Its explicit qualifications agree with the section's boundaries. Earlier batch theorems summarized there were not re-proved in this pass.

The exact imported scope was checked in III-A 4768–4962; III-D 2673–2763; III-E 370–442; and I-A 3662–3692, 3764–3775, 3921–3952, 4016–4127. These bounded checks do not declare the imported papers audited.

## Attacks preserved

| Claim | Exact attack and disposition |
|---|---|
| C0171 | Co-realization without a licensed common word, and local reconstruction without global gluing: excluded explicitly; no missing constructor is smuggled in. |
| C0172 | Total stationarity does not kill sector contacts: an exact control has total gradient 0 and Hessian 2 coming entirely from the contact. Nonlinear odd transition creates retained bilinear and quartic coefficient Hessians, both 2, while the bosonic coefficient remains 0. Both support the printed complete prescription. |
| C0173 | Constant skew H satisfies derivative equality but is excluded by the imported symmetric-Hessian type. Symmetric nonintegrable H, different affine anchors and a closed angular form on an annulus attack omitted hypotheses only. The imported theorem supplies C1 symmetry and the source expressly retains periods and affine gluing. |
| C0174 | Nonlinear transitions give Hessian 4 at zero only when the contact terms are retained. The actual full chain rule associates; odd mixing must be completed before coefficient extraction as printed. |
| C0175 | Exact positive noncommuting 2×2 pivots with moving weights satisfy the ordered Schur variance identity. No commutation was needed. |
| C0176 | The same controls cancel DC and D2C terms at compatibility and match every second-jet component. The finite HS certificate is 57/7 in the mismatch control and zero with common slope derivatives. Positivity blocks nonzero mismatches from cancelling. |
| C0177 | q²u² has zero ordinary action two-jet at (0,0), but K(q)=2q² has background second derivative 4. This agrees with the source's derivative-order distinction. |
| C0178 | Moving-frame derivative terms cancel at Delta=0. A constant nonzero Delta acquires a derivative under a rotating frame; that valid counterexample concerns only an explicitly unclaimed off-compatible extension. |
| C0179 | Smooth variable-weight controls at r=1,2,3 reproduce the factorial/binomial formula. C2-only data can fail to have a fourth derivative when r=2, but the source separately says sufficiently smooth. Flat smooth functions do not refute the first potentially nonzero-order statement. |
| C0180 | A closing gap gives V=2t with an undefined endpoint inverse; an indefinite pivot gives V=−2. Both are valid attacks on extensions expressly excluded by the source. |
| C0181 | The shared sum reduces to q²u², so the retained Hessian is 2q², not q². Its second background derivative is 4. The source explicitly treats the pair as a mathematical diagnostic. |
| C0182 | Current III-E admits the raw Gphys=Graw=Gscal/96 branch. The stronger equality needs z=1/96 inside an already certified uniform complete transport. A moving z matching that value at one point has extra Hessian terms, exactly as the source warns. |
| C0183 | The finite import presupposes an occurring embedded 2I branch; it does not select an embedding or identify a 15-edge A5 module with momentum H1. I-A completeness is confined to the stated linear equivariant edge domain. |
| C0184 | Exact current I-A coordinates reproduce all five orthogonal Jm, their zero sum and all ten complement polar identities. Nonlinear norm-squared terms need not cancel: their sum is 15. The printed proposition claims only linear cancellation and no physical action occurrence. |
| C0185 | Ambient continuous rotations are not a generated physical Noether symmetry. The finite A5 action has no nontrivial continuous one-parameter subgroup. Marked local A4 intertwiners and a nine-dimensional host envelope do not insert a physical field or action coefficient into the common-action theorem. |

## Exact controls

Run `python audit_batch5/proposals/adversarial/Paper3A-Batch5-Adversarial-Controls-v1_1.py` from the workspace. The script uses SymPy and writes the adjacent JSON. All exact assertions passed; the result contains 17 named controls. Tests construct only mathematical host diagnostics and never assert native physical occurrence.

The moving-pivot test uses base pivots [[2,1],[1,2]] and diag(3,1), whose commutator is [[0,−2],[2,0]]. Its complete second-jet results are:

- DxxV = [[18/7,−12/7],[−12/7,15/7]].
- DxyV = [[−18/7,6/7],[6/7,3]].
- DyyV = diag(18/7,9).

These equal the source formula exactly, including all matrix ordering and moving-weight effects.

For the higher-smoothness boundary, Delta₁=t²+t⁵sin(1/t), Delta₂=−Delta₁ with C₁=C₂=1 is C2, but V'''(t)/t=48+4cos(1/t)+o(1). Thus an ordinary fourth derivative does not exist. This is retained as a valid attack on a C2-only mutation, not a missing-condition allegation: the proposition expressly requires sufficient smoothness.

No source was edited, no repair was introduced, no PDF was generated, and no subagent was spawned. The coordinator-supplied candidate issue identifiers G0008 and G0009 are retained as provisional local issues; no new canonical issue IDs were minted.

## Post-freeze source adjudication

**G0008 — minor OPEN source-scope ambiguity, C0174 lines 5507–5509.** Full actual Hessian 2-jets associate, with the contact included. Pure tensor congruence also associates universally: Dg* (Df* H Df) Dg = (Df Dg)* H (Df Dg) = D(f o g)* H D(f o g), at the appropriate mapped points. Consequently an actual-Hessian mismatch from omitting contact does not prove nonassociativity of the tensor rule. For s(z)=z, f(y)=y+y² and g(x)=x+x², every pure-congruence path gives 0 at zero while the same-action actual Hessian is 4. The final phrase “destroys that coherence” is ambiguous between actual-Hessian correctness and algebraic associativity. Only that final property reference remains unresolved; the full formula and its valid actual-Hessian coherence are preserved. No new hypothesis or source-wide refutation follows.

**G0009 — minor OPEN citation-route mismatch, C0185 lines 5721–5725.** The cited C150 theorem (4783–4833) concerns positive finite quadratic retained/shared-interior Schur reduction. It does not by itself prove generic complete-jet/source-mark retention for every licensed action with a Petersen operator. Existing C145 (4683–4715), C147 (4725–4758), and C118 (3782–3817) supply the generic retained-parent/action-constructor route. The main firewall survives through those existing statements. No positive-pivot restriction is imposed on C0185's generic action branch; that restriction remains local to C150.

These addenda preserve the original negative attack history and distinguish a source citation/property ambiguity from a mathematical refutation. They were appended after coordinator steering and exact current-source confirmation.
