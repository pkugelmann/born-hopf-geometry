"""Independent exact checks of existing Paper II-E batch-1 claims.

Inputs are explicit mathematical objects, not Atlas verdicts or other agents'
outputs.  This checks algebra, finite support spectra and character data. It
does not certify physical occurrence or the upstream constructor grammar.
"""
from itertools import product, permutations, combinations
from fractions import Fraction as F
import json
import sympy as s

checks=[]
def ok(name, condition, result):
    if not bool(condition):
        raise AssertionError(name)
    checks.append({'check': name, 'passed': True, 'result': result})

I=s.I; I2=s.eye(2); I4=s.eye(4)
pauli=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-I],[I,0]]),s.diag(1,-1)]
k0,k1,k2,k3=s.symbols('k0 k1 k2 k3',real=True)
K=k0*I2+sum((k*p for k,p in zip([k1,k2,k3],pauli)),s.zeros(2))
ok('Pauli determinant polynomial',s.expand(K.det())==k0**2-k1**2-k2**2-k3**2,'det K=k0^2-|k|^2')

# Independent real Lorentz matrices from spinor congruence; rational controls
# include one noncompact and one nondiagonal compact element.
As=[s.Matrix([[2,0],[0,s.Rational(1,2)]]),s.Matrix([[1,1+I],[0,1]]),s.Matrix([[s.Rational(3,5),s.Rational(4,5)],[-s.Rational(4,5),s.Rational(3,5)]])]
basis=[I2]+pauli; metric=s.diag(1,-1,-1,-1)
for n,A in enumerate(As):
    T=s.Matrix([[s.simplify(s.trace(B*A*C*A.conjugate().T)/2) for C in basis] for B in basis])
    ok('Lorentz congruence control '+str(n),s.simplify(T.T*metric*T)==metric and s.simplify(T.det())==1 and T[0,0]>0,{'T':str(T)})
    H=s.Matrix([[2,1-I],[1+I,3]])
    theta=A.conjugate().T.inv()
    dual=s.simplify(s.trace(theta*H*A.inv()*A*K*A.conjugate().T)/2-s.trace(H*K)/2)
    ok('Conjugate-dual trace pairing '+str(n),dual==0,'trace pairing invariant')

# Euclidean gamma matrices built from tensor products.  Even-algebra faithfulness
# is checked over R, including its pseudoscalar, rather than assumed from the
# relations alone.
C=[s.kronecker_product(pauli[0],p) for p in pauli]+[s.kronecker_product(pauli[1],I2)]
Gamma=C[0]*C[1]*C[2]*C[3]
a,b=s.symbols('alpha beta',real=True)
X=[a*c+b*I*Gamma*c for c in C]
ok('Protected Euclidean relations',all(C[i]*C[j]+C[j]*C[i]==2*(i==j)*I4 for i in range(4) for j in range(4)),'{Ca,Cb}=2 delta I')
ok('Protected two-parameter squared radius',s.simplify(sum((x*x for x in X),s.zeros(4)))==4*(a*a+b*b)*I4,'sum Xa^2=4(alpha^2+beta^2) I')
ok('Protected exact even phase cancellation',all(s.simplify(X[i]*X[3]-(a*a+b*b)*C[i]*C[3])==s.zeros(4) for i in range(3)),'Xi X4=(alpha^2+beta^2) Ci C4')
e=[C[i]*C[3] for i in range(3)]
mons=[I4]+e+[e[i]*e[j] for i in range(3) for j in range(i+1,3)]+[e[0]*e[1]*e[2]]
realcols=[s.Matrix([s.re(x) for x in list(m)]+[s.im(x) for x in list(m)]) for m in mons]
rank=s.Matrix.hstack(*realcols).rank()
ok('Represented real even algebra faithful dimension',rank==8,{'real_rank':rank,'Cl(0,3)_dimension':8})
R=s.symbols('R',positive=True)
rho=s.sqrt(3)*R/4
ok('Generated protected radius substitution',s.simplify(4*rho*rho-3*R*R/4)==0,'4 (sqrt3 R/4)^2=3R^2/4 > 0')
ok('Raw zero member',all(x.subs({a:0,b:0})==s.zeros(4) for x in X),'zero member exists; inverse normalization undefined there')

# Hurwitz support and natural left regular action, constructed in exact rationals.
qs=[]
for j in range(4):
    for sign in [-1,1]:
        q=[F(0)]*4;q[j]=F(sign);qs.append(tuple(q))
qs += [tuple(F(v,2) for v in signs) for signs in product([-1,1],repeat=4)]
qindex={q:i for i,q in enumerate(qs)}
def qm(q,r):
    a,b,c,d=q; e,f,g,h=r
    return (a*e-b*f-c*g-d*h,a*f+b*e+c*h-d*g,a*g-b*h+c*e+d*f,a*h+b*g-c*f+d*e)
def qi(q): return (q[0],-q[1],-q[2],-q[3])
ok('Hurwitz closure',len(qs)==24 and all(qm(q,r) in qindex for q in qs for r in qs),'24 exact unit quaternions closed under multiplication')
Ad=s.Matrix([[int(sum(q[t]*r[t] for t in range(4))==F(1,2)) for r in qs] for q in qs])
evals=Ad.eigenvals();ok('24-cell adjacency spectrum',evals=={8:1,4:4,0:9,-2:8,-4:2},{str(k):v for k,v in evals.items()})
# Spectral projector P0 onto the zero adjacency sector; complementary target E15.
P9=(Ad-8*s.eye(24))*(Ad-4*s.eye(24))*(Ad+2*s.eye(24))*(Ad+4*s.eye(24))/(s.Integer(-8)*(-4)*2*4)
P15=s.eye(24)-P9
ok('BM orthogonal rank split',P9*P9==P9 and P9.T==P9 and P9.rank()==9 and P15.rank()==15,{'rank_E9':9,'rank_E15':15})
reps=[]
for q in qs:
    reps.append(s.Matrix([[int(qm(q,r)==p) for r in qs] for p in qs]))
avg=sum(reps,s.zeros(24))/24
ok('Natural BM fixed subspace',s.trace(P15*avg)==1,'dim E15^(2T)=1')
ch1=[s.Integer(1)]*24
ch2=[s.Rational(2*q[0]) for q in qs]
ch3=[s.Rational(4*q[0]*q[0]-1) for q in qs]
chars=[ch1,ch2,ch3]; dims=[1,2,3]
inner=s.Matrix([[sum(x*y for x,y in zip(c,d))/24 for d in chars] for c in chars])
ok('Relevant quaternion irreducible characters',inner==s.eye(3),'1,V2,V3 pairwise orthonormal')
target_mult=[]
for char in chars:
    target_mult.append(s.simplify(sum(char[i]*s.trace(P15*reps[i]) for i in range(24))/24))
ok('Natural E15 relevant multiplicities',target_mult==[1,2,0],{'multiplicities':list(map(int,target_mult))})
source_mult=[6,3,1]
fixed=source_mult[0]
maxrank=sum(d*min(x,int(y)) for d,x,y in zip(dims,source_mult,target_mult))
homdim=sum(x*int(y) for x,y in zip(source_mult,target_mult))
ok('Natural H1/BM obstruction and sharp rank',fixed==6 and maxrank==5 and homdim==12,{'source_fixed_dim':fixed,'target_fixed_dim':1,'maximum_intertwiner_rank':maxrank,'minimum_kernel_dim':15-maxrank,'Hom_dim':homdim})
Ev=s.Matrix([[1]+[s.Rational(t) for t in q] for q in qs])
ok('Rank-five positive control',Ev.rank()==5 and P15*Ev==Ev,{'rank_evaluation':5,'image_contained_in_E15':True})
B=s.diag(*range(1,16))
ok('Supported trace scaling',s.trace(B)/24==s.Rational(15,24)*(s.trace(B)/15),'tau24(i B i*)=(15/24) tau15(B) for all B by trace invariance')

out={'kind':'E3-INDEPENDENT-EXACT','target':'Paper2E-KinematicExports-v3_130.tex','source_lines':[1,1274],'input_lineage':'Source theorem objects, explicit Pauli matrices, explicit Hurwitz coordinates; no other agent proposals or atlas statuses read.','checks':checks,'checks_count':len(checks),'all_passed':all(x['passed'] for x in checks)}
from pathlib import Path
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'all_passed':out['all_passed'],'checks_count':out['checks_count'],'output':str(Path(__file__).with_suffix('.json'))}))
