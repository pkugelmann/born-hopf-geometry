"""Claim-matched E4 finite/symbolic controls for II-E source lines 1-1274.
No source modification or theory-extension proof is performed.
"""
from itertools import product
from fractions import Fraction as Q
import json
import sympy as s
I=s.I
one=s.eye(2)
sigma=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-I],[I,0]]),s.diag(1,-1)]
# Euclidean Hermitian gamma realization, no inherited source coefficients.
C=[s.kronecker_product(sigma[0],x) for x in sigma]+[s.kronecker_product(sigma[1],one)]
G=C[0]*C[1]*C[2]*C[3]
assert G*G==s.eye(4)
D=[I*G*c for c in C]
a,b=s.symbols('a b', real=True)
X=[a*c+b*d for c,d in zip(C,D)]
clifford_phase_controls=[]
for i in range(3):
 assert s.simplify(X[i]*X[3]-(a*a+b*b)*C[i]*C[3])==s.zeros(4)
for ai,bi in [(s.Rational(3,5),s.Rational(4,5)),(0,1),(1,0),(-1,0),(0,-1)]:
 Y=[ai*c+bi*d for c,d in zip(C,D)]
 assert all(s.simplify(Y[i]*Y[3]-C[i]*C[3])==s.zeros(4) for i in range(3))
 clifford_phase_controls.append([str(ai),str(bi)])
e=[C[i]*C[3] for i in range(3)]
basis=[s.eye(4),*e,e[0]*e[1],e[0]*e[2],e[1]*e[2],e[0]*e[1]*e[2]]
real_vectors=[s.Matrix([s.re(x) for x in v]+[s.im(x) for x in v]) for v in basis]
assert s.Matrix.hstack(*real_vectors).rank()==8
# Zero and raw-scale mutations: normalized output excluded exactly at zero.
assert all(x.subs({a:0,b:0})==s.zeros(4) for x in X)
raw_comm=s.simplify(X[0]*X[1]-X[1]*X[0])
assert raw_comm.subs({a:1,b:0}) != raw_comm.subs({a:2,b:0})
# Hermitian/null-cone attacks with nonunitary and complex shear controls.
z=s.Matrix([1,I]); K=z*z.conjugate().T
As=[s.diag(2,s.Rational(1,2)),s.Matrix([[1,1],[0,1]]),s.Matrix([[1,I],[0,1]])]
for A in As:
 assert A.det()==1
 th=A.conjugate().T.inv()
 for B in [A,th]:
  T=B*K*B.conjugate().T
  assert T.det()==0 and T.rank()==1 and s.re(s.trace(T))>0
 H=s.Matrix([[3,1+I],[1-I,4]])
 assert s.simplify(s.trace(th*H*A.inv()*A*K*A.conjugate().T)-s.trace(H*K))==0
 assert s.simplify((A*z)*(A*z).conjugate().T-A*K*A.conjugate().T)==s.zeros(2)
# Ray invariance under every tested nonzero complex scalar.
for c in [2,I,1+I,-3]:
 assert s.simplify((c*z)*(c*z).conjugate().T-c*s.conjugate(c)*K)==s.zeros(2)
# Invalid witnesses document why each is outside target hypotheses.
invalid_cone=[{'witness':'zero matrix','fails':'rank(K)=1'},
 {'witness':'diag(-1,0)','fails':'K>=0'}, {'witness':'I_2','fails':'rank(K)=1'},
 {'witness':'diag(1,0) acting matrix','fails':'det(A)=1'}]
# Exact unit Hurwitz group and adjacency realization.
H=[]
for k in range(4):
 for sign in [-1,1]:
  v=[Q(0)]*4;v[k]=Q(sign);H.append(tuple(v))
H += [tuple(Q(t,2) for t in signs) for signs in product([-1,1],repeat=4)]
H=sorted(H); assert len(H)==24
ix={x:i for i,x in enumerate(H)}
def mul(x,y):
 a,b,c,d=x;e,f,g,h=y
 return(a*e-b*f-c*g-d*h,a*f+b*e+c*h-d*g,a*g-b*h+c*e+d*f,a*h+b*g-c*f+d*e)
assert all(mul(x,y) in ix for x in H for y in H)
T=[x for x in H if x[0]==Q(1,2)]
A=s.zeros(24)
for j,q in enumerate(H):
 for t in T:A[ix[mul(t,q)],j]+=1
assert A.rank()==15 and A*s.ones(24,1)==8*s.ones(24,1)
chi2=[2*x[0] for x in H];chi3=[4*x[0]*x[0]-1 for x in H]
fixedH=sum(6+3*x+y for x,y in zip(chi2,chi3))/24
assert fixedH==6 and sum(chi2)==0 and sum(chi3)==0
# Trace normalization mutation on the same supported operator.
B=s.diag(*range(1,16));tau15=s.trace(B)/15;tau24=s.trace(B)/24
assert tau24==s.Rational(15,24)*tau15 and tau15==s.Rational(24,15)*tau24
assert tau24!=s.Rational(24,15)*tau15
# Level transport/integrality controls, both sign branches and negative/zero n.
R=s.Rational(2);hb=s.Rational(3)
for eps in [-1,1]:
 for n in [-2,0,1]:
  mu=eps*hb*n/R;mu0=R*mu
  assert eps*mu0/hb==n
assert R*s.Rational(1)/hb==s.Rational(2,3)
results={'all_assertions_passed':True,'protected_even_real_dimension':8,
 'protected_phase_controls':clifford_phase_controls,'zero_completion_normalization':'undefined, target correctly excludes',
 'raw_commutator_varies_with_magnitude':True,'celestial_SL2C_controls':len(As),
 'invalid_cone_attacks':invalid_cone,'hurwitz_adjacency_rank':A.rank(),
 'natural_H1_fixed_dimension':int(fixedH),'BM_natural_fixed_dimension':1,
 'trace_test':{'tau15':str(tau15),'tau24':str(tau24)},
 'moment_empty_fibre_ratio':'2/3','new_framework_results':False}
print(json.dumps(results,indent=2))
