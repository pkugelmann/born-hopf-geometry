"""Independent normalized Hopf/cotangent/endpoint presentation controls."""
import sympy as s
from itertools import product
from pathlib import Path
import json
checks=[]
def ok(n,c,r):
 if not c:raise AssertionError(n)
 checks.append({'check':n,'passed':True,'result':r})
chi,theta,phi=s.symbols('chi theta phi',real=True)
R,hbar=s.symbols('R hbar',positive=True)
n=s.symbols('n',integer=True);mu=s.symbols('mu',real=True)
eps=s.symbols('eps',real=True)
# eta=cos^2 chi dphi1+sin^2 chi dphi2; positively orient total space by
# eta wedge deta. Direct coefficient magnitude is 2 sin chi cos chi.
volume=s.integrate(2*s.sin(chi)*s.cos(chi),(chi,0,s.pi/2))*(2*s.pi)**2
ok('Hopf normalized total-space integral',s.simplify(volume/(4*s.pi**2))==1,'integral eta0 wedge deta0=4 pi^2')
ok('Hopf character quadratic diagnostic',s.simplify(n*n*volume/(4*s.pi**2))==n*n,'n^2, distinct from linear n')
A=(1-s.cos(theta))/2
flux=s.integrate(s.diff(A,theta),(theta,0,s.pi))*2*s.pi
ok('Local Hopf curvature flux',s.simplify(flux)==2*s.pi,'A=(1-cos theta)/2 dphi gives integral dA=2pi')
ok('Metric/principal moment scaling',s.simplify((R*mu)/R-mu)==0,'mu0=R mu; Jxi=J0/R')
ok('Magnetic Chern coefficient',s.simplify(mu*R*flux/(2*s.pi*hbar)-R*mu/hbar)==0,'n_pq=eps R mu/hbar; sign depends declared reduction convention')
cap=s.integrate(s.diff(A,theta),(theta,0,s.pi/2))*2*s.pi
ok('Individual geometric phase need not be full flux',cap==s.pi,'hemisphere curvature flux pi; holonomy -1')
ok('Optional calibrated rows incompatible',s.simplify(R/2-R/(2*s.sqrt(2)))>0,'R>0 rules out R/2=R/(2sqrt2)')
ok('Optional PI/factorized same-completion equation',s.simplify(2*R/(2*s.sqrt(2))-R/s.sqrt(2))==0,'rho_prot=R/sqrt2; not rho_prot=R')

I=s.I;I2=s.eye(2);I4=s.eye(4)
sigma=[s.Matrix([[0,1],[1,0]]),s.Matrix([[0,-I],[I,0]]),s.diag(1,-1)]
C=[s.kronecker_product(sigma[0],p) for p in sigma]+[s.kronecker_product(sigma[1],I2)]
pairs=[(i,j) for i in range(4) for j in range(i+1,4)]
def W(q):return s.Matrix([[q[i]*(j==k)-q[j]*(i==k) for k in range(4)] for i,j in pairs])
c=s.symbols('c',real=True)
def K(q):
 q=s.Matrix(q);w=W(q);H=2*w*w.T-s.eye(6)
 out=s.zeros(15)
 out[0,0]=1;out[0,1:5]=2/s.sqrt(3)*q.T;out[1:5,0]=2/s.sqrt(3)*q
 out[1:5,1:5]=s.Rational(8,9)*I4+s.Rational(4,9)*q*q.T
 out[1:5,5:11]=4*s.sqrt(6)/9*w.T;out[5:11,1:5]=4*s.sqrt(6)/9*w
 out[5:11,5:11]=s.eye(6)+c*H
 out[11:15,11:15]=I4+sum((q[a]*C[a] for a in range(4)),s.zeros(4))
 return out
Q=[]
for a in range(4):
 for sign in [-1,1]:
  q=[0]*4;q[a]=sign;Q.append(q)
dens=[K(q) for q in Q]
ok('Eight quaternion effects normalize',s.simplify(sum(dens,s.zeros(15))/8)==s.eye(15),'sum E_q=I15 for all real c')
for a in range(4):
 X=s.simplify(s.sqrt(3)*R*sum((q[a]*k for q,k in zip(Q,dens)),s.zeros(15))/8)
 expected=s.zeros(15);expected[0,1+a]=expected[1+a,0]=R/2
 w=W([int(j==a) for j in range(4)])
 expected[1:5,5:11]=s.sqrt(2)*R/3*w.T;expected[5:11,1:5]=s.sqrt(2)*R/3*w
 expected[11:15,11:15]=s.sqrt(3)*R/4*C[a]
 ok('Exact eight-outcome native moment '+str(a),s.simplify(X-expected)==s.zeros(15),'native scalar/vector/protected edges R/2,sqrt2 R/3,sqrt3 R/4')
ok('Endpoint geometric/protected traces',all(s.trace(k[:11,:11])==11 and s.trace(k[11:,11:])==4 for k in dens),'Tr_geo K=11, Tr_sp K=4')
T=s.diag(*([s.Rational(1,11)]*11+[-s.Rational(1,4)]*4));Pg=s.diag(*([1]*11+[0]*4));Ps=s.eye(15)-Pg
vals=[s.simplify(s.trace(T*P*k*P)/8) for k in dens for P in [Pg,Ps]]
norm2=s.trace(T*T);frame=s.simplify(sum(x*x for x in vals)/norm2)
ok('Tagged population effect-frame constant',frame==s.Rational(11,15),{'frame_constant_N8':str(frame),'general_constant':'88/(15N)'})
ok('Untagged population blindness',all(s.simplify(s.trace(T*k))==0 for k in dens),'Tr(T E_j)=0')
ok('Center exact reconstruction',sum((Pg*k*Pg for k in dens),s.zeros(15))/8==Pg and sum((Ps*k*Ps for k in dens),s.zeros(15))/8==Ps,'tag sums reconstruct Pg,Ps and every central word')

out={'kind':'E3-INDEPENDENT-EXACT','lineage':'Explicit Hopf coordinate integral and exact 15x15 endpoint matrices at Q8; no Atlas flags or other verifier outcomes.','checks_count':len(checks),'all_passed':True,'checks':checks}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'checks_count':len(checks),'all_passed':True}))
