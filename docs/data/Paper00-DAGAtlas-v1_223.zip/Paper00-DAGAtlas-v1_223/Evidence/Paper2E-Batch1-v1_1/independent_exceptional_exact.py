"""Exact exceptional-group moment/frontier controls for II-E's conditional atlas.
This is mathematical evidence only; group/role occurrence is not inferred.
"""
from itertools import product,permutations
from fractions import Fraction as F
from math import factorial
import json
from pathlib import Path
checks=[]
def ok(n,c,r):
 if not c: raise AssertionError(n)
 checks.append({'check':n,'passed':True,'result':r})

# Q(sqrt5) coordinates in the basis (1,sqrt5), represented as rational pairs.
def add(x,y): return (x[0]+y[0],x[1]+y[1])
def mul(x,y): return (x[0]*y[0]+5*x[1]*y[1],x[0]*y[1]+x[1]*y[0])
def neg(x): return (-x[0],-x[1])
def scale(x,c): return (x[0]*c,x[1]*c)
def pw(x,n):
 r=(F(1),F(0))
 for _ in range(n):r=mul(r,x)
 return r
zero=(F(0),F(0));one=(F(1),F(0));half=(F(1,2),F(0))
phi2=(F(1,4),F(1,4));invphi2=(F(-1,4),F(1,4))
T=[]
for j in range(4):
 for sign in [-1,1]:
  q=[zero]*4;q[j]=scale(one,sign);T.append(tuple(q))
T += [tuple(scale(half,v) for v in signs) for signs in product([-1,1],repeat=4)]
Is=set(T)
for per in permutations(range(4)):
 if sum(per[i]>per[j] for i in range(4) for j in range(i+1,4))%2:continue
 for signs in product([-1,1],repeat=3):
  v=[zero]+[scale(x,y) for x,y in zip([half,phi2,invphi2],signs)]
  Is.add(tuple(v[j] for j in per))
Is=sorted(Is)
ok('Icosahedral coordinate count',len(Is)==120,{'count':len(Is)})

# Even-coordinate moments of 2O are rational because the added vertices have
# exactly two nonzero coordinates of magnitude 1/sqrt2. Their odd moments
# vanish by independent sign reversals, as for the two other coordinate sets.
O_sq=[tuple(F(x[0]*x[0]+5*x[1]*x[1]) for x in q) for q in T]
for i in range(4):
 for j in range(i+1,4):
  for _ in range(4):
   q=[F(0)]*4;q[i]=q[j]=F(1,2);O_sq.append(tuple(q))
T_sq=[tuple(mul(x,x) for x in q) for q in T]
I_sq=[tuple(mul(x,x) for x in q) for q in Is]
def haar(es):
 n=sum(es)
 return F(__import__('functools').reduce(lambda a,b:a*b,(factorial(2*k)//factorial(k) for k in es),1),4**n*factorial(n+1))
def avg_ext(sq,es):
 acc=zero
 for q in sq:
  v=one
  for x,n in zip(q,es):v=mul(v,pw(x,n))
  acc=add(acc,v)
 return scale(acc,F(1,len(sq)))
def avg_rat(sq,es):return sum((__import__('functools').reduce(lambda a,b:a*b,(x**n for x,n in zip(q,es)),F(1)) for q in sq),F(0))/len(sq)
for name,sq,limit,external in [('2T',T_sq,2,True),('2O',O_sq,3,False),('2I',I_sq,5,True)]:
 count=0
 for es in product(range(limit+1),repeat=4):
  if sum(es)>limit:continue
  h=haar(es);v=avg_ext(sq,es) if external else (avg_rat(sq,es),F(0))
  ok(name+' even moment '+str(es),v==(h,F(0)),{'exponents':str(tuple(2*n for n in es)),'value':str(h)})
  count+=1
 checks.append({'check':name+' design summary','passed':True,'result':{'even_monomials':count,'odd_moments':'zero by coordinate sign symmetry','degree_strength':2*limit+1}})
for name,sq,n,external in [('2T',T_sq,3,True),('2O',O_sq,4,False),('2I',I_sq,6,True)]:
 es=(n,0,0,0);v=avg_ext(sq,es) if external else (avg_rat(sq,es),F(0));h=haar(es)
 ok(name+' first failed even moment',v!=(h,F(0)),{'finite':str(v[0]),'haar':str(h),'degree':2*n})

# Independently enumerate A5 and its five vertex stabilizers. These are the
# projective tetrahedral cores; each pair intersects in a cyclic order-three
# subgroup, whose binary lift is order six.
def parity(p):return sum(p[i]>p[j] for i in range(len(p)) for j in range(i+1,len(p)))%2
def comp(p,q):return tuple(p[q[j]] for j in range(len(p)))
def inv(p):return tuple(p.index(j) for j in range(len(p)))
A5=[p for p in permutations(range(5)) if parity(p)==0]
cores=[{p for p in A5 if p[j]==j} for j in range(5)]
sizes=[len(cores[i]&cores[j]) for i in range(5) for j in range(i+1,5)]
ok('Five projective tetrahedral cores',len(A5)==60 and all(len(c)==12 for c in cores) and sizes==[3]*10,{'A5_order':60,'cores':5,'core_orders':[12]*5,'pairwise_intersection_orders':sizes})

# Matrix presentation controls for abstract scalar torsion automorphisms.
def mm(A,B,p):return tuple(sum(A[2*i+k]*B[2*k+j] for k in range(2))%p for i in range(2) for j in range(2))
def mp(A,n,p):
 r=(1,0,0,1)
 for _ in range(n):r=mm(r,A,p)
 return r
def gen(gs,p):
 seen={(1,0,0,1)};todo=list(seen)
 while todo:
  a=todo.pop()
  for b in gs:
   c=mm(a,b,p)
   if c not in seen:seen.add(c);todo.append(c)
 return seen
for p in [3,5]:
 allm={a for a in product(range(p),repeat=4) if (a[0]*a[3]-a[1]*a[2])%p==1}
 A=(0,p-1,1,0);B=(0,p-1,1,1);minus=(p-1,0,0,p-1)
 G=gen([A,B],p)
 ok('Scalar SL2F'+str(p)+' binary triangle presentation',G==allm and mp(A,2,p)==minus and mp(B,3,p)==minus and mp(mm(A,B,p),p,p)==minus,{'order':len(G),'A_squared':'-I','B_cubed':'-I','AB_power':p,'AB_power_value':'-I'})

out={'kind':'E3-INDEPENDENT-EXACT','target_label':'p2e:thm:joint-exceptional-core-support-ledger','lineage':'Explicit exceptional quaternion coordinate moments; permutation A5 stabilizers; finite SL2 fields. No occurrence status imported.','checks_count':len(checks),'all_passed':True,'checks':checks}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'checks_count':len(checks),'all_passed':True}))
