#!/usr/bin/env python3
"""Independent finite checks of EXISTING IV-C v1_42 claims, source lines 8564-10128.
No existing manuscripts or theory content are altered. All results are scoped to
specific finite test instances and do not constitute universal E3 proof.
"""
from __future__ import annotations
import json, hashlib, math, os
from pathlib import Path
from itertools import combinations, product
import numpy as np
from numpy.linalg import norm, eigvalsh
from scipy.linalg import expm, logm, sqrtm, block_diag
from scipy.integrate import solve_ivp
from collections import defaultdict
OUT=Path(__file__).with_suffix('.json')
SOURCE=Path('/mnt/data/bh4c_work/papers/Paper00-PapersMinimal-v2_371/Paper4C-TechnicalMaterial-v1_42.tex')
rng=np.random.default_rng(2406)
I=np.eye
PAULIX=np.array([[0,1],[1,0]],complex)
PAULIZ=np.diag([1.,-1.]).astype(complex)
PAULIY=np.array([[0,-1j],[1j,0]],complex)
checks=[]

def record(name,claim,result,truth=True,kind='E3',detail=None):
    ok=bool(truth)
    if not ok: raise AssertionError((name,claim,result,detail))
    checks.append({'id':f'BH-IVC-B6-{kind}-{sum(c["kind"]==kind for c in checks)+1:03}',
                   'kind':kind,'name':name,'source_claim':claim,'passed':ok,
                   'numeric_residual':float(np.real(result)) if result is not None else None,
                   'details':detail or '', 'scope':'finite exact/numerical instance; not a universal proof'})

def zero(x,scale=1,tol=1e-9): return norm(x,ord=2) if isinstance(x,np.ndarray) and x.ndim==2 else np.max(np.abs(np.asarray(x)))
def t_close(a,b,tol=1e-9):return zero(np.asarray(a)-np.asarray(b)) <=tol

def car(d):
    n=2**d
    aas=[]
    for mode in range(d):
        a=np.zeros((n,n),complex)
        for bits in range(n):
            if (bits>>mode)&1:
                new=bits^(1<<mode)
                a[new,bits]=(-1)**((bits&((1<<mode)-1)).bit_count())
        aas.append(a)
    return aas

def gamma_h(h):
    aa=car(h.shape[0]); D=aa[0].shape[0]
    return sum((h[i,j]*aa[i].conj().T@aa[j] for i in range(len(aa)) for j in range(len(aa))),np.zeros((D,D),complex))

def occ_indices(d,k):return [tuple(v) for v in combinations(range(d),k)]

def gamma_W(W):
    d=W.shape[0];dim=2**d;ans=np.zeros((dim,dim),complex)
    for k in range(d+1):
        for tuplei in occ_indices(d,k):
            bi=sum(1<<i for i in tuplei)
            for tuplej in occ_indices(d,k):
                bj=sum(1<<j for j in tuplej)
                ans[bi,bj]=np.linalg.det(W[np.ix_(tuplei,tuplej)]) if k else 1
    return ans

def canonical_rho(n):
    # For diagonal covariance only (sufficient for direct numerical checks)
    vals=np.real(np.diag(n));d=len(vals)
    rho=np.diag([np.prod([vals[i] if (bits>>i)&1 else (1-vals[i]) for i in range(d)]) for bits in range(2**d)]).astype(complex)
    return rho

def randherm(dim,scale=0.25):
    a=rng.normal(size=(dim,dim))+1j*rng.normal(size=(dim,dim))
    return scale*(a+a.conj().T)/2

def pure_density(vector): return np.outer(vector,vector.conj())

# I. Auxiliary pair, fixed port and source commutator checks
for d in [2]:
    dim=1+10
    pair=[np.zeros((dim,dim),complex) for _ in range(10)]
    for i in range(10):pair[i][0,i+1]=1
    mu,nu=2,7
    comm=pair[mu]@pair[nu].conj().T-pair[nu].conj().T@pair[mu]
    expect=-(np.outer(I(dim)[:,nu+1],I(dim)[mu+1,:]))
    record('rank-one pair boundary', 'p4:lem:v2174-aux-pair-boundary',zero(comm-expect),t_close(comm,expect))
    creator=pair[4].conj().T
    record('pair graded creator square zero','p4:lem:v2174-aux-pair-boundary',zero(creator@creator), t_close(creator@creator,0))

# Exact truncated boson coordinates d=2, total cap N
def boson_a(d,N):
    occupations=[tuple(v) for n in range(N+1) for v in product(range(n+1),repeat=d) if sum(v)==n]
    dim=len(occupations);lookup={v:i for i,v in enumerate(occupations)}
    ladd=[]
    for m in range(d):
        a=np.zeros((dim,dim),complex)
        for v,i in lookup.items():
            if v[m]:
                x=list(v);x[m]-=1
                a[lookup[tuple(x)],i]=math.sqrt(v[m])
        ladd.append(a)
    return occupations,ladd
for N in [1,2,3]:
    occ,aas=boson_a(2,N);zeroidx=occ.index((0,0));vac=I(len(occ))[:,zeroidx]
    units=0
    for i,x in enumerate(occ):
        for j,y in enumerate(occ):
            left=I(len(occ));right=I(len(occ));fac=1
            for mode in range(2):
                left=left@np.linalg.matrix_power(aas[mode].conj().T,x[mode]);right=right@np.linalg.matrix_power(aas[mode],y[mode]);fac*=math.factorial(x[mode])*math.factorial(y[mode])
            M=left@pure_density(vac)@right/math.sqrt(fac)
            ans=np.outer(I(len(occ))[:,i],I(len(occ))[j,:]);units=max(units,zero(M-ans))
    record('fixed-port full matrix-unit generation cap '+str(N),'p4:prop:v2174-fixed-port-intertwiners',units,units<1e-12)

# Reversal odd comparison from appendix
H=np.array([[1,2+1j],[2-1j,-1]],complex);Q=np.diag([0,-2]);rho=np.ones((2,2),complex)/2
for t in [0.13,0.41]:
    U=expm(-1j*H*t);V=expm(-1j*H.conj()*t)
    q=.5*np.trace(rho@(U.conj().T@Q@U-V.conj().T@Q@V))
    target=np.sin(np.sqrt(24)*t)/np.sqrt(6)
    record('reversal odd source comparison t='+str(t),'p4:v2171:app:fullchainchecks',abs(q-target),abs(q-target)<1e-12)

# Frozen Ward projection identity (with noncommuting parent, both signs)
H=randherm(5);G=randherm(5);P=np.diag([1,1,1,0,0]).astype(complex);Qp=I(5)-P
lhs=(P@H@P)@(P@G@P)-(P@G@P)@(P@H@P)-P@(H@G-G@H)@P
rhs=P@G@Qp@H@P-P@H@Qp@G@P
record('projected Ward commutator boundary','p4:app:v4106-cutoff-ward-defect',zero(lhs-rhs),t_close(lhs,rhs))

# II. Interacting vertex moments and spectral source observations
A=car(2);h=np.array([[0,0.41],[0.41,0]],complex);Tmat=np.array([[0.16,0.04],[0.04,0.12]],complex)
HB=np.diag([0.,1.31]).astype(complex);X=PAULIX
Ht=np.kron(gamma_h(h),I(2))+np.kron(I(4),HB)+np.kron(gamma_h(Tmat),X)
vac_f=I(4)[:,0];vac_b=I(2)[:,0];omega=np.kron(vac_f,vac_b)
j=np.array([1,0],complex)
create=np.kron(A[0].conj().T,I(2));src=create@omega
# Shift off bosonic ground E_B = 0
mu1=np.vdot(src,Ht@src);mu2=np.vdot(Ht@src,Ht@src)
expect1=np.vdot(j,h@j);expect2=np.vdot(j,h@h@j)+np.vdot(Tmat@j,Tmat@j)*np.vdot(X@vac_b,X@vac_b)
record('stationary vertex mu1','p4:prop:v2168-product-unit-vertex-moment',abs(mu1-expect1),abs(mu1-expect1)<1e-12)
record('stationary vertex mu2 Gram','p4:prop:v2168-product-unit-vertex-moment',abs(mu2-expect2),abs(mu2-expect2)<1e-12)
comm=Ht@create-create@Ht
pred=np.kron((A[0].conj().T*h[0,0]+A[1].conj().T*h[1,0]),I(2))+np.kron((A[0].conj().T*Tmat[0,0]+A[1].conj().T*Tmat[1,0]),X)
record('current vertex CAR first commutator','p4:prop:v2168-product-unit-vertex-moment',zero(comm-pred),t_close(comm,pred))

M=np.diag([2.,3.,5.]); tcol=np.array([[1.],[0.],[0.]])
L=np.block([[np.zeros((3,3)),M,np.zeros((3,1))],[M,np.zeros((3,3)),tcol],[np.zeros((1,3)),tcol.conj().T,np.zeros((1,1))]])
J=np.vstack((I(3),np.zeros((4,3))))
mu2=J.conj().T@L@L@J;mu4=J.conj().T@np.linalg.matrix_power(L,4)@J
record('fourth moment leakage positive diagonal','p4:prop:v2168-product-unit-vertex-moment',zero(mu4-np.linalg.matrix_power(M,4)-np.diag([4.,0,0])),t_close(mu4-np.linalg.matrix_power(M,4),np.diag([4.,0,0])))
for z in [1.5+0.8j,3.1+0.5j]:
    g=(J.conj().T@np.linalg.inv(z*I(7)-L)@J)[0,0]
    exp=(z*z-1)/(z*(z*z-5))
    record('fourth moment witness exact resolvent '+str(z),'p4:prop:v2168-product-unit-vertex-moment',abs(g-exp),abs(g-exp)<1e-12)

# Adversarial false inference: a true higher-sector interaction is invisible to vacuum linear sources.
cc=car(2);n0=cc[0].conj().T@cc[0];n1=cc[1].conj().T@cc[1]
HV=0.47*n0@n1;omega_f=I(4)[:,0]
q=cc[0].conj().T;first=q@omega_f
record('quartic vertex nonzero but linear-vacuum response unchanged','p4:cor:v2168-source-invisible-interaction',norm(HV,2),norm(HV,2)>0 and norm(HV@first)<1e-12,kind='E4',detail='n0 n1 is nonzero on |11> but annihilates vacuum and one-particle sectors')

# III. Detector, partial trace and Gaussian jets
psi=rng.normal(size=3)+1j*rng.normal(size=3);psi=psi/norm(psi)
Sm=expm(1j*randherm(3));Sn=expm(1j*randherm(3));
F=randherm(3); e,v=np.linalg.eigh(F);Qm=v@np.diag([0.11,0.42,0.87])@v.conj().T
F=randherm(3); e,v=np.linalg.eigh(F);Qn=v@np.diag([0.2,0.57,0.73])@v.conj().T
eta=norm((Sm-Sn)@psi);ds=norm(Qm-Qn,2)
pm=np.vdot(Sm@psi,Qm@(Sm@psi)).real;pn=np.vdot(Sn@psi,Qn@(Sn@psi)).real
record('detector probability stability','p4:prop:v2210-lit-detector-stability',abs(pm-pn)/(2*eta+ds),abs(pm-pn)<=2*eta+ds+1e-12)
fm,fn=1.7,1.71;df=abs(fm-fn);bound=(2*eta+ds)/min(fm,fn)+df/min(fm,fn)**2
record('flux ratio stability','p4:prop:v2210-lit-detector-stability',abs(pm/fm-pn/fn)/bound,abs(pm/fm-pn/fn)<=bound+1e-12)
raw=rng.normal(size=(6,6))+1j*rng.normal(size=(6,6));rr=raw@raw.conj().T;rr/=np.trace(rr)
Qh=np.diag([0.9,0.4,0.05]);F1=(I(2)+PAULIX)/2;F2=I(2)-F1
combined=np.trace(rr@np.kron(Qh,F1))+np.trace(rr@np.kron(Qh,F2))
res=np.trace(rr@np.kron(Qh,I(2)))
record('inclusive hard soft POVM identity','p4:cor:v2210-lit-inclusive-soft',abs(combined-res),abs(combined-res)<1e-12)

# Derivatives of log determinant by polynomial exact symbolic on diagonal and general matrix finite differences
Q0=np.array([[2.1,.3],[.3,1.8]],complex);Q1=np.array([[.23,.08],[.08,-.19]],complex);Q2=np.array([[.15,.03],[.03,.07]],complex);Q3=np.array([[.02,.01],[.01,-.01]],complex)
# Q(t)=Q0+t Q1+ (t^2/2)Q2+(t^3/6)Q3
G0=np.linalg.inv(Q0)
formal=[np.trace(G0@Q1),np.trace(G0@Q2-G0@Q1@G0@Q1),np.trace(G0@Q3-3*G0@Q1@G0@Q2+2*np.linalg.matrix_power(G0@Q1,3))]
def lgdet(x):
    mat=Q0+x*Q1+(x*x/2)*Q2+(x*x*x/6)*Q3
    return np.log(np.linalg.det(mat))
h=.002
approx=[(lgdet(h)-lgdet(-h))/(2*h),(lgdet(h)-2*lgdet(0)+lgdet(-h))/h**2,(lgdet(2*h)-2*lgdet(h)+2*lgdet(-h)-lgdet(-2*h))/(2*h**3)]
for k in range(3):
    record('Gaussian log determinant derivative '+str(k+1),'p4:thm:v2210-lit-determinant-jets',abs(formal[k]-approx[k]),abs(formal[k]-approx[k])<4e-5)

# IV. Arbitrary-state polynomial and quasifree compression
W=expm(1j*randherm(3,0.7))
raw=rng.normal(size=(8,8))+1j*rng.normal(size=(8,8));rhoF=raw@raw.conj().T;rhoF/=np.trace(rhoF)
A=car(3); source=0+0j
D=W-I(3)
for k in range(4):
    for ix in occ_indices(3,k):
        for jy in occ_indices(3,k):
            Ai=I(8);Aj=I(8)
            for i in ix: Ai=Ai@A[i].conj().T
            for j in reversed(jy): Aj=Aj@A[j]
            # rho times normal-ordered monomial with derivative matrix minors
            source+=np.linalg.det(D[np.ix_(ix,jy)])*np.trace(rhoF@Ai@Aj) if k else np.trace(rhoF)
gam=np.trace(rhoF@gamma_W(W))
record('complete occupied-correlation minor polynomial','p4c:thm:v247-source-correlation-polynomial',abs(source-gam),abs(source-gam)<1e-11)
for n in [np.diag([.1,.4,.75]),np.diag([.3,.6,.6])]:
    state=canonical_rho(n); lhs=np.trace(state@gamma_W(W));rhs=np.linalg.det(I(3)-n+n@W)
    record('quasifree determinant compression','p4c:cor:v247-correlation-determinant-compression',abs(lhs-rhs),abs(lhs-rhs)<1e-11)
rc=np.diag([.5,0,0,.5]);rq=I(4)/4;WX=1j*I(2)
Z1=np.trace(rc@gamma_W(WX));Z2=np.trace(rq@gamma_W(WX))
record('covariance insufficient nonGaussian control','p4c:cor:v247-correlation-determinant-compression',abs(Z1-Z2),abs(Z1)<1e-12 and abs(Z2-0.5j)<1e-12,kind='E4',detail='same C=I/2 yet trace influences differ 0 and i/2')

# V. Current path sum, arbitrary joint correlations, noncommuting boson ports
h=randherm(2,0.3);hb=randherm(2,0.4);Ts=[randherm(2,0.25),randherm(2,0.25)]
Xs=[PAULIX,PAULIZ];delta=0.31
rhoF=canonical_rho(np.diag([.2,.7]));
braw=rng.normal(size=(2,2))+1j*rng.normal(size=(2,2));rhoB=braw@braw.conj().T;rhoB/=np.trace(rhoB)

def make_branches(h,hb,Ts,Xs,delta):
    fw=expm(-1j*delta*h);fb=expm(-1j*delta*hb)
    branches=[(fw,fb)]
    for T,X in zip(Ts,Xs):
        eigvals,vec=np.linalg.eigh(X)
        update=[]
        for wa,ma in branches:
            for k,x in enumerate(eigvals):
                Pr=np.outer(vec[:,k],vec[:,k].conj())
                update.append((wa@expm(-1j*delta*x*T),ma@Pr))
        branches=update
    return branches

hp=(h,hb,Ts,Xs); hm=(h+0.11*PAULIZ,hb-0.15*PAULIX,[Ts[0]+0.05*PAULIY,Ts[1]],Xs)
bp=make_branches(*hp,delta);bm=make_branches(*hm,delta)

def buildU(parts,delta):
    h,hb,Ts,Xs=parts
    terms=[np.kron(gamma_h(h),I(2)),np.kron(I(4),hb)]+[np.kron(gamma_h(T),X) for T,X in zip(Ts,Xs)]
    U=I(8).astype(complex)
    for term in terms:U=U@expm(-1j*delta*term)
    return U,terms
Up,tp=buildU(hp,delta);Um,tm=buildU(hm,delta)
Up_branch=sum((np.kron(gamma_W(w),B) for w,B in bp),np.zeros((8,8),complex))
Um_branch=sum((np.kron(gamma_W(w),B) for w,B in bm),np.zeros((8,8),complex))
record('noncommuting spectral-branch decomposition plus','p4:thm:v248-current-determinant-sum',zero(Up-Up_branch),t_close(Up,Up_branch))
record('noncommuting spectral-branch decomposition minus','p4:thm:v248-current-determinant-sum',zero(Um-Um_branch),t_close(Um,Um_branch))
rho=np.kron(rhoF,rhoB)
Zfull=np.trace(Up@rho@Um.conj().T)
Zpath=sum(np.trace(Bp@rhoB@Bm.conj().T)*np.linalg.det(I(2)-np.diag([.2,.7])+np.diag([.2,.7])@wm.conj().T@wp) for wp,Bp in bp for wm,Bm in bm)
record('interacting determinant path sum','p4:thm:v248-current-determinant-sum',abs(Zpath-Zfull),abs(Zpath-Zfull)<1e-11)
record('exact equal-history unitarity','p4:cor:v248-interacting-parent-error',abs(np.trace(Up@rho@Up.conj().T)-1),abs(np.trace(Up@rho@Up.conj().T)-1)<1e-12)

# Path evaluator on entangled, not quasifree, joint pure state
rv=rng.normal(size=8)+1j*rng.normal(size=8);rv=rv/norm(rv);rr=pure_density(rv)
C=car(2)
def bosval_corr(i,j):
    op=I(4)
    for k in j:op=op@C[k].conj().T
    for k in reversed(i):op=op@C[k]
    # partial trace over Fermion: R_(i,j) = sum_ff' O_(f,f') rho_(f',b;f,b')
    T=rr.reshape(4,2,4,2)
    return np.einsum('ac,cbad->bd',op,T)

Zjoint=0+0j
for wp,Bp in bp:
    for wm,Bm in bm:
        D=wm.conj().T@wp-I(2)
        B=Bm.conj().T@Bp
        for k in range(3):
            for ix in occ_indices(2,k):
                for jy in occ_indices(2,k):
                    # R_(j,i), where i,j are exterior minor (row creation i, column annihilation j)
                    Zjoint+=np.linalg.det(D[np.ix_(ix,jy)])*np.trace(bosval_corr(jy,ix)@B) if k else np.trace(bosval_corr((),())@B)
Ztarget=np.trace(Up@rr@Um.conj().T)
record('arbitrary entangled CAR boson influence evaluator','p4:cor:v248-joint-state-interacting-determinants',abs(Zjoint-Ztarget),abs(Zjoint-Ztarget)<1e-11)

# Adversarial controls: noncommuting port reordering; non-product joint state
# These refute stronger simplified claims, not the exact conditional theorem.
# A naive swapped order of the two vertex unitary factors is not generally exact.
plus_terms=tp
wrong=expm(-1j*delta*plus_terms[0])@expm(-1j*delta*plus_terms[1])@expm(-1j*delta*plus_terms[3])@expm(-1j*delta*plus_terms[2])
wrongdiff=norm(Up-wrong,2)
record('noncommuting port order cannot be dropped','p4:thm:v248-current-determinant-sum',wrongdiff,wrongdiff>1e-5,kind='E4',detail='sliced operators X and Z noncommute, reversing their source order changes U')
# Wrong product-state quasifree approximation to entangled joint preparation.
# Take its marginals, and compare their exact trace influence with joint trace.
rF=np.einsum('abcb->ac',rr.reshape(4,2,4,2));rB=np.einsum('abad->bd',rr.reshape(4,2,4,2))
wrongjoint=np.trace(Up@np.kron(rF,rB)@Um.conj().T)
record('entangled joint state requires boson-valued correlations','p4:cor:v248-joint-state-interacting-determinants',abs(Ztarget-wrongjoint),abs(Ztarget-wrongjoint)>1e-7,kind='E4',detail='discarding F-B correlations by tensor product of marginals changes exact influence')

# VI. Quartic discrete spectral decoupling and Trotter error
S=randherm(3,0.5);F=gamma_h(S);q_eval,q_vec=np.linalg.eigh(F)
x=np.unique(np.round(q_eval,10))
s=.32;zr=np.exp(1j*s*x);N=len(x)
V=np.vstack([zr**k for k in range(N)]).T
params=np.linalg.solve(V,np.exp(-1j*.27*.61*x*x))
reconstruct=sum((params[k]*expm(1j*k*s*F) for k in range(N)),np.zeros_like(F))
actual=expm(-1j*.27*.61*F@F)
record('finite quartic square Vandermonde decoupling','p4:lem:v248-quartic-discrete-decoupling',zero(reconstruct-actual),t_close(reconstruct,actual,tol=3e-9))

# Nonautonomous matrix whose Trotter error is rigorously bounded
H0=randherm(3,0.4);H1=randherm(3,0.35);Dtime=randherm(3,0.3)
N=12;step=.5/N;Ttime=.5
Uapprox=I(3).astype(complex)
for j in range(N):
    tj=j*step
    Uapprox=expm(-1j*step*(H0+tj*Dtime))@expm(-1j*step*H1)@Uapprox

def ode(t,y):
    A=y.reshape((3,3));return (-1j*(H0+t*Dtime+H1)@A).reshape(-1)
sol=solve_ivp(ode,[0,Ttime],I(3).astype(complex).reshape(-1),rtol=1e-12,atol=1e-13)
Ureal=sol.y[:,-1].reshape((3,3))
L=norm(Dtime,2); Csplit=max(norm((H0+t*Dtime)@H1-H1@(H0+t*Dtime),2) for t in np.linspace(0,Ttime,200))
bound=Ttime*step/2*(L+Csplit)
record('sliced propagator L plus commutator norm bound','p4:thm:v248-current-determinant-sum',norm(Ureal-Uapprox,2)/bound,norm(Ureal-Uapprox,2)<=bound+1e-8)

# VII. log tube and exact influence-zero obstruction
Hone=randherm(3,0.4);dt=.6;D=randherm(3,0.15)
U1=expm(-1j*dt*Hone);U2=expm(-1j*dt*(Hone+D))
raw=rng.normal(size=(3,3))+1j*rng.normal(size=(3,3));rn=raw@raw.conj().T;rn/=np.trace(rn)
z=np.trace(U1@rn@U2.conj().T);rad=dt*norm(D,2)
record('Duhamel tube |Z-1| <= r','p4:prop:v249-uniform-log-tube',abs(z-1)/rad,abs(z-1)<=rad+1e-12)
for phase in [0.7,math.pi/2,math.pi]:
    ze=(np.cos(phase)+1)/2
    wanted=np.cos(phase/2)**2
    record('paired influence zero phase '+str(phase),'p4:prop:v249-paired-influence-zero',abs(ze-wanted),abs(ze-wanted)<1e-14,kind='E4' if abs(phase-math.pi)<1e-6 else 'E3',detail='at pi phase Z=0; no global finite complex logarithm')

# VIII. Jet bound of static source-controlled H_a with two noncommuting terms
AA=randherm(2,0.55);BB=randherm(2,0.4);CC=randherm(2,0.25);DD=randherm(2,0.25)
Ttime=0.75;num=16;dd=Ttime/num

def Ujet(q,approx):
    terms=[AA+q*BB,CC+.5*q*q*DD]
    if approx:
        U0=expm(-1j*dd*terms[0])@expm(-1j*dd*terms[1]);return np.linalg.matrix_power(U0,num)
    return expm(-1j*Ttime*sum(terms))
q=.08;st=1e-4
Ud=[Ujet(q,False),(Ujet(q+st,False)-Ujet(q-st,False))/(2*st),(Ujet(q+st,False)-2*Ujet(q,False)+Ujet(q-st,False))/(st*st)]
Un=[Ujet(q,True),(Ujet(q+st,True)-Ujet(q-st,True))/(2*st),(Ujet(q+st,True)-2*Ujet(q,True)+Ujet(q-st,True))/(st*st)]
ms0=norm(AA+q*BB,2)+norm(CC+.5*q*q*DD,2)
M11=norm(BB,2);M21=norm(q*DD,2);M22=norm(DD,2)
R=2*M11+2*M21+M22
cs=[]
for t in [q-.12,q,q+.12]:
    X=AA+t*BB;Y=CC+.5*t*t*DD
    cs.append([X@Y-Y@X,BB@Y-Y@BB+X@(t*DD)-(t*DD)@X,2*(BB@(t*DD)-(t*DD)@BB)+X@DD-DD@X])
Cbound=sum(max(norm(cs[i][k],2) for i in range(3)) for k in range(3))
Lhat=0;eps=Ttime*dd/2*np.exp(Ttime*R)*Cbound
for k in range(3):
    err=norm(Ud[k]-Un[k],2)
    record('uniform source jet k='+str(k),'p4:thm:v249-interacting-two-jet-convergence',err/eps,err<=eps+1e-7,detail=f'finite instance eps {eps:.4g}, err {err:.4g}; grid norm bounds include q=±0.12')

# IX. HS source realization, state bound, spectral cluster and Gibbs data
HH=np.diag([0.,1.5,2.7]).astype(complex);pr=np.array([.13,.27,.60]);rhod=np.diag(pr)
Qr=np.array([[0,1,0],[0,0,1],[0.2,0,0]],complex)
Qs=Qr.conj().T
Tliou=np.kron(HH,I(3))-np.kron(I(3),HH.T)
# vectorization row major: vec_r(HX-XH) = (H⊗I - I⊗H^T) vec_r(X)
def makeJ(H,Q,rho):
    dr=sqrtm(rho).astype(complex)
    return np.concatenate(((Q@dr).reshape(-1),(dr@Q).reshape(-1)))
Jr=makeJ(HH,Qr,rhod);Js=makeJ(HH,Qs,rhod)
z=1.2+.7j
RR=np.linalg.inv(z*I(9)-Tliou)
val=Jr.conj()@block_diag(RR,RR)@Js
X=np.linalg.solve(z*I(9)-Tliou,Qs.reshape(-1)).reshape((3,3))
expect=np.trace(rhod@(Qr.conj().T@X+X@Qr.conj().T))
record('Hilbert-Schmidt anticommutator resolvent realization','p4:thm:v249-source-hs-realization',abs(val-expect),abs(val-expect)<1e-12)
# positive residues by explicit pair support
atfreq=1.5;total=sum((pr[m]+pr[n])*abs(Qr[m,n])**2 for m in range(3) for n in range(3) if abs((HH[m,m].real-HH[n,n].real)-atfreq)<1e-8)
record('positive source visible weight source eigenpair','p4:thm:v249-source-hs-realization',total,total>=0)

RRb=randherm(3,0.15);rho2=expm(-RRb);rho2/=np.trace(rho2)
RRa=randherm(3,0.15);rho1=expm(-RRa);rho1/=np.trace(rho1)
Dsq=sqrtm(rho1).astype(complex)-sqrtm(rho2).astype(complex)
trace_norm=sum(abs(np.linalg.eigvalsh(rho1-rho2)))
record('sqrt state HS perturbation bound','p4:lem:v249-source-state-error',norm(Dsq,'fro')**2/trace_norm,norm(Dsq,'fro')**2<=trace_norm+1e-12)
Qtilde=Qr+.04*PAULIX if Qr.shape==(2,2) else Qr+.04*I(3)
J1=makeJ(HH,Qr,rho1);J2=makeJ(HH,Qtilde,rho2)
bound=np.sqrt(2)*norm(Qr-Qtilde,2)+np.sqrt(2)*norm(Qtilde,2)*np.sqrt(trace_norm)
record('source-state J perturbation bound','p4:lem:v249-source-state-error',norm(J1-J2)/bound,norm(J1-J2)<=bound+1e-12)

H1=np.diag([0,1,2.2]).astype(complex)
H2=H1+np.array([[0.,.03,0.],[.03,.015,.01],[0.,.01,-.02]])
p=np.array([.3,.3,.4]); # stationarity enforced by using thermal states in eigenbases
rho1=expm(-1.2*H1);rho1/=np.trace(rho1)
rho2=expm(-1.2*H2);rho2/=np.trace(rho2)
J1=makeJ(H1,Qr,rho1);J2=makeJ(H2,Qr,rho2)
T1=np.kron(H1,I(3))-np.kron(I(3),H1.T);T2=np.kron(H2,I(3))-np.kron(I(3),H2.T)
D1=block_diag(T1,T1);D2=block_diag(T2,T2)
E=2*norm(H1-H2,2);eta=norm(J1-J2);ja=norm(J1);jb=norm(J2)
z=1.7+1.0j;d=abs(z.imag)
for k in [0,1,2]:
    G1=(-1)**k*math.factorial(k)*np.vdot(J1,np.linalg.matrix_power(np.linalg.inv(z*I(18)-D1),k+1)@J1)
    G2=(-1)**k*math.factorial(k)*np.vdot(J2,np.linalg.matrix_power(np.linalg.inv(z*I(18)-D2),k+1)@J2)
    bound=math.factorial(k)*((ja+jb)*eta/d**(k+1)+jb**2*(k+1)*E/d**(k+2))
    record('source resolvent z-derivative k='+str(k),'p4:thm:v249-certified-visible-poles',abs(G1-G2)/bound,abs(G1-G2)<=bound+1e-11)
# projector cluster using isolated reference frequency 1.0 (T2) vs T1
refevals=np.linalg.eigvalsh(T1);refw=1.0;g=min(abs(v-refw) for v in refevals if abs(v-refw)>1e-8)
r=.5*g
# E is small<r. compare projectors as spectral indicator
v1,V1=np.linalg.eigh(T1);v2,V2=np.linalg.eigh(T2)
P1=V1[:,abs(v1-refw)<r]@V1[:,abs(v1-refw)<r].conj().T
P2=V2[:,abs(v2-refw)<r]@V2[:,abs(v2-refw)<r].conj().T
Pbound=E/(r-E)
record('visible pole Riesz projection stability','p4:thm:v249-certified-visible-poles',norm(P1-P2,2)/Pbound, E<r and norm(P1-P2,2)<=Pbound+1e-12)
record('visible pole rank preservation','p4:thm:v249-certified-visible-poles',abs(np.linalg.matrix_rank(P1, tol=1e-7)-np.linalg.matrix_rank(P2,tol=1e-7)),np.linalg.matrix_rank(P1,tol=1e-7)==np.linalg.matrix_rank(P2,tol=1e-7))

# Adversarial negative control: full Liouvillian spectrum versus source-visible pole set.
# Identity source has no off-diagonal transition despite distinct energy gaps.
Qdark=I(3)
Jdark=makeJ(H1,Qdark,rho1)
E0,V0=np.linalg.eigh(T1)
off=np.flatnonzero(np.abs(E0-1.)<1e-8)
offw=norm(V0[:,off].conj().T@Jdark[:9])**2+norm(V0[:,off].conj().T@Jdark[9:])**2
record('nonzero Liouvillian eigenvalue can be source-dark','p4:thm:v249-source-hs-realization',offw,offw<1e-12,kind='E4',detail='H has a nonzero gap but identity Q has only frequency zero in its response')

# C(t) Laplace bridge, evaluate scalar source via exact resolvent in stable upper half-plane
z=0.8+2j;J=J1;D=D1
G=np.vdot(J,np.linalg.solve(z*I(len(D))-D,J))
ww,VV=np.linalg.eigh(D);weights=np.abs(VV.conj().T@J)**2
Lap=np.sum(weights/(z-ww))
record('finite Laplace exact spectral bridge','p4:cor:v249-correlation-resolvent-bridge',abs(G-Lap),abs(G-Lap)<1e-12)

# Two-spin even/odd Gibbs/error bounds
pE0=np.array([0.4,0.7,0.6,0.15]);pE1=np.array([0.405,0.68,0.64,0.17])
# [epsilon0,epsilon1,v,g]
def two_spin(p):
    e0,e1,v,g=p
    out=np.diag([0.,e0,e1,e0+e1+v]).astype(complex)
    out[0,3]=out[3,0]=g
    return out
H0=two_spin(pE0);Hn=two_spin(pE1);dH=Hn-H0
dE=sum((pE1-pE0)[:3]);dg=(pE1-pE0)[3]
calc=max(abs((pE1-pE0)[0]),abs((pE1-pE0)[1]),abs(dE)/2+math.sqrt((dE/2)**2+dg**2))
record('interacting paired Hamiltonian norm exact','p4:cor:v249-paired-coefficient-certification',abs(norm(dH,2)-calc),abs(norm(dH,2)-calc)<1e-12)
beta=1.9
s0=expm(-beta*H0);s0/=np.trace(s0)
s1=expm(-beta*Hn);s1/=np.trace(s1)
dist=sum(abs(np.linalg.eigvalsh(s0-s1)))
record('finite Gibbs state norm sensitivity','p4:cor:v249-paired-coefficient-certification',dist/min(2,2*beta*calc),dist<=min(2,2*beta*calc)+1e-12)

result={'audit':'Paper4C','batch':6,'source_file':SOURCE.name,
        'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        'source_lines':[8564,10128],
        'check_count':len(checks),'passed_count':sum(x['passed'] for x in checks),
        'E3_count':sum(x['kind']=='E3' for x in checks),
        'E4_count':sum(x['kind']=='E4' for x in checks),
        'checks':checks,'limitation':'Constructive finite cases test source identities; do not replace E1 full proof replay or prove physical constructor/realization.'}
OUT.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'checks':result['check_count'],'passed':result['passed_count'],'E3':result['E3_count'],'E4':result['E4_count'],'outfile':str(OUT)},indent=2))
