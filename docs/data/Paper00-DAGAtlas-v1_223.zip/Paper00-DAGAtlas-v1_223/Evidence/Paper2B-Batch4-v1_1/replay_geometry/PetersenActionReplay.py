"""Exact E1 action replay for the imported signed Petersen cochain module.
Current source owner is Paper1A-Geometry-v5_163.tex, especially
p1:thm:petersen-fifteen-resolution and p1:thm:v339-petersen-sl4-isometry.
The ordinary unoriented permutation action is retained as a negative control.
"""
import itertools,json
from pathlib import Path
n=5
vertices=list(itertools.combinations(range(n),2));vi={v:i for i,v in enumerate(vertices)}
edges=[(a,b) for a in range(10) for b in range(a+1,10) if not set(vertices[a])&set(vertices[b])]
def even(p):return sum(p[i]>p[j] for i in range(n) for j in range(i+1,n))%2==0
def ctype(p):
 seen=set();ls=[]
 for i in range(n):
  if i in seen:continue
  j=i;k=0
  while j not in seen:seen.add(j);k+=1;j=p[j]
  ls.append(k)
 return tuple(sorted(ls,reverse=True))
classes={}
for p in itertools.permutations(range(n)):
 if not even(p):continue
 vmap=[vi[tuple(sorted(p[a] for a in v))] for v in vertices]
 signed=0;unsigned=0
 for a,b in edges:
  c,d=vmap[a],vmap[b]
  if (c,d)==(a,b):signed+=1;unsigned+=1
  if (c,d)==(b,a):signed-=1;unsigned+=1
 key=ctype(p)
 row=classes.setdefault(key,{'count':0,'signed':set(),'unsigned':set(),'vertex':set(),'standard4':set()})
 row['count']+=1;row['signed'].add(signed);row['unsigned'].add(unsigned)
 row['vertex'].add(sum(i==j for i,j in enumerate(vmap)))
 row['standard4'].add(sum(i==j for i,j in enumerate(p))-1)
checks=[]
def check(name,condition):
 assert condition,name
 checks.append(name)
check('Petersen vertex and edge counts',len(vertices)==10 and len(edges)==15)
check('A5 action has sixty elements',sum(c['count'] for c in classes.values())==60)
for key,row in classes.items():
 check('character constant on cycle type '+str(key),all(len(row[k])==1 for k in ['signed','unsigned','vertex','standard4']))
 for k in ['signed','unsigned','vertex','standard4']:row[k]=next(iter(row[k]))
 row['gradient9']=row['vertex']-1
 row['harmonic5']=row['gradient9']-row['standard4']
 row['cycle6']=row['signed']-row['gradient9']
expected={(1,1,1,1,1):(1,15,15),(2,2,1):(15,-1,3),(3,1,1):(20,0,0),(5,):(24,0,0)}
for k,(count,s,u) in expected.items():
 check('signed and unsigned characters '+str(k),(classes[k]['count'],classes[k]['signed'],classes[k]['unsigned'])==(count,s,u))
check('signed action has no trivial constituent',sum(row['count']*row['signed'] for row in classes.values())==0)
check('unsigned action has one trivial constituent',sum(row['count']*row['unsigned'] for row in classes.values())==60)
check('signed action character norm is four',sum(row['count']*row['signed']**2 for row in classes.values())==240)
check('standard4 multiplicity in signed cochains is one',sum(row['count']*row['signed']*row['standard4'] for row in classes.values())==60)
check('harmonic5 multiplicity in signed cochains is one',sum(row['count']*row['signed']*row['harmonic5'] for row in classes.values())==60)
check('cycle6 character norm is two',sum(row['count']*row['cycle6']**2 for row in classes.values())==120)
out={'evidence_level':'E1','action':'Signed oriented real edge cochains; reversing an oriented edge contributes minus sign.','checks_passed':len(checks),'checks':checks,'classes':{'-'.join(map(str,k)):v for k,v in classes.items()},'decomposition':'4 + 5 + 3 + 3prime','negative_control':'Ordinary unoriented fifteen-edge permutation module has an invariant constant and character15,3,0,0; it is a different representation.','binary_center':'The 2I action is pulled back through 2I/{+1,-1}=A5, so the binary center acts trivially.'}
Path(__file__).with_name('PetersenActionReplayResults.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'checks_passed':len(checks),'classes':out['classes']}))
