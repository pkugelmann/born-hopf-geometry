from pathlib import Path
import json,hashlib
r=Path('/workspace/scratch/6302724ed082')
p=r/'work/corpus/Paper2B-MomentumCarrier-v2_135.tex'
census=json.loads((r/'work/proposals/census/Paper2B-ClaimCensus-v1_1.json').read_text())['claims']
claims=[c for c in census if 2881<=c['complete_span']['start_line']<=3169]
checks={
'p2b:rem:v264-converse-firewall':dict(
 domain='Retrospective mathematical converses and physical-origin boundaries after the independent frozen-seed carrier proof.',
 reasoning=[
'The E9 types are (0,0), (1/2,1/2), (1/2,0), (0,1/2), whose maximal half-level is one. E9 lacks both adjoint object types, so m_p=1 does not imply exact H1 support.',
'The same abstract H1 representation can be obtained from a tensor prefix or a lower-ideal support definition. An output representation isomorphism therefore does not identify the physical gradient/bracket constructor ancestry.',
'The 15/137 algebra and quadratic fingerprint are mathematical reconstruction tests of their supplied data. They do not supply G0 token provenance or turn a covariant exchange operator into an occurring action, process or environmental interface.'
 ],
 imports=['p2:thm:momentum-host-H1','p2:thm:m1-component','p2b:thm:v264-algebra-rigidity','p2b:prop:v264-quadratic-inversion','p2b:thm:v264-canonical-paired-exchange'],
 conditions='Respect the direction of the support-to-level implication and preserve separate constructor/occurrence premises.'),
'p2b:prop:v318-petersen-vs-h1':dict(
 domain='Conditional occurring embedded 2I support and its A5 signed oriented Petersen edge-cochain module; compare with independent complex Spin(4) momentum module and 24-cell Bose–Mesner range.',
 reasoning=[
'The actual I-A owner defines W_P=C1(KG(5,2);R) as signed oriented edge cochains. Under a graph automorphism, reversing the chosen edge orientation contributes minus sign. It is not the ordinary unoriented fifteen-edge permutation module.',
'The source Hodge resolution has gradient types 4 and 5, plus two three-dimensional flux-cycle types 3 and 3prime. Its four orthogonal projector ranks sum to fifteen. The later explicit signed-edge isometry with sl4(R) preserves this module.',
'Exact action replay on all sixty even five-label permutations gives signed character values 15,−1,0,0 on identity, double transpositions, three-cycles and five-cycles. The ordinary unoriented action instead gives 15,3,0,0 and contains a trivial constituent. Using that alternative would attack a different theorem object.',
'The signed action is pulled back from A5, so the binary center of 2I acts trivially. Spinorial/quaternionic lifts are separate data and cannot be recovered from the unsigned incidence or matching dimension.',
'The three carriers have distinct source objects, real/complex types and actions: W_P is fifteen real dimensions, H1 is fifteen complex dimensions, and the Bose–Mesner range is a fifteen-dimensional subspace of functions on the separate 24-cell support. Dimension equality supplies no canonical map among them.',
'Even restricting a continuous representation to a finite subgroup specifies an action on its existing space, not an identification with a separately constructed edge or shell space. The target makes no claim that all conceivable intertwiners are zero.'
 ],
 imports=['p1:thm:petersen-fifteen-resolution','p1:thm:petersen-signed-and-flux','p1:thm:v339-petersen-sl4-isometry','p1:rem:v339-three-fifteens-firewall','p2a:thm:v318-petersen-same-owner-descent','p1:prop:math-twentyfourcell-bose-mesner','p2:thm:momentum-host-H1'],
 conditions='Supplied embedded 2I support and exact signed action; no universal exceptional-support selection or physical particle identification.',
 calculation_artifacts=['work/batch4/proposals/replay_geometry/PetersenActionReplay.py','work/batch4/proposals/replay_geometry/PetersenActionReplayResults.json']),
'p2b:rem:v318-petersen-momentum-scope':dict(
 domain='Scope-preservation remark about the independently derived intrinsic momentum package and a conditional additional finite comparison descendant.',
 reasoning=[
'The phrase “intrinsic result H_p≅H1” is unqualified notation in this remark, but it introduces no universal quantifier over all structured endpoints. Its “remain as before” clause inherits the earlier distinction between common generated support/one-copy presentation and the separately guarded universal endpoint theorem.',
'The preceding proposition separates the Petersen role from the momentum carrier, and the following conclusion explicitly says universal endpoint multiplicity-one holds only under the three GP3 comparison hypotheses. Thus the remark does not discharge those hypotheses or supply a contrary universal proof.',
'The finite comparison packet changes neither the frozen initial constructor frontier, the descriptor m_p=1, the coordinate-completion family nor any previously parameterized scale. It provides no new carrier multiplicity, component ceiling or level selector.'
 ],
 imports=['p2b:prop:v318-petersen-vs-h1','p2:thm:momentum-host-H1','p2:thm:m1-component','p2b:thm:momentum-carrier-rigidity','p2a:prop:v318-petersen-nonconverse'],
 conditions='Existing BH-IIB-STRUCTURED-RIGIDITY-001 and its three comparison guards continue to control any universal full-carrier reading.'),
'p2b:thm:v352-minimal-faithful':dict(
 domain='A nonzero finite-dimensional complex unital C*-algebra A=direct_sum_i M_di(C), with positive integer block sizes; finite-dimensional faithful unital *-representations.',
 reasoning=[
'The central identities of the simple summands are orthogonal projections summing to I in a unital representation. They split H into central-block spaces. Faithfulness forces each block space to be nonzero.',
'Every unital representation of M_di(C) is a direct sum of its defining di-dimensional module. Hence each block is C^di tensor C^mi with positive integer mi, and dim H=sum_i di mi.',
'The matrix-unit commutation relations force the commutant on one block to be I_di tensor M_mi(C). Central projections exclude cross-block commutant operators, even if two block sizes coincide.',
'The minimum dimension is sum_i di and equality holds exactly when all mi=1. At that minimum, each labeled simple block acts once, giving uniqueness up to a block-preserving unitary intertwiner.',
'The commutant equals the represented center exactly when every M_mi(C) is scalar, equivalently mi=1 for every block. This is a mathematical minimum for a supplied abstract algebra, not a GP3 physical comparison theorem.'
 ],
 imports=[],
 conditions='Finite-dimensional, complex, faithful, unital *-representation; preserve labeled central blocks. No deduction that bare G0 generates the algebra.'),
'p2b:thm:v352-capacity-euler':dict(
 domain='The same supplied finite unital C*-algebra; algebraic state space, one finite POVM with effects in that algebra, and abstract pure states with weak-star topology.',
 reasoning=[
'On the canonical minimum module, each positive normalized functional has a unique block-diagonal density matrix with total trace one. Taking rank-one basis states and basis projectors inside every simple block gives sum_i di states perfectly discriminated by one POVM.',
'For the upper bound, perfect discrimination gives Tr(rho_j e_j)=1 and Tr(rho_k e_j)=0 for k≠j. Positivity of e_j and I−e_j implies that e_j is identity on the support of rho_j and zero on every other support.',
'Those nonzero supports are pairwise orthogonal eigenspaces of self-adjoint effects. Their total rank cannot exceed the minimum module dimension sum_i di, so no one POVM can discriminate more states. Additional decoding outcomes may be grouped by state without changing this bound.',
'A pure state of a finite direct sum has weight one in exactly one central block; otherwise it is a nontrivial convex combination. Pure states of M_di(C) are rank-one density projectors, homeomorphic to CP^(di−1). The finitely many blocks are disjoint open-and-closed components in the finite-dimensional weak-star topology.',
'CP^n has one cell in each even real dimension from zero through 2n, so its Euler characteristic is n+1. Additivity over the finite disjoint union gives Euler characteristic sum_i di, equal to the one-shot capacity and minimum faithful module dimension.',
'These are properties of the same abstract state/effect algebra. A faithful amplification may change its Hilbert representation and commutant but does not add new abstract effects or alter this capacity/topology.'
 ],
 imports=['p2b:thm:v352-minimal-faithful'],
 conditions='One common POVM must discriminate the state family; same abstract effects under faithful implementations. This is distinguishability capacity, not a physical bit rate.'),
'p2b:cor:v352-three-stage-capacity':dict(
 domain='The specified abstract stages with block sizes (1,2,2,4,3,3), (11,4), and (15); full-algebra stage conditional on a licensed full field/event test domain.',
 reasoning=[
'The sums of block sizes are 1+2+2+4+3+3=15, 11+4=15 and 15. The preceding theorem therefore gives capacity and pure-state Euler characteristic fifteen at all three stages.',
'The complex algebra dimensions are 1²+2²+2²+4²+3²+3²=43, 11²+4²=137 and 15²=225.',
'In their minimum faithful representations, commutant dimensions equal the number of simple central blocks: six, two and one. The same values count connected pure-state components; they do not equal Euler characteristic, which remains fifteen.',
'The logarithm base two of the largest exactly distinguishable alphabet is log2(15) bits per single distinguishability use. No time or physical bit rate is specified.',
'The third stage remains explicitly conditional on admitting its full field/event state and effect domain. The result does not derive an unconditional full M15 test algebra or universal one-copy physical carrier from the common value fifteen.'
 ],
 imports=['p2b:thm:v352-minimal-faithful','p2b:thm:v352-capacity-euler'],
 conditions='Already supplied abstract algebra stages; the M15 stage retains its explicit additional test-domain license.')
}
records=[]
for i,c in enumerate(claims,1):
 k=c['claim_id']; d=checks.pop(k)
 records.append({'id':f'EV-IIB-B4-E1A-{i:03}','claim_id':k,'evidence_level':'E1','agent':'/root/proof_replay','statement_layer':'SOURCE-AS-PRINTED','source_file':p.name,'source_locator':{'statement':c['statement_span'],'complete':c['complete_span']},'source_as_printed':c['source_as_printed'],'source_replay':'COMPLETE','status_proposal':'REPRODUCED; E3/E4 adjudication required for final verification status','new_confirmed_issue':False,**d})
assert not checks,checks
conclusion=[
 {'lines':[2945,2955],'claim':'Single SU2 parent and derived SO4/Spin4 symmetry, no numerical cutoff selector.','owners':['p2:thm:single-su2-derived-spin4-isometries','p2:thm:momentum-host-H1'],'verdict':'Matches exact earlier scope.'},
 {'lines':[2957,2995],'claim':'Frozen scalar/spinor/first-harmonic objects and generated bracket linear hull supply six-type support with dimension15.','owners':['p2b:lem:canonical-bracket-image','p2b:cor:bracket-image-same-carrier','p2:thm:momentum-host-H1'],'verdict':'Linear hull distinguished from literal decomposable bilinear image; finite section object distinguished from operation occurrence.'},
 {'lines':[2996,3014],'claim':'Canonical retained smooth one-copy presentation and same-root constituent occurrence.','owners':['p2b:thm:canonical-retained-smooth-realization','p2b:cor:retained-smooth-realization-corealization'],'verdict':'Explicit one-copy model only, no new coordinate completion, ambient lift or kinetic operator.'},
 {'lines':[3015,3027],'claim':'All physical GP3 endpoints have H1 full carriers only under additional complete comparison hypotheses.','owners':['p2b:thm:momentum-carrier-rigidity'],'verdict':'Three guards retained. No uniqueness of entire structured endpoint asserted. Existing open comparison issue unchanged.'},
 {'lines':[3029,3049],'claim':'Exact support implies m_p=1 independently of optional lower-ideal/tower/ceiling/coordinate packages; not conversely.','owners':['p2:thm:m1-component','p2b:rem:v264-converse-firewall'],'verdict':'Matches support-to-level direction and multiplicity independence.'},
 {'lines':[3050,3064],'claim':'Coordinate cone, nondegenerate normalized protected even algebra, exceptional-support occurrence and scales remain separate.','owners':['p1:def:s3one-finite-geometry-datum','p2c:cor:protected-clifford-selector-discharge','p2b:rem:carrier-scale-kinetic-firewall','p2:cor:core-support-inheritance-no-duplicate-witness'],'verdict':'Current I-A defines the cone R_ge0^3 after phase quotient; current II-C explicitly requires protected magnitude>0 for normalized even Cl(0,3). No numerical radius/scale match or 2T support occurrence follows from H1 or m_p=1.'},
 {'lines':[3065,3070],'claim':'Root occurrence co-realizes generated parent and constituents; later independent events need their own stage-safe witness.','owners':['p2b:cor:momentum-seed-constituent-corealization','p2b:cor:physical-momentum-carrier-corealization','p2b:cor:retained-smooth-realization-corealization'],'verdict':'Universal multiplicity-free physical endpoint remains explicitly comparison-gated; no token-to-role converse inserted.'}
]
result={'target':p.name,'batch':4,'package':'E1A nonconverses, Petersen boundary, finite algebra capacity and conclusion reconciliation','coverage_lines':[2881,3169],'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'census_object_count':len(records),'records':records,'issues':[],'candidate_issues':[],
 'rejected_adverse_checks':[
  {'target':'p2b:prop:v318-petersen-vs-h1','attack':'Use ordinary unoriented edge permutation character to contradict the stated decomposition.','verdict':'INVALID TARGET MATCH','reason':'Current owner defines signed oriented edge cochains. The two representations have different order-two character and invariant dimensions.'},
  {'target':'p2b:rem:v318-petersen-momentum-scope','attack':'Promote unqualified local H_p≅H1 shorthand to an unconditionally quantified theorem about every physical endpoint.','verdict':'UNSUPPORTED STRENGTHENING','reason':'No universal endpoint quantifier is stated in the remark; earlier theorem and immediately following conclusion preserve the three comparison guards. Record the exact shorthand and its inherited scope without inventing a stronger claim.'}
 ],
 'conclusion_reconciliation':conclusion,
 'bounded_import_review':[
  {'source_file':'Paper1A-Geometry-v5_163.tex','source_label':'p1:thm:petersen-signed-and-flux','lines':[3862,3912],'scope':'Oriented edge flux and cycle/gradient orthogonality used by the finite resolution.'},
  {'source_file':'Paper1A-Geometry-v5_163.tex','source_label':'p1:thm:petersen-fifteen-resolution','lines':[3915,3949],'scope':'Four orthogonal signed edge-cochain projectors of ranks4,5,3,3.'},
  {'source_file':'Paper1A-Geometry-v5_163.tex','source_label':'p1:thm:v339-petersen-sl4-isometry','lines':[20665,20718],'scope':'Exact signed oriented C1 module and orientation-preserving transport; not a plain unoriented permutation module.'},
  {'source_file':'Paper1A-Geometry-v5_163.tex','source_label':'p1:rem:v339-three-fifteens-firewall','lines':[20775,20788],'scope':'Distinct real edge, complex momentum and shell carrier roles; no physical mass/action or GP3 certificate.'},
  {'source_file':'Paper2A-GeometricConstitution-v3_212.tex','source_label':'p2a:thm:v318-petersen-same-owner-descent','lines':[11754,11786],'scope':'Conditional occurring embedded2I support, quotientA5 finite incidence and no extra observed labels.'},
  {'source_file':'Paper1A-Geometry-v5_163.tex','source_label':'p1:prop:math-twentyfourcell-bose-mesner','lines':[14315,14357],'scope':'Shell scheme primitive ranks1,4,9,8,2 and complementary15-dimensional range; no identification with the edge or H1 module.'},
  {'source_file':'Paper1A-Geometry-v5_163.tex','source_label':'p1:def:s3one-finite-geometry-datum','lines':[11752,11785],'scope':'Conclusion source check of three-magnitude coordinate completion cone and optional protected radius.'},
  {'source_file':'Paper2C-ReciprocalLocalization-v2_160.tex','source_label':'p2c:cor:protected-clifford-selector-discharge','lines':[2692,2788],'scope':'Conclusion source check only: normalized represented real even algebra independent of phase/scale on varrho_sp>0, explicitly excluding the degenerate face.'}
 ],
 'existing_frontier_reused':{'issue_id':'BH-IIB-STRUCTURED-RIGIDITY-001','condition_ids':['BH-IIA-A-B54-CMP-I-001','BH-IIA-A-B54-CMP-II-001','BH-IIA-A-B54-CMP-III-001'],'new_gap':False},
 'notes':['All six assigned census objects replayed. Conclusion reconciliation is supplemental evidence, not an additional denominator claim.','Finite capacity is a property of an already constituted abstract algebra and its effects; a minimum faithful representation is not a physical GP3 endpoint comparison.','No source, paper, PDF or canonical graph edits; no theory development or repairs.']}
(r/'work/batch4/proposals/replay_geometry/E1Records.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('Wrote',len(records),'E1A records and',len(conclusion),'conclusion checks; no new issue')
