"""Exact E4 controls of II-B v2.135 lines2881--3294, standard library.
Finite controls accompany general source-domain arguments; not physical occurrence.
"""
from fractions import Fraction as F
from itertools import product,permutations,combinations
from collections import Counter
from pathlib import Path
import json
O=Path(__file__).parent;checks=[]
def chk(n,p):
 assert p,n
 checks.append(n)
def zero(n):return [[F(0) for _ in range(n)] for _ in range(n)]
def eye(n):
 a=zero(n)
 for i in range(n):a[i][i]=F(1)
 return a
def add(a,b):return [[x+y for x,y in zip(r,s)] for r,s in zip(a,b)]
def scale(c,a):return [[c*x for x in r] for r in a]
def mul(a,b):return [[sum(x*y for x,y in zip(r,c)) for c in zip(*b)] for r in a]
def adj(a):return [list(r) for r in zip(*a)]
def tr(a):return sum(a[i][i] for i in range(len(a)))
def rho(v):return scale(F(1)/sum(x*x for x in v),[[x*y for y in v] for x in v])
# A5 action on oriented Petersenedges, with unsignedmutation retained separately.
verts=list(combinations(range(5),2));vi={v:i for i,v in enumerate(verts)}
edges=[(a,b) for a,b in combinations(range(10),2) if not set(verts[a])&set(verts[b])]
eidx={e:i for i,e in enumerate(edges)}
chars=Counter();unsigned=Counter();size=Counter()
for p in permutations(range(5)):
 if sum(p[i]>p[j] for i in range(5) for j in range(i+1,5))%2:continue
 vp=[vi[tuple(sorted(p[x] for x in v))] for v in verts]
 cyc=[];seen=set()
 for j in range(5):
  if j in seen:continue
  k=j;n=0
  while k not in seen:seen.add(k);n+=1;k=p[k]
  cyc.append(n)
 typ=tuple(sorted(cyc));ts=tu=0
 for a,b in edges:
  aa,bb=vp[a],vp[b];out=tuple(sorted((aa,bb)))
  if out==(a,b):tu+=1;ts+=1 if aa<bb else -1
 chars[typ]+=ts;unsigned[typ]+=tu;size[typ]+=1
expected={(1,1,1,1,1):(1,15,15),(1,2,2):(15,-1,3),(1,1,3):(20,0,0),(5,):(24,0,0)}
for typ,(n,s,u) in expected.items():
 chk(f'Petersen_A5_class_size_{typ}',size[typ]==n)
 chk(f'Petersen_signed_character_{typ}',chars[typ]==n*s)
 chk(f'Petersen_unsigned_mutation_{typ}',unsigned[typ]==n*u)
chk('Petersen_signed_no_trivial',sum(chars.values())==0)
chk('Petersen_unsigned_has_trivial',sum(unsigned.values())==60)
# Since signedcharacter vanishes on3/5classes, irrational5class character valuesdropout.
for name,degree,c2 in [('trivial',1,1),('3',3,-1),('3prime',3,-1),('4',4,0),('5',5,1)]:
 multiplicity=F(15*degree+15*(-1)*c2,60)
 chk(f'Petersen_signed_irrep_multiplicity_{name}',multiplicity==(0 if name=='trivial' else 1))
chk('real15_not_complex15_as_real_dimension',15!=2*15)
# Faithful unital representation minimum and commutant criterion.
stages=[[1,2,2,4,3,3],[11,4],[15]]
for stage,ds in enumerate(stages):
 chk(f'stage_capacity15_{stage}',sum(ds)==15)
 chk(f'stage_algebra_dimension_{stage}',sum(d*d for d in ds)==[43,137,225][stage])
 chk(f'stage_Euler_CP_union_{stage}',sum((d-1)+1 for d in ds)==15)
 for ms in product([1,2,3],repeat=len(ds)):
  dim=sum(d*m for d,m in zip(ds,ms));comm=sum(m*m for m in ms)
  chk(f'faithful_module_minimum_{stage}_{ms}',dim>=sum(ds) and (dim==sum(ds))==all(m==1 for m in ms))
  chk(f'commutant_center_criterion_{stage}_{ms}',(comm==len(ds))==all(m==1 for m in ms))
# Minimalmodule basisstates and one15outcomePOVM attain15; all effectsnativeinallstages.
for j in range(15):
 pj=zero(15);pj[j][j]=1
 for k in range(15):chk(f'onePOVM_discrimination_{j}_{k}',pj[k][k]==int(j==k))
# Uniformamplification *-polynomialincluding noncommutingwords and constants.
A=[[F(1),F(2)],[F(0),F(-1)]];B=[[F(0),F(1)],[F(3),F(2)]]
def kron(a,b):return [[x*y for x in r for y in s] for r in a for s in b]
def poly(a,b):return add(add(mul(mul(a,adj(b)),a),scale(F(2,3),mul(b,a))),scale(-F(3,2),eye(len(a))))
for k in range(1,7):
 ak=kron(A,eye(k));bk=kron(B,eye(k));p=poly(A,B);pk=poly(ak,bk)
 chk(f'noncommutative_star_polynomial_amplifies_k{k}',pk==kron(p,eye(k)))
 chk(f'normalized_polynomial_trace_k{k}',tr(pk)/(2*k)==tr(p)/2)
# Nonuniformsector multiplicities with arbitrary fullstatecoherences andfiniteancillas.
ds=[1,2];ms=[2,3];anc=2
full_offsets=[0,ds[0]*ms[0]*anc];min_offsets=[0,ds[0]*anc]
N=sum(d*m*anc for d,m in zip(ds,ms));n=sum(ds)*anc
blocks=[d*anc for d in ds]
def fq(l,a,t,b):return full_offsets[l]+(a*ms[l]+t)*anc+b
def mq(l,a,b):return min_offsets[l]+a*anc+b
def quotient(R):
 out=zero(n)
 for l,d in enumerate(ds):
  for a,b,c,e in product(range(d),range(anc),range(d),range(anc)):
   out[mq(l,a,b)][mq(l,c,e)]=sum(R[fq(l,a,t,b)][fq(l,c,t,e)] for t in range(ms[l]))
 return out
def embed(X):
 out=zero(N)
 for l,d in enumerate(ds):
  for a,b,c,e,t in product(range(d),range(anc),range(d),range(anc),range(ms[l])):
   out[fq(l,a,t,b)][fq(l,c,t,e)]=X[mq(l,a,b)][mq(l,c,e)]
 return out
def section(S):
 out=zero(N)
 for l,d in enumerate(ds):
  for a,b,c,e,t in product(range(d),range(anc),range(d),range(anc),range(ms[l])):
   out[fq(l,a,t,b)][fq(l,c,t,e)]=S[mq(l,a,b)][mq(l,c,e)]/ms[l]
 return out
vecs=[]
for j in range(N):vecs.append([F(int(i==j)) for i in range(N)])
# Explicit crosssectorcoherence; M-KBellcorrelation; retainedV-KBellentanglement.
for terms in [[(0,0,0,0),(1,1,2,1)],[(1,0,0,0),(1,0,1,1)],[(1,0,0,0),(1,1,0,1)]]:
 v=[F(0)]*N
 for term in terms:v[fq(*term)]=1
 vecs.append(v)
vecs.append([F((i*3)%7-3) for i in range(N)])
unit_effects=[]
for l,sz in enumerate(blocks):
 off=min_offsets[l]
 for i,j in product(range(sz),repeat=2):
  E=zero(n);E[off+i][off+j]=1;unit_effects.append(E)
for h,v in enumerate(vecs):
 R=rho(v);S=quotient(R)
 chk(f'nonuniform_ancilla_quotient_trace_{h}',tr(S)==1)
 chk(f'nonuniform_ancilla_mixed_section_{h}',quotient(section(S))==S and tr(section(S))==1)
 for k,E in enumerate(unit_effects):chk(f'all_joint_native_matrix_unit_expectations_{h}_{k}',tr(mul(R,embed(E)))==tr(mul(S,E)))
# Concrete2branchCPinstruments, exactunitarywithinblocks andcompleteness.
def instrument(setting):
 U=eye(n)
 for off in [0,2,4]:
  c,s=(F(3,5),F(4,5)) if setting==0 else (F(5,13),F(12,13))
  U[off][off]=c;U[off][off+1]=-s;U[off+1][off]=s;U[off+1][off+1]=c
 Ks=[]
 for outcome in range(2):
  D=zero(n)
  for i in range(n):D[i][i]=F(3,5) if (i+outcome+setting)%2 else F(4,5)
  Ks.append(mul(U,D))
 return Ks
inst=[instrument(0),instrument(1)]
for s,Ks in enumerate(inst):
 total=zero(n)
 for x,K in enumerate(Ks):
  effect=mul(adj(K),K);total=add(total,effect)
  chk(f'CPbranch_subunital_diagonal_{s}_{x}',all(0<=effect[i][i]<=1 for i in range(n)))
 chk(f'CPinstrument_normalization_{s}',total==eye(n))
J=lambda K,X:mul(mul(adj(K),X),K)
S=quotient(rho(vecs[-1]));R=rho(vecs[-1]);total=F(0);wrong_order_detected=False
for x,y in product(range(2),repeat=2):
 K1=inst[0][x];K2=inst[x][y] # setting2 dependsclassicallyon firstoutcome.
 effect=J(K1,J(K2,eye(n)))
 p0=tr(mul(S,effect));pfull=tr(mul(R,embed(effect)))
 Kword=mul(K2,K1);pSchr=tr(mul(mul(Kword,S),adj(Kword)))
 chk(f'adaptive_native_history_descends_{x}_{y}',p0==pfull==pSchr)
 chk(f'adaptive_branch_probability_nonnegative_{x}_{y}',p0>=0)
 total+=p0
 rev=J(K2,J(K1,eye(n)))
 if tr(mul(S,rev))!=p0:wrong_order_detected=True
chk('adaptive_history_probability_sum1',total==1)
chk('reversed_Heisenberg_order_mutation_detected',wrong_order_detected)
# Nonuniformcopies change the external maximally-mixedpreparation promise.
# Equivalence is at the same abstract functional, not a promise of maximum
# mixing independently imposed on two different carrier Hilbertspaces.
Rmax=scale(F(1,N),eye(N));Smax=quotient(Rmax);Pfirst=zero(n)
for j in range(blocks[0]):Pfirst[j][j]=1
p_external=tr(mul(Rmax,embed(Pfirst)))
p_canonical=tr(mul(Smax,Pfirst))
p_minmax=tr(mul(scale(F(1,n),eye(n)),Pfirst))
chk('nonuniform_fulltrace_preparation_weights',p_external==F(1,4))
chk('nonuniform_trace_canonical_state_equivalence',p_canonical==p_external)
chk('different_external_maxmixed_promises_different_abstract_states',p_minmax==F(1,3) and p_minmax!=p_external)
# Separate literal-faithful/nonunital representation challenge and controls.
# This is not a normalized-native state/effect model on the full carrier.
pi=lambda a:[[F(a),F(0)],[F(0),F(0)]]
rnull=[[F(0),F(0)],[F(0),F(1)]]
ress=[[F(1),F(0)],[F(0),F(0)]]
for a,b in product([F(-1),F(0),F(1),F(2,3)],repeat=2):
 chk(f'nonunital_faithful_scalar_star_rep_product_{a}_{b}',pi(a*b)==mul(pi(a),pi(b)))
chk('literal_faithful_rep_identity_not_full_carrier_unit',pi(1)!=eye(2))
chk('literal_faithful_rep_nullsector_history_weight0',tr(mul(rnull,pi(1)))==0)
chk('essential_support_state_normalization_control',tr(mul(ress,pi(1)))==1)
chk('unital_rep_arbitrary_density_normalization_control',tr(mul(rnull,eye(2)))==1)
result={'scope':'Paper2B v2.135 lines2881--3294','assertion_count':len(checks),'all_passed':True,'checks':checks,'limits':'Finite controls supplement general source-matched arguments. Full arbitrary complexdensity andCPmap equivalence follows exact partial-trace/abstractword reasoning, not finite samples alone. No microscopicmultiplicity, physicaloccurrence or universalGP3 comparison certified.'}
(O/'Paper2B-Batch4AdversarialResults-v1_1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'}))
