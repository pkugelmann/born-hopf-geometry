from pathlib import Path
import json,hashlib
W=Path('/workspace/scratch/6302724ed082/work')
S=W/'corpus/Paper2B-MomentumCarrier-v2_135.tex'
census=json.loads((W/'proposals/census/Paper2B-ClaimCensus-v1_1.json').read_text())['claims']
selected=[x for x in census if 3171<=x['complete_span']['start_line']<=3294]
args={
'p2b:prop:v352-normalized-amplification':[
'For k>=1, the unital star homomorphism T->T tensor I_k preserves sums, products, adjoints and constant terms, so p(a_1 tensor I_k,...)=p(a_1,...) tensor I_k for every finite star-polynomial, without commuting the a_i.',
'The ordinary trace multiplies by k and the actual represented dimension is15k. Dividing cancels exactly; no use of an unknown physical calibration or unnormalized trace is hidden in this equation.',
'For every density rho, including states correlated or entangled with the multiplicity slot, Tr[rho(a tensor I_k)]=Tr[(Tr_k rho)a]. The partial trace is positive with trace one, so all effects in the same multiplicity-blind algebra are reproduced.',
'The conclusion excludes inference of k from these normalized/multiplicity-blind data only. It neither makes amplified implementations GP3 minima nor creates a proper generated whole-candidate comparison or a multiplicity-resolving algebra.'
],
'p2b:rem:v352-capacity-occurrence':[
'Capacity was defined on the already constituted abstract algebra and its mathematical state/effect set. The remark correctly keeps the existence of abstract perfectly distinguishable states separate from performed preparations, instruments and outcomes.',
'The integer15 is the observable algebra capacity/minimum faithful module dimension from the preceding stated theorems. It does not identify the actual microscopic carrier dimension when representation multiplicities or available physical preparations remain unproved.',
'No GP3 axiom or universal comparison antecedent is removed by this algebraic result.'
],
'BH-IIB-CENSUS-U011':[
'This is an explicit definition of the process domain: every readout and every instrument branch belongs to the same specified abstract constituted test algebra. It excludes hidden multiplicity-commutant dynamics from the protocol definition.',
'It is not an assertion that every apparatus interaction on an amplified Hilbert space obeys this restriction. No GP3 whole-candidate comparison is inferred from process equivalence.',
'When comparing representations the SAME abstract CP branch maps are used. Multiplicity-dependent external settings, a separately generated multiplicity readout, or a physical Heisenberg map whose image leaves the represented native algebra are different process/test doctrines.'
],
'p2b:thm:v353-multitime-amplification':[
'In the inherited faithful-unital representation domain, omega_rho(a)=Tr[rho pi_k(a)] is a positive normalized functional on A: omega_rho(1)=Tr rho=1. A branch J_x is CP and the instrument condition sum_x J_x(1)=1 makes each J_x(1) a positive effect. Compositions of the branches therefore give valid nonnegative joint probabilities.',
'The source Heisenberg order J_(s1,x1) composed with ... composed with J_(sn,xn) evaluated on1 is correct: it is dual to applying the Schrödinger branches in chronological order1,...,n. Summing over the final outcome removes the innermost final branch by sum_x J_x(1)=1, giving normalized marginals recursively.',
'Every resulting history operator lies in A, so probabilities depend only on omega_rho, not the carrier multiplicity k. The earlier faithful-module decomposition and state/effect quotient show that every finite A-state has a positive trace-one block density in its minimum faithful representation, with the same values on A.',
'For adaptive settings s_j=s_j(x_1,...,x_(j-1)), a fixed history selects a fixed abstract CP word. The equality of functionals applies separately to that word; recursively summing last outcomes still normalizes because each branch-dependent instrument satisfies its own unit condition.',
'No state factorization on the original carrier and no repeated resetting of multiplicity is needed. The result compares the same abstract native CP protocol; it does not quantify over all physical amplified-system interactions or prove their native descent.'
],
'p2b:thm:v354-ancilla-stable-descent':[
'The representation decomposition is the faithful-UNITAL class already fixed in the preceding minimal-faithful theorem: pi_m(a)=direct_sum(a_lambda tensor I_mlambda), m_lambda>=1. With finite reference K, decompose H_m tensor K by central sectors; for arbitrary density rho define sigma_lambda=Tr_(Mlambda)[(P_lambda tensor I_K)rho(P_lambda tensor I_K)], canonically reordering tensor factors to V_lambda tensor K.',
'Each sigma_lambda is positive, and sum_lambda Tr sigma_lambda=Tr rho=1. Sector off-diagonal coherences do not contribute to any observable of A tensor B(K), because that abstract algebra is block diagonal in lambda. No tensor factorization between V_lambda, M_lambda and K is assumed.',
'For every joint observable a_lambda tensor b, the partial trace identity gives Tr rho[(a_lambda tensor I_mlambda) tensor b]=Tr sigma_lambda(a_lambda tensor b). Linear span proves equality for every element of A tensor B(K), including entangled tests in that joint algebra.',
'A faithful star representation is a star isomorphism onto its image, and hence a complete-order isomorphism. This remains true after any finite matrix amplification. Thus every fixed abstract joint CP Heisenberg branch has the same abstract output word in every representation; equal restricted functionals give equal probabilities on every finite history branch.',
'Classical adaptivity selects different CP words after different records but does not change the equality on a fixed branch. Entangled initial finite ancillas are included by arbitrary rho and are carried into sigma by partial trace, rather than replaced by a product state.',
'The theorem makes no inference about hidden multiplicity-sensitive operations, actual occurrence, infinite reference limits, or generated GP3 comparisons. An independently licensed operation whose Heisenberg image of native effects leaves A tensor B(K) violates the same-native-algebra premise.'
],
'p2b:rem:v355-native-operation-firewall':[
'The preceding equivalences determine native statistics and abstract test capacity, while the actual carrier multiplicities remain unmeasured by that restricted doctrine. The minimum module is a representation of the test algebra, not an automatic physical carrier selection.',
'A multiplicity-sensitive process or readout requires a separately licensed owner. When its pulled-back effects depend on multiplicity, operational test closure is enlarged and the abstract-native premise no longer applies. An invisible commutant unitary alone supplies no counterexample to the stated equality.',
'GP3 and its proper whole-candidate comparison remain distinct. Finite entanglement with references does not create an otherwise absent multiplicity port or violate the block partial-trace identity.'
]
}
conds={
'p2b:prop:v352-normalized-amplification':['Positive integer common amplification k>=1','Finite star-polynomial in the same canonical15-dimensional algebra representation','State/effects restricted to multiplicity-blind image'],
'p2b:rem:v352-capacity-occurrence':['Already constituted abstract state/effect test algebra','Physical preparation/instrument/outcome require their separate G0/GP2 occurrence certificates'],
'BH-IIB-CENSUS-U011':['Same specified abstract constituted algebra for every readout and CP instrument branch','No admitted multiplicity-commutant dynamics or independent multiplicity readout in the native protocol'],
'p2b:thm:v353-multitime-amplification':['Finite-dimensional unital C*-algebra A','Faithful unital finite representation inherited from preceding theorem and constituted effect unit','Same CP Heisenberg branches J:A->A across representations','For each setting sum_x J_(s,x)(1)=1','Finite history; adaptive choices classical and based on past outcomes only'],
'p2b:thm:v354-ancilla-stable-descent':['Same faithful unital representation domain','Arbitrary positive multiplicities m_lambda>=1','Finite reference Hilbert space K','Arbitrary trace-one positive joint initial density; entanglement allowed','Every branch CP on the same abstract A tensor B(K)','Finite adaptive histories'],
'p2b:rem:v355-native-operation-firewall':['Native algebra/process scope as explicitly declared at3210–3216','No universal GP3 comparison obtained from observational equivalence']
}
records=[]
for n,c in enumerate(selected,1):
 cid=c['claim_id']
 records.append({'id':f'EV-IIB-B4-E1B-{n:03}','evidence_level':'E1','agent':'/root/replay_states','claim_id':cid,'statement_layer':'SOURCE-AS-PRINTED','source_file':S.name,'statement_lines':list(c['statement_span'].values()),'proof_lines':list(c['proof_span'].values()) if c['proof_span'] else None,'complete_lines':list(c['complete_span'].values()),'source_as_printed':c['source_as_printed'],'source_replay':'COMPLETE WITHIN PRINTED / INHERITED OPERATIONAL SCOPE','reasoning':args[cid],'conditions_consumed_predicates':conds[cid],'imports':[{'file':S.name,'label':'p2b:thm:v352-minimal-faithful','lines':[3084,3110],'scope':'Inherited faithful unital representation/minimum module domain'},{'file':S.name,'label':'p2b:thm:v293-operational-multiplicity-quotient','lines':[1256,1363],'scope':'Already-checked finite state/effect partial-trace quotient, not GP3 comparison'}] if cid in ['p2b:thm:v353-multitime-amplification','p2b:thm:v354-ancilla-stable-descent'] else [],'adjudication':'Source proof replayed; final E3/E4 gate adjudication belongs to coordinator','physical_occurrence_newly_certified':False})
out={'target':S.name,'batch':4,'scope_lines':[3171,3294],'source_sha256':hashlib.sha256(S.read_bytes()).hexdigest(),'records':records,'candidate_issues':[],'confirmed_mathematical_defects':[], 'boundary_notes':[{'target':['p2b:thm:v353-multitime-amplification','p2b:thm:v354-ancilla-stable-descent'],'status':'FAITHFUL-UNITAL DOMAIN INHERITED','source_anchor':{'file':S.name,'lines':[3084,3102]},'why':'The preceding representation theorem explicitly uses faithful unital star representations, and the constituted effect unit must represent certainty. Degenerate pi(a)=diag(a,0) would not give omega_rho(1)=1 for arbitrary densities, so it is not admitted as a represented native state/effect system. This source-domain interpretation is recorded, not silently added as a new physical axiom.'},{'target':'p2b:thm:v354-ancilla-stable-descent','status':'NO HIDDEN FACTORIZATION','why':'The construction starts with arbitrary joint rho, drops only operationally invisible cross-central-sector blocks and traces only multiplicity factors. Each resulting sigma_lambda may remain entangled between V_lambda and K.'}], 'not_audited':'No actual process occurrence or universal GP3 comparison certified, no infinite-reference claim, no remote paper audit, no source/PDF edit or new theory.'}
p=W/'batch4/proposals/replay_process/E1Records.json';p.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'written':str(p),'records':len(records),'candidate_issues':0}))
