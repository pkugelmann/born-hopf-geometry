#!/usr/bin/env python3
"""Exact realified block-matrix check of existing normalizedprotected even claim.
The source ND_sp(rho>0) boundary is retained. No physical license is added.
"""
from fractions import Fraction as F
from pathlib import Path
from collections import defaultdict
import json
checks=defaultdict(int)
def ck(ok,g):
    assert ok,g
    checks[g]+=1

def z(n):return [[F(0)]*n for _ in range(n)]
def eye(n):
    a=z(n)
    for i in range(n):a[i][i]=1
    return a
def add(a,b):return [[x+y for x,y in zip(r,s)] for r,s in zip(a,b)]
def sc(c,a):return [[c*x for x in r] for r in a]
def mm(a,b):return [[sum(a[i][k]*b[k][j] for k in range(len(b))) for j in range(len(b))] for i in range(len(a))]
def block(A,B,C,D):return [list(r)+list(s) for r,s in zip(A,B)]+[list(r)+list(s) for r,s in zip(C,D)]
I2=eye(2);Z2=[[1,0],[0,-1]];X2=[[0,1],[1,0]];J2=[[0,1],[-1,0]];O2=z(2);O4=z(4)
# q1=i sigma1, q2=i sigma2, q3=i sigma3,q4=I.
q=[(O2,X2),(J2,O2),(O2,Z2),(I2,O2)]
C=[]
for a,(re,im) in enumerate(q):
    dagger_sign=1 if a==3 else -1
    Cre=block(O2,re,sc(dagger_sign,re),O2)
    Cim=block(O2,im,sc(dagger_sign,im),O2)
    C.append(block(Cre,sc(-1,Cim),Cim,Cre))
Gamma4=[[1,0,0,0],[0,1,0,0],[0,0,-1,0],[0,0,0,-1]]
Gamma=block(Gamma4,O4,O4,Gamma4)
imaginary=block(O4,sc(-1,eye(4)),eye(4),O4)
D=[mm(imaginary,mm(Gamma,c)) for c in C]
for i in range(4):
    ck(add(mm(Gamma,C[i]),mm(C[i],Gamma))==z(8),'chiral_anticommutation')
    for j in range(4):ck(add(mm(C[i],C[j]),mm(C[j],C[i]))==sc(2 if i==j else 0,eye(8)),'Clifford4_relations')
e=[mm(C[i],C[3]) for i in range(3)]
for i in range(3):
    for j in range(3):ck(add(mm(e[i],e[j]),mm(e[j],e[i]))==sc(-2 if i==j else 0,eye(8)),'Clifford03_relations')
phasepairs=[(F(1),F(0)),(F(0),F(1)),(F(3,5),F(4,5)),(F(5,13),F(12,13)),(F(-4,5),F(3,5))]
for a,b in phasepairs:
    ck(a*a+b*b==1,'normalized_phase_pair')
    Y=[add(sc(a,c),sc(b,d)) for c,d in zip(C,D)]
    for i in range(3):ck(mm(Y[i],Y[3])==e[i],'literal_phase_independent_even_generators')
    for i in range(4):
        for j in range(4):ck(add(mm(Y[i],Y[j]),mm(Y[j],Y[i]))==sc(2 if i==j else 0,eye(8)),'normalized_Clifford_relations')
    for rho in [F(1),F(2),F(1,3)]:
        X=[sc(rho,y) for y in Y]
        ck([sc(1/rho,x) for x in X]==Y,'positive_scale_normalization')
# The eight standardeven monomials are real-linearly independent, certifying
# faithful representedrealCl(0,3), not merely an abstract Cliffordquotient.
basis=[eye(8),e[0],e[1],e[2],mm(e[0],e[1]),mm(e[0],e[2]),mm(e[1],e[2]),mm(e[0],mm(e[1],e[2]))]
rows=[[F(v) for r in a for v in r] for a in basis];rank=0
for col in range(64):
    pivot=next((r for r in range(rank,8) if rows[r][col]),None)
    if pivot is None:continue
    rows[rank],rows[pivot]=rows[pivot],rows[rank]
    fac=rows[rank][col];rows[rank]=[v/fac for v in rows[rank]]
    for r in range(8):
        if r!=rank and rows[r][col]:
            fac=rows[r][col];rows[r]=[a-fac*b for a,b in zip(rows[r],rows[rank])]
    rank+=1
    if rank==8:break
ck(rank==8,'represented_real_even_algebra_dimension')
result={'script':Path(__file__).name,'status':'PASS','assertions':sum(checks.values()),'groups':dict(checks),'real_even_dimension':rank,'domain':'ND_sp:rho>0; reala,b witha²+b²=1','general_block_argument':'Gamma=diag(I,-I),C offdiagonal. Y hasuppercoefficient(a+ib)andlower(a-ib). ThereforeYiY4=(a²+b²)CiC4=CiC4 identically for every realunitpair, irrespective of positive scale.','limitations':['Finite rationalphase/scale controls supplement the exact universalchiral-block argument.','rho=0 is excluded: no normalization or stratum identification is asserted.','This verifies an existing sourceclaim; no completionpoint, physical scale, support, or occurrence is selected.']}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
