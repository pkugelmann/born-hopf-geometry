#!/usr/bin/env python3
"""Exact controls for existing II-B2881–3294; signed Petersen owner retained.
General representation/topology/native-protocol arguments are separate.
"""
from fractions import Fraction as F
from collections import Counter,defaultdict
from itertools import product,permutations,combinations
from pathlib import Path
import json,time
start=time.monotonic();checks=defaultdict(int)
def check(ok,g):
    assert ok,g
    checks[g]+=1

def z(n):return [[F(0)]*n for _ in range(n)]
def I(n):
    a=z(n)
    for k in range(n):a[k][k]=1
    return a
def add(a,b):return [[x+y for x,y in zip(r,s)] for r,s in zip(a,b)]
def sc(c,a):return [[c*x for x in r] for r in a]
def tr(a):return sum(a[i][i] for i in range(len(a)))
def t(a):return list(map(list,zip(*a)))
def mm(a,b):return [[sum(a[i][k]*b[k][j] for k in range(len(b))) for j in range(len(b[0]))] for i in range(len(a))]
def block(a,b):
    n=len(a);m=len(b);out=z(n+m)
    for i in range(n):
        for j in range(n):out[i][j]=a[i][j]
    for i in range(m):
        for j in range(m):out[n+i][n+j]=b[i][j]
    return out
def kron(a,b):return [[a[i//len(b)][j//len(b[0])]*b[i%len(b)][j%len(b[0])] for j in range(len(a[0])*len(b[0]))] for i in range(len(a)*len(b))]
def emat(n,i,j):
    a=z(n);a[i][j]=1;return a
# Petersen owner: oriented C1(KG(5,2)), not unoriented edge permutations.
vertices=list(combinations(range(5),2))
edges=[(a,b) for a in range(10) for b in range(a+1,10) if not(set(vertices[a])&set(vertices[b]))]
check(len(vertices)==10 and len(edges)==15,'Petersen_counts')
parity=lambda p:(-1)**sum(p[i]>p[j] for i in range(5) for j in range(i+1,5))
def order(p):
    q=tuple(range(5))
    for n in range(1,61):
        q=tuple(p[q[i]] for i in range(5))
        if q==tuple(range(5)):return n
chars=defaultdict(list);unsigned=defaultdict(list)
for p in permutations(range(5)):
    if parity(p)!=1:continue
    vimage=[vertices.index(tuple(sorted((p[a],p[b])))) for a,b in vertices]
    c=uc=0
    for a,b in edges:
        aa,bb=vimage[a],vimage[b]
        if tuple(sorted((aa,bb)))==(a,b):
            uc+=1;c+=1 if aa<bb else -1
    chars[order(p)].append(c);unsigned[order(p)].append(uc)
check({o:len(v) for o,v in chars.items()}=={1:1,2:15,3:20,5:24},'A5_order_class_sizes')
expected={1:15,2:-1,3:0,5:0}
for o,values in chars.items():check(set(values)=={expected[o]},'signed_edge_character')
check(sum(sum(v) for v in chars.values())==0,'signed_edge_no_trivial')
check(sum(sum(v) for v in unsigned.values())==60,'unsigned_edge_distinct_control')
# Character 4+5+3+3prime: combine two golden-ratio terms to their rational
# sum1 in eachfivecycle class, so no numericalsqrt5 is needed.
char4={1:4,2:0,3:1,5:-1};char5={1:5,2:1,3:-1,5:0};char3plus3={1:6,2:-2,3:0,5:1}
for o in expected:check(char4[o]+char5[o]+char3plus3[o]==expected[o],'signed_edge_irrep_decomposition')
check(sum(expected[o]**2*len(chars[o]) for o in chars)==60*4,'signed_edge_four_irreducibles')
# Minimum representation/commutant and pure-space Euler block arithmetic.
stages=[[1,2,2,4,3,3],[11,4],[15]]
for ds,wantdim,wantblocks in zip(stages,[43,137,225],[6,2,1]):
    check(sum(ds)==15 and sum(d*d for d in ds)==wantdim,'three_stage_capacity_dimension')
    check(len(ds)==wantblocks,'three_stage_center_components')
    # CP^(d−1)hasoneevenCWcell foreachj0..d−1; Euler equalsd.
    check(sum(sum((-1)**(2*j) for j in range(d)) for d in ds)==15,'pure_state_Euler')
    for ms in product([1,2],repeat=len(ds)):
        dimension=sum(d*m for d,m in zip(ds,ms));comm=sum(m*m for m in ms)
        check((dimension==15)==all(m==1 for m in ms),'faithful_minimum_equality')
        check((comm==len(ds))==all(m==1 for m in ms),'commutant_center_equality')
# Rankone discriminating matrixunit projections across each centralblock.
for ds in stages:
    n=sum(ds);effects=[emat(n,j,j) for j in range(n)]
    check(sum(tr(e) for e in effects)==15,'capacity_attaining_POVM')
    for j,e in enumerate(effects):check(all(tr(mm(emat(n,k,k),e))==int(k==j) for k in range(n)),'capacity_perfect_discrimination')
# Exact *polynomial amplification controls; all matrices real rationals.
A=[[F(1,2),1],[0,-1]];B=[[1,0],[F(1,3),2]]
def polynomial(a,b):return add(add(I(len(a)),mm(t(a),b)),add(sc(F(2,3),mm(a,mm(b,t(a)))),sc(-1,mm(b,b))))
base=polynomial(A,B)
for k in range(1,5):
    amplified=polynomial(kron(A,I(k)),kron(B,I(k)))
    check(amplified==kron(base,I(k)),'star_polynomial_replication')
    check(tr(amplified)/F(2*k)==tr(base)/2,'normalized_star_trace_replication')
# Ancilla jointalgebra A⊗M2 forA=M2⊕C; faithful multiplicities m=(2,3).
ds=[2,1];anc=2;ms=[2,3]
def offsets(mults):
    out=[];h=k=0
    for d,m in zip(ds,mults):out.append((h,k,d,m));h+=d*m*anc;k+=d*anc
    return out,h,k

def jmap(a,mults):
    offs,n,dtotal=offsets(mults);out=z(n)
    for h,k,d,m in offs:
        for i,j,c,e in product(range(d),range(d),range(anc),range(anc)):
            for r in range(m):out[h+(i*m+r)*anc+c][h+(j*m+r)*anc+e]=a[k+i*anc+c][k+j*anc+e]
    return out

def quotient(rho,mults):
    offs,n,dtotal=offsets(mults);out=z(dtotal)
    for h,k,d,m in offs:
        for i,j,c,e in product(range(d),range(d),range(anc),range(anc)):
            out[k+i*anc+c][k+j*anc+e]=sum(rho[h+(i*m+r)*anc+c][h+(j*m+r)*anc+e] for r in range(m))
    return out

def lift(sigma,mults):
    offs,n,dtotal=offsets(mults);out=z(n)
    for h,k,d,m in offs:
        for i,j,c,e in product(range(d),range(d),range(anc),range(anc)):
            for r in range(m):out[h+(i*m+r)*anc+c][h+(j*m+r)*anc+e]=sigma[k+i*anc+c][k+j*anc+e]/m
    return out

offs,n,dtotal=offsets(ms)
# Pure source entangled acrossV,M,K, with nonzerointercentralcoherence.
v=[F(0)]*n;v[0]=1;v[7]=2;v[8]=1
rho=[[a*b/F(6) for b in v] for a in v]
check(tr(rho)==1 and mm(rho,rho)==rho,'entangled_source_density')
sigma=quotient(rho,ms)
check(tr(sigma)==1,'sectorwise_partial_trace_normalization')
abasis=[]
for h,k,d,m in offs:
    for i,j in product(range(d*anc),repeat=2):abasis.append(emat(dtotal,k+i,k+j))
for a in abasis:
    check(tr(mm(rho,jmap(a,ms)))==tr(mm(sigma,a)),'entangled_joint_expectation_pairing')
for mults in [[1,1],[1,2],[3,1],[2,3]]:
    lifted=lift(sigma,mults)
    check(quotient(lifted,mults)==sigma,'all_faithful_multiplicity_right_inverse')
    for a in abasis:check(tr(mm(lifted,jmap(a,mults)))==tr(mm(sigma,a)),'all_faithful_joint_effect_equivalence')
# A native CP instrument onjointalgebra, including genuineV-K controlledflip
# foroneclassicalsetting. Every branch Kraus isinsideM4⊕M2.
D0=[[F(3,5),0],[0,F(4,5)]];D1=[[F(4,5),0],[0,F(3,5)]]
C=z(4)
for sys,ref in product(range(2),repeat=2):C[(sys^ref)*2+ref][sys*2+ref]=1
K={}
for setting in [0,1]:
    U=I(4) if setting==0 else C
    for outcome,D in enumerate([D0,D1]):
        scalar=F(3,5) if outcome==0 else F(4,5)
        K[setting,outcome]=block(mm(kron(D,I(anc)),U),sc(scalar,I(anc)))
    check(add(mm(t(K[setting,0]),K[setting,0]),mm(t(K[setting,1]),K[setting,1]))==I(dtotal),'native_CP_instrument_normalization')
probabilities=[];effect_sum=z(dtotal)
for outcomes in product([0,1],repeat=4):
    settings=[sum(outcomes[:j])%2 for j in range(4)]
    effect=I(dtotal)
    for setting,outcome in reversed(list(zip(settings,outcomes))):
        branch=K[setting,outcome];effect=mm(t(branch),mm(effect,branch))
    p=tr(mm(sigma,effect));source_p=tr(mm(rho,jmap(effect,ms)))
    other_ms=[3,1];other_p=tr(mm(lift(sigma,other_ms),jmap(effect,other_ms)))
    check(p==source_p==other_p and p>=0,'adaptive_entangled_history_equivalence')
    probabilities.append(p);effect_sum=add(effect_sum,effect)
check(sum(probabilities)==1 and effect_sum==I(dtotal),'adaptive_history_total_probability')
# A multiplicity-sensitive effect isoutsideA⊗BK: two rawstates have sameQ
# butdifferentMreadout. This isadomaincontrol,not a targetcounterexample.
r0=z(n);r1=z(n);r0[0][0]=1;r1[2][2]=1
check(quotient(r0,ms)==quotient(r1,ms),'native_boundary_same_abstract_state')
raw_effect=z(n);raw_effect[0][0]=1
check(tr(mm(r0,raw_effect))!=tr(mm(r1,raw_effect)),'nonnative_multiplicity_sensitive_control')
result={'script':Path(__file__).name,'status':'PASS','assertions':sum(checks.values()),'groups':dict(checks),'runtime_seconds':round(time.monotonic()-start,3),'signed_Petersen_character_by_order':{str(k):sorted(set(v)) for k,v in chars.items()},'A5_character_domain':'Signed orientededge cochains C1(KG(5,2);R); unsigned edge permutation module is a different control.','ancilla_test':{'abstract_system_blocks':ds,'ancilla_dimension':anc,'source_multiplicities':ms,'other_multiplicities_checked':[[1,1],[1,2],[3,1],[2,3]],'joint_matrixunit_effects':len(abasis),'adaptive_depth':4,'histories':16,'state':'Exact pure V-M-K entanglement plus intersector coherences; sectorwiseQ retains precisely abstractjointstatistics.'},'limitations':['Finite controls supplement the universal analytic proofs.','Protocol effects/instruments stay in specified abstractjointalgebra; no all-apparatus equivalence is asserted.','No physical GP3 comparison or source token is supplied.']}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
