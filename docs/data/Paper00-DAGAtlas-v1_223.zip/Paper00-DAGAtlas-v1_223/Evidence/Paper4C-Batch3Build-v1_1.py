#!/usr/bin/env python3
"""Assemble immutable-source-sequential IV-C Batch 3 audit ledger/report from E1,E2,E3,E4 evidence."""
from collections import Counter,defaultdict
from pathlib import Path
import json,hashlib,re
ROOT=Path('/mnt/data/bh4c_work')
stag=ROOT/'staging';C=stag/'Paper4C-CompleteSourceCensus-v1_1.json';census=json.loads(C.read_text())
source=ROOT/'papers'/'Paper00-PapersMinimal-v2_371'/'Paper4C-TechnicalMaterial-v1_42.tex'
slines=source.read_text().splitlines();sha=hashlib.sha256(source.read_bytes()).hexdigest()
assert sha==census['source_sha256']=='db4933305c7acd0a67ac9c81ba219d051cbad95777a9848514ce4ce0e4e57626'
source_lo,source_hi=3435,5219
claims=[c for c in census['named_claims'] if source_lo<=c['source_locator']['line_start']<=source_hi]
assert len(claims)==30
checks=json.loads((stag/'Evidence/Paper4C-Batch3IndependentChecks-v1_1.json').read_text())
assert checks['total_controls']==33 and checks['passed']==33
b1=json.loads((stag/'Batches/Paper4C-AuditBatch1-v1_1.json').read_text());b2=json.loads((stag/'Batches/Paper4C-AuditBatch2-v1_1.json').read_text())
assert b1['source_sha256']==b2['source_sha256']==sha and b2['source_coverage']['end']==source_lo-1
# Keep the precise source-as-printed layer distinct from issue/adjudication statuses.
statuses={
'p4:thm:v245-nonstationary-hessian-bogoliubov-source':'UNRESOLVED',
'p4:cor:v247-defect-bogoliubov-source':'UNRESOLVED',
'p4:thm:v247-two-level-fermion-mixing':'VERIFIED',
'p4:thm:v247-conformal-floquet':'VERIFIED-CONDITIONAL',
'p4:thm:curved-background-finite-bridge':'VERIFIED-CONDITIONAL',
'p4:thm:positive-production-density':'VERIFIED',
'p4:cor:absent-target-production':'VERIFIED',
'p4:thm:profile-independent-thin-layer-squeeze':'VERIFIED',
'p4:rem:thin-layer-squeeze-scope':'FORMALIZED',
'p4:thm:v2105-zero-excess-ground-support':'VERIFIED',
'p4:cor:v2105-quadratic-ground-complex-structure':'VERIFIED',
'p4:thm:finite-cosmological-perturbation-bridge':'VERIFIED-CONDITIONAL',
'p4:thm:finite-reheating-interface':'VERIFIED-CONDITIONAL',
'p4:thm:finite-transfer-kernel-status':'VERIFIED-CONDITIONAL',
'p4:thm:v244-no-independent-wave-postulate':'VERIFIED-CONDITIONAL',
'Paper4C-remark-line-4369':'FORMALIZED',
'p4:thm:nondeg-perturbation':'VERIFIED',
'p4:thm:degenerate-perturbation':'VERIFIED',
'p4:cor:second-order-effective':'VERIFIED',
'p4:thm:dyson-finite':'VERIFIED',
'p4:cor:first-order-transition':'VERIFIED',
'p4:thm:finite-adiabatic':'VERIFIED',
'p4:rem:adiabatic-status':'FORMALIZED',
'p4:thm:transported-frame-sector':'VERIFIED',
'p4:rem:transported-frame-status':'FORMALIZED',
'p4:prop:rank-three-weyl-basis':'VERIFIED',
'p4:cor:rank-three-a2-defect-plane':'VERIFIED',
'p4:thm:local-affine-normal-form':'VERIFIED-CONDITIONAL',
'p4:cor:intervalwise-affine-normal-form':'VERIFIED-CONDITIONAL',
'p4:cor:chart-transfer-affine':'REPRODUCED',
}
assert set(statuses)=={c['id'] for c in claims},(len(statuses),len(claims))
conditional={
'p4:thm:v245-nonstationary-hessian-bogoliubov-source':'Original m C2, ell continuous, Omega_eff²>0 do not ensure Omega_eff C1; exact pointwise time derivative fails at an interior time even on positive branch.',
'p4:cor:v247-defect-bogoliubov-source':'Inherits the one-mode missing time-regularity hypothesis. The algebraic identity holds on any differentiable defect/frequency branch; no physical defect time profile is selected.',
'p4:thm:v247-conformal-floquet':'Free integer/half-integer conformal tower only, calibrated III-A stationary branch; parity-even time-independent V; E0 scalar; no Magnus or physical nonconformal sector implied.',
'p4:thm:curved-background-finite-bridge':'Finite CAR and finite occupation boson carriers exact unitary. Nambu linear exact only CAR and regular CCR with implemented common-domain evolution. Finite-boson defects require separate state/word-degree boundary controls. Bundle, connection, h,Delta and inductive maps supplied.',
'p4:thm:positive-production-density':'Exact CAR/regular CCR coefficient beta and supplied positive-frequency splits. h_t>=0 for produced quadratic energy; no finite-cutoff operator-norm conclusion.',
'p4:cor:absent-target-production':'Zero final projector means zero production internally; external enlarged carriers not forbidden.',
'p4:thm:profile-independent-thin-layer-squeeze':'Mutually commuting positive bosonic frequencies, fixed canonical q,p and basis, monotone endpoint profiles with width -> 0; finite width and rotating modes expressly excluded.',
'p4:thm:v2105-zero-excess-ground-support':'Positive state and excess Hamiltonian, finite trace or declared trace class finite-energy domain; no physical zero-excitation state selection.',
'p4:cor:v2105-quadratic-ground-complex-structure':'Strictly positive real quadratic Hamiltonian and canonical symplectic orientation; covariance is fixed given ground-state occurrence, which is not established here.',
'p4:thm:finite-cosmological-perturbation-bridge':'VI-A supplies a constraint-reduced quadratic perturbation sector and one of two separately guarded positive-energy branches; cutoff vs regular-CCR domains; continuum correlators only under an independent compatible limit.',
'p4:thm:finite-reheating-interface':'Time-dependent supplied self-adjoint H(t), norm-continuity/local L1; product assignment for CP channel; GKLS only under separate reservoir hypotheses and forward IV-C theorem; Markov only under exact invariant projector algebra. Ancillary recurrence sentence exceeds nonautonomous domain.',
'p4:thm:finite-transfer-kernel-status':'CPTP transfer, response functional and nonzero denominator supplied; effects only give probabilities, determinants require kernel/extraction, no cosmological numbers from carrier alone.',
'p4:thm:v244-no-independent-wave-postulate':'Conditional synthesis over the II-C licensed presentation, III-F stationary positive physical Hessian, IV-B state/dynamics; finite wave presentation only, no automatic continuum or physical initial-state selection.',
'p4:thm:dyson-finite':'Local norm-integrability of V_I is an inherited IV-A hypothesis, verified at Paper4A lines 3696-3703. Valid both positive and negative t with reversed simplex.',
'p4:thm:finite-adiabatic':'C2 family, constant-rank isolated gapped band, T slow; bound concerns leakage, not arbitrary wavefunction phase gauge.',
'p4:thm:transported-frame-sector':'Fixed finite rank-three moving corner, Kato transport and supplied Y C1; physical dynamics reduced only with adiabatic leakage bound.',
'p4:thm:local-affine-normal-form':'Simple positive spectrum and C2 trajectory; autonomous affine vector-field linearization only with an additional projectable C2 F, not from one trajectory alone.',
'p4:cor:intervalwise-affine-normal-form':'Time-independent GKLS alone insufficient; exact projectability on simple-spectrum chart, or listed sufficient equivariant/MASA cases.',
'p4:cor:chart-transfer-affine':'Injective fixed linear coordinate reparameterization with inverse on image; no nonlinear chart-transport claim.'
}
# Material unnamed steps/equation checks. These are not additional named theorem denominators.
steps=[
(3451,3464,'m-dependent canonical integration by parts; Omega_eff² formula','BH-G-000103'),
(3465,3489,'Instantaneous annihilation derivative and missing regularity precondition','BH-G-000103'),
(3515,3519,'Defect-frequency derivative chain rule (inherits root)','BH-G-000103'),
(3530,3561,'Pauli Y-axis diagonalization and fermion basis connection',None),
(3573,3617,'Integer/half-integer free monodromy, parity and exact Floquet unitary',None),
(3621,3678,'Three separate CAR, truncated boson, regular CCR evolution domains',None),
(3685,3749,'Covariant connection gauge, Nambu commutator closure and cutoff defects',None),
(3773,3812,'Anti-linear beta quadratic-form pullback, Hilbert-Schmidt number and energy trace',None),
(3841,3903,'Zero-width bounded phase-space propagator and endpoint squeeze',None),
(3920,3950,'Positive energy expectation zero forces state support in ground kernel',None),
(3954,3990,'One-mode Hamiltonian complex structure / symplectic ground covariance',None),
(3994,4061,'Positive quadratic vs positive-energy splitting stability; conditional correlator limit',None),
(4081,4117,'Unitary Duhamel estimate, fixed product channel, selected CP instrument',None),
(4122,4190,'GKLS reservoir antecedent, population MASA invariance and Markov W',None),
(4191,4194,'Ancillary finite-time-dependent recurrence assertion, not used in central derivation','BH-G-000104'),
(4203,4261,'Finite trace-dual response ratio, effect criterion and determinant distinction',None),
(4274,4290,'Strong-resolvent to strong-unitary compact-time presentation, conditional only',None),
(4297,4324,'Finite Trotter path sums and separate continuum path measure obligation',None),
(4329,4367,'Six conditional clauses of finite no-independent-wave-postulate synthesis',None),
(4397,4493,'First-/second-order isolated block perturbation and reduced inverse',None),
(4501,4596,'Locally L1 interaction-picture Dyson and controlled transition remainder',None),
(4606,4724,'Riesz cluster local contour, adiabatic intertwiner and 1/T leakage',None),
(4726,4844,'Rank-one Berry gauge phase, Kato transport and unitary fixed-corner conjugation',None),
(4896,4935,'Rank-three Weyl trace Fourier orthogonality',None),
(4943,5011,'Log scale/shape split, Weyl S3 and symmetric C2,C3 invariants',None),
(5016,5069,'A2 projector centered defects and Cartan Gram',None),
(5088,5137,'C2 eigenvalue log shape first jet and conditional autonomous local linearization',None),
(5141,5198,'GKLS spectral flow needs projectability along isospectral fibers',None),
(5200,5216,'Full-rank fixed linear chart preserves conditional affine form',None),
]
material_steps=[{'id':f'BH-IVC-B3-ST-{i:03d}','line_range':[a,b],'description':d,**({'issue_ids':[g]} if g else {})} for i,(a,b,d,g) in enumerate(steps,1)]
# All references resolve in the current authoritative peer source; this is location E0, not proof evidence.
root=source.parent;label_map=defaultdict(list)
for p in root.glob('*.tex'):
 for n,l in enumerate(p.read_text().splitlines(),1):
  for lab in re.findall(r'\\label\{([^}]+)\}',l): label_map[lab].append({'file':p.name,'line':n})
source_refs=[]
for n in range(source_lo,source_hi+1):
 for lab in re.findall(r'\\(?:eqref|ref|autoref|cref|Cref)\{([^}]+)\}',slines[n-1]):
  source_refs.append({'use_line':n,'label':lab,'target':label_map.get(lab,[])})
missing=[x for x in source_refs if len(x['target'])==0];ambiguous=[x for x in source_refs if len(x['target'])>1]
assert len(source_refs)==47 and len({x['label'] for x in source_refs})==31 and not missing and not ambiguous
# Imported proof-use/trace edges only when observed in source; review the controlling imported scope, not whole remote proof.
edge_rows=[
('p4:thm:v245-nonstationary-hessian-bogoliubov-source','p4:cor:v247-defect-bogoliubov-source','REQUIRES',3497,'One-mode Omega C1/defect branch','MATERIAL','AND'),
('p3a:def:v247-affine-spectral-defect','p4:cor:v247-defect-bogoliubov-source','NORMALIZATION_CHOICE',3503,'Calibrated dimensionless clock interpretation of defect','MATERIAL_CONDITIONAL','AND'),
('p3a:thm:v247-conformal-clock-hierarchy','p4:thm:v247-conformal-floquet','IMPORTED_PROOF',3568,'Massless integer conformal, half-integer Dirac modes','MATERIAL_CONDITIONAL','AND'),
('p4:prop:explicit-finite-ccr-boundary-defect','p4:thm:curved-background-finite-bridge','IMPORTED_PROOF',3716,'Finite occupation truncated boson only','MATERIAL_CONDITIONAL','AND'),
('p4:thm:inductive-qft-bridge','p4:thm:curved-background-finite-bridge','REQUIRES',3670,'Optional compatible inductive presentation branch','MATERIAL_CONDITIONAL','OR:INDUCTIVE'),
('p4:thm:curved-background-finite-bridge','p4:thm:positive-production-density','REQUIRES',3772,'Exact CAR/regular CCR branches','MATERIAL','AND'),
('p4:thm:positive-production-density','p4:cor:absent-target-production','REQUIRES',3833,'Zero final carrier projectors','MATERIAL','AND'),
('p4:thm:curved-background-finite-bridge','p4:thm:finite-cosmological-perturbation-bridge','REQUIRES',4015,'Unitary Nambu curved-background domain','MATERIAL_CONDITIONAL','AND'),
('p4:thm:curved-background-finite-bridge','p4:thm:finite-reheating-interface','REQUIRES',4070,'Optional finite product bundle connection branch','MATERIAL_CONDITIONAL','OR:BUNDLE'),
('p4:thm:microscopic-bath-gkls','p4:thm:finite-reheating-interface','IMPORTED_PROOF',4124,'Reservoir/repeated-probe/large-bath GKLS branch; forward IV-C theorem not yet audited','REVIEWED_USE_PENDING_TARGET_PROOF','AND'),
('p4:thm:exact-finite-system-environment-reduction','p4:thm:finite-reheating-interface','IMPORTED_PROOF',4171,'Fixed product CP channel and instrument','MATERIAL_CONDITIONAL','AND'),
('p3f:thm:v244-stationary-physical-hessian-propagation','p4:thm:v244-no-independent-wave-postulate','IMPORTED_PROOF',4341,'Stationary physical Hessian wave equation only','MATERIAL_CONDITIONAL','AND'),
('p4:thm:stationary-positive-frequency-mode-space','p4:thm:v244-no-independent-wave-postulate','IMPORTED_PROOF',4343,'Positive-frequency structure on supplied stable sector','MATERIAL_CONDITIONAL','AND'),
('p4:thm:v244-action-generated-schrodinger-form','p4:thm:v244-no-independent-wave-postulate','IMPORTED_PROOF',4346,'First-order complex form of stable real Hessian','MATERIAL_CONDITIONAL','AND'),
('p4:eq:UI-evolution','p4:thm:dyson-finite','IMPORTED_PROOF',4521,'Locally norm-integrable IV-A interaction-picture equation','MATERIAL','AND'),
('p4:thm:dyson-finite','p4:cor:first-order-transition','REQUIRES',4588,'First-order Dyson matrix element plus tail','MATERIAL','AND'),
('p4:thm:finite-adiabatic','p4:thm:transported-frame-sector','REQUIRES',4753,'Kato gapped projector and O(1/T) leakage','MATERIAL','AND'),
('p1:prop:math-trimer-weyl-a2','p4:prop:rank-three-weyl-basis','CITATION_ONLY',4934,'Specialization to trimer; proof general rank 3','NONMATERIAL','NONMATERIAL'),
('p1:prop:math-trimer-weyl-a2','p4:cor:rank-three-a2-defect-plane','CITATION_ONLY',5067,'Specialization to trimer; direct projector proof independent','NONMATERIAL','NONMATERIAL'),
('p4:thm:local-affine-normal-form','p4:cor:intervalwise-affine-normal-form','REQUIRES',5156,'After autonomous GKLS spectral projectability','MATERIAL_CONDITIONAL','AND'),
('p4:thm:local-affine-normal-form','p4:cor:chart-transfer-affine','REQUIRES',5203,'Affine C2 local-normal-form domain','MATERIAL_CONDITIONAL','AND'),
]
edges=[]
for i,(frm,to,kind,line,guard,status,logic) in enumerate(edge_rows,1):
 edges.append({'id':f'BH-IVC-B3-EDGE-{i:03d}','from':frm,'to':to,'relation':kind,
  'proof_route':f'BH-IVC-B3-ROUTE-{to.split(":")[-1]}','logic_group':logic,'source_use_locator':f'{source.name}:{line}',
  'domain_guard':guard,'review_status':status,'verified_material_edge':status=='MATERIAL',
  'candidate_not_automatic':status in ('NONMATERIAL','REVIEWED_USE_PENDING_TARGET_PROOF')})
# Local source proper proof line start from actual \begin{proof} to \end{proof} and conditional remarks do not have proofs.
entries=[]
for i,c in enumerate(claims,1):
 lab=c['id'];loc=c['source_locator'];lines=loc.get('proof_lines')
 # Compiler's census proof_lines include theorem end as beginning; correct it for exact source proof range.
 pp= None if not lines else {'line_start':lines[0]+2,'line_end':lines[1]}
 E3=[x['id'] for x in checks['checks'] if x['claim']==lab and x['type']=='E3']
 E4=[x['id'] for x in checks['checks'] if x['claim']==lab and x['type']=='E4']
 issues=(['BH-G-000103'] if i in (1,2) else ['BH-G-000104'] if lab=='p4:thm:finite-reheating-interface' else [])
 entries.append({
 'id':f'BH-IVC-B3-CL-{i:03d}','source_label':lab,'kind':c['kind'],
 'source_location':{'file':source.name,'line_start':loc['line_start'],'line_end':loc['line_end'],'proof_lines':pp},
 'source_as_printed_title':c['title'],'source_as_printed':c['source_as_printed'],'proof_as_printed':c['proof_as_printed'],
 'statement_layer':'SOURCE-AS-PRINTED','disposition':statuses[lab],
 'lifecycle':'UNDER_CHALLENGE' if issues and statuses[lab]=='UNRESOLVED' else 'ACTIVE',
 'E1':'PRINTED_PROOF_REPLAYED_AND_TYPED', 'E3_ids':E3,'E4_ids':E4,
 'E3_scope':'SCOPED_SUBCLAIM_CHECKS_ONLY' if E3 else 'NOT_INDEPENDENTLY_CERTIFIED_THIS_BATCH',
 'typed_conditions':conditional.get(lab,'Finite matrix / source hypotheses as printed; no physical selection inferred.'),
 'issues':issues,'not_a_physical_occurrence_certification':True,
 'caveat':('Main finite reheating CPTP/GKLS-conditional statements survive; its 4191 auxiliary recurrence generalization does not follow for arbitrary time-dependent H.' if lab=='p4:thm:finite-reheating-interface' else '')
 })
# source-first, earliest step issue certificates
new_issues=[
{
 'issue_id':'BH-G-000103','class':'MISSING_CONDITION','secondary_class':'INCORRECT_STEP','severity':'moderate',
 'lifecycle':'OPEN','issue_status':'confirmed_in_domain_pointwise_counterexample',
 'first_origin':{'paper':'Paper4C','theorem_id':'p4:thm:v245-nonstationary-hessian-bogoliubov-source','step_locator':f'{source.name}:3465-3475 and proof 3487-3489','source_excerpt':'On any interval where Omega:=Omega_eff>0, define a(t) ... dot a=-i Omega a+dot Omega/(2 Omega)a^dagger'},
 'statement_layer':'SOURCE-AS-PRINTED',
 'exact_obligation':'Given only m in C^2 and ell continuous, positivity of Omega_eff^2 does not imply that Omega_eff is C^1. The exact pointwise instantaneous Nambu law and corollary require dot Omega or dot D, which need not exist.',
 'in_domain_counterexample':{'I':'(-1,1)','m':'m(t)=1; positive and C2','ell':'ell(t)=1+|t|; continuous','Omega_eff':'sqrt(1+|t|)>0','initial_data':'q(0)=1, p(0)=0','failure':'a(t) not differentiable at t=0; real part one-sided derivatives +/-1/(4 sqrt(2 hbar)) (for hbar=1, +/-1/(4 sqrt 2)); dot Omega undefined'},
 'evidence':['BH-IVC-B3-E4-002','BH-IVC-B3-E3-001','BH-IVC-B3-E3-003'],
 'conditions_consumed':['m C2, ell continuous, Omega²>0 (explicit)','Omega_eff differentiable on interval (implicit and not implied)'],
 'new_canonical_condition_candidate':'BH-IVC-A-OMEGA-C1-001',
 'verified_material_path':[['p4:thm:v245-nonstationary-hessian-bogoliubov-source','p4:cor:v247-defect-bogoliubov-source']],
 'affected_source_claims':['p4:thm:v245-nonstationary-hessian-bogoliubov-source','p4:cor:v247-defect-bogoliubov-source'],
 'unconfirmed_possible_impacts':['Physical nonstationary oscillator mode production estimates later citing the instantaneous coefficient; no remote material edge certified'],
 'verified_bypass_routes':['Fermionic two-level rotation uses independent C1 mass source','Finite bundle quadratic Nambu propagator needs norm-continuous h,Delta not this scalar dot Omega identity','Sudden-layer squeeze proof uses bounded phase-space propagation and no Omega derivative'],
 'not_affected':['p4:thm:v247-two-level-fermion-mixing','p4:thm:v247-conformal-floquet','p4:thm:profile-independent-thin-layer-squeeze','p4:thm:positive-production-density'],
 'next_required_certificate':'Either identify a previously established exact C1 (or valid a.e. regularity) condition on Omega_eff and document its source ancestry, or state the narrower differentiable domain as a required scope change. Do not silently repair the manuscript in this audit.'
},
{
 'issue_id':'BH-G-000104','class':'INCORRECT_STEP','secondary_class':'TYPE_OR_DOMAIN','severity':'minor',
 'lifecycle':'OPEN','issue_status':'confirmed_auxiliary_scope_overstatement',
 'first_origin':{'paper':'Paper4C','theorem_id':'p4:thm:finite-reheating-interface','step_locator':f'{source.name}:4191','source_excerpt':'A fixed finite unresolved block remains recurrent and does not establish the kinetic limit.'},
 'statement_layer':'SOURCE-AS-PRINTED',
 'exact_obligation':'The theorem permits an arbitrary norm-continuous or locally L1 time-dependent finite Hamiltonian. Fixed finite dimension alone gives no late-time return/recurrent orbit; only special autonomous or suitably recurrent driving gives this property. This auxiliary sentence is not used in the CPTP or GKLS-rate derivations.',
 'in_domain_counterexample':{'carrier':'H_bg=C2, H_mat=C; V=0','Hamiltonian':'H_bg(t)=f(t) sigma_x with smooth nonnegative f supported in (0,1), integral f dt = pi/2; H(t)=0 for t>=1','state':'initial |0>','evolved':'for every t>=1, U(t,0)|0>=-i|1>, with zero overlap to initial; no arbitrarily late returns'},
 'evidence':['BH-IVC-B3-E4-017'],'conditions_consumed':['Finite product carrier; arbitrary norm-continuous H(t) in theorem'],
 'verified_material_path':[],
 'affected_source_claims':['p4:thm:finite-reheating-interface:ancillary-proof-scope-line-4191'],
 'unconfirmed_possible_impacts':['Any later claim that a finite nonautonomous block is automatically dynamically recurrent; none certified here'],
 'verified_bypass_routes':['Time-ordered finite evolution, Duhamel, exact CPTP/instrument and conditional population-Markov closure do not use recurrence'],
 'next_required_certificate':'Qualify the recurrence observation to a proven recurrent/autonomous driving domain, or remove it as an unneeded explanatory assertion; the theorem main finite operator consequences require no change.'
}]
assert len(new_issues)==2
# Canonical candidates only; final archive integration must cross-match earliest ancestry and active global AssumptionRegistry.
conditions=[
{'id':'BH-IVC-A-OMEGA-C1-001','category':'INFERRED_CONDITION','statement':'On intervals asserting a pointwise instantaneous Nambu derivative in a resolved scalar oscillator, Omega_eff is C1 on that interval (or the precise a.e. version with adequate absolute continuity is explicitly used).','first_known_occurrence':f'{source.name}:3465-3475','status':'MISSING_FROM_THEOREM_AS_PRINTED','aliases':['differentiable Omega_eff','well-defined dot Omega','differentiable affine defect on calibrated branch'],'use_edges':['p4:thm:v245-nonstationary-hessian-bogoliubov-source','p4:cor:v247-defect-bogoliubov-source'],'canonical_registry_matching':'No matching exact Omega_eff condition found in current v1_108 top global AssumptionRegistry; global audit-layer ancestry to be checked before final integration','is_new_axiom':False},
{'id':'BH-IVC-B3-CONDITION-CONFORMAL-CLOCK','category':'EXPLICIT_CONDITIONAL','statement':'Calibrated stationary conformal integer bosonic/half-integer massless Dirac towers plus parity-even interaction V','first_known_occurrence':'Paper3A-GeneratedDynamics-v1_169.tex:2913','status':'REUSE_EXISTING_UPSTREAM_HYPOTHESES','new_assumption_node':False},
{'id':'BH-IVC-B3-CONDITION-CURVED-BUNDLE','category':'EXPLICIT_CONDITIONAL','statement':'Supplied finite-rank Hermitian bundle, metric connection, norm-continuous h_t,Delta_t and separated regular-CCR domain conditions','first_known_occurrence':f'{source.name}:3621','status':'LOCAL_SCOPE_GUARDS_ONLY','new_assumption_node':False},
{'id':'BH-IVC-B3-CONDITION-PERTURBATION-LIMIT','category':'EXPLICIT_CONDITIONAL','statement':'Compatible states/embeddings/evolutions/convergence and (if truncated) occupation-cutoff tail control for cosmological large-window correlator readout','first_known_occurrence':f'{source.name}:3992','status':'LOCAL_SCOPE_GUARDS_ONLY','new_assumption_node':False},
{'id':'BH-IVC-B3-CONDITION-ADIABATIC-GAP','category':'EXPLICIT_CONDITIONAL','statement':'C2 finite H(s), constant rank tracked spectral cluster, positive uniform gap and slow runtime T','first_known_occurrence':f'{source.name}:4606','status':'LOCAL_SCOPE_GUARDS_ONLY','new_assumption_node':False},
{'id':'BH-IVC-B3-CONDITION-SPECTRAL-PROJECTABILITY','category':'EXPLICIT_CONDITIONAL','statement':'D pi_Y[L(Y)] constant on isospectral fibers of one simple-spectrum chart for an autonomous spectral flow','first_known_occurrence':f'{source.name}:5141','status':'LOCAL_SCOPE_GUARDS_ONLY','new_assumption_node':False}]
unique_status=Counter(statuses.values())
assert sum(unique_status.values())==30
src_covered=[v for v in census['display_equations'] if source_lo<=v['line_start']<=source_hi]
assert len(src_covered)==40
report={
 'audit':'Paper4C','batch':3,'revision':'v1_1','protocol':'Paper00-RigorousVerificationDAGWorkProtocol-v2_4',
 'source_authority':'Paper00-PapersMinimal-v2_371','source_file':source.name,'source_sha256':sha,
 'latest_supplied_dag_input':'Paper00-DAGAtlas-v1_108(1).zip','latest_supplied_audit_input':'Paper00-ProofChainAudits-v1_25(1).zip',
 'source_coverage':{'start':source_lo,'end':source_hi,'total_lines':len(slines),'named_checked':len(claims),'named_total':census['named_count'],'cumulative_named_checked':64+len(claims),'cumulative_named_remaining':census['named_count']-64-len(claims),'formal_results_in_batch':sum(c['kind'] not in ('remark','definition') for c in claims),'display_environments_reviewed':len(src_covered),'display_environments_total':census['display_count'],'material_unnamed_steps':len(steps),'material_steps_ledger':material_steps,'out_of_scope':'Lines 5220–10934, not-yet-audited forward IV-C results, blanket remote-paper re-audits'},
 'status_counts':dict(unique_status), 'previous_cumulative_named':64,
 'cumulative_status_counts':dict(Counter(b2['cumulative_status_counts'])+unique_status),
 'named_claim_ledger':entries, 'source_reference_audit':{'ref_occurrences':len(source_refs),'unique_ref_labels':len({x['label'] for x in source_refs}),'all_resolve_uniquely_in_current_tex':True,'missing':missing,'ambiguous':ambiguous,'reference_targets':source_refs,'caveat':'E0 resolution only; a cited label is not ipso facto a material proof edge'},
 'source_proof_use_edges':edges,
 'proof_route_review':['Finite CAR exact vs regular CCR common-domain vs truncated boson defect do not conflate','III-A conformal free tower monodromy only; no physical nonconformal Floquet selection','Exact thin layer with fixed mode basis is separate from finite-width or rotating basis','Positive quadratic one-particle branch does not select initial vacuum','Finite cosmological correlators do not imply continuum correlator limit','GKLS rate closure iff L* preserves chosen projector MASA','Schr wave/kernel/path-integral presentation assumptions are not finite carrier outcomes','Dyson V_I locally L1 inherited from Paper IV-A','Adiabatic leakage/gauge and Kato fixed-corner are different claims','Autonomous spectral F only on projectability domain; time-independent L insufficient'],
 'independent_checks_file':'Evidence/Paper4C-Batch3IndependentChecks-v1_1.json','independent_check_count':checks['total_controls'],'independent_check_passed':checks['passed'],'independent_E3_count':checks['E3_count'],'adversarial_E4_count':checks['E4_count'],
 'found_issues':new_issues,'carried_forward_issues_unchanged':[{'id':'BH-G-000102','origin':'Paper4C lines 3069-3072,3145-3154','status':'UNRESOLVED','effect':'truncated bosonic polynomial microcausality route only','source_batch':2}],
 'canonical_condition_review':conditions,'open_verification_gates':[
 {'target':'p4:thm:v245-nonstationary-hessian-bogoliubov-source','gate':'E4 counterexample; source cannot prove pointwise dot Omega without extra regularity'},
 {'target':'p4:cor:v247-defect-bogoliubov-source','gate':'Inherited frequency/affine-defect differentiability obligation'},
 {'target':'p4:thm:curved-background-finite-bridge','gate':'Source-scoped regular CCR unbounded-operator common domain + implementability assumed, not newly proven; boson cutoff boundary word-level control independent'},
 {'target':'p4:thm:finite-cosmological-perturbation-bridge','gate':'No independent VI-A background/perturbation generation and continuum-limit certificate in this batch'},
 {'target':'p4:thm:finite-reheating-interface','gate':'Forward IV-C GKLS reservoir result (source lines 7258+) is not audited yet; ancillary recurrence sentence contradicted by nonautonomous control'},
 {'target':'p4:thm:v244-no-independent-wave-postulate','gate':'Conditional II-C/III-F/IV-B interfaces checked only to source labels, not independently blanket-certified'},
 {'target':'p4:thm:finite-adiabatic','gate':'Finite matrix proof replay plus numerical gapped family, no full symbolic E3 theorem-wide constants proof'},
 {'target':'p4:cor:intervalwise-affine-normal-form','gate':'Projectability of actual physical-sector GKLS generator not provided; conditional criterion checked'}
 ],
 'adversarial_challenges':[{'id':z['id'],'claim':z['claim'],'scope':z['scope'],'result':z['details']} for z in checks['checks'] if z['type']=='E4'],
 'agent_mode':'single coordinator; separate sequential E1 source replay, E2 ancestry, E3 independently computed controls and E4 adversarial source-domain tests; no multi-agent claim',
 'batch_closure':'PARTIALLY_AUDITED_OVERALL_WITH_TWO_NEW_ISSUES_ONE_MATERIAL_REGULARITY_ONE_AUXILIARY_SCOPE',
 'overall_full_audit_ready':False,'successor_archive_policy':'NO_DAG_ZIP_OR_AUDIT_ZIP_IN_INTERMEDIATE_BATCH; final batch only; latest version per payload file',
 'no_source_modification':True
}
opath=stag/'Batches/Paper4C-AuditBatch3-v1_1.json';opath.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
# report MD with persistent complete IDs/issues and precise assumptions.
header=f'''# Paper IV-C — Rigorous Verification DAG audit, Batch 3 (v1_1)

**Authority:** `Paper00-PapersMinimal-v2_371` controlling `{source.name}` (SHA-256 `{sha}`); protocol `Paper00-RigorousVerificationDAGWorkProtocol-v2_4`.

**Coverage:** printed lines **{source_lo}–{source_hi}** (1,785 lines) of 10,934; **30** named results/remarks, **{len(steps)}** material unnamed steps, **{len(src_covered)}** displayed equation environments. **Cumulative: 94/186** named objects; **92 remaining**. Prior 64 objects retained, not reclassified.

**Batch dispositions:** {', '.join(f'{k}: {v}' for k,v in unique_status.items())}. These statuses apply to source-as-printed, with a main theorem's independently contradicted *auxiliary* remark separated from its core statements. E1 replay/E2 imported scope are not the same as universal E3: **{checks['passed']}/{checks['total_controls']}** scoped controls PASS (**{checks['E3_count']} E3, {checks['E4_count']} E4**).

## Named source ledger (30/30)

| Source line | Label | Source-as-printed status | Independent control IDs | Issue |
|---:|---|---|---|---|
'''
for v in entries:
 src=v['source_location'];ids=[id.split('-')[-1] for id in v['E3_ids']+v['E4_ids']];header+=f"| {src['line_start']} | `{v['source_label']}` | {v['disposition']} | {', '.join(ids) if ids else '—'} | {', '.join(v['issues']) if v['issues'] else '—'} |\n"
rest='''
## Issue BH-G-000103 — missing time differentiability for scalar Bogoliubov law

- **Class/severity:** `MISSING_CONDITION` with a pointwise `INCORRECT_STEP`, **moderate**, source-as-printed **UNRESOLVED**. Earliest source: theorem `p4:thm:v245-nonstationary-hessian-bogoliubov-source`, lines **3451–3475**, proof **3484–3489**. Direct descendant `p4:cor:v247-defect-bogoliubov-source` lines **3494–3519**.
- **Exact mismatch:** `m∈C²`, `ℓ` continuous and `Ω_eff²>0` guarantee continuous but not differentiable `Ω_eff`. The displayed pointwise equation `dot a = −iΩ a + (dot Ω)/(2Ω) a†` uses an unestablished derivative.
- **In-domain counterexample:** `m(t)=1`, `ℓ(t)=1+|t|` for `t∈(−1,1)` satisfies every printed regularity and positivity condition. Then `Ω_eff(t)=√(1+|t|)`, which has no derivative at zero. With `q(0)=1`, `p(0)=0`, the real part of the instantaneous annihilation variable has opposite one-sided slopes `±1/(4√2)` for `ℏ=1`. No exact pointwise Nambu law exists there. `E4-002` reproduced the limits. A separately differentiable `D(t)` yields the correct algebraic coefficient (`E3-003`) but is not part of the printed general theorem premises.
- **Canonical inferred condition:** proposed unique ID `BH-IVC-A-OMEGA-C1-001`, differentiable positive `Ω_eff` (or a precisely formulated absolutely continuous/a.e. variant) at the pointwise proof use; this is **not** a new constitutional axiom. Its global ancestry must be matched before the final DAG merge.
- **Scope/impacts:** proven local material path is one-mode theorem → affine-defect corollary. The two-level fermion mixing, general finite bundle Nambu implementation, and sudden-layer squeeze law use independent hypotheses/derivations and **are not declared broken**. Physical/cosmological downstream usages are **POSSIBLE, not yet linked by a verified material edge**.
- **Required certificate:** identify an earlier proof supplying the exact missing regularity on this theorem's quantified domain, or explicitly scope the pointwise claim to adequate regularity. The manuscript is not edited during audit.

## Issue BH-G-000104 — auxiliary time-dependent recurrence overstatement

- **Class/severity:** `INCORRECT_STEP` / `TYPE_OR_DOMAIN`, **minor**, precisely source `p4:thm:finite-reheating-interface` proof **line 4191**. This does **not** refute the theorem's main Duhamel, CPTP/instrument or conditionally GKLS/Markov statements.
- **Source assertion:** “A fixed finite unresolved block remains recurrent...” The theorem allows norm-continuous or locally L¹ **time-dependent** finite Hamiltonians. Compact finite dimension does not imply late-time return for arbitrary nonautonomous dynamics.
- **In-domain witness (`E4-017`):** take `H_bg=C²`, one-dimensional matter sector, `V(t)=0`, and `H_bg(t)=f(t) σ_x` for smooth `f` supported on `(0,1)` with `∫ f=π/2` in `ℏ=1` units. For all `t≥1`, the evolved initial `|0⟩` is `−i|1⟩`; it never returns near the initial state. Thus the unqualified recurrence sentence is incorrect. A stationary finite Hamiltonian has a different recurrence theorem.
- **Impact:** no certified material descendant path uses line 4191; the finite evolution and the conditional kinetic-limit distinction are established independently. Any future recurrence use is **POSSIBLE/UNCONFIRMED**.
- **Required certificate:** qualify the recurrence sentence to an appropriate autonomous/recurrent drive, or remove the unused assertion in a later separate source-update instruction.

## Main source-bound verification and conditions

1. **Time-dependent mode bridge:** the canonical Hessian, Pauli rotation/fermionic source, conformal parity-Floquet identity, finite CAR Nambu closure and covariant moving-frame generator were checked. The scalar instantaneous derivative is the exact open point. A finite occupation boson cutoff is not an exact regular CCR implementation.
2. **Production and cosmology:** the positive final density `Γ`, sector positivity, zero-target result, fixed-basis zero-width squeeze `β→−sinh d`, positive-ground covariance and finite product-channel/Duhamel identities passed checks. Cosmological mode selection, large-window correlators, initial state, physical thin-layer width, squeezed-to-thermal conversion, GKLS reservoir and scalar Markov populations remain separately typed and conditional. In particular, `L*(span{P_a})⊂span{P_a}` is necessary and sufficient for all-state population closure; an arbitrary reduced channel alone does not provide scalar rates.
3. **Wave presentation:** conditional strong-resolvent target and time-sliced finite Trotter limit have been distinguished. Neither finite matrices nor a dense harmonics ladder automatically yields a path-space measure, continuum kernel, or Schrödinger operator. The no-independent-wave-postulate theorem has the explicitly listed upstream physical Hessian, representation and quantum-calculus prerequisites.
4. **Finite approximation:** first/second order nondegenerate/degenerate perturbation, the negative-time Dyson norm bound, transition remainder, isolated-band adiabatic leakage and Kato fixed-corner transport replayed and matched finite-matrix controls. IV-A already supplies the locally norm-integrable interaction qualification, so no false missing-condition finding is added there.
5. **Three-level shape:** rank-three finite Weyl basis, `A₂` projector Gram, log-spectrum `C₂/C₃`, time first jet, projectable affine vector-field form and chart transfer match exact matrix/symbolic checks. No actual family-sector selection follows from these rank-three identities. A time-independent GKLS generator alone is not eigenvalue-projectable, as the text itself correctly demonstrates.

## Source references and dependency handling

All **47** explicit `\\ref`/`\\eqref` occurrences to **31** unique labels in lines 3435–5219 resolve exactly once in the current `.tex` corpus (**E0 navigation only**). The ledger records **21** separately reviewed source-use/citation edges; direct proof-use is never inferred from a textual citation alone. Crucially, `p4:thm:microscopic-bath-gkls` is a **forward IV-C theorem beyond this batch** (line 7258), so its prior-proof status is not silently promoted.

**Persistent earlier issue:** `BH-G-000102` (degree-relative bosonic microcausality boundary control, lines 3069–3072 and 3145–3154) remains **UNRESOLVED** exactly as recorded in Batch 2; no closure is implied by the present finite CAR/Bogoliubov checks.

## Continuation / artifact policy

**Overall:** `PARTIALLY_AUDITED`, **94/186** named source objects examined, **92 remaining**. Next source line **5220** begins relative diagonalization and mixing stability. No source paper or original ZIP was changed. Batch 3 has a source-bound JSON ledger, markdown report and reproducible independent checks. Final updated DAG ZIP and proof-chain audit ZIP will be made **only upon final batch completion**, from the latest supplied `Paper00-DAGAtlas-v1_108(1).zip` and `Paper00-ProofChainAudits-v1_25(1).zip`, each with latest payload versions only. The final merge must preserve the existing global graph and issue ancestry, not replace it with a standalone local issue list.
'''
mpath=stag/'Batches/Paper4C-AuditBatch3-v1_1.md';mpath.write_text(header+rest)
print('COVERAGE',report['source_coverage']['cumulative_named_checked'],'/',report['source_coverage']['named_total'])
print('STATUS',dict(unique_status))
print('REFS',len(source_refs),'unique',len(set(x['label'] for x in source_refs)))
print('MATERIAL STEPS',len(steps),'edges',len(edges),'issues',len(new_issues))
print('REPORT',mpath,'size',mpath.stat().st_size)
print('LEDGER',opath,'size',opath.stat().st_size)
