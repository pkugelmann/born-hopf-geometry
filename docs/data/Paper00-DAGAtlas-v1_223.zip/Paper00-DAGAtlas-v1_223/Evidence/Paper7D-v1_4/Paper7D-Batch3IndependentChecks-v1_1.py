#!/usr/bin/env python3
"""Paper VII-D batch-3 independent E3/E4 checks of EXISTING claims only.
Requires sympy, mpmath; no new Born-Hopf theoretical assumptions/results.
"""
import itertools, json, hashlib
from math import exp
from pathlib import Path
import mpmath as mp
import sympy as sp
mp.mp.dps = 55

def dim(p,q): return mp.mpf((p+1)*(q+1)*(p+q+2))/2
def c2(p,q): return mp.mpf(p*p+q*q+p*q+3*p+3*q)/3
def h(t,n=28):
    d=C=mp.mpf('0')
    for r in range(n+1):
        for p in range(r+1):
            w=dim(p,r-p)**2 * mp.exp(-t*c2(p,r-p)/2)
            d+=w; C+=w*c2(p,r-p)
    return C/(8*d)
def R(t,n=28): return sum((dim(p,r-p)**2 * mp.exp(-t*c2(p,r-p)/2) for r in range(1,n+1) for p in range(r+1)), mp.mpf('0'))
a=mp.mpf('0.25');B=mp.mpf(76);C=mp.mpf(300)
thal=mp.findroot(lambda t:h(t)-1/(2*mp.pi**2),6)
td4=mp.findroot(lambda t:h(t)-1/mp.pi**2,4)
ecrit=a*mp.exp(-a)/(B+a*C)
tcrit=mp.findroot(lambda t:R(t)-ecrit,14)
kmax=ecrit/(6*(1+ecrit))
qbudget=B*(R(3*thal)*mp.exp(a))/(1-C*(R(3*thal)*mp.exp(a)))
free=mp.mpf('.25')-qbudget
rstop=mp.lambertw(free)
N, Be, z=map(mp.mpf,['0.01','0.8','1.1'])
u=mp.exp(-2*td4/3); v=mp.exp(-3*td4/2)
n=v*z*(1+N)**2
fn=(1+n)**3-1
x=u*z*(1+N+Be)**2
fb=((1+N+2*x)**3-(1+N-x)**3)/3
assert fn<N and fb<Be
assert qbudget<mp.mpf('0.25')
assert R(2*mp.pi**2)<mp.mpf('0.000034689')

# Exact D4 24-cell two-face bivector tight-frame identity.
vertices=set()
for i,j in itertools.combinations(range(4),2):
    for si,sj in itertools.product([-1,1],repeat=2):
        vv=[0]*4;vv[i]=si;vv[j]=sj;vertices.add(tuple(vv))
vertices=sorted(vertices)
dot=lambda v,w: sum(q*r for q,r in zip(v,w))
faces=[(p,q,r) for p,q,r in itertools.combinations(vertices,3) if dot(p,q)==dot(p,r)==dot(q,r)==1]
frame=sp.zeros(6)
pairs=list(itertools.combinations(range(4),2))
for p,q,r in faces:
    e=[q[i]-p[i] for i in range(4)]; f=[r[i]-p[i] for i in range(4)]
    wedge=sp.Matrix([e[i]*f[j]-e[j]*f[i] for i,j in pairs])
    assert (wedge.T*wedge)[0]==3
    frame+=wedge*wedge.T / 3
assert len(vertices)==24 and len(faces)==96
assert frame==16*sp.eye(6)

# Exact counterexample to source-as-printed QFT4 isometry+gap implication
# absent a unique, common vacuum state: identical transfer and A at every level,
# two-fold ground degeneracy; alternating chosen vacua.
K=sp.diag(1,1,sp.Rational(1,3))
A=sp.diag(1,-1,0)
e1=sp.Matrix([1,0,0]); e2=sp.Matrix([0,1,0])
assert K*e1==e1 and K*e2==e2
assert (e1.T*A*e1)[0]==1 and (e2.T*A*e2)[0]==-1
assert sp.eye(3)*K-K*sp.eye(3)==sp.zeros(3)
assert sp.eye(3)*A-A*sp.eye(3)==sp.zeros(3)

# UV recursion with p=2 and g_j^2=1/(j+1) tolerates non-summable
# residual r_j=1/(j+1), for rho=1/2 and C=1.
for j in range(1,10000):
    assert sp.Rational(1,j+2)<=sp.Rational(1,2*(j+1))+sp.Rational(1,j+1)

# Two binary states saturate the sharp oscillation bound (verified at d=2).
delta=mp.mpf('2'); p=1/(1+mp.exp(delta/2)); q2=p/(p+(1-p)*mp.exp(-delta))
assert abs(abs(q2-p)-mp.tanh(delta/4))<mp.mpf('1e-45')

# Zero exactness of the isolated U(1) Fourier (1,0,0) mode after 3-face integration.
# The (1,-1,0) mode survives with coefficient exp(-t).
assert (1+0+0)!=0 and (1-1+0)==0

# RG bookkeeping does not uniquely fix hidden action coefficients from the
# same visible cylinder expectations: tensor-factorized Gibbs model.
visible=sp.diag(1,1)
hidden=sp.diag(1,-1)
# rho_g = (I_vis/2) ⊗ diag(e^-g,e^g)/(2cosh(g));
# partial trace of rho_g against every A_visible ⊗ I is Tr(A_visible)/2,
# for every real g and same exact identity comparison on the visible algebra.

fmt=lambda x:mp.nstr(x,26)
results={
    'source':'Paper7D-TechnicalMaterial-v1_46.tex',
    'source_span':[2817,4546],
    'tests':{
      'su3_heat_hessian_group_times':{'t_Hess':fmt(thal),'t_D4':fmt(td4),'R0_t_Hess':fmt(R(thal)),'R0_3t_Hess':fmt(R(3*thal))},
      'polymer_threshold':{'epsilon_crit':fmt(ecrit),'t_crit':fmt(tcrit),'kappa_max':fmt(kmax),'Q_3tHess':fmt(qbudget),'margin':fmt(free),'LambertW_defect_ceiling':fmt(rstop)},
      'optional_D4_bivector':{'vertices':len(vertices),'triangular_faces':len(faces),'frame_matrix':str(frame),'status':'EXACT_16I6'},
      'D4_comparison_tree_recursion':{'FN':fmt(fn),'FB':fmt(fb),'strict':True},
      'standard_heat':{'R0_at_2pi2':fmt(R(2*mp.pi**2)),'less_than_3_4689e-5':True},
      'positive_TV_oscillation':{'delta':fmt(delta),'difference':fmt(abs(q2-p)),'tanh_delta_over_4':fmt(mp.tanh(delta/4)),'saturates':True},
      'qft4_rank_two_E4':{'gapped_transfer':'diag(1,1,1/3)','observable':'diag(1,-1,0)','vacuum_states':['e1','e2'],'omega_alternates':['1','-1'],'J_K_minus_K_J':'0','J_A_minus_A_J':'0','scope':'adversarial test to printed absence of rank-one condition, not native-sector counterexample'},
      'uv_recurrence_E4':{'g_j_squared':'1/(j+1)','R_j':'1/(j+1)','rho':'1/2','forcing_exponent_p':2,'all_recurrences_checked':10000,'sum_R_diverges':'harmonic series','scope':'recurrence alone cannot prove UV telescoping summability'},
      'three_face_U1_Fourier':{'single_nonzero_mode_vanishes':True,'coupled_mode_survives':True},
      'rg_coordinate_Underdetermination_E4':{'visible_observables':'A_visible tensor identity_hidden','hidden_Gibbs_parameter':'any real g','visible_expectation':'Tr(A_visible)/2 independent of g','scope':'observable comparison does not fix invisible action coordinate'}
    }
}
out=Path('/mnt/data/Paper7D-Batch3IndependentResults-v1_1.json')
out.write_text(json.dumps(results,indent=2)+'\n')
print('Wrote',out, 'with',len(results['tests']),'test groups')
for k,v in results['tests'].items():print(k,v)
