#!/usr/bin/env python3
"""Independent exact identities and high-precision E2 numerical controls for VII-D lines 1-1239.
No paper/source mathematical content is modified.
"""
import sympy as s
from fractions import Fraction as F
import mpmath as mp
from pathlib import Path
import json
x,t,b,m,a,R =s.symbols('x t b m a R',real=True)
# Normalization: geometry of the equilateral spherical Hurwitz triangle
area=float(3*s.acos(s.Rational(1,3))-s.pi)
assert abs(area-0.5512855984)<1e-10
# Exact ordinary overlap Gram for finite involutions: use unit circle eigenvalue e^(i theta)
assert s.simplify((2-s.exp(s.I*x)-s.exp(-s.I*x))/4 - s.sin(x/2)**2)==0
# Accretive bound analytic derivative: negative for b>0, positive for b<0 and |b|<a
c=s.symbols('c',real=True)
q=(a+b*c)/(a*a+b*b+2*a*b*c)
der=s.factor(s.diff(q,c)); assert s.simplify(der-b*(b*b-a*a)/(a*a+b*b+2*a*b*c)**2)==0
# Zeta reference energy exact evaluation
zeta_g = s.simplify(s.Integer(8)*(s.zeta(-3)-s.zeta(-1)))
assert zeta_g == s.Rational(11,15)
# Positive gap mesh arithmetic
assert F(32,125)-F(11,56)==F(417,7000)
assert F(2576,10001)>F(32,125)
assert 3*16*18==864
# Kink profile Euler-Lagrange and normalized zero mode integrals
z=s.symbols('z',real=True); f=(1+s.tanh(z))/2
assert s.simplify(s.diff(f,z,2)-4*f*(1-f)*(1-2*f))==0
u=s.symbols('u',real=True)
assert s.simplify(s.integrate(s.sqrt(1-u*u),(u,-1,1))-s.pi/2)==0
# Singlet SUSY partner potentials
A= s.Rational(3,2)*s.tanh(z)
assert s.simplify(A*A-s.diff(A,z)-(s.Rational(9,4)-s.Rational(15,4)*s.sech(z)**2))==0
assert s.simplify(A*A+s.diff(A,z)-(s.Rational(9,4)-s.Rational(3,4)*s.sech(z)**2))==0
# Casimir heat representation bound at fixed sum k: lower and upper bounds algebraic
for k in range(1,36):
 for p in range(k+1):
  q=k-p
  C=F(p*p+q*q+p*q+3*p+3*q,3)
  assert F(k*(k+4),4)<=C<=F(k*(k+3),3)
  d=F((p+1)*(q+1)*(k+2),2)
  assert d<=F((k+2)**3,8)
mp.mp.dps=80
v0=mp.mpf(14383)/2500

def h(time):
 d=mp.mpf('0'); num=mp.mpf('0')
 for k in range(16):
  for p in range(k+1):
   q=k-p
   dim=mp.mpf((p+1)*(q+1)*(k+2))/2
   C=mp.mpf(p*p+q*q+p*q+3*p+3*q)/3
   w=dim*dim*mp.exp(-time*C/2)
   num += C*w; d+=w
 return num/(8*d)
rt=mp.findroot(lambda time: h(time)-1/(2*mp.pi**2), (mp.mpf('5.7'),mp.mpf('5.9')))
assert rt>v0 and abs(rt-mp.mpf('5.7532958466'))<mp.mpf('1e-10')
res={'source_range':'Paper7D-TechnicalMaterial-v1_46.tex:1-1239','hurwitz_unit_spherical_area':format(area,'.16f'), 'zeta_free_adjoint_energy_in_units_hbar_c_over_R':'11/15','mesh_extension_gap_lower_bound':'417/7000','spectral_root_diagnostic_not_exact_certificate':mp.nstr(rt,36),'heat_root_t0_margin_diagnostic_not_exact_certificate':mp.nstr(h(v0)-1/(2*mp.pi**2),25), 'check_kind':'E3 exact algebraic checks, E2 numeric diagnostic for heat root'}
print(json.dumps(res,indent=2))
Path('/mnt/data/work7d/Paper7D-Batch1AnalyticResults-v1_1.json').write_text(json.dumps(res,indent=2)+'\n')
