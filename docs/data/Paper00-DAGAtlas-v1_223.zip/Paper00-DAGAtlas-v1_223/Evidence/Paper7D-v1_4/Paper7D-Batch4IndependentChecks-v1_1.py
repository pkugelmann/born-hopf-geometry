#!/usr/bin/env python3
"""Paper VII-D lines 4547-6757: independent E3 and adversarial E4 checks.
Verification only; no paper edits, physical selector or theory development.
Source: Paper7D-TechnicalMaterial-v1_46.tex, framework v2.371.
"""
from __future__ import annotations
from fractions import Fraction
from itertools import combinations
from math import comb, sqrt
from pathlib import Path
from collections import Counter
import json, math, hashlib, subprocess
import mpmath as mp
import numpy as np
import sympy as sp

mp.mp.dps=55
results={}
def put(name,actual,description='',kind='E3'):
    results[name]={'verdict':'PASS' if kind=='E3' else 'ADVERSARIAL_EVIDENCE', 'result':actual,'scope':description,'kind':kind}

# Kinematic product trace at finite stage, valid for any chosen finite B.
A=sp.Matrix([[2,3],[5,7]]); B=sp.Matrix([[1,4,0],[2,-1,2],[0,1,3]])
assert sp.kronecker_product(A,B).trace()==A.trace()*B.trace()
put('finite_tensor_trace',str(A.trace()*B.trace()),'Direct finite tensor-factor identity; no state/measure factorization')

# Selector anti-isotonicity and multiplicity normal form.
sz=sp.diag(1,-1); I=sp.eye(2); S1=sp.kronecker_product(sz,I); S2=sp.kronecker_product(I,sz)
unknown=sp.symbols('a:16'); X=sp.Matrix(4,4,unknown)
comm1=list(X*S1-S1*X); comm2=list(X*S2-S2*X)
r1=sp.linsolve(comm1,unknown); r2=sp.linsolve(comm1+comm2,unknown)
n1=len(set().union(*(s.free_symbols for s in next(iter(r1)))))
n2=len(set().union(*(s.free_symbols for s in next(iter(r2)))))
assert n1==8 and n2==4
put('selector_commutant_anti_isotonicity',{'dim_B1_prime':n1,'dim_B1B2_prime':n2},'Exact linear commutator nullspaces for nested selector algebras')

# CCR expectation and geometric tail at three cited cutoffs.
ccr={}
for N in (8,32,128):
 p=Fraction(1,2)**N/(2*(1-Fraction(1,2)**(N+1)))
 eps=Fraction(N+1)*p
 ccr[N]={'power_law_gamma2':str(Fraction(1,N+1)), 'geometric_r_half':float(eps)}
assert abs(ccr[8]['geometric_r_half']-1.761e-2)<5e-6
assert abs(ccr[32]['geometric_r_half']-3.842e-9)<1e-12
assert abs(ccr[128]['geometric_r_half']-1.895e-37)<5e-40
put('ccr_cutoff_table',ccr,'One-mode truncated CCR expectation values and displayed decimals')
N=25
creation=sp.zeros(N+1); annih=sp.zeros(N+1)
for j in range(1,N+1):
 annih[j-1,j]=sp.sqrt(j);creation[j,j-1]=sp.sqrt(j)
assert annih*creation-creation*annih==sp.eye(N+1)-(N+1)*sp.eye(N+1)[:,N]*sp.eye(N+1)[N,:]
put('ccr_boundary_identity',f'[a_N,a_N†] = I-{N+1}|{N}><{N}|','Exact finite annihilator/creator matrices')
# The printed v2.350 theorem gives explicit in-domain counterexample to the earlier overclaim.
for N in (4,16,64):
 assert (N+1)*int(N-1==N)==0
put('ccr_overpromotion_counterexample','rho_N=|N-1><N-1|: epsilon_N=0 but mean occupation N-1→∞',
    'Expectation-level convergence is not sufficient for regular Weyl-state convergence',kind='E4')

# Finite decomposition does NOT alone provide Poisson correspondence or local hydro variables.
Qbell=sp.Matrix([1,0,0,1])*sp.Matrix([[1,0,0,1]])/2
p0=sp.eye(2); sx=sp.Matrix([[0,1],[1,0]]); sy=sp.Matrix([[0,-sp.I],[sp.I,0]]); zz=sp.diag(1,-1)
local=[sp.kronecker_product(s,p0) for s in (p0,sx,sy,zz)] + [sp.kronecker_product(p0,s) for s in (sx,sy,zz)]
Y=sp.Matrix.hstack(*(sp.Matrix(m).reshape(16,1) for m in local));target=Qbell.reshape(16,1)
assert Y.rank()==7 and Y.row_join(target).rank()==8
assert sp.zeros(4)*Qbell-Qbell*sp.zeros(4)==sp.zeros(4)
put('conserved_charge_not_automatically_local','Q=|Phi+><Phi+|, H=0: [H,Q]=0; Q not sum of on-site 2×2 densities',
    'With specified two-site local net, charge conservation alone does not construct local densities',kind='E4')

# 24-cell/face reference moments and SU(3) character orthogonality.
assert Fraction(1,81)+Fraction(2,36)==Fraction(11,162)
assert Fraction(11,162)/96==Fraction(11,15552)
put('haar_flux_moments',{'E_F':'1/9','Var_F':'11/162','Var_avg96':'11/15552'},
    'Exact SU(3) character orthogonality and pairwise face independence under independent Haar links')
# Traces of baryon determinant fan under three independent Haar variables.
assert Fraction(1,3)**3==Fraction(1,27)
put('haar_baryon_fan_second_moment','1/27','Independent normalized Haar three-path comparator, not interacting QCD')

# Clifford eigenpairs, degeneracies and exact ranks. n orbital l=n,n-2,...,
# j=l+1/2 (2l+2 states); for l>=1 j=l-1/2 (2l states).
R=7; w=sp.Integer(1); kap=sp.Rational(1,20)
levels=[]
for n in range(R+1):
 for ell in range(n,-1,-2):
  levels.extend([(n*w+kap*(n-ell),n,ell,'plus')]*(2*ell+2))
  if ell>=1:levels.extend([(n*w+kap*(n+ell+1),n,ell,'minus')]*(2*ell))
assert len(levels)==sum((n+1)*(n+2) for n in range(R+1))
counts=[];gaps={}
for r in range(R+1):
 if r<3: thr=sp.Rational(2*r+1,2)  # half-way between r and r+1, for kap=1/20
 else: thr=r+kap
 count=sum(int(bool(level[0]<thr)) for level in levels)
 counts.append(count)
 if r>=3:
  before=max(v[0] for v in levels if v[0]<=r)
  after=min(v[0] for v in levels if v[0]>r)
  assert before==r and after==r+2*kap
  gaps[r]=str(after-before)
assert counts==[2,8,20,28,50,82,126,184],counts
put('clifford_shell_count',{'R':7,'ranks':counts,'gaps_r3_to7':gaps},'Exact angular momentum/spinor degeneracy enumeration; comparison Hamiltonian only')
assert [comb(k+2,3) if k else 0 for k in range(5)]==[0,1,4,10,20]
put('symmetric_cube_rank_no_go',[0,1,4,10,20],'Rank Sym^3(T) cannot equal 14')
assert 16+4==20
put('spin4_cauchy_no_go',{'summands':[16,4],'permitted_kernel_dimensions':[0,4,16,20]},
    'Multiplicity-free Sym^3(C²⊗C²) decomposition under full Spin(4)')

# SU(3) heat character root check and sign derivative.
f=lambda t:(1+8*mp.exp(-3*t/2))/9-mp.exp(-2*t/3)
tstar=mp.findroot(f,(3,3.5))
assert abs(tstar-mp.mpf('3.200226335068'))<mp.mpf('1e-11')
assert f(mp.mpf('.1'))<0 and f(mp.mpf('10'))>0
put('heat_character_sign_change',{'t_star':mp.nstr(tstar,35),'f(0.1)':mp.nstr(f(mp.mpf('.1')),15),'f(10)':mp.nstr(f(10),15)},
    'Exact expression and unique positive root via one interior critical point')

# Clock cover cofinality: odd 5 never divides 3^j, every odd <= 2j+1 divides some (2k+1)!!
k=1
for j in range(2,10):k*=2*j+1
assert k%5==0 and all(pow(3,j,5)!=0 for j in range(1,20))
put('clock_odd_cover_divisibility',{'double_factorial_19':k,'divisible_by5':True},
    'Divisor-order cofinality check, not an orbital/spatial completion')

# Source dual mass coordinate transport on real 2×2 chart.
C=sp.Matrix([[2,1],[3,4]]); T=sp.Matrix([5,7]); O=sp.Matrix([11,13]);M=C.T.inv()*T
assert (M.T*C*O)[0]==(T.T*O)[0]
Gamma=sp.Matrix([[sp.Rational(1,7),3],[2,sp.Rational(1,5)]])
mu=sp.symbols('mu',positive=True);Cs=(sp.eye(2)+mu*Gamma)*C
Ms=Cs.T.inv()*T
lhs=sp.diff(Ms,mu); G=sp.diff(Cs,mu)*Cs.inv()
assert sp.simplify(lhs+G.T*Ms)==sp.zeros(2,1)
put('source_dual_contragredience',{'pairing':str((T.T*O)[0]),'mass_RGE':'verified exact symbolic'},
    'Real minimal source quotient; common noncritical invertible source chart only')

# Diagnostic rows are only arithmetic; use published E36 inferred from 878.316 and E40 from 2.20064404/sqrt2.
E36=878.316/4;E40=2.20064404/math.sqrt(2); eta=24/25
rows={'sigma_piN':(E36*eta/math.sqrt(24),43.0285207),
'm0':(4*E36,878.316),
'rho_omega':(E36*math.sqrt(eta)*math.sqrt(13),775.707688),
'phi':(E36*eta*math.sqrt(24),1032.68450),
'nucleon_iso':(E36*eta**(-1.5)*4,933.778660),
'sigma_sN':(E36*eta**(-1)/math.sqrt(24),46.6889330),
'Bd':(E40*math.sqrt(2),2.20064404),
'Balpha':(E36*eta**(-1.5)/(math.sqrt(6)+math.sqrt(12)+math.sqrt(6)),27.9137153)}
# Four+ significant figures; original source may use more precise upstream E36 than 878.316/4.
put('historical_split_grammar_table',{k: {'recomputed':v[0], 'printed':v[1], 'abs_difference':abs(v[0]-v[1])} for k,v in rows.items()},
    'Diagnostic-only arithmetic with rounded inferred E36, E40; no mass-operator claim')

# Dependency presence: the provided executable F40 v1_11 depends on absent v1_10.
script=Path('/mnt/data/work7d/Paper00-PetersenHodgePlucker-v1_11-verify.py')
assert script.is_file()
parent=script.with_name('Paper00-PetersenHodgePlucker-v1_10-verify.py')
assert not parent.exists()
put('F40_v1_11_dependency_missing','requires Paper00-PetersenHodgePlucker-v1_10-verify.py (not supplied)',
    'Unreplayable full certificate as archived; not a mathematical refutation',kind='E4')

out={'source':'Paper7D-TechnicalMaterial-v1_46.tex','scope_lines':[4547,6757],
 'independent_checks':results, 'checked_count':len(results),
 'note':'E3 results are exact or diagnostic only within stated hypotheses; E4 targets overclaimed inference/missing evidence.'}
path=Path('/mnt/data/Paper7D-Batch4IndependentResults-v1_1.json')
path.write_text(json.dumps(out,indent=2,ensure_ascii=False,default=str)+'\n')
print(json.dumps({'checks':len(results),'heat_root':str(tstar),'clifford_ranks':counts,'output':str(path),'split_arithmetic':{k:round(v[0]-v[1],6) for k,v in rows.items()}},indent=2))
