#!/usr/bin/env python3
"""Make rigorous Batch 2 ledger from frozen source census, E3 tests and E4 challenge.
No modifications to source archives; final atlas/audit archive reserved for final batch.
"""
from pathlib import Path
from collections import Counter,defaultdict
import hashlib, json, re, zipfile
root=Path('/mnt/data/bh4c_work')
stage=root/'staging'; papers=root/'papers/Paper00-PapersMinimal-v2_371'
src=papers/'Paper4C-TechnicalMaterial-v1_42.tex'
sc=json.load(open(stage/'Paper4C-CompleteSourceCensus-v1_1.json'))
ec=json.load(open(stage/'Evidence/Paper4C-Batch2IndependentChecks-v1_1.json'))
assert hashlib.sha256(src.read_bytes()).hexdigest()==sc['source_sha256']==ec['source_sha256']
first,last=1863,3434
selected=[c for c in sc['named_claims'] if first<=c['source_locator']['line_start']<=last]
assert len(selected)==26, len(selected)
statuses={
 'p4:rem:wick-claim-ledger':'FORMALIZED',
 'p4:thm:hamiltonian-generated-euclidean-branch':'VERIFIED',
 'p4:thm:complex-time-reciprocal-dynamics-square':'VERIFIED-CONDITIONAL',
 'p4:thm:finite-euclidean-hamiltonian-reconstruction':'VERIFIED',
 'p4:thm:finite-os-positivity':'VERIFIED-CONDITIONAL',
 'p4:thm:hamiltonian-transfer-reflection-positivity':'VERIFIED',
 'p4:rem:euclidean-hamiltonian-noncircular':'FORMALIZED',
 'p4:thm:v2109-gaussian-boundary-source':'VERIFIED-CONDITIONAL',
 'p4:prop:v2109-ground-width-collar':'VERIFIED',
 'p4:prop:v2109-stationarity-distinction':'VERIFIED',
 'p4:thm:v4118-transported-embedding-covariance':'VERIFIED-CONDITIONAL',
 'p4:cor:v4118-source-bound-spatial-ward':'REPRODUCED',
 'p4:lem:matrix-embedding-divisibility':'VERIFIED',
 'p4:thm:inductive-qft-bridge':'VERIFIED-CONDITIONAL',
 'p4:prop:inductive-reflection-positivity-inheritance':'VERIFIED-CONDITIONAL',
 'p4:rem:truncation-compatibility':'FORMALIZED',
 'p4:thm:compatible-local-net':'VERIFIED-CONDITIONAL',
 'p4:thm:weighted-conjugation-car-locality':'VERIFIED-CONDITIONAL',
 'p4:thm:approximate-microcausality':'UNRESOLVED',
 'p4:rem:microcausality-leakage-status':'FORMALIZED',
 'p4:rem:microcausality-status':'FORMALIZED',
 'p4:thm:quasifree-reconstruction':'REPRODUCED',
 'p4:rem:truncated-boson-quasifree-boundary':'FORMALIZED',
 'p4:prop:weak-ovd-smeared-fields':'REPRODUCED',
 'p4:thm:renormalization-semigroup':'VERIFIED-CONDITIONAL',
 'p4:cor:rg-universal-continuation-instance':'REPRODUCED'
}
assert len(statuses)==len(selected) and set(statuses)==set(c['id'] for c in selected)
source_lines=src.read_text().splitlines()
# Build current cross-source label map; locator != proof evidence.
source_label_map=defaultdict(list)
for f in papers.glob('*.tex'):
 for i,line in enumerate(f.read_text().splitlines(),1):
  for label in re.findall(r'\\label\{([^{}]+)\}',line):source_label_map[label].append({'file':f.name,'line':i})
occ=[(i,x) for i,line in enumerate(source_lines,1) if first<=i<=last for x in re.findall(r'\\ref\{([^{}]+)\}',line)]
missing=[(i,x) for i,x in occ if not source_label_map.get(x)]
ambiguous=[(i,x) for i,x in occ if len(source_label_map.get(x,[]))>1]
assert not missing and not ambiguous
# The paper's local proof for approximate microcausality is separated from the theorem
# by an intervening remark; correct the extractor limitation explicitly, not by silent shift.
override_proof={'p4:thm:approximate-microcausality':[3131,3162]}
# Unnamed material statements carry source locators and route controls.
material_steps=[
 {'id':'BH-IVC-B2-ST-001','line_range':[1933,1946],'description':'Scalar positive spectral weights and positive invertible whitening on the forward branch'},
 {'id':'BH-IVC-B2-ST-002','line_range':[2022,2051],'description':'Imaginary-axis anti-diagonal and positive-time CP dual evaluation'},
 {'id':'BH-IVC-B2-ST-003','line_range':[2131,2143],'description':'Cyclic reconstruction from scalar nonzero Z_a and Lagrange spectral projections'},
 {'id':'BH-IVC-B2-ST-004','line_range':[2233,2252],'description':'OS linear Gram factorization plus symmetric Fock/Wick polynomial extension'},
 {'id':'BH-IVC-B2-ST-005','line_range':[2343,2365],'description':'Transfer OS inner product equals half-space vector norm'},
 {'id':'BH-IVC-B2-ST-006','line_range':[2420,2450],'description':'Fixed-measure Gaussian determinant absolute normalization and Schur variation'},
 {'id':'BH-IVC-B2-ST-007','line_range':[2465,2484],'description':'Möbius collar map and unique positive oscillator fixed width'},
 {'id':'BH-IVC-B2-ST-008','line_range':[2545,2622],'description':'Complete moving parent embedding and coefficient frame connection cancellation'},
 {'id':'BH-IVC-B2-ST-009','line_range':[2687,2703],'description':'Full-matrix injective unital representation multiplicity obstruction'},
 {'id':'BH-IVC-B2-ST-010','line_range':[2747,2794],'description':'Isometric directed union, compatible state and compatible local automorphism'},
 {'id':'BH-IVC-B2-ST-011','line_range':[2881,2946],'description':'Exact support conditional local CAR/even subnet and closure'},
 {'id':'BH-IVC-B2-ST-012','line_range':[2990,3029],'description':'Duhamel weighted conjugation and CAR anticommutator LR transfer'},
 {'id':'BH-IVC-B2-ST-013','line_range':[3033,3111],'description':'Three independent spectral, occupation and dynamical inputs to conditional microcausality'},
 {'id':'BH-IVC-B2-ST-014','line_range':[3131,3162],'description':'Explicit truncated-boson proof step using compressed elementary defect in repeated graded Leibniz expansion','issue_ids':['BH-G-000102']},
 {'id':'BH-IVC-B2-ST-015','line_range':[3180,3237],'description':'Compatible quasi-free CAR and regular Weyl states and finite-support moment stabilization'},
 {'id':'BH-IVC-B2-ST-016','line_range':[3258,3331],'description':'Weak smeared field forms and stated test-topology continuity'},
 {'id':'BH-IVC-B2-ST-017','line_range':[3334,3424],'description':'State CP cocycle does not automatically imply coefficient RG projectability'}
]
# Free-form statement layer and epistemic route scoped; do not up-promote all clauses by controls.
qualified={
 'p4:thm:complex-time-reciprocal-dynamics-square':'Co-realization is conditional on one actual generated root and complete functional-calculus/parent grammar. No actual DYN role or independent time-to-cutoff identification.',
 'p4:thm:finite-os-positivity':'Bosonic positivity uses positive matrix weights plus supplied quasi-free/Wick higher moments; fermion criterion requires complete graded R and twist, not merely q>=0.',
 'p4:thm:v2109-gaussian-boundary-source':'Absolute Gaussian integral for C>0 on fixed dx and R^m. Wavefunction interpretation requires licensed boundary-amplitude map and K>0.',
 'p4:thm:v4118-transported-embedding-covariance':'Exact full-word transport with all sources, lifted projectors and central allocation; not a physical moving cutoff, not generic bosonic squeeze.',
 'p4:cor:v4118-source-bound-spatial-ward':'Conditional on full sourced family diagram and IV-B canonical Ward theorem; finite generator variation E3 only.',
 'p4:thm:inductive-qft-bridge':'Existence of coherent injective *-homomorphisms is an explicit domain condition; state and dynamics compatibilities independently supplied.',
 'p4:prop:inductive-reflection-positivity-inheritance':'Requires compatible positive-time subalgebras, reflections, states and graded products as applicable.',
 'p4:thm:compatible-local-net':'Assumes exact-support finite generators/locality (iii); no identification with the sharp spectral bandlimit.',
 'p4:thm:weighted-conjugation-car-locality':'Conditional on one-particle weighted conjugation hypothesis and quadratic number-preserving CAR dynamics.',
 'p4:thm:approximate-microcausality':'CAR and regular Weyl branches reproduce conditional bounds. Total-cap bosonic polynomial branch has a challenged compressed-CCR-to-multiword step; full statement remains unresolved, not refuted.',
 'p4:thm:quasifree-reconstruction':'Finite CAR branch E3 control. Regular Weyl branch and smooth GNS field domain source-replayed but not independently closed in this batch.',
 'p4:prop:weak-ovd-smeared-fields':'Weak form distribution only under continuity/smoothness; full operator realization additionally requires a genuine boundedness or closability criterion.',
 'p4:thm:renormalization-semigroup':'Coefficient matching functoriality, closed basis, differentiability and thresholds are supplied, not deduced from mere CPTP state coarse graining.',
 'p4:cor:rg-universal-continuation-instance':'III-A projectability and typed exact-continuation origin required; E4 rejects unconditional coefficient descent.'
}
status_counts=Counter(statuses.values())
local_proof_map={c['id']:c['source_locator'].get('proof_lines') for c in selected}
# E3 scopes are per check, not global claim-wide proofs.
entries=[]
for k,c in enumerate(selected,1):
 label=c['id'];loc=dict(c['source_locator'])
 if label in override_proof:loc['proof_lines']=override_proof[label]
 proofs=loc.get('proof_lines')
 entries.append({
  'id':f'BH-IVC-B2-CL-{k:03d}','source_label':label,'kind':c['kind'],
  'source_location':loc,'source_as_printed_title':c.get('title',''),
  'source_as_printed':c['source_as_printed'],
  'proof_as_printed':c.get('proof_as_printed') or ( '\n'.join(source_lines[override_proof[label][0]-1:override_proof[label][1]]) if label in override_proof else None),
  'statement_layer':'SOURCE-AS-PRINTED','disposition':statuses[label],
  'lifecycle':'UNDER-CHALLENGE' if statuses[label]=='UNRESOLVED' else 'ACTIVE',
  'source_replay':'E1_REPLAYED_WITH_SCOPES' if c['kind']!='remark' else 'E1_BOUNDARY_REVIEW',
  'E3_ids':[z['id'] for z in ec['checks'] if z['claim']==label and z['type']=='E3'],
  'E4_ids':[z['id'] for z in ec['checks'] if z['claim']==label and z['type']=='E4'],
  'E3_scope':'SCOPED_SUBCLAIM_CHECKS_ONLY' if any(z['claim']==label and z['type']=='E3' for z in ec['checks']) else 'NOT_INDEPENDENTLY_CERTIFIED_THIS_BATCH',
  'conditional_scope':qualified.get(label,'Source theorem/remark scope and its explicit stated antecedents only; no stronger occurrence inferred.'),
  'issues':['BH-G-000102'] if label=='p4:thm:approximate-microcausality' else [],
  'not_a_physical_occurrence_certification':True,
  'notes':('Extractor missed proof after intervening remark; manually located at 3131–3162' if label in override_proof else '')
 })
# Create explicit source-use witnesses only when actual local proof consumes earlier result.
material_edges=[
 ('p4:thm:finite-euclidean-hamiltonian-reconstruction','p4:thm:hamiltonian-generated-euclidean-branch','IMPORTED_PROOF',1981,'cyclic scalar branch',True),
 ('p4:lem:positive-frequency-generator-from-euclidean-block','p4:thm:hamiltonian-generated-euclidean-branch','IMPORTED_PROOF',1990,'same-carrier',True),
 ('p4:thm:hamiltonian-generated-euclidean-branch','p4:thm:complex-time-reciprocal-dynamics-square','REQUIRES',2001,'forward finite carrier branch',True),
 ('p2a:thm:evaluation-dual-corealization','p4:thm:complex-time-reciprocal-dynamics-square','IMPORTED_PROOF',2056,'physical co-realization conditional route',False),
 ('p2a:thm:universal-corealization-bridge-normal-form','p4:thm:complex-time-reciprocal-dynamics-square','IMPORTED_PROOF',2057,'rooted co-realization conditional route',False),
 ('p4:thm:finite-os-positivity','p4:thm:hamiltonian-transfer-reflection-positivity','CITATION_ONLY',2338,'graded exception and comparison, not premise of transfer proof',True),
 ('p4:thm:inductive-qft-bridge','p4:prop:inductive-reflection-positivity-inheritance','REQUIRES',2801,'compatible state extension',True),
 ('p4:thm:inductive-qft-bridge','p4:thm:compatible-local-net','REQUIRES',2940,'directed union and norm completion',True),
 ('p4:thm:inductive-qft-bridge','p4:thm:quasifree-reconstruction','REQUIRES',3217,'CAR directed union/state extension',True),
 ('p4:thm:quasifree-reconstruction','p4:prop:weak-ovd-smeared-fields','REQUIRES',3267,'inductive CAR/Weyl branch',True),
 ('p4:rem:truncated-boson-quasifree-boundary','p4:prop:weak-ovd-smeared-fields','ALTERNATIVE_ROUTE',3269,'polynomial moment-limit branch only',True),
 ('p4:thm:renormalization-semigroup','p4:cor:rg-universal-continuation-instance','REQUIRES',3409,'state-map cocycle',True),
 ('p3a:thm:generated-process-projectability','p4:cor:rg-universal-continuation-instance','IMPORTED_PROOF',3417,'coefficient readout/projectability route',True),
 ('p4:thm:approximate-microcausality','p4:rem:microcausality-status','INTERPRETATION_OF',3168,'scoped bandlimited theorem warning',True),
 ('p4:prop:no-exact-ccr','p4:thm:approximate-microcausality','CANDIDATE_LINK',3146,'truncation boundary defect is relied upon but explicit direct reference not in theorem proof',False),
]
typed=[]
for k,(frm,to,typ,ln,guard,reviewed) in enumerate(material_edges,1):
 typed.append({'id':f'BH-IVC-B2-EDGE-{k:03d}','from':frm,'to':to,'relation':typ,
  'proof_route':('car' if frm=='p4:thm:inductive-qft-bridge' else 'source-scoped'),
  'and_or_group':('OR:moment-limit' if typ=='ALTERNATIVE_ROUTE' else 'AND:source-supplied' if typ not in ('CITATION_ONLY','CANDIDATE_LINK') else 'NONMATERIAL'),
  'source_evidence':{'file':src.name,'line':ln},'domain_guard':guard,
  'review_status':'REVIEWED_MATERIAL_STEP' if reviewed and typ not in ('CITATION_ONLY','CANDIDATE_LINK','INTERPRETATION_OF') else 'NONPROPAGATING_OR_PENDING',
  'candidate_not_automatic':typ in ('CITATION_ONLY','CANDIDATE_LINK')})
# Exact source-evidence mismatch deliberately not hidden.
issue={
 'issue_id':'BH-G-000102','class':'MISSING_CONDITION','secondary_class':'LOGICAL_GAP',
 'severity':'moderate','lifecycle':'UNDER_CHALLENGE','issue_status':'unresolved',
 'first_origin':{'paper':'Paper4C','theorem_id':'p4:thm:approximate-microcausality',
                 'step_locator':f'{src.name}:3069-3072, proof 3145-3154',
                 'source_excerpt':r'compression by \(Q_N\) bounds it by'},
 'statement_layer':'SOURCE-AS-PRINTED',
 'exact_obligation':'Show that a small compressed elementary truncated-boson CCR defect Q[a_i,a_j^dagger]-delta Q controls Q[A,B]Q for arbitrary bounded finite local polynomials A,B; source calls Q chosen away from boundary but does not quantify its margin relative to polynomial word degree or bound internal boundary excursions.',
 'source_replayed':True,'independent_evidence':[],
 'adversarial_evidence':['BH-IVC-B2-E4-022','BH-IVC-B2-E4-028'],
 'constitution_boundary':'BND-IVC-B2-001',
 'conditions_consumed':['finite total occupation cutoff from IV-B','small compressed elementary CCR defect on Q','separate assumed spatial-overlap and dynamical-locality bounds'],
 'conditions_open':['quantified degree-relative occupation margin for every expanded word, OR an actual word-level leakage bound'],
 'counterexample_to_intermediate_implication':{'status':'VALID_ALGEBRAIC_COUNTERMODEL; NOT FULL S3 THEOREM REFUTATION',
   'total_cap':3,'Q_support':'total occupation <=2','two_modes':'orthogonal mode labels 1 and 2',
   'A':'(a_1^dagger)^2','B':'a_2^2',
   'compressed_elementary_CCR_defect':'zero for all pairs on Q',
   'compressed_quadratic_commutator':'<2,0|Q[A,B]Q|0,2>=2',
   'extended_control':'cap=5, Q<=3, A=(a_1^dagger)^3, B=a_2^3 gives 6 with two-layer margin'},
 'upstream_material_paths':[['p4:thm:gp1-bosonic-occupation-boundary','finite total-occupation cutoff branch','p4:thm:approximate-microcausality:3146-3154']],
 'downstream_verified_paths':[['p4:thm:approximate-microcausality','p4:rem:microcausality-status']],
 'other_papers_affected':[],
 'possible_unconfirmed_impacts':['Paper4B:lines 234,386 status/navigation mentions, not material proof-use verified', 'Any later physical microcausality readout that actually consumes bosonic polynomial branch'],
 'verified_bypass_routes':['CAR exact branch independent of bosonic occupation defect', 'regular Weyl branch with direct symplectic propagation estimate'],
 'why_it_matters':'The bosonic-polynomial route cannot be promoted to norm microcausality using only a compressed degree-one CCR defect; higher-degree occupation excursions can contribute despite vanishing degree-one compression.',
 'resolution_requirement':'Specify/check the required polynomial-degree-dependent safe-occupation depth (cf. source IV-B finite Wick theorem r-layer), or provide a bound on the full word-level boundary excursion; then audit with actual S3-localizer and dynamics hypotheses. No source repair performed.',
 'audit_scope_limit':'The 2-mode countermodel checks the isolated truncation-algebra implication. It does not instantiate or violate all S3 spectral overlap and finite dynamical-locality hypotheses; the full theorem is UNRESOLVED, not REFUTED.'
}
bnd={'id':'BND-IVC-B2-001','source_layer':'SOURCE-AS-PRINTED',
 'first_origin':{'paper':'Paper4B','source_label':'p4:thm:gp1-bosonic-occupation-boundary','file':'Paper4B-QuantumResponse-v1_42.tex','line':1466},
 'consumer':{'paper':'Paper4C','source_label':'p4:thm:approximate-microcausality','source_lines':[3069,3154]},
 'chronology':'IV-B finite capacity and optional exact initial-sublevel grammar precede IV-C auxiliary cutoff-locality comparisons',
 'kind':'[CONST] GP1 finite occupation at realized stage; [GEN] initial-sublevel only if separately generated boundary; [HOST] finite Fock cutoff matrix calculus; [DER] CCR defect; [REAL] not implied by host cutoff',
 'scope':'finite total cap, chosen Q sector, word degree, spatial bandlimit and dynamic locality independent conditions',
 'licensed_operations':['P_occ generated sublevel only if boundary role specified','finite CAR and truncated boson algebra','algebraic compression Q as readout'],
 'not_licensed':['unconditional physical occupation level','exact CCR on finite bosonic full carrier','infer boundary-free polynomial words from Q degree-one compression alone'],
 'exists_vs_realizes':'finite matrix cutoff mathematical test; does not assert an actually selected bosonic occupation cap',
 'review_result':'VALID_ALGEBRAIC_E4_AND_DEGREE_MARGIN_OPEN; no physical constructor-leakage refutation'}
conditions=[
 {'name':'positive finite Euclidean H and invertible C0','source_first_line':1912,'epistemic_status':'STIPULATED','type':'finite operators H>=0,C0>0','consumers':['p4:thm:hamiltonian-generated-euclidean-branch','p4:thm:complex-time-reciprocal-dynamics-square']},
 {'name':'positive scalar kernel spectral weights','source_first_line':2084,'epistemic_status':'STIPULATED/DERIVED-ON-FORWARD-BRANCH','type':'finite scalar C(t) with nonnegative Z_a,E_a','consumers':['p4:thm:finite-euclidean-hamiltonian-reconstruction']},
 {'name':'higher bosonic quasi-free Wick extension','source_first_line':2169,'epistemic_status':'CONDITIONAL','type':'correlations beyond two-point','consumers':['p4:thm:finite-os-positivity']},
 {'name':'graded OS reflection/twist/factorization','source_first_line':2177,'epistemic_status':'CONDITIONAL','type':'Z2-graded algebraic OS data','consumers':['p4:thm:finite-os-positivity']},
 {'name':'Hamiltonian transfer ground vector','source_first_line':2277,'epistemic_status':'STIPULATED','type':'H>=0,H Omega=0','consumers':['p4:thm:hamiltonian-transfer-reflection-positivity']},
 {'name':'fixed Gaussian dx, domain and positive C','source_first_line':2420,'epistemic_status':'STIPULATED','type':'real finite Gaussian coefficient data','consumers':['p4:thm:v2109-gaussian-boundary-source']},
 {'name':'licensed quantum boundary-amplitude interpretation','source_first_line':2431,'epistemic_status':'CONDITIONAL','type':'map from positive Euclidean weight to wave amplitude','consumers':['p4:thm:v2109-gaussian-boundary-source']},
 {'name':'licensed full parent first-order word and actual transport','owner':'Paper3F:p3f:thm:v1148-finite-metric-constructor','source_use_line':2527,'epistemic_status':'INHERITED-CONDITIONAL','consumers':['p4:thm:v4118-transported-embedding-covariance','p4:cor:v4118-source-bound-spatial-ward']},
 {'name':'coherent algebra embeddings and separately compatible states/dynamics','source_first_line':2712,'epistemic_status':'CONDITIONAL','type':'injective *-homomorphisms and projective compatibility','consumers':['p4:thm:inductive-qft-bridge','p4:prop:inductive-reflection-positivity-inheritance','p4:thm:quasifree-reconstruction']},
 {'name':'exact finite support locality for regions','source_first_line':2883,'epistemic_status':'CONDITIONAL','type':'subspace isotony, embedding and graded locality','consumers':['p4:thm:compatible-local-net']},
 {'name':'DLOC weighted conjugation or direct propagator control','source_first_line':2990,'epistemic_status':'CONDITIONAL','type':'norm bound for weighted h_N','consumers':['p4:thm:weighted-conjugation-car-locality','p4:thm:approximate-microcausality']},
 {'name':'bandlimited spatial localizer operator norm leakage rate','source_first_line':3059,'epistemic_status':'CONDITIONAL','type':'E_N J_O overlap rate; not implied by spectral cutoff','consumers':['p4:thm:approximate-microcausality']},
 {'name':'occupation-truncated CCR boundary control','owner':'Paper4B:p4:thm:gp1-bosonic-occupation-boundary','source_use_line':3069,'epistemic_status':'INHERITED-CONDITIONAL','consumers':['p4:thm:approximate-microcausality'],'issue_ids':['BH-G-000102']},
 {'name':'compatible quasi-free CAR/regular CCR states','source_first_line':3180,'epistemic_status':'CONDITIONAL','type':'inductive covariance and state regularity','consumers':['p4:thm:quasifree-reconstruction']},
 {'name':'locally convex test topology and all required continuous matrix elements','source_first_line':3262,'epistemic_status':'CONDITIONAL','type':'test space and weak forms','consumers':['p4:prop:weak-ovd-smeared-fields']},
 {'name':'functorial closed operator-coefficient matching','source_first_line':3350,'epistemic_status':'CONDITIONAL','type':'G_r finite basis and R maps, projectability','consumers':['p4:thm:renormalization-semigroup','p4:cor:rg-universal-continuation-instance']},
]
# For conditions already owned upstream no duplicate assumption node inserted in final graph; review markers only.
for n,c in enumerate(conditions,1):c.update({'review_id':f'BH-IVC-B2-COND-REVIEW-{n:03d}','canonical_integration':'REUSE_UPSTREAM' if c.get('owner') else 'LOCAL_FIRST_THEOREM_DOMAIN_NOT_NEW_AXIOM'})
proof_routes=[
 {'target':'p4:thm:finite-euclidean-hamiltonian-reconstruction','route':'kernel-first','required':['finite scalar positive spectral weights'],'conclusion':'cyclic positive Hamiltonian, not original carrier'},
 {'target':'p4:thm:hamiltonian-generated-euclidean-branch','route':'Hamiltonian-first','required':['supplied H>=0','C0>0'],'conclusion':'same-carrier H and entire positive-time branch'},
 {'target':'p4:thm:finite-os-positivity','route':'bosonic-Wick','required':['Z_a>=0 as matrices','quasi-free Wick extension','neutral/charged compatible reflection'],'conclusion':'ordinary bosonic OS'},
 {'target':'p4:thm:finite-os-positivity','route':'graded-Fermi','required':['graded factorization','Theta','twist','full R>=0'],'conclusion':'finite algebraic graded OS iff R PSD'},
 {'target':'p4:thm:hamiltonian-transfer-reflection-positivity','route':'transfer-direct','required':['positive H','ground Omega','ordinary reflection'],'conclusion':'OS Gram square independent of Wick'},
 {'target':'p4:thm:approximate-microcausality','route':'CAR','required':['spectral overlap','DLOC_alg','even observables or graded odd','uniform constants'],'status':'REPRODUCED-CONDITIONAL'},
 {'target':'p4:thm:approximate-microcausality','route':'regular-Weyl','required':['symplectic DLOC_LR','bounded Weyl word coefficients'],'status':'REPRODUCED-CONDITIONAL'},
 {'target':'p4:thm:approximate-microcausality','route':'total-cap-bosonic-polynomials','required':['spatial overlap','DLOC_alg','truncated occupation boundary','degree-relative margin unresolved'],'status':'UNDER_CHALLENGE','issue_ids':['BH-G-000102']},
 {'target':'p4:prop:weak-ovd-smeared-fields','route':'exact-CAR-Weyl','required':['compatible quasi-free state','matrix element continuity','Weyl smooth vector subcore'],'status':'REPRODUCED-CONDITIONAL'},
 {'target':'p4:prop:weak-ovd-smeared-fields','route':'bosonic-moment-limit','required':['vanishing tails for every fixed word degree','compatible 2-point','test topology continuity'],'status':'REPRODUCED-CONDITIONAL'},
 {'target':'p4:cor:rg-universal-continuation-instance','route':'coarse-state','required':['functorial CPTP maps','certified generated origin'],'status':'REPRODUCED-CONDITIONAL'},
 {'target':'p4:cor:rg-universal-continuation-instance','route':'closed-coefficient','required':['coarse-state plus factorization/projectability','effective matching functoriality'],'status':'REPRODUCED-CONDITIONAL'}
]
# Core evidence rows, keeping separate checks and affected branches.
batch={
 'audit':'Paper4C','batch':2,'revision':'v1_1','source_authority':'Paper00-PapersMinimal-v2_371',
 'source_file':src.name,'source_sha256':sc['source_sha256'],
 'source_coverage':{'start':first,'end':last,'total_lines':sc['source_line_count'],
 'named_checked':len(entries),'named_total':sc['named_count'],'cumulative_named_checked':38+len(entries),
 'cumulative_named_remaining':sc['named_count']-(38+len(entries)),
 'formal_results_in_batch':sum(c['kind'] in ('theorem','lemma','proposition','corollary') for c in selected),
 'display_environments_reviewed':sum(first<=x['line_start']<=last for x in sc['display_equations']),
 'display_environments_total':sc['display_count'],
 'material_unnamed_steps':len(material_steps),'material_steps_ledger':material_steps,
 'out_of_scope':'Paper IV-C 3435–10934 and global audit of remote papers'},
 'status_counts':dict(status_counts), 'previous_batch_source_count':38,
 'cumulative_status_counts':dict(Counter(json.load(open(stage/'Batches/Paper4C-AuditBatch1-v1_1.json'))['status_counts'])+status_counts),
 'claimed_status_basis':'E1 printed proof replay and typed conditional domains + scoped E3/E4 controls; no claim-wide status inferred from a small model alone',
 'named_claim_ledger':entries,
 'source_reference_audit':{'ref_occurrences':len(occ),'unique_ref_labels':len(set(x[1] for x in occ)), 'all_present_in_current_source_map':True, 'missing':missing,'ambiguous':ambiguous,
 'caveat':'Current source locator is navigation; semantics of each import require proof-use evidence'},
 'source_proof_use_edges':typed,'proof_route_review':proof_routes,
 'independent_checks_file':'Evidence/Paper4C-Batch2IndependentChecks-v1_1.json','independent_check_count':ec['count'], 'independent_check_passed':ec['passed_count'],
 'found_issues':[issue], 'boundary_review':[bnd],
 'canonical_condition_review':conditions,
 'adversarial_challenges':[z for z in ec['checks'] if z['type']=='E4'],
 'negative_evidence_note':'E4 003 and 026 refute stronger NOT PRINTED claims; E4 022,028 target actual proof inference but do not supply complete in-domain S3 countermodel; E4 027 states the guard is assumed.',
 'controlling_imports':[{'owner':'IV-B','labels':['p4:lem:positive-frequency-generator-from-euclidean-block','p4:thm:v2109-euclidean-weight-support','p4:thm:v4106-canonical-stress-ward','p4:prop:no-exact-ccr','p4:thm:finite-wick-quasifree-calculus','p4:thm:gp1-bosonic-occupation-boundary']},
 {'owner':'III-F','labels':['p3f:thm:v1148-finite-metric-constructor']},
 {'owner':'III-A','labels':['p3a:thm:universal-generated-exact-continuation','p3a:thm:generated-process-projectability']},
 {'owner':'II-A','labels':['p2a:thm:evaluation-dual-corealization','p2a:thm:universal-corealization-bridge-normal-form']}],
 'open_verification_gates':[{'target':'p4:thm:approximate-microcausality','gate':'Quantified bosonic polynomial-degree-to-occupation-margin obligation; E4 isolated commutator tests supply algebraic witness; full S3-localizer guards not countertested'},
 {'target':'p4:thm:quasifree-reconstruction','gate':'Independent general CCR Weyl inductive and GNS-domain certification beyond finite CAR control'},
 {'target':'p4:prop:weak-ovd-smeared-fields','gate':'Independent full test-topology/regular Weyl subcore verification; no operator-valued strengthening without closability'},
 {'target':'p4:cor:v4118-source-bound-spatial-ward','gate':'Imported IV-B canonical stress Ward source-jet proof not independently reaudited; preserve full source marks'},
 {'target':'p4:cor:rg-universal-continuation-instance','gate':'Source-replayed III-A constructor origin/projectability; independent G0 realization not inferred'}],
 'agent_mode':'single coordinator, separate sequential E1/E3/E4 passes; no concurrent agents claimed',
 'batch_closure':'PARTIALLY_AUDITED_OVERALL_WITH_ONE_UNRESOLVED_LOCAL_PROOF_SCOPE_ISSUE',
 'overall_full_audit_ready':False,
 'successor_archive_policy':'NO_DAG_ZIP_OR_AUDIT_ZIP_IN_INTERMEDIATE_BATCH; final batch only',
 'no_source_modification':True,
 'latest_supplied_dag_input':'Paper00-DAGAtlas-v1_108(1).zip',
 'latest_supplied_audit_input':'Paper00-ProofChainAudits-v1_25(1).zip',
}
# Assert source-to-entry, status, proof locations and evidence integrity.
assert set(statuses)==set(x['source_label'] for x in entries)
assert len(material_steps)==17
assert ec['count']==28 and ec['passed_count']==28
assert sum(status_counts.values())==26
assert batch['source_coverage']['cumulative_named_checked']==64
assert len({e['id'] for e in entries})==len(entries)
assert len({e['id'] for e in typed})==len(typed)
assert len({e['review_id'] for e in conditions})==len(conditions)
assert issue['issue_id'] not in json.dumps(json.load(open(stage/'Batches/Paper4C-AuditBatch1-v1_1.json')))
out=stage/'Batches/Paper4C-AuditBatch2-v1_1.json';out.write_text(json.dumps(batch,indent=2,ensure_ascii=False)+'\n')
# Report is durable, explicitly states one unresolved issue and full source coverage.
md=[]
md+=['# Paper IV-C — Rigorous Verification DAG audit, Batch 2 (v1_1)','']
md += [f'**Controlling source:** `{src.name}` SHA-256 `{sc["source_sha256"]}` from `Paper00-PapersMinimal-v2_371`.','']
md += [f'**Audited Batch 2:** lines **{first:,}–{last:,}** of {sc["source_line_count"]:,}; **{len(entries)}** named statements, **{len(material_steps)}** material unnamed steps; **{batch["source_coverage"]["display_environments_reviewed"]}/{sc["display_count"]}** displayed equation environments covered in this batch. Cumulative: **64/186** named; **122** remain unaudited.','']
md += ['**Statuses (Batch 2):** '+', '.join(f'{x}: {status_counts[x]}' for x in ['VERIFIED','VERIFIED-CONDITIONAL','REPRODUCED','FORMALIZED','UNRESOLVED'])+'.','']
md += [f'**Evidence:** {ec["count"]}/{ec["count"]} scoped controls passed (**23 E3 independent** + **5 E4 adversarial**); a successful adversarial control is evidence of a vulnerability or correct restriction, not a theorem verification. One proof-scope issue remains open, with no full theorem-domain refutation established.','']
md += ['## Source-as-printed ledger (26/26)','','| Line | Exact source label | Status | E3 | E4 |','|---:|---|---|---|---|']
for e in entries:
 e3=', '.join(x.split('-')[-1] for x in e['E3_ids']) or '—'
 e4=', '.join(x.split('-')[-1] for x in e['E4_ids']) or '—'
 md.append(f"| {e['source_location']['line_start']} | `{e['source_label']}` | {e['disposition']} | {e3} | {e4} |")
md += ['','## Main evidence-backed results','']
md += ['- **Finite Euclidean bridges:** the Hamiltonian-first positive kernel and kernel-first cyclic reconstruction are distinct; direct finite spectral and semigroup controls passed. The original-carrier identification is not inferred from arbitrary positive Euclidean data.']
md += ['- **Finite reflection positivity:** matrix-positive spectral weights plus an explicitly supplied bosonic Wick extension imply ordinary OS; the graded fermionic branch requires its full reflection matrix and twist. Hamiltonian transfer yields a separate Gram-square argument without Wick factorization.']
md += ['- **Gaussian and stationarity:** complete-square integration, absolute determinant variation, collar Möbius composition, positive absorbing width and the distinction between normalized excited Euclidean stationarity and unnormalized ground support all reproduced.']
md += ['- **Transported embedding:** nonunitary coefficient-frame polar factor is unitary after normalization, and the moving-frame connection sign and parent B-cancellation were checked with independent finite matrices. Spatial Ward transfer still requires its full IV-B actual-source diagram.']
md += ['- **Inductive limit and local nets:** injective algebra embeddings, compatible states/dynamics, finite OS-inheritance, exact-support even CAR locality and quadratic CAR weighted-conjugation bounds are sound at their stated conditional domains. No G0 physical mode-refinement or sharp spectral overlap rate is selected merely by the existence of an inductive algebra.']
md += ['- **Field and RG:** compatible quasi-free CAR reconstruction and regular-Weyl/moment-limit interfaces preserve distinct operator domains; weak smeared-field distributions require continuity. CPTP scale contraction alone does not yield a coefficient beta flow without typed matching and projectability.']
md += ['','## Open issue BH-G-000102 — degree-relative bosonic boundary control','']
md += ['- **Class/severity:** `MISSING_CONDITION` / moderate; `UNDER_CHALLENGE`; affects only the occupation-truncated finite polynomial route of `p4:thm:approximate-microcausality` (source 3069–3085 and proof 3145–3154). CAR and regular Weyl bypasses are not challenged by this witness.']
md += ['- **Exact algebraic witness:** in two bosonic modes with total occupation cap 3, take `Q=P_{n≤2}`, `A=(a_1†)^2`, `B=a_2^2`. Each elementary truncated CCR defect satisfies `Q([a_i,a_j†]−δ_ij I)Q=0`, yet the exact finite matrix calculation gives `⟨2,0|Q[A,B]Q|0,2⟩=2`. With cap 5, `Q=P_{n≤3}`, and local cubic words the analogous value is 6 although the degree-one defect again vanishes.']
md += ['- **Adjudication:** this falsifies the intermediate inference that compressed degree-one CCR control by itself bounds arbitrary higher-degree polynomial commutators. However, the source says `Q` is “chosen away from the bosonic truncation boundary”; its precise **degree-relative** strength is not specified. The finite-mode countermodel does **not** certify all source S³ spectral-localizer assumptions, so the full theorem is **UNRESOLVED, not REFUTED**.']
md += ['- **Required evidence, not a new physical axiom:** quantify the safe-occupation distance against the actual polynomial word degree (compare the already printed IV-B Wick boundary-layer `N-r`) or establish a direct word-level defect estimate. Then verify the independent spatial and dynamical localization hypotheses. No TeX source has been altered.']
md += ['','## Conditional domains / non-issues','','The positive finite spectral branch, fixed Gaussian measure, exact graded reflection, licensed parent/embedding, isometric inductive maps, exact-support local mode spaces, small spectral overlap, stable states, Wightman-style operator domain, and functorial effective coefficient matching are all explicit theorem-domain premises. Their lack of an unconditional physical occurrence is **not** being misclassified as a mathematical defect.','']
md += ['## Dependency and traceability','']
md += [f'- All **{len(occ)}** source `\\ref` occurrences (to **{len(set(x[1] for x in occ))}** unique labels) in the batch resolve uniquely in the supplied current TeX corpus; this is E0 only.','']
md += ['- Imported proof interfaces checked in source: II-A rooted co-realization; III-F finite first-order metric constructor; III-A generated continuation and projectability; IV-B same-carrier criterion, finite Wick boundary layer, occupation capacity and canonical stress Ward. Full re-audits of these papers were *not* carried out.','']
md += ['- Issue path: `IV-B occupation boundary` → `IV-C compressed polynomial microcausality step` → `IV-C microcausality scope remark`. Two IV-B mentions of the theorem are navigation, not yet certified remote material descendant paths.','']
md += ['- Separate routes preserved: kernel-first vs Hamiltonian-first; ordinary/Wick vs transfer vs graded OS; exact-support vs spectral-bandlimited locality; CAR vs Weyl vs boson-cutoff; coarse-state vs coefficient RG. OR branches have not been collapsed into one assumption conjunction.','']
md += ['## Continuation and packaging','']
md += ['The next section begins at **line 3,435** (`Time-dependent modes and curved backgrounds`), with its next named theorem at **line 3,443**. Overall **PARTIALLY_AUDITED** (64/186 named). Only batch files and independent evidence have been written; the **successor DAG ZIP** and **proof-chain audit ZIP** are reserved for the final batch, preserving the latest supplied corpus versions and retaining only the newest per-file versions.','']
md += [f'**Evidence file:** `Paper4C-Batch2IndependentChecks-v1_1.json` ({ec["count"]} controls); **ledger file:** `Paper4C-AuditBatch2-v1_1.json`; **source unchanged**.']
(stage/'Batches/Paper4C-AuditBatch2-v1_1.md').write_text('\n'.join(md)+'\n')
print('CREATED',out, stage/'Batches/Paper4C-AuditBatch2-v1_1.md')
print('STATUS',status_counts,'REFS',len(occ),'CUMULATIVE',64,'ISSUE',issue['issue_id'])
