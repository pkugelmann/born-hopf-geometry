#!/usr/bin/env python3
"""Source-frozen rigorous verification Batch 5, no edits to supplied manuscripts or ZIPs.
This is a staged source/E3/E4 audit record, *not* a completed global DAG release.
"""
from pathlib import Path
from collections import Counter, defaultdict
import json,re,hashlib
root=Path('/mnt/data/bh4c_work'); stage=root/'staging'; src=root/'papers/Paper00-PapersMinimal-v2_371'; tex=src/'Paper4C-TechnicalMaterial-v1_42.tex'
srcbytes=tex.read_bytes();text=srcbytes.decode();lines=text.splitlines();sourcehash=hashlib.sha256(srcbytes).hexdigest()
census=json.loads((stage/'Paper4C-CompleteSourceCensus-v1_1.json').read_text());assert census['source_sha256']==sourcehash
prev=json.loads((stage/'Batches/Paper4C-AuditBatch4-v1_1.json').read_text());assert prev['source_sha256']==sourcehash and prev['source_coverage']['end']==6900
lo,hi=6901,8563
claims=[c for c in census['named_claims'] if lo<=c['source_locator']['line_start']<=hi];assert len(claims)==24
checks=json.loads((stage/'Evidence/Paper4C-Batch5IndependentChecks-v1_1.json').read_text());assert checks['total_controls']==checks['passed']==39
statuses={
'p4:prop:unital-coarse-entropy':'VERIFIED',
'p4:thm:v2211-correlated-landauer':'VERIFIED',
'p4:cor:v2211-product-landauer':'VERIFIED',
'p4:prop:v2211-correlated-erasure-witness':'VERIFIED',
'p4:cor:clifford-midpoint-adiabatic':'VERIFIED-CONDITIONAL',
'p4:thm:exact-finite-system-environment-reduction':'VERIFIED-CONDITIONAL',
'p4:thm:fixed-finite-bath-semigroup-rigidity':'VERIFIED',
'p4:thm:microscopic-bath-gkls':'FORMALIZED',
'p4:rem:microbath-status':'FORMALIZED',
'p4:thm:lie-closure-controllability':'VERIFIED-CONDITIONAL',
'Paper4C-remark-line-7737':'FORMALIZED',
'p4:thm:finite-kl-recovery':'VERIFIED',
'p4:def:reeb-sensitive-readout':'FORMALIZED',
'p4:thm:derived-reeb-phase-signature':'VERIFIED-CONDITIONAL',
'p4:cor:reeb-apparatus-overlap-interface':'VERIFIED-CONDITIONAL',
'p4:thm:v2188-moment-pencil':'VERIFIED-CONDITIONAL',
'p4:prop:v239-visible-schur-residue':'VERIFIED',
'p4:cor:v2188-common-moments':'VERIFIED-CONDITIONAL',
'p4:thm:v2191-source-cofactor':'VERIFIED',
'p4:cor:v2191-adjacent-cofactor':'VERIFIED-CONDITIONAL',
'p4:v2171:thm:finite':'VERIFIED',
'p4:thm:native-source-constant-cyclic':'VERIFIED-CONDITIONAL',
'p4:cor:native-source-determinant-zero':'VERIFIED-CONDITIONAL',
'p4:cor:native-source-square-polynomial':'VERIFIED-CONDITIONAL',
}
assert set(statuses)=={c['id'] for c in claims}
notes={
'p4:prop:unital-coarse-entropy':('Unital CPTP on *fixed* finite matrix algebra; nested trace-preserving expectations E_{r+1}E_r=E_{r+1}; semigroup is explicitly unital. Nonunital subsystem entropies excluded.','Relative entropy contractivity against I/d; semigroup factorization and conditional-expectation composition. Entropy is not a universal time arrow.'),
'p4:thm:v2211-correlated-landauer':('Supplied finite joint unitary and actual M|B partition; initial bath marginal a faithful Gibbs state, but M/B may be correlated; fixed H_B and beta>0.','Joint entropy conservation and Gibbs logarithm give exact beta Q=delta S_M + delta I + D; no Markov limit.'),
'p4:cor:v2211-product-landauer':('Additional factorization rho_MB=rho_M tensor tau_B; reset-error statement uses initial maximally mixed classical bit and final entropy <=epsilon.','Mutual information and relative entropy nonnegative; finite faithful bath rank excludes exact product pure-reset of mixed M.'),
'p4:prop:v2211-correlated-erasure-witness':('Two qubits initially classically correlated with thermal bath marginal for H_B=0; controlled NOT is an actual finite joint unitary.','Exact CNOT consumes correlation Delta I=-ln2 while memory entropy falls ln2 and bath heat stays zero.'),
'p4:cor:clifford-midpoint-adiabatic':('Supplied C^2 protected path, C^2 pair energies with strictly positive gap, actual Hamiltonian realizes Clifford P_±.','Import Paper2C protected rank-two frames; gapped finite adiabatic estimate; both signs have connection A=U†dU/2 and F=-Theta^2/4.'),
'p4:thm:exact-finite-system-environment-reduction':('A finite chosen S⊗E partition, fixed sigma_E and H_tot, product assignment, time-independent finite H_tot. Semigroup conclusion explicitly conditional.','Kraus K_ba=sqrt(q_a)<f_b|U_t|a> implies CPTP; the GKLS form only follows if exact semigroup hypothesis separately holds.'),
'p4:thm:fixed-finite-bath-semigroup-rigidity':('Same bath/state/total finite time-independent H for all real t, and exact all-time positive-time semigroup law.','Exponential-polynomial analyticity extends semigroup law to negative times; channel and inverse both CPTP; unital dual multiplicative domain yields inner *-automorphism.'),
'p4:thm:microscopic-bath-gkls':('Disjoint routes: (i) stationary mixing C*-reservoir with weighted correlations and all-order cumulant estimates, (ii) independent fresh-probe maps with uniform expansion, (iii) simultaneous large-bath/weak-coupling with uniform assumptions and recurrence separation. These are not consequences of GP2 alone.','Finite collision Euler/GKLS route checked; Bohr secular, positive Fourier coefficient, pointer complex kappa and KMS algebra checked. All-order reservoir/Davies convergence remains an imported conditional theorem; full independent E3 was not completed.'),
'p4:rem:microbath-status':('Source interpretation only; exact fixed finite bath and true reservoir/fresh-probe/large-bath limits must be kept distinct.','No inference from a pre-recurrence fit to an exact irreversible all-time semigroup; sources remain conditional.'),
'p4:thm:lie-closure-controllability':('Piecewise-constant controls admitted with span one-parameter flows, concatenations AND inverse reachable in closure; no bounded control time. G may be nonclosed.','Every reachable word lies in G, Lie–Trotter/commutator approximation generates G inside closure R. Dense SU(d) case follows when Lie algebra is su(d).'),
'Paper4C-remark-line-7737':('Analytic subgroups of compact unitary groups need not be closed; example irrational diagonal slope.','Irrational one-parameter winding is dense in torus while subgroup is proper; no claim that bounded-time generation is dense.'),
'p4:thm:finite-kl-recovery':('Finite CPTP noise with correctable code projection and exact PC_a†C_bP=alpha_ab P.','Diagonalize alpha>=0, orthogonal syndrome ranges, inverse partial isometries and trace-filling complement give exact CPTP recovery.'),
'p4:def:reeb-sensitive-readout':('Explicit *definition* of L2loc real residual with a.e. covariance for supplied step s L_H; s is apparatus/rank-channel input.','Definition supplies covariance law, not its realization or physical periodic log-energy data; prior REG_sigma family remains unfixed.'),
'p4:thm:derived-reeb-phase-signature':('Source-defined Reeb-covariant L2 residual, T=sL_H>0, and nonconstant case for fundamental-period formula; actual apparatus and REG_sigma not selected.','L2 circle Fourier expansion and support gcd: T is a period; least positive is T/d iff nonconstant, otherwise no least period.'),
'p4:cor:reeb-apparatus-overlap-interface':('Specified real L2 transfer functional on circle; no first-harmonic or physical conversion factor derived from GP2.','Standard orthogonal Fourier projection yields a_E,b_E; normalization factors are separate apparatus input.'),
'p4:thm:v2188-moment-pencil':('Inherited *complete* stationary H,q, exact support P and self-adjoint ad_H quotient T; canonical rho_P is only a calculation pairing; v!=0.','Positive Krylov Gram K_d, closure det K_{d+1}=0 requires moments m_2d; generalized Hermitian Hankel eigenvalue pencil gives distinct visible roots and positive weights.'),
'p4:prop:v239-visible-schur-residue':('Finite Hermitian full H, fixed orthogonal split, lambda simple in full H and outside spec C; source in upper block.','Schur inverse residue equals spectral projector upper block; derivative S prime strictly positive. Definite complement excludes a nonzero coupled unshifted scalar root.'),
'p4:cor:v2188-common-moments':('Independently licensed complete stationary charts, equal fixed cyclic d, canonical moments match through m_{2d-1}, and cyclic degree is separately certified by m_{2d}.','Shared Gram, Jacobi and Vandermonde weights give an isometric source-cyclic intertwiner, not a total carrier map; actual pairings only if separately matched.'),
'p4:thm:v2191-source-cofactor':('T finite Hermitian and source map V; ordinary unweighted trace of V† adj(zI-T)V.','Spectral resolvent positive weights prevent cancellation of supported distinct roots, gcd cancels full degeneracy factors; rank appended column criterion tests visibility.'),
'p4:cor:v2191-adjacent-cofactor':('Inherited fixed-energy/charge exact support and two complete adjacent T_±,Q_±; positive frequency and global ground for removal exclusion.','Apply cofactor theorem to each branch and LCM; global ground gives T_- >=0, so removal poles lie at nonpositive frequencies.'),
'p4:v2171:thm:finite':('Complete constant finite H on autonomous interval, actual charge Q and input state rho_i; signed reversal is only mathematical diagnostic unless separately licensed CP.','Charge expectation derivative is entire and all Krylov moments vanish iff derivative vanishes; nonzero Taylor coefficient certifies nonconstant charge history, not endpoint sign.'),
'p4:thm:native-source-constant-cyclic':('Supplied native midpoint B_R plus constant b·sigma_E and singlet s0; b is NOT a selected physical mass/current insertion.','Parallel constant sector reduces to singlet-triplet 2×2 plus two invisible triplets, giving spectrum, resolvent and source-cyclic roots/weights.'),
'p4:cor:native-source-determinant-zero':('Same native *comparison* sector with rho=2/R, not physical electron chart.','Invisible triplet eigenvalue becomes zero while source polynomial at zero remains -rho²; determinant zero not physical source pole.'),
'p4:cor:native-source-square-polynomial':('Declared comparison H_b=D_b² and rho>0; unique full-spatial ground only for rho<sqrt3/(2R) using imported midpoint gap.','Square 2×2 eigenvalues, exact quadratic in E and quartic low-energy expansion; no assertion that physical mass source is this square.'),
}
assert set(notes)==set(statuses)
# Record test IDs by claim, and exact source and proof text already frozen by census.
check_map=defaultdict(list)
for c in checks['controls']:check_map[c['claim']].append(c['id'])
ledger=[]
for j,c in enumerate(claims,1):
    guard,replay=notes[c['id']]
    rec={'id':f'BH-IVC-B5-CL-{j:03d}','source_label':c['id'],'kind':c['kind'],
         'source_location':c['source_locator'],'source_as_printed_title':c['title'],
         'source_as_printed':c['source_as_printed'],'proof_as_printed':c['proof_as_printed'],
         'statement_layer':'SOURCE-AS-PRINTED','status':statuses[c['id']],
         'E1_replay':'SOURCE_REPLAYED' if statuses[c['id']] not in ('FORMALIZED',) else 'SOURCE_DOMAIN_FORMALIZED',
         'E1_proof_notes':replay,'domain_guard':guard,'independent_evidence_ids':[id for id in check_map.get(c['id'],[]) if '-E3-' in id],
         'adversarial_evidence_ids':[id for id in check_map.get(c['id'],[]) if '-E4-' in id],
         'gap_or_issue_ids':[],'not_physical_realization':'physical' in guard.lower() or 'supplied' in guard.lower()}
    if c['id']=='p4:thm:microscopic-bath-gkls':rec['E3_gate']='Reservoir (i) and simultaneous finite bath (iii) all-order Dyson/van Hove norm convergence not independently reproduced; collision (ii) and algebraic structure tested.'
    ledger.append(rec)
count=Counter(statuses.values());assert sum(count.values())==24
prevcounts=prev['cumulative_status_counts'];cum={x:prevcounts.get(x,0)+count.get(x,0) for x in sorted(set(prevcounts)|set(count))};assert sum(cum.values())==140
# Extract exact reference labels in this specific source span, resolve against entire active TeX snapshot, without treating navigation as proof use.
segment='\n'.join(lines[lo-1:hi]);refs=re.findall(r'\\(?:ref|eqref|autoref|pageref)\{([^{}]+)\}',segment)
labels=defaultdict(list)
for f in src.glob('*.tex'):
    for i,line in enumerate(f.read_text().splitlines(),1):
        for m in re.finditer(r'\\label\{([^{}]+)\}',line):labels[m.group(1)].append({'file':f.name,'line':i})
resolved={r:labels[r] for r in sorted(set(refs)) if len(labels[r])==1};unresolved=[r for r in sorted(set(refs)) if not labels[r]];ambiguous=[r for r in sorted(set(refs)) if len(labels[r])>1]
assert len(refs)==35 and len(resolved)==27 and not unresolved and not ambiguous
# Material proof/interpretation edges; all have paper-matched source-use locator. Typed by route, no cross-paper citation auto-promotion.
edgedata=[
 ('p4:thm:v2211-correlated-landauer','p4:cor:v2211-product-landauer','REQUIRES',6990,'Inherited exact finite correlated balance; product prep sets initial I=0'),
 ('p2c:thm:protected-projector-midpoint','p4:cor:clifford-midpoint-adiabatic','IMPORTED_PROOF',7091,'Global rank-two protected frames and common midpoint connection'),
 ('p4:thm:gkls','p4:thm:exact-finite-system-environment-reduction','IMPORTED_PROOF',7171,'Only the conditional already-semigroup branch gives GKLS'),
 ('p4:thm:exact-finite-system-environment-reduction','p4:thm:fixed-finite-bath-semigroup-rigidity','REQUIRES',7204,'Same S,E factorization, state sigma_E and exact CPTP maps for all t'),
 ('p4:thm:gkls','p4:thm:microscopic-bath-gkls','IMPORTED_PROOF',7510,'Collision route finite CPTP Euler-limit gives GKLS generator'),
 ('p4:thm:exact-finite-system-environment-reduction','p4:rem:microbath-status','REQUIRES',7680,'Exact finite-bath CPTP branch'),
 ('p4:thm:fixed-finite-bath-semigroup-rigidity','p4:rem:microbath-status','REQUIRES',7684,'Negative all-time irreversible fixed bath branch'),
 ('p4:thm:microscopic-bath-gkls','p4:rem:microbath-status','REQUIRES',7685,'Separate conditional reservoir, collision and large bath routes'),
 ('p4:def:reeb-sensitive-readout','p4:thm:derived-reeb-phase-signature','REQUIRES',7907,'Supplied periodicity and L2 regularity only'),
 ('p4:v2169:b10:thm:support','p4:thm:v2188-moment-pencil','IMPORTED_PROOF',8009,'Complete stationary exact support quotient; physical tagged pole set'),
 ('p4:lem:v2186-exact-source-cyclic-action','p4:thm:v2188-moment-pencil','IMPORTED_PROOF',8010,'Finite self-adjoint source-cyclic action without reentry'),
 ('p4:thm:v2188-moment-pencil','p4:cor:v2188-common-moments','REQUIRES',8117,'Identical positive-definite Gram and source-cyclic determinant'),
 ('p4:thm:v2191-source-cofactor','p4:cor:v2191-adjacent-cofactor','REQUIRES',8220,'Apply source cofactor polynomial to each complete adjacent leg'),
 ('p4:thm:native-source-constant-cyclic','p4:cor:native-source-determinant-zero','REQUIRES',8463,'Native four-eigenvalue characteristic polynomial and source support'),
 ('p4:thm:native-source-constant-cyclic','p4:cor:native-source-square-polynomial','REQUIRES',8475,'Same native 2x2 reducing matrix and source weights'),
 ('p1b:thm:dirac-spectrum','p4:cor:native-source-square-polynomial','IMPORTED_PROOF',8495,'The full midpoint B_R nonzero gap sqrt3/R used for global uniqueness'),
]
edges=[]
for n,(up,down,relation,l,meaning) in enumerate(edgedata,1):
    ex='\n'.join(lines[max(0,l-6):min(len(lines),l+6)])
    direct=(f'\\ref{{{up}}}' in ex) or (up=='p1b:thm:dirac-spectrum' and 'nonzero gap' in ex) or (up=='p4:thm:v2211-correlated-landauer' and 'preceding domain' in ex) or (up=='p4:thm:v2191-source-cofactor' and ('apply the theorem' in ex or 'The theorem supplies their source-image' in ex)) or (up=='p4:thm:native-source-constant-cyclic' and 'constant-sector characteristic' in ex) or (up=='p4:thm:native-source-constant-cyclic' and 'declared comparison' in ex) or (up=='p4:thm:v2188-moment-pencil' and 'canonical-support moments' in ex)
    assert direct,(up,down,l,ex)
    edges.append({'id':f'BH-IVC-B5-EDGE-{n:03d}','from':up,'to':down,'relation':relation,'proof_route':f'BH-IVC-B5-ROUTE-{down}',
      'logic_group':'AND','source_use_locator':f'{tex.name}:{l}','source_witness':meaning,'domain_guard':notes[down][0],
      'review_status':'SOURCE_MATCHED_MATERIAL','verified_material_edge':True,'candidate_not_automatic':False})
# Group branches of bath theorem, not AND-merged: i/ii/iii are source OR routes; evidence only for ii + local formulas.
route_groups=[
  {'target':'p4:thm:microscopic-bath-gkls','routes':[{'id':'BH-IVC-B5-BATH-I','logic':'OR','conditions':'stationary C*-reservoir, mixing, integrable weighted C and all-order connected cumulant estimates','source':'7259-7283,7300-7328,7332-7374,7413-7669','E3_full':False},
 {'id':'BH-IVC-B5-BATH-II','logic':'OR','conditions':'fresh finite probes, uniform Phi_h=id+hL+o(h), independence','source':'7265,7376-7384,7487-7512','E3_full':'finite Euler product verified'},
 {'id':'BH-IVC-B5-BATH-III','logic':'OR','conditions':'simultaneous finite bath limit and weak coupling with uniform Davies controls','source':'7266-7270,7285-7328,7419-7485','E3_full':False}],
 'AND_interpretation_inadmissible':True},
 {'target':'p4:thm:v2188-moment-pencil','routes':[{'id':'BH-IVC-B5-MOMENTS','logic':'AND','conditions':'stationary exact support, canonical calculation pairing, Krylov closure det K_{d+1}=0','source':'8008-8043','E3_full':'finite explicit sources checked'}]},
]
# Structural statements and all meaningful material unnamed steps, separately from 21 labeled equation environments.
steps=[
 (6893,6941,'Unital/CPTP fixed algebra and relative entropy monotonicity; semigroup and nested expectations'),
 (6948,6986,'Correlated joint entropy conservation and exact Gibbs logarithmic balance'),
 (6988,7015,'Product-preparation mutual information positivity, two-state entropy bound, finite rank impossibility'),
 (7018,7047,'Thermal two-qubit correlated witness, actual bath controlled NOT and heat convention'),
 (7053,7061,'Mandelstam–Tamm speed limit on supplied closed orthogonal pure-state theorem domain'),
 (7063,7105,'Clifford midpoint protected global V± frames, C2 adiabatic gap and nonselected physical history'),
 (7123,7131,'Feedback-conditioned generator is supplied by instrument record, not exact-GP2 constituent'),
 (7139,7154,'Exact supplied factorization and separate semigroup/weak-coupling hypotheses'),
 (7157,7199,'Kraus extraction from finite U(t), trace-preserving identity and conditional GKLS import'),
 (7201,7254,'Exponential-polynomial continuation of all-time semigroup; CP inverse and multiplicative domain'),
 (7257,7300,'Three disjoint bath/process routes, stationary correlations and centering conditions'),
 (7301,7328,'Weighted two-point and all-order connected correlation hypotheses; finite-bath uniform assumptions'),
 (7332,7374,'Interaction-picture van Hove convergence statement and physical time generator units'),
 (7376,7410,'Fresh-probe product maps, pointer and KMS conditional interfaces; fixed bath no dissipative exact limit'),
 (7421,7451,'Dyson expansion and reservoir GNS conditional expectation vs finite partial trace'),
 (7453,7485,'Davies imported connected-cumulant remainder, level-shift and second-order kernel; E3 limit outstanding'),
 (7487,7512,'Collision map norm telescoping bound and finite-dimensional Euler limit'),
 (7515,7574,'Bohr secular frequencies and generator picture/time scale; no Schr van Hove limit claimed'),
 (7577,7596,'Positive-type matrix-valued correlations, Bochner PSD coefficients, finite bath pure point'),
 (7599,7647,'Full complex pointer coefficient and PSD real damping, dark null space and phase caveat'),
 (7650,7694,'KMS detailed balance and reversible exact finite-bath source limit guard'),
 (7701,7736,'Lie–Trotter/commutator generation in reachable closure with inverses admitted'),
 (7737,7746,'Nonclosed irrational analytic subgroup and no unsupplied accessibility'),
 (7753,7849,'KL matrix positivity, diagonal errors, orthogonal syndrome recovery and trace fill'),
 (7858,7878,'Imported REG_sigma family and rank-one/rank-seven valuation, no unearned L_H/7'),
 (7885,7969,'A.e. residual covariance definition, real Fourier class, exact gcd minimal period'),
 (7971,7995,'First harmonic real Fourier projection and physical transfer coefficient firewall'),
 (8006,8064,'Support pairing is mathematical only; moment Gram, closure m_2d, spectral weights and target test'),
 (8068,8108,'Feshbach exact Schur, positive derivative/residue, definite-vs-indefinite complement'),
 (8111,8150,'Canonical vs actual moments/weights, isometric source-cyclic maps and exact-support guard'),
 (8166,8206,'Adjugate trace positive residues, multiplicity gcd and appended rank test'),
 (8208,8231,'Charge-adjacent cofactor LCM, global-ground removal and support assumptions'),
 (8248,8285,'Autonomous charge and analytic Krylov recurrence finite terminating decision test'),
 (8300,8351,'Degenerate cofactor multiplicity, invisible determinant zero, positivity on exact support'),
 (8358,8395,'Moving metric transport and finite CAR/CCR diagnostics; no projected-word reinterpretation'),
 (8403,8459,'Native constant-source model exact 4-block decomposition and singlet cyclic subspace'),
 (8461,8499,'Invisible triplet determinant zero, squared energy polynomial and perturbation gap bound'),
 (8515,8546,'Explicit rational Hankel source comparison R=1,rho=2 and no physical electron identification'),
 (8551,8563,'Auxiliary occupation comparison scope declaration; next named lemma starts at 8564'),
]
step_ledger=[{'id':f'BH-IVC-B5-ST-{i:03d}','line_range':[a,b],'description':s,'statement_layer':'SOURCE-AS-PRINTED','E1_status':'SOURCE_REPLAYED_WITH_SCOPE' if not (7453<=a<=7485) else 'IMPORTED_DAVIES_LIMIT_NOT_INDEPENDENTLY_E3_CERTIFIED'} for i,(a,b,s) in enumerate(steps,1)]
displays=[x for x in census['display_equations'] if lo<=x['line_start']<=hi]
assert len(displays)==21
# No new confirmed mathematical issues; four earlier issues unchanged; preserve nonpromoted interface obligations.
previous_issues={
'BH-G-000102':{'status':'UNRESOLVED','origin':'Paper4C 3069-3072,3145-3154','source_batch':2,'impact':'truncated bosonic polynomial microcausality only'},
'BH-G-000103':{'status':'UNRESOLVED','origin':'Paper4C 3443-3489','source_batch':3,'impact':'scalar Bogoliubov differentiability and affine corollary'},
'BH-G-000104':{'status':'AUXILIARY_STEP_REFUTED','origin':'Paper4C 4191','source_batch':3,'impact':'nonautonomous recurrence sentence only'},
'BH-G-000105':{'status':'SOURCE_PROSE_NECESSITY_REFUTED','origin':'Paper4C 6613','source_batch':4,'impact':'interference disappearance interpretation, not Born formula'},
}
condreview=[
 {'name':'unital CPTP coarse graining on fixed algebra','first_known_occurrence':f'{tex.name}:6901','status':'EXPLICIT_SCOPE','consumers':['p4:prop:unital-coarse-entropy'],'canonical_integration':'LINK_TO_PREEXISTING_CPTP_OWNERS; NOT NEW_CONSTITUTIONAL_AXIOM'},
 {'name':'thermal initial bath marginal beta>0, actual joint resource partition','first_known_occurrence':f'{tex.name}:6949-6957','status':'EXPLICIT_THERMAL_DOMAIN','consumers':['p4:thm:v2211-correlated-landauer','p4:cor:v2211-product-landauer'],'canonical_integration':'STATE_PREPARATION_DOMAIN NOT_GENERAL_CPTP_FACT'},
 {'name':'initial product state for erasure bound','first_known_occurrence':f'{tex.name}:6990-6991','status':'STRONGER_THAN_THERMAL_MARGINAL','consumers':['p4:cor:v2211-product-landauer'],'canonical_integration':'DO_NOT_MERGE_WITH_WEAKER_THERMAL_MARGINAL'},
 {'name':'gapped Clifford history and Hamiltonian realization','first_known_occurrence':f'{tex.name}:7063-7074; mathematical frame inherited Paper2C:2824','status':'EXPLICIT_INTERFACE','consumers':['p4:cor:clifford-midpoint-adiabatic'],'canonical_integration':'HISTORY AND PHYSICAL_GENERATOR NOT_SELECTED_BY_MIDPOINT_GEOMETRY'},
 {'name':'finite product system-environment split','first_known_occurrence':f'{tex.name}:7159-7167; precursor Paper4A','status':'EXPLICIT_MODEL_PARTITION','consumers':['p4:thm:exact-finite-system-environment-reduction','p4:thm:fixed-finite-bath-semigroup-rigidity'],'canonical_integration':'USE_EXISTING_INTERFACE; GP2 DOES_NOT_GENERATE_BATH'},
 {'name':'fixed-bath exact all-time semigroup','first_known_occurrence':f'{tex.name}:7203-7210','status':'EXPLICIT_STRONGER_HYPOTHESIS','consumers':['p4:thm:fixed-finite-bath-semigroup-rigidity'],'canonical_integration':'NOT_FROM_CPTP_ALONE'},
 {'name':'mixing reservoir/all-order Dyson cumulant norm control','first_known_occurrence':f'{tex.name}:7259-7328','status':'EXPLICIT_CONDITIONAL_RESERVOIR_INTERFACE','consumers':['p4:thm:microscopic-bath-gkls'],'canonical_integration':'OR_ROUTE_I; FULL_E3_OUTSTANDING'},
 {'name':'fresh probe uniform scaled channel expansion','first_known_occurrence':f'{tex.name}:7376-7381','status':'EXPLICIT_CONDITIONAL_COLLISION_INTERFACE','consumers':['p4:thm:microscopic-bath-gkls'],'canonical_integration':'OR_ROUTE_II NOT_MERGED_WITH_DAVIES'},
 {'name':'simultaneous large bath/weak coupling and recurrence separation','first_known_occurrence':f'{tex.name}:7266-7269,7285-7328','status':'EXPLICIT_CONDITIONAL_LARGE_BATH_INTERFACE','consumers':['p4:thm:microscopic-bath-gkls'],'canonical_integration':'OR_ROUTE_III NOT_FIXED_FINITE_BATH'},
 {'name':'reversible Lie control span/accessibility','first_known_occurrence':f'{tex.name}:7711-7715','status':'EXPLICIT_CONTROL_DOMAIN','consumers':['p4:thm:lie-closure-controllability'],'canonical_integration':'NOT_IMPLIED_BY_RANK_CONDITION'},
 {'name':'finite KL exact error-correlation scalar code condition','first_known_occurrence':f'{tex.name}:7753-7759','status':'EXPLICIT_CODE_CONDITION','consumers':['p4:thm:finite-kl-recovery'],'canonical_integration':'ERROR_MODEL_NOT_PHYSICALLY_SELECTED'},
 {'name':'Reeb period T=sL_H and REG_sigma physical readout','first_known_occurrence':f'{tex.name}:7858-7902','status':'DEFINITION_OR_APPLIED_INTERFACE','consumers':['p4:thm:derived-reeb-phase-signature'],'canonical_integration':'NOT_PREDICTION; NO_L_H_DIVIDED_BY_7'},
 {'name':'exact stationary source support and comparison pairing','first_known_occurrence':'Paper4B-QuantumResponse-v1_42.tex:7405-7440,7701-7720','status':'INHERITED_FROM_IV_B','consumers':['p4:thm:v2188-moment-pencil','p4:cor:v2188-common-moments','p4:cor:v2191-adjacent-cofactor'],'canonical_integration':'REUSE_EXISTING_SOURCE_SUPPORT_NO_DUPLICATE_NODE'},
 {'name':'regular complementary resolvent z outside spec C','first_known_occurrence':f'{tex.name}:8070-8076','status':'EXPLICIT_SCHUR_DOMAIN','consumers':['p4:prop:v239-visible-schur-residue'],'canonical_integration':'SCOPE_GUARD'},
 {'name':'autonomous constant full H and actual charge Q','first_known_occurrence':f'{tex.name}:8248-8256','status':'EXPLICIT_AUTONOMOUS_ONLY','consumers':['p4:v2171:thm:finite'],'canonical_integration':'NOT_NONAUTONOMOUS_PHYSICAL_COSMOLOGY'},
 {'name':'native constant insertion b and singlet source, compared square H_b=D_b²','first_known_occurrence':f'{tex.name}:8403-8418','status':'EXPLICIT_COMPARISON_NOT_PHYSICAL_SELECTION','consumers':['p4:thm:native-source-constant-cyclic','p4:cor:native-source-determinant-zero','p4:cor:native-source-square-polynomial'],'canonical_integration':'NO_PHYSICAL_ELECTRON_MASS_OR_CURRENT_CLAIM'},
]
nonpromoting=[
 {'from':'p4:cor:v226-native-controls','to':'Paper4C-remark-line-7737','kind':'CITATION_ONLY','source_locator':f'{tex.name}:7741-7743','reason':'Closed native groups used as example/context; not a proof premise of full arbitrary Lie control theorem.'},
 {'from':'p4:v2171:thm:flow','to':'p4:v2171:thm:finite','kind':'ALTERNATIVE_ROUTE_NOT_DEPENDENCY','source_locator':f'{tex.name}:8289-8291','reason':'Nonautonomous separate theorem explicitly outside autonomous test; not an AND prerequisite.'},
 {'from':'p3f:thm:native-source-helicity-coefficient','to':'p4:cor:native-source-square-polynomial','kind':'CORROBORATION_NOT_MATERIAL','source_locator':f'{tex.name}:8488-8490','reason':'Paper III-G signed Dirac low coefficient is consistent with direct exact 2x2 root expansion, not required.'},
 {'from':'p6:cor:v2191-mass-cofactor','to':'p4:thm:v2191-source-cofactor','kind':'DOWNSTREAM_MENTION_NOT_REVERSE_PROOF','source_locator':f'{tex.name}:8330-8337','reason':'Paper V-B mass-source consumer is cited for a diagnostic, not a proof source for IV-C cofactor theorem.'},
 {'from':'p4:thm:microscopic-bath-gkls','to':'p4:thm:fixed-finite-bath-semigroup-rigidity','kind':'NOT_MATERIAL','source_locator':f'{tex.name}:7400-7409','reason':'The latter rigidity proof does not require the former conditional Davies theorem; scope exclusion is only forward interpretation.'},
]
review={
 'E_U_C_R_I':'Theorem-existence/uniqueness vs physical realization and interpretation are separate: finite matrix algebra does not select a reservoir, control Hamiltonian, code, source q, comparison b or lab Reeb transfer.',
 'source_constitution_boundary':'Paper2C:2824 protected geometry imported as already proven; Paper1B:16028 midpoint spectral gap imported for specific native comparison only. Neither creates a physical mass/interaction selector.',
 'formal_condition_one_introduction':'Local first occurrences are recorded, but no new global BH-A IDs are minted until complete DAG integration and ancestry reconciliation.',
 'bath_route_certification':'Collision route is independently checked; reservoir and large-bath Davies limits require their stated strong assumptions and were not exhaustively independently verified by finite scripts.',
 'potential_gap_challenges_rejected':['No Lindblad irreversibility from one fixed bath is claimed; finite-bath semigroup rigidity explicitly excludes it.','No automatic logarithmic period from the imported rank hierarchy is claimed; Reeb covariance is supplied.','No exact electron mass polynomial is claimed from the native constant source; source says comparison only.','Same support does not imply identical actual residues; source explicitly separates canonical and physical pairings.'],
 'no_new_confirmed_gap':True,
}
gates=[
 {'target':'p4:thm:microscopic-bath-gkls','evidence_status':'FORMALIZED','gate':'Independent E3 certificate for the all-order interaction-picture Davies limit on both infinite reservoir and simultaneous finite-bath asymptotic branches. Printed cumulant/hypothesis and cited Davies theorem retained; not reclassified as mathematical error.'},
 {'target':'p4:cor:clifford-midpoint-adiabatic','evidence_status':'VERIFIED-CONDITIONAL','gate':'Physical adiabatic realization requires actual C2 Hamiltonian and coefficient-sphere history; not selected by projectors.'},
 {'target':'p4:thm:derived-reeb-phase-signature','evidence_status':'VERIFIED-CONDITIONAL','gate':'Physical log-periodic transfer requires independently supplied and verified Reeb covariance, rank channel s and apparatus coefficient; source does not provide these.'},
 {'target':'p4:thm:native-source-constant-cyclic','evidence_status':'VERIFIED-CONDITIONAL','gate':'The computed b,s0 are explicit comparison inputs, not the physical tagged electron source or action.'},
]
assert all(x['source_label'] in statuses for x in ledger)
batch={
 'audit':'Paper4C','batch':5,'revision':'v1_1','protocol':'Paper00-RigorousVerificationDAGWorkProtocol-v2_4',
 'source_authority':'Paper00-PapersMinimal-v2_371','source_file':tex.name,'source_sha256':sourcehash,
 'latest_supplied_dag_input':'Paper00-DAGAtlas-v1_108(1).zip','latest_supplied_audit_input':'Paper00-ProofChainAudits-v1_25(1).zip',
 'source_coverage':{'start':lo,'end':hi,'total_lines':len(lines),'named_checked':24,'named_total':186,'cumulative_named_checked':140,'cumulative_named_remaining':46,
  'formal_results_in_batch':sum(x['kind'] not in ('remark','definition') for x in claims),'display_environments_reviewed':len(displays),
  'display_environments_total':census['display_count'],'material_unnamed_steps':len(steps),'material_steps_ledger':step_ledger,
  'out_of_scope':'Paper4C 8564-10934; independent full audits of referenced other papers, manuscript edits and final ZIP integration'},
 'status_counts':dict(count),'previous_cumulative_named':116,'cumulative_status_counts':cum,'named_claim_ledger':ledger,
 'source_reference_audit':{'reference_occurrences':len(refs),'unique_reference_labels':len(resolved),'resolved_exactly_once':len(resolved),
   'unresolved':unresolved,'ambiguous':ambiguous,'navigation_only_not_proof_edges':True,'reference_label_index':resolved},
 'source_proof_use_edges':edges,'nonpromoting_edges':nonpromoting,'proof_route_review':route_groups,
 'independent_checks_file':'Paper4C-Batch5IndependentChecks-v1_1.json','independent_check_count':39,'independent_check_passed':39,'independent_E3_count':30,'adversarial_E4_count':9,
 'found_issues':[],'carried_forward_issues_unchanged':[{'id':k,**v} for k,v in previous_issues.items()],
 'canonical_condition_review':condreview,'boundary_review':review,'open_verification_gates':gates,
 'adversarial_challenges':[x for x in checks['controls'] if x['type']=='E4'],
 'agent_mode':'single-run source E1; independent finite/symbolic E3 and exact/negative-domain E4; no external multiagent provenance claimed',
 'batch_closure':'BATCH_5_COMPLETE_24_NAMED_39_SCOPED_CONTROLS_ZERO_NEW_CONFIRMED_DEFECTS',
 'overall_full_audit_ready':False,'no_source_modification':True,'successor_archive_policy':'defer DAG ZIP and separate audit ZIP until after source 8564-10934; latest versions only',
}
pjson=stage/'Batches/Paper4C-AuditBatch5-v1_1.json';pjson.write_text(json.dumps(batch,indent=2,ensure_ascii=False)+'\n')
rows='\n'.join(f'| {c["source_location"]["line_start"]} | `{c["source_label"]}` | {c["status"]} | {", ".join(x.rsplit("-",1)[-1] for x in c["independent_evidence_ids"]+c["adversarial_evidence_ids"]) or "—"} |' for c in ledger)
md=f'''# Paper IV-C — Rigorous Verification DAG audit, Batch 5 (v1_1)

**Controlling source:** `{tex.name}` from `Paper00-PapersMinimal-v2_371`, SHA-256 `{sourcehash}`. **Audit protocol:** `Paper00-RigorousVerificationDAGWorkProtocol-v2_4`.

**Coverage:** source lines **{lo}–{hi}** ({hi-lo+1:,} lines); **24/24 named claims/definitions/remarks** whose starts are in this span, **{len(steps)} material unnamed proof/qualification blocks**, and **{len(displays)} labeled equation environments** replayed at E1. All remaining unnumbered displayed formulas within these step blocks are source-inspected, but not each independently checked by E3. **Cumulative:** **140/186** named objects audited; **46 remain** (source lines **8564–10934**).

**Status breakdown:** VERIFIED **{count['VERIFIED']}**; VERIFIED-CONDITIONAL **{count['VERIFIED-CONDITIONAL']}**; FORMALIZED **{count['FORMALIZED']}**; new UNRESOLVED **0**. **Independent tests:** **39/39 PASS** (30 E3; 9 adversarial E4). Passing E4 may certify an exclusion or show a counterexample to an overstrong OUT-OF-SCOPE interpretation, not prove all cases of a theorem.

## Source-bound named claim census

| Start line | Label | Disposition | E3/E4 control numbers |
|---:|---|---|---|
{rows}

## Main proof results and qualifications

### Finite entropy, Landauer, adiabatic transport and exact baths (6901–7254)

The unital channel entropy inequalities follow from data-processing against `I/d` and the explicitly nested expectations/semigroup; the source carefully does **not** claim a time arrow for arbitrary reductions. The exact correlated Landauer identity is

\\[\\beta Q=\\Delta S_M+\\Delta I+D(\\rho'_B\\|\\tau_B).\\]

A thermal bath **marginal** does not imply an uncorrelated resource: the explicit correlated CNOT witness has `Delta S_M = ln 2`, `Delta I = -ln 2`, and `Q=0`, whereas the product-prepared branch obeys `beta Q >= Delta S_M`. The faithful finite-bath rank obstruction is correct. An actual gapped protected Clifford Hamiltonian and `C²` history are required to realize the Paper-II-C midpoint connection adiabatically. Exact finite system–bath reduction yields CPTP maps; an exact all-time Markov semigroup from a **fixed finite bath** is unitary-conjugation only, by exponential-polynomial continuation and the CP-inverse multiplicative-domain argument.

### Microscopic bath bridge and control/code interfaces (7257–7998)

The microscopic GKLS bridge contains **three OR alternatives**, not one conjunctive physical mechanism: (i) mixing stationary reservoir with strong cluster estimates, (ii) independent fresh probe collisions with `Phi_h=id+hL+o(h)`, or (iii) a simultaneous uniform large-bath/weak-coupling limit. The collision Euler product, Fourier positive coefficients, pointer **complex** `kappa_ab` and its nonnegative real damping quadratic form, and finite KMS detailed balance all pass separate checks. The **all-order Davies limit** for routes (i)/(iii) has *not* received a complete independent E3 certificate in this batch and remains **FORMALIZED** with a stated verification gate; it is **not refuted** and its physically supplied interface remains conditional.

The Lie-closure theorem explicitly requires reversible accessibility in reachable closure; bare Lie rank does not alone grant a bounded-time operation. The finite Knill–Laflamme recovery construction works for the exact scalar error-correlation condition; a three-qubit repetition-code instantiation verifies full recovery, and a logical-phase-error negative control confirms why the hypothesis matters. The Reeb signature derives a Fourier period only **after** a supplied covariance law: `T=s L_H` is a period, its least period can be `T/d` where `d` is the Fourier support gcd, a constant signal has no least positive period, and neither an apparatus transfer coefficient nor the rank-seven subperiod `L_H/7` is forced by GP2.

### Complete source cyclic/pole calculation and native comparison (7999–8563)

The source-cyclic Hankel method uses the **full** stationary source action and the **exact** support. The calculation pairing `P/rank(P)` is canonical for comparison but is *not* an assertion about the actual physical state; the closure test uses `m_2d` in `det K_(d+1)=0`. The source cofactor `chi/gcd(chi,eta)` correctly removes invisible eigenvalues and all extra multiplicities; appending source columns increases rank exactly at visible eigenvalues. The Feshbach residue denominator `v†S'(lambda)v` is strictly positive when `lambda` is regular outside the complement spectrum. An unshifted coupled scalar source root is possible with an **indefinite** complement, but not a definite one. Matching canonical moments alone does not force equal residues for differing actual densities.

The autonomous charge certificate requires checking its entire finite cyclic moment prefix: the first derivative can vanish even when a later moment and the charge change do not. The native constant-insertion four-state comparison reproduces the exact two-root singlet cyclic polynomial and demonstrates a full determinant zero **invisible** to that source at `rho=2/R`. Squaring the comparison operator gives the printed quadratic energy polynomial and quartic small-insertion branch, conditional on the inherited midpoint spectral gap. This does **not** evaluate or select the physical electron tagged polynomial or physical action.

## New issues and continuing issues

**No new confirmed source-matched mathematical defects** in this batch. The 39 controls pass on their declared finite/test domains, but they do not prove all-order reservoir convergence or physical occurrence of apparatus/source inputs. The stronger unverified Davies E3 gate is a **verification obligation**, not a source math refutation.

Four earlier independent roots carry forward **unchanged**:

- `BH-G-000102` — higher-degree truncated boson microcausality occupation margin (Batch 2, open).
- `BH-G-000103` — scalar Bogoliubov differentiability (Batch 3, open).
- `BH-G-000104` — nonautonomous finite recurrence overstatement (Batch 3, auxiliary issue).
- `BH-G-000105` — no general implication from absent detector interference to dephasing (Batch 4, localized interpretation).

No verified downstream path connects those four roots to a new theorem in the Batch 5 span. In particular, finite entropy/Landauer and source-cyclic spectral algebra do not consume the challenged bosonic locality or detector-only-if step.

## Integrity and imported proof uses

- Current target SHA-256 agrees with the first four batches and the original census; source is unchanged.
- All **{len(refs)}** `\\ref`/`\\eqref` occurrences across **{len(resolved)}** labels resolve once in the current minimal papers archive (navigation E0, **not** proof verification).
- **{len(edges)}** independently reviewed proof-use edges and **{len(nonpromoting)}** explicitly nonpromoted links preserve material routes and alternatives. Bath routes (i), (ii) and (iii) are **OR**, not AND. Statements about later Paper V-B are *not* reverse proof imports into IV-C.
- Specific remote dependencies were bounded to `p2c:thm:protected-projector-midpoint` (Paper II-C:2824), `p4:thm:gkls` (Paper IV-A:3047), `p4:v2169:b10:thm:support` (Paper IV-B:7421), `p4:lem:v2186-exact-source-cyclic-action` (Paper IV-B:7716), and `p1b:thm:dirac-spectrum` (Paper I-B:16028). No remote paper is claimed newly audited in full.
- Canonical conditions were reviewed for first appearances and stronger/weaker distinctions without inventing new constitutional axioms or duplicating existing global `BH-A` nodes; full global-ID reconciliation is reserved for final DAG integration.

**Cumulative verdict:** `PARTIALLY_AUDITED` — **140/186**, **46 remaining**. Next unexamined source line **8564** starts `p4:lem:v2174-aux-pair-boundary`; the remaining 2,371 lines cover fixed graded-port comparisons, interacting finite-source determinants, influence-jet convergence, source spectral certificates and cutoff cumulants. The final DAG ZIP and requested separate proof-chain audit ZIP are **not** yet generated; when complete they will retain **only newest appropriate versions**. Source manuscripts and supplied input ZIPs remain untouched.

**Evidence:** `Paper4C-Batch5IndependentChecks-v1_1.py/.json`; **machine ledger:** `Paper4C-AuditBatch5-v1_1.json`.
'''
pmd=stage/'Batches/Paper4C-AuditBatch5-v1_1.md';pmd.write_text(md)
validation={
  'batch':5,'source_file':tex.name,'source_sha256':sourcehash,'source_unchanged':True,
  'prev_batch_source_coverage_end':prev['source_coverage']['end'],'current_source_coverage_start':lo,'current_source_coverage_end':hi,
  'source_coverage_contiguous':prev['source_coverage']['end']+1==lo,
  'named_in_span':len(claims),'named_records_unique':len({c['source_label'] for c in ledger})==len(ledger),
  'source_named_total':186,'cumulative_named':140,'previous_named':116,'status_sum':sum(count.values()),
  'cumulative_status_sum':sum(cum.values()),'material_step_blocks':len(steps),'labeled_equation_envs':len(displays),
  'controls':checks['total_controls'],'controls_passed':checks['passed'],'E3':checks['independent_E3_count'],'E4':checks['adversarial_E4_count'],
  'references_total':len(refs),'references_unique':len(resolved),'reference_unresolved':unresolved,'reference_ambiguous':ambiguous,
  'reviewed_material_edges':len(edges),'provenance_scope':'source + current corpus; no automatic citation promotion',
  'new_confirmed_issues':[],'carried_forward_issues':list(previous_issues),
  'paper_zip_untouched':True,'input_dag_zip_untouched':True,'input_audit_zip_untouched':True,'final_archives_deferred':True,
  'files_created':[str(pjson),str(pmd)]}
pval=stage/'Evidence/Paper4C-Batch5Validation-v1_1.json';pval.write_text(json.dumps(validation,indent=2)+'\n')
for p in [pjson,pmd,pval]:print('WRITTEN',str(p),'bytes',p.stat().st_size,'sha256',hashlib.sha256(p.read_bytes()).hexdigest())
print('TOTAL',len(claims),'statuses',dict(count),'cumulative',cum,'references',len(refs),'edges',len(edges),'steps',len(steps),'displays',len(displays))
