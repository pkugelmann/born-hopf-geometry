#!/usr/bin/env python3
"""Validate Batch23 v1_34 exact mathematics, effective status and immutable inherited graph."""
from __future__ import annotations
import json,pathlib,subprocess,sys,xml.etree.ElementTree as ET
R=pathlib.Path(__file__).resolve().parent
read=lambda f:json.loads((R/f).read_text())
old=read('data/v133_verified_frontier_status.json');new=read('data/v134_verified_frontier_status.json')
cc=read('data/v134_scoped_math_replays.json');bc=read('data/v134_unresolved_boundary_tests.json')
E=read('data/mathematical_relations.json');O=read('data/objects.json');H=read('data/joint_input_relations.json');D=read('data/derived_compositions.json')
assert (len(O),len(E),len(H),len(D))==(862,1392,242,183)
assert new['parent']=='v1_33' and new['release']=='v1_34'
assert old['replay_count']==17 and old['pending_count']==7
assert new['replay_count']==21 and new['pending_count']==3
assert len(new['relations'])==24 and new['original_frontier_count']==24
assert cc['new_conditional_replayed_count']==4
assert set(new['newly_verified_ids'])==set(cc['new_conditional_replayed_ids'])=={'G32-059','G32-061','G32-066','G32-070'}
assert set(new['carried_forward_verified_ids'])==set(old['verified_ids'])
assert set(new['pending_ids'])==set(bc['remaining_ids'])=={'G32-052','G32-056','G32-072'}
assert set(new['verified_ids'])|set(new['pending_ids'])==set(new['relations'])
assert not (set(new['verified_ids'])&set(new['pending_ids']))
assert new['whole_source_theorems_or_physical_premises_promoted']==0
assert new['physical_action_occurrence_promoted']==0
assert cc['whole_source_theorems_promoted']==cc['physical_action_occurrence_promoted']==0
assert new['graph_topology_changed'] is False
G={e['id']:e for e in E}
Hmap={h['id']:h for h in H}
assert {k for k,e in G.items() if e['verification']=='SOURCE_RESTRICTED_MATHEMATICAL_MAP_EXACT_PROOF_NOT_REPLAYED'}==set(new['relations'])
for id,v in new['relations'].items():
 assert id in G and (v['from'],v['to'])==(G[id]['from'],G[id]['to'])
 assert v['joint_relation_id'] in Hmap and v['guarded_conditions']==Hmap[v['joint_relation_id']]['conditions']
 assert v['original_v132_verification']==G[id]['verification']
 assert v['physical_owner_or_source_theorem_independently_dischargeable'] is False
 assert v['remaining_conditions']
 if id in new['newly_verified_ids']:
  assert v['certificate_ref']=='data/v134_scoped_math_replays.json#checks/'+id[4:]
  assert v['effective_mathematical_map_status']=='INDEPENDENT_CONDITIONAL_MATHEMATICAL_MAP_REPLAY'
  assert cc['checks'][id[4:]]['undischarged_source_or_physical_conditions']
 elif id in old['verified_ids']:
  assert v==old['relations'][id]
 else:
  assert id in new['pending_ids'] and v['certificate_ref'] is None and v['pending_reason']
ns={'g':'http://graphml.graphdrawing.org/xmlns'}
def parse(fname):
 root=ET.parse(R/fname).getroot()
 kk={e.attrib['id']:e.attrib['attr.name'] for e in root.findall('g:key',ns)}
 nodes={e.attrib['id'] for e in root.findall('.//g:node',ns)}
 edges={e.attrib['id']:(e.attrib['source'],e.attrib['target'],{kk[d.attrib['key']]:d.text for d in e.findall('g:data',ns)}) for e in root.findall('.//g:edge',ns)}
 return nodes,edges
on,ee=parse('graph/mathematical_structure_network_effective_v134.graphml')
assert on=={x['id'] for x in O} and set(ee)==set(G)
for id,(frm,to,m) in ee.items():
 assert (frm,to)==(G[id]['from'],G[id]['to'])
 assert m['source_verification_v132']==G[id]['verification']
 assert m['effective_verification']==new['relations'].get(id,{}).get('effective_mathematical_map_status',G[id]['verification'])
 assert (m['certificate_ref'] or None)==(new['relations'].get(id,{}).get('certificate_ref') or None)
on2,ee2=parse('graph/batch23_verified_scoped_math_maps.graphml')
assert set(ee2)==set(new['newly_verified_ids'])
assert on2=={k for id,(a,b,d) in ee2.items() for k in (a,b)}
commands=[
 [sys.executable,'verify_scoped_math_v134.py','--check'],
 [sys.executable,'verify_boundary_v134.py','--check'],
 [sys.executable,'build_overlay_v134.py','--check'],
 [sys.executable,'rebuild_effective_graph_v134.py','--check'],
 [sys.executable,'verify_parent_v133_integrity_v134.py'],
 [sys.executable,'verify_batch22_v133.py'],
]
for cmd in commands:
 p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,check=True)
 print(p.stdout.rstrip().splitlines()[-1])
print('PASS Batch23: 21/24 conditional mathematical replays, 3 pending source-selective maps; unchanged 862/1392/242/183 topology; 0 physical promotions')
