#!/usr/bin/env python3
"""Independent exact-arithmetic checks of reciprocal S3xS3 torus quotient geometry.

Contains NO physical decay, evidence DAG, calibration, or particle model.
General statements require primitive integral cocharacters and fixed oriented
Hopf fibres; code checks symbolic identities plus all representatives of finite
kernel for bounded example matrices. Detailed group/Gysin proof in report.
"""
from __future__ import annotations
import json, pathlib, math, itertools
import sympy as s
from sympy.matrices.normalforms import smith_normal_form
from sympy.polys.domains import ZZ
from fractions import Fraction

ROOT=pathlib.Path(__file__).resolve().parent

def primitive(w):return math.gcd(*w)==1

def chirow(w):
    a,b=w
    return (b,-a)

def chi_matrix(w,v):return s.Matrix([chirow(w),chirow(v)])

def c1(w,ex=1,ep=1):
    a,b=w
    return s.Matrix([b*ex,-a*ep])

def kernel_points(M):
    assert M.det()!=0
    d=abs(int(M.det()))
    Mi=M.inv()
    pts=set()
    for k,l in itertools.product(range(d),repeat=2):
        x=Mi*s.Matrix([k,l]); y=tuple(Fraction(int(z.p),int(z.q))%1 for z in x)
        pts.add(y)
    return pts

def check_pair(w,v):
    assert primitive(w) and primitive(v)
    M=chi_matrix(w,v)
    det=int(s.det(M))
    delta=int(s.det(s.Matrix([w,v])))
    assert det==delta
    if delta==0:return {'w':list(w),'v':list(v),'det':0,'cover':False}
    snf=smith_normal_form(M,domain=ZZ)
    invariants=sorted(abs(int(snf[i,i])) for i in range(2))
    assert invariants==[1,abs(delta)], (w,v,snf)
    assert len(kernel_points(M))==abs(delta)
    return {'w':list(w),'v':list(v),'det':det,'cover_degree':abs(det),'deck_group':'C_'+str(abs(det))}

# Primitive residual circle character and integral Chern class.
a,b,ex,ep=s.symbols('a b epsilon_x epsilon_p',integer=True)
w=s.Matrix([a,b]); row=s.Matrix([[b,-a]])
assert row*w==s.zeros(1,1)
assert s.expand((b*ex)*(-a*ep)*2)==-2*a*b*ex*ep
assert s.det(s.Matrix([[ex,0],[0,ep]]))==ex*ep
for a0,b0 in [(1,1),(1,-1),(1,0),(0,1),(2,3),(-3,7),(5,-2)]:
    assert primitive((a0,b0))
    c=s.Matrix(c1((a0,b0)))
    assert c==s.Matrix(chirow((a0,b0)))
    # Bezout primitive H^2 ring generator with x=(u h_x+v h_p),
    # y=(b h_x+a h_p)*f and x cup y=(a u+b v)[base] f=1.
    u,v,g=s.gcdex(a0,b0)
    assert int(g)==1 and int(u*a0+v*b0)==1
    assert int((s.Matrix([[u,v]])*s.Matrix([a0,b0]))[0])==1
    assert int((s.Matrix([[b0,-a0]])*s.Matrix([a0,b0]))[0])==0
    assert (-a0)*b0+b0*a0==0
    assert math.gcd(*c)==1

# Compare exchange-stable Hopf slopes (both pure-Hopf and primitive).
wplus=(1,1);wminus=(1,-1)
AH=chi_matrix(wplus,wminus)
AS=s.Matrix([[1,1],[1,-1]])
J=s.Matrix([[0,1],[-1,0]])
assert AH==J*AS
assert AH.det()==AS.det()==-2
assert AH.inv()*AH==s.eye(2)
assert AH*AH==AS*AS==2*s.eye(2)
assert AH*s.Matrix([s.Rational(1,2),s.Rational(1,2)])==s.Matrix([0,-1])
assert AS*s.Matrix([s.Rational(1,2),s.Rational(1,2)])==s.Matrix([1,0])
assert kernel_points(AH)==kernel_points(AS)=={(Fraction(0),Fraction(0)),(Fraction(1,2),Fraction(1,2))}
assert c1(wplus)==s.Matrix([1,-1]);assert c1(wminus)==s.Matrix([-1,-1])
CH=s.Matrix.hstack(c1(wplus),c1(wminus)).T
assert CH==AH and abs(int(CH.det()))==2
assert 2*CH.row(0)[0]*CH.row(0)[1]==-2
assert 2*CH.row(1)[0]*CH.row(1)[1]==2
# The simultaneous quotient of P by both residual characters is P/Delta(C2),
# i.e. Spin(4)/{(1,1),(-1,-1)} = SO(4), not P=Spin(4).
assert len(kernel_points(AH))==2

# Both exchange parity diagonalizations together on T_H^2 x T_sc^2.
B=s.diag(AH,AS)
assert B.det()==4
assert smith_normal_form(B,domain=ZZ)==s.diag(1,1,2,2) or sorted(abs(int(smith_normal_form(B,domain=ZZ)[i,i])) for i in range(4))==[1,1,2,2]
combined_kernel=[(p[0],p[1],q[0],q[1]) for p in sorted(kernel_points(AH)) for q in sorted(kernel_points(AS))]
assert len(combined_kernel)==4
for x in combined_kernel:
    v=s.Matrix(x); assert all(z.q==1 for z in (B*v))

# Quotient by primitive (a,b,m,n) circle in M8 and scalar Smith invariant.
def mixed_class(w):
    a,b,m,n=w
    assert math.gcd(a,b,m,n)==1
    d=math.gcd(m,n)
    return {'w':list(w),'d':d,'pi2':'Z' if d==0 else '0',
            'pi1':'Z^2' if d==0 else ('Z' if d==1 else f'Z ⊕ Z/{d}'),
            'normal_form':('T^(a,b) x T^2' if d==0 else ('S^3 x S^3 x S^1' if d==1 else f'((S^3xS^3)/mu_{d}^(a,b)) x S^1'))}
examples=[(1,1,0,0),(1,1,1,0),(1,1,2,4),(2,3,0,0),(1,-1,3,6),(0,1,5,10),(1,0,0,1)]
for w in examples:
    c=mixed_class(w)
    assert c['pi2']==('Z' if c['d']==0 else '0')
    assert c['pi1']==('Z^2' if c['d']==0 else 'Z' if c['d']==1 else f'Z ⊕ Z/{c["d"]}')
    if c['d']>1:assert math.gcd(w[0],w[1],c['d'])==1
    if c['d']==0:assert math.gcd(w[0],w[1])==1

# Relative quotient identity r(kh,h)=k on KxK; exchange gives inversion.
# Nonabelian quaternion test uses exact rational quaternions for a local check.
def mul(x,y):
    a,b,c,d=x;e,f,g,h=y
    return (a*e-b*f-c*g-d*h,a*f+b*e+c*h-d*g,a*g-b*h+c*e+d*f,a*h+b*g-c*f+d*e)
def inv(x):return (x[0],-x[1],-x[2],-x[3])
i=(0,1,0,0);j=(0,0,1,0);k=(0,0,0,1)
assert mul(i,mul(j,inv(j)))==i
assert mul(mul(i,j),inv(j))==i
assert mul(i,inv(j))==inv(mul(j,inv(i)))
assert mul(mul(i,k),inv(k))==i

# A finite exhaustive sample of 2x2 primitive character matrices.
samples=[]
for w in [(1,0),(0,1),(1,1),(1,-1),(1,2),(2,1),(2,3),(3,2)]:
 for v in [(1,0),(0,1),(1,1),(1,-1),(1,2),(-1,2),(2,3)]:
  samples.append(check_pair(w,v))

output={
 'convention':{'bi_hopf_action':'(g_x,g_p)*(z,w)=(g_x h_x(z),h_p(w)g_p)','base':'S²_x×S²_p','chern_matrix':'diag(epsilon_x,epsilon_p)','residual_character':'chi_(a,b)(z_x,z_p)=z_x^b z_p^-a'},
 'primitive_contact':{'residual_chern_class':'b epsilon_x h_x - a epsilon_p h_p','c1_square':'-2 a b epsilon_x epsilon_p','contact_iff':'a*b != 0','bundle_integral_cohomology':'H*(T^(a,b);Z) ≅ Z[x_2,y_3]/(x_2^2,y_3^2) with x_2∪y_3=[T] when gcd(a,b)=1; generator choices noncanonical','topology':'S² × S³, diffeomorphism noncanonical'},
 'pair_of_slopes':{'source_fibre':'U(1)^2','matrix_formula':'[[b,-a],[d,-c]]','determinant_formula':'ad-bc','if_nonzero':'regular cyclic cover of degree |ad-bc| from P to Q_(a,b)×_B Q_(c,d)','if_unit':'canonical map is fibrewise isomorphism, globally a bundle isomorphism','if_zero':'not a finite covering; paired characters dependent','checked_examples':samples},
 'exchange_pair':{'slopes':[[1,1],[1,-1]],'hopf_character_matrix':[[1,-1],[-1,-1]],'scalar_eigenphase_matrix':[[1,1],[1,-1]],'unimodular_output_rotation':[[0,1],[-1,0]],'identity':'A_H=J A_scalar','kernel_phase_coordinates':[['0','0'],['1/2','1/2']],'fiber_product_total_space':'SO(4) ≅ (S³_x×S³_p)/Delta{±1}','relative_chern_rows':[[1,-1],[-1,-1]],'chern_lattice_index':2,'chern_characteristic_numbers':[-2,2],'parity_obstruction':'requires common diagonal C2 sign; no integral eigenbasis of full Hopf torus'},
 'combined_exchange':{'T4_degree':4,'deck_group':'(C2)^2','block_diagonal_matrices':'diag(A_H,A_scalar)','kernel_phase_coordinates':[[str(z) for z in row] for row in combined_kernel]},
 'mixed_cocharacters':{'normal_form_classifier':'d=gcd(m,n); d=0 pure Hopf, d=1 scalar primitive, d>1 residual cyclic action','examples':[mixed_class(w) for w in examples]},
 'mathematical_limits':['no canonical identification between Hopf lattice and scalar torus geometric bundles','exchanging independently marked Hopf axes requires identifying their orientations first','no physical source, mass or interaction claim','Chern classes depend on chosen oriented Hopf fibre sign','map to double quotient is a covering only for nonzero slope determinant'],
 'verification':'symbolic integer identities, exact kernel enumeration, Smith normal forms and Gysin model'
}
(ROOT/'data'/'bihopf_integral_geometry_instance.json').write_text(json.dumps(output,indent=2,ensure_ascii=False)+'\n')
print('PASS: primitive slope Chern and contact formula, integral Gysin product ring')
print('PASS: all tested primitive slope-pair covers and cyclic Smith normal forms')
print('PASS: exchange pair reconstructs Spin(4)/Delta(C2)=SO(4); lattice index 2')
print('PASS: Hopf/scalar character isogenies conjugate by integral J; combined degree 4')
print('PASS: mixed scalar cocharacter fundamental-group Smith classification and relative quotient test')
