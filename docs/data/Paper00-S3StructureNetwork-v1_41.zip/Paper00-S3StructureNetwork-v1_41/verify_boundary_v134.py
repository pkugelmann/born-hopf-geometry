#!/usr/bin/env python3
"""Exact counterfamilies / conditional sublemma tests for remaining 3 source maps.
These deliberately do NOT discharge source-branch selection. Read with v134 report.
"""
from __future__ import annotations
import json,itertools,pathlib,sys,hashlib,zipfile
import sympy as s
r=pathlib.Path(__file__).resolve().parent
out=r/'data/v134_unresolved_boundary_tests.json'
# 052: independent full matrix-component actions mathematically generate M9.
I=s.eye(3)
def E(i,j):
 m=s.zeros(3);m[i,j]=1;return m
A=[s.kronecker_product(E(i,j),I) for i in range(3) for j in range(3)]
B=[s.kronecker_product(I,E(i,j)) for i in range(3) for j in range(3)]
assert all(a*b==b*a for a in A for b in B)
basis=[a*b for a in A for b in B]
assert len(basis)==81 and len(set(tuple(M) for M in basis))==81
# Explicit 81 matrix units in full M9; not evidence of Hurwitz-generation.
assert {tuple(M) for M in basis} == {tuple(E9) for i in range(9) for j in range(9) for E9 in [s.eye(9)[:,i]*s.eye(9)[j,:]]}
# 056: a terminal shell scale alone has no algebraic mechanism to constrain a
# separately supplied nonzero dimensionless factor. Source no-insertion is typed.
E56,k=s.symbols('E56 kappa',positive=True)
T=s.diag(1,2,3)
assert (k*E56*T)/(E56)==k*T and T!=2*T
# 072: exact color-singlet compression but Hermitian color-invariant H not selected.
v=s.zeros(9,1)
for j in range(3):v[3*j+j]=1
Pc=v*v.T/3
assert Pc**2==Pc and Pc.T==Pc and Pc.rank()==1
lambdas=[
 s.Matrix([[0,1,0],[1,0,0],[0,0,0]]),
 s.Matrix([[0,-s.I,0],[s.I,0,0],[0,0,0]]),
 s.diag(1,-1,0),
 s.Matrix([[0,0,1],[0,0,0],[1,0,0]]),
 s.Matrix([[0,0,-s.I],[0,0,0],[s.I,0,0]]),
 s.Matrix([[0,0,0],[0,0,1],[0,1,0]]),
 s.Matrix([[0,0,0],[0,0,-s.I],[0,s.I,0]]),
 s.diag(1,1,-2)/s.sqrt(3)]
for L in lambdas:
 J=s.kronecker_product(L,s.eye(3))-s.kronecker_product(s.eye(3),L.T)
 assert J*Pc==s.zeros(9) and Pc*J==s.zeros(9)
t=s.symbols('t',real=True)
H0=s.zeros(9);H1=t*Pc
assert Pc*H0*Pc==s.zeros(9) and Pc*H1*Pc==t*Pc
assert H0==H0.conjugate().T and H1==H1.conjugate().T
# provenance: exact hash of all seven sources, using all 24 unchanged witnesses.
wit=json.loads((r/'data/v133_current_tex_scope_witnesses.json').read_text())
needed={'G32-052','G32-056','G32-059','G32-061','G32-066','G32-070','G32-072'}
source_dir=pathlib.Path(__import__('os').environ.get('BH_PAPERS_TEX_DIR','/mnt/data/work_papers'))
checked=[]
for w in wit['witnesses']:
 if w['relation_id'] not in needed:continue
 src=source_dir/w['source_tex']
 if src.is_file():
  assert hashlib.sha256(src.read_bytes()).hexdigest()==w['sha256'],w['relation_id']
  assert ('\\label{'+w['label']+'}') in src.read_text()
 elif '--strict-sources' in sys.argv:
  raise AssertionError('External controlling TeX file missing: '+str(src))
 checked.append({'relation_id':w['relation_id'],'source_tex':w['source_tex'],'label':w['label'],'sha256':w['sha256'],'source_checked':True})
assert {x['relation_id'] for x in checked}==needed
D={'release':'v1_34','source_archive':'Paper00-PapersMinimal-v3_029(1).zip',
   'current_tex_source_anchor_checks':sorted(checked,key=lambda x:x['relation_id']),
   'remaining_ids':['G32-052','G32-056','G32-072'],
   'boundary_tests':{
      'G32-052':{'mathematical_conditional_sublemma':'commuting full M3(C) independent test algebras span M9(C)',
                 'all_commutators_zero':True,'generated_matrix_units':81,
                 'not_proved':'that the selected oriented Hurwitz link generates two independent, complementary source trimers and GP2/GP3 one-copy owner'},
      'G32-056':{'nonuniqueness_with_unlicensed_dimensionless_scalar':'E56*T and kappa*E56*T both typed row energies for kappa positive, without word-generation criterion',
                 'not_proved':'independent non-generation of kappa56 for all eligible terminal source words; theorem states no-insertion conditional'},
      'G32-072':{'color_singlet_projector_rank':1,'SU3_generators_checked':8,'invariant_H_counterfamily':'H0=0 and Ht=t Psinglet give singlet compressed energies 0 and t',
                 'not_proved':'selected relative Hamiltonian, hyperfine/radial coefficients and physical meson pole'}},
   'sources_verified_by_full_hash':True,'theorem_or_physical_claims_promoted':0}
if '--check' in sys.argv:
 assert json.loads(out.read_text())==D
 print('CHECK 3 exact boundary certificates and seven current TeX label+hash anchors')
else:
 out.write_text(json.dumps(D,indent=2,ensure_ascii=False,sort_keys=True)+'\n')
 print('WRITE',out)
print('PASS unresolved map tests: Hurwitz independent tensor structure conditional, E56 scalar port conditional, meson H nonuniqueness exact')
