#!/usr/bin/env python3
"""Independent exact Q(sqrt(5)) Hopf/600-cell finite graph verification.

Reconstructs the icosian group and 600-cell edges from quaternionic formulas,
then independently checks every finite claim against the packaged Hopf instance.
The underlying formula source is the exact v1_12 exceptional model, but the
Hopf quotient and graph spectra are recalculated, not trusted from JSON.
"""
from __future__ import annotations
import pathlib,sys,json,itertools,collections
import sympy as sp
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from exceptional_model import generate_vertices,qmul,conj,dot16,neg,ZERO
IUNIT=(ZERO,(4,0),ZERO,ZERO)
JUNIT=(ZERO,ZERO,(4,0),ZERO)
KUNIT=(ZERO,ZERO,ZERO,(4,0))
ONE=((4,0),ZERO,ZERO,ZERO)
MINUS=((-4,0),ZERO,ZERO,ZERO)
def negate(q):return tuple(neg(x) for x in q)
C4={ONE,MINUS,IUNIT,negate(IUNIT)}
Q8=C4|{JUNIT,negate(JUNIT),KUNIT,negate(KUNIT)}
HR=lambda q:qmul(qmul(q,IUNIT),conj(q))
HL=lambda q:qmul(qmul(conj(q),IUNIT),q)

H,I=generate_vertices();V=sorted(I);vid={v:i for i,v in enumerate(V)}
assert len(H)==24 and len(I)==120
assert C4<=Q8<=H<=I
assert all(HR(conj(v))==HL(v) for v in V)
assert len({HR(v) for v in V})==30
assert len({HR(v) for v in H})==6

# Reconstruct 600-cell adjacency from exact golden neighbour criterion.
edges=[(a,b) for a,b in itertools.combinations(range(120),2) if dot16(V[a],V[b])==(4,4)]
assert len(edges)==720
adj={i:set() for i in range(120)}
for a,b in edges:adj[a].add(b);adj[b].add(a)
assert {len(x) for x in adj.values()}=={12}

# Work out five 24-element left cosets directly, not from old packaged colors.
Hcosets=[frozenset(H)];unseen=I-H
while unseen:
 g=min(unseen);coset=frozenset(qmul(g,h) for h in H)
 assert coset<=unseen and len(coset)==24
 Hcosets.append(coset);unseen-=coset
assert len(Hcosets)==5
colors={vid[q]:i for i,C in enumerate(Hcosets) for q in C}
cores=[frozenset(qmul(qmul(min(C),h),conj(min(C))) for h in H) for C in Hcosets]
assert len(set(cores))==5
assert all(len(cores[i]&cores[j])==6 for i,j in itertools.combinations(range(5),2))

# The directed base point is HR(q), with stabilizer right C4.
dirs=sorted({HR(q) for q in V});did={d:i for i,d in enumerate(dirs)}
map30={i:did[HR(q)] for i,q in enumerate(V)}
fil30=[[i for i in range(120) if map30[i]==d] for d in range(30)]
assert all(len(f)==4 for f in fil30)
assert all({qmul(V[f[0]],g) for g in C4}=={V[i] for i in f} for f in fil30)
colors30={d:colors[fil30[d][0]] for d in range(30)}
assert all(len({colors[v] for v in f})==1 for f in fil30)
for ci in range(5):
 group=[dirs[d] for d in range(30) if colors30[d]==ci]
 assert len(group)==6
 dots=collections.Counter(dot16(x,y) for x,y in itertools.combinations(group,2))
 assert dots=={(0,0):12,(-16,0):3}

# Antipodal direction quotient; verify exactly identical to right Q8 orbits.
axes=sorted({frozenset((d,negate(d))) for d in dirs},key=lambda c:min(c))
assert len(axes)==15
axmap={did[d]:a for a,ax in enumerate(axes) for d in ax}
map15={v:axmap[map30[v]] for v in range(120)}
fil15=[[v for v in range(120) if map15[v]==a] for a in range(15)]
assert all(len(f)==8 for f in fil15)
assert all({qmul(V[f[0]],g) for g in Q8}=={V[i] for i in f} for f in fil15)
colors15={a:colors[fil15[a][0]] for a in range(15)}
assert collections.Counter(colors15.values())=={i:3 for i in range(5)}
for a,ax in enumerate(axes):
 d=next(iter(ax))
 assert [i for i,C in enumerate(cores) if d in C]==[colors15[a]],'C4 axis must belong to unique core'

# Actual edge projection and local bijection (stronger than just degree/edge count).
ce30=collections.Counter(tuple(sorted((map30[u],map30[v]))) for u,v in edges)
ce15=collections.Counter(tuple(sorted((map15[u],map15[v]))) for u,v in edges)
assert len(ce30)==180 and set(ce30.values())=={4}
assert len(ce15)==90 and set(ce15.values())=={8}
assert all(a!=b for a,b in ce30) and all(a!=b for a,b in ce15)
a30={i:set() for i in range(30)};a15={i:set() for i in range(15)}
for u,v in ce30:a30[u].add(v);a30[v].add(u)
for u,v in ce15:a15[u].add(v);a15[v].add(u)
assert all(len(v)==12 for v in a30.values()) and all(len(v)==12 for v in a15.values())
for i in range(120):
 assert len({map30[v] for v in adj[i]})==12
 assert len({map15[v] for v in adj[i]})==12
 assert {map30[v] for v in adj[i]}==a30[map30[i]]
 assert {map15[v] for v in adj[i]}==a15[map15[i]]
for i in range(30):
 assert len({axmap[v] for v in a30[i]})==12
 assert {axmap[v] for v in a30[i]}==a15[axmap[i]]

# K33333, not just a 15-vertex 12-regular arbitrary graph.
assert all((a,b) in ce15 for a,b in itertools.combinations(range(15),2) if colors15[a]!=colors15[b])
assert all((a,b) not in ce15 for a,b in itertools.combinations(range(15),2) if colors15[a]==colors15[b])
for i,j in itertools.combinations(range(5),2):
 assert sum(tuple(sorted((colors[u],colors[v])))==(i,j) for u,v in edges)==72
 assert sum(tuple(sorted((colors30[a],colors30[b])))==(i,j) for a,b in ce30)==18
 assert sum(tuple(sorted((colors15[a],colors15[b])))==(i,j) for a,b in ce15)==9

# The explicit right action is a free deck-group action at all stages.
edge_lookup=set(edges)
for g in Q8:
 for a,b in edges:
  transported=tuple(sorted((vid[qmul(V[a],g)],vid[qmul(V[b],g)])))
  assert transported in edge_lookup
assert all(qmul(qmul(g,c),conj(g)) in C4 for g in Q8 for c in C4)

X=sp.Symbol('x')
A30=sp.zeros(30);A15=sp.zeros(15)
for a,b in ce30:A30[a,b]=A30[b,a]=1
for a,b in ce15:A15[a,b]=A15[b,a]=1
assert sp.expand(A30.charpoly(X).as_expr()-X**15*(X-12)*(X+3)**8*(X**2-4*X-16)**3)==0
assert sp.expand(A15.charpoly(X).as_expr()-X**10*(X-12)*(X+3)**4)==0

# Compare regenerated mathematical instance, keyed using natural labels rather than
# assuming an independently generated ordering matches the stored coset labels.
pack=json.loads((ROOT/'data/hopf_quotient_exact_instance.json').read_text())
assert len(pack['hopf_directions'])==30 and len(pack['hopf_axes'])==15
assert set(tuple(tuple(pair) for pair in [((0,0),)+tuple(tuple(e) for e in p['imag_qcoords'])][0]) for p in pack['hopf_directions'])==set(dirs)
for p in pack['hopf_directions']:
 d=((0,0),)+tuple(tuple(v) for v in p['imag_qcoords'])
 assert sorted(p['vertex_fibre'])==sorted(vid[q] for q in V if HR(q)==d)
 assert p['coset_color'] in range(5)
for p in pack['hopf_axes']:
 assert len(p['vertex_fibre'])==8 and len(p['direction_ids'])==2
assert sorted((e['u'],e['v']) for e in pack['graph_30']['edges'])==sorted(ce30)
assert sorted((e['u'],e['v']) for e in pack['graph_15']['edges'])==sorted(ce15)
assert all(e['original_edge_multiplicity']==4 for e in pack['graph_30']['edges'])
assert all(e['original_edge_multiplicity']==8 for e in pack['graph_15']['edges'])
assert pack['checks']['fifteen_axis_graph_is_K_3_3_3_3_3']
print('VALID: exact marked SU2/Hopf maps, 120→30→15 = regular 4-fold/2-fold/Q8 eightfold graph covers')
print('VALID: five 6-point octahedra, fifteen core-owned axes, K33333, 72→18→9 C6 edge classes')
print('VALID: two exact adjacency characteristic polynomials and handedness inversion identity')
