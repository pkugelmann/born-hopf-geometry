#!/usr/bin/env python3
"""Verify unchanged numerical instances from cumulative parent v1_24 by sha256."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parent
rec=json.loads((R/'reports/INHERITED_V124_DATA_HASHES.json').read_text())
for n,h in rec['inherited_unchanged_data_sha256'].items():
 p=R/'data'/n
 assert p.exists() and hashlib.sha256(p.read_bytes()).hexdigest()==h, n
print('PASS: '+str(len(rec['inherited_unchanged_data_sha256']))+' unchanged v1_24 mathematical instance files, hash-verified')
