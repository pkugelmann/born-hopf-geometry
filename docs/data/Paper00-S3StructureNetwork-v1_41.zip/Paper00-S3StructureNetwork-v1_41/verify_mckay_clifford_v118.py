#!/usr/bin/env python3
"""Recompute geometry-only Batch 7 McKay/Clifford/E8 certificates with exact arithmetic."""
import json,pathlib,hashlib
from scripts.mckay_clifford_v118 import build
root=pathlib.Path(__file__).resolve().parent
expected=json.loads((root/'data/mckay_clifford_v118_instance.json').read_text())
actual=build()
assert actual==expected,'exact finite group/root model fails to reproduce packaged data'
assert actual['cross_ADE_rank']==5
assert actual['cross_ADE_squared_singular_value_multiplicities']=={'10':2,'4':2,'2':1,'0':4}
assert actual['e8_quaternionic_coefficient_action']['two_sided_effective_action_size']==7200
assert len(actual['e8_quaternionic_coefficient_action']['sample_twice_action_matrices'])==5
print('PASS: 2T/2O/2I 7/8/9 irreducible class tables exactly verified as central algebra characters')
print('PASS: affine E6/E7/E8 tensor products and 61 SU2 harmonic levels agree with prior geometry')
print('PASS: exact restriction B(7x8), B(7x9); X(8x9), rank5, A7 X=X A8, eigenvalue/singular spectrum')
print('PASS: both Galois SU2 spinors, exact Euclidean metric splitting, all 120 left and right E8 root automorphisms')
print('PASS: 7200 effective two-sided actions, two regular 120-root orbits, H/Q8=C3 triality sector permutations')
