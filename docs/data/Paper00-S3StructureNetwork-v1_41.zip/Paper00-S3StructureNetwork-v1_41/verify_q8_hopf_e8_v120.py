#!/usr/bin/env python3
"""Independent exact regeneration and comparison of the v1_20 common-axis bridge."""
import pathlib,sys,json,collections
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts.q8_hopf_e8_bridge_v120 import build
computed=build()
stored=json.loads((ROOT/'data/q8_hopf_e8_bridge_v120_instance.json').read_text())
assert stored==computed,'Batch 9 computed quotient/incidence data differ from saved mathematical instance'
assert all(rec['id']==i for i,rec in enumerate(stored['axis15']))
assert len(stored['two_golden_sheets_thirty_Q8_orbits'])==30
assert len(stored['weighted_full_E8_axis_hyperedges'])==215
assert len(stored['triality_axis12_hyperedges'])==104
print('PASS: regenerated full 600-cell adjacency, both exact E8 coefficient sheets, all 240 roots and root-sum incidence')
print('PASS: LEFT Q8 orbit partition transported by INVERSION to existing RIGHT Q8 Hopf axes')
print('PASS: quotient Q600=K_(3,3,3,3,3), QE8=4(K15), difference 4(five K3)')
print('PASS: 1+4+10 simultaneous spectral decomposition from exact rational matrices')
print('PASS: 280 Q8 triple-orbits give weighted 2-(15,3,8) design on 215 supports')
print('PASS: 24 Q8 triality orbit nodes map two-to-one onto 12 non-D4 axes; 104 support triples and all weights retained')
