#!/usr/bin/env python3
"""Regenerate Batch 5 exact finite geometry; compare *every* stored instance field.
Mathematics is determined by quaternionic vertex coordinates and finite integer
matrices, not by copied claim-node summaries or floating point measurements.
"""
import pathlib,json,hashlib
from scripts.finite_geom_v116 import build
root=pathlib.Path(__file__).resolve().parent
p=root/'data'/'finite_geometry_v116_instance.json'
recorded=json.loads(p.read_text())
fresh=json.loads(json.dumps(build()))
assert recorded==fresh, 'finite instance differs from independent regeneration'
inst=recorded
assert inst['transporter_24cells']['B60_SNF_invariant_factors']==[1]*17
assert inst['transporter_24cells']['Aplus3_rank_mod101']==104
assert inst['transporter_24cells']['projector_rank']==16
assert inst['chambers']['counts']=={'chambers':600,'blocks':25,'chambers_per_block':24}
assert inst['projective_cyclic_design']['poly_counts']=={'2':450,'3':200,'5':72}
assert len(inst['petersen_kneser']['two_RP2_triangle_orbits'])==2
assert inst['hurwitz_F4']['f_vector']==[24,96,96,24]
assert inst['hurwitz_F4']['rank_unsigned_edge_face']==73
assert inst['hurwitz_F4']['W_F4_order']==1152
print('PASS v1_16: exact 2I/A5 core action, 25 transporter 24-cells, -3 projector and primitive SNF image')
print('PASS v1_16: 600 tetrahedral chambers, 25 face-block complements, 722 projective cyclic polygons')
print('PASS v1_16: both 6-axis RP2 triangle systems, Petersen/Kneser and signed exterior-Hodge identities')
print('PASS v1_16: exact Hurwitz 24-cell boundary, rank-73 incidence, 48 F4 roots, |W(F4)|=1152')
print('COMMITTED INSTANCE SHA256',hashlib.sha256(p.read_bytes()).hexdigest())
