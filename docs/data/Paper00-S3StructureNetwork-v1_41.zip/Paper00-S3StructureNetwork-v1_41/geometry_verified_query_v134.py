#!/usr/bin/env python3
"""Query v134 per-edge proof quality without confusing relation existence with theorem closure."""
import pathlib,json,argparse
r=pathlib.Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--edge');p.add_argument('--pending',action='store_true');p.add_argument('--new',action='store_true');p.add_argument('--summary',action='store_true');a=p.parse_args()
D=json.loads((r/'data/v134_verified_frontier_status.json').read_text()); E={e['id']:e for e in json.loads((r/'data/mathematical_relations.json').read_text())}
if a.edge:
 x=a.edge.upper()
 if not x.startswith('G32-'):x='G32-'+x.zfill(3)
 if x not in E:raise SystemExit('Unknown edge: '+x)
 print(json.dumps({'relation':E[x],'effective_status':D['relations'].get(x,{'effective_mathematical_map_status':E[x]['verification']})},indent=2))
else:
 print('v134 source map frontier:',D['replay_count'],'locally replayed,',D['pending_count'],'still pending; 0 physical/whole-source theorem promotions')
 for id,x in sorted(D['relations'].items()):
  if a.pending and id not in D['pending_ids']:continue
  if a.new and id not in D['newly_verified_ids']:continue
  print(id,x['from'], '->',x['to'], '|',x['effective_mathematical_map_status'])
