#!/usr/bin/env python3
"""Build v134 effective certificate-overlaid mathematical graph without mutating v132 graph ledgers.

Edges are SAME source map relations; only their effective proof grade is changed in this
adjacent export. Original mathematical_structure_network.graphml remains bytewise preserved.
"""
from pathlib import Path
import xml.etree.ElementTree as ET
import json,argparse
ROOT=Path(__file__).resolve().parent
rd=lambda n:json.loads((ROOT/'data'/n).read_text())
O=rd('objects.json');E=rd('mathematical_relations.json');H=rd('joint_input_relations.json')
front=rd('v134_verified_frontier_status.json');cert=rd('v134_scoped_math_replays.json')
assert len(front['relations'])==24
assert set(front['relations'])=={e['id'] for e in E if e.get('verification')=='SOURCE_RESTRICTED_MATHEMATICAL_MAP_EXACT_PROOF_NOT_REPLAYED'}
assert set('G32-'+i for i in cert['checks'])==set(front['newly_verified_ids'])
ns='http://graphml.graphdrawing.org/xmlns';ET.register_namespace('',ns);t=lambda a:'{'+ns+'}'+a
om={o['id']:o for o in O}
mp={e['id']:e for e in E}

def gml(nodes,edges):
    root=ET.Element(t('graphml'))
    keys=[('n0','node','label'),('n1','node','object_type'),('n2','node','batch'),('e0','edge','relation'),('e1','edge','link_type'),('e2','edge','effective_verification'),('e3','edge','requires_and_inputs'),('e4','edge','source_anchor'),('e5','edge','certificate_ref'),('e6','edge','guard_id'),('e7','edge','source_verification_v132')]
    for key,context,name in keys:ET.SubElement(root,t('key'),{'id':key,'for':context,'attr.name':name,'attr.type':'string'})
    g=ET.SubElement(root,t('graph'),{'id':'BornHopfS3EffectiveMathV134','edgedefault':'directed'})
    for id in nodes:
        o=om[id];n=ET.SubElement(g,t('node'),{'id':id})
        for k,val in [('n0',o['name']),('n1',o['object_type']),('n2',o.get('batch',''))]:ET.SubElement(n,t('data'),{'key':k}).text=str(val)
    for edge in edges:
        ed=ET.SubElement(g,t('edge'),{'id':edge['id'],'source':edge['from'],'target':edge['to']})
        state=front['relations'].get(edge['id'],{});
        eff=state.get('effective_mathematical_map_status',edge.get('verification',''))
        source=(edge.get('current_source_anchor') or edge.get('witness') or {})
        for k,val in [('e0',edge['relation']),('e1',edge['link_type']),('e2',eff),('e3',','.join(edge.get('requires_joint_inputs',[]))),('e4',source.get('label') or source.get('claim_id') or ''),('e5',state.get('certificate_ref','')),('e6',edge.get('joint_relation_id','')),('e7',edge.get('verification',''))]:
            ET.SubElement(ed,t('data'),{'key':k}).text='' if val is None else str(val)
    import io
    buf=io.BytesIO();ET.ElementTree(root).write(buf,encoding='utf-8',xml_declaration=True);return buf.getvalue()

def dot(nodes,edges):
    lines=['digraph BornHopfS3MathV134 {','  graph [rankdir=LR];','  node [shape=box];']
    for id in nodes:lines.append('  '+json.dumps(id)+' [label='+json.dumps(om[id]['name'])+'];')
    for e in edges:
        status=front['relations'].get(e['id'],{}).get('effective_mathematical_map_status',e.get('verification',''))
        label=e['id']+': '+('CONDITIONAL-MATH-REPLAY' if status.startswith('INDEPENDENT') else ('PENDING' if e['id'] in front['relations'] else e['relation']))
        lines.append('  '+json.dumps(e['from'])+' -> '+json.dumps(e['to'])+' [label='+json.dumps(label)+'];')
    return ('\n'.join(lines)+'\n}\n').encode()

subset=[mp[x] for x in sorted(front['newly_verified_ids'])]
subnodes=sorted(set(x for e in subset for x in (e['from'],e['to'])))
records={
 'graph/mathematical_structure_network_effective_v134.graphml':gml([o['id'] for o in O],E),
 'graph/mathematical_structure_network_effective_v134.dot':dot([o['id'] for o in O],E),
 'graph/batch23_verified_scoped_math_maps.graphml':gml(subnodes,subset),
 'graph/batch23_verified_scoped_math_maps.dot':dot(subnodes,subset),
}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--write',action='store_true');p.add_argument('--check',action='store_true');opt=p.parse_args()
 assert len(subset)==front['newly_verified_count']==4 and front['replay_count']==21
 for name,data in records.items():
    dest=ROOT/name
    if opt.write:dest.write_bytes(data)
    if opt.check:assert dest.read_bytes()==data,name
    print(('WRITE' if opt.write else 'CHECK'),name,len(data))
 print('PASS effective graph: identical base endpoints, exactly 21 scoped certificate overrides, 3 pending untouched')
