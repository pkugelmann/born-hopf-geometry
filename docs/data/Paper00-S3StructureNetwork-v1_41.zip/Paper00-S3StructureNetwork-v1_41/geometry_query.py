#!/usr/bin/env python3
"""Search actual S³ mathematical objects, typed morphisms and finite instances.

This is NOT a theorem/proof DAG. Path output is geometric navigation; it does not
prove an AND-input relation or an independently conditional construction.
"""
from __future__ import annotations
import argparse,collections,json,pathlib
from fractions import Fraction
HERE=pathlib.Path(__file__).resolve().parent
load=lambda n:json.loads((HERE/'data'/n).read_text())
objs={r['id']:r for r in load('objects.json')};rels=load('mathematical_relations.json')
hyp=load('joint_input_relations.json')
a=argparse.ArgumentParser(description=__doc__)
a.add_argument('--batch21',action='store_true',help='v1_32 exact 20-directed-pair nonet, Hurwitz even10, S3 spectra and 53-isolate closure')
a.add_argument('--classification',metavar='OBJECT_ID',help='show v1_31 isolate mathematical link/disposition and current source anchor')
a.add_argument('--closure-frontier',action='store_true',help='classify all 53 previous isolates; not physical closure')
a.add_argument('--batch20',action='store_true',help='v1_31 S3-to-SU3 group, Haar and finite path geometry')
a.add_argument('--hopf-su3',action='store_true',help='marked Cartan/Hopf normalized 3-form pullback')
a.add_argument('--two-vertex-gauss',action='store_true',help='exact two-vertex SU3 Gauss projector and Casimir blocks')
a.add_argument('--path-refinement-example',action='store_true',help='finite three-edge SU3 holonomy refinement and gauge naturality')
a.add_argument('--batch19',action='store_true',help='v1_30 Petersen compression and SU3 finite invariant summary')
a.add_argument('--petersen-core-compression',action='store_true',help='all 32 support polynomials and new averaged square identity')
a.add_argument('--su3-finite-invariants',action='store_true',help='exact 3x3bar singlet, epsilon determinant and Casimir operators')
a.add_argument('--batch18',action='store_true',help='v1_29 Hurwitz cellular Hodge and finite Q8 quotient bridge counts')
a.add_argument('--hurwitz-hodge',action='store_true',help='unit-weight 96-face Hodge spectrum, ranks and dual cellular graph')
a.add_argument('--hurwitz-q8',action='store_true',help='explicit 2T 24-cell Q8 quotient 4K3 and rank2 -4 eigenprojector')
a.add_argument('--batch17',action='store_true',help='v1_28 geometry harmonics, pair-incidence and scalar-Green bridges')
a.add_argument('--icosahedral-harmonics',action='store_true',help='reconstructed H6, H10, H15, Phi12 polynomial certificates')
a.add_argument('--pair-gram',action='store_true',help='signed and unsigned 2I Petersen pair coefficient Gram spectra')
a.add_argument('--s3-green',action='store_true',help='round S3 mean-zero Green spectrum and p-factor mode cutoff')
a.add_argument('--geometry-coverage',action='store_true',help='latest audited component and isolation counts; not a proof DAG')
a.add_argument('--petersen-total',action='store_true',help='exact 600-cell D20/Z30 shell, T(dodecahedron) and Petersen quotient')
a.add_argument('--milnor-spectral',action='store_true',help='metric-adapted SU2 scalar blocks and spin-one inverse metric invariant')
a.add_argument('--c6-tight-frame',action='store_true',help='ten exact C6 axis-line projectors, local and global frame sums')
a.add_argument('--search',metavar='TEXT')
a.add_argument('--batch16-bridges',action='store_true',help='v1_27 completeness bridge summaries: Cl(0,3), M8, 600 zero band')
a.add_argument('--twisted25',action='store_true',help='exact 120-vertex quintet character kernel and modular rank certificate')
a.add_argument('--clifford-tangent',action='store_true',help='four active projector ranks and quaternion tangent/energy identities')
a.add_argument('--m8-exchange-betti',action='store_true',help='exact product/exchange Betti polynomials and conditions')
a.add_argument('--petersen-e36',action='store_true',help='exact quaternionic flux K and rank-two comparison spectrum')
a.add_argument('--finite-operator-bridges',action='store_true',help='mathematical Hermite/CAR/scalar parity/signed Petersen identities')
a.add_argument('--node',metavar='NODE')
a.add_argument('--neighbors',metavar='NODE')
a.add_argument('--path',nargs=2,metavar=('START','END'))
a.add_argument('--exact-only',action='store_true',help='use only individually exact group/incidence certificate edges')
a.add_argument('--joint-inputs',metavar='NODE')
a.add_argument('--axis',nargs=2,type=int,metavar=('CORE_I','CORE_J'),help='ten Petersen C6 axis model 0..4')
a.add_argument('--hopf-cover',action='store_true',help='summarize exact 600→30→15 regular graph cover')
a.add_argument('--hopf-direction',type=int,metavar='0..29')
a.add_argument('--hopf-axis',type=int,metavar='0..14')
a.add_argument('--lens',type=int,metavar='N',help='show Hopf-cyclic lens bundle and scalar first gap for n')
a.add_argument('--epsilon',type=str,default='1',help='Berger epsilon as positive rational for --lens (default 1)')
a.add_argument('--seifert',choices=['2T','2O','2I+','2I-'])
a.add_argument('--spin4-spectrum',choices=['2T','2O','2I'],help='round S3 binary quotient spectral multiplicities (n=0..60)')
a.add_argument('--degree',type=int,default=None,help='harmonic degree for --spin4-spectrum')
a.add_argument('--spin4-twin-angle',action='store_true',help='exact twin degree-12 Reynolds/projector invariants')
a.add_argument('--spin4-clifford',action='store_true',help='exact chiral gamma/Cl(0,3) summaries')
a.add_argument('--bihopf-pair',nargs=4,type=int,metavar=('a','b','c','d'),help='two primitive pure-Hopf slopes and their exact fibre-product cover')
a.add_argument('--m8-slope',nargs=4,type=int,metavar=('a','b','m','n'),help='primitive reciprocal maximal-torus quotient with scalar Smith invariant')
a.add_argument('--exchange-isogeny',action='store_true',help='paired Hopf/scalar exchange character matrices, C2 and C2xC2 deck groups')
a.add_argument('--mckay-group',choices=['2T','2O','2I'],help='exact McKay graph dimensions, adjacency and harmonic series')
a.add_argument('--mckay-restrict',choices=['2O','2I'],help='integer branching to shared embedded 2T and operator relation')
a.add_argument('--mckay-cross',action='store_true',help='exact rank-5 E7/E8 common-2T representation-ring intertwiner')
a.add_argument('--clifford-e8',action='store_true',help='two Galois quaternion spinors and 2I root-automorphism action')
a.add_argument('--q8-triality',action='store_true',help='exact Q8 orbit quotient, character and triple-hypergraph summary')
a.add_argument('--q8-orbit-pair',choices=['01','02','12'],help='weighted 8x8 quotient operator and rank-five projector for triality pair')
a.add_argument('--q8-mckay',action='store_true',help='affine D4 Q8 McKay restriction and rank-three E7/E8 correspondence')
a.add_argument('--petersen-five-six',action='store_true',help='exact five and six Petersen signed sectors: 2 quintet axis maps, exterior Hodge six and A5 no-go')
a.add_argument('--petersen56-matrix',choices=['wedge6','axis5a','axis5b','edgehodge6'],help='print one exact v1_25 matrix (integer/rational entries)')
a.add_argument('--petersen-a5-intertwiner',action='store_true',help='exact marked A5-equivariant Petersen edge, signed Hodge 10-pair and 600/E8 rank-four maps')
a.add_argument('--petersen-intertwiner-matrix',choices=['Z15','W10','K15x10'],help='print exact integer numerator of Petersen-to-axis / pair-sector partial isometry')
a.add_argument('--a5-coefficient',action='store_true',help='A5 standard 4D matrix coefficient and 60-point cyclic-polygon projector bridge')
a.add_argument('--q8-fourier',action='store_true',help='exact rank16 -> four orthogonal rank4 Q8-character spectral resolution')
a.add_argument('--q8-projector',choices=['trivial','chi_i','chi_j','chi_k'],help='inspect exact 120x120 rational Q8 projector numerator and rank')
a.add_argument('--e8-projector-bridge',action='store_true',help='exact Q8-fixed 600 minus3 / Hopf 15 axis / E8 Gram rank4 intertwiner')
a.add_argument('--polygon-c3',action='store_true',help='right C3 orbit types on 450,200,72 projective cyclic polygon sets')
a.add_argument('--holonomy-tower',action='store_true',help='the exact right 2T/Q8 covering 120->15->5 and matching identification')
a.add_argument('--holonomy-core-pair',nargs=2,type=int,metavar=('A','B'),help='all three third-core matching voltages for two distinct cores')
a.add_argument('--holonomy-triangle',nargs=3,type=int,metavar=('A','B','C'),help='exact 27-label triangle holonomy distribution')
a.add_argument('--axis-cubic',action='store_true',help='exact 15-axis ternary tensor, Gram spectral decomposition, and order-360 symmetry')
a.add_argument('--axis-local-core-triple',nargs=3,type=int,metavar=('A','B','C'),help='one 3x3x3 local matching tensor for three distinct cores 0..4')
a.add_argument('--axis-core-pair',nargs=2,type=int,metavar=('A','B'),help='all three K3,3 perfect matchings and C3 transport between the chosen core pair 0..4')
a.add_argument('--q8-hopf-e8',action='store_true',help='common 15-axis graph operator identity and weighted E8 root-triple design')
a.add_argument('--axis-e8',type=int,metavar='0..14',help='one shared Hopf axis: 600-cell, E8 fibres, quotient operator rows')
a.add_argument('--axis-triples',type=int,metavar='0..14',help='weighted E8 root-sum axis triple blocks containing selected axis')
a.add_argument('--golden-e8',action='store_true',help='exact E8 golden sheets, orthogonal D4, triality and E7/E6 summary')
a.add_argument('--golden-triality-pair',choices=['01','02','12'],help='view one exact 64x64 triality incidence operator and singular spectrum')
a.add_argument('--golden-e6-fiber',type=int,metavar='0..5',help='inspect one E6 A2-normal 27-weight/45-triple fibre')
a.add_argument('--finite-600',action='store_true',help='25 transporter cells, 600 chambers, 722 cyclic polygons: exact finite-geometry summary')
a.add_argument('--projector-link',action='store_true',help='exact -3 600-cell / A5 cyclic-polygon projector equality and proof certificate')
a.add_argument('--kneser-hodge',action='store_true',help='the two RP2 dual Petersen triangle orbits and signed exterior-Hodge identity')
a.add_argument('--hurwitz-f4',action='store_true',help='24-cell cellular f-vector, edge-face rank, 48-root F4 and W(F4)')
a.add_argument('--transporter',nargs=2,type=int,metavar=('I','J'),help='one 24-cell transporter block, row and column indices 0..4')
args=a.parse_args()
if args.geometry_coverage:
    c=json.loads((HERE/'reports/geometry_completeness_v132.json').read_text())
    print('MATHEMATICAL NETWORK COVERAGE; not a theorem-DAG or completeness proof')
    print(json.dumps(c['counts'],indent=2))
    print(c['status'])
if args.batch20 or args.hopf_su3 or args.two_vertex_gauss or args.path_refinement_example:
    d31=load('hopf_su3_v131_instance.json')
    if args.batch20:print(json.dumps(load('v131_release_counts.json'),indent=2))
    if args.hopf_su3:print(json.dumps(d31['su2_su3_embedding'],indent=2))
    if args.two_vertex_gauss:print(json.dumps({'single_vertex':{k:v for k,v in d31['SU3_tensor'].items() if not k.endswith('_9x9')},'two_vertex':d31['two_vertex_example']},indent=2))
    if args.path_refinement_example:print(json.dumps(d31['path_groupoid_sample'],indent=2))
if args.batch19 or args.petersen_core_compression or args.su3_finite_invariants:
    finite=load('finite_invariant_geometry_v130_instance.json')
    if args.batch19:
        print('Batch 19: exact 32 Petersen compressions, averaged-square identity and finite SU3 invariant tensor examples. Mathematical-only, not physical gauge source or QCD Hamiltonian.')
        print(json.dumps(load('v130_release_counts.json'),indent=2))
    if args.petersen_core_compression:
        print(json.dumps({'polynomials_scaled_H_sqrt5D':finite['petersen']['characteristic_polynomials_scaled_H_sqrt5D'], 'averaged_square':finite['petersen']['new_averaged_squared_compression_identity']},indent=2))
    if args.su3_finite_invariants:
        print(json.dumps({'rank_checks':finite['su3']['rank_checks'],'casimir_eigenvalues':finite['su3']['casimir_eigenvalues'],'condition':finite['su3']['center_triality_condition'],'scope':finite['su3']['scope']},indent=2))

if args.batch18 or args.hurwitz_hodge or args.hurwitz_q8:
 d=load('hurwitz_cellular_v129_instance.json')
 if args.batch18:
  print('GEOMETRY-ONLY Batch 18: Hurwitz 2T Cayley, Q8 quotient, oriented 24cell cellular Hodge')
  print(json.dumps(load('v129_release_counts.json'),indent=2))
 if args.hurwitz_hodge:
  print('Oriented 24-cell boundary and Hodge ranks:',d['counts']['incidence_ranks'])
  print('Exact unit-weight Hodge polynomial:',d['unit_weight_2_hodge']['characteristic_polynomial'])
  print('First four integer moments:',d['unit_weight_2_hodge']['exact_trace_moments_k1to4'])
  print('Dual facet/vertex permutation:',d['dual_24cell']['vertex_to_dual_facet_isomorphism'])
  print('Unit-cellular weights are a mathematical choice; not an interacting field Hessian.')
 if args.hurwitz_q8:
  q=d['hurwitz_group']
  print('The 2T Cayley quotient by normal Q8 is weighted 4K3:')
  print(json.dumps(q['q8_quotient_adjacency'],indent=2))
  print('Three quotient cosets:',q['q8_cosets'])
  print('Projector P_minus4=(3*delta_same_coset-1)/24, rank 2, A P=-4P.')
  print('Exact matrix and group multiplication in data/hurwitz_cellular_v129_instance.json')

if args.batch17:
    print(json.dumps(load('v128_release_counts.json'),indent=2))
    c=json.loads((HERE/'reports/geometry_completeness_v128.json').read_text())
    print('Remaining graph isolates:',c['counts']['isolated_objects'])
if args.icosahedral_harmonics:
    d=load('icosahedral_harmonics_v128_instance.json')
    print('Marked icosahedral axis geometry:',d['marked_geometry'])
    print('Polynomial sparse-term counts:',{k:len(v) for k,v in d['polynomials'].items()})
    print('T6 axis value:',d['T6_at_all_ten_axes'],'mean square:',d['T6_spherical_mean_square'])
    print('Right 2I harmonic eigenvalue:',d['Phi12_eigenvalue_round_unit_S3'],'fixed shell dimension:',d['right_2I_fixed_dimension_on_E12'])
if args.pair_gram:
    d=load('petersen_pair_coefficients_v128_instance.json')
    print('Twenty-five-cell and Petersen pair integer Gram certificates:')
    print(json.dumps(d['exact_Gram_spectral_multiplicities'],indent=2))
    for x in d['exact_matrix_identities']:print(x)
if args.s3_green:
    d=load('scalar_spectral_compositions_v128_instance.json')
    print('Mean-zero S3 spectral inverse:',d['mean_zero_green'])
    print('Momentum p-factor auxiliary cutoff:',d['finite_p_factor_Peter_Weyl_readout'])
    print('R(T6) marked chamber eigencontrast:',d['T6_contrast_eigenvalue'])
    print('No-coisometry dimension obstruction:',d['prohibited_coisometry'])
if args.batch16_bridges:
    o=load('v127_release_counts.json');c=json.loads((HERE/'reports/geometry_completeness_v127.json').read_text())
    print('GEOMETRY ONLY Batch 16: exact Clifford, Petersen, M8, 600 zero eigenspace, finite operator links')
    print(json.dumps(o,indent=2)); print(json.dumps(c['counts'],indent=2))
if args.twisted25:
    v=load('twisted25_v127_instance.json')
    print('TWISTED QUINTET: Pi25=P24/24, rank25, A600 Pi25=0, exact ker identification')
    print('Modular A600 rank lower bounds:',v['modular_lower_bounds_rank_A600'])
    print('Orthogonality:',v['minus3_transporter_orthogonality'])
    print('Integer matrix: data/twisted25_v127_instance.json')
if args.clifford_tangent:
    v=load('geometry_bridges_v127_instance.json')['clifford']
    print(v['structure'],v['marked_hopf_axis'])
    print(v['eight_dimensional_projector_ranks']);print(*v['exact_identities'],sep='\n')
if args.m8_exchange_betti:
    v=load('geometry_bridges_v127_instance.json')['reciprocal_heat']
    for k in ('harmonic_Betti_polynomial','exchange_Lefschetz_polynomial','exchange_even_Betti_polynomial','exchange_odd_Betti_polynomial','conditions'):
        print(k,':',v[k])
if args.petersen_e36:
    v=load('geometry_bridges_v127_instance.json')['petersen']
    for k in ('K_Ktranspose','rank','nonzero_Gram_eigenvalue','zero_multiplicity','protected_response_Gram','physical_scope'):
        print(k,':',v[k])
if args.finite_operator_bridges:
    v=load('geometry_bridges_v127_instance.json')['finite_geometric_operator_models']
    for k in ('finite_43_algebra_dimension','carrier_direct_sum_dimension','scalar_eigencharge_index','scalar_eigencharge_image','signed_Petersen_auxiliary_spectrum','nonidentification'):
        print(k,':',v[k])
if args.petersen_total:
    x=load('petersen_total_v126_instance.json')
    print('GEOMETRY ONLY: one marked 2I shell induced subgraph; quotient by q->q^-1')
    print(json.dumps(x['certificate'],indent=2))
    print('chi[T(Petersen)](x)=',x['total_graph_25_charpoly'])
    print('chi[T(Dodecahedron)](x)=',x['total_graph_50_charpoly'])
if args.milnor_spectral:
    x=load('milnor_spectral_v126_instance.json')
    print('GENERAL LEFT-INVARIANT SU2 METRIC; preserve left Milnor vs primary right Hopf frame distinction')
    print('H_j:',x['conventions']['H_j'])
    print('Jacobi matrix:',x['conventions']['tridiagonal'])
    print('j=1/2:',x['spin_half_block'])
    print('j=1 spectrum:',x['spin_one_block_spectrum'])
    print('Bound:',x['spectral_lower_bound'])
if args.c6_tight_frame:
    x=load('ten_axis_projectors_v126_instance.json')
    print(x['source_geometry'])
    print(x['local_tight_frame_identity']);print(x['global_tight_frame_identity'])
    print('Ten projectors and their 3x3 matrices are stored under data/ten_axis_projectors_v126_instance.json')
if args.petersen_five_six or args.petersen56_matrix:
    d25=load('petersen_five_six_v125_instance.json')
    print('GEOMETRY ONLY: Petersen signed 15-edge 4+5+6, axis 15-point A5 module 1+4+5+5, signed Hodge exterior 10-pair 4+3+3prime.')
    print('Three actual equivariant axis/unoriented-Petersen-edge bijections; chosen permutation:',d25['canonical_choice_axis_to_edge'])
    print('Exact Hom dimensions:',d25['A5_Hom_dimensions'])
    print('Spectral axis images:',d25['spectral_eigenvalues_axis_images'])
    print('Six-sector U6=W6/(25 sqrt(2)); Hodge eigenvalues +/-sqrt5 each threefold.')
    print('Five-sector maps U5a=X0/sqrt8 and U5b=X1/sqrt24 have orthogonal axis images.')
    if args.petersen56_matrix:
        k={'wedge6':'signed_edge_to_exterior_wedge_W6_10x15','axis5a':'signed_petersen5_to_axis5_X0_15x15',
           'axis5b':'signed_petersen5_to_axis5_X1_15x15','edgehodge6':'pulled_back_Petersen_edge_Hodge6_15x15'}[args.petersen56_matrix]
        print(k)
        for row in d25['matrices'][k]: print(' '.join(str(v) for v in row))

if args.petersen_a5_intertwiner or args.petersen_intertwiner_matrix:
    p=load('petersen_a5_bridge_v124_instance.json')
    print('GEOMETRY ONLY: marked 2I/2T/Q8 and oriented Petersen cochains.')
    print('unique five-core to Hopf-axis block relabeling sigma:',p['five_core_relabelling_to_axis_blocks'])
    print('Petersen 15-edge real cochain decomposes 4+5+6; signed exterior 10-pair Hodge decomposes 4+3+3.')
    print('Partial isometries:',p['normalizations'])
    for k,v in p['identities'].items():print(k+':',v)
    print('Actual A5 group elements checked:',p['permutation_group_checks']['distinct_A5_elements'])
    if args.petersen_intertwiner_matrix:
        k={'Z15':'petersen15_to_axis15_integer_Z_15x15',
           'W10':'petersen10_to_axis15_integer_W_15x10',
           'K15x10':'petersen10_to_petersen15_integer_K_15x10'}[args.petersen_intertwiner_matrix]
        print(k)
        for row in p['matrices'][k]:print(' '.join(str(x) for x in row))

if args.a5_coefficient or args.q8_fourier or args.q8_projector or args.e8_projector_bridge or args.polygon_c3:
    x23=load('a5_q8_projector_v123_instance.json')
    if args.a5_coefficient:
        z=x23['A5_matrix_coefficients']
        print('EXACT A5 MATRIX-COEFFICIENT GEOMETRY: 5D five-core permutation representation = 1+W4.')
        print('Centered 5x5 permutation coefficients span W4 x W4* of rank 16 in real R[A5].')
        print(z['cyclic_polygon_identity'])
        print('P60=(M3-M5)/15; antipodal P600=(B120 B120^T - J120)/30.')
    if args.q8_fourier:
        q=x23['Q8_character_projectors']
        print('Marked right Q8, W16_-3:',q['irreducible_characters'],'ranks',q['ranks'])
        print('P_chi=C_chi/240;',q['multiplication_law'])
        print('Right C3 permutation of sign projectors',q['right_C3_conjugation_of_character_projectors'])
        print('Complex C3 dimensions on W16:',q['C3_complex_eigenspace_dimensions'])
        print('This is NOT the rank-5 left-Q8 triality module from v1_19.')
    if args.q8_projector:
        q=x23['Q8_character_projectors'];k=q['irreducible_characters'].index(args.q8_projector)
        print(args.q8_projector,'rank4; projector exact rational numerator /',q['projector_denominator'])
        print('numerator 120x120:')
        for row in q['projector_integer_numerators'][k]:print(' '.join(map(str,row)))
    if args.e8_projector_bridge:
        z=x23['Q8_axis15_intertwiner']
        print('Exact same marked 15-axis operator from 600 and E8:',z['compression_identity'])
        print(z['lifting_identity']);print(z['quotient_adjacency_projector'])
        print(z['E8_weighted_tensor_gram_projector'])
        print('Projected rank4 P4=(5 SameCore-J15)/15; the isometry is F/sqrt(8).')
        print('Residual C3 complex dimensions on V10',z['C3_complex_eigen_dims_on_V10'])
        print('No 16D-to-4D isomorphism is asserted: map is only on the Q8-fixed summand.')
    if args.polygon_c3:
        print('Exact right C3 action on projective A5 cyclic polygons:')
        print(json.dumps(x23['polygon_family_under_right_C3'],indent=2))
        print('20 fixed C3 hexagons = 20 three-cycles of the right order-3 action on 60 A5 points.')

if args.holonomy_tower or args.holonomy_core_pair is not None or args.holonomy_triangle is not None:
    h=load('axis15_holonomy_v122_instance.json')
    if args.holonomy_tower:
        print('GEOMETRY ONLY: exact free right-2T action on the marked 600-cell.')
        print('Graph covers G600(120,720) --/Q8 degree8--> K33333(15,90) --/C3 degree3--> 3K5(5,30).')
        print('The five-vertex BASE IS A MULTIGRAPH with three parallel edges between every core pair.')
        print('All thirty right-2T edge orbit matchings EXACTLY equal the golden E8 weighted weight-two matchings.')
        print('The right-2T quotient C3 is the residual weighted tensor automorphism kernel, not a coincidental group order.')
        print('Aut(T) = C3 semidirect_sign S5; generator orientation is a marking choice.')
        print('Global choices: 3^10=59049; flat 3^4=81; distinct curvature patterns 3^6=729.')
        print('Nonzero loop curvature depends on which edge matching is selected; the geometry alone does not prefer one.')
    if args.holonomy_core_pair is not None:
        a,b=args.holonomy_core_pair
        if a==b or any(x not in range(5) for x in (a,b)):raise SystemExit('two distinct core indices 0..4 are required')
        ca,cb=sorted((a,b))
        rec=next(x for x in h['edge_voltage_table'] if x['core_pair']==[ca,cb])
        print('THREE MATCHING CHOICES; +1 and -1 depend on the marked deck generator:')
        print(json.dumps(rec,indent=2))
        orbits=[o for o in h['edge_orbits_2T'] if o['core_pair']==[ca,cb]]
        for x in orbits:
            print('third core',x['third_core'],'600-cell 2T orbit representative',x['edge_representative'],
                  '3 matching axis edges',x['axis_edge_matching'])
    if args.holonomy_triangle is not None:
        t=args.holonomy_triangle
        if len(set(t))!=3 or any(x not in range(5) for x in t):raise SystemExit('three distinct cores 0..4 are required')
        t=sorted(t)
        print('Triangle',t,'27 choices =',h['triangle_holonomy_counts_mod3_for_each_of_10_triangles'][','.join(map(str,t))],
              'counts for holonomy 0,1,2 in Z3.')
        print('The face-coherent matching labels (c,a,b) give identity holonomy, but other label choices need not.')
        print('Curvature satisfies the exact tetrahedral Bianchi relation; no canonical matching choice is assumed.')

if args.axis_cubic or args.axis_local_core_triple is not None or args.axis_core_pair is not None:
    cub=load('axis15_cubic_v121_instance.json')
    if args.axis_cubic:
        print('EXACT 15-axis E8 ROOT INCIDENCE TENSOR, NOT A PHYSICAL CUBIC INTERACTION.')
        print(cub['gram_closed_form'],'and',cub['gram_as_600_operator_polynomial'])
        print('Gram spectrum',cub['gram_eigenvalue_multiplicity'],'aut group order',cub['automorphism_group']['order'])
        print('Core-block recovery',cub['intrinsic_core_partition_from_tensor_gram'])
        print('Cubic sector squared norms:')
        for z in cub['cubic_sector_squarenorms']:
            print(' x '.join(z['sectors']),z['squared_frobenius_norm'])
        print('Five exact 3-subset orbits',cub['automorphism_group']['triple_orbits'])
    if args.axis_local_core_triple is not None:
        cs=args.axis_local_core_triple
        if len(set(cs))!=3 or any(not 0<=c<=4 for c in cs):raise SystemExit('three distinct core labels 0..4 required')
        rec=next(x for x in cub['ten_local_3x3x3_templates'] if set(x['core_colors'])==set(cs))
        print(json.dumps(rec,indent=2))
    if args.axis_core_pair is not None:
        cs=args.axis_core_pair
        if cs[0]==cs[1] or any(not 0<=c<=4 for c in cs):raise SystemExit('two distinct core labels 0..4 required')
        rec=next(x for x in cub['ten_pairwise_K33_one_factorizations'] if set(x['core_pair'])==set(cs))
        print(json.dumps(rec,indent=2))

if args.q8_triality or args.q8_orbit_pair or args.q8_mckay:
    q8=json.loads((HERE/'data/q8_triality_v119_instance.json').read_text())
    if args.q8_triality:
        print('Q8 action on 3 triality X64 sectors: eight free Q8-orbits per sector (8 vertices/orbit).')
        print('Each 64x64 cross-sector M has rank25; Q8 orbit incidence N has rank5 and Gram spectrum {256:1,16:4,0:3}.')
        print('24 Q8 orbit nodes across three sectors, 168 nonzero weighted edges (weights 2 or 4).')
        print('1024 zero-sum root triples -> 128 Q8 orbits represented by 104 weighted orbit triples: 96 singleton patterns, 8 fourfold patterns.')
        print('Q8 character on the 25D image: 25 at 1, 9 at -1, 1 at six order-four elements; fixed subspace rank5.')
    if args.q8_orbit_pair:
        k=list(map(int,args.q8_orbit_pair));z=next(x for x in q8['Q8_orbit_cross_sector_pairs'] if x['sectors']==k)
        print('Weighted Q8 orbit incidence X'+str(k[0])+' x X'+str(k[1]))
        for row in z['orbit_incidence_8x8']: print(row)
        print('rank',z['rank'],'gram eigenvalues',z['gram_eigenvalues'],'four-match permutation',z['four_match_perm_row_to_col'])
    if args.q8_mckay:
        m=q8['Q8_McKay_affineD4']
        print('Q8 McKay affine D4 adjacency:')
        for row in m['A_affine_D4']:print(row)
        print('R(2T) -> R(Q8) branch B (rank3):')
        for row in m['B_2T_to_Q8']:print(row)
        print('Q8-mediated E7/E8 map Y (rank3), shared eigenmodes [-2,0,2]:')
        for row in m['Y_cross_via_Q8']:print(row)
        print('Comparison: 2T-mediated X rank5; the rank5 triality quotient has DIFFERENT Gram eigenvalues; no natural identification inferred.')

if args.q8_hopf_e8 or args.axis_e8 is not None or args.axis_triples is not None:
    v20=load('q8_hopf_e8_bridge_v120_instance.json')
    if args.q8_hopf_e8:
        print('MARKED COMMON AXES: 600 nearest edges / LEFT Q8 -> 15 LEFT orbits -> invert -> 15 RIGHT Hopf axes.')
        print('Golden E8 sheets: 240 roots -> 30 LEFT Q8 orbits -> 15 RIGHT Hopf axes (16 roots/axis).')
        print('Q600=A(K33333), QE8=4(J15-I15), QE8-4Q600=4A(5K3).')
        print('Joint spectral ranks 1+4+10, eigenvalues:',v20['joint_eigenvalues_by_subspace'])
        print('Weighted 2-(15,3,8): 280 Q8 root-triple orbits, 215 supports, each pair multiplicity 8.')
        print('Triality 24 orbit vertices -> 12 axes two-to-one, 104 weighted hyperedge patterns.')
        print('IMPORTANT: left/right actions are transported by inversion; E8 map is equitable NOT a graph covering.')
    if args.axis_e8 is not None:
        k=args.axis_e8
        if not 0<=k<15:raise SystemExit('shared axis must be 0..14')
        print(json.dumps(v20['axis15'][k],ensure_ascii=False,indent=2))
        print('Q600 axis row:',v20['quotient_600_15x15'][k])
        print('QE8  axis row:',v20['quotient_E8_addition_15x15'][k])
        print('Delta axis row:',v20['difference_4_5K3_15x15'][k])
    if args.axis_triples is not None:
        k=args.axis_triples
        if not 0<=k<15:raise SystemExit('shared axis must be 0..14')
        triples=[x for x in v20['weighted_full_E8_axis_hyperedges'] if k in x['axis_triple']]
        print('Axis',k,'weighted triple supports',len(triples),'weighted incidences',sum(x['q8_orbit_multiplicity'] for x in triples))
        for x in triples:print(x['axis_triple'],'multiplicity',x['q8_orbit_multiplicity'])

if args.exact_only:
 exact_types={'EXACT_MARKED_2T_CAYLEY_CELLULAR_AND_INTEGER_HODGE_V129','EXACT_QSQRT5_COORDINATE_CERTIFICATE_AND_GROUP_ARGUMENT','EXACT_QUATERNION_HOPF_Q8_GRAPH_CERTIFICATE','EXACT_SYMBOLIC_AND_PRINCIPAL_BUNDLE_ARGUMENT','EXACT_QUATERNION_PERMUTATION_INCIDENCE_AND_ROOT_CERTIFICATE','EXACT_INTEGER_COORDINATE_AND_ROOT_SYSTEM_VERIFICATION','EXACT_CLASS_ALGEBRA_RESTRICTION_AND_ORTHOGONAL_ROOT_ACTION_CERTIFICATE','EXACT_QUATERNION_Q8_ORBIT_MATRIX_AND_ADE_RESTRICTION_CERTIFICATE','EXACT_QUATERNION_INVERSION_E8_ADJACENCY_AND_WEIGHTED_DESIGN_CERTIFICATE','EXACT_AXIS15_TRIPLE_TENSOR_GRAM_MATCHING_AND_FULL_AUTOMORPHISM_ENUMERATION'}
 rels=[e for e in rels if e.get('verification') in exact_types]
if args.search:
 for o in objs.values():
  if args.search.casefold() in (o['id']+' '+o['name']+' '+o['object_type']).casefold():print(o['id'],o['name'])
if args.node:
 print(json.dumps(objs.get(args.node,{'error':'unknown object'}),indent=2,ensure_ascii=False))
if args.neighbors:
 for e in rels:
  if args.neighbors in (e['from'],e['to']):
   print(e['from'],'--',e['relation'],'-->',e['to'],'AND:',e.get('requires_joint_inputs',[]))
if args.joint_inputs:
 for h in hyp:
  if args.joint_inputs in h.get('inputs',[])+h.get('outputs',[]):print(json.dumps(h,indent=2,ensure_ascii=False))
if args.path:
 source,target=args.path
 adj=collections.defaultdict(list)
 for e in rels:adj[e['from']].append(e)
 queue=collections.deque([(source,[])]);seen={source}
 while queue:
  node,path=queue.popleft()
  if node==target:
   for e in path:print(e['from'],'--',e['relation'],'-->',e['to'],'AND:',e.get('requires_joint_inputs',[]))
   print('GEOMETRIC NAVIGATION ONLY: joint conditions and source markings still need independent checking.')
   break
  for e in adj[node]:
   if e['to'] not in seen:seen.add(e['to']);queue.append((e['to'],path+[e]))
 else:print('No directed path under the selected relation filter.')
if args.axis:
 inst=load('exceptional_600cell_instance.json');pair=sorted(args.axis)
 item=next((q for q in inst['axes'] if q['pair']==pair),None)
 print(json.dumps(item or {'error':'select distinct core indices 0..4'},indent=2))
if args.hopf_cover or args.hopf_direction is not None or args.hopf_axis is not None:
 inst=load('hopf_quotient_exact_instance.json')
 if args.hopf_cover:
  print('600-cell:120 vertices/720 edges --right C4 (degree4)--> 30 directions/180 edges --C2 (degree2)--> 15 axes/90 edges')
  print('Direct cover is right Q8 regular degree8; 15-axis graph is K_{3,3,3,3,3}.')
  print('Each 24-cell coset produces a six-point octahedron; the resulting three C4 axes belong to its conjugate 2T core.')
  print('Every one of ten C6 pair labels carries 72 original edges / 18 C4 quotient edges / 9 Q8 quotient edges.')
 if args.hopf_direction is not None:
  d=args.hopf_direction
  print(json.dumps(inst['hopf_directions'][d] if 0<=d<30 else {'error':'direction must be 0..29'},indent=2))
 if args.hopf_axis is not None:
  i=args.hopf_axis
  print(json.dumps(inst['hopf_axes'][i] if 0<=i<15 else {'error':'axis must be 0..14'},indent=2))
if args.lens is not None:
 n=args.lens
 if n<1:raise SystemExit('N must be a positive integer')
 eps=Fraction(args.epsilon)
 if eps<=0:raise SystemExit('epsilon must be positive')
 print('L(%d,1) up to orientation; Chern number=%d, fibre length=(2πR epsilon)/%d; volume=(2π²R³ epsilon)/%d'%(n,n,n,n))
 print('Scalar weights q divisible by',n,'; k≥|q|, k≡q (mod 2), lambda=(k(k+2)+(epsilon^-2-1)q²)/R²')
 if n>=2 and eps<=1:print('Provable first positive scalar eigenvalue: 8/R². Basic q=0 band from k=2, multiplicity 3 unless epsilon=1 and n=2 (multiplicity 9).')
 else:print('First positive scalar gap is NOT asserted to equal 8/R² in this parameter regime.')
if args.seifert:
 m=load('hopf_metric_quotient_family.json');q=next(i for i in m['left_exceptional_right_Hopf'] if i['group']==args.seifert)
 print(json.dumps(q,indent=2))
 print('Branch uses opposite right Hopf and LEFT binary deck group; orbifold base, not ordinary principal S1 over S2.')
if args.spin4_spectrum or args.spin4_twin_angle or args.spin4_clifford:
 rep=load('spin4_exact_representation_instance.json')
 if args.spin4_spectrum:
  grp=args.spin4_spectrum
  if args.degree is not None:
   n=args.degree
   if not 0<=n<=60:raise SystemExit('degree must be 0..60')
   a=rep['invariant_multiplicities_0_to_60'][grp][n];d=rep['scalar_spaceform_multiplicities_0_to_60'][grp][n]
   print(f'{grp}: n={n}, dim V_n^G={a}, scalar eigenvalue={n*(n+2)}/R², scalar multiplicity={d}')
  else:
   print(grp,'Molien',rep['molien_closed_forms'][grp])
   print('first nonconstant mode',rep['first_nonconstant_scalar_modes'][grp])
   print('n,m_n,spaceform_multiplicity (0..30 for nonzero degrees):')
   for n,a in enumerate(rep['invariant_multiplicities_0_to_60'][grp][:31]):
    if a:print(n,a,rep['scalar_spaceform_multiplicities_0_to_60'][grp][n])
 if args.spin4_twin_angle:print(json.dumps(rep['twin_marking'],indent=2,ensure_ascii=False))
 if args.spin4_clifford:print(json.dumps(rep['clifford'],indent=2,ensure_ascii=False))
if args.bihopf_pair is not None:
 import math
 a0,b0,c0,d0=args.bihopf_pair
 if math.gcd(a0,b0)!=1 or math.gcd(c0,d0)!=1:raise SystemExit('Both Hopf slope pairs must be primitive')
 delta=a0*d0-b0*c0
 print('Slope pair',args.bihopf_pair,'character matrix',[[b0,-a0],[d0,-c0]],'det=',delta)
 if delta==0:print('Dependent characters: NOT a finite covering onto the full fibre product')
 else:
  print('P_v -> T^(a,b) x_B T^(c,d) is a regular cyclic cover of degree',abs(delta))
  if abs(delta)==1:print('Unimodular: bundle isomorphism')
  if (a0,b0,c0,d0)==(1,1,1,-1):print('Exchange pair: deck=diagonal C2, fibre product SO(4), P_v=Spin(4)')
 print('Normalization: oriented Hopf circles and fixed common base B=S²xS²; no physical meaning.')
if args.m8_slope is not None:
 import math
 a0,b0,m0,n0=args.m8_slope
 if math.gcd(a0,b0,m0,n0)!=1:raise SystemExit('Cocharacter must be primitive in Z^4')
 d=math.gcd(m0,n0)
 print('d=',d,'pi2=','Z' if d==0 else '0','pi1=','Z^2' if d==0 else 'Z' if d==1 else f'Z + Z/{d}')
 print('model:',('T^(a,b) x T_sc²' if d==0 else 'S³ x S³ x S¹' if d==1 else f'((S³ x S³)/mu_{d}^(a,b)) x S¹'))
if args.exchange_isogeny:
 z=load('bihopf_integral_geometry_instance.json')
 print('Hopf pair:',z['exchange_pair']['hopf_character_matrix'])
 print('Scalar eigenphase:',z['exchange_pair']['scalar_eigenphase_matrix'])
 print('Unimodular output rotation J:',z['exchange_pair']['unimodular_output_rotation'])
 print('A_H=J A_sc; both have diagonal C2 kernel. Combined T4 has deck group C2xC2, degree four.')
 print('ABSTRACT LATTICE COMPARISON ONLY: Hopf and scalar torus bundles are NOT geometrically identified.')
if any([args.finite_600,args.projector_link,args.kneser_hodge,args.hurwitz_f4,args.transporter is not None]):
 d=load('finite_geometry_v116_instance.json')
 if args.finite_600:
  print('Marked quaternionic 2I: 120 vertices, 720 nearest edges; 2I/{±1}=A5 acts on five core labels.')
  print('25 inscribed 24-cell transporters in five five-colorings; 600 tetrahedra split into 25 chamber blocks of 24.')
  print('60 projective vertices support 450 square, 200 hexagon and 72 decagon cosets (722 total).')
  print('Exact chamber complement: T^T U = J-B; face-block adjacency: U^T A_ch U = 6((J5-I5)⊗(J5-I5)).')
 if args.projector_link:
  print('B_120: 120x25 transporter incidence; A_600 B=3(J-B).')
  print('P_(-3)=(B B^T-J_120)/30 = L(M3-M5)L^T/30; P²=P, rank=16, AP=-3P.')
  print('rank_(F101)(A+3I)=104 and P has rank16: complete -3 eigenspace over Q.')
  print('Projective 60-point B has integral Smith factors [1]*17, plus eight zero columns.')
  print('CAVEAT: 120-point vs 60-point incidence require the explicitly stated antipodal lift L.')
 if args.kneser_hodge:
  x=d['petersen_kneser'];print('Two complementary 10-triangle RP2 systems on six Sylow5 axes; dual graphs Petersen.')
  print('Each A5-equivariant pair-to-triangle map:',x['equivariant_petersen_triangle_maps'])
  print('KG(6,2) spectrum:',x['KG6_2_spectrum'])
  print('Signed exterior Hodge relations:',x['hodge_relations'])
 if args.hurwitz_f4:
  x=d['hurwitz_F4'];print('24-cell cellular f-vector:',x['f_vector'])
  print('Unsigned edge/face matrix: rank',x['rank_unsigned_edge_face'],'nullity',x['nullity_unsigned_edge_face'])
  print('F4 = 24 Hurwitz short + 24 dual long roots; Weyl reflection group order',x['W_F4_order'])
 if args.transporter is not None:
  i,j=args.transporter
  if not (0<=i<5 and 0<=j<5):raise SystemExit('Transporter indices must be 0..4')
  k=5*j+i;print('24-cell transporter C_(%d,%d), vertex IDs:'%(i,j),d['transporter_24cells']['sets'][k])
  print('Complement 24-chamber register block IDs:',d['transporter_24cells']['vertex_chamber_absence_partitions'][k])
if any([args.mckay_group,args.mckay_restrict,args.mckay_cross,args.clifford_e8]):
 f=load('mckay_clifford_v118_instance.json')
 if args.mckay_group:
  t=f['mcKay'][args.mckay_group]
  print('McKay',args.mckay_group,'| irreps',t['classes'],'| representation dimensions',t['dimensions'])
  print('A adjacency:',t['A'])
  print('chi_A:',t['adjacency_characteristic_polynomial'])
  print('Sym^n trivial character multiplicity through n60:',t['trivial_SymnV_multiplicities_n0_60'])
 if args.mckay_restrict:
  print('R('+args.mckay_restrict+') -> R(2T) matrix:')
  k='restriction_from_'+args.mckay_restrict+'_to_2T'
  for row in f[k]: print(' ',row)
  print('A_2T B = B A_'+args.mckay_restrict+' verified exactly.')
 if args.mckay_cross:
  print('X=B_O^T B_I, R(2I)->R(2O):')
  for row in f['cross_ADE_map_X_transpose_BO_times_BI']:print(' ',row)
  print('rank',f['cross_ADE_rank'],'squared singular values',f['cross_ADE_squared_singular_value_multiplicities'])
  print('shared ADE eigenvalues',f['cross_ADE_shared_eigenvalues'])
  print('NOT an inclusion 2O subset 2I; common group is fixed embedded 2T.')
 if args.clifford_e8:
  print(json.dumps(f['e8_quaternionic_coefficient_action'],indent=2))
  print('The Galois scalar extension is an algebra map, but the original 8D coefficient lift is not.')
if not any([args.batch21,args.closure_frontier,args.classification,args.batch20,args.hopf_su3,args.two_vertex_gauss,args.path_refinement_example,args.batch19,args.petersen_core_compression,args.su3_finite_invariants,args.batch18,args.hurwitz_hodge,args.hurwitz_q8,args.batch17,args.icosahedral_harmonics,args.pair_gram,args.s3_green,args.batch16_bridges,args.twisted25,args.clifford_tangent,args.m8_exchange_betti,args.petersen_e36,args.finite_operator_bridges,args.geometry_coverage,args.petersen_total,args.milnor_spectral,args.c6_tight_frame,args.spin4_spectrum,args.spin4_twin_angle,args.spin4_clifford,args.search,args.node,args.neighbors,args.path,args.axis,args.joint_inputs,args.hopf_cover,
            args.hopf_direction is not None,args.hopf_axis is not None,args.lens is not None,args.seifert, args.bihopf_pair is not None,args.m8_slope is not None,args.exchange_isogeny, args.finite_600,args.projector_link,args.kneser_hodge,args.hurwitz_f4,args.transporter is not None,args.golden_e8,args.golden_triality_pair,args.golden_e6_fiber is not None,args.mckay_group,args.mckay_restrict,args.mckay_cross,args.clifford_e8,args.q8_triality,args.q8_orbit_pair,args.q8_mckay,args.q8_hopf_e8,args.axis_e8 is not None,args.axis_triples is not None,
            args.a5_coefficient,args.q8_fourier,args.q8_projector,args.e8_projector_bridge,args.polygon_c3,args.petersen_a5_intertwiner,args.petersen_intertwiner_matrix,
            args.holonomy_tower,args.holonomy_core_pair is not None,args.holonomy_triangle is not None,
            args.axis_cubic,args.axis_local_core_triple is not None,args.axis_core_pair is not None]):a.print_help()

if args.golden_e8 or args.golden_triality_pair or args.golden_e6_fiber is not None:
 e8=load('golden_e8_v117_instance.json')
 if args.golden_e8:
  print(json.dumps(e8['exact_invariants'],indent=2))
  print('600-cell fourclass Q:',e8['ordinary_600cell_24_plus_3x32'])
  print('E8 source triple class ledger:',e8['root_triple_class_counts'])
  print('Rank25 is a new incidence invariant; no canonical map to other 25D geometry is claimed.')
 if args.golden_triality_pair:
  pair=list(map(int,args.golden_triality_pair))
  x=next(x for x in e8['triality_cross_sector_pairs'] if x['pair']==pair)
  print('Cross-sector pair',pair,'third:',x['third_sector'],'edges',x['edge_count'],'degree',x['degree_each_side'])
  print('left and right 8x8 factor matrices:')
  print(x['left_8x8_weight_compatibility']);print(x['right_8x8_weight_compatibility'])
  print('rank',x['Kronecker_rank'],'singular multiplicities',x['Kronecker_singular_value_multiplicities'])
 if args.golden_e6_fiber is not None:
  i=args.golden_e6_fiber
  if not 0<=i<6:raise SystemExit('E6 fibre index must be 0..5')
  f=e8['E7_E6_A2_sections']['six_27weight_fibers'][i]
  print('normal',f['A2_normal_pair'],'weights',len(f['weights_projected_int_x3']),'orbits',list(map(len,f['D1_Weyl_orbits'])))
  print('45 cubic-triple class counts:',f['triple_class_counts'])

if args.batch21 or args.closure_frontier or args.classification:
    v=load('v132_release_counts.json');cl=load('v132_remaining_frontier_classification.json')
    if args.batch21:
        print('Batch21 v1_32 S3 strict mathematical network, NOT proof DAG')
        print(json.dumps(v,indent=2))
    if args.closure_frontier:
        print('Reviewed 53/53 former isolates; guarded edges count for navigation, never unconditional proof.')
        print(json.dumps(cl['classification_counts'],indent=2))
        print('Guarded mathematical map certificates awaiting independent proof:',v['still_open_morphism_frontier'])
    if args.classification:
        x=next((r for r in cl['objects'] if r['id']==args.classification),None)
        print(json.dumps(x if x is not None else {'not_in_v131_isolate_inventory':args.classification},indent=2))
