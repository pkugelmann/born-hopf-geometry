#!/usr/bin/env python3
"""Prove every inherited v134 file besides prepended release README and manifest is unmodified."""
from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent
p=json.loads((R/'data/v135_parent_manifest_snapshot.json').read_text())
assert p['version']=='v1_34'
count=0
for f in p['files']:
 if f['path']=='README.md':continue
 path=R/f['path']
 assert path.is_file() and path.stat().st_size==f['bytes'],f['path']
 assert hashlib.sha256(path.read_bytes()).hexdigest()==f['sha256'],f['path']
 count+=1
print('PASS',count,'inherited files from v134 SHA256 identical; README prepended; manifest replaced')
