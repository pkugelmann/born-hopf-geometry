#!/usr/bin/env python3
"""Batch22: source-scoped mathematical replays. No physical-field selection implied.

Standalone exact symbolic and finite-enumeration derivations from mathematical definitions,
not reuse of previous result JSON. Run with --write or --check.
"""
from __future__ import annotations
import argparse, itertools, json, math
from collections import Counter
from fractions import Fraction as Q
from pathlib import Path
import sympy as s
import numpy as np

HERE=Path(__file__).resolve().parent
RESULT=HERE/'data/v133_scoped_math_replays.json'
results={}
def record(edge, assertion, exact_result, conditions, note=''):
    assert edge not in results
    results[edge]={
        'edge_id': 'G32-'+edge, 'status':'INDEPENDENT_CONDITIONAL_MATHEMATICAL_MAP_REPLAY',
        'mathematical_statement_replayed':assertion,
        'certificate': exact_result,
        'still_required':conditions,
        'scope_limitation':note or 'Does not certify upstream selection, physical occurrence, or experimental observables.'}

# 049: Hilbert-Schmidt (ordinary trace; never insert normalized 1/3 trace).
D1=s.diag(s.Rational(2,3),s.Rational(-1,3),s.Rational(-1,3));D2=s.diag(0,1,-1)
a=s.trace(D1**2); b=s.trace((D1+D2)**2)
assert a==s.Rational(2,3) and b==s.Rational(8,3)
record('049','Selected A2 diagonal Hilbert-Schmidt traces',{'Tr(DI^2)':str(a),'Tr((DI+DII)^2)':str(b)},['chosen A2 diagonal chart','ordinary unnormalized trace'],'Not a measured family mass invariant.')

# 050: all finite charge coefficients in a single left-handed generation.
ys={'Q_L':Q(1,6),'L_L':Q(-1,2),'nu_Rc':Q(0),'u_Rc':Q(-2,3),'d_Rc':Q(1,3),'e_Rc':Q(1)}
co={
 'SU3^2Y':Q(1,2)*(2*ys['Q_L']+ys['u_Rc']+ys['d_Rc']),
 'SU2^2Y':Q(1,2)*(3*ys['Q_L']+ys['L_L']),
 'grav^2Y':6*ys['Q_L']+2*ys['L_L']+ys['nu_Rc']+3*ys['u_Rc']+3*ys['d_Rc']+ys['e_Rc'],
 'Y^3':6*ys['Q_L']**3+2*ys['L_L']**3+ys['nu_Rc']**3+3*ys['u_Rc']**3+3*ys['d_Rc']**3+ys['e_Rc']**3,
 'SU3^3_triplet_minus_antitriplet':2-1-1,
 'SU2_Witten_doublets_mod2':(3+1)%2}
assert all(v==0 for v in co.values())
record('050','Full finite family rational anomaly cancellation and four-doublet parity', {k:str(v) for k,v in co.items()}, ['six-sector one-generation finite representation of source','local QFT inference additionally needs J5 and R5SSQFT'], 'Finite charge arithmetic and parity only, not independent QFT anomaly proof.')

# 051: independent signed A5 action on exterior of ten edge carriers.
N=5;pair=list(itertools.combinations(range(N),2));pid={x:i for i,x in enumerate(pair)}
wedges=list(itertools.combinations(range(10),2));wid={x:i for i,x in enumerate(wedges)}
PE=np.zeros((45,45),dtype=np.int64);STAR=np.zeros((45,45),dtype=np.int64)
def rooted_basis(r,a,b):
    ea,eb=pid[tuple(sorted((r,a)))],pid[tuple(sorted((r,b)))]
    sign=(1 if r<a else -1)*(1 if r<b else -1)
    if ea>eb: ea,eb=eb,ea;sign=-sign
    return wid[(ea,eb)],sign
for j,(ix,iy) in enumerate(wedges):
    common=set(pair[ix])&set(pair[iy]);
    if not common: PE[j,j]=1;continue
    r=next(iter(common));a,b=sorted((set(pair[ix])|set(pair[iy]))-{r})
    jj,ss=rooted_basis(r,a,b);assert j==jj
    others=[k for k in range(N) if k!=r];c,d=[k for k in others if k not in (a,b)]
    perm=[others.index(k) for k in (a,b,c,d)]
    parity=sum(perm[u]>perm[v] for u in range(4) for v in range(u+1,4))
    star_sign=(-1)**(r+parity)
    kk,tt=rooted_basis(r,c,d)
    STAR[kk,j]=ss*tt*star_sign
PO=np.eye(45,dtype=np.int64)-PE;P2plus=PO+STAR;P2minus=PO-STAR
assert np.array_equal(STAR@STAR,PO)
assert np.array_equal(P2plus@P2plus,2*P2plus) and np.array_equal(P2minus@P2minus,2*P2minus)
assert np.trace(PE)==15 and np.trace(P2plus)==np.trace(P2minus)==30
assert np.array_equal(P2plus@P2minus,np.zeros((45,45),dtype=np.int64))
chars={}; nperm=0
for g in itertools.permutations(range(N)):
    if sum(g[i]>g[j] for i in range(N) for j in range(i+1,N))%2:continue
    nperm+=1
    M=np.zeros((45,45),dtype=np.int64)
    for j,(i1,i2) in enumerate(wedges):
        x,y=pair[i1];z,w=pair[i2]
        sg=(1 if g[x]<g[y] else -1)*(1 if g[z]<g[w] else -1)
        p1=pid[tuple(sorted((g[x],g[y])))];p2=pid[tuple(sorted((g[z],g[w])))]
        if p1>p2:p1,p2=p2,p1;sg=-sg
        M[wid[(p1,p2)],j]=sg
    assert np.array_equal(M@STAR,STAR@M)
    assert np.array_equal(M@PE,PE@M)
    cyc=[];seen=set()
    for k in range(N):
        if k not in seen:
            t=k;c=0
            while t not in seen:seen.add(t);c+=1;t=g[t]
            cyc.append(c)
    sig='-'.join(map(str,sorted(cyc,reverse=True)))
    tr=(int(np.trace(PE@M)),int(np.trace(P2plus@M)//2),int(np.trace(P2minus@M)//2))
    chars.setdefault(sig,set()).add(tr)
assert nperm==60 and all(len(v)==1 for v in chars.values())
assert {k:next(iter(v)) for k,v in chars.items()} == {'1-1-1-1-1':(15,15,15),'2-2-1':(-1,-1,-1),'3-1-1':(0,0,0),'5':(0,0,0)}
record('051','45=15+15+15 exact orthogonal A5-equivariant disjoint/rooted Hodge sectors',{'group_order':60,'ranks':[15,15,15],'classes':{k:list(next(iter(v))) for k,v in chars.items()},'irreps_each':'3+3prime+4+5','Hodge_commutator_violations':0},['five marked coordinate-core axes and induced oriented exterior action','root-dependent inherited orientation for Hodge stars'], 'Identifies finite representations, not physical two-source interactions.')

# 053: all unitary split stabilizer elements are block diagonal, determinant one.
BL=s.diag(-1,s.Rational(1,3),s.Rational(1,3),s.Rational(1,3));Pell=s.diag(1,0,0,0);Pc=s.eye(4)-Pell
assert BL==Pc/3-Pell and s.trace(BL)==0 and Pc*Pell==s.zeros(4)
# The commutant of P_ell in u(4) is u(1)+u(3), dim 10; imposing trace zero reduces by one.
comm_dims=1**2+3**2
assert comm_dims-1==9
record('053','Connected special-unitary stabilizer S(U1 x U3) of C+ell decomposition',{'dim_centralizer_u4':comm_dims,'dim_special_unitary_stabilizer':9,'BL_eigenvalues':['-1','1/3','1/3','1/3'],'trace_BL':str(s.trace(BL))},['chosen orthogonal Q=ell direct sum C with ranks 1+3','source trimer SU3 action on C is a separate input'], 'Does not generate SU4 parent, off-block gauge bosons, or color-sector physical occurrence.')

# 054 and 058: explicit pseudoreal quaternionic doublet identity plus one real selfadjoint channel.
a,b,c,d=s.symbols('a b c d',real=True)
h1=a+s.I*b;h2=c+s.I*d;HH=s.Matrix([h1,h2]); eps=s.Matrix([[0,1],[-1,0]])
Phi=eps*HH.conjugate();Phi=Phi.row_join(HH); norm=a*a+b*b+c*c+d*d
assert s.simplify(Phi.conjugate().T*Phi-norm*s.eye(2))==s.zeros(2)
assert s.simplify(Phi.det()-norm)==0
S=s.Matrix([[0,0,Phi[0,0],Phi[0,1]], [0,0,Phi[1,0],Phi[1,1]], [s.conjugate(Phi[0,0]),s.conjugate(Phi[1,0]),0,0], [s.conjugate(Phi[0,1]),s.conjugate(Phi[1,1]),0,0]])
assert S==S.conjugate().T and s.simplify(S*S-norm*s.eye(4))==s.zeros(4)
V=[s.diff(S,v) for v in (a,b,c,d)]
X=s.Matrix.hstack(*[s.Matrix([s.re(z) for z in M]+[s.im(z) for z in M]) for M in V])
assert X.rank()==4
# General SU2 pseudoreality: epsilon conjugate(U) = U epsilon for U=[[alpha,beta],[-bar beta,bar alpha]].
x,y,z,t=s.symbols('x y z t',real=True);alpha=x+s.I*y;beta=z+s.I*t;U=s.Matrix([[alpha,beta],[-s.conjugate(beta),s.conjugate(alpha)]])
assert s.simplify(eps*U.conjugate()-U*eps)==s.zeros(2)
record('054','Selected Spin4 (1/2,1/2) coordinate model is a four-real-dimensional SU2 pseudoreal doublet',{'real_channel_rank':4,'Phi_dagger_Phi':'||H||^2 I2','det_Phi':'||H||^2','SU2_pseudoreal_intertwiner':'epsilon conjugate(U) = U epsilon'}, ['retained protected Spin4 half-spin modules','multiplicity-one Clebsch-Gordan channel is a selected representation theorem'], 'Does not select nonzero physical Higgs amplitude, scale, or coupling.')
record('058','Selfadjoint coordinate-type finite Dirac intertwiner and conjugate doublet',{'selfadjoint':True,'D_squared':'||H||^2 I4','real_parameter_dimension':4},['selected finite half-spin input/output blocks','one scalar intertwiner type and trivial family action','Y=1/2 uses separate finite representation action'], 'A mathematical 4D real type, not an occurring Yukawa matrix or Higgs mass.')

# 055: interval spectral algebra: explicitly condition on carrier spectrum; no independent carrier theorem.
alpha,E0=s.symbols('alpha E0',positive=True)
E40=E0*alpha**s.Rational(-5,4);E56=E0*alpha**s.Rational(-7,4);E48=E0*alpha**s.Rational(-3,2)
assert s.simplify(E48**2-E40*E56)==0
assert s.simplify((E40-E56)-E48*(alpha**s.Rational(1,4)-alpha**s.Rational(-1,4)))==0
assert s.simplify(E40/E56-alpha**s.Rational(1,2))==0
record('055','Exact E40-E56 open-gap algebra and E48 geometric mean under declared carrier spectrum',{'E48_squared':'E40 E56','additive_width':'E48(alpha^(1/4)-alpha^(-1/4))','ratio':'alpha^(1/2)'},['alpha>1, E0>0','premise spec(H_car)={E0,E32,E40,E56} with no active P48 not proved by this replay'], 'The zero gap projector follows from SUPPLIED spectrum only; not a physical rest/pole mass.')

# 057: exhaust all possible common central-kernel elements.
sectors={'Q_L':(1,1,1),'u_R':(1,0,4),'d_R':(1,0,-2),'L_L':(0,1,-3),'e_R':(0,0,-6),'nu_R':(0,0,0),'H':(0,1,3)}
ker=[]
for aa in range(3):
    for bb in range(2):
        for nn in range(6):
            if all((2*aa*color+3*bb*weak+nn*y)%6==0 for color,weak,y in sectors.values()):
                ker.append((aa,bb,nn))
assert sorted(ker)==sorted([(n%3,n%2,n) for n in range(6)])
assert math.gcd(*(abs(t[2]) for t in sectors.values() if t[2]))==1
record('057','Exhaustive central kernel of SU3 x SU2 x U1 on source six-sector finite representation',{'kernel_elements':ker,'order':len(ker),'generator':'(omega3,-I2,exp(i*pi/3))','charge_gcd':1},['already constituted six-sector finite representation','integer qY=6Y normalization','internal weak SU2 not identified with geometric Spin4 action'], 'The Z6 quotient is exact for this finite representation only; no spacetime gauge-field construction.')

# 060: kernel of one-dimensional distinguished-line character in source 2D torus plane.
qa,qb=s.symbols('qa qb',real=True)
chi=qa*s.Rational(1,2)-qb
assert s.solve(chi,qb)==[qa/2]
record('060','Infinitesimal distinguished-right-neutral line kernel',{'character':'a/2-b','one_dimensional_kernel':'b=a/2','normalized_generator':'TR3+(B-L)/2'},['weight TR3=+1/2 on WR+','weight (B-L)=-1 on ell','projective/traceless torus plane'], 'Character kernel does not by itself select the complete action-stabilizer U1.')

# 062 and 063: exact left-current incidence and mixed-moment recovery for a concrete nontrivial unitary carrier.
root=s.sqrt(3); w=s.Rational(-1,2)+s.I*root/2
C=s.Matrix([[w**(i*j) for j in range(3)] for i in range(3)])/root
assert s.simplify(C.conjugate().T*C-s.eye(3))==s.zeros(3)
Qu=s.diag(1,2,4);Qd=s.diag(3,5,7)
Du=s.diag(1,s.I,-1);Dd=s.diag(-1,1,s.I)
newC=Du*C*Dd.conjugate().T
assert s.simplify(newC.conjugate().T*newC-s.eye(3))==s.zeros(3)
for pp in range(3):
 for qq in range(3):
  moment=s.trace(Qu**pp*C*Qd**qq*C.conjugate().T)
  transformed=s.trace((Du*Qu*Du.conjugate().T)**pp*newC*(Dd*Qd*Dd.conjugate().T)**qq*newC.conjugate().T)
  assert s.simplify(moment-transformed)==0
V_u=s.Matrix([[k**p for k in [1,2,4]] for p in range(3)])
V_d=s.Matrix([[k**p for k in [3,5,7]] for p in range(3)])
M=s.Matrix([[s.trace(Qu**p*C*Qd**q*C.conjugate().T) for q in range(3)] for p in range(3)])
P=V_u.inv()*M*V_d.inv().T
assert s.simplify(P-s.Matrix(3,3,lambda i,j:s.Rational(1,3)))==s.zeros(3)
Com=Qu*C*Qd*C.conjugate().T-C*Qd*C.conjugate().T*Qu
CP=s.simplify(s.trace(Com**3)/(6*s.I))
assert CP!=0 and s.simplify(s.im(CP))==0
record('062','Current pullback C_ud=W_u dagger W_d is unitary for two surjective isometries into same family space',{'C_dagger_C':'I3','exact_nontrivial_DFT_unitary':True,'role_change_covariance':True},['both source W_u and W_d are FULL-RANK unitary role-to-G_L incidences','left family current J_W=I_G'], 'No current entries or experimentally measured CKM numbers derived.')
record('063','Current-based mixed traces and commutator cube are invariant; Vandermonde recovery at simple masses',{'two_role_conjugation_invariance':True,'M':'V_u P V_d^T','recovered_P':'1/3 all entries in chosen exact Fourier example','CP_odd_nonzero_example':str(CP)},['given selfadjoint terminal weights Q_u,Q_d','given selected unitary current C_ud','pairwise-distinct role weights for Vandermonde inversion'], 'Demonstrates invariant algebra and capacity, not the source-evaluated quark flavor point.')

# 064: Moore-Penrose support polar identities on tagged rank-one examples.
F=[s.Matrix([[3],[4]]),s.Matrix([[6,8]]),s.Matrix([[1,2],[2,4]])]
mu=[5,10,5]
Pin=[];Pout=[];VV=[]
for f,m in zip(F,mu):
    assert f.rank()==1 and s.trace(f.conjugate().T*f)==m*m
    fp=f.pinv();pin=fp*f;pout=f*fp;v=f/m
    assert pin*pin==pin and pout*pout==pout
    assert s.simplify(v.conjugate().T*v-pin)==s.zeros(pin.rows)
    assert s.simplify(v*v.conjugate().T-pout)==s.zeros(pout.rows)
    Pin.append(pin);Pout.append(pout);VV.append(v)
FT=s.diag(*F); Sigma=s.diag(*[m*x for m,x in zip(mu,Pin)]); V=s.diag(*VV)
assert s.simplify(FT-V*Sigma)==s.zeros(FT.rows,FT.cols)
assert FT.rank()==3
record('064','Rank-one Moore-Penrose source/target support and three-role direct-sum polar decomposition',{'rank_tagged_map':3,'singular_magnitudes':mu,'support_dimensions':[3,3],'FT':'V Sigma on active input support'},['three selected nonzero role-tagged rank-one F_r','underlying selected F_r not generated by the abstract invariant lattice alone'], 'No extra terminal mass selector, no untagged physical-state identification.')

# 065: general K-set orbit invariant lattice, with exhaustive generator fixed spaces for regular cyclic n=3,5,24.
orders=[3,5,24]; fixed=[]
for n in orders:
  R=s.zeros(n)
  for j in range(n):R[(j+1)%n,j]=1
  ker=(R-s.eye(n)).nullspace()
  assert len(ker)==1 and ker[0]==s.ones(n,1)
  fixed.append({'n':n,'integer_primitive':'(1,...,1)','singular_value_square':n})
record('065','Any transitive finite K-set fixed integer lattice is Z times orbit sum; transfer singular norm sqrt(size)',{'cyclic_regular_tests':fixed,'abstract_argument':'orbit transitivity forces all fixed integer coefficients equal'},['given transitive finite K-set with counting inner product','regular 2T on 24 Hurwitz vertices is one specialization'], 'A primitive lattice map does not choose a physical terminal normalization.')

# 067: exact local invariant-chart differentiation on the primitive trimer.
I3=s.eye(3);X=s.Matrix([[0,0,1],[1,0,0],[0,1,0]]);C1=X+X.T;C2=-s.I*(X-X.T)
T=[I3,D1,D2,C1,C2];A=10*I3+D1+2*D2+C1+C2;B=12*I3+2*D1-D2+2*C1+3*C2
Ja=[I3,2*A,3*A**2,s.zeros(3),s.zeros(3),s.zeros(3),B,B**2,A*B+B*A,A*B**2+B**2*A]
Jb=[s.zeros(3),s.zeros(3),s.zeros(3),I3,2*B,3*B**2,A,B*A+A*B,A**2,B*A**2+A**2*B]
J=s.Matrix([[s.trace(G*Tj) for Tj in T]+[s.trace(H*Tj) for Tj in T] for G,H in zip(Ja,Jb)])
Jdet=J.det();assert Jdet==-159690424320
Amin=[A[:n,:n].det() for n in range(1,4)]; Bmin=[B[:n,:n].det() for n in range(1,4)]
assert all(v>0 for v in Amin+Bmin)
x=s.symbols('x');discA=s.discriminant(A.charpoly(x).as_expr(),x);discB=s.discriminant(B.charpoly(x).as_expr(),x)
assert discA==3240 and discB==50240
E=[s.eye(3)[:,i]*s.eye(3)[j,:] for i in range(3) for j in range(3)]
comm=s.Matrix.vstack(s.Matrix.hstack(*[s.Matrix(A*e-e*A).reshape(9,1) for e in E]),s.Matrix.hstack(*[s.Matrix(B*e-e*B).reshape(9,1) for e in E]))
assert comm.rank()==8
chitr=s.simplify(s.trace((A*B-B*A)**3)/(6*s.I));assert chitr==378
record('067','Full exact primitive trimer 10x10 local invariants Jacobian and generic CP-positive witness',{'Jacobian_determinant':int(Jdet),'chi_CP':int(chitr),'principal_minors_A':[str(v) for v in Amin],'principal_minors_B':[str(v) for v in Bmin],'discriminants':[int(discA),int(discB)],'commutant_rank':8},['selected five-real-dimensional trimer slice with marked cyclic X','full-rank positive 3x3 Hermitian A,B owner','quotient dimension 10 on generic two-sector flavor branch'], 'Local generic capacity only, not source occurrence or numerical CKM/PMNS prediction.')

# 068: differential of final octet logarithmic complement under source curvature character.
q=s.symbols('q',real=True); Wc=7-q;Dc=q-6
assert s.simplify(Wc+Dc-1)==0 and (Wc.subs(q,6),Dc.subs(q,6))==(1,0) and (Wc.subs(q,7),Dc.subs(q,7))==(0,1)
# With rho/C=alpha^(7-q) for alpha>1, differential dQD=-d(rho)/(rho log alpha).
ratio=alpha**(7-q)
assert s.simplify(s.diff(s.log(ratio),q)/s.log(alpha)+1)==0
record('068','K48/K56 scalar complement, normalized closed top-form conservation and exact 4-form transfer',{'QW':'7-q_sp','QD':'q_sp-6','endpoints':{'K48':[1,0],'K56':[0,1]},'dQD':'-d rho/(rho log alpha)','d(JW+JD)':0},['alpha>1, inherited curvature character rho=U alpha^(-q_sp)','selected normalized closed S3 top-form Omega3','q_sp in [6,7]'], 'Geometric neutral form relation, not a number current or dark-matter abundance.')

# 069: finite-collar DtN plus new *sharp* universal norm bound W(1/e)/L.
L=s.symbols('L',positive=True);y=s.symbols('y',nonnegative=True);mu=s.symbols('mu',nonnegative=True);t=s.symbols('t',real=True)
u=s.cosh(mu*(L-t))/s.cosh(mu*L)
assert s.simplify(s.diff(u,t,2)-mu**2*u)==0
assert s.simplify(u.subs(t,0)-1)==0 and s.simplify(s.diff(u,t).subs(t,L))==0
assert s.simplify(-s.diff(u,t).subs(t,0)-mu*s.tanh(L*mu))==0
xx=s.symbols('xx',positive=True);w0=s.LambertW(s.exp(-1))
# g(x)=x(1-tanh x)=2x/(e^(2x)+1), g'(x) has unique positive root.
xstar=(1+w0)/2
# W(e^-1)e^{W(e^-1)}=e^-1, hence e^{2x*}=e^{1+W(e^-1)}=1/W(e^-1).
assert s.simplify((2*xstar-1)/w0-1)==0
assert s.simplify((2*xstar/(1/w0+1))-w0)==0
num=s.N(w0,18); assert num<s.N(1/s.E,18)
record('069','Exact scalar and self-adjoint positive-operator finite-collar DtN with sharp absolute norm error',{'boundary_function':'sqrt(y) tanh(L sqrt(y))','source_upper_norm_bound':'1/(eL)','sharpened_universal_bound':'LambertW(1/e)/L','sharpened_constant_approx':str(num),'sharp_extremum':'L sqrt(y*)=(1+LambertW(1/e))/2','relative_error_sup_each_finite_L':1},['L>0 Neumann end and Dirichlet boundary','A nonnegative selfadjoint tangential operator (functional calculus)','physical collar/refinement occurrence not inferred'], 'Optimal over all nonnegative spectra, but a specified discrete S3 spectrum may have strictly smaller norm.')

# 071: Fischer spinor polynomial shell and Pauli angular-j decomposition.
R=7;omega=Q(1);kappa=Q(1,20)  # <1/(2R-1)=1/13
assert Q(0)<kappa<omega/Q(2*R-1)
energies=[];ranks={}
for n in range(R+1):
 for ell in range(n,-1,-2):
  # j=ell+1/2: multiplicity 2ell+2 and CD=n-ell
  energies.append({'n':n,'ell':ell,'branch':'+','CD':n-ell,'mult':2*ell+2,'E':n*omega+kappa*(n-ell)})
  if ell>=1:
   energies.append({'n':n,'ell':ell,'branch':'-','CD':n+ell+1,'mult':2*ell,'E':n*omega+kappa*(n+ell+1)})
 assert sum(z['mult'] for z in energies if z['n']==n)==(n+1)*(n+2) # spinor dim of homogeneous deg n polys in 3 variables
for r in range(R+1):
 if r<=2:
  maxprev=max(z['E'] for z in energies if z['n']<=r)
  threshold=(maxprev+(r+1)*omega)/2
 else:threshold=r*omega+kappa
 k=sum(z['mult'] for z in energies if z['E']<threshold)
 ranks[r]=k
 assert all(z['E']<threshold for z in energies if z['n']<r)
 if r>=3:
  assert min(z['E'] for z in energies if z['n']==r and z['CD']>0)==r*omega+2*kappa
  assert all(z['E']>=r*omega+2*kappa for z in energies if z['n']>r)
assert list(ranks.values())==[2,8,20,28,50,82,126,184]
record('071','Single finite Fischer-spinor comparison Hamiltonian spectrum with cumulative rank and 2-kappa gap',{'R':R,'test_omega':'1','test_kappa':str(kappa),'cumulative_ranks':list(ranks.values()),'symbolic_eigenvalue_branches':['n omega + kappa(n-ell)','n omega + kappa(n+ell+1)'],'gap_above_r_ge3':'2 kappa'},['mathematical rotation identification of spinor Fischer polynomial carrier','R>=3 and 0<kappa<omega/(2R-1)','Pauli j=l±1/2 decomposition'], 'Only an auxiliary comparison Hamiltonian; no native baryon/meson mass prediction.')

payload={'release':'v1_33','parent':'v1_32','scope':'exact conditional mathematics only, with source-domain guards; no physical theorem promotion','replayed_relation_count':len(results),'checks':results,'note':'The v1_32 graph JSON and its historical qualifiers remain immutable. Apply this certificate overlay for effective status. Source owners and physical occurrence are not discharged.'}
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--write',action='store_true');parser.add_argument('--check',action='store_true');opt=parser.parse_args()
 b=(json.dumps(payload,indent=2,ensure_ascii=False,sort_keys=True)+'\n').encode()
 if opt.write:RESULT.write_bytes(b);print('WROTE',RESULT)
 if opt.check:assert RESULT.read_bytes()==b,'math replay output differs from committed certificate'
 print('PASS Batch22',len(results),'independent source-scoped mathematical replays:',', '.join(sorted(results)))
