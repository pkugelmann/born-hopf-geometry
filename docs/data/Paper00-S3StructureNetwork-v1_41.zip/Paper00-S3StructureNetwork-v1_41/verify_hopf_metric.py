#!/usr/bin/env python3
"""Symbolic checks for primary Hopf, Berger metric, cyclic lens and Seifert indices.

The source first supplies the marked Hopf/metric/spectrum model; this script
checks the newly composed geometric consequences and finite-band filters.
"""
import json,pathlib
from fractions import Fraction
import sympy as s
ROOT=pathlib.Path(__file__).resolve().parent
M=json.loads((ROOT/'data/hopf_metric_quotient_family.json').read_text())
theta,epsilon,R=s.symbols('theta epsilon R',positive=True,real=True)
# Metric determinant in (theta,phi,psi), preserving the primary Berger branch.
g=(R**2/s.Integer(4))*s.Matrix([[1,0,0],
 [0,s.sin(theta)**2+epsilon**2*s.cos(theta)**2,epsilon**2*s.cos(theta)],
 [0,epsilon**2*s.cos(theta),epsilon**2]])
assert s.simplify(g.det()-R**6*epsilon**2*s.sin(theta)**2/64)==0
vol=s.integrate(R**3*epsilon*s.sin(theta)/8,(theta,0,s.pi))*2*s.pi*4*s.pi
assert s.simplify(vol-2*s.pi**2*R**3*epsilon)==0
curv=s.integrate(-s.sin(theta)/2,(theta,0,s.pi))*2*s.pi
assert s.simplify(curv+2*s.pi)==0 # coordinate orientation; reversed base gives +2pi
for n in range(1,12):
 assert s.simplify(n*curv/(2*s.pi)+n)==0
 assert s.simplify(vol/n-2*s.pi**2*R**3*epsilon/n)==0
 # For fixed R, epsilon the base S2 metric is unchanged by the fibre quotient.
 # The quotient volume divides by n and the fibre length is 2pi R epsilon/n.
 assert s.simplify((vol/n)/(2*s.pi*R*epsilon/n)-s.pi*R**2)==0
# Fixed Berger eigenvalue formula; diagonal Peter–Weyl weight parity is crucial.
lam=lambda k,q,eps:Fraction(k*(k+2),1)+((Fraction(1,1)/(eps*eps))-1)*q*q
for n in range(1,15):
 for eps in [Fraction(1),Fraction(1,2),Fraction(2,3),Fraction(1,5)]:
  bands=[]
  for k in range(0,45):
   for q in range(-k,k+1,2):
    if q % n==0:
     bands.append((lam(k,q,eps),k,q,k+1))
  low=min(z[0] for z in bands if z[0]>0)
  if n>=2:assert low==8,(n,eps,low)
  if n==1:assert low==min(Fraction(8),Fraction(2)+Fraction(1)/(eps*eps)),(n,eps,low)
  if eps<1 and n>=2:
   assert sum(z[3] for z in bands if z[0]==8)==3
  if eps==1 and n==2:
   assert sum(z[3] for z in bands if z[0]==8)==9
  if eps==1 and n>=3:
   assert sum(z[3] for z in bands if z[0]==8)==3
for ell in range(0,30):
 k=2*ell
 assert lam(k,0,Fraction(2,3))==Fraction(4*ell*(ell+1))
 assert lam(k,0,Fraction(1,7))==Fraction(4*ell*(ell+1))
# Finite subgroups: Euler characteristic base orbifold S2/A4,S4,A5.
for item in M['left_exceptional_right_Hopf']:
 p,q,r=item['orbifold_signature'];order=item['order']//2
 chi=Fraction(1,p)+Fraction(1,q)+Fraction(1,r)-1
 assert chi==Fraction(2,order)==Fraction(item['orbifold_euler'])
for item in M['nested_exceptional_covering_squares']:
 assert item['degree'] in (2,5)
 assert item['regular']==(item['degree']==2)
print('VALID: Berger metric determinant, 2pi² R³ epsilon volume, Hopf Chern +1 oriented normalization')
print('VALID: cyclic lens c1=n and volume/fibre /n; q divisible n; q=0 base bands')
print('VALID: lambda1=8/R² for n>=2, epsilon<=1 (exact rational tests n=2..14); multiplicity endpoint checks')
print('VALID: tetra/octa/icosa orbifold Euler characteristics and covering degrees')
