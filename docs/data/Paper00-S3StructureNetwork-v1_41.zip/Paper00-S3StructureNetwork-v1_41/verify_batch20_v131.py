#!/usr/bin/env python3
"""Regenerate all exact v1_31 group-theoretic matrices and check strict geometry scope."""
from pathlib import Path
import json,hashlib,xml.etree.ElementTree as ET
from scripts.hopf_su3_geometry_v131 import build
ROOT=Path(__file__).resolve().parent
load=lambda n:json.loads((ROOT/'data'/n).read_text())
inst=load('hopf_su3_v131_instance.json')
assert build()==inst,'saved matrices fail exact regeneration'
assert inst['su2_su3_embedding']['normalized_integral']==1
assert inst['SU3_tensor']['casimir_spectrum']=={'0':1,'3':8}
assert inst['SU3_tensor']['centralizer_rank_over_Q']==79
assert inst['SU3_tensor']['centralizer_dimension']==2
assert inst['SU3_tensor']['generated_star_algebra_dimension']==65
assert inst['two_vertex_example']['casimir_eigenvalue_multiplicity']=={'0':1,'3':16,'6':64}
assert inst['SU3_tensor']['identity_singlet_projector_9x9']==load('finite_invariant_geometry_v130_instance.json')['su3']['matrix_meson_singlet_projector_9x9']
O=load('objects.json');E=load('mathematical_relations.json');H=load('joint_input_relations.json');C=load('derived_compositions.json')
assert len([o for o in O if o.get('batch')=='v1_31'])==17
assert len([e for e in E if e['id'].startswith('G31-')])==41
assert len([h for h in H if h['id'].startswith('HYP-G31-')])==10
assert len([d for d in C if d['id'].startswith('D31-')])==9
assert len([o for o in O if o.get('batch')!='v1_32'])==849
assert len([e for e in E if not e['id'].startswith('G32-')])==1320
assert len([h for h in H if not h['id'].startswith('HYP-G32-')])==185
assert len([d for d in C if not d['id'].startswith('D32-')])==171
assert all(e['conditions_preserved'] for e in E)
assert all('physical' not in e['link_type'].lower() for e in E)
W=load('batch20_current_tex_witnesses.json')['source_witnesses']
assert len(W)==11
assert all(len(w['tex_sha256'])==64 and w['line']>0 and w['located_in_current_tex'] for w in W.values())
assert load('v131_release_counts.json')['isolated_objects']==53
ns={'g':'http://graphml.graphdrawing.org/xmlns'}
g=ET.parse(ROOT/'graph/batch20_hopf_su3_group_invariants.graphml').getroot()
assert len(g.findall('.//g:edge',ns))==41
assert {e.get('id') for e in g.findall('.//g:edge',ns)}=={e['id'] for e in E if e['id'].startswith('G31-')}
assert all(o['id'].startswith('geo:') for o in O)
print('PASS: v1_31 exact S3/SU3 Cartan form, 1+8 Casimir, Haar/Gauss, centralizer, paths and determinant contraction')
print('PASS: 17 new mathematical objects, 41 typed relations, 10 joint conditions, 9 derivations; 11 current-source provenance labels')
