#!/usr/bin/env python3
"""Exact Batch24 release integrity, dual-axis proof status, original graph preservation."""
from pathlib import Path
import subprocess,sys,json,xml.etree.ElementTree as ET
R=Path(__file__).resolve().parent
read=lambda n:json.loads((R/n).read_text())
F=read('data/v135_verified_frontier_status.json');P=read('data/v134_verified_frontier_status.json')
C=read('data/v135_scoped_math_replays.json');B=read('data/v135_source_owner_frontier.json')
O=read('data/objects.json');E=read('data/mathematical_relations.json');H=read('data/joint_input_relations.json');D=read('data/derived_compositions.json')
assert (len(O),len(E),len(H),len(D))==(862,1392,242,183)
assert P['replay_count']==21 and set(P['pending_ids'])=={'G32-052','G32-056','G32-072'}
assert F['replay_count']==F['original_frontier_count']==24 and F['pending_count']==0
assert set(F['verified_ids'])==set(F['relations'])
assert set(F['newly_verified_ids'])==set(C['new_conditional_replayed_ids'])==set(B['boundaries'])==set(F['source_boundary_pending_ids'])=={'G32-052','G32-056','G32-072'}
assert F['source_boundary_pending_count']==3 and F['whole_source_theorems_or_physical_premises_promoted']==F['physical_action_occurrence_promoted']==0
assert C['source_theorems_promoted']==C['physical_actions_promoted']==0
assert F['graph_topology_changed'] is False
edgemap={e['id']:e for e in E};guards={h['id']:h for h in H}
for id,record in F['relations'].items():
    assert record['from']==edgemap[id]['from'] and record['to']==edgemap[id]['to']
    assert record['joint_relation_id'] in guards
    assert record['guarded_conditions']==guards[record['joint_relation_id']]['conditions']
    assert record['physical_owner_or_source_theorem_independently_dischargeable'] is False
    assert record['effective_mathematical_map_status']=='INDEPENDENT_CONDITIONAL_MATHEMATICAL_MAP_REPLAY'
    assert record['certificate_ref']
    if id in C['new_conditional_replayed_ids']:
        assert record['certificate_ref']=='data/v135_scoped_math_replays.json#checks/'+id[4:]
        assert record['source_boundary_still_open'] is True
    else:assert record==P['relations'][id]
ns={'g':'http://graphml.graphdrawing.org/xmlns'}
def graph(path):
    t=ET.parse(R/path).getroot()
    ks={x.attrib['id']:x.attrib['attr.name'] for x in t.findall('g:key',ns)}
    n={x.attrib['id'] for x in t.findall('.//g:node',ns)}
    e={x.attrib['id']:(x.attrib['source'],x.attrib['target'],{ks[d.attrib['key']]:d.text for d in x.findall('g:data',ns)}) for x in t.findall('.//g:edge',ns)}
    return n,e
on,ee=graph('graph/mathematical_structure_network_effective_v135.graphml')
assert on=={o['id'] for o in O} and set(ee)==set(edgemap)
for id,(a,b,payload) in ee.items():
    assert (a,b)==(edgemap[id]['from'],edgemap[id]['to'])
    assert payload['source_verification_v132']==edgemap[id]['verification']
    if id in F['relations']:
        assert payload['conditional_math_status']=='INDEPENDENT_CONDITIONAL_MATHEMATICAL_MAP_REPLAY'
        assert payload['physical_owner_status']=='SOURCE_OR_PHYSICAL_OWNER_NOT_INDEPENDENTLY_DISCHARGED'
    if id in F['source_boundary_pending_ids']:
        assert payload['targeted_frontier']=='TARGETED_SOURCE_SELECTION_OPEN'
subset,subedge=graph('graph/batch24_scoped_math_and_owner_frontier.graphml')
assert set(subedge)==set(C['new_conditional_replayed_ids'])
assert subset==set(i for t in subedge.values() for i in (t[0],t[1]))
anchor=read('data/v135_source_anchor_ledger.json');assert len(anchor['anchors'])==12
for id in B['boundaries']:
    assert any(a['relation_id']==id for a in anchor['anchors'])
for cmd in (
 [sys.executable,'verify_scoped_math_v135.py','--check'],
 [sys.executable,'build_overlay_v135.py','--check'],
 [sys.executable,'rebuild_effective_graph_v135.py','--check'],
 [sys.executable,'verify_parent_v134_integrity_v135.py'],
 [sys.executable,'verify_batch23_v134.py']):
  p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,check=True)
  print(p.stdout.rstrip().splitlines()[-1])
print('PASS Batch24: 24/24 source-guarded exact mathematical maps; targeted owner boundaries 3 open; no physical promotion; original graph 862/1392/242/183 unchanged.')
