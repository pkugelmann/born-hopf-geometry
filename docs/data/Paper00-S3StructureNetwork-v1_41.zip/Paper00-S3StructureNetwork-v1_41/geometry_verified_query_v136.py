#!/usr/bin/env python3
"""Compact terminal queries of v1_36 source-scoped mathematical/owner graph."""
from pathlib import Path
import json, argparse
R=Path(__file__).resolve().parent
A=json.loads((R/'data/v136_math_extension.json').read_text())
F=json.loads((R/'data/v136_frontier_resolution.json').read_text())
P=json.loads((R/'data/v136_exact_harmonic_gp3_certificate.json').read_text())
p=argparse.ArgumentParser();p.add_argument('--summary',action='store_true');p.add_argument('--boundary',action='store_true');p.add_argument('--new',action='store_true');p.add_argument('--edge');a=p.parse_args()
if a.summary or not (a.summary or a.boundary or a.new or a.edge):
 print('S3 v1_36: 879 effective mathematical objects / 1424 relations / 250 guards / 189 compositions')
 print('Exact 169→6 harmonic boundary, 163+5+1, pre-Schur mixed Green 5/168, post-Schur 163/168')
 print('24/24 inherited conditional maps replayed; all 3 targeted physical owner/source selections still not discharged (historical D4 branch reclassified)')
if a.boundary:
 for item in F['three_selection_frontiers']:print(item['legacy'],item['status'],item['needed'])
if a.new:
 for x in A['objects']:print(x['id'],x['name'])
if a.edge:
 out=[x for x in A['relations'] if x['id']==a.edge]
 if a.edge=='G32-056':print(F['historical_branch']);out=[]
 for item in out:print(json.dumps(item,indent=2,ensure_ascii=False))
 if not out and a.edge!='G32-056':print('No new v1_36 edge of that id (use v135 tool for inherited relations)')
