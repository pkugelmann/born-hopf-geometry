#!/usr/bin/env python3
"""Exact replay of all new Q8-triality orbit and affine-D4 McKay calculations."""
from pathlib import Path
import json
import sympy as sp
from scripts.q8_triality_v119 import build

HERE=Path(__file__).resolve().parent
file=HERE/'data/q8_triality_v119_instance.json'
recomputed=build()
stored=json.loads(file.read_text())
# The build path regenerates all 64×64 incidence entries from golden root
# coordinates, all 8×8 orbit matrices via explicit quaternion action, all
# Q8 characters, spectral projectors, and all representation restrictions.
assert recomputed==stored,'Saved mathematics differs from regenerated exact model.'
assert len(stored['Q8_root_orbit_partitions'])==3
assert [len(o) for o in stored['Q8_root_orbit_partitions']]==[8]*3
assert all(len(c)==8 for blocks in stored['Q8_root_orbit_partitions'] for c in blocks)
assert len(stored['Q8_orbit_cross_sector_pairs'])==3
for q in stored['Q8_orbit_cross_sector_pairs']:
 N=sp.Matrix(q['orbit_incidence_8x8'])
 assert N.rank()==5 and q['rank25_Q8_fixed_subspace_dimension']==5
 assert q['nonzero_orbit_edge_count']==56
 assert q['rank25_Q8_real_irrep_multiplicities']=={'trivial_1':5,'nontrivial_1_x':4,'nontrivial_1_y':4,'nontrivial_1_z':4,'quaternionic_4':2}
 assert sp.factor((N*N.T).charpoly().as_expr())==sp.Symbol('lambda')**3*(sp.Symbol('lambda')-256)*(sp.Symbol('lambda')-16)**4
 assert q['match_involution_column_map'] != list(range(8))
assert stored['hypergraph_invariants']['distinct_orbit_triples']==104
assert stored['hypergraph_invariants']['total_Q8_triple_orbits_with_multiplicities']==128
Q=stored['Q8_McKay_affineD4'];X=sp.Matrix(Q['Y_cross_via_Q8']);B=sp.Matrix(Q['B_2T_to_Q8'])
assert X.rank()==3 and B.rank()==3
assert Q['Y_common_ADE_eigenmodes']=={'-2':1,'0':1,'2':1}
assert Q['image_Y_subset_image_X'] is True
print('PASS: exact 2T/Q8 and 3×64 roots -> 3×8 free-orbit quotients; ranks 5/5/5; 25D character decompositions')
print('PASS: weighted 24-node multigraph, 128 triple orbits / 104 patterns, affine D4 integer McKay restriction and rank-3 cross-ADE Y')
print('PASS: rank-five triality and McKay subspaces are NOT identified by dimension alone')
