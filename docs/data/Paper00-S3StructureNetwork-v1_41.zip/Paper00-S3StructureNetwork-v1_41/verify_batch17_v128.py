#!/usr/bin/env python3
"""Exact regeneration and scope guard for geometry-only Batch 17."""
import json,pathlib,xml.etree.ElementTree as ET
from scripts.icosahedral_harmonics_v128 import build as harm
from scripts.petersen_pair_coefficients_v128 import build as pair
from scripts.scalar_spectral_compositions_v128 import build as scalar
ROOT=pathlib.Path(__file__).resolve().parent
load=lambda f:json.loads((ROOT/'data'/f).read_text())
assert harm()==load('icosahedral_harmonics_v128_instance.json')
assert pair()==load('petersen_pair_coefficients_v128_instance.json')
assert scalar()==load('scalar_spectral_compositions_v128_instance.json')
O=load('objects.json');E=load('mathematical_relations.json');H=load('joint_input_relations.json');C=load('derived_compositions.json')
counts=load('v128_release_counts.json')
assert [sum(x.get('batch') not in ('v1_29','v1_30','v1_31','v1_32') for x in a) for a in (O,E,H,C)]==[799,1185,158,144]
assert counts['new_objects']==14 and counts['new_typed_relations']==51
assert counts['new_joint_inputs']==10 and counts['new_compositions']==9
assert not any(':thm:' in o['id'] or ':cor:' in o['id'] for o in O)
assert all(e['conditions_preserved'] is True for e in E if e.get('batch')=='v1_28')
assert not any('PHYSICAL_DECAY' in e['relation'] or 'PROOF_DEPENDENCY' in e['relation'] for e in E)
namespace={'x':'http://graphml.graphdrawing.org/xmlns'}
root=ET.parse(ROOT/'graph/batch17_icosahedral_hopf_pair_coefficients.graphml').getroot()
assert len(root.findall('.//x:edge',namespace))==51
root2=ET.parse(ROOT/'graph/mathematical_structure_network.graphml').getroot()
assert len(root2.findall('.//x:node',namespace))==len(O)
assert len(root2.findall('.//x:edge',namespace))==len(E)
W=load('batch17_current_tex_witnesses.json')['source_witnesses']
assert len(W)>=15 and all(len(v['tex_sha256'])==64 and v['line']>0 for v in W.values())
cc=json.loads((ROOT/'reports/geometry_completeness_v128.json').read_text())
assert cc['counts']['isolated_objects']==88
assert cc['counts']['previous_isolates_now_mathematically_linked']==11
assert cc['counts']['nontrivial_disconnected_components']==0
print('PASS: independently regenerated exact Q(sqrt5) icosahedral harmonics, Hopf degree-12 map, pair/25-cell operators, and scalar spectral compositions')
print('PASS: v1_28 historical 799 objects/1185 links remain intact within cumulative extension; recorded old 88-isolate ledger unchanged')
