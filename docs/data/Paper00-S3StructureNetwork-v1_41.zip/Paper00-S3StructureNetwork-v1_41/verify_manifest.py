#!/usr/bin/env python3
"""Check that all release files match the SHA-256 manifest."""
import json,pathlib,hashlib
root=pathlib.Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text())
for rec in manifest['files']:
 p=root/rec['path']
 assert p.is_file(),('missing file',rec['path'])
 assert p.stat().st_size==rec['bytes'],('size mismatch',rec['path'])
 assert hashlib.sha256(p.read_bytes()).hexdigest()==rec['sha256'],('hash mismatch',rec['path'])
print('MANIFEST VALID',len(manifest['files']),'files; no previous ZIP or proof-DAG bundles')
