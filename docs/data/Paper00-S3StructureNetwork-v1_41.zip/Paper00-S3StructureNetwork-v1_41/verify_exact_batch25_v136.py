#!/usr/bin/env python3
"""Independent exact checks for 6-point harmonic geometry and GP3 finite owner diagnostics.

Does not generate a physical K56 action, a GP3 comparison, or a meson pole.
"""
from pathlib import Path
from itertools import product,permutations
from math import factorial
import argparse,hashlib,json
import sympy as s
R=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--write',action='store_true');p.add_argument('--check',action='store_true');p.add_argument('--source-dir');args=p.parse_args()

# 6 nonaxial sign-cube points, q_eps=(1+eps*i+...)/2.
sg=[e for e in product((-1,1),repeat=3) if abs(sum(e))==1]
assert len(sg)==6
qdot=lambda e,f:s.Rational(1+sum(e[i]*f[i] for i in range(3)),4)
U=lambda x:s.chebyshevu(12,x)
assert all(U(v)==1 for v in (s.Rational(-1,2),s.S.Zero,s.Rational(1,2)))
assert U(1)==13
G=s.Matrix([[13*U(qdot(e,f)) for f in sg] for e in sg])
J=s.ones(6); I=s.eye(6);P0=J/6; Pa=I-P0
assert G==156*I+13*J==234*P0+156*Pa
assert G.det()==234*156**5
assert G.inv()==P0/s.Integer(234)+Pa/s.Integer(156)
assert G*G.inv()==I
assert s.trace(P0)==1 and s.trace(Pa)==5 and P0*Pa==s.zeros(6)
# six coordinate permutations with parity sign act projectively, regular on six points.
perms=list(permutations(range(3)))
def parity(p):return (-1)**sum(p[i]>p[j] for i in range(3) for j in range(i+1,3))
perms_table={}
for pp in perms:
 pi=parity(pp)
 oe=lambda e:tuple(pi*e[pp.index(i)] for i in range(3))
 mapped=[oe(e) for e in sg]
 assert sorted(mapped)==sorted(sg)
 perms_table[str(pp)]=[sg.index(f) for f in mapped]
assert len({perms_table[p][0] for p in perms_table})==6
# Each nonidentity element has no fixed point in the regular action.
for pp in perms:
 if pp!=tuple(range(3)):
  m=perms_table[str(pp)]
  assert all(m[i]!=i for i in range(6))

# Full scalar degree 12 harmonic character, H12=V6⊗V6*: (169,1,1)
# (spin-6 =13-dimensional; at conjugation rotations pi,2pi/3 its characters are +1,+1).
assert s.simplify(s.sin(13*s.pi/2)/s.sin(s.pi/2))==1
assert s.simplify(s.sin(13*s.pi/3)/s.sin(s.pi/3))==1
full=(169,1,1);vvisible=(6,0,0);kernel=tuple(full[i]-vvisible[i] for i in range(3));assert kernel==(163,1,1)
chars=((1,1,1),(1,-1,1),(2,0,-1)); sizes=(1,3,2)
def decompose(ch):return [sum(sizes[i]*ch[i]*rr[i] for i in range(3))//6 for rr in chars]
assert decompose(full)==[29,28,56]
assert decompose(kernel)==[28,27,54]
aug=(5,-1,-1);assert decompose(aug)==[0,1,2]
assert sum(a*b for a,b in zip(decompose(kernel),decompose(aug)))==135

# Orthogonal decomposition: ran(E†) = 6, Psing=1, Paug=5, Q=169-6=163.
rank={'total':169,'kernel':163,'augmentation':5,'singlet':1,'nonsinglet':168}
assert rank['kernel']+rank['augmentation']+rank['singlet']==rank['total']
# Round kinetic K12=R^2 Δ=12(12+2)I=168I.
assert 12*(12+2)==168
Pns_rank=168;Paug_rank=5
Green=s.Matrix([[s.Rational(Pns_rank,168),s.Rational(Paug_rank,168)],
                [s.Rational(Paug_rank,168),s.Rational(Paug_rank,168)]])
assert Green==s.Matrix([[1,s.Rational(5,168)],[s.Rational(5,168),s.Rational(5,168)]])
assert Green.det()==s.Rational(5*163,168**2)
Schur=s.factor(Green[0,0]-Green[0,1]*Green[1,1]**-1*Green[1,0]);assert Schur==s.Rational(163,168)
assert s.Rational(5,168)>0  # pre-elimination mixed contraction (not off-diagonal mass Hessian)
# Rank-port singular magnitudes for iota_E:z -> zI_E with ordinary unnormalized HS.
assert s.sqrt(163)*1/s.sqrt(163)==1 and s.sqrt(5)**2==5

# Normalized zonal harmonic U12(Re q): mean 0 and norm 1 under round probability Haar.
x=s.symbols('x');pol=s.Poly(s.chebyshevu(12,x),x)
def haar_monomial(n):
 if n%2:return 0
 k=n//2
 return s.Rational(factorial(2*k),4**k*factorial(k)*factorial(k+1))
mean=sum(c*haar_monomial(m[0]) for m,c in pol.terms())
sq=s.Poly(pol.as_expr()**2,x)
norm=sum(c*haar_monomial(m[0]) for m,c in sq.terms())
assert mean==0 and norm==1 and U(s.Rational(1,2))==1
sing=s.Rational(6,234);augweight=s.S.Zero;kerweight=norm-sing
comm=s.factor(2*kerweight*(1-kerweight))
assert (sing,augweight,kerweight,comm)==(s.Rational(1,39),0,s.Rational(38,39),s.Rational(76,1521))

# Source-specified factor-local finite matter algebra: M12⊕M36, arbitrary faithful amplifications.
assert 12*12+36*36==1440 and 12+36==48
# Exact diagnostic profile: D_l=0 on C12, D_C=I on C36; t=ln2 so exp(-tD²) gives 1 and 1/2.
# This profile is an *illustrative mathematical test*, not an occurring action.
for k_l,k_c in product(range(1,6),repeat=2):
 y=12*k_l+18*k_c
 assert y>=30 and (y==30)==(k_l==k_c==1)
 # Sector-conditioned normalized traces remain invariant under each amplification.
 assert s.Rational(12*k_l,12*k_l)==1 and s.Rational(18*k_c,36*k_c)==s.Rational(1,2)

# Cross-object referential integrity for extension
X=json.loads((R/'data/v136_math_extension.json').read_text())
bo=json.loads((R/'data/objects.json').read_text());be=json.loads((R/'data/mathematical_relations.json').read_text())
valid={o['id'] for o in bo+X['objects']}
assert len(bo)==862 and len(be)==1392 and len(X['objects'])==17 and len(X['relations'])==32
assert len(valid)==879
assert all(e['from'] in valid and e['to'] in valid and e['conditions_preserved'] for e in X['relations'])
assert set(e['guard_id'] for e in X['relations'])==set(h['id'] for h in X['joint_conditions'])
assert all(set(h['inputs']+h['outputs'])<=valid for h in X['joint_conditions'])
assert all(set(c['inputs']+c['outputs'])<=valid for c in X['compositions'])
# Current source anchoring (proof-independent locator+hash check)
anchors=json.loads((R/'data/v136_current_source_anchors.json').read_text())
assert len(anchors['anchors'])==17
if args.source_dir:
 sd=Path(args.source_dir)
 for a in anchors['anchors']:
  text=(sd/a['file']).read_text()
  assert hashlib.sha256((sd/a['file']).read_bytes()).hexdigest()==a['sha256']
  assert '\\label{'+a['label']+'}' in text
  assert text.count('\n',0,text.index('\\label{'+a['label']+'}'))+1==a['one_indexed_line']

cert={
 'version':'v1_36','exact_arithmetic':'Sympy rationals and integers; all identities independently reconstructed from source-defined domains',
 'boundaries':{'neutral_current_branch':'harmonic rank proposal; action, port consumption and physical mass not selected',
   'legacy_D4':'historical only relative to harmonic branch; algebraic response remains true',
   'gp3':'same-owner unnormalized heat trace obstructs multiplicity-blind full-candidate equivalence IF frozen; occurrence/whole-candidate comparison open',
   'meson':'owner-selected relative H_L and reducing JPC/flavor projector still open'},
 'harmonic':{'n':12,'dimension':169,'laplacian_eigenvalue_times_R2':168,
  'six_sign_vectors':[list(v) for v in sg],
  'reproducing_kernel_K12_six_gram':[[int(G[i,j]) for j in range(6)] for i in range(6)],
  'gram_diagonal':169,'gram_offdiagonal':13,'gram_spectrum':{'234':1,'156':5},
  'gram_determinant':int(G.det()),'rank_packet':rank,
  'S3_class_chars_full':[169,1,1],'S3_class_chars_kernel':[163,1,1],
  'S3_irrep_multiplicities_full':decompose(full),'S3_irrep_multiplicities_kernel':decompose(kernel),
  'S3_irrep_multiplicities_augmentation':decompose(aug),
  'S3_Hom_kernel_to_aug_dimension':135,
  'green_2x2':[[str(Green[i,j]) for j in range(2)] for i in range(2)],
  'green_schur_residual':str(Schur),
  'zonal_U12_source_weights':{'singlet':str(sing),'augmentation':str(augweight),'kernel':str(kerweight),'projector_commutator_HS_norm_squared':str(comm)},
  'conditional_rank_magnitudes':['1/sqrt(163)','sqrt(5)','sqrt(163)'],
  'six_point_action_regular':True},
 'matter':{'algebra':'M12(C) direct_sum M36(C)','complex_dimension':1440,'minimum_faithful_carrier_dim':48,
   'faithful_representation_dims':'12*k_l+36*k_C, k_l,k_C positive integers',
   'common_heat_unnormalized':'k_l*h_12(t)+k_C*h_36(t)',
   'trace_excess':'(k_l-1)*h_12(t)+(k_C-1)*h_36(t)>0 for t>0 if any k>1, given same D_c and common profile',
   'illustrative_not_occurring_profile':'t=ln2, D_l=0 I12, D_C=I36; h_12=12, h_36=18',
   'illustrative_values':{'k1_1':30,'k2_1':42,'k1_2':48},
   'physical_owner_occurrence_claim':False},
 'source_claims_physically_promoted':0}
out=R/'data/v136_exact_harmonic_gp3_certificate.json';contents=json.dumps(cert,indent=2,sort_keys=True,ensure_ascii=False)+'\n'
if args.write:out.write_text(contents)
if args.check:assert out.read_text()==contents
print('PASS exact batch25: K12 Gram det',G.det(),'163+5+1, S3 Hom=135, green Schur=163/168, zonal 1/39, GP3 trace obstruction conditional; 17 new nodes, 32 new edges')
