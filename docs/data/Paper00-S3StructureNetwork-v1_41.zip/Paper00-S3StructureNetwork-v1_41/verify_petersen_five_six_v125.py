#!/usr/bin/env python3
"""Independent regeneration of exact Petersen quintet/sextet maps from inherited integer instances."""
from pathlib import Path
import json
from scripts.petersen_five_six_v125 import build
R=Path(__file__).resolve().parent
saved=json.loads((R/'data/petersen_five_six_v125_instance.json').read_text())
new=build()
assert saved==json.loads(json.dumps(new)), 'regenerated marked geometry differs from saved certificate'
assert len(saved['equivariant_unsigned_axis_maps'])==3
assert saved['A5_Hom_dimensions']=={'signed_edge15_to_axis15':3,'signed_edge6_to_axis15':0,'max_equivariant_rank':9}
assert len(saved['group_elements_60'])==60
assert saved['spectral_eigenvalues_axis_images']=={'rank4':{'Q600':-3,'E8_Gram':296},'rank5_x2':{'Q600':0,'E8_Gram':164}}
print('PASS v1_25: 6D exterior wedge-Hodge isometry, 2 independent 5D axis maps, rank9 maximal intertwiner, 0 Hom_A5(six,axis); actual 60 marked group actions')
