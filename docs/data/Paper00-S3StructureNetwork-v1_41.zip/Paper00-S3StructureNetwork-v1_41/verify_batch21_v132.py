#!/usr/bin/env python3
"""Exact and guarded v1_32 mathematical structure network regression checks."""
import json,pathlib,subprocess,sys,hashlib,collections
from fractions import Fraction as F
R=pathlib.Path(__file__).resolve().parent
subprocess.run([sys.executable,str(R/'scripts/rebuild_structure_graph_v132.py'),'--check'],cwd=R,check=True)
load=lambda p:json.loads((R/p).read_text())
subprocess.run([sys.executable,str(R/'scripts/structure_closure_v132.py')],cwd=R,check=True)
C=load('data/v132_release_counts.json')
O=load('data/objects.json');E=load('data/mathematical_relations.json')
H=load('data/joint_input_relations.json');D=load('data/derived_compositions.json')
assert (len(O),len(E),len(H),len(D))==(862,1392,242,183)
assert (C['new_objects'],C['new_typed_relations'],C['new_joint_inputs'],C['new_compositions'])==(13,72,57,12)
assert len([o for o in O if o.get('batch')=='v1_32'])==13
assert len([e for e in E if e['id'].startswith('G32-')])==72
assert len([h for h in H if h['id'].startswith('HYP-G32-')])==57
assert len([x for x in E if x.get('verification')=='EXACT_MATHEMATICAL_SUBOBJECT_V132'])==18
assert len({o['id'] for o in O})==len(O)
assert len({e['id'] for e in E})==len(E)
assert len({h['id'] for h in H})==len(H)
assert all(e['conditions_preserved'] for e in E)
assert not any(':thm:' in o['id'] or ':claim:' in o['id'] for o in O)
Hids={h['id']:h for h in H};Ids={o['id'] for o in O}
for e in E:
 assert e['from'] in Ids and e['to'] in Ids
 if e.get('joint_relation_id'):
  h=Hids[e['joint_relation_id']]
  assert e['to'] in h['outputs'] and set(e.get('requires_joint_inputs',[]))==set(h['inputs'])
  assert len(h.get('conditions',[]))>0
assert len([e for e in E if e['id'].startswith('G32-') and e['verification']=='SOURCE_RESTRICTED_MATHEMATICAL_MAP_EXACT_PROOF_NOT_REPLAYED'])==24
iso=load('reports/geometry_completeness_v132.json')
assert iso['counts']['isolated_objects']==5 and iso['counts']['component_containing_S3']==855
assert iso['counts']['weak_components']==7 and iso['counts']['previous_isolates_now_mathematically_linked']==48
ledger=load('data/v132_remaining_frontier_classification.json')
assert len(ledger['objects'])==53 and len({a['id'] for a in ledger['objects']})==53
assert collections.Counter(a['verification_class'] for a in ledger['objects'])=={
 'LINKED_SOURCE_FORMULA_GUARDED_EXACT_CERTIFICATE_OPEN':24,
 'LINKED_SOURCE_GUARDED_MATH_INTERFACE':24,'INTENTIONAL_NONIDENTIFICATION':5}
current=load('data/v132_current_tex_isolate_witnesses.json')
assert len(current['source_witnesses'])==53 and all(w['label_located'] and len(w['tex_sha256'])==64 for w in current['source_witnesses'])
for edge in E:
 if edge.get('verification')!='SOURCE_RESTRICTED_MATHEMATICAL_MAP_EXACT_PROOF_NOT_REPLAYED':continue
 w=edge['current_source_anchor'];h=Hids[edge['joint_relation_id']]
 assert w['id']==edge['to'] and len(h['conditions'])>=2
 assert edge['source_scope'] and edge['current_source_anchor']['label_located']
# Independent exact arithmetic for the source finite selected representations.
D1=[F(2,3),F(-1,3),F(-1,3)];D2=[F(0),F(1),F(-1)]
assert sum(x*x for x in D1)==F(2,3)
assert sum((x+y)**2 for x,y in zip(D1,D2))==F(8,3)
Anomaly={
 'su3su3Y':2*F(1,6)*F(1,2)-F(2,3)*F(1,2)+F(1,3)*F(1,2),
 'su2su2Y':3*F(1,6)*F(1,2)-F(1,2)*F(1,2),
 'gravgravY':6*F(1,6)+2*F(-1,2)+3*F(-2,3)+3*F(1,3)+1,
 'Y3':6*F(1,6)**3+2*F(-1,2)**3+3*F(-2,3)**3+3*F(1,3)**3+1}
assert all(v==0 for v in Anomaly.values())
assert all((2*c+3*w+y)%6==0 for c,w,y in [(1,1,1),(1,0,4),(1,0,-2),(0,1,-3),(0,0,-6),(0,0,0)])
assert load('data/v132_second_pass_guarded_math_checks.json')['source_literal_structural_operator_map_count']==24
print('PASS Batch21: exact Qsqrt5/A5, Hurwitz, round-S3, 62-node instances; 24 guarded source-formula connections; 53/53 source classifications; five intentional no-maps; finite charge arithmetic, no physical promotions')
