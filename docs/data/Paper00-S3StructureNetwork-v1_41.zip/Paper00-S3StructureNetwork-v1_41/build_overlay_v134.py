#!/usr/bin/env python3
"""Overlay v133 effective proof grades with v134 four new scoped exact replays.
The source relations and actual mathematical graph topology are never edited.
"""
from pathlib import Path
import json,sys
R=Path(__file__).resolve().parent
rd=lambda x:json.loads((R/x).read_text())
source=rd('data/v133_verified_frontier_status.json')
cert=rd('data/v134_scoped_math_replays.json')
obst=rd('data/v134_unresolved_boundary_tests.json')
replayed_ids=sorted(cert['new_conditional_replayed_ids'])
assert replayed_ids==['G32-059','G32-061','G32-066','G32-070']
assert set(replayed_ids)<=set(source['pending_ids'])
new=json.loads(json.dumps(source))
new.update({'release':'v1_34','parent':'v1_33',
            'authority':'Effective conditional mathematical-map verification overlay v134. Historical v132 and v133 data unchanged. Does NOT discharge source-selected terminal actions, physical owners, theorem claims or observables.',
            'original_frontier_count':24,
            'carried_forward_verified_ids':source['verified_ids'],
            'carried_forward_verified_count':17,
            'newly_verified_ids':replayed_ids,
            'newly_verified_count':len(replayed_ids),
            'verified_ids':sorted(source['verified_ids']+replayed_ids),
            'replay_count':source['replay_count']+len(replayed_ids),
            'pending_ids':sorted(set(source['pending_ids'])-set(replayed_ids)),
            'pending_count':len(source['pending_ids'])-len(replayed_ids),
            'whole_source_theorems_or_physical_premises_promoted':0,
            'physical_action_occurrence_promoted':0,
            'graph_topology_changed':False,
            'pending_boundary_cert_ref':'data/v134_unresolved_boundary_tests.json',
            'scope_statement':'17 pre-existing v133 and four new v134 independently replayed conditional finite mathematical submaps; 3 remain source-selection/reconstruction unverified; no physical theorem promoted.'})
for id in replayed_ids:
 x=new['relations'][id]
 x['effective_mathematical_map_status']='INDEPENDENT_CONDITIONAL_MATHEMATICAL_MAP_REPLAY'
 x['certificate_ref']='data/v134_scoped_math_replays.json#checks/'+id[4:]
 x['pending_reason']=None
 x['replay_generation']='v1_34'
 x['replay_scope']='independent source-scoped mathematical submap, still conditional on retained source-domain owner hypotheses'
 x['undischarged_source_or_physical_conditions']=cert['checks'][id[4:]]['undischarged_source_or_physical_conditions']
for id in new['pending_ids']:
 x=new['relations'][id]
 x['frontier_boundary_certificate']='data/v134_unresolved_boundary_tests.json#boundary_tests/'+id
 x['pending_reason']=obst['boundary_tests'][id]['not_proved']
assert len(new['verified_ids'])==21 and len(new['pending_ids'])==3
assert set(new['verified_ids'])|set(new['pending_ids'])==set(new['relations'])
assert not(set(new['verified_ids'])&set(new['pending_ids']))
out=R/'data/v134_verified_frontier_status.json'
if '--check' in sys.argv:
 assert rd('data/v134_verified_frontier_status.json')==new
 print('CHECK overlay 21/24 replayed, 3 pending, 0 physical promotions')
else:
 out.write_text(json.dumps(new,indent=2,ensure_ascii=False,sort_keys=True)+'\n')
 print('WRITE overlay',out,'21/24 replayed; 3 pending')
