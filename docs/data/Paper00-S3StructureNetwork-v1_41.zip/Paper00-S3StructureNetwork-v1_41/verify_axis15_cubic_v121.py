#!/usr/bin/env python3
"""Independent exact verification of Batch 10 cubic 15-axis geometry.

Regenerates the v1_20 240-root E8 incidence from quaternion integers first,
then compares the complete new exact rational/finite group reconstruction.
"""
import pathlib,json,hashlib
from scripts.q8_hopf_e8_bridge_v120 import build as rebuild_previous
from scripts.axis15_cubic_v121 import build as rebuild_cubic
R=pathlib.Path(__file__).resolve().parent
prior=json.loads((R/'data/q8_hopf_e8_bridge_v120_instance.json').read_text())
assert rebuild_previous()==prior, 'Earlier weighted axis incidence does not match regenerated 240-root E8 geometry'
saved=json.loads((R/'data/axis15_cubic_v121_instance.json').read_text())
assert rebuild_cubic()==saved, 'Cubic tensor, automorphism group or local matchings changed'
assert saved['gram_eigenvalue_multiplicity']=={'896':1,'296':4,'164':10}
assert saved['automorphism_group']['order']==360
assert saved['automorphism_group']['induced_core_perm_count']==120
assert saved['automorphism_group']['kernel_order']==3
assert len(saved['ten_pairwise_K33_one_factorizations'])==10
assert len(saved['ten_local_3x3x3_templates'])==10
assert len(saved['triple_tensor_sparse'])==215
assert len(saved['automorphism_group']['triple_orbits'])==5
assert saved['symmetric_tensor_frobenius_norm_squared']==3720
zero={tuple(c['sectors']) for c in saved['cubic_sector_squarenorms'] if c['identically_zero']}
assert zero=={('1','1','4'),('1','1','10'),('1','4','10'),('4','4','10')}
print('PASS: 2240 exact E8 root triples independently regenerated and projected to 280 Q8 triple-orbits')
print('PASS: 15-axis tensor Gram = 164I + 44 SameCore + 40J = 164I - 23Q600 + 7Q600^2')
print('PASS: intrinsic five 3-axis cores, Gram eigenvalues 896/296/164 with ranks 1/4/10')
print('PASS: exact cubic selection rules and all ten 3x3x3 local ternary forms')
print('PASS: ten K3,3 triple-matching factorizations and relative order-3 transports')
print('PASS: exhaustive 933120-permutation enumeration yields automorphism group of order 360')
print('PASS: five complete symmetry orbits of all 455 three-axis subsets; no physical selection claims')
