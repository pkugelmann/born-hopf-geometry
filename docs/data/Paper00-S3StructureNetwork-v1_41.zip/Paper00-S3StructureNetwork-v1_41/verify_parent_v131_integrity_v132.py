#!/usr/bin/env python3
"""Check v1_31 inherited data file hashes and immutable graph-export hashes in v1_32."""
import json, pathlib, hashlib
R=pathlib.Path(__file__).resolve().parent
D=json.loads((R/'data/v132_parent_inheritance_certificate.json').read_text())
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for rec in D['immutable_historical_data']:
 p=R/'data'/rec['file']
 assert p.is_file() and p.stat().st_size==rec['bytes'] and H(p)==rec['sha256'],rec['file']
for rec in D['append_only_historical_json_ledgers']:
 x=json.loads((R/'data'/rec['file']).read_text());assert len(x)>=rec['old_records']
 h=hashlib.sha256(json.dumps(x[:rec['old_records']],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
 assert h==rec['original_prefix_hash_sha256']==rec['updated_prefix_hash_sha256'],rec['file']
for rec in D['immutable_historical_graph_exports']:
 assert H(R/rec['file'])==rec['sha256'],rec['file']
print('PASS v1_31 inherited content:',len(D['immutable_historical_data']),'data bytewise,',len(D['append_only_historical_json_ledgers']),'append-only ledgers,',len(D['immutable_historical_graph_exports']),'historic graphs bytewise')
