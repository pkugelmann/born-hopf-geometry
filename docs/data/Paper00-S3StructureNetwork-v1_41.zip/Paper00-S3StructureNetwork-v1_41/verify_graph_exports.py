#!/usr/bin/env python3
"""Verify exported GraphML describes exactly the JSON mathematical-object graph."""
import pathlib,json,collections,xml.etree.ElementTree as ET
root=pathlib.Path(__file__).resolve().parent
load=lambda f:json.loads((root/'data'/f).read_text())
O=load('objects.json');E=load('mathematical_relations.json');H=load('joint_input_relations.json')
ns={'g':'http://graphml.graphdrawing.org/xmlns'}
def parse(path):
 tree=ET.parse(root/path).getroot()
 keynames={k.attrib['id']:k.attrib['attr.name'] for k in tree.findall('g:key',ns)}
 nodes={n.attrib['id']: {keynames[d.attrib['key']]:d.text or '' for d in n.findall('g:data',ns)} for n in tree.findall('.//g:node',ns)}
 edges={e.attrib.get('id',e.attrib['source']+'--'+e.attrib['target']):{'from':e.attrib['source'],'to':e.attrib['target'],**{keynames[d.attrib['key']]:d.text or '' for d in e.findall('g:data',ns)}} for e in tree.findall('.//g:edge',ns)}
 return nodes,edges
nodes,edges=parse('graph/mathematical_structure_network.graphml')
assert set(nodes)=={o['id'] for o in O}
assert set(edges)=={e['id'] for e in E}
for o in O:
 assert nodes[o['id']]['label']==o['name']
for e in E:
 x=edges[e['id']]
 assert (x['from'],x['to'],x['relation'])==(e['from'],e['to'],e['relation'])
 assert x.get('requires_and_inputs','')==','.join(e.get('requires_joint_inputs',[]))
fn,fe=parse('graph/batch3_spin4_clifford_bridges.graphml')
g14={e['id'] for e in E if e['id'].startswith('G14-')}
assert set(fe)==g14 and all(x['from'] in fn and x['to'] in fn for x in fe.values())
assert len(g14)==68 and len(fn)>=29
fn15,fe15=parse('graph/batch4_bihopf_reciprocal_bridges.graphml')
g15={e['id'] for e in E if e['id'].startswith('G15-')}
assert set(fe15)==g15 and len(g15)==78 and len(fn15)>=42
assert all(x['from'] in fn15 and x['to'] in fn15 for x in fe15.values())
fn16,fe16=parse('graph/batch5_finite_geometry_bridges.graphml')
g16={e['id'] for e in E if e['id'].startswith('G16-')}
assert set(fe16)==g16 and len(g16)==68 and len(fn16)>=34
assert all(x['from'] in fn16 and x['to'] in fn16 for x in fe16.values())
fn17,fe17=parse('graph/batch6_golden_e8_triality_bridges.graphml')
g17={e['id'] for e in E if e['id'].startswith('G17-')}
assert set(fe17)==g17 and len(g17)==77 and len(fn17)>=40
assert all(x['from'] in fn17 and x['to'] in fn17 for x in fe17.values())
fn18,fe18=parse('graph/batch7_mckay_clifford_bridges.graphml')
g18={e['id'] for e in E if e['id'].startswith('G18-')}
assert set(fe18)==g18 and len(g18)==70 and len(fn18)>=32
fn20,fe20=parse('graph/batch9_q8_hopf_e8_axis_bridges.graphml')
g20={e['id'] for e in E if e['id'].startswith('G20-')}
assert set(fe20)==g20 and len(g20)==44 and len(fn20)>=20
for group,counts in [('2T',(7,6)),('2O',(8,7)),('2I',(9,8))]:
 a,b=parse(f'graph/affine_mckay_{group}.graphml')
 assert (len(a),len(b))==counts
for name,nonzero in [('BO',10),('BI',15),('X',21)]:
 a,b=parse(f'graph/batch7_{name}_matrix_bipartite.graphml')
 assert len(b)==nonzero
qn,qe=parse('graph/batch8_q8_triality_24orbit_weighted.graphml')
assert len(qn)==24 and len(qe)==168
cn,ce=parse('graph/batch10_cubic_gram_15axis.graphml')
assert len(cn)==15 and len(ce)==105
cn,ce=parse('graph/batch10_local_weight2_matchings_and_five_cores.graphml')
assert len(cn)==50 and len(ce)==105
an,ae=parse('graph/batch9_common_axis15_operators.graphml')
assert len(an)==15 and len(ae)==105
dn,de=parse('graph/batch9_E8_axis15_weighted_2design.graphml')
assert len(dn)==230 and len(de)==645
trn,tre=parse('graph/batch9_triality24_to_hopf15.graphml')
assert len(trn)==39 and len(tre)==24
htn,hte=parse('graph/batch9_triality_axis12_weighted_hypergraph.graphml')
assert len(htn)==116 and len(hte)==312

hn,he=parse('graph/batch8_q8_triality_104hyperedges.graphml')
assert len(hn)==128 and len(he)==312
mn,me=parse('graph/affine_mckay_Q8_D4.graphml')
assert len(mn)==5 and len(me)==4
full_root,full_edges=parse('graph/golden_e8_root_addition_240.graphml')
assert len(full_root)==240 and len(full_edges)==6720
tri_nodes,tri_edges=parse('graph/golden_e8_triality_192.graphml')
assert len(tri_nodes)==192 and len(tri_edges)==3072
# Strictly no source-claim nodes.
f22n,f22e=parse('graph/batch11_C3_holonomy_geometry_bridges.graphml')
g22={e['id'] for e in E if e['id'].startswith('G22-')}
assert set(f22e)==g22 and len(g22)==33 and all(x['from'] in f22n and x['to'] in f22n for x in f22e.values())
assert (lambda x:(len(x.findall('.//g:node',ns)),len(x.findall('.//g:edge',ns))))(ET.parse(root/'graph/batch11_3K5_three_parallel_edge_multigraph.graphml').getroot())==(5,30)
assert len(parse('graph/batch11_3K5_three_parallel_edge_multigraph.graphml')[1])==30  # globally unique multiedge IDs
assert tuple(map(len,parse('graph/batch11_15axis_matching_voltage_graph.graphml')))==(15,90)
assert tuple(map(len,parse('graph/batch11_120_to_15_to_5_vertex_fibres.graphml')))==(140,135)
f23n,f23e=parse('graph/batch12_A5_Q8_C3_spectral_bridges.graphml')
g23={e['id'] for e in E if e['id'].startswith('G23-')}
assert set(f23e)==g23 and len(g23)==42 and len(f23n)==33
assert all(x['from'] in f23n and x['to'] in f23n for x in f23e.values())
assert tuple(map(len,parse('graph/batch13_actual_15x15_signed_intertwiner.graphml')))==(30,180)
fn25,fe25=parse('graph/batch14_Petersen_A5_five_six_completions.graphml')
g25={e['id'] for e in E if e['id'].startswith('G25-')}
assert set(fe25)==g25 and len(fe25)==42 and all(x['from'] in fn25 and x['to'] in fn25 for x in fe25.values())
for name in ('wedge6','axis5'):
    bnodes,bedges=parse(f'graph/batch14_actual_{name}_matrix.graphml')
    assert bnodes and bedges
    from fractions import Fraction
    cert=load('petersen_five_six_v125_instance.json')['matrices']
    matrix=cert['signed_edge_to_exterior_wedge_W6_10x15'] if name=='wedge6' else cert['signed_petersen5_to_axis5_X0_15x15']
    assert len(bedges)==sum(Fraction(str(x))!=0 for row in matrix for x in row)
f24n,f24e=parse('graph/batch13_Petersen_A5_600_E8_fourspace.graphml')
g24={e['id'] for e in E if e['id'].startswith('G24-')}
assert set(f24e)==g24 and len(g24)==43
assert all(x['from'] in f24n and x['to'] in f24n for x in f24e.values())
assert tuple(map(len,parse('graph/batch12_actual_C3_on_15_axes.graphml')))==(15,15)
assert tuple(map(len,parse('graph/batch12_actual_C3_on_60_projective_points.graphml')))==(60,60)
assert tuple(map(len,parse('graph/batch15_induced_dodeca_total50.graphml')))==(50,150)
assert tuple(map(len,parse('graph/batch15_total_petersen25.graphml')))==(25,75)
assert tuple(map(len,parse('graph/batch15_twofold_petersen_cover.graphml')))==(75,50)
assert tuple(map(len,parse('graph/batch15_petersen_total_milnor_geometric_connections.graphml')))[1]==33
# Exact new-batch graph is a subgraph of the same mathematical schema.
n27,e27=parse('graph/batch16_clifford_m8_operator_bridges.graphml')
assert set(e27)=={e['id'] for e in E if e['id'].startswith('G27-')}
assert len(e27)==58 and len(n27)>=13
assert all(x['from'] in n27 and x['to'] in n27 for x in e27.values())
n28,e28=parse('graph/batch17_icosahedral_hopf_pair_coefficients.graphml')
g28={e['id'] for e in E if e['id'].startswith('G28-')}
assert set(e28)==g28 and len(e28)==51 and all(x['from'] in n28 and x['to'] in n28 for x in e28.values())
# Compare exact operator GraphML against saved rational matrix instances.
mirror_nodes,mirror_edges=parse('graph/batch19_petersen_mirror_H15.graphml')
sing_nodes,sing_edges=parse('graph/batch19_su3_identity_singlet_P9.graphml')
from fractions import Fraction
inst=load('finite_invariant_geometry_v130_instance.json')
HH=inst['petersen']['matrix_H_sqrt5D_15x15']
PP=inst['su3']['matrix_meson_singlet_projector_9x9']
assert len(mirror_nodes)==15 and len(mirror_edges)==sum(Fraction(HH[i][j])!=0 for i in range(15) for j in range(i,15))
assert len(sing_nodes)==9 and len(sing_edges)==sum(Fraction(PP[i][j])!=0 for i in range(9) for j in range(i,9))==6
g30n,g30e=parse('graph/batch19_petersen_su3_invariant_bridges.graphml')
assert len(g30e)==40 and set(g30e)=={e['id'] for e in E if e['id'].startswith('G30-')}
assert all(z['from'] in g30n and z['to'] in g30n for z in g30e.values())
assert not any(':thm:' in n or ':cor:' in n or ':claim:' in n for n in nodes)
h29n,h29e=parse('graph/batch18_hurwitz_cellular_hodge_relatives.graphml')
assert set(h29e)=={e['id'] for e in E if e['id'].startswith('G29-')} and len(h29e)==54
assert tuple(map(len,parse('graph/batch18_hurwitz_Q8_weighted_three_graph.graphml')))==(3,3)
assert tuple(map(len,parse('graph/batch20_hopf_su3_group_invariants.graphml')))[1]==41
print('PASS: full graph exports exactly',len(O),'mathematical objects and',len(E),'typed relations; batch20 has 41 relations')
