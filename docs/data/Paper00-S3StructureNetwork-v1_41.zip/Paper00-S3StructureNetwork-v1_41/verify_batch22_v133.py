#!/usr/bin/env python3
"""Validate 17 source-scoped conditional math certificates, 7 pending, all immutable parent records."""
from __future__ import annotations
import json,pathlib,subprocess,sys,collections,xml.etree.ElementTree as ET
R=pathlib.Path(__file__).resolve().parent
load=lambda x:json.loads((R/x).read_text())
F=load('data/v133_verified_frontier_status.json');C=load('data/v133_scoped_math_replays.json')
E=load('data/mathematical_relations.json');O=load('data/objects.json');H=load('data/joint_input_relations.json');D=load('data/derived_compositions.json')
W=load('data/v133_current_tex_scope_witnesses.json'); I=load('data/v132_remaining_frontier_classification.json')
assert (len(O),len(E),len(H),len(D))==(862,1392,242,183)
assert F['replay_count']==C['replayed_relation_count']==17
assert F['pending_count']==7 and F['original_frontier_count']==24
assert len(F['verified_ids'])==17 and len(F['pending_ids'])==7
assert set(F['verified_ids'])=={'G32-'+k for k in C['checks']}
assert not set(F['verified_ids'])&set(F['pending_ids'])
assert F['whole_source_theorems_or_physical_premises_promoted']==0
assert W['source_witness_count']==24 and W['all_full_hashes_confirmed'] and W['all_labels_relocated']
actual_ids={e['id'] for e in E if e['verification']=='SOURCE_RESTRICTED_MATHEMATICAL_MAP_EXACT_PROOF_NOT_REPLAYED'}
assert actual_ids==set(F['relations'])==set(F['verified_ids']+F['pending_ids'])
G={e['id']:e for e in E}
Hmap={h['id']:h for h in H}
for id,rec in F['relations'].items():
 e=G[id]
 assert (e['from'],e['to'])==(rec['from'],rec['to'])
 assert rec['joint_relation_id'] in Hmap
 assert rec['guarded_conditions']==Hmap[rec['joint_relation_id']]['conditions']
 assert rec['physical_owner_or_source_theorem_independently_dischargeable'] is False
 assert rec['remaining_conditions']
 assert rec['tex_sha256'] and len(rec['tex_sha256'])==64
 if id in F['verified_ids']:
  assert rec['certificate_ref']==('data/v133_scoped_math_replays.json#checks/'+id[4:])
  assert rec['effective_mathematical_map_status']=='INDEPENDENT_CONDITIONAL_MATHEMATICAL_MAP_REPLAY'
 else:
  assert rec['certificate_ref'] is None
  assert rec['pending_reason']
for w in W['witnesses']:
 rec=F['relations'][w['relation_id']]
 assert w['sha256']==rec['tex_sha256'] and w['label']==rec['source_label']
assert len(I['objects'])==53 and I['still_missing_unconditionally_certified_math_interfaces']==24  # past status unchanged
ns={'g':'http://graphml.graphdrawing.org/xmlns'}
def parse(path):
 root=ET.parse(R/path).getroot()
 keys={k.attrib['id']:k.attrib['attr.name'] for k in root.findall('g:key',ns)}
 nodes={n.attrib['id'] for n in root.findall('.//g:node',ns)}
 edges={e.attrib['id']:(e.attrib['source'],e.attrib['target'],{keys[d.attrib['key']]:d.text for d in e.findall('g:data',ns)}) for e in root.findall('.//g:edge',ns)}
 return nodes,edges
n,e=parse('graph/mathematical_structure_network_effective_v133.graphml')
assert n=={x['id'] for x in O} and set(e)==set(G)
for id,(frm,to,props) in e.items():
 assert (frm,to)==(G[id]['from'],G[id]['to'])
 assert props['source_verification_v132']==G[id]['verification']
 if id in F['relations']:
  assert props['effective_verification']==F['relations'][id]['effective_mathematical_map_status']
 else:assert props['effective_verification']==G[id]['verification']
n2,e2=parse('graph/batch22_verified_scoped_math_maps.graphml')
assert set(e2)==set(F['verified_ids'])
assert n2=={x for id in e2 for x in e2[id][:2]}
for cmd in ['verify_scoped_math_v133.py --check','rebuild_effective_graph_v133.py --check','verify_parent_v132_integrity_v133.py']:
 p=subprocess.run([sys.executable,*cmd.split()],cwd=R,capture_output=True,text=True,check=True)
 print(p.stdout.rstrip())
print('PASS Batch22: 17 exact conditional mathematical-map replays, 7 retained open, immutable v132 graph ledgers; 0 physical/source-theorem promotions')
