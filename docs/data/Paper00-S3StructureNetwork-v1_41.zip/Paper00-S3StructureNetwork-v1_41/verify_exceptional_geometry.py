#!/usr/bin/env python3
"""Independently regenerate/check the full exact exceptional-S3 incidence instance.
Requires Python 3.10+ and SymPy for the symbolic 48x48 charpolys.
No original TeX files or proof-DAG archive required to rerun.
"""
from pathlib import Path
import sys,json,collections
import sympy as sp
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'scripts'))
from exceptional_model import build_instance,qmul

inst=json.loads((HERE/'data/exceptional_600cell_instance.json').read_text())
regen=build_instance()
assert inst==regen, 'Packaged quaternionic group/incidence instance differs from exact regenerated one'
V=inst['vertices']; E=inst['nearest_edges']; colors={v['id']:v['color'] for v in V}
assert len(V)==120 and len(E)==720
assert collections.Counter((e['coset_pair'][0],e['coset_pair'][1]) for e in E)=={(i,j):72 for i in range(5) for j in range(i+1,5)}
assert not any(colors[e['u']]==colors[e['v']] for e in E)
expected_pairs={(i,j) for i in range(5) for j in range(i+1,5)}
assert {tuple(a['pair']) for a in inst['axes']}==expected_pairs
assert all(len(a['subgroup_vertices'])==6 and a['edge_count']==72 for a in inst['axes'])
# Check orbit action on the FULL edge set, rather than just its 4x4 quotient.
q_by_id={v['id']:tuple(tuple(x) for x in v['qcoords']) for v in V}
id_by_q={v:i for i,v in q_by_id.items()}
adjacency={v['id']:set() for v in V}
for e in E:
 adjacency[e['u']].add(e['v']);adjacency[e['v']].add(e['u'])
assert all(len(s)==12 for s in adjacency.values())
x=sp.Symbol('x'); expected48=x**12*(x**2-9)*(x**2-6)**4*(x**2-4)**6*(x**2-3)**4*(x**2-1)**3
expected8=(x**2-9)*(x**2-1)**3
for axis in inst['axes']:
 i,j=axis['pair'];verts=set(inst['coset_blocks'][i]+inst['coset_blocks'][j]);L={k:n for n,k in enumerate(sorted(verts))}
 A=[[0]*48 for _ in range(48)]
 for e in E:
  u,v=e['u'],e['v']
  if u in verts and v in verts: A[L[u]][L[v]]=A[L[v]][L[u]]=1
 assert all(sum(row)==3 for row in A)
 assert sp.expand(sp.Matrix(A).charpoly(x).as_expr()-expected48)==0, 'exact cover charpoly mismatch'
 B=axis['quotient_biadjacency'];Q=[[0]*8 for _ in range(8)]
 for a in range(4):
  for b in range(4):Q[a][b+4]=Q[b+4][a]=B[a][b]
 assert sp.expand(sp.Matrix(Q).charpoly(x).as_expr()-expected8)==0
 assert all(sorted(row)==[0,1,1,1] for row in B)
 assert all(sorted(col)==[0,1,1,1] for col in zip(*B))
 cover_edges={tuple(sorted((e['u'],e['v']))) for e in E if tuple(e['coset_pair'])==(i,j)}
 assert len(cover_edges)==72
 c6=[q_by_id[k] for k in axis['subgroup_vertices']]
 unseen=set(cover_edges); edge_orbits=[]
 while unseen:
  e=min(unseen)
  orb={tuple(sorted((id_by_q[qmul(c6elem,q_by_id[e[0]])],id_by_q[qmul(c6elem,q_by_id[e[1]])]))) for c6elem in c6}
  assert orb<=unseen and len(orb)==6
  assert len({v for edge in orb for v in edge})==12, 'six edges should be a disjoint matching'
  unseen-=orb;edge_orbits.append(orb)
 assert len(edge_orbits)==12 and axis['connected_cover_components']==[48]
 print('C6 AXIS',i,j,': connected 48-vertex cyclic six-cover of cube; 12 six-edge orbit matchings; charpoly exact')
print('VALID: exact Q(sqrt5) finite geometry, 120 vertices, 720 edges, ten Petersen-indexed cyclic cube covers')
