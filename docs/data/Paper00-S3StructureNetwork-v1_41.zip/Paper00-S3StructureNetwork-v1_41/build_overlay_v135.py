#!/usr/bin/env python3
"""v1_35 dual-axis: 24 conditional math replays, 3 owner/source-selection frontiers.
Never changes base geometry objects, relations, guards or compositions.
"""
from pathlib import Path
import json,sys
R=Path(__file__).resolve().parent
read=lambda name:json.loads((R/name).read_text())
parent=read('data/v134_verified_frontier_status.json')
cert=read('data/v135_scoped_math_replays.json')
orig=read('data/v134_unresolved_boundary_tests.json')
assert parent['replay_count']==21 and parent['pending_count']==3
newids=cert['new_conditional_replayed_ids']
assert newids==['G32-052','G32-056','G32-072']==parent['pending_ids']
new=json.loads(json.dumps(parent))
new.update({'release':'v1_35','parent':'v1_34',
    'authority':'Dual-axis conditional mathematical proof overlay. All 24 source-scoped maps replayed as guarded finite mathematics; original source/owner selection frontier remains explicit and unproved. Base graph untouched.',
    'carried_forward_verified_ids':parent['verified_ids'],
    'carried_forward_verified_count':parent['replay_count'],
    'newly_verified_ids':newids,'newly_verified_count':3,
    'verified_ids':sorted(parent['verified_ids']+newids),'replay_count':24,
    'pending_ids':[],'pending_count':0,'graph_topology_changed':False,
    'whole_source_theorems_or_physical_premises_promoted':0,
    'physical_action_occurrence_promoted':0,
    'source_boundary_pending_ids':newids,'source_boundary_pending_count':3,
    'source_boundary_certificate':'data/v135_source_owner_frontier.json',
    'scope_statement':'All 24 conditional mathematical graph edges independently replayed. The three former pending edges still have unresolved source/owner selection or physical observable conditions, with extra [H,P]=0 reduction guard explicit for the meson spectral theorem. No physical theorem promoted.'})
for id in newids:
    d=new['relations'][id]
    d['effective_mathematical_map_status']='INDEPENDENT_CONDITIONAL_MATHEMATICAL_MAP_REPLAY'
    d['certificate_ref']='data/v135_scoped_math_replays.json#checks/'+id[4:]
    d['pending_reason']=None
    d['replay_generation']='v1_35'
    d['replay_scope']='Source-fixed exact finite algebra and spectral theorem under retained typed conditions; does NOT establish physical owner or occurrence.'
    d['undischarged_source_or_physical_conditions']=cert['checks'][id[4:]]['not_proved']
    d['source_boundary_still_open']=True
    d['source_boundary_certificate']='data/v135_source_owner_frontier.json#boundaries/'+id
    if id=='G32-072':
        d['mathematical_replay_required_hypotheses']=['H_L-E_0,L selfadjoint', '[H_L,P_{singlet,JPC,flavor}]=0 for invariant-sector interpretation; otherwise only Ritz/compression eigenvalues']
    else:d['mathematical_replay_required_hypotheses']=list(d['remaining_conditions'])
assert len(new['verified_ids'])==24 and not new['pending_ids']
assert set(new['source_boundary_pending_ids'])==set(orig['remaining_ids'])
assert set(new['relations'])==set(new['verified_ids'])
out=R/'data/v135_verified_frontier_status.json'
if '--check' in sys.argv:assert read('data/v135_verified_frontier_status.json')==new
else:out.write_text(json.dumps(new,indent=2,ensure_ascii=False,sort_keys=True)+'\n')
print('PASS effective dual-axis frontier: 24/24 conditional math, three source-owner selection open, zero physical promotions')
