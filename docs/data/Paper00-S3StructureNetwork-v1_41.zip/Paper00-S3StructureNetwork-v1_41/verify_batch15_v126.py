#!/usr/bin/env python3
"""Independently regenerate exact v1_26 mathematics and confirm source audit topology."""
from pathlib import Path
import json,networkx as nx,xml.etree.ElementTree as ET
from scripts.petersen_total_v126 import build as petersen
from scripts.milnor_spectral_v126 import build as milnor
from scripts.ten_axis_projectors_v126 import build as c6
R=Path(__file__).resolve().parent
D=R/'data'
for name,build in [('petersen_total_v126_instance.json',petersen),('milnor_spectral_v126_instance.json',milnor),('ten_axis_projectors_v126_instance.json',c6)]:
 saved=json.loads((D/name).read_text());actual=build()
 assert saved==json.loads(json.dumps(actual)),name
 print('EXACT REGENERATION PASS',name)
obj=json.loads((D/'objects.json').read_text());links=json.loads((D/'mathematical_relations.json').read_text());J=json.loads((D/'joint_input_relations.json').read_text());c=json.loads((D/'derived_compositions.json').read_text())
# v1_26 historical totals are strict for its own release. Cumulative later
# releases must preserve the original v1_26 records but necessarily have
# larger graphs; do not misreport the historical isolate count as current.
parent_counts=(772,1076,137,123)
is_historical_release=(len(obj),len(links),len(J),len(c))==parent_counts
assert all(x>=y for x,y in zip((len(obj),len(links),len(J),len(c)),parent_counts))
assert len([x for x in obj if x.get('batch')=='v1_26'])==13
assert len([x for x in links if x['id'].startswith('G26-')])==33
assert len([x for x in J if x['id'].startswith('HYP-G26-')])==5
assert len([x for x in c if x['id'].startswith('D26-')])==6
G=nx.Graph();G.add_nodes_from(x['id'] for x in obj);G.add_edges_from((x['from'],x['to']) for x in links)
audit=json.loads((R/'reports/geometry_completeness_v126.json').read_text())
if is_historical_release:
 assert len(list(nx.isolates(G)))==115 and len(list(nx.connected_components(G)))==118
 assert len(nx.node_connected_component(G,'geo:s3'))==648
assert audit['counts']['isolated_objects']==115
ns={'g':'http://graphml.graphdrawing.org/xmlns'}
def count(name):
 root=ET.parse(R/'graph'/name).getroot();return len(root.findall('.//g:node',ns)),len(root.findall('.//g:edge',ns))
assert count('batch15_induced_dodeca_total50.graphml')==(50,150)
assert count('batch15_total_petersen25.graphml')==(25,75)
assert count('batch15_dodeca20.graphml')==(20,30)
assert count('batch15_twofold_petersen_cover.graphml')==(75,50)
assert count('batch15_petersen_total_milnor_geometric_connections.graphml')[1]==33
print('PASS: inherited v1_26 exact instances and focused graph certificates retained; historical isolate count stays in its archived audit (not current)')
