#!/usr/bin/env python3
"""Regenerate v1_23 A5/Q8/C3/E8 geometry from actual quaternion and polygon incidence."""
from __future__ import annotations
import pathlib,json,xml.etree.ElementTree as ET
import numpy as np
from scripts.a5_q8_projector_v123 import build
ROOT=pathlib.Path(__file__).resolve().parent
expected=json.loads((ROOT/'data/a5_q8_projector_v123_instance.json').read_text())
actual=build()
assert actual==expected, 'Exact source-independent integer regeneration differs from saved instance.'
a=expected['A5_matrix_coefficients'];q=expected['Q8_character_projectors'];f=expected['Q8_axis15_intertwiner']
assert a['A5_regular_matrix_coefficient_rank']==16
assert q['ranks']==[4,4,4,4]
assert q['C3_complex_eigenspace_dimensions']==[8,4,4]
assert sorted(q['right_C3_conjugation_of_character_projectors'])==[0,1,2,3]
assert q['right_C3_conjugation_of_character_projectors'][0]==0
assert f['projector_denominator']==15 and f['C3_complex_eigen_dims_on_V10']==[5,5]
Q=np.array(q['projector_integer_numerators'],dtype=np.int64)
N=np.array(expected['transporter_spectrum']['N120_matrix'],dtype=np.int64)
assert Q.shape==(4,120,120) and N.shape==(120,120)
assert np.array_equal(Q.sum(axis=0),8*N)
assert np.array_equal(N@N,30*N)
assert all(np.array_equal(Q[i]@Q[j],(240*Q[i] if i==j else np.zeros((120,120),dtype=np.int64))) for i in range(4) for j in range(4))
assert expected['polygon_family_under_right_C3']=={
  '2':{'polygons':450,'fixed_by_right_C3':0,'orbits_of_size3':150,'total_orbits':150},
  '3':{'polygons':200,'fixed_by_right_C3':20,'orbits_of_size3':60,'total_orbits':80},
  '5':{'polygons':72,'fixed_by_right_C3':0,'orbits_of_size3':24,'total_orbits':24}}
ns={'g':'http://graphml.graphdrawing.org/xmlns'}
def sizes(name):
 root=ET.parse(ROOT/'graph'/name).getroot()
 return len(root.findall('.//g:node',ns)),len(root.findall('.//g:edge',ns))
assert sizes('mathematical_structure_network.graphml')==(740,1001)
assert sizes('batch12_A5_Q8_C3_spectral_bridges.graphml')==(33,42)
assert sizes('batch12_actual_C3_on_15_axes.graphml')==(15,15)
assert sizes('batch12_actual_C3_on_60_projective_points.graphml')==(60,60)
print('PASS v1_23: A5 4D matrix coefficients exactly equal cyclic 3/5 polygon projector')
print('PASS v1_23: 600-cell -3 projector splits into four Q8 character modules of rank four')
print('PASS v1_23: quaternionic C3 cycles three sign modules and fixes 4D Hopf/E8 Gram projector')
print('PASS v1_23: all 722 projective cyclic polygons carry exact right-C3 orbit classification')
print('PASS v1_23: mathematical JSON regenerates and GraphML exports match intended counts')
