#!/usr/bin/env python3
"""All parent v132 release files except README and top manifest preserved bytewise."""
import pathlib,json,hashlib
r=pathlib.Path(__file__).resolve().parent
old=json.loads((r/'data/v132_parent_manifest_snapshot.json').read_text())
assert old['version']=='v1_32'
exclude={'README.md','MANIFEST.json'}
for a in old['files']:
 if a['path'] in exclude:continue
 p=r/a['path'];assert p.is_file() and p.stat().st_size==a['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==a['sha256'],a['path']
print('PASS parent v132 preserved bytewise:',len(old['files'])-len(exclude),'files incl all graph ledgers/source evidence and historical validators')
