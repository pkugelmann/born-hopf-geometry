#!/usr/bin/env python3
"""Independently regenerate Batch19 mathematical matrices from inherited exact instances."""
import json
from pathlib import Path
from scripts.finite_invariant_geometry_v130 import build
R=Path(__file__).resolve().parent
saved=json.loads((R/'data/finite_invariant_geometry_v130_instance.json').read_text())
assert saved==build()
p=saved['petersen'];assert len(p['all_32_supports'])==32
assert sum(x['subsets'] for x in p['characteristic_polynomials_scaled_H_sqrt5D'].values())==32
assert p['new_averaged_squared_compression_identity']['coefficients'][3]['coefficient_on_six']=='9/50'
s=saved['su3'];assert s['rank_checks']['meson_singlet']==1 and s['rank_checks']['baryon_determinant']==1
assert all(s['checks'].values())
print('PASS v1_30: exactly 32 signed Petersen compressions, all six characteristic polynomial families, new average-squared identity, normalized SU3 singlet/determinant/Fierz/Casimirs and finite three-source Gram.')
