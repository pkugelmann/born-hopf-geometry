#!/usr/bin/env python3
"""Recheck that every v1_33 release file except README remains bytewise unchanged."""
import hashlib,json,pathlib
R=pathlib.Path(__file__).resolve().parent
D=json.loads((R/'data/v134_parent_manifest_snapshot.json').read_text())
assert D['version']=='v1_33'
N=0
for rec in D['files']:
 if rec['path']=='README.md':continue
 p=R/rec['path']
 assert p.is_file() and p.stat().st_size==rec['bytes'],rec['path']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==rec['sha256'],rec['path']
 N+=1
print('PASS original v133 data/graphs/scripts/reports preserved bytewise:',N,'manifest-listed files')
