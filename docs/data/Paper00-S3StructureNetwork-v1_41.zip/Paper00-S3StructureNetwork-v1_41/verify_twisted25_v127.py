#!/usr/bin/env python3
"""Reproduce exact 25D central character spectral projector from quaternion roots."""
import json,pathlib
from scripts.twisted25_v127 import build
R=pathlib.Path(__file__).resolve().parent
saved=json.loads((R/'data/twisted25_v127_instance.json').read_text())
assert build()==saved,'exact twisted 25D projector reconstruction fails'
assert len(saved['projector_numerator_120x120'])==120
assert saved['projector_trace_and_rank']==25
assert all(v==95 for v in saved['modular_lower_bounds_rank_A600'].values())
print('PASS exact P24/24 projector: rank 25, A600 kernel equals image, orthogonal to rank16 minus-three transporter space; modular rank bounds verified')
