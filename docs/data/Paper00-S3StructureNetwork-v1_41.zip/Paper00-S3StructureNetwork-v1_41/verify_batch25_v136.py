#!/usr/bin/env python3
"""Integrated v1_36 mathematical-extension and conditional-owner verification."""
import subprocess,sys,json,xml.etree.ElementTree as ET
from pathlib import Path
R=Path(__file__).resolve().parent
load=lambda f:json.loads((R/f).read_text())
O=load('data/objects.json');E=load('data/mathematical_relations.json');H=load('data/joint_input_relations.json');C=load('data/derived_compositions.json')
X=load('data/v136_math_extension.json');F=load('data/v136_frontier_resolution.json');Z=load('data/v136_exact_harmonic_gp3_certificate.json')
assert tuple(map(len,(O,E,H,C)))==(862,1392,242,183)
assert tuple(len(X[k]) for k in ('objects','relations','joint_conditions','compositions'))==(17,32,8,6)
assert Z['harmonic']['rank_packet']=={'total':169,'kernel':163,'augmentation':5,'singlet':1,'nonsinglet':168}
assert Z['harmonic']['green_schur_residual']=='163/168'
assert Z['harmonic']['S3_Hom_kernel_to_aug_dimension']==135
assert Z['source_claims_physically_promoted']==0
assert F['physical_theorems_promoted']==0 and F['actual_K56_owner_selected'] is False and F['GP3_multiplicity_unconditionally_closed'] is False
assert F['three_selection_frontiers'][1]['legacy']=='G32-056' and F['three_selection_frontiers'][1]['status']=='RECLASSIFIED_HISTORICAL_D4_BRANCH'
assert set(a['id'] for a in O).isdisjoint({a['id'] for a in X['objects']})
assert set(a['id'] for a in E).isdisjoint({a['id'] for a in X['relations']})
ids={a['id'] for a in O+X['objects']};allE=E+X['relations']
assert len(ids)==879 and len(allE)==1424 and all(e['from'] in ids and e['to'] in ids for e in allE)
ns={'g':'http://graphml.graphdrawing.org/xmlns'}
def parse(f):
 t=ET.parse(R/f).getroot()
 keys={k.attrib['id']:k.attrib['attr.name'] for k in t.findall('g:key',ns)}
 nodes={n.attrib['id'] for n in t.findall('.//g:node',ns)}
 edges={e.attrib['id']:(e.attrib['source'],e.attrib['target'],{keys[d.attrib['key']]:d.text for d in e.findall('g:data',ns)}) for e in t.findall('.//g:edge',ns)}
 return nodes,edges
nodes,edges=parse('graph/mathematical_structure_network_effective_v136.graphml')
assert nodes==ids and len(edges)==1424
for e in allE:
 assert e['id'] in edges and edges[e['id']][:2]==(e['from'],e['to'])
for e in X['relations']:
 attrs=edges[e['id']][2]
 assert attrs['guard_id_v136']==e['guard_id']
 assert attrs['physical_owner_scope_v136']==e['physical_owner_status']
assert 'HISTORICAL_D4_ONLY_ON_NEW_HARMONIC_BRANCH' in edges['G32-056'][2]['physical_owner_scope_v136']
assert edges['G32-052'][2]['physical_owner_scope_v136']=='PHYSICAL_SOURCE_SELECTION_STILL_OPEN'
assert edges['G32-072'][2]['physical_owner_scope_v136']=='PHYSICAL_SOURCE_SELECTION_STILL_OPEN'
fn,fe=parse('graph/batch25_current_neutral_harmonic_GP3.graphml')
assert len(fe)==32 and set(fe)=={e['id'] for e in X['relations']}
assert fn==set(i for e in X['relations'] for i in (e['from'],e['to']))
# Count weak component sizes and isolates for combined graph.
parent={n:n for n in nodes}
def root(i):
 while parent[i]!=i:
  parent[i]=parent[parent[i]];i=parent[i]
 return i
for e in allE:
 a,b=root(e['from']),root(e['to'])
 if a!=b:parent[b]=a
from collections import Counter
sizes=sorted(Counter(root(i) for i in nodes).values(),reverse=True)
assert sizes==[872,2,1,1,1,1,1],sizes

for cmd in ([sys.executable,'scripts/build_batch25_v136.py','--check'],
            [sys.executable,'verify_exact_batch25_v136.py','--check'],
            [sys.executable,'rebuild_effective_graph_v136.py','--check'],
            [sys.executable,'verify_parent_v135_integrity_v136.py'],
            [sys.executable,'verify_batch24_v135.py']):
 r=subprocess.run(cmd,cwd=R,capture_output=True,text=True,check=True)
 print(r.stdout.strip().splitlines()[-1])
print('PASS Batch25: effective graph 879 objects 1424 edges 250 guards 189 compositions, S3-root=872, 5 deliberate isolates, 2-node Gram component. Old conditional 24/24 retained; zero source/physical promotions.')
