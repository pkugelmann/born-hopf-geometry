#!/usr/bin/env python3
"""Validate cumulative pure mathematical geometry graph and exact source-independent checks."""
from __future__ import annotations
import pathlib,json,collections,subprocess,sys,xml.etree.ElementTree as ET
ROOT=pathlib.Path(__file__).resolve().parent
load=lambda f:json.loads((ROOT/'data'/f).read_text())
objects=load('objects.json');edges=load('mathematical_relations.json');joint=load('joint_input_relations.json')
compositions=load('derived_compositions.json');comp=load('geometric_comparisons.json')
ids={o['id'] for o in objects}
assert len(ids)==len(objects)==862
assert len(edges)==1392 and len({e['id'] for e in edges})==1392
assert len(joint)==242 and len({e['id'] for e in joint})==242
assert len(compositions)==183 and len({e['id'] for e in compositions})==183
assert len([o for o in objects if o.get('batch')=='v1_12'])==14
assert len([o for o in objects if o.get('batch')=='v1_13'])==37
assert len([e for e in edges if e['id'].startswith('G12-')])==24
assert len([e for e in edges if e['id'].startswith('G13-')])==76
assert len([o for o in objects if o.get('batch')=='v1_14'])==29
assert len([e for e in edges if e['id'].startswith('G14-')])==68
assert len([o for o in objects if o.get('batch')=='v1_15'])==42
assert len([e for e in edges if e['id'].startswith('G15-')])==78
assert len([o for o in objects if o.get('batch')=='v1_16'])==34
assert len([e for e in edges if e['id'].startswith('G16-')])==68
assert len([h for h in joint if h['id'].startswith('HYP-G16-')])==10
assert len([d for d in compositions if d['id'].startswith('D16-')])==10
assert len([h for h in joint if h['id'].startswith('HYP-G15-')])==13
assert len([c for c in compositions if c['id'].startswith('D15-')])==11
assert len([h for h in joint if h['id'].startswith('HYP-G14-')])==12
assert len([c for c in compositions if c['id'].startswith('D14-')])==10
assert len([h for h in joint if h['id'].startswith('HYP-G13-')])==12
assert len([c for c in compositions if c['id'].startswith('D13-')])==8
assert len([o for o in objects if o.get('batch')=='v1_17'])==40
assert len([e for e in edges if e['id'].startswith('G17-')])==77
assert len([h for h in joint if h['id'].startswith('HYP-G17-')])==12
assert len([d for d in compositions if d['id'].startswith('D17-')])==10
assert len([o for o in objects if o.get('batch')=='v1_18'])==32
assert len([e for e in edges if e['id'].startswith('G18-')])==70
assert len([o for o in objects if o.get('batch')=='v1_19'])==20
assert len([e for e in edges if e['id'].startswith('G19-')])==41
assert len([o for o in objects if o.get('batch')=='v1_20'])==20
assert len([e for e in edges if e['id'].startswith('G20-')])==44
assert len([o for o in objects if o.get('batch')=='v1_21'])==16
assert len([e for e in edges if e['id'].startswith('G21-')])==28
assert len([o for o in objects if o.get('batch')=='v1_22'])==18
assert len([e for e in edges if e['id'].startswith('G22-')])==33
assert len([o for o in objects if o.get('batch')=='v1_23'])==20
assert len([o for o in objects if o.get('batch')=='v1_24'])==18
assert len([o for o in objects if o.get('batch')=='v1_25'])==19
assert len([o for o in objects if o.get('batch')=='v1_26'])==13
assert len([e for e in edges if e['id'].startswith('G26-')])==33
assert len([o for o in objects if o.get('batch')=='v1_27'])==13
assert len([e for e in edges if e['id'].startswith('G27-')])==58
assert len([h for h in joint if h['id'].startswith('HYP-G27-')])==11
assert len([d for d in compositions if d['id'].startswith('D27-')])==12
assert len([h for h in joint if h['id'].startswith('HYP-G26-')])==5
assert len([d for d in compositions if d['id'].startswith('D26-')])==6
assert len([e for e in edges if e['id'].startswith('G25-')])==42
assert len([h for h in joint if h['id'].startswith('HYP-G25-')])==9
assert len([d for d in compositions if d['id'].startswith('D25-')])==8
assert len([e for e in edges if e['id'].startswith('G24-')])==43
assert len([h for h in joint if h['id'].startswith('HYP-G24-')])==7
assert len([d for d in compositions if d['id'].startswith('D24-')])==7
assert len([e for e in edges if e['id'].startswith('G23-')])==42
assert len([h for h in joint if h['id'].startswith('HYP-G23-')])==7
assert len([d for d in compositions if d['id'].startswith('D23-')])==8
assert len([h for h in joint if h['id'].startswith('HYP-G22-')])==7
assert len([d for d in compositions if d['id'].startswith('D22-')])==7
assert len([h for h in joint if h['id'].startswith('HYP-G21-')])==6
assert len([d for d in compositions if d['id'].startswith('D21-')])==6
assert len([h for h in joint if h['id'].startswith('HYP-G20-')])==8
assert len([d for d in compositions if d['id'].startswith('D20-')])==8
assert len([h for h in joint if h['id'].startswith('HYP-G19-')])==7
assert len([d for d in compositions if d['id'].startswith('D19-')])==7
assert len([h for h in joint if h['id'].startswith('HYP-G18-')])==11
assert len([d for d in compositions if d['id'].startswith('D18-')])==11
assert all(e['from'] in ids and e['to'] in ids for e in edges)
assert all(set(e.get('requires_joint_inputs',[]))<=ids for e in edges)
assert all(set(h.get('inputs',[])+h.get('outputs',[]))<=ids for h in joint)
assert all(o.get('scope') in {'mathematical_object_or_defined_operator','mathematical_structure_or_morphism','mathematical_derived_by_finite_group_composition'} for o in objects)
assert all(o.get('source_kind')!='statement_locator' and 'claim_locator' not in o['id'] for o in objects)
assert all(o['id'].startswith('geo:') for o in objects)
for e in edges:
 relation=e['relation'].upper()
 assert not any(s in relation for s in ('PHYSICAL_DECAY','CITATION_EDGE','CLAIM_WITNESS','SOURCE_POINTER','PROOF_DEPENDENCY','MEASURED_BRANCHING'))
 assert e.get('conditions_preserved') is True
for h in joint:assert h.get('kind') and h.get('verification')
assert not any(o['id'].startswith(('p1:','p2:','p3:','p4:','p5:','p6:','p7:')) for o in objects)

# Validate the actual export layers (no fake incidence edges or a copied theorem DAG).
ns={'g':'http://graphml.graphdrawing.org/xmlns'}
def graph_counts(path):
 t=ET.parse(ROOT/path).getroot()
 return (len(t.findall('.//g:node',ns)),len(t.findall('.//g:edge',ns)))
assert graph_counts('graph/mathematical_structure_network.graphml')==(862,1392)
assert graph_counts('graph/batch18_hurwitz_cellular_hodge_relatives.graphml')[1]==54
assert len([o for o in objects if o.get('batch')=='v1_32'])==13
assert len([e for e in edges if e['id'].startswith('G32-')])==72
assert len([h for h in joint if h['id'].startswith('HYP-G32-')])==57
assert len([c for c in compositions if c['id'].startswith('D32-')])==12
assert graph_counts('graph/batch21_S3_closure_exact_scoped_links.graphml')[1]==72
assert len([o for o in objects if o.get('batch')=='v1_31'])==17
assert len([e for e in edges if e['id'].startswith('G31-')])==41
assert len([h for h in joint if h['id'].startswith('HYP-G31-')])==10
assert len([d for d in compositions if d['id'].startswith('D31-')])==9
assert graph_counts('graph/batch20_hopf_su3_group_invariants.graphml')[1]==41
assert len(load('batch20_current_tex_witnesses.json')['source_witnesses'])==11
assert len([o for o in objects if o.get('batch')=='v1_30'])==14
assert len([e for e in edges if e['id'].startswith('G30-')])==40
assert len([h for h in joint if h['id'].startswith('HYP-G30-')])==8
assert len([d for d in compositions if d['id'].startswith('D30-')])==8
assert graph_counts('graph/batch19_petersen_su3_invariant_bridges.graphml')[1]==40
assert len(load('batch19_current_tex_witnesses.json')['source_witnesses'])==12
assert len(load('finite_invariant_geometry_v130_instance.json')['petersen']['all_32_supports'])==32
assert graph_counts('graph/batch18_hurwitz_Q8_weighted_three_graph.graphml')==(3,3)
assert len([o for o in objects if o.get('batch')=='v1_29'])==19
assert len([e for e in edges if e['id'].startswith('G29-')])==54
assert len([h for h in joint if h['id'].startswith('HYP-G29-')])==9
assert len([d for d in compositions if d['id'].startswith('D29-')])==10
assert graph_counts('graph/batch17_icosahedral_hopf_pair_coefficients.graphml')[1]==51
assert len([o for o in objects if o.get('batch')=='v1_28'])==14
assert len([e for e in edges if e['id'].startswith('G28-')])==51
assert len([h for h in joint if h['id'].startswith('HYP-G28-')])==10
assert len([d for d in compositions if d['id'].startswith('D28-')])==9
assert graph_counts('graph/batch5_finite_geometry_bridges.graphml')[1]==68
assert graph_counts('graph/batch7_mckay_clifford_bridges.graphml')[1]==70
assert graph_counts('graph/batch8_q8_triality_mckay_bridges.graphml')[1]==41
assert graph_counts('graph/batch9_q8_hopf_e8_axis_bridges.graphml')[1]==44
assert graph_counts('graph/batch11_C3_holonomy_geometry_bridges.graphml')[1]==33
assert graph_counts('graph/batch12_A5_Q8_C3_spectral_bridges.graphml')==(33,42)
assert graph_counts('graph/batch13_Petersen_A5_600_E8_fourspace.graphml')[1]==43
assert graph_counts('graph/batch13_actual_15x15_signed_intertwiner.graphml')==(30,180)
assert graph_counts('graph/batch14_Petersen_A5_five_six_completions.graphml')[1]==42
assert graph_counts('graph/batch14_actual_wedge6_matrix.graphml')[0]==25
assert graph_counts('graph/batch14_actual_axis5_matrix.graphml')[0]==30
assert graph_counts('graph/batch12_actual_C3_on_15_axes.graphml')==(15,15)
assert graph_counts('graph/batch12_actual_C3_on_60_projective_points.graphml')==(60,60)
assert graph_counts('graph/batch11_3K5_three_parallel_edge_multigraph.graphml')==(5,30)
assert graph_counts('graph/batch11_15axis_matching_voltage_graph.graphml')==(15,90)
assert graph_counts('graph/batch11_120_to_15_to_5_vertex_fibres.graphml')==(140,135)
assert graph_counts('graph/batch10_axis15_cubic_geometry_bridges.graphml')[1]==28
assert graph_counts('graph/batch10_local_weight2_matchings_and_five_cores.graphml')==(50,105)
assert graph_counts('graph/batch10_cubic_gram_15axis.graphml')==(15,105)
assert load('axis15_holonomy_v122_instance.json')['covering_tower']['regular_cover_degrees']==[8,3,24]
assert load('axis15_holonomy_v122_instance.json')['all_connection_choices']['number_flat_connections']==81
assert load('axis15_cubic_v121_instance.json')['automorphism_group']['order']==360
assert graph_counts('graph/batch9_common_axis15_operators.graphml')==(15,105)
assert graph_counts('graph/batch9_E8_axis15_weighted_2design.graphml')==(230,645)
assert graph_counts('graph/batch9_triality24_to_hopf15.graphml')==(39,24)
assert graph_counts('graph/batch9_triality_axis12_weighted_hypergraph.graphml')==(116,312)
assert graph_counts('graph/batch8_q8_triality_24orbit_weighted.graphml')==(24,168)
assert graph_counts('graph/batch8_q8_triality_104hyperedges.graphml')==(128,312)
assert graph_counts('graph/affine_mckay_Q8_D4.graphml')==(5,4)
assert graph_counts('graph/affine_mckay_2T.graphml')==(7,6)
assert graph_counts('graph/affine_mckay_2O.graphml')==(8,7)
assert graph_counts('graph/affine_mckay_2I.graphml')==(9,8)
assert graph_counts('graph/batch4_bihopf_reciprocal_bridges.graphml')[1]==78
assert graph_counts('graph/batch3_spin4_clifford_bridges.graphml')[1]==68
assert graph_counts('graph/hopf_30_direction_graph.graphml')==(30,180)
assert graph_counts('graph/hopf_15_axis_K33333.graphml')==(15,90)
assert graph_counts('graph/exceptional_600cell_exact.graphml')==(120,720)
assert graph_counts('graph/petersen_c6_axis_index.graphml')==(10,15)
for filename in ROOT.glob('graph/c6_axis_covers/*graphml'):ET.parse(filename)
assert len(list(ROOT.glob('graph/c6_axis_covers/*graphml')))==20
instance=load('hopf_quotient_exact_instance.json')
assert len(instance['hopf_directions'])==30 and len(instance['hopf_axes'])==15
assert len(instance['graph_30']['edges'])==180 and len(instance['graph_15']['edges'])==90
assert len(instance['five_octahedra'])==5
assert len(load('hopf_commuting_diagrams.json'))==6
assert len(load('primary_source_witnesses.json'))>=29
reprdata=load('spin4_exact_representation_instance.json')
assert reprdata['first_nonconstant_scalar_modes']['2I']=={'n':12,'lambda_R2':168,'multiplicity':13,'spherical_design_strength':11}
assert reprdata['twin_marking']['angle_between_degree12_invariant_lines_cos2']=='25/256'
assert reprdata['twin_marking']['twin_mean_operator_nonidempotence']=='A_H^2-A_H=-(231/1024)P_H'
sources=load('primary_source_witnesses.json')
for key in sources:
 if key.startswith('g13:'):
  w=sources[key]
  assert w.get('file','').startswith('Paper1')
  assert len(w.get('tex_sha256',''))==64 and isinstance(w.get('line'),int)

for key in ['g14:round','g14:diagonal','g14:borel','g14:clifford','g14:molien','g14:spectra','g14:twins','g14:cubature','g14:spinhalf','g14:p2f','g14:p1c']:
 w=sources[key]
 assert len(w['tex_sha256'])==64 and w['line']>0
assert len([n for n in objects if n.get('source_kind')=='statement_locator'])==0
tex=__import__('hashlib').sha256((ROOT/'data'/'bihopf_integral_geometry_instance.json').read_bytes()).hexdigest()
assert len(tex)==64
for o in objects:
 if o.get('batch')=='v1_15':
  w=o['witness'];assert w['file']=='Paper1C-M8Geometry-v1_142.tex' and w['tex_sha256']=='d26e8cd74bf2eae998a04184e5026edd52d09331ebff5371aa548b1fa3b25fbc' and w['line']>0
for h in joint:
 if h['id'].startswith('HYP-G15-'):assert h['verification']=='EXACT_SYMBOLIC_INTEGRAL_LATTICE_AND_GYSIN_CERTIFICATE'
for e in edges:
 if e['id'].startswith('G15-'):assert e['verification']=='EXACT_SYMBOLIC_AND_PRINCIPAL_BUNDLE_ARGUMENT'
assert load('bihopf_integral_geometry_instance.json')['exchange_pair']['chern_lattice_index']==2
assert load('bihopf_integral_geometry_instance.json')['combined_exchange']['T4_degree']==4
for o in objects:
 if o.get('batch')=='v1_16':
  w=o['witness'];assert w['file']=='Paper1B-ExceptionalGeometry-v1_14.tex' and w['tex_sha256']=='54f8c52f2b790148832eff12eae0a43957a27b0b9f2b38939dab0b378c4dbfb2' and w['line']>0
assert len(load('finite_geometry_v116_instance.json')['transporter_24cells']['sets'])==25
assert graph_counts('graph/batch6_golden_e8_triality_bridges.graphml')[1]==77
assert graph_counts('graph/golden_e8_root_addition_240.graphml')==(240,6720)
assert graph_counts('graph/golden_e8_triality_192.graphml')==(192,3072)
assert len(load('golden_e8_v117_instance.json')['roots_240'])==240
for name in ('verify_parent_v131_integrity_v132.py','verify_batch21_v132.py','verify_batch20_v131.py','verify_batch19_v130.py','verify_batch18_v129.py','verify_batch17_v128.py','verify_batch16_v127.py','verify_twisted25_v127.py','verify_batch15_v126.py','verify_petersen_five_six_v125.py','verify_parent_v124_integrity_v125.py','verify_petersen_a5_bridge_v124.py','verify_inherited_data_integrity_v124.py','verify_a5_q8_projector_v123.py','verify_axis15_holonomy_v122.py','verify_axis15_cubic_v121.py','verify_q8_hopf_e8_v120.py','verify_q8_triality_v119.py','verify_mckay_clifford_v118.py','verify_golden_e8_v117.py','verify_exceptional_geometry.py','verify_hopf_geometry.py','verify_hopf_metric.py','verify_spin4_representations.py','verify_bihopf_integral_geometry.py','verify_finite_geometry_v116.py','verify_graph_exports.py'):
 if "--fast" in sys.argv and name not in ("verify_parent_v131_integrity_v132.py","verify_batch21_v132.py","verify_batch20_v131.py","verify_batch19_v130.py","verify_batch18_v129.py","verify_batch17_v128.py","verify_batch15_v126.py","verify_petersen_five_six_v125.py","verify_parent_v124_integrity_v125.py","verify_petersen_a5_bridge_v124.py","verify_graph_exports.py","verify_inherited_data_integrity_v124.py"):
  continue
 r=subprocess.run([sys.executable,str(ROOT/name)],text=True,capture_output=True,check=True)
 print(name+':\n'+r.stdout.rstrip())
print('PASS: 862 strictly mathematical objects, 1392 typed relations, 242 AND-input bundles, 183 derived compositions')
print('PASS: no theorem/claim locator nodes or physical transitions in geometry graph')
print('PASS: exact v1_32 regeneration, inherited v1_24–v1_31 fast certificates, and cumulative graph invariants; use without --fast for the full historical suite' if '--fast' in sys.argv else 'PASS: all cumulative and newly derived exact/symbolic geometry certificates')
