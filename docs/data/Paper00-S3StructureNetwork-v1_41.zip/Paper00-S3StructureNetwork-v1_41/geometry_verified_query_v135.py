#!/usr/bin/env python3
"""Explore the v1_35 effective mathematical map replay and original source-owner boundary separately."""
import pathlib,json,argparse
R=pathlib.Path(__file__).resolve().parent
J=lambda f:json.loads((R/f).read_text())
D=J('data/v135_verified_frontier_status.json');B=J('data/v135_source_owner_frontier.json')
p=argparse.ArgumentParser();p.add_argument('--summary',action='store_true');p.add_argument('--owner-pending',action='store_true');p.add_argument('--edge',default=None);a=p.parse_args()
if a.summary or not(a.owner_pending or a.edge):
 print('v1_35 CONDITIONAL FINITE MATHEMATICAL REPLAY:', D['replay_count'],'/',D['original_frontier_count'])
 print('TARGETED SOURCE-OWNER FRONTIERS:',D['source_boundary_pending_count'])
 print('PHYSICAL OWNER/ACTION/THEOREM CLAIMS PROMOTED:',D['whole_source_theorems_or_physical_premises_promoted'])
 print('Topology: 862 objects, 1392 relations, 242 guarded AND relations, 183 compositions — unchanged')
if a.owner_pending:
 for id,obj in B['boundaries'].items():
  print(id,obj['target']);print('  NEEDS:',obj['earliest_remaining_source_edge'])
if a.edge:
 assert a.edge in D['relations'], 'The requested relation is not among the 24 scoped maps'
 print(json.dumps(D['relations'][a.edge],indent=2,ensure_ascii=False))
 if a.edge in B['boundaries']:print(json.dumps(B['boundaries'][a.edge],indent=2,ensure_ascii=False))
