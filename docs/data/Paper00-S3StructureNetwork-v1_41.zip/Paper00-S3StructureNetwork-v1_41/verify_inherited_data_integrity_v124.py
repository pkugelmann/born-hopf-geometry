#!/usr/bin/env python3
"""Check that immutable exact input instances from validated v1_23 are unchanged.
Not a substitute for running all historical exact verifiers; --fast uses it as a regression integrity check.
"""
import pathlib,json,hashlib
R=pathlib.Path(__file__).resolve().parent
rec=json.loads((R/'reports/INHERITED_V123_INSTANCE_HASHES.json').read_text())
for x in rec['files']:
 p=R/x['path']
 assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==x['sha256'],x['path']
print('PASS: inherited immutable v1_23 mathematical instances',len(rec['files']),'SHA256 matches')
