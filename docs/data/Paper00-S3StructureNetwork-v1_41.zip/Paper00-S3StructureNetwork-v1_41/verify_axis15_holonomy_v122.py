#!/usr/bin/env python3
"""Independently rebuild the 2T/Q8 cover, matching parity, C3 holonomy and Aut(T) split."""
from __future__ import annotations
import json,pathlib,sys,collections,xml.etree.ElementTree as ET
ROOT=pathlib.Path(__file__).resolve().parent
from scripts.axis15_holonomy_v122 import build
expected=json.loads((ROOT/'data/axis15_holonomy_v122_instance.json').read_text())
computed=build()
assert computed==expected,'The release instance is not regenerated EXACTLY by the quaternion group / tensor verifier.'
cov=expected['covering_tower']; assert cov['vertex_fibres']==[120,15,5]
assert cov['edge_orbits']==[720,90,30] and cov['regular_cover_degrees']==[8,3,24]
assert len(expected['edge_orbits_2T'])==30 and sum(x['size'] for x in expected['edge_orbits_2T'])==720
assert all(x['size']==24 and len(x['edges_600'])==24 and len(x['axis_edge_matching'])==3 for x in expected['edge_orbits_2T'])
assert expected['all_30_2T_edge_orbit_matchings_equal_weight2_E8_tensor_matchings']
assert len(expected['Levi_Civita_relative_transport']['ordered_quadruple_checks'])==120
assert expected['all_connection_choices']['number_total_connections']==59049
assert expected['all_connection_choices']['number_flat_connections']==81
assert expected['all_connection_choices']['number_distinct_curvature_patterns']==729
assert expected['all_connection_choices']['connections_per_curvature_pattern']==81
assert expected['weighted_tensor_automorphisms']['split_group_isomorphism']=='Aut(T) ~= C3 semidirect_(sign) S5'
ns={'g':'http://graphml.graphdrawing.org/xmlns'}
def counts(rel):
 x=ET.parse(ROOT/'graph'/rel).getroot()
 return len(x.findall('.//g:node',ns)),len(x.findall('.//g:edge',ns))
assert counts('batch11_3K5_three_parallel_edge_multigraph.graphml')==(5,30)
import networkx as nx
multi=nx.read_graphml(ROOT/'graph/batch11_3K5_three_parallel_edge_multigraph.graphml',force_multigraph=True)
assert multi.number_of_nodes()==5 and multi.number_of_edges()==30
assert all(multi.number_of_edges(str(a),str(b))==3 for a in range(5) for b in range(a+1,5))
assert all(len({data['third_core_label'] for _,data in multi.get_edge_data(str(a),str(b)).items()})==3
    for a in range(5) for b in range(a+1,5))
assert counts('batch11_15axis_matching_voltage_graph.graphml')==(15,90)
assert counts('batch11_120_to_15_to_5_vertex_fibres.graphml')==(140,135)
assert counts('batch11_C3_holonomy_geometry_bridges.graphml')[1]==33
print('PASS v1_22: exact 600-cell/right-2T covering, Q8 intermediary and 30 tensor matching equalities')
print('PASS v1_22: alternating 120-quadruple transport, 59049 matching-connection enumeration and Bianchi')
print('PASS v1_22: split Aut(T)=C3 semidirect_sign S5 and all four explicit geometric graph exports')
