#!/usr/bin/env python3
"""Batch 24: independent exact guarded-map mathematics (G32-052/056/072).

No physical event, whole-owner GP3 comparison, scalar-port occurrence,
source-selected Hamiltonian or rest-mass spectrum is certified by these tests.
Run: python verify_scoped_math_v135.py --check  (recomputes every certificate)
"""
from __future__ import annotations
from itertools import product
from fractions import Fraction as F
from pathlib import Path
import argparse, json, hashlib, os
import sympy as S
R=Path(__file__).resolve().parent
I=S.I

def qmul(a,b):
    a0,a1,a2,a3=a; b0,b1,b2,b3=b
    return (a0*b0-a1*b1-a2*b2-a3*b3,
            a0*b1+a1*b0+a2*b3-a3*b2,
            a0*b2-a1*b3+a2*b0+a3*b1,
            a0*b3+a1*b2-a2*b1+a3*b0)

def qconj(a):return (a[0],-a[1],-a[2],-a[3])
def dot(a,b):return sum(i*j for i,j in zip(a,b))
def qe(e):return (F(1,2),)+tuple(F(x,2) for x in e)
def jmat(A):return [[str(x) for x in row] for row in A.tolist()]

def color_family():
    u=(1,1,1)
    Tminus=((1,-1,-1),(-1,1,-1),(-1,-1,1))
    Tplus=((-1,1,1),(1,-1,1),(1,1,-1))
    cube=set(product((1,-1),repeat=3))
    assert {u,(-1,-1,-1)}|set(Tminus)|set(Tplus)==cube
    assert len({u,(-1,-1,-1)}|set(Tminus)|set(Tplus))==8
    Q=[qe(u)]+[qe(t) for t in Tminus]
    G=S.Matrix([[S.Rational(dot(a,b)) for b in Q] for a in Q]);assert G==S.eye(4)
    rot=[qmul(qconj(qe(u)),q) for q in Q]
    assert rot[0]==(F(1),F(0),F(0),F(0))
    assert all(v[0]==0 for v in rot[1:])
    assert S.Matrix.hstack(*[S.Matrix(v) for v in rot]).det() in (1,-1)
    unit=[(F(1),F(0),F(0),F(0)),(F(0),F(1),F(0),F(0)),(F(0),F(0),F(1),F(0)),(F(0),F(0),F(0),F(1))]
    mult=S.Matrix.hstack(*[S.Matrix(qmul(qconj(qe(u)),a)) for a in unit])
    assert mult.det()==1 and mult.T*mult==S.eye(4)
    D=S.diag(-1,0,1);X=S.zeros(3)
    for j in range(3):X[(j+1)%3,j]=1
    assert X**3==S.eye(3) and D==D.H
    projectors=(D*(D-S.eye(3))/2,S.eye(3)-D**2,D*(D+S.eye(3))/2)
    U=[]
    for i in range(3):
        for j in range(3):
            M=X**((i-j)%3)*projectors[j]
            target=S.zeros(3);target[i,j]=1
            assert M==target
            U.append(M)
    w=(-1+S.sqrt(-3))/2
    Z=S.diag(1,w,w*w)
    assert S.simplify(w**3-1)==0
    assert all(S.simplify(x)==0 for x in (Z*X-w*X*Z))
    for j in range(3):
        P=sum((w**(-j*b)*Z**b for b in range(3)), S.zeros(3))/3
        assert all(S.simplify(x)==0 for x in P-projectors[j])
    # 81 explicit 9x9 matrix units, with source-aligned commuting factor actions.
    units9=[]
    for a in U:
        for b in U:
            units9.append(S.kronecker_product(a,b))
    assert len(units9)==81
    assert len({(int(next((i for i in range(9) if m[i,j] !=0),-1)),j)
                for m in units9 for j in range(9) if any(m[i,j]!=0 for i in range(9))})==81
    assert all(sum(1 for x in M if x!=0)==1 for M in units9)
    assert all(S.kronecker_product(X,S.eye(3))*S.kronecker_product(S.eye(3),B)
               ==S.kronecker_product(S.eye(3),B)*S.kronecker_product(X,S.eye(3)) for B in U)
    assert all(S.kronecker_product(D,S.eye(3))*S.kronecker_product(S.eye(3),B)
               ==S.kronecker_product(S.eye(3),B)*S.kronecker_product(D,S.eye(3)) for B in U)
    # The unnormalised scalar trace distinguishes unmarked ampliations despite identical normalised traces.
    trace1=S.trace(S.eye(9));trace2=S.trace(S.eye(18))
    assert (trace1,trace2)==(9,18)
    assert S.trace(S.kronecker_product(X,S.eye(3)))/9 == S.trace(S.kronecker_product(X,S.eye(6)))/18
    return {
      'input':'rooted oriented u+=(+,+,+), exact 8-point Hurwitz quaternion link and source color/family factor-local operator grammar',
      'exact_hurwitz_frame_gram':jmat(G),'left_quaternion_map_det':str(mult.det()),
      'opposite_trimer_imaginary_images':[[str(x) for x in v] for v in rot[1:]],
      'trimer_cardinalities':{'color':len(Tminus),'complementary_family':len(Tplus)},
      'color_trimer_generated_matrix_units':len(U),'joint_independent_matrix_units':len(units9),
      'joint_simple_module_dimension':9, 'selected_algebra_complex_dimension':81,
      'family_weyl_clock_relation':'ZX=omega XZ, omega^3=1 verified in Q(sqrt(-3))',
      'unnormalised_identity_trace_k1_k2':[str(trace1),str(trace2)],
      'mathematical_conclusion':'For the source-fixed axial branch and the stipulated independent factor-local grammar, the two rank-three supports yield C^3 tensor C^3 and full commuting M3 tensor M3=M9, up to unitary equivalence.',
      'not_proved':'GP3 proper whole-candidate comparison for each physical amplified realization; independently occurring scalar/action/test ports, including ordinary unnormalised trace, may distinguish k>1.'}

def e56_role():
    x=192**S.Rational(1,3)
    assert S.simplify(x**3-192)==0
    Rop=x*S.eye(3)
    inv=Rop.inv();direct=Rop;gram=Rop.H*Rop
    assert inv*direct==S.eye(3)
    assert all(S.simplify(y)==0 for y in gram-x*x*S.eye(3))
    Sig=S.diag(1/x,x,x*x)
    assert all(S.simplify(y)==0 for y in (S.diag(inv[0,0],direct[0,0],gram[0,0])-Sig))
    assert S.simplify(Sig.det()-x*x)==0
    gap=S.simplify((x**6-1)/(x**4-1))
    assert abs(float(gap)-33.3105115561)<1e-9
    E=S.Symbol('E56',positive=True,real=True)
    assert (E*Sig).shape==(3,3)
    # Deliberately show algebraic compatibility but absence of constructor ownership for independent kappa.
    k=S.Symbol('kappa56',positive=True,real=True)
    assert S.simplify((k*E*Sig)[0,0]/(E*Sig)[0,0]-k)==0
    return {'input':'source-defined depth-one response jet (R^+, R, R^dagger R), R=x I3, x^3=192; positive shell E56',
            'response_jet_ports':3,'response_jet_exact_diagonal':['x^-1','x','x^2'],
            'defining_polynomial':'x^3-192=0','scalar_energy_formula':'E56 * diag(x^-1,x,x^2)',
            'gap_ratio_value':format(float(gap),'.12f'),
            'rank':3,'determinant_role_operator':'x^2','extra_kappa_dimensional_test':'kappa56 E56 T has same energy dimension for any kappa56>0',
            'mathematical_conclusion':'Unique output of the declared triple-port depth-one response grammar and the defined row-energy insertion, conditional on no additional licensed independent scalar normalization port.',
            'not_proved':'Global source-word exhaustion of all possible independently generated dimensionless normalization ports; family projector matching; neutrino physical pole/rest-mass comparison.'}

def meson_block():
    z=S.zeros(3);E=lambda i,j:S.Matrix(3,3,lambda a,b:1 if (a,b)==(i,j) else 0)
    I3=S.eye(3);I2=S.eye(2)
    T=[E(0,1)+E(1,0),-I*(E(0,1)-E(1,0)), E(0,0)-E(1,1),
       E(0,2)+E(2,0),-I*(E(0,2)-E(2,0)),E(1,2)+E(2,1),
       -I*(E(1,2)-E(2,1)),(E(0,0)+E(1,1)-2*E(2,2))/S.sqrt(3)]
    v=S.zeros(9,1)
    for i in range(3):v[3*i+i]=1
    P=v*v.H/3
    assert P*P==P and P.H==P and S.trace(P)==1
    Q=S.eye(9)-P
    for t in T:
        c=S.kronecker_product(t,I3)-S.kronecker_product(I3,t.T)
        assert c*v==S.zeros(9,1) and c*P==P*c
    p=S.diag(1,0); block=S.kronecker_product(P,p)
    assert block*block==block and S.trace(block)==1
    def hamiltonian(A,B):return S.kronecker_product(P,A)+S.kronecker_product(Q,B)
    B=S.diag(11,13)
    H0=hamiltonian(S.diag(2,5),B)
    H7=hamiltonian(S.diag(9,5),B)
    assert H0.H==H0 and H7.H==H7
    assert H0*block==block*H0 and H7*block==block*H7
    assert block*H0*block==2*block and block*H7*block==9*block
    assert S.kronecker_product(P,I2)*H0==H0*S.kronecker_product(P,I2)
    for t in T:
        c=S.kronecker_product(t,I3)-S.kronecker_product(I3,t.T)
        big=S.kronecker_product(c,I2)
        assert H0*big==big*H0 and H7*big==big*H7
    Amix=S.Matrix([[2,1],[1,5]])
    Hmix=hamiltonian(Amix,B)
    assert Hmix.H==Hmix and Hmix*block!=block*Hmix
    assert block*Hmix*block==2*block
    eig=list(Amix.eigenvals())
    assert set(eig)=={(7-S.sqrt(13))/2,(7+S.sqrt(13))/2}
    for t in T:
        c=S.kronecker_product(t,I3)-S.kronecker_product(I3,t.T)
        assert Hmix*S.kronecker_product(c,I2)==S.kronecker_product(c,I2)*Hmix
    return {'input':'3 tensor anti-3 color space and supplied selfadjoint relative Hamiltonian; sector projectors must reduce H for a true spectral sector',
            'color_generators_verified':8,'singlet_projector_rank':1,'octet_complement_rank':8,
            'sector_H0_eigenvalue':2,'sector_H7_eigenvalue':9,
            'H0_H7_both_color_and_sector_invariant':True,
            'nonreducing_countermodel':'Hmix color-invariant, [Hmix, Psinglet tensor PJ] !=0, compression level 2 but true singlet eigenvalues (7±sqrt(13))/2',
            'nonreducing_singlet_eigenvalues':['(7-sqrt(13))/2','(7+sqrt(13))/2'],
            'mathematical_conclusion':'For the specified reducing, selfadjoint H_L-E0,L, finite relative sector energies are eigenvalues of P H P restricted to ran(P), with exact transfer exp(-t PHP) on that reducing subspace.',
            'not_proved':'Action-selected H_L, physical pole/root readout, coefficient values, or sector reduction if Hamiltonian is not certified to preserve the given JPC/flavor labels.'}

def compute():
  checks={'052':color_family(),'056':e56_role(),'072':meson_block()}
  return {'release':'v1_35','exact_math_scope':'three remaining G32-052/056/072 conditional mathematical submaps only',
          'new_conditional_replayed_ids':['G32-052','G32-056','G32-072'],
          'new_conditional_replayed_count':3,'source_theorems_promoted':0,'physical_actions_promoted':0,
          'owner_boundary_ids_still_open':['G32-052','G32-056','G32-072'],
          'checks':checks}

def run():
  p=argparse.ArgumentParser();p.add_argument('--write',action='store_true');p.add_argument('--check',action='store_true')
  p.add_argument('--source-dir',type=Path,help='optional directory containing authoritative current .tex files (verify labels/hashes against stored source ledger)')
  a=p.parse_args();out=R/'data/v135_scoped_math_replays.json';result=compute()
  if a.write:out.write_text(json.dumps(result,indent=2,ensure_ascii=False,sort_keys=True)+'\n')
  if a.check:
    assert json.loads(out.read_text())==result
  if a.source_dir:
    w=json.loads((R/'data/v135_source_anchor_ledger.json').read_text())
    for r in w['anchors']:
      path=a.source_dir/r['tex_file'];data=path.read_bytes()
      assert hashlib.sha256(data).hexdigest()==r['sha256'],r['tex_file']
      assert ('\\label{'+r['label']+'}').encode() in data,(r['tex_file'],r['label'])
    print('PASS current external TeX hash and label identities:',len(w['anchors']))
  print('PASS exact Hurwitz source-frame and M9 algebra; terminal x^3=192 response jet; full SU3 meson compression and nonreducing countermodel.')
  print('No GP3 whole owner, extra-kappa nonoccurrence, physical meson H, or rest mass promoted.')
if __name__=='__main__':run()
