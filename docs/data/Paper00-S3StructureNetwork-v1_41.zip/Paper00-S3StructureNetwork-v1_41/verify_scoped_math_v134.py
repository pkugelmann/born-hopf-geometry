#!/usr/bin/env python3
"""Batch23 independent exact finite mathematics for four previously guarded S3 graph maps.

Only conditional mathematical maps are replayed. No action occurrence, generation
selection, physical mass, cosmological history or source theorem is proved.
Uses arithmetic in Z[sqrt(2)]/2, integer roots and CAR, and exact SymPy.
"""
from __future__ import annotations
import itertools,json,math,pathlib,sys
from collections import Counter
import numpy as np
import sympy as sp
R=pathlib.Path(__file__).resolve().parent
OUT=R/'data/v134_scoped_math_replays.json'
checks={}
def check(num,statement,certificate,remaining,boundary):
 assert num not in checks
 checks[num]={'relation_id':'G32-'+num,'status':'INDEPENDENT_CONDITIONAL_MATHEMATICAL_MAP_REPLAY',
              'mathematical_submap':statement,'exact_certificate':certificate,
              'undischarged_source_or_physical_conditions':remaining,
              'scope_boundary':boundary}

# G32-061: exact 48-element binary octahedral quaternion group.
# Each real coefficient represents (r+s sqrt(2))/2; all roots stay in this ring.
ZERO=(0,0)
def V(vals):return tuple(vals)
def unit_at(j,x):
 a=[ZERO]*4;a[j]=x;return tuple(a)
def plus(x,y):return (x[0]+y[0],x[1]+y[1])
def minus(x,y):return (x[0]-y[0],x[1]-y[1])
def prod_c(x,y):return (x[0]*y[0]+2*x[1]*y[1],x[0]*y[1]+x[1]*y[0])
def prod_quat(x,y):
 a,b,c,d=x;e,f,g,h=y
 terms=[
  ( (a,e,1),(b,f,-1),(c,g,-1),(d,h,-1)),
  ( (a,f,1),(b,e,1),(c,h,1),(d,g,-1)),
  ( (a,g,1),(b,h,-1),(c,e,1),(d,f,1)),
  ( (a,h,1),(b,g,1),(c,f,-1),(d,e,1))]
 out=[]
 for row in terms:
  num=[0,0]
  for q,r,sgn in row:
   rr,ss=prod_c(q,r);num[0]+=sgn*rr;num[1]+=sgn*ss
  assert all(n%2==0 for n in num),('not in ring',x,y,num)
  out.append((num[0]//2,num[1]//2))
 return tuple(out)
def inv_quat(x):return (x[0],)+tuple((-i,-j) for i,j in x[1:])
T=set()
for j in range(4):
 for sgn in [-1,1]:T.add(unit_at(j,(2*sgn,0)))
for signs in itertools.product([-1,1],repeat=4):T.add(tuple((a,0) for a in signs))
O=set(T)
for a,b in itertools.combinations(range(4),2):
 for x,y in itertools.product([-1,1],repeat=2):
  q=[ZERO]*4;q[a]=(0,x);q[b]=(0,y);O.add(tuple(q))
assert len(T)==24 and len(O)==48
idq=unit_at(0,(2,0))
assert idq in T and all(prod_quat(q,inv_quat(q))==idq for q in O)
assert all(prod_quat(q,r) in O for q in O for r in O)
assert all(prod_quat(q,r) in T for q in T for r in T)
assert all(prod_quat(prod_quat(q,r),inv_quat(q)) in T for q in O for r in T)
par={q:(1 if q in T else -1) for q in O}
assert all(par[prod_quat(q,r)]==par[q]*par[r] for q in O for r in O)
comm={prod_quat(prod_quat(prod_quat(q,r),inv_quat(q)),inv_quat(r)) for q in O for r in O}
sub={idq};changed=True
while changed:
 new=sub|comm|{prod_quat(a,b) for a in sub for b in comm}
 changed=(new!=sub);sub=new
assert sub==T
S=sp.Matrix([[0,1],[1,0]]);Pm=(sp.eye(2)-S)/2;Pp=(sp.eye(2)+S)/2
assert Pm**2==Pm and Pp**2==Pp and Pm*Pp==sp.zeros(2)
assert Pm.rank()==1 and sp.kronecker_product(Pm,sp.eye(3)).rank()==3
check('061','Exact marked binary-octahedral quotient action and odd-line ⊗ family-three projector',
 {'binary_tetrahedral_order':24,'binary_octahedral_order':48,'quotient_order':2,
  'derived_subgroup_equals_2T':sub==T,'all_group_products_closed':True,'coset_sign_homomorphism':True,
  'quotient_swap_matrix':[[0,1],[1,0]],'Pminus_matrix':[['1/2','-1/2'],['-1/2','1/2']],
  'rank_Pminus':1,'rank_odd_tensor_G3':3,'odd_line_action_on_nontrivial_coset':-1},
 ['inheritance of the actual selected 2T/2O exceptional-support branch',
  'separate Paper V-A generated neutral line and rooted rank-three G family trimer'],
 'No heavy-neutrino Hamiltonian, pole mass, K16 owner or physical packet selected.')

# G32-070: 240/126/72 E-root construction, exact Clifford isometry, root response.
planes=['0123','4567','0147','2356','0156','2347','0245','1367','0267','1345','0346','1257','0357','1246']
assert len(set(planes))==14
roots=set()
for j in range(8):
 for sign in (-1,1):
  v=[0]*8;v[j]=sign*2;roots.add(tuple(v))
for plane in planes:
 ix=list(map(int,plane))
 for signs in itertools.product((-1,1),repeat=4):
  v=[0]*8
  for j,sgn in zip(ix,signs):v[j]=sgn
  roots.add(tuple(v))
assert len(roots)==240
r7={v for v in roots if v[0]==0}
r6={v for v in r7 if sum(v[i] for i in (1,2,3))==0}
assert len(r7)==126 and len(r6)==72
assert all(sum(x*x for x in v)==4 for v in roots)
# Reflection closure of all 72 E6 roots without assuming a Cartan system.
for a in r6:
 for b in r6:
  ip=sum(x*y for x,y in zip(a,b));assert ip%2==0
  c=tuple(y-(ip//2)*x for x,y in zip(a,b))
  assert c in r6,('root reflection failure',a,b,c)
root_matrix=sp.Matrix(sorted(r6))/2
frame=root_matrix.T*root_matrix
v=sp.zeros(8,1);v[1]=v[2]=v[3]=1
P=sp.eye(8);P[0,0]=0;P=P-v*v.T/3
assert frame==12*P and P**2==P and P.rank()==6
# Extract simple roots without relying on a claimed classification.
gen=(0,1,10,-11,101,1009,10007,100003)
assert all(sum(x*y for x,y in zip(a,gen))!=0 for a in r6)
pos={a for a in r6 if sum(x*y for x,y in zip(a,gen))>0}
assert len(pos)==36
simple=[a for a in pos if not any(tuple(x+y for x,y in zip(b,c))==a for b in pos for c in pos)]
assert len(simple)==6
Cartan=sp.Matrix([[sum(x*y for x,y in zip(a,b))//2 for b in simple] for a in simple])
assert Cartan.det()==3
assert all(Cartan[i,i]==2 for i in range(6))
assert all(Cartan[i,j] in (0,-1) for i in range(6) for j in range(6) if i!=j)
deg=[sum(1 for j in range(6) if i!=j and Cartan[i,j]==-1) for i in range(6)]
assert sorted(deg)==[1,1,1,2,2,3]
# Actual exterior-bivector -> even-Clifford pseudoscalar multiplication.
def cliffprod(a,b):
 x,s1=a;y,s2=b
 swaps=sum(1 for i in range(4) if x>>i&1 for j in range(4) if y>>j&1 and i>j)
 return (x^y, s1*s2*(-1 if swaps%2 else 1))
vol=(15,1)
basis_pairs=list(itertools.combinations(range(4),2))
# i=C1C4,j=C2C4,k=C3C4, i omega=C2C3,j omega=-C1C3,k omega=C1C2
b6=[(9,1),(10,1),(12,1),(6,1),(5,-1),(3,1)]
sig=sp.zeros(8,6)
for col,(a,b) in enumerate(basis_pairs):
 target=cliffprod((1<<a|1<<b,1),vol)
 matches=[(j,target[1]*sgn) for j,(mask,sgn) in enumerate(b6) if mask==target[0]]
 assert len(matches)==1
 j,sgn=matches[0];sig[(1,2,3,5,6,7)[j],col]=sgn
assert sig.T*sig==sp.eye(6)
# sigma maps bivector generators orthogonally to B6; swap u for omega.
u=v/sp.sqrt(3);w=sp.zeros(8,1);w[4]=1
Swap=sp.eye(8)-u*u.T+w*u.T
M=sp.simplify(Swap*sig)
assert sp.simplify(M.T*M)==sp.eye(6)
assert sp.simplify(P*M-M)==sp.zeros(8,6)
Gram=sp.simplify(M.T*frame*M)
assert Gram==12*sp.eye(6)
J0=root_matrix*M # J=J0/sqrt(12)
assert sp.simplify(J0.T*J0)==12*sp.eye(6)
# Nontrivial 6x6 exact curvature sample checks the Hilbert-Schmidt identity.
K=sp.Matrix([[i+j+1 if i==j else ((i+j)%5)-2 for j in range(6)] for i in range(6)])
assert K==K.T
Y=J0*K
normK=sp.trace(K.T*K);normY=sp.simplify(sp.trace(Y.T*Y))
assert normY==12*normK
check('070','Exact Clifford Hodge isometry, 72-root E6 frame and isometric curvature-response coordinate map',
 {'root_cardinality_E8_E7_E6':[240,126,72],'root_reflections_checked':72*72,
  'E6_simple_Cartan_det':str(Cartan.det()),'E6_Dynkin_degrees':sorted(deg),
  'E6_frame_identity':'R6^T R6=12 P6','Clifford_volume_multiplication_matrix':[[int(sig[i,j]) for j in range(6)] for i in range(8)],
  'sigma_isometry':True,'axis_volume_swap_isometry':True,'J6^T_J6':'I6','Y_HS_squared_over_K_HS_squared':'12',
  'curvature_sample_K_HS_sq':str(normK),'curvature_sample_Y_HS_sq':str(normY)},
 ['source-rooted unit Hurwitz axis u and fixed Cl4 volume orientation',
  'physical positive-coframe metric and actual Levi-Civita curvature Kx are separate typed inputs'],
 'No physical curvature-amplitude bound, gravitational field equation, black-hole history, or root-selection weight proved.')

# G32-059: CAR exterior nonzero rooted pair on all 64 Fock basis states.
Mgeom=sp.diag((-1+sp.I)/2,(1+sp.I)/2,(-1-sp.I)/2)
epsilon=sp.Matrix([[0,1],[-1,0]])
Delta=sp.kronecker_product(Mgeom,epsilon)
assert Delta.T==-Delta and Delta.rank()==6
assert sp.simplify(Delta*Delta.conjugate().T)==sp.eye(6)/2
assert sp.simplify(Mgeom.det())==(1+sp.I)/4
D=64
creators=[]
for j in range(6):
 c=np.zeros((D,D),dtype=np.int64)
 for state in range(D):
  if state&(1<<j):continue
  parity=(state&((1<<j)-1)).bit_count()%2
  c[state|(1<<j),state]=(-1 if parity else 1)
 creators.append(c)
N=np.diag([i.bit_count() for i in range(D)]).astype(np.int64)
Aterms=[creators[2*j]@creators[2*j+1] for j in range(3)]
assert all(np.any(A) for A in Aterms)
assert all(np.array_equal(N@A-A@N,2*A) for A in Aterms)
# 2*rooted coefficient A = ((-1+i) A0 + (1+i) A1 + (-1-i) A2), all exact Gaussian integers.
A2=(-1+1j)*Aterms[0]+(1+1j)*Aterms[1]+(-1-1j)*Aterms[2]
A2dag=A2.conjugate().T
assert np.array_equal(N@A2-A2@N,2*A2)
assert np.array_equal(N@A2dag-A2dag@N,-2*A2dag)
assert np.any(A2[:,0]) and not np.any(A2dag[:,0])
assert np.array_equal(N@(A2+A2dag)-(A2+A2dag)@N,2*(A2-A2dag))
# generators: TR3=+1/2 and B-L=-1 on neutral-right 1p, Y=0.
# Hence dGamma(TR3)=N/2, dGamma(B-L)=-N, and [X,Hpair]=q(A-A†).
check('059','Exact finite CAR rooted-pair action algebra and full connected torus kernel *given* pair consumption',
 {'CAR_modes':6,'Fock_dimension':64,'rooted_M_det':str(Mgeom.det()),
  'Delta_rank':Delta.rank(),'Delta_Delta_dagger':'I6/2',
  'creation_pair_nonzero_on_vacuum':True,'dGamma_TR3_pair_commutator_weight':'1',
  'dGamma_BL_pair_commutator_weight':'-2','pair_H_commutator':'(a-2b)/2 (A-A_dagger)',
  'connected_pair_action_stabilizer':'b=a/2','number_grading_separates_pair_from_normal_terms':True},
 ['THE ACTUAL K16 BOUNDARY OWNER MUST CONSUME THIS PAIR (Paper5A source explicitly CONDITIONAL_OWNER)',
  'the full-owner Y stabilizer also requires a Y-covariant normal companion H0',
  'rooted nonzero structural M from a selected Hopf-axial source word'],
 'Exact operator algebra on the specified finite action; does NOT establish physical K16 occurrence, normalization or Ward-state expectation.')

# G32-066: exact 48D matter-role projectors, from explicitly supplied Fcore tensor G.
# W: left slots 0,1; right+ slot 2; right- slot 3. Q: ell=0, colors=1,2,3. G: 0..2.
F=[(w,q,g) for w in range(4) for q in range(4) for g in range(3)]
assert len(F)==48
sectors={
 'Q_L':lambda w,q: w<2 and q>0,
 'L_L':lambda w,q: w<2 and q==0,
 'u_R':lambda w,q: w==2 and q>0,
 'd_R':lambda w,q: w==3 and q>0,
 'nu_R':lambda w,q: w==2 and q==0,
 'e_R':lambda w,q: w==3 and q==0}
expected_ranks={'Q_L':18,'L_L':6,'u_R':9,'d_R':9,'nu_R':3,'e_R':3}
proj={name:np.diag([int(p(w,q)) for w,q,g in F]).astype(np.int64) for name,p in sectors.items()}
I48=np.eye(48,dtype=np.int64)
assert np.array_equal(sum(proj.values()),I48)
assert all(np.array_equal(P@P,P) for P in proj.values())
assert all(np.array_equal(P@Q,np.zeros((48,48),dtype=np.int64)) for i,P in proj.items() for j,Q in proj.items() if i!=j)
assert {k:int(np.trace(P)) for k,P in proj.items()}==expected_ranks
Ys={}
for w,q,g in F:
 tr3=sp.Rational(1,2) if w==2 else (-sp.Rational(1,2) if w==3 else sp.Rational(0))
 bl=sp.Rational(1,3) if q>0 else -sp.Rational(1)
 Ys[(w,q,g)]=tr3+bl/2
expected_charges={'Q_L':sp.Rational(1,6),'L_L':-sp.Rational(1,2),
 'u_R':sp.Rational(2,3),'d_R':-sp.Rational(1,3),'nu_R':sp.Rational(0),'e_R':-sp.Rational(1)}
for name,p in sectors.items():
 assert set(Ys[t] for t in F if p(t[0],t[1]))=={expected_charges[name]}
# P_G(g)=identity_WQ⊗rank-one on G, commutes with all 6 role projectors.
for g in range(3):
 Pg=np.diag([int(t[2]==g) for t in F]).astype(np.int64)
 assert int(np.trace(Pg))==16
 assert all(np.array_equal(P@Pg,Pg@P) for P in proj.values())
assert sum(expected_ranks.values())==48
check('066','Exact 48D Fcore⊗G finite six-role projection/charge representation conditional on source G5fin',
 {'core_dimension':16,'family_dimension':3,'total_dimension':48,
  'sector_projector_ranks':expected_ranks,
  'hypercharge_by_sector':{k:str(v) for k,v in expected_charges.items()},
  'projector_resolution_of_identity':True,'pairwise_orthogonal':True,
  'family_rank16_projectors_commute_with_all_roles':True},
 ['GP2/GP3 unique multiplicity selection and actual G5fin independent-generated carrier',
  "source's hypercharge character Y and W_L,R±,ell,C,G incidence"],
 'No independent proof of the actual 3x3 Hurwitz source selection; finite classification, not spacetime QFT matter realization.')

payload={'release':'v1_34','parent':'v1_33','scope':'independently replay conditional mathematical submaps only',
 'new_conditional_replayed_ids':sorted('G32-'+k for k in checks),
 'new_conditional_replayed_count':len(checks),'whole_source_theorems_promoted':0,
 'physical_action_occurrence_promoted':0,'checks':checks}
if '--check' in sys.argv:
 assert OUT.exists() and json.loads(OUT.read_text())==payload
 print('CHECK identical exact certificates',len(checks))
else:
 OUT.write_text(json.dumps(payload,indent=2,ensure_ascii=False,sort_keys=True)+'\n')
 print('WRITE',OUT,'exact certificates',len(checks))
for k,c in checks.items():print('PASS',k,c['mathematical_submap'])
print('PASS 4 exact conditional submaps; no physical/source theorem promotion')
