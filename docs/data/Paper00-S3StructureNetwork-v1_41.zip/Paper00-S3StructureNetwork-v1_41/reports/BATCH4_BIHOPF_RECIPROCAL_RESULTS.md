# Geometry-only Batch 4: reciprocal S³ × S³, bi-Hopf circle quotients and integral exchange geometry

**Release:** `Paper00-S3StructureNetwork-v1_15`  
**Parent:** `v1_14`  
**Source owner:** `Paper1C-M8Geometry-v1_142.tex`, SHA-256 `d26e8cd74bf2eae998a04184e5026edd52d09331ebff5371aa548b1fa3b25fbc` (PapersMinimal v3_023).  
**No proof/evidence DAG records or physical transition edges are present.** The original papers are referenced *only* by source-label provenance.

## Scope and conventions

Take the **labelled** factors of the reciprocal product

\[
M_8=(SU(2)_x\times U(1)_t)\times(SU(2)_p\times U(1)_E),\quad
P_v=SU(2)_x\times SU(2)_p\cong S_x^3\times S_p^3.
\]

On `P_v`, fix the marked bi-Hopf action from source theorem `p1b:thm:bihopf`

\[
(g_x,g_p)\cdot(z,w)=(g_x h_x(z),h_p(w)g_p),\qquad
T_H^2\longrightarrow P_v\xrightarrow{\pi}B=S_x^2\times S_p^2.
\]

Let `h_x,h_p` be oriented integral degree-two base generators and `ε_x,ε_p` each be `±1`, so the Hopf bundle Chern matrix is `diag(ε_x,ε_p)`. All formulae that specify `h_x` and `h_p` without `ε` use the normalised choice `ε_x=ε_p=+1`; other choices require the displayed sign factors. Independently marked Hopf axes are **not** exchanged by a bare factor swap unless their markings have first been transported to a common orientation.

## 1. The primitive pure-Hopf quotient is a *circle bundle*, not merely a named five-manifold

For `w=(a,b)∈Z²`, `gcd(a,b)=1`, the annihilating character of the subcircle is

\[
\chi_w(z_x,z_p)=z_x^b z_p^{-a},\qquad
\chi_w(a,b)=ba-ab=0
\]

(the latter equation is in the integer cocharacter/character pairing). The quotient `T^w=P_v/S^1_w` has a residual principal circle over `B`. Its normalized connection and Chern class are

\[
\eta_w=b\alpha_x-a\alpha_p,\quad
\frac{d\eta_w}{2\pi}=b\varepsilon_x h_x-a\varepsilon_p h_p=e_w.
\]

Since `h_x²=h_p²=0`, its characteristic number is

\[
\langle e_w^2,[B]\rangle=-2ab\varepsilon_x\varepsilon_p.
\]

Therefore the residual circle connection is contact iff `ab≠0`; in that case it is a regular prequantization of the integral symplectic form `bF_x−aF_p` on `B`. **These formulae and the contact criterion are already source theorems** `p1b:thm:primitive-circle-quotients`, `p1b:thm:g17-contact`, and `p1b:cor:g17-prequantization`; this batch turns them into maps and verifies the integer algebra independently.

**Integral Gysin ring (explicit composition):** because `e_w` is primitive, the Gysin sequence gives free `H²(T^w;Z)=Z`, `H³(T^w;Z)=Z`, and `H⁴(T^w;Z)=0`. For the `ε_x=ε_p=+1` oriented bases, choose Bezout integers `u,v` with `au+bv=1`. In the Serre-model ring (`d f=b h_x−a h_p`), take

\[
x=[u h_x+v h_p]\in H^2(T^w),\qquad
y=[(b h_x+a h_p)f]\in H^3(T^w).
\]

Then `x∪y=[T^w]` and `x²=y²=0`. Thus, noncanonically,

\[
H^*(T^w;\mathbb Z)\cong H^*(S^2\times S^3;\mathbb Z).
\]

Changing the base orientations changes the explicit generator representatives but not the abstract ring. The source also establishes `T^w≅S²×S³` as a smooth manifold; that diffeomorphism is not canonical and does not identify distinct marked circle bundles.

## 2. A general determinantal theorem for *pairs* of primitive Hopf quotients

This is the main new **cross-structure composition**. Take `w=(a,b)` and `v=(c,d)` primitive. Both `T^w` and `T^v` project to `B`. Their common-base fibre product is a principal `T²` bundle `T^w×_B T^v`. The canonical map

\[
F_{w,v}:P_v\longrightarrow T^w\times_B T^v,
\qquad p\longmapsto ([p]_w,[p]_v)
\]

acts on each original Hopf torus fibre via the two residual characters, with integer matrix

\[
A_{w,v}=\begin{pmatrix}b&-a\\d&-c\end{pmatrix},\quad
\Delta:=\det A_{w,v}=ad-bc.
\]

**If `Δ≠0`, `F_{w,v}` is a finite, regular, cyclic covering of degree `|Δ|`.** The group kernel on fibres is cyclic: because the first row is primitive, the gcd of all matrix entries is one, so the Smith normal form is `diag(1,|Δ|)`. The finite kernel acts freely as fibre translations. The map is a bundle isomorphism iff `|Δ|=1`. If `Δ=0`, the characters are dependent and there is no such cover of the entire two-circle fibre product.

The theorem follows from fibrewise compact group actions and the integral character matrix; it does not depend on any physical interpretation. The independent checker enumerates exact rational-phase kernel representatives for sample slopes and symbolically tests the universal determinant identity. This relation *is not stated as a paired reconstruction theorem in the cited source*, so it is recorded as a new derived composition, not mislabelled as a source theorem.

## 3. Exchange-stable Hopf slopes reconstruct SO(4), not Spin(4)

Under matched Hopf markings, the primitive exchange eigenslopes are `w_+=(1,1)` and `w_-=(1,−1)`. Their residual character matrix is

\[
A_H=\begin{pmatrix}1&-1\\-1&-1\end{pmatrix},\qquad
\det A_H=-2,\quad A_H^2=2I.
\]

Its kernel in the original `T_H²` is precisely the common sign flip `Δ{±1}`. Because this subgroup is central in `SU(2)_x×SU(2)_p`, the quotient is a Lie group:

\[
\boxed{\ T^{1,1}\times_B T^{1,-1}\cong P_v/\Delta\{\pm1\}
\cong SO(4),\quad P_v\cong Spin(4)\ \xrightarrow{2:1}\ SO(4).\ }
\]

This is an isomorphism of the explicitly marked total-space constructions (and of the underlying manifolds); it does not mean the individual 5-manifold `T^{1,±1}` is a Lie group `SO4`. It is a pure group-covering consequence of the paired Hopf characters.

The two residual Chern vectors, with `ε_x=ε_p=+1`, are

\[
e_+=h_x-h_p,\quad e_-=-h_x-h_p,
\qquad \det\begin{pmatrix}1&-1\\-1&-1\end{pmatrix}=-2.
\]

Thus the integral lattice generated by the two exchange Chern classes has index **two**, despite spanning the same *real* cohomology plane. Their contact characteristic numbers have opposite signs, `−2` and `+2`. There is no globally integral inverse eigenbasis on the original marked Hopf torus without restoring the common sign bit.

## 4. Independent scalar-torus exchange exhibits the same integral *lattice pattern*

The independently marked scalar torus `T²_sc` has the **source-established** eigenphase covering (`p1b:thm:eigenphase`)

\[
A_{sc}=\begin{pmatrix}1&1\\1&-1\end{pmatrix},\qquad
Q(z_t,z_E)=(z_tz_E,z_tz_E^{-1}).
\]

The new cross-structure integer identity is

\[
\boxed{A_H=J A_{sc},\qquad J=\begin{pmatrix}0&1\\-1&0\end{pmatrix}\in SL(2,\mathbb Z).}
\]

Both have index-two character images, the same abstract `C₂` diagonal sign kernel, and squares `A_H²=A_sc²=2I`. On the product **abstract four-torus** with selected Hopf/scalar bases, the combined isogeny `diag(A_H,A_sc)` has determinant `+4` and deck group `C₂×C₂` (Smith invariants `1,1,2,2`).

**Nonidentification:** this is an exact equivalence of **integral character-lattice matrices**, not an isomorphism between the nontrivial Hopf torus bundle `P_v→B` and the independent scalar torus (nor a geometrically preferred identification of their coordinate circles).

## 5. Full reciprocal M8 circle-quotient Smith classification

For a primitive cocharacter `w=(a,b,m,n)∈Z⁴`, let `Q_w=M8/S¹_w` and `d=gcd(m,n)` (with `d=0` when `m=n=0`). The homotopy exact sequence has the source-identified scalar map

\[
0\to\pi_2(Q_w)\to\mathbb Z\xrightarrow{1\mapsto(m,n)}\mathbb Z^2\to\pi_1(Q_w)\to0.
\]

The exact Smith classification is:

| Scalar gcd | `π₂(Q_w)` | `π₁(Q_w)` | Smooth normal form (source theorem) |
|---|---|---|---|
| `d=0` | `Z` | `Z²` | `T^{a,b}×T²_sc` |
| `d=1` | `0` | `Z` | `S³×S³×S¹` |
| `d>1` | `0` | `Z⊕Z/d` | `((S³×S³)/μ_d^(a,b))×S¹` |

For `d>1`, the residual cyclic group acts freely because the whole vector is primitive, equivalently `gcd(a,b,d)=1`.

Also preserved: the *different* relative principal bundle `M8→K=SU2×U1` is trivialized by `(k,h)↦(kh,h)` and factors through `X7=M8/U(1)_diag` before the remaining SU2 diagonal quotient. A smooth normal form is **not** permission to identify its quotient map with the scalar-diagonal quotient or an embedded subgroup. This distinction is explicit in source `p1b:thm:relative` and `p1b:rem:circle-quotient-firewall`.

## 6. Internal verification and status

- The new source citations refer to *mathematical premises*, not copied theorem nodes. Files are not bundled as evidence DAGs. Source SHA-256 and statement line labels are preserved as attributes.
- `verify_bihopf_integral_geometry.py` tests primitive and mixed cocharacters, exact Smith forms and rational torus kernels, base cohomology products, source transgression conventions, quaternionic relative-map identities, the index-two Hopf/scalar maps, and the combined fourfold isogeny.
- `verify_graph_exports.py` checks the full and focused GraphML against the exact mathematical JSON nodes/edges; `validate_geometry.py` runs every inherited exact verifier.
- The general slope-cover theorem is proved algebraically above; the finite sample computations are additional checks, not its only justification.
- No particle states, masses, physical decay transitions, experimental observations, or theorem-DAG nodes are part of the geometry graph.
- This completes **one scoped batch**, not the entire S³ mathematical-object grammar. In particular the older disconnected objects and higher-rank root/chamber maps remain unresolved.

### Source ownership

- `p1b:thm:group` — compact group derived subgroup, connected centre, character lattice.
- `p1b:thm:relative` — relative principal K bundle, explicit trivialization, diagonal quotient chain.
- `p1b:thm:eigenphase` — integral twofold scalar eigenphase cover.
- `p1b:thm:bihopf` — marked free bi-Hopf bundle and Chern matrix.
- `p1b:thm:primitive-circle-quotients` — primitive four-torus slopes and Smith/gcd quotient types.
- `p1b:cor:exchange-stable-slopes` — marked exchange-stable ± Hopf weights.
- `p1b:cor:scalar-born-parity-rigidity` — primitive scalar ± exchange eigenlines.
- `p1b:thm:g17-contact`, `p1b:cor:g17-prequantization` — contact/prequantization criterion.
- `p1b:prop:bihopf-transgression` — Serre transgression identities.
