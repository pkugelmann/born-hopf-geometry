# v1_32 geometric network components (post source-domain coverage)

- Mathematical objects: **862**
- Typed mathematical relations: **1392**
- AND-input guards: **242**
- Compositions: **183**
- S³-root weak component: **855**
- Weak connected components: **7**
- Intentionally isolated no-map objects: **5**
- Separate original two-node Gram component: **1**, no forced isometry
- Previously isolated v1_31 records connected under exact or source-scoped interfaces: **48/53**; five are intentional no-identifications
- Of the 48 connections: **24 first-pass source-guarded** and **24 second-pass source-formula-guarded**. The new 24 require independent proof replay before upgrading to exact verification.

**Weak connectivity is navigation, not an unconditional proof.**
