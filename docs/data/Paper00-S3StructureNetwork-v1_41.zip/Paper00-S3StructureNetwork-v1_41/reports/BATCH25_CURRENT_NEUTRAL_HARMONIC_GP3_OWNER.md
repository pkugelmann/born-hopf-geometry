# Batch 25 — Exact round-S³ harmonic six-port and GP3 owner-boundary clarification

**Current release:** `Paper00-S3StructureNetwork-v1_36` · **Parent:** `v1_35` · **Source:** `Paper00-PapersMinimal-v3_029(1).zip` (current `.tex` content, independent of earlier assistant summaries). Precise theorem labels, source lines and complete SHA-256 file hashes are in [`data/v136_current_source_anchors.json`](../data/v136_current_source_anchors.json). **Mission:** extend the mathematical S³ graph with the current harmonic neutral-boundary geometry while distinguishing mathematical identities from source selection/observable occurrence. This is NOT a proof-DAG audit or a proof of a physical neutrino spectrum.

## 1. Source chronology correction, no historical deletion

Paper V-B (`Paper5B-TerminalSpectrum-v5_201.tex`, `p6:sec:v2208-neutral-rank-word`) explicitly describes the old inverse/direct/closed-Gram neutral word \(x^{-1},x,x^2\) as **historical** on the new harmonic-rank branch. The older `p6:thm:v587-n56-response-jet-closure` remains correct **in its originally declared D4 response domain**, but its arithmetic cannot constrain the harmonic branch. General native `E56` terminal row-energy scaling (`p6:thm:v570-e56-terminal-row-energy-scale`) is separately retained.

Consequently, v1_35's `G32-056` *conditional mathematical replay* is preserved, but `v1_36` adds a current-source **scope override**: `HISTORICAL_D4_ONLY_ON_NEW_HARMONIC_BRANCH`. The appropriate new proof target is an action-owned terminal harmonic word, not further scalar-port enumeration on the D4 jet. The neutral harmonic proposal itself is **not certified as occurring**; see `p6:prop:v2208-collective-rank-word`, `p6:cor:v2208-conditional-rank-energies`, and `p5:thm:v2208-neutral-boundary-export`.

## 2. Exact independent replay of harmonic geometry

For the round \(S^3\) degree-12 scalar harmonic space \(\mathcal H_{12}\), \(\dim=169\), \(R^2\Delta|_{\mathcal H_{12}}=12(12+2)=168\). Let \(\Omega\) be the six nonaxial Hurwitz half-units \(h_\epsilon=(1+\epsilon_1i+\epsilon_2j+\epsilon_3k)/2\) with \(\sum\epsilon_i=\pm1\), using the rooted diagonal. The normalized Haar reproducing kernel is \(K_{12}(q,h)=13U_{12}(q\cdot h)\).

**Independent exact computation:** every off-diagonal value \(q\cdot h\) in \(\Omega\) is one of \(-1/2,0,1/2\); the integer Chebyshev recurrence gives \(U_{12}=1\) at all three. The diagonal has \(U_{12}(1)=13\). Consequently, with raw harmonic evaluation \(E:\mathcal H_{12}\to\mathbb C^{\Omega}\),

\[
G=EE^\dagger=156I_6+13J_6=234P_0+156P_a,\quad
P_0=J_6/6,\ P_a=I-P_0.
\]

Eigenvalues \(234\) (once) and \(156\) (five times), determinant \(234\cdot156^5=21619161667584\). Positive normalization \(B=G^{-1/2}E\) gives \(BB^\dagger=I_6\). The mutually orthogonal subspaces have ranks \(163\), \(5\), and \(1\):

\[
\mathcal H_{12}=\ker B\oplus B^\dagger\mathbf1^\perp\oplus B^\dagger\mathbb C\mathbf1.
\]

This is **geometry**, not three family mass eigenvectors, and rank fractions are probabilities only for an additional maximally mixed state \(I_{169}/169\).

The rooted signed coordinate-permutation \(S_3\) action is regular on all six points. Independent spin-6 character arithmetic gives \(\chi_{\mathcal H_{12}}=(169,1,1)\) on the identity/transposition/3-cycle classes; after subtracting the visible regular six, \(\ker B\cong \mathbf1\oplus27\,\mathbb C[S_3]\). The augmentation \(\mathbf1^\perp\cong\mathrm{sgn}\oplus2\mathrm{std}\). Hence

\[
\dim\operatorname{Hom}_{S_3}(\ker B,E_5)=27+54\cdot2=135.
\]

Thus even **full S3 equivariance does not select a unique coupling** between these owners.

## 3. Mixed Green return versus its reduction

On the mathematically specified \(K_{12}=168I\) and \(P_{\rm ns}=Q_{163}+P_{\rm aug}\), the ordinary (unnormalized) trace contraction is

\[
\mathcal G^{(K)}=\frac1{168}\begin{pmatrix}168&5\\5&5\end{pmatrix},\qquad
\mathcal G^{(K)}_{\mathrm{ns,aug}}=\frac5{168}>0,\qquad
\mathcal G^{(K)}_{\mathrm{Schur}}=\frac{163}{168}.
\]

**Key owner distinction:** \(\operatorname{Tr}(P_{\rm ns}K_{12}^{-1}P_{\rm aug})=5/168\) is a trace of **overlapping geometric projectors**. The orthogonal kernel-augmentation operator itself satisfies \(Q_{163}K_{12}^{-1}P_{\rm aug}=0\). The mixed scalar return cannot be reinterpreted as a physical off-diagonal neutrino mass/Hessian. It survives before the specified Schur reduction; whether a physical \(K_{56}\) action performs this contraction or eliminates it at any stage is not yet demonstrated.

The formal rank-port proposal uses ordinary unnormalized Hilbert–Schmidt metric on \(\operatorname{End}(E)\): \(\iota_E:z\mapsto zI_E\) has singular magnitude \(\sqrt{\dim E}\), pseudoinverse magnitude \(1/\sqrt{\dim E}\). This produces the **mathematical conditional packet** \(\{1/\sqrt{163},\sqrt5,\sqrt{163}\}\). It does not turn the packet into observed pole masses or establish its terminal action occurrence.

### Scalar-harmonic versus rank-port test

For normalized \(Z_{12}(q)=U_{12}(\operatorname{Re}q)\), exact Haar moments show \(\|Z_{12}\|=1\) and \(E Z_{12}=\mathbf1_6\). Its projector weights are

\[
(\|P_{\rm sing}Z_{12}\|^2,\|P_{\rm aug}Z_{12}\|^2,\|QZ_{12}\|^2)
=(1/39,0,38/39).
\]

The Hilbert–Schmidt commutator \(\|[|Z\rangle\langle Z|,Q]\|_{HS}^2=76/1521\). Thus *scalar amplitude sampling* and *full-owner rank traces* are mathematically distinct, even when both arise from the same round harmonic carrier. No unjustified scalarization may replace a required complete six-port source.

## 4. GP3 matter multiplicity: a conditional obstruction, NOT closure

Paper V-A's exact factor-local algebra is \(\mathcal B=M_{12}(\mathbb C)\oplus M_{36}(\mathbb C)\), complex dimension 1440. Every faithful representation has two integers \(k_\ell,k_C\ge1\):

\[
H_{k_\ell,k_C}=(\mathbb C^{12}\otimes\mathbb C^{k_\ell})\oplus(\mathbb C^{36}\otimes\mathbb C^{k_C}),\quad \dim H=12k_\ell+36k_C.
\]

Suppose one ordinary **unnormalized**, same-owner finite heat trace is **actually frozen** on both representations, with unchanged block profiles \(D_c\):

\[
y_{k_\ell,k_C}(t)-y_{1,1}(t)
=(k_\ell-1)h_{12}(t)+(k_C-1)h_{36}(t)>0
\]

for any \(t>0\) whenever one multiplicity exceeds one. Here every \(h_c(t)=\operatorname{Tr}(e^{-tD_c^2/L^2})>0\). An exact **illustrative** finite profile \(D_\ell=0\), \(D_C=I_{36}\), \(t=\log2\) yields \(y_{1,1}=30\), \(y_{2,1}=42\), and \(y_{1,2}=48\). This test is *not* an actual occurring matter operator; the general formula is a source-theorem application.

A state/effect quotient may be multiplicity blind and still fail to preserve such a frozen unnormalized scalar port. GP3's Postulate `p2:post:GP3` and conditional multiplicity proposition `p2:prop:gp3-multiplicity-bound` **require an actual generated proper whole-candidate comparison**; a mathematically chosen copy projection or erasure of the trace output is not a valid witness. The math therefore diagnoses **why the old multiplicity sandwich cannot simply be promoted**, rather than proving physical one-copy uniqueness.

## 5. Exact status and graph navigation

| Inventory | v1_35 historical base | New v1_36 extension | v1_36 effective |
|:--|--:|--:|--:|
| Mathematical objects | 862 | 17 | **879** |
| Mathematical relations | 1,392 | 32 | **1,424** |
| Joint-input mathematical scope guards | 242 | 8 | **250** |
| Derived compositions | 183 | 6 | **189** |
| Main S³ weak component | 855 | +17 | **872** |

Other components remain five deliberate singletons and one abstract two-object Gram component. The v1_35 base JSON, graphs and source ledger are preserved byte-for-byte; the **current effective graph** is `graph/mathematical_structure_network_effective_v136.graphml`, and exact extension records are `data/v136_math_extension.json`. An additional current source branch ledger at `data/v136_frontier_resolution.json` reclassifies `G32-056` without rewriting its old mathematical proof status. All 24 inherited conditional source maps stay replayed, but their original typed conditions remain.

**Remaining targeted physical/source-owner obligations (none discharged here):** (1) GP3 whole-candidate comparison with complete frozen matter signature; (2) K56 generation of an action-owned harmonic six-port and its Schur/terminal ordering; (3) same-action relative meson Hamiltonian and sector invariance for pole readout. These are three targeted frontiers, **not an exhaustive count of all framework gaps**.

## Replay and integrity

```sh
python verify_exact_batch25_v136.py --check
python scripts/build_batch25_v136.py --check
python rebuild_effective_graph_v136.py --check
python verify_batch25_v136.py
python validate_geometry.py --fast
python verify_graph_exports.py
python verify_parent_v135_integrity_v136.py
python verify_manifest.py
python geometry_verified_query_v136.py --summary
python geometry_verified_query_v136.py --boundary
```

Current TeX source hashes may be rechecked separately using `python verify_exact_batch25_v136.py --check --source-dir /path/to/extracted/current/tex`. The separate papers corpus is **not** bundled in this mathematical graph ZIP. No measured masses, source-selected actions, proof-DAG nodes, or physical decay/transition edges have been added.
