# Geometry-only Batch 8 — Q8 orbit quotient of E8 triality, and affine-D4 McKay comparison

**Release:** `Paper00-S3StructureNetwork-v1_19`; cumulative from v1_18. **Mathematics only.** No theorem/claim locator graph, physical model, decay channel or bracket-sign hypothesis. Regeneration uses the marked `2I⊃2T⊃Q8` and golden E8 coordinates already included in the prior ZIP. This batch's discoveries are **new calculations/compositions from existing geometric premises**; they have not been checked for prior publication or claimed as previously unknown mathematics.

## 1. The canonical left-Q8 action and eight-root regular orbits

In the source-marked quaternionic embedding, the normal quaternion group `Q8={±1,±i,±j,±k} ⊂ 2T` acts **from the left** on the 240 golden E8 roots through the coefficient representation constructed in v1_18. Each of the three orthogonal-D4 triality sectors `X0,X1,X2`, of 64 roots, is stabilized by Q8. Direct exact multiplication shows the action on each sector is free. Consequently each 64-root sector has exactly **eight orbits of size eight**, with full orbit partitions and all eight explicit vertex permutations in `data/q8_triality_v119_instance.json`. This **left** action must not be confused with the **right** Q8 Hopf-quotient action of v1_13.

## 2. Exact weighted quotient matrices, not guessed connections

For distinct sectors a,b,c, define `M_ab(r,s)=1` exactly when `−r−s ∈ X_c`. The prior data contains 64×64 matrices of rank 25, each with 1024 incidences. Let `O_{a,i}`, i=0…7, denote the left-Q8 root orbits. Define the **integer** quotient

```
N_ab(i,j) = sum_{s∈O_{b,j}} M_ab(r,s),   for ANY r∈O_{a,i}.
```

Q8 equivariance proves independence of the representative r. Each of the three 8×8 matrices has entries 0 (8 times), 2 (48 times), 4 (8 times); row and column sums are 16. The positions of entries 4 and 0 are two perfect matchings, with permutation matrices P+ and P−. Their relative permutation is a fixed-point-free involution of cycle type `2^4`, so

```
N_ab = 2(J_8 + P+ − P−),
Spec(N_ab N_ab^T) = {256^(1),16^(4),0^(3)},
rank N_ab = 5.
```

The quotient matrices carry genuinely new geometry: they are weighted incidence maps on **eight actual Q8 root-orbits**, not a relabeling of affine McKay vertices.

## 3. Q8 character of the full 25-dimensional image

Using the exact 8×8 factor-Gram projectors of v1_17, the orthogonal image projector of each 64×64 M is `P_25 = P_5^(left)⊗P_5^(right)`. For each h∈Q8 the character `trace(P_25 · permutation(h))` is, exactly,

```
h = 1            -> 25
h = −1           ->  9
h = ±i,±j,±k    ->  1 each
```

Q8 character orthogonality gives a **real representation** decomposition

```
V_25|Q8 ≅ 5·1 ⊕ 4·χ_i ⊕ 4·χ_j ⊕ 4·χ_k ⊕ 2·H_4,
```

where χ_i,χ_j,χ_k are the three nontrivial real one-dimensional characters and H_4 is the four-dimensional quaternionic irreducible (the complex 2D spinor has quaternionic type). Thus `dim(V_25^Q8)=5`. Independently, the quotient matrix N_ab has image rank five, so the geometric orbit quotient realizes this fixed image. **This is a genuine five-dimensional construction, not an identification with any other rank-five space.**

## 4. A 24-vertex weighted tripartite graph and triple hypergraph

The three quotient sectors have 8 nodes each; the three 8×8 matrices yield exactly 168 nonzero weighted bipartite links. All 1,024 ordered `(r0,r1,r2)` root triples satisfying `r0+r1+r2=0` form free Q8 orbits of size eight, hence **128 Q8 triple orbits**. They collapse to 104 distinct triples of orbit labels with weights:

```
96 orbit triples of multiplicity 1
 8 orbit triples of multiplicity 4
TOTAL 96 + 8×4 = 128
```

Every weighted 8×8 quotient matrix is the **exact pairwise marginal** of this 8×8×8 integer triple tensor; all 192 pairwise marginals were checked entry by entry. The ZIP carries the three complete matrices, 104 hyperedge patterns, and GraphML for both the 24-node graph and its 128-node incidence bipartite expansion.

## 5. The actual McKay link through Q8: affine D4 and rank-three reduction

The quaternionic subgroup Q8 has four one-dimensional complex characters and one two-dimensional irreducible; the defining SU2 spinor gives the **affine D4** McKay star. Exact restriction of the seven 2T irreducibles to Q8 yields a nonnegative 5×7 integer matrix `B_QT` satisfying

```
A_D4 B_QT = B_QT A_affineE6,      rank(B_QT)=3.
```

Compose with previous matrices `B_O:R(2O)->R(2T)` and `B_I:R(2I)->R(2T)`:

```
B_QO = B_QT B_O,     B_QI = B_QT B_I,
Y = B_QO^T B_QI,
A_affineE7 Y = Y A_affineE8,
rank Y = 3,    im(Y) ⊊ im(X),       X=B_O^T B_I (rank5).
```

The image of Y occupies the common McKay adjacency eigenspaces **−2,0,2**, with one dimension in each. Its squared singular spectrum is `{90^(2),18^(1),0^(6)}`. The larger common-2T X additionally carries ±1 modes. This is a real, source-grounded **representation restriction/induction bridge**, and the correct answer to “what does restriction all the way to Q8 preserve?”

## 6. The rank-five comparison is an explicit non-identification

The triality quotient rank-five Gram spectrum is `{256,16,16,16,16}` on its image. The cross-McKay X has positive Gram spectrum `{10,10,4,4,2}`. These cannot be related by **an orthogonal intertwiner preserving the natural Gram operators up to a single common scalar** (the multiplicity partitions already differ). There may be other meaningful functors or maps, but **no canonical equivariant isomorphism has been constructed or claimed here**. In particular the five McKay-compatible modes, five Q8 irreducible labels, and five Q8-fixed triality modes are three **distinct** constructions.

## 7. What is independently checked

- Exact group closure Q8, explicit 8×8 action group law on each X64, no fixed roots under any nonidentity Q8 element.
- Direct 64×64 root-sum incidence independently regenerated from 8D integer coordinates and compared with v1_17 edges.
- All three weighted orbit matrices and their matching involutions, integer rank, exact Gram eigenvalues, all row/column sums.
- Full 25D character computed via exact rational orthogonal projectors; all Q8 irreducible multiplicities checked.
- 1,024 original triples, 128 Q8 orbits, 104 orbit patterns and all three pairwise marginals.
- Full affine-D4 character orthogonality and 2T→Q8 McKay tensor naturality; rank-three cross-E7/E8 map and its containment in X.
- No physical, theorem/claim, or unsupported equality edges are inserted into the object graph.

Replay: `python verify_q8_triality_v119.py`; then `python validate_geometry.py`, `python verify_graph_exports.py`, `python verify_manifest.py`. Queries: `python geometry_query.py --q8-triality`, `--q8-orbit-pair 01`, `--q8-mckay`.

**Open next problem:** Does a further specified, equivariant operation link the five Q8-invariant triality modes to an appropriate representation-ring module? A dimension match alone cannot do so. Also determine how the 24-node orbit hypergraph interacts with the right-Q8 Hopf 15-axis quotient, without conflating left and right actions.
