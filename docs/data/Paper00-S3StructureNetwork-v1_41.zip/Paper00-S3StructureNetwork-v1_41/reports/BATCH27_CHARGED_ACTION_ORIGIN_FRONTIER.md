# Batch 27 — charged action-origin frontier, v1_38

Source corpus: PapersMinimal v3_038. This release is a **provenance overlay**, not a new physical geometry theorem.

Native signed triality, C3 ports, Hopf negative-current relation and polar arrows are geometric. Paper V-A v3_215 preserves the independent input `Cert_hier`; Paper III-F v1_271 states the actual Hessian acceptance test. The unprovided typed edge from action-unowned `Relation/Op/Port` to required same-owner `HierArrowAction` is marked **OPEN**. It is NOT installed in the effective geometry as a proved physical relation.

The charged right-frame may be quotiented only for actual left-only observable fibres. The u,d,e origins must be separately established. No new masses, hadronic decays, GP axioms, or Newton claims are promoted.
