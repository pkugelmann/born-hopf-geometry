# Geometry-only Batch 10 — Ternary incidence, 1+4+10 algebra and cyclic matching geometry

**Cumulative release** `Paper00-S3StructureNetwork-v1_21` (parent `v1_20`). **Pure finite mathematics.** This batch does **not** introduce a physical cubic vertex, particle selection rule, decay process, theorem-locator node, or a new geometry axiom. The results are exact, independently regenerated compositions of the **marked** two-sheet golden-`E8` root system and its previously computed `Q8`-orbit map to 15 Hopf axes. The corresponding Paper I-B source witness is retained as provenance, not evidence for the newly composed results.

## 1. Exact tensor and intrinsic core recovery

From the 2,240 unordered zero-sum `E8` root triples, free left-`Q8` projection produces 280 weighted triple-orbits on 15 axes. Its **symmetric tensor** `T_ijk` has support 215 distinct triples: 180 of weight 1, 30 of weight 2, and 5 of weight 8, and zero whenever two indices agree. In particular,

\[
\sum_k T_{ijk}=8(1-\delta_{ij}),\qquad
\sum_{ijk}T_{ijk}^2=3720.
\]

The first equation reproduces the previously established weighted 2-`(15,3,8)` design, but its **pair contraction alone is uniform** and cannot distinguish the five tetrahedral blocks. The next contraction does distinguish them:

\[
G_{ij}:=\sum_{k,l}T_{ikl}T_{jkl}.
\]

Exact integer enumeration of the full tensor gives `G_ii=248`, `G_ij=84` for distinct axes from the same tetrahedral block, and `G_ij=40` for axes in different blocks. Writing `C_ij=1` for axes in the same block (including the diagonal), we obtain

\[
\boxed{G=164I_{15}+44C+40J_{15}.}
\]

**Intrinsic recovery, without input block labels:** Connect distinct axes `i,j` when `G_ij=84`. The result has exactly five connected components of size three; these exactly reproduce the marked five-core partition that was originally obtained from the 600-cell geometry. In particular, the ternary data remembers geometric information that the uniform pair marginal does not.

## 2. An actual polynomial relation to the 600-cell quotient

Let `Q600=A(K_{3,3,3,3,3})` be the exact 15-axis quotient adjacency from Batch 9. Integer matrix multiplication gives

\[
\boxed{G=164I_{15}-23Q_{600}+7Q_{600}^{2}.}
\]

Since `spec(Q600)={12^(1),(-3)^(4),0^(10)}`, the Gram spectrum is

\[
\boxed{\operatorname{spec}(G)=\{896^{(1)},296^{(4)},164^{(10)}\}.}
\]

The three **orthogonal rational spectral projectors** obtained as polynomials in `G` equal, entry for entry, the `P_1,P_4,P_10` projectors independently constructed from `Q600` and the golden `E8` quotient in Batch 9:

\[
P_1=J/15,\quad P_4=C/3-J/15,\quad P_{10}=I-C/3.
\]

This is an exact operator intertwining relationship on a shared, marked 15-axis coordinate space—not a claim of identity of the 120-vertex 600-cell and 240-root `E8` original graphs.

## 3. The cubic tensor is more selective than the pair algebra

Write `V=V_1\oplus V_4\oplus V_{10}` for the orthogonal eigenspaces of `G`. Apply the rational projector on **all three indices** of `T`, forming components `T_{a,b,c}`. Their exact squared Frobenius norms (ordered tensors, standard Euclidean basis) are:

| Sector triple (up to permutation) | `||T_(a,b,c)||²` |
|---|---:|
| `(1,1,1)` | `12544/15` |
| `(1,1,4)` | **0** |
| `(1,1,10)` | **0** |
| `(1,4,4)` | `256/15` |
| `(1,4,10)` | **0** |
| `(1,10,10)` | `128/3` |
| `(4,4,4)` | `4096/5` |
| `(4,4,10)` | **0** |
| `(4,10,10)` | `992/3` |
| `(10,10,10)` | `2680/3` |

Orthogonality with the appropriate permutation multiplicities exactly recovers `||T||²=3720`. Thus

\[
\boxed{T(V_4,V_4,V_{10})=0}
\]

and three other sector types also vanish identically. **These are constraints on a mathematical incidence trilinear form only**. They are *not* automatically selection rules for physical particle transitions, masses, or decay amplitudes.

## 4. Ten local ternary patterns and ten cyclic one-factorizations

For any three distinct core blocks `A,B,C` (there are `choose(5,3)=10`), the restricted `3×3×3` cube has exactly three weight-2, eighteen weight-1, and six zero entries. The three weight-2 triples identify a common *local* matching coordinate `i,j,k in {0,1,2}`, in which the **entire cube** is recovered by

\[
\boxed{T_{ABC}(i,j,k)=\delta_{ij}+\delta_{ik}+\delta_{jk}-\delta_{ij}\delta_{ik}.}
\]

Hence the local cube is 2 for three equal coordinates, 1 for exactly two equal, and 0 for all distinct.

For a *fixed pair* `A,B` of core blocks, each of the three remaining choices `C` induces one perfect matching between their three axes. The three matchings are disjoint and **exactly cover all nine edges of `K_{3,3}`**. Any two choices of the third core differ, after transport back to one axis set, by a fixed-point-free three-cycle. This creates a cyclic `C3` relative-matching system. A single global labeling making every weight-2 triple simultaneously diagonal is **impossible**, because the matching of the same core pair changes with the third core.

These ten local matching cubes, plus the five within-core weight-eight triples and the global no-two-in-one-core rule, reconstruct all 215 weighted supports exactly. The source of this structure is finite, marked incidence geometry; no continuum geometry or physics postulate is required.

## 5. Complete automorphism calculation: order 360

An automorphism of the weighted design must permute its five **disjoint weight-eight triples**. It therefore lies in the wreath-product search space `S_3 wr S_5`, of cardinality `3!^5·5!=933120`. Exhaustive inspection of every such permutation, checking the weight-2 triples and then the **entire weighted tensor**, leaves exactly **360** automorphisms. The induced action on the five blocks is surjective onto all `S5` permutations, with a **normal cyclic kernel of order 3**. Conjugation by lifts of even block permutations fixes a generator of this kernel, while lifts of odd block permutations invert it.

The exact short sequence is

\[
\boxed{1\longrightarrow C_3\longrightarrow\operatorname{Aut}(T)
       \longrightarrow S_5\longrightarrow1.}
\]

This *specifies the action and exact sequence*; no stronger abstract splitting/isomorphism of the group is asserted without a separate group-extension proof. It is **not** an identification with the full `E8` Weyl group.

The full group is transitive on **each of the five classes** of 3-subsets of 15 axes:

| Distinct core blocks | Triple weight | Orbit size | Stabilizer size |
|---|---:|---:|---:|
| 1 | 8 | 5 | 72 |
| 2 | 0 | 180 | 2 |
| 3 | 0 | 60 | 6 |
| 3 | 1 | 180 | 2 |
| 3 | 2 | 30 | 12 |

These sizes sum to `455=choose(15,3)`, and the weighted-support sizes are exactly `5+180+30=215`. The automorphism group explains the five mutually distinct kinds of ternary incidence, including the two classes of forbidden geometric triples.

## 6. What is and is not established

**Established by independent, reproducible finite computations:**

- Gram reconstruction of the five core blocks; the exact 600-cell/`E8` operator polynomial and rational eigenspaces.
- All ten orthogonal cubic-sector norms, including exact vanishing of the `(4,4,10)` component.
- Ten local tensor equality patterns, ten pairwise `K3,3` one-factorizations, and order-three relative transports.
- A complete search over all `933120` potential weighted-design automorphisms, 360 survivors, and five triple orbits.
- Reproduction of all 2,240 original exact `E8` root-sum triples before the new tensor checks.

**Not established:** a Lie bracket, a physical cubic interaction, a mass/decay constraint, a canonical map to the separate McKay rank-five module, an identification of the two marked `2I` completions, or novelty relative to all mathematics literature. The numerical calculations use integer/rational operations; the exact permutation enumeration is a finite certificate for the specified marked geometry. Existing source-attested parts of the cumulative network have their prior verification status unchanged.

### Reproduce

```bash
python verify_axis15_cubic_v121.py
python validate_geometry.py
python verify_graph_exports.py
python verify_manifest.py
python geometry_query.py --axis-cubic
python geometry_query.py --axis-local-core-triple 0 1 2
python geometry_query.py --axis-core-pair 0 1
```

Input: `data/q8_hopf_e8_bridge_v120_instance.json` (regenerated and compared from exact `E8` roots). New exact instance: `data/axis15_cubic_v121_instance.json`. Reproducer: `scripts/axis15_cubic_v121.py`. Literal geometric graphs: `graph/batch10_cubic_gram_15axis.graphml`, `graph/batch10_local_weight2_matchings_and_five_cores.graphml`, and the focused true-object graph `graph/batch10_axis15_cubic_geometry_bridges.graphml`. No imported proof/evidence DAG.
