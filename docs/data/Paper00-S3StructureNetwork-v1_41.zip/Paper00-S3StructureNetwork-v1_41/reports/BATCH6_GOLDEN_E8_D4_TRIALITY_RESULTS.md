# Geometry-only Batch 6 — exact golden `E8`, orthogonal `D4` roots, triality incidence

**Release:** `Paper00-S3StructureNetwork-v1_17`  
**Previous version:** `v1_16`. **Source status:** explicitly stated E8/D4/E6 formulas already occur in Papers I-B and I-D; the new 64×64 compatibility **singular spectrum and triangle-decomposition calculation** is an additional exact geometric computation, not a claim that the E8 embedding itself is new.  
**Primary TeX witnesses:**
- `Paper1B-ExceptionalGeometry-v1_14.tex` SHA-256 `54f8c52f2b790148832eff12eae0a43957a27b0b9f2b38939dab0b378c4dbfb2`.
- `Paper1D-TechnicalMaterial-v1_67.tex` SHA-256 `3cd6ae8bb286536ef7bc871d359996309e53ac3a6aed89917a5a82c53b6dcb2`.
- Exact theorem/claim provenance (metadata only): `p1:prop:exroot-golden-action`, `p1:thm:exroot-explicit-e876`, `p1:thm:v370-e8-d4-triality`, `p1:thm:v370-e8-shell-chamber`, `p1:prop:v370-e6-cubic-support`, `p1c:prop:v370-e8-finite-certificate`.

## 1. Coefficient coordinates and what the lift means

Fix the *single marked* quaternionic 120-element group `U=2I` and its Hurwitz subgroup `H=2T` (order24). Work in the real Clifford coefficient module `Cl(0,3)=H ⊕ Hω`, equipped with coefficient scalar product, **not** with an asserted algebra homomorphism of `Q(φ)` into the real Clifford algebra.

For each quaternion coordinate written `(a+bφ)/2`, with integer `a,b` and `φ²=φ+1`, use the doubled integral eight-coordinate embedding

```
ι( (a+bφ)/2 ) = (a,b)  (first four and last four coefficient coordinates).
F(x,y) = (y,x+y); F²=F+I.
Φ8 = ι(U) ⊔ F ι(U),                  |Φ8|=240.
```

An integer vector `r` represents Euclidean vector `r/2`; the source-normalized root bilinear form is `B(r,s)=r·s/2`, so each root has `B(r,r)=2`. Exact integer reflection `s_a(r)=r−(r·a/2)a` preserves all 240 roots. The parity code of the doubled integral coordinates has 16 words, of Hamming weights `0^(1),4^(14),8^(1)`. **The weight-eight codeword is a lattice-code word, not a norm-two root.** This double-even self-dual affine-plane code gives the even unimodular E8 root lattice. The explicit source proof and an independent reflection replay are kept separate.

`D0=ι(H)` and `D1=Fι(H)` have 24 roots each, lie in orthogonal four-subspaces and each are type D4. Their complement has 192 roots.

## 2. Weyl orbit and root-addition partition

Under the commuting reflection actions `W(D0)×W(D1)`, the 192-root complement consists of precisely three 64-root orbits `X0,X1,X2`. Each `Xa` is **exactly the Cartesian product** of an eight-weight orbit in each D4 factor; each intersects each golden sheet in exactly 32 roots. No canonical permutation-invariant label 0/1/2 is asserted.

The full root-addition hypergraph has 2240 unordered distinct root triples `r+s+t=0`, and a 240-node degree-56 graph of 6720 compatible root pairs. Every root appears in 28 of the zero-sum triples:

```
32 = (D0,D0,D0)         32 = (D1,D1,D1)
192 in each (D_i,X_a,X_a) for i=0,1 and a=0,1,2  → 1152
1024 = (X0,X1,X2)
TOTAL: 2240
```

These are geometric root-addition supports, not Lie-bracket coefficient signs and certainly not physical transitions.

## 3. **Additional exact cross-triality invariant: rank 25 and singular spectrum**

For distinct a,b,c in `{0,1,2}`, define the `64×64` binary matrix

```
M_ab(r,s) = 1 if (−r−s)∈X_c, else 0,       r∈X_a, s∈X_b.
```

The exact eight-weight Cartesian decompositions give **not just a dimension coincidence**, but an explicit binary matrix factorization:

```
M_ab = B_ab^(0) ⊗ B_ab^(1)      (after the specified product ordering).
```

Each factor `B` is 8×8, four-regular on both sides. Its Gram matrix satisfies

```
B B^T = 2(J_8 + I_8 − P),
P²=I, diag(P)=0, P is exactly four disjoint transpositions.
```

On the constant line `BB^T` has eigenvalue 16. On the anti-invariant dimension-four space of `P` it has eigenvalue 4, and on the remaining three-dimensional centered invariant space eigenvalue zero. Therefore

```
Spec(BB^T) = {16^(1), 4^(4), 0^(3)}.
Spec(M_ab M_ab^T) = {256^(1),64^(8),16^(16),0^(39)}.
Singular(M_ab) = {16^(1),8^(8),4^(16),0^(39)}.
rank(M_ab) = 25.
```

This has been checked for **all three** ordered sector-pair choices `(01),(02),(12)` both by the factor matrices and by direct comparison with all `64²` root sums. No canonical identification is made with the separate 25-cell transporter incidence representation from Batch 5. Proving such an intertwiner would be a *new* next problem.

The 192-vertex symmetric 2-section compatibility graph has degree 32, exactly 3072 edges, and exactly 1024 triangles. Every edge belongs to exactly **one** zero-sum root triple: there are no spurious tripartite 3-cliques. This follows from the exact incidence comparison and a complete three-matrix triangle count. It is a useful, separately verifiable geometric hypergraph property.

## 4. E7 and E6 as exact orthogonal sections

In the same coordinates

```
Φ7 = {r∈Φ8:r0=0}                         |Φ7|=126, rank7
Φ6 = {r∈Φ7:r1+r2+r3=0}                  |Φ6|=72,  rank6
A2 = {r∈Φ8 : r⊥Φ6}                     |A2|=6
```

Both sections are closed under their root reflections. The 240 roots divide into a 72-root E6 section, six singleton A2 roots, and six normal-coordinate classes of 27 roots: `72+6+6·27=240`. A projection onto the E6 subspace gives 27 distinct weights for each of the six nonzero A2 weights. The D1 Weyl reflection bank splits each projected 27 as `1+1+1+8+8+8`. Each 27-weight fiber contains exactly 45 unordered distinct zero-sum weight triples of types `1+4+4+4+32`, and each weight occurs in five triples. The six fibers are retained in the data; the first is used in examples only as a **coordinate ordering choice**.

## 5. Return map to the ordinary 600-cell geometry

Intersect the three Xa with the ordinary 120-root sheet. The resulting partition has sizes 24,32,32,32, with 24 equal to the original Hurwitz 2T. All 120 rows satisfy the equitable nearest-neighbor quotient

```
Q = [[0,4,4,4],
     [3,3,3,3],
     [3,3,3,3],
     [3,3,3,3]],     eigenvalues (12,-3,0,0).
```

The left Hurwitz action permutes the three 32-vertex classes through its quotient `H/Q8 ≅ C3`, with kernel order 8. Consequently, the two independent class-contrast indicator functions lie in the 600-cell adjacency eigenvalue-zero subspace. This is a new **explicit graph path** from the E8 coefficient lift to the earlier finite 600-cell adjacency geometry, without identifying the 600-cell itself with the E8 root system.

## 6. Coverage boundaries

- This is one marked `2I⊃2T` construction; the independently marked twin `2I` completion is not automatically identified with the coefficients used here.
- The golden coefficient embedding is linear/metric, not an algebra homomorphism.
- A root-sum triple is **only** a support relation; signs, bracket structure constants and transition amplitudes are **not** constructed.
- The new rank-25 subspace is not the 25-cell transporter module by dimension alone. No canonical or equivariant isomorphism has been proved.
- Neither `E8`, `D4×D4`, the three 64-root sectors nor `E6` is assigned a physical gauge/particle interpretation.
- The previous geometry network contains source-attested but still unclassified/disconnected objects. This does not establish exhaustive mathematical completeness.

## 7. Reproduction

All numbers above are entirely integer or exact rational consequences of the same marked 2I coordinates. No approximate matching thresholds. From extracted release root:

```bash
python verify_golden_e8_v117.py
python validate_geometry.py
python geometry_query.py --golden-e8
python geometry_query.py --golden-triality-pair 01
python geometry_query.py --golden-e6-fiber 0
```

`data/golden_e8_v117_instance.json` contains the complete 240 vectors, 6720 root-pair edges, 2240 zero-sum triples, three 64×64 compatibility incidence edge banks, all 8×8 factor matrices and Grams, the E7/E6/A2 sections, and all six 27-weight triple tables. Two focused GraphML exports encode the 240-root addition graph and 192-root tripartite graph. The imported mathematical structure graph (596/700) is separate from those fine-grained incidence graphs.
