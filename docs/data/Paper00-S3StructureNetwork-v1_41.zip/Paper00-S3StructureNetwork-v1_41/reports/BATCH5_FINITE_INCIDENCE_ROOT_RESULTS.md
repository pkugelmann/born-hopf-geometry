# Geometry-only Batch 5: finite exceptional incidence, chambers, Kneser and root systems

**Artifact:** `Paper00-S3StructureNetwork-v1_16`  
**Mode:** Pure geometry. This is not the proof/evidence DAG; no physical particle or decay interpretation is entered.  
**Source anchor:** `Paper1B-ExceptionalGeometry-v1_14.tex`, SHA-256 `54f8c52f2b790148832eff12eae0a43957a27b0b9f2b38939dab0b378c4dbfb2`, as contained in `Paper00-PapersMinimal-v3_023`. The exact current-source labels are recorded on the geometric object definitions. Some formulas below are source-established; the projector equality joining their two incidence descriptions is an **additional mathematical composition**.

## 1. Precise marked construction: `2I -> A5`

Take the *one fixed marked* binary icosahedral unit-quaternion group `G=2I` from the previously verified `Q(sqrt5)` coordinate instance and a fixed embedded `H=2T`. The five conjugates of `H` are `H_i`. The conjugation action of `G` on this five-element set yields an explicit degree-five permutation representation

```
σ: G → A5,                 ker σ = {+1,−1},
G/{±1} ≅ A5,              |G|=120, |A5|=60.
```

All 120 vertex-permutations are explicitly included in `data/finite_geometry_v116_instance.json`. This construction **does not identify the two separately marked 2I completions**; it is scoped to one fixed group and core frame.

## 2. Five partitions by inscribed 24-cell transporter sets

Define 25 sets (a row/column arrangement)

```
C_(i,j) = {g ∈ G : σ_g(j)=i},       i,j=0,...,4.
```

Every set has 24 elements, is a left-right isometric translate of the Hurwitz 24-cell, and each fixed-column family partitions the 120 vertices into five sets. Thus the same marked 600-cell has **five parallel proper five-colorings**. The exact `120×25` incidence matrix `B` obeys

```
B^T B = 24 I_25 + 6 R,       R=(J_5−I_5)⊗(J_5−I_5)
A_600 B = 3 (J_(120×25)−B).
```

The 25 sets are **not pairwise disjoint**: if both their row and column indices differ their intersection is a six-vertex great hexagon, otherwise distinct sets have zero intersection. There are precisely `25×16/2=200` such hexagons.

### Complete exact `-3` adjacency projector (new cross-structure composition)

Center the columns, `C=B−J_(120×25)/5`. Since the Gram operator on their doubly centered 16-dimensional sector is `30I`, the orthogonal projection is

```
P_(-3) = (B B^T−J_120)/30,
P_(-3)^2=P_(-3),    tr P_(-3)=16,
A_600 P_(-3)=−3 P_(-3).
```

The exact modular row reduction `rank_{F101}(A_600+3I)=104` supplies a rational rank **lower** bound of 104. The exhibited 16-dimensional eigenspace supplies a rational rank **upper** bound of 104. Therefore the eigenspace is exactly 16-dimensional, and `P_(-3)` is the projector onto the **entire** eigenvalue-`−3` eigenspace—not just an included subspace.

Independently, `B_60` (one row per antipodal pair) has exact rank 17 and integer Smith form with **17 unit invariant factors** and 8 zero columns. Its image in `Z^60` is thus primitive/saturated; the cokernel has no torsion. This integral invariant does **not** follow from rational rank alone.

## 3. The 722-polygon `A5` design and an exact identification of projectors

Project the 120 vertices to the 60 antipodal points `A5`. Cosets of cyclic subgroups of order 2, 3 and 5 give respectively

| Projective polygon | Cyclic subgroups | Cosets | Points per coset |
|---|---:|---:|---:|
| Order 2: lifted square | 15 | 450 | 2 |
| Order 3: lifted hexagon | 10 | 200 | 3 |
| Order 5: lifted decagon | 6 | 72 | 5 |

Every pair of distinct projective vertices occurs in exactly one polygon, and the three `60×60` incidence Grams satisfy

```
M_2 + M_3 + M_5 = 30 I_60 + J_60.
P_4 = (M_3−M_5)/15,   P_4^2=P_4, rank(P_4)=16.
```

The 200 order-three cosets are **exactly** the antipodal images of the 200 nonempty intersections among the 25 transporter 24-cells. This equality is checked set-by-set.

Let `L` denote antipodal duplication `R^60 -> R^120`. The two previously separate incidence constructions meet in the exact equality

```
B_120 B_120^T − J_120 = L (M_3−M_5) L^T,
P_(-3) = L (M_3−M_5) L^T /30 = (1/2) L P_4 L^T.
```

This is the **main new cross-network composition**: the global 600-cell nearest-neighbor `−3` eigenspace is exactly the lifted `A5` order-three minus order-five cyclic-polygon character subspace, and also the centered span of all 25 Hurwitz transporter 24-cells. It is not an identity of the objects themselves: it is an equality of specified **projectors** after the proper central lift.

## 4. Complete 600-tetrahedron chamber action and 25 register blocks

An exact nearest-neighbor four-clique enumeration produces 600 tetrahedral chambers; 1200 triangular facets belong to exactly two tetrahedra. The source incidence `T` obeys

```
T^T T = 20 I_120 + 5 A_600.
```

Under left-right `H×H` action, there is one 24-chamber orbit disjoint from `H`; its 25 double-coset translates partition all 600 chambers. Their binary matrix `U` obeys

```
T^T U = J_(120×25) − B,
T B = J_(600×25) − (I_600+A_chamber) U,
U^T A_chamber U = 6 R,
R=(J_5−I_5)⊗(J_5−I_5).
```

Thus the 25-register face-walk quotient is the complement of the `5×5` rook graph, with adjacency spectrum `16^(1), 1^(16), (−4)^(8)`. This is a **geometric chamber adjacency** and is **not** a physical transition matrix or Markov model. The original theorem occurs in Paper I-B; this batch independently regenerates the exact orbits and all entries.

## 5. Petersen/Kneser and the two projective-plane triangulations

The six Sylow-5 subgroups of `A5` are the six projective fivefold axes. Their unordered three-element subsets split under the exact `A5` action into two complementary ten-triangle orbits. Each orbit is a closed connected six-vertex, 15-edge, ten-triangle surface with five-cycle vertex links and Euler characteristic `6−15+10=1`, hence is a triangulation of `RP²`.

The dual of either triangulation is Petersen. An explicit `A5`-equivariant bijection carries the ten unordered core-pairs `ij` to the ten triangles in each orbit, with

```
{i,j} disjoint {k,l}   iff   |f(ij) ∩ f(kl)|=2.
```

The fifteen pairs of sixfold axes form the `KG(6,2)` Kneser graph with eigenvalues `6^(1),1^(9),(−3)^(5)`. The separately computed signed Petersen exterior-Hodge operator `S=*5(c∧·)` and contraction `B_c=ι_c` obey

```
B_c S = 0,       B_c^T B_c + S²=5I_10,       S³=5S.
```

The signed matrix support is exactly the Petersen disjoint-pair graph. The two `RP²` face orientations and the two icosahedral triplets are *marked* constructions; one cannot infer a canonical isomorphism between all realizations just from the abstract graph.

## 6. Hurwitz `24-cell` cellular boundary and `F4` root completion

Exactly 24 Hurwitz quaternion units generate the 24-cell graph with 96 edges and 96 triangles. The 24 dual facet normals `±e_i±e_j` define the 24 octahedral three-cells, each with six vertices, 12 edges and eight triangle faces. The cellular `f` vector is

```
(f0,f1,f2,f3) = (24,96,96,24).
```

The unsigned edge/face matrix is `96×96` of rank 73, so its nullity is 23. The matrix is related by the source-established orientation gauge to the boundary operator of the `S³` cellulation. The full boundary-complex calculation is reproduced over exact rational coefficients.

The 24 Hurwitz units form a **short-root** orbit of a crystallographic `F4` root system. The 24 dual facet normals form its longer-root orbit. Integer-scaled reflection computations show exact closure of the 48 roots and the four simple-root reflections generate `|W(F4)|=1152`. This is a mathematical comparison/refinement, not a proposed physical gauge group.

## 7. Scope, certification, and remaining work

- Newly added graph **objects** are mathematical structures/maps/operators; paper labels appear only in `witness` fields. No theorem node, source-context edge, physical channel, decay, or observable is added.
- New Batch 5 checks are exact integer/quaternionic/symbolic checks, not floating-point fits. The complete instance file can be independently regenerated with `python verify_finite_geometry_v116.py`.
- The source-established claims in sections 1,3 (except the final projector identification),4,5,6 are correctly credited as source facts with independent reproduction. The projector identity, whole-eigenspace completeness and integral SNF saturation are newly expressed compositions/invariants in this network, not a claim that the underlying source geometry is newly invented.
- The marked `2I` used here is **one** 120-point embedding. Distinctions between twin icosahedral completions, between the projective 60-point group and binary 120-point group, and between signed and unsigned Petersen operators remain enforced.
- A graph path is only mathematical navigation: it does **not** discharge all required joint inputs. Check the corresponding `joint_input_relations` records and the explicit identity before treating a map as proved.
- **Next geometry-only batch** can investigate the **two-sheet `E8`/`D4×D4` golden lift**, explicit triality action, and McKay/restriction branching, with the same source-independent arithmetic standard.
