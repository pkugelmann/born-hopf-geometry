# Geometry-only Batch 16 — exact operator bridges and structural completeness

Release: `Paper00-S3StructureNetwork-v1_27` (cumulative update from `v1_26`).

## Scope and method

**Graph objects are mathematical structures/operators, and edges are defined mathematical maps or relations.** Source labels are provenance annotations, not nodes or graph edges. There are no physical decay, pole, observable-measurement or proof-DAG edges. All conditional claims preserve their mathematical construction guards.

We first tested the two disconnected nontrivial components from the `v1_26` ledger: the six-object protected Clifford hierarchy and the three-object reciprocal `M8` heat cluster. We also addressed independently verifiable isolated objects and retained the unreconciled ones in `geometry_completeness_v127.json`.

## 1. Quaternionic even-Clifford tangent and protected response

On the explicitly marked even part of `Cl(0,3) = H ⊕ H`, choose `u=i` in the unit imaginary quaternion sphere and `V=span_R(j,k)`. For the projectors

- `Q4=|u><u|` (rank 1),
- `Q5=P_V` (rank 2),
- `Q7=|1><1|` (rank 1),
- `Q0` = the odd complementary 4D summand,

we regenerated the rational real quaternion operators `L_v,R_v` and verified for `v,w` in the 2D tangent plane

`T_u(v)=Q5 L_v Q4=|vu><u|`, `S_u(v)=T_u(v)+T_u(v)^T=[(L_v-R_v)/2,Q4]`,

`T_u(v)^T T_u(w)=<v,w> Q4`, and

`Tr_8(S_u(v)^T S_u(w))/8=<v,w>/4`.

For the **positive** carrier grading `H=E32 Q4+E40 Q5+E56 Q7+E0 Q0` the exact spectral calculus gives

`H^(1/2) S_u(v) H^(1/2)=sqrt(E32*E40) S_u(v)` and

`[(L_v-R_v)/2,H]=(E32-E40) S_u(v)`.

Here `E32=E0 alpha^-1`, `E40=E0 alpha^-5/4`, `E56=E0 alpha^-7/4`, and `E36=E0 alpha^-9/8`. These are **carrier-character coefficients, not automatically physical energies**. The identification of the represented protected carrier with the algebra requires the upstream `(ND_sp)` and active-support conditions; the newly verified matrix identity does not discharge those conditions.

## 2. The Petersen-to-Clifford rank-two Gram bridge

Using the **actual** ten `C6` axis quaternion coordinates in `ten_axis_projectors_v126_instance.json` and the exact oriented Petersen edge list from `petersen_a5_bridge_v124_instance.json`, we reconstructed the fifteen flux vectors

`k_(v,w) = (3/2) sgn(u_v·u_w) (u_v × u_w)`.

For `K=[k_e]` (3×15), exact `Q(sqrt5)` arithmetic verifies `KK^T=5I3`. For any chosen unit projective `C6` axis `u`, let `P_u=I-u u^T`. Then `A_u=K^T P_u K` obeys

`A_u²=5A_u`, `tr A_u=10`, so `Spec(A_u)={5^(2),0^(13)}`.

The protected comparison map's source-metric Gram is `(E36²/9) A_u`, hence has nonzero eigenvalue `5 E36²/9` of multiplicity two. It is not a physical vertex or decay amplitude. The exact saved 3×15 flux matrix and source projectors are in `data/geometry_bridges_v127_instance.json`.

## 3. Product and exchange Hodge geometry of M8

For the marked product `M8=S3_x×S3_p×T2` and a product bi-invariant metric with torus metric `G>0`, the scalar/Hodge spectrum is the Künneth sum and its heat traces factor. On harmonic forms the Poincaré polynomial is

`B(z)=(1+z)^2(1+z^3)^2`.

The graded exchange of matched factors gives the exact Lefschetz trace polynomial

`L(z)=(1-z²)(1-z⁶)=1-z²-z⁶+z⁸`, and the exchange ± harmonic-sector polynomials are `(B±L)/2` (both total dimension eight). The construction is independently checked on explicit finite tensor spectral blocks, and the provided scalar connection-Casimir spectrum is checked on finite `SU(2)` couplings. The full heat formulas require matched radii and exchange-invariant torus metric; a connection-coupled scalar Laplacian requires that connection to be *supplied*.

## 4. Twisted Hurwitz 25-space = 600-cell adjacency kernel

This batch's new **independent exact zero-band certificate** uses all 120 marked binary-icosahedral quaternion roots, without an interpolated spectral fit. Each quaternion scalar product takes exactly one of nine values. For the degree-four `SU(2)` character polynomial `U4(t)=16t⁴−12t²+1`, define the integer matrix

`P24[q,r]=U4(Re(q⁻¹r))` and `Π25=P24/24`.

The matrix entries are integers in `{-1,0,1,5}`. Exact integer arithmetic proves

- `P24²=24P24`, `tr(P24)=600`, so `Π25` is an orthogonal rank-25 projector.
- `A600 P24=0` using the **existing** 120×120 nearest-neighbor adjacency.
- Modular Gaussian elimination gives rank 95 for `A600` over each of `F101`, `F1009` and `F100003`. A nonzero 95×95 minor mod a prime certifies rational rank ≥95; the explicit rational null projector gives rational rank ≤95. Thus `Ran(Π25)=ker(A600)` exactly.
- `P24 (BB^T−J)=0`, where `B` is the existing 120×25 transporter 24-cell incidence matrix, proving orthogonality to the **separate** rank-16 adjacency-`−3` eigenspace.

**Do not interpret** `A600`'s zero eigenvalue as a zero-Laplacian mode or a massless physical state. The exact matrix and modular-rank verifier are bundled.

## 5. Other finite mathematical structures, kept distinct from physical realization

- The truncated bosonic Jacobi matrix satisfies `[a_N,a_N^T]=I−(N+1)|N><N|`. Its characteristic polynomial is the probabilists' Hermite polynomial `He_(N+1)` (for `q=a+a^T`), and vacuum moments agree with Gaussian moments through degree `2N+1`; small `N=1..5` checks plus the standard determinant recurrence are recorded. Hence no exact finite-dimensional CCR is asserted.
- A two-mode exterior-algebra carrier satisfies the CAR identities, verified by four-by-four integer occupation matrices. Its use as a *realized* fermion carrier requires a selected one-particle mode and statistics structure.
- The native scalar character transform `[[1,1],[1,−1]]` has index two and image the equal-parity lattice. It is a scalar-deck map, **not** a physical charge-identification theorem.
- For the signed auxiliary Petersen 10D matrix `S`, the identity `S³=5S` yields rank-3, rank-4, rank-3 spectral projectors. These are **not automatically** the identically sized blocks of the finite 43-complex-dimensional test algebra. The latter's six block sizes `(1,2,2,4,3,3)` have squared dimensions summing to 43, but that algebra identity is source-defined, not inferred from coincident block sizes.
- For a two-complex-dimensional projective ray carrier, the unit sphere is `S³` and projectivization gives the degree-one Hopf fibration `S³→CP¹≅S²`. This is a **specific comparison of two circle-phase roles**; it is not a claim that every Hopf action on every finite mode carrier is scalar.

## Completeness audit — actual connectivity

| Quantity | v1_26 | v1_27 |
|---|---:|---:|
| Mathematical object records | 772 | 785 |
| Typed mathematical relations | 1,076 | 1,134 |
| Joint-input bundles | 137 | 148 |
| Derivation/composition records | 123 | 135 |
| Largest weak connected component | 648 | 686 |
| Nontrivial disconnected components outside core | 2 | **0** |
| Isolated object records | 115 | **99** |
| Isolated foundational/technical | 19 | **3** |
| Isolated later-paper mathematical operators | 96 | **96** |

The three remaining foundational/technical items are `geo:s1_root`, `geo:quantum_free_dispersion`, and `geo:quantum_auxiliary_pair_poles`. The constitutional `S1` root is **not automatically the Hopf fibre**; the latter two need their own correctly scoped operator realization before admission. The 96 later-paper operators remain a separate source-scoped classification frontier, not 96 failed theorems.

**Not exhaustive.** Object counts include represented mathematical operators and marked constructions, not a classification of every isomorphism class. Graph connectivity is not proof closure. Existing source-verified results have been independently regenerated only where their executable mathematical certificates are supplied.

## Reproduction

```bash
python verify_batch16_v127.py
python verify_twisted25_v127.py
python verify_graph_exports.py
python validate_geometry.py --fast
python geometry_query.py --batch16-bridges
python geometry_query.py --twisted25
python geometry_query.py --geometry-coverage
python verify_manifest.py
```

The full historical mathematical regeneration suite may be run with `python validate_geometry.py` but is **not** represented as completed by the fast checks. Source-claim anchor hashes from `Paper00-PapersMinimal-v3_027(1).zip` are provenance references only; the original source TeX and proof DAG are not included in this geometry-only ZIP.
