# Geometry-only Batch 13: exact signed Petersen ↔ five-core ↔ Hopf/600-cell/E8 4-space

**Release:** `Paper00-S3StructureNetwork-v1_24`  
**Parent:** `v1_23`  
**Scope:** mathematical structure maps for one *marked* quaternionic embedding `Q8 ◁ 2T < 2I < S³`. No evidence-DAG entries or physical decay/observable interfaces are used.

## 1. Original question and result

The signed Petersen 15-**edge** cochain `C¹(KG(5,2)) ≅ R¹⁵` contains a real four-dimensional `A5` summand. The ten oriented **pair** channels `Λ² R⁵ ≅ R¹⁰` carry a distinct signed exterior-Hodge operator `S=*₅(c∧·)` whose zero eigenspace is also four-dimensional. Earlier geometry batches constructed a *third* four-dimensional space, the five-block contrasts in the 15 Hopf axes, and identified it with the right-`Q8`-fixed part of the 600-cell `−3` eigenspace and the weighted `E8` Gram `296` eigenspace.

This batch constructs and validates actual **partial isometries** connecting all three four-dimensional spaces, including all sign conventions, core labels and actual finite-group actions.

**Primary source premises:** `Paper1B-ExceptionalGeometry-v1_15.tex` in `PapersMinimal v3_026` (full TeX SHA-256 `b38803550ab964421312daa97a0b93c08c25d53fb49c22a6b813d381a69651d4`), especially labels:

- `p1:thm:kneser-five-six-hodge-duality` (line 1244)
- `p1:thm:v338-signed-petersen-hodge` (line 14581)
- `p1:thm:v339-petersen-sl4-isometry` (line 14682)
- `p1:thm:v340-incidence-character-projectors` (line 14853)

These sources already establish the individual signed Petersen and core-representation decompositions; the new *cross-instance composition* and its actual marking alignment are independently verified here. Nothing is inferred solely from coincident dimensions.

## 2. Explicit integral matrix construction

Index the ten Petersen vertices by unordered 2-subsets `A` of the five core labels and its fifteen **oriented** edges by pairs of disjoint 2-subsets `A→B`. Define:

- `N ∈ Z^(10×5)`, `N_(A,i)=1` if `i∈A` and `0` otherwise.
- `C=N−(2/5)J_(10×5)`, and its integral numerator `C5=5N−2J`.
- `D ∈ Z^(10×15)`, the actual edge boundary, with `D_(A,e)=+1` for the source and `−1` for the target.
- `B ∈ Z^(5×10)`, the exterior contraction `ι_c(e_i∧e_j)=e_j−e_i` with `c=(1,1,1,1,1)`.
- `S ∈ Z^(10×10)`, `S_(ij,kl)=ε_(mijkl)` for disjoint pairs, where `m` is the fifth core.
- `R ∈ {0,1}^(15×5)`, with `R_(a,i)=1` if Hopf axis `a` belongs to the block corresponding to source core `i`.
- `F ∈ {0,1}^(120×15)`, the actual right-Q8 Hopf-axis fibre incidence from Batch 12.

**Marking warning.** The five-core labels used by the current 600-cell quaternion model and the axis-block labels in Batch 12 are not aligned naively. Actual left multiplication on all 120 vertex labels forces the **unique** equivariant relabelling

`σ=(0,2,3,4,1)` (source core index → Hopf block index).

The installer and regenerating verifier enumerate all `5!=120` candidate label bijections and verify uniqueness against all 60 projective elements of `A5` (both binary lifts are also tested).

With this relabelling, `RᵀR=3 I₅`, and the following rank-four projectors are exact:

```
Q5 = I5 - J5/5
P_edge4 = Dᵀ C Cᵀ D / 15                         (15×15)
P_pair4 = Bᵀ B / 5 = I10 - S²/5                  (10×10)
P_axis4 = R Q5 Rᵀ / 3                           (15×15)
P_6004 = F P_axis4 Fᵀ / 8                      (120×120)
```

All are self-adjoint idempotents with trace `4`. The `P_6004` formula agrees **entrywise** with the saved exact right-`Q8`-trivial projector on the 600-cell `−3` spectral sector from Batch 12.

## 3. The three explicit partial isometries

In terms of exact integer matrices `Z=R C5ᵀ D` (15×15), `W=R B` (15×10), `K=Dᵀ C5 B` (15×10):

```
T = Z/(15 sqrt(5))       : Petersen 15-edge → Hopf axis 15
W₀ = W/sqrt(15)         : signed Petersen 10-pair → Hopf axis 15
K₀ = K/(25 sqrt(3))     : signed Petersen 10-pair → Petersen 15-edge
```

The verified **integer certificates**, from which normalization follows without floating-point fitting, are:

```
ZᵀZ = 3 Pe_num,       Pe_num=Dᵀ C5 C5ᵀ D=375 P_edge4
ZZᵀ = 75 Pa_num,      Pa_num=R (5 I5 − J5) Rᵀ=15 P_axis4
WᵀW = 3 Ph_num,       Ph_num=Bᵀ B=5 P_pair4
WWᵀ = Pa_num
KᵀK = 375 Ph_num,    KKᵀ=5 Pe_num
ZᵀW = 3 K
```

Thus

```
TᵀT=P_edge4,  TTᵀ=P_axis4;
W₀ᵀW₀=P_pair4, W₀W₀ᵀ=P_axis4;
K₀ᵀK₀=P_pair4, K₀K₀ᵀ=P_edge4;
K₀=TᵀW₀.
```

None is a bijection between the full ambient modules: the 15-edge cochain has a `4⊕5⊕6` decomposition, while the signed ten-pair exterior Hodge has a `4⊕3⊕3` decomposition. The rank-four partial isometries kill the orthogonal complements, as is checked by explicit projectors. Reorienting individual Petersen edges changes column signs but preserves the geometric projector.

## 4. Exact A5-equivariance and operator intertwinement

For each of the 60 `A5` permutations, with its signed actions on oriented edges and exterior pairs and its *actual* left quaternion action on the right-Q8 Hopf-axis fibres, the script checks

```
ρ_axis(g) Z = Z ρ_Petersen-edge(g)
ρ_axis(g) W = W ρ_wedge²(g)
ρ_wedge²(g) S = S ρ_wedge²(g)
ρ_axis(g) R = R ρ_fivecore(g).
```

The matrices `Q600` (600-cell adjacency on 15 axes), `G_E8` (weighted triple-tensor slice Gram) and `A600` (full 120-vertex nearest-neighbor adjacency) satisfy

```
Q600 Z = −3 Z
G_E8 Z = 296 Z
A600 F Z = −3 F Z
(F Z)ᵀ(F Z) = 8 Zᵀ Z
2(FZ)(FZ)ᵀ = 75 C_trivial,
```

where `C_trivial/240=P_6004` is the independently supplied **exact** `120×120` right-Q8-trivial projector. Equivalently `FT/sqrt(8)` is an isometric embedding from the Petersen rank-four Hodge sector into the 600-cell `−3` eigenspace, whose image is exactly its right-Q8-fixed summand.

The test is stronger than identifying two abstract copies of the standard four-representation: it supplies the actual normalized matrix, source/target spectral projectors, group actions, quaternion marking and 600/E8 compatibility checks.

## 5. What is not inferred

- No full `15D ↔ 15D` isomorphism is asserted: the Petersen `5⊕6` complement is annihilated by `T`.
- The ten-pair signed exterior Hodge and the fifteen graph-edge cochain are **different carrier spaces**. They only share the specified four-dimensional image via `K₀`.
- Odd `S5` permutations reverse the orientation of the exterior Hodge operator. The action verified here is the actual even `A5` action.
- This is not an identification of the separately named momentum 15-space, or of physical chirality, gauge interactions, masses or decay channels.
- The result is conditional on the explicit common marked `2I/2T/Q8` construction; it is not a canonical map across unmarked embeddings.

## 6. Exact instance, queries and independent reproduction

- `data/petersen_a5_bridge_v124_instance.json` — actual oriented Petersen boundaries, signed 10-pair Hodge, 4+5+6 projectors, `σ`, matrices `Z,W,K`, all normalizations, source owners and non-identifications.
- `graph/batch13_Petersen_A5_600_E8_fourspace.graphml` — object-level geometric morphisms.
- `graph/batch13_actual_15x15_signed_intertwiner.graphml` — actual **180 nonzero** integer-coefficient entries of `Z`.
- `scripts/petersen_a5_bridge_v124.py` — source-independent regeneration from prior exact geometry instances (no TeX used during calculations).
- `verify_petersen_a5_bridge_v124.py` — full fresh regeneration, equality with saved data, exact group and projector checks.

```
python verify_petersen_a5_bridge_v124.py
python geometry_query.py --petersen-a5-intertwiner
python geometry_query.py --petersen-intertwiner-matrix Z15
python validate_geometry.py --fast  # current batch + graph checks + inherited-data integrity
python validate_geometry.py         # slower: also rerun all historical exact verifiers
python verify_graph_exports.py
python verify_manifest.py
```
