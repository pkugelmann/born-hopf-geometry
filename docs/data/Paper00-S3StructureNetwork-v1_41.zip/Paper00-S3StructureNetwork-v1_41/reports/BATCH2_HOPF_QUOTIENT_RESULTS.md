# Geometry-only Batch 2 — Hopf, covering, quotient and metric geometry

**Release:** `Paper00-S3StructureNetwork-v1_13` · **Date:** 2026-11-16

## Purpose and evidence boundary

This mathematical graph represents **geometric objects and morphisms**, not source statements, proof dependencies, physical state transitions, or observables. The source TeX is provenance for the assumptions; fresh mathematical consequences are checked independently. Source claim IDs appear as object/edge attributes or in the small source-witness registry, never as graph vertices. The exact 600-cell data from v1_12 is preserved.

The primary Hopf marking in Paper I-A is the **common-phase / left-circle** fibration, given in quaternionic coordinates by

\[
 h_L(q)=q^{-1} i q.
\]

The finite exceptional-quotient construction requires the **opposite / right-circle** fibration,

\[
 h_R(q)=q i q^{-1}.
\]

They are transported by the inversion diffeomorphism \(\iota(q)=q^{-1}\): \(h_R\circ\iota=h_L\). They are not literally identical under the same marked group action, and inversion reverses the orientation of \(S^3\). Paper I-B explicitly warns that a general binary deck action does **not** preserve the primary left Hopf foliation.

## 1. Exact 600-cell to 15-axis quotient

Choose the marked \(2I\subset SU(2)\) and \(H=2T\) from the existing exact coordinate model. Let \(C_4=\{\pm1,\pm i\}\subset Q_8=\{\pm1,\pm i,\pm j,\pm k\}\subset H\). Right multiplication acts freely on the 120 quaternionic vertices, preserves nearest-neighbor relations, and preserves each left coset \(gH\).

The restriction \(h_R|_{2I}\) has precisely 30 directions in the unit imaginary sphere. For any \(q\in2I\), its fibre within the finite 120-set is exactly \(qC_4\). Thus

\[
 120/4=30.
\]

The existing five left cosets \(gH\) each have 24 vertices and project to six pairwise orthogonal/antipodal unit directions. Every such six-point set forms the vertex set of a regular octahedron (three antipodal pairs); the five sets are disjoint. The antipodal involution of the 30 directions is induced by right multiplication by \(j\), and its orbits are precisely the right \(Q_8\)-orbits, giving \(120/8=15\) *unoriented* order-two axes.

The **15 axes partition into five disjoint triples**, one per conjugate tetrahedral subgroup \(H_a=g_a H g_a^{-1}\). Every order-four subgroup \(\{\pm1,\pm u\}\) is contained in exactly one \(H_a\), because any two distinct \(H_a\)'s intersect in a \(C_6\), containing no order-four element.

Construct graph \(G_{30}\) by projecting the 720 edges of the nearest-neighbor 600-cell graph \(G_{120}\) under \(h_R|_{2I}\). Each projected edge has exactly four preimages, giving 180 quotient edges. The resulting graph is 12-regular. (This is **not** a claim that these 180 edges are the spherical nearest-neighbor edges of the 30 directions.)

Construct graph \(G_{15}\) by identifying antipodal directions (equivalently, by right \(Q_8\)-orbits on the 120 vertices). Each projected edge has exactly eight preimages; thus \(G_{15}\) has 90 edges and degree 12. Its vertex set splits into five triples, with no intra-triple edges and all possible edges between distinct triples. Consequently,

\[
 \boxed{G_{15}\cong K_{3,3,3,3,3}.}
\]

**The crucial covering test:** for every one of the 120 original vertices, the 12 neighbors map *bijectively* to the 12 neighbors of its image in both \(G_{30}\) and \(G_{15}\); the same holds for every one of the 30 intermediate vertices. Therefore these are actual graph coverings, not merely graph homomorphisms with matching cardinalities:

\[
 G_{120}\;\xrightarrow{4:1}\;G_{30}\;\xrightarrow{2:1}\;K_{3,3,3,3,3},
 \qquad G_{120}/Q_8\cong K_{3,3,3,3,3}.
\]

The exhibited regular deck actions are right \(C_4\), \(Q_8/C_4\cong C_2\), and right \(Q_8\), respectively. No claim is made about these being the *entire* graph automorphism/deck groups.

### Exact spectra and the Petersen-index edge count

With \(A\) the adjacency matrix,

\[
 \chi_{G_{30}}(x)=x^{15}(x-12)(x+3)^8(x^2-4x-16)^3,
\]
\[
 \chi_{G_{15}}(x)=x^{10}(x-12)(x+3)^4.
\]

Both polynomials were checked by exact integer-matrix characteristic-polynomial calculation. In particular, \(G_{15}\) is the complete 5-partite graph on five classes of three vertices. All projected edges retain the unordered pair of source color/core labels. Therefore the ten \(C_6\) intersections (equivalently, the ten vertices of the Petersen pair-index graph) each index

\[
 \boxed{72\text{ edges of }G_{120}\;\to\;18\text{ edges of }G_{30}\;\to\;9\text{ edges of }G_{15}.}
\]

This unifies the v1_12 five-core/ten-axis Petersen structure with a new Hopf/\(Q_8\) graph-covering layer. The 15 **order-four/twofold axes** in this batch are distinct mathematical objects from the ten **order-six intersection axes** in v1_12. They must not be counted as the same axis system.

## 2. Hopf bundle and Berger metric geometry

In the primary common-phase convention, with \(\psi\) of period \(4\pi\),

\[
 \alpha=\frac12(d\psi+\cos\theta\,d\phi),\quad
 d\alpha=-\frac12\sin\theta\,d\theta\wedge d\phi.
\]

The base orientation of Paper I-A is chosen so that \(\int_{S^2}d\alpha/(2\pi)=+1\); the coordinate \((\theta,\phi)\) orientation yields \(-1\). We keep this sign dictionary rather than hiding it.

For the marked Berger metric

\[
 g_\varepsilon=\frac{R^2}{4}\left[d\theta^2+\sin^2\theta\,d\phi^2
 +\varepsilon^2(d\psi+\cos\theta\,d\phi)^2\right],
\]

\[
 \mathrm{Vol}(S^3,g_\varepsilon)=2\pi^2R^3\varepsilon,\quad
 \ell_{\mathrm{fibre}}=2\pi R\varepsilon,\quad
 \mathrm{radius}(S^2)=\frac R2.
\]

For each \(n\ge1\), quotient by the order-\(n\) subgroup of the **primary left Hopf circle**, obtaining the marked Hopf lens bundle \(C_n\backslash S^3\to S^2\). The normalized connection becomes \(\alpha_n=n\alpha\), hence the Euler/Chern number is \(n\) in the paper's base orientation. The fibre length and volume are divided by \(n\), while the horizontal base remains unchanged. The lens notation is \(L(n,1)\) up to orientation convention; it is **not** an identification with a general \(L(n,q)\).

The scalar spectrum from Paper I-A is

\[
 \lambda_{k,q}(\varepsilon)=\frac{k(k+2)+(\varepsilon^{-2}-1)q^2}{R^2},
 \quad |q|\le k,\quad k\equiv q\pmod2.
\]

Invariance under the cyclic deck group imposes **\(q\equiv0\pmod n\)**. The \(q=0\) sector is the pullback of functions on the base \(S^2(R/2)\), so its eigenvalues are \(4\ell(\ell+1)/R^2\), independent of \(n,\varepsilon\). If \(n\ge2\), the \(k=1\) band cannot survive; if \(0<\varepsilon\le1\), every Berger correction is nonnegative. The first surviving positive band is \((k,q)=(2,0)\), giving

\[
 \boxed{\lambda_1(C_n\backslash S^3,g_\varepsilon)=\frac8{R^2}\quad(n\ge2,\;0<\varepsilon\le1).}
\]

Its multiplicity is 3 for \(0<\varepsilon<1\); at \(\varepsilon=1\), \(n=2\) has multiplicity 9 because the \(q=\pm2\) branches coincide, whereas \(n\ge3\) still has multiplicity 3. The result does **not** apply without qualification to elongated Berger fibres \(\varepsilon>1\). It is a source-plus-elementary spectral-filter deduction, not an unrelated physical prediction.

## 3. Exceptional quotient / opposite-Hopf Seifert squares

Let \(\Gamma\subset SU(2)\) be one of the binary polyhedral groups acting by **left** multiplication. The opposite-Hopf map satisfies

\[
 h_R(\gamma q)=\gamma h_R(q)\gamma^{-1}.
\]

Thus it induces a Seifert fibration \(\Gamma\backslash S^3\to(\Gamma/\{\pm1\})\backslash S^2\). The base is a rotational 2-orbifold, not necessarily a smooth round sphere with a free principal-circle fibration:

| Binary group | Effective rotation group | Orbifold cone orders | \(\chi_{\rm orb}\) |
|---|---|---|---|
| \(2T\), order 24 | \(A_4\), order 12 | \((2,3,3)\) | \(1/6\) |
| \(2O\), order 48 | \(S_4\), order 24 | \((2,3,4)\) | \(1/12\) |
| Either marked \(2I\), order 120 | \(A_5\), order 60 | \((2,3,5)\) | \(1/30\) |

Because the fixed \(2T\) lies in \(2O\) and each marked \(2I\), there are simultaneous quotient-covering squares of degrees \(2\) and \(5\) on total 3-manifolds and base orbifolds. The degree-2 \(2T\to2O\) cover is regular; the degree-5 \(2T\to2I\) cover is *not* regular, because \(N_{2I}(2T)=2T\) in the marked source construction. The two marked \(2I\) branches remain separate.

These are quotient geometry and group actions only. In particular, the primary left-Hopf Berger metric is *not automatically* a metric on the exceptional right-Hopf Seifert quotient. That requires a separately compatible metric marking.

## Tests and files

* `verify_hopf_geometry.py` independently constructs 120 vertices, 720 edges, right-C4/Q8 orbit quotients, every vertex-neighborhood covering bijection, five octahedra, fifteen axes/core ownership, 90 quotient edges, and both exact characteristic polynomials.
* `verify_hopf_metric.py` checks the symbolic Berger determinant/volume, orientation-sensitive Hopf curvature integral, cyclic Chern multiplication, rational spectral weight filters/gap multiplicities, and the orbifold Euler formulas.
* `data/hopf_quotient_exact_instance.json` contains **actual coordinates, maps and edge lists**, not merely schematic nodes.
* `data/hopf_metric_quotient_family.json` records exact parameter scopes, lens/Seifert branches and non-identifications.
* `data/hopf_commuting_diagrams.json` records the composable maps and all required markings.
* `graph/hopf_30_direction_graph.graphml`, `graph/hopf_15_axis_K33333.graphml` are the native instance graphs.
* `graph/hopf_quotient_cover_tower.svg` is a simplified mathematical diagram.

**Not claimed:** physical dynamics; a particle decay selection rule; exhaustive \(S^3\) classification; a canonical identification of distinct left/right Hopf markings; a new literature theorem. The finite 2I source model is **one selected embedded branch**; the exact 30/15 coordinate computation has not been separately repeated for the second marked completion, although the general group-theoretic quotient claims apply to both.
