# Geometry-only Batch 12 — A5 matrix coefficients, Q8 Fourier sectors and the E8 15-axis intertwiner

**Release:** `Paper00-S3StructureNetwork-v1_23` · **Parent:** `v1_22` · **Mathematical scope:** a *fixed marked* embedding `Q8 ◁ 2T < 2I < S³` and the same marked 600-cell, 24-cell transporter, 60-point projective polygon, 15-axis Hopf quotient, and golden-E8 weighted triple geometry from Batches 5–11. No particle assignments, proof-DAG claim nodes, physical transition operators, or source-citation edges are created.

## Main result

The global 600-cell adjacency `A_600` has a **complete** 16-dimensional eigenspace at eigenvalue `−3`, denoted `W16`. Its 25 transported 24-cell sets have vertex–set incidence matrix `B120`; set `N120=B120 B120ᵀ − J120`. Exact integer tests give

```
N120² = 30 N120,             A600 N120 = −3 N120,
tr(N120) = 480,             P_(−3) = N120/30, rank = 16.
```

The full right `Q8` deck group preserves `A600` and the projector. Because antipodes act identically on transported 24-cell incidence, `Q8` acts on `W16` through its Klein quotient `Q8/{±1}=V4`. Its four real characters are `1, χ_i, χ_j, χ_k`. For `χ` define the **actual rational 120×120 matrix**

```
P_χ = (1/(30·8)) Σ_{h∈Q8} χ(h) N120 U_h
    = C_χ / 240,
```

where `U_h` is the right-multiplication permutation of the **120 actual quaternion vertices**. Regeneration checks **all 16 products**

```
C_χ C_ψ = 240 δ_{χψ} C_χ;
Σ_χ C_χ = 8 N120;             tr(C_χ) = 960.
```

Thus `Pχ` are four orthogonal rank-4 projectors, giving the exact mathematical decomposition

\[
\boxed{W_{16}=W_{1}^{(4)}\oplus W_{\chi_i}^{(4)}\oplus
W_{\chi_j}^{(4)}\oplus W_{\chi_k}^{(4)}.}
\]

All four rational 120×120 projector numerators are included in `data/a5_q8_projector_v123_instance.json`; they are not merely inferred from dimension counts.

## Why this 16-space appears — the A5 matrix coefficient theorem

The five conjugate tetrahedral cores carry a faithful five-point action of the projective group `2I/{±1}≈A5`. On `R⁵`, the permutation representation splits into a constant line and a standard irreducible **four-dimensional** space `W4={x:∑x_i=0}`. For each of the 60 A5 elements `g`, let `B60[g,(i,j)] = 1_{g(j)=i}` and center the coefficients by subtracting `1/5`.

The centered coefficient Gram is

\[
C_{60}=B_{60}B_{60}^{\mathsf T}-J_{60},\qquad
C_{60}^2=15C_{60},\quad\operatorname{tr}C_{60}=240.
\]

This is precisely the 16-dimensional matrix coefficient block `W4⊗W4*` in the real regular representation `R[A5]`. Schur orthogonality explains `60/4=15` in the projector normalization. Independently reconstructing the **200 order-three coset polygons** and the **72 order-five coset polygons** gives the exact old geometric identity

\[
\boxed{C_{60}=M_3-M_5,\qquad P_{60}=(M_3-M_5)/15.}
\]

Every vertex `q∈2I` and its antipode map to the same projective `g∈A5`; lifting the 60-point operator by this twofold quotient gives `N120` and `P_(−3)` exactly. Consequently, the older cyclic-polygon and 600-cell transported-24-cell constructions are not unrelated 16-dimensional spaces: **they are the same explicitly identified A5 standard matrix coefficient module**, under an antipodal lift.

## Right A4 / Q8 / C3 restriction structure

The marked `2T/{±1}≈A4` is the stabilizer of one core in the five-point A5 action. It acts as even permutations on the remaining four cores. Hence `W4` restricted to this A4 is its ordinary four-point permutation module `1⊕3`; because the coefficient block contains four right copies of W4, the entire `W16` is

\[
W_{16}\big|_{\mathrm{right}\,A_4}\cong
4\cdot (\mathbf 1\oplus \mathbf 3).
\]

This representation-theoretic proof is independently verified by the **actual character traces** `tr(N U_h)/30` for all 24 marked right Hurwitz elements:

| Quaternion class | Number | Character on W16 |
|---|---:|---:|
| identity `+1` | 1 | 16 |
| central `−1` | 1 | 16 |
| order-four Q8 elements `±i,±j,±k` | 6 | 0 |
| remaining binary tetrahedral elements | 16 | 4 |

The residual `2T/Q8≈C3` conjugates the three nontrivial one-dimensional Q8 characters cyclically while fixing the trivial character. For any marked nontrivial generator `t`, the action on W16 has complex eigenspace multiplicities `(8,4,4)` for `(1,ω,ω²)`. This is a property of the right subgroup action, **not of a chosen nonflat matching connection**.

## The explicit isometry to E8 15-axis rank-four geometry

Let `F` be the **actual 120×15 incidence matrix** of the right-Q8 Hopf axis fibres (`FᵀF=8I15`). Let `S` be the 15×15 matrix `S_ij=1` when two axes lie in the same one of five three-axis tetrahedral blocks, and zero otherwise. Define

\[
U_4=5S-J_{15},\qquad P_4=U_4/15.
\]

`P4` is the rank-four projector onto differences of the five block constants. Exact integer multiplications, using the prior independent golden-E8 cubic-Gram instance and the original 600-cell instance, prove

\[
\boxed{F^{\mathsf T}N_{120}F=16U_4},\qquad
\boxed{P_{\mathbf1}=\frac{F P_4 F^{\mathsf T}}8}.
\]

Thus `F/√8` restricts to an **isometry from the 15-axis four-block contrast to the Q8-fixed rank-four part** of the 600-cell `−3` eigenspace. It does **not** identify the complete 16-space with a four-space.

Furthermore the 15-axis 600-cell quotient operator `Q600` and the symmetric E8 slice-Gram `G` from the weighted triple tensor obey

\[
G=164I-23Q_{600}+7Q_{600}^2,
\]

and the common projector is, exactly,

\[
\boxed{
P_4=\frac{Q_{600}(Q_{600}-12I)}{45}
=-\frac{(G-164I)(G-896I)}{79200}.}
\]

This is the advertised **three-way exact intertwinement**: transported 24-cell incidence/600 adjacency, projective A5 cyclic polygons, and the weighted golden-E8 cubic Gram all produce the *same four-dimensional submodule* after the stated `Q8` compression. The other 12 dimensions of the 600 `−3` space remain separate sign-character components.

On the full 15-axis real space the residual `C3` fixes the `1⊕4` block-constant sector and acts by five copies of the real two-dimensional rotation representation on the within-block 10-sector. Over `C`, the refinement is `1⊕4⊕5_ω⊕5_{ω²}`. The E8 Gram commutes with this exact right `C3` permutation, but no physical cubic selection rule is implied.

## Exact C3 action on 722 projective cyclic polygons

Project right multiplication by a nontrivial `t∈2T\Q8` to its order-three permutation of `A5`. It acts freely on the 60 projective points, producing twenty 3-cycles. It also preserves **each complete family** of cyclic cosets and their Gram operators. Exact set enumeration yields:

| Family | Polygon sets | C3-fixed polygons | Three-element orbits | Total orbits |
|---|---:|---:|---:|---:|
| order 2 | 450 | 0 | 150 | 150 |
| order 3 | 200 | 20 | 60 | 80 |
| order 5 | 72 | 0 | 24 | 24 |

The 20 fixed order-three polygons are precisely the 20 point-orbits of the right order-three translation on `A5`; this also explains why neither order-two nor order-five polygons are fixed (a free 3-cycle cannot preserve a 2- or 5-point set).

This establishes a direct group-action bridge from the right-Hurwitz `C3` transport to the previously constructed `A5` polygon incidence algebra. It is not an identification with the **distinct signed Petersen Hodge module** or with geometric loop curvature, and no such identification is asserted.

## What is new versus inherited

- **Inherited:** the 600-cell, 25 transported 24-cells, 60 projective A5 points, 722 polygon cosets, 15 Hopf axes, weighted E8 Gram, and `C3=2T/Q8` subgroup structure.
- **Independently derived in this batch:** the explicit four rank-four rational Q8 projectors; complete 2T character and A4 module identification; the C3 permutation of sign-character projectors; the explicit rank-four Hopf/E8/600 intertwiner; and the three cyclic-polygon orbit inventories under the actual marked right C3 action.
- **Not established:** a universal unmarked correspondence, an identity of the three rank-four nontrivial sign sectors with specific E8 triality modules, a preferred nonzero C3 connection, or any measured/physical consequence.

## Reproduce

From this release directory with Python 3.10+, `numpy`, `sympy`, `networkx`:

```bash
python verify_a5_q8_projector_v123.py
python verify_graph_exports.py
python validate_geometry.py
python verify_manifest.py
python geometry_query.py --a5-coefficient
python geometry_query.py --q8-fourier
python geometry_query.py --e8-projector-bridge
python geometry_query.py --polygon-c3
python geometry_query.py --q8-projector chi_i
```

Data: `data/a5_q8_projector_v123_instance.json` (actual 120×120 integer projectors; 60×60 polygon matrix, A5 projection and subgroup character tables). Regenerating script: `scripts/a5_q8_projector_v123.py`. Mathematical object graph: `graph/mathematical_structure_network.graphml`. Focused new bridges: `graph/batch12_A5_Q8_C3_spectral_bridges.graphml`; actual cyclic permutations of 15 and 60 points are separately exported to GraphML.
