# Geometry-only Batch 19: exact Petersen support operators and finite SU(3) invariant tensors

**Version:** v1_30. **Parent:** v1_29. **Scope:** finite mathematical constructions derived from already marked Petersen, 2T / A2 / SU(3) representation data. This is **not** a proof DAG, and none of the new links establishes a particle mass, bound state, gauge-source occurrence, local Gauss law, or decay channel.

## A. Petersen all-subset geometric compression

Reuse the fixed source-independent signed Petersen 15-edge carrier of v1_24 and v1_25, with its actual five three-edge core blocks. Let `H=√5 D` be the *rational* signed-Hodge six-sector operator, `D` the Galois mirror-contrast operator, and `P4,P5,P6` the orthogonal `4+5+6` projections.

The reproducible verifier constructs `H` from the saved integer/rational wedge data, tests `H²=5P6`, `D²=P6`, the two rank-three Galois eigenspace projectors `(P6±D)/2`, and all 32 compressions `P_S D P_S`. The characteristic polynomials depend only on `k=|S|` and reproduce the existing Paper VII-D result:

| k | characteristic polynomial of `D_S` |
|---|---|
| 0 | 1 |
| 1 | `t³` |
| 2 | `t²(t²−3/20)²` |
| 3 | `t³(t²−1/5)(t²−7/20)²` |
| 4 | `t⁶(t²−3/5)³` |
| 5 | `t⁹(t²−1)³` |

**Additional exact composition from previous data:** for each k, the uniform mean of the squared *embedded* compressed operators is a two-eigenvalue expression

```
(1/binom(5,k)) Σ_{|S|=k} (P_S D P_S)² = a_k P6 + b_k (I15 − P6)
```

with `(a_k,b_k)` at k=0,1 `(0,0)`, k=2 `(1/25,1/25)`, k=3 `(9/50,2/25)`, k=4 `(12/25,2/25)`, k=5 `(1,0)`. All **225 matrix entries** are checked for all six k. For every specific k-subset `S`, `Tr(D_S²)=3k(k−1)/10`.

The distinct kernel/sector projectors and all 32 support certificates are kept; the trace norm inequalities do **not** imply interacting hadron poles or masses.

## B. Elementary SU(3) invariant-tensor geometry

Use a **specified** three-dimensional complex vector space `C` carrying the fundamental of SU(3), with eight Hermitian generators `Tr(T_a T_b)=δ_ab/2`. This is a mathematical representation choice on the paper's trimer support, **not an unconditional derivation** of a physical color gauge Hilbert space from bare S³.

Independently verify the exact Fierz tensor identity:

```
Σ T_a ⊗ T_a = (Swap − I9/3)/2  on C⊗C
Σ T_a ⊗ (−T_aᵀ) = I9/6 − (3/2) P1  on C⊗C*
P1 = |I3⟩⟩⟨⟨I3|/3
```

Consequently `C⊗C* = 1⊕8` and `C⊗C = 6⊕3bar` with Casimirs `−4/3,+1/6` and `+1/3,−2/3` on their respective blocks. A third tensor power contains the determinant invariant `ε` with `Pε=|ε⟩⟨ε|/6` of rank 1, and every pairwise Casimir on that line has eigenvalue `−2/3`. All calculations use exact SymPy matrices (including the `27×27` determinant projection), not floating tolerances.

The center `Z3` supplies a **necessary, not sufficient**, condition `n_q−n_qbar ≡ 0 mod 3` for invariant tensors. The adjoint module is neutral under the center but contains no singlet. These are mathematical invariant-theory results, **not** a verification of the full paper's occupation-dependent Fock singlet projector, compiled strong algebra or physical source response.

## C. Three-vector Gram cone

For a separate abstract three-source equal-norm model, `G=40[(1−γ)I3 + γ J3]`. Its spectrum is `40(1+2γ),40(1−γ)²`, positivity is equivalent to `−1/2≤γ≤1`, and the coherent sum has squared norm `120+240γ`. This is the Paper VII-B mathematical Gram identity, not a hadronic mass prediction. It remains a separate two-object connected component in the cumulative graph; we deliberately did **not** invent an identification with the 600-cell or SU(3) color representation.

## D. Certification tiers and completeness

- **Exact direct source suboperator correspondence:** four pre-existing Petersen records (`petersen_mirror`, `petersen_kcore`, `petersen_char`, `petersen_coherence_bound`).
- **Guarded partial mathematical interface only:** eight pre-existing records (`d4_a2_color`, `color_singlet`, `color_singlet_basis`, `singlet_support`, `baryon_determinant`, `casimir_channels`, `baryon_color_gram`, `meson_gram`). These *are not* complete identifications of the originally named, larger objects.
- **Not added:** any full compiled QCD Hamiltonian, local Gauss projector, finite strong-algebra centralizer, hadron pole or decay. No spurious connection is made between the distinct nine-dimensional objects of the framework.

The graph-level isolation count is **63**, down from **75**; this includes guarded partial interfaces, so semantic completeness is weaker than connectivity. A separate two-object mathematical Gram component remains disconnected. No exhaustion certificate exists for arbitrary map compositions or all source-defined geometry.

## E. Reproduce

```
python verify_batch19_v130.py
python verify_graph_exports.py
python validate_geometry.py --fast
python verify_manifest.py
python geometry_query.py --petersen-core-compression
python geometry_query.py --su3-finite-invariants
python geometry_query.py --geometry-coverage
```

The full historical regeneration suite is included but was **not executed** for this batch. Current source labels and file hashes are indexed in `data/batch19_current_tex_witnesses.json`, read from the independently supplied `Paper00-PapersMinimal-v3_028(1).zip`, not copied as graph nodes.
