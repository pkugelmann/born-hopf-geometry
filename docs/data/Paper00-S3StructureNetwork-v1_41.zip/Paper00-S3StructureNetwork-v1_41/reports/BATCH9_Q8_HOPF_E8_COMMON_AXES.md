# Geometry-only Batch 9 — Common Hopf-axis quotient of the 600-cell and golden E8

**Release:** `Paper00-S3StructureNetwork-v1_20` (cumulative from v1_19). **Pure mathematics.** This batch constructs explicit maps between quaternionic 600-cell geometry, two-sheet golden E8 root geometry and the Q8-reduced triality hypergraph. No proof DAG nodes, particle assignments, decay operators or physical predictions have been added.

**Source scope:** one fixed embedded marked branch `Q8 ⊂ 2T ⊂ 2I`, one exact golden two-sheet `E8` coefficient representation and the existing opposite/right Hopf axis labels. The source statements provide these **inputs**, not the new quotient algebra and weighted design. New results are independently regenerated from exact quaternion and integer-root coordinates by `scripts/q8_hopf_e8_bridge_v120.py` and `verify_q8_hopf_e8_v120.py`. No priority or global novelty claim about the mathematics is made.

## 1. Left versus right Q8: explicit inversion, not an identification

The marked 600-cell Hopf quotient in v1_13 has **right** `Q8` fibres `q Q8`; the golden E8 coefficient model carries the **left** action `h·q = hq`. Quaternion inversion gives a concrete bijection

\[
\operatorname{inv}: Q_8\backslash 2I\longrightarrow 2I/Q_8,
\qquad Q_8q\longmapsto q^{-1}Q_8,
\]

because `(hq)^{-1}=q^{-1}h^{-1}`. It preserves the 600-cell nearest-neighbor condition (a real quaternionic inner product) but reverses the marked left/right operation. Exact finite enumeration checks all 15 eight-vertex orbit fibres.

Every one of the two 120-root golden E8 sheets inherits the **left** Q8 action compatibly with its coefficient embedding. There are 15 free 8-root orbits per sheet, 30 total. Via quaternion inversion, their common orbit image consists of the same 15 marked right Hopf axes; hence there are **16 roots per axis**, eight from each sheet.

The 192 roots in the three triality 64-sets account for 24 orbits mapping **two-to-one** to twelve axes. The remaining 48 roots (D0 and D1) account for six orbits mapping **two-to-one** to the three axes of the fixed 2T core.

## 2. Two different graphs, one exact 15-axis coordinate space

Let `G600` be the 120-vertex, 720-edge quaternionic nearest-neighbor graph. Its left-Q8 orbit projection, transported by inversion to the right Hopf labels, is an **eightfold regular graph cover** of `K_{3,3,3,3,3}`. Thus its fifteen-by-fifteen equitable quotient is

\[
 Q_{600}(a,b)=\begin{cases}1,&a,b\text{ belong to distinct cores},\\0,&\text{otherwise} .\end{cases}
\]

Let `GE8` be the **different** root-addition graph on 240 E8 roots, where roots `r,s` are adjacent exactly when `−r−s` is another E8 root. This graph has 6,720 edges and 56 neighbors per root. Exact enumeration establishes that every root has **four** neighbors in each one of the other 14 Hopf-axis fibres, and zero within its own. It therefore has an equitable (but **not** locally bijective covering) quotient

\[
 Q_{E8}=4(J_{15}-I_{15}).
\]

Every distinct pair of 16-root fibres carries exactly **64** E8 root-addition edges. The original 600-cell graph carries only the edges between distinct three-axis core blocks. Consequently

\[
\boxed{\qquad Q_{E8}-4Q_{600}=4A(5K_3).\qquad}
\]

Here `A(5K3)` is the ordinary adjacency of **five disjoint triangles**, one on the three Hopf axes in each tetrahedral core block. This is a new **derived geometric composition of two previously established input structures**, not an equation of the 600-cell and E8 adjacency operators on their original vertex spaces.

## 3. Exact common spectral algebra

Put `SameCore(a,b)=1` precisely when axes `a,b` belong to the same core (including the diagonal). Then the mutually orthogonal rational idempotents

\[
 P_0=\frac{J_{15}}{15},\quad
 P_4=\frac{\mathrm{SameCore}}{3}-\frac{J_{15}}{15},\quad
 P_{10}=I_{15}-\frac{\mathrm{SameCore}}{3}
\]

have ranks 1, 4 and 10, sum to the identity, and simultaneously diagonalize both quotient operators and their difference:

| Joint subspace | Dimension | `Q600` | `QE8` | `QE8−4Q600` |
|---|---:|---:|---:|---:|
| Global constant | 1 | 12 | 56 | 8 |
| Five-block contrasts | 4 | −3 | −4 | 8 |
| Within-block contrasts | 10 | 0 | −4 | −4 |

All projector equations are checked over exact rational arithmetic rather than inferred from numerical eigensolvers.

## 4. Weighted 2-(15,3,8) design from 2240 root-sum triples

The 240-root E8 zero-sum hypergraph has **2,240 unordered triples**. The left-Q8 action is free also on these triples: there are exactly **280 orbits**, each of size eight. Project all triple-orbit vertices through the **same** 15-axis map used in §2 and record multiplicities. The result is a weighted 3-uniform hypergraph on 15 axes:

- **215 distinct** unordered axis triples: 180 of weight 1, 30 of weight 2, and 5 of weight 8.
- Total weight = `180+2·30+8·5=280` triple orbits.
- **Every pair of distinct axes** lies in exactly **eight** triples *counted with weight*; every axis has weighted incidence degree 56.

Thus the root-sum triple incidence defines a **weighted `2-(15,3,8)` design**. The qualified word *weighted* matters: this is **not** a 280-block simple Steiner system.

The support decomposes more sharply by the five core colors: for each of the five triples entirely inside a single core, multiplicity is eight. For each of the ten choices of three *different* core colors there are 21 supported triples (18 weight 1, three weight 2). There are **no** supported triples with exactly two axes from the same core and the third axis outside that core. This also accounts for `5+10·21=215` supports and `5·8+10·24=280` weighted blocks.

## 5. The 24-node Q8 triality graph maps to twelve axes

Each 64-root triality sector has eight left-Q8 root orbits. From all three sectors, their 24 orbits map onto the twelve axes outside the D4 core, exactly **two** orbit nodes per axis, one from each golden sheet. This map is explicit in `data/q8_hopf_e8_bridge_v120_instance.json`. The other three axes receive two orbit nodes from the two D4 systems.

Pushing the **1,024** `X0×X1×X2` zero-sum root triples through this map yields the same **128** Q8 triple orbits and **104 distinct ordered axis triple patterns** as the original triality orbit hypergraph, with multiplicity distribution **96 at weight 1 and 8 at weight 4**. Exact checks compare all 1,024 original triple images to the weighted quotient. The coefficient sheet `q→φq` permutes the sector labels in the measured mapping `X0→X2→X1→X0`, but does not identify the sheet-labelled roots or the distinct sector representations.

## 6. Reproduction and exact scope of the claims

Run in the extracted release directory:

```bash
python verify_q8_hopf_e8_v120.py
python validate_geometry.py
python verify_graph_exports.py
python verify_manifest.py
python geometry_query.py --q8-hopf-e8
python geometry_query.py --axis-e8 0
```

The new JSON contains all 15 exact quotient rows, 15 root fibres, 30 root orbits, rational spectral idempotents, 215 weighted 15-axis triple patterns, 24→12 triality orbit labels and all 104 triality axis patterns. GraphML exports encode the true axis operators and weighted incidence hypergraphs, not a theorem/evidence catalog.

**Non-identifications preserved:** `left-Q8` ≠ `right-Q8` without inversion; `E8` root-addition ≠ `600` nearest-neighbor adjacency; E8→15-axis is **equitable**, not a graph cover; weighted orbit incidence ≠ a new Lie-bracket structure; and no result on physical decays, masses, or allowed interactions follows from these finite geometric graphs alone.
