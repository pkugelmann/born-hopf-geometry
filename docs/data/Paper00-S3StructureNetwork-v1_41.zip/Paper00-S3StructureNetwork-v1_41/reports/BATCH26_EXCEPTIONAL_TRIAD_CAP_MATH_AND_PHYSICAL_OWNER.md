# Source-scoped exceptional triad / cap bridge (v1.37)

Source files: Paper00-PapersMinimal-v3_037.zip.

Exact mathematical objects: nearest-shell raw frames (4/3,1,2), protected E36/E48 source Grams, marked source-port isometry, declared-cap Schur two-jet, and identity of three proposed dressing factors.

**No physical transition / observed cosmological claim is proved.** The actual source Hessian, shell incidence, reciprocal determinant-line transport, reflected energy rebase and Newton/measure normalization are unresolved. Antipodal coherent current sums vanish; direct energy-weighted edge ratio fails. The conditional action is not the selected native action. The main historical S3 graph arrays remain unchanged; new links are in data/v137_exceptional_triad_cap.json.
