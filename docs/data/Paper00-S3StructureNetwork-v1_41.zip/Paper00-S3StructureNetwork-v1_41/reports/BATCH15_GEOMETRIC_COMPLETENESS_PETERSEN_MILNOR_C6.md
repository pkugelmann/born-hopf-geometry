# Geometry-only Batch 15 — v1_26

**Purpose:** Begin a systematic *geometric completeness* audit of the actual mathematical object network, closing explicit maps without importing theorem/proof-DAG nodes or physics. The previous release is `v1_25`.

## Real additions (independent calculations)

1. **600-cell to Petersen total graph:** In a fixed marked quaternionic `2I`, the real-half shell `D20` and the zero-real shell `Z30` give the induced total graph `T(D20)` with 50 vertices and 150 edges. Quaternion inversion is a free graph automorphism and yields the 2-fold graph covering `T(D20) → T(P10)` with 25 vertices and 75 edges. All vertices, 50/150 and 25/75 edges, the twofold vertex map, the 50×25 adjacency intertwiner and both exact characteristic polynomials are included. The graph theorem itself is source-attested in Paper I-B; the characteristic polynomial is an additional exact calculation.
2. **Milnor scalar-operator branch:** The metric-dependent left-invariant SU(2) frame is now connected to the finite spin-`j` Peter–Weyl blocks `H_j=Σa_i^-2 J_i²`, their step-two Jacobi/parity chains, and the spin-one unordered metric-weight reconstruction from pairwise sums. Exact symbolic regenerators test all spins `j=0,1/2,...,4` with four weight triples and give a proof-algebra check of the Casimir spectral bound. **Do not identify** the metric-adapted left Milnor frame with the primary right Hopf/ Berger frame without inversion, orientation and homothety. The complete Hodge/Dirac and infinite heat trace links are **source-attested only**, not independently regenerated in this batch.
3. **Ten C6 axis-line projectors:** The pairwise intersections of the five marked `2T` cores yield ten exact rational-Q(√5) 3×3 rank-one projectors. Their five local sums are `(4/3) I_3` and the global sum is `(10/3) I_3`. This independently closes another previously isolated geometric-object node. These formulas are already given in Paper III-C and upstream Paper I-A; the batch reproduces them from actual 600-cell quaternionic coordinates.

## Cumulative network and audit

| Network quantity | Parent v1_25 | Current v1_26 |
|---|---:|---:|
| Mathematical object records | 759 | **772** |
| Typed mathematical relationships | 1,043 | **1,076** |
| Joint-input constraints | 132 | **137** |
| Derived/composed results | 117 | **123** |
| Largest weak component | 628 | **648** |
| Isolated geometric object records | 122 | **115** |
| Weak components | 125 | **118** |

**Important:** A graph component is not a proof of geometry and an object count is not a count of inequivalent geometric structures. **This is not yet exhaustive**. 19 foundational/technical source-attested objects and 96 later-paper mathematical operator records remain isolated. Two nontrivial components of sizes 6 and 3 remain outside the main connected component.

### Current source provenance check

Used the current supplied `Paper00-PapersMinimal-v3_027(1).zip` for label-presence and source-hash checking (the TeX corpus itself is *not* bundled). This is a version audit, **not** independent proof review.

- Nodes: 236 exact source-hash-and-label matches; 263 labels found in changed source versions without semantic re-verification; 273 records without a direct TeX-label witness in that graph record.
- Relations: 231 exact matches; 124 labels preserved in newer source files; 721 with no direct TeX-label witness in the relation record, including independently computed relations.

The missing-witness count **must not** be conflated with mathematical invalidity: new coordinate verifications can have no paper label. Similarly, a preserved TeX label does **not** establish unchanged theorem content.

## Regeneration commands

```bash
python verify_batch15_v126.py
python verify_graph_exports.py
python validate_geometry.py --fast
python geometry_query.py --geometry-coverage
python geometry_query.py --petersen-total
python geometry_query.py --milnor-spectral
python geometry_query.py --c6-tight-frame
python verify_manifest.py
```

The long historical all-batches regeneration remains separate; use `python validate_geometry.py` without `--fast` if needed. **Do not describe it as completed unless executed.**

### Future mathematical focus

Use `reports/geometry_completeness_v126.json` as the closure ledger, separating missing **actual mathematical maps**, source-only objects needing classification, and genuine nonidentification constraints. High-value next targets include the disconnected scalar/exchange heat component, the protected Clifford response component, the twisted 25-dimensional projector, and the general spherical-spaceform classification. Prioritize exact commuting maps and obstructions rather than automatically connecting isolated nodes by shared vocabulary.
