# Geometry-only Batch 14 — Completing the oriented Petersen 5⊕6 sectors

**Release:** `Paper00-S3StructureNetwork-v1_25`  
**Parent:** `v1_24`  
**Scope:** exact finite geometry, one marked binary icosahedral/tetrahedral/quaternion subgroup chain, left projective `A5` representation and independently given right cyclic `C3` deck action. No evidence-DAG or particle/decay data.

## 1. Mathematical starting point

The **signed, oriented** 15-edge Petersen cochain `E` has three mutually orthogonal rational projectors of ranks `4, 5, 6`, already given in the prior release. They arise from the 10-vertex Petersen graph boundary `D`, the 10×5 centred pair-incidence numerator `C5=5N−2J`, and the signed exterior-Hodge operator `S` on `Λ²R⁵`.

`E = E4 ⊕ E5 ⊕ E6` as orthogonal real `A5` modules. The 15-dimensional Hopf-axis permutation space `H` is a **different** representation. Batch 13 constructed an exact signed map `E4 → H4`, with `H4` equal to the five-core contrast and common 600/E8 spectral space. This batch resolves the remaining `E5` and `E6` geometrically.

## 2. Six-sector: exact alternating wedge into the nonzero exterior-Hodge space

Index the 10 Petersen vertices by 2-element core subsets. Let `c_A` denote a row of `C5`. An oriented Petersen edge `e:A→B` joins two **disjoint** subsets. Define the integer 10×15 operator

`W6[:,e] = c_A ∧ c_B`.

Its rows are indexed by oriented basis pairs `e_i∧e_j` in `Λ² R⁵`. Direct integer calculation gives

```
W6ᵀ W6 = 1250 P_edge6
W6 W6ᵀ = 250 S² = 1250 P_Hodge6
W6 P_edge4 = W6 P_edge5 = 0
S² W6 = 5 W6
```

Hence `U6=W6/(25√2)` is a rank-six partial isometry onto precisely the nonzero signed-Hodge eigenspaces. Its nonzero Hodge eigenvalues are `+√5` and `−√5`, each with multiplicity three. The 60 actual marked left-`A5` elements obey `ρ_Λ²(g) W6=W6 ρ_signed-edge(g)`.

The transferred signed Hodge operator on the **edge** six-space is

```
H_edge6 = W6ᵀ S W6/1250,
H_edge6² = 5 P_edge6, H_edge6³=5 H_edge6.
```

Its 15×15 entries lie in `{−1/2,0,1/2}`. It is zero on `E4⊕E5`. The resulting `E6≅3⊕3′` decomposition is exact and uses no numerical fitting.

## 3. Five-sector: exact equivariant incidence and two Hopf-axis quintets

Write the Petersen **vertex** five-projector as

```
P_v5 = I10 − J10/10 − C5 C5ᵀ/75.
```

The signed edge five-projector is `P_edge5 = Dᵀ P_v5 D/2`; thus `DᵀP_v5/√2` identifies the vertex and oriented-edge quintets.

For the Hopf-axis link, the **unoriented** Petersen edges constitute a 15-point `A5` permutation set. The actual fifteen right-`Q8` Hopf axes form another 15-point `A5` permutation set. Enumerating the full marked action produces **exactly three** equivariant bijections between these sets. Selecting the lexicographically first bijection gives a 15×15 permutation matrix `U`. This choice is **not canonical** absent further marking; it is one of a three-element `C3` family.

Let `E=|D|ᵀ` be the 15×10 unsigned edge-to-Petersen-vertex support. With `J_C3` the actual order-three deck permutation on Hopf axes, set

```
A = U E P_v5                (15×10)
A′ = (2 J_C3 + I15) A        (15×10)
```

Exact identities are

```
Aᵀ A = 4 P_v5,            A′ᵀ A′ = 12 P_v5,        Aᵀ A′=0,
P_axis5a = A Aᵀ/4,       P_axis5b = A′ A′ᵀ/12,
P_axis5a + P_axis5b = I15 − RRᵀ/3,
```

where `R` is the actual 15×5 source-aligned axis/core incidence of Batch 13. The two quintets occupy the 10-dimensional within-core contrast space. Each projector has rank five. The cyclic action mixes the two quintets while commuting with left `A5`.

The resulting explicit **signed Petersen edge → Hopf axis** operators are

```
X0 = A D;    X0ᵀ X0 = 8 P_edge5;    X0 X0ᵀ = 8 P_axis5a,
X1 = A′ D;   X1ᵀ X1 = 24 P_edge5;   X1 X1ᵀ = 24 P_axis5b,
X0ᵀ X1 = 0.
```

Thus `X0/√8` and `X1/√24` are two orthogonal-target rank-five partial isometries, verified equivariant under all 60 marked `A5` actions.

Their **axis spectral** eigenvalues are also independently checked:

```
Q600 X0 = Q600 X1 = 0,
G_E8 X0 = G_E8 X1 = 164 X0 or 164 X1, respectively.
```

These are complementary to the Batch 13 rank-four map `T4`, for which `Q600 T4=−3 T4`, `G_E8 T4=296 T4`.

## 4. Complete representation-theoretic Hom result and rigorous no-go

The marked finite actions have these characters by element order (the two order-five conjugacy classes give the same displayed character in these *real* sectors):

| Real module | order 1 | order 2 | order 3 | order 5 | decomposition |
|---|---:|---:|---:|---:|---|
| signed Petersen edges (15) | 15 | −1 | 0 | 0 | `4⊕5⊕3⊕3′` |
| Hopf-axis permutation (15) | 15 | 3 | 0 | 0 | `1⊕4⊕5⊕5` |
| Petersen edge six-space (6) | 6 | −2 | 0 | 1 | `3⊕3′` |

The class-count-weighted character inner products (1 identity, 15 involutions, 20 elements of order three, 24 of order five) give

```
dim_R Hom_A5(E15,H15) = (15·15 + 15·(−1)·3)/60 = 3,
dim_R Hom_A5(E6,H15) = (6·15 + 15·(−2)·3)/60 = 0.
```

The three explicitly constructed maps `T4`, `X0`, and `X1` have independent, orthogonal sector supports and therefore **span the entire equivariant Hom space**. Any equivariant map from the full signed Petersen edge module to the full axis module has rank at most **9**. The normalized sum `T4+X0/√8` attains rank 9. In particular, an `A5`-equivariant full 15-to-15 isomorphism is mathematically impossible.

**Qualification:** A non-equivariant linear map may exist; the no-go is specifically for **the same marked `A5` actions**. The `E6` sector is not lost: it has the explicit nonzero-Hodge isometry `U6`. The quintet-to-axis maps require selecting one of three equally valid equivariant unoriented-edge/axis identifications. Neither selection is physical nor a new geometric axiom.

## 5. Reproduction and saved data

- `data/petersen_five_six_v125_instance.json`: actual complete integer/rational matrices, all 60 group permutations, three unsigned-edge bijections, A5 characters, exact spectral eigenvalues, and no-go dimensions.
- `scripts/petersen_five_six_v125.py`: independently regenerates all matrices and verifies equalities, group actions and character orthogonality.
- `verify_petersen_five_six_v125.py`: regenerates and compares the full instance.
- `graph/batch14_Petersen_A5_five_six_completions.graphml`: 42 real mathematical links among objects.
- `graph/batch14_actual_wedge6_matrix.graphml` and `graph/batch14_actual_axis5_matrix.graphml`: the actual nonzero matrix coefficients, not textual references.
- `reports/INHERITED_V124_DATA_HASHES.json` and `verify_parent_v124_integrity_v125.py`: ensure parent exact mathematical instances are unchanged.

Run:

```bash
python verify_petersen_five_six_v125.py
python geometry_query.py --petersen-five-six
python geometry_query.py --petersen56-matrix wedge6
python validate_geometry.py --fast
python verify_graph_exports.py
python verify_manifest.py
```

All claims in this batch are mathematical. Their verification is **conditioned on the same marked finite group model used in v1_24**. No proof-DAG nodes, source-text stand-ins, physics, decay channels or empirical parameters enter the network.
