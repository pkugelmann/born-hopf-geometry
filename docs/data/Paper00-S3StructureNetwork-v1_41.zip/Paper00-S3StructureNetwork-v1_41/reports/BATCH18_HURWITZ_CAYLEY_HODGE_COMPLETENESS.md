# Geometry-only Batch 18 — Hurwitz/2T 24-cell Cayley, Hodge, and Q8 quotient (v1_29)

## Purpose and boundary

This is a mathematical **object-and-morphism** network, not a theorem/evidence DAG. This batch connects previously isolated Paper VII and Paper V/VI mathematical suboperators to the already instantiated quaternionic `2T`, 24-cell, finite spectra, Clifford and Hopf geometry. No QCD physical Hamiltonian, source action, measured mass, decay channel, or dynamical scale is inferred. An edge to a source-named mixed physical/mathematical object asserts *only the explicitly labelled mathematical portion* and is marked `GUARDED...` where appropriate.

Source provenance is from current `Paper00-PapersMinimal-v3_028(1).zip` TeX, indexed by **14 labels** and file SHA-256 hashes in `data/batch18_current_tex_witnesses.json`; the papers themselves are not copied. The 96-face Hodge eigenvalues are already **stated in Paper VII-A**; the new contribution is an independent reconstruction and explicit links to previously disconnected objects.

## Exact finite shell

In the one marked `2T⊂2I⊂S³`, the 24-cell boundary has 24 vertices, 96 edges, 96 triangular faces, and 24 octahedral facets. Its nearest-neighbor graph is the Cayley graph

\[
 A_H(q,r)=1_{\operatorname{Re}(q^{-1}r)=1/2},\quad q,r\in2T.
\]

The eight real-half neighbor group elements form a conjugation-stable generating set, so the adjacency commutes with left and right `2T` translations. Reconstructed characteristic polynomial:

\[
\chi_{A_H}(x)=(x-8)(x-4)^4x^9(x+2)^8(x+4)^2.
\]

The graph has degree eight, and the Laplacian eigenvalues are `0^(1), 4^(4), 8^(9), 10^(8), 12^(2)`.

### Exact Q8 quotient and new projector bridge

For the normal quaternion subgroup `Q8◁2T`, the 24 vertices form three disjoint eight-element right cosets. The equitable adjacency quotient is the **weighted multigraph** `4K3` (four parallel edges per pair), not ordinary `K3` and not `3K3`:

\[
 B_{Q8}=4(J_3-I_3),\quad\operatorname{Spec}(B_{Q8})=\{8,-4,-4\}.
\]

The pullback of the mean-zero 3-vertex quotient subspace is exactly the full rank-two `−4` eigenspace of the 24-cell adjacency. Its entrywise projector is

\[
\boxed{P_{-4}(q,r)=\frac{3\,1_{qQ_8=rQ_8}-1}{24}}.
\]

The package verifies `P²=P`, `AP=−4P`, `tr(P)=2` as exact integer identities after multiplying by 24. This is an explicit link between the finite group quotient and the earlier `2T/Q8=C3` geometry; it is *not* the unrelated 600-cell 15-axis quotient.

### Local cube tensor

The eight tangent neighbors at every Hurwitz vertex have normalized imaginary-quaternion directions `u=(±1,±1,±1)/√3`, giving

\[
 \sum u_a=0,\qquad \sum u_a u_b=\frac83\delta_{ab}.
\]

For a selected oriented body diagonal, these split into `1+1+3+3` vertices. This establishes the geometric portion of the source trimer support, not any physical color occurrence. The local spinorial principal-symbol isotropy is checked; the full Dirac remainder depends on separately selected spin transport/smoothness and is not proved by the moment identity alone.

## Oriented cellular Hodge geometry

We regenerated consistent integer boundary matrices

\[
\partial_1:\mathbb Z^{96}\to\mathbb Z^{24},\qquad
\partial_2:\mathbb Z^{96}\to\mathbb Z^{96},\qquad
\partial_3:\mathbb Z^{24}\to\mathbb Z^{96},
\]

satisfying `∂1∂2=0`, `∂2∂3=0` with exact ranks `(23,73,23)`. Hence `H¹=H²=0`; the 96-dimensional face-cochain space decomposes into a rank-73 coexact and rank-23 exact part.

For the **unit-weight** face Laplacian

\[
 \Delta_2=\partial_2^{\!*}\partial_2+\partial_3\partial_3^{\!*},
\]

we reproduced the exact polynomial

\[
\boxed{\begin{aligned}
\chi_{\Delta_2}(x)={}&(x-1)^6(x-2)^{16}(x-4)^{16}(x-5)^{16}\\
&\times(x-8)^{13}(x-9)(x-10)^8(x-12)^2\\
&\times(x^2-9x+16)^9.
\end{aligned}}
\]

Its smallest eigenvalue is 1 and kernel dimension 0. The first four trace moments are exactly `(480,3168,24672,212640)`.

A second explicit 24-cell map connects the primal and dual cellular complexes: the dual facet adjacency `A_dual=8I−∂3ᵀ∂3` is permutation-isomorphic to the original `A_H`. An explicit vertex-to-facet permutation is included. Accordingly, the 23 nonzero upper-face Hodge eigenvalues agree with the 23 nonzero vertex-Laplacian eigenvalues. This is a finite **self-duality and Hodge operator** connection, not a dynamical model.

## Exact relative quotient and strict source limits

`G²/G_diag ≅ G` by `(x,y)↦x^{-1}y` and `G³/G_diag ≅ G²` by `(x1,x2,x3)↦(x1^{-1}x2,x1^{-1}x3)`, for `G=2T` under *diagonal left* multiplication. Explicit group multiplication and invariance checks are included. No transfer kernel eigenvalues are claimed without supplied kernels.

Other connections are source-scoped: local `2T` parent factorization, 2I invariant-projector comb (no smooth envelope follows), finite trimer support, the rank-normalized `1/sqrt(8·9)` *dimensionless* count, scalar-shell spectral-calculus projectors, and the local Clifford/Dirac principal symbol. **These mathematical submaps must not be interpreted as certifying physical fields or measured observables.**

## Verification, coverage and remaining work

- Added **19** mathematical object/operator records, **54** typed geometric relations, **9** joint-input guards, and **10** derivation/composition records.
- Cumulative **818** objects, **1,239** relations, **167** guards, **154** compositions.
- Isolated records fell **88→75**, with **13 preexisting records newly linked**. The main weak component has **743** objects; the other 75 records remain singletons.
- No theorem/claim vertices, evidence-DAG edges, or particle decay edges were introduced.
- Source claims and historical calculations are separated in the data. No claim of exhaustive semantic or relational coverage.

Run in an extracted ZIP:

```bash
python verify_batch18_v129.py
python verify_graph_exports.py
python validate_geometry.py --fast
python geometry_query.py --hurwitz-hodge
python geometry_query.py --hurwitz-q8
python geometry_query.py --geometry-coverage
python verify_manifest.py
```

Historical full regeneration (`python validate_geometry.py` without `--fast`) was not run to completion for this release. The new exact calculation, inherited fast checks, and archive manifest are separately verified.

## Next priority

Review the **72 remaining later-paper operator isolates**, sorting those that have explicit finite-group, 24-cell cochain, Hopf-bundle or spectral maps from those requiring physical actions or source maps. Keep the three foundational isolates deliberately separate until their missing hypotheses are resolved. A graph without isolates is neither necessary nor sufficient for mathematically exhaustive closure.
