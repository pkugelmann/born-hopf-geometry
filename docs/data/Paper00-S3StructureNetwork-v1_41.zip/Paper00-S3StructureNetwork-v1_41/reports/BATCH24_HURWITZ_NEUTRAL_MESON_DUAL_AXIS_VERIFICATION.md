# Batch 24 — Hurwitz color–family, E56 response, meson sector: complete conditional-map replay with explicit source-owner frontier

**Release:** `Paper00-S3StructureNetwork-v1_35` · **Parent:** `v1_34` · **Mathematical proof scope:** the three source-guarded finite maps previously awaiting independent replay (`G32-052`, `G32-056`, `G32-072`). **Source:** authoritative supplied `.tex` in `Paper00-PapersMinimal-v3_029(1).zip`; each exact label and full-file SHA-256 recorded in `data/v135_source_anchor_ledger.json`. No paper, proof DAG, source theorem, physical state, test, action or observable was changed or independently promoted.

## Results and exact independent replay

### G32-052 — Hurwitz oriented 1+3 and two complementary trimer roles

Take the complete eight-point sign-cube Hurwitz link `h_eps = (1+eps_1 i+eps_2 j+eps_3 k)/2`. The source's oriented `u+=(+,+,+)` separates its opposite trimer `T_-={(+,-,-),(-,+,-),(-,-,+)}` from complementary `T_+={(-,+,+),(+,-,+),(+,+,-)}`. Exhaustive dot products give the Gram matrix of `h_u+` and the three `h_T-` units exactly `I4`, and left multiplication by `conj(h_u+)` has real determinant `+1`, sends the axial unit to `1`, and sends the other three basis vectors to `Im H`. Thus the source's marked color `C ≅ C^3` and complementary family `G ≅ C^3` are source-generated **incidence/role outputs**, not an arbitrary swap of indistinguishable trimers.

For the source's stipulated relation-free independent factor-local operator grammar, set `X e_j=e_(j+1)` and `D=diag(-1,0,1)` on the trimer, and recover the rank-one projectors by Lagrange interpolation in `D`; then `X^(i-j)P_j=E_ij`. Independently, the family Weyl `X,Z` with `ZX=omega XZ`, `omega^3=1`, gives these same spectral projections in `Q(sqrt(-3))`. On `C⊗G`, the 81 products `(E_ij⊗I)(I⊗E_kl)=E_ij⊗E_kl` are precisely all `9×9` matrix units and commute between factors, so they generate `M9(C)`. **This directly replays the source-guarded mathematical map**, not merely a generic unrelated `M3⊗M3` example.

**Owner boundary retained:** the full amplified algebra has faithful representations on `C^9⊗C^k`. A proof that GP3 physically selects `k=1` requires the actual *generated proper whole-candidate comparison* of Paper II-F, `p2:prop:gp3-multiplicity-bound`. A normalized state/effect test can be blind to `k`; an occurring unnormalized scalar trace distinguishes it (`Tr I9=9`, `Tr I18=18`). The comparison cannot be replaced by a non-generated copy projection or abstract algebra simplicity. Paper V-A v3.029 itself limits its general faithful amplification classification to the stated operator grammar and does not infer physical occurrence of every generator or whole-candidate GP3 comparison.

### G32-056 — E56 role-energy response constructor

Paper V-B's explicitly typed depth-one response jet is `J56^(1)(R)=(R^+,R,R†R)`. For its rooted central response `R=xI3`, `x^3=192`, `x>1`, independent algebra gives the three exact ports `x^-1I3`, `xI3`, `x²I3`. Its role-packet operator is `Sigma=diag(x^-1,x,x²)`; the **source-defined** native row-energy insertion is therefore `E56 Sigma`, and its determinant is `x²`. The squared-gap quotient `(x^6-1)/(x^4-1)` numerically equals `33.310511556...`. These are exact conditional mathematics, not inferred neutrino masses.

**Owner boundary retained:** the source's `p6:thm:v570-e56-terminal-row-energy-scale` says `kappa56=1` **in the absence of an additional independently generated dimensionless normalization port**. Source-jet completeness for its three *declared response ports* is not global exhaustion of all scalar source-word outputs. Another positive `kappa56` remains dimensionally legitimate, but dimensional possibility alone does not make it a GP2-generated port. One must inspect the actual complete frozen K=56 normalization/output grammar, not invent a free parameter or declare it absent without source proof. Physical pole/rest-mass readout remains downstream.

### G32-072 — SU(3) color singlet and reducing relative-Hamiltonian sectors

With the standard eight `su(3)` generators on `3⊗bar3`, the exact singlet vector `v=vec(I3)` satisfies `D_a v=0` for every `D_a=T_a⊗I−I⊗T_a^T`. The projector `P_s=vv†/3` has rank one and commutes with all eight, with octet complement rank eight. On a supplied selfadjoint relative Hamiltonian `H`, a sector `P=P_s⊗P_(JPC,flavor,...)` has the **actual sector eigenvalues** `spec(PHP|ran P)` when `PH=HP`. Two such color- and sector-preserving Hermitian examples on the same finite carrier yield singlet energies 2 and 9, establishing that color and kinematic labels do not fix energy.

**Additional precise mathematical guard identified:** if `[P,H]≠0`, `PHP` still exists but its eigenvalues are **Ritz/compressed levels**, not automatically the physical invariant-sector energies. An exact color-invariant counterexample has singlet radial `A=[[2,1],[1,5]]` and first radial projector `p=diag(1,0)`: compression gives `2`, while the full singlet eigenvalues are `(7±sqrt(13))/2`. It preserves color but not the further radial/quantum-number projector. Therefore the paper's phrase “finite invariant block” requires an actual source-domain check that its selected `JPC/flavor` projectors reduce the **supplied** `H_L-E_(0,L)`. It is **not claimed** that the real physical compiler violates this condition; no physically selected `H_L`, radial/hyperfine matrix or pole readout has been provided by these finite calculations.

## Two distinct verification axes

| Axis | v1_34 | v1_35 |
|---|---:|---:|
| Independent **source-scoped conditional mathematical map replays** | 21/24 | **24/24** |
| The three specifically targeted **source-selection/owner frontiers** independently discharged | 0/3 | **0/3** |
| Source theorems / actual physical occurrence / particle pole claims promoted | 0 | **0** |
| Mathematical graph topology | 862 objects, 1392 relations, 242 guards, 183 compositions | **Identical** |

**Do not confuse 24/24 with framework-wide closure or a proof DAG.** All 24 guarded maps still retain their original source conditions. The three frontier entries above are only the remaining targets of v1_34's conditional-map replay work; they are **not** the complete list of open physical dependencies in the papers.

## Proof provenance and exact reproduction

- Finite replays: `python verify_scoped_math_v135.py --check`; external source-anchor confirmation, when `.tex` is supplied: `python verify_scoped_math_v135.py --check --source-dir /path/to/current/tex`.
- Independent guard/status and graph: `python build_overlay_v135.py --check`, `python rebuild_effective_graph_v135.py --check`, `python verify_batch24_v135.py`.
- Parent preservation: `python verify_parent_v134_integrity_v135.py`; cumulative validation: `python validate_geometry.py --fast`; export and SHA256: `python verify_graph_exports.py`, `python verify_manifest.py`.
- Query verification status: `python geometry_verified_query_v135.py --summary` or `--owner-pending` or `--edge G32-072`.

The historical `data/mathematical_relations.json`, `data/joint_input_relations.json`, `data/objects.json`, all v1_34/before exports and their certificates remain intact. The new current effective GraphML has **two separate edge attributes**: conditional mathematical replay and undischarged source-owner status. No non-source mathematical structure is asserted physically necessary merely because the finite calculation works.
