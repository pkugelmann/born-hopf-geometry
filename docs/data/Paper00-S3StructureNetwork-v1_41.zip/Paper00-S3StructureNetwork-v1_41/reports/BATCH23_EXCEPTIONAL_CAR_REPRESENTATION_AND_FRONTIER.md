# Batch 23 — S³ structure network, independent exceptional/CAR/matter-map replays (v1_34)

**Parent:** `Paper00-S3StructureNetwork-v1_33.zip`; current controlling source: `Paper00-PapersMinimal-v3_029(1).zip`. **Scope:** exact mathematical checks of *existing* source-guarded graph relations; no source `.tex` edit and no proof-DAG or physical-action insertion. The mathematical graph topology is unchanged (862 objects, 1,392 typed relations, 242 AND guards, 183 compositions, 855 S³-root component, five deliberate non-identification isolates plus the historical two-object Gram component).

**Verification frontier:** 17/24 conditional mathematical replays carried forward from v1_33, **four newly replayed**, for **21/24** independent conditional mathematical replays; **three** still pending independent source-map reconstruction. This **does not establish 21 physical theorems**, a generated owner, a selected Hamiltonian, or an observable. The source-domain conditions recorded by the original source, including explicit action-occurrence conditions, are kept rather than bypassed. Full TeX SHA-256 and label presence were independently rechecked for the seven v1_33 pending map sources against the supplied corpus; hashes/labels are listed in `data/v134_unresolved_boundary_tests.json`. A standalone extraction replays the mathematics from the included scripts. A renewed TeX hash check requires the separately supplied paper corpus (`BH_PAPERS_TEX_DIR=/path/to/tex python verify_boundary_v134.py --check --strict-sources`).

## Four newly replayed conditional mathematical submaps

### G32-061: actual binary-octahedral quotient-odd module

From the 24 Hurwitz units (eight coordinate units plus sixteen half-units) and 24 additional octahedral elements `(±e_a±e_b)/sqrt(2)` for `a<b`, construct *all* 48 quaternion units in the coefficient ring `(Z+sqrt(2)Z)/2`. Exhaustively check all `48²` products, inverses, normalization, normality of 2T, coset character multiplicativity, and the generated commutator subgroup `[2O,2O]=2T`. Its quotient is C2, on the two cosets `T_O=[[0,1],[1,0]]`; the odd projector is `P^-=(I-T_O)/2`, `P^-²=P^-`, `rank(P^-)=1`. On **the already supplied** rank-three family trimer, `rank(P^-⊗I_3)=3`. This explicitly certifies the mathematical quotient-odd action and conditional rank-three representation, not a physical heavy particle, K16 assignment, mass matrix or clock.

**Source:** `Paper5B-TerminalSpectrum-v5_201.tex`, `p6:thm:binary-octahedral-normalizer`, `p6:cor:rank-three-heavy-carrier`.

### G32-070: independent 72-root E6-to-Clifford curvature map

Independently generate exactly 240 normalized E8 roots from the eight coordinate pairs and fourteen affine-plane supports with sixteen signs each, using the source's printed planes. Impose the scalar-free hyperplane (126 E7 roots), then the rooted `(i+j+k)^2` section (72 E6 roots); all `72×72=5,184` root reflections preserve that 72-element set. Extract six simple positive roots: the integer Cartan matrix has determinant **3** and degree sequence **1,1,1,2,2,3**, identifying E6 rather than merely counting 72 roots. Independently compute the exact 72×8 root-response Gram `R_6ᵀ R_6 = 12 P_6`.

Represent `Cl(4,0)` in bit-encoded monomials and calculate the **actual signed action** of the four-volume element on the six oriented coordinate bivectors, not a free six-dimensional basis identification. In `Cl(0,3)` notation, use `i=C1C4`, `j=C2C4`, `k=C3C4`, `omega=e1e2e3=-I_V`, and `i omega=C2C3`, `j omega=-C1C3`, `k omega=C1C2`. On `B6=W7∩omega⊥`, the source-rooted `u=(i+j+k)/sqrt(3)` and the swap `S_u(cu+x)=c omega+x` yield `M=S_u sigma6`, with `Mᵀ M=I6`, `P6 M=M`; hence `J=(R6 M)/sqrt(12)` satisfies **`Jᵀ J=I6`**. The independent nonzero 6×6 symmetric curvature-operator test verifies `||Y||²_HS=12||K||²_HS` exactly. The local coframe and physical curvature history remain separate inputs; there is no inferred black-hole range bound.

**Sources:** `Paper1B-ExceptionalGeometry-v1_16.tex` (`p1:thm:exroot-explicit-e876`, `p1:thm:v558-coordinate-pair-bivector-owner`), `Paper1C-M8Geometry-v1_142.tex` (`p1b:prop:septet`), `Paper1D-TechnicalMaterial-v1_67.tex` (`p1b:thm:exroot-response-norms`), `Paper6C-TechnicalMaterial-v1_51.tex` (`p8:thm:v2181-e6-curvature-response-map`).

### G32-059: the nonzero K16 neutral pair *mathematical* action

Use the source's **specific** normalized symmetric coefficient `M_BL2=diag(-1+i,1+i,-1-i)/2` and antisymmetric Weyl matrix `epsilon`. The six-mode skew coefficient `Delta=M_BL2⊗epsilon` has rank six and `Delta Delta†=I_6/2`. Independently construct all six fermionic creation matrices on **every** Fock bitstring (`2⁶=64`), including CAR ordering signs. The resulting nonzero pair operator acts nontrivially on the vacuum and obeys `[N,A]=2A`, `[N,A†]=-2A`, where on this neutral-right support `dGamma(T_R³)=N/2` and `dGamma(B-L)=-N`. Consequently, for `X=a T_R³+b(B-L)`:

`[dGamma(X),A]=(a-2b)A` and `[dGamma(X),H_pair]=(a-2b)/2 (A-A†)`.

Since `A|0>≠0`, vanishing forces `a-2b=0`; hence the **connected stabilizer of this nonzero pair Hamiltonian** is the Y line. **Critical source firewall:** Paper V-A, `p5:thm:v3105-k16-bl2-pair-corealization`, explicitly states `BL2_BOUNDARY_ACTION_OCCURRENCE=CONDITIONAL_OWNER` and `BL2_ACTION_NORMALIZATION=CONDITIONAL_NORMALIZATION`. The exact CAR identity is not evidence that the actual K16 owner consumes the pair. A full-owner Y stabilizer also requires the source's Y-covariant normal-part clause.

**Source:** `Paper5A-FiniteMatterGeometry-v3_213.tex`, `p5:thm:v3103-generated-bl2-family-coefficient`, `p5:prop:v382-majorana-car-spinor-intertwiner`, `p5:thm:v3105-k16-bl2-pair-corealization`, `p5:thm:v270-k16-action-hypercharge-ward`.

### G32-066: F_core⊗G finite role decomposition

On the **assumed/generated** source carrier `W=(2_L⊕1_R+⊕1_R-)`, `Q=(1_ell⊕3_C)`, `G=3`, build all 48 source basis vectors and six exact, orthogonal diagonal role projectors summing to identity. The ranks are `Q_L=18`, `L_L=6`, `u_R=9`, `d_R=9`, `nu_R=3`, `e_R=3`. From the source's `Y=T_R³+(B-L)/2`, verify the six rational eigencharges `(1/6,-1/2,2/3,-1/3,0,-1)` and the action of each of three family projectors (rank 16, commuting with all role projectors). This establishes the conditional finite-representation **content**, not independent GP2/GP3 selection of its original `F_core⊗G` owner or local QFT.

**Source:** `Paper5A-FiniteMatterGeometry-v3_213.tex`, `p5:thm:component-independence-composition`, `p5:prop:three-generation-content`.

## Three remaining mapped interfaces — exact boundary diagnoses

| ID | What is algebraically verified | What still cannot be promoted independently |
|---|---|---|
| `G32-052` | Two **supplied, independent** commuting M3(C) test families span the complete M9(C) tensor-action algebra (all 81 matrix units). | That the specific oriented Hurwitz incidence supplies the independent complementary color/family trimers and discharges the **source's GP2–GP3 multiplicity-sandwich premise**. Merely constructing M3⊗M3 from independent modules does not verify source generation. |
| `G32-056` | The row-energy formula `E56 T_nu` is dimensionally valid; for any externally supplied κ>0, `κ E56 T_nu` has the same dimensions. | Source-word proof of **absence of an additional generated dimensionless port** κ56. The printed theorem explicitly uses no-insertion conditional on no such port; this is not a separate universal mathematical nonuniqueness defect. The neutral terminal role gate is separately stated. |
| `G32-072` | Exact SU3 singlet projector `P=|I3><I3|/3` in `3⊗bar3` commutes with the eight color generators. `H0=0` and `Ht=tP` are equally color-invariant Hermitian operators but yield compressed singlet energies `0` and `t`. | The selected relative meson Hamiltonian, radial/hyperfine coefficients, and pole readout. The source explicitly supplies the relative H as an input rather than assigning masses from color alone. |

The exact boundary tests are replayed by `python verify_boundary_v134.py --check`. They characterize **precise open selection/occurrence obligations**, not a demand to reproduce conventional particle dynamics.

## Cumulative release and reproduction

- Effective current status: `data/v134_verified_frontier_status.json` (**21 verified conditional mathematical maps, 3 pending**); v1_33 layer is immutable historical evidence.
- Independent new certificates: `data/v134_scoped_math_replays.json`; remaining boundary tests and current source hashes: `data/v134_unresolved_boundary_tests.json`.
- Effective mathematical edges: `graph/mathematical_structure_network_effective_v134.graphml` and `.dot`; new four certificate edges only: `graph/batch23_verified_scoped_math_maps.graphml` and `.dot`.
- Validation: `python verify_scoped_math_v134.py --check`; `python verify_boundary_v134.py --check`; `python build_overlay_v134.py --check`; `python rebuild_effective_graph_v134.py --check`; `python verify_batch23_v134.py`; `python validate_geometry.py --fast`; `python verify_graph_exports.py`; `python verify_manifest.py`.
- Query: `python geometry_verified_query_v134.py --summary`, `--pending`, `--new` or `--edge G32-070`.
- Parent core structure object/typed relation/guard/composition JSON, original GraphML exports, v1_32 and v1_33 certificates, and all associated validators are retained bytewise. **No old ZIP, proof DAG, paper TeX or physical mass/decay additions are inserted.**

**Status:** Complete for this finite-map replay batch. Global semantic completeness, full historical mathematical regeneration, independent discharge of the remaining three source selections, and empirical predictions are **not claimed**.
