# Geometry-only Batch 11 — Regular 2T covering and exact C3 matching holonomy

**Release:** `Paper00-S3StructureNetwork-v1_22`. **Mathematical scope:** one fixed marked quaternionic 600-cell (`2I`), its embedded right `2T`, normal `Q8`, and the separate golden-`E8` incidence tensor transported to the common Hopf axes via the explicit left/right inversion from v1_20. This is a **source-independent exact composition** of the previously established geometry, not a new claim of literature novelty. No claim/theorem nodes or particle-transition semantics are present.

## 1. Genuine graph-covering tower — the base has THREE parallel edges

Let `G600` be the 12-regular nearest-neighbor graph on the 120 marked unit quaternions `2I`. Right multiplication by the fixed `2T` preserves every edge. Since the action is free on vertices and preserves each of the five right-`2T` cosets, there are five 24-vertex orbits and no within-coset edges. Exact enumeration of **720** nearest-neighbor edges under 24 elements gives **30** orbits, each of 24 edges, with exactly three orbits between each pair of cosets. The actual quotient is

\[
G_{600}/2T\;\cong\;3K_5,
\]

meaning a five-vertex **multigraph** with three parallel (but distinct) edges per pair, hence degree 12. Checking the star at **each** of the 120 vertices confirms that it has exactly one lifted edge over each of the twelve incident base multiedges: this is a *regular graph covering* of degree 24 with deck group right-`2T`, not merely an equitable vertex quotient. Forgetting the multiplicities would replace `3K5` by the ordinary degree-four `K5` and destroy the covering property.

Normality `Q8 ◁ 2T` and index three give the composable regular graph coverings

\[
\boxed{G_{600}\xrightarrow{\ /Q_8\ } K_{3,3,3,3,3}
  \xrightarrow{\ /(2T/Q_8)\ } 3K_5}\qquad
 (8,3,24)\text{ as cover degrees}.
\]

The intermediate graph has 15 vertices and 90 edges; the full graph and base have 120/720 and 5/30. Exact right-`Q8` edge orbit enumeration gives 90 orbits, each of eight edges, and every 24-edge `2T` orbit breaks into exactly three of them.

## 2. NEW cross-geometry identity: thirty `2T` edge orbits = thirty `E8` matchings

Take one of the 30 `2T` edge orbits joining two 24-vertex core cosets `a,b`. Project its 24 edges to the fifteen right-`Q8` axes. This gives three **distinct axis edges**, each with exactly eight preimages. They form one perfect matching between the three axes in core `a` and the three in core `b`.

The golden-`E8` weighted triple tensor independently defines three perfect matchings `M_ab^c` for each pair `a,b`, labelled by the three **other** cores `c`. Comparing actual axis pairs gives an **exact set equality for all 30 matchings**, not merely equality of counts or spectra:

\[
\boxed{\{\text{right-}2T\text{ edge-orbit matchings}\}
       =\{M_{ab}^{c}\text{ from the }E_8\text{ weight-2 tensor}\}.}
\]

This identifies the three *parallel edges* over each base pair with the three `E8`-selected third-core colours. The underlying graph quotient supplies the three unlabelled matching orbits; the `E8` tensor supplies a canonical **relative third-core label** for each matching. It is a precise map between the 600-cell and `E8` incidence geometries.

## 3. The residual `C3` really comes from quaternions

Choose `t∈2T\Q8` and act on all 120 600-cell vertices by **right** multiplication. The action descends to the fifteen right-`Q8` axis fibres; its quotient class generates `2T/Q8 ≅ C3`. It fixes the five core blocks and cycles each block's three axes. Direct comparison with the weighted tensor verifies that this permutation is an element of the already computed order-360 group `Aut(T)`, in fact a generator of its normal kernel over the five-core permutation group.

Therefore the order-three matching transports found in v1_21 are **the same exact cyclic subgroup** as the residual quaternionic deck group. This is an identification of operators/actions, not an inference from matching group orders.

## 4. An alternating five-core transport law

For an ordered pair of cores `a,b`, let `M_ab^c` map the three axes of `a` to those of `b`, using third core `c`, with `c` distinct from `a,b`. Let `c,d` be distinct possible third cores and let `e` be the remaining fifth core. Define the relative transporter on the first fibre by

\[
D_{ab}^{c,d}=(M_{ab}^{d})^{-1} M_{ab}^{c}.
\]

With `κ_a` the residual right-`2T/Q8` generator on the axes in `a`, complete computation of all **120 ordered distinct quadruples** shows

\[
\boxed{D_{ab}^{c,d}=\kappa_a^{\varepsilon\operatorname{sgn}(a,b,c,d,e)}}
\]

where `ε∈{+1,−1}` depends solely on the initially chosen generator `t` and enumeration orientation. The order-three relative rotation is geometrically fixed; **calling it +1 or −1 is a marking choice**. Reversing the five-core orientation or choosing `t^{-1}` interchanges the two exponents.

This compact alternating sign rule is an exact global organization of the thirty matching maps. It is strictly stronger than the local assertion that distinct matching choices differ by three-cycles.

## 5. Gauge-labelled holonomy, Bianchi and exactly 81 flat choices

Choose a trivialization of each three-element axis fibre compatible with the residual deck action. Each oriented core-edge choice `a→b` and third core `c` acquires a voltage `v_ab^c∈Z/3Z`. Reversing the edge negates the voltage. The three matchings for a fixed unoriented core pair attain **all three** voltages, exactly once. For a triangular closed path,

\[
F_{abc}=v_{ab}+v_{bc}+v_{ca}\pmod3.
\]

The coherent face choice—using third cores `c,a,b` for edges `ab,bc,ca`—has zero curvature for each of the ten triangles. Changing a matching can introduce nontrivial `C3` holonomy. For each triangle there are `3³=27` local edge choices: **nine give holonomy 0, nine +1, nine −1**. This is verified for all ten triangles.

For all five tetrahedral 4-vertex subsets `a<b<c<d`, the discrete Bianchi identity holds exactly:

\[
\boxed{F_{bcd}-F_{acd}+F_{abd}-F_{abc}=0\pmod3.}
\]

There are `3^{10}=59049` global choices of one of three matching maps for each of the ten core pairs. Exhaustive enumeration gives

\[
\boxed{\#\{F\equiv0\}=3^4=81,\qquad
\#\{\text{possible }F\}=3^6=729,}
\]

and each of the 729 curvature patterns has **81** preimages. This is also explained by the cochain sequence of the full five-vertex simplex: the edge-to-triangle coboundary has rank six over `F3`, and its kernel has dimension four.

**Crucial nonidentification:** There is *no canonically forced nonzero curvature* without specifying one particular matching on every traversed core pair. The 81 flat choices do not contradict the v1_21 impossibility of making **all three** matchings on every pair simultaneously diagonal. A single global flat matching choice is possible; simultaneously identifying the three distinct matching maps is not.

## 6. The 360-element automorphism extension actually splits

The exact weighted-tensor group of v1_21 fits into `1 → C3 → Aut(T) → S5 → 1`. The current independent permutation-group computation sharpens this to an actual **split extension**. The even-core-permutation preimage has order 180, and its commutator subgroup has order 60, is normal in the full group, and intersects the residual `C3` trivially. Lifting an odd transposition of the five cores gives an involution; together with that order-60 group it generates an order-120 subgroup, again intersecting the kernel trivially. Every odd core permutation inverts the residual `C3` generator.

Thus, for the fixed marked weighted design,

\[
\boxed{\operatorname{Aut}(T)\cong C_3\rtimes_{\rm sign}S_5.}
\]

The `C3` factor is the actual right-quaternion deck action just identified, not an arbitrary numerical rank coincidence. This result refines the previous release, which intentionally asserted only the short exact sequence.

## 7. Status, exact data, and reproducibility

All new statements are exact mathematical results on the given **marked** coordinate and incidence systems. Their supporting assertions include quaternion multiplication, actual 600-cell edge enumeration, 24- and 8-element edge orbits, local graph-covering checks at 120 vertices, equality of all 30 `E8` matching sets, all 120 ordered parity tests, all 59049 edge connection choices, every Bianchi relation, and full 360-element automorphism-group splitting checks.

They are **not** claims of an unknown universal classification of all `S³` geometry, an unmarked/canonical geometric curvature, or physical decay/charge/coupling consequences. Previous source-attested objects remain source-attested; the v1_22 compositions are independently regenerated.

### Files and commands

- `data/axis15_holonomy_v122_instance.json`: all thirty actual 24-edge orbits, the exact axis permutations, the 120 parity checks, 30 edge voltages, all 81 flat selections, and group certificate.
- `scripts/axis15_holonomy_v122.py`: regenerating source-independent exact algorithm.
- `verify_axis15_holonomy_v122.py`: strict reproduction and GraphML-size checks.
- `graph/batch11_3K5_three_parallel_edge_multigraph.graphml`: **literal parallel edges**, including the third-core labels.
- `graph/batch11_15axis_matching_voltage_graph.graphml`: literal 90-edge axis geometry with matching labels/voltages.
- `graph/batch11_120_to_15_to_5_vertex_fibres.graphml`: actual 120→15→5 quotient maps.
- `graph/batch11_C3_holonomy_geometry_bridges.graphml`: typed mathematical-object graph relationships.
- `graph/batch11_2T_C3_cover_tower.svg`: compact overview.

```bash
python verify_axis15_holonomy_v122.py
python verify_axis15_cubic_v121.py
python verify_graph_exports.py
python validate_geometry.py
python verify_manifest.py
python geometry_query.py --holonomy-tower
python geometry_query.py --holonomy-core-pair 0 1
python geometry_query.py --holonomy-triangle 0 1 2
```
