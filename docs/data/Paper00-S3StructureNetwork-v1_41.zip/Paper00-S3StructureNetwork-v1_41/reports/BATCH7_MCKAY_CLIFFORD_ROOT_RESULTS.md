# Geometry-only Batch 7 — affine McKay, common-`2T` restriction and Clifford/E8 intertwiners

**Release:** `Paper00-S3StructureNetwork-v1_18` (cumulative, 2026-11-16).  
**Primary TeX:** `Paper1B-ExceptionalGeometry-v1_14.tex`; SHA-256 `54f8c52f2b790148832eff12eae0a43957a27b0b9f2b38939dab0b378c4dbfb2`. Its actual source is in the separately supplied `Paper00-PapersMinimal-v3_023`.  
**Source anchors, not graph nodes:** `p1b:thm:v12-mckay-resolvent`, `p1b:cor:v13-all-irrep-etas`, `p1:prop:exceptional-shell-mckay-eigenvalues`, `p1b:thm:v16-mckay-class-angles`, `p1:prop:exroot-golden-action`, `p1:thm:exroot-explicit-e876`, `p1:thm:v370-e8-d4-triality`, `p1:thm:v273-two-icosahedral-completions`, and `p1:thm:hopf-clifford-finite-carrier`. All are located against the source-file hash in `data/primary_source_witnesses.json`.

This is a mathematical object/morphism graph. It contains **no proof-DAG nodes** and **no physical transitions**. The affine ADE graph associated with a finite subgroup of SU(2) must not be identified with the finite ADE *root lattice* solely because the two share an ADE label.

## 1. Exact reconstruction of the three McKay diagrams

Generate Hurwitz `H=2T` as 24 unit quaternions in `Q(sqrt 5)/4`; build the marked `I=2I` from the 120 finite vertices, and build the 48-element octahedral normalizer as `O=H ∪ ((1+i)/sqrt2)H` in `Q(sqrt2)/4`. Quaternion products and conjugacy classes are exact in the appropriate quadratic rings.

For each finite group `G`, the saved character table is a matrix with entries `(a+b*r)/2` where `r=i√3` (2T), `√2` (2O), or `√5` (2I). Its values are not accepted based on a floating-point fit: the verifier recomputes **exact central class-algebra structure constants**, tests all central character eigenvalue identities and the exact character orthogonality relations, and then constructs the tensor multiplicities of the defining complex 2D SU2 character. The resulting nonnegative integer adjacency is independently checked against the source-affine diagrams and their characteristic polynomials.

| Group | Order | Irreducibles | McKay diagram | Dimension vector | Edges |
|---|---:|---:|---|---|---:|
| `2T` | 24 | 7 | affine `E6` | `(1,1,1,2,2,2,3)` | 6 |
| `2O` | 48 | 8 | affine `E7` | `(1,2,3,4,3,2,1,2)` | 7 |
| marked `2I` | 120 | 9 | affine `E8` | `(1,2,3,4,5,6,4,2,3)` | 8 |

The exact affine adjacency spectra have polynomials:

```
2T: x(x²−4)(x²−1)²
2O: x²(x²−4)(x²−1)(x²−2)
2I: x(x²−4)(x²−1)(x⁴−3x²+1)
```

The complete trivial-representation multiplicities of symmetric powers `Sym^n V` through degree 60 agree exactly with the earlier independent Spin(4) harmonic data. This uses `b_(n+1)=A b_n−b_(n−1)`, `b_0=e_0` and `b_(-1)=0`; the full all-isotypic formal resolvent is `(I−tA+t²I)^−1 e_0`. The paper already contains the McKay diagrams and this recurrence: the new value here is a regenerated exact finite-character certificate and its integration into the geometry-only network.

## 2. **Additional geometric composition: affine E7 ↔ affine E8 through the common 2T core**

With the **same fixed embedded** `H=2T`, let `B_O:R(2O)→R(2T)` and `B_I:R(2I)→R(2T)` be representation restrictions, in the source's vertex order. Exact class-character inner products over all 24 H-elements produce integer matrices of shapes `7×8` and `7×9`:

```
A_T B_O = B_O A_O,
A_T B_I = B_I A_I,
B_O^T d_T = d_O,      B_I^T d_T = d_I.
```

The identity is naturality of tensoring by the same defining SU2 module. The source ordering of the two conjugate nontrivial 2T one-dimensional characters can be swapped together with their corresponding modules; the matrices below fix one consistent choice. Now compose **induction** from H to 2O with **restriction** from 2I to H:

```
X = B_O^T B_I : R(2I) → R(2O),
A_O X = X A_I,
rank(X) = 5,
spec(X^T X) = [10,10,4,4,2,0,0,0,0].
```

The nine exact columns of `X`, its 8 rows, and both restriction matrices are in `data/mckay_clifford_v118_instance.json`. Because the two source adjacency operators are symmetric and their common distinct eigenvalues are `−2,−1,0,1,2`, the five-dimensional `im(X)` consists precisely of the direct sum of these five one-dimensional eigenspaces in the affine E7 adjacency module. This is an *actual* integer intertwiner, not a graph-label coincidence. There is **no** assertion `2O⊂2I`; they are incomparable subgroups of SU2 sharing H.

The exact characteristic polynomial of `X^T X` is

`λ⁴(λ−10)²(λ−4)²(λ−2)`.

The dimension vectors also satisfy `X d_I=5 d_O` and `X^T d_O=2 d_I`, as expected from the two relative subgroup indices. These identities provide independent algebraic consistency checks.

## 3. **Explicit Clifford-to-golden-E8 group intertwiner**

Write each quaternion coordinate in `K=Q(φ)` as `x+yφ`, with `φ=(1+√5)/2` and `φ′=(1−√5)/2`. Algebraic scalar extension gives a **real-algebra isomorphism**

```
H⊗_Q K ⊗_Q R   →   H ⊕ H ≅ Cl(0,3),
q=x+yφ          ↦   (q_+=x+yφ, q_−=x+yφ′).
```

This real algebra splitting is **not** the same operation as the original integer coefficient map `ι(q)=(a,b)`, which is linear and need not preserve products. The actual coefficient Euclidean metric is the positive weighted Galois metric

```
w_+ = (√5−1)/(2√5)  >0,
w_− = (√5+1)/(2√5)  >0,
x²+y² = w_+(x+φ y)² + w_−(x+φ′ y)².
```

The equality holds coefficient by coefficient and is verified symbolically. Both Galois quaternion components of a marked unit `g∈2I` have unit norm, so left or right quaternion multiplication induces an exact orthogonal `8×8` operator on the coefficient model. The verifier constructs all 120 **left** and all 120 **right** rational matrices with denominator 2, checks `M^T M=I`, and checks each of the 240 E8 roots is mapped onto another root. Thus the marked group really does act as an orthogonal root-system automorphism, rather than being related to E8 merely by a root count.

The two complex degree-two spinor representations in the marked affine E8 character table are vertices `1` (the defining SU2 representation) and `7` (its field-Galois counterpart). Their characters satisfy the exact eight-dimensional real trace identity

`χ_8(g) = 2χ_V(g)+2χ_(V^σ)(g)`.

All 120 elements yield the integer character trace distribution

```
trace8: −8:1, −4:20, −2:24, 0:30, 2:24, 4:20, 8:1.
```

Under left multiplication the two 120-root sheets are two regular `2I` orbits. Under simultaneous left/right multiplication the only kernel is diagonal `±1`, since the center of 2I is `{±1}`. Hence the effective finite root automorphism subgroup is

`(2I_L×2I_R)/{(1,1),(−1,−1)}` of order `120²/2=7200`.

Under left or right `2T⊂2I`, both chosen D4 root banks from Batch 6 remain stable, while the three complementary 64-root triality sectors are permuted by a cyclic order-three quotient with **Q8 kernel of eight elements**. Both the group action and the sector-level permutation fibers have been enumerated exactly.

## 4. Mathematical scope and exclusions

- **Not two equal E8 objects:** the rank-nine **affine E8 McKay adjacency representation** and the rank-eight **finite E8 root lattice** are distinct, although we now exhibit a common group action and exact character comparison.
- **Not a second marked 2I construction:** the Galois spinor is a different *representation of the chosen marked 2I*. Identifying it with the other *subgroup completion* of the fixed 2T requires a separately specified map.
- **Not a Clifford algebra homomorphism from coefficient vectors:** the original `ι` map is only coefficient linear. The algebra splitting uses scalar extension and both field embeddings.
- **Not a physical model:** these integer intertwiners, root actions and incidence properties have no particle, mass, decay-width, or channel meaning supplied here.
- **Not globally complete:** legacy objects that still lack admitted geometric maps remain visible as disconnected or unresolved structures in the network. All new material is source-anchored and independently exact-checked; inherited source-only records do not become independent proofs automatically.

## 5. Files and replay

- `data/mckay_exact_character_seed_v118.json`: exact algebraic character tables with fixed class and source-vertex orderings.
- `data/mckay_clifford_v118_instance.json`: exact McKay graphs, two integer restrictions, rank-5 cross-ADE intertwiner, Galois spinor and E8 finite-group root-automorphism certificates.
- `scripts/mckay_clifford_v118.py`: regenerating exact class algebra, representation restriction and all 240-root action checks (no floating-point comparisons).
- `verify_mckay_clifford_v118.py`: exact rebuild-and-compare test.
- `graph/affine_mckay_2T.graphml`, `graph/affine_mckay_2O.graphml`, `graph/affine_mckay_2I.graphml`: actual affine ADE adjacency, not proof edges.
- `graph/batch7_BO_matrix_bipartite.graphml`, `batch7_BI_matrix_bipartite.graphml`, `batch7_X_matrix_bipartite.graphml`: integer correspondence edges and multiplicities.
- `graph/batch7_mckay_clifford_bridges.graphml`, `.dot`, `.svg`: object/morphism integration (70 edges), plus the cumulative full network.

From the unpacked release root:

```bash
python verify_mckay_clifford_v118.py
python validate_geometry.py
python verify_graph_exports.py
python verify_manifest.py
python geometry_query.py --mckay-group 2I
python geometry_query.py --mckay-restrict 2O
python geometry_query.py --mckay-cross
python geometry_query.py --clifford-e8
```
