# Geometry-only Batch 17 — v1_28

## Objective and limits

Continue the independent **mathematical-object network**, not the theorem/proof DAG, by connecting source-attested but previously isolated VI/VII geometries to the established finite `2I`/Petersen and continuous `S³` modules. All statements concern a fixed marked `2I` containing the ten `C6` axes. No stage *occurrence*, physical mass, decay channel, cosmological transfer or observed sky spectrum is inferred.

**Independent regeneration**: `python verify_batch17_v128.py`. Full data are `data/*v128_instance.json`; the saved source-label SHA-256 witnesses are in `data/batch17_current_tex_witnesses.json`. Source text is not bundled. The no-go and conditional interfaces are *not* turned into unrestricted edges.

## A. Exact rotational-icosahedral harmonic tower

Start with the ten actual 3×3 projectors `P_a = u_a u_aᵀ`, extracted from the marked `2T∩2T = C6` axes. Define

\[
M_{2j}(v)=\sum_{a=1}^{10}(v^{T}P_av)^j,\quad r^2=v^Tv.
\]

The exact `Q(√5)` polynomial expansions give

\[
M_2=\frac{10}{3}r^2,\quad M_4=2r^4,\quad
H_6=M_6-\frac{10}{7}r^6,\quad
M_8=\frac{10}{9}r^8+\frac{28}{15}r^2H_6,
\]
\[
H_{10}=M_{10}-\frac{10}{11}r^{10}-\frac{42}{17}r^4H_6,
\quad H_{15}=\det(v,\nabla H_6,\nabla H_{10}).
\]

The three Laplacians vanish symbolically, as does the Euler homogeneity defect. `H15` is nonzero and odd. All 120 marked `2I` elements conjugate the 20 oriented axis representatives into one another, ensuring `A5`-invariance. The rotational Molien rational expression simplifies exactly to

\[
\operatorname{Hilb}(\mathbb R[x,y,z]^{A_5};t)
=\frac{1+t^{15}}{(1-t^2)(1-t^6)(1-t^{10})}.
\]

The full ring presentation is a **source theorem**, not claimed to follow from the finite polynomial tests alone. For the antipodal 20-axis-point measure, the addition theorem verifies

\[
T_6=\frac{231}{160}H_6|_{S^2},\quad
T_6(u_a)=\frac{11}{81},\quad
\langle T_6^2\rangle_{S^2}=\frac{11}{1053}.
\]

The primary **left-circle** Hopf map is specifically `h(q)=q̄ i q`, not the opposite right-circle map `q i q̄`. Its real `R^4→R^3` Jacobian obeys `Dh Dhᵀ=4|q|²I₃` with harmonic coordinate components. The composed nonzero polynomial `Φ12=H6∘h` is degree 12, is harmonic in four real variables and has unit-round-`S³` scalar Laplacian eigenvalue 168. Because `2I` conjugates the ten axes, `Φ12(qg)=Φ12(q)` for `g∈2I`; the right-`2I` fixed `E12` subspace has dimension 13. This is an exact mathematical invariant, not an asserted physical state.

Source owners: `p6c:thm:v322-icosahedral-moment-tower`, `p6c:thm:v322-icosahedral-invariant-algebra`, `p6c:thm:v322-right2i-hopf-lift` and `p6b:prop:v322-angular-six`.

## B. Exact Petersen-pair / 25-cell / Chebyshev zero-band identity

Using the 120 quaternions, construct the 60 distinct five-core permutations modulo central sign. The matrices are entirely specified by these permutations:

- `B5` (`120×25`): a `1` in column `(π(g)j,j)` for each `j`.
- `Bu` (`120×100`): a `1` in column `(π(g)S,S)` for each of ten unordered core pairs `S`.
- `Bo` (`120×100`): identical support with sign induced by the order of the two permuted core indices.
- `P5=N5/6`, where `N5=−(A_Petersen−3I)(A_Petersen+2I)` on the ten pair labels.

All entries were rebuilt independently from the marked 2I group action, and the integer matrix identities hold **entrywise**:

\[
B_5^TB_5=24I_{25}+6(J_5-I_5)\otimes(J_5-I_5),
\]
\[
\boxed{B_uB_u^T-B_5B_5^T=24\Pi_{25}=U_4},
\]
\[
B_u(N_5\otimes N_5)B_u^T=36U_4.
\]

Here `U4` is the **exact 120×120 integer numerator** of the separately verified `v1_27` Chebyshev-character projector onto the 600-cell zero-adjacency band. No comparison relies merely on equal dimensions. Signed and unsigned Gram annihilator polynomials and their integer power traces yield the exact spectra:

| Matrix | Nonzero eigenvalues and multiplicities | Rank |
|---|---|---:|
| `B5 B5ᵀ` | `120¹, 30¹⁶` | 17 |
| `Bu Buᵀ` | `120¹, 30¹⁶, 24²⁵` | 42 |
| `Bo Boᵀ` | `40¹⁸, 30¹⁶` | 34 |
| `Bu Buᵀ+Bo Boᵀ` | `120¹, 60¹⁶, 40¹⁸, 24²⁵` | 60 |

Both coefficient images are center-even; the combined rank 60 proves their sum is the full center-even function space on marked `2I`. These are coefficient/incidence strengths, not particle energies.

Source owners: `p6:thm:cell-incidence`, `p6:thm:incidence-spectrum`, `p6:thm:v338-pair-incidence-full-rank`, plus independently tested `v1_27` Chebyshev projector.

## C. Scalar harmonic functional calculus and chamber comparison

On round `S³(r)`, `Δ_n=n(n+2)/r²` with scalar multiplicity `(n+1)²`. The inverse on the mean-zero subspace is `r²/[n(n+2)]` for `n≥1`. On the **separately marked momentum factor** `S³_p`, a finite auxiliary harmonic comparison cutoff `L` has `N_L=(L+1)(L+2)(2L+3)/6` modes. This does not identify the `S³_x` and `S³_p` roles or generate dynamics.

For the marked chamber comparison, Paper VI-B supplies the *source-owned* 25-vector

\[
R(T_6)=-\frac{55}{2304}\mathbf1_{25}
+\frac{77}{3072}\mathbf1_{5}\otimes(4,-1,-1,-1,-1).
\]

The supplied response coefficients are **not independently rederived** here; its contrast lies in the `−5/4` eigenspace of the exact comparison generator `I₅⊗(J₅−5I₅)/4`. Therefore its formal return has the `e^{-5t/4}` factor, with no empirical or cosmological interpretation.

## D. Completeness and deliberate nonconnections

Cumulative `v1_28`: **799 objects**, **1,185 typed relations**, **158 joint-input bundles**, **144 derivation records**. Eleven formerly isolated records became connected, leaving **88 isolated records** (three foundational/technical and 85 later-paper operators); no disconnected nontrivial component remains. This is not a proof of exhaustiveness. `reports/geometry_completeness_v128.json` gives the remaining full ledger.

In particular, a map `R^8→C^44` **cannot** be a coisometry: the target's real dimension is 88. This is independently checked and retained as a no-go, not falsely connected by an arrow. The separate constitutional `S¹` root is also not merged with a Hopf fibre merely to improve graph connectivity.

## Commands

```bash
python verify_batch17_v128.py
python verify_graph_exports.py
python validate_geometry.py --fast
python geometry_query.py --icosahedral-harmonics
python geometry_query.py --pair-gram
python geometry_query.py --s3-green
python geometry_query.py --geometry-coverage
python verify_manifest.py
```

The full historical regeneration (`python validate_geometry.py`) is separate and **has not been completed for this release**. The earlier mathematical instances and inherited certificates are retained unchanged; source-witness verification is not a reproof of all earlier papers.
