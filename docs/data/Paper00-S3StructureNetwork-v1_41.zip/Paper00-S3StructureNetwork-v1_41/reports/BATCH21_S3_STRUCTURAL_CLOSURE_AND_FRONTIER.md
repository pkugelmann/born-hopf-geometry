# Geometry-only Batch 21 (v1_32): S³ structural-graph closure and source-scoped frontiers

Parent: `Paper00-S3StructureNetwork-v1_31.zip`, uploaded archive unpacked directly. This archive is the **mathematical object graph** and does not copy or change the proof/evidence DAG, papers, physical mass predictions, gauge action or measured particle data.

## Exact new structural certificates

1. **Five-core 20→9 nonet projector.** On the 20 directed ordered distinct core pairs, the 60 even permutations of A5 give `20=(1+4+5)+(4+3+3')`. Fix the 5-cycle hand. Compute exact central idempotents in Q(sqrt5). With 20×20 integer U,V, `P9=(U+sqrt5 V)/120`; check `U²+5V²=120U`, `UV+VU=120V`, `P9ᵀ=P9`, A5 equivariance for all 60 group elements, rank 9, complement rank 11. The signed 3/3' hand is *not* dropped. This realizes the precise mathematical comparison of Paper VII-B `p11:thm:v1158-directed-two-core-nonet`, not nine physical mesons.
2. **Hermitian 9-space Jordan/Lie bridge.** A *chosen* A5 isometry identifies `1+3+5` with `Herm3(C)=R I + i so(3) + Sym0(R3)`. Jordan `(XY+YX)/2` and traceless compact bracket `-i[X,Y]` have source-specific meaning after choosing Upsilon. The determinant invariant is checked symbolically. There is no unmarked canonical matching of 20 pair labels to SU3 color states.
3. **Exact ten-axis nonet triplet Gram.** Re-read all ten original `P_i=u_i u_iᵀ` from the inherited instance, confirm `Σ_iP_i=(10/3)I` over Q(sqrt5), and hence `(1/10)Σ_i(I−P_i)/4=I/6`. Multiplication by a supplied E36² yields `E36² P3/6`, but no physical E36 meson mass.
4. **Exact Hurwitz constant+quadratic 10-band.** Independently enumerate all 24 Hurwitz unit vertices. For `t=q·r`, `K=(1+16t²)/120=P0+(4/15)P2`; `rank P0=1`, `rank P2=9`; `K` has eigenvalues `1(1),4/15(9),0(14)`. This is only the quadratic-incidence part of Paper V-D's polar return; its additional unital P17 action remains source-attributed.
5. **Petersen exterior 45→15 map.** Explicit 15×45 integer coordinate projection onto disjoint-pair wedges. `JJᵀ=I15`, `JᵀJ` has `1(15),0(30)`. It is A5-equivariant with the standard oriented-edge sign, matching the actual source comparison not supplying a meson splitting.
6. **Petersen auxiliary 6×6 chiral block.** From singular values `(2,1/2,1/2)`, exact characteristic polynomial `(z²−4)(z²−1/4)²` and source diagonal resolvent. Dimensionless comparison, not physical poles.
7. **Round S3 scalar spectral family.** Verify shell `lambda_k=k(k+2)/R²`, degeneracy `(k+1)²`, finite count `(L+1)(L+2)(2L+3)/6`, mean-zero Green and spectral-function composition. A selected Proca longitudinal mode has `omega²=lambda_k+m²` for k≥1,m>0 after its nondynamical field is eliminated. Positive-frequency one-particle realization and cosmological cold retarded response remain distinct, explicitly guarded downstream interfaces.
8. **Icosahedral 62-node sampling.** Independently construct 12 vertices, 30 edge-midpoints and 20 face-centers on unit S2, apply source weights `(125,256,81)/462` by orbit. The 36-column degree<=5 harmonic frame is numerically isometric with max residual below 2e-15, with the degree-six-to-five leakage below tolerance. Source Paper I-B proves exact degree-eleven cubature; the new numerical replay is not an algebraic source-proof substitute.

## Graph connectivity / scope

| Quantity | v1_31 | v1_32 |
|--|--:|--:|
| Mathematical objects | 849 | 862 |
| Typed relations | 1,320 | 1392 |
| AND-input bundles | 185 | 242 |
| Compositions | 171 | 183 |
| Previously isolated objects newly linked | — | 48 |
| Remaining isolates | 53 | 5 |
| S3-root component | 794 | 855 |
| Other nontrivial components | 1 | 1 |

The 53 previous isolates have **53/53 current-source label+file-hash witnesses** in `data/v132_current_tex_isolate_witnesses.json` and individual link/no-link dispositions in `data/v132_remaining_frontier_classification.json`. This is 100% **inventory classification**, not 100% mathematical or semantic exhaustiveness; 24 second-pass links are source formula-guarded and not independently certified. A guarded edge connects nodes for navigation but never establishes the entire source owner or physical interpretation.

No forced S1-to-Hopf-fibre identification, no 8-real-dimensional onto 88-real-dimensional coisometry, no S3-momentum to Euclidean momentum-ball conflation, no flat fixed-band kernel-to-S3 intrinsic identification, no isolated 9-state meson physical-pole interpretation. Pending exact mathematical maps remain OPEN in the ledger. The separate original abstract Gram component is preserved as separate until an actual marked intertwiner is found.

## Verification and files

`python verify_batch21_v132.py`, `python verify_graph_exports.py`, `python validate_geometry.py --fast`, `python verify_manifest.py` and `python geometry_query.py --batch21 --closure-frontier` (also `--classification NODE_ID`). `data/structure_closure_v132_instance.json` is reproducible by `python scripts/structure_closure_v132.py` without mutation; use `--write` only to regenerate intentionally. For every source-target relation a fresh current Tex anchor is included; none becomes a proof DAG edge. Historical full regeneration and all historical source-semantic reviews were not done in this batch.

## Second pass: source-formula scoped completion of remaining 24 candidates

The 24 source-located records previously carrying `OPEN_MATERIAL_MAP_NOT_CERTIFIED` do have **partially explicit source-domain operator maps** to existing mathematical nodes, e.g. rational A2 traces, finite charge anomaly coefficients, the K16 CAR hypercharge commutator, the root-6 curvature isometry, finite-collar DtN functional calculus, and conditional relative meson compression. They are included as **24 new conditional navigation links**, one labelled and source-hash anchored per object, with their full premises in `HYP-G32-34..57`. This does not independently reproduce the full 24 source proof chains; see `data/v132_remaining_frontier_classification.json` status `LINKED_SOURCE_FORMULA_GUARDED_EXACT_CERTIFICATE_OPEN`.

Cumulative network: **862 objects / 1392 relations / 242 joint guards / 183 compositions**. The S³-root weak component has **855 nodes**, with **5 deliberate unmapped records** and the historical separate two-node abstract Gram component intact.

Independent checks now also verify exact selected 3x3 A2 Hilbert--Schmidt traces, all four rational one-generation finite anomaly sums, integer-hypercharge Z6 kernel-generator congruences, and the 2T regular-orbit invariant-sum lemma. No local QFT, physical spectrum, meson mass, or cosmic source is inferred.

**Completion is source-located map *coverage*, not unconditional derivational closure.** No positive map is inserted for the 5 intentional non-identifications.
