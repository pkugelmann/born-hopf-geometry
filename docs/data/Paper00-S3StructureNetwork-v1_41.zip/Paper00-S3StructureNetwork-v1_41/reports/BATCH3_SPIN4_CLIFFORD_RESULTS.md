# Batch 3 — exact Spin(4), exceptional harmonic and Clifford bridges

**Release:** `Paper00-S3StructureNetwork-v1_14` · **Parent:** `v1_13` · **Subject:** mathematical representations and intertwiners of the round quaternionic three-sphere only.

## Source scope and non-novelty rule

The primary witnesses are the *current* `PapersMinimal-v3_023` TeX versions of Paper I-A (`v5_178`), I-B (`v1_14`), I-C (`v1_142`), and II-F (`v1_67`). Every promoted relation is mathematical; sources are attributes and not nodes or links. See `data/primary_source_witnesses.json` for exact claim labels, line numbers and source SHA-256 hashes.

**The Molien series, quotient spectra, 600-cell design, and the twin projector identities are already present in the papers.** Here they have been *independently recomputed* from exact quaternion coordinates and assembled into one typed geometric network. The newly explicit cross-construction paths do not assert that the underlying theorems are new.

## 1. Continuous Spin(4) and Hopf-symbol branch

Let `S³(R) ≅ SU(2)`, let `V_n=Sym^n(C²)` (complex dimension n+1) and let the round group action be `(g_L,g_R):q↦g_L q g_R⁻¹`. Then the scalar harmonic band is

`E_n(S³)_C ≅ V_n ⊗ V_n*`, with `dim(E_n)=(n+1)²`, and `Δ|E_n=n(n+2)/R²`.

Under the diagonal SU(2) subgroup, `End(V_n) = ⊕_{ℓ=0}^n V_(2ℓ)`. This gives the dimension identity `sum_{ℓ=0}^n (2ℓ+1)=(n+1)²` and the coherent-state symbol to the finite window of `S²` harmonics. The coherent-state map is *not* ordinary Hopf pullback; the latter selects the zero Hopf-charge modes in even S³ shells only. Borel–Weil supplies `H⁰(CP¹,O(n)) ≅ V_n*` with the chosen dual convention.

## 2. All-degree finite-subgroup character averages

For a finite unit-quaternion subgroup `G` define its Reynolds projector on `V_n`:

`P_G^(n)=(1/|G|) sum_{g∈G} rho_n(g)`, with `m_G(n)=rank(P_G^(n))`.

The SU(2) character of `V_n` is `U_n(Re(g))` (Chebyshev polynomial of second kind). Hence the Molien series is the *exact rational function*

`M_G(t)=sum_n m_G(n) t^n= (1/|G|)sum_{g∈G} (1-2t Re(g)+t²)⁻¹`.

Exact class-average rational simplification gives:

| Group | Molien series | first `n>0` with `m_G(n)>0` | first scalar quotient eigenvalue | multiplicity |
|---|---|---:|---:|---:|
| 2T | `(1+t¹²)/((1-t⁶)(1-t⁸))` | 6 | 48/R² | 7 |
| 2O | `(1+t¹⁸)/((1-t⁸)(1-t¹²))` | 8 | 80/R² | 9 |
| 2I | `(1+t³⁰)/((1-t¹²)(1-t²⁰))` | 12 | 168/R² | 13 |

The scalar spaceform multiplicity is `(n+1)m_G(n)`, not `m_G(n)` alone. Exact coefficients are stored through `n=60` as a practical table, **and the rational functions above were checked symbolically for all degrees**, not inferred from only 61 coefficients. For the two embedded 2I completions the Molien functions coincide; they nevertheless remain different *embedded* subgroups.

## 3. Connection between five 24-cell cosets and harmonic cancellations

With `H=2T⊂I=2I`, choose left-coset representatives `g_j` so that `I=⋃_{j=1}^5 g_j H`. For any `v∈V_n^H`:

`(1/5)∑_{j=1}^5 rho_n(g_j)v=P_I^(n)v`.

For `n=6` and `n=8`, the H-fixed space has dimension one, whereas `V_n^I=0`. Therefore the *five translated Hurwitz components sum to zero as representation vectors* in each of those degrees. This mathematically explains part of the enhancement from the Hurwitz 24-cell's five-design strength to the 600-cell's eleven-design strength. More generally, `m_I(n)=0` for all `1≤n≤11` shows that the uniform unit 600-cell vertex orbit is a spherical eleven-design by Peter–Weyl.

This is a group-representation average and **not** a decomposition of physical states, a decay channel, or an operator on a particle spectrum.

## 4. A precise twin completion comparison

From the chosen exact 120-quaternion `2I` coordinate set over `Q(√5)`, apply field conjugation `√5↦−√5` to every coordinate. The resulting 120-set equals the conjugate `u I u⁻¹` for `u=(1+i)/√2` acting by `(q₀,q₁,q₂,q₃)↦(q₀,q₁,−q₃,q₂)`. Their exact intersection contains 24 points, precisely the selected Hurwitz `H=2T`. These are the two completions **as an unordered pair**; this computation does not canonically label the coordinate branch `I_+` versus `I_-`.

At `n=12`, the invariant dimensions are

`dim V_12^H=2`, `dim V_12^O=1`, `dim V_12^I=dim V_12^{u I u⁻¹}=1`.

Let `P_I,P_I′` be the orthogonal rank-one projectors on the 13-dimensional `V_12` and let `P_H,P_O` be the corresponding rank-two and rank-one projectors. Two independent exact character calculations give

- signed normalizer overlap `⟨v,rho_12(u)v⟩=−5/16` for a unit I-fixed vector v;
- `tr(P_I P_I′)=25/256` from the exact 14,400-pair quaternionic double character sum.

The source-identified *twin Reynolds mean* therefore satisfies

`A_H=(P_I+P_I′)/2=(21P_H−10P_O)/32`,

`A_H²−A_H=−(231/1024)P_H`.

Its nonzero eigenvalues on `V_12^H` are `11/32` on the `O`-even line and `21/32` on the `O`-odd line. On the full scalar shell `E_12=V_12⊗V_12*`, their multiplicities are 13 and 13, and zero has multiplicity 143. **A_H is not a projector.** This matches the explicit result of Paper II-F and the follow-on Paper I-C result, rather than claiming a new theorem.

The source also proves that the two distinct embedded 2I copies generate a dense subgroup of SU(2), so simultaneously invariant nonconstant functions are absent despite their nonzero *projector overlap* (two different notions).

## 5. Real Clifford models and normalizations

The Pauli matrices give an explicit Spin(4)-equivariant quaternionic coordinate map `X(q)=q₀I−i(q₁σ₁+q₂σ₂+q₃σ₃)` and a Hermitian chiral block operator `Γ(q)=[[0,X(q)],[X(q)†,0]]` on `S_+⊕S_−≅C⁴`.

The four coordinate generators satisfy `{Γ_a,Γ_b}=2δ_ab I₄`. The sixteen real Clifford basis monomials have full real rank 16 in this matrix model. The full `2⊗2=3_s⊕1_a` Clebsch–Gordan isometry is exhibited and verified on finite quaternionic generators.

**Separately**, three anti-Euclidean generators in two opposite quaternionic chiral blocks give a faithful real eight-dimensional algebra `Cl(0,3) ≅ H⊕H`, with pseudoscalar operator `Ω=diag(+I₂,−I₂)`; the eight Clifford monomials are independent over R.

The real `Cl(4,0)` and `Cl(0,3)` algebras are *not identified*. The protected Paper I-B Clifford coordinate representative has its own independent algebraic scale `ρ_prot` and cannot be equated with exact finite compression of the radius-R sphere coordinates. Any further map needs this separate input.

## Reproducibility

- `data/spin4_exact_representation_instance.json`: class census, mₙ and quotient-spectrum tables n=0..60, exact twin fractions, Clifford conventions.
- `verify_spin4_representations.py`: independently rebuilds and checks the rational Molien identities, Galois/normalizer sets, exact character overlaps, and Clifford matrices. Uses existing exact 120-vertex coordinates as input.
- `graph/batch3_spin4_clifford_bridges.graphml`: focused mathematical subnetwork; `graph/mathematical_structure_network.graphml` is cumulative.
- `data/joint_input_relations.json`: twelve new joint constructions prevent one-parent arrows being mistaken for complete proofs.

Run:

```
python verify_spin4_representations.py
python validate_geometry.py
python verify_manifest.py
python geometry_query.py --spin4-spectrum 2I --degree 12
python geometry_query.py --spin4-twin-angle
python geometry_query.py --spin4-clifford
```

## Remaining mathematical work

Full branch-by-branch restriction into all nontrivial irreducible representations of 2T/2O/2I; full McKay adjacency/intertwiner matrices beyond the trivial-isotypic Molien data; scalar-to-spinor/Hodge quotient operator restrictions with spin-structure choices; all individual Hopf-weight matrix intertwiners; second embedded subgroup’s independent 600-cell graph structure; exhaustive classification of the 123 older isolated geometry nodes. No inference to observed physical masses or decays is made here.
