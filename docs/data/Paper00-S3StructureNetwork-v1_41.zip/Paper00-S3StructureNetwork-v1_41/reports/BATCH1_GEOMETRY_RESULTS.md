# Batch 1: exact exceptional geometry and cross-structure compositions

## Status distinction

**Source premises independently rechecked numerically:** 24 Hurwitz units and 120 icosian vertices, group closure over `Q(sqrt(5))`, five index-five cosets, the 600-cell 720-edge nearest-shell graph, and its quotient matrix `3(J5−I5)`. Their mathematical content is already present in Paper I-B; reproducing them is verification, not new physics or a novelty claim.

**New explicit compositions/structural relations in this network:**

1. **Equivariant identification of the two five-point actions:** for the fixed `H≅2T`, `N_I(H)=H`, hence `Θ(gH)=gHg⁻¹` identifies the left cosets with the conjugate tetrahedral subgroups. For each `a ∈ I`, `Θ(agH)=aΘ(gH)a⁻¹`.
2. **Canonical edge-to-`C6` projection:** write `c: I→I/H` for the 24-cell-coset coloring. Every nearest-neighbor edge `{u,v}` has `c(u)≠c(v)`, so

   `ε({u,v}) = Θ(c(u)) ∩ Θ(c(v)) ∈ {ten distinct C6 subgroups}`.

   This labeling is `I`-equivariant under left multiplication, with ten fibers of size 72, indexed as Petersen vertices. The 720 edges are partitioned into ten *edge sets*; the associated 48-vertex subgraphs overlap in vertices. Their union is not a disjoint decomposition of vertex sets.
3. **Ten cyclic cube covers:** For each unordered pair `(i,j)`, the subgroup `C_ij=H_i∩H_j` preserves the induced 48-vertex bipartite graph `Γ_ij`. The exact certificate verifies connectedness, every orbit of the order-6 action having size six, and a 4×4 `C6`-orbit biadjacency matrix of the form `J4−P` for a permutation matrix `P`. Thus `Γ_ij / C_ij ≅ K4,4\M ≅ Q3` and `Γ_ij → Q3` is a connected six-sheeted regular graph covering. There are 12 edge orbits in every `Γ_ij`, each a six-edge matching.
4. **Exact finite adjacency spectral invariants:** For every one of the ten covers, the characteristic polynomial is

   `x^12 (x²−9)(x²−6)^4(x²−4)^6(x²−3)^4(x²−1)^3`.

   The quotient cube has `χ(x)=(x²−9)(x²−1)^3`. The cover spectrum consists of `±3` (multiplicity 1 each), `±√6` (4 each), `±2` (6 each), `±√3` (4 each), `±1` (3 each), and `0` (12).

All these statements are finite mathematical claims reproducible from the explicit coordinates, not consequence by mere graph path navigation.

## Important non-identifications

- The coset `gH` (a translated 24-vertex set) is **not** the subgroup `gHg⁻¹` (a conjugate subgroup). The latter is the **left stabilizer** of the former; they correspond as *labels* via `Θ`.
- One coordinate model of `2I` is **not** automatically both of Paper I-B's two marked `I±` completions relative to the same fixed `H`.
- The `Q3` orbit quotient and Paper I-B's Hurwitz link cube `N(1)` have the **same abstract graph type**. They have no canonical map of embedded geometry supplied by this computation.
- `C6` matching orbits are mathematical incidence data, not physical interaction strengths.

## Checks actually performed

- Explicit list of 120 unit quaternions with coefficients in `Q(sqrt5)` and unique normalized integer-pair arithmetic.
- Exact multiplicative closure of `2T` and `2I`.
- Exact dot-product test `u·v=φ/2` for all 7140 unordered vertex pairs.
- Five cosets, their five conjugate core stabilizers, ten distinct `C6` intersections, and the three-core central intersection.
- Every 120-vertex left `2I` translation preserves the five-coset/core action.
- Per-axis `C6` orbit sizes, exact quotient biadjacency, orbit matchings, and connectivity for all ten pairs.
- Exact integer symbolic 48×48 and 8×8 characteristic polynomials, for **all ten axes**.

## Source scopes and provenance

TeX source: `Paper1B-ExceptionalGeometry-v1_14.tex` from `Paper00-PapersMinimal-v3_023`, SHA256 `54f8c52f2b790148832eff12eae0a43957a27b0b9f2b38939dab0b378c4dbfb2`. Key labels include:

- `p1:thm:v273-two-icosahedral-completions` (fixed 2T, 2O, twin 2I)
- `p1:cor:v237-five-core-ten-axis-packet` (five cores and ten intersections)
- `p1:cor:nearest-shell-inclusion-consequences` (five-coset nearest-shell walk)
- `p1:thm:v338-petersen-tight-frame` (ten pair-incidence/Petersen structure)
- `p1:prop:hurwitz-link-cube` (the Hurwitz sign cube)

Proof/DAG audit claims are *not copied*; original claim IDs are only source pointers.

## Still open for this graph

The older 400 source-attested geometric objects remain broadly accepted as named mathematical structures but have not all undergone the same independent finite verifier. In particular, 104 unadmitted scoped constructions and unresolved disconnected math components remain. No assertion of global geometry completeness or new experimental results is made.
