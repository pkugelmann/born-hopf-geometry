# Batch 22 — independently replayed source-scoped mathematical maps (v1_33)

**Parent:** Paper00-S3StructureNetwork-v1_32. **Scope:** S³ mathematical relation-network proof-evidence overlay, not an edit to the global audit DAG, parent paper source, terminal observable dictionary, or physical action. All 24 mapped current-paper source files were re-opened and exact SHA-256/label references matched their inherited anchors. The parent mathematical graph and historical validators remain bytewise unchanged.

## Outcome and explicit limitation

- **17** of the **24** v1_32 mathematically guarded source-map relations have *independent conditional mathematical replays* (`G32-049,050,051,053,054,055,057,058,060,062,063,064,065,067,068,069,071`); the current v1_33 overlay marks the **mathematical submap only**, and preserves all previously stated source-domain guards.
- **7** retain `SOURCE_FORMULA_SCOPED_MAP_PROOF_REPLAY_PENDING` (`G32-052,056,059,061,066,070,072`). The source-state names may be connected by guarded navigation links but are not independently proved here.
- **Zero** upstream constructor, source-selected state, particle pole, physical field, or entire source theorem has been promoted or inferred solely from these tests.
- Graph topology **unchanged**: 862 objects, 1,392 typed relations, 242 joint-input bundles, 183 compositions; 855 objects in the S³-root component; five intentional no-morphism isolates and one independent two-object abstract Gram component.
- The immutable `data/mathematical_relations.json` still records historical v1_32 `SOURCE_RESTRICTED_MATHEMATICAL_MAP_EXACT_PROOF_NOT_REPLAYED`. The current **effective** status is in `data/v133_verified_frontier_status.json`, available as `graph/mathematical_structure_network_effective_v133.graphml`; reading the old main GraphML alone will not show the upgrades. This separation is deliberate for replay of the parent release.

## Higher-value exact checks

### 1. All three 15D A5-equivariant Clifford/Petersen modules (G32-051)

Set U=Λ² R⁵, dim U=10 and Λ² U=45. The 15 disjoint pair-pair wedges form E₁₅. The other 30 have a common root r and consist of Λ² R⁴ in each of five rooted 4D complements. The rooted Hodge star uses the *induced 5D orientation* (including the (-1)^r orientation sign); forgetting that sign would destroy full A₅ equivariance. Independent integer matrix construction verifies

- `star²=P_overlapping`, `2P±=P_overlapping±star`, `(2P±)²=2(2P±)`, P+P−=0 and rank(E₁₅)=rank(O₁₅⁺)=rank(O₁₅⁻)=15.
- All 60 signed exterior actions commute with the rooted star and disjoint projector, not just one generator.
- Each sector has character 15 at the identity, −1 on 15 double transpositions, zero on 20 three-cycles and both classes of 12 five-cycles. Consequently each decomposes as 3⊕3′⊕4⊕5 by the A₅ character table.

This improves v1_32, which certified only the disjoint 45→15 exterior map. It still does not supply a physical two-source interaction.

### 2. Trimer flavor local capacity (G32-067)

From the source-specific explicit matrices I, D_I=diag(2/3,-1/3,-1/3), D_II=diag(0,1,-1), C₁=X+X†, C₂=−i(X−X†), the direct Jacobian of the ten trace invariants at the source's A* and B* has determinant **−159690424320**. The two leading-principal-minor triples are `(32/3,1102/9,24032/27)` and `(40/3,1123/9,30760/27)`, both positive. Discriminants are 3240 and 50240; the common commutant of A*,B* has complex dimension one; `(1/(6i))Tr([A*,B*]^3)=378`. This independently reproduces full local rank-ten capacity and a noncommuting, CP-sensitive sample. **No numerical CKM prediction** follows without evaluating a selected physical source member.

### 3. Finite-collar DtN: strictly sharper mathematical theorem (G32-069)

For L>0, Neumann endpoint and A≥0 selfadjoint, direct ODE solution and spectral calculus give `K_L=√A tanh(L√A)`. The paper's uniform norm inequality `||√A−K_L||≤1/(eL)` is correct. In fact for x≥0,

`x(1−tanh x)=2x/(e^(2x)+1)`.

Its unique positive stationary maximum has `x*=(1+W(e^(−1)))/2`, where W is the principal Lambert W. At that point `2x*/(e^(2x*)+1)=W(e^(−1))≈0.2784645428`. Thus the universally sharp inequality is

`||√A−K_L|| ≤ W(e^(−1))/L < 1/(eL)`.

Equality is achievable with a one-dimensional scalar operator at spectral value `(x*/L)^2`, so sharpness is mathematical, not merely numerical. For a fixed round S³ discrete spectrum, the actual best norm may be smaller. The normalized ratio stays nonuniform at y=0: its error supremum is 1 for any finite L. **No unbounded physical collar realization is inferred.**

### 4. Exact finite representation and current-map replays

The G5 finite-charge table yields vanishing rational SU3²Y, SU2²Y, grav²Y, Y³ and SU3³ coefficients, with four weak doublets per family (even parity). Exhausting the complete compact central kernel using primitive integer `qY=6Y` gives exactly six elements `(ω3^n,(-1)^n,e^(iπ n/3))`, n=0,…,5; this does **not** identify the internal weak SU2 with the spatial Spin4 action or construct a spacetime-local gauge theory. The distinguished-line character has kernel b=a/2 in its stated two-dimensional torus plane, which need not equal the full action stabilizer.

An independent exact 3×3 Fourier-unitary example verifies current trace covariance, reconstruction `M=V_u P V_dᵀ` under simple terminal weights and a nonzero CP-sensitive example. The role-incidence map `W_u†W_d` is unitary only assuming both maps are surjective isometries into the same family space. An exact rank-one tagged polar decomposition and transitive-orbit transfer lattice checks complete the elementary conditional matrix interfaces. None chooses the physical mass/CKM inputs.

### 5. Remaining conditional interfaces

The source-scoped E40/E56 gap algebra, one-complex-doublet/pseudoreal Dirac type, S(U1×U3) split stabilizer, finite representation anomaly coefficients and final-octet closed top-form differential also pass local mathematical tests. The E48 empty-projector statement, color/family selection, neutral row-energy uniqueness, and cosmological response still require their antecedent constructors or occurrence conditions; they are **not** newly proved simply by checking formulas.

## Seven explicitly open map tests

| Relation | Missing independent test |
|---|---|
| `G32-052` | GP2 independent color–family tensor composition and multiplicity selection |
| `G32-056` | E56 unique terminal energy owner / absence of extra neutral normalization |
| `G32-059` | Actual nonzero K16 CAR Hopf–axial action pair and full stabilizer |
| `G32-061` | Marked octahedral odd rank-three representation and projection |
| `G32-066` | Source-selected `F_core⊗G` matter carrier and GP2–GP3 multiplicity |
| `G32-070` | Explicit rooted Clifford 6D isometry plus E6 root/curvature section |
| `G32-072` | Selected meson relative Hamiltonian and physical spectral readout |

These are the next logical targets; connection in the S³ graph alone cannot discharge them.

## Reproduction

Run `python verify_scoped_math_v133.py --check`, `python rebuild_effective_graph_v133.py --check`, `python verify_parent_v132_integrity_v133.py`, `python verify_batch22_v133.py`, `python validate_geometry.py --fast`, `python verify_graph_exports.py`, `python verify_manifest.py`, and `python geometry_verified_query_v133.py --summary` or `--pending` or `--edge G32-051`. The parent v1_32 validation suite remains executable because the v1_32 mathematical JSON and graph exports were not modified.

All independent proof code and results are self-contained. External paper sources are referenced by hashes and labels, **not** copied into this mathematical graph archive.
