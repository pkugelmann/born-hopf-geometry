#!/usr/bin/env python3
"""Regenerate and independently cross-check the mathematical golden E8 batch.
Uses exact integer root coordinates and short 8x8 Gram argument; no floating tolerance.
"""
import pathlib,json,sys,collections,hashlib
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts.golden_e8_v117 import build,dot,vecplus,vecneg,reflect
j=json.loads((ROOT/'data/golden_e8_v117_instance.json').read_text())
replayed=build()
assert replayed==j, 'regenerated exact integer root incidence must match frozen instance'
roots=[tuple(r['coordinates_doubled']) for r in j['roots_240']];I=set(roots)
assert len(I)==240 and len(j['root_addition_6720_graph_edges'])==6720
assert len({(tuple(sorted((i,k)))) for i,k in j['root_addition_6720_graph_edges']})==6720
# Check actual root-addition relation independently against stored 240 edges.
for i,k in j['root_addition_6720_graph_edges']:
 assert vecneg(vecplus(roots[i],roots[k])) in I and dot(roots[i],roots[k])==-2
for a in roots:
 assert dot(a,a)==4
 assert all(reflect(b,a) in I for b in roots)
triples=j['root_addition_2240_triples']
assert len(triples)==2240 and len({tuple(t) for t in triples})==2240
assert all(i<k<h and vecplus(vecplus(roots[i],roots[k]),roots[h])==(0,)*8 for i,k,h in triples)
part=j['root_triple_class_counts'];assert part['D0,D0,D0']==part['D1,D1,D1']==32
assert part['X0,X1,X2']==1024 and len(part)==9
# All 64x64 cross sector M_ab are exactly products of the two factor support maps.
for x in j['triality_cross_sector_pairs']:
 assert x['edge_count']==1024 and x['Kronecker_rank']==25
 a,b=x['pair'];A=j['three_X64'][a];B=j['three_X64'][b]
 F=x['left_8x8_weight_compatibility'];G=x['right_8x8_weight_compatibility']
 Aroots=[roots[i] for i in A];Broots=[roots[i] for i in B]
 ai={u:i for i,u in enumerate(sorted({r[:4] for r in Aroots}))}
 bi={u:i for i,u in enumerate(sorted({r[:4] for r in Broots}))}
 aj={u:i for i,u in enumerate(sorted({r[4:] for r in Aroots}))}
 bj={u:i for i,u in enumerate(sorted({r[4:] for r in Broots}))}
 edges={(i,k) for i,k in x['bipartite_edges_local_indices']};assert len(edges)==1024
 for i,r in enumerate(Aroots):
  for k,s in enumerate(Broots):
   predicted=F[ai[r[:4]]][bi[s[:4]]]*G[aj[r[4:]]][bj[s[4:]]]
   assert predicted == int((i,k) in edges)
 def verify_weight(B):
  assert sum(map(sum,B))==32
  H=[[sum(B[i][k]*B[j][k] for k in range(8)) for j in range(8)] for i in range(8)]
  P=[[int(i!=j and H[i][j]==0) for j in range(8)] for i in range(8)]
  assert all(sum(row)==1 for row in P) and all(P[i][i]==0 for i in range(8))
  assert all(H[i][j]==2*(1+int(i==j)-P[i][j]) for i in range(8) for j in range(8))
  # P^2=I and P 4 disjoint transpositions; Gram eigen 16^1,4^4,0^3.
  assert all(sum(P[i][k]*P[k][j] for k in range(8))==int(i==j) for i in range(8) for j in range(8))
 verify_weight(F);verify_weight(G)
# The 192-node compatibility 2-section has exactly 1024 triangles, one per
# zero-sum hyperedge: there are no additional/spurious triangles.
edgepairs={tuple(x['pair']):set(map(tuple,x['bipartite_edges_local_indices']))
           for x in j['triality_cross_sector_pairs']}
triangle_count=sum((a,c) in edgepairs[(0,2)] and (b,c) in edgepairs[(1,2)]
                   for a,b in edgepairs[(0,1)] for c in range(64))
assert triangle_count==j['exact_invariants']['triality_2section_triangles']==1024
# E6 fibres; every 27-set 45 root-sum triples, each projected weight occurs five times.
e6=j['E7_E6_A2_sections'];assert (len(e6['E7_roots']),len(e6['E6_roots']),len(e6['A2_perpendicular_roots']))==(126,72,6)
for f in e6['six_27weight_fibers']:
 W={tuple(q) for q in f['weights_projected_int_x3']};assert len(W)==27
 assert sorted(map(len,f['D1_Weyl_orbits']))==[1,1,1,8,8,8]
 assert len(f['triple_support'])==45
 for tri in f['triple_support']:
  assert len({tuple(v) for v in tri})==3
  assert all(sum(v[t] for v in tri)==0 for t in range(8))
 assert set(collections.Counter(tuple(v) for t in f['triple_support'] for v in t).values())=={5}
# Source provenance must match paper TeX hashes recorded in this release.
references=json.loads((ROOT/'data/primary_source_witnesses.json').read_text())
for key in ('golden','e8root','triality','shell','e6','certificate'):
 w=references['g17:'+key]
 assert len(w['tex_sha256'])==64 and w['line']>0 and w['claim_id'].startswith(('p1:','p1c:'))
assert j['ordinary_600cell_24_plus_3x32']['equitable_nearest_neighbor_Q']==[[0,4,4,4]]+[[3,3,3,3]]*3
print('PASS exact golden E8: 240 roots, 2 orthogonal D4, 3x64 reflection orbits, 2240 zero-sum triples')
print('PASS all three 64x64 triality compatibility matrices: rank25, singular 16(1),8(8),4(16),0(39)')
print('PASS E7/E6 roots and all six 27-weight/45-triple fibres; 600-cell 24+3x32 equitable Q')
