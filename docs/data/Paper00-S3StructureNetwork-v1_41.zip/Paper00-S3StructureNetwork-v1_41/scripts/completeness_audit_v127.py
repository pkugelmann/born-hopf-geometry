#!/usr/bin/env python3
"""Strict connectivity audit; a link does not certify a proof or global completeness."""
import pathlib,json,networkx as nx,collections
R=pathlib.Path(__file__).resolve().parents[1]
def rd(f):return json.loads((R/'data'/f).read_text())
def build():
    O=rd('objects.json');E=rd('mathematical_relations.json')
    G=nx.Graph();G.add_nodes_from(o['id'] for o in O);G.add_edges_from((e['from'],e['to']) for e in E)
    cc=sorted(nx.connected_components(G),key=len,reverse=True);iso=set(nx.isolates(G))
    found=lambda o:not o['id'].startswith(('geo:b6:','geo:b7:','geo:b8:'))
    records=[]
    for o in O:
        if o['id'] not in iso:continue
        later=not found(o)
        records.append({'id':o['id'],'name':o['name'],'object_type':o['object_type'],
                        'witness_claim':o.get('witness',{}).get('claim_id'),
                        'bucket':'LATER_PAPER_MATH_OPERATOR_AWAITING_GEOMETRIC_MAP' if later else 'FOUNDATIONAL_OR_TECHNICAL_OBJECT_AWAITING_MATHEMATICAL_MAP',
                        'status':'ISOLATED_NO_ADMITTED_GEOMETRIC_EDGE'})
    exact_new=sum(z['verification'].startswith('EXACT_') for z in E if z.get('batch')=='v1_27')
    return {'version':'v1_27','parent':'v1_26','method':'weak components of mathematical object-morphism graph; isolates are records, not automatically proof gaps',
       'counts':{'mathematical_object_records':len(O),'typed_morphism_records':len(E),'joint_input_bundles':len(rd('joint_input_relations.json')),
                 'derived_composition_records':len(rd('derived_compositions.json')),
                 'weak_components':len(cc),'component_containing_S3':len(nx.node_connected_component(G,'geo:s3')),
                 'largest_weak_component':len(cc[0]),'isolated_objects':len(iso),
                 'isolated_foundational_or_core_records':sum(found(o) and o['id'] in iso for o in O),
                 'isolated_later_operator_records':sum(not found(o) and o['id'] in iso for o in O),
                 'nontrivial_disconnected_components':sum(len(c)>1 for c in cc[1:]),
                 'new_v127_exact_or_algebraically_regenerated_relations':exact_new},
       'nontrivial_disconnected_components':[sorted(c) for c in cc[1:] if len(c)>1],
       'isolate_ledger':records,
       'remaining_technical_attention':['geo:s1_root is an independent constitutional S1 role, not identified with Hopf fibre merely to connect graph',
              'geo:quantum_free_dispersion requires a chosen positive-frequency/mass operator source before direct geometric map',
              'geo:quantum_auxiliary_pair_poles should not be promoted from auxiliary spectral calculations to physical mass poles',
              '96 later-paper mathematical operators require explicit source-scoped maps or scope classification'],
       'status':'NOT_EXHAUSTIVE: connectivity is not proof, and not all mathematically distinct objects/morphisms in the papers are yet classified'}
if __name__=='__main__':
    x=build();p=R/'reports/geometry_completeness_v127.json';p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n');print(json.dumps(x['counts'],indent=2))
