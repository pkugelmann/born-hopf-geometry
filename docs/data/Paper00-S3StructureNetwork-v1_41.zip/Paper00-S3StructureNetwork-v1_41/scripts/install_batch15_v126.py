#!/usr/bin/env python3
"""Install exact total-Petersen cover + source-scoped Milnor spectral connections.

Adds only mathematical objects/maps; source-label bookkeeping is NOT graph data.
Idempotent.  Run inside the release root as `python -m scripts.install_batch15_v126`.
"""
from __future__ import annotations
import json,pathlib,hashlib,xml.etree.ElementTree as ET
from collections import Counter
from .petersen_total_v126 import build as build_petersen
from .milnor_spectral_v126 import build as build_milnor
from .ten_axis_projectors_v126 import build as build_c6
ROOT=pathlib.Path(__file__).resolve().parents[1]
D=ROOT/'data';G=ROOT/'graph'

def rd(name):return json.loads((D/name).read_text())
def wr(name,x): (D/name).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')

sP=rd('primary_source_witnesses.json')
W_A={'claim_id':'p1a:proposition:atlas-milnor-normal-form-0d88235','file':'Paper1A-Geometry-v5_178.tex','line':799,'tex_sha256':'970cf792a328b0d55f8327c8869250dae964be0edf15a943a7dcc7a2efb2551c'}
W_FR={'claim_id':'p1:def:general-spectral-frame','file':'Paper1A-Geometry-v5_178.tex','line':871,'tex_sha256':W_A['tex_sha256']}
W_SC={'claim_id':'p1:thm:general-left-invariant-scalar-spectrum','file':'Paper1A-Geometry-v5_178.tex','line':899,'tex_sha256':W_A['tex_sha256']}
W_HD={'claim_id':'p1:thm:general-left-invariant-hodge-dirac-compiler','file':'Paper1A-Geometry-v5_178.tex','line':1013,'tex_sha256':W_A['tex_sha256']}
W_HT={'claim_id':'p1:thm:general-spectral-heat-and-limits','file':'Paper1A-Geometry-v5_178.tex','line':1199,'tex_sha256':W_A['tex_sha256']}
W_C6={'claim_id':'p3c:thm:v237-generated-clifford-exceptional-resolution','file':'Paper3C-ProtectedHierarchy-v1_191.tex','line':2148,'tex_sha256':'32ed1db85861b46b23adf8d4b73ad946c5a19a04c5fcc6b3b5e312f8bd76af1c'}
W_PE={'claim_id':'p1:thm:v371-petersen-600cell-total-cover','file':'Paper1B-ExceptionalGeometry-v1_16.tex','line':734,'tex_sha256':'e1e317b8faa190737434da8ac3860166e83404148f0c67ea73aba6c93a27e210'}

exact='EXACT_QSQRT5_SHELL_INCIDENCE_TOTAL_GRAPH_AND_MATRIX_INTERTWINER_V126'
block='EXACT_SU2_SPIN_MATRIX_AND_MILNOR_JACOBI_IDENTITY_V126'
attest='CURRENT_SOURCE_ATTESTED_MATHEMATICAL_COMPILER_NOT_FULLY_REGENERATED_V126'

newO=[
 ('shellD20','Real-half quaternion shell D20 inside marked 600-cell','finite_root_orbit',W_PE,exact),
 ('shellZ30','Pure-imaginary quaternion shell Z30 inside marked 600-cell','finite_root_orbit',W_PE,exact),
 ('totalD50','Induced 50-vertex dodecahedral total graph T(D20)','finite_graph',W_PE,exact),
 ('tau_total50','Quaternion-inversion free involution on T(D20)','finite_group_action',W_PE,exact),
 ('totalP25','25-vertex Petersen total graph T(P10)','finite_graph',W_PE,exact),
 ('total50_cover25','Regular twofold graph covering T(D20)→T(P10)','regular_graph_covering',W_PE,exact),
 ('total_graph_spec','Exact T(D20)/T(P10) adjacency characteristic polynomials','adjacency_operator',W_PE,exact),
 ('milnor_spin_Hj','Metric-adapted spin-j anisotropic SU(2) Laplace blocks H_j','spectrum_or_operator',W_SC,block),
 ('milnor_parity','Step-two weight parity chains of each SU(2) scalar block','orthogonal_representation_decomposition',W_SC,block),
 ('milnor_j1_inverse','Spin-one metric recovery from three pair-sum eigenvalues','mathematical_invariant_or_construction',W_SC,block),
 ('milnor_bound','Exact spectral lower bound H_j≥w_min*j(j+1)I','mathematical_invariant_or_construction',W_SC,block),
 ('milnor_berger_transport','Marked quaternion inversion and SO(3) coframe transport to primary Berger family','real_linear_embedding',W_A,attest),
 ('ten_c6_tight_frame','Ten exact C6 quaternion-axis rank-one projector tight frame identities','finite_incidence_operators',W_C6,exact),
]
objects=rd('objects.json');objids={x['id'] for x in objects}
for key,name,typ,w,ver in newO:
 k='geo:g26:'+key
 if k not in objids:
  objects.append({'id':k,'name':name,'object_type':typ,'scope':'mathematical_structure_or_morphism','source_kind':'exact_construction_v126','conditional':False,'batch':'v1_26','verification':ver,'witness':w});objids.add(k)
assert len(set(objids))==len(objects)

# Source-defined arrows don't become independently proved by sharing a witness.
# All arrows are actual restriction, construction, quotient, operator or
# functional maps; never citation or proof dependencies.
linkdata=[
 ('geo:600cell','geo:g26:shellD20','REAL_PART_PLUS_HALF_SHELL_SELECTION',exact,W_PE),
 ('geo:600cell','geo:g26:shellZ30','REAL_PART_ZERO_SHELL_SELECTION',exact,W_PE),
 ('geo:g26:shellD20','geo:dodecahedron20','SHELL_INDUCED_DODECAHEDRAL_NEAREST_GRAPH',exact,W_PE),
 ('geo:g26:shellD20','geo:g26:totalD50','TOTAL_GRAPH_VERTEX_PART',exact,W_PE),
 ('geo:g26:shellZ30','geo:g26:totalD50','TOTAL_GRAPH_EDGE_VERTEX_PART',exact,W_PE),
 ('geo:dodecahedron20','geo:g26:shellZ30','BIJECTIVE_DODECAHEDRAL_EDGE_TO_MIDPOINT_MAP',exact,W_PE),
 ('geo:g26:totalD50','geo:g26:tau_total50','RESTRICTION_OF_QUATERNION_INVERSION_AUTOMORPHISM',exact,W_PE),
 ('geo:g26:tau_total50','geo:g26:total50_cover25','ORBIT_QUOTIENT_DECK_INVOLUTION',exact,W_PE),
 ('geo:g26:totalD50','geo:g26:total50_cover25','REGULAR_GRAPH_QUOTIENT_BY_FREE_C2',exact,W_PE),
 ('geo:g26:total50_cover25','geo:g26:totalP25','TWO_TO_ONE_GRAPH_COVERING_MAP',exact,W_PE),
 ('geo:petersen_graph','geo:g26:totalP25','GRAPH_TOTALIZATION_VERTEX_AND_EDGE_INCIDENCE',exact,W_PE),
 ('geo:g26:totalD50','geo:petersen_600','EXPLICIT_SOURCE_50VERTEX_REALIZATION',exact,W_PE),
 ('geo:petersen_600','geo:g26:totalP25','QUATERNION_INVERSION_TOTAL_GRAPH_QUOTIENT',exact,W_PE),
 ('geo:g26:totalD50','geo:g26:total_graph_spec','EXACT_INTEGER_ADJACENCY_CHARPOLY_50',exact,W_PE),
 ('geo:g26:totalP25','geo:g26:total_graph_spec','EXACT_INTEGER_ADJACENCY_CHARPOLY_25',exact,W_PE),
 ('geo:g26:total50_cover25','geo:g26:total_graph_spec','ADJACENCY_INTERTWINER_A50C_CA25',exact,W_PE),
 ('geo:left_invariant_metric','geo:milnor_frame','METRIC_DEPENDENT_MILNOR_ORTHONORMALIZATION',attest,W_A),
 ('geo:milnor_frame','geo:general_spectral_frame','METRIC_ADAPTED_SU2_REPRESENTATION_FRAME',attest,W_FR),
 ('geo:general_spectral_frame','geo:g26:milnor_spin_Hj','PETER_WEYL_SCALAR_BLOCK_CONSTRUCTION',block,W_SC),
 ('geo:g26:milnor_spin_Hj','geo:scalar_tridiagonal','EXACT_STEP_TWO_JACOBI_MATRIX',block,W_SC),
 ('geo:g26:milnor_spin_Hj','geo:g26:milnor_parity','WEIGHT_PARITY_INVARIANT_SUBSPACES',block,W_SC),
 ('geo:g26:milnor_spin_Hj','geo:g26:milnor_j1_inverse','J1_WEIGHT_SUM_INVERSE_METRIC_SPECTRUM',block,W_SC),
 ('geo:g26:milnor_spin_Hj','geo:g26:milnor_bound','SU2_CASIMIR_POSITIVE_SPECTRAL_BOUND',block,W_SC),
 ('geo:scalar_tridiagonal','geo:general_heat_traces','HEAT_TRACE_AS_SUM_OF_FINITE_SCALAR_BLOCKS',attest,W_HT),
 ('geo:general_spectral_frame','geo:hodge_dirac_compiler','EXTERIOR_AND_CLIFFORD_HODGE_DIRAC_FINITE_BLOCKS',attest,W_HD),
 ('geo:hodge_dirac_compiler','geo:general_heat_traces','HODGE_AND_SQUARED_DIRAC_HEAT_TRACE_BLOCK_FUNCTIONAL',attest,W_HT),
 ('geo:left_invariant_metric','geo:g26:milnor_berger_transport','INVERSION_AND_HOMOTHETY_ON_SPECIAL_METRIC_SLICE',attest,W_A),
 ('geo:g26:milnor_berger_transport','geo:berger_family','FRAME_CORRECT_OPPOSITE_TO_PRIMARY_BERGER_TRANSPORT',attest,W_A),
 ('geo:spin4_harmonics','geo:g26:milnor_spin_Hj','SU2_PETER_WEYL_REPRESENTATION_CARRIER',block,W_SC),
 ('geo:ten_c6_subgroups','geo:c6_projectors','C6_INTERSECTION_TO_SIGNLESS_QUATERNION_LINE_PROJECTOR',exact,W_C6),
 ('geo:c6_axes','geo:c6_projectors','UNORIENTED_C6_AXIS_TO_RANK_ONE_PROJECTOR',exact,W_C6),
 ('geo:c6_projectors','geo:g26:ten_c6_tight_frame','SUM_OF_FIVE_LOCAL_AND_ONE_GLOBAL_TIGHT_FRAMES',exact,W_C6),
 ('geo:five_tetrahedral_cores','geo:g26:ten_c6_tight_frame','FIVE_LOCAL_TETRAHEDRAL_FRAME_IDENTITIES',exact,W_C6),
]
rels=rd('mathematical_relations.json');eid={x['id'] for x in rels}
for n,(a,b,relation,ver,w) in enumerate(linkdata,1):
 rid=f'G26-{n:03d}'
 if rid not in eid:
  assert a in objids and b in objids,(a,b)
  rels.append({'id':rid,'from':a,'to':b,'relation':relation,'link_type':'exact_mathematical_construction_or_source_scoped_operator_map','source_relation':'EXPLICIT_GEOMETRIC_MAP','conditions_preserved':True,'verification':ver,'witness':w,'batch':'v1_26'});eid.add(rid)

joint=rd('joint_input_relations.json');known={x['id'] for x in joint}
newH=[
 ('01',['geo:g26:shellD20','geo:g26:shellZ30'],['geo:g26:totalD50'],['single marked 2I root set','real part taken relative to identity','shortest-edge threshold Re(q^-1 r)=phi/2'],'exact shell selection and graph incidence'),
 ('02',['geo:g26:totalD50','geo:g26:tau_total50','geo:petersen_graph'],['geo:g26:total50_cover25','geo:g26:totalP25'],['free quaternion inversion on D∪Z','Petersen edge vertices identified by source midpoint map'],'twofold total graph quotient'),
 ('03',['geo:left_invariant_metric','geo:milnor_frame','geo:general_spectral_frame'],['geo:g26:milnor_spin_Hj'],['metric-dependent left Milnor coframe','a,b,c positive','inversion before comparison with primary right Hopf frame'],'full j-block scalar Laplace compiler'),
 ('04',['geo:left_invariant_metric','geo:g26:milnor_berger_transport','geo:berger_family'],['geo:g26:milnor_berger_transport'],['special slice a=b≠c','marked inversion to primary right coframe','homothety after metric choice'],'not an identity of untransported metric tensors'),
 ('05',['geo:five_tetrahedral_cores','geo:ten_c6_subgroups','geo:c6_projectors'],['geo:g26:ten_c6_tight_frame'],['fixed embedded 2I; no physical axis selected','ten common C6 intersections','quaternion unit-axis projectors are sign-independent'],'local 4/3 and global 10/3 exact tight frames'),
]
for ix,inputs,outputs,conditions,description in newH:
 hid='HYP-G26-'+ix
 if hid not in known:
  joint.append({'id':hid,'kind':'exact_joint_input_geometry_or_explicit_frame_condition','inputs':inputs,'outputs':outputs,'conditions':conditions,'result':description,'verification':exact if ix in ('01','02') else block if ix=='03' else attest})
comps=rd('derived_compositions.json');known={x['id'] for x in comps}
newC=[
 ('01','Dodecahedral total-graph realization inside 600-cell','600[D20 ∪ Z30]=T(D20), 50 vertices, 150 edges','select D20 real-half and Z30 real-zero shells of same marked 2I','Exact dot products give D20 nearest graph 3-regular with 30 edges. Each Z30 vertex meets exactly its two corresponding D20 endpoints; two Z vertices are adjacent exactly when those edges share an endpoint.','source result independently regenerated'),
 ('02','Petersen total-graph regular double covering','T(D20)/<q→q^{-1}> = T(P10), degree 2','free inversion on D20 and Z30 and locally bijective star maps','All 50 vertices form 25 involution pairs; quotient adjacency has 75 edges, six neighbors per vertex, and exactly the Petersen total-graph incidence relations. The 50×25 incidence matrix C satisfies A50 C=C A25 and C^T C=2I.','source result independently regenerated'),
 ('03','Exact total-graph spectral factorization','chi25(x)=(x-6)(x-1)(x+2)^5(x²-3x-2)^5(x²+3x+1)^4','Petersen 25-vertex quotient adjacency','Integer 25×25 characteristic polynomial factored exactly, with its 50×50 lift polynomial separately saved.','additional independently computed invariant'),
 ('04','Anisotropic SU(2) scalar matrix-block formula','H_j = wbar j(j+1)I+(w3-wbar)J3²+(w1-w2)(J+²+J-²)/4','metric-dependent Milnor left frame, a_i>0','Algebraic SU2 identities give the step-two Jacobi matrix and Casimir lower bound. Exact spin matrices were checked for j=0...4 and four metric choices.','source formula independently checked'),
 ('05','Spin-one inverse anisotropy spectrum','Spec(H_1)={w1+w2,w2+w3,w3+w1}','metric-dependent SU2 scalar block j=1','The three unordered pair sums reconstruct the positive metric eigenweights up to axis permutations; round normalization a_i=R/2 gives λ3=8/R².','source formula with independent algebraic derivation'),
 ('06','Quaternion C6 axis projector tight frame','Σ_{j≠i}P_ij=(4/3)I3 and Σ_{i<j}P_ij=(10/3)I3','five 2T cores in one marked 2I; ten six-element intersections','Select the unique order-six generator with real part +1/2 in each C6, take its imaginary unit line, form its rank-one orthogonal projector. Rational Qsqrt5 matrix arithmetic verifies all five local and global sums.','source result independently regenerated'),
]
for n,name,formula,hyp,proof,status in newC:
 rid='D26-'+n
 if rid not in known:
  comps.append({'id':rid,'name':name,'formula':formula,'hypotheses':[hyp],'proof':proof,'status':status,'verification':'EXACT_INDEPENDENT_V126' if n!='05' else 'EXACT_SU2_REPRESENTATION_ALGEBRA_V126','instance_file':'data/petersen_total_v126_instance.json' if n in ('01','02','03') else 'data/ten_axis_projectors_v126_instance.json' if n=='06' else 'data/milnor_spectral_v126_instance.json'})

# Graph arcs are navigational. Multi-input constructions require all owner nodes;
# their individual arcs MUST NOT imply standalone sufficiency.
guards={
 'G26-004':['geo:g26:shellD20','geo:g26:shellZ30'],
 'G26-005':['geo:g26:shellD20','geo:g26:shellZ30'],
 'G26-008':['geo:g26:totalD50','geo:g26:tau_total50'],
 'G26-009':['geo:g26:totalD50','geo:g26:tau_total50'],
 'G26-010':['geo:g26:totalD50','geo:g26:tau_total50','geo:petersen_graph'],
 'G26-013':['geo:g26:totalD50','geo:g26:tau_total50'],
 'G26-027':['geo:left_invariant_metric','geo:milnor_frame'],
 'G26-028':['geo:left_invariant_metric','geo:g26:milnor_berger_transport','geo:berger_family'],
 'G26-032':['geo:five_tetrahedral_cores','geo:ten_c6_subgroups','geo:c6_projectors'],
 'G26-033':['geo:five_tetrahedral_cores','geo:ten_c6_subgroups','geo:c6_projectors'],
}
for e in rels:
 if e['id'] in guards:e['requires_joint_inputs']=guards[e['id']]

wr('objects.json',objects);wr('mathematical_relations.json',rels);wr('joint_input_relations.json',joint);wr('derived_compositions.json',comps)
wr('petersen_total_v126_instance.json',build_petersen())
wr('milnor_spectral_v126_instance.json',build_milnor())
wr('ten_axis_projectors_v126_instance.json',build_c6())
wr('v126_release_counts.json',{'version':'v1_26','parent':'v1_25',
 'new_objects':len([x for x in objects if x.get('batch')=='v1_26']),
 'new_typed_relations':len([x for x in rels if x['id'].startswith('G26-')]),
 'new_joint_inputs':len([x for x in joint if x['id'].startswith('HYP-G26-')]),
 'new_derived_compositions':len([x for x in comps if x['id'].startswith('D26-')]),
 'cumulative_objects':len(objects),'cumulative_edges':len(rels),'cumulative_joint_inputs':len(joint),'cumulative_compositions':len(comps)})

ns='http://graphml.graphdrawing.org/xmlns'; ET.register_namespace('',ns)
def el(name,attrib={}):return ET.Element('{'+ns+'}'+name,attrib)
def make_graph(path,nodes,edges,label='v126',directed=True):
 r=el('graphml')
 definitions=[('d0','node','label'),('d1','node','kind'),('d2','node','batch'),('d3','node','verification'),('d4','edge','id'),('d5','edge','relation'),('d6','edge','verification'),('d7','edge','requires_and_inputs')]
 for id,kind,attr in definitions:ET.SubElement(r,'{'+ns+'}key',{'id':id,'for':kind,'attr.name':attr,'attr.type':'string'})
 g=ET.SubElement(r,'{'+ns+'}graph',{'id':label,'edgedefault':'directed' if directed else 'undirected'})
 for o in nodes:
  n=ET.SubElement(g,'{'+ns+'}node',{'id':o['id']})
  for k,v in [('d0',o.get('name',o['id'])),('d1',o.get('object_type','')),('d2',o.get('batch','')),('d3',o.get('verification',''))]:
   ET.SubElement(n,'{'+ns+'}data',{'key':k}).text=str(v)
 for z in edges:
  e=ET.SubElement(g,'{'+ns+'}edge',{'id':z['id'],'source':z['from'],'target':z['to']})
  for k,v in [('d4',z['id']),('d5',z['relation']),('d6',z.get('verification','')),('d7',','.join(z.get('requires_joint_inputs',[])))]:
   ET.SubElement(e,'{'+ns+'}data',{'key':k}).text=str(v)
 ET.ElementTree(r).write(path,encoding='utf-8',xml_declaration=True)
make_graph(G/'mathematical_structure_network.graphml',objects,rels,'S3_mathematical_geometry_v126')
batchrel=[x for x in rels if x['id'].startswith('G26-')]; batchids={x['from'] for x in batchrel}|{x['to'] for x in batchrel}
make_graph(G/'batch15_petersen_total_milnor_geometric_connections.graphml',[x for x in objects if x['id'] in batchids],batchrel,'S3_batch15_bridges')

def finite_graph(name,n,edges):
 oo=[{'id':str(i),'name':str(i)} for i in range(n)]
 ee=[{'id':f'e{i}','from':str(a),'to':str(b),'relation':'UNDIRECTED_NEAREST_ADJACENCY'} for i,(a,b) in enumerate(edges)]
 make_graph(G/name,oo,ee,name,False)
f=rd('petersen_total_v126_instance.json')
finite_graph('batch15_induced_dodeca_total50.graphml',50,f['edges_total50'])
finite_graph('batch15_total_petersen25.graphml',25,f['edges_total_petersen25'])
finite_graph('batch15_dodeca20.graphml',20,f['edges_D20'])
make_graph(G/'batch15_twofold_petersen_cover.graphml',
 [{'id':f't:{i}','name':f'50-vertex {i}'} for i in range(50)]+[{'id':f'p:{i}','name':f'25-vertex {i}'} for i in range(25)],
 [{'id':f'cover:{i}','from':f't:{i}','to':f'p:{j}','relation':'TWO_FOLD_COVER_FIBRE_MAP'} for i,j in enumerate(f['projection_50_to_25'])],'S3_batch15_cover')
print('INSTALLED',len(objects),'objects',len(rels),'relations',len(joint),'joint-inputs',len(comps),'compositions')
