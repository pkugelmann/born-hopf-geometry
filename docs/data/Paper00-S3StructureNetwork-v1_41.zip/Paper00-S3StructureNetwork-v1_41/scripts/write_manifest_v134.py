#!/usr/bin/env python3
"""Generate cumulative SHA256 manifest for S3 mathematical network v1_34."""
import hashlib,json,pathlib
r=pathlib.Path(__file__).resolve().parents[1]
parent=pathlib.Path('/mnt/data/Paper00-S3StructureNetwork-v1_33.zip')
S=json.loads((r/'data/v134_verified_frontier_status.json').read_text())
P=json.loads((r/'data/v134_parent_manifest_snapshot.json').read_text())
files=[]
for p in sorted(r.rglob('*')):
 if not p.is_file() or p.name=='MANIFEST.json' or '__pycache__' in p.parts or p.suffix in ('.pyc','.zip'):
  continue
 files.append({'path':p.relative_to(r).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
M={
 'version':'v1_34','parent':'v1_33','theme':'S3StructureNetwork',
 'archive_root':'Paper00-S3StructureNetwork-v1_34',
 'release_type':'cumulative_S3_geometric_graph_and_independent_conditional_proof_overlay',
 'parent_archive_sha256':hashlib.sha256(parent.read_bytes()).hexdigest() if parent.is_file() else None,
 'parent_manifest_version':P['version'],'parent_manifest_files':len(P['files']),
 'historical_data_and_graphs_mutated':False,'physical_transition_edges':0,'theorem_claim_nodes_added':0,
 'proof_dag_copied':False,
 'cumulative_objects':862,'cumulative_edges':1392,'cumulative_joint_inputs':242,'cumulative_compositions':183,
 'isolated_object_records':5,'main_connected_component':855,
 'source_scoped_map_candidates':S['original_frontier_count'],
 'independent_conditional_map_replays_total':S['replay_count'],
 'new_independent_conditional_map_replays':S['newly_verified_count'],
 'pending_source_scoped_map_replays':S['pending_count'],
 'source_theorems_or_physical_occurrences_promoted':0,
 'newly_verified_relation_ids':S['newly_verified_ids'],
 'pending_relation_ids':S['pending_ids'],
 'effective_verification_source':'data/v134_verified_frontier_status.json',
 'effective_graph':'graph/mathematical_structure_network_effective_v134.graphml',
 'checks':['verify_scoped_math_v134.py --check','verify_boundary_v134.py --check','build_overlay_v134.py --check',
    'rebuild_effective_graph_v134.py --check','verify_parent_v133_integrity_v134.py','verify_batch23_v134.py',
    'validate_geometry.py --fast','verify_graph_exports.py','verify_manifest.py'],
 'verification_summary':{'exceptional_2O_quotient':'PASS exact','E6_root_clifford_isometry':'PASS exact',
   'K16_CAR_action_only_given_occurrence':'PASS exact conditional','finite_matter_Fcore_tensor_G':'PASS exact conditional',
   'remaining_three_precise_boundaries':'PASS exact counterfamily/source guard check',
   'source_selection_theorem_proof':'THREE PENDING','physical_action_occurrence':'NOT PROMOTED',
   'full_historical_regeneration':'NOT RUN','semantic_exhaustiveness':'NOT CLAIMED'},
 'files':files,
}
(r/'MANIFEST.json').write_text(json.dumps(M,indent=2,ensure_ascii=False)+'\n')
print('WRITE SHA256 manifest',len(files),'non-manifest files')
