#!/usr/bin/env python3
"""Batch 8: exact Q8 triality orbit quotient and McKay D4 restriction.

All root, incidence, and group assertions are recomputed using integer
quaternion operations. The order of root sets is inherited from v1_17 data.
The result is MATHEMATICAL ONLY, not a source proof DAG, Lie bracket or
physical transition. The comparison does not assert an isomorphism.
"""
from __future__ import annotations
import collections, json, pathlib
import sympy as sp
from . import exceptional_model as ex
from . import mckay_clifford_v118 as mc
from . import golden_e8_v117 as gold

ROOT=pathlib.Path(__file__).resolve().parents[1]
C=collections.Counter

def q8_elements():
    H,_=ex.generate_vertices()
    q=sorted(h for h in H if all(b==0 for a,b in h) and sum(a!=0 for a,b in h)==1)
    assert len(q)==8
    assert {mc.qmul(x,y,5) for x in q for y in q}==set(q)
    return q

def q_class(q):
    if q[0][0]:return 0 if q[0][0]==4 else 1
    return 2+next(i for i in range(3) if q[1+i][0]!=0)

def orbits(action, size=64):
    allidx=set(range(size));out=[]
    while allidx:
        i=min(allidx)
        block=sorted({v[i] for v in action.values()})
        assert len(block)==8 and set(block)<=allidx
        allidx-=set(block);out.append(block)
    assert len(out)==8
    index={x:k for k,block in enumerate(out) for x in block}
    return out,index

def factor_projector(B):
    B=sp.Matrix(B);assert B.shape==(8,8)
    G=B*B.T
    assert G*G*G-20*G*G+64*G==sp.zeros(8)
    P=sp.eye(8)-(sp.eye(8)-G/4)*(sp.eye(8)-G/16)
    assert P==P.T and P*P==P and sp.trace(P)==5
    return P

def q8_mckay(q):
    H,_=ex.generate_vertices();H=sorted(set(H))
    assert set(q)<=set(H)
    seed=json.loads((ROOT/'data/mckay_exact_character_seed_v118.json').read_text())['2T']
    classes=mc.conjugacy(H,5)
    classidx={g:i for i,c in enumerate(classes) for g in c}
    chars=sp.Matrix([[mc.char_value(c,'2T') for c in row] for row in seed['character_coefficients_2x_a_plus_b_rad']])
    chi=sp.Matrix([[1,1,1,1,1],
                   [1,1,1,-1,-1],
                   [1,1,-1,1,-1],
                   [1,1,-1,-1,1],
                   [2,-2,0,0,0]])
    dimQ=sp.Matrix([1,1,1,1,2])
    for i in range(5):
        for j in range(5):
            assert sum(chi[i,q_class(g)]*chi[j,q_class(g)] for g in q)==8*int(i==j)
    AQ=sp.zeros(5)
    for k in range(4):AQ[k,4]=AQ[4,k]=1
    assert AQ*dimQ==2*dimQ
    B=sp.Matrix([[sp.simplify(sum(chi[i,q_class(g)]*chars[j,classidx[g]] for g in q)/8)
                  for j in range(7)] for i in range(5)])
    assert all(v.is_Integer and v>=0 for v in B)
    AT=sp.zeros(7)
    for i,j in seed['mcKay_edges']:AT[i,j]=AT[j,i]=1
    assert AQ*B==B*AT and dimQ.T*B==sp.Matrix(seed['mcKay_dimensions']).T
    assert B.rank()==3
    previous=json.loads((ROOT/'data/mckay_clifford_v118_instance.json').read_text())
    BO=sp.Matrix(previous['restriction_from_2O_to_2T']);BI=sp.Matrix(previous['restriction_from_2I_to_2T'])
    BQO=B*BO;BQI=B*BI
    X=BO.T*BI
    Y=BQO.T*BQI
    AO=sp.Matrix(previous['mcKay']['2O']['A']);AI=sp.Matrix(previous['mcKay']['2I']['A'])
    assert X.rank()==5 and Y.rank()==3 and AO*Y==Y*AI
    assert sp.factor((Y.T*Y).charpoly().as_expr())==sp.Symbol('lambda')**6*(sp.Symbol('lambda')-90)**2*(sp.Symbol('lambda')-18)
    assert sp.factor((X.T*X).charpoly().as_expr())==sp.Symbol('lambda')**4*(sp.Symbol('lambda')-10)**2*(sp.Symbol('lambda')-4)**2*(sp.Symbol('lambda')-2)
    assert sp.Matrix.hstack(X,Y).rank()==5
    eigen_ranks={}
    for lam in (-2,0,2):
        # Integer polynomial spectral projectors for a simple-eigenspace
        # symmetric integer matrix A_O; all eigenvalues algebraic real.
        v=(AO-lam*sp.eye(8)).nullspace()
        assert len(v)>=1
        basis=sp.Matrix.hstack(*v)
        projector=basis*(basis.T*basis).inv()*basis.T
        assert projector*Y!=sp.zeros(8,9)
        eigen_ranks[str(lam)]=int((projector*Y).rank())
    assert eigen_ranks=={'-2':1,'0':1,'2':1}
    # Orthogonal spectral test: image Y has no ±1 components.
    assert (AO*AO*(AO*AO-4*sp.eye(8))*Y)==sp.zeros(8,9)
    return {'order':8,'irreducible_dimensions':[1,1,1,1,2],
            'conjugacy_class_order':['1','-1','±i','±j','±k'],
            'characters':chi.tolist(),'A_affine_D4':AQ.tolist(),
            'characteristic_polynomial':'lambda^3(lambda^2-4)',
            'B_2T_to_Q8':B.tolist(),'B_Q8_from_2O':BQO.tolist(),
            'B_Q8_from_2I':BQI.tolist(),'rank_B_Q8_T':int(B.rank()),
            'Y_cross_via_Q8':Y.tolist(),'rank_Y':int(Y.rank()),
            'Y_squared_singular_spectrum':{'90':2,'18':1,'0':6},
            'Y_common_ADE_eigenmodes':eigen_ranks,
            'X_via_2T_rank':int(X.rank()),
            'X_squared_singular_spectrum':{'10':2,'4':2,'2':1,'0':4},
            'image_Y_subset_image_X':sp.Matrix.hstack(X,Y).rank()==X.rank()}

def build():
    z=json.loads((ROOT/'data/golden_e8_v117_instance.json').read_text())
    rt=[tuple(x['coordinates_doubled']) for x in z['roots_240']]
    roots=[[rt[i] for i in inds] for inds in z['three_X64']]
    inds=[{r:i for i,r in enumerate(s)} for s in roots]
    assert all(len(s)==64 and len(inds[k])==64 for k,s in enumerate(roots))
    q=q8_elements()
    actions=[];orb=[];oid=[]
    for sector,rows in enumerate(roots):
        perms={h:tuple(inds[sector][mc.mul_twice(mc.twice_matrix(h,'left'),r)] for r in rows) for h in q}
        assert all(sorted(p)==list(range(64)) for p in perms.values())
        # Faithful permutation action with free Q8 orbits.
        assert all(all(p[i]!=i for i in range(64)) for h,p in perms.items() if q_class(h)!=0)
        for h in q:
            for k in q:
                hk=mc.qmul(h,k,5)
                assert tuple(perms[h][perms[k][j]] for j in range(64))==perms[hk]
        O,idx=orbits(perms)
        actions.append(perms);orb.append(O);oid.append(idx)
    pairs=[];cross_matrices={}
    for entry in z['triality_cross_sector_pairs']:
        a,b=entry['pair']; c=entry['third_sector']
        M=sp.Matrix(64,64,lambda i,j:int(gold.vecneg(gold.vecplus(roots[a][i],roots[b][j])) in inds[c]))
        assert {(i,j) for i in range(64) for j in range(64) if M[i,j]}=={tuple(x) for x in entry['bipartite_edges_local_indices']}
        assert sum(M)==1024 and all(sum(M[i,j] for j in range(64))==16 for i in range(64))
        for h in q:
            pa=actions[a][h];pb=actions[b][h]
            assert all(M[i,j]==M[pa[i],pb[j]] for i in range(64) for j in range(64))
        N=sp.Matrix(8,8,lambda i,j:sum(M[orb[a][i][0],u] for u in orb[b][j]))
        assert all(sum(M[u,v] for v in orb[b][j])==N[i,j]
                   for i in range(8) for u in orb[a][i] for j in range(8))
        assert dict(C(N))=={2:48,4:8,0:8}
        assert all(sum(N[i,j] for j in range(8))==16 for i in range(8))
        assert all(sum(N[i,j] for i in range(8))==16 for j in range(8))
        plus=[next(j for j in range(8) if N[i,j]==4) for i in range(8)]
        minus=[next(j for j in range(8) if N[i,j]==0) for i in range(8)]
        assert sorted(plus)==sorted(minus)==list(range(8))
        sigma=[None]*8
        for i in range(8):sigma[plus[i]]=minus[i]
        assert all(sigma[j]!=j and sigma[sigma[j]]==j for j in range(8))
        assert N==sp.Matrix(8,8,lambda i,j:2*(1+int(j==plus[i])-int(j==minus[i])))
        assert N*N.T==32*sp.ones(8,8)+8*(sp.eye(8)-sp.Matrix(8,8,lambda i,j:int(sigma[i]==j)))
        assert N.rank()==5 and (N*N.T).eigenvals()=={sp.Integer(256):1,sp.Integer(16):4,sp.Integer(0):3}
        # Full 64D image projector, using factorized 8+8 weight compatibility.
        P=sp.kronecker_product(factor_projector(entry['left_8x8_weight_compatibility']),
                               factor_projector(entry['right_8x8_weight_compatibility']))
        assert sp.trace(P)==25 and P*P==P
        # Certify that the factorized projector is onto the ACTUAL M image,
        # rather than merely a coincidental rank-25 projector.
        assert P*M==M
        assert M.rank()==25
        for h in q:
            pa=actions[a][h]
            assert all(P[pa[i],pa[j]]==P[i,j] for i in range(64) for j in range(64))
        characters={}
        for h in q:
            perm=actions[a][h]
            # Character of left Q8 on the rank-25 image, via the orthogonal projector.
            val=sp.simplify(sum(P[i,perm[i]] for i in range(64)))
            assert val.is_Integer
            characters[str(q_class(h))]=int(val)
        assert C(int(sp.simplify(sum(P[i,actions[a][h][i]] for i in range(64)))) for h in q)=={1:6,9:1,25:1}
        assert sum(int(sp.simplify(sum(P[i,actions[a][h][i]] for i in range(64)))) for h in q)//8==5
        qchar=[25,9,1,1,1]; sizes=[1,1,2,2,2]
        chiQ=sp.Matrix([[1,1,1,1,1],[1,1,1,-1,-1],[1,1,-1,1,-1],
                        [1,1,-1,-1,1],[2,-2,0,0,0]])
        complex_multiplicities=[sum(sizes[c]*qchar[c]*chiQ[i,c] for c in range(5))//8 for i in range(5)]
        assert complex_multiplicities==[5,4,4,4,4]
        # Q8 spinor is quaternionic: its complex multiplicity four is two
        # copies of the four-dimensional real quaternionic irreducible.
        assert sum(complex_multiplicities[i] for i in range(4))+4*(complex_multiplicities[4]//2)==25
        cross_matrices[f'{a}{b}']=M
        pairs.append({'sectors':[a,b],'third_sector':c,
                      'orbit_incidence_8x8':N.tolist(),
                      'nonzero_orbit_edge_count':sum(x!=0 for x in N),
                      'orbit_edge_multiplicity_histogram':{str(t):int(v) for t,v in sorted(C(N).items())},
                      'four_match_perm_row_to_col':plus,'zero_match_perm_row_to_col':minus,
                      'match_involution_column_map':sigma,
                      'match_involution_transpositions':[[i,sigma[i]] for i in range(8) if i<sigma[i]],
                      'rank':int(N.rank()),'gram_eigenvalues':{'256':1,'16':4,'0':3},
                      'rank25_Q8_character_per_class':{'1':25,'-1':9,'order4':1},
                      'rank25_Q8_real_irrep_multiplicities':{'trivial_1':5,'nontrivial_1_x':4,'nontrivial_1_y':4,'nontrivial_1_z':4,'quaternionic_4':2},
                      'rank25_Q8_fixed_subspace_dimension':5})
    # Root-sum triples X0×X1×X2 quotient by Q8.
    triples=C()
    M01=cross_matrices['01']
    for i in range(64):
        for j in range(64):
            if not M01[i,j]:continue
            r,s=roots[0][i],roots[1][j]
            k=inds[2][gold.vecneg(gold.vecplus(r,s))]
            triples[(oid[0][i],oid[1][j],oid[2][k])]+=1
    assert sum(triples.values())==1024
    assert all(v%8==0 for v in triples.values())
    torb={k:v//8 for k,v in triples.items()}
    assert len(torb)==104 and C(torb.values())=={1:96,4:8} and sum(torb.values())==128
    for key in ('01','02','12'):
        a,b=map(int,key)
        N=sp.Matrix(next(p['orbit_incidence_8x8'] for p in pairs if p['sectors']==[a,b]))
        assert all(sum(v for ids,v in torb.items() if ids[a]==i and ids[b]==j)==N[i,j]
                   for i in range(8) for j in range(8))
    mckay=q8_mckay(q)
    return {'schema':'s3_Q8_triality_McKay_exact_v119',
            'coordinate_scope':'single marked 2I over fixed 2T; coefficient golden E8 construction from v117, fixed X0/X1/X2 coordinate ordering',
            'Q8_elements_quaternion_numerator_over4':[[list(ab) for ab in h] for h in q],
            'Q8_root_orbit_partitions':orb,
            'Q8_permutation_sector':[{str(k):list(v) for k,v in ((q.index(h),p) for h,p in perm.items())} for perm in actions],
            'Q8_orbit_cross_sector_pairs':pairs,
            'Q8_tripartite_hyperedges': [{'orbit_triple':list(k),'Q8_orbit_multiplicity':v} for k,v in sorted(torb.items())],
            'hypergraph_invariants':{'original_root_zero_sum_triples':1024,'Q8_orbit_size':8,'total_Q8_triple_orbits_with_multiplicities':128,'distinct_orbit_triples':104,'single_triple_orbits':96,'fourfold_triple_orbit_patterns':8},
            'Q8_McKay_affineD4':mckay,
            'comparison_constraints':[
              'Q8-fixed triality incidence image dimension 5 is an exact quotient invariant; equality with im(B_O^T B_I) is NOT established.',
              'The 5D McKay X^T X positive eigenvalues 10,10,4,4,2 differ from Q8 triality N N^T positive values 256,16,16,16,16; no nonzero scalar similarity of their natural Gram operators.',
              'The 5D R(Q8) module and 5D Q8-fixed triality image are not identified merely because of dimension 5.',
              'Q8 McKay restriction through 2T yields an independent rank-3 bridge preserving only shared ADE adjacency eigenmodes -2,0,2.',
              'Graph orbit adjacency is weighted, not a simple graph; weights 0,2,4 retain all original root-sum incidence.',
              'No physical transition, Lie-bracket signs, mass or decay map is implied.'
            ]}

if __name__=='__main__':
    out=build()
    print(json.dumps({'sector_orbits':[len(s) for s in out['Q8_root_orbit_partitions']],
                      'quotient_ranks':[p['rank'] for p in out['Q8_orbit_cross_sector_pairs']],
                      'triple_orbit_ledger':out['hypergraph_invariants'],
                      'mckay_rank':out['Q8_McKay_affineD4']['rank_Y']},indent=2))
