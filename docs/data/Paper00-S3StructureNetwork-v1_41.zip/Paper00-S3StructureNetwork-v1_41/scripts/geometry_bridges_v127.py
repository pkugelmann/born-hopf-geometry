#!/usr/bin/env python3
"""Regenerate only mathematical morphisms for v1_27.

Every equality below is exact SymPy arithmetic or a finite combinatorial
identity.  Hypotheses from the sources are retained by the installer; the
certificate is NOT a proof of their physical-realization premises.
"""
from __future__ import annotations
import json,pathlib
from itertools import product
import sympy as S
ROOT=pathlib.Path(__file__).resolve().parents[1]

def data(f):return json.loads((ROOT/'data'/f).read_text())
def mat_json(m):return [[str(S.simplify(v)) for v in m.row(i)] for i in range(m.rows)]
def simp(m):return m.applyfunc(S.simplify)

def clifford():
    # Quaternion basis (1,i,j,k), uv right-handed, even part of Cl(0,3).
    bas=list(S.eye(4).columnspace())
    def mult(a,b):
        A,B,C,D=a;E,F,G,H=b
        return S.Matrix([A*E-B*F-C*G-D*H,A*F+B*E+C*H-D*G,
                         A*G-B*H+C*E+D*F,A*H+B*G-C*F+D*E])
    def L(a):return S.Matrix.hstack(*(mult(a,b) for b in bas))
    def R(a):return S.Matrix.hstack(*(mult(b,a) for b in bas))
    e0,ei,ej,ek=bas
    Q4=ei*ei.T;Q5=ej*ej.T+ek*ek.T;Q7=e0*e0.T
    assert Q4+Q5+Q7==S.eye(4)
    tangents={}
    for name,v in [('j',ej),('k',ek)]:
        T=Q5*L(v)*Q4; J=(L(v)-R(v))/2;O=T+T.T
        assert O==J*Q4-Q4*J
        assert T==mult(v,ei)*ei.T
        assert S.trace(O.T*O)==2
        tangents[name]={'T':T,'S':O,'J':J}
    for a,v in [('j',ej),('k',ek)]:
        for b,w in [('j',ej),('k',ek)]:
            t=tangents[a]['T'];u=tangents[b]['T']
            assert simp(t.T*u-(v.T*w)[0]*Q4)==S.zeros(4)
            assert S.trace(tangents[a]['S'].T*tangents[b]['S'])/8==(v.T*w)[0]/4
    E0,E32,E40,E56=S.symbols('E0 E32 E40 E56',positive=True)
    H=E32*Q4+E40*Q5+E56*Q7
    Hh=S.sqrt(E32)*Q4+S.sqrt(E40)*Q5+S.sqrt(E56)*Q7
    for t in tangents.values():
        O,J=t['S'],t['J']
        assert simp(Hh*O*Hh-S.sqrt(E32*E40)*O)==S.zeros(4)
        assert simp(J*H-H*J-(E32-E40)*O)==S.zeros(4)
    alpha=S.symbols('alpha',positive=True)
    assert S.simplify((alpha**S.Rational(1,8)-alpha**(-S.Rational(1,8)))*alpha**(-S.Rational(9,8))-(alpha**(-1)-alpha**(-S.Rational(5,4))))==0
    # Extension to eight-dimensional Cl(0,3) regular carrier.
    Q={'Q0':S.diag(S.zeros(4),S.eye(4)),
       'Q4':S.diag(Q4,S.zeros(4)),
       'Q5':S.diag(Q5,S.zeros(4)),
       'Q7':S.diag(Q7,S.zeros(4))}
    assert sum(Q.values(),S.zeros(8))==S.eye(8)
    assert [int(S.trace(Q[x])) for x in ['Q0','Q4','Q5','Q7']]==[4,1,2,1]
    return {'structure':'Even Cl(0,3)=H; regular Cl(0,3)=H⊕H with ND_sp and active-support hypotheses',
        'marked_hopf_axis':'u=i; tangent plane span{j,k}; real trace Tr8/8',
        'eight_dimensional_projector_ranks':{'Q0':4,'Q4':1,'Q5':2,'Q7':1},
        'Q4':mat_json(Q4),'Q5':mat_json(Q5),'Q7':mat_json(Q7),
        'source_Tj':mat_json(tangents['j']['T']),'source_Tk':mat_json(tangents['k']['T']),
        'selfadjoint_Sj':mat_json(tangents['j']['S']),'selfadjoint_Sk':mat_json(tangents['k']['S']),
        'graded_E_values':{'E32':'E0*alpha^-1','E40':'E0*alpha^(-5/4)','E56':'E0*alpha^(-7/4)',
                           'E36':'E0*alpha^(-9/8)=sqrt(E32*E40)'},
        'exact_identities':['T(v)^T T(w)=<v,w>Q4','S(v)=[(L_v-R_v)/2,Q4]',
                            'Tr8(S(v)^T S(w))/8=<v,w>/4',
                            'H^(1/2)S(v)H^(1/2)=sqrt(E32 E40) S(v)',
                            '[J_v,H]=(E32-E40)S(v)'],
        'not_identified':['carrier grading with physical spectrum','source tangent with physical decay vertex']}

def petersen():
    # Source-independent reconstruction from earlier exact quaternion projectors,
    # preserving the v1_24 Petersen orientation convention.
    a=data('ten_axis_projectors_v126_instance.json');b=data('petersen_a5_bridge_v124_instance.json')
    U=[]
    for pair in b['petersen_vertices_10_core_pairs']:
        q=next(x['chosen_quaternion_re_half'] for x in a['projectors'] if x['core_pair']==pair)
        uv=S.Matrix([(S.Integer(aa)+S.Integer(bb)*S.sqrt(5))/(2*S.sqrt(3)) for aa,bb in q[1:]])
        assert S.simplify((uv.T*uv)[0])==1
        U.append(uv)
    K=S.zeros(3,15)
    for e,(v,w) in enumerate(b['petersen_oriented_edges_15']):
        dot=S.simplify((U[v].T*U[w])[0]);assert S.simplify(dot**2-S.Rational(5,9))==0
        K[:,e]=S.Rational(3,2)*S.sign(dot)*U[v].cross(U[w])
    assert simp(K*K.T-5*S.eye(3))==S.zeros(3)
    # A_u = K^T P_u K; from KK^T=5I and P_u²=P_u, rank P_u=2:
    # A_u²=5A_u, tr A_u=tr(P_u KK^T)=10 for every unit u.
    u=U[0];P=S.eye(3)-u*u.T
    assert S.simplify((u.T*u)[0]-1)==0
    assert simp(P*P-P)==S.zeros(3)
    assert S.simplify(S.trace(P* (K*K.T))-10)==0
    return {'witnessed_geometric_flux':'k_e=(3/2)sgn(u_v.u_w)(u_v cross u_w)',
        'quaternion_axis_coordinate_basis':'five ordered 2T core labels; ten projective C6 axes; v1_24 Petersen edges',
        'K_3x15':mat_json(K),'K_Ktranspose':'5I3',
        'example_Pu_3x3':mat_json(P),
        'example_Petersen_Gram_recipe':'K^T P_u K; explicit K and P_u supplied',
        'rank':2,'nonzero_Gram_eigenvalue':5,'zero_multiplicity':13,
        'protected_response_Gram':'J_u^*J_u=(E36^2/9) K^T P_u K',
        'physical_scope':'comparison-only: no scattering vertex, pole or decay width'}

def product_heat():
    z=S.symbols('z'); B=S.expand((1+z)**2*(1+z**3)**2)
    XB=S.expand((1-z**2)*(1-z**6))
    bp=S.expand((B+XB)/2); bm=S.expand((B-XB)/2)
    assert all(int(p)>=0 for p in S.Poly(bp,z).all_coeffs()+S.Poly(bm,z).all_coeffs())
    assert bp.subs(z,1)==8 and bm.subs(z,1)==8
    # Grade-exchange trace: odd 3-forms anticommute; torus 1-forms swap.
    assert XB==1-z**2-z**6+z**8
    X,Y,u,v=S.symbols('X Y u v')
    ts={(0,0):1,(0,1):u,(1,0):u,(1,1):v}
    basic={0:X,1:Y}
    ordinary=S.expand(sum(basic[a]*basic[b]*wt for a,b in product(range(2),repeat=2) for (nx,np),wt in ts.items()))
    exch=S.expand(sum(basic[a]*basic[b]*wt for a,b in product(range(2),repeat=2) for (nx,np),wt in ts.items() if a==b and nx==np))
    assert S.expand(ordinary-(X+Y)**2*(1+2*u+v))==0
    assert S.expand(exch-(X**2+Y**2)*(1+v))==0
    # Finite representation-Casimir sum: dimension test for coupled SU2 modules.
    f=S.Rational(1,2)
    samples=[]
    for j in [S.Rational(0),S.Rational(1,2),S.Integer(1),S.Rational(3,2)]:
        for i in [S.Rational(1,2),S.Integer(1)]:
            ks=[abs(j-i)+n for n in range(int(2*min(j,i))+1)]
            assert sum(int(2*k+1) for k in ks)==int((2*j+1)*(2*i+1))
            modes=[]
            for k in ks:
                lam=S.simplify(4*((1-f)*j*(j+1)+f*k*(k+1)+(f*f-f)*i*(i+1)))
                modes.append({'k':str(k),'R2_lambda':str(lam),'multiplicity':int((2*j+1)*(2*k+1))})
            samples.append({'j':str(j),'iota':str(i),'f':str(f),'modes':modes})
    # Scalar product of S3×S3×T2: first gap depends on metric, not a universal constant.
    return {'M8_product_scalar_formula':'kx(kx+2)/Rx²+kp(kp+2)/Rp²+n^T G^-1 n',
      'Hodge_heat_generating_function':'[A_Rx(1+z³)+C_Rx(z+z²)] [A_Rp(1+z³)+C_Rp(z+z²)] (1+z)² Θ_G',
      'harmonic_Betti_polynomial':str(B),'exchange_Lefschetz_polynomial':str(XB),
      'exchange_even_Betti_polynomial':str(bp),'exchange_odd_Betti_polynomial':str(bm),
      'test_tensor_heat':'(X+Y)^2*(1+2u+v)', 'test_tensor_exchange_heat':'(X^2+Y^2)*(1+v)',
      'covariant_s3_connection':'Δ_f,iota=4/R²*(J+fI)^2; supplied A_f=f Θ',
      'covariant_spectrum_samples':samples,
      'conditions':['product bi-invariant metric','exchange traces require Rx=Rp, exchange-invariant torus metric and compatible factor actions',
      'connection-covariant spectrum requires explicitly supplied f and spin iota',
      'finite joint spectrum uses independently chosen representation truncation and torus weights']}

def quantum():
    assert sum(x*x for x in [1,2,2,4,3,3])==43
    assert sum([1,2,2,4,3,3])==15
    oscillator={}
    x=S.symbols('x')
    for N in range(1,6):
        a=S.zeros(N+1)
        for n in range(1,N+1):a[n-1,n]=S.sqrt(n)
        at=a.T
        assert a*at-at*a==S.eye(N+1)-(N+1)*S.diag(*([0]*N+[1]))
        char=(a+at).charpoly(x).as_expr().expand()
        assert S.simplify(char-S.hermite_prob(N+1,x))==0
        # vacuum Gaussian moments through order 2N+1, with sigma=1.
        Q=a+at
        for k in range(2*N+2):
            expect=(Q**k)[0,0]
            gaussian=0 if k%2 else S.factorial2(k-1) if k>0 else 1
            assert expect==gaussian,(N,k,expect,gaussian)
        oscillator[str(N)]={'dimension':N+1,'truncation_defect_top':N+1,
            'quadrature_characteristic_polynomial_He':str(char),
            'gaussian_moment_exact_through_degree':2*N+1,
            'first_nonmatching_moment_degree':2*N+2}
    # Two fermionic modes with exterior-algebra signs.
    states=list(product([0,1],repeat=2)); c=[]
    for f in [0,1]:
        M=S.zeros(4)
        for col,bits in enumerate(states):
            if bits[f]==1:
                target=list(bits);target[f]=0
                M[states.index(tuple(target)),col]=(-1)**sum(bits[:f])
        c.append(M)
    for i in range(2):
        for j in range(2):
            assert c[i]*c[j]+c[j]*c[i]==S.zeros(4)
            assert c[i]*c[j].T+c[j].T*c[i]==(S.eye(4) if i==j else S.zeros(4))
    # Born scalar eigenphase lattice, Smith index two.
    A=S.Matrix([[1,1],[1,-1]])
    assert abs(A.det())==2
    for n,w in product(range(-3,4),repeat=2):
        p,q=A*S.Matrix([n,w]); assert (p-q)%2==0
        assert S.Matrix([[(p+q)/2],[(p-q)/2]])==S.Matrix([[n],[w]])
    # Degree-one U(1) projective Hopf comparison in C² only.
    ax,by,cz,dt=S.symbols('a b c d',real=True)
    xx=2*(ax*cz+by*dt); yy=2*(ax*dt-by*cz); zz=ax*ax+by*by-cz*cz-dt*dt
    assert S.expand(xx*xx+yy*yy+zz*zz-(ax*ax+by*by+cz*cz+dt*dt)**2)==0
    # Signed Petersen auxiliary 10x10 self-adjoint Hodge spectral projections.
    signed=data('petersen_a5_bridge_v124_instance.json')['matrices']['signed_exterior_hodge_S_10x10']
    S10=S.Matrix([[S.sympify(v) for v in row] for row in signed]);assert S10**3==5*S10
    Pp=S.simplify((S10*S10/5+S10/S.sqrt(5))/2)
    Pm=S.simplify((S10*S10/5-S10/S.sqrt(5))/2)
    Pz=S.eye(10)-S10*S10/5
    for P,rank in [(Pp,3),(Pm,3),(Pz,4)]:
        assert simp(P*P-P)==S.zeros(10);assert S.simplify(S.trace(P))==rank
    assert simp(Pp*Pm)==S.zeros(10)
    return {'finite_43_algebra_block_sizes':[1,2,2,4,3,3],
        'finite_43_algebra_dimension':43,'carrier_direct_sum_dimension':15,
        'fermionic_exterior_Fock_2mode_dimension':4,
        'fermionic_annihilators_two_mode':[mat_json(M) for M in c],
        'bosonic_truncated_oscillators_sigma1':oscillator,
        'scalar_eigenphase_A':[[1,1],[1,-1]],'scalar_eigenphase_index':2,
        'scalar_eigencharge_image':'(p+,p-) integers of equal parity',
        'ray_Hopf_S3_to_S2_formula':['2 Re(bar(z0)z1)','2 Im(bar(z0)z1)','abs(z0)^2-abs(z1)^2'],
        'ray_Hopf_scope':'C^2 unit sphere S^3, primitive identity U(1)_Hopf to central ray phase; not equality of arbitrary Hopf action on modes',
        'signed_Petersen_auxiliary_spectrum':{'eigenvalues':{'sqrt5':3,'0':4,'-sqrt5':3},'spectral_projections':'P±=(S²/5 ± S/√5)/2; P0=I-S²/5'},
        'nonidentification':'10x10 Petersen auxiliary group algebra dimension 34 is not canonically a sub-block of the 43D kinematic test algebra'}

def build():
    import sys,time
    print('calculating Clifford',file=sys.stderr,flush=True); C=clifford()
    print('calculating Petersen',file=sys.stderr,flush=True); P=petersen()
    print('calculating M8',file=sys.stderr,flush=True); M=product_heat()
    print('calculating finite algebra',file=sys.stderr,flush=True); Q=quantum()
    return {'scope':'source-anchored, mathematical constructions only; parent geometry v1_26',
        'clifford':C,'petersen':P,'reciprocal_heat':M,'finite_geometric_operator_models':Q}
if __name__=='__main__':
    print(json.dumps(build(),indent=2,ensure_ascii=False))
