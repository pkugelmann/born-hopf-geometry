#!/usr/bin/env python3
"""Write self-contained SHA-256 file manifest for geometry-only v1_29."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[1]
counts=json.loads((R/'data/v129_release_counts.json').read_text())
cover=json.loads((R/'reports/geometry_completeness_v129.json').read_text())['counts']
parent=Path('/mnt/data/Paper00-S3StructureNetwork-v1_28.zip')
files=[]
for path in sorted(R.rglob('*')):
 if not path.is_file() or path.name=='MANIFEST.json' or '__pycache__' in path.parts or path.suffix in ('.pyc','.zip'):continue
 data=path.read_bytes()
 files.append({'path':str(path.relative_to(R)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
m={
 'version':'v1_29','parent':'v1_28','theme':'S3StructureNetwork',
 'archive_root':'Paper00-S3StructureNetwork-v1_29',
 'release_type':'standalone_cumulative_pure_mathematical_geometry_network',
 'parent_archive_sha256':hashlib.sha256(parent.read_bytes()).hexdigest() if parent.exists() else 'unavailable',
 'proof_dag_copied':False,'statement_locator_nodes':0,'physical_transition_edges':0,
 'batch_scope':'strict geometry-only Hurwitz 24cell Cayley and Q8 quotient, full oriented finite cellular Hodge and dual incidence, relative 2T support quotients, source-scoped mathematical bridges',
 'new_objects':counts['new_objects'], 'new_typed_relations':counts['new_typed_relations'],
 'new_joint_inputs':counts['new_joint_inputs'],'new_derived_compositions':counts['new_compositions'],
 'cumulative_objects':counts['cumulative_objects'],'cumulative_edges':counts['cumulative_edges'],
 'cumulative_joint_inputs':counts['cumulative_joint_inputs'],'cumulative_compositions':counts['cumulative_compositions'],
 'isolated_object_records':cover['isolated_objects'],
 'largest_connected_component':cover['largest_weak_component'],
 'nontrivial_disconnected_components_outside_core':cover['nontrivial_disconnected_components'],
 'verification_summary':{
   'new_exact_v129':'PASS: group Cayley and Q8 quotient, exact 24cell adjacency and rank2 projector, integer boundary matrices and 96x96 unit-weight Hodge characteristic polynomial, dual-facet graph',
   'graph_exports':'PASS: full GraphML JSON parity, focused batch 18 graph, and 3-vertex weighted quotient',
   'source_witnesses':'PASS: 14 current TeX labels and file hashes; does not certify all source proofs, and the Hodge polynomial is already in Paper VII-A',
   'cumulative_fast_validation':'PASS: inherited mathematical regression checks plus new batch verifier; repeat after clean extraction',
   'historical_full_regeneration':'NOT_RUN_IN_THIS_BATCH; full historical suite provided separately'},
 'current_papers_source_archive':'Paper00-PapersMinimal-v3_028(1).zip (read-only source label/hash verification; not copied)',
 'files':files}
(R/'MANIFEST.json').write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n')
print('wrote manifest of',len(files),'files')
