#!/usr/bin/env python3
"""Rebuild native finite object-incidence GraphML files from exact instance JSON."""
import json,pathlib,networkx as nx
ROOT=pathlib.Path(__file__).resolve().parents[1]
inst=json.loads((ROOT/'data/exceptional_600cell_instance.json').read_text())
base=ROOT/'graph'/'c6_axis_covers';base.mkdir(parents=True,exist_ok=True)
P=nx.Graph()
for i,a in enumerate(inst['axes']):
 p=a['pair'];P.add_node(i,coset_pair='-'.join(map(str,p)),c6_subgroup=','.join(map(str,a['subgroup_vertices'])),edge_fiber_size=72)
for i,j in inst['petersen_pair_graph']['edges']:P.add_edge(i,j,relation='PAIR_DISJOINTNESS')
nx.write_graphml(P,ROOT/'graph'/'petersen_c6_axis_index.graphml')
for a in inst['axes']:
 i,j=a['pair'];stem=f'axis_{i}_{j}';included=set(inst['coset_blocks'][i])|set(inst['coset_blocks'][j]);G=nx.Graph()
 for v in included:G.add_node(str(v),class_color=i if v in inst['coset_blocks'][i] else j)
 for e in inst['nearest_edges']:
  if e['u'] in included and e['v'] in included:G.add_edge(str(e['u']),str(e['v']))
 assert G.number_of_nodes()==48 and G.number_of_edges()==72 and nx.is_connected(G)
 nx.write_graphml(G,base/(stem+'_48vertex.graphml'))
 Q=nx.Graph()
 for v in range(8):Q.add_node(str(v),side='i' if v<4 else 'j')
 for u,row in enumerate(a['quotient_biadjacency']):
  for v,n in enumerate(row):
   if n:Q.add_edge(str(u),str(v+4))
 assert Q.number_of_nodes()==8 and Q.number_of_edges()==12 and nx.is_isomorphic(Q,nx.hypercube_graph(3))
 nx.write_graphml(Q,base/(stem+'_cube8.graphml'))
print('EXPORTED: Petersen axis graph + ten 48-vertex covers + ten 8-vertex quotient cubes')
