#!/usr/bin/env python3
"""Exact pure-geometric 2T / 24-cell cellular, quotient and Hodge construction.

No physical action or source realization is assumed. The face Hodge Laplacian
uses unit weights and the standard oriented cellular chain inner products.
The source papers also state its spectrum; this is an independent regeneration.
"""
from __future__ import annotations
import collections
import itertools
import json
from pathlib import Path
import numpy as np
import sympy as sp
import networkx as nx

ROOT=Path(__file__).resolve().parents[1]

def rank_mod(A, p=1000003):
    a=np.array(A,dtype=np.int64).copy()%p
    m,n=a.shape
    rank=0
    for col in range(n):
        rr=np.flatnonzero(a[rank:,col])
        if not len(rr): continue
        row=rank+int(rr[0]); a[[rank,row],:]=a[[row,rank],:]
        a[rank,:]=a[rank,:]*pow(int(a[rank,col]),-1,p)%p
        ix=np.flatnonzero(a[rank+1:,col])
        if len(ix):
            rows=rank+1+ix
            a[rows,:]=(a[rows,:]-a[rows,col,None]*a[rank,:])%p
        rank+=1
        if rank==m: break
    return rank

def quaternion_product(a,b):
    w,x,y,z=a; W,X,Y,Z=b
    raw=(w*W-x*X-y*Y-z*Z, w*X+x*W+y*Z-z*Y,
         w*Y-x*Z+y*W+z*X, w*Z+x*Y-y*X+z*W)
    assert all(v%2==0 for v in raw)
    return tuple(v//2 for v in raw)

def conjugate(a):
    return (a[0],-a[1],-a[2],-a[3])

def make_chains():
    finite=json.loads((ROOT/'data/finite_geometry_v116_instance.json').read_text())
    shell=finite['hurwitz_F4']
    Ed=[tuple(e) for e in shell['24cell_edges']]
    Fa=[tuple(t) for t in shell['24cell_triangles']]
    Ce=[tuple(c) for c in shell['24cell_octahedral_facets']]
    assert len(Ed)==len(Fa)==96 and len(Ce)==24
    edgeidx={e:i for i,e in enumerate(Ed)}
    B1=np.zeros((24,96),dtype=np.int64)
    B2=np.zeros((96,96),dtype=np.int64)
    for i,(a,b) in enumerate(Ed):
        assert a<b
        B1[a,i]=-1; B1[b,i]=1
    for i,(a,b,c) in enumerate(Fa):
        for edge,sgn in [((b,c),1),((a,c),-1),((a,b),1)]:
            B2[edgeidx[edge],i]=sgn
    assert not (B1@B2).any()
    B3=np.zeros((96,24),dtype=np.int64)
    for k,cell in enumerate(Ce):
        fids=[i for i,t in enumerate(Fa) if set(t).issubset(cell)]
        assert len(fids)==8
        nbr=collections.defaultdict(list)
        for i in fids:
            for en in np.flatnonzero(B2[:,i]):nbr[int(en)].append(i)
        assert len(nbr)==12 and all(len(v)==2 for v in nbr.values())
        signs={fids[0]:1};stack=[fids[0]]
        while stack:
            u=stack.pop()
            for en in np.flatnonzero(B2[:,u]):
                en=int(en)
                a,b=nbr[en]
                v=b if a==u else a
                s=-signs[u]*int(B2[en,u])*int(B2[en,v])
                if v in signs: assert signs[v]==s
                else: signs[v]=s;stack.append(v)
        assert len(signs)==8
        for i,sgn in signs.items():B3[i,k]=sgn
    assert not (B2@B3).any()
    # Globally consistent orientation of the top-dimensional octahedral cells.
    adjacent=collections.defaultdict(list)
    for i in range(96):
        a,b=map(int,np.flatnonzero(B3[i,:]))
        adjacent[a].append((b,i));adjacent[b].append((a,i))
    signs={0:1};stack=[0]
    while stack:
        u=stack.pop()
        for v,i in adjacent[u]:
            sign=-signs[u]*int(B3[i,u])*int(B3[i,v])
            if v in signs: assert signs[v]==sign
            else:signs[v]=sign;stack.append(v)
    assert len(signs)==24
    for k,sgn in signs.items():B3[:,k]*=sgn
    assert not B3.sum(axis=1).any() and not (B2@B3).any()
    assert [rank_mod(x) for x in (B1,B2,B3)]==[23,73,23]
    A=np.zeros((24,24),dtype=np.int64)
    for a,b in Ed:A[a,b]=A[b,a]=1
    assert np.all(A.sum(axis=1)==8)
    D2=B2.T@B2+B3@B3.T
    assert not (B2@B3).any()
    poly=sp.factor(sp.Matrix(D2.tolist()).charpoly().as_expr())
    X=sp.symbols('lambda')
    expected=((X-12)**2*(X-10)**8*(X-9)*(X-8)**13*(X-5)**16*
              (X-4)**16*(X-2)**16*(X-1)**6*(X*X-9*X+16)**9)
    assert sp.Poly(poly,X)==sp.Poly(expected,X)
    # Exact multiplicities for the rank-73 coexact and rank-23 exact bands.
    exfac=sp.factor(sp.Matrix((B3.T@B3).tolist()).charpoly().as_expr())
    cofac=sp.factor(sp.Matrix((B2@B2.T).tolist()).charpoly().as_expr())
    expected_exfac=X*(X-12)**2*(X-10)**8*(X-8)**9*(X-4)**4
    expected_cofac=X**23*(X-9)*(X-8)**4*(X-5)**16*(X-4)**12*(X-2)**16*(X-1)**6*(X*X-9*X+16)**9
    assert sp.Poly(exfac,X)==sp.Poly(expected_exfac,X)
    assert sp.Poly(cofac,X)==sp.Poly(expected_cofac,X)
    # Dual 24-cell's edge adjacency from facet-sharing; exact graph isomorphism.
    dual=8*np.eye(24,dtype=np.int64)-(B3.T@B3)
    assert set(dual.ravel())=={0,1} and np.all(dual.sum(axis=1)==8)
    matcher=nx.algorithms.isomorphism.GraphMatcher(nx.from_numpy_array(A),nx.from_numpy_array(dual))
    assert matcher.is_isomorphic()
    perm=[int(matcher.mapping[i]) for i in range(24)]
    assert np.array_equal(A,dual[np.ix_(perm,perm)])
    # Cochains: 0-th, 1st, 2nd reduced homology = (0,0) in degrees 1,2.
    assert 96-73-23==0 and 96-23-73==0
    return A,B1,B2,B3,D2,dual,perm,Ed,Fa,Ce

def make_group(A,Ed):
    ex=json.loads((ROOT/'data/exceptional_600cell_instance.json').read_text())
    ids=ex['tetrahedral_core_vertex_ids']
    units=[tuple(int(x[0]//2) for x in ex['vertices'][i]['qcoords']) for i in ids]
    # Source's qcoords are 4*q, so their integer-half coordinates are 2*q.
    assert len(units)==24 and len(set(units))==24
    idx={q:i for i,q in enumerate(units)}
    mult=np.empty((24,24),dtype=np.int64)
    for i,q in enumerate(units):
        for j,r in enumerate(units):
            mult[i,j]=idx[quaternion_product(q,r)]
    identity=idx[(2,0,0,0)]
    inv=[idx[conjugate(q)] for q in units]
    assert np.array_equal(mult[identity,:],np.arange(24)) and np.array_equal(mult[:,identity],np.arange(24))
    assert all(mult[i,inv[i]]==identity for i in range(24))
    source={i for i,q in enumerate(units) if q[0]==1} # real part +1/2
    assert len(source)==8
    for i in range(24):
        for j in range(24):
            assert int(A[i,j])==(int(mult[inv[i],j]) in source)
    # The graph is a central Cayley graph, hence both left/right multipliers commute.
    for g in range(24):
        assert np.array_equal(A, A[np.ix_(mult[g,:],mult[g,:])])
        assert np.array_equal(A, A[np.ix_(mult[:,g],mult[:,g])])
    charpoly=sp.factor(sp.Matrix(A.tolist()).charpoly().as_expr())
    X=sp.symbols('lambda')
    expected=X**9*(X-8)*(X-4)**4*(X+2)**8*(X+4)**2
    assert sp.Poly(charpoly,X)==sp.Poly(expected,X)
    Q8={i for i,q in enumerate(units) if sum(1 for x in q if x!=0)==1 and max(abs(x) for x in q)==2}
    assert len(Q8)==8
    cosets=[]
    for i in range(24):
        orb={int(mult[i,h]) for h in Q8}
        if not any(orb==cc for cc in cosets):cosets.append(orb)
    assert len(cosets)==3 and all(len(cc)==8 for cc in cosets)
    labels=[next(j for j,cc in enumerate(cosets) if i in cc) for i in range(24)]
    quotient=np.zeros((3,3),dtype=np.int64)
    for i in range(24):
        projected=np.bincount([labels[j] for j in np.flatnonzero(A[i,:])],minlength=3)
        if quotient[labels[i]].any():assert np.array_equal(quotient[labels[i]],projected)
        quotient[labels[i]]=projected
    assert np.array_equal(quotient,4*(np.ones((3,3),dtype=np.int64)-np.eye(3,dtype=np.int64)))
    # projector onto the -4 eigenvalue of the 24-vertex adjacency.
    P24num=np.array([[3*(labels[i]==labels[j])-1 for j in range(24)] for i in range(24)],dtype=np.int64)
    assert np.array_equal(P24num@P24num,24*P24num)
    assert np.array_equal(A@P24num,-4*P24num)
    assert int(np.trace(P24num))==48  # projective trace 2
    assert len({(i,j) for i in range(24) for j in range(24) if mult[inv[i],j] in source})==192
    # The tangent cube-link directions are the imaginary coords of q^{-1}q' times 2.
    moments=[]
    for i in range(24):
        directions=[]
        for j in np.flatnonzero(A[i,:]):
            z=units[int(mult[inv[i],int(j)])]
            assert z[0]==1 and all(abs(s)==1 for s in z[1:])
            directions.append(z[1:])
        dirs=np.array(directions,dtype=np.int64)
        assert not dirs.sum(axis=0).any() and np.array_equal(dirs.T@dirs,8*np.eye(3,dtype=np.int64))
        moments.append(dirs.tolist())
    # Group quotient: G^2/Gdiag and G^3/Gdiag, coordinates x^{-1}y.
    for i in range(24):
        for j in range(24):
            relative=int(mult[inv[i],j])
            for g in range(24):
                assert int(mult[inv[int(mult[g,i])],int(mult[g,j])])==relative
    return {'units_2q': [list(q) for q in units], 'identity_index':identity,'inverse':inv,
       'multiplication_table':mult.tolist(),'nearest_neighbor_generators':sorted(source),
       'q8_group_indices':sorted(Q8),'q8_cosets':list(map(lambda cc:sorted(cc),cosets)),
       'q8_coset_vertex_index':labels,'q8_quotient_adjacency':quotient.tolist(),
       'minus_four_projector_numerator_24x24':P24num.tolist(),
       'local_tangent_cube_directions_sqrt3_scaled':moments,
       'adjacency_characteristic_polynomial':str(charpoly),
       'adjacency_spectrum':{'8':1,'4':4,'0':9,'-2':8,'-4':2}}

def sparse_entries(B):
    i,j=np.nonzero(B)
    return [[int(a),int(b),int(B[a,b])] for a,b in zip(i,j)]

def build():
    A,B1,B2,B3,D2,dual,perm,Ed,Fa,Ce=make_chains()
    group=make_group(A,Ed)
    return {'version':'v1_29','source_geometry':'fixed marked 2T subgroup of marked 2I 600cell; unit weights for Hodge',
     'disclaimer':'24-cell geometry only: excludes any action, interactions, physical source, measured scale, and weighted Hodge identification',
     'counts':{'vertices':24,'edges':96,'oriented_triangles':96,'oriented_octahedral_cells':24,'incidence_ranks':[23,73,23],
               'H_1':0,'H_2':0,'coexact_face_rank':73,'exact_face_rank':23,
               'adjacency_degree':8,'q8_cosets':3},
     'cells':{'edges':list(map(list,Ed)),'oriented_triangles':list(map(list,Fa)),'octahedral_facets':list(map(list,Ce))},
     'boundary_matrices':{'B1_24x96':sparse_entries(B1),'B2_96x96':sparse_entries(B2),'B3_96x24':sparse_entries(B3)},
     'dual_24cell':{'adjacency_24x24':dual.tolist(),'vertex_to_dual_facet_isomorphism':perm,'description':'B3.T B3 = 8I-A_dual, and A_dual is permutation-isomorphic to primal A'},
     'unit_weight_2_hodge':{
       'D2_96x96':D2.tolist(),
       'characteristic_polynomial':'(x-1)^6*(x-2)^16*(x-4)^16*(x-5)^16*(x-8)^13*(x-9)*(x-10)^8*(x-12)^2*(x^2-9*x+16)^9',
       'coexact_B2TB2_nonzero_characteristic_polynomial':'(x-9)*(x-8)^4*(x-5)^16*(x-4)^12*(x-2)^16*(x-1)^6*(x^2-9*x+16)^9',
       'exact_B3B3T_nonzero_characteristic_polynomial':'(x-12)^2*(x-10)^8*(x-8)^9*(x-4)^4',
       'exact_trace_moments_k1to4':[int(np.trace(np.linalg.matrix_power(D2,k))) for k in range(1,5)],
       'kernel_dim':0,'min_eigenvalue':1,'unit_cellular_weights_only':True},
     'hurwitz_group':group}
if __name__=='__main__':
    out=build()
    path=ROOT/'data/hurwitz_cellular_v129_instance.json';path.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print('PASS: exact 24-cell cellular boundary ranks; 96-dim Hodge polynomial; self-dual 24cell; 2T Cayley/Q8 quotient; local cube second moments')
    print('wrote',path, 'bytes',path.stat().st_size)
