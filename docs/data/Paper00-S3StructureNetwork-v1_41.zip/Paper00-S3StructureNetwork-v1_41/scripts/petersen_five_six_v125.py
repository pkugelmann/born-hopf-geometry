#!/usr/bin/env python3
"""Exact marked Petersen 5+6 source geometry: exploratory development module."""
from __future__ import annotations
import itertools, json, pathlib
import numpy as np
from sympy import Matrix, Rational, eye, zeros, LeviCivita
from . import exceptional_model as ex
ROOT=pathlib.Path(__file__).resolve().parents[1]
def jd(n):return json.loads((ROOT/'data'/n).read_text())


def build():
    old=jd('petersen_a5_bridge_v124_instance.json')
    prev=jd('exceptional_600cell_instance.json')
    axes=jd('q8_hopf_e8_bridge_v120_instance.json')['axis15']
    c3=jd('axis15_holonomy_v122_instance.json')['axis_C3_deck_generator_right_2T']
    old_m=old['matrices']
    D=np.asarray(old_m['petersen_oriented_incidence_D_10x15'],dtype='int64')
    C5=np.asarray(old_m['pair_to_core_centered_numerator_C5_10x5'],dtype='int64')
    S=np.asarray(old_m['signed_exterior_hodge_S_10x10'],dtype='int64')
    B=np.asarray(old_m['exterior_contraction_B_5x10'],dtype='int64')
    R=np.asarray(old_m['actual_axis_block_core_R_15x5'],dtype='int64')
    pairs=[tuple(x) for x in old['petersen_vertices_10_core_pairs']]
    pedges=[tuple(x) for x in old['petersen_oriented_edges_15']]
    edgelook={e:i for i,e in enumerate(pedges)}
    pairlook={e:i for i,e in enumerate(pairs)}
    P4=Matrix(old_m['petersen15_rank4_projector_numerator_Pe375_15x15'])/375
    P5=Matrix(old_m['petersen15_rank5_projector_Pe5_15x15'])
    P6=Matrix(old_m['petersen15_rank6_projector_Pe6_15x15'])
    M5=Matrix.eye(10)-Matrix.ones(10,10)/10-Matrix(C5)*Matrix(C5.T)/75
    assert P5==Matrix(D.T)*M5*Matrix(D)/2
    assert P6==eye(15)-P4-P5
    # Six sector from pairwise exterior products of centered core-pair vectors
    W6=np.zeros((10,15),dtype=np.int64)
    for e,(a,b) in enumerate(pedges):
        u,v=C5[a],C5[b]
        for i,(r,s) in enumerate(pairs): W6[i,e]=int(u[r]*v[s]-u[s]*v[r])
    assert Matrix(W6.T@W6)==1250*P6
    assert Matrix(W6@W6.T)==250*Matrix(S@S)   # since P_H6=S^2/5
    assert Matrix(W6)*P4==zeros(10,15) and Matrix(W6)*P5==zeros(10,15)
    assert Matrix(W6).rank()==6
    assert Matrix(S@S@W6)==5*Matrix(W6)
    H6=Matrix(W6.T@S@W6)/1250
    assert H6*H6==5*P6 and H6**3==5*H6
    assert set(H6)=={Rational(-1,2), Rational(0), Rational(1,2)}
    # Group representations and equivariant map from axis fibres to unoriented Petersen edges
    H,I=ex.generate_vertices();V=sorted(I);ix={q:i for i,q in enumerate(V)}
    cores=[frozenset(V[i] for i in ids) for ids in prev['conjugate_core_groups']]
    clook={c:i for i,c in enumerate(cores)}
    fiber=[frozenset(a['right_vertex_fibre']) for a in axes]
    flock={f:i for i,f in enumerate(fiber)}
    assert len(flock)==15 and len({i for f in fiber for i in f})==120
    groups={}
    for q in V:
        p=tuple(clook[frozenset(ex.qmul(ex.qmul(q,h),ex.conj(q)) for h in c)] for c in cores)
        ap=tuple(flock[frozenset(ix[ex.qmul(q,V[i])] for i in f)] for f in fiber)
        ep=[];epsign=[]
        for a,b in pedges:
            a2=pairlook[tuple(sorted((p[pairs[a][0]],p[pairs[a][1]])))]
            b2=pairlook[tuple(sorted((p[pairs[b][0]],p[pairs[b][1]])))]
            ep.append(edgelook[tuple(sorted((a2,b2)))])
            epsign.append(1 if a2<b2 else -1)
        if p in groups:
            assert (ap,tuple(ep),tuple(epsign))==groups[p]
        else:groups[p]=(ap,tuple(ep),tuple(epsign))
    assert len(groups)==60
    # Equivariant bijections from the 15 unoriented Petersen edges to 15 actual Hopf axes
    pi_candidates=[]
    for axis0 in range(15):
        for edge0 in range(15):
            perm={};ok=True
            for ap,ep,_ in groups.values():
                a,e=ap[axis0],ep[edge0]
                if a in perm and perm[a]!=e:ok=False;break
                perm[a]=e
            if ok and len(perm)==15 and len(set(perm.values()))==15:
                pi_candidates.append(tuple(perm[a] for a in range(15)))
    pi_candidates=list(dict.fromkeys(pi_candidates))
    assert len(pi_candidates)==3, ('equivariant maps',len(pi_candidates))
    chosen=min(pi_candidates)
    U=np.zeros((15,15),dtype=np.int64) # axis <-- unoriented edges
    for a,e in enumerate(chosen): U[a,e]=1
    assert np.array_equal(U@U.T,np.eye(15,dtype=np.int64))
    Ec=np.abs(D.T) # 15 unsigned edge x 10 vertex
    Jc=np.zeros((15,15),dtype=np.int64)
    for i,j in enumerate(c3):Jc[j,i]=1
    assert np.array_equal(Jc@Jc@Jc,np.eye(15,dtype=np.int64))
    # Canonical five-dimensional maps, numerator N5=U|D|^t P_vertex5
    A=Matrix(U@Ec)*M5 # 15x10
    # A/sqrt4 is a partial isometry vertex 5 -> axis 10
    assert A.T*A==4*M5
    P_ax5=A*A.T/4
    assert int(P_ax5.trace())==5 and P_ax5**2==P_ax5
    assert Matrix(R.T)*A==zeros(5,10)
    assert A.T*Matrix(Jc)*A==-2*M5 # rotation cos(120)=-1/2 * 4
    assert A.T*Matrix(Jc.T)*A==-2*M5
    A_ortho=(2*Matrix(Jc)+eye(15))*A # normalized A_ortho/(2*sqrt(3))? inspect
    assert A.T*A_ortho==zeros(10)
    assert A_ortho.T*A_ortho==12*M5
    P_ax5b=A_ortho*A_ortho.T/12
    Q_ax10=eye(15)-Matrix(R)*Matrix(R.T)/3
    assert P_ax5+P_ax5b==Q_ax10
    assert (Matrix(Jc)*P_ax5*Matrix(Jc.T)) != P_ax5
    # Maps from signed Petersen edge 5 to each axis 5, normalized:
    # P_vertex5 D/sqrt2 : edge -> vertex 5 ; A/2 : vertex -> axis 5
    X0=A*Matrix(D)  # vertex projector included
    X1=A_ortho*Matrix(D)
    assert X0.T*X0==8*P5 and X0*X0.T==8*P_ax5
    assert X1.T*X1==24*P5 and X1*X1.T==24*P_ax5b
    assert X0.T*X1==zeros(15)
    Q=Matrix(jd('q8_hopf_e8_bridge_v120_instance.json')['quotient_600_15x15'])
    G=Matrix(jd('axis15_cubic_v121_instance.json')['gram_matrix_15x15'])
    assert Q*X0==zeros(15) and Q*X1==zeros(15)
    assert G*X0==164*X0 and G*X1==164*X1
    Z=Matrix(old_m['petersen15_to_axis15_integer_Z_15x15'])
    assert Z.T*X0==zeros(15) and Z.T*X1==zeros(15)
    assert Z*P6==zeros(15) and X0*P6==zeros(15)
    # The T4 and X0 maps have disjoint ranges, so their normalized sum is rank 9.
    assert (Z/Matrix([1])[0] if False else Z).rank()==4 and X0.rank()==5
    # Verify group actions for signed edge, vertex and axis, and exterior wedge
    reps=[]
    for p,(ap,ep,epsign) in sorted(groups.items()):
        PV=np.zeros((10,10),dtype=np.int64)
        PW=np.zeros((10,10),dtype=np.int64)
        PE=np.zeros((15,15),dtype=np.int64)
        PA=np.zeros((15,15),dtype=np.int64)
        for k,(i,j) in enumerate(pairs):
            z1,z2=p[i],p[j];index=pairlook[tuple(sorted((z1,z2)))]
            PV[index,k]=1;PW[index,k]= 1 if z1<z2 else -1
        for i,(j,sgn) in enumerate(zip(ep,epsign)):PE[j,i]=sgn
        for i,j in enumerate(ap):PA[j,i]=1
        assert np.array_equal(PA@U@Ec,U@Ec@PV)
        assert np.array_equal(PA@U,U@np.abs(PE))
        assert np.array_equal(PA@Jc,Jc@PA)
        assert Matrix(PA)*A==A*Matrix(PV)
        assert Matrix(PA)*X0==X0*Matrix(PE)
        assert Matrix(PA)*X1==X1*Matrix(PE)
        assert np.array_equal(PW@W6,W6@PE)
        assert np.array_equal(PW@S,S@PW)
        reps.append((p,ap,ep,epsign))
    # check A5 irreps using nontrivial 2,3,5 classes; S5 odd excluded
    order=lambda p: next(i for i in range(1,7) if tuple((lambda x:x)(p)[j] for j in range(5))==tuple(range(5))) if False else None
    # all char traces grouped by A5 order
    def permorder(p):
        q=tuple(range(5))
        for i in range(1,7):
            q=tuple(p[q[k]] for k in range(5))
            if q==tuple(range(5)): return i
        raise ValueError
    char={}
    for p,ap,ep,epsign in reps:
        PP=np.zeros((15,15),dtype=np.int64)
        for i,j in enumerate(ep): PP[j,i]=epsign[i]
        o=permorder(p)
        t=tuple(int(s.trace()) for s in [Matrix(PP)*P4, Matrix(PP)*P5, Matrix(PP)*P6])
        char.setdefault(o,set()).add(t)
    print('Petersen characters by element order',char)
    assert char=={1:{(4,5,6)},2:{(0,1,-2)},3:{(1,-1,0)},5:{(-1,0,1)}}
    # axis characters: 1+4+5+5; forbidden 6 -> axis by character orthogonality
    charax={}
    for p,ap,ep,sgn in reps:
        o=permorder(p)
        charax.setdefault(o,set()).add(sum(i==j for i,j in enumerate(ap)))
    print('axis total characters',charax)
    assert charax=={1:{15},2:{3},3:{0},5:{0}}
    # Orthogonal character pairing Hom_A5(E,Axis)=3 and Hom_A5(E6,Axis)=0.
    group_by_order={j:sum(permorder(p)==j for p in groups) for j in (1,2,3,5)}
    assert group_by_order=={1:1,2:15,3:20,5:24}
    hom=(1*15*15+15*(-1)*3+20*0*0+24*0*0)//60
    six_hom=(1*6*15+15*(-2)*3)//60
    assert hom==3 and six_hom==0
    assert (P4+P5).rank()==9
    return {'input_v124_sha':None,
            'schema':'S3_exact_Petersen_A5_rank5_rank6_sector_morphisms_v125',
            'matrices':{
                'signed_edge_to_exterior_wedge_W6_10x15':W6.tolist(),
                'equivariant_axis_to_unsigned_edge_permutation_U_15x15':U.tolist(),
                'unsigned_edge_endpoint_incidence_E_15x10':Ec.tolist(),
                'vertex_5projector_Pv5_10x10':[[str(x) for x in row] for row in M5.tolist()],
                'axis5_embed_A_15x10':[[str(x) for x in row] for row in A.tolist()],
                'axis5_rotated_Aprime_15x10':[[str(x) for x in row] for row in A_ortho.tolist()],
                'axis5_projector_first_15x15':[[str(x) for x in row] for row in P_ax5.tolist()],
                'axis5_projector_second_15x15':[[str(x) for x in row] for row in P_ax5b.tolist()],
                'signed_petersen5_to_axis5_X0_15x15':[[str(x) for x in row] for row in X0.tolist()],
                'signed_petersen5_to_axis5_X1_15x15':[[str(x) for x in row] for row in X1.tolist()],
                'axis_C3_deck_15x15':Jc.tolist(),
                'pulled_back_Petersen_edge_Hodge6_15x15':[[str(x) for x in row] for row in H6.tolist()],
            },
            'equivariant_unsigned_axis_maps': [list(v) for v in pi_candidates],
            'canonical_choice_axis_to_edge':list(chosen),
            'A5_character_classes_by_element_order':{str(k):list(v)[0] for k,v in char.items()},
            'A5_axis_characters_by_element_order':{str(k):list(v)[0] for k,v in charax.items()},
            'A5_Hom_dimensions':{'signed_edge15_to_axis15':3,'signed_edge6_to_axis15':0,'max_equivariant_rank':9},
            'spectral_eigenvalues_axis_images':{'rank4':{'Q600':-3,'E8_Gram':296},'rank5_x2':{'Q600':0,'E8_Gram':164}},
            'group_elements_60':[{'p5':list(p),'axis15':list(ap),'petersen_edge15':list(ep),'signed_edge':list(epsign)} for p,ap,ep,epsign in reps],
            'scope':['Actual one-marked 2I/2T/Q8 axis data and left-A5 actions, three possible equivariant unsigned-edge-to-axis matchings; lexicographic choice fixed for the two rank5 maps.',
                     'Rank6 oriented Petersen cochain equivalent to nonzero signed exterior Hodge as A5 modules; no equivariant map from rank6 to axis permutation 15 carrier.','No claim of canonical choice of one of the two rank5 axis copies or a physical coupling.']}

if __name__=='__main__':
    d=build();(ROOT/'data/petersen_five_six_v125_instance.json').write_text(json.dumps(d,indent=2)+'\n')
    print('PASS new Petersen 5+6 morphology; three choices of matching, exact A5 equivariance')
