#!/usr/bin/env python3
"""Create v1_24 release SHA256 manifest from the current standalone geometry-only directory."""
from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parents[1]
load=lambda f:json.loads((R/'data'/f).read_text())
c=load('v124_release_counts.json')
records=[]
for p in sorted(R.rglob('*')):
 if not p.is_file() or p.name=='MANIFEST.json' or '__pycache__' in p.parts or p.suffix in ('.pyc','.zip'):
  continue
 b=p.read_bytes();records.append({'path':str(p.relative_to(R)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
manifest={
 'version':'v1_24','theme':'S3StructureNetwork',
 'release_type':'standalone_cumulative_pure_mathematical_geometry_network',
 'archive_root':'Paper00-S3StructureNetwork-v1_24','parent_geometry_release':'v1_23',
 'proof_dag_copied':False,'statement_locator_nodes':0,'physical_transition_edges':0,
 'batch_scope':'marked A5-equivariant partial isometries between signed 15-edge Petersen Hodge 4D, signed 10-pair Hodge 4D, five-core Hopf 15-axis 4D, and Q8-fixed 600/-3 E8 Gram-296 sector; exact core ordering, signed orientations and 60 group actions',
 'new_mathematical_objects':c['new_objects'],'new_typed_relations':c['new_typed_relations'],
 'new_joint_inputs':c['new_joint_inputs'],'new_derived_compositions':c['new_derived_compositions'],
 'cumulative_mathematical_objects':c['cumulative_objects'],'cumulative_typed_relations':c['cumulative_edges'],
 'cumulative_joint_inputs':c['cumulative_joint_inputs'],'cumulative_derived_compositions':c['cumulative_compositions'],
 'independent_batch_verification':'PASS: exact integer matrices and all 60 marked A5 signed actions regenerated',
 'cumulative_structure_integrity':'PASS: 740 object IDs, 1001 typed morphisms, 123 joint conditions, 109 derivations; graphml verified',
 'inherited_source_validation':'PASS: sha256 of 21 unmodified inherited v1_23 mathematical data files',
 'complete_old_suite_replay':'NOT_COMPLETED_IN_RELEASE_BUILD; older regenerators and default validate_geometry.py retained for independent replay',
 'primary_source':[{'file':'Paper1B-ExceptionalGeometry-v1_15.tex','sha256':'b38803550ab964421312daa97a0b93c08c25d53fb49c22a6b813d381a69651d4','source_location':'PapersMinimal-v3_026','copied_into_archive':False},
                   {'archive':'Paper00-S3StructureNetwork-v1_23.zip','sha256':load('../reports/INHERITED_V123_INSTANCE_HASHES.json') if False else json.loads((R/'reports/INHERITED_V123_INSTANCE_HASHES.json').read_text())['parent_archive_sha256']}],
 'files':records
}
(R/'MANIFEST.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
print('WROTE MANIFEST',len(records),'files')
