#!/usr/bin/env python3
"""Geometry-only Batch 20: marked S3->SU3, exact finite Haar/Casimir algebra and path maps."""
from __future__ import annotations
import pathlib, json, zipfile, hashlib, xml.etree.ElementTree as ET
from .hopf_su3_geometry_v131 import build
ROOT=pathlib.Path(__file__).resolve().parents[1];D=ROOT/'data';G=ROOT/'graph'
SRC=pathlib.Path('/mnt/data/Paper00-PapersMinimal-v3_029(1).zip')
def ld(n):return json.loads((D/n).read_text())
def wr(n,x):(D/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
labels=[
'p8:thm:final-octet-canonical-hopf-descent',
'p8:thm:final-octet-flrw-hodge-dilution',
'p10:def:admissible-color-connection',
'p10:thm:canonical-haar-heat-representative',
'p10:thm:v350-local-gauss-projector',
'p10:def:finite-strong-generated-algebra',
'p10:thm:finite-strong-algebra-centralizer',
'p12:thm:finite-gauge-projection',
'p12:thm:v251-inherited-path-coarse-map',
'p12:def:admissible-refinement-set',
'p11:thm:baryon-flux-junction-contraction',
]
assert SRC.exists(), 'Current TeX source unavailable: cannot certify current source labels/hashes'
W={}
with zipfile.ZipFile(SRC) as z:
 for f in sorted(z.namelist()):
  if not f.endswith('.tex'):continue
  raw=z.read(f);s=raw.decode(errors='replace');digest=hashlib.sha256(raw).hexdigest()
  for label in labels:
   if label in W:continue
   pos=s.find('\\label{'+label+'}')
   if pos>=0:
    W[label]={'claim_id':label,'file':f,'line':s.count('\n',0,pos)+1,'tex_sha256':digest,
     'located_in_current_tex':True,'source_scope':'Paper00-PapersMinimal-v3_029 original TeX'}
assert set(W)==set(labels),set(labels)-set(W)
wr('batch20_current_tex_witnesses.json',{'source_archive':SRC.name,'source_witnesses':W,'provenance_only_not_graph_vertices':True})
inst=build()
assert inst['SU3_tensor']['centralizer_dimension']==2
# Carry forward the previous exact SU3 singlet projector *without a change of basis*.
assert inst['SU3_tensor']['identity_singlet_projector_9x9']==ld('finite_invariant_geometry_v130_instance.json')['su3']['matrix_meson_singlet_projector_9x9']
wr('hopf_su3_v131_instance.json',inst)
O=ld('objects.json');R=ld('mathematical_relations.json');H=ld('joint_input_relations.json');C=ld('derived_compositions.json')
ids={o['id'] for o in O};usededge={e['id'] for e in R}
new='EXACT_MARKED_GROUP_AND_RATIONAL_LINEAR_ALGEBRA_V131'
guard='SCOPED_MATHEMATICAL_SUBOPERATOR_ONLY_NOT_FULL_SOURCE_OPERATOR_V131'
# Each new node is a mathematical object/operator, never a theorem node or a source locator.
def addo(key,name,typ,claim,ver=new):
 id='geo:g31:'+key
 if id not in ids:
  O.append({'id':id,'name':name,'object_type':typ,'scope':'mathematical_structure_or_morphism',
    'source_kind':'marked_s3_su3_group_hopf_invariants_and_finite_path_geometry',
    'conditional':ver==guard,'batch':'v1_31','verification':ver,
    'source_role':'SOURCE_CONTEXT_FOR_EXPLICIT_INSTANCE_NOT_FULL_SOURCE_CLAIM',
    'witness':W[claim]});ids.add(id)
 return id
x={}
x['iota']=addo('su2_to_su3','Marked block-group embedding SU2=S3 -> SU3, diag(q,1)', 'compact_lie_group_inclusion','p10:def:admissible-color-connection')
x['branch']=addo('fundamental_su2_2plus1','Restricted SU3 fundamental representation: 3|SU2 = 2 plus 1','representation_branching','p10:def:admissible-color-connection')
x['MC']=addo('flat_MC_s3','Pulled-back flat su3 Maurer-Cartan one-form along SU2 inclusion','lie_algebra_valued_connection_form','p10:def:admissible-color-connection')
x['CS']=addo('normalized_cartan3_to_hopf','Oriented normalized SU3 Cartan 3-form pullback equals normalized S3 Hopf volume','closed_invariant_differential_three_form','p8:thm:final-octet-canonical-hopf-descent')
x['hodge']=addo('threeform_hodge_scaling','Pure 3-form Hodge scaling vol_{a2g}=a3 vol_g and dual charge a^-3','hodge_metric_scaling','p8:thm:final-octet-flrw-hodge-dilution')
x['V9']=addo('conjugation_V9','SU3 conjugation carrier End(C3) = complex scalar plus traceless adjoint','finite_group_representation','p10:thm:finite-strong-algebra-centralizer')
x['P18']=addo('singlet_adjoint_P1_P8','Orthogonal 9x9 singlet and octet projectors in 3 tensor 3-dual','exact_projector_pair','p10:thm:v350-local-gauss-projector')
x['Cas']=addo('adjoint_casimir3','Exact quadratic Casimir C=3(I-P1) on the SU3 conjugation carrier','finite_lie_casimir_operator','p10:thm:canonical-haar-heat-representative')
x['cent']=addo('finite_commutant2','Two-dimensional exact commutant of SU3 conjugation generators in End(C9)','finite_commutant_and_matrix_algebra','p10:thm:finite-strong-algebra-centralizer')
x['Wed']=addo('wedderburn_C_plus_M8','Selected associative star algebra C plus M8 and centralizers C plus C','finite_wedderburn_example','p10:thm:finite-strong-algebra-centralizer')
x['heat']=addo('adjoint_Casimir_heat','Finite central heat semigroup P1 + exp(-3t) P8','finite_Casimir_heat_semigroup','p10:thm:canonical-haar-heat-representative')
x['V81']=addo('independent_two_vertex_V81','Two independently transformed 1 plus 8 site modules (SU3 x SU3 on C81)','finite_vertexwise_product_representation','p10:thm:v350-local-gauss-projector')
x['Gauss']=addo('exact_two_vertex_GaussP','Exact rank-one vertexwise Haar projector P1 tensor P1 in C81','finite_Haar_invariant_projector','p10:thm:v350-local-gauss-projector')
x['evolution']=addo('invariant_two_vertex_generator','Finite commuting Hamiltonian H=alpha I+beta(C1+C2), purely operator-geometric','finite_commuting_operator','p12:thm:finite-gauge-projection')
x['path']=addo('sample_tree_path_restriction','Oriented 3-edge path-groupoid subdivision functor and SU3 ordered-holonomy restriction','finite_path_groupoid_functor','p12:thm:v251-inherited-path-coarse-map')
x['natural']=addo('path_gauge_naturality','Endpoint gauge-conjugation naturality and loop-trace invariant for SU3 path restriction','equivariant_finite_path_map','p12:thm:v251-inherited-path-coarse-map')
x['cas3']=addo('determinant_casimir_minus2','Three-fundamental determinant singlet total pairwise Casimir equals -2','finite_tensor_Casimir_identity','p11:thm:baryon-flux-junction-contraction')
links=[
('geo:s3',x['iota'],'MARKED_LIE_GROUP_BLOCK_EMBEDDING',new),
('geo:spin4_chiral_factors',x['iota'],'CHOSEN_CHIRAL_SU2_FACTOR_INTO_SU3',guard),
(x['iota'],x['branch'],'SU3_FUNDAMENTAL_RESTRICTION_2_PLUS_1',new),
('geo:g30:A2_su3_fundamental',x['branch'],'MARKED_TRIMER_BASIS_BRANCH_RESTRICTION',guard),
(x['iota'],x['MC'],'PULLBACK_MAURER_CARTAN_FORM',new),
(x['MC'],x['CS'],'NORMALIZED_CARTAN_THREE_FORM_EXTERIOR_CUBE',new),
('geo:hopf_c1',x['CS'],'PRIMITIVE_HOPF_THREE_FORM_NORMALIZATION_ORIENTED',new),
('geo:g28:primary_hopf_hbar_i_h',x['CS'],'MARKED_HOPF_VOLUME_MATCH',guard),
(x['CS'],'geo:b7:final_octet_hopf_form','NORMALIZED_INVARIANT_TOP_FORM_COMPONENT_ONLY',guard),
('geo:s3',x['hodge'],'ROUND_THREE_SPHERE_SCALE_a2',new),
(x['CS'],x['hodge'],'NORMALIZED_THREE_FORM_METRIC_SCALE',new),
(x['hodge'],'geo:b7:final_octet_hodge','EXACT_THREE_FORM_DENSITY_SHAPE_ONLY_NOT_OCCURRENCE',guard),
(x['iota'],x['V9'],'FUNDAMENTAL_END_REPRESENTATION_AFTER_CHOSEN_SU3',new),
('geo:g30:su3_3_3bar',x['V9'],'SAME_MARKED_NINE_DIMENSIONAL_TENSOR_REPRESENTATION',new),
(x['V9'],x['P18'],'ORTHOGONAL_SCALAR_AND_ADJOINT_SPLITTING',new),
('geo:g30:su3_identity_singlet_P1',x['P18'],'ENTRYWISE_EXACT_SAME_NINE_BY_NINE_P1',new),
(x['P18'],x['Cas'],'ADJOINT_CASIMIR_EQUALS_3_TIMES_P8',new),
(x['V9'],x['Cas'],'LIE_GENERATOR_CONJUGATION_CASIMIR',new),
(x['V9'],x['cent'],'EXACT_EIGHT_GENERATOR_CENTRALIZER_LINEAR_KERNEL',new),
(x['cent'],x['Wed'],'BURNSIDE_SIMPLE_ADJOINT_AND_DOUBLE_CENTRALIZER',new),
(x['P18'],x['Wed'],'MINIMAL_CENTRAL_PROJECTIONS_1_AND_8',new),
(x['Wed'],'geo:b8:strong_generated_algebra','SPECIFIC_GROUP_ACTION_GENERATED_STAR_ALGEBRA_ONLY',guard),
(x['cent'],'geo:b8:strong_centralizer','SELECTED_REPRESENTATION_WEDDERBURN_EXAMPLE_ONLY',guard),
(x['Cas'],x['heat'],'FINITE_CASIMIR_HEAT_FUNCTIONAL_CALCULUS',new),
(x['heat'],'geo:b8:haar_heat','NINE_DIMENSIONAL_HEAT_MATRIX_ONLY_NOT_FULL_GROUP_HEAT_KERNEL',guard),
(x['V9'],x['V81'],'TENSOR_TWO_VERTEX_INDEPENDENT_GROUP_ACTION',new),
(x['V81'],x['Gauss'],'PRODUCT_HAAR_INVARIANT_PROJECTION',new),
(x['P18'],x['Gauss'],'EXACT_TWO_VERTEX_P1_TENSOR_P1',new),
(x['Gauss'],'geo:b8:local_gauss','TWO_VERTEX_EXPLICIT_UNITARY_REPRESENTATION_ONLY',guard),
(x['Cas'],x['evolution'],'TOTAL_TWO_SITE_CASIMIR_HERMITIAN_GENERATOR',new),
(x['Gauss'],x['evolution'],'COMMUTING_GAUSS_PROJECTION_PRESERVES_INVARIANTS',new),
(x['evolution'],'geo:b8:local_gauge_proj','GAUGE_INVARIANT_TWO_VERTEX_OPERATOR_EXAMPLE_ONLY',guard),
('geo:pair_groupoid',x['path'],'FINITE_TREE_PATH_GROUP_AS_PAIR_GROUPOID_INSTANCE',guard),
('geo:m8_product_coord_graph',x['path'],'AUXILIARY_FINITE_PRESENTATION_NOT_PRIMITIVE_POSITION',guard),
(x['path'],x['natural'],'GROUP_FUNCTOR_SUBDIVISION_AND_CONJUGATION_NATURALITY',new),
(x['iota'],x['natural'],'COMPACT_TARGET_SU3_HOLONOMY_PRODUCT_RULE',new),
(x['natural'],'geo:b8:path_coarse','EXACT_FINITE_THREE_EDGE_EXAMPLE_NOT_FULL_LEVEL_FAMILY',guard),
(x['MC'],'geo:b8:color_connection','FLAT_SU3_CONNECTION_RESTRICTION_ON_S3_ONLY',guard),
('geo:g30:su3_epsilon_singlet',x['cas3'],'DETERMINANT_INVARIANT_PAIRED_CASIMIR',new),
('geo:g30:su3_fierz_casimir',x['cas3'],'THREE_EQUAL_PAIRS_EACH_MINUS_2_THIRDS',new),
(x['cas3'],'geo:b8:baryon_junction_casimir','DETERMINANT_COLOR_CONTRACTION_ONLY_NO_DYNAMICAL_RESPONSE',guard),
]
assert len(links)==41,len(links)
for i,(a,b,rela,ver) in enumerate(links,1):
 assert a in ids and b in ids,(i,a,b)
 eid=f'G31-{i:03d}'
 if eid not in usededge:
  edge={'id':eid,'from':a,'to':b,'relation':rela,
        'link_type':'explicit_group_morphism_exterior_form_or_finite_tensor_map',
        'batch':'v1_31','verification':ver,'conditions_preserved':True}
  if ver==guard:
   edge['requires_joint_inputs']=[x['iota']] if 'geo:b8:' in b else [x['CS']] if b.startswith('geo:b7:') else [x['iota']]
   edge['scope_note']='Partial exact mathematical example, not an identification of the full named framework operator'
  R.append(edge);usededge.add(eid)
# Every AND-input bundle explicitly names its boundary.
hypotheses=[
 ('Marked SU2-to-SU3 embedding',["geo:s3","geo:g30:A2_su3_fundamental"],x['iota'],['selection of SU3 fundamental basis and upper-left SU2 block']),
 ('Oriented normalized Cartan/Hopf pullback',[x['iota'],'geo:hopf_c1'],x['CS'],['unit round S3 and compatible Haar/Hopf orientations','Cartan convention -Tr(theta^3)/(24*pi^2)']),
 ('Metric scaling of closed S3 form',[x['CS'],'geo:s3'],x['hodge'],['h=a(t)^2*g_round with a(t)>0','three-form identity only; no physical matter occurrence']),
 ('Single-vertex SU3 Haar invariant',[x['V9'],x['P18']],x['Cas'],['unitary conjugation 3 tensor 3-dual; generators normalized Tr(TaTb)=delta/2']),
 ('Finite Wedderburn block',[x['V9'],x['cent']],x['Wed'],['finite representation End(C3)=C plus sl3, sl3 irreducible adjoint']),
 ('Finite heat semigroup',[x['Cas'],x['P18']],x['heat'],['only the 9D representation heat function; not the continuous SU3 group heat kernel']),
 ('Two-site local Gauss',[x['V81'],x['P18']],x['Gauss'],['independent SU3 vertex actions on 2 copies of 3 tensor 3-dual']),
 ('Finite invariant evolution',[x['Gauss'],x['Cas']],x['evolution'],['H=alpha I+beta C_total finite toy operator; no actual Hamiltonian identification']),
 ('Finite path-groupoid coarse map',[x['path'],x['iota']],x['natural'],['chosen two subdivision edges and ordered SU3 matrices, gauge action at endpoints']),
 ('Three-quark determinant Casimir',[x['cas3'],'geo:g30:su3_epsilon_singlet'],x['cas3'],['color determinant tensor and Casimir normalization only; no baryon dynamics']),
]
for i,(name,inp,out,conds) in enumerate(hypotheses,1):
 H.append({'id':f'HYP-G31-{i:02d}','kind':'explicit_mathematical_joint_relation','batch':'v1_31',
          'name':name,'inputs':inp,'outputs':[out],'conditions':conds,
          'verification':new,'physical_occurrence_asserted':False})
comps=[
('Quaternion SU2 block inclusion in SU3','q↦diag(q,1) preserves unitary multiplication and det=1; 3|SU2=2⊕1.',[x['iota'],x['branch']]),
('Cartan/Hopf top-form equality','-Tr(theta³)/(24π²)|SU2=vol_round/(2π²), integral 1 in chosen orientation.',[x['iota'],x['MC'],x['CS']]),
('FLRW normalized-three-form scaling','Q Omega = Q/(2π² a³) vol_{a²g}; pure Hodge shape, no physical dust inference.',[x['CS'],x['hodge']]),
('SU3 adjoint Casimir','Σ_a(Ta⊗I−I⊗Ta^T)²=3(I−|I><I|/3) on C3⊗C3*.',[x['V9'],x['P18'],x['Cas']]),
('Exact finite commutant and Wedderburn algebra','Centralizer constraints rank 79 on 81 unknowns, commutant dimension 2 and group-generated algebra C⊕M8.',[x['V9'],x['cent'],x['Wed']]),
('Finite central Casimir heat semigroup','H(z)=P1+zP8; H(z)H(w)=H(zw), z=e^(-3t).',[x['Cas'],x['heat']]),
('Two-vertex SU3xSU3 Haar projection','P_G=P1⊗P1 rank 1; Ctot spectrum 0(1), 3(16), 6(64).',[x['V81'],x['Gauss'],x['evolution']]),
('Finite path restriction gauge naturality','Hol_{U∘j}(e)=U(e2)U(e1), inversion and endpoint transformations commute with composition.',[x['path'],x['natural']]),
('Color determinant sum of pair Casimirs','On SU3 determinant singlet, 3 pairwise channels each -2/3, hence total -2; no energy implication.',[x['cas3']]),
]
for i,(name,formula,inps) in enumerate(comps,1):
 C.append({'id':f'D31-{i:02d}','name':name,'formula':formula,'hypotheses':['chosen finite geometric representation and orientation; no physical Hilbert-space identification'],
    'source_premises':list(W),'input_ids':inps,'status':'EXACT_GEOMETRIC_GROUP_AND_FINITE_LINEAR_ALGEBRA_COMPOSITION',
    'batch':'v1_31'})
wr('objects.json',O);wr('mathematical_relations.json',R);wr('joint_input_relations.json',H);wr('derived_compositions.json',C)
# GraphML: preserve exact schema used by all earlier batches.
NS='http://graphml.graphdrawing.org/xmlns';ET.register_namespace('',NS)
def el(t):return '{'+NS+'}'+t
def export(path,nodes,edges,graphid):
 root=ET.Element(el('graphml'))
 keys=[('d0','node','label'),('d1','node','object_type'),('d2','edge','relation'),('d3','edge','verification'),('d4','edge','requires_and_inputs')]
 for key,scope,name in keys:ET.SubElement(root,el('key'),{'id':key,'for':scope,'attr.name':name,'attr.type':'string'})
 graph=ET.SubElement(root,el('graph'),{'id':graphid,'edgedefault':'directed'})
 for o in nodes:
  n=ET.SubElement(graph,el('node'),{'id':o['id']})
  for k,v in [('d0',o['name']),('d1',o['object_type'])]:ET.SubElement(n,el('data'),{'key':k}).text=str(v)
 for e in edges:
  item=ET.SubElement(graph,el('edge'),{'id':e['id'],'source':e['from'],'target':e['to']})
  for k,v in [('d2',e['relation']),('d3',e['verification']),('d4',','.join(e.get('requires_joint_inputs',[])))]:ET.SubElement(item,el('data'),{'key':k}).text=str(v)
 ET.ElementTree(root).write(path,encoding='utf-8',xml_declaration=True)
export(G/'mathematical_structure_network.graphml',O,R,'S3_mathematical_v131')
newedges=[e for e in R if e.get('batch')=='v1_31'];used={e['from'] for e in newedges}|{e['to'] for e in newedges}
export(G/'batch20_hopf_su3_group_invariants.graphml',[o for o in O if o['id'] in used],newedges,'S3_batch20_exact_group_invariants')
print('PASS v1_31 installer:',len([o for o in O if o.get('batch')=='v1_31']),'objects',len(newedges),'typed relations',len(hypotheses),'joint inputs',len(comps),'compositions')
