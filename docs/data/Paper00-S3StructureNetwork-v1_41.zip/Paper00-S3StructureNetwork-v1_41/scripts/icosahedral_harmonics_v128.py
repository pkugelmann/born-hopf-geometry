#!/usr/bin/env python3
"""Batch 17: exact 2I/C6-axis harmonics and opposite Hopf lift.

Reconstructs H6, H10, H15 in Q(sqrt5)[x,y,z] from the ten actual
C6 rank-one projectors, tests their harmonicity, the A5 Molien
identity and the degree-12 right-2I harmonic pullback. Everything is
pure mathematics and uses the marked right-Hopf convention.
"""
import sympy as s
from .ten_axis_projectors_v126 import build as ten_axes
from .exceptional_model import generate_vertices, build_instance, qmul, conj

x,y,z=s.symbols('x y z');v=s.Matrix([x,y,z]);r2=x*x+y*y+z*z
sqrt5=s.sqrt(5)

def equality_zero(expr):
    return s.Poly(s.expand(expr),x,y,z,extension=sqrt5).is_zero

def poly_data(expr,variables):
    p=s.Poly(s.expand(expr),*variables,extension=sqrt5)
    return [{'powers':list(power),'coefficient':str(s.simplify(coefficient))} for power,coefficient in p.terms()]

def build():
    axes=ten_axes()['projectors']
    P=[s.Matrix([[s.sympify(elt) for elt in row] for row in q['projector_3x3']]) for q in axes]
    quadratic=[s.expand((v.T*p*v)[0]) for p in P] # (u·v)^2, sign-free
    M=lambda j:s.Poly(s.expand(sum((q**j for q in quadratic),s.S(0))),x,y,z,extension=sqrt5).as_expr()
    M2,M4,M6,M8,M10=[M(j) for j in (1,2,3,4,5)]
    assert equality_zero(M2-s.Rational(10,3)*r2)
    assert equality_zero(M4-2*r2**2)
    H6=s.expand(M6-s.Rational(10,7)*r2**3)
    H10=s.expand(M10-s.Rational(10,11)*r2**5-s.Rational(42,17)*r2**2*H6)
    assert equality_zero(M8-s.Rational(10,9)*r2**4-s.Rational(28,15)*r2*H6)
    assert equality_zero(sum(s.diff(H6,a,2) for a in (x,y,z)))
    assert equality_zero(sum(s.diff(H10,a,2) for a in (x,y,z)))
    H15=s.expand(s.det(s.Matrix.hstack(v,s.Matrix([s.diff(H6,a) for a in (x,y,z)]),s.Matrix([s.diff(H10,a) for a in (x,y,z)]))))
    assert equality_zero(sum(s.diff(H15,a,2) for a in (x,y,z)))
    assert not equality_zero(H15)
    for poly,degree in [(H6,6),(H10,10),(H15,15)]:
        assert equality_zero(sum(a*s.diff(poly,a) for a in (x,y,z))-degree*poly)
    # The ten 3-fold projective axes are permuted by conjugation of the
    # full marked 2I (120 elements), so all symmetric even moments are A5-invariant.
    _,I=generate_vertices();V=sorted(I);inst=build_instance()
    twenty=[V[k] for axis in inst['axes'] for k in axis['subgroup_vertices'] if V[k][0]==(2,0)]
    assert len(twenty)==20 and len(set(twenty))==20
    twenty_set=set(twenty)
    for g in V:
        gbar=conj(g)
        assert all(qmul(qmul(gbar,q),g) in twenty_set for q in twenty)
    ov=[[s.simplify(s.trace(P[i]*P[j])) for j in range(10)] for i in range(10)]
    # Exact addition theorem norm and value at every axis. P6 is even.
    leg6=lambda w:(231*w**3-315*w**2+105*w-5)/16
    axis_vals=[s.simplify(sum(leg6(ov[i][j]) for j in range(10))/10) for i in range(10)]
    assert axis_vals == [s.Rational(11,81)]*10
    norm=s.simplify(sum(leg6(ov[i][j]) for i in range(10) for j in range(10))/(100*13))
    assert norm==s.Rational(11,1053)
    t=s.symbols('t');cp=(-1+sqrt5)/2;cm=(-1-sqrt5)/2
    molien=(s.S(1)/(1-t)**3+15/((1-t)*(1+t)**2)+20/((1-t)*(1+t+t*t))
           +12/((1-t)*(1-cp*t+t*t))+12/((1-t)*(1-cm*t+t*t)))/60
    hilbert=(1+t**15)/((1-t**2)*(1-t**6)*(1-t**10))
    assert s.simplify(molien-hilbert)==0
    a,b,c,d=s.symbols('a b c d')
    h=s.Matrix([a*a+b*b-c*c-d*d, 2*(b*c-a*d),2*(b*d+a*c)])
    j=h.jacobian([a,b,c,d]);normq=a*a+b*b+c*c+d*d
    assert (j*j.T-4*normq*s.eye(3)).applyfunc(s.expand)==s.zeros(3)
    assert all(s.expand(sum(s.diff(hi,w,2) for w in (a,b,c,d)))==0 for hi in h)
    terms=s.Poly(H6,x,y,z,extension=sqrt5).terms()
    phi12=s.expand(sum((coefficient*h[0]**p[0]*h[1]**p[1]*h[2]**p[2] for p,coefficient in terms),s.S(0)))
    assert phi12!=0 and s.expand(sum(s.diff(phi12,w,2) for w in (a,b,c,d)))==0
    assert s.expand(sum(w*s.diff(phi12,w) for w in (a,b,c,d))-12*phi12)==0
    # Invariant multiplicity 1 on right V6 means left dim=13.
    return {
      'marked_geometry':'2I core, ten C6 axis projectors and primary left-circle Hopf map h(q)=qbar i q',
      'source_axis_projectors':10, 'right2i_conjugation_checks':len(V)*len(twenty),
      'polynomials':{'H6':poly_data(H6,(x,y,z)),'H10':poly_data(H10,(x,y,z)),
                     'H15':poly_data(H15,(x,y,z)),'Phi12':poly_data(phi12,(a,b,c,d))},
      'harmonic_degrees':[6,10,15,12],
      'even_moment_identities':{'M2':'10/3*r²','M4':'2*r⁴','M8':'10/9*r⁸+28/15*r²*H6'},
      'icosahedral_ring_hilbert_series':'(1+t^15)/((1-t²)(1-t⁶)(1-t¹⁰))',
      'T6_definition':'T6=(231/160)*H6 on unit S²; antipodal axis measure',
      'T6_at_all_ten_axes':str(axis_vals[0]),'T6_spherical_mean_square':str(norm),
      'Hopf_components':[str(k) for k in h],
      'Hopf_differential':'Dh Dh^T=4 |q|² I3; each component harmonic',
      'Phi12_eigenvalue_round_unit_S3':168,'right_2I_fixed_dimension_on_E12':13,
      'verification_scope':'exact symbolic polynomial, finite quaternion conjugation, and character/Molien identities; no empirical map'
    }

if __name__=='__main__':
 import json
 out=build();print(json.dumps({'harmonic_degrees':out['harmonic_degrees'],'terms':{k:len(v) for k,v in out['polynomials'].items()},'T6_square':out['T6_spherical_mean_square'],'right_invariant_dim':out['right_2I_fixed_dimension_on_E12']},indent=2))
