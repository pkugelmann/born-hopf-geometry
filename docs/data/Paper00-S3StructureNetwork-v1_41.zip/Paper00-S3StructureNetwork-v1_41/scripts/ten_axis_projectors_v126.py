#!/usr/bin/env python3
"""Exact ten C6 quaternionic line projectors inside one marked 2I.

Every order-six axis is derived from the actual intersection of two
conjugate 2T subgroups and normalized sign-independently.
"""
import sympy as sp
from .exceptional_model import build_instance,generate_vertices

def build():
    _,I=generate_vertices();V=sorted(I);instance=build_instance()
    out=[];P={}
    for a in instance['axes']:
        pair=tuple(a['pair'])
        qs=[V[k] for k in a['subgroup_vertices'] if V[k][0]==(2,0)]
        assert len(qs)==2 and qs[0][1:] == tuple((-x[0],-x[1]) for x in qs[1][1:])
        q=qs[0]
        u=sp.Matrix([sp.simplify((aa+bb*sp.sqrt(5))/4) for aa,bb in q[1:]])
        assert sp.simplify((u.T*u)[0])==sp.Rational(3,4)
        proj=(sp.Rational(4,3)*u*u.T).applyfunc(sp.simplify)
        assert (proj**2-proj).applyfunc(sp.simplify)==sp.zeros(3)
        assert sp.trace(proj)==1 and proj==proj.T
        P[pair]=proj
        out.append({'core_pair':list(pair),'chosen_quaternion_re_half':[[int(a),int(b)] for a,b in q],
                    'projector_3x3':[[str(proj[i,j]) for j in range(3)] for i in range(3)]})
    assert len(out)==10
    for core in range(5):
        sm=sum((proj for pair,proj in P.items() if core in pair),sp.zeros(3))
        assert (sm-sp.Rational(4,3)*sp.eye(3)).applyfunc(sp.simplify)==sp.zeros(3)
    s=sum(P.values(),sp.zeros(3))
    assert (s-sp.Rational(10,3)*sp.eye(3)).applyfunc(sp.simplify)==sp.zeros(3)
    return {'source_geometry':'common marked 2I, five conjugate 2T groups, C6 pairwise intersections',
            'choice_of_quaternion':'two inverse elements in C6 with real part +1/2; projectors coincide under opposite imaginary orientation',
            'projectors':out,'local_tight_frame_identity':'sum_{j!=i} P_ij=4/3 I3 for each i=0..4',
            'global_tight_frame_identity':'sum_{i<j} P_ij=10/3 I3',
            'checks':'ten symmetric 3x3 rational-Qsqrt5 rank1 idempotents, all five local sums and global sum exact'}
if __name__=='__main__':
 import json
 print(json.dumps(build(),indent=2))
