#!/usr/bin/env python3
"""Write independent v1_26 archive manifest with SHA256 per file."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[1]
C=json.loads((R/'data/v126_release_counts.json').read_text())
P=Path('/mnt/data/Paper00-S3StructureNetwork-v1_25.zip')
files=[]
for f in sorted(R.rglob('*')):
 if not f.is_file() or f.name=='MANIFEST.json' or '__pycache__' in f.parts or f.suffix in ('.pyc','.zip'):
  continue
 b=f.read_bytes()
 files.append({'path':str(f.relative_to(R)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
manifest={
 'version':'v1_26','parent':'v1_25','theme':'S3StructureNetwork',
 'archive_root':'Paper00-S3StructureNetwork-v1_26',
 'release_type':'standalone_cumulative_pure_mathematical_geometry_network',
 'parent_archive_sha256':hashlib.sha256(P.read_bytes()).hexdigest() if P.exists() else 'not_available',
 'proof_dag_copied':False,'statement_locator_nodes':0,'physical_transition_edges':0,
 'batch_scope':'completeness audit and exact 600-cell Petersen total-graph covering, Milnor scalar blocks and C6 rank-one frames',
 **{k:v for k,v in C.items() if k not in ('parent','version')},
 'verification_summary':{
   'new_exact_v126':'PASS: exact quaternion/spectral/group constructions and 50-to-25 covering',
   'graph_exports':'PASS: full GraphML id+type equality and focused incidence graph counts',
   'cumulative_fast_validation':'PASS: all v1_25 and v1_26 fast and source-instance integrity checks',
   'historical_full_regeneration':'NOT_RUN_IN_THIS_BATCH; available separately'},
 'current_papers_source_archive':'Paper00-PapersMinimal-v3_027(1).zip (source-hash/label audit only; not copied)',
 'files':files}
(R/'MANIFEST.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
print('manifest',len(files),'files')
