#!/usr/bin/env python3
"""SHA256 manifest for cumulative geometry-only v1_25 archive."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[1]
counts=json.loads((R/'data/v125_release_counts.json').read_text())
records=[]
for p in sorted(R.rglob('*')):
 if not p.is_file() or p.name=='MANIFEST.json' or '__pycache__' in p.parts or p.suffix in ('.pyc','.zip'):
  continue
 b=p.read_bytes();records.append({'path':str(p.relative_to(R)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
p=R/'reports/INHERITED_V124_DATA_HASHES.json'
parent=json.loads(p.read_text())
manifest={
 'version':'v1_25','theme':'S3StructureNetwork','release_type':'standalone_cumulative_pure_mathematical_geometry_network',
 'archive_root':'Paper00-S3StructureNetwork-v1_25','parent_geometry_release':'v1_24',
 'proof_dag_copied':False,'statement_locator_nodes':0,'physical_transition_edges':0,
 'batch_scope':'exact A5-equivariant Petersen edge 5+6 sectors; two quintet axis intertwiners and natural Hodge sextet partial isometry; complete Hom dimension=3 and rank9 no-go',
 **{k:v for k,v in counts.items() if k!='parent' and k!='version'},
 'parent_archive_sha256':parent['parent_sha256'],
 'independent_batch_verification':'PASS: regenerate signed wedge, 2 quintet maps, 60 A5 actions, character Hom classification',
 'cumulative_structure_integrity':'PASS: 759 objects, 1043 maps, 132 joint-inputs, 117 compositions, full exported graph checked',
 'inherited_source_validation':'PASS: 24 unchanged v1_24 instance data SHA256 matches and previous v1_24 exact check',
 'complete_old_suite_replay':'NOT_COMPLETED_IN_THIS_RELEASE; full historical regenerators preserved as separate longer validation',
 'files':records}
(R/'MANIFEST.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
print('WROTE v1_25 MANIFEST:',len(records),'files')
