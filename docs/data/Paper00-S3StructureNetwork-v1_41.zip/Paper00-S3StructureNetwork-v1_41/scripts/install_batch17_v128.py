#!/usr/bin/env python3
"""Idempotent installation of geometry-only Batch 17 (v1_28).

Adds exact mathematical objects, maps and joint-input constraints for
2I harmonics, the Hopf degree-12 lift, the 25-cell/Petersen coefficient
projector identity, and labelled S3 harmonic functional calculus.
No theorem/claim vertices, no physics interface/decay edges.
"""
from __future__ import annotations
import json,pathlib,xml.etree.ElementTree as ET
from .icosahedral_harmonics_v128 import build as harmonic_build
from .petersen_pair_coefficients_v128 import build as pair_build
from .scalar_spectral_compositions_v128 import build as scalar_build
ROOT=pathlib.Path(__file__).resolve().parents[1];D=ROOT/'data';G=ROOT/'graph'
def rd(name):return json.loads((D/name).read_text())
def wr(name,val):(D/name).write_text(json.dumps(val,indent=2,ensure_ascii=False)+'\n')
W=rd('batch17_current_tex_witnesses.json')['source_witnesses']
O=rd('objects.json');R=rd('mathematical_relations.json');H=rd('joint_input_relations.json');C=rd('derived_compositions.json')
ids={v['id'] for v in O};edgeids={v['id'] for v in R};hids={v['id'] for v in H};cids={v['id'] for v in C}
ex='EXACT_REGENERATED_V128';sc='SOURCE_ATTESTED_CURRENT_TEX_WITH_EXACT_RESTRICTED_TEST_V128';guard='CONDITIONAL_GEOMETRIC_MAP_NOT_PHYSICAL_OCCURRENCE_V128'

def new_object(key,name,typ,claim,status=ex):
 id='geo:g28:'+key
 if id not in ids:
  O.append({'id':id,'name':name,'object_type':typ,'scope':'mathematical_structure_or_morphism',
            'source_kind':'mathematically_defined_operator_v128','conditional':status==guard,
            'batch':'v1_28','verification':status,'witness':W[claim]});ids.add(id)
 return id

a=new_object('icosahedral_antipodal_20','Antipodal 20-point design from ten C6 axis lines','finite_spherical_design','p6c:thm:v322-icosahedral-moment-tower')
b=new_object('icosahedral_H6','Exact degree-six icosahedral harmonic H6 on R3','homogeneous_harmonic_polynomial','p6c:thm:v322-icosahedral-moment-tower')
c=new_object('icosahedral_H10','Exact degree-ten icosahedral harmonic H10 on R3','homogeneous_harmonic_polynomial','p6c:thm:v322-icosahedral-moment-tower')
d=new_object('icosahedral_H15','Parity-odd degree-fifteen Jacobian harmonic H15','homogeneous_harmonic_polynomial','p6c:thm:v322-icosahedral-invariant-algebra')
e=new_object('T6_Legendre_axis_template','Normalized A5-invariant degree-six Legendre template T6 on S2','spherical_harmonic','p6b:prop:v322-angular-six')
f=new_object('primary_hopf_hbar_i_h','Quadratic primary left-circle Hopf map h(q)=qbar i q','bundle_map','p6c:thm:v322-right2i-hopf-lift')
g=new_object('Hopf_Phi12','Explicit right-2I fixed degree-12 harmonic Phi12=H6∘h','harmonic_intertwiner','p6c:thm:v322-right2i-hopf-lift')
h=new_object('chamber_T6_return25','Ordered twenty-five-block auxiliary degree-six return vector','finite_incidence_operator','p6b:cor:cc18-degree-six-chamber-bridge',sc)
i=new_object('fivecore_incidence_B5','Exact 120×25 five-core cell incidence B5','integer_incidence_operator','p6:thm:cell-incidence')
j=new_object('Petersen_pair_unsigned_Bu','Exact unsigned 120×100 2I Petersen-pair coefficient matrix Bu','integer_coefficient_operator','p6:thm:v338-pair-incidence-full-rank')
k=new_object('Petersen_pair_signed_Bo','Exact signed 120×100 2I Petersen-pair coefficient matrix Bo','integer_coefficient_operator','p6:thm:v338-pair-incidence-full-rank')
l=new_object('Petersen_10_P5','Rank-five Petersen ten-vertex spectral projector P5','rational_representation_projector','p6:thm:v338-pair-incidence-full-rank')
m=new_object('pair_25_zero_band_difference','Identity BuBuᵀ−B5B5ᵀ=24Π25=Chebyshev U4 kernel','finite_incidence_operator','p6:thm:v338-pair-incidence-full-rank')
n=new_object('momentum_S3_finite_shell_count','Finite scalar momentum-S3 harmonic cutoff count N_L','spectral_cutoff_operator','p10:thm:momentum-s3-harmonic-basis')

# Each entry specifies an actual mathematical map or restriction, with all
# source-specific guards in a joint-input bundle where needed.
links=[
 ('geo:2i',a,'ADJOINT_ICOSAHEDRAL_AXIS_ORBIT',ex,[]),
 ('geo:c6_projectors',a,'EXTRACT_TEN_PROJECTIVE_C6_AXES_AS_TWENTY_ANTIPODES',ex,[]),
 ('geo:g16:a5_conjugation_action',a,'A5_PERMUTES_TEN_C6_AXIS_LINES',ex,[]),
 (a,'geo:b7:icosahedral_moments','MOMENT_POLYNOMIALS_M2_M4_M6_M8_M10',ex,[]),
 (a,b,'SUBTRACT_ROTATIONAL_DEGREE_SIX_SCALAR_TRACE',ex,[]),
 (b,c,'DEGREE_TEN_HARMONIC_FROM_M10_AND_H6',ex,[b]),
 (b,d,'JACOBIAN_DETERMINANT_H15_WITH_H10',ex,[c]),
 (c,d,'JACOBIAN_DETERMINANT_H15_WITH_H6',ex,[b]),
 (b,'geo:b7:icosahedral_invariants','DEGREE_SIX_INVARIANT_RING_GENERATOR',ex,[]),
 (c,'geo:b7:icosahedral_invariants','DEGREE_TEN_INVARIANT_RING_GENERATOR',ex,[]),
 (d,'geo:b7:icosahedral_invariants','DEGREE_FIFTEEN_SECONDARY_INVARIANT_AND_MOLIEN',ex,[b,c]),
 ('geo:b7:icosahedral_moments','geo:b7:icosahedral_invariants','ROTATIONAL_INVARIANT_RING_MOLIEN_GENERATION',ex,[]),
 (a,e,'LEGENDRE_P6_ANTIPODAL_DESIGN_TEMPLATE',ex,[]),
 (b,e,'T6_EQUALS_231_OVER_160_H6_ON_UNIT_S2',ex,[]),
 (e,'geo:b7:angular_t6','EXACT_GEOMETRIC_T6_FIRST_NONISOTROPIC_TEMPLATE',ex,[]),
 (e,h,'SOURCE_DEFINED_CHAMBER_READOUT_T6_SOURCE_MARKED',sc,['geo:chamber_25register']),
 ('geo:chamber_25register',h,'ORDERED_25_BLOCK_RETURN_MARKING',sc,[]),
 ('geo:g16:chamber_U25_partition',h,'CHAMBER_TRANSPORTER_25_BLOCK_COMPARISON',sc,[]),
 (h,'geo:b7:chamber_sky_t6','AUXILIARY_RETURN_EIGENCONTRAST_NO_SKY_INTERPRETATION',sc,[]),
 ('geo:hopf',f,'PRIMARY_LEFT_CIRCLE_HOPF_QUADRATIC_COORDINATES',ex,[]),
 ('geo:hopf_base',f,'HOPF_BASE_IS_S2_WITH_QUADRATIC_H_COORDINATES',ex,[]),
 (f,g,'COMPOSE_HOPF_MAP_WITH_H6_HARMONIC',ex,[b]),
 (b,g,'DEGREE_SIX_TO_TWELVE_HARMONIC_PULLBACK',ex,[f]),
 (g,'geo:b7:right2i_hopf_lift','RIGHT_2I_INVARIANT_DEGREE12_SCALAR_HARMONIC',ex,[]),
 ('geo:g14:peter_weyl_E_n','geo:b7:right2i_hopf_lift','E12_SHELL_HAS_13_DIM_LEFT_MODULE_ON_RIGHT_2I_FIXED',ex,['geo:2i']),
 ('geo:2i_degree12',g,'EXPLICIT_HOPF_REPRESENTATIVE_OF_DEGREE12_INVARIANT',ex,[f]),
 ('geo:exceptional_spaceform_spectrum','geo:b7:right2i_hopf_lift','RIGHT_2I_S3_QUOTIENT_SCALAR_FIRST_HARMONIC',ex,[]),
 ('geo:b7:right2i_hopf_lift','geo:b7:binary2i_scalar_onset','EXCEPTIONAL_SCALAR_ONSET_ONLY_NOT_ROLE_OCCURRENCE',guard,[]),
 ('geo:g16:transporter25_shells',i,'TWENTYFIVE_24CELL_TRANSPORTERS_TO_INCIDENCE_MATRIX',ex,[]),
 ('geo:g16:a5_conjugation_action',i,'FIVE_CORE_PERMUTATION_MATRIX_COEFFICIENTS',ex,[]),
 ('geo:b6:icosahedral_25cell_incidence',i,'INCIDENCE_B5_FROM_25_TRANSLATED_2T_CELLS',ex,[]),
 (i,'geo:b6:icosahedral_incidence_spectrum','GRAM_B5T_B5_120_30_0_SPECTRUM',ex,[]),
 ('geo:petersen_graph',l,'PETERSEN_ADJACENCY_RANKFIVE_IDEMPOTENT',ex,[]),
 (l,j,'P5_TENSOR_P5_UNSIGNED_COEFFICIENT_RESOLUTION',ex,['geo:g16:a5_conjugation_action']),
 ('geo:g16:a5_conjugation_action',j,'A5_UNORIENTED_PAIR_PERMUTATION_COEFFICIENT',ex,[]),
 ('geo:petersen_signed',k,'ORIENTATION_SIGNS_OF_TEN_PETERSEN_PAIR_LABELS',ex,[]),
 ('geo:g16:a5_conjugation_action',k,'A5_SIGNED_PAIR_PERMUTATION_COEFFICIENT',ex,[]),
 (j,m,'UNSIGNED_K_MINUS_25CELL_K_GIVES_24_P25',ex,[i]),
 (i,m,'25_CELL_GRAM_REMOVES_1_PLUS_4_BLOCK',ex,[j]),
 ('geo:g27:twisted25_zero_band',m,'CHEBYSHEV_U4_CHARACTER_PROJECTOR_EQUALS_GRAM_DIFFERENCE',ex,[j,i]),
 (m,'geo:b6:25center_even_petersen_completion','RANK25_25CENTRE_EVEN_COEFFICIENT_SPECTRAL_BLOCK',ex,[]),
 (j,'geo:b6:25center_even_petersen_completion','UNSIGNED_42_DIM_COEFFICIENT_BLOCK',ex,[]),
 (k,'geo:b6:25center_even_petersen_completion','SIGNED_34_DIM_COEFFICIENT_BLOCK',ex,[j]),
 ('geo:b6:icosahedral_incidence_spectrum','geo:b6:25center_even_petersen_completion','RANK17_SUBMODULE_B5_WITHIN_RANK42_UNSIGNED',ex,[]),
 ('geo:round_s3','geo:b7:s3_green_spectrum','MEAN_ZERO_SCALAR_LAPLACIAN_SPECTRAL_INVERSE',ex,['geo:g14:peter_weyl_E_n']),
 ('geo:g14:peter_weyl_E_n','geo:b7:s3_green_spectrum','PETER_WEYL_LAPLACIAN_EIGENVALUE_RECIPROCALS',ex,[]),
 ('geo:s3_p','geo:b8:momentum_harmonics','MOMENTUM_LABELLED_S3_P_PETER_WEYL_BASIS',ex,[]),
 ('geo:spin4_harmonics','geo:b8:momentum_harmonics','FACTORWISE_SCALAR_PETER_WEYL_WITH_LABEL_P',ex,['geo:s3_p']),
 ('geo:m8_product','geo:b8:momentum_harmonics','RESTRICTION_TO_MARKED_S3_P_FACTOR_ONLY',ex,[]),
 ('geo:b8:momentum_harmonics',n,'EXACT_FINITE_MODE_CUTOFF_SUM_NL',ex,[]),
 ('geo:g14:peter_weyl_E_n',n,'SCALAR_HARMONIC_MULTIPLICITY_LPLUS1_SQUARED',ex,['geo:s3_p']),
]
for vfrom,vto,kind,status,requires in links:
    assert vfrom in ids and vto in ids,(vfrom,vto)
    id='G28-'+str(len([e for e in R if e['id'].startswith('G28-')])+1).zfill(3)
    if any(e['from']==vfrom and e['to']==vto and e['relation']==kind for e in R):continue
    relation={'id':id,'from':vfrom,'to':vto,'relation':kind,'link_type':'explicit_geometric_morphism_or_operator_composition',
        'conditions_preserved':True,'verification':status,'batch':'v1_28'}
    if requires:relation['requires_joint_inputs']=requires
    R.append(relation)

bundle_specs=[
 ('01',[a,'geo:c6_projectors'],[b,c,d],['fixed marked 2I and ten oriented-axis lines','unit-axis projectors, even moments','distinguish the A5 base invariant from right 2I harmonic']),
 ('02',[b,c],[d],['H15=det(v,grad H6,grad H10)','chosen orientation of imaginary quaternion space','H15 flips under spatial inversion']),
 ('03',[f,b],[g],['left-fibre h(q)=qbar i q','right-2I invariance from conjugation action','do not substitute opposite right Hopf map q i qbar']),
 ('04',[e,'geo:chamber_25register'],[h],['marked 25-block order from Paper I-B','T6 source-owned chamber readout','not a physical CMB/sky transfer or damping']),
 ('05',[l,'geo:g16:a5_conjugation_action'],[j,k],['same 2I on five tetrahedral core conjugates','Petersen ten pair ordering and signed action','not an SU2 continuum intertwiner']),
 ('06',[i,j,'geo:g27:twisted25_zero_band'],[m],['same marked 120 group elements and 25 cells','BuBuT-B5B5T exact identity','Chebyshev U4 projector already separately verified']),
 ('07',[j,k],[ 'geo:b6:25center_even_petersen_completion'],['central sign acts trivially on pair modules','combined Gram rank60 equals dimension center-even functions','no physical mass or source pole']),
 ('08',['geo:round_s3','geo:g14:peter_weyl_E_n'],['geo:b7:s3_green_spectrum'],['round metric radius r>0','remove constant zero mode','spectral inverse only, not cosmological perturbation propagator']),
 ('09',['geo:s3_p','geo:spin4_harmonics'],['geo:b8:momentum_harmonics',n],['marked momentum p factor','auxiliary finite cutoff L>=0','does not change primitive momentum multiplicity']),
 ('10',['geo:b7:right2i_hopf_lift'],['geo:b7:binary2i_scalar_onset'],['scalar spectral onset only','no promoted stage occurrence without source conditions']),
]
for nn,inputs,outputs,conditions in bundle_specs:
 id='HYP-G28-'+nn
 if id not in hids:
  assert all(v in ids for v in inputs+outputs)
  H.append({'id':id,'kind':'joint_mathematical_inputs_with_explicit_scope_conditions','inputs':inputs,'outputs':outputs,
            'conditions':conditions,'verification':guard if nn in ('04','10') else ex,'batch':'v1_28'})

compositions=[
 ('01','Icosahedral icosian axis polynomial tower','H6=M6−(10/7)r^6; H10=M10−(10/11)r^10−(42/17)r^4H6; H15=det(v,∇H6,∇H10)',
  'All ten axes extracted from the same marked C6 projectors. Exact polynomial expansion verifies ΔH6=ΔH10=ΔH15=0 and the 2I conjugation action permutes all axis lines.',['p6c:thm:v322-icosahedral-moment-tower','p6c:thm:v322-icosahedral-invariant-algebra']),
 ('02','Molien invariant-ring Hilbert series','Hilb(R[x,y,z]^A5;t)=(1+t^15)/((1−t²)(1−t^6)(1−t^10))',
  'Exact rotational character Molien rational expression simplifies to Hilbert series; degrees 2,6,10,15 are source-established. The full algebraic ring presentation is source-attested, not reproved solely from a finite polynomial test.',['p6c:thm:v322-icosahedral-invariant-algebra']),
 ('03','Antipodal T6 normalization and mean-square','T6=(231/160)H6 on S²; T6(u_a)=11/81; <T6²> = 11/1053',
  'Even sixth Legendre polynomial and exact ten-axis squared-overlap matrix. Addition theorem yields the mean-square exactly.',['p6b:prop:v322-angular-six']),
 ('04','Right 2I invariant Hopf scalar degree-12 lift','Φ12=H6(qbar i q); ΔR4 Φ12=0; −ΔS3 Φ12=168 Φ12',
  'Jacobian DhDhT=4|q|²I; coordinates of h are harmonic, H6 is homogeneous harmonic degree6, right-2I conjugation permutes projective C6 axes; E12^2I_R has dimension13.',['p6c:thm:v322-right2i-hopf-lift']),
 ('05','Petersen pair and 25-cell exact zero-band Gram difference','BuBuᵀ−B5B5ᵀ=U4=24 Π25',
  'Regenerate B5 (120x25), unsigned Bu and signed Bo (120x100) from 2I core permutations. Verify all 120x120 entries equal the separately certified Chebyshev U4 numerator.',['p6:thm:v338-pair-incidence-full-rank','p6:thm:cell-incidence']),
 ('06','Signed+unsigned pair functions span exactly center-even 2I coefficients','Spec(BuBuᵀ+BoBoᵀ)={120^1,60^16,40^18,24^25,0^60}',
  'Exact integer annihilator polynomials plus power-trace Vandermonde. Matrices invariant under central -1 and rank 60, equal full center-even space.',['p6:thm:v338-pair-incidence-full-rank']),
 ('07','25-cell Gram rook tensor decomposition','B5ᵀB5=24I25+6(J5−I5)⊗(J5−I5), spec 120^1+30^16+0^8',
  'All 25 incidence supports reconstructed from the 120 2I permutations, equality entrywise and spectral polynomial checked.',['p6:thm:cell-incidence','p6:thm:incidence-spectrum']),
 ('08','Round S3 scalar Green inverse and momentum factor cutoff','G_r|E_n=r²/[n(n+2)] for n≥1; N_L=(L+1)(L+2)(2L+3)/6',
  'Finite Peter-Weyl spectrum with constant mode removed. Momentum p-factor finite readout is a labelled copy, not identification of distinct S3_x/p roles.',['p9:lem:s3-green-spectrum','p10:thm:momentum-s3-harmonic-basis']),
 ('09','Marked degree-six chamber auxiliary return spectral contrast','R(T6)=−55/2304 1_25+77/3072 1_5⊗(4,−1,−1,−1,−1); contrast eigenvalue −5/4',
  'Source-attested marked return coefficients; independently checked eigenvector of I5⊗(J5−5I5)/4 and exp(−5t/4) evolution. Not an observed sky response.',['p6b:cor:cc18-degree-six-chamber-bridge']),
]
for nn,name,formula,proof,refs in compositions:
 id='D28-'+nn
 if id not in cids:
  C.append({'id':id,'name':name,'formula':formula,'hypotheses':['marked finite 2I/Hopf conventions','mathematical composition only, no source-visible physical parameter'],
            'proof':proof,'source_premises':refs,'status':'EXACT_V128_REPRODUCED' if nn not in ('02','09') else 'SOURCE_MATHEMATICAL_STATEMENT_WITH_EXACT_COMPONENT_CHECK_V128','batch':'v1_28'})
wr('objects.json',O);wr('mathematical_relations.json',R);wr('joint_input_relations.json',H);wr('derived_compositions.json',C)
wr('icosahedral_harmonics_v128_instance.json',harmonic_build())
wr('petersen_pair_coefficients_v128_instance.json',pair_build())
wr('scalar_spectral_compositions_v128_instance.json',scalar_build())
counts={'version':'v1_28','parent':'v1_27','new_objects':sum(v.get('batch')=='v1_28' for v in O),
 'new_typed_relations':sum(v.get('batch')=='v1_28' for v in R),
 'new_joint_inputs':sum(v.get('batch')=='v1_28' for v in H),
 'new_compositions':sum(v.get('batch')=='v1_28' for v in C),
 'cumulative_objects':len(O),'cumulative_edges':len(R),'cumulative_joint_inputs':len(H),'cumulative_compositions':len(C)}
wr('v128_release_counts.json',counts)
ns='http://graphml.graphdrawing.org/xmlns';ET.register_namespace('',ns);gtag=lambda t:'{'+ns+'}'+t
def graphml(path,objects,relations,label):
    root=ET.Element(gtag('graphml'))
    for key,typ,attr in [('d0','node','label'),('d1','node','kind'),('d2','node','batch'),('d3','node','verification'),('d4','edge','id'),('d5','edge','relation'),('d6','edge','verification'),('d7','edge','requires_and_inputs')]:
        ET.SubElement(root,gtag('key'),{'id':key,'for':typ,'attr.name':attr,'attr.type':'string'})
    g=ET.SubElement(root,gtag('graph'),{'id':label,'edgedefault':'directed'})
    for o in objects:
        n=ET.SubElement(g,gtag('node'),{'id':o['id']})
        for key,v in [('d0',o['name']),('d1',o['object_type']),('d2',o.get('batch','')),('d3',o.get('verification',''))]:ET.SubElement(n,gtag('data'),{'key':key}).text=str(v)
    for rel in relations:
        e=ET.SubElement(g,gtag('edge'),{'id':rel['id'],'source':rel['from'],'target':rel['to']})
        for key,v in [('d4',rel['id']),('d5',rel['relation']),('d6',rel.get('verification','')),('d7',','.join(rel.get('requires_joint_inputs',[])))]:ET.SubElement(e,gtag('data'),{'key':key}).text=str(v)
    ET.ElementTree(root).write(path,encoding='utf-8',xml_declaration=True)
graphml(G/'mathematical_structure_network.graphml',O,R,'S3_geometry_only_v128')
new=[e for e in R if e.get('batch')=='v1_28'];used={e['from'] for e in new}|{e['to'] for e in new}
graphml(G/'batch17_icosahedral_hopf_pair_coefficients.graphml',[o for o in O if o['id'] in used],new,'S3_batch17_icosahedral_hopf_pair')
print(json.dumps(counts,indent=2))
