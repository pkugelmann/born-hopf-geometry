#!/usr/bin/env python3
"""Exact finite representation geometry, independent of all physical identifications.
Reconstruct the Petersen 5-core mirror compressions, their new averaged squares,
and the elementary SU(3) invariant tensor and Casimir projectors.
"""
from __future__ import annotations
import json,itertools,collections
from pathlib import Path
import sympy as s
ROOT=Path(__file__).resolve().parents[1]
def load(f):return json.loads((ROOT/'data'/f).read_text())

def build_petersen():
    data=load('petersen_five_six_v125_instance.json')['matrices']; p=load('petersen_a5_bridge_v124_instance.json')
    H=s.Matrix([[s.Rational(x) for x in row] for row in data['pulled_back_Petersen_edge_Hodge6_15x15']])
    P4=s.Matrix(p['matrices']['petersen15_rank4_projector_numerator_Pe375_15x15'])/375
    P5=s.Matrix(p['matrices']['petersen15_rank5_projector_Pe5_15x15']);P6=s.eye(15)-P4-P5
    assert H**2==5*P6 and P6**2==P6 and P4*P6==s.zeros(15)
    pairs=[set(x) for x in p['petersen_vertices_10_core_pairs']];ed=p['petersen_oriented_edges_15']
    blocks={i:[] for i in range(5)}
    for i,(a,b) in enumerate(ed):
        missing=set(range(5))-(pairs[a]|pairs[b]);assert len(missing)==1
        blocks[missing.pop()].append(i)
    assert sorted(map(len,blocks.values()))==[3]*5
    w=s.symbols('t')
    expected={0:s.Integer(1),1:w**3,2:w**2*(w*w-s.Rational(3,4))**2,
              3:w**3*(w*w-1)*(w*w-s.Rational(7,4))**2,
              4:w**6*(w*w-3)**3,5:w**9*(w*w-5)**3}
    groups={}; per_subset=[];averages=[]
    for k in range(6):
        S=s.zeros(15)
        subsets=list(itertools.combinations(range(5),k))
        for sub in subsets:
            inds=[i for j in sub for i in blocks[j]]
            C=H.extract(inds,inds)
            assert s.expand(C.charpoly(w).as_expr()-expected[k])==0,('charpoly',sub)
            PP=s.diag(*[int(i in inds) for i in range(15)])
            full=PP*H*PP
            S+=(full*full)/5
            trace2=s.trace(C*C)/5 if inds else s.Integer(0)
            assert trace2==s.Rational(3,10)*k*(k-1)
            per_subset.append({'support_cores':list(sub),'dimension':3*k,'rank_mirror':int(C.rank()),'trace_D_S_squared':str(trace2)})
        average=S/len(subsets)
        coeff6=s.trace(average*P6)/6
        coeffother=s.trace(average*(P4+P5))/9
        assert average==coeff6*P6+coeffother*(P4+P5),('average spectral',k)
        averages.append({'k':k,'coefficient_on_six':str(coeff6),'coefficient_on_four_plus_five':str(coeffother),'trace':str(s.trace(average))})
        groups[k]={'subsets':len(subsets),'charpoly_of_sqrt5_times_mirror':str(expected[k]),'ranks':sorted({item['rank_mirror'] for item in per_subset if len(item['support_cores'])==k})}
    assert [c['coefficient_on_six'] for c in averages]==['0','0','1/25','9/50','12/25','1']
    assert [c['coefficient_on_four_plus_five'] for c in averages]==['0','0','1/25','2/25','2/25','0']
    # This follows from orthogonal rank-three Galois projectors; no mass, pole or field assignment.
    D=H/s.sqrt(5)
    Pi_plus=(P6+D)/2;Pi_minus=(P6-D)/2
    assert (Pi_plus*Pi_plus-Pi_plus).applyfunc(s.simplify)==s.zeros(15)
    assert (Pi_minus*Pi_minus-Pi_minus).applyfunc(s.simplify)==s.zeros(15)
    assert (Pi_plus*Pi_minus).applyfunc(s.simplify)==s.zeros(15)
    assert s.simplify(s.trace(Pi_plus))==3 and s.simplify(s.trace(Pi_minus))==3
    return {'schema':'exact_signed_Petersen_mirror_core_compressions_v130','source_instance':'petersen_five_six_v125_instance.json',
            'characteristic_polynomials_scaled_H_sqrt5D':{str(k):v for k,v in groups.items()},
            'core_triplets':{str(i):v for i,v in blocks.items()},
            'all_32_supports':per_subset,
            'new_averaged_squared_compression_identity':{'formula':'C(5,k)^{-1} sum_{|S|=k} (P_S D P_S)^2 = a_k P_6 + b_k (P_4+P_5)','coefficients':averages},
            'matrix_H_sqrt5D_15x15':[[str(x) for x in row] for row in H.tolist()],
            'matrix_rank6_P6_15x15':[[str(x) for x in row] for row in P6.tolist()],
            'checks':{'all_32_polynomials':True,'sharp_coherence_eigenvalues':True,'averaged_exact_operator_identity':True,'Pi_plus_rank3':True,'Pi_minus_rank3':True}}

def matunits():
    E={}
    for i in range(3):
        for j in range(3):
            M=s.zeros(3);M[i,j]=1;E[i,j]=M
    return E

def build_su3():
    e=matunits();I3=s.eye(3);I9=s.eye(9);I27=s.eye(27)
    T=[]
    for i,j in ((0,1),(0,2),(1,2)):
        T.extend([(e[i,j]+e[j,i])/2,(-s.I*e[i,j]+s.I*e[j,i])/2])
    T.extend([(e[0,0]-e[1,1])/2,(e[0,0]+e[1,1]-2*e[2,2])/(2*s.sqrt(3))])
    assert len(T)==8
    assert all(x==x.H and x.trace()==0 for x in T)
    assert all(s.simplify(s.trace(T[a]*T[b])-(s.Rational(1,2) if a==b else 0))==0 for a in range(8) for b in range(8))
    Swap=s.zeros(9)
    for i in range(3):
        for j in range(3):Swap[3*j+i,3*i+j]=1
    QQ=sum([s.kronecker_product(t,t) for t in T],s.zeros(9))
    assert s.simplify(QQ-(Swap-I9/3)/2)==s.zeros(9)
    v=s.zeros(9,1)
    for i in range(3):v[3*i+i]=1
    P1=v*v.T/3
    Qbar=-sum([s.kronecker_product(t,t.T) for t in T],s.zeros(9))
    assert s.simplify(Qbar-(I9/6-s.Rational(3,2)*P1))==s.zeros(9)
    assert P1**2==P1 and P1.trace()==1
    P8=I9-P1
    for t in T:
        L=s.kronecker_product(t,I3)-s.kronecker_product(I3,t.T)
        assert L*P1==s.zeros(9) and P1*L==s.zeros(9)
    Pa=(I9-Swap)/2;Ps=(I9+Swap)/2
    assert QQ*Pa==-s.Rational(2,3)*Pa
    assert QQ*Ps==s.Rational(1,3)*Ps
    assert Pa.trace()==3 and Ps.trace()==6
    eps=s.zeros(27,1)
    for perm in itertools.permutations(range(3)):
        inversions=sum(perm[i]>perm[j] for i in range(3) for j in range(i+1,3))
        eps[9*perm[0]+3*perm[1]+perm[2],0]=(-1)**inversions
    Peps=eps*eps.T/6
    assert Peps**2==Peps and Peps.trace()==1
    for t in T:
        Lt=s.kronecker_product(t,I3,I3)+s.kronecker_product(I3,t,I3)+s.kronecker_product(I3,I3,t)
        assert Lt*eps==s.zeros(27,1)
    # baryon state has each pair in antisymmetric 3-bar, hence -2/3 pair Casimir.
    for a,b in [(0,1),(0,2),(1,2)]:
        Cab=s.zeros(27)
        for t in T:
            fac=[t if i in (a,b) else I3 for i in range(3)]
            Cab+=s.kronecker_product(*fac)
        assert (Cab+s.Rational(2,3)*I27)*eps==s.zeros(27,1)
    # fundamental Lie generators on C^3 are irreducible; Haar singlet projectors
    # on 3x3bar and 3x3x3 are the displayed orthogonal rank-one projectors.
    gram=(v.T*v)[0];assert gram==3 and (eps.T*eps)[0]==6
    return {'schema':'exact_su3_fundamental_invariant_tensor_geometry_v130',
            'matrix_meson_singlet_projector_9x9':[[str(x) for x in row] for row in P1.tolist()],
            'matrix_baryon_determinant_projector_27x27':[[str(x) for x in row] for row in Peps.tolist()],
            'matrix_quark_antiquark_casimir_9x9':[[str(x) for x in row] for row in Qbar.tolist()],
            'matrix_quark_quark_casimir_9x9':[[str(x) for x in row] for row in QQ.tolist()],
            'characteristic_scopes':{'3_x_3bar':'1 ⊕ 8','3_x_3':'6 ⊕ 3bar','exterior3_3':'1 determinant',
                                     '3_x_3_x_3':'1 ⊕ 8 ⊕ 8 ⊕ 10'},
            'rank_checks':{'meson_singlet':1,'meson_adjoint':8,'diquark_antisymmetric':3,'diquark_symmetric':6,'baryon_determinant':1},
            'casimir_eigenvalues':{'3_x_3bar_singlet':'-4/3','3_x_3bar_octet':'1/6',
                                  '3_x_3_antisym':'-2/3','3_x_3_sym':'1/3',
                                  'baryon_pairwise':'-2/3'},
            'center_triality_condition':'n_q-n_anti is 0 mod 3 is necessary for singlet; not sufficient',
            'scope':'abstract SU(3) fundamental and tensor invariants, NOT a physical Hilbert space, QCD Hamiltonian, mass or pole',
            'checks':{'gell_mann_normalization':True,'SU3_singlets_invariant':True,'exact_Fierz':True,
                      'Casimir_spectrum':True,'determinant_invariant':True}}

def build_gram():
    gamma=s.symbols('gamma',real=True)
    J=s.ones(3,3);G=40*((1-gamma)*s.eye(3)+gamma*J)
    assert G.eigenvals()=={40*(1-gamma):2,40*(1+2*gamma):1}
    assert s.trace(G)==120 and sum(G)==120+240*gamma
    return {'equicorrelation_real_three_source_gram_formula':'40*((1-gamma)*I3+gamma*J3)',
      'eigenvalues':['40(1+2 gamma)','40(1-gamma) multiplicity 2'],
      'PSD_iff':'-1/2 <= gamma <= 1',
      'sum_amplitude_squared':'120+240 gamma',
      'mathematical_scope_only':True}

def build():return {'petersen':build_petersen(),'su3':build_su3(),'gram':build_gram()}

if __name__=='__main__':
    obj=build();(ROOT/'data/finite_invariant_geometry_v130_instance.json').write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n');print('PASS exact 32 Petersen core compressions, average operators and finite SU3 invariant tensors, Casimirs.')
