#!/usr/bin/env python3
"""Graph connectivity only; a conditional link is NOT a certificate for the whole source claim."""
import json,networkx as nx
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def load(name):return json.loads((ROOT/name).read_text())
def main():
 O=load('data/objects.json');E=load('data/mathematical_relations.json');H=load('data/joint_input_relations.json');D=load('data/derived_compositions.json')
 prev=load('reports/geometry_completeness_v130.json');old=set(x['id'] for x in prev['remaining_isolates'])
 G=nx.Graph();G.add_nodes_from(o['id'] for o in O);G.add_edges_from((e['from'],e['to']) for e in E)
 comp=sorted(nx.connected_components(G),key=len,reverse=True);isolates=set(nx.isolates(G));idx={o['id']:o for o in O}
 linked=sorted(old-isolates)
 counts={'mathematical_object_records':len(O),'typed_morphism_records':len(E),'joint_input_bundles':len(H),
 'derived_composition_records':len(D),'weak_components':len(comp),
 'component_containing_S3':len(nx.node_connected_component(G,'geo:s3')),
 'largest_weak_component':len(comp[0]),'isolated_objects':len(isolates),
 'isolated_foundational_or_core_records':sum(not s.startswith(('geo:b6:','geo:b7:','geo:b8:')) for s in isolates),
 'isolated_later_operator_records':sum(s.startswith(('geo:b6:','geo:b7:','geo:b8:')) for s in isolates),
 'nontrivial_disconnected_components':sum(len(c)>1 for c in comp[1:]),
 'previous_isolates_now_mathematically_linked':len(linked)}
 def entry(o):return {'id':o['id'],'name':o['name'],'object_type':o['object_type'],
    'witness_claim':o.get('witness',{}).get('claim_id'),
    'bucket':'LATER_PAPER_MATHEMATICAL_OPERATOR' if o['id'].startswith(('geo:b6:','geo:b7:','geo:b8:')) else 'FOUNDATIONAL_OR_TECHNICAL_RECORD',
    'status':'UNCONNECTED_NO_ADMITTED_MATHEMATICAL_MORPHISM'}
 x={'version':'v1_31','parent':'v1_30',
    'method':'Weak connected components of typed mathematical graph; even guarded edges count for navigation, not full theorem closure',
    'counts':counts,'newly_linked_preexisting_records':[{'id':i,'name':idx[i]['name']} for i in linked],
    'remaining_isolates':[entry(o) for o in O if o['id'] in isolates],
    'deliberate_nonconnections':prev['deliberate_nonconnections'],
    'verified_new_subobjects':'Marked SU2->SU3 group embedding and normalized Cartan/Hopf form; exact 3x3bar Casimir and centralizer; two-site Haar Gauss; ordered finite-path naturality; normalized determinant Casimir total',
    'guarded_partial_owner_warning':'Ten previously isolated owner records now have links. These identify mathematical suboperators/examples only, not complete physical or QCD source constructions. In particular 7 later-paper full operators are NOT certified by toy carriers.',
    'source_audit':'11 current TeX label/hash witnesses verified against PapersMinimal v3_029; inherited labels not all semantically reverified',
    'status':'NOT_EXHAUSTIVE: source-derived geometry inventory, full operator identification and all compositions remain open'}
 (ROOT/'reports/geometry_completeness_v131.json').write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
 release={'version':'v1_31','parent':'v1_30','batch_index':20,
    'new_objects':len([o for o in O if o.get('batch')=='v1_31']),
    'new_typed_relations':len([e for e in E if e.get('batch')=='v1_31']),
    'new_joint_inputs':len([h for h in H if h.get('batch')=='v1_31']),
    'new_compositions':len([d for d in D if d.get('batch')=='v1_31']),
    'cumulative_objects':len(O),'cumulative_edges':len(E),
    'cumulative_joint_inputs':len(H),'cumulative_compositions':len(D),
    'isolated_objects':len(isolates),'main_component':counts['component_containing_S3'],
    'nontrivial_disconnected_components':counts['nontrivial_disconnected_components'],
    'previous_isolates_now_linked':len(linked),
    'conditional_links_this_batch':len([e for e in E if e.get('batch')=='v1_31' and e['verification'].startswith('SCOPED')]),
    'new_exact_links_this_batch':len([e for e in E if e.get('batch')=='v1_31' and e['verification'].startswith('EXACT')]),
    'source_labels_hashed_in_current_TeX':11,'full_historical_regeneration':'NOT_RUN',
    'batch_specific_mathematics':'EXACT_PASS'}
 (ROOT/'data/v131_release_counts.json').write_text(json.dumps(release,indent=2,ensure_ascii=False)+'\n')
 assert release['new_objects']==17 and release['new_typed_relations']==41
 assert counts['isolated_objects']==53 and counts['component_containing_S3']==794
 print(json.dumps(counts,indent=2));print('PASS: v1_31 counts and documented isolation scope')
if __name__=='__main__':main()
