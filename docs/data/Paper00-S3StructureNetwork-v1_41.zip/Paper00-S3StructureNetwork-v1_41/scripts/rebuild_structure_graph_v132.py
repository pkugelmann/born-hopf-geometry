#!/usr/bin/env python3
"""Rebuild/check v1_32 mathematical-structure GraphML and DOT from the JSON operator graph.

The GraphML is a source-scope-preserving navigation export, not a proof DAG.
Use --check to verify deterministic bytes without modifying the archive.
"""
from pathlib import Path
import json, xml.etree.ElementTree as ET, argparse
ROOT=Path(__file__).resolve().parents[1]
load=lambda name:json.loads((ROOT/'data'/name).read_text())
O=load('objects.json');E=load('mathematical_relations.json')
NS='http://graphml.graphdrawing.org/xmlns'; ET.register_namespace('',NS)
t=lambda name:'{'+NS+'}'+name
omap={o['id']:o for o in O}

def graphml(nodes,edges):
    root=ET.Element(t('graphml'))
    for key,context,name in [('n0','node','label'),('n1','node','object_type'),('n2','node','batch'),
                              ('e0','edge','relation'),('e1','edge','link_type'),('e2','edge','verification'),
                              ('e3','edge','requires_and_inputs')]:
        ET.SubElement(root,t('key'),{'id':key,'for':context,'attr.name':name,'attr.type':'string'})
    g=ET.SubElement(root,t('graph'),{'id':'BornHopfS3Mathematical','edgedefault':'directed'})
    for id in nodes:
        o=omap[id];n=ET.SubElement(g,t('node'),{'id':id})
        for key,value in [('n0',o['name']),('n1',o['object_type']),('n2',o.get('batch',''))]:
            ET.SubElement(n,t('data'),{'key':key}).text=str(value)
    for e in edges:
        ed=ET.SubElement(g,t('edge'),{'id':e['id'],'source':e['from'],'target':e['to']})
        for key,value in [('e0',e['relation']),('e1',e['link_type']),('e2',e.get('verification','')),
                          ('e3',','.join(e.get('requires_joint_inputs',[])))]:
            ET.SubElement(ed,t('data'),{'key':key}).text=str(value)
    from io import BytesIO
    f=BytesIO();ET.ElementTree(root).write(f,encoding='utf-8',xml_declaration=True)
    return f.getvalue()

def dot(nodes,edges):
    lines=['digraph BornHopfS3Mathematical {','  graph [rankdir=LR];','  node [shape=box];']
    for id in nodes:
        lines.append('  '+json.dumps(id)+' [label='+json.dumps(omap[id]['name'])+'];')
    for e in edges:
        lines.append('  '+json.dumps(e['from'])+' -> '+json.dumps(e['to'])+' [label='+json.dumps(e['id']+': '+e['relation'])+'];')
    return ('\n'.join(lines)+'\n}\n').encode()

def main():
    p=argparse.ArgumentParser();p.add_argument('--check',action='store_true');args=p.parse_args()
    full=[o['id'] for o in O];ed21=[e for e in E if e['id'].startswith('G32-')]
    sub=sorted({i for e in ed21 for i in (e['from'],e['to'])})
    for path,data in [('graph/mathematical_structure_network.graphml',graphml(full,E)),
                      ('graph/mathematical_structure_network.dot',dot(full,E)),
                      ('graph/batch21_S3_closure_exact_scoped_links.graphml',graphml(sub,ed21)),
                      ('graph/batch21_S3_closure_exact_scoped_links.dot',dot(sub,ed21))]:
        target=ROOT/path
        if args.check:
            assert target.read_bytes()==data,(path,'graph export differs from JSON replay')
        else:target.write_bytes(data)
        print(('CHECK' if args.check else 'WRITE'),path,len(data))
    assert len(ed21)==72 and len(E)==1392 and len(O)==862
    print('PASS v1_32 GraphML/DOT deterministic replay and exact current node/edge inventory')

if __name__=='__main__':main()
