#!/usr/bin/env python3
"""Generate cumulative SHA256 manifest for S3 structure network v1_35."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[1]
parent=Path('/mnt/data/Paper00-S3StructureNetwork-v1_34.zip')
prev=json.loads((R/'data/v135_parent_manifest_snapshot.json').read_text())
stat=json.loads((R/'data/v135_verified_frontier_status.json').read_text())
files=[]
for p in sorted(R.rglob('*')):
 if not p.is_file() or p.name=='MANIFEST.json' or '__pycache__' in p.parts or p.suffix in ('.pyc','.zip'):
  continue
 files.append({'path':p.relative_to(R).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
M={
 'version':'v1_35','theme':'S3StructureNetwork','parent':'v1_34','archive_root':'Paper00-S3StructureNetwork-v1_35',
 'release_type':'cumulative_S3_math_graph_and_dual_axis_conditional_proof_evidence',
 'parent_archive_sha256':hashlib.sha256(parent.read_bytes()).hexdigest() if parent.exists() else None,
 'parent_manifest_version':prev['version'],'parent_manifest_files':len(prev['files']),
 'historical_data_and_graphs_mutated':False,'physical_transition_edges':0,'theorem_claim_nodes_added':0,
 'proof_dag_copied':False,'source_tex_copied':False,'previous_zip_copied':False,
 'cumulative_objects':862,'cumulative_edges':1392,'cumulative_joint_inputs':242,'cumulative_compositions':183,
 'isolated_object_records':5,'main_connected_component':855,
 'source_scoped_map_candidates':stat['original_frontier_count'],
 'independent_conditional_map_replays_total':24,'new_independent_conditional_map_replays':3,
 'source_scoped_map_replays_unverified':0,'targeted_source_owner_selection_frontiers_still_open':3,
 'source_theorems_or_physical_occurrences_promoted':0,
 'newly_replayed_relation_ids':stat['newly_verified_ids'],
 'targeted_open_owner_relation_ids':stat['source_boundary_pending_ids'],
 'effective_verification_source':'data/v135_verified_frontier_status.json',
 'effective_graph':'graph/mathematical_structure_network_effective_v135.graphml',
 'source_owner_frontier':'data/v135_source_owner_frontier.json',
 'checks':['verify_scoped_math_v135.py --check','build_overlay_v135.py --check','rebuild_effective_graph_v135.py --check',
  'verify_parent_v134_integrity_v135.py','verify_batch24_v135.py','validate_geometry.py --fast','verify_graph_exports.py','verify_manifest.py'],
 'verification_summary':{
  'fixed_axial_Hurwitz_color_family_M9':'PASS exact on source-fixed orientation and independent factor-local tests',
  'E56_terminal_depth1_jet':'PASS exact under source-defined jet/row-energy grammar',
  'meson_singlet_reducing_H':'PASS exact conditional on H selfadjoint reducing sector',
  'meson_color_only_nonreducing_countermodel':'PASS exact',
  'GP3_whole_candidate_source_selection':'OPEN conditional owner',
  'kappa56_frozen_source_word_exhaustion':'OPEN source-port occurrence',
  'actual_meson_H_JPC_commutation_pole':'OPEN supplied source/action',
  'physical_owner_occurrence':'NOT PROMOTED',
  'historical_full_regeneration':'NOT RUN',
  'global_semantic_exhaustiveness':'NOT CLAIMED',
  'cumulative_geometry_fast_suite':'PASS',
  'cumulative_graph_export':'PASS'},
 'files':files}
(R/'MANIFEST.json').write_text(json.dumps(M,indent=2,ensure_ascii=False)+'\n')
print('WRITE MANIFEST',len(files),'files; source-order ready')
