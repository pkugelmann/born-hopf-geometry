#!/usr/bin/env python3
"""Independently regenerate the 600-cell's twisted-quintet zero-band.

Only exact integer and Q(sqrt5) polynomial arithmetic is used. Ranks of
integer matrices are rigorously certified via a nonzero minor over F_p
and an explicit rational nullspace (no floating rank tolerance).
"""
from __future__ import annotations
import pathlib,json
import numpy as np
from sympy import sqrt,simplify,Rational
ROOT=pathlib.Path(__file__).resolve().parents[1]
def data(f):return json.loads((ROOT/'data'/f).read_text())

def rank_mod(A,p=1000003):
    a=A.copy().astype(np.int64)%p;m,n=a.shape;rank=0
    for col in range(n):
        candidates=np.nonzero(a[rank:,col])[0]
        if len(candidates)==0:continue
        pivot=int(candidates[0])+rank
        if pivot!=rank:a[[rank,pivot]]=a[[pivot,rank]]
        inv=pow(int(a[rank,col]),-1,p)
        a[rank,col:]=(a[rank,col:]*inv)%p
        if rank+1<m:
            factors=a[rank+1:,col].copy()
            a[rank+1:,col:]=(a[rank+1:,col:]-factors[:,None]*a[rank,col:])%p
        rank+=1
        if rank==m:break
    return rank

def build():
    x=data('exceptional_600cell_instance.json');V=[r['qcoords'] for r in x['vertices']]
    assert len(V)==120
    # x=Re(q^-1r)=(A+B sqrt5)/16 for quaternion coordinates /4.
    def dot(q,r):
        return (sum(a*c+5*b*d for (a,b),(c,d) in zip(q,r)),
                sum(a*d+b*c for (a,b),(c,d) in zip(q,r)))
    all_dot={dot(V[0],r) for r in V}
    # Every dot product of the 120 roots belongs to exactly these 9 values.
    expected={(16,0),(-16,0),(8,0),(-8,0),(0,0),
              (4,4),(4,-4),(-4,4),(-4,-4)}
    assert all_dot==expected
    cheb={}
    for key in sorted(expected):
        u=Rational(key[0],16)+Rational(key[1],16)*sqrt(5)
        value=simplify(16*u**4-12*u**2+1)
        assert value.is_integer
        cheb[key]=int(value)
    P24=np.array([[cheb[dot(q,r)] for r in V] for q in V],dtype=np.int64)
    assert np.array_equal(P24,P24.T)
    assert np.trace(P24)==600   # 24*25
    assert np.array_equal(P24@P24,24*P24)
    A=np.zeros((120,120),dtype=np.int64)
    for e in x['nearest_edges']:
        a,b=e['u'],e['v'];A[a,b]=A[b,a]=1
    assert len(x['nearest_edges'])==720 and all(A.sum(axis=1)==12)
    assert not np.any(A@P24)
    # The rational projector has rank 25, giving rank_Q A<=95.
    # A mod p has rank 95, giving rank_Q A>=95. Hence equality.
    ranks={str(p):rank_mod(A,p) for p in (101,1009,100003)}
    assert all(v==95 for v in ranks.values()),ranks
    # Separate -3 transporter eigenspace, certificate in inherited v1_16 data.
    B=np.zeros((120,25),dtype=np.int64)
    for j,s in enumerate(data('finite_geometry_v116_instance.json')['transporter_24cells']['sets']):
        B[s,j]=1
    N16=B@B.T-np.ones((120,120),dtype=np.int64) # 30 P_minus3
    assert np.array_equal(N16@N16,30*N16)
    assert np.array_equal(A@N16,-3*N16)
    assert not np.any(P24@N16)
    assert np.trace(N16)==480 # 30*16
    return {'schema':'pure_integer_projector_and_exact_modular_rank_certificate',
            'root_order':'the 120 exact quaternion roots in exceptional_600cell_instance.json',
            'Re_quaternion_product_field':'(A+B sqrt5)/16; keys (A,B) encoded as decimal integers',
            'U4_Chebyshev_on_nine_inner_product_classes':[
               {'A':a,'B':b,'U4':v} for (a,b),v in sorted(cheb.items())],
            'projector_numerator_120x120':P24.tolist(),
            'projector':'Pi25=P24/24=U4(Re(q^-1 r))/24',
            'exact_idempotence':'P24^2=24 P24',
            'projector_trace_and_rank':25,
            'A600_times_projector':'A600 P24 = 0',
            'exact_rational_rank_A600':95,
            'modular_lower_bounds_rank_A600':ranks,
            'spectrum_zero_band':'Ran(Pi25)=ker(A600), dimension 25',
            'minus3_transporter_orthogonality':'P24 (B B^T-J)=0, B is 25 transporter 24cells',
            'nonidentification':['rank-25 adjacency-zero band is not the rank-16 adjacency-minus3 band',
                                 'not a zero-eigenvalue graph Laplacian sector',
                                 'not a physical zero-energy or massless state']}
if __name__=='__main__':
 print(json.dumps(build(),indent=2))
