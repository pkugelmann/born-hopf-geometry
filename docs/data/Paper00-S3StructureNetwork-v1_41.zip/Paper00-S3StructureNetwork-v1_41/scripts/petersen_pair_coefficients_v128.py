#!/usr/bin/env python3
"""Batch 17: regenerate pair coefficient carriers from one marked 2I action.

The unsigned 120x100 B_u, signed 120x100 B_o, and 25-cell 120x25
B_5 are built by integer permutation/signed-permutation actions of
2I on the five marked 2T cores; no fitted factors or paper DAG nodes.
"""
from itertools import combinations
import numpy as np
import sympy as sp
from .exceptional_model import build_instance, generate_vertices, qmul,conj
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]

def spectral_multiplicities(K, spectrum):
    """Recover spectral multiplicities exactly from traces of K^p.
    Requires a separately verified squarefree annihilating polynomial.
    """
    n=K.shape[0]
    X=np.eye(n,dtype=np.int64)
    traces=[]
    for k in range(len(spectrum)):
        traces.append(int(np.trace(X)))
        X=X@K
    v=sp.Matrix([[sp.Integer(k)**p for k in spectrum] for p in range(len(spectrum))])
    sol=v.inv()*sp.Matrix(traces)
    assert all(x.is_Integer and x>=0 for x in sol)
    return {str(k):int(m) for k,m in zip(spectrum,sol)}

def build():
    I0=build_instance();_,I=generate_vertices();V=sorted(I);vix={q:i for i,q in enumerate(V)}
    cores=[set(ids) for ids in I0['conjugate_core_groups']]
    dic={frozenset(x):i for i,x in enumerate(cores)}
    perms=[]
    for g in V:
        gb=conj(g)
        perms.append([dic[frozenset(vix[qmul(qmul(g,V[t]),gb)] for t in core)] for core in cores])
    assert len({tuple(x) for x in perms})==60
    pair=list(combinations(range(5),2));pidx={p:i for i,p in enumerate(pair)}
    Bu=np.zeros((120,100),dtype=np.int64)
    Bo=np.zeros((120,100),dtype=np.int64)
    B5=np.zeros((120,25),dtype=np.int64)
    unsigned_rows=[];signed_rows=[];signed_signs=[];cells_rows=[]
    for g,perm in enumerate(perms):
        urow=[];sgn=[];vrow=[]
        for j,S in enumerate(pair):
            out=(perm[S[0]],perm[S[1]])
            t=pidx[tuple(sorted(out))]
            col=t*10+j;w=1 if out[0]<out[1] else -1
            Bu[g,col]=1;Bo[g,col]=w
            urow.append(col);sgn.append(w)
        for j in range(5):
            col=perm[j]*5+j;B5[g,col]=1;vrow.append(col)
        unsigned_rows.append(urow);signed_signs.append(sgn);cells_rows.append(vrow)
    assert np.all(Bu.sum(axis=1)==10) and np.all(B5.sum(axis=1)==5)
    A=np.array([[int(i!=j and not set(p)&set(q)) for j,q in enumerate(pair)] for i,p in enumerate(pair)],dtype=np.int64)
    eye10=np.eye(10,dtype=np.int64)
    N5=-(A-3*eye10)@(A+2*eye10) # P5=N5/6, rank five
    assert np.array_equal(N5@N5,6*N5) and int(np.trace(N5))==30
    K=Bu@Bu.T;K5=B5@B5.T;Ko=Bo@Bo.T;Ksum=K+Ko
    U4=np.array(json.loads((ROOT/'data/twisted25_v127_instance.json').read_text())['projector_numerator_120x120'],dtype=np.int64)
    assert np.array_equal(K-K5,U4), 'new cross-paper operator equality failed'
    assert np.array_equal(Bu@np.kron(N5,N5)@Bu.T,36*U4)
    assert np.array_equal(U4@U4,24*U4) and int(np.trace(U4))==600
    J5=np.ones((5,5),dtype=np.int64);I5=np.eye(5,dtype=np.int64)
    assert np.array_equal(B5.T@B5,24*np.eye(25,dtype=np.int64)+6*np.kron(J5-I5,J5-I5))
    Z=np.zeros((120,120),dtype=np.int64);I120=np.eye(120,dtype=np.int64)
    assert np.array_equal(K@(K-24*I120)@(K-30*I120)@(K-120*I120),Z)
    assert np.array_equal(K5@(K5-30*I120)@(K5-120*I120),Z)
    assert np.array_equal(Ko@(Ko-30*I120)@(Ko-40*I120),Z)
    assert np.array_equal(Ksum@(Ksum-24*I120)@(Ksum-40*I120)@(Ksum-60*I120)@(Ksum-120*I120),Z)
    # All matrices are real symmetric: annihilator roots and exact moment
    # Vandermonde solutions give the full spectra without numeric eigensolvers.
    eig={
      'unsigned':spectral_multiplicities(K,[0,24,30,120]),
      '25cells':spectral_multiplicities(K5,[0,30,120]),
      'signed':spectral_multiplicities(Ko,[0,30,40]),
      'combined':spectral_multiplicities(Ksum,[0,24,40,60,120])}
    assert eig['unsigned']=={'0':78,'24':25,'30':16,'120':1}
    assert eig['25cells']=={'0':103,'30':16,'120':1}
    assert eig['signed']=={'0':86,'30':16,'40':18}
    assert eig['combined']=={'0':60,'24':25,'40':18,'60':16,'120':1}
    assert all(perms[i]==perms[vix[tuple((-q[0],-q[1]) for q in V[i])]] for i in range(120))
    return {
      'source':'one marked 2I, five 2T core conjugates, ten Petersen core pairs',
      '120_group_elements_to_five_core_permutations':perms,
      'unsigned_Bu_row_nonzero_indices':unsigned_rows,
      'signed_Bo_row_nonzero_indices':unsigned_rows,
      'signed_Bo_row_nonzero_values':signed_signs,
      'five_core_B5_row_nonzero_indices':cells_rows,
      'Petersen_adjacency_10x10':A.tolist(),
      'Petersen_rank5_projector_numerator_N5_over_6':N5.tolist(),
      'exact_Gram_spectral_multiplicities':eig,
      'exact_matrix_identities':[
        'Bu Bu^T - B5 B5^T = U4 = 24 Pi25 (exact integer entrywise)',
        'Bu (N5 tensor N5) Bu^T = 36 U4; P5=N5/6',
        'B5^T B5=24 I25+6(J5-I5) tensor (J5-I5)',
        'im Bu + im Bo is precisely the 60-dimensional center-even subspace',
        'all annihilator polynomials verified over integers'
      ],
      'vertex_count':120,'unsigned_shape':[120,100],'signed_shape':[120,100],'cell_shape':[120,25],
      'distinct_projective_permutations':60,
      'condition':'same marked 2I/2T and ten pair ordering, not a mass or physical spectrum',
    }
if __name__=='__main__':
 out=build();print(json.dumps({'spectra':out['exact_Gram_spectral_multiplicities'],'identities':out['exact_matrix_identities']},indent=2))
