#!/usr/bin/env python3
"""Symbolic SU(2) left-invariant scalar spectral block certificates.

The coframe is the *metric-adapted left-invariant* Milnor coframe.
No identification with the primary right-invariant Hopf/ Berger frame
without inversion and constant SO(3) transport is made.
"""
from __future__ import annotations
import sympy as sp


def spin_matrices(twoj):
    j=sp.Rational(twoj,2);ms=[-j+i for i in range(twoj+1)];n=twoj+1
    Jp=sp.zeros(n)
    for idx,m in enumerate(ms[:-1]):
        Jp[idx+1,idx]=sp.sqrt((j-m)*(j+m+1))
    Jm=Jp.T;J3=sp.diag(*ms)
    J1=(Jp+Jm)/2;J2=(Jp-Jm)/(2*sp.I)
    assert J1*J2-J2*J1 == sp.I*J3
    assert J1**2+J2**2+J3**2 == j*(j+1)*sp.eye(n)
    return j,J1,J2,J3,Jp,Jm


def block(twoj,w):
    j,J1,J2,J3,Jp,Jm=spin_matrices(twoj)
    w1,w2,w3=w
    h=w1*(J1**2)+w2*(J2**2)+w3*(J3**2)
    wbar=(w1+w2)/2
    jacobi=wbar*j*(j+1)*sp.eye(twoj+1)+(w3-wbar)*(J3**2)+(w1-w2)/4*(Jp**2+Jm**2)
    assert h==jacobi
    assert h==h.H
    assert all(h[i,k]==0 for i in range(twoj+1) for k in range(twoj+1) if abs(i-k) not in (0,2))
    wmin=min(w)
    assert h-wmin*j*(j+1)*sp.eye(twoj+1)==sum(((wi-wmin)*(Ji**2) for wi,Ji in zip(w,[J1,J2,J3])),sp.zeros(twoj+1))
    return h


def build():
    examples=[]
    weights=[tuple(map(sp.Rational,x)) for x in [(1,2,5),(2,3,7),(4,4,4),(3,3,8)]]
    for w in weights:
        for twoj in range(0,9):
            h=block(twoj,w)
            if twoj==1:assert h==(sum(w)/4)*sp.eye(2)
            if twoj==2:
                assert sorted([e for e,m in h.eigenvals().items() for _ in range(m)])==sorted([w[0]+w[1],w[0]+w[2],w[1]+w[2]])
            if twoj in (0,1,2,4):
                examples.append({'weights':[str(x) for x in w], 'twice_spin':twoj, 'block_dimension':twoj+1,
                                 'block_trace':str(sp.trace(h)), 'step_two_only':True})
    # 1-spin spectral unordered recovery: l=(w2+w3,w3+w1,w1+w2)
    a,b,c=sp.symbols('a b c',positive=True)
    lambdas=(b+c,a+c,a+b)
    recovered=tuple(sp.simplify((sum(lambdas)-2*l)/2) for l in lambdas)
    assert recovered==(a,b,c)
    # The round special case a=b=c=R/2 implies w_i=4/R^2;
    # j=1/2 gives 3/R^2, j=1 gives 8/R^2.
    R=sp.symbols('R',positive=True);wr=(4/R**2,)*3
    assert block(1,wr)==3/R**2*sp.eye(2)
    assert block(2,wr)==8/R**2*sp.eye(3)
    return {'conventions':{'coframe':'metric-adapted Milnor left-invariant; T_i brackets epsilon_ijk',
              'H_j':'sum_i (a_i^-2) J_i^(j)^2',
              'tridiagonal':'wbar*j*(j+1)I + (w3-wbar) J3^2 + (w1-w2)/4 (J+^2+J-^2)',
              'global_multiplicity':'Peter-Weyl spectator index d_j=2j+1'},
            'certified_symbolic_examples':examples,
            'spin_half_block':'(w1+w2+w3)/4 times I2',
            'spin_one_block_spectrum':['w2+w3','w3+w1','w1+w2'],
            'spin_one_reconstruction':'unordered (w1,w2,w3) recoverable from pairwise sums',
            'spectral_lower_bound':'H_j >= min(w1,w2,w3)*j*(j+1)*I for all j',
            'round_special_case':'a=b=c=R/2 -> first blocks 3/R^2 and 8/R^2',
            'sampling_scope':'exact blocks j=0,1/2,...,4 for four positive rational metric choices; global formulas follow algebraically',
            'source_scope':'does not regenerate Hodge or Dirac blocks or full infinite heat traces; those are source-attested links only'}
if __name__=='__main__':
 import json
 print(json.dumps(build(),indent=2))
