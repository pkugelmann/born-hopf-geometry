#!/usr/bin/env python3
"""Cumulative v1_36 manifest: exact base/extension distinction, source owner frontiers retained."""
from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parents[1]
parent=Path('/mnt/data/Paper00-S3StructureNetwork-v1_35.zip')
prev=json.loads((R/'data/v136_parent_manifest_snapshot.json').read_text())
frontier=json.loads((R/'data/v136_frontier_resolution.json').read_text())
files=[]
for p in sorted(R.rglob('*')):
 if not p.is_file() or p.name=='MANIFEST.json' or '__pycache__' in p.parts or p.suffix in ('.pyc','.zip'):
  continue
 files.append({'path':p.relative_to(R).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
M={'version':'v1_36','theme':'S3StructureNetwork','parent':'v1_35','archive_root':'Paper00-S3StructureNetwork-v1_36',
 'release_type':'cumulative_S3_mathematical_graph_with_source_scoped_current_harmonic_extension',
 'parent_archive_sha256':hashlib.sha256(parent.read_bytes()).hexdigest() if parent.exists() else None,
 'parent_manifest_version':prev['version'],'parent_manifest_files':len(prev['files']),
 'historical_data_and_graphs_mutated':False,'physical_transition_edges':0,'theorem_claim_nodes_added':0,
 'proof_dag_copied':False,'source_tex_copied':False,'previous_zip_copied':False,
 'historical_base_objects':862,'historical_base_edges':1392,'historical_base_joint_inputs':242,'historical_base_compositions':183,
 'new_effective_objects':17,'new_effective_edges':32,'new_joint_conditions':8,'new_compositions':6,
 'cumulative_objects':879,'cumulative_edges':1424,'cumulative_joint_inputs':250,'cumulative_compositions':189,
 'isolated_object_records':5,'main_connected_component':872,
 'source_scoped_map_candidates_inherited':24,'independent_conditional_map_replays_inherited':24,
 'targeted_source_owner_selection_frontiers_not_closed':3,'current_neutral_branch_scope_reclassified':'G32-056',
 'source_theorems_or_physical_occurrences_promoted':0,
 'effective_graph':'graph/mathematical_structure_network_effective_v136.graphml',
 'geometry_extension':'data/v136_math_extension.json',
 'source_owner_frontier':'data/v136_frontier_resolution.json',
 'exact_certificate':'data/v136_exact_harmonic_gp3_certificate.json',
 'source_anchors':'data/v136_current_source_anchors.json',
 'checks':['verify_exact_batch25_v136.py --check','scripts/build_batch25_v136.py --check',
 'rebuild_effective_graph_v136.py --check','verify_batch25_v136.py',
 'verify_parent_v135_integrity_v136.py','validate_geometry.py --fast','verify_graph_exports.py','verify_manifest.py'],
 'verification_summary':{
 'six_hurwitz_degree12_gram':'PASS exact',
 '163_5_1_coisometry':'PASS exact',
 'S3_character_and_Hom135':'PASS exact',
 'pre_schur_5_over_168_post_schur_163_over_168':'PASS exact; only geometric kinetic owner',
 'zonal_scalar_weights':'PASS exact; not rank trace',
 'matter_M12_M36_same_owner_heat':'PASS conditional algebra; no occurring action owner selected',
 'historical_D4_current_branch_scope':'RECLASSIFIED source-based; general E56 row scale retained',
 'GP3_generated_whole_candidate_comparison':'OPEN',
 'actual_neutral_K56_harmonic_constructor_and_physical_pole':'OPEN',
 'meson_supplied_H_sector_and_pole':'OPEN',
 'physical_action_occurrence':'NOT PROMOTED',
 'historical_full_regeneration':'NOT RUN',
 'global_semantic_exhaustiveness':'NOT CLAIMED',
 'cumulative_geometry_fast_suite':'PASS',
 'cumulative_graph_export':'PASS'},
 'files':files}
(R/'MANIFEST.json').write_text(json.dumps(M,indent=2,ensure_ascii=False)+'\n')
print('WRITE v1_36 SHA256 manifest',len(files),'files')
