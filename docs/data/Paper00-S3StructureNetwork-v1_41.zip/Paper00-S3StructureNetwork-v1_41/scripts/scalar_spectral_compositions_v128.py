#!/usr/bin/env python3
"""Exact finite-mode, Green-operator and chamber-contrast algebra.

The chamber readout coefficient R(T6) is source-attributed; only its
linear spectral evolution is independently checked here. The x/p
S³ representations are labelled factors, not identified geometric roles.
"""
import sympy as s

def build():
    r=s.symbols('r',positive=True)
    shells=[]
    for n in range(0,25):
        lam=s.Rational(n*(n+2)) / r**2
        d=(n+1)**2
        inverse=s.S(0) if n==0 else s.simplify(1/lam)
        assert n==0 or s.simplify(lam*inverse)==1
        shells.append({'n':n,'scalar_eigenvalue':str(lam),'scalar_multiplicity':d,'mean_zero_Green_eigenvalue':str(inverse)})
    for L in range(0,31):
        assert sum((k+1)**2 for k in range(L+1))==((L+1)*(L+2)*(2*L+3))//6
    # Mathematical comparison return in 5x5 chamber (a,b) coordinates.
    v=s.Matrix([4,-1,-1,-1,-1]);one=s.ones(5,1)
    Q=(s.ones(5,5)-5*s.eye(5))/4
    assert Q*v==-s.Rational(5,4)*v and Q*one==s.zeros(5,1)
    L25=s.kronecker_product(s.eye(5),Q)
    contrast=s.kronecker_product(one,v)
    C25=s.ones(25,1)
    assert L25*contrast==-s.Rational(5,4)*contrast and L25*C25==s.zeros(25,1)
    # This form of the readout is SOURCE-ATTESTED in VI-B / I-B.
    R=-s.Rational(55,2304)*C25+s.Rational(77,3072)*contrast
    assert s.simplify(sum(R)/25)==-s.Rational(55,2304)
    t=s.symbols('t',real=True)
    returned=-s.Rational(55,2304)*C25+s.exp(-s.Rational(5,4)*t)*s.Rational(77,3072)*contrast
    assert s.simplify(s.diff(returned,t)-L25*returned)==s.zeros(25,1)
    # A source dimension no-go: no coisometry R8 -> R88; keep it as a
    # NO-MORPHISM certificate and do not insert a mathematical edge.
    protected_real_dim=8
    target_complex_dim=sum(q+1 for q in range(1,9))
    assert target_complex_dim==44 and protected_real_dim<2*target_complex_dim
    return {
       'round_S3_scalar_Laplacian_nonnegative_convention':'lambda_n=n(n+2)/r², multiplicity=(n+1)²',
       'mean_zero_green':'lambda_n^{-1}=r²/[n(n+2)] for n>=1; constants removed',
       'first_25_exact_mode_eigenpairs':shells,
       'finite_p_factor_Peter_Weyl_readout':'N_L=(L+1)(L+2)(2L+3)/6 for L>=0, not a change of primitive S3_p',
       'T6_25chamber_source_attributed_input_coefficients':{'constant':'-55/2304','contrast':'77/3072','contrast_vector':[int(q) for q in v]},
       'T6_auxiliary_generator':'I_5 tensor ((J_5-5I_5)/4), on span{constant,contrast}',
       'T6_contrast_eigenvalue':'-5/4',
       'T6_return':'constant + exp(-5t/4) contrast; source-owned comparison only, not sky map',
       'prohibited_coisometry':{'source_real_dimension':8,'target_complex_dimension':44,'target_real_dimension':88,'status':'RANK_OBSTRUCTION_NO_ADMITTED_MAP'},
       'verification_scope':'exact finite spectral sums and source-attributed contrast; no unproved physical realization'
    }

if __name__=='__main__':
 import json
 x=build();print(json.dumps({'modes':len(x['first_25_exact_mode_eigenpairs']),'contrast_eigenvalue':x['T6_contrast_eigenvalue'],'coisometry':x['prohibited_coisometry']},indent=2))
