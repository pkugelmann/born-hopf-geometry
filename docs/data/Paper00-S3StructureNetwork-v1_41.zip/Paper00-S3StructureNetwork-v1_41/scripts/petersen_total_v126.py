#!/usr/bin/env python3
"""Exact 600-cell D20/Z30 shell and Petersen total-graph construction.

All vertices are generated in Q(sqrt(5)); graph edges are determined by
exact quaternionic scalar products.  No physical constructions are used.
"""
from __future__ import annotations
import sys
from pathlib import Path
from collections import Counter
from itertools import combinations
from sympy import Matrix, factor
from .exceptional_model import generate_vertices, dot16, conj


def build():
    _,I=generate_vertices()
    D=sorted(q for q in I if q[0]==(2,0))
    Z=sorted(q for q in I if q[0]==(0,0))
    assert (len(D),len(Z))==(20,30)
    verts=D+Z
    index={q:i for i,q in enumerate(verts)}
    Dset=set(D);Zset=set(Z)
    edgelist=[];neighbors={q:set() for q in verts}
    for u,v in combinations(verts,2):
        if dot16(u,v)==(4,4):
            edgelist.append((index[u],index[v])); neighbors[u].add(v);neighbors[v].add(u)
    e_dd=[(u,v) for u,v in edgelist if u<20 and v<20]
    e_zz=[(u,v) for u,v in edgelist if u>=20 and v>=20]
    e_dz=[(u,v) for u,v in edgelist if u<20<=v]
    assert len(edgelist)==150 and (len(e_dd),len(e_zz),len(e_dz))==(30,60,60)
    assert all(len(neighbors[q])==6 for q in verts)
    assert all(len(neighbors[q]&Dset)==3 for q in D)
    assert all(len(neighbors[q]&Dset)==2 for q in Z)
    assert all(len(neighbors[q]&Zset)==4 for q in Z)
    assert all((u in neighbors[v])==(bool((neighbors[u]&neighbors[v])&Dset)) for u,v in combinations(Z,2))
    # Z is exactly the graph-theoretic edge set of D; the map is a bijection.
    Dedge_to_Z={tuple(sorted(index[q] for q in neighbors[z]&Dset)):index[z] for z in Z}
    assert len(Dedge_to_Z)==30 and set(Dedge_to_Z)=={tuple(sorted(e)) for e in e_dd}

    # Inversion acts freely on D U Z, preserves the total graph, and has
    # 25 two-element orbits. The quotient must preserve each local star.
    tau=[index[conj(q)] for q in verts]
    assert all(tau[tau[i]]==i and tau[i]!=i for i in range(50))
    assert {tuple(sorted((tau[u],tau[v]))) for u,v in edgelist}==set(edgelist)
    orbits=[];seen=set()
    for i in range(50):
        if i not in seen:
            p=tuple(sorted((i,tau[i])))
            orbits.append(p);seen.update(p)
    assert len(orbits)==25
    orbits.sort(key=lambda p:(p[0]>=20,p))
    proj={i:oi for oi,orb in enumerate(orbits) for i in orb}
    eq={tuple(sorted((proj[u],proj[v]))) for u,v in edgelist}
    assert len(eq)==75 and all(u!=v for u,v in eq)
    assert all(len({proj[index[v]] for v in neighbors[q]})==6 for q in verts)
    assert Counter(tuple(sorted((proj[u],proj[v]))) for u,v in edgelist)==Counter({e:2 for e in eq})
    
    assert [sum(i in pair for pair in eq) for i in range(25)]==[6]*25
    # The twofold D quotient has the Petersen graph; the fifteen Z orbits
    # map bijectively to its edge set, and total-graph incidence is exact.
    P_edges={tuple(sorted((proj[u],proj[v]))) for u,v in e_dd}
    assert len(P_edges)==15
    Dquot=set(range(10));Zquot=set(range(10,25))
    assert all(u in Dquot and v in Dquot for u,v in P_edges)
    q_edges=set(eq)
    edgevertices={}
    for oi in Zquot:
        z=verts[orbits[oi][0]]
        ends=frozenset(proj[index[d]] for d in neighbors[z]&Dset)
        assert len(ends)==2
        edgevertices[oi]=tuple(sorted(ends))
    assert len(set(edgevertices.values()))==15 and set(edgevertices.values())==P_edges
    expected=set(P_edges)
    for oi,e in edgevertices.items():
        expected.update(tuple(sorted((oi,v))) for v in e)
    for oi,oj in combinations(Zquot,2):
        if set(edgevertices[oi])&set(edgevertices[oj]):expected.add((oi,oj))
    assert eq==expected, 'quotient is precisely the total graph of Petersen'

    # Chromatic/geometric quotient is distinguishable from the 600-cell's
    # Q8-quotient: it is an independent inversion quotient of an induced graph.
    A=Matrix.zeros(25,25)
    for u,v in eq:A[u,v]=A[v,u]=1
    import sympy as sp
    x=sp.Symbol('x')
    qpoly=factor(A.charpoly(x).as_expr())
    eQ='(x-6)*(x-1)*(x+2)**5*(x*x-3*x-2)**5*(x*x+3*x+1)**4'
    import sympy as sp
    assert sp.expand(qpoly-sp.sympify(eQ))==0
    A50=Matrix.zeros(50,50)
    for u,v in edgelist:A50[u,v]=A50[v,u]=1
    p50=factor(A50.charpoly(x).as_expr())
    e50='(x-6)*(x-1)*(x+2)**10*(x*x-3*x-2)**5*(x*x-x-3)**4*(x*x+3*x+1)**4*(x**4-2*x**3-15*x*x-4*x+4)**3'
    assert sp.expand(p50-sp.sympify(e50))==0
    # Quotient adjacency intertwiner C: A50 C = C A25, and C^T C=2 I.
    C=Matrix.zeros(50,25)
    for i in range(50): C[i,proj[i]]=1
    assert A50*C==C*A
    assert C.T*C==2*Matrix.eye(25)
    return {
      'coordinate_field':'(a+b sqrt(5))/4 with integer a,b; exact scalar-product comparison',
      'marking':'one fixed 2I embedded in the coordinate 600-cell; real-part shells relative to identity',
      'shell_D20_vertex_ids':list(range(20)),
      'shell_Z30_vertex_ids':list(range(20,50)),
      'vertices_50':[[[int(a),int(b)] for a,b in q] for q in verts],
      'edges_D20':e_dd,
      'edges_Z30':e_zz,
      'cross_edges_DZ':e_dz,
      'edges_total50':edgelist,
      'dodeca_edge_to_midpoint':[{ 'D_edge':list(edge),'Z_vertex':v} for edge,v in sorted(Dedge_to_Z.items())],
      'inversion_tau_50':tau,
      'inversion_orbits_25':[list(o) for o in orbits],
      'projection_50_to_25':[proj[i] for i in range(50)],
      'edges_petersen10':sorted(list(P_edges)),
      'quotient_edgevertex_to_petersen_edge':[{ 'quotient_vertex':i,'petersen_endpoints':list(edgevertices[i])} for i in sorted(edgevertices)],
      'edges_total_petersen25':sorted([list(e) for e in eq]),
      'total_graph_25_charpoly':str(qpoly).replace(str(x),'x'),
      'total_graph_50_charpoly':str(p50).replace(str(x),'x'),
      'certificate':{
        'induced_50_vertices':50,'induced_50_edges':150,'induced_regular_degree':6,
        'dodeca_vertices':20,'dodeca_edges':30,'midpoint_vertices':30,'midpoint_edges':60,'cross_incidence_edges':60,
        'inversion_free':True,'inversion_graph_automorphism':True,
        'quotient_vertices':25,'quotient_edges':75,'quotient_degree':6,
        'total_graph_petersen_exact':True,'regular_2fold_cover':True,
        'adjacency_intertwiner':'A50*C=C*A25, C^T C=2I25'}
    }

if __name__=='__main__':
 import json
 print(json.dumps(build()['certificate'],indent=2))
