#!/usr/bin/env python3
"""Exhaustiveness ledger of actual geometric objects and source-grounded maps.

Does not add source claims, physical objects or DAG edges to the math graph.
Optionally reconciles old source anchors against a user-provided current papers zip.
A matching TeX label is NOT a semantic mathematical verification.
"""
from __future__ import annotations
import json,re,zipfile,hashlib,argparse,pathlib,collections
import networkx as nx
ROOT=pathlib.Path(__file__).resolve().parents[1]
read=lambda x:json.loads((ROOT/'data'/x).read_text())

def build(source_zip=None):
 O=read('objects.json'); E=read('mathematical_relations.json')
 G=nx.Graph();G.add_nodes_from(x['id'] for x in O);G.add_edges_from((x['from'],x['to']) for x in E)
 comps=sorted(nx.connected_components(G),key=len,reverse=True)
 isolates=set(nx.isolates(G));root=nx.node_connected_component(G,'geo:s3')
 base=[x for x in O if not x['id'].startswith(('geo:b6:','geo:b7:','geo:b8:'))]
 downstream=[x for x in O if x['id'].startswith(('geo:b6:','geo:b7:','geo:b8:'))]
 fam=lambda n: 'later-paper-operator:'+n.split(':')[1] if n.startswith(('geo:b6:','geo:b7:','geo:b8:')) else 'foundational-S3-and-mathematical-extensions'
 open_nodes=[{'id':x['id'],'name':x['name'],'object_type':x['object_type'],
  'bucket':'SOURCE_ATTESTED_DOWNSTREAM_OPERATOR_PENDING_MATHEMATICAL_MAP' if x['id'].startswith(('geo:b6:','geo:b7:','geo:b8:'))
   else 'ISOLATED_FOUNDATIONAL_GEOMETRIC_OBJECT_PENDING_EXPLICIT_MAP',
  'witness_claim':x.get('witness',{}).get('claim_id')}
   for x in O if x['id'] in isolates]
 graph_audit={
 'version':'v1_26','method':'weak connected components on typed mathematical object-map graph; not proof dependencies',
 'counts':{'mathematical_object_records':len(O),'typed_morphism_records':len(E),'weak_components':len(comps),
           'largest_weak_component':len(comps[0]),'component_containing_s3':len(root),
           'isolated_objects':len(isolates),'isolated_foundational_or_core_records':sum(x['id'] in isolates for x in base),
           'isolated_later_operator_records':sum(x['id'] in isolates for x in downstream),
           'remaining_nontrivial_disconnected_components':sum(1 for c in comps[1:] if len(c)>1),
           'nontrivial_disconnected_sizes':sorted([len(c) for c in comps[1:] if len(c)>1],reverse=True)},
 'nontrivial_disconnected_components':[{'size':len(c),'node_ids':sorted(c)} for c in comps[1:] if len(c)>1],
 'isolate_ledger':open_nodes,
 'status':'NOT_EXHAUSTIVE: all unconnected objects require source-scoped exact map, proof of obstruction, or explicit scope exclusion',
 'source_notes':'A source label in an archive is provenance, not independent validation of the contents or of a mathematical morphism'}
 source_audit={'source_archive':'NOT_RECHECKED_IN_THIS_RUN','node_witnesses':{},'relation_witnesses':{},'counts':{}}
 if source_zip:
  with zipfile.ZipFile(source_zip) as z:
   files={f:z.read(f) for f in z.namelist() if f.endswith('.tex') and f.startswith('Paper')}
  label_catalog={}
  for f,b in files.items():
   text=b.decode('utf8',errors='replace')
   label_catalog[f]=set(re.findall(r'\\label\{([^}]+)\}',text))
  source_audit={'source_archive':pathlib.Path(source_zip).name,
                'source_archive_sha256':hashlib.sha256(pathlib.Path(source_zip).read_bytes()).hexdigest(),
                'current_tex_file_count':len(files),'current_tex_hashes':{k:hashlib.sha256(v).hexdigest() for k,v in files.items()},
                'node_witnesses':{},'relation_witnesses':{},'counts':{}}
  def check(rec):
   w=rec.get('witness')
   if not isinstance(w,dict) or not w.get('claim_id'):
    return {'status':'NO_TEX_LABEL_WITNESS_IN_GRAPH_RECORD'}
   fname=w.get('file',''); paper=re.match(r'^Paper\d+[A-Z]',fname)
   options=[f for f in files if paper and f.startswith(paper.group(0)+'-')]
   current=fname if fname in files else options[0] if len(options)==1 else None
   if current is None:return {'status':'CURRENT_SOURCE_FILE_UNAVAILABLE_OR_AMBIGUOUS','recorded_file':fname}
   label=w['claim_id'];is_found=label in label_catalog[current]
   same_hash=w.get('tex_sha256')==source_audit['current_tex_hashes'][current]
   return {'status':'EXACT_SOURCE_HASH_AND_LABEL_MATCH' if is_found and same_hash else
                   'LABEL_IN_NEW_SOURCE_VERSION_SEMANTICS_NOT_RECHECKED' if is_found else
                   'LABEL_NOT_FOUND_IN_CURRENT_SOURCE',
           'current_file':current,'source_label':label,
           'recorded_file':fname,'source_hash_same':same_hash,'current_label_found':is_found}
  for kind,records in [('node_witnesses',O),('relation_witnesses',E)]:
   report={z['id']:check(z) for z in records};source_audit[kind]=report
   source_audit['counts'][kind]=dict(collections.Counter(x['status'] for x in report.values()))
 return graph_audit,source_audit

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--sources',type=pathlib.Path,default=None);a=p.parse_args()
 graph,source=build(a.sources)
 for name,data in [('geometry_completeness_v126.json',graph),('source_anchor_refresh_v126.json',source)]:
  (ROOT/'reports'/name).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
 print('GEOMETRY COVERAGE',json.dumps(graph['counts'],indent=2))
 print('SOURCE PROVENANCE COUNTS',json.dumps(source['counts'],indent=2))
