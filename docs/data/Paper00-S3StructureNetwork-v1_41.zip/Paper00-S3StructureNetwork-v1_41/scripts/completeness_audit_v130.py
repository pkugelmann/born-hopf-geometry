#!/usr/bin/env python3
"""Only a graph-level coverage audit: no proof of semantic or relational exhaustiveness."""
import json,networkx as nx
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def rd(name):return json.loads((ROOT/'data'/name).read_text())
def build():
    O=rd('objects.json');R=rd('mathematical_relations.json');H=rd('joint_input_relations.json');C=rd('derived_compositions.json')
    G=nx.Graph();G.add_nodes_from(o['id'] for o in O);G.add_edges_from((e['from'],e['to']) for e in R)
    comps=sorted(nx.connected_components(G),key=len,reverse=True);isolates=set(nx.isolates(G))
    previous=json.loads((ROOT/'reports/geometry_completeness_v129.json').read_text())
    prev={o['id'] for o in previous['remaining_isolates']}
    owners={o['id']:o for o in O}
    remaining=[{'id':o['id'],'name':o['name'],'object_type':o['object_type'],
      'witness_claim':o.get('witness',{}).get('claim_id'),
      'bucket':'LATER_PAPER_MATHEMATICAL_OPERATOR' if o['id'].startswith(('geo:b6:','geo:b7:','geo:b8:')) else 'FOUNDATIONAL_OR_TECHNICAL_RECORD',
      'status':'UNCONNECTED_NO_ADMITTED_MATHEMATICAL_MORPHISM'} for o in O if o['id'] in isolates]
    newly=sorted(prev-isolates)
    return {'version':'v1_30','parent':'v1_29','method':'weak components of strict mathematical graph; conditional edges included as connectivity only, not proofs',
       'counts':{'mathematical_object_records':len(O),'typed_morphism_records':len(R),'joint_input_bundles':len(H),
         'derived_composition_records':len(C),'weak_components':len(comps),
         'component_containing_S3':len(nx.node_connected_component(G,'geo:s3')),
         'largest_weak_component':len(comps[0]),'isolated_objects':len(isolates),
         'isolated_foundational_or_core_records':sum(not t.startswith(('geo:b6:','geo:b7:','geo:b8:')) for t in isolates),
         'isolated_later_operator_records':sum(t.startswith(('geo:b6:','geo:b7:','geo:b8:')) for t in isolates),
         'nontrivial_disconnected_components':sum(len(c)>1 for c in comps[1:]),
         'previous_isolates_now_mathematically_linked':len(newly)},
       'newly_linked_preexisting_records':[{'id':u,'name':owners[u]['name']} for u in newly],
       'remaining_isolates':remaining,
       'deliberate_nonconnections':previous['deliberate_nonconnections'],
       'unresolved_source_semantic_scope':'All new links to mixed physical operators are restricted to mathematical suboperators; this is not source-independent certification of the full named object',
       'status':'NOT_EXHAUSTIVE: source-derived geometric object inventory and all possible relation compositions are not proven complete'}
if __name__=='__main__':
 x=build();(ROOT/'reports/geometry_completeness_v130.json').write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
 print(json.dumps(x['counts'],indent=2))
