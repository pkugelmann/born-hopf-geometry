#!/usr/bin/env python3
"""Deterministic v1_36 current-branch mathematical extension (historical base graph immutable)."""
from pathlib import Path
import json
R=Path(__file__).resolve().parents[1]
read=lambda f:json.loads((R/f).read_text())
anchors=read('data/v136_current_source_anchors.json')['anchors']
bylabel={x['label']:x for x in anchors}

def obj(tag,name,kind,label,conditional=False):
 return {'id':'geo:g36:'+tag,'name':name,'object_type':kind,'scope':'mathematical_structure_or_morphism',
         'source_kind':'source_anchored_independently_replayed_finite_mathematics','batch':'v1_36',
         'conditional':conditional,'verification':'INDEPENDENT_BATCH25_EXACT_ARITHMETIC_SOURCE_SCOPED',
         'witness':bylabel[label]}

O=[
 obj('hurwitz_boundary6','Rooted non-axial six Hurwitz half-units Ω','finite_marked_subset','p1b:thm:v2208-boundary-gram'),
 obj('harmonic12_169','Round S³ degree-12 harmonic space H12 (dim 169, Laplacian 168/R²)','finite_round_harmonic_module','p1b:thm:v2208-boundary-gram'),
 obj('regular_s3_action','Free regular projective S3 action on six boundary points','finite_group_action','p1b:proposition:atlas-native-regular-action-2b29373'),
 obj('eval12','Native harmonic evaluation E:H12→C^Ω','finite_evaluation_map','p1b:thm:v2208-boundary-gram'),
 obj('gram6','Evaluation Gram EE†=156I6+13J6, eigenvalues 234,156','positive_gram_operator','p1b:thm:v2208-boundary-gram'),
 obj('coisometry6','Canonical polar boundary coisometry B=G^(-1/2)E','partial_isometry','p1b:thm:v2208-boundary-coisometry'),
 obj('kernel163','H12 boundary restriction kernel projector Q163 (rank 163)','orthogonal_projector','p1b:thm:v2208-boundary-projectors'),
 obj('augmentation5','Five-dimensional augmentation projector Paug','orthogonal_projector','p1b:thm:v2208-boundary-projectors'),
 obj('singlet1','One-dimensional boundary singlet projector Psing','orthogonal_projector','p1b:thm:v2208-boundary-projectors'),
 obj('nonsinglet168','Complete harmonic nonsinglet projector Pns=Q163+Paug (rank 168)','orthogonal_projector','p1b:thm:v239-nonsinglet-green-schur'),
 obj('green_return','Native round K12^(-1) nonsinglet/augmentation Green Gram [[1,5/168],[5/168,5/168]]','geometric_bilinear_response','p1b:thm:v239-nonsinglet-green-schur'),
 obj('schur163','Schur-eliminated geometric residual 163/168, distinct from pre-elimination 5/168','geometric_schur_complement','p1b:thm:v239-nonsinglet-green-schur'),
 obj('rank_port_proposal','Typed 163 and 5 collective singular magnitudes (1/√163,√5,√163)','conditional_source_scoped_rank_port_math','p6:prop:v2208-collective-rank-word',True),
 obj('matter_M12_M36','Generated-factor grammar B5A=M12(C)⊕M36(C)','finite_star_algebra','p5:thm:v329-matter-factor-envelope',True),
 obj('matter_trace_firewall','Same-owner heat trace distinguishes kℓ,kC>1 matter ampliations','conditional_trace_obstruction','p3b:thm:v295-trace-owner-multiplicity-firewall',True),
 obj('zonal_scalar_h12','Normalized radial scalar U12(Re q) has boundary weights 1/39,0,38/39','finite_harmonic_function','p1b:prop:v2208-h12-scalar-control'),
 obj('s3_boundary_rep_modules','S3 representations of kernel/augmentation, 135-dimensional Hom(E163,E5)','finite_representation_decomposition','p1b:prop:v240-k56-orthogonal-green-firewall')
]
ids=[x['id'] for x in O]
assert len(set(ids))==len(ids)==17
allbase={x['id'] for x in read('data/objects.json')}
assert not set(ids)&allbase

def name(s):return 'geo:g36:'+s if not s.startswith('geo:') else s
# Exact / guarded mathematical edge only. This is NOT a claim/proof or physical occurrence graph.
raw=[
 ('geo:24cell','hurwitz_boundary6','MARKED_HURWITZ_HALFUNIT_SUBSET',1),
 ('geo:round_s3','harmonic12_169','ROUND_SCALAR_HARMONIC_EIGENSPACE',2),
 ('geo:spin4_harmonics','harmonic12_169','PETER_WEYL_DEGREE12_MODULE',2),
 ('hurwitz_boundary6','regular_s3_action','SIGNED_COORDINATE_PERMUTATION_ACTION',1),
 ('hurwitz_boundary6','eval12','EVALUATION_SUPPORT_INPUT',2),
 ('harmonic12_169','eval12','HARMONIC_EVALUATION_DOMAIN',2),
 ('eval12','gram6','SIX_POINT_REPRODUCING_KERNEL_GRAM',2),
 ('regular_s3_action','gram6','REGULAR_ACTION_INVARIANT_GRAM',4),
 ('gram6','coisometry6','UNIQUE_POSITIVE_POLAR_NORMALIZATION',3),
 ('eval12','coisometry6','POLAR_RESTRICTION_COISOMETRY',3),
 ('coisometry6','kernel163','ORTHOGONAL_RESTRICTION_KERNEL',3),
 ('coisometry6','augmentation5','BOUNDARY_MEAN_ZERO_PULLBACK',3),
 ('coisometry6','singlet1','BOUNDARY_CONSTANT_LINE_PULLBACK',3),
 ('kernel163','nonsinglet168','ORTHOGONAL_COMPLEMENT_OF_SINGLET',5),
 ('augmentation5','nonsinglet168','ORTHOGONAL_SUM_WITH_KERNEL',5),
 ('nonsinglet168','green_return','ROUND_K12_INVERSE_TRACE_CONTRACTION',5),
 ('augmentation5','green_return','GREEN_AUGMENTATION_CROSS_TERM',5),
 ('green_return','schur163','EXACT_TWO_CHANNEL_SCHUR_ELIMINATION',5),
 ('kernel163','schur163','POST_ELIMINATION_KERNEL_REMAINDER',5),
 ('kernel163','rank_port_proposal','COLLECTIVE_RANK_INVERSE_SINGULAR_VALUE',6),
 ('augmentation5','rank_port_proposal','COLLECTIVE_AUGMENTATION_SINGULAR_VALUE',6),
 ('geo:b6:e56_terminal_row_energy','rank_port_proposal','CONDITIONAL_NATIVE_E56_ROW_ENERGY_INSERTION',6),
 ('geo:b6:three_generation_carrier','matter_M12_M36','INDEPENDENT_MATTER_FACTOR_GRAMMAR',7),
 ('geo:b6:color_family_composition','matter_M12_M36','COLOR_FAMILY_ALGEBRA_COMPONENT',7),
 ('matter_M12_M36','matter_trace_firewall','ORDINARY_TRACE_AMPLIATION_TEST',7),
 ('harmonic12_169','zonal_scalar_h12','NORMALIZED_ROTATIONAL_SCALAR_HARMONIC',8),
 ('gram6','zonal_scalar_h12','EXACT_BOUNDARY_WEIGHT_DECOMPOSITION',8),
 ('singlet1','zonal_scalar_h12','BOUNDARY_SINGLET_EXPECTATION',8),
 ('regular_s3_action','s3_boundary_rep_modules','S3_CHARACTER_RESTRICTION',4),
 ('kernel163','s3_boundary_rep_modules','KERNEL_REPRESENTATION_DECOMPOSITION',4),
 ('augmentation5','s3_boundary_rep_modules','AUGMENTATION_REPRESENTATION_DECOMPOSITION',4),
 ('s3_boundary_rep_modules','rank_port_proposal','RANK_ALONE_DOES_NOT_SELECT_S3_INTERTWINER',6)
]
E=[]
for i,(fr,to,rel,guard) in enumerate(raw,1):
 a,b=name(fr),name(to)
 assert a in allbase|set(ids) and b in allbase|set(ids)
 E.append({'id':f'G36-{i:03d}','from':a,'to':b,'relation':rel,'link_type':'EXACT_FINITE_MATHEMATICAL_MAP' if guard not in (6,7) else 'SOURCE_GUARDED_MATHEMATICAL_MAP',
           'conditions_preserved':True,'verification':'INDEPENDENT_EXACT_BATCH25_WITH_STATED_SOURCE_SCOPE',
           'guard_id':f'HYP-G36-{guard:02d}','requires_joint_inputs':[],
           'physical_owner_status':'NOT_SELECTED_OR_GENERATED_BY_THIS_GEOMETRY' if guard in (6,7) else 'GEOMETRY_ONLY'})

rawguards=[
 ('Native rooted six half-Hurwitz points Ω, fixed oriented line; projective S3 is mathematical symmetry',['geo:24cell'],['hurwitz_boundary6','regular_s3_action']),
 ('Round metric with probability Haar; n=12 reproducing kernel K12=(n+1)U12; distinct six points',['harmonic12_169','hurwitz_boundary6'],['eval12','gram6']),
 ('Standard counting metric on CΩ; positive Gram; positive polar normalization not an arbitrary rescaling',['eval12','gram6'],['coisometry6','kernel163','augmentation5','singlet1']),
 ('The signed permutation S3 action on rooted nonaxial six-point port, not all SU2 rotations',['regular_s3_action','harmonic12_169'],['s3_boundary_rep_modules']),
 ('Geometric round kinetic K12=168I; unnormalized full-harmonic trace; Schur elimination only after mixed return',['nonsinglet168','augmentation5'],['green_return','schur163']),
 ('Formal End(E) ordinary unnormalized HS metric; conditional K56 action selects the harmonic owner and typed role packet (not established)',['kernel163','augmentation5'],['rank_port_proposal']),
 ('Specified factor-local full generated M12⊕M36 algebra; faithful multiplicities; same-owner *ordinary unnormalized heat trace* if occurring; no GP3 comparison asserted',['matter_M12_M36'],['matter_trace_firewall']),
 ('Normalized zonal U12(Re q) on round S3 with probability Haar metric; scalar averaging distinguished from rank trace',['harmonic12_169','gram6'],['zonal_scalar_h12'])
]
H=[]
for i,(c,inputs,outputs) in enumerate(rawguards,1):
 H.append({'id':f'HYP-G36-{i:02d}','kind':'verified_mathematical_scope_or_explicit_undischarged_owner_condition',
           'conditions':[c], 'inputs':[name(x) for x in inputs], 'outputs':[name(x) for x in outputs],
           'verification':'SOURCE_SCOPED_EXACT_BATCH25_MATH; PHYSICAL_OWNER_NOT_CERTIFIED'})

rcomp=[
 ('Native degree-12 Hurwitz six-point Gram','EE†=156 I6+13 J6; spec {234^1,156^5}',[name('eval12'),name('hurwitz_boundary6')],[name('gram6')],'Exact U12 at cube inner products and diagonal 13 coefficient.'),
 ('Harmonic coisometry and 163+5+1','BB†=I6; H12=ker B ⊕ B†1⊥ ⊕ B†C1, ranks 163+5+1',[name('gram6'),name('eval12')],[name('kernel163'),name('augmentation5'),name('singlet1')],'G positive; B=G^-1/2 E; rank E=6 and dim H12=169.'),
 ('Nonsinglet kinetic Schur response','Tr(Pns K^-1 Paug)=5/168; residual 163/168',[name('nonsinglet168'),name('augmentation5')],[name('green_return'),name('schur163')],'K12=168I, Pns=Q+Paug; trace projectors.'),
 ('Zonal radial scalar boundary weights','(sing,aug,ker)=(1/39,0,38/39); norm commutator²=76/1521',[name('zonal_scalar_h12'),name('gram6')],[name('zonal_scalar_h12')],'Normalized Chebyshev U12 has all six boundary evaluations equal 1.'),
 ('Regular S3 character and kernel/augmentation','H12=1⊕28 Reg; ker B=1⊕27 Reg; dim HomS3(ker B,E5)=135',[name('regular_s3_action'),name('kernel163'),name('augmentation5')],[name('s3_boundary_rep_modules')],'Character of full harmonics (169,1,1), remove visible regular.'),
 ('Matter multiplicity vs scalar heat','Tr_H e^-tD²= kℓ h12(t)+kC h36(t)>h12+h36 if some k>1',[name('matter_M12_M36')],[name('matter_trace_firewall')],'Tensor-product ordinary heat trace; conditional common owner/profile and scalar port occurrence.')
]
C=[]
for i,(n,f,inputs,outs,proof) in enumerate(rcomp,1):
 C.append({'id':f'D36-{i:02d}','name':n,'formula':f,'inputs':inputs,'outputs':outs,'hypotheses':['Source-scoped finite mathematical owner; not an observed mass or generated occurrence.'],'proof':proof,'verification':'EXACT_BATCH25_CHECKED','physical_observable_claim':False})

F={'release':'v1_36','basis':'Paper00-PapersMinimal-v3_029(1).zip','math_extension_objects':len(O),'math_extension_edges':len(E), 'math_extension_guards':len(H),'math_extension_compositions':len(C),
   'current_geometry':'The 169→6 harmonic evaluation has exact positive Gram 156I+13J, orthogonal 163+5+1 and pre-elimination Green cross 5/168.',
   'historical_branch':'G32-056 is an exact source-scoped D4 inverse/direct/Gram response replay; its three-role word is historical on the new harmonic-rank K56 proposal and cannot select that branch’s neutral mass word.',
   'general_E56':'The E56 row-energy insertion remains valid as a conditional typed general scale; not replaced by the 163+5+1 geometric ranks.',
   'three_selection_frontiers':[
    {'legacy':'G32-052','status':'STILL_OPEN','needed':'Complete generated GP3 whole-candidate comparison for the M12⊕M36 representation; action occurrence and frozen trace ports.'},
    {'legacy':'G32-056','status':'RECLASSIFIED_HISTORICAL_D4_BRANCH','needed':'For the current harmonic proposal, prove K56 actual action consumes full 169→6 source/Green packet and where the 5D Schur elimination occurs; physical role/pole bridge remains separate.'},
    {'legacy':'G32-072','status':'STILL_OPEN','needed':'Actual same-owner QCD H_L with verified reducing JPC/flavor sectors and computed pole matrix.'}],
   'physical_theorems_promoted':0,'actual_K56_owner_selected':False,'GP3_multiplicity_unconditionally_closed':False,
   'source_anchors':'data/v136_current_source_anchors.json',
   'source_warning':'Source-derived mathematical identities verified here; choice of occurring action and spectra not derived.'}

files={'data/v136_math_extension.json':{'objects':O,'relations':E,'joint_conditions':H,'compositions':C},'data/v136_frontier_resolution.json':F}
import argparse
p=argparse.ArgumentParser();p.add_argument('--check',action='store_true'); a=p.parse_args()
for dest,payload in files.items():
 path=R/dest;text=json.dumps(payload,indent=2,ensure_ascii=False,sort_keys=True)+'\n'
 if a.check:assert path.read_text()==text,dest
 else:path.write_text(text)
 print(('CHECK' if a.check else 'WRITE'),dest,[(k,len(v)) for k,v in payload.items()] if dest.endswith('extension.json') else 'frontier')
