#!/usr/bin/env python3
"""Instance-level GraphML for the new *mathematical matrices*, not source edges."""
import pathlib,json,networkx as nx
from fractions import Fraction
ROOT=pathlib.Path(__file__).resolve().parents[1]
d=json.loads((ROOT/'data/finite_invariant_geometry_v130_instance.json').read_text())
M=[[Fraction(x) for x in row] for row in d['petersen']['matrix_H_sqrt5D_15x15']]
G=nx.Graph()
block={i:int(k) for k,v in d['petersen']['core_triplets'].items() for i in v}
for i in range(15):G.add_node(str(i),core=block[i],basis=f'Petersen-edge-{i}')
for i in range(15):
 for j in range(i,15):
  if M[i][j]:G.add_edge(str(i),str(j),scaled_mirror_weight=str(M[i][j]))
assert G.number_of_nodes()==15
nx.write_graphml(G,ROOT/'graph/batch19_petersen_mirror_H15.graphml')
S=[[Fraction(x) for x in row] for row in d['su3']['matrix_meson_singlet_projector_9x9']]
Q=nx.Graph()
for i in range(9):Q.add_node(str(i),fundamental=i//3,antifundamental=i%3)
for i in range(9):
 for j in range(i,9):
  if S[i][j]:Q.add_edge(str(i),str(j),singlet_weight=str(S[i][j]))
assert Q.number_of_edges()==6
nx.write_graphml(Q,ROOT/'graph/batch19_su3_identity_singlet_P9.graphml')
print('PASS: exported exact 15-edge Petersen operator and SU3 rank-one tensor projector GraphML')
