#!/usr/bin/env python3
"""Exact geometry-only S3->SU3 and finite invariant algebra, Haar, and path examples.

No full gauge dynamics, QCD, or measured observables are constructed.
"""
from __future__ import annotations
import sympy as s
from sympy.polys.matrices import DomainMatrix

def E(i,j,n=3):
    a=s.zeros(n);a[i,j]=1;return a

def mstr(A):
    return [[str(v) for v in row] for row in A.tolist()]

def build():
    i=s.I
    I3=s.eye(3);I9=s.eye(9)
    sigma1=E(0,1,2)+E(1,0,2)
    sigma2=-i*E(0,1,2)+i*E(1,0,2)
    sigma3=E(0,0,2)-E(1,1,2)
    Q=[s.diag(-i*sig, s.zeros(1)) for sig in (sigma1,sigma2,sigma3)]
    for idx in range(3):
        a=Q[idx];b=Q[(idx+1)%3];c=Q[(idx+2)%3]
        assert a.H==-a and s.trace(a)==0
        assert a*b-b*a==2*c
    # Quaternion Maurer--Cartan: d(theta_i)=-2 theta_j wedge theta_k,
    # theta wedge theta carries +[q_j,q_k]=+2 q_i, so curvature vanishes.
    for k in range(3):
        j=(k+1)%3; l=(k+2)%3
        assert -2*Q[k]+(Q[j]*Q[l]-Q[l]*Q[j])==s.zeros(3)
    trprod=s.trace(Q[0]*Q[1]*Q[2]); assert trprod==-2
    trace_theta_cube=6*trprod; assert trace_theta_cube==-12
    # Conventional orientation: -(24 pi^2)^-1 Tr(theta^3) = vol_S3/(2 pi^2).
    # a(t)^3 spatial scaling yields a(t)^-3 Hodge-dual density as a pure form identity.
    a,Qcharge=s.symbols('a Q', positive=True, real=True)
    assert s.simplify(Qcharge/(2*s.pi**2*a**3)*a**3-Qcharge/(2*s.pi**2))==0
    # The chosen SU2 fundamental is the upper-left 2x2 block of SU3 (3 -> 2+1).
    T=[(E(0,1)+E(1,0))/2,
       (E(0,1)-E(1,0))/(2*i),
       (E(0,0)-E(1,1))/2,
       (E(0,2)+E(2,0))/2,
       (E(0,2)-E(2,0))/(2*i),
       (E(1,2)+E(2,1))/2,
       (E(1,2)-E(2,1))/(2*i),
       (E(0,0)+E(1,1)-2*E(2,2))/(2*s.sqrt(3))]
    for u in T:
        assert u.H==u and s.trace(u)==0
    # Matrices for conjugation representation V=C3 tensor C3* of dimension nine.
    generators=[s.kronecker_product(t,I3)-s.kronecker_product(I3,t.T) for t in T]
    v=s.zeros(9,1)
    for k in range(3):v[4*k]=1
    P=v*v.T/3;R=I9-P
    assert P*P==P and P.H==P and s.trace(P)==1
    assert all(g*v==s.zeros(9,1) for g in generators)
    C=sum((g*g for g in generators),s.zeros(9))
    assert s.simplify(C-3*R)==s.zeros(9)
    assert s.trace(C)==24
    # Centralizer of the explicitly generated sl3 action: 2-dimensional span{P1,P8}.
    basis=[E(0,1),E(1,0),E(1,2),E(2,1),E(0,0)-E(1,1),E(1,1)-E(2,2)]
    L=[s.kronecker_product(t,I3)-s.kronecker_product(I3,t.T) for t in basis]
    rows=[]
    for A in L:
        for p in range(9):
            for q in range(9):
                coeff={}
                for k in range(9):
                    if A[k,q]:coeff[9*p+k]=coeff.get(9*p+k,0)+A[k,q]
                    if A[p,k]:coeff[9*k+q]=coeff.get(9*k+q,0)-A[p,k]
                coeff={k:v for k,v in coeff.items() if v}
                if coeff:rows.append(coeff)
    Z=s.MutableSparseMatrix(len(rows),81,{(r,c):v for r,row in enumerate(rows) for c,v in row.items()})
    cent_rank=DomainMatrix.from_Matrix(Z).convert_to(s.QQ).rank()
    assert cent_rank==79
    assert all(P*A==A*P for A in L)
    # The adjoint complement is an irreducible sl3 module (sl3 simple). By Burnside
    # the associative algebra generated in this representation is C*P1 + M8*P8.
    # Finite two-vertex tensor: local SU3 x SU3 average is P1 tensor P1.
    P2=s.kronecker_product(P,P)
    T3=s.kronecker_product(P,R)+s.kronecker_product(R,P)
    T6=s.kronecker_product(R,R)
    I81=s.eye(81)
    assert P2+T3+T6==I81
    for b,r in [(P2,1),(T3,16),(T6,64)]:
        assert b*b==b and s.trace(b)==r
    Ctot=s.kronecker_product(C,I9)+s.kronecker_product(I9,C)
    assert Ctot==3*T3+6*T6
    z,w=s.symbols('z w',real=True)
    H=P+z*R;H2=P+w*R
    assert s.simplify(H*H2-(P+z*w*R))==s.zeros(9)
    assert P*H==P
    # Embedded SU3 holonomies on an explicit graph, including inverses and gauge changes.
    A=s.Matrix([[0,-1,0],[1,0,0],[0,0,1]])
    B=s.Matrix([[1,0,0],[0,0,-1],[0,1,0]])
    F=s.Matrix([[0,0,1],[0,1,0],[-1,0,0]])
    for M in (A,B,F):assert M.T*M==I3 and M.det()==1
    fine=[A,B,F]
    coarsened=B*A
    total=F*B*A
    gauges=[A,B,F,A]
    # Endpoint gauge: U_{p->q}'=g_q U_{p->q} g_p^{-1}, product is natural.
    transformed=[gauges[k+1]*fine[k]*gauges[k].inv() for k in range(3)]
    assert transformed[1]*transformed[0]==gauges[2]*coarsened*gauges[0].inv()
    assert transformed[2]*transformed[1]*transformed[0]==gauges[3]*total*gauges[0].inv()
    assert (B*A).inv()==A.inv()*B.inv()
    # Noncommuting sample emphasizes that coarse holonomy is ORDERED.
    assert B*A!=A*B
    # A loop with gauge g0=g3 transforms holonomy by conjugation.
    assert s.trace(transformed[2]*transformed[1]*transformed[0])==s.trace(total)
    return {
      'schema':'v1_31_exact_S3_SU3_marked_group_inclusion_finite_Haar_Gauss_path_geometry',
      'mathematical_scope':'chosen SU2-in-SU3 embedding; finite tensor examples only; no full QCD or physical action',
      'su2_su3_embedding':{'quaternion_i_j_k_su3_3x3':list(map(mstr,Q)),
         'commutator':'[qi,qj]=2 epsilon_ijk qk',
         'trace_of_qi_qj_qk_in_positive_order':str(trprod),
         'trace_theta_cubed_on_positively_oriented_Maurer_frame':str(trace_theta_cube),
         'cartan_3form_convention':'-Tr(g^-1 dg)^3/(24*pi^2)',
         'pullback_to_S3':'vol_round_S3/(2*pi^2)',
         'normalized_integral':1,'SU3_fundamental_restriction':'C3 | SU2 = C2 + C1',
         'flat_connection':'g^-1 dg, F=dA + A wedge A = 0 (Maurer-Cartan)'},
      'SU3_tensor':{'dimension':9,'identity_singlet_projector_9x9':mstr(P),
         'adjoint_complement_projector_9x9':mstr(R),
         'adjoint_quadratic_casimir_9x9':mstr(C),
         'casimir_spectrum':{'0':1,'3':8},
         'centralizer_linear_constraints':len(rows),'centralizer_rank_over_Q':cent_rank,
         'centralizer_dimension':81-cent_rank,
         'generated_star_algebra_dimension':65,'commutant_dimension':2,
         'wedderburn_example':'C * P1 direct_sum M8(C) * P8',
         'central_heat_semigroup':'H_t=P1+exp(-3t)*P8, on 1 plus adjoint finite module only'},
      'two_vertex_example':{'dimensions':81,'vertexwise_gauge_group':'SU3 x SU3',
          'orthogonal_projector_rank':1,'orthogonal_projector':'P1 tensor P1',
          'casimir_eigenvalue_multiplicity':{'0':1,'3':16,'6':64},
          'two_vertex_gauge_invariant_evolution_example':'H=alpha*I+beta*C_total preserves Ran(P1 tensor P1)'},
      'path_groupoid_sample':{'fine_holonomies':list(map(mstr,fine)),
        'coarse_e01_e12':mstr(coarsened), 'coarse_three_step':mstr(total),
        'gauge_naturality_verified':True,'inverse_path_verified':True,
        'composition_order_is_noncommutative':True,'trace_of_loop_gauge_invariant':True},
      'flrw_hodge_math':{'spatial_h':'a(t)^2*g_round',
       'vol_h':'a(t)^3 vol_round',
       'normalized_3form':'Omega=vol_round/(2*pi^2)',
       'fixed_charge_density':'Q/(2*pi^2*a(t)^3)',
       'physical_dust_identification':'NOT_ASSERTED'}
    }

if __name__=='__main__':
    import json
    print(json.dumps(build(),indent=2)[:1600]);print('PASS v1_31 exact independent group/linear algebra tests')
