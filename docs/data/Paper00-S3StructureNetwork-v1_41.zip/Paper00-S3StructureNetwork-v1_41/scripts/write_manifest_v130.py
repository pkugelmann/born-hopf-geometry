#!/usr/bin/env python3
"""Write self-contained SHA256 manifest for v1_30."""
import json,hashlib,pathlib
R=pathlib.Path(__file__).resolve().parents[1]
c=json.loads((R/'data/v130_release_counts.json').read_text())
cover=json.loads((R/'reports/geometry_completeness_v130.json').read_text())['counts']
parent=pathlib.Path('/mnt/data/Paper00-S3StructureNetwork-v1_29.zip')
files=[]
for p in sorted(R.rglob('*')):
 if not p.is_file() or p.name=='MANIFEST.json' or '__pycache__' in p.parts or p.suffix in ('.pyc','.zip'):continue
 files.append({'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
m={'version':'v1_30','parent':'v1_29','theme':'S3StructureNetwork','archive_root':'Paper00-S3StructureNetwork-v1_30',
 'release_type':'cumulative_pure_geometric_object_and_typed_relation_network',
 'parent_archive_sha256':hashlib.sha256(parent.read_bytes()).hexdigest() if parent.exists() else 'unavailable',
 'proof_dag_copied':False,'statement_locator_nodes':0,'physical_transition_edges':0,
 'batch_scope':'exact Petersen 15-edge support-compression and average-squared spectral invariants; conditional abstract SU3 tensor, singlet, determinant and Casimir representation geometry; separate generic Gram model',
 'new_objects':c['new_objects'],'new_typed_relations':c['new_typed_relations'],
 'new_joint_inputs':c['new_joint_inputs'],'new_derived_compositions':c['new_compositions'],
 'cumulative_objects':c['cumulative_objects'],'cumulative_edges':c['cumulative_edges'],
 'cumulative_joint_inputs':c['cumulative_joint_inputs'],'cumulative_compositions':c['cumulative_compositions'],
 'isolated_object_records':cover['isolated_objects'], 'main_connected_component':cover['component_containing_S3'],
 'nontrivial_disconnected_components_outside_core':cover['nontrivial_disconnected_components'],
 'linked_exact_suboperators':cover['newly_linked_direct_exact_Petersen'],
 'linked_guarded_partial_interfaces':cover['newly_linked_only_guarded_finite_math_interface'],
 'verification_summary':{'batch19_exact':'PASS: 32 Petersen characteristic polynomials; new 6-class average squares; SU3 Fierz, normalized singlet and determinant; all finite Gram eigenvalues',
 'graph_exports':'PASS: JSON-GraphML exact parity, focused math object graph and instance operators',
 'source_witnesses':'12 labels/hashes in current Paper00-PapersMinimal-v3_028 TeX; not copied as nodes',
 'cumulative_fast':'PASS', 'historical_full_regeneration':'NOT_RUN_THIS_BATCH'},
 'files':files}
(R/'MANIFEST.json').write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n')
print('manifest written',len(files),'files')
