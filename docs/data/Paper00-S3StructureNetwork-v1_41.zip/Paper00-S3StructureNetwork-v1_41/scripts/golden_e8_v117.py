#!/usr/bin/env python3
"""Regenerate the *mathematical* golden E8 root system, D4+D4 triality
and E7/E6 sections from the prior marked 2I quaternion bank.
All calculations are exact integers. A vertex (a+b phi)/2 becomes
(a,b) in ordered Clifford coefficient coordinates, with phi^2=phi+1.
No physical or theorem-DAG nodes occur in the output.
"""
from __future__ import annotations
import collections,itertools,sys
from . import exceptional_model as ex
C=collections.Counter

def dot(a,b):return sum(x*y for x,y in zip(a,b))
def vecplus(a,b):return tuple(x+y for x,y in zip(a,b))
def vecminus(a,b):return tuple(x-y for x,y in zip(a,b))
def vecneg(a):return tuple(-x for x in a)
def iota(q):
 a=[];b=[]
 for x,y in q:
  assert (x-y)%2==0
  a.append((x-y)//2);b.append(y)
 return tuple(a+b)
def golden(q):
 r=iota(q)
 return tuple(r[k+4] for k in range(4))+tuple(r[k]+r[k+4] for k in range(4))
def reflect(x,a):
 t=dot(x,a);assert t%2==0
 return tuple(x[i]-(t//2)*a[i] for i in range(8))
def orbit(seed,roots):
 seen={seed};todo=[seed]
 while todo:
  p=todo.pop()
  for a in roots:
   t=reflect(p,a)
   if t not in seen:seen.add(t);todo.append(t)
 return seen

def rrank(a,p=101):
 a=[[x%p for x in row] for row in a];r=0
 for c in range(len(a[0])):
  k=next((i for i in range(r,len(a)) if a[i][c]),None)
  if k is None:continue
  a[r],a[k]=a[k],a[r];inv=pow(a[r][c],-1,p)
  a[r][c:]=[(t*inv)%p for t in a[r][c:]]
  for i in range(r+1,len(a)):
   v=a[i][c]
   if v:a[i][c:]=[(x-v*y)%p for x,y in zip(a[i][c:],a[r][c:])]
  r+=1
 return r

def sector_pair(a,b,sector_sets):
 c=({0,1,2}-{a,b}).pop();A=sorted(sector_sets[a]);B=sorted(sector_sets[b]);Z=sector_sets[c]
 wA0=sorted({r[:4] for r in A});wB0=sorted({r[:4] for r in B});wZ0={r[:4] for r in Z}
 wA1=sorted({r[4:] for r in A});wB1=sorted({r[4:] for r in B});wZ1={r[4:] for r in Z}
 def factor(U,V,W):return [[int(vecneg(vecplus(u,v)) in W) for v in V] for u in U]
 B0=factor(wA0,wB0,wZ0);B1=factor(wA1,wB1,wZ1)
 assert all(sum(row)==4 for row in B0+B1)
 def gram(B):return [[sum(B[i][k]*B[j][k] for k in range(8)) for j in range(8)] for i in range(8)]
 gr0=gram(B0);gr1=gram(B1)
 for gr in (gr0,gr1):
  assert all(gr[i][i]==4 for i in range(8))
  assert all(sorted(gr[i])==[0]+[2]*6+[4] for i in range(8))
  assert all(sum(gr[i][j]==0 for j in range(8))==1 for i in range(8))
 pair_to_value={(u,v):int(vecneg(vecplus(u,v)) in Z) for u in A for v in B}
 edges=[[i,j] for i,u in enumerate(A) for j,v in enumerate(B) if pair_to_value[u,v]]
 assert len(edges)==1024
 assert all(sum(pair_to_value[u,v] for v in B)==16 for u in A)
 assert all(sum(pair_to_value[u,v] for u in A)==16 for v in B)
 for u in A:
  for v in B:
   assert pair_to_value[u,v]==B0[wA0.index(u[:4])][wB0.index(v[:4])]*B1[wA1.index(u[4:])][wB1.index(v[4:])]
 # Each Gram factor has eigenvalues 16^1,4^4,0^3; the Kronecker Gram yields 256^1,64^8,16^16,0^39.
 return {'pair':[a,b],'third_sector':c,'edge_count':1024,'degree_each_side':16,
         'left_8x8_weight_compatibility':B0,'right_8x8_weight_compatibility':B1,
         'two_weight_Gram_matrix':gr0,'two_weight_Gram_matrix_right':gr1,
         'Kronecker_singular_value_multiplicities':{'16':1,'8':8,'4':16,'0':39},
         'Kronecker_rank':25,'bipartite_edges_local_indices':edges}

def section_e6(Phi8, D1):
 E7=sorted(r for r in Phi8 if r[0]==0)
 E6=sorted(r for r in E7 if r[1]+r[2]+r[3]==0)
 assert (len(E7),len(E6))==(126,72)
 assert (rrank(E7),rrank(E6))==(7,6)
 for a in E7:
  for b in E7:assert reflect(b,a) in E7
 for a in E6:
  for b in E6:assert reflect(b,a) in E6
 A2=sorted(r for r in Phi8 if all(dot(r,s)==0 for s in E6))
 assert len(A2)==6
 normal=collections.defaultdict(list)
 for r in Phi8:normal[(r[0],r[1]+r[2]+r[3])].append(r)
 assert len(normal[(0,0)])==72
 normal27={k:v for k,v in normal.items() if len(v)==27}
 assert len(normal27)==6 and len([k for k,v in normal.items() if len(v)==1])==6
 def project3(r):
  s=sum(r[1:4])
  return (0,)+tuple(3*x-s for x in r[1:4])+tuple(3*x for x in r[4:])
 fibers=[]
 for key,rows in sorted(normal27.items()):
  W={project3(r) for r in rows};assert len(W)==27
  parts=[];remaining=set(W)
  while remaining:
   piece=orbit(min(remaining),D1)
   assert piece<=remaining
   remaining-=piece;parts.append(piece)
  parts.sort(key=lambda p:(len(p),min(p)))
  assert sorted(map(len,parts))==[1,1,1,8,8,8]
  labels={w:i for i,piece in enumerate(parts) for w in piece}
  triples=[];classes=C()
  for u,v,w in itertools.combinations(sorted(W),3):
   if all(u[i]+v[i]+w[i]==0 for i in range(8)):
    triples.append([list(u),list(v),list(w)])
    classes[','.join(map(str,sorted((labels[u],labels[v],labels[w]))))]+=1
  assert len(triples)==45
  assert sorted(classes.values())==[1,4,4,4,32]
  vdegree=C(tuple(v) for tri in triples for v in tri)
  assert set(vdegree.values())=={5}
  fibers.append({'A2_normal_pair':list(key),'weights_projected_int_x3':[list(w) for w in sorted(W)],
                 'D1_Weyl_orbits':[[list(w) for w in sorted(p)] for p in parts],
                 'triple_support':triples,'triple_class_counts':dict(classes)})
 return {'E7_roots':[list(r) for r in E7],'E6_roots':[list(r) for r in E6],
         'A2_perpendicular_roots':[list(r) for r in A2],
         'six_27weight_fibers':fibers,'normal_class_histogram':{str(k):len(v) for k,v in sorted(normal.items())}}

def build():
 H,I=ex.generate_vertices()
 D0={iota(q) for q in H};D1={golden(q) for q in H}
 A0={iota(q) for q in I};A1={golden(q) for q in I}
 Phi8=A0|A1
 assert (len(D0),len(D1),len(A0),len(A1),len(Phi8))==(24,24,120,120,240)
 assert D0.isdisjoint(D1) and len({dot(a,b) for a in D0 for b in D1})==1
 assert {dot(a,b) for a in D0 for b in D1}=={0}
 assert all(dot(a,a)==4 for a in Phi8)
 assert rrank(list(Phi8))==8
 parity={tuple(x%2 for x in r) for r in Phi8}
 parity.add((0,)*8)
 # The all-one parity is a lattice-code word, but no norm-two root has it.
 parity.add((1,)*8)
 assert len(parity)==16 and C(sum(t) for t in parity)==C({0:1,4:14,8:1})
 for r in Phi8:
  for a in Phi8:
   assert dot(r,a)%2==0
 # Enough to check all root reflections in the E8 root set (57k exact dot products)
 for a in Phi8:
  for r in Phi8:assert reflect(r,a) in Phi8
 X=Phi8-D0-D1
 sectors=[];remaining=set(X)
 while remaining:
  group=orbit(min(remaining),D0|D1)
  assert group<=remaining
  remaining-=group;sectors.append(group)
 sectors.sort(key=min)
 assert list(map(len,sectors))==[64,64,64]
 for O in sectors:
  assert len(O&A0)==len(O&A1)==32
  p0={r[:4] for r in O};p1={r[4:] for r in O}
  assert (len(p0),len(p1))==(8,8) and len(O)==len(p0)*len(p1)
 labels={r:('D0' if r in D0 else 'D1' if r in D1 else 'X'+str(next(i for i,o in enumerate(sectors) if r in o))) for r in Phi8}
 roots=sorted(Phi8);ind={r:i for i,r in enumerate(roots)}
 tri=[];counts=C();vertexcounts=C()
 for i,r in enumerate(roots):
  for j in range(i+1,len(roots)):
   s=roots[j];k=ind.get(vecneg(vecplus(r,s)))
   if k is None or k<=j:continue
   tri.append([i,j,k]);counts[','.join(sorted((labels[r],labels[s],labels[roots[k]])))]+=1
   vertexcounts.update((i,j,k))
 assert len(tri)==2240
 assert all(vertexcounts[i]==28 for i in range(240))
 assert counts['D0,D0,D0']==counts['D1,D1,D1']==32
 assert counts['X0,X1,X2']==1024
 assert all(counts[f'D{d},X{a},X{a}']==192 for d in range(2) for a in range(3))
 assert sum(counts.values())==2240 and len(counts)==9
 cross_pairs=[sector_pair(a,b,sectors) for a,b in itertools.combinations(range(3),2)]
 # 2-section compatibility graph has no spurious triangles: each 3-clique
 # is one unique zero-sum root triple, and each of its edges occurs once.
 et={tuple(q['pair']):set(map(tuple,q['bipartite_edges_local_indices'])) for q in cross_pairs}
 triangles_2section=sum((a,c) in et[(0,2)] and (b,c) in et[(1,2)]
                        for a,b in et[(0,1)] for c in range(64))
 assert triangles_2section==1024
 # E8 root graph (an edge from r to s when -r-s is a root) is 56 regular.
 edges=[[i,j] for i,r in enumerate(roots) for j in range(i+1,240) if vecneg(vecplus(r,roots[j])) in Phi8]
 assert len(edges)==6720 and all(C(i for e in edges for i in e)[i]==56 for i in range(240))
 section=section_e6(Phi8,D1)
 # Native 600-cell adjacency four-color resolution, using the ordinary 120 sheet.
 classes={q:('H' if q in H else 'X'+str(next(i for i,o in enumerate(sectors) if iota(q) in o))) for q in I}
 names=['H','X0','X1','X2'];rows=[]
 for cls in names:
  tuples={tuple(sum(classes[v]==other for v in I if v!=u and ex.dot16(u,v)==(4,4)) for other in names) for u in I if classes[u]==cls}
  assert len(tuples)==1
  rows.append(list(next(iter(tuples))))
 assert rows==[[0,4,4,4]]+[[3,3,3,3]]*3
 # The left H action on the three 32-vertex sectors is a cyclic C3 action.
 sector_vertices=[{q for q in I if classes[q]=='X'+str(a)} for a in range(3)]
 actions={}
 for h in H:
  images=[]
  for a in range(3):
   target={ex.qmul(h,q) for q in sector_vertices[a]}
   images.append(next(b for b in range(3) if target==sector_vertices[b]))
  actions[h]=tuple(images)
 assert len(set(actions.values()))==3
 kernel=sorted(h for h,a in actions.items() if a==(0,1,2))
 assert len(kernel)==8
 # The C3 contrasts are *zero* adjacency modes, not geometric eigenvectors with a chosen phase.
 color_vectors=[{q:int(classes[q]==f'X{a}') for q in I} for a in range(3)]
 for a in (1,2):
  contrast={q:color_vectors[0][q]-color_vectors[a][q] for q in I}
  assert all(sum(contrast[v] for v in I if v!=u and ex.dot16(u,v)==(4,4))==0 for u in I)
 return {'schema':'golden_E8_D4_triality_exact_int_v117',
         'coordinate_convention':'quaternion coordinates (a+b sqrt5)/4 -> ((a-b)/2,b) where physical coefficient is (a0+b0 phi)/2; 8-vector is doubled Clifford coefficient (a0,b0)',
         'norm_convention':'root vector represented by integer r has r.r=4, bilinear E8 Cartan form B(r,s)=r.s/2',
         'roots_240':[{'id':i,'coordinates_doubled':list(r),'sheet':0 if r in A0 else 1,'family':labels[r]} for i,r in enumerate(roots)],
         'D0':[[int(x) for x in r] for r in sorted(D0)],'D1':[[int(x) for x in r] for r in sorted(D1)],
         'three_X64':[[ind[r] for r in sorted(O)] for O in sectors],
         'root_addition_2240_triples':tri,'root_addition_6720_graph_edges':edges,
         'root_triple_class_counts':dict(sorted(counts.items())),
         'parity_code_16_words':[[int(x) for x in r] for r in sorted(parity)],
         'triality_cross_sector_pairs':cross_pairs,
         'E7_E6_A2_sections':section,
         'ordinary_600cell_24_plus_3x32':{'class_sizes':[24,32,32,32], 'labels':names,
                                            'equitable_nearest_neighbor_Q':rows,
                                            'quotient_eigenvalues':[12,-3,0,0],
                                            'H_action_image_order':3, 'H_action_kernel_size':len(kernel)},
         'exact_invariants':{'rank_root_system':8,'root_count':240,'internal_D4_count':2,
                             'tripartite_orbit_count':3,'triality_root_orbit_size':64,
                             'root_addition_triples':2240,'root_addition_graph_degree':56,
                             'cross_triality_triples':1024,'triality_2section_triangles':triangles_2section,
                             'triality_2section_edges':3072,'triality_2section_degree':32,
                             'cross_sector_compatibility_rank':25,
                             'cross_sector_compatibility_singular_values':{'16':1,'8':8,'4':16,'0':39},
                             'E7_roots':126,'E6_roots':72,'E6_A2_perpendicular_roots':6,
                             'E6_27weight_fibers':6,'E6_cubic_support_triples_per_fiber':45}}
if __name__=='__main__':
 import json
 out=build()
 print(json.dumps(out['exact_invariants'],indent=2))
