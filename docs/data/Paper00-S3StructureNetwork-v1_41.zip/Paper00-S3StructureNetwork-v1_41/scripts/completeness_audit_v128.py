#!/usr/bin/env python3
"""Strict v1_28 geometry-only connectivity and scoped exclusions audit.

Connectivity never entails a theorem. Isolates can be deliberate no-go
objects, missing genuine morphisms, or outside the target geometric scope.
"""
import pathlib,json,collections,networkx as nx
ROOT=pathlib.Path(__file__).resolve().parents[1]
def rd(f):return json.loads((ROOT/'data'/f).read_text())
def build():
 O=rd('objects.json');E=rd('mathematical_relations.json');G=nx.Graph();G.add_nodes_from(o['id'] for o in O);G.add_edges_from((e['from'],e['to']) for e in E)
 components=sorted(nx.connected_components(G),key=len,reverse=True);isolates=set(nx.isolates(G))
 records=[]
 for o in O:
  if o['id'] not in isolates:continue
  later=o['id'].startswith(('geo:b6:','geo:b7:','geo:b8:'))
  records.append({'id':o['id'],'name':o['name'],'object_type':o['object_type'],
     'witness_claim':o.get('witness',{}).get('claim_id'),
     'bucket':'LATER_PAPER_MATHEMATICAL_OPERATOR' if later else 'FOUNDATIONAL_OR_TECHNICAL_RECORD',
     'status':'UNCONNECTED_NO_ADMITTED_MATHEMATICAL_MORPHISM'})
 excluded=[
  {'id':'geo:s1_root','reason':'Distinct constitutional abelian root; identifying with Hopf fibre just to connect it would be wrong','policy':'KEEP_DISTINCT'},
  {'id':'geo:quantum_free_dispersion','reason':'Positive-frequency one-particle Hamiltonian requires a selected local free dynamical domain beyond a bare geometric Laplacian','policy':'NO_PHYSICAL_PROMOTION'},
  {'id':'geo:quantum_auxiliary_pair_poles','reason':'Auxiliary two-core spectral pole polynomial is not automatically a source-visible physical pole','policy':'AUXILIARY_ONLY'},
  {'id':'geo:b6:hopf_coisometry_obstruction','reason':'No coisometry R^8 onto C^44 exists by rank 8 < 88; nonexistence does not give a directed morphism','policy':'PROVED_NO_GO_NO_SPURIOUS_LINK'}]
 assert all(x['id'] in isolates for x in excluded)
 counts={'mathematical_object_records':len(O),'typed_morphism_records':len(E),
   'joint_input_bundles':len(rd('joint_input_relations.json')),'derived_composition_records':len(rd('derived_compositions.json')),
   'weak_components':len(components),'component_containing_S3':len(nx.node_connected_component(G,'geo:s3')),
   'largest_weak_component':len(components[0]),'isolated_objects':len(isolates),
   'isolated_foundational_or_core_records':sum(not x.startswith(('geo:b6:','geo:b7:','geo:b8:')) for x in isolates),
   'isolated_later_operator_records':sum(x.startswith(('geo:b6:','geo:b7:','geo:b8:')) for x in isolates),
   'nontrivial_disconnected_components':sum(len(c)>1 for c in components[1:]),
   'new_v128_math_relations':sum(e.get('batch')=='v1_28' for e in E),
   'previous_isolates_now_mathematically_linked':len(set(x['id'] for x in json.loads((ROOT/'reports/geometry_completeness_v127.json').read_text())['isolate_ledger'])-isolates)}
 return {'version':'v1_28','parent':'v1_27','method':'weak components of mathematical object-morphism graph, not a proof/dependency DAG',
   'counts':counts,'remaining_isolates':records,'deliberate_nonconnections':excluded,
   'nontrivial_disconnected_components':[sorted(c) for c in components[1:] if len(c)>1],
   'status':'NOT_EXHAUSTIVE: source mathematical structures still require complete semantic extraction and genuine map classification'}
if __name__=='__main__':
 out=build();(ROOT/'reports/geometry_completeness_v128.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n');print(json.dumps(out['counts'],indent=2))
