#!/usr/bin/env python3
"""Exact Q(sqrt(5)) finite quaternionic geometry; no physics/DAG data.

Coordinates are (a+b*sqrt(5))/4, with integer a,b.  The 120
quaternions form one marked copy of binary icosahedral 2I containing
2T as the 24 Hurwitz units.  All incidences are checked symbolically.
"""
from itertools import combinations, permutations, product
from collections import Counter

ZERO=(0,0)
def neg(x): return (-x[0],-x[1])
def add(x,y): return (x[0]+y[0],x[1]+y[1])
def sub(x,y): return (x[0]-y[0],x[1]-y[1])
def mul(x,y): return (x[0]*y[0]+5*x[1]*y[1], x[0]*y[1]+x[1]*y[0])
def conj(q): return (q[0],)+tuple(neg(v) for v in q[1:])
def parity(p): return sum(p[i]>p[j] for i in range(len(p)) for j in range(i+1,len(p))) % 2

def qmul(q,r):
    a,b,c,d=q; e,f,g,h=r
    out=(sub(sub(sub(mul(a,e),mul(b,f)),mul(c,g)),mul(d,h)),
         add(add(mul(a,f),mul(b,e)),sub(mul(c,h),mul(d,g))),
         add(add(mul(a,g),mul(c,e)),sub(mul(d,f),mul(b,h))),
         add(add(mul(a,h),mul(d,e)),sub(mul(b,g),mul(c,f))))
    assert all(x%4==y%4==0 for x,y in out), 'quaternion product leaves the expected coordinate ring'
    return tuple((x//4,y//4) for x,y in out)

def dot16(q,r):
    out=ZERO
    for x,y in zip(q,r):out=add(out,mul(x,y))
    return out

def generate_vertices():
    axial=[]
    for i in range(4):
        for sign in (-1,1):
            v=[ZERO]*4;v[i]=(4*sign,0);axial.append(tuple(v))
    half=[tuple((2*sign,0) for sign in signs) for signs in product((-1,1),repeat=4)]
    golden=[]
    t=[ZERO,(2,0),(1,1),(-1,1)]
    for p in permutations(range(4)):
        if parity(p):continue
        permuted=[t[i] for i in p]
        for signs in product((-1,1),repeat=3):
            it=iter(signs)
            golden.append(tuple(ZERO if v==ZERO else (v if next(it)==1 else neg(v)) for v in permuted))
    H=set(axial+half);I=set(axial+half+golden)
    assert (len(axial),len(half),len(golden),len(H),len(I))==(8,16,96,24,120)
    assert all(qmul(a,b) in H for a in H for b in H)
    assert all(qmul(a,b) in I for a in I for b in I)
    assert all(dot16(a,a)==(16,0) for a in I)
    return H,I

def orbit_parts(group,verts):
    todo=set(verts);parts=[]
    while todo:
        v=min(todo);one=frozenset(qmul(g,v) for g in group)
        assert one<=todo and len(one)==len(group)
        todo-=one;parts.append(one)
    return sorted(parts,key=lambda s:min(s))

def components(vs,adj):
    todo=set(vs);components=[]
    while todo:
        root=min(todo);component={root};queue=[root]
        while queue:
            for neighbor in adj[queue.pop()]&vs:
                if neighbor not in component:component.add(neighbor);queue.append(neighbor)
        todo-=component;components.append(len(component))
    return sorted(components)

def build_instance():
    H,I=generate_vertices();V=sorted(I);vix={v:i for i,v in enumerate(V)}
    cosets=[frozenset(H)];todo=I-H
    while todo:
        g=min(todo);C=frozenset(qmul(g,h) for h in H)
        assert C<=todo and len(C)==24
        cosets.append(C);todo-=C
    assert len(cosets)==5 and len(set().union(*cosets))==120
    color={v:i for i,C in enumerate(cosets) for v in C}
    adjacency={v:set() for v in V};edges=[]
    for u,v in combinations(V,2):
        if dot16(u,v)==(4,4):
            adjacency[u].add(v);adjacency[v].add(u)
            edges.append((vix[u],vix[v], tuple(sorted((color[u],color[v])))))
    assert len(edges)==720 and all(len(adjacency[v])==12 for v in V)
    assert all(i!=j for _,_,(i,j) in edges)
    edge_counts=Counter(pair for _,_,pair in edges)
    assert len(edge_counts)==10 and set(edge_counts.values())=={72}
    for C in cosets:
        for u in C:
            assert Counter(color[v] for v in adjacency[u])==Counter({j:3 for j in range(5) if j!=color[u]})

    representatives=[min(C) for C in cosets]
    cores=[frozenset(qmul(qmul(g,h),conj(g)) for h in H) for g in representatives]
    assert all(len(core)==24 for core in cores) and len(set(cores))==5
    normalizer=[g for g in I if frozenset(qmul(qmul(g,h),conj(g)) for h in H)==H]
    assert set(normalizer)==H
    # Equivariance: stabilizer of coset gH under left I action is gHg^{-1}.
    for g,C,core in zip(representatives,cosets,cores):
        assert core==frozenset(k for k in I if frozenset(qmul(k,v) for v in C)==C)

    axes=[];edge_axis={}
    for (i,j) in combinations(range(5),2):
        c6=cores[i]&cores[j]
        assert len(c6)==6
        o1=orbit_parts(c6,cosets[i]);o2=orbit_parts(c6,cosets[j])
        assert len(o1)==len(o2)==4 and all(len(o)==6 for o in o1+o2)
        raw=[[sum(v in adjacency[u] for u in a for v in b) for b in o2] for a in o1]
        assert all(m%6==0 for row in raw for m in row)
        quotient=[[m//6 for m in row] for row in raw]
        assert all(sorted(row)==[0,1,1,1] for row in quotient)
        assert all(sorted(col)==[0,1,1,1] for col in zip(*quotient))
        vertices=cosets[i]|cosets[j]
        assert components(vertices,adjacency)==[48]
        axes.append({'pair':[i,j], 'subgroup_vertices':sorted(vix[v] for v in c6),
                     'left_orbits_i':[[vix[v] for v in sorted(o)] for o in o1],
                     'left_orbits_j':[[vix[v] for v in sorted(o)] for o in o2],
                     'quotient_biadjacency':quotient,
                     'edge_count':edge_counts[(i,j)],
                     'connected_cover_components':components(vertices,adjacency)})
    assert len({frozenset(a['subgroup_vertices']) for a in axes})==10
    assert all(len(set.intersection(*(set(cores[k]) for k in triple)))==2 for triple in combinations(range(5),3))
    assert all(len(cores[i]&cores[j])==6 for i,j in combinations(range(5),2))
    # Check that the label action gives the Petersen graph on ten unordered pairs.
    pairs=[tuple(a['pair']) for a in axes]
    pet_edges=[[ix,jx] for ix,p in enumerate(pairs) for jx,q in enumerate(pairs) if ix<jx and not set(p)&set(q)]
    assert len(pet_edges)==15
    for vertex,degree in Counter(i for pair in pet_edges for i in pair).items():assert degree==3
    # All group translations preserve vertex adjacency and the coset/core/axis labels.
    for g in V:
        translated_cosets={i: next(j for j,D in enumerate(cosets) if frozenset(qmul(g,v) for v in C)==D) for i,C in enumerate(cosets)}
        assert len(set(translated_cosets.values()))==5
        for i,c in enumerate(cores):
            target=cores[translated_cosets[i]]
            assert frozenset(qmul(qmul(g,h),conj(g)) for h in c)==target

    return {'exact_coordinate_field':'Q(sqrt(5)); each quaternion coordinate (a+b*sqrt(5))/4',
            'marked_embedding':'one chosen 2I containing the coordinate 2T; no I_plus/I_minus branch identified',
            'vertices':[{'id':vix[v],'qcoords':[[a,b] for a,b in v],'color':color[v]} for v in V],
            'tetrahedral_core_vertex_ids':sorted(vix[v] for v in H),
            'coset_blocks':[[vix[v] for v in sorted(C)] for C in cosets],
            'conjugate_core_groups':[[vix[v] for v in sorted(core)] for core in cores],
            'nearest_edges':[{'u':u,'v':v,'coset_pair':[i,j]} for u,v,(i,j) in edges],
            'axes':axes,
            'petersen_pair_graph':{'vertices':[[i,j] for i,j in pairs], 'edges':pet_edges},
            'five_color_quotient_B':[[0 if i==j else 3 for j in range(5)] for i in range(5)],
            'ten_edge_class_counts':[edge_counts[p] for p in pairs],
            'totals':{'vertices':120,'edges':720,'vertex_degree':12,'cosets':5,'vertices_per_coset':24,
                      'tetrahedral_subgroups':5,'pairwise_c6_axes':10,'edges_per_axis':72,
                      'axis_orbit_vertex_count':8,'axis_orbit_edge_count':12,
                      'axis_cover_degree':6,'axis_cover_vertices':48,'axis_cover_edges':72,
                      'petersen_edges':15}}

if __name__=='__main__':
    import json
    print(json.dumps(build_instance()['totals'],indent=2))
