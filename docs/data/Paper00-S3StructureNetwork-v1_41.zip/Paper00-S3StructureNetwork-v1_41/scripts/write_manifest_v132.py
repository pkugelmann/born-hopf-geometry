#!/usr/bin/env python3
"""Write a self-contained SHA-256 file manifest for the cumulative S3 geometry network v1_32."""
import pathlib,json,hashlib
R=pathlib.Path(__file__).resolve().parents[1]
C=json.loads((R/'data/v132_release_counts.json').read_text())
A=json.loads((R/'reports/geometry_completeness_v132.json').read_text())['counts']
parent=pathlib.Path('/mnt/data/Paper00-S3StructureNetwork-v1_31(1).zip')
files=[]
for p in sorted(R.rglob('*')):
 if not p.is_file() or p.name=='MANIFEST.json' or '__pycache__' in p.parts or p.suffix in ('.pyc','.zip'):continue
 files.append({'path':p.relative_to(R).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
M={'version':'v1_32','parent':'v1_31','theme':'S3StructureNetwork','archive_root':'Paper00-S3StructureNetwork-v1_32',
 'release_type':'cumulative_pure_mathematical_object_and_typed_relation_network',
 'parent_archive_sha256':hashlib.sha256(parent.read_bytes()).hexdigest() if parent.exists() else None,
 'proof_dag_copied':False,'statement_locator_nodes':0,'physical_transition_edges':0,
 'batch_scope':'Source-scoped S3 mathematical structural map coverage: exact A5 20-to-9; 24cell even10; Petersen wedge; S3 spectral functional; 62 node harmonic frame; 53 former isolates classified with 24 new source-guarded maps awaiting independent proof',
 'new_objects':C['new_objects'],'new_typed_relations':C['new_typed_relations'],
 'new_joint_inputs':C['new_joint_inputs'],'new_compositions':C['new_compositions'],
 'cumulative_objects':C['cumulative_objects'],'cumulative_edges':C['cumulative_edges'],
 'cumulative_joint_inputs':C['cumulative_joint_inputs'],'cumulative_compositions':C['cumulative_compositions'],
 'isolated_object_records':A['isolated_objects'],'main_connected_component':A['component_containing_S3'],
 'linked_preexisting_records':C['previous_isolates_now_linked'],
 'new_exact_instance_links':C['new_exact_links_this_batch'],'new_guarded_partial_links':C['conditional_links_this_batch'],
 'source_formulas_without_independent_full_exact_certificates':C['source_scoped_guarded_connections_without_full_independent_proof'],
 'source_53_classification_coverage':True,
 'verification_summary':{'v132_exact_and_62node_numeric':'PASS','graph_exports':'PASS','source_witnesses':'53 current TeX label+hash source-located, not theorem DAG vertices',
  'current_v132_fast':'PASS','parent_v131_data_prefix_immutable':'PASS','parent_graph_exports_immutable':'PASS',
  'full_historical_regeneration':'NOT_RUN','all_source_morphism_proofs':'NOT_CLOSED; 24 source guard connections remain to be independently replayed',
  'semantic_exhaustiveness':'NOT_CLAIMED','physical_observables':'NOT_CLAIMED'},
 'files':files}
(R/'MANIFEST.json').write_text(json.dumps(M,indent=2,ensure_ascii=False)+'\n')
print('manifest written',len(files),'files',len(M['files']),'entries')
