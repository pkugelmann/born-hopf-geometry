#!/usr/bin/env python3
"""Regenerate exact A5-equivariant signed-Petersen -> Hopf-600-E8 rank-four bridges.

Objects: oriented Petersen 15-edge cochains, exterior-Hodge signed 10-pair
module, five-core standard representation, 15 Hopf axis fibres, 120-vertex
600-cell. Marked source order and genuine left-quaternion actions are checked.
No proof DAG or physical interpretation.
"""
from __future__ import annotations
import json, itertools, hashlib, pathlib, sys
import numpy as np
from sympy import Matrix, Rational, eye, zeros, LeviCivita
from . import exceptional_model as ex

ROOT=pathlib.Path(__file__).resolve().parents[1]
load=lambda fn:json.loads((ROOT/'data'/fn).read_text())
pairs=list(itertools.combinations(range(5),2)); pair_idx={p:i for i,p in enumerate(pairs)}
pedge=[(a,b) for a in range(10) for b in range(a+1,10) if not set(pairs[a])&set(pairs[b])]
pedge_idx={e:i for i,e in enumerate(pedge)}
assert len(pedge)==15


def rank(M):return int(Matrix(M.tolist() if isinstance(M,np.ndarray) else M).rank())


def build():
    prev=load('exceptional_600cell_instance.json')
    qdata=load('a5_q8_projector_v123_instance.json')
    a15=load('q8_hopf_e8_bridge_v120_instance.json')
    cubic=load('axis15_cubic_v121_instance.json')
    H,I=ex.generate_vertices();V=sorted(I);ix={q:i for i,q in enumerate(V)}
    assert len(V)==120 and [tuple(tuple(c) for c in row['qcoords']) for row in prev['vertices']]==V
    cores=[frozenset(V[i] for i in ids) for ids in prev['conjugate_core_groups']]
    clook={frozenset(c):i for i,c in enumerate(cores)}
    assert len(clook)==5
    act5=lambda q:tuple(clook[frozenset(ex.qmul(ex.qmul(q,h),ex.conj(q)) for h in c)] for c in cores)
    p5={q:act5(q) for q in V}
    assert len(set(p5.values()))==60 and all(ex.parity(p)==0 for p in p5.values())

    # Petersen vertices and oriented edges are real math carriers, NOT theorem nodes.
    D=np.zeros((10,15),dtype=np.int64)
    for j,(a,b) in enumerate(pedge):D[a,j]=1;D[b,j]=-1
    A=np.zeros((10,10),dtype=np.int64)
    for a,b in pedge:A[a,b]=A[b,a]=1
    assert np.array_equal(D@D.T,3*np.eye(10,dtype=np.int64)-A)
    assert sorted(np.linalg.eigvalsh(A).round(9).tolist())==[-2.0]*4+[1.0]*5+[3.0]
    N=np.zeros((10,5),dtype=np.int64)
    for a,(i,j) in enumerate(pairs):N[a,i]=N[a,j]=1
    C5=5*N-2*np.ones((10,5),dtype=np.int64)
    Q5=5*np.eye(5,dtype=np.int64)-np.ones((5,5),dtype=np.int64)
    assert np.array_equal(A@C5,-2*C5)
    assert np.array_equal(C5.T@C5,15*Q5)
    assert rank(C5)==4
    # Exterior Hodge on 10 oriented pairs: S=*5(c wedge .)
    S=np.zeros((10,10),dtype=np.int64)
    for u,(i,j) in enumerate(pairs):
        for v,(k,l) in enumerate(pairs):
            if len({i,j,k,l})<4:continue
            m=(set(range(5))-{i,j,k,l}).pop()
            S[u,v]=int(LeviCivita(m,i,j,k,l))
    B=np.zeros((5,10),dtype=np.int64)
    for v,(i,j) in enumerate(pairs):B[j,v]=1;B[i,v]=-1
    assert np.array_equal(S,S.T)
    assert np.array_equal(abs(S),A)
    assert np.array_equal(S@S@S,5*S)
    assert np.array_equal(B@S,np.zeros((5,10),dtype=np.int64))
    assert np.array_equal(B.T@B+S@S,5*np.eye(10,dtype=np.int64))
    assert np.array_equal(B@B.T,Q5)
    assert rank(B)==4 and rank(S)==6
    # P_H=I - S^2/5, P_E (Petersen 15-edge 4D sector), P_axis
    Ph_num=B.T@B
    Pe_num=D.T@C5@C5.T@D
    assert np.array_equal(Pe_num@Pe_num,375*Pe_num)
    assert int(np.trace(Pe_num))==4*375
    assert np.array_equal(5*np.eye(10,dtype=np.int64)-S@S,Ph_num)

    # The axis' five block labels differ from the source's five core labels.
    axis_blocks=cubic['intrinsic_core_partition_from_tensor_gram']
    assert len(axis_blocks)==5 and sorted(sum(axis_blocks,[]))==list(range(15))
    fiber=[set(int(v) for v in a['right_vertex_fibre']) for a in a15['axis15']]
    assert len(fiber)==15 and len({i for ss in fiber for i in ss})==120 and all(len(ss)==8 for ss in fiber)
    afiber=np.array(qdata['Q8_axis15_intertwiner']['axis_fibre_of_120_vertex'],dtype=np.int64)
    assert all(set(np.flatnonzero(afiber==a))==fiber[a] for a in range(15))
    color_of={ax:c for c,arr in enumerate(axis_blocks) for ax in arr}
    core_block_actions=[]
    axis_actions=[]
    for q in V:
        axperm=[]
        for ss in fiber:
            im={ix[ex.qmul(q,V[i])] for i in ss}
            matches=[a for a,tar in enumerate(fiber) if im==tar]
            assert len(matches)==1
            axperm.append(matches[0])
        coreperm=tuple(next(iter({color_of[axperm[i]] for i in block})) for block in axis_blocks)
        assert sorted(coreperm)==list(range(5))
        core_block_actions.append(coreperm)
        axis_actions.append(tuple(axperm))
    assert len(set(core_block_actions))==60
    # Source core ordering -> axis-block order is the UNIQUE equivariant bijection.
    aligned=[]
    for sig in itertools.permutations(range(5)):
        if all(tuple(a[sig[i]] for i in range(5))==tuple(sig[x] for x in p5[q])
               for q,a in zip(V,core_block_actions)):
            aligned.append(sig)
    assert len(aligned)==1
    sigma=aligned[0]
    R=np.zeros((15,5),dtype=np.int64)
    for c in range(5):
        for i in axis_blocks[sigma[c]]:R[i,c]=1
    assert np.array_equal(R.T@R,3*np.eye(5,dtype=np.int64))
    F=np.zeros((120,15),dtype=np.int64)
    F[np.arange(120),afiber]=1
    assert np.array_equal(F.T@F,8*np.eye(15,dtype=np.int64))

    # An integer certificate for the 15-edge -> 15-axis partial isometry:
    # T=Z/(15 sqrt 5).  Its two quadratic products are actual rank-4 projectors.
    Z=R@C5.T@D # 15x15 integer
    Paxis_num=R@Q5@R.T  # P_axis=Paxis_num/15
    assert np.array_equal(Paxis_num@Paxis_num,15*Paxis_num)
    assert np.array_equal(Pe_num,D.T@C5@C5.T@D)
    assert np.array_equal(Z@Z.T,75*Paxis_num) # =1125 P_axis
    assert np.array_equal(Z.T@Z,3*Pe_num)      # =1125 P_edge
    assert rank(Z)==4
    # 10 pair signed Hodge zero-space -> 15 axis
    W=R@B # integer, 15x10, normalized /sqrt(15)
    assert np.array_equal(W.T@W,3*Ph_num)
    assert np.array_equal(W@W.T,Paxis_num)
    assert np.array_equal(W@S,np.zeros((15,10),dtype=np.int64))
    # Explicit 15-edge ↔ 10-pair signed Hodge 4-sector bridge.
    K=D.T@C5@B # 15x10, normalized /sqrt(1875)
    assert np.array_equal(K.T@K,375*Ph_num)
    assert np.array_equal(K@K.T,5*Pe_num)
    assert rank(K)==4
    assert np.array_equal(Z.T@W,3*K)   # composition with shared 15-axis projection

    # Raw Petersen graph spectral projectors 4+5+6.
    # P_v4 = C5 C5^t /75; P_v5=I-J/10-P_v4; P_E5=D^t P_v5 D/2.
    J10=Matrix.ones(10,10); I10=eye(10)
    P_v4=Matrix(C5.tolist())*Matrix(C5.T.tolist())/75
    P_v5=I10-J10/10-P_v4
    P_E4=Matrix(Pe_num.tolist())/375
    P_E5=Matrix(D.T.tolist())*P_v5*Matrix(D.tolist())/2
    P_E6=eye(15)-P_E4-P_E5
    assert [int(X.trace()) for X in (P_E4,P_E5,P_E6)]==[4,5,6]
    assert all(X*X==X for X in (P_E4,P_E5,P_E6))
    assert P_E4*P_E5==zeros(15) and P_E4*P_E6==zeros(15)
    assert Matrix(Z.tolist())*P_E5==zeros(15) and Matrix(Z.tolist())*P_E6==zeros(15)

    # Check actual 60 A5 permutations (binary +/- pair have same action).
    groupchecks=0
    for q,pa,pb,ax in zip(V,p5.values(),core_block_actions,axis_actions):
        P5=np.zeros((5,5),dtype=np.int64)
        for i,j in enumerate(pa):P5[j,i]=1
        P10=np.zeros((10,10),dtype=np.int64)
        Pwedge=np.zeros((10,10),dtype=np.int64)
        for i,(a,b) in enumerate(pairs):
            out=tuple(sorted((pa[a],pa[b])));j=pair_idx[out]
            P10[j,i]=1;Pwedge[j,i]=1 if (pa[a]<pa[b]) else -1
        Pedge=np.zeros((15,15),dtype=np.int64)
        for e,(a,b) in enumerate(pedge):
            aa,bb=pair_idx[tuple(sorted(pa[t] for t in pairs[a]))],pair_idx[tuple(sorted(pa[t] for t in pairs[b]))]
            f=pedge_idx[tuple(sorted((aa,bb)))]
            Pedge[f,e]=1 if aa<bb else -1
        Paxis=np.zeros((15,15),dtype=np.int64)
        for i,j in enumerate(ax):Paxis[j,i]=1
        assert np.array_equal(Paxis@R,R@P5)
        assert np.array_equal(P10@N,N@P5)
        assert np.array_equal(P10@D,D@Pedge)
        assert np.array_equal(Pwedge@S,S@Pwedge)
        assert np.array_equal(B@Pwedge,P5@B)
        assert np.array_equal(Paxis@Z,Z@Pedge)
        assert np.array_equal(Paxis@W,W@Pwedge)
        assert np.array_equal(Pedge.T@Pe_num@Pedge,Pe_num)
        assert np.array_equal(Paxis.T@Paxis_num@Paxis,Paxis_num)
        groupchecks+=1
    assert groupchecks==120

    # Cumulative 600-cell and E8 operator intertwiners.
    Q600=np.array(a15['quotient_600_15x15'],dtype=np.int64)
    G=np.array(cubic['gram_matrix_15x15'],dtype=np.int64)
    assert np.array_equal(Q600@Z,-3*Z)
    assert np.array_equal(G@Z,296*Z)
    assert np.array_equal(Q600@W,-3*W)
    assert np.array_equal(G@W,296*W)
    A600=np.zeros((120,120),dtype=np.int64)
    for uv in prev['nearest_edges']:A600[uv['u'],uv['v']]=A600[uv['v'],uv['u']]=1
    assert np.array_equal(A600@F,F@Q600)
    U600=F@Z
    assert np.array_equal(A600@U600,-3*U600)
    assert rank(U600)==4
    # P6004 as integer numerator from the exact saved Q8 character projector.
    Ctriv=np.array(qdata['Q8_character_projectors']['projector_integer_numerators'][0],dtype=np.int64)
    assert np.array_equal(Ctriv,2*F@Paxis_num@F.T)
    assert np.array_equal(2*U600@U600.T,75*Ctriv) # U600/ sqrt(9000), Ctriv/240
    # Unit normalization works: (FZ/sqrt9000)(FZ/sqrt9000)^t = Ctriv/240
    assert np.array_equal(U600.T@U600,8*Z.T@Z)

    # Separate exact-integer gauge check: reversing any oriented Petersen
    # edge flips the corresponding source column but preserves its projector.
    flip=np.diag([(-1 if e%2 else 1) for e in range(15)]).astype(np.int64)
    assert np.array_equal((Z@flip)@(Z@flip).T,Z@Z.T)
    assert np.array_equal((flip@Pe_num@flip)@(flip@Pe_num@flip),375*(flip@Pe_num@flip))

    out={
      'schema':'S3_Petersen_signed_edge_A5_Hodge_to_600_E8_axis4_exact_v124',
      'source_marking':'one marked 2I with 2T/Q8 as in v1_23; source core order and Hopf block order aligned equivariantly',
      'source_premises': ['p1:thm:kneser-five-six-hodge-duality','p1:thm:v338-signed-petersen-hodge','p1:thm:v339-petersen-sl4-isometry','p1:thm:v340-incidence-character-projectors'],
      'five_core_relabelling_to_axis_blocks':list(sigma),
      'permutation_group_checks':{'binary_2I_lifts':120,'distinct_A5_elements':60,'actual_left_quaternion_action_on_axis_fibres':True,'signed_wedge_and_petersen_edge_actions':True},
      'petersen_vertices_10_core_pairs':[list(x) for x in pairs],
      'petersen_oriented_edges_15':[list(x) for x in pedge],
      'matrices':{
        'petersen_oriented_incidence_D_10x15':D.tolist(),
        'petersen_adjacency_A_10x10':A.tolist(),
        'pair_to_core_centered_numerator_C5_10x5':C5.tolist(),
        'signed_exterior_hodge_S_10x10':S.tolist(),
        'exterior_contraction_B_5x10':B.tolist(),
        'actual_axis_block_core_R_15x5':R.tolist(),
        'petersen15_to_axis15_integer_Z_15x15':Z.tolist(),
        'petersen10_to_axis15_integer_W_15x10':W.tolist(),
        'petersen10_to_petersen15_integer_K_15x10':K.tolist(),
        'petersen15_rank4_projector_numerator_Pe375_15x15':Pe_num.tolist(),
        'petersen10_rank4_projector_numerator_Ph5_10x10':Ph_num.tolist(),
        'axis15_rank4_projector_numerator_Pa15_15x15':Paxis_num.tolist(),
        'petersen15_rank5_projector_Pe5_15x15':[[str(x) for x in row] for row in P_E5.tolist()],
        'petersen15_rank6_projector_Pe6_15x15':[[str(x) for x in row] for row in P_E6.tolist()],
      },
      'normalizations':{'petersen15_to_axis15':'Z/(15 sqrt(5))',
                        'petersen10_to_axis15':'W/sqrt(15)',
                        'petersen10_to_petersen15':'K/(25 sqrt(3))',
                        'petersen15_to_600_W4':'F Z/sqrt(9000)'},
      'identities':{
         'ZtZ':'3 Pe_num = 1125 P_Petersen15_rank4',
         'ZZt':'75 Pa_num = 1125 P_axis_rank4',
         'WtW':'3 Ph_num =15 P_Petersen10_rank4',
         'WWt':'Pa_num = 15 P_axis_rank4',
         'KtK':'375 Ph_num=1875 P_Petersen10_rank4',
         'KKt':'5 Pe_num=1875 P_Petersen15_rank4',
         'S_hodge_10':'S^3=5S; B S=0; B^t B + S^2 = 5 I_10',
         'A5_equivariance':'P_axis(g)Z=Z P_Petersen_edge_signed(g), P_axis(g)W=W P_exterior_wedge(g) for all 60 A5 elements',
         'spectral':'Q600 Z=-3Z; E8 G Z=296 Z; A600 F Z=-3 F Z; 2(FZ)(FZ)^t=75 Ctriv',
      },
      'no_go_and_scope':['Intertwiner is a rank-four partial isometry, not an isomorphism of full signed Petersen 15D and axis 15D carriers.',
                          'Full oriented-edge module has rank-four, rank-five and rank-six A5 sectors; other 11 dimensions are annihilated.',
                          'Signed Petersen Hodge 10-pair module and graph-edge 15-cochain module are different carriers; only their marked rank-four sectors are identified.',
                          'Odd S5 relabellings reverse the sign of the exterior Hodge operator; all verified signed equivariance here concerns the A5 action.',
                          'The five-core order of source and Hopf-axis quotient are related by the explicit sigma permutation; naive core-label identification fails.',
                          'This is a mathematical finite-geometry morphism only, not a physical interaction, chirality or decay operator.'],
    }
    return out

if __name__=='__main__':
    d=build();(ROOT/'data/petersen_a5_bridge_v124_instance.json').write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
    print('PASS: exact signed Petersen↔axis↔600/E8 4D partial isometry, 60 A5 actions, unique five-core relabelling',d['five_core_relabelling_to_axis_blocks'])
