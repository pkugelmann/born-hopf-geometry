#!/usr/bin/env python3
"""Install exact geometry-only Batch 13 (v1_24): source-attested signed-Petersen modules,
explicit A5-equivariant partial isometries, and common Hopf/600/E8 rank-four spectrum.
Run once from the release root; rerun verifier separately.
"""
from __future__ import annotations
import json,pathlib,hashlib,collections,xml.etree.ElementTree as ET
ROOT=pathlib.Path(__file__).resolve().parents[1]
data=ROOT/'data'; load=lambda f:json.loads((data/f).read_text())
def dump(n,x): (data/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
cert=load('petersen_a5_bridge_v124_instance.json')
existing=load('objects.json'); edges=load('mathematical_relations.json'); joints=load('joint_input_relations.json'); comps=load('derived_compositions.json')
assert len(existing)==722 and len(edges)==958 and len(joints)==116 and len(comps)==102
sha='b38803550ab964421312daa97a0b93c08c25d53fb49c22a6b813d381a69651d4'
claimed={'p1:thm:kneser-five-six-hodge-duality':1244,'p1:thm:v338-signed-petersen-hodge':14581,
         'p1:thm:v339-petersen-sl4-isometry':14682,'p1:thm:v340-incidence-character-projectors':14853}
verification='EXACT_INTEGER_SIGNED_PETERSEN_A5_ORIENTATION_AND_HOPF_E8_PARTIAL_ISOMETRY'
def wit(k='p1:thm:v339-petersen-sl4-isometry'):
 return {'source_premise':k,'file':'Paper1B-ExceptionalGeometry-v1_15.tex','line':claimed[k],
         'tex_sha256':sha,'source_statement_verified_against_current_tex':True,
         'new_result':'EXACT_COMPOSITION_FROM_SOURCE_OBJECTS_REGENERATED_WITH_ACTUAL_Q8_HOPF_MARKING'}
node_specs=[
 ('petersen_boundary_D','Oriented 10-by-15 Petersen edge boundary D, rank 9','signed_finite_graph_boundary','p1:thm:v339-petersen-sl4-isometry'),
 ('core_pair_C5','Five-core centred 10-by-5 pair incidence C5=5N-2J, rank 4','exact_incidence_operator','p1:thm:kneser-five-six-hodge-duality'),
 ('petersen_Pe4','Rank-four projector of the 15-edge Petersen cochain, P_E4= Dᵀ C5 C5ᵀ D/375','rational_spectral_projector','p1:thm:v339-petersen-sl4-isometry'),
 ('petersen_Pe5','Rank-five projector of the oriented Petersen 15-edge cochain','rational_spectral_projector','p1:thm:v339-petersen-sl4-isometry'),
 ('petersen_Pe6','Rank-six projector of the oriented Petersen 15-edge cochain','rational_spectral_projector','p1:thm:v339-petersen-sl4-isometry'),
 ('petersen_P_hodge0','Rank-four kernel projector of the 10-pair signed exterior Hodge operator, BᵀB/5','rational_spectral_projector','p1:thm:v338-signed-petersen-hodge'),
 ('core_order_alignment','Unique equivariant core-to-axis block relabelling sigma=(0,2,3,4,1)','equivariant_finite_set_bijection','p1:thm:kneser-five-six-hodge-duality'),
 ('axis_core_R','Explicit 15-by-5 Hopf-axis/five-core indicator R with source-correct labelling','finite_geometric_incidence_operator','p1:thm:kneser-five-six-hodge-duality'),
 ('petersen_signed_A5_action','Signed A5 action on fifteen oriented Petersen graph edges','finite_group_signed_permutation_action','p1:thm:v339-petersen-sl4-isometry'),
 ('exterior_wedge_A5_action','A5 exterior-square signed permutation action on ten core pairs','finite_group_exterior_representation','p1:thm:v338-signed-petersen-hodge'),
 ('axis15_actual_A5_action','Actual left-2I/center A5 permutation action on fifteen right-Q8 Hopf fibres','finite_group_permutation_action','p1:thm:kneser-five-six-hodge-duality'),
 ('T_edge_to_axis','Rank-four partial isometry oriented Petersen edges to Hopf axes T=R Cᵀ D/(3√5)','equivariant_partial_isometry','p1:thm:v339-petersen-sl4-isometry'),
 ('W_pair_to_axis','Rank-four partial isometry signed 10-pair Hodge kernel to Hopf axes W=R B/√15','equivariant_partial_isometry','p1:thm:v338-signed-petersen-hodge'),
 ('K_pair_to_edge','Rank-four partial isometry between Petersen edge and exterior Hodge kernels K=Dᵀ C5 B/(25√3)','equivariant_partial_isometry','p1:thm:v339-petersen-sl4-isometry'),
 ('T_lift_600','Fibre-lifted Petersen 4-sector F T inside the 600-cell Q8-fixed minus-three eigenspace','equivariant_isometric_spectral_embedding','p1:thm:v340-incidence-character-projectors'),
 ('T_spectral_E8','Exact Q600 T=-3T and weighted-E8 Gram G T=296T spectral intertwining','exact_operator_intertwining_identity','p1:thm:v340-incidence-character-projectors'),
 ('Hodge_kernel_selection','Signed Petersen Hodge annihilates four-space; signed 15-edge 5⊕6 complement is killed by T','finite_group_spectral_selection_rule','p1:thm:v338-signed-petersen-hodge'),
 ('Petersen_456','Complete orthogonal 4⊕5⊕6 decomposition of Petersen 15-edge cochain','rational_spectral_decomposition','p1:thm:v339-petersen-sl4-isometry'),
]
new=[{'id':'geo:g24:'+id,'name':name,'batch':'v1_24','object_type':typ,
      'scope':'mathematical_structure_or_morphism','source_kind':'independently_derived_exact_geometry_from_existing_marked_input',
      'conditional':False,'verification':verification,'witness':wit(k)} for id,name,typ,k in node_specs]
ids={o['id'] for o in existing}|{o['id'] for o in new}
assert len(ids)==len(existing)+len(new)
# Only genuine mathematical construction/representation links. No citation-only edges.
links=[
 ('geo:petersen_15edge','petersen_boundary_D','ORIENTED_GRAPH_EDGE_TO_VERTEX_BOUNDARY'),
 ('geo:petersen_graph','petersen_boundary_D','PETERSEN_GRAPH_INCIDENT_SIGNED_BOUNDARY'),
 ('geo:g23:a5_standard_W4','core_pair_C5','CENTERED_TWO_SUBSET_TO_STANDARD_A5_MODULE'),
 ('geo:g16:petersen_rp2_equiv_maps','core_pair_C5','TWO_CORE_INDEX_OF_PETERSEN_VERTEX_MODULE'),
 ('petersen_boundary_D','petersen_Pe4','EDGE_BOUNDARY_OF_RANKFOUR_PROJECTOR'),
 ('core_pair_C5','petersen_Pe4','CENTERED_PAIR_EIGENSPACE_OF_VERTEX_ADJACENCY'),
 ('petersen_boundary_D','petersen_Pe5','EDGE_BOUNDARY_OF_RANKFIVE_PROJECTOR'),
 ('core_pair_C5','petersen_Pe5','ORTHOGONAL_VERTEX_SPECTRAL_COMPLEMENT'),
 ('petersen_Pe4','petersen_Pe6','KER_GRAD_SPECTRAL_COMPLEMENT'),
 ('petersen_Pe5','petersen_Pe6','GRAD_SPECTRAL_COMPLEMENT'),
 ('petersen_Pe4','Petersen_456','ORTHOGONAL_SUM_FOUR_FIVE_SIX'),
 ('petersen_Pe5','Petersen_456','ORTHOGONAL_SUM_FOUR_FIVE_SIX'),
 ('petersen_Pe6','Petersen_456','ORTHOGONAL_SUM_FOUR_FIVE_SIX'),
 ('geo:g16:signed_exterior_hodge5','petersen_P_hodge0','ZERO_EIGENSPACE_EXACT_IDEMPOTENT'),
 ('geo:g16:contraction_Lambda2_R5','petersen_P_hodge0','CONTRACTION_GRAM_RANKFOUR_PROJECTOR'),
 ('geo:g16:a5_conjugation_action','core_order_alignment','EXACT_UNIQUE_FIVE_CORE_AND_HOPF_BLOCK_EQUIVARIANT_RELABELLING'),
 ('geo:g21:intrinsic_five_core_partition','core_order_alignment','HOPF_BLOCKS_OF_THREE_MATCH_THE_MARKED_CORE_ACTION'),
 ('core_order_alignment','axis_core_R','PERMUTE_HOPF_BLOCK_LABELS_INTO_CORE_LABELS'),
 ('geo:g23:hopf_axis_F_indicator','axis_core_R','PARTITION_120_VERTEX_FIBRES_INTO_FIVE_AXIS_BLOCKS'),
 ('geo:g16:a5_conjugation_action','petersen_signed_A5_action','INDUCED_SIGNED_EXTERIOR_EDGE_COCHAIN_PERMUTATION'),
 ('geo:g16:a5_conjugation_action','exterior_wedge_A5_action','EXTERIOR_SQUARE_OF_FIVE_POINT_ACTION'),
 ('geo:g23:hopf_axis_F_indicator','axis15_actual_A5_action','ACTUAL_LEFT_QUATERNION_PERMUTATION_ON_RIGHT_Q8_AXIS_FIBRES'),
 ('core_order_alignment','axis15_actual_A5_action','AXIS_BLOCK_PERMUTATION_EQUIVARIANCE'),
 ('petersen_Pe4','T_edge_to_axis','DOMAIN_RANKFOUR_SOURCE_PROJECTOR'),
 ('petersen_boundary_D','T_edge_to_axis','ORIENTED_EDGE_BOUNDARY_IN_COMPOSITION'),
 ('core_pair_C5','T_edge_to_axis','CENTERED_PAIR_INCIDENCE_IN_COMPOSITION'),
 ('axis_core_R','T_edge_to_axis','AXIS_FIVE_CORE_INCIDENCE_IN_COMPOSITION'),
 ('petersen_signed_A5_action','T_edge_to_axis','SIGNED_EGDE_ACTION_INTERTWINED_BY_T'),
 ('axis15_actual_A5_action','T_edge_to_axis','ACTUAL_A5_AXIS_ACTION_INTERTWINED_BY_T'),
 ('petersen_P_hodge0','W_pair_to_axis','SIGNED_HODGE_ZERO_EIGENSPACE_SOURCE'),
 ('axis_core_R','W_pair_to_axis','ISOMETRY_VIA_EXTERIOR_CONTRACTION'),
 ('exterior_wedge_A5_action','W_pair_to_axis','A5_WEDGE_EQUIVARIANT_ISOMETRY'),
 ('T_edge_to_axis','K_pair_to_edge','COMPOSE_PARTIAL_ISOMETRIES_THROUGH_COMMON_AXIS_FOURSPACE'),
 ('W_pair_to_axis','K_pair_to_edge','COMPOSE_PARTIAL_ISOMETRIES_THROUGH_COMMON_AXIS_FOURSPACE'),
 ('geo:g23:q8_projection_triv4','T_lift_600','TARGET_Q8_FIXED_MINUS_THREE_PROJECTOR'),
 ('geo:g23:hopf_axis_F_indicator','T_lift_600','FIBRE_INDICATOR_LIFT_F_OVER_SQRT8'),
 ('T_edge_to_axis','T_lift_600','LIFT_RANKFOUR_PARTIAL_ISOMETRY'),
 ('geo:g20:A600_left_axis_operator','T_spectral_E8','Q600_EIGENVALUE_MINUS_THREE_ON_INTERTWINER'),
 ('geo:g21:slice_gram_operator','T_spectral_E8','E8_GRAM_EIGENVALUE_296_ON_INTERTWINER'),
 ('T_edge_to_axis','T_spectral_E8','SAME_MAP_INTERTWINES_BOTH_15_AXIS_OPERATORS'),
 ('geo:g16:signed_exterior_hodge5','Hodge_kernel_selection','ZERO_OF_SIGNED_HODGE_ON_SHARED_FOURSPACE'),
 ('Petersen_456','Hodge_kernel_selection','ANNIHILATE_OTHER_ELEVEN_PETERSEN_EDGE_MODES'),
 ('T_edge_to_axis','Hodge_kernel_selection','PARTIAL_ISOMETRY_SELECTS_ONLY_RANKFOUR'),
]
def res(s):return s if s.startswith('geo:') else 'geo:g24:'+s
new_edges=[]
for i,(a,b,rel) in enumerate(links,1):
 a,b=res(a),res(b);assert a in ids and b in ids and a!=b
 new_edges.append({'id':f'G24-{i:03d}','from':a,'to':b,'relation':rel,
                   'link_type':'exact_A5_equivariant_signed_Petersen_Hodge_Hopf_E8_morphism',
                   'conditions_preserved':True,'requires_joint_inputs':[],'verification':verification})
assert len({e['id'] for e in new_edges})==len(new_edges)
inputs=[
 (['petersen_boundary_D','core_pair_C5'],['petersen_Pe4'],'Oriented Petersen boundary and centred five-core pair incidence yield rank-four graph Hodge projector'),
 (['geo:g16:signed_exterior_hodge5','geo:g16:contraction_Lambda2_R5'],['petersen_P_hodge0'],'Signed exterior Hodge has rank-four zero sector selected by contraction'),
 (['core_order_alignment','axis_core_R','petersen_boundary_D','core_pair_C5'],['T_edge_to_axis'],'Unique five-core equivariant relabelling yields exact signed Petersen 15-edge to 15-axis partial isometry'),
 (['axis_core_R','geo:g16:contraction_Lambda2_R5','petersen_P_hodge0'],['W_pair_to_axis'],'Contraction identifies 10-pair Hodge kernel with the same 15-axis fourspace'),
 (['T_edge_to_axis','W_pair_to_axis'],['K_pair_to_edge'],'Composition identifies the two distinct Petersen four-sector carriers'),
 (['T_edge_to_axis','geo:g20:A600_left_axis_operator','geo:g21:slice_gram_operator'],['T_spectral_E8'],'The same actual 15-axis intertwiner lies in Q600 eigenvalue -3 and weighted E8 Gram eigenvalue 296'),
 (['T_edge_to_axis','geo:g23:hopf_axis_F_indicator','geo:g23:q8_projection_triv4'],['T_lift_600'],'Fibre lift identifies rank-four signed Petersen with Q8-fixed minus-three sector of 600 adjacency'),
]
new_joint=[{'id':f'HYP-G24-{i:02d}','kind':'exact_finite_mathematical_multi_input_construction',
            'inputs':[res(x) for x in xin],'outputs':[res(x) for x in xout],
            'conditions':['one fixed marked 2I, 2T and Q8 embedding; five-core and Hopf-axis labels aligned by sigma',
                          'Petersen graph-edge orientation and exterior Hodge orientation fixed explicitly',
                          'only rank-four partial isometry, no whole-module identification'],
            'output_statement':summary,'verification':verification} for i,(xin,xout,summary) in enumerate(inputs,1)]
new_comps=[
 ('Petersen graph 4+5+6 Hodge decomposition','P_E4=D^T C5 C5^T D/375, P_E5=D^T(I-J10/10-C5C5^T/75)D/2, P_E6=I-P_E4-P_E5','Actual rational projector traces 4,5,6; pairwise orthogonal idempotence and signed A5 invariance.'),
 ('Signed Petersen exterior Hodge zero-sector','S^3=5S; B S=0; P_H4=B^t B/5=I-S^2/5','Ten-by-ten integer Hodge matrix and contraction B define a rank-four kernel and two rank-three nonzero Hodge sectors.'),
 ('Uniqueness of five-core alignment in actual 2I model','sigma=(0,2,3,4,1)','Compare all 120 permutations of 5 core labels against actual left-multiplication actions on the right-Q8 Hopf fibres; exactly one intertwines the actions.'),
 ('Normalized signed Petersen 15-edge to 15-axis partial isometry','T=R C^t D/(3 sqrt(5)); T^tT=P_E4; TT^t=P_axis4','Use integer numerator Z=R C5^t D and verify Z^t Z=3 Pe_num, Z Z^t=75 Pa_num.'),
 ('Normalized signed 10-pair Hodge to 15-axis partial isometry','W=R B/sqrt(15); W^tW=P_H4; WW^t=P_axis4; WS=0','Use integer contraction B, core incidence R and signed exterior Hodge matrix S.'),
 ('Petersen pair and edge four-module composition','K=D^t C5 B/(25 sqrt(3)); K^tK=P_H4; KK^t=P_E4','Integer matrix K has rank4, K^tK=375 Ph_num, KK^t=5 Pe_num.'),
 ('A5-equivariance and spectral match to 600 and E8','Paxis(g)T=T Pedge(g) for g in A5; Q600 T=-3T; GE8 T=296T; A600 FT=-3FT','Check actual quaternion left action on all fifteen right-Q8 fibres and all 60 five-core even permutations, then exact integer matrices Q600,G and full A600.'),
]
new_comp=[]
for i,(title,formula,proof) in enumerate(new_comps,1):
 new_comp.append({'id':f'D24-{i:02d}','name':title,'formula':formula,
  'hypotheses':['one marked 2I and 2T/Q8 embedding; fixed five-core relabelling and oriented Petersen edges',
                'all maps are finite real mathematical representations and operators, no physical occurrence'],
  'proof':proof,'status':verification,'independent_checks':['verify_petersen_a5_bridge_v124.py','validate_geometry.py'],
  'source_premises':list(claimed)})

existing.extend(new);edges.extend(new_edges);joints.extend(new_joint);comps.extend(new_comp)
for f,x in [('objects.json',existing),('mathematical_relations.json',edges),('joint_input_relations.json',joints),('derived_compositions.json',comps)]:dump(f,x)
# Graph exports use exactly the same mathematical JSON data. No evidence nodes.
NS='http://graphml.graphdrawing.org/xmlns';ET.register_namespace('',NS)
def q(tag):return '{'+NS+'}'+tag

def graphml(path, nodes, relations, name):
 root=ET.Element(q('graphml'))
 for typ,k,id,lab in [('node','label','d0','label'),('node','kind','d1','kind'),('node','batch','d2','batch'),('node','verification','d3','verification'),
                      ('edge','id','d4','id'),('edge','relation','d5','relation'),('edge','verification','d6','verification'),('edge','requires_and_inputs','d7','requires_and_inputs')]:
  ET.SubElement(root,q('key'),{'id':id,'for':typ,'attr.name':lab,'attr.type':'string'})
 G=ET.SubElement(root,q('graph'),{'id':name,'edgedefault':'directed'})
 for o in nodes:
  n=ET.SubElement(G,q('node'),{'id':o['id']})
  for k,v in [('d0',o['name']),('d1',o.get('object_type','')),('d2',o.get('batch','')),('d3',o['verification'])]:
   ET.SubElement(n,q('data'),{'key':k}).text=str(v)
 for e in relations:
  a=ET.SubElement(G,q('edge'),{'id':e['id'],'source':e['from'],'target':e['to']})
  for k,v in [('d4',e['id']),('d5',e['relation']),('d6',e['verification']),('d7',','.join(e.get('requires_joint_inputs',[])))]:
   ET.SubElement(a,q('data'),{'key':k}).text=str(v)
 path.parent.mkdir(parents=True,exist_ok=True)
 ET.ElementTree(root).write(path,encoding='utf-8',xml_declaration=True)

graphml(ROOT/'graph/mathematical_structure_network.graphml',existing,edges,'S3_mathematical_geometry_v124')
used={e['from'] for e in new_edges}|{e['to'] for e in new_edges}
graphml(ROOT/'graph/batch13_Petersen_A5_600_E8_fourspace.graphml', [o for o in existing if o['id'] in used],new_edges,'Batch13_Petersen_A5_fourspace')
# An actual bipartite incidence visualization of integer matrix Z, not a claim DAG.
Z=cert['matrices']['petersen15_to_axis15_integer_Z_15x15']
mat_nodes=[{'id':'Pedge:'+str(i),'name':'Petersen oriented edge '+str(i),'verification':verification} for i in range(15)]+[{'id':'Axis:'+str(i),'name':'Hopf axis '+str(i),'verification':verification} for i in range(15)]
mat_edges=[]
for i,row in enumerate(Z):
 for j,v in enumerate(row):
  if v:
   mat_edges.append({'id':f'Z-{i}-{j}','from':'Pedge:'+str(j),'to':'Axis:'+str(i),
     'relation':'COEFFICIENT_'+str(v),'verification':verification,'requires_joint_inputs':[]})
graphml(ROOT/'graph/batch13_actual_15x15_signed_intertwiner.graphml',mat_nodes,mat_edges,'Batch13_exact_Z_coefficients')
# Strict graph DOT append only mathematical nodes and links; inherited diagram remains cumulative.
dot_path=ROOT/'graph/mathematical_structure_network.dot'
s=dot_path.read_text();assert s.strip().endswith('}')
part=[]
for o in new:
 lab=o['name'].replace('"',"'").replace('\\','\\\\')
 part.append('"'+o['id']+'" [label="'+lab+'"];')
for e in new_edges:part.append('"'+e['from']+'" -> "'+e['to']+'" [label="'+e['relation']+'",fontsize=8];')
s=s.rstrip();s=s[:-1]+'\n'+'\n'.join(part)+'\n}\n';dot_path.write_text(s)
counts={'parent':'v1_23','batch':'v1_24','new_objects':len(new),'new_typed_relations':len(new_edges),
 'new_joint_inputs':len(new_joint),'new_derived_compositions':len(new_comp),
 'cumulative_objects':len(existing),'cumulative_edges':len(edges),'cumulative_joint_inputs':len(joints),
 'cumulative_compositions':len(comps),'exact_intertwiner_nonzero_entries':len(mat_edges)}
dump('v124_release_counts.json',counts)
print('INSTALLED',counts)
