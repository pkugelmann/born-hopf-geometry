#!/usr/bin/env python3
"""Write self-contained file/hash manifest for the mathematical network v1_31."""
import json,hashlib,pathlib
R=pathlib.Path(__file__).resolve().parents[1]
C=json.loads((R/'data/v131_release_counts.json').read_text())
A=json.loads((R/'reports/geometry_completeness_v131.json').read_text())['counts']
parent=pathlib.Path('/mnt/data/Paper00-S3StructureNetwork-v1_30.zip')
files=[]
for p in sorted(R.rglob('*')):
 if not p.is_file() or p.name=='MANIFEST.json' or '__pycache__' in p.parts or p.suffix in ('.pyc','.zip'):continue
 files.append({'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
M={'version':'v1_31','parent':'v1_30','theme':'S3StructureNetwork','archive_root':'Paper00-S3StructureNetwork-v1_31',
 'release_type':'cumulative_pure_geometric_object_and_typed_relation_network',
 'parent_archive_sha256':hashlib.sha256(parent.read_bytes()).hexdigest() if parent.exists() else None,
 'proof_dag_copied':False,'statement_locator_nodes':0,'physical_transition_edges':0,
 'batch_scope':'Marked S3=SU2 inclusion into SU3, normalized Cartan/Hopf volume, finite 1+8 conjugation Casimir, two-vertex Haar/Gauss, selected Wedderburn and path groupoid examples; scoped owner interfaces only',
 'new_objects':C['new_objects'],'new_typed_relations':C['new_typed_relations'],
 'new_joint_inputs':C['new_joint_inputs'],'new_compositions':C['new_compositions'],
 'cumulative_objects':C['cumulative_objects'],'cumulative_edges':C['cumulative_edges'],
 'cumulative_joint_inputs':C['cumulative_joint_inputs'],'cumulative_compositions':C['cumulative_compositions'],
 'isolated_object_records':A['isolated_objects'],'main_connected_component':A['component_containing_S3'],
 'linked_preexisting_records':C['previous_isolates_now_linked'],
 'new_exact_instance_links':C['new_exact_links_this_batch'],'new_guarded_partial_links':C['conditional_links_this_batch'],
 'verification_summary':{'batch20_exact':'PASS','graph_exports':'PASS','source_witnesses':'11 current TeX label+hashes, not graph vertices',
 'cumulative_fast':'PASS','full_historical_regeneration':'NOT_RUN','semantic_exhaustiveness':'NOT_CLAIMED'},
 'files':files}
(R/'MANIFEST.json').write_text(json.dumps(M,indent=2,ensure_ascii=False)+'\n')
print('manifest written',len(files),'files')
