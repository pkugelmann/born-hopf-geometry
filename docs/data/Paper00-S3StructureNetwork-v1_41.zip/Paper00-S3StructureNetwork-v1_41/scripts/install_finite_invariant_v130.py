#!/usr/bin/env python3
"""Append finite Petersen compression and SU3 *representation geometry* only."""
from __future__ import annotations
import hashlib,re,json,zipfile,pathlib,xml.etree.ElementTree as ET
from .finite_invariant_geometry_v130 import build
ROOT=pathlib.Path(__file__).resolve().parents[1];D=ROOT/'data';G=ROOT/'graph'
SRC=pathlib.Path('/mnt/data/Paper00-PapersMinimal-v3_028(1).zip')
def ld(n):return json.loads((D/n).read_text())
def wr(n,x):(D/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
source_claims=[
'p10:def:v323-petersen-strong-contrast','p11:thm:v323-petersen-k-core-spectrum',
'p13:prop:v323-petersen-charpolys','p13:cor:v323-petersen-coherence-bound',
'p10:prop:d4-a2-reading-of-qcd-color-support','p10:def:finite-colour-singlet-projector',
'p10:thm:finite-colour-singlet-basis-transcript','p11:thm:singlet-support-classification',
'p11:thm:color-casimir-attraction-channels',
'p11:thm:three-quark-determinant-geometry-baryon-multiplets',
'p10:prop:v365-baryon-color-gram','p11:prop:v327-meson-gram-support']
assert SRC.exists(),'Need exact TeX archive to recheck current sources'
W={}
with zipfile.ZipFile(SRC) as z:
 for f in sorted(z.namelist()):
  if not f.endswith('.tex'): continue
  raw=z.read(f);s=raw.decode(errors='replace');sha=hashlib.sha256(raw).hexdigest()
  for label in source_claims:
   if label in W:continue
   i=s.find('\\label{'+label+'}')
   if i<0:continue
   W[label]={'claim_id':label,'file':f,'line':s[:i].count('\n')+1,'tex_sha256':sha,
      'located_in_current_tex':True,'source_scope':'Paper00-PapersMinimal-v3_028 original TeX'}
assert set(W)==set(source_claims),(set(source_claims)-set(W))
wr('batch19_current_tex_witnesses.json',{'source_archive':SRC.name,'source_witnesses':W,'provenance_only_not_graph_vertices':True})
inst=build();assert inst==ld('finite_invariant_geometry_v130_instance.json')
O=ld('objects.json');R=ld('mathematical_relations.json');H=ld('joint_input_relations.json');C=ld('derived_compositions.json')
ids={o['id'] for o in O};usededge={e['id'] for e in R};hid={e['id'] for e in H};cid={e['id'] for e in C}
exact='EXACT_FINITE_REPRESENTATION_INVARIANT_V130'
guard='SCOPED_FINITE_MATH_MODEL_NOT_FULL_QCD_OPERATOR_V130'
def addo(key,name,typ,claim,ver=exact):
 id='geo:g30:'+key
 if id not in ids:
  O.append({'id':id,'name':name,'object_type':typ,'scope':'mathematical_structure_or_morphism',
        'source_kind':'finite_petersen_or_su3_representation_geometry','conditional':ver==guard,
        'batch':'v1_30','verification':ver,'witness':W[claim]});ids.add(id)
 return id
x={}
x['mirror']=addo('mirror_D15','Petersen 15-edge signed six-sector mirror-contrast D','symmetric_representation_operator','p10:def:v323-petersen-strong-contrast')
x['core']=addo('mirror_five_Pm','Five Petersen core-projectors rank three each','orthogonal_core_decomposition','p10:def:v323-petersen-strong-contrast')
x['family']=addo('mirror_32_compressions','All 32 exact Petersen core-compressions P_S D P_S','finite_spectral_compression_family','p13:prop:v323-petersen-charpolys')
x['poly']=addo('mirror_charpolys','Six exact cardinality-class characteristic polynomials','spectral_invariant_family','p13:prop:v323-petersen-charpolys')
x['av']=addo('mirror_mean_square','Average squared Petersen support compression: a_k P6+b_k(I-P6)','group_averaged_spectral_identity','p13:prop:v323-petersen-charpolys')
x['coh']=addo('mirror_norm_bound','Sharp variational norm of each Petersen core compression','operator_norm_invariant','p13:cor:v323-petersen-coherence-bound')
x['A2']=addo('A2_su3_fundamental','Selected A2 root Lie algebra su3 acting on complex trimer C3','finite_lie_algebra_representation','p10:prop:d4-a2-reading-of-qcd-color-support',guard)
x['qanti']=addo('su3_3_3bar','SU3 3 tensor conjugate-3 module: 1 plus 8 decomposition','finite_tensor_representation','p11:thm:singlet-support-classification')
x['mesonproj']=addo('su3_identity_singlet_P1','Rank-one normalized identity-tensor projector on C3 tensor C3-dual','orthogonal_invariant_projector','p10:def:finite-colour-singlet-projector')
x['baryonproj']=addo('su3_epsilon_singlet','Rank-one determinant epsilon projector on C3 cubed','orthogonal_invariant_projector','p11:thm:three-quark-determinant-geometry-baryon-multiplets')
x['qq']=addo('su3_diquark_antisym','SU3 3 tensor 3 symmetric 6 and antisymmetric 3bar projectors','finite_tensor_symmetry_projectors','p11:thm:color-casimir-attraction-channels')
x['casimir']=addo('su3_fierz_casimir','Exact SU3 quark/antiquark and quark/quark Fierz-Casimir tensors','finite_quadratic_lie_operator','p11:thm:color-casimir-attraction-channels')
x['center']=addo('su3_center_triality','Necessary center Z3 triality selection law for SU3 invariants','invariant_selection_obstruction','p10:thm:finite-colour-singlet-basis-transcript')
x['gram']=addo('three_equal_gram','Three-source real equicorrelation Gram PSD cone and spectrum','finite_gram_positive_semidefinite_invariant','p11:prop:v327-meson-gram-support')
# Links to existing *mathematical suboperator names*, NOT identification of full actions or measured phenomena.
links=[
('geo:g24:petersen_Pe6',x['mirror'],'SIX_SECTOR_SIGNED_HODGE_SPLIT_D2_EQUALS_PE6',exact),
('geo:g25:petersen_hodge6' if 'geo:g25:petersen_hodge6' in ids else 'geo:g24:petersen_Pe6',x['mirror'],'HODGE_SIX_SQRT_FIVE_NORMALIZATION',exact),
('geo:g24:petersen_signed_A5_action',x['mirror'],'A5_EQUIVARIANT_MIRROR_MATRIX',exact),
('geo:petersen_graph',x['core'],'PETERSEN_OMITTED_CORE_TRIPLE_PARTITION',exact),
('geo:g24:petersen_boundary_D',x['core'],'THREE_ORIENTED_EDGES_OMITTING_EACH_CORE',exact),
(x['mirror'],x['family'],'ORTHOGONAL_P_S_COMPRESS_MIRROR',exact),
(x['core'],x['family'],'ALL_SUBSETS_OF_FIVE_RANK_THREE_CORE_PROJECTORS',exact),
(x['family'],x['poly'],'ALL_THIRTYTWO_EXACT_CHARPOLYS_BY_CARDINALITY',exact),
(x['family'],x['av'],'EXACT_AVERAGE_SQUARES_OVER_K_CORE_SUBSETS',exact),
(x['mirror'],x['av'],'POLYNOMIAL_IN_RANK_SIX_PROJECTOR',exact),
('geo:g24:petersen_Pe4',x['av'],'COMMON_FOUR_PLUS_FIVE_COMPLEMENT_PROJECTOR',exact),
('geo:g24:petersen_Pe5',x['av'],'COMMON_FOUR_PLUS_FIVE_COMPLEMENT_PROJECTOR',exact),
(x['family'],x['coh'],'VARIATIONAL_NORM_OF_SELECTED_CORE_BLOCK',exact),
(x['poly'],x['coh'],'EXTREMAL_CHARACTERISTIC_ROOT_GIVES_SHARP_NORM',exact),
(x['mirror'],'geo:b8:petersen_mirror','EXACT_MATHEMATICAL_PETERSEN_D_AND_FIVE_CORE_P_S_ONLY',exact),
(x['family'],'geo:b8:petersen_kcore','EXACT_K_CORE_SPECTRA_NO_MASS_INTERPRETATION',exact),
(x['poly'],'geo:b8:petersen_char','ALL_THIRTYTWO_EXACT_COMPRESSION_POLYNOMIALS',exact),
(x['coh'],'geo:b8:petersen_coherence_bound','SHARP_FINITE_MATRIX_VARIATIONAL_BOUND',exact),
('geo:hurwitz_cube_link',x['A2'],'SELECTED_TRIMER_AND_A2_DEFECT_READING_GUARDED',guard),
('geo:g29:body_diagonal_split',x['A2'],'CHOICE_OF_MARKED_TRIMER_C3_GUARDED',guard),
(x['A2'],'geo:b8:d4_a2_color','SU3_A2_ROOT_ALGEBRA_MATHEMATICAL_PART_ONLY',guard),
(x['A2'],x['qanti'],'FUNDAMENTAL_AND_DUAL_TENSOR_MODULE',exact),
(x['qanti'],x['mesonproj'],'HERMESIAN_ORTHOGONAL_HAAR_SINGLET_IN_3_X_3BAR',exact),
(x['A2'],x['baryonproj'],'EXTERIOR_CUBED_DETERMINANT_INVARIANT',exact),
(x['A2'],x['qq'],'TENSOR_SQUARED_SWAP_SYMMETRY_6_PLUS_3BAR',exact),
(x['A2'],x['casimir'],'EIGHT_GENERATOR_FIERZ_COMPLETENESS',exact),
(x['qanti'],x['casimir'],'COLOR_3_3BAR_CASIMIR_SINGLET_AND_OCTET',exact),
(x['qq'],x['casimir'],'COLOR_3_3_PAIR_CASIMIR_ANTISYMMETRIC_AND_SYMMETRIC',exact),
(x['baryonproj'],x['casimir'],'DETERMINANT_COLOR_PAIR_CASIMIR_MINUS_TWO_THIRDS',exact),
(x['A2'],x['center'],'CENTRAL_Z3_CONGRUENCE_FOR_TENSOR_INVARIANTS',exact),
(x['mesonproj'],'geo:b8:color_singlet','SPECIFIC_3_X_3BAR_HAAR_SINGLET_NOT_GENERAL_FOCK',guard),
(x['baryonproj'],'geo:b8:color_singlet','SPECIFIC_3_X_3_X_3_HAAR_SINGLET_NOT_GENERAL_FOCK',guard),
(x['mesonproj'],'geo:b8:color_singlet_basis','FINITE_OCCUPATION_EXAMPLE_ONLY_NOT_FULL_COMPILER',guard),
(x['center'],'geo:b8:color_singlet_basis','SU3_CENTER_NECESSARY_NOT_SUFFICIENT_SINGLET',guard),
(x['mesonproj'],'geo:b8:singlet_support','MESON_IDENTITY_COLOR_TENSOR_SUBSPACE_ONLY',guard),
(x['baryonproj'],'geo:b8:singlet_support','DETERMINANT_TENSOR_SUBSPACE_ONLY',guard),
(x['baryonproj'],'geo:b8:baryon_determinant','COLOR_ANTISYMMETRIC_TENSOR_ONLY_NOT_SPECTRAL_MULTIPLET',guard),
(x['casimir'],'geo:b8:casimir_channels','FOUR_FUNDAMENTAL_CASIMIR_CHANNELS_ONLY',guard),
(x['baryonproj'],'geo:b8:baryon_color_gram','NORMALIZED_DETERMINANT_TENSOR_GRAM_BOUND_ONLY',guard),
(x['gram'],'geo:b8:meson_gram','ABSTRACT_3_SOURCE_GRAM_RULE_ONLY_NOT_POLE_MASS',guard),
]
for i,(a,b,rela,ver) in enumerate(links,1):
 assert a in ids and b in ids,('edge',i,a,b)
 eid=f'G30-{i:03d}'
 if eid not in usededge:
  e={'id':eid,'from':a,'to':b,'relation':rela,'link_type':'finite_explicit_matrix_map_or_guarded_invariant_suboperator',
     'batch':'v1_30','verification':ver,'conditions_preserved':True}
  if ver==guard:e['requires_joint_inputs']=[x['A2']] if b.startswith('geo:b8:') else ['geo:hurwitz_cube_link']
  R.append(e);usededge.add(eid)

hypotheses=[
 ('Petersen selected subset compression',[x['mirror'],x['core']],x['family'],['marked 2I and oriented 15-edge carrier, a chosen S subset']),
 ('Petersen Galois two-rank3 decomposition',[x['mirror'],'geo:g24:petersen_Pe6'],x['poly'],['verified signed Hodge six normalization']),
 ('Petersen exact k-averages',[x['family'],'geo:g24:petersen_Pe4','geo:g24:petersen_Pe5'],x['av'],['all C(5,k) subsets; selected marking and signed A5 action']),
 ('Quark-antiquark invariant projector',[x['A2'],x['qanti']],x['mesonproj'],['selected SU3 fundamental on complex trimer C3, no Fock identification']),
 ('Determinant invariant projector',[x['A2']],x['baryonproj'],['three identical fundamental color tensor factors only']),
 ('Casimir Fierz decomposition',[x['A2'],x['qanti'],x['qq']],x['casimir'],['Tr TaTb=delta_ab/2, complex SU3 fundamental']),
 ('Center-triality obstruction',[x['A2'],x['qanti']],x['center'],['necessary selection only, not sufficient for invariance']),
 ('Abstract Gram PSD comparison',[x['gram']], 'geo:b8:meson_gram',['generic equal-norm three-source model, not measured mass']),
]
for i,(name,inputids,output,conds) in enumerate(hypotheses,1):
 eid=f'HYP-G30-{i:02d}'
 if eid not in hid:
  H.append({'id':eid,'kind':'finite_mathematical_joint_relation','name':name,'inputs':inputids,'outputs':[output],
            'conditions':conds,'verification':guard if output.startswith('geo:b8:') else exact,'batch':'v1_30'});hid.add(eid)
comps=[
('Petersen 32-subset compression certificate','For k=0,...,5 all C(5,k) selected-core polynomials are identical, exactly reconstructed from H=√5D.',[x['mirror'],x['core']]),
('Petersen averaged square spectral algebra','Mean_{|S|=k}(P_S D P_S)^2 = a_k P6+b_k (I-P6); table k2=(1,1)/25, k3=(9,4)/50, k4=(12,2)/25, k5=(1,0).',[x['family'],x['av']]),
('Petersen second spectral moment','tr[(P_SDP_S)^2]=3 k(k-1)/10 for every k-subset S.',[x['mirror'],x['family']]),
('SU3 Fierz identity','Sum_a Ta ⊗ Ta=(Swap-I9/3)/2 on C3 ⊗ C3.',[x['A2'],x['qq'],x['casimir']]),
('SU3 quark-antiquark Casimir identity','Sum_a Ta ⊗ (-Ta^T)=I9/6-(3/2)P1 on C3 ⊗ C3 dual.',[x['qanti'],x['mesonproj'],x['casimir']]),
('SU3 determinant invariant','P_eps=|epsilon><epsilon|/6 has rank one on C3^⊗3 and (Ta_1+Ta_2+Ta_3)epsilon=0.',[x['A2'],x['baryonproj']]),
('Center necessary versus sufficient','Z3-neutrality is necessary for invariant tensor, but no guarantee (adjoint representation is neutral without singlet).',[x['center'],x['qanti']]),
('Three-equal-source Gram PSD cone','G=40((1-gamma)I+gamma J) is PSD iff -1/2<=gamma<=1 and trace 120.',[x['gram']]),
]
for i,(name,formula,inputs) in enumerate(comps,1):
 eid=f'D30-{i:02d}'
 if eid not in cid:
  C.append({'id':eid,'name':name,'formula':formula,'hypotheses':['fixed marked finite representation and precisely specified linear algebra, no physical gauge Hamiltonian'],
            'source_premises':list(W.keys()),'input_ids':inputs,'status':'EXACT_FINITE_MATRIX_GEOMETRY_OR_ELEMENTARY_COMPOSITION_NOT_PHYSICAL',
            'batch':'v1_30'});cid.add(eid)
wr('objects.json',O);wr('mathematical_relations.json',R);wr('joint_input_relations.json',H);wr('derived_compositions.json',C)
# Encode exact abstract object graph with the inherited GraphML format.
NS='http://graphml.graphdrawing.org/xmlns';ET.register_namespace('',NS);t=lambda s:'{'+NS+'}'+s

def export(path,nodes,edges,graphid):
 root=ET.Element(t('graphml'))
 keys=[('d0','node','label'),('d1','node','object_type'),('d2','edge','relation'),('d3','edge','verification'),('d4','edge','requires_and_inputs')]
 for key,scope,name in keys:ET.SubElement(root,t('key'),{'id':key,'for':scope,'attr.name':name,'attr.type':'string'})
 graph=ET.SubElement(root,t('graph'),{'id':graphid,'edgedefault':'directed'})
 for o in nodes:
  n=ET.SubElement(graph,t('node'),{'id':o['id']})
  for k,v in [('d0',o['name']),('d1',o['object_type'])]:ET.SubElement(n,t('data'),{'key':k}).text=str(v)
 for e in edges:
  q=ET.SubElement(graph,t('edge'),{'id':e['id'],'source':e['from'],'target':e['to']})
  for k,v in [('d2',e['relation']),('d3',e['verification']),('d4',','.join(e.get('requires_joint_inputs',[])))]:ET.SubElement(q,t('data'),{'key':k}).text=str(v)
 ET.ElementTree(root).write(path,encoding='utf-8',xml_declaration=True)
export(G/'mathematical_structure_network.graphml',O,R,'S3_mathematical_v130')
newedges=[e for e in R if e.get('batch')=='v1_30'];used={e['from'] for e in newedges}|{e['to'] for e in newedges}
export(G/'batch19_petersen_su3_invariant_bridges.graphml',[o for o in O if o['id'] in used],newedges,'S3_batch19_finite_invariants')
print('installed batch19',len([o for o in O if o.get('batch')=='v1_30']),'objects',len(newedges),'edges',len(hypotheses),'hyperedges',len(comps),'compositions')
