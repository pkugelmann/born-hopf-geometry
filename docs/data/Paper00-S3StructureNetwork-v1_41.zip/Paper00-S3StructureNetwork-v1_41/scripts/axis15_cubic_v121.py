#!/usr/bin/env python3
"""Exact cubic design algebra of the marked 15 Hopf axes (geometry only).

Source input is the Q8 orbit pushforward of the golden E8 root-sum triples.
The axis tensor here is NOT a physics interaction tensor. Finite arithmetic,
complete 5!*(3!)^5 automorphism enumeration and rational spectral tests.
"""
from __future__ import annotations
import collections,itertools,json,pathlib
from fractions import Fraction
import numpy as np
import sympy as sp
ROOT=pathlib.Path(__file__).resolve().parent.parent

def build():
 prior=json.loads((ROOT/'data/q8_hopf_e8_bridge_v120_instance.json').read_text())
 n=15
 assert len(prior['axis15'])==n
 colors=[x['core_color'] for x in prior['axis15']]
 assert set(colors)==set(range(5)) and sorted(collections.Counter(colors).values())==[3]*5
 blocks={c:tuple(i for i in range(n) if colors[i]==c) for c in range(5)}
 wt={tuple(r['axis_triple']):int(r['q8_orbit_multiplicity']) for r in prior['weighted_full_E8_axis_hyperedges']}
 assert len(wt)==215 and collections.Counter(wt.values())=={1:180,2:30,8:5}
 T=np.zeros((n,n,n),dtype=np.int64)
 for tr,w in wt.items():
  assert len(set(tr))==3
  for xyz in itertools.permutations(tr):T[xyz]=w
 assert int(T.sum())==1680 and int(np.sum(T*T))==3720
 assert np.array_equal(T,T.transpose(1,0,2)) and np.array_equal(T,T.transpose(0,2,1))
 pair=T.sum(axis=2)
 assert np.array_equal(pair,8*(np.ones((n,n),dtype=np.int64)-np.eye(n,dtype=np.int64)))
 # Gram determines the FIVE core partition without access to its labels.
 Gram=np.einsum('ijk,ljk->il',T,T,optimize=True)
 diag=set(int(Gram[i,i]) for i in range(n))
 assert diag=={248}
 intrinsic_edges=[(i,j) for i in range(n) for j in range(i+1,n) if Gram[i,j]==84]
 assert len(intrinsic_edges)==15
 intrinsic_groups=[];unvisited=set(range(n))
 while unvisited:
  i=min(unvisited);com={i};todo=[i]
  while todo:
   k=todo.pop()
   for a,b in intrinsic_edges:
    v=b if a==k else a if b==k else None
    if v is not None and v not in com:com.add(v);todo.append(v)
  intrinsic_groups.append(sorted(com));unvisited-=com
 intrinsic_groups.sort()
 assert len(intrinsic_groups)==5 and all(len(c)==3 for c in intrinsic_groups)
 assert {frozenset(c) for c in intrinsic_groups}=={frozenset(c) for c in blocks.values()}
 C=np.array([[int(colors[i]==colors[j]) for j in range(n)] for i in range(n)],dtype=np.int64)
 I=np.eye(n,dtype=np.int64);J=np.ones((n,n),dtype=np.int64)
 assert np.array_equal(Gram,164*I+44*C+40*J)
 Q=np.array(prior['quotient_600_15x15'],dtype=np.int64)
 assert np.array_equal(Gram,164*I-23*Q+7*(Q@Q))
 # Rational projectors as integer numerators over denominator 15.
 PN={'1':J,'4':5*C-J,'10':15*I-5*C}
 assert np.array_equal(PN['1']+PN['4']+PN['10'],15*I)
 for a in PN:
  assert np.array_equal(PN[a]@PN[a],15*PN[a])
  for b in PN:
   if a!=b:assert not np.any(PN[a]@PN[b])
 assert [int(np.trace(PN[k])//15) for k in ('1','4','10')]==[1,4,10]
 gram_spectrum={str(z):int(mult) for z,mult in sp.Matrix(Gram.tolist()).eigenvals().items()}
 assert gram_spectrum=={'896':1,'296':4,'164':10}
 assert all(np.array_equal(np.array([[sp.Rational(s)*15 for s in row] for row in prior['spectral_projectors'][a]],dtype=np.int64),PN[k])
            for a,k in [('P_constant_rank1','1'),('P_blockcontrast_rank4','4'),('P_withinblock_rank10','10')])
 # The local 3x3x3 tensor is universally the equality pattern (2/1/0).
 local_templates=[]
 for triplecolors in itertools.combinations(range(5),3):
  A,B,D=(blocks[t] for t in triplecolors)
  thick=[(i,j,k) for i in A for j in B for k in D if T[i,j,k]==2]
  assert len(thick)==3
  assert all({p[r] for p in thick}==set((A,B,D)[r]) for r in range(3))
  thick.sort(key=lambda t:t[0]);idx={axis:k for k,t in enumerate(thick) for axis in t}
  # Each local triple has 2 for all equal; 1 for exactly two equal; 0 for all distinct.
  for i,j,k in itertools.product(A,B,D):
   a,b,c=idx[i],idx[j],idx[k]
   expected=int(a==b)+int(a==c)+int(b==c)-int(a==b==c)
   assert T[i,j,k]==expected,(triplecolors,i,j,k,T[i,j,k],expected)
  local_templates.append({'core_colors':list(triplecolors),'weight2_axis_matching':[list(t) for t in thick],
                          'weight_distribution_3cube':{'2':3,'1':18,'0':6},
                          'formula':'delta_ab+delta_ac+delta_bc-delta_ab*delta_ac in the weight2 matching coordinates'})
 # Ten K3,3 matchings: every third core defines one 1-factor; the three 1-factors cover all 9 edges.
 pair_factorizations=[]
 for a,b in itertools.combinations(range(5),2):
  fs=[];used=set()
  for c in set(range(5))-{a,b}:
   matches=[]
   for t,w in wt.items():
    if w==2 and {colors[i] for i in t}=={a,b,c}:
     matches.append((next(i for i in t if colors[i]==a),next(i for i in t if colors[i]==b)))
   matches=sorted(matches)
   assert len(matches)==3 and {i for i,j in matches}==set(blocks[a]) and {j for i,j in matches}==set(blocks[b])
   assert not (used&set(matches))
   used.update(matches)
   fs.append({'third_core':c,'matching':[list(t) for t in matches]})
  assert used==set(itertools.product(blocks[a],blocks[b]))
  # For distinct third-core choices, the change-of-transport on A is a 3-cycle.
  matchmaps=[{i:j for i,j in f['matching']} for f in fs]
  for f,g in itertools.combinations(matchmaps,2):
   invg={v:k for k,v in g.items()}
   p={i:invg[f[i]] for i in blocks[a]}
   assert all(p[i]!=i and p[p[p[i]]]==i for i in blocks[a])
  pair_factorizations.append({'core_pair':[a,b],'three_perfect_matchings':fs,
                               'relative_transport':'difference between any two matchings is an order-3 fixed-point-free permutation'})
 # Complete AUTOMORPHISM group: preserve all five weight-8 blocks and all 30 weight-2 triples.
 # Every automorphism of the weighted tensor must permute the five disjoint weight-8 triples,
 # giving an upper search domain S_3 wr S_5 of order 5!*(3!)^5 = 933120.
 W2=[t for t,w in wt.items() if w==2]
 W2bits={sum(1<<i for i in t) for t in W2}
 p3=list(itertools.permutations(range(3)))
 pos={i:(k,j) for k in range(5) for j,i in enumerate(blocks[k])}
 aut=[];block_hist=collections.Counter()
 for blockperm in itertools.permutations(range(5)):
  for within in itertools.product(range(6),repeat=5):
   m=[blocks[blockperm[pos[i][0]]][p3[within[pos[i][0]]][pos[i][1]]] for i in range(n)]
   if all(sum(1<<m[i] for i in t) in W2bits for t in W2):
    # Direct independent full tensor preservation incl weights 0,1,8.
    assert all(wt.get(tuple(sorted(m[i] for i in t)),0)==w for t,w in wt.items())
    aut.append(m);block_hist[blockperm]+=1
 assert len(aut)==360 and len(block_hist)==120 and set(block_hist.values())=={3}
 kernel=[g for g in aut if all(colors[g[i]]==colors[i] for i in range(n))]
 assert len(kernel)==3
 idperm=tuple(range(n))
 def comp(p,q):return tuple(p[q[i]] for i in range(n))
 def inverse(p):return tuple(p.index(i) for i in range(n))
 nontriv=tuple(next(g for g in kernel if tuple(g)!=idperm))
 assert comp(nontriv,comp(nontriv,nontriv))==idperm
 for g in aut:
  bp=[colors[g[blocks[k][0]]] for k in range(5)]
  parity=sum(bp[i]>bp[j] for i in range(5) for j in range(i+1,5))%2
  conjug=comp(comp(tuple(g),nontriv),inverse(g))
  assert conjug==(nontriv if parity==0 else comp(nontriv,nontriv))
 # All 15 choose 3 triples fall into five automorphism orbits (incl 0-weight classes).
 classes=collections.defaultdict(set)
 for t in itertools.combinations(range(n),3):classes[(len({colors[i] for i in t}),wt.get(t,0))].add(t)
 assert {k:len(v) for k,v in classes.items()}=={(1,8):5,(2,0):180,(3,2):30,(3,1):180,(3,0):60}
 orbit_table=[]
 for (distinct,w),S in sorted(classes.items()):
  start=min(S)
  orb={tuple(sorted(g[i] for i in start)) for g in aut}
  assert orb==S and len(aut)%len(S)==0
  orbit_table.append({'distinct_core_blocks':distinct,'weight':w,'orbit_size':len(S),
                      'stabilizer_size':len(aut)//len(S),'representative':list(start)})
 # Exact orthogonal 1+4+10 decomposition of the symmetric cubic form.
 order=['1','4','10'];norm_table=[];multinomial_sum=Fraction(0)
 for a,b,c in itertools.combinations_with_replacement(order,3):
  arr=np.einsum('ia,jb,kc,abc->ijk',PN[a],PN[b],PN[c],T,optimize=True)
  norm=Fraction(sum(int(u)**2 for u in arr.flat),15**6)
  multi=1 if a==b==c else 3 if a==b or b==c or a==c else 6
  multinomial_sum+=multi*norm
  norm_table.append({'sectors':[a,b,c],'squared_frobenius_norm':str(norm),
                     'identically_zero':norm==0,'permutation_multiplicity':multi})
 assert multinomial_sum==3720
 assert {tuple(r['sectors']) for r in norm_table if r['identically_zero']}=={
  ('1','1','4'),('1','1','10'),('1','4','10'),('4','4','10')}
 output={'schema':'S3_axis15_weighted_E8_cubic_geometry_exact_v121',
  'scope':'one fixed marked Q8 < 2T < 2I golden E8 sheet pair, purely mathematical root incidence, NO physical cubic vertex',
  'source_instance':'data/q8_hopf_e8_bridge_v120_instance.json',
  'axis_count':15,'triple_tensor_sparse':[{'triple':list(t),'weight':w} for t,w in sorted(wt.items())],
  'symmetric_tensor_frobenius_norm_squared':3720,
  'weighted_pair_contraction':'sum_k T_ijk = 8(1-delta_ij)',
  'intrinsic_core_partition_from_tensor_gram':intrinsic_groups,
  'gram_matrix_15x15':Gram.tolist(),
  'gram_closed_form':'G=164 I_15 + 44 SameCore + 40 J_15',
  'gram_as_600_operator_polynomial':'G=164 I_15 - 23 Q600 + 7 Q600^2',
  'gram_eigenvalue_multiplicity':gram_spectrum,
  'gram_spectral_projectors':{k:[[str(Fraction(int(a),15)) for a in row] for row in PN[k]] for k in order},
  'cubic_sector_squarenorms':norm_table,
  'ten_local_3x3x3_templates':local_templates,
  'ten_pairwise_K33_one_factorizations':pair_factorizations,
  'automorphism_group':{'order':360,'induced_core_perm_count':120,'kernel_order':3,
    'kernel':'cyclic order 3 acting freely and simultaneously on the three axes of each core',
    'conjugation_on_kernel':'even core permutations centralize generator, odd invert generator',
    'exhaustive_search_space':933120,'triple_orbits':orbit_table,
    'note':'Finite permutation group certified as order 360 with specified action/kernel; abstract group extension naming is not asserted without separate proof.'},
  'nonidentifications':['The 15-axis weighted cubic tensor is root-incidence, not a physical coupling vertex.',
                         'Its automorphism group acts on the finite weighted design; no statement equates it with the full E8 Weyl group.',
                         'The five-block local matching coordinate systems cannot be chosen globally to make every weight-two triple diagonal.',
                         'Cubic-projector orthogonality is a combinatorial selection rule, not a particle decay selection rule.']}
 return output
if __name__=='__main__':
 x=build();print('OK:',x['gram_closed_form'],x['gram_eigenvalue_multiplicity'],
                  'aut order',x['automorphism_group']['order'],
                  'zero cubic sectors', [n['sectors'] for n in x['cubic_sector_squarenorms'] if n['identically_zero']])
