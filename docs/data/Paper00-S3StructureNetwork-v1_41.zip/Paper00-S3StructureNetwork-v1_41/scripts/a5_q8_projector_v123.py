#!/usr/bin/env python3
"""Exact-INT geometry-only v1_23: A5 4-dim matrix-coefficient spectral block,
Q8 character resolution, C3 action, and E8 15-axis Gram identification.

All equations are independently computed from marked quaternion vertices, the
saved 25 transported 24-cell sets and projective cyclic polygon incidence,
not from a theorem DAG or a physical model. `numpy` uses int64, with all bounds
small enough to avoid overflow. Regenerates the complete current instance.
"""
from __future__ import annotations
from collections import Counter
from pathlib import Path
import json,itertools
import numpy as np
from . import exceptional_model as ex
from .q8_triality_v119 import q8_elements,q_class
ROOT=Path(__file__).resolve().parents[1]
def read(name):return json.loads((ROOT/'data'/name).read_text())
def build():
  finite=read('finite_geometry_v116_instance.json')
  source=read('exceptional_600cell_instance.json')
  common=read('q8_hopf_e8_bridge_v120_instance.json')
  cubic=read('axis15_cubic_v121_instance.json')
  hol=read('axis15_holonomy_v122_instance.json')
  H,I=ex.generate_vertices();V=sorted(I);vid={q:i for i,q in enumerate(V)}
  assert len(H)==24 and len(I)==120 and len(V)==120
  assert [tuple(tuple(v) for v in r['qcoords']) for r in source['vertices']]==V
  hs=sorted(H);q8=q8_elements();assert set(q8)<=H and len(q8)==8
  # Independently recover the 25 transporter vertex incidences.
  sets=finite['transporter_24cells']['sets'];assert len(sets)==25
  B=np.zeros((120,25),dtype=np.int64)
  for j,s in enumerate(sets):
    assert len(set(s))==24
    B[s,j]=1
  assert np.array_equal(B.sum(axis=1),np.full(120,5))
  N=B@B.T-np.ones((120,120),dtype=np.int64) # 30*P_(-3)
  assert np.array_equal(N,N.T) and np.array_equal(N@N,30*N)
  assert int(np.trace(N))==480
  A=np.zeros((120,120),dtype=np.int64)
  for e in source['nearest_edges']:
    A[e['u'],e['v']]=A[e['v'],e['u']]=1
  assert int(A.sum())==1440 and np.array_equal(A@N,-3*N)
  # Recompute A5=2I/{+-1} by conjugation on five marked tetrahedral subgroups.
  cores=[frozenset(V[i] for i in s) for s in source['conjugate_core_groups']]
  clook={c:i for i,c in enumerate(cores)}
  assert len(cores)==5
  perms=[]
  for q in V:
    qi=ex.conj(q)
    perm=tuple(clook[frozenset(ex.qmul(ex.qmul(q,h),qi) for h in c)] for c in cores)
    perms.append(perm)
  G=sorted(set(perms)); assert len(G)==60
  gidx={g:i for i,g in enumerate(G)}
  projective_indices=np.array([gidx[p] for p in perms],dtype=np.int64)
  assert all(np.count_nonzero(projective_indices==i)==2 for i in range(60))
  # The 5-point permutation bank is a 1+4 representation. Its 4D centered
  # matrix coefficients yield a 16D Peter-Weyl subspace of R[A5].
  B60=np.zeros((60,25),dtype=np.int64)
  for k,p in enumerate(G):
    for j,i in enumerate(p):B60[k,5*j+i]=1
  assert np.array_equal(B60.sum(axis=1),np.full(60,5))
  C60=B60@B60.T-np.ones((60,60),dtype=np.int64)
  assert np.array_equal(C60@C60,15*C60) and int(np.trace(C60))==240
  # Distinct independent source: 200 three-point and 72 five-point
  # *projective* cyclic polygons, with actual 60-point membership.
  M={k:np.zeros((60,60),dtype=np.int64) for k in (2,3,5)}
  for k,rows in finite['projective_cyclic_design']['polygons'].items():
    key=int(k)
    for polygon in rows:
      assert len(polygon)==key
      for i in polygon:
        for j in polygon:M[key][i,j]+=1
  assert np.array_equal(M[3]-M[5],C60)
  assert np.array_equal(M[2]+M[3]+M[5],30*np.eye(60,dtype=np.int64)+np.ones((60,60),dtype=np.int64))
  assert np.array_equal(N,C60[np.ix_(projective_indices,projective_indices)])
  # 2T right deck action, exact character on the complete -3 space.
  right={h:np.array([vid[ex.qmul(v,h)] for v in V],dtype=np.int64) for h in hs}
  tr={h:int(np.trace(N[:,right[h]])//30) for h in hs}
  assert all(int(np.trace(N[:,right[h]]))==30*tr[h] for h in hs)
  assert Counter((q_class(h),tr[h]) for h in q8)==Counter({(0,16):1,(1,16):1,(2,0):2,(3,0):2,(4,0):2})
  assert all(tr[h]==4 for h in H-set(q8))
  # Four Q8 1D real characters; χ_i(+/-i)=+1, other pure directions -1.
  chi=lambda c,h:(1 if c==0 or q_class(h) in (0,1,c+1) else -1)
  Qmat=[]
  for c in range(4):
    Qc=sum(chi(c,h)*N[:,right[h]] for h in q8) # numerator of P_c=Qc/(30*8)
    assert np.array_equal(Qc,Qc.T)
    assert np.array_equal(Qc@Qc,240*Qc)
    assert int(np.trace(Qc))==4*240
    Qmat.append(Qc)
  assert np.array_equal(sum(Qmat),8*N)
  assert all(not np.any(Qmat[i]@Qmat[j]) for i,j in itertools.combinations(range(4),2))
  # Every nontrivial C3 deck generator conjugates the three sign characters.
  t=next(h for h in hs if h not in q8)
  pt=right[t]
  perm_sign=[next(j for j in range(4) if np.array_equal(Qmat[c][np.ix_(pt,pt)],Qmat[j])) for c in range(4)]
  assert perm_sign[0]==0 and set(perm_sign[1:])=={1,2,3}
  assert perm_sign[1:]!=[1,2,3]
  # The fixed space of the right C3 is dimension 8; remaining eigenspaces
  # have complex multiplicities 4 and 4 by exact character 16,4,4.
  assert (16+2*tr[t])//3==8 and (16-tr[t])//3==4
  # Explicit isometry (indicator 120x15 divided by sqrt(8)), 15 axis fibres.
  F=np.zeros((120,15),dtype=np.int64)
  for a in common['axis15']:
    for v in a['right_vertex_fibre']:F[v,a['id']]=1
  assert np.array_equal(F.sum(axis=1),np.ones(120,dtype=np.int64))
  assert np.array_equal(F.T@F,8*np.eye(15,dtype=np.int64))
  colors=np.array([a['core_color'] for a in common['axis15']])
  Same=np.equal.outer(colors,colors).astype(np.int64)
  U4=5*Same-np.ones((15,15),dtype=np.int64)  # 15 P_4, rank 4
  assert np.array_equal(U4@U4,15*U4)
  assert int(np.trace(U4))==60
  # The genuine compression and lift identities, integer-scaled.
  assert np.array_equal(F.T@N@F,16*U4)
  assert np.array_equal(Qmat[0],2*F@U4@F.T)
  Q=np.array(common['quotient_600_15x15'],dtype=np.int64)
  assert np.array_equal(Q@(Q-12*np.eye(15,dtype=np.int64)),3*U4)
  tensorGram=np.array(cubic['gram_matrix_15x15'],dtype=np.int64)
  I15=np.eye(15,dtype=np.int64)
  J15=np.ones((15,15),dtype=np.int64)
  assert np.array_equal(tensorGram,164*I15+44*Same+40*J15)
  assert np.array_equal(tensorGram,164*I15-23*Q+7*Q@Q)
  assert np.array_equal((tensorGram-164*I15)@(tensorGram-896*I15),-5280*U4)
  # The C3 cycles each of five 3-axis blocks. It commutes with the 15-axis
  # operators Q and G; fixes their 4D block contrast and rotates V10 in 5+5.
  c3perm=np.array(hol['axis_C3_deck_generator_right_2T'],dtype=np.int64)
  assert all(colors[i]==colors[c3perm[i]] for i in range(15))
  assert np.array_equal(Q[np.ix_(c3perm,c3perm)],Q)
  assert np.array_equal(tensorGram[np.ix_(c3perm,c3perm)],tensorGram)
  assert np.array_equal(U4[np.ix_(c3perm,c3perm)],U4)
  assert not any(int(c3perm[i])==i for i in range(15))
  assert all(int(c3perm[c3perm[c3perm[i]]])==i for i in range(15))
  # The C3 action preserves all three cyclic-polygon incidence matrices,
  # and actually fixes twenty 3-point cosets as sets (the right-C3 orbits).
  proj_t=np.array([gidx[perms[right[t][i]]] for i in [next(k for k in range(120) if projective_indices[k]==j) for j in range(60)]],dtype=np.int64)
  assert len(set(proj_t))==60 and all(int(proj_t[proj_t[proj_t[i]]])==i for i in range(60))
  poly_orbits={}
  for k in (2,3,5):
    rows=finite['projective_cyclic_design']['polygons'][str(k)]
    cells={tuple(sorted(x)) for x in rows}
    transformed={tuple(sorted(int(proj_t[i]) for i in c)) for c in cells}
    assert transformed==cells
    assert np.array_equal(M[k][np.ix_(proj_t,proj_t)],M[k])
    fixed=sum(tuple(sorted(int(proj_t[i]) for i in c))==c for c in cells)
    assert (len(cells)-fixed)%3==0
    poly_orbits[str(k)]={'polygons':len(cells),'fixed_by_right_C3':fixed,'orbits_of_size3':(len(cells)-fixed)//3,'total_orbits':fixed+(len(cells)-fixed)//3}
  assert poly_orbits=={'2':{'polygons':450,'fixed_by_right_C3':0,'orbits_of_size3':150,'total_orbits':150},
                         '3':{'polygons':200,'fixed_by_right_C3':20,'orbits_of_size3':60,'total_orbits':80},
                         '5':{'polygons':72,'fixed_by_right_C3':0,'orbits_of_size3':24,'total_orbits':24}}
  # Universal positivity/idempotence stored as small exact certificates.
  classes=[]
  for h in hs:
    classes.append({'quaternion_coord':[[int(a),int(b)] for a,b in h],
                    'is_Q8':h in q8,'q8_class':q_class(h) if h in q8 else 'half',
                    'trace_on_600_minus3':tr[h]})
  result={
    'schema':'S3_A5_matrix_coeff_Q8_fourier_C3_cyclic_polygon_E8_gram_exact_v123',
    'mathematical_scope':'one marked 2I/2T/Q8 quaternionic model; projective A5; 600-cell adjacency and transporter incidence; opposite-right Hopf quotient and E8 weighted tensor; NO physical interpretation',
    'input_instances':['data/exceptional_600cell_instance.json','data/finite_geometry_v116_instance.json','data/q8_hopf_e8_bridge_v120_instance.json','data/axis15_cubic_v121_instance.json','data/axis15_holonomy_v122_instance.json'],
    'A5_matrix_coefficients':{
      'projective_120_to_60':projective_indices.tolist(),
      'A5_order':60,
      'five_core_perm_rep_dimension':5,
      'centered_standard_rep_dimension':4,
      'centered_coefficients_matrix_shape':[60,25],
      'centered_coefficients_Gram_C60':C60.tolist(),
      'C60_projector_denominator':15,
      'A5_regular_matrix_coefficient_rank':16,
      'cyclic_polygon_identity':'C60 = M3 - M5 = B60 B60^T - J60',
      'antipodal_lift_identity':'N120_(u,v)=C60_(projective(u),projective(v)); P_(-3)=N120/30'
    },
    'transporter_spectrum':{'A_600_N120':'-3*N120', 'N120_squared':'30*N120','N120_trace':480, 'minus3_eigenspace_dimension':16,
                            'N120_matrix':N.tolist()},
    'Q8_character_projectors':{'order':8,'irreducible_characters':['trivial','chi_i','chi_j','chi_k'],
                               'projector_denominator':240,'projector_integer_numerators': [m.tolist() for m in Qmat],
                               'ranks':[4,4,4,4],
                               'multiplication_law':'C_alpha C_beta=240 delta_ab C_alpha; sum C_alpha=8 N120',
                               'right_2T_character':classes,
                               'right_C3_conjugation_of_character_projectors':perm_sign,
                               'right_A4_module':'4 copies of the 4-dimensional permutation module on the other four cores',
                               'C3_complex_eigenspace_dimensions':[8,4,4]},
    'Q8_axis15_intertwiner':{'axis_fibre_of_120_vertex': [int(np.argmax(F[i])) for i in range(120)],
                           '15_block_contrast_projector_numerator':U4.tolist(),'projector_denominator':15,
                           'compression_identity':'F^T N120 F = 16*(5 SameCore - J15)',
                           'lifting_identity':'C_trivial = 2*F*(5 SameCore - J15)*F^T',
                           'quotient_adjacency_projector':'Q600*(Q600-12I)=3*(5 SameCore-J15)',
                           'E8_weighted_tensor_gram_projector':'(G-164I)*(G-896I)=-5280*(5 SameCore-J15)',
                           'C3_deck_generator_on_15_axes':c3perm.tolist(),
                           'C3_complex_eigen_dims_on_V10':[5,5]},
    'polygon_family_under_right_C3':poly_orbits,
    'nonidentifications':[
      'The 16D 600-cell -3 eigenspace contains a 4D right-Q8 fixed subspace; the 4D E8 axis block contrast is isometric to that subspace via F/sqrt(8), not to the full 16D space.',
      'The C3 rotation on axis colours is the residual marked right 2T/Q8 deck action and is distinct from a selected nonflat matching connection.',
      'The 16D module is the coefficient block of the 4D A5 standard representation; it is not an identification with either 8D quaternionic E8 coefficient representation or a physical Hilbert space.',
      'All identities depend on the fixed marked 2I, 2T and Q8 embeddings; no unmarked universal claim or decay selection is made.'
    ]
  }
  return result
if __name__=='__main__':
  x=build();print(json.dumps({'schema':x['schema'],'projector_ranks':x['Q8_character_projectors']['ranks'],
         'right_A4':x['Q8_character_projectors']['right_A4_module'],'polygon_orbits':x['polygon_family_under_right_C3']},indent=2))
