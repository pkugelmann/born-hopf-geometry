#!/usr/bin/env python3
"""Add exact 25D 600-cell adjacency kernel and reconcile isolated twisted quintet."""
from __future__ import annotations
import pathlib,json,hashlib,zipfile
from .twisted25_v127 import build
from .install_batch16_v127 import make_graph,wr,rd,O,R,H,C,ids,W,exact,G,D

# Refresh source witness only if the original archive is accessible, but the
# release has the standalone evidence map already supplied.
source=rd('batch16_source_witnesses.json')
for label in ('p1:thm:v344-twisted-25-gram','p1:cor:v3026-twisted25-adjacency-kernel'):
    assert label in source['source_witnesses'],('witness not bundled',label)
W=source['source_witnesses']
new_id='geo:g27:twisted25_zero_band'
if new_id not in ids:
    O.append({'id':new_id,'name':'Exact 120×120 25-dimensional Chebyshev character projector onto the 600-cell zero band',
              'object_type':'finite_spectral_projector','scope':'mathematical_structure_or_morphism',
              'source_kind':'exact_finite_quaternionic_spectral_calculation_v127','conditional':False,
              'batch':'v1_27','verification':exact,'witness':W['p1:cor:v3026-twisted25-adjacency-kernel']})
    ids.add(new_id)
new_edges=[
 ('geo:600cell_nearest_vertex_graph',new_id,'ZERO_ADJACENCY_CHARACTER_SPECTRAL_PROJECTOR', 'p1:cor:v3026-twisted25-adjacency-kernel'),
 ('geo:twisted_quintet','geo:twisted_25','IRREP_QUINTET_MATRIX_COEFFICIENT_PROJECTOR_25', 'p1:thm:v344-twisted-25-gram'),
 ('geo:twisted_25_coefficients','geo:twisted_25','SCHUR_ORTHOGONALITY_FFSTAR_OVER24', 'p1:thm:v344-twisted-25-gram'),
 ('geo:twisted_25',new_id,'EXACT_CHEBYSHEV_CHARACTER_KERNEL_EQUALS_ADJACENCY_ZERO_EIGENSPACE', 'p1:cor:v3026-twisted25-adjacency-kernel'),
 ('geo:g16:minus3_projector',new_id,'ORTHOGONAL_16_AND_25_CENTRAL_ADJACENCY_EIGENSPACES', 'p1:cor:v3026-twisted25-adjacency-kernel'),
 ('geo:twisted25_harmonic',new_id,'SPIN_TWO_SU2_CHARACTER_U4_PROJECTOR_FORMULA','p1:cor:v3026-twisted25-adjacency-kernel')]
for i,(a,b,k,label) in enumerate(new_edges,53):
    rid='G27-%03d'%i
    assert a in ids and b in ids,(a,b)
    if not any(e['id']==rid for e in R):
        R.append({'id':rid,'from':a,'to':b,'relation':k,'link_type':'explicit_mathematical_map_or_operator_composition',
         'source_relation':'MATHEMATICAL_CONSTRUCTION_NOT_PROOF_EDGE','conditions_preserved':True,
         'verification':exact if i in (53,56,57) else 'CURRENT_SOURCE_ATTESTED_MATHEMATICAL_RELATION_NOT_FULLY_REPROVED_V127',
         'witness':W[label],'batch':'v1_27'})
if not any(h['id']=='HYP-G27-11' for h in H):
    H.append({'id':'HYP-G27-11','kind':'joint_mathematical_inputs_with_explicit_scope_conditions',
      'inputs':['geo:600cell_nearest_vertex_graph','geo:twisted_25_coefficients','geo:g16:minus3_projector'],
      'outputs':[new_id],
      'conditions':['same marked 120-root quaternion 2I coordinates','nearest graph adjacency based on Re(q^-1r)=phi/2',
                   'U4 polynomial of the scalar quaternionic inner product','do not identify adjacency zero with Laplacian zero'],
      'result':'Pi25=P24/24 rank25, Pi25²=Pi25, Ran Pi25=ker A600, Pi25 Pminus3=0',
      'verification':exact})
if not any(c['id']=='D27-12' for c in C):
    C.append({'id':'D27-12','name':'Exact twisted-quintet character kernel is 600-cell adjacency zero band',
      'formula':'Pi25(q,r)=U4(Re(q^-1r))/24; rank Pi25=25; A600 Pi25=0; Pi25 Pminus3=0',
      'hypotheses':['marked 120 golden-quaternion 2I vertices','same 600-cell nearest graph and transported 24cells'],
      'proof':'Only nine scalar-product classes occur. Their U4 values are integers 5,-1,0,1. Exact 120×120 integer product P24²=24P24, tr P24=600, and A600 P24=0. Modular Gaussian rank certificates give rank(A600)>=95, while the 25D explicit projector gives rank(A600)<=95; hence ker(A600)=ran(Pi25). The 16D BB^T-J projector is exactly orthogonal.',
      'source_premises':['p1:cor:v3026-twisted25-adjacency-kernel'],
      'status':'EXACT_INDEPENDENT_MATRIX_AND_MODULAR_RANK_CERTIFICATE_V127'})
wr('objects.json',O);wr('mathematical_relations.json',R);wr('joint_input_relations.json',H);wr('derived_compositions.json',C)
wr('twisted25_v127_instance.json',build())
counts={'version':'v1_27','parent':'v1_26','new_objects':len([x for x in O if x.get('batch')=='v1_27']),
 'new_typed_relations':len([x for x in R if x['id'].startswith('G27-')]),
 'new_joint_inputs':len([x for x in H if x['id'].startswith('HYP-G27-')]),
 'new_derived_compositions':len([x for x in C if x['id'].startswith('D27-')]),
 'cumulative_objects':len(O),'cumulative_edges':len(R),'cumulative_joint_inputs':len(H),'cumulative_compositions':len(C)}
wr('v127_release_counts.json',counts)
make_graph(G/'mathematical_structure_network.graphml',O,R,'S3_geometry_only_v127')
newrels=[x for x in R if x['id'].startswith('G27-')];used={z['from'] for z in newrels}|{z['to'] for z in newrels}
make_graph(G/'batch16_clifford_m8_operator_bridges.graphml',[x for x in O if x['id'] in used],newrels,'S3_batch16_geometry_gaps')
print('TWISTED25 INSTALLED; TOTALS',counts)
