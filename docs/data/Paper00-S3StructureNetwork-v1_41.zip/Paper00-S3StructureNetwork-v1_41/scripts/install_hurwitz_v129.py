#!/usr/bin/env python3
"""Add geometry-only mathematical objects/maps for Hurwitz 24-cell cellular/Hodge/Cayley geometry.

No source claim nodes or physics edges; current TeX labels serve only as provenance.
Idempotent, reproducible installer over the v1_28 mathematical object graph.
"""
import json,hashlib,re,sys,pathlib,xml.etree.ElementTree as ET
from .hurwitz_cellular_v129 import build as math_build
ROOT=pathlib.Path(__file__).resolve().parents[1];D=ROOT/'data';G=ROOT/'graph'
SOURCE=pathlib.Path('/mnt/data/work_s3_v129/sources')
def rd(name):return json.loads((D/name).read_text())
def wr(name,v):(D/name).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
labels=['p10:def:hurwitz-shell-transfer-complex','p10:thm:hurwitz-shell-adjacency-spectrum',
 'p10:lem:hurwitz-cube-link-second-moment','p10:thm:finite-plaquette-hodge-curvature-hessian',
 'p10:lem:scalar-shell-dirichlet-kernel','p10:cor:exact-minimal-scalar-shell-moments',
 'p10:thm:hurwitz-shell-dirac-compression','p10:thm:hurwitz-trimer-color-carrier',
 'p10:cor:exceptional-shell-ancestry-of-qcd-delta','p11:thm:hurwitz-relative-support-lift',
 'p11:thm:finite-plaquette-hodge-curvature-hessian','p5:thm:v236-local-core-parent-indifference',
 'p5:thm:hurwitz-link-support-import','p8:thm:unique-2I-envelope']
files=['Paper7A-QCDKernel-v1_177.tex','Paper7D-TechnicalMaterial-v1_56.tex',
  'Paper5A-FiniteMatterGeometry-v3_212.tex','Paper6C-TechnicalMaterial-v1_51.tex']
W={}
for file in (files if all((SOURCE/f).exists() for f in files) else []):
 text=(SOURCE/file).read_text();sha=hashlib.sha256((SOURCE/file).read_bytes()).hexdigest()
 for label in labels:
  m=re.search(r'\\label\{'+re.escape(label)+r'\}',text)
  if m is None:continue
  if label in W:
   # A repeated theorem in Paper7D must remain a separate source witness.
   if label=='p10:thm:finite-plaquette-hodge-curvature-hessian':continue
   raise AssertionError((label,file,W[label]['file']))
  start=max(0,text.rfind('\\begin{',0,m.start()))
  W[label]={'claim_id':label,'file':file,'line':text[:m.start()].count('\n')+1,
     'tex_sha256':sha,'located_in_current_tex':True,'source_scope':'Current 2026-11-17 PapersMinimal-v3_028 original TeX',
     'statement_lead':re.sub(r'\s+',' ',text[start:m.start()]).strip()[:250]}
if not W:
 W=rd('batch18_current_tex_witnesses.json')['source_witnesses']
assert set(W)==set(labels),(set(labels)-set(W),set(W)-set(labels))
wr('batch18_current_tex_witnesses.json',{'source_witnesses':W,'notes':'Source labels/hashes are provenance, not graph vertices. The independent Hodge computation reproduces a theorem already present in VII-A.'})
O=rd('objects.json');R=rd('mathematical_relations.json');H=rd('joint_input_relations.json');C=rd('derived_compositions.json')
ids={o['id'] for o in O};rid={r['id'] for r in R};hid={h['id'] for h in H};cid={c['id'] for c in C}
verified='EXACT_MARKED_2T_CAYLEY_CELLULAR_AND_INTEGER_HODGE_V129'
source='SOURCE_ATTESTED_CURRENT_TEX_PARTIAL_GEOMETRY_V129'
guarded='GUARDED_SOURCE_MATHEMATICAL_CONSTRUCTION_NOT_A_PHYSICAL_MAP_V129'

def obj(short,name,typ,label,verification=verified):
 id='geo:g29:'+short
 if id not in ids:
  O.append({'id':id,'name':name,'object_type':typ,
   'scope':'mathematical_structure_or_morphism','source_kind':'exact_hurwitz_cellular_construction_v129',
   'conditional':verification==guarded,'batch':'v1_29','verification':verification,'witness':W[label]})
  ids.add(id)
 return id

shell=obj('2T_24cell_cayley_shell','24-cell 2T Cayley shell with eight nearest generators','finite_cayley_graph','p10:def:hurwitz-shell-transfer-complex')
adj=obj('shell_A24','Exact 24×24 Hurwitz Cayley adjacency A_H','integer_adjacency_operator','p10:thm:hurwitz-shell-adjacency-spectrum')
q8=obj('shell_Q8_C3_coset','Normal-Q8 quotient of the Hurwitz Cayley graph, weighted 4K3','finite_quotient_graph','p10:thm:hurwitz-shell-adjacency-spectrum')
pminus=obj('shell_P_minus4','Rank-two central C3 character projector in the −4 eigenspace','rational_spectral_projector','p10:thm:hurwitz-shell-adjacency-spectrum')
cube=obj('cube_tangent_moment','Exact eight cube-link tangent directions and (8/3)I moment','finite_local_tangent_tensor','p10:lem:hurwitz-cube-link-second-moment')
b1=obj('cellular_B1','Oriented 24×96 24-cell vertex/edge boundary ∂1','integer_cellular_boundary','p10:thm:finite-plaquette-hodge-curvature-hessian')
b2=obj('cellular_B2','Oriented 96×96 24-cell edge/face boundary ∂2','integer_cellular_boundary','p10:thm:finite-plaquette-hodge-curvature-hessian')
b3=obj('cellular_B3','Oriented 96×24 24-cell face/octahedron boundary ∂3','integer_cellular_boundary','p10:thm:finite-plaquette-hodge-curvature-hessian')
h2=obj('unit_Hodge2','Unit-weight cellular Hodge 2-Laplacian Δ2 on 96 faces','symmetric_integer_hodge_operator','p10:thm:finite-plaquette-hodge-curvature-hessian')
coex=obj('face_coexact73','Coexact face image im ∂2* of dimension 73','cellular_cochain_subspace','p10:thm:finite-plaquette-hodge-curvature-hessian')
ex=obj('face_exact23','Exact face image im ∂3 of dimension 23','cellular_cochain_subspace','p10:thm:finite-plaquette-hodge-curvature-hessian')
dual=obj('dual_24cell_selfadj','Dual octahedral facet adjacency isomorphic to primal 24-cell adjacency','finite_dual_polytope_incidence','p10:thm:finite-plaquette-hodge-curvature-hessian')
cohom=obj('cellular_H1_H2_zero','Oriented 24-cell cellular vanishing H¹=H²=0','topological_cohomology_invariant','p11:thm:finite-plaquette-hodge-curvature-hessian')
spec=obj('face_Hodge_spectral_bands','Exact unit-weight 96-face Hodge eigenband polynomial','integer_spectral_invariant','p10:thm:finite-plaquette-hodge-curvature-hessian')
quot2=obj('G2_Gdiag_G','Exact diagonal-left quotient 2T²/2T_diag ≅ 2T','quotient_group_action','p11:thm:hurwitz-relative-support-lift')
quot3=obj('G3_Gdiag_G2','Exact diagonal-left quotient 2T³/2T_diag ≅ 2T²','quotient_group_action','p11:thm:hurwitz-relative-support-lift')
dirac=obj('tangent_Dirac_principal','Cube-link Clifford principal-symbol normalization on the round S³ tangent space','local_spinorial_symbol','p10:thm:hurwitz-shell-dirac-compression')
trimer=obj('body_diagonal_split','Cube-link oriented body diagonal: 1+1+3+3 partition','finite_cubic_incidence','p10:thm:hurwitz-trimer-color-carrier')
normalized=obj('eight_nine_rank_ratio','Normalized scalar rank count 1/sqrt(8×9)','geometric_multiplicity_invariant','p10:cor:exceptional-shell-ancestry-of-qcd-delta')

# Hard-pure geometry morphisms; existing conditional entries connect only the
# explicitly verified mathematical suboperators, never the full physical claim.
links=[
('geo:hurwitz_units',shell,'UNIT_GROUP_AS_FINITE_CAYLEY_VERTEX_SET',verified),
('geo:24cell',shell,'SAME_MARKED_24CELL_VERTEX_EDGE_GEOMETRY',verified),
('geo:g16:hurwitz_24cell_chain',shell,'SAME_24_96_96_24_CELLULAR_COMPLEX',verified),
(shell,adj,'GROUP_CONVOLUTION_WITH_EIGHT_REAL_HALF_GENERATORS',verified),
('geo:24cell_bose_mesner',adj,'EIGHT_REGULAR_SHELL_ASSOCIATION_MATRIX',verified),
(adj,'geo:b8:shell_adjacency','EXACT_24CELL_ADJACENCY_POLYNOMIAL_SPECTRUM',verified),
(shell,'geo:b8:hurwitz_shell','EXPLICIT_CELLULAR_SHELL_MATH_PORTION_ONLY',source),
('geo:g13:right_q8',q8,'RIGHT_Q8_COSET_IDENTIFICATION_WITH_MARKED_2T',verified),
(shell,q8,'QUOTIENT_BY_NORMAL_Q8_SUBGROUP_OF_2T',verified),
(adj,q8,'EQUITABLE_3_BY3_ADJACENCY_4_J3_MINUS_I3',verified),
(q8,pminus,'CENTRAL_C3_CONTRAST_PROJECTOR',verified),
(adj,pminus,'MINUS_FOUR_ADJACENCY_EIGENPROJECTOR',verified),
('geo:hurwitz_cube_link',cube,'NORMALIZED_CUBE_LINK_TANGENT_DIRECTIONS',verified),
(shell,cube,'EIGHT_TANGENT_GENERATORS_AT_EACH_HURWITZ_VERTEX',verified),
(cube,'geo:b8:shell_cube_moment','EXACT_EIGHT_OVER_THREE_TANGENT_SECOND_MOMENT',verified),
('geo:g16:hurwitz_24cell_chain',b1,'ORIENT_96_VERTEX_EDGE_INCIDENCES',verified),
('geo:g16:hurwitz_24cell_chain',b2,'ORIENT_96_EDGE_FACE_INCIDENCES',verified),
('geo:g16:hurwitz_24cell_chain',b3,'ORIENT_24_FACE_OCTAHEDRON_INCIDENCES',verified),
(b1,b2,'CELLULAR_CHAIN_IDENTITY_PARTIAL1_PARTIAL2_ZERO',verified),
(b2,b3,'CELLULAR_CHAIN_IDENTITY_PARTIAL2_PARTIAL3_ZERO',verified),
(b2,h2,'FACE_HODGE_LOWER_TERM_PARTIAL2_STAR_PARTIAL2',verified),
(b3,h2,'FACE_HODGE_UPPER_TERM_PARTIAL3_PARTIAL3_STAR',verified),
(b2,coex,'RANK73_FACE_COEXACT_IMAGE',verified),
(b3,ex,'RANK23_FACE_EXACT_IMAGE',verified),
(coex,h2,'UNIT_WEIGHT_COEXACT_73_BAND',verified),
(ex,h2,'UNIT_WEIGHT_EXACT_23_BAND',verified),
(b1,cohom,'H1_VANISHES_FROM_BOUNDARY_RANKS',verified),
(b2,cohom,'H2_VANISHES_FROM_BOUNDARY_RANKS',verified),
(b3,cohom,'TOP_CELL_ORIENTATION_AND_ZERO_H2',verified),
(b3,dual,'DUAL_FACET_ADJACENCY_B3TRANSPOSE_B3',verified),
(adj,dual,'EXPLICIT_24_VERTEX_DUAL_FACET_GRAPH_ISOMORPHISM',verified),
(h2,spec,'UNIT_WEIGHT_EXACT_HODGE_CHARACTERISTIC_POLYNOMIAL',verified),
(spec,'geo:b8:plaquette_hodge','GEOMETRIC_FACE_HODGE_SPECTRAL_PART_ONLY',guarded),
(spec,'geo:b8:scalar_shell_moments','UNIT_WEIGHT_FINITE_HODGE_MOMENTS_ONLY',guarded),
(h2,'geo:b8:scalar_shell_hodge','RIESS_SPECTRAL_PROJECTOR_REQUIRES_CHOSEN_INTERVAL',guarded),
(cohom,'geo:b8:plaquette_hodge','LINEARIZED_H1_H2_ZERO_GAUGE_HODGE_RESULT_ONLY',guarded),
('geo:2t',quot2,'DIAGONAL_LEFT_ACTION_ON_2T_SQUARED',verified),
('geo:2t',quot3,'DIAGONAL_LEFT_ACTION_ON_2T_CUBED',verified),
(quot2,'geo:b8:relative_hurwitz','RELATIVE_COORDINATE_X_INV_Y_ON_DOUBLE_SUPPORT',verified),
(quot3,'geo:b8:relative_hurwitz','RELATIVE_COORDINATE_X1_INV_X2_X1_INV_X3',verified),
(shell,'geo:b8:relative_hurwitz','CLASS_CONVOLUTION_OVER_HURWITZ_GROUP_LAW',verified),
(cube,dirac,'CLIFFORD_SYMBOL_ISOTROPY_FROM_8_OVER_THREE_TENSOR',verified),
('geo:clifford_03',dirac,'SCOPED_ROUND_S3_TANGENT_CLIFFORD_SYMBOL',source),
(dirac,'geo:b8:hurwitz_dirac','LOCAL_PRINCIPAL_SYMBOL_ONLY_REQUIRES_SPIN_TRANSPORT',guarded),
(cube,trimer,'CHOICE_OF_ORIENTED_CUBE_BODY_DIAGONAL_1_1_3_3',verified),
(trimer,'geo:b8:trimer_color','MATHEMATICAL_TRIMER_FINITE_SUPPORT_ONLY',guarded),
(trimer,'geo:b6:hurwitz_link_support','MATHEMATICAL_LINK_TRIMER_SUPPORT_ONLY',guarded),
('geo:2t','geo:b6:tetrahedral_core_factor','LOCAL_CORE_PARENT_INDEPENDENT_GROUP_CARRIER_ONLY',source),
('geo:2o','geo:b6:tetrahedral_core_factor','TETRAHEDRAL_NORMAL_SUBGROUP_2T_OF_2O',verified),
('geo:2i','geo:b6:tetrahedral_core_factor','FIVE_CONJUGATE_TETRAHEDRAL_SUBGROUPS',verified),
('geo:2i','geo:b7:icosahedral_projector_comb','FINITE_2I_GROUP_AVERAGE_ON_HARMONIC_SECTORS_ONLY',source),
('geo:g14:molien_2i','geo:b7:icosahedral_projector_comb','MOLIEN_ONSET_AND_SPARSE_INVARIANT_HARMONIC_BANDS',source),
(adj,normalized,'USE_RANKS_NINE_AND_EIGHT_OF_HURWITZ_SHELL',verified),
(normalized,'geo:b8:exceptional_delta','GEOMETRIC_NORMALIZED_COUNT_ONLY_NO_PHYSICAL_SCALE',source),
]

# In older geometry graph the tangent Clifford has a different canonical name.
for j,link in enumerate(links):
 a,b,rel,ver=link
 if a=='geo:clifford_03' and a not in ids:
  # Find validated mathematical Clifford R3 source construction, not a guess.
  links[j]=('geo:clifford_tangent',b,rel,ver)

for ix,(a,b,rel,ver) in enumerate(links,1):
 assert a in ids and b in ids,(ix,a,b)
 rid0=f'G29-{ix:03d}'
 if rid0 in rid: continue
 entry={'id':rid0,'from':a,'to':b,'relation':rel,
        'link_type':'explicit_finite_group_cellular_map_or_conditioned_operator_port',
        'batch':'v1_29','verification':ver,'conditions_preserved':True}
 if ver==guarded:
  entry['requires_joint_inputs']=[i for i in (shell,h2,cube) if i in ids]
 R.append(entry);rid.add(rid0)

bundles=[
('01',[shell,adj,q8],[pminus],['Same marked 2T group and Q8 normal subgroup','Cayley neighbors are the eight quaternion elements of real part +1/2','No physical interpretation of the -4 eigenmode']),
('02',[b1,b2,b3],[h2,cohom],['All boundaries use one global orientation of the 24-cell','Unweighted real cellular cochains; positive unit inner products','Do not identify with arbitrary weighted Hodge or interacting Yang--Mills Hessians']),
('03',[h2,coex,ex],[spec],['Exact 73+23 face decomposition','Spectral polynomial of this specific 96x96 integer operator','No new dynamical mass or scale from the smallest eigenvalue']),
('04',[cube,'geo:clifford_03' if 'geo:clifford_03' in ids else 'geo:clifford_tangent'],[dirac,'geo:b8:hurwitz_dirac'],['Cube local directions must be measured in one quaternionic tangent frame','The Clifford principal-symbol part uses the source-selected spin parallel transport','Remainder/error control is source-attested, not inferred from the second-moment check']),
('05',[trimer,'geo:hurwitz_cube_link'],['geo:b8:trimer_color','geo:b6:hurwitz_link_support'],['Choose an oriented cube body diagonal (not canonical without marking)','The 1+1+3+3 partition is finite geometry, not a physical color or matter occurrence']),
('06',[shell,quot2,quot3],['geo:b8:relative_hurwitz'],['Quotient is by simultaneous left multiplication','Relative coordinates x^-1y and (x1^-1x2,x1^-1x3)','Actual convolution kernel eigenvalues depend on supplied class kernels']),
('07',['geo:2t','geo:2o','geo:2i'],['geo:b6:tetrahedral_core_factor'],['A fixed same-owner 2T inside given exceptional parent','Only the group-theoretic factorization is admitted','No assertion that physical state/representation incidence is parent-independent without additional source conditions']),
('08',['geo:2i','geo:g14:molien_2i'],['geo:b7:icosahedral_projector_comb'],['Exact invariant-projector selection for marked 2I','No smooth envelope E(k) follows from Molien/onset alone']),
('09',[spec,h2],['geo:b8:scalar_shell_hodge','geo:b8:scalar_shell_moments'],['Specific unweighted 24-cell face Hodge Laplacian','Any spectral band I must be explicitly specified','Not a physical scalar mass, source-visible pole, or unique mode selection']),
]
for nn,inputs,outputs,conditions in bundles:
 name='HYP-G29-'+nn
 assert all(i in ids for i in inputs+outputs),(nn,set(inputs+outputs)-ids)
 if name not in hid:
  H.append({'id':name,'kind':'typed_joint_math_input_guard','inputs':inputs,'outputs':outputs,
            'conditions':conditions,'verification':guarded,'batch':'v1_29'});hid.add(name)
comps=[
 ('01','24cell Cayley central class and Q8 quotient',
  'A_H=Cayley(2T,S_Re=1/2); quotient_Q8 A=4(J3-I3); P_minus4(q,r)=(3*1_{qQ8=rQ8}-1)/24',
  'Exact multiplication-table, left/right invariance, quotient equity and rank2 projector checks. Adjacent 2T classes split into two 4-element cosets.',['p10:thm:hurwitz-shell-adjacency-spectrum']),
 ('02','Cube link first and second moments','sum_dir n=0, sum_dir n n^T=(8/3)I3',
  'At every one of 24 vertices the eight relative quaternion directions are all sign triples; integer scaled Gram is exactly 8I.',['p10:lem:hurwitz-cube-link-second-moment']),
 ('03','24cell exact cellular chain and cohomology','rank(∂1,∂2,∂3)=(23,73,23), ∂1∂2=0, ∂2∂3=0, H¹=H²=0',
  'Independent oriented boundary construction from 24,96,96,24 incidence; modular rank and maximal rank bounds prove rational ranks.',['p10:thm:finite-plaquette-hodge-curvature-hessian','p11:thm:finite-plaquette-hodge-curvature-hessian']),
 ('04','Exact unit-weight 96-face Hodge spectral decomposition',
  'χ_D2=(x-1)^6(x-2)^16(x-4)^16(x-5)^16(x-8)^13(x-9)(x-10)^8(x-12)^2(x²-9x+16)^9',
  'Independent exact SymPy characteristic polynomial and integer boundary checks; same formula is already explicitly present in current Paper VII-A.',['p10:thm:finite-plaquette-hodge-curvature-hessian']),
 ('05','Dual 24cell facet/vertex Laplacian equivalence','∂3ᵀ∂3=8I-A_dual; A_dual ≅ A_H as 24-vertex graphs',
  'All facets share octahedral faces with sign -1 and have degree8. Exact adjacency isomorphism permutation stored.',['p10:thm:finite-plaquette-hodge-curvature-hessian']),
 ('06','Cellular Hodge exact/coexact 73+23 spectral splitting',
  'Spec_nonzero(B2ᵀB2)=Spec_nonzero(B2B2ᵀ), rank73; Spec_nonzero(B3B3ᵀ)=Spec_nonzero(B3ᵀB3), rank23',
  'Exact characteristic polynomials, zero kernel and positive eigenvalues. These are unweighted cellular operators only.',['p10:thm:finite-plaquette-hodge-curvature-hessian']),
 ('07','Hurwitz two/three-support relative quotient','G²/Gdiag≈G via x^-1y; G³/Gdiag≈G² via (x1^-1x2,x1^-1x3)',
  'Exact group multiplication and invariance of relative coordinates under all 24 simultaneous left actions; no transfer kernel normalized.',['p11:thm:hurwitz-relative-support-lift']),
 ('08','Local Clifford principal symbol from cube isotropy','(3/8)*Σ_(n in cube) n_a n_b=δ_ab',
  'Verified quaternion tangent second moments and standard Clifford linearity. The full spinorial remainder still needs source-specified transport and smoothness.',['p10:thm:hurwitz-shell-dirac-compression']),
 ('09','Local Hurwitz body diagonal decomposition','N(q)={u+,u-} ∪ T+ ∪ T-, with |T+|=|T-|=3',
  'Exact eight sign triples classified by Hamming weight relative to chosen oriented body diagonal; no physical color identification.',['p10:thm:hurwitz-trimer-color-carrier']),
 ('10','Exceptional 2I finite comb vs smooth envelope obstruction','Finite 2I Molien projector constrains discrete invariant harmonics, not an arbitrary regular positive E(k)',
  'Source mathematics explicitly separates a non-generated smooth envelope from the 2I projector. No arbitrary decay profile added.',['p8:thm:unique-2I-envelope']),
]
for nn,name,formula,proof,claims in comps:
 key='D29-'+nn
 if key not in cid:
  C.append({'id':key,'name':name,'formula':formula,'hypotheses':['Fixed marked quaternionic 2T/2I and strict geometry only'],
     'proof':proof,'source_premises':claims,'status':verified if nn not in ('08','10') else source,
     'batch':'v1_29'});cid.add(key)
wr('objects.json',O);wr('mathematical_relations.json',R);wr('joint_input_relations.json',H);wr('derived_compositions.json',C)
wr('hurwitz_cellular_v129_instance.json',math_build())
wr('v129_release_counts.json',{'version':'v1_29','parent':'v1_28','new_objects':sum(o.get('batch')=='v1_29' for o in O),
     'new_typed_relations':sum(e.get('batch')=='v1_29' for e in R),
     'new_joint_inputs':sum(h.get('batch')=='v1_29' for h in H),
     'new_compositions':sum(c.get('batch')=='v1_29' for c in C),
     'cumulative_objects':len(O),'cumulative_edges':len(R),'cumulative_joint_inputs':len(H),'cumulative_compositions':len(C)})

NS='http://graphml.graphdrawing.org/xmlns';ET.register_namespace('',NS);tag=lambda x:'{'+NS+'}'+x
def export(path,obs,eds,gid):
 r=ET.Element(tag('graphml'))
 for key,kind,attr in [('d0','node','label'),('d1','node','kind'),('d2','node','batch'),('d3','node','verification'),('d4','edge','id'),('d5','edge','relation'),('d6','edge','verification'),('d7','edge','requires_and_inputs')]:
  ET.SubElement(r,tag('key'),{'id':key,'for':kind,'attr.name':attr,'attr.type':'string'})
 g=ET.SubElement(r,tag('graph'),{'id':gid,'edgedefault':'directed'})
 for o in obs:
  n=ET.SubElement(g,tag('node'),{'id':o['id']})
  for k,v in [('d0',o['name']),('d1',o['object_type']),('d2',o.get('batch','')),('d3',o.get('verification',''))]: ET.SubElement(n,tag('data'),{'key':k}).text=str(v)
 for e0 in eds:
  e=ET.SubElement(g,tag('edge'),{'id':e0['id'],'source':e0['from'],'target':e0['to']})
  for k,v in [('d4',e0['id']),('d5',e0['relation']),('d6',e0.get('verification','')),('d7',','.join(e0.get('requires_joint_inputs',[])))]:ET.SubElement(e,tag('data'),{'key':k}).text=str(v)
 ET.ElementTree(r).write(path,encoding='utf-8',xml_declaration=True)
export(G/'mathematical_structure_network.graphml',O,R,'S3_geometric_only_v129')
new=[e for e in R if e.get('batch')=='v1_29'];used={e['from'] for e in new}|{e['to'] for e in new}
export(G/'batch18_hurwitz_cellular_hodge_relatives.graphml',[o for o in O if o['id'] in used],new,'S3_batch18_Hurwitz_cellular')
# Add only an abstract quotient graph (this is *not* a 600cell graph covering).
source=rd('hurwitz_cellular_v129_instance.json')['hurwitz_group']['q8_quotient_adjacency']
r=ET.Element(tag('graphml'));ET.SubElement(r,tag('key'),{'id':'d0','for':'edge','attr.name':'multiplicity','attr.type':'int'})
g=ET.SubElement(r,tag('graph'),{'id':'2T_to_Q8_C3_quotient','edgedefault':'undirected'})
for k in range(3):ET.SubElement(g,tag('node'),{'id':f'Q8coset_{k}'})
for i in range(3):
 for j in range(i+1,3):
  e=ET.SubElement(g,tag('edge'),{'id':f'{i}-{j}','source':f'Q8coset_{i}','target':f'Q8coset_{j}'})
  ET.SubElement(e,tag('data'),{'key':'d0'}).text=str(source[i][j])
ET.ElementTree(r).write(G/'batch18_hurwitz_Q8_weighted_three_graph.graphml',encoding='utf-8',xml_declaration=True)
print(json.dumps(rd('v129_release_counts.json'),indent=2))
