#!/usr/bin/env python3
"""Install only actual Petersen 5/6 modules and verified finite A5 geometric maps."""
from pathlib import Path
import json,hashlib,xml.etree.ElementTree as ET
from . import petersen_five_six_v125 as reg
ROOT=Path(__file__).resolve().parents[1]
load=lambda p:json.loads((ROOT/'data'/p).read_text())
def dump(p,x): (ROOT/'data'/p).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
cert=reg.build();dump('petersen_five_six_v125_instance.json',cert)
O=load('objects.json');E=load('mathematical_relations.json');H=load('joint_input_relations.json');C=load('derived_compositions.json')
assert (len(O),len(E),len(H),len(C))==(740,1001,123,109)
oldid={o['id'] for o in O}; norm='EXACT_PETERSEN_A5_5_6_MAPS_V125';batch='v1_25'
witness={'source_premises':['p1:thm:v338-signed-petersen-hodge','p1:thm:v339-petersen-sl4-isometry','p1:thm:v340-incidence-character-projectors'],
  'parent_geometry_release':'v1_24','exact_certificate':'data/petersen_five_six_v125_instance.json',
  'verification_script':'verify_petersen_five_six_v125.py',
  'conditions':'one marked 2I/2T/Q8 with actual left A5 and right C3 actions, one of three equivariant unsigned-edge identifications'}
new_defs=[
 ('vertex_P5','Petersen 10-vertex five-dimensional A5 isotypic projector P_v5','rational_projector'),
 ('vertex_edge_U5','Normalized rank-five vertex-to-oriented-edge boundary isometry DᵀP_v5/√2','equivariant_partial_isometry'),
 ('unoriented_edges15','Fifteen unoriented Petersen edge support lines (unsigned A5 permutation module)','finite_A5_permutation_module'),
 ('unsigned_endpoint_E','Unsigned Petersen edge-to-endpoint incidence E=|D|ᵀ (15×10)','integer_incidence_operator'),
 ('three_axis_edge_maps','Exactly three equivariant bijections between 15 Hopf axes and 15 unoriented Petersen edges','equivariant_bijection_torsor'),
 ('axis_edge_U','Chosen A5-equivariant axis-to-unoriented-edge permutation U (15×15)','exact_permutation_isomorphism'),
 ('axis5_embed_A','Quintet embedding A=UEP_v5 into fifteen Hopf axes','rational_equivariant_operator'),
 ('axis5_first_P','First rank-five axis projector P_A=AAᵀ/4','rational_projector'),
 ('axis5_rotated_Aprime','Orthogonal second quintet embedding A′=(2C3+I)A','equivariant_operator'),
 ('axis5_second_P','Second rank-five axis projector P_Aprime=A′A′ᵀ/12','rational_projector'),
 ('edge5_to_axis5_X0','Rank-five Petersen-edge-to-axis intertwiner X0=AD','equivariant_partial_isometry'),
 ('edge5_to_axis5_X1','Independent rank-five Petersen-edge-to-axis intertwiner X1=A′D','equivariant_partial_isometry'),
 ('signed_edge_wedge_W6','Alternating wedge of centred Petersen endpoints W6 : signed edges to Λ²R⁵','integer_exterior_product_map'),
 ('hodge_nonzero_P6','Rank-six projector S²/5 onto nonzero signed exterior-Hodge eigenspaces','rational_projector'),
 ('edge6_hodge_pullback','Half-integral 15×15 pulled-back Petersen six-sector Hodge H6=W6ᵀSW6/1250','finite_selfadjoint_Hodge_operator'),
 ('A5_Hom_space3','Three-dimensional Hom_A5(signed Petersen 15-edge, Hopf axis 15) intertwiner space','finite_representation_intertwiner_space'),
 ('max_rank9_map','Explicit maximal-rank-nine equivariant partial isometry combining four and one five sector','equivariant_partial_isometry'),
 ('no_edge6_axis_map','Zero-dimensional Hom_A5(Petersen six-sector, axis permutation module)','representation_theoretic_no_go_space'),
 ('axis5_spectral','Common quintet spectral eigenspaces of Q600=0 and weighted E8 Gram=164','joint_spectral_sector'),
]
new=[]
for sid,name,typ in new_defs:
    new.append({'id':'geo:g25:'+sid,'name':name,'batch':batch,'object_type':typ,
      'scope':'mathematical_structure_or_morphism','source_kind':'independently_derived_exact_geometry_from_existing_marked_input',
      'conditional':True if sid in ('axis_edge_U','axis5_embed_A','axis5_first_P','axis5_rotated_Aprime','axis5_second_P','edge5_to_axis5_X0','edge5_to_axis5_X1','max_rank9_map') else False,
      'verification':norm,'witness':witness})
assert len(new)==19
all_ids=oldid|{n['id'] for n in new}
def nid(s):return s if s.startswith('geo:') else 'geo:g25:'+s
links=[
 ('geo:g24:petersen_boundary_D','vertex_edge_U5','NORMALIZED_FIVE_SECTOR_GRADIENT'),
 ('geo:g24:petersen_Pe5','vertex_edge_U5','IMAGE_PROJECTOR_PETERSEN5'),
 ('vertex_P5','vertex_edge_U5','DOMAIN_PROJECTOR_VERTEX5'),
 ('geo:g24:petersen_boundary_D','unsigned_endpoint_E','REMOVE_ORIENTATION_SIGNS_TO_GET_ENDPOINT_SUPPORT'),
 ('unsigned_endpoint_E','unoriented_edges15','UNDERLYING_UNORIENTED_EDGE_SUPPORT'),
 ('geo:g24:axis15_actual_A5_action','three_axis_edge_maps','FIFTEEN_POINT_A5_SET_CORRESPONDENCE'),
 ('unoriented_edges15','three_axis_edge_maps','THREE_EQUIVARIANT_IDENTIFICATIONS'),
 ('three_axis_edge_maps','axis_edge_U','CHOOSE_ONE_BIJECTION_OF_THREE_C3_RELATED_MATCHINGS'),
 ('axis_edge_U','axis5_embed_A','TRANSPORT_UNSIGNED_PETERSEN_ENDPOINT_GEOMETRY'),
 ('unsigned_endpoint_E','axis5_embed_A','INCIDENCE_EMBEDDING_OF_PETERSEN_VERTEX5'),
 ('vertex_P5','axis5_embed_A','PROJECT_TO_FIVE_DIMENSIONAL_SOURCE'),
 ('axis5_embed_A','axis5_first_P','GRAM_PROJECTOR_A_AT_A_OVER_FOUR'),
 ('geo:g22:residual_C3_deck_action','axis5_rotated_Aprime','RIGHT_C3_ROTATION_COMMUTES_WITH_LEFT_A5'),
 ('axis5_embed_A','axis5_rotated_Aprime','ORTHOGONALIZE_SECOND_C3_ROTATED_COPY'),
 ('axis5_rotated_Aprime','axis5_second_P','ORTHOGONAL_RANKFIVE_GRAM_PROJECTOR'),
 ('axis5_first_P','axis5_second_P','ORTHOGONAL_QUINTETS_SUM_TO_TEN_BLOCK_CONTRAST'),
 ('vertex_edge_U5','edge5_to_axis5_X0','COMPOSE_VERTEX_FIVE_WITH_AXIS_FIRST_QUINTET'),
 ('axis5_embed_A','edge5_to_axis5_X0','ISOMETRY_TO_FIRST_AXIS_QUINTET'),
 ('vertex_edge_U5','edge5_to_axis5_X1','COMPOSE_VERTEX_FIVE_WITH_SECOND_QUINTET'),
 ('axis5_rotated_Aprime','edge5_to_axis5_X1','ISOMETRY_TO_SECOND_AXIS_QUINTET'),
 ('geo:g24:core_pair_C5','signed_edge_wedge_W6','ALTERNATING_WEDGE_OF_CENTERED_VERTEX_PAIRS'),
 ('geo:g24:petersen_signed_A5_action','signed_edge_wedge_W6','SIGNED_EDGE_A5_EQUIVARIANT_WEDGE'),
 ('geo:g24:exterior_wedge_A5_action','signed_edge_wedge_W6','EXTERIOR_A5_ACTION_INTERTWINED_BY_WEDGE'),
 ('geo:g16:signed_exterior_hodge5','hodge_nonzero_P6','NONZERO_HODGE_SQUARED_PROJECTOR_S2_OVER_FIVE'),
 ('signed_edge_wedge_W6','hodge_nonzero_P6','EXACT_RANKSIX_WEDGE_RANGE'),
 ('geo:g24:petersen_Pe6','signed_edge_wedge_W6','EXACT_RANKSIX_WEDGE_SOURCE'),
 ('signed_edge_wedge_W6','edge6_hodge_pullback','TRANSPORT_HODGE_TO_SIGNED_EDGE_SIX_SECTOR'),
 ('geo:g16:signed_exterior_hodge5','edge6_hodge_pullback','SIX_SECTOR_HODGE_SPECTRAL_SPLITTING'),
 ('geo:g24:petersen_Pe5','A5_Hom_space3','COMMON_IRREP_QUINTET_GIVES_TWO_INTERTWINERS'),
 ('geo:g24:petersen_Pe4','A5_Hom_space3','COMMON_IRREP_FOUR_GIVES_ONE_INTERTWINER'),
 ('edge5_to_axis5_X0','A5_Hom_space3','FIRST_OF_TWO_FIVE_INTERTWINERS'),
 ('edge5_to_axis5_X1','A5_Hom_space3','SECOND_OF_TWO_FIVE_INTERTWINERS'),
 ('geo:g24:T_edge_to_axis','A5_Hom_space3','FOUR_INTERTWINER_COMPLETES_HOM_BASIS'),
 ('A5_Hom_space3','no_edge6_axis_map','CHARACTER_ORTHOGONALITY_FORBIDS_SIX_TO_AXIS'),
 ('geo:g24:petersen_Pe6','no_edge6_axis_map','SIX_EQUALS_THREE_PLUS_THREE_PRIME'),
 ('edge5_to_axis5_X0','max_rank9_map','ORTHOGONAL_COMPOSITION_WITH_FOUR_INTERTWINER'),
 ('geo:g24:T_edge_to_axis','max_rank9_map','MAXIMAL_EQUIVARIANT_RANK_FOUR_PLUS_FIVE'),
 ('max_rank9_map','no_edge6_axis_map','EXACT_NONGOAL_FULL_FIFTEEN_ISOMETRY'),
 ('geo:g20:A600_left_axis_operator','axis5_spectral','EIGENVALUE_ZERO_ON_TWO_QUINTETS'),
 ('geo:g21:slice_gram_operator','axis5_spectral','EIGENVALUE_164_ON_TWO_QUINTETS'),
 ('edge5_to_axis5_X0','axis5_spectral','QUINTET_SPECTRAL_OPERATOR_BRIDGE'),
 ('edge5_to_axis5_X1','axis5_spectral','SECOND_QUINTET_SPECTRAL_OPERATOR_BRIDGE'),
]
assert len(links)==42,len(links)
new_edges=[]
for i,(a,b,r) in enumerate(links,1):
 a,b=nid(a),nid(b)
 assert a in all_ids and b in all_ids and a!=b,(i,a,b)
 new_edges.append({'id':f'G25-{i:03d}','from':a,'to':b,'relation':r,
 'link_type':'exact_A5_equivariant_Petersen_5_6_incidence_Hodge_Hopf_morphism',
 'conditions_preserved':True,'requires_joint_inputs':[],'verification':norm})
inputs=[
 (['geo:g24:petersen_boundary_D','vertex_P5'],['vertex_edge_U5'],'The oriented Petersen boundary identifies the ten-vertex 5 with signed edge-5 by partial isometry'),
 (['unsigned_endpoint_E','geo:g24:axis15_actual_A5_action','geo:g24:petersen_signed_A5_action'],['three_axis_edge_maps'],'The two unsigned 15-point permutation sets have exactly three marked A5-equivariant bijections'),
 (['three_axis_edge_maps','vertex_P5','unsigned_endpoint_E'],['axis5_embed_A'],'Chosen unsigned edge matching and endpoint support map construct a first axis quintet'),
 (['axis5_embed_A','geo:g22:residual_C3_deck_action'],['axis5_rotated_Aprime'],'Right C3 rotation produces orthogonal second 5-dimensional target copy'),
 (['vertex_edge_U5','axis5_embed_A','axis5_rotated_Aprime'],['edge5_to_axis5_X0','edge5_to_axis5_X1'],'Normalized compositions give two independent A5-equivariant rank-five edge-to-axis maps'),
 (['geo:g24:core_pair_C5','geo:g24:petersen_Pe6','geo:g16:signed_exterior_hodge5'],['signed_edge_wedge_W6','edge6_hodge_pullback'],'Wedge of centred endpoints yields rank-six partial isometry and pulled-back Hodge'),
 (['geo:g24:T_edge_to_axis','edge5_to_axis5_X0','edge5_to_axis5_X1'],['A5_Hom_space3','max_rank9_map'],'Character inner products show three-dimensional Hom space, with explicit independent 4+5+5 maps and maximal rank 9'),
 (['geo:g24:petersen_Pe6','geo:g24:axis15_actual_A5_action'],['no_edge6_axis_map'],'Different irreducible sectors imply no nonzero A5-equivariant six-to-axis map'),
 (['edge5_to_axis5_X0','edge5_to_axis5_X1','geo:g20:A600_left_axis_operator','geo:g21:slice_gram_operator'],['axis5_spectral'],'Both axis quintets have Q600 eigenvalue 0 and E8 Gram eigenvalue 164'),
]
new_h=[{'id':f'HYP-G25-{i:02d}','kind':'exact_finite_mathematical_multi_input_construction',
        'inputs':[nid(x) for x in a],'outputs':[nid(x) for x in b],
        'conditions':['Marked one-branch 2I/2T/Q8 and actual left A5, right C3; one of three equivariant axis-edge matchings selected where relevant',
                      'All sectors are defined using the actual rational Hodge/projector matrices, not assumed by equal dimensions'],
        'output_statement':c,'verification':norm} for i,(a,b,c) in enumerate(inputs,1)]
formula=[
 ('Petersen vertex-to-edge five-sector gradient','P_v5=I10-J10/10-C5 C5^T/75; P_edge5=D^T P_v5 D/2','D D^T=3I-A_Petersen, eigenvalue 1 on vertex5, so D^T P_v5/√2 is an isometry'),
 ('Natural alternating centred incidence and six-dimensional Hodge bridge','W6(e)=(C5)_A ∧ (C5)_B; W6^T W6=1250 P_edge6; W6 W6^T=250 S^2','Explicit 10x15 integer wedge; rank6; W6/(25√2) is a partial isometry onto the nonzero Hodge eigenspaces'),
 ('Six-sector signed Petersen Hodge transported to 15-edge module','H_edge6=W6^T S W6/1250, H_edge6^2=5 P_edge6, H_edge6^3=5 H_edge6','Half-integral symmetric 15x15, nonzero eigenvalues ±√5 each multiplicity3'),
 ('Equivariant unsigned edge/axis matching torsor','Exactly three bijections U: axes15 → unoriented Petersen edges15 commuting with all A5 permutations','Enumerate all 60 even permutations in marked 2I action; stabilizer-compatible bijections are exactly three'),
 ('Axis quintet resolution by right C3','A=U |D|^T P_v5, A^T A=4P_v5; A_prime=(2C3+I)A, A_prime^T A_prime=12P_v5, A^T A_prime=0','Rank5 orthogonal projectors AA^T/4 + A_prime A_prime^T/12 = I15-RR^T/3'),
 ('Two rank-five signed Petersen-to-axis maps','X0=A D; X1=A_prime D; X0^T X0=8P_edge5, X1^T X1=24P_edge5, X0^T X1=0','Normalized X0/√8 and X1/(2√6) have orthogonal axis quintet images, intertwining all 60 A5 elements'),
 ('Exact Hom dimension and no-go for six-sector to axis','Hom_A5(E15,Axis15) has real dimension 3, Hom_A5(E6,Axis15)=0; maximal rank9','Character values by element order: E15=(15,-1,0,0), Axis=(15,3,0,0); inner product 3; E6=(6,-2,0,1) pairs to 0'),
 ('Common 600-cell and E8 Gram quintet eigenoperators','Q600 X0=Q600 X1=0; G_E8 X0=164 X0, G_E8 X1=164 X1','Exact rational matrices, no physics; complementary to rank4 Petersen T with Q600=-3 and G_E8=296'),
]
new_c=[{'id':f'D25-{i:02d}','name':n,'formula':f,'hypotheses':['one fixed marked 2I/2T/Q8, orientation of signed edges and 10-pair Hodge, one of three axis matchings where selected',
     'pure representation and incidence geometry'], 'proof':pr,'status':norm,
     'independent_checks':['verify_petersen_five_six_v125.py','verify_graph_exports.py'],
     'source_premises':witness['source_premises']} for i,(n,f,pr) in enumerate(formula,1)]
O+=new;E+=new_edges;H+=new_h;C+=new_c
assert (len(O),len(E),len(H),len(C))==(759,1043,132,117)
for n,x in [('objects.json',O),('mathematical_relations.json',E),('joint_input_relations.json',H),('derived_compositions.json',C)]:dump(n,x)
# Properly declared graph attributes; no proof nodes or source-citation edges.
ns='http://graphml.graphdrawing.org/xmlns';ET.register_namespace('',ns)
def tag(s):return '{'+ns+'}'+s
def graphml(path,nodes,edges,name):
 root=ET.Element(tag('graphml'))
 for typ,attr,k in [('node','label','d0'),('node','kind','d1'),('node','batch','d2'),('node','verification','d3'),('edge','id','d4'),('edge','relation','d5'),('edge','verification','d6'),('edge','requires_and_inputs','d7')]:
  ET.SubElement(root,tag('key'),{'id':k,'for':typ,'attr.name':attr,'attr.type':'string'})
 graph=ET.SubElement(root,tag('graph'),{'id':name,'edgedefault':'directed'})
 for o in nodes:
  elem=ET.SubElement(graph,tag('node'),{'id':o['id']})
  for k,v in [('d0',o['name']),('d1',o['object_type']),('d2',o.get('batch','')),('d3',o['verification'])]:ET.SubElement(elem,tag('data'),{'key':k}).text=str(v)
 for e in edges:
  elem=ET.SubElement(graph,tag('edge'),{'id':e['id'],'source':e['from'],'target':e['to']})
  for k,v in [('d4',e['id']),('d5',e['relation']),('d6',e['verification']),('d7',','.join(e.get('requires_joint_inputs',[])))]:ET.SubElement(elem,tag('data'),{'key':k}).text=str(v)
 ET.ElementTree(root).write(path,encoding='utf-8',xml_declaration=True)
graphml(ROOT/'graph/mathematical_structure_network.graphml',O,E,'S3_mathematical_geometry_v125')
used={e['from'] for e in new_edges}|{e['to'] for e in new_edges}
graphml(ROOT/'graph/batch14_Petersen_A5_five_six_completions.graphml',[o for o in O if o['id'] in used],new_edges,'Batch14_Petersen_A5_five_six')
# Display the actual nonzero signed wedge coefficients, not theorem nodes.
W=cert['matrices']['signed_edge_to_exterior_wedge_W6_10x15'];S=cert['matrices']['signed_petersen5_to_axis5_X0_15x15']
for short,M,rowlabel,collabel in [('wedge6',W,'exterior_pair','oriented_edge'),('axis5',S,'hopf_axis','oriented_edge')]:
 N=[{'id':f'{rowlabel}:{i}','name':f'{rowlabel} {i}','object_type':'incidence_matrix_row','batch':batch,'verification':norm} for i in range(len(M))]
 N +=[{'id':f'{collabel}:{j}','name':f'{collabel} {j}','object_type':'incidence_matrix_column','batch':batch,'verification':norm} for j in range(len(M[0]))]
 Ee=[{'id':f'{short}:{i}:{j}','from':f'{rowlabel}:{i}','to':f'{collabel}:{j}','relation':f'COEFFICIENT={v}', 'verification':norm,'requires_joint_inputs':[]}
    for i,row in enumerate(M) for j,v in enumerate(row) if str(v)!='0']
 graphml(ROOT/f'graph/batch14_actual_{short}_matrix.graphml',N,Ee,f'Batch14_actual_{short}_matrix')
reportcounts={'parent':'v1_24','version':'v1_25','new_objects':19,'new_typed_relations':42,'new_joint_inputs':9,'new_derived_compositions':8,
 'cumulative_objects':len(O),'cumulative_edges':len(E),'cumulative_joint_inputs':len(H),'cumulative_compositions':len(C)}
dump('v125_release_counts.json',reportcounts)
print('INSTALLED',reportcounts,'focused graph nodes',len(used))
