#!/usr/bin/env python3
"""Idempotent v1_27 installation: geometry-only operator bridges and gap audit.

Run as: python -m scripts.install_batch16_v127
The explicit current-TeX witnesses are stored in data/batch16_source_witnesses.json,
so a released ZIP can be independently regenerated without paper bytes.
"""
from __future__ import annotations
import json,pathlib,xml.etree.ElementTree as ET
from .geometry_bridges_v127 import build
ROOT=pathlib.Path(__file__).resolve().parents[1];D=ROOT/'data';G=ROOT/'graph'
def rd(f):return json.loads((D/f).read_text())
def wr(f,x):(D/f).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
W=rd('batch16_source_witnesses.json')['source_witnesses']
exact='EXACT_QUATERNION_MATRIX_POLYNOMIAL_OR_FINITE_INCIDENCE_V127'
conditional='CURRENT_SOURCE_DEFINED_MATHEMATICAL_CONSTRUCTION_CONDITIONAL_V127'
source='CURRENT_SOURCE_ATTESTED_MATHEMATICAL_RELATION_NOT_FULLY_REPROVED_V127'

newO=[
 ('clifford_projector_sources','Even-Clifford projector tangent T,S,J with normalized real trace','representation_or_clifford','p3c:thm:v179-clifford-projector-tangent',exact),
 ('protected_carrier_grading','Four-block 8D protected Clifford carrier grading Q0,Q4,Q5,Q7','orthogonal_operator_decomposition','p3c:thm:v179-balanced-hierarchy-response',exact),
 ('petersen_Kflux','Exact fifteen-edge Petersen quaternionic flux matrix K','finite_incidence_operator','p1:thm:petersen-signed-and-flux',exact),
 ('petersen_Krank2','Fixed-axis transverse Petersen flux Gram of rank two','finite_incidence_operator','p3c:cor:v371-petersen-e36-comparison',exact),
 ('m8_hodge_exchange_Betti','Kunneth Hodge and graded-exchange Lefschetz polynomial on M8','topology_or_cohomology','p1b:thm:exchange-heat',exact),
 ('covariant_connection_casimir','SU2 coupling Casimir for supplied connection A_f=f Theta','spectrum_or_operator','p1b:thm:covariant-spectrum',exact),
 ('ray_CP1_explicit','Degree-one C2 projective Hopf map S3 to CP1=S2','differential_geometry','p4:thm:hopf-ray-phase',exact),
 ('bosonic_Jacobi_cutoff','Finite oscillator Jacobi matrix and top CCR defect','finite_spectrum_or_operator','p4c:thm:v349-hermite-vacuum-law',exact),
 ('two_mode_exterior_CAR','Two-mode exterior algebra with exact CAR matrices','finite_algebra','p4:thm:finite-second-quantization',exact),
 ('scalar_eigencharge_index2','Scalar two-torus parity sublattice of index two','integer_lattice','p4:thm:v190-born-eigencharge-lattice',exact),
 ('finite_test_algebra43_blockmodel','Six full matrix blocks with dimensions 1,2,2,4,3,3','finite_algebra','p4:thm:full-finite-observable-algebra',exact),
 ('signed_Petersen_aux_PVM','Three orthogonal signed-Petersen auxiliary spectral projectors','finite_algebra','p4a:thm:v320-signed-projective-test',exact),
]
O=rd('objects.json');ids={o['id'] for o in O}
for key,name,typ,label,ver in newO:
    id='geo:g27:'+key
    if id not in ids:
        O.append({'id':id,'name':name,'object_type':typ,'scope':'mathematical_structure_or_morphism',
                  'source_kind':'exact_operator_or_group_construction_v127','conditional':key in ('protected_carrier_grading','ray_CP1_explicit'),
                  'batch':'v1_27','verification':ver,'witness':W[label]});ids.add(id)

# (source, target, exact mathematical construction/restriction, source claim, status, additional input objects)
Edata=[
 ('geo:g14:clifford_cl03_chiral','geo:protected_clifford','CONDITIONAL_PROTECTED_REAL_CL03_MODULE_IDENTIFICATION','p3:thm:clifford-dim',conditional,['geo:clifford_h1']),
 ('geo:protected_clifford','geo:protected_septet','ENDPOINT_SCALAR_1_PLUS_7_SPLITTING','p3:thm:hopf-decomposition',conditional,['geo:protected_clifford']),
 ('geo:protected_clifford','geo:clifford_tangent','EVEN_H_QUATERNION_HOPF_PROJECTOR_TANGENT','p3c:thm:v179-clifford-projector-tangent',conditional,['geo:hopf']),
 ('geo:hopf','geo:clifford_tangent','UNIT_IMAGINARY_HOPF_AXIS_TANGENT_TWO_PLANE','p3c:thm:v179-clifford-projector-tangent',exact,[]),
 ('geo:clifford_tangent','geo:g27:clifford_projector_sources','L_V_R_V_OFFDIAGONAL_SOURCE_MATRIX_CONSTRUCTION','p3c:thm:v179-clifford-projector-tangent',exact,[]),
 ('geo:protected_clifford','geo:g27:protected_carrier_grading','EIGHT_DIMENSIONAL_ORTHOGONAL_GRADING','p3c:thm:v179-balanced-hierarchy-response',conditional,['geo:protected_septet']),
 ('geo:g27:protected_carrier_grading','geo:e32','Q4_PROTECTED_CARRIER_E32_EIGENCOEFFICIENT','p3c:thm:v179-balanced-hierarchy-response',exact,[]),
 ('geo:g27:protected_carrier_grading','geo:e40','Q5_PROTECTED_CARRIER_E40_EIGENCOEFFICIENT','p3c:thm:v179-balanced-hierarchy-response',exact,[]),
 ('geo:g27:protected_carrier_grading','geo:e56','Q7_PROTECTED_CARRIER_E56_EIGENCOEFFICIENT','p3c:thm:v179-balanced-hierarchy-response',exact,[]),
 ('geo:g27:clifford_projector_sources','geo:e36','POSITIVE_SANDWICH_ROOT_RESPONSE_ON_TANGENT','p3c:thm:v179-balanced-hierarchy-response',exact,['geo:e32','geo:e40']),
 ('geo:e32','geo:e36','GEOMETRIC_MEAN_POSITIVE_PROTECTED_WEIGHT_INPUT','p3c:thm:v179-balanced-hierarchy-response',exact,['geo:e40']),
 ('geo:e40','geo:e36','GEOMETRIC_MEAN_POSITIVE_PROTECTED_WEIGHT_INPUT','p3c:thm:v179-balanced-hierarchy-response',exact,['geo:e32']),
 ('geo:petersen_signed','geo:g27:petersen_Kflux','SIGNED_EDGE_CROSS_PRODUCT_QUATERNION_FLUX','p1:thm:petersen-signed-and-flux',exact,['geo:c6_axes']),
 ('geo:c6_projectors','geo:g27:petersen_Kflux','UNORIENTED_C6_AXES_ORIENTED_PETERSEN_FLUX','p1:thm:petersen-signed-and-flux',exact,['geo:petersen_15edge']),
 ('geo:petersen_15edge','geo:g27:petersen_Kflux','ORIENTED_EDGE_TO_IMAGINARY_QUATERNION_MAP','p1:thm:petersen-signed-and-flux',exact,[]),
 ('geo:g27:petersen_Kflux','geo:g27:petersen_Krank2','TRANSVERSE_GRAM_KT_PU_K_EIGENVALUES_5_0','p3c:cor:v371-petersen-e36-comparison',exact,['geo:c6_projectors']),
 ('geo:clifford_tangent','geo:petersen_e36','COMPOSITION_TANGENT_SOURCE_WITH_PETERSEN_FLUX','p3c:cor:v371-petersen-e36-comparison',conditional,['geo:g27:petersen_Kflux','geo:e36']),
 ('geo:e36','geo:petersen_e36','E36_TIMES_SOURCE_OPERATOR_NO_INTERACTION','p3c:cor:v371-petersen-e36-comparison',conditional,['geo:g27:petersen_Krank2']),
 ('geo:petersen_e36','geo:g27:petersen_Krank2','RANK_TWO_POSITIVE_GRAM_COMPARISON_SPECTRUM','p3c:cor:v371-petersen-e36-comparison',exact,[]),
 ('geo:m8_product','geo:m8_hodge_heat','PRODUCT_METRIC_KUNNETH_HODGE_HEAT_GENERATOR','p1b:thm:product-hodge',exact,[]),
 ('geo:m8_hodge_heat','geo:m8_exchange_heat','GRADED_SWAP_EVEN_ODD_HEAT_DECOMPOSITION','p1b:thm:exchange-heat',exact,['geo:m8_product']),
 ('geo:m8_hodge_heat','geo:g27:m8_hodge_exchange_Betti','HARMONIC_BETTI_POLYNOMIAL_KUNNETH','p1b:thm:product-hodge',exact,[]),
 ('geo:m8_exchange_heat','geo:g27:m8_hodge_exchange_Betti','SWAP_LEFSCHETZ_TRACE_AND_GRADED_PROJECTORS','p1b:thm:exchange-heat',exact,[]),
 ('geo:m8_product','geo:m8_bi_scalar_spectrum','CONNECTION_COUPLED_SCALAR_PRODUCT_LAPLACIAN','p1b:thm:covariant-spectrum',conditional,['geo:spin4_harmonics']),
 ('geo:spin4_harmonics','geo:m8_bi_scalar_spectrum','SU2_COUPLED_CASIMIR_BLOCK_RESTRICTION','p1b:thm:covariant-spectrum',source,[]),
 ('geo:m8_bi_scalar_spectrum','geo:g27:covariant_connection_casimir','EXACT_SPIN_J_SPIN_IOTA_RECOUPLED_CASIMIR','p1b:thm:covariant-spectrum',exact,[]),
 ('geo:m8_product_band_families','geo:m8_finite_joint_spectra','FINITE_TRUNCATED_JOINT_SPECTRAL_TENSOR_SUM','p1b:thm:mixed-spectra',source,[]),
 ('geo:m8_irreps','geo:m8_finite_joint_spectra','SU2XSU2_CASIMIR_MULTIPLICITIES','p1b:thm:mixed-spectra',source,[]),
 ('geo:scalar_torus','geo:m8_scalar_line_spectrum','INTEGRAL_FLUX_Q_SCALAR_LINE_LANDAU_LAPLACIAN','p1b:thm:g13-landau',source,[]),
 ('geo:m8_product','geo:m8_scalar_line_spectrum','PRODUCT_PULLBACK_OF_TORUS_LINE_OPERATOR','p1b:thm:g13-landau',source,[]),
 ('geo:hopf','geo:quantum_hopf_rays','C2_UNIT_SPHERE_PROJECTIVIZATION_COMPARISON','p4:thm:hopf-ray-phase',conditional,['geo:hopf_fibre']),
 ('geo:quantum_hopf_rays','geo:g27:ray_CP1_explicit','DEGREE_ONE_C2_HOPF_RAY_FIBRE_COMPARISON','p4:thm:hopf-ray-phase',exact,[]),
 ('geo:s3','geo:g27:ray_CP1_explicit','EXPLICIT_HOPF_BASE_CP1_IDENTIFICATION','p4:thm:hopf-ray-phase',exact,[]),
 ('geo:finite_compressed_observables','geo:quantum_no_exact_ccr','FINITE_DIMENSIONAL_COMMUTATOR_TRACE_OBSTRUCTION','p4:prop:no-exact-ccr',exact,[]),
 ('geo:quantum_no_exact_ccr','geo:g27:bosonic_Jacobi_cutoff','TRUNCATED_OSCILLATOR_TOP_PROJECTION_DEFECT','p4:prop:no-exact-ccr',exact,[]),
 ('geo:quantum_boson_cutoff','geo:g27:bosonic_Jacobi_cutoff','VACUUM_TO_FIRST_EXCITATION_COVARIANCE_MATRIX','p4:thm:v245-finite-free-vacuum-covariance',exact,[]),
 ('geo:quantum_hermite_cutoff_law','geo:g27:bosonic_Jacobi_cutoff','HERMITE_JACOBI_CHARPOLY_AND_GAUSS_MOMENTS','p4c:thm:v349-hermite-vacuum-law',exact,[]),
 ('geo:quantum_fock_car','geo:g27:two_mode_exterior_CAR','EXTERIOR_TENSOR_POWER_CAR_TWO_MODE_REPRESENTATIVE','p4:thm:finite-second-quantization',exact,[]),
 ('geo:h1','geo:quantum_fock_car','ONE_PARTICLE_MODE_TO_STATISTICS_SELECTED_TENSOR_POWERS','p4:thm:finite-second-quantization',conditional,[]),
 ('geo:quantum_scalar_charge_lattice','geo:g27:scalar_eigencharge_index2','SMITH_DETERMINANT_TWO_PARITY_IMAGE','p4:thm:v190-born-eigencharge-lattice',exact,[]),
 ('geo:scalar_torus','geo:quantum_scalar_charge_lattice','NATIVE_SCALAR_INTEGER_CHARACTERS_TO_EIGENCHARGES','p4:thm:v190-born-eigencharge-lattice',exact,[]),
 ('geo:g15:scalar_eigenphase_matrix','geo:g27:scalar_eigencharge_index2','EXACT_INTEGER_CHARACTER_MATRIX_IMAGE_INDEX_TWO','p4:thm:v190-born-eigencharge-lattice',exact,[]),
 ('geo:petersen_signed','geo:quantum_signed_petersen_test','AUXILIARY_S_CUBED_EQUALS_5S_SPECTRAL_PVM','p4a:thm:v320-signed-projective-test',exact,[]),
 ('geo:quantum_signed_petersen_test','geo:g27:signed_Petersen_aux_PVM','THREE_IDEMPOTENTS_RANK_3_4_3','p4a:thm:v320-signed-projective-test',exact,[]),
 ('geo:quantum_test_algebra43','geo:g27:finite_test_algebra43_blockmodel','SIX_BLOCK_MATRIX_DIRECT_SUM_DIMENSION_43','p4:thm:full-finite-observable-algebra',exact,[]),
 ('geo:h1','geo:quantum_test_algebra43','LEVEL_ONE_CARRIER_BLOCKS_1_2_2_4_3_3','p4:thm:full-finite-observable-algebra',source,[]),
 ('geo:hopf_charges','geo:quantum_reeb_superselection','HOPF_CIRCLE_SPECTRAL_PROJECTOR_DEPHASING','p4:cor:hopf-reeb-superselection',conditional,[]),
 ('geo:spin4_harmonics','geo:quantum_finite_selection','DIAGONAL_SU2_CLEBSCH_GORDAN_VECTOR_RULE','p4:thm:vector-selection',source,[]),
 ('geo:s3','geo:sphere_spaceform_classes','FINITE_SUBGROUP_FREE_ACTION_CLASSIFICATION','p1a:theorem:atlas-finite-subgroup-classification-b4f160f',source,[]),
 ('geo:sphere_spaceform_classes','geo:spaceform_2t','QUOTIENT_OF_SU2_BY_BINARY_TETRAHEDRAL_GROUP','p1a:theorem:atlas-finite-subgroup-classification-b4f160f',source,[]),
 ('geo:sphere_spaceform_classes','geo:spaceform_2o','QUOTIENT_OF_SU2_BY_BINARY_OCTAHEDRAL_GROUP','p1a:theorem:atlas-finite-subgroup-classification-b4f160f',source,[]),
 ('geo:sphere_spaceform_classes','geo:spaceform_2i','QUOTIENT_OF_SU2_BY_BINARY_ICOSAHEDRAL_GROUP','p1a:theorem:atlas-finite-subgroup-classification-b4f160f',source,[]),
]
R=rd('mathematical_relations.json');rids={e['id'] for e in R}
for i,(a,b,k,label,ver,inputs) in enumerate(Edata,1):
    rid=f'G27-{i:03d}'
    assert a in ids and b in ids,(i,a,b)
    if rid not in rids:
        e={'id':rid,'from':a,'to':b,'relation':k,'link_type':'explicit_mathematical_map_or_operator_composition',
           'source_relation':'MATHEMATICAL_CONSTRUCTION_NOT_PROOF_EDGE','conditions_preserved':True,
           'verification':ver,'witness':W[label],'batch':'v1_27'}
        if inputs:e['requires_joint_inputs']=inputs
        R.append(e);rids.add(rid)
H=rd('joint_input_relations.json');hids={h['id'] for h in H}
hyp=[
 ('01',['geo:g14:clifford_cl03_chiral','geo:clifford_h1','geo:protected_clifford'],['geo:clifford_tangent'],['(ND_sp) and upstream protected active support','chosen Hopf axis u; even Cl(0,3)=H','not inferred from End_C(S+) dimension count alone'],'conditional represented module and Hopf tangent'),
 ('02',['geo:g27:protected_carrier_grading','geo:e32','geo:e40','geo:e56'],['geo:e36'],['positive quarter-character branch','E0>0 and alpha_hier>0','response coefficient is not a physical mass, energy or width'],'E36=sqrt(E32 E40) as unique positive half-sandwich on tangent'),
 ('03',['geo:petersen_signed','geo:c6_projectors','geo:petersen_15edge'],['geo:g27:petersen_Kflux'],['same marked five-core 2T family and its ten C6 axes','choose Petersen edge orientations','projective signs cancel via sgn(u_v.u_w)'],'K K^T=5I3, exact quaternion flux'),
 ('04',['geo:g27:petersen_Kflux','geo:g27:clifford_projector_sources','geo:e36'],['geo:petersen_e36'],['chosen projective u (any one of ten C6 axes)','positive E36 grading','comparison map only; not a physical interaction vertex'],'rank-two protected comparison Gram'),
 ('05',['geo:m8_product','geo:m8_hodge_heat'],['geo:m8_exchange_heat'],['factorwise bi-invariant Riemannian metric and torus G>0','exchange-even/odd needs Rx=Rp and exchange-invariant G'],'scalar/Hodge heat factor and graded swap'),
 ('06',['geo:m8_product','geo:m8_bi_scalar_spectrum','geo:g27:covariant_connection_casimir'],['geo:m8_bi_scalar_spectrum'],['connection A_f=fTheta supplied in spin iota representation','not the geometric bundle Laplacian without separately specified connection'],'coupled SU2 Casimir eigenvalue identity'),
 ('07',['geo:quantum_hopf_rays','geo:g27:ray_CP1_explicit','geo:hopf'],['geo:quantum_hopf_rays'],['Hilbert carrier specifically C2 so unit sphere is S3','primitive chosen positive Hopf winding +1','comparison of circle phase roles only; not identical weight actions on other modes'],'S3 to CP1 projective ray Hopf comparison'),
 ('08',['geo:quantum_fock_car','geo:g27:two_mode_exterior_CAR'],['geo:g27:two_mode_exterior_CAR'],['finite one-particle carrier assigned','fermionic antisymmetry selector','no physical Hamiltonian claimed'],'canonical two-mode finite exterior CAR'),
 ('09',['geo:quantum_boson_cutoff','geo:g27:bosonic_Jacobi_cutoff'],['geo:quantum_hermite_cutoff_law'],['specified finite occupation N>=1','sigma²>0 and self-adjoint finite Jacobi operator','finite top-boundary CCR defect retained'],'Hermite quadrature cutoff and vacuum moments'),
 ('10',['geo:quantum_reeb_superselection','geo:hopf_charges'],['geo:quantum_reeb_superselection'],['accessible algebra commutes with Q_xi','reduced channels U(1)-covariant','without these guards only charge-sector decomposition, not exact superselection'],'conditional finite charge twirl'),
]
for n,inputs,outputs,conditions,result in hyp:
    hid='HYP-G27-'+n
    if hid not in hids:
        assert all(k in ids for k in inputs+outputs)
        H.append({'id':hid,'kind':'joint_mathematical_inputs_with_explicit_scope_conditions',
                  'inputs':inputs,'outputs':outputs,'conditions':conditions,'result':result,
                  'verification':conditional if n in ('01','02','04','06','07','08','10') else exact})
C=rd('derived_compositions.json');cids={x['id'] for x in C}
results=[
 ('01','Clifford rank-two Hopf tangent normalization','Tr8(S(v)^T S(w))/8=<v,w>/4','Even Cl(0,3) H, u=i; protected active projectors; (ND_sp) for identification','Compute explicit L_v,R_v on H. Q5 L_v Q4=|vu><u|, S=[(L-R)/2,Q4]. The real-trace normalization and unique offdiagonal completion follow by matrix multiplication.','EXACT_IN_THIS_BATCH'),
 ('02','Protected energy-character geometric mean','H^(1/2) S_v H^(1/2)=sqrt(E32*E40) S_v','positive alpha_hier,E0; active-depth Q4,Q5,Q7; carrier grading only','Diagonal functional calculus on mutually orthogonal projectors produces the E36 coefficient on the Q4-Q5 offdiagonal block. E56 is the independent Q7 eigenweight.','EXACT_IN_THIS_BATCH'),
 ('03','Petersen/C6 quaternion Gram and protected comparison','K K^T=5I3; Spec(K^T(I-uu^T)K)={5^2,0^13}','same marked ten C6 axes and Petersen orientation; chosen unit u','Generate fifteen cross-product fluxes in Q(sqrt5); verify KK^T=5I3. For unit u, P²=P rank2, hence (K^T P K)²=5 K^T P K and its trace is 10.','EXACT_IN_THIS_BATCH'),
 ('04','Kunneth Hodge and exchange cohomology','B(z)=(1+z)^2(1+z^3)^2; L_ex(z)=1-z^2-z^6+z^8','product M8; graded factor exchange; exchange-invariant metric for heat traces','H*(S3) has generators in degree 3; H*(T2) has two degree-1 generators. Graded swap signs give the Lefschetz polynomial; (B±L)/2 have eight modes each.','EXACT_IN_THIS_BATCH'),
 ('05','Supplied SU2 connection-Casimir spectral identity','R² λ=4[(1-f)j(j+1)+f k(k+1)+(f²-f)iota(iota+1)]','A_f=fTheta and spin-iota representation supplied; j⊗iota recoupled','Expand (J+fI)²=(1-f)J²+f(J+I)²+(f²-f)I². Sample character multiplicities are regenerated exactly.','EXACT_FINITE_TEST_AND_SYMBOLIC_IDENTITY'),
 ('06','Finite bosonic CCR defect and Hermite rule','[a_N,a_N^T]=I-(N+1)|N><N|; det(xI-(a+a^T))=He_{N+1}(x)','finite occupation 0..N and sigma=1 normalization','The boundary defect follows from matrix multiplication; determinant recurrence is the probabilists Hermite recurrence. Gaussian vacuum moments match through degree 2N+1 (checked N=1..5).','EXACT_FINITE_TEST_AND_RECURRENCE'),
 ('07','Two-mode exterior CAR','{c_i,c_j^†}=delta_ij I and {c_i,c_j}=0','fermionic exterior algebra of a selected 2D one-particle space','The four canonical occupation basis vectors with Jordan-Wigner signs yield exact real 4x4 CAR matrices.','EXACT_IN_THIS_BATCH'),
 ('08','Index-two scalar eigencharge lattice','Image([[1,1],[1,-1]] Z²)={(p+,p-):p+≡p- mod 2}','two-torus native integer character basis; Born eigenphase marking','Determinant -2 and inverse (p++p-)/2,(p+-p-)/2 give if-and-only-if parity.','EXACT_IN_THIS_BATCH'),
 ('09','Signed Petersen auxiliary spectral projectors','P±=(S²/5 ± S/√5)/2, P0=I-S²/5, ranks (3,3,4)','marked signed 10-axis representation; not automatic kinematic algebra identification','Verify S³=5S from the prior exact Petersen instance and the three idempotent projector identities.','EXACT_IN_THIS_BATCH'),
 ('10','Projective C2 Hopf map, fixed winding','(z0,z1)↦[z0:z1] with |z0|²+|z1|²=1, image S²','specifically C² Hilbert carrier and positive primitive Hopf-ray comparison','The Bloch/Hopf coordinate triple has squared norm (|z0|²+|z1|²)² and is U(1)-invariant. It does not identify arbitrary Hopf charge representations with scalar phases.','EXACT_IN_THIS_BATCH'),
 ('11','Six-block algebra dimension certificate','C⊕M2⊕M2⊕M4⊕M3⊕M3, dimC=43, carrier block dim=15','source-defined finite kinematic carrier; no ENV extension inserted','Sum of matrix dimensions squares gives 43; sum of defining module dimensions gives 15; no physical occurrence inferred from dimension count.','EXACT_DIMENSION_CALCULATION_SOURCE_DEFINED_BLOCKS'),
]
source_map={
 '01':['p3c:thm:v179-clifford-projector-tangent'],
 '02':['p3c:thm:v179-balanced-hierarchy-response'],
 '03':['p1:thm:petersen-signed-and-flux','p3c:cor:v371-petersen-e36-comparison'],
 '04':['p1b:thm:product-hodge','p1b:thm:exchange-heat'],
 '05':['p1b:thm:covariant-spectrum'],
 '06':['p4:prop:no-exact-ccr','p4c:thm:v349-hermite-vacuum-law'],
 '07':['p4:thm:finite-second-quantization'],
 '08':['p4:thm:v190-born-eigencharge-lattice'],
 '09':['p4a:thm:v320-signed-projective-test'],
 '10':['p4:thm:hopf-ray-phase'],
 '11':['p4:thm:full-finite-observable-algebra'],
}
for n,name,formula,hyps,proof,status in results:
    key='D27-'+n
    if key not in cids:
        C.append({'id':key,'name':name,'formula':formula,'hypotheses':[hyps],
                  'proof':proof,'source_premises':source_map.get(n,[]),
                  'status':status})
wr('objects.json',O);wr('mathematical_relations.json',R);wr('joint_input_relations.json',H);wr('derived_compositions.json',C)
wr('geometry_bridges_v127_instance.json',build())
counts={'version':'v1_27','parent':'v1_26','new_objects':len([x for x in O if x.get('batch')=='v1_27']),
 'new_typed_relations':len([x for x in R if x['id'].startswith('G27-')]),
 'new_joint_inputs':len([x for x in H if x['id'].startswith('HYP-G27-')]),
 'new_derived_compositions':len([x for x in C if x['id'].startswith('D27-')]),
 'cumulative_objects':len(O),'cumulative_edges':len(R),'cumulative_joint_inputs':len(H),'cumulative_compositions':len(C)}
wr('v127_release_counts.json',counts)
# Keep exact GraphML format (node ids, relation/guards equal to JSON) and focused map.
ns='http://graphml.graphdrawing.org/xmlns';ET.register_namespace('',ns)
def gtag(t):return '{'+ns+'}'+t
def make_graph(path,objects,relations,label):
    root=ET.Element(gtag('graphml'))
    for id,kind,attr in [('d0','node','label'),('d1','node','kind'),('d2','node','batch'),('d3','node','verification'),('d4','edge','id'),('d5','edge','relation'),('d6','edge','verification'),('d7','edge','requires_and_inputs')]:
        ET.SubElement(root,gtag('key'),{'id':id,'for':kind,'attr.name':attr,'attr.type':'string'})
    g=ET.SubElement(root,gtag('graph'),{'id':label,'edgedefault':'directed'})
    for o in objects:
        n=ET.SubElement(g,gtag('node'),{'id':o['id']})
        for key,val in [('d0',o['name']),('d1',o['object_type']),('d2',o.get('batch','')),('d3',o.get('verification',''))]:
            ET.SubElement(n,gtag('data'),{'key':key}).text=str(val)
    for e in relations:
        n=ET.SubElement(g,gtag('edge'),{'id':e['id'],'source':e['from'],'target':e['to']})
        for key,val in [('d4',e['id']),('d5',e['relation']),('d6',e.get('verification','')),('d7',','.join(e.get('requires_joint_inputs',[])))]:
            ET.SubElement(n,gtag('data'),{'key':key}).text=str(val)
    ET.ElementTree(root).write(path,encoding='utf-8',xml_declaration=True)
make_graph(G/'mathematical_structure_network.graphml',O,R,'S3_geometry_only_v127')
newrels=[x for x in R if x['id'].startswith('G27-')];used={z['from'] for z in newrels}|{z['to'] for z in newrels}
make_graph(G/'batch16_clifford_m8_operator_bridges.graphml',[x for x in O if x['id'] in used],newrels,'S3_batch16_geometry_gaps')
print('INSTALLED',counts)
