#!/usr/bin/env python3
"""One-time deterministic release assembler: v1_22 -> v1_23.

Run in an extracted v1_22 copy renamed to v1_23. Avoid rerunning on an
already updated release. Adds only true mathematical structures and maps.
"""
from __future__ import annotations
from pathlib import Path
import json,copy,collections,xml.etree.ElementTree as ET
import networkx as nx
from .a5_q8_projector_v123 import build
ROOT=Path(__file__).resolve().parents[1]
D=ROOT/'data';G=ROOT/'graph'
def save(rel,x):
 p=ROOT/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
load=lambda name:json.loads((D/name).read_text())
instance=build();save('data/a5_q8_projector_v123_instance.json',instance)
objects=load('objects.json');edges=load('mathematical_relations.json');joint=load('joint_input_relations.json');compositions=load('derived_compositions.json')
assert (len(objects),len(edges),len(joint),len(compositions))==(702,916,109,94)
base={o['id']:o for o in objects}
source=base['geo:g16:minus3_projector']['witness']
witness={'source_premise':'p1:thm:v365-600-cell-incidence',
         'file':source.get('file','Paper1B-ExceptionalGeometry-v1_14.tex'),
         'line':source.get('line',1),
         'tex_sha256':source.get('tex_sha256','54f8c52f2b790148832eff12eae0a43957a27b0b9f2b38939dab0b378c4dbfb2'),
         'new_statement_status':'EXACT_REGENERATION_FROM_MARKED_QUATERNIONIC_AND_POLYGON_INSTANCES_NOT_CLAIMED_AS_SOURCE_THEOREM'}
V='EXACT_INTEGER_A5_MATRIXCOEFFICIENT_Q8_FOURIER_AND_E8_GRAM_INTERTWINER_CERTIFICATE'
nspec=[
 ('a5_five_core_perm5','A5 permutation representation on five tetrahedral cores','five_core_permutation_representation'),
 ('a5_standard_W4','Four-dimensional centered standard representation W4 of A5','finite_group_real_irreducible_representation'),
 ('a5_centered_matrixcoeff_C60','Centered A5 60×25 matrix coefficient frame C(g,i,j)','matrix_coefficient_operator'),
 ('a5_matrixcoeff16','16-dimensional W4⊗W4* matrix coefficient block inside R[A5]','finite_group_matrix_coefficient_module'),
 ('a5_right_restriction_A4','Restriction W4|A4 = 1⊕3 for 2T/±1 inside A5','exact_representation_restriction'),
 ('right_2T_character_W16','Exact right-2T character on the 600-cell minus-three 16-space','finite_group_character'),
 ('q8_fourier_idempotents','Four real Q8 central character projectors on the minus-three space','finite_group_fourier_projection_algebra'),
 ('q8_projection_triv4','Rank-four trivial-Q8 spectral projector on W16','exact_rational_projector'),
 ('q8_projection_i4','Rank-four χ_i Q8 sign spectral projector on W16','exact_rational_projector'),
 ('q8_projection_j4','Rank-four χ_j Q8 sign spectral projector on W16','exact_rational_projector'),
 ('q8_projection_k4','Rank-four χ_k Q8 sign spectral projector on W16','exact_rational_projector'),
 ('q8_4x4_isotypic_decomposition','Exact orthogonal W16=4+4+4+4 Q8-character decomposition','orthogonal_representation_decomposition'),
 ('c3_three_sign_cycle','Residual right C3 cyclic permutation of the χ_i,χ_j,χ_k spectral blocks','group_conjugacy_morphism'),
 ('c3_W16_complex_spectrum','Residual C3 eigenspace multiplicities 8+4ω+4ω² on W16','cyclic_group_complex_spectral_decomposition'),
 ('hopf_axis_F_indicator','Exact 120×15 right-Q8 Hopf-axis fibre indicator F','integral_quotient_incidence_operator'),
 ('a5_P4_to_e8_gram_intertwiner','Explicit isometry between Q8-fixed minus-three subspace and E8 Gram four-block contrast','intertwining_isometry'),
 ('axis_E8_threeway_projector','Three-way common rank-four projector from 600 quotient, 24-cell incidence, and E8 Gram','exact_rational_spectral_projector'),
 ('polygon_right_C3_permutation','Right projective A5 order-three permutation of 60 vertices and cyclic polygon families','finite_group_permutation_action'),
 ('polygon_C3_orbit_count','Right-C3 orbit counts on 450 order-two, 200 order-three and 72 order-five polygon cosets','exact_orbit_partition_invariant'),
 ('axis_C3_fourier_refinement','Right-C3 refinement of 15-axis 1+4+10 modules into 1+4+5ω+5ω²','complex_cyclic_spectral_decomposition')
]
for key,title,kind in nspec:
 oid='geo:g23:'+key
 assert oid not in base
 objects.append({'id':oid,'name':title,'batch':'v1_23','object_type':kind,
                 'scope':'mathematical_structure_or_morphism',
                 'source_kind':'independently_derived_exact_geometry_from_existing_marked_input',
                 'conditional':False,'verification':V,'witness':copy.deepcopy(witness)})
base={o['id']:o for o in objects}
# In this geometry graph, an edge is an explicit map or operator relation, not a citation.
refs=[
 ('geo:g16:a5_conjugation_action','a5_five_core_perm5','EXPLICIT_FIVE_CORE_PERMUTATION_ACTION'),
 ('a5_five_core_perm5','a5_standard_W4','REMOVE_CONSTANT_LINE_FROM_FIVE_CORE_PERMUTATION_MODULE'),
 ('a5_standard_W4','a5_centered_matrixcoeff_C60','CENTER_5x5_PERMUTATION_MATRIX_COEFFICIENTS'),
 ('a5_centered_matrixcoeff_C60','a5_matrixcoeff16','SPAN_OF_4x4_MATRIX_COEFFICIENTS_RANK16'),
 ('geo:g16:transporter_smith_lattice','a5_matrixcoeff16','SATURATED_PERMUTATION_COEFFICIENT_LATTICE_HAS_RANK17_INCLUDING_CONSTANT'),
 ('geo:g16:M2M3M5_Gram','a5_centered_matrixcoeff_C60','IDENTIFY_M3_MINUS_M5_AS_CENTERED_MATRIX_COEFFICIENT_GRAM'),
 ('a5_centered_matrixcoeff_C60','geo:g16:A5_character_P4','EXACT_PROJECTOR_C60_OVER_15'),
 ('a5_matrixcoeff16','geo:g16:A5_character_P4','PROJECT_ON_A5_STANDARD_MATRIX_COEFFICIENT_SPACE'),
 ('geo:g16:A5_character_P4','geo:g16:projector_antipodal_lift','ANTIPODAL_TWO_SHEET_SPECTRAL_LIFT'),
 ('geo:g16:projector_antipodal_lift','geo:g16:minus3_projector','EXACT_60_TO_120_MINUS_THREE_SPECTRAL_LIFT'),
 ('geo:g16:a5_conjugation_action','a5_right_restriction_A4','STABILIZER_OF_MARKED_2T_CORE_IS_RIGHT_A4'),
 ('a5_standard_W4','a5_right_restriction_A4','RESTRICT_A5_FIVE_POINT_STANDARD_TO_A4_POINT_STABILIZER'),
 ('a5_matrixcoeff16','right_2T_character_W16','RIGHT_REGULAR_ACTION_RESTRICTS_TO_4_COPIES_OF_4_POINT_A4_PERMUTATION'),
 ('a5_right_restriction_A4','right_2T_character_W16','CHARACTER_OF_FOUR_COPIES_OF_1_PLUS_3_A4_MODULE'),
 ('geo:g13:right_q8','q8_fourier_idempotents','CHARACTER_AVERAGING_ON_RIGHT_Q8_DECK_ACTION'),
 ('geo:g16:minus3_projector','q8_fourier_idempotents','SPECTRAL_PROJECTOR_COMMUTES_WITH_RIGHT_Q8_ACTION'),
 ('right_2T_character_W16','q8_fourier_idempotents','FOURIER_CHARACTER_RESTRICTION_TO_Q8_MOD_CENTER'),
 ('q8_fourier_idempotents','q8_projection_triv4','Q8_TRIVIAL_CHARACTER_AVERAGING_PROJECTOR'),
 ('q8_fourier_idempotents','q8_projection_i4','Q8_CHI_I_CHARACTER_AVERAGING_PROJECTOR'),
 ('q8_fourier_idempotents','q8_projection_j4','Q8_CHI_J_CHARACTER_AVERAGING_PROJECTOR'),
 ('q8_fourier_idempotents','q8_projection_k4','Q8_CHI_K_CHARACTER_AVERAGING_PROJECTOR'),
 ('q8_projection_triv4','q8_4x4_isotypic_decomposition','ORTHOGONAL_SUM_FOUR_RANKFOUR_PROJECTORS'),
 ('q8_projection_i4','q8_4x4_isotypic_decomposition','ORTHOGONAL_SUM_FOUR_RANKFOUR_PROJECTORS'),
 ('q8_projection_j4','q8_4x4_isotypic_decomposition','ORTHOGONAL_SUM_FOUR_RANKFOUR_PROJECTORS'),
 ('q8_projection_k4','q8_4x4_isotypic_decomposition','ORTHOGONAL_SUM_FOUR_RANKFOUR_PROJECTORS'),
 ('geo:g22:residual_C3_deck_action','c3_three_sign_cycle','NORMALIZER_CONJUGATION_PERMUTES_NONTRIVIAL_Q8_CHARACTERS'),
 ('q8_4x4_isotypic_decomposition','c3_three_sign_cycle','C3_CYCLES_THREE_SIGN_COMPONENTS_AND_FIXES_TRIVIAL_COMPONENT'),
 ('c3_three_sign_cycle','c3_W16_complex_spectrum','C3_CHARACTER_EIGENSPLIT_8_PLUS_4_PLUS_4'),
 ('geo:g20:inversion_axis_bijection','hopf_axis_F_indicator','INDICATOR_OF_8_VERTEX_Q8_AXIS_FIBRES'),
 ('hopf_axis_F_indicator','a5_P4_to_e8_gram_intertwiner','ISOMETRY_BY_F_DIVIDED_BY_SQRT8'),
 ('q8_projection_triv4','a5_P4_to_e8_gram_intertwiner','EXACT_LIFT_OF_RANKFOUR_PROJECTOR_ON_15_AXES'),
 ('geo:g21:slice_gram_operator','a5_P4_to_e8_gram_intertwiner','EXACT_296_EIGENSPACE_E8_GRAM_PROJECTOR'),
 ('geo:g16:minus3_projector','axis_E8_threeway_projector','COMPRESS_Q8_FIXED_600_SPECTRAL_PROJECTOR'),
 ('geo:g20:axis_joint_projector_algebra','axis_E8_threeway_projector','POLYNOMIAL_IN_QUOTIENT_ADJACENCY_Q600'),
 ('a5_P4_to_e8_gram_intertwiner','axis_E8_threeway_projector','EQUAL_E8_TENSOR_GRAM_AND_600_SPECTRAL_RANKFOUR_IDEMPOTENT'),
 ('geo:g16:cyclic3_polygon_cosets','polygon_right_C3_permutation','PERMUTE_PROJECTIVE_C3_COSETS_BY_RIGHT_THREE_CYCLE'),
 ('geo:g16:polygon722_BoseMesner','polygon_right_C3_permutation','ALL_CYCLIC_ORDER_POLYGONS_STABLE_UNDER_RIGHT_A5_TRANSLATION'),
 ('geo:g22:residual_C3_deck_action','polygon_right_C3_permutation','FACTOR_RIGHT_2T_DECK_ACTION_TO_PROJECTIVE_A5'),
 ('polygon_right_C3_permutation','polygon_C3_orbit_count','EXACT_450_200_72_POLYGON_ORBIT_ENUMERATION'),
 ('polygon_right_C3_permutation','axis_C3_fourier_refinement','SAME_MARKED_ORDERTHREE_DECK_SUBGROUP_ON_AXIS_QUOTIENT'),
 ('axis_E8_threeway_projector','axis_C3_fourier_refinement','E8_GRAM_COMMUTES_WITH_C3_PERMUTATION'),
 ('c3_three_sign_cycle','axis_C3_fourier_refinement','C3_FIXED_RANKFOUR_AXIS_CONTRAST_AND_COMPLEX_FIVE_PLUS_FIVE_SPLIT')
]
# Reference IDs confirmed from actual archive, not invented.
for src,dst,relation in refs:
 src=src if src.startswith('geo:') else 'geo:g23:'+src
 dst=dst if dst.startswith('geo:') else 'geo:g23:'+dst
 assert src in base and dst in base,(src,dst)
 edges.append({'id':f'G23-{len([e for e in edges if e["id"].startswith("G23-")])+1:03d}',
               'from':src,'to':dst,'relation':relation,
               'link_type':'exact_A5_Q8_C3_character_and_spectral_projector_composition',
               'conditions_preserved':True,'requires_joint_inputs':[],
               'verification':V})
assert len([e for e in edges if e['id'].startswith('G23-')])==len(refs)
new={n['id'] for n in objects if n.get('batch')=='v1_23'}
conditions=['one fixed marked 2I< S3 coordinate system and embedded right Q8 ◁ 2T',
            'the 25 transporter 24-cells, 60 projective A5 points, 15 right-Q8 axes and E8 weighted Gram are regenerated from the SAME marking',
            'all arithmetic concerns finite geometry only; no physical observable or channel is inferred']
link_defs=[
 ('a5_matrix_coeff',['geo:g16:a5_conjugation_action','geo:g16:M2M3M5_Gram'],['geo:g23:a5_centered_matrixcoeff_C60','geo:g23:a5_matrixcoeff16'],'Centered five-point 4D A5 matrix coefficient block has projector (M3-M5)/15 of rank16'),
 ('antipodal_projector',['geo:g16:A5_character_P4','geo:g16:projector_antipodal_lift'],['geo:g16:minus3_projector'],'The 60-point A5 character idempotent lifts to the full 600-cell -3 eigenspace'),
 ('q8_fourier',['geo:g16:minus3_projector','geo:g13:right_q8'],['geo:g23:q8_4x4_isotypic_decomposition'],'Four rational Q8-character idempotents, pairwise orthogonal and each rank four'),
 ('a4_character',['geo:g23:a5_right_restriction_A4','geo:g23:a5_matrixcoeff16'],['geo:g23:right_2T_character_W16'],'The right 2T action factors through A4 and has character 4×(4,0,1)'),
 ('q8_E8_identification',['geo:g23:q8_projection_triv4','geo:g23:hopf_axis_F_indicator','geo:g21:slice_gram_operator'],['geo:g23:a5_P4_to_e8_gram_intertwiner'],'Q8-fixed 600 -3 projector is isometric to E8 15-axis Gram rank-four projector'),
 ('threeway_projector',['geo:g16:minus3_projector','geo:g20:axis_joint_projector_algebra','geo:g21:slice_gram_operator'],['geo:g23:axis_E8_threeway_projector'],'Identical rational rank-four idempotent from transporter incidence, Q600 and E8 weighted Gram'),
 ('c3_polygons',['geo:g22:residual_C3_deck_action','geo:g16:polygon722_BoseMesner'],['geo:g23:polygon_C3_orbit_count'],'Right order-three A5 translation orbit sizes on all three cyclic polygon families')
]
for i,(name,ins,outs,statement) in enumerate(link_defs,1):
 assert set(ins+outs)<=set(base)
 joint.append({'id':f'HYP-G23-{i:02d}','kind':'exact_A5_quaternion_spectral_joint_input',
               'inputs':ins,'outputs':outs,'conditions':conditions,'output_statement':statement,
               'verification':V})
proofs=[
 ('A5 standard 4D coefficient model', 'C60=B60 B60^T - J60 = M3-M5; P60=C60/15, rank=16',
  'Compute the A5 action on five conjugate 2T cores. Center the 5×5 permutation matrices by subtracting the constant 1/5. Their 25 coefficients span the 4×4 matrix coefficient space of the 4D standard representation. Verify C60²=15C60; generate the 200 C3 and 72 C5 projective polygon cosets independently and verify the Gram equality entrywise.'),
 ('Antipodal lift to the complete 600-cell -3 eigenspace','P600=(B120 B120^T-J120)/30=L P60 L^T/2, rank=16',
  'Regenerate the 25 transported 24-cells from the fixed 600-cell bank; N=B120 B120^T-J120 satisfies N²=30N and A600 N=-3N. Every quaternion and its antipode induce the same A5 core permutation, giving N(u,v)=C60(projective u,projective v). Rank16 and the inherited adjacency nullity16 establish completeness.'),
 ('Right A4 character and matrix-coefficient restriction','W16|right(2T)=4·(1⊕3_A4); character values 16 on ±1, 0 on six order-four Q8 elements, 4 on sixteen other 2T elements',
  'The 2T stabilizer of one of the five 2T cores projects to the A4 point stabilizer in A5. The 4D A5 standard rep restricts to the 4-point A4 permutation module; the regular A5 matrix coefficient span has four copies under right translations. Independently compute trace(N U_h)/30 for each of the 24 marked right Hurwitz elements.'),
 ('Four character projectors of Q8','Pχ=(1/240)Σ_(h∈Q8)χ(h)N U_h, each rank4; Pχ Pψ=δχψ Pχ; Σχ Pχ=P600',
  'The central element −1 acts trivially on antipodally even 24-cell incidence, so Q8 acts through V4. Sum the actual right permutation operators with all four real characters, check matrix products with exact int64 arithmetic, and obtain rank4 from trace 960/240 for each.'),
 ('C3 action on Q8 signs','2T/Q8=C3 fixes P_trivial and cyclically permutes P_i,P_j,P_k; eigenspace dimensions on W16 are 8,4,4',
  'Pick a marked t∈2T outside Q8 and conjugate all four 120×120 projectors by its right permutation; obtain a three-cycle of nontrivial sign projectors. Character on t,t² is 4, so real fixed dimension (16+2·4)/3=8 and complex ω/ω² multiplicities (16−4)/3=4.'),
 ('Common 600-cell, Hopf and E8 rank-four idempotent','F^T N F=16(5 SameCore−J15); Pχtriv=F P4 F^T/8; P4=(5 SameCore−J15)/15',
  'Construct actual 120×15 Hopf-axis incidence F from the right Q8 orbits. Its columns have squared norm 8. Check the compressed 600-cell idempotent and the inverse 120-point lift equality, establishing an isometry between the 4D Q8-fixed subspace and the 15-axis five-block contrast.'),
 ('Triple polynomial equality with weighted E8 Gram','P4=Q600(Q600−12I)/45=(G−164I)(G−896I)/(−79200)',
  'Regenerate Q600 from 600-cell incidence and G from the saved E8 weighted triple Gram; verify G=164I−23Q600+7Q600², Q600(Q600−12I)=3(5SameCore−J), and (G−164I)(G−896I)=−5280(5SameCore−J), all entrywise as exact integers.'),
 ('Right C3 polygon orbit refinement','(C2 polygons: 150×3); (C3 polygons:20×1+60×3); (C5 polygons:24×3)',
  'Project right t∈2T to a nontrivial order-3 element of A5. Act by right multiplication on all 450+200+72 projective cyclic polygons and compare exact canonical sets. There are 20 fixed order-3 polygon sets and none fixed among orders 2 or 5; the three polygon incidence Gram operators commute with t.')
]
for i,(name,formula,proof) in enumerate(proofs,1):
 compositions.append({'id':f'D23-{i:02d}','name':name,'formula':formula,
                     'hypotheses':conditions,'proof':proof,'status':V,
                     'independent_checks':['verify_a5_q8_projector_v123.py','validate_geometry.py'],
                     'source_premises':['p1:thm:v365-600-cell-incidence','p1:thm:v370-e8-d4-triality']})
# Store cumulatively (ONLY mathematical objects and typed relations).
save('data/objects.json',objects);save('data/mathematical_relations.json',edges)
save('data/joint_input_relations.json',joint);save('data/derived_compositions.json',compositions)
# Preserve GraphML schema/attrs from v1_22 and append only mathematical nodes/edges.
ns='http://graphml.graphdrawing.org/xmlns';ET.register_namespace('',ns);qn=lambda n:f'{{{ns}}}{n}'
path=G/'mathematical_structure_network.graphml';root=ET.parse(path).getroot();main=root.find(qn('graph'))
assert main is not None
newO=[o for o in objects if o.get('batch')=='v1_23']
newE=[e for e in edges if e['id'].startswith('G23-')]
for o in newO:
 node=ET.SubElement(main,qn('node'),{'id':o['id']})
 for k,v in [('d0',o['name']),('d1',o['object_type']),('d2','v1_23'),('d3',o['verification'])]:ET.SubElement(node,qn('data'),{'key':k}).text=str(v)
for e in newE:
 node=ET.SubElement(main,qn('edge'),{'id':e['id'],'source':e['from'],'target':e['to']})
 for k,v in [('d4',e['id']),('d5',e['relation']),('d6',e['verification']),('d7',','.join(e.get('requires_joint_inputs',[])))]:ET.SubElement(node,qn('data'),{'key':k}).text=str(v)
ET.ElementTree(root).write(path,encoding='utf-8',xml_declaration=True)
# A focused pure-geometry graph: pre-existing input objects shown only when used.
focusRoot=ET.Element(qn('graphml'))
for key in root.findall(qn('key')):focusRoot.append(copy.deepcopy(key))
focusGraph=ET.SubElement(focusRoot,qn('graph'),{'id':'Batch12_A5_Q8_C3_Poly_E8','edgedefault':'directed'})
idsFocus={e['from'] for e in newE}|{e['to'] for e in newE}
for node in main.findall(qn('node')):
 if node.attrib['id'] in idsFocus:focusGraph.append(copy.deepcopy(node))
for node in main.findall(qn('edge')):
 if node.attrib['id'].startswith('G23-'):focusGraph.append(copy.deepcopy(node))
ET.ElementTree(focusRoot).write(G/'batch12_A5_Q8_C3_spectral_bridges.graphml',encoding='utf-8',xml_declaration=True)
# Further actual 15-axis C3 cycles (no evidence/catalog nodes).
G15=nx.DiGraph()
cols={int(a['id']):int(a['core_color']) for a in load('q8_hopf_e8_bridge_v120_instance.json')['axis15']}
perm=instance['Q8_axis15_intertwiner']['C3_deck_generator_on_15_axes']
for i in range(15):G15.add_node(str(i),core=int(cols[i]))
for i,j in enumerate(perm):G15.add_edge(str(i),str(j),relation='right_C3')
nx.write_graphml(G15,G/'batch12_actual_C3_on_15_axes.graphml')
# Actual projective order-three-orbit action on 60 A5 points encoded as graph.
proj=instance['A5_matrix_coefficients']['projective_120_to_60']
right60={}
for i in range(120):
 right60.setdefault(proj[i],i)
# Read C3 from actual right group action via matrices from source instance: choose
# lift of axis permutation and match projective map using full coordinate generator.
from . import exceptional_model as ex
from .q8_triality_v119 import q8_elements
H,I=ex.generate_vertices();V=sorted(I);vid={v:i for i,v in enumerate(V)}
t=next(h for h in sorted(H) if h not in q8_elements())
permt=[proj[vid[ex.qmul(V[right60[i]],t)]] for i in range(60)]
G60=nx.DiGraph()
for i in range(60):G60.add_node(str(i),kind='A5_projective_point')
for i,j in enumerate(permt):G60.add_edge(str(i),str(j),relation='right_C3_projective')
nx.write_graphml(G60,G/'batch12_actual_C3_on_60_projective_points.graphml')
# Summary stats, with computed graph component counts; dynamic, not guessed.
Gwe=nx.Graph();Gwe.add_nodes_from(o['id'] for o in objects)
Gwe.add_edges_from((e['from'],e['to']) for e in edges)
size=sorted(map(len,nx.connected_components(Gwe)),reverse=True)
Gdir=nx.DiGraph();Gdir.add_nodes_from(o['id'] for o in objects)
Gdir.add_edges_from((e['from'],e['to']) for e in edges)
reach=len(nx.descendants(Gdir,'geo:s3'))+1
counts={'new_objects':len(newO),'new_typed_relations':len(newE),'new_joint_inputs':len(link_defs),
        'new_derived_compositions':len(proofs),'cumulative_objects':len(objects),
        'cumulative_edges':len(edges),'cumulative_joint_inputs':len(joint),
        'cumulative_compositions':len(compositions),'weak_components':len(size),
        'largest_weak_component':size[0],'s3_reachable':reach}
save('data/v123_release_counts.json',counts)
coverage=json.loads((ROOT/'reports/coverage.json').read_text())
coverage.update({'release':'v1_23','batch':'Geometry-only Batch 12: A5 matrix-coefficient / right-Q8 Fourier / C3 polygon / E8 Gram rank-four bridge',
                'objects_total':len(objects),'typed_morphisms_total':len(edges),
                'joint_constructions_total':len(joint),'mathematical_composition_proofs_total':len(compositions),
                'new_objects':len(newO),'new_typed_morphisms':len(newE),'new_joint_constructions':len(link_defs),
                'new_composition_proofs':len(proofs),
                'new_objects_v1_23':len(newO),'new_edges_v1_23':len(newE),
                'new_joint_constructions_v1_23':len(link_defs),'new_derived_compositions_v1_23':len(proofs),
                'new_geometry_scope':'Exact A5 W4 matrix coefficients and cyclic-polygon character projector, Q8 4+4+4+4 Fourier splitting, C3 polygon orbit refinement and rank4 E8/Hopf/600 isometry',
                'weak_components':len(size),'largest_weak_component':size[0],
                'directed_s3_reachability':reach,'s3_directed_reachable':reach,
                'weak_component_sizes':size,'object_count':len(objects),'relation_count':len(edges),
                'joint_input_count':len(joint),'derived_composition_count':len(compositions),
                'is_exhaustive':False,'contains_proof_dag':False,'contains_physical_decay_transition_graph':False})
save('reports/coverage.json',coverage)
(Root:=ROOT/'reports/connected_components.md').write_text(
 '## v1_23 geometry-only object graph components\n\n'+
 f'- Total distinct mathematical object records: **{len(objects)}**\n'
 f'- Typed mathematical relationships: **{len(edges)}**\n'
 f'- Weak components: **{len(size)}**\n'
 f'- Largest weak component: **{size[0]}**\n'
 f'- Directed reachable from `geo:s3`, including root: **{reach}**\n'
 f'- Isolated mathematical objects: **{sum(c==1 for c in size)}**\n\n'
 'Component connectivity is NOT a proof certificate and does not include physical claims.\n')
print('ASSEMBLED:',json.dumps(counts,indent=2));print('Batch12 graph edges:',len(newE))
