#!/usr/bin/env python3
"""Geometry-only Batch 11: right-2T graph covering, E8 matching identification, C3 holonomy.

Every claim is checked by finite integer/quaternionic arithmetic and exact permutation
operations on the actual v1_21 incidence instance. No physics/claim-DAG nodes.

A 'connection' here means a CHOICE of one of the three geometric matching maps on
EACH of the ten 2T-core pairs. Such a choice is not canonical; individual nonzero
loop holonomies are not claimed to be intrinsic until a connection is specified.
"""
from __future__ import annotations
import collections, itertools, json, pathlib
from sympy.combinatorics import Permutation, PermutationGroup
from . import exceptional_model as ex
from . import q8_triality_v119 as trial
ROOT=pathlib.Path(__file__).resolve().parent.parent

def read(name):return json.loads((ROOT/'data'/name).read_text())
def pairs5():return list(itertools.combinations(range(5),2))
def invert(f):return {v:k for k,v in f.items()}
def compose(f,g):return {x:f[g[x]] for x in g}
def ppow(f,n):
 res={x:x for x in f}
 for _ in range(n):res=compose(f,res)
 return res
def parity(t):return -1 if sum(t[i]>t[j] for i in range(len(t)) for j in range(i+1,len(t)))%2 else 1

def build():
 data=read('axis15_cubic_v121_instance.json')
 common=read('q8_hopf_e8_bridge_v120_instance.json')
 original=read('exceptional_600cell_instance.json')
 H,I=ex.generate_vertices();Q=trial.q8_elements()
 assert len(H)==24 and len(Q)==8 and set(Q)<=set(H) and len(I)==120
 V=sorted(I);VI={q:i for i,q in enumerate(V)}
 assert [tuple(tuple(c) for c in rec['qcoords']) for rec in original['vertices']]==V
 E={tuple(sorted((e['u'],e['v']))) for e in original['nearest_edges']}
 assert len(E)==720 and all(ex.dot16(V[i],V[j])==(4,4) for i,j in E)
 axes=common['axis15'];assert len(axes)==15
 va={v:a['id'] for a in axes for v in a['right_vertex_fibre']}
 assert len(va)==120 and set(va.values())==set(range(15))
 colors={i:int(x['core_color']) for i,x in enumerate(axes)}
 vc={i:colors[va[i]] for i in range(120)}
 fibers={a:tuple(i for i in range(15) if colors[i]==a) for a in range(5)}
 assert all(len(v)==3 for v in fibers.values())
 # Right group actions are exact quaternion multiplications on the marked 600-cell.
 act={h:tuple(VI[ex.qmul(q,h)] for q in V) for h in H}
 assert len({f for f in act.values()})==24
 for h,f in act.items():
  assert sorted(f)==list(range(120))
  assert all(vc[i]==vc[f[i]] for i in range(120))
  assert {tuple(sorted((f[u],f[v]))) for u,v in E}==E
 for h in H:
  assert {ex.qmul(ex.qmul(h,q),ex.conj(h)) for q in Q}==set(Q) # Q8 normal in 2T
 # Both actual 120-vertex coset partition and the Q8 quotient are checked.
 grp_orbits=[];remaining=set(range(120))
 while remaining:
  v=min(remaining);orbit={f[v] for f in act.values()}
  assert len(orbit)==24 and len({vc[i] for i in orbit})==1
  grp_orbits.append(sorted(orbit));remaining-=orbit
 assert len(grp_orbits)==5
 assert {frozenset(s) for s in grp_orbits}=={frozenset(i for i in range(120) if vc[i]==k) for k in range(5)}
 # E8 weight-two matching maps, one per (unordered core pair, third core).
 matches={};match_map={}
 for rec in data['ten_pairwise_K33_one_factorizations']:
  a,b=rec['core_pair'];assert a<b
  for rr in rec['three_perfect_matchings']:
   c=int(rr['third_core']);f={int(x):int(y) for x,y in rr['matching']}
   assert set(f)==set(fibers[a]) and set(f.values())==set(fibers[b])
   matches[(a,b,c)]=tuple(sorted(f.items()))
   match_map[(a,b,c)]=f;match_map[(b,a,c)]=invert(f)
 assert len(matches)==30 and len(match_map)==60
 # ACTUAL edge orbits under full right 2T. Each has 24 600-cell edges, and
 # its Q8 suborbits yield THREE AXIS PAIRS, one matching between two core fibers.
 remaining=set(E);E_to_label={};orbits=[]
 while remaining:
  u,v=min(remaining)
  orb={tuple(sorted((f[u],f[v]))) for f in act.values()}
  assert len(orb)==24 and orb<=remaining
  remaining-=orb
  a,b=sorted((vc[u],vc[v]));assert a!=b
  induced=collections.Counter((va[x],va[y]) if vc[x]==a else (va[y],va[x]) for x,y in orb)
  assert len(induced)==3 and set(induced.values())=={8}
  match=tuple(sorted(induced))
  hit=[c for c in range(5) if (a,b,c) in matches and matches[(a,b,c)]==match]
  assert len(hit)==1,('FAILED 2T/E8 MATCHING IDENTIFICATION',a,b,match,hit)
  c=hit[0]
  for edge in orb:
   assert edge not in E_to_label
   E_to_label[edge]=(a,b,c)
  orbits.append({'core_pair':[a,b],'third_core':c,
                 'edge_representative':list(min(orb)),'size':24,
                 'axis_edge_matching':[list(x) for x in match],
                 'axis_edge_fibre_multiplicity':8,
                 'edges_600':[list(x) for x in sorted(orb)]})
 assert len(orbits)==30 and len(E_to_label)==720
 assert collections.Counter(tuple(x['core_pair']) for x in orbits)=={ab:3 for ab in pairs5()}
 assert {tuple([*o['core_pair'],o['third_core']]) for o in orbits}==set(matches)
 # Covering local-star check for BOTH 600->15 and 600->3K5, not just vertex counts.
 neighbors={v:set() for v in range(120)}
 for x,y in E:neighbors[x].add(y);neighbors[y].add(x)
 assert all(len(ns)==12 for ns in neighbors.values())
 for v in range(120):
  assert len({va[n] for n in neighbors[v]})==12
  assert collections.Counter((vc[n],E_to_label[tuple(sorted((v,n)))][2]) for n in neighbors[v])==collections.Counter(
   {(b,c):1 for b in range(5) if b!=vc[v] for c in range(5) if c not in (b,vc[v])})
 # Q8 edges partition as 90 free edge orbits of size 8, giving an 8-fold regular cover.
 Qact=[act[h] for h in Q]
 qedges=set(E);qorbits=[]
 while qedges:
  u,v=min(qedges)
  orb={tuple(sorted((f[u],f[v]))) for f in Qact}
  assert len(orb)==8 and orb<=qedges
  qedges-=orb;qorbits.append(orb)
  assert len({tuple(sorted((va[x],va[y]))) for x,y in orb})==1
 assert len(qorbits)==90
 # The C3 kernel on 15 axes is EXACTLY the residual right-2T/Q8 deck action.
 t=next(h for h in sorted(H) if h not in Q)
 full_t=act[t];assert ex.qmul(ex.qmul(t,t),t) in Q
 perm={}
 for i,x in enumerate(axes):
  hits={va[full_t[v]] for v in x['right_vertex_fibre']}
  assert len(hits)==1;perm[i]=hits.pop()
 assert sorted(perm.values())==list(range(15))
 assert all(colors[i]==colors[perm[i]] for i in range(15))
 assert ppow(perm,3)=={i:i for i in range(15)} and all(perm[i]!=i for i in range(15))
 assert all(len({a,perm[a],perm[perm[a]]})==3 for a in range(15))
 weights={tuple(r['triple']):int(r['weight']) for r in data['triple_tensor_sparse']}
 assert len(weights)==215 and collections.Counter(weights.values())=={1:180,2:30,8:5}
 assert all(weights[tuple(sorted(perm[i] for i in tri))]==w for tri,w in weights.items())
 for (a,b,c),f in match_map.items():
  assert compose(f,{x:perm[x] for x in fibers[a]})==compose({x:perm[x] for x in fibers[b]},f)
 # Exact alternating 5-core orientation law. The arbitrary choice of t specifies
 # which of the two nonidentity deck rotations is called '+1'.
 signs=[];epsilon=None
 for a,b,c,d in itertools.permutations(range(5),4):
  e=next(k for k in range(5) if k not in (a,b,c,d))
  rel=compose(invert(match_map[(a,b,d)]),match_map[(a,b,c)])
  ka={x:perm[x] for x in fibers[a]}
  sign=1 if rel==ka else -1 if rel==ppow(ka,2) else None
  assert sign is not None
  par=parity((a,b,c,d,e))
  if epsilon is None:epsilon=sign*par
  assert sign==epsilon*par
  signs.append({'ordered_4_core_labels':[a,b,c,d], 'remaining_core':e,
                'relative_deck_exponent_mod3':sign%3, 'five_label_parity':par})
 assert len(signs)==120 and epsilon in (1,-1)
 # Gauge choice: coordinate maps h_a from the 0-fiber to all five fibers;
 # each matching is a C3 shift relative to these trivializations.
 maps={0:{x:x for x in fibers[0]}}
 for b in range(1,5):
  c=min(set(range(5))-{0,b});maps[b]=match_map[(0,b,c)]
 voltage={}
 for (a,b,c),f in match_map.items():
  trivial=compose(maps[b],invert(maps[a]))
  diff=compose(f,invert(trivial))
  exp=[i for i in range(3) if diff==ppow({x:perm[x] for x in fibers[b]},i)]
  assert len(exp)==1
  voltage[(a,b,c)]=exp[0]
 assert all((v+voltage[(b,a,c)])%3==0 for (a,b,c),v in voltage.items())
 assert all(set(voltage[(a,b,c)] for c in range(5) if c not in (a,b))=={0,1,2} for a,b in pairs5())
 for a,b,c in itertools.permutations(range(5),3):
  assert (voltage[(a,b,c)]+voltage[(b,c,a)]+voltage[(c,a,b)])%3==0
 # Full table of 10 undirected core edges x 3 canonical third-core labels.
 voltage_table=[{'core_pair':[a,b], 'options':[{'third_core':c,'voltage_mod3':voltage[(a,b,c)]}
  for c in range(5) if c not in (a,b)]} for a,b in pairs5()]
 tri=list(itertools.combinations(range(5),3));pairs=pairs5();edge_index={p:i for i,p in enumerate(pairs)}
 # 3^10 connection choices, each choice one parallel base-edge per K5 pair.
 option_lists=[sorted(set(range(5))-{a,b}) for a,b in pairs]
 patterns=collections.Counter();flat=[];nonzero_hist=collections.Counter()
 for options in itertools.product(*(range(3) for _ in range(10))):
  choices=[option_lists[i][v] for i,v in enumerate(options)]
  def volt(a,b):
   A,B=sorted((a,b));c=choices[edge_index[(A,B)]]
   return voltage[(a,b,c)]
  curv=tuple((volt(a,b)+volt(b,c)+volt(c,a))%3 for a,b,c in tri)
  patterns[curv]+=1
  nonzero_hist[sum(x!=0 for x in curv)]+=1
  if all(f==0 for f in curv):flat.append(list(choices))
  F={t:curv[j] for j,t in enumerate(tri)}
  for a,b,c,d in itertools.combinations(range(5),4):
   assert (F[(b,c,d)]-F[(a,c,d)]+F[(a,b,d)]-F[(a,b,c)])%3==0
 assert len(patterns)==3**6 and set(patterns.values())=={3**4}
 assert len(flat)==3**4==81 and sum(patterns.values())==3**10==59049
 # Every oriented triangle has precisely nine assignments in each holonomy class.
 triangle_counts={}
 for a,b,c in tri:
  count=collections.Counter()
  for x in set(range(5))-{a,b}:
   for y in set(range(5))-{b,c}:
    for z in set(range(5))-{c,a}:
     f=(voltage[(a,b,x)]+voltage[(b,c,y)]+voltage[(c,a,z)])%3
     count[f]+=1
  assert count=={0:9,1:9,2:9}
  triangle_counts[','.join(map(str,(a,b,c)))]=[count[i] for i in range(3)]
 # Group refinement: exact split extension of Aut(T).
 perms3=list(itertools.permutations(range(3)))
 pos={axis:(colors[axis],fibers[colors[axis]].index(axis)) for axis in range(15)}
 W2=[tr for tr,w in weights.items() if w==2]; W2bits={sum(1<<i for i in tr) for tr in W2}
 aut=[]
 for bp in itertools.permutations(range(5)):
  for coord in itertools.product(range(6),repeat=5):
   p=tuple(fibers[bp[pos[i][0]]][perms3[coord[pos[i][0]]][pos[i][1]]] for i in range(15))
   if all(sum(1<<p[i] for i in w) in W2bits for w in W2):
    assert all(weights.get(tuple(sorted(p[i] for i in tr)),0)==wt for tr,wt in weights.items())
    aut.append(p)
 assert len(aut)==360
 group=PermutationGroup([Permutation(list(p)) for p in aut]);assert group.order()==360
 even=[p for p in aut if parity(tuple(colors[p[fibers[a][0]]] for a in range(5)))==1]
 g_even=PermutationGroup([Permutation(list(p)) for p in even]);assert len(even)==180 and g_even.order()==180
 N=g_even.derived_subgroup()
 assert N.order()==60 and N.is_normal(group)
 kernel=[p for p in aut if all(colors[p[i]]==colors[i] for i in range(15))]
 assert len(kernel)==3 and {tuple(p[i] for i in range(15)) for p in kernel}=={
  tuple(range(15)),tuple(perm[i] for i in range(15)),tuple(ppow(perm,2)[i] for i in range(15))}
 assert sum(N.contains(Permutation(list(p))) for p in kernel)==1
 transposition_lifts=[p for p in aut if tuple(colors[p[fibers[a][0]]] for a in range(5))==(1,0,2,3,4)]
 assert len(transposition_lifts)==3 and all(Permutation(list(p)).order()==2 for p in transposition_lifts)
 odd_lift=Permutation(list(transposition_lifts[0]))
 complement=PermutationGroup(list(N.generators)+[odd_lift])
 assert complement.order()==120
 assert sum(complement.contains(Permutation(list(p))) for p in kernel)==1
 # The complement maps faithfully onto S5, its action on normal C3 is sign.
 # Note that the complement itself is not required to be normal in Aut(T).
 kgen=Permutation([perm[i] for i in range(15)])
 for p in aut:
  gp=Permutation(list(p));bperm=tuple(colors[p[fibers[a][0]]] for a in range(5))
  conj=gp*kgen*~gp
  assert conj==(kgen if parity(bperm)==1 else kgen**2)
 # Exact output, no arbitrary physical interpretation.
 return {
  'schema':'S3_five_core_C3_holonomy_and_2T_graph_cover_exact_v122',
  'geometry_scope':'fixed marked 2T < 2I, right Q8 ⊳ 2T group action, and independent left-Q8 E8 root triple tensor transferred via inversion; mathematical only',
  'input_instances':['data/exceptional_600cell_instance.json','data/q8_hopf_e8_bridge_v120_instance.json','data/axis15_cubic_v121_instance.json'],
  'subgroup_indices':{'Q8_order':8,'2T_order':24,'2I_order':120,'Q8_index_in_2T':3,'2T_index_in_2I':5},
  'covering_tower':{'vertex_fibres':[120,15,5],'edge_orbits':[720,90,30],
    'group_tower':['Q8','2T/Q8 ~= C3','2T'],
    'regular_cover_degrees':[8,3,24],
    'base_multigraph':'3K5 with 5 vertices, 3 parallel edges per unordered core pair and degree 12',
    'middle_graph':'K3,3,3,3,3 with 15 vertices and degree 12',
    'top_graph':'600-cell nearest-neighbor graph 120 vertices degree 12',
    'q8_edge_orbits':90,'2T_edge_orbits':30,
    'verified_local_star_bijection':True},
  'edge_orbits_2T':sorted(orbits,key=lambda x:(x['core_pair'],x['third_core'])),
  'axis_C3_deck_generator_right_2T':list(perm[i] for i in range(15)),
  'right_2T_cosets_vertices':sorted(grp_orbits,key=lambda x:(vc[x[0]],x[0])),
  'five_axis_fibres_by_core':{str(k):list(v) for k,v in fibers.items()},
  'all_30_2T_edge_orbit_matchings_equal_weight2_E8_tensor_matchings':True,
  'Levi_Civita_relative_transport':{'definition':'D_ab^{c,d}=(M_ab^d)^(-1) M_ab^c on fiber a, with e the fifth core',
    'formula':'D_ab^{c,d}= kappa_a^(orientation_sign*sgn(a,b,c,d,e)) where kappa is right-2T generator on axes',
    'orientation_sign_for_this_marked_generator':epsilon,
    'ordered_quadruple_checks':signs,'generator_inversion_changes_all_orientation_signs':True},
  'gauge_reference':'fibre0 identity, h_b=M_(0,b)^(least other core), edge voltage modulo 3 relative to h_b h_a^-1',
  'edge_voltage_table':voltage_table,
  'face_coherent_third_core_connection_is_flat':True,
  'triangle_holonomy_counts_mod3_for_each_of_10_triangles':triangle_counts,
  'all_connection_choices':{'one_of_three_matchings_per_unordered_core_pair':True,
    'number_of_core_pairs':10,'number_total_connections':3**10,
    'number_flat_connections':81,'flat_connection_selected_third_cores_for_core_pair_order_01_02_03_04_12_13_14_23_24_34':flat,
    'number_distinct_curvature_patterns':3**6,'connections_per_curvature_pattern':3**4,
    'nonzero_triangle_curvature_histogram':{str(k):v for k,v in sorted(nonzero_hist.items())},
    'Bianchi':'For every ordered a<b<c<d, F_bcd-F_acd+F_abd-F_abc=0 (mod 3)',
    'connection_depends_on_choice':True,
    'no_preferred_nonzero_holonomy_without_choosing_a_matching_per_edge':True},
  'weighted_tensor_automorphisms':{'size':360,'kernel_right_2T_mod_Q8_size':3,
    'even_core_permutation_preimage_size':180,
    'commutator_of_even_preimage_order':60,
    'normal_complement_60_in_full_group':True,
    'odd_core_transposition_lifts':3,'odd_transposition_lifts_order':2,
    'subgroup_generated_by_A5_and_odd_involution_order':120,
    'intersection_with_C3_kernel_order':1,
    'split_group_isomorphism':'Aut(T) ~= C3 semidirect_(sign) S5',
    'orientation_reversed_by_odd_core_permutations':True},
  'nonidentifications':['The quotient of a graph by a group must retain parallel edge orbits; the 5-vertex base is 3K5, not the simple K5.',
    'Nonzero matching holonomy requires an explicit third-core choice for each traversed edge; no canonical nonzero curvature is inferred.',
    'A global flat choice of one matching per core pair exists (81 choices), but it cannot make all three matchings for every pair identical.',
    'The C3 holonomy is a purely geometric matching system, not a particle charge, phase observable, or physical decay current.',
    'The global generator kappa orientation depends on choosing one of the two generators of 2T/Q8; inversion flips all signs.']
 }

if __name__=='__main__':
 r=build()
 print('PASS: 120->15->5 regular graph covers 8x3=24, 30 2T edge orbits exactly match E8 matchings')
 print('PASS: 120 relative matching orientation checks, 81/59049 flat connections, 3^6 curvature patterns')
 print('PASS: Aut(T) split extension C3 semidirect_sign S5, exact 360 subgroup permutations')
