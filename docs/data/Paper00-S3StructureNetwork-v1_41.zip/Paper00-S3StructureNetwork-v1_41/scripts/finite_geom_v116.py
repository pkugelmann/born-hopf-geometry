#!/usr/bin/env python3
"""Recompute the marked 2I/2T, 24/600-cell, Petersen/Kneser, A5 and F4
geometry from exact quaternion/finite-permutation arithmetic. No physics.

All coordinates are in Q(sqrt5); calculations of graph incidence,
chamber and root reflection are exact integer arithmetic. The projective
A5 coordinates come from the *action on the five conjugate 2T cores*.
"""
import collections, itertools, json, pathlib, sys
from sympy import Matrix, ZZ
from sympy.matrices.normalforms import smith_normal_form
from . import exceptional_model as ex

comb=itertools.combinations

def mul(p,q): return tuple(p[q[i]] for i in range(len(p)))
def inv(p): return tuple(p.index(i) for i in range(len(p)))
def order(p):
    acc=tuple(range(len(p)))
    for n in range(1,61):
        acc=mul(acc,p)
        if acc==tuple(range(len(p))):return n
    raise ValueError('not finite A5 permutation')

def mod_rank(data,prime=101):
    a=[[int(x)%prime for x in row] for row in data]
    m=len(a);n=len(a[0]);i=0
    for j in range(n):
        pivot=next((k for k in range(i,m) if a[k][j]),None)
        if pivot is None:continue
        a[i],a[pivot]=a[pivot],a[i]
        invp=pow(a[i][j],-1,prime)
        a[i][j:]=[(x*invp)%prime for x in a[i][j:]]
        for k in range(i+1,m):
            factor=a[k][j]
            if factor:
                a[k][j:]=[(u-factor*v)%prime for u,v in zip(a[k][j:],a[i][j:])]
        i+=1
        if i==m:break
    return i

def build():
    H,I=ex.generate_vertices(); V=sorted(I); ix={q:i for i,q in enumerate(V)}
    data0=json.loads((pathlib.Path(__file__).resolve().parents[1]/'data'/'exceptional_600cell_instance.json').read_text())
    assert [tuple(tuple(z) for z in v['qcoords']) for v in data0['vertices']]==V
    cosets=[set(s) for s in data0['coset_blocks']]
    cores=[frozenset(V[i] for i in s) for s in data0['conjugate_core_groups']]
    core_lookup={s:i for i,s in enumerate(cores)}
    groupaction={q:tuple(core_lookup[frozenset(ex.qmul(ex.qmul(q,h),ex.conj(q)) for h in c)] for c in cores) for q in V}
    G=sorted(set(groupaction.values()))
    assert len(G)==60 and all(ex.parity(p)==0 for p in G)
    ids={p:i for i,p in enumerate(G)}
    assert collections.Counter(groupaction.values())==collections.Counter({p:2 for p in G})
    identity=tuple(range(5))
    assert all(mul(groupaction[q],groupaction[r])==groupaction[ex.qmul(q,r)] for q,r in itertools.product(V,V))
    reps=[min([V[i] for i in c]) for c in cosets]
    assert all(groupaction[r][0]==i for i,r in enumerate(reps))

    A=[[0]*120 for _ in range(120)]
    for e in data0['nearest_edges']:
        A[e['u']][e['v']]=A[e['v']][e['u']]=1
    assert sum(map(sum,A))==1440 and all(sum(r)==12 for r in A)
    B=[[int(groupaction[q][j]==i) for j in range(5) for i in range(5)] for q in V]
    assert all(sum(row)==5 for row in B) and all(sum(B[q][i] for q in range(120))==24 for i in range(25))
    for u in range(120):
        for a in range(25):
            assert sum(A[u][v]*B[v][a] for v in range(120))==3*(1-B[u][a])
    Bm=Matrix(B);gram=Bm.T*Bm
    for a in range(25):
        i,j=a%5,a//5
        for b in range(25):
            k,l=b%5,b//5
            assert gram[a,b]==(24 if a==b else (6 if i!=k and j!=l else 0))
    B60=Matrix([[int(p[j]==i) for j in range(5) for i in range(5)] for p in G])
    assert B60.rank()==17
    snf=smith_normal_form(B60,domain=ZZ)
    factors=[abs(int(snf[i,i])) for i in range(25) if snf[i,i]]
    assert factors==[1]*17  # saturated integer column image, 8 relations
    # Write rank-16 projector P=(BB' - J)/30. Let N=30P, check N²=30N.
    N=Bm*Bm.T-Matrix.ones(120,120)
    assert N*N==30*N
    assert Matrix(A)*N==-3*N
    assert N.trace()==480
    # Mod-101 lower rank of A+3I, combined with 16 explicit eigenvectors
    # gives exact rational nullity 16 (and hence the complete -3 eigenspace).
    arank=mod_rank([[A[i][j]+(3 if i==j else 0) for j in range(120)] for i in range(120)])
    assert arank==104

    # 25 transporter 24-cells are all left-right H images, and five 5-color partitions.
    hids={ix[h] for h in H}
    L=[[ix[ex.qmul(g,q)] for q in V] for g in reps]
    R=[[ix[ex.qmul(q,ex.conj(g))] for q in V] for g in reps]
    transporters=[]
    for j in range(5):
        for i in range(5):
            T=[L[i][R[j][v]] for v in range(120)]
            C=sorted(T[v] for v in hids)
            assert C==[q for q in range(120) if groupaction[V[q]][j]==i]
            transporters.append(C)
    assert len({tuple(C) for C in transporters})==25
    assert all(len(set(C)&set(D))==(24 if k==l else 6 if (k%5!=l%5 and k//5!=l//5) else 0)
               for k,C in enumerate(transporters) for l,D in enumerate(transporters))
    # Maximal simplices of the 600-cell: 600 tetrahedra, 1200 triangles.
    adj=[{j for j in range(120) if A[i][j]} for i in range(120)]
    tetra=sorted({tuple(sorted((u,a,b,c))) for u in range(120) for a,b,c in comb(sorted(adj[u]),3)
                  if b in adj[a] and c in adj[a] and c in adj[b]})
    assert len(tetra)==600
    chamber_index={t:i for i,t in enumerate(tetra)}
    assert all(sum(i in t for t in tetra)==20 for i in range(120))
    pair_facets=collections.Counter(pair for f in tetra for pair in comb(f,2))
    assert all(pair_facets.get((i,j),0)==5*A[i][j] for i,j in comb(range(120),2))
    face_owners=collections.defaultdict(list)
    for t in tetra:
        for face in comb(t,3):face_owners[face].append(chamber_index[t])
    assert len(face_owners)==1200 and all(len(fs)==2 for fs in face_owners.values())
    # Face-adjacency graph of tetrahedral chambers, regular degree 4.
    camp=[set() for _ in tetra]
    for owners in face_owners.values():
        u,v=owners;camp[u].add(v);camp[v].add(u)
    assert all(len(r)==4 for r in camp)
    # Choose the unique HxH orbit of 24 chambers avoiding H, then translate.
    h=sorted(H)
    lH=[[ix[ex.qmul(g,q)] for q in V] for g in h]
    rH=[[ix[ex.qmul(q,ex.conj(g))] for q in V] for g in h]
    hh_maps=[[ll[rr[v]] for v in range(120)] for ll in lH for rr in rH]
    possible=[]
    for t in tetra:
        if set(t)&hids:continue
        orbit={tuple(sorted(mp[v] for v in t)) for mp in hh_maps}
        if len(orbit)==24:
            possible.append(orbit);break
    assert possible, 'no core complement orbit of 24 tetrahedra'
    F00=possible[0]
    assert len({v for t in F00 for v in t})==96 and all(sum(v in t for t in F00)==1 for v in set(range(120))-hids)
    chamberblocks=[]
    for j in range(5):
        for i in range(5):
            T=[L[i][R[j][v]] for v in range(120)]
            block=sorted(chamber_index[tuple(sorted(T[v] for v in t))] for t in F00)
            assert len(block)==24 and all(not set(tetra[t])&set(transporters[j*5+i]) for t in block)
            chamberblocks.append(block)
    assert len(set().union(*(set(block) for block in chamberblocks)))==600
    U=[[int(t in block) for block in chamberblocks] for t in range(600)]
    assert all(sum(row)==1 for row in U)
    for v in range(120):
        for k in range(25):
            assert sum(v in tetra[t] for t in chamberblocks[k])==1-B[v][k]
    for t in range(600):
        for k in range(25):
            lhs=sum(B[v][k] for v in tetra[t])
            rhs=1-U[t][k]-sum(U[s][k] for s in camp[t])
            assert lhs==rhs
    faceblockmatrix=[[0]*25 for _ in range(25)]
    cb={ch:i for i,block in enumerate(chamberblocks) for ch in block}
    for t in range(600):
        for n in camp[t]:faceblockmatrix[cb[t]][cb[n]]+=1
    for a in range(25):
        for b in range(25):
            assert faceblockmatrix[a][b]==(6 if a%5!=b%5 and a//5!=b//5 else 0)

    # Projective A5 polygons in class orders 2/3/5 (722 cosets).
    polygons={};M={};subgroups={}
    for k in (2,3,5):
        cyclic=set()
        for g in G:
            if order(g)!=k:continue
            elems=[];q=identity
            for _ in range(k):elems.append(q);q=mul(q,g)
            cyclic.add(frozenset(elems))
        subgroups[k]=sorted(cyclic,key=lambda h:sorted(h))
        cellset=set()
        for hh in subgroups[k]:
            for g in G:
                cellset.add(frozenset(mul(g,q) for q in hh))
        polygons[k]=sorted([sorted(ids[q] for q in cell) for cell in cellset])
        M[k]=[[0]*60 for _ in range(60)]
        for cell in polygons[k]:
            for u in cell:
                for v in cell:M[k][u][v]+=1
    assert {k:len(v) for k,v in polygons.items()}=={2:450,3:200,5:72}
    assert {k:len(v) for k,v in subgroups.items()}=={2:15,3:10,5:6}
    # Every nonempty intersection of two different transporter 24-cells
    # is exactly a 6-vertex lift of one of the 200 projective C3 hexagons.
    hexagon_projective={tuple(sorted(ids[groupaction[V[v]]] for v in set(transporters[a])&set(transporters[b])))
                        for a,b in comb(range(25),2) if len(set(transporters[a])&set(transporters[b]))==6}
    # Each projective point appears twice among the six binary vertices.
    hexagon_projective={tuple(sorted(set(h))) for h in hexagon_projective}
    assert hexagon_projective=={tuple(c) for c in polygons[3]} and len(hexagon_projective)==200
    assert all(M[2][i][j]+M[3][i][j]+M[5][i][j]==(31 if i==j else 1)
               for i in range(60) for j in range(60))
    assert all(M[3][i][j]-M[5][i][j]==sum(B60[i,k]*B60[j,k] for k in range(25))-1
               for i in range(60) for j in range(60))
    M3m=Matrix(M[3]);M5m=Matrix(M[5]);P4=(M3m-M5m)
    assert P4*P4==15*P4 and P4.trace()==240
    assert P4.rank()==16
    # N on 600 = lift of 60-point kernel via the antipodal pairing of groupaction.
    for u in range(120):
        for v in range(120):
            assert N[u,v] == P4[ids[groupaction[V[u]]],ids[groupaction[V[v]]]]

    # Dual six fivefold axes (Sylow5), A5 equivariant Petersen face maps.
    f5=subgroups[5];f5ix={frozenset(c):i for i,c in enumerate(f5)}
    act6={g:tuple(f5ix[frozenset(mul(mul(g,h),inv(g)) for h in s)] for s in f5) for g in G}
    triples=list(comb(range(6),3));to_visit=set(triples);triangle_orbits=[]
    while to_visit:
        tri=min(to_visit)
        orbit={tuple(sorted(act6[g][i] for i in tri)) for g in G}
        triangle_orbits.append(sorted(orbit));to_visit-=orbit
    assert list(map(len,triangle_orbits))==[10,10]
    assert {tuple(sorted(set(range(6))-set(t))) for t in triangle_orbits[0]}==set(triangle_orbits[1])
    five_pairs=list(comb(range(5),2));pair0=five_pairs[0]
    pair_stab=[g for g in G if tuple(sorted(g[i] for i in pair0))==pair0]
    assert len(pair_stab)==6
    petr_maps=[];dual_edges=[]
    for orbit in triangle_orbits:
        fixed=[tri for tri in orbit if all(tuple(sorted(act6[g][i] for i in tri))==tri for g in pair_stab)]
        assert len(fixed)==1
        mp={}
        for g in G:
            p=tuple(sorted(g[i] for i in pair0));t=tuple(sorted(act6[g][i] for i in fixed[0]))
            if p in mp: assert mp[p]==t
            mp[p]=t
        assert len(mp)==10
        for p,q in comb(five_pairs,2):
            assert (not(set(p)&set(q))) == (len(set(mp[p])&set(mp[q]))==2)
        freq=collections.Counter(t for tri in orbit for t in tri)
        efreq=collections.Counter(tuple(sorted(e)) for tri in orbit for e in comb(tri,2))
        assert len(freq)==6 and set(freq.values())=={5}
        assert len(efreq)==15 and set(efreq.values())=={2}
        # At each vertex, its five incident triangles form a five-cycle link.
        for v in range(6):
            link_edges={tuple(sorted(x for x in tri if x!=v)) for tri in orbit if v in tri}
            links=collections.defaultdict(set)
            for a,b in link_edges:links[a].add(b);links[b].add(a)
            assert len(link_edges)==5 and len(links)==5 and all(len(z)==2 for z in links.values())
            seen_link={next(iter(links))};work=list(seen_link)
            while work:
                t=work.pop()
                for w in links[t]:
                    if w not in seen_link:seen_link.add(w);work.append(w)
            assert len(seen_link)==5
        dual=sorted([tuple(sorted((i,j))) for i,j in comb(range(10),2) if len(set(orbit[i])&set(orbit[j]))==2])
        assert len(dual)==15
        petr_maps.append([list(mp[p]) for p in five_pairs]);dual_edges.append(dual)
    kn_pairs=list(comb(range(6),2))
    KG=Matrix([[int(i!=j and not(set(p)&set(q))) for j,q in enumerate(kn_pairs)] for i,p in enumerate(kn_pairs)])
    assert KG.charpoly().as_expr().factor()==(KG.charpoly().gen-6)*(KG.charpoly().gen-1)**9*(KG.charpoly().gen+3)**5
    # Hodge on oriented core pairs, using epsilon tensor.
    pairs=five_pairs;pidx={p:i for i,p in enumerate(pairs)}
    SH=Matrix.zeros(10);contraction=Matrix.zeros(5,10)
    for idx,(i,j) in enumerate(pairs):
        contraction[i,idx]=-1;contraction[j,idx]=1
        for k in range(5):
            if k in (i,j):continue
            pq=tuple(u for u in range(5) if u not in (k,i,j))
            sign=(-1)**sum([a>b for pos,a in enumerate((k,i,j)+pq) for b in ((k,i,j)+pq)[pos+1:]])
            SH[pidx[pq],idx]+=sign
    assert SH==SH.T and SH**3==5*SH and contraction*SH==Matrix.zeros(5,10)
    assert SH**2+contraction.T*contraction==5*Matrix.eye(10)
    assert SH.rank()==6 and SH.trace()==0 # three +sqrt(5), three -sqrt(5), four zero eigenvalues
    assert all((SH[i,j]!=0)==(i!=j and not(set(p)&set(q))) for i,p in enumerate(pairs) for j,q in enumerate(pairs))

    # Hurwitz 24-cell: 24 roots / 96 edges / 96 triangles / 24 octahedra.
    hh=sorted(H);hix={q:i for i,q in enumerate(hh)}
    Hedges=sorted((i,j) for i,j in comb(range(24),2) if ex.dot16(hh[i],hh[j])==(8,0))
    Hedgeset=set(Hedges)
    Hfaces=sorted((i,j,k) for i,j,k in comb(range(24),3) if all(tuple(sorted(e)) in Hedgeset for e in comb((i,j,k),2)))
    Hcells=[]
    for i,j in comb(range(4),2):
        for a,b in itertools.product((-1,1),repeat=2):
            normal=[0]*4;normal[i]=a;normal[j]=b
            face=tuple(idx for idx,q in enumerate(hh) if sum(normal[t]*q[t][0] for t in range(4))==4)
            assert len(face)==6
            Hcells.append(face)
    assert (len(Hedges),len(Hfaces),len(set(Hcells)))==(96,96,24)
    assert all(sum(set(f)<=set(c) for c in Hcells)==2 for f in Hfaces)
    M=Matrix([[int(set(edge)<=set(face)) for face in Hfaces] for edge in Hedges])
    assert M.rank()==73
    assert all((M.T*M)[i,i]==3 for i in range(96))
    assert all(sum(1 for j in range(96) if i!=j and (M.T*M)[i,j])==6 for i in range(96))
    assert all(M.T*M == Matrix(M.T*M) for _ in range(1))
    # F4 root system from Hurwitz short roots and D4 long roots; reflection closure.
    short={tuple(q[i][0]//2 for i in range(4)) for q in hh}
    long=set()
    for i,j in comb(range(4),2):
        for a,b in itertools.product((-2,2),repeat=2):
            coord=[0]*4;coord[i]=a;coord[j]=b;long.add(tuple(coord))
    roots=sorted(short|long);rix={r:i for i,r in enumerate(roots)}
    assert len(short)==len(long)==24 and len(roots)==48
    for r in roots:
        d=sum(x*x for x in r)
        for v in roots:
            t=2*sum(x*y for x,y in zip(r,v))
            assert t%d==0
            assert tuple(v[i]-(t//d)*r[i] for i in range(4)) in rix
    simple=[(0,2,-2,0),(0,0,2,-2),(0,0,0,2),(1,-1,-1,-1)]
    reflections=[]
    for u in simple:
        d=sum(x*x for x in u)
        reflections.append(tuple(rix[tuple(v[i]-(2*sum(x*y for x,y in zip(u,v))//d)*u[i] for i in range(4))] for v in roots))
    seen={tuple(range(48))};stack=list(seen)
    while stack:
        p=stack.pop()
        for q in reflections:
            r=tuple(p[q[i]] for i in range(48))
            if r not in seen:seen.add(r);stack.append(r)
    assert len(seen)==1152

    return {
      'basis':{'v600':120,'edges600':720,'vertices24':24,'core_subgroup_order':24,'projective_group':'2I/{±1}=A5','source_geometry':'marked quaternionic 2I, not both twin completions'},
      'permutation_A5':{'order':60,'core_conjugation_permutation_at_vertex':[list(groupaction[q]) for q in V], 'permutations':[list(p) for p in G], 'central_fibre':2},
      'transporter_24cells':{'columns_labels':'j=0..4 outer then i=0..4 inner','sets':transporters,'vertex_chamber_absence_partitions':chamberblocks,'B_rank':17,'B60_SNF_invariant_factors':factors,'B60_integral_kernel_dimension':8,'Aplus3_rank_mod101':arank,'minus3_projector_formula':'(B_120 B_120^T-J_120)/30','A_B_formula':'A_600 B_120=3(J_120x25-B_120)','projector_rank':16,'transporter_Gram':'B^T B=24 I_25 + 6((J_5-I_5)⊗(J_5-I_5))'},
      'chambers':{'tetrahedra':tetra,'triangles_count':len(face_owners),'chamber_face_degree':4,'TtT':'20 I_120+5 A_600','TU':'T^T U=J_120x25-B_120','facewalk':'T B=J_600x25-(I_600+A_chamber) U','blockwalk':'U^T A_chamber U=6((J_5-I_5)⊗(J_5-I_5))','matrix':faceblockmatrix,'counts':{'chambers':600,'blocks':25,'chambers_per_block':24}},
      'projective_cyclic_design':{'poly_counts':{str(k):len(polygons[k]) for k in (2,3,5)},'poly_points':{str(k):k for k in (2,3,5)},'polygons':{str(k):polygons[k] for k in (2,3,5)},'M2M3M5_sum':'30 I_60+J_60','M3_minus_M5':'B60 B60^T-J_60','P4':'(M3-M5)/15','projector_lift':'P_minus3^600 = L (M3-M5) L^T /30'},
      'petersen_kneser':{'five_core_pairs':[list(t) for t in five_pairs], 'six_Sylow5_axes':[[[list(p) for p in sorted(hh)] for hh in f5][i] for i in range(6)],'two_RP2_triangle_orbits':[[list(t) for t in orbit] for orbit in triangle_orbits], 'equivariant_petersen_triangle_maps':petr_maps,'dual_petersen_edges':[[list(e) for e in d] for d in dual_edges], 'KG6_2_vertices':[list(p) for p in kn_pairs],'KG6_2_spectrum':{'6':1,'1':9,'-3':5},'signed_hodge_matrix':[[int(SH[i,j]) for j in range(10)] for i in range(10)],'contraction_matrix':[[int(contraction[i,j]) for j in range(10)] for i in range(5)],'hodge_relations':['B S=0','S³=5S','BᵀB+S²=5I']},
      'hurwitz_F4':{'24cell_edges':[list(e) for e in Hedges], '24cell_triangles':[list(e) for e in Hfaces], '24cell_octahedral_facets':[list(e) for e in Hcells], 'f_vector':[24,96,96,24], 'rank_unsigned_edge_face':73,'nullity_unsigned_edge_face':23,'F4_scaled_short_roots':[list(x) for x in sorted(short)],'F4_scaled_long_roots':[list(x) for x in sorted(long)],'F4_root_count':48,'W_F4_order':len(seen),'coordinate_scaling':'integer vectors are twice the physical short and long root coordinates; squared norms 4 and 8'}
    }

if __name__=='__main__':
    root=pathlib.Path(__file__).resolve().parents[1]
    x=build()
    p=root/'data'/'finite_geometry_v116_instance.json'
    p.write_text(json.dumps(x,indent=2,ensure_ascii=False,sort_keys=True)+'\n')
    print('GENERATED',p, 'bytes',p.stat().st_size)
    print('25 registers / 600 chambers / 722 projective polygons / two RP2 triangulations / F4 Weyl order 1152; exact checks PASS')
