#!/usr/bin/env python3
"""Independent exact / numerical certificates for S3 graph Batch21, v1_32.
Only mathematical comparison models; not the source theorem proof DAG.
"""
from __future__ import annotations
import itertools,math,json,sys
from fractions import Fraction
from pathlib import Path
from collections import Counter
import numpy as np
import sympy as sp
from scipy.spatial import ConvexHull
from scipy.special import sph_harm_y

IN=Path(__file__).resolve().parents[1]
OUT=IN/'data'/'structure_closure_v132_instance.json'

def group_nonet():
    allp=itertools.permutations(range(5))
    G=[p for p in allp if sum(p[i]>p[j] for i in range(5) for j in range(i+1,5))%2==0]
    assert len(G)==60
    comp=lambda p,q:tuple(p[q[i]] for i in range(5))
    inv=lambda p:tuple(p.index(i) for i in range(5))
    t=(1,2,3,4,0)
    c5a={comp(comp(g,t),inv(g)) for g in G}; c5b={comp(comp(g,comp(t,t)),inv(g)) for g in G}
    assert len(c5a)==len(c5b)==12 and c5a.isdisjoint(c5b)
    pairs=[(i,j) for i in range(5) for j in range(5) if i!=j]
    lookup={p:i for i,p in enumerate(pairs)}
    A=np.zeros((20,20),dtype=np.int64);B=A.copy();S=A.copy();F=A.copy();Tot=A.copy()
    classes=Counter()
    group_actions=[]
    for g in G:
        seen=set(); lens=[]
        for i in range(5):
            if i in seen:continue
            q=i;L=0
            while q not in seen:
                seen.add(q);q=g[q];L+=1
            lens.append(L)
        order=math.lcm(*lens)
        cl='1' if order==1 else ('2' if order==2 else ('3' if order==3 else ('5a' if g in c5a else '5b')))
        classes[cl]+=1
        aa,bb={'1':(6,0),'2':(-2,0),'3':(0,0),'5a':(1,1),'5b':(1,-1)}[cl]
        c5={'1':5,'2':1,'3':-1,'5a':0,'5b':0}[cl]
        c4={'1':4,'2':0,'3':1,'5a':-1,'5b':-1}[cl]
        perm20=[lookup[(g[i],g[j])] for i,j in pairs]
        group_actions.append(perm20)
        for column,row in enumerate(perm20):
            A[row,column]+=aa; B[row,column]+=bb;S[row,column]+=c5;F[row,column]+=c4;Tot[row,column]+=1
    # Idempotents: P1=Tot/60, P5=S/12, P3=(A+sqrt5 B)/40, P4=F/15
    # P9=(U+sqrt5 V)/120; exact idempotence is two integer equations.
    U=2*Tot+10*S+3*A; V=3*B
    assert np.array_equal(U@U+5*V@V,120*U)
    assert np.array_equal(U@V+V@U,120*V)
    assert np.array_equal(U,U.T) and np.array_equal(V,V.T)
    assert int(np.trace(U))==9*120 and int(np.trace(V))==0
    assert np.array_equal(U@U+5*V@V,120*U)
    # Group equivariance: matrices commute with ALL 60 permutation actions.
    for perm in group_actions:
        assert np.array_equal(U[np.ix_(perm,perm)],U)
        assert np.array_equal(V[np.ix_(perm,perm)],V)
    eig=np.linalg.eigvalsh((U+math.sqrt(5)*V)/120)
    assert np.max(np.abs(eig[:11]))<1e-10 and np.max(np.abs(eig[11:]-1))<1e-10
    return {'exact_field':'Q(sqrt(5))','group':'A5 even permutations of 5 cores','group_order':60,
     'conjugacy_class_cardinalities':dict(sorted(classes.items())),'ordered_pairs':pairs,
     'projector_P9_numerator_U_20x20':U.tolist(),'projector_P9_sqrt5_numerator_V_20x20':V.tolist(),
     'projector_common_denominator':120,'formula':'P9=(U+sqrt(5)*V)/120=P_1+P_5+P_3',
     'exact_idempotence':['U^2+5V^2=120U','UV+VU=120V'],
     'exact_group_equivariance':'[P9,rho(g)]=0 for all 60 g',
     'eigenvalue_multiplicities':{'0':11,'1':9},
     'representation_decomposition':'20=(1+4+5)+(4+3+3prime); P9 selects 1+3+5; class 5a marking distinguishes 3/3prime',
     'nonidentification':'P9 is A5 comparison geometry only; no physical meson pole, coupling or mass.'}

def hurwitz_24():
    V=[]
    for i in range(4):
      for sgn in [-1,1]:
        a=[sp.S(0)]*4;a[i]=sp.S(sgn);V.append(a)
    for ss in itertools.product([-1,1],repeat=4):V.append([sp.Rational(q,2) for q in ss])
    assert len(V)==24 and len({tuple(v) for v in V})==24
    P0=sp.ones(24)/24
    P2=sp.Matrix(24,24,lambda i,j:(4*sum(V[i][k]*V[j][k] for k in range(4))**2-1)/8)
    K=sp.Matrix(24,24,lambda i,j:(1+16*sum(V[i][k]*V[j][k] for k in range(4))**2)/120)
    assert P0*P0==P0 and P2*P2==P2 and P0*P2==sp.zeros(24)
    assert K==P0+sp.Rational(4,15)*P2
    assert sp.trace(P0)==1 and sp.trace(P2)==9
    assert K*P0==P0 and K*P2==sp.Rational(4,15)*P2
    return {'vertex_count':24,'kernel_formula':'K(q,r)=(1+16(q dot r)^2)/120=P0+(4/15)P2',
       'projector_formulas':{'P0':'1/24','P2':'(4(q dot r)^2-1)/8'},'exact_rank':{'P0':1,'P2':9},
       'exact_eigenvalues':{'1':1,'4/15':9,'0':14},
       'strict_scope':'24-cell even quadratic incidence restriction only; source P17 return/polar normalization not independently regenerated here'}

def tenaxes():
    j=json.loads((IN/'data/ten_axis_projectors_v126_instance.json').read_text())
    Ps=[sp.Matrix([[sp.sympify(v) for v in row] for row in p['projector_3x3']]) for p in j['projectors']]
    assert len(Ps)==10
    assert sum(Ps,sp.zeros(3))==sp.Rational(10,3)*sp.eye(3)
    assert all((P*P-P).applyfunc(sp.simplify)==sp.zeros(3) and sp.simplify(sp.trace(P)-1)==0 for P in Ps)
    gram=sum((sp.eye(3)-P for P in Ps),sp.zeros(3))/10/4
    assert gram==sp.eye(3)/6
    return {'axes':10,'input_path':'data/ten_axis_projectors_v126_instance.json',
      'exact_rank1_projectors':True,'tight_frame_sum':'sum_i P_i=(10/3)I3',
      'averaged_normalized_complement_Gram':'(1/10)sum_i(I-P_i)/4=I3/6',
      'nonet_extension':'With a chosen isometric triplet projection T:N9->R3 and a supplied E36 scalar, G36=(E36^2/6)P3',
      'scope':'No claim that E36 is a physical nonet pole mass'}

def petersen_wedge():
    verts=list(itertools.combinations(range(5),2))
    edges=[(i,j) for i,a in enumerate(verts) for j,b in enumerate(verts) if i<j and not set(a)&set(b)]
    assert len(verts)==10 and len(edges)==15
    assert len(list(itertools.combinations(range(10),2)))==45
    # canonical coordinate projection from 45-dim exterior square to 15 Petersen edges
    P=np.zeros((15,45),int)
    domain=list(itertools.combinations(range(10),2));lookup={a:i for i,a in enumerate(domain)}
    for i,e in enumerate(edges):P[i,lookup[e]]=1
    assert np.array_equal(P@P.T,np.eye(15,dtype=int))
    assert np.array_equal(P.T@P@P.T,P.T)
    return {'petersen_vertices':10,'petersen_edges':15,'source_exterior_dimension':45,
      'matrix_15x45':P.tolist(),'exact_orthogonal_projection':True,
      'JdaggerJ_eigenvalues':{'1':15,'0':30},
      'A5_equivariance':'Induced signed wedge action permutes the 15 disjoint-pair coordinate wedges',
      'scope':'Surjective A5-equivariant exterior multiplication comparison; no two-meson mass splitting from one projector'}

def spectral_compat():
    k,m,R=sp.symbols('k m R',positive=True)
    lam=k*(k+2)/R**2
    kin=lam*m**2/(lam+m**2)
    pot=m**2*lam
    assert sp.simplify(pot/kin-(lam+m**2))==0
    L=sp.symbols('L',integer=True,nonnegative=True)
    j=sp.symbols('j',integer=True,nonnegative=True)
    assert sp.simplify(sp.summation((j+1)**2,(j,0,L))-(L+1)*(L+2)*(2*L+3)/6)==0
    H,a,c,d=sp.symbols('H a c d',positive=True)
    # Frozen-coefficient retarded mode kernel satisfies (3H/c^2)*(d/dt+Gamma)G=delta.
    Gamma=H+c**2*d/(3*H*a*a)
    tt,ss=sp.symbols('t s',real=True)
    G=c*c/(3*H)*sp.exp(-Gamma*(tt-ss))
    assert sp.simplify(3*H/c**2*(sp.diff(G,tt)+Gamma*G))==0
    assert sp.simplify(G.subs(tt,ss)*3*H/c**2-1)==0
    return {'scalar_eigenvalues':'lambda_k=k(k+2)/R^2','round_S3_scalar_degeneracy':'(k+1)^2',
      'band_dimension':'sum_{k=0}^L (k+1)^2=(L+1)(L+2)(2L+3)/6',
      'mean_zero_green':'R^2/[k(k+2)] (k>=1)',
      'positive_frequency_model':'sqrt(c^2*lambda_k+m^2), conditional on a one-particle admissible reducing block',
      'proca_longitudinal':'K_k=lambda_k m^2/(lambda_k+m^2), M_k=m^2 lambda_k; omega_k^2=M_k/K_k=lambda_k+m^2 for k>=1,m>0',
      'k_zero':'no gradient longitudinal mode since dY_0=0',
      'frozen_cold_retarded':'Theta(t-s)c^2/(3H)exp(-(H+c^2d/(3Ha^2))(t-s)), H,a,c,d>0',
      'exact_identity_checks':True,
      'scope':'Model spectral compositions on round S3; do not equate Proca, physical Maxwell, scalar particle, or cosmological constraints merely by a shared lambda_k'}

def hamiltonian_aux():
    T=sp.diag(2,sp.Rational(1,2),sp.Rational(1,2))
    H=sp.BlockMatrix([[sp.zeros(3),T],[T,sp.zeros(3)]]).as_explicit()
    z=sp.symbols('z')
    pol=sp.factor(H.charpoly(z).as_expr())
    assert sp.expand(pol-(z-2)*(z+2)*(z-sp.Rational(1,2))**2*(z+sp.Rational(1,2))**2)==0
    X=(z*sp.eye(3))*(z*z*sp.eye(3)-T*T).inv()
    assert sp.simplify(X[0,0]-z/(z*z-4))==0
    assert sp.simplify(X[1,1]-z/(z*z-sp.Rational(1,4)))==0
    return {'chosen_T_diagonal':['2','1/2','1/2'],'chosen_TdaggerT':['4','1/4','1/4'],
        'charpoly':'(z^2-4)(z^2-1/4)^2',
        'eigenvalues':['-2','-1/2','-1/2','1/2','1/2','2'],
        'upper_resolvent':'z*(P_a/(z^2-4)+P_t/(z^2-1/4))',
        'scope':'A singular-value-normal representative of auxiliary pair operator; not physical resonance frequencies'}

def hermitian_jordan():
    a,u,v,w,p,q=sp.symbols('a u v w p q',real=True)
    Q=sp.diag(p,q,-p-q)
    A=sp.Matrix([[0,-w,v],[w,0,-u],[-v,u,0]])
    X=a*sp.eye(3)+Q+sp.I*A
    lhs=sp.expand(X.det())
    rhs=sp.expand(a**3-a/2*((Q*Q).trace()+2*(u*u+v*v+w*w))+(Q*Q*Q).trace()/3- (sp.Matrix([u,v,w]).T*Q*sp.Matrix([u,v,w]))[0])
    assert sp.simplify(lhs-rhs)==0
    # Test Jordan identity on generic small Hermitian matrices.
    A1=sp.Matrix([[1,2+sp.I,0],[2-sp.I,-2,1],[0,1,0]])
    B1=sp.Matrix([[2,1,-sp.I],[1,0,2],[sp.I,2,-1]])
    jordan=lambda X,Y:(X*Y+Y*X)/2
    assert (jordan(jordan(A1,A1),jordan(A1,B1))-jordan(A1,jordan(jordan(A1,A1),B1))).applyfunc(sp.simplify)==sp.zeros(3)
    return {'real_dimension':9,'decomposition':'Herm3(C)=R I + i so(3) + Sym0(3,R): 1+3+5',
       'jordan_product':'(XY+YX)/2','compact_bracket':'-i[X,Y] on Hermitian traceless matrices',
       'trace_det_formula':'det(aI+Q+iA(v))=a^3-a/2*(trQ^2+2|v|^2)+trQ^3/3-v^TQv',
       'exact_checks':['symbolic determinant polynomial','Jordan identity on an explicit pair'],
       'scope':'Mathematical transported algebra under a chosen A5 equivariant isometry; not a physical meson dynamics compiler'}

def angular62():
    phi=(1+5**0.5)/2
    verts=np.array([(0,s,t*phi) for s in [-1,1] for t in [-1,1]]+
                   [(s,t*phi,0) for s in [-1,1] for t in [-1,1]]+
                   [(t*phi,0,s) for s in [-1,1] for t in [-1,1]],float)
    verts=verts/np.linalg.norm(verts,axis=1)[:,None]
    hull=ConvexHull(verts)
    assert len(hull.simplices)==20
    faces=[tuple(sorted(x)) for x in hull.simplices]
    edges=sorted({tuple(sorted((i,j))) for face in faces for i,j in itertools.combinations(face,2)})
    assert len(edges)==30
    vc=verts
    ec=np.array([(verts[i]+verts[j])/np.linalg.norm(verts[i]+verts[j]) for i,j in edges])
    fc=np.array([sum(verts[list(f)]) / np.linalg.norm(sum(verts[list(f)])) for f in faces])
    pts=np.vstack([fc,ec,vc]); w=np.array([81/(462*20)]*20+[256/(462*30)]*30+[125/(462*12)]*12)
    assert len(w)==len(pts)==62 and abs(sum(w)-1)<1e-14
    def harmonics(L):
       theta=np.arccos(np.clip(pts[:,2],-1,1));az=np.arctan2(pts[:,1],pts[:,0])
       return np.column_stack([sph_harm_y(l,m,theta,az) for l in range(L+1) for m in range(-l,l+1)])
    Y=harmonics(6)
    frame=Y[:,:36]*np.sqrt(4*np.pi*w)[:,None]
    gram=frame.conj().T@frame
    e1=float(np.max(abs(gram-np.eye(36))))
    leakage=float(np.max(abs(frame.conj().T@(Y[:,36:]*np.sqrt(4*np.pi*w)[:,None]))))
    assert e1<2e-13 and leakage<2e-13
    return {'orbit_counts':{'face_centers':20,'edge_midpoints':30,'vertices':12},
      'orbit_weight_each':{'face_centers':'81/(462*20)','edge_midpoints':'256/(462*30)','vertices':'125/(462*12)'},
      'total_weight':1,'degree5_frame_dimension':36,'spherical_cubature_proven_degree':11,
      'numerical_frame_gram_max_abs_error':e1,'numerical_degree6_to_degree5_aliasing_max_abs':leakage,
      'scope':'The source supplies exact degree-11 cubature proof; this independent instance replays numeric 62-node quadrature, not symbolic algebraic proof. A sky transfer function remains separately assumed.'}

def main():
    d={'version':'v1_32','parent':'v1_31','release_scope':'Strict mathematical object graph extension; no physics, no proof/evidence DAG changes',
      'nonet_A5_directed_pairs':group_nonet(),'hurwitz_quadratic_even_incidence':hurwitz_24(),
      'ten_axis_nonet_triplet_gram':tenaxes(),'petersen_exterior_pair':petersen_wedge(),
      'round_S3_spectral_compatibility':spectral_compat(),'auxiliary_chiral_six':hamiltonian_aux(),
      'Herm3_jordan':hermitian_jordan(),'icosahedral_62node_frame':angular62()}
    if '--write' in sys.argv:
        OUT.parent.mkdir(parents=True,exist_ok=True)
        OUT.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
    else:
        assert OUT.is_file(), 'Regeneration certificate file missing'
        assert json.loads(json.dumps(d))==json.loads(OUT.read_text()), 'Regeneration mismatch against release artifact'
    print('PASS new v132 mathematical certificates: nonet P9 exact Qsqrt5, 24cell 10even, ten-axis Gram, A5 wedge, scalar mode, auxiliary H6, Herm3, 62 sky')
    print('PASS exact P9 ranks 9+11; exact Hurwitz 1+9+14; sky numerical orthogonal frame',d['icosahedral_62node_frame']['numerical_frame_gram_max_abs_error'])
if __name__=='__main__':main()
