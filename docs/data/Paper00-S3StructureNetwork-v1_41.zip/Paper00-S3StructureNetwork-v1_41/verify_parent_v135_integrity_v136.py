#!/usr/bin/env python3
"""Verify all v1_35 manifest-listed files except intentionally updated README are byte-identical."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parent
P=json.loads((R/'data/v136_parent_manifest_snapshot.json').read_text())
assert P['version']=='v1_35' and len(P['files'])==330
n=0
for rec in P['files']:
 if rec['path']=='README.md':continue
 f=R/rec['path']
 assert f.is_file(),rec['path']
 assert f.stat().st_size==rec['bytes'],rec['path']
 assert hashlib.sha256(f.read_bytes()).hexdigest()==rec['sha256'],rec['path']
 n+=1
assert n==329
print('PASS parent integrity: all',n,'inherited non-README manifest files byte-identical to v1_35; no historical graph overwritten')
