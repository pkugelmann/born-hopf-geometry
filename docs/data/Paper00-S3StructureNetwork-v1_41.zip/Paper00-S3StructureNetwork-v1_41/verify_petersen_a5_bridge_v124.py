#!/usr/bin/env python3
"""Rebuild the complete exact Petersen/Hodge/A5/600/E8 bridge certificate."""
import pathlib,json,hashlib
from scripts.petersen_a5_bridge_v124 import build
R=pathlib.Path(__file__).resolve().parent
saved=json.loads((R/'data/petersen_a5_bridge_v124_instance.json').read_text())
rebuilt=build()
assert rebuilt==saved, 'the exact coordinate data were not regenerated faithfully'
assert saved['five_core_relabelling_to_axis_blocks']==[0,2,3,4,1]
assert saved['permutation_group_checks']['distinct_A5_elements']==60
print('PASS: regenerated signed Petersen 10+15, unique A5 core alignment, 15-axis and 120-vertex rank-four intertwiners')
