#!/usr/bin/env python3
"""Independently regenerate exact Hurwitz 24-cell cellular and quotient data."""
from pathlib import Path
import json,sys,numpy as np
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts.hurwitz_cellular_v129 import build
saved=json.loads((ROOT/'data/hurwitz_cellular_v129_instance.json').read_text())
now=build()
assert saved==now
assert saved['counts']=={'vertices':24,'edges':96,'oriented_triangles':96,'oriented_octahedral_cells':24,
                          'incidence_ranks':[23,73,23],'H_1':0,'H_2':0,'coexact_face_rank':73,
                          'exact_face_rank':23,'adjacency_degree':8,'q8_cosets':3}
q=saved['hurwitz_group']; assert q['q8_quotient_adjacency']==[[0,4,4],[4,0,4],[4,4,0]]
assert saved['unit_weight_2_hodge']['kernel_dim']==0
assert saved['unit_weight_2_hodge']['exact_trace_moments_k1to4']==[480,3168,24672,212640]
print('PASS Batch18: exact 2T/Cayley group action, Q8/C3 quotient, rank2 -4 projector, 8-direction cube moments, cellular ranks/cohomology, 96-face Hodge spectra and dual 24cell.')
