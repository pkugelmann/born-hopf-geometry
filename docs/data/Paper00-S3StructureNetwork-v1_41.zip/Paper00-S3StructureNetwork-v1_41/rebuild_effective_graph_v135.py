#!/usr/bin/env python3
"""Source-preserving v135 graph overlay: conditional mathematics and physical-owner status separate."""
from pathlib import Path
import json,argparse,xml.etree.ElementTree as ET
R=Path(__file__).resolve().parent
read=lambda n:json.loads((R/n).read_text())
O=read('data/objects.json');E=read('data/mathematical_relations.json');F=read('data/v135_verified_frontier_status.json');C=read('data/v135_scoped_math_replays.json')
node={o['id']:o for o in O};byid={e['id']:e for e in E}
NS='http://graphml.graphdrawing.org/xmlns';ET.register_namespace('',NS);tag=lambda s:'{'+NS+'}'+s
keys=[('n0','node','name'),('n1','node','object_type'),('n2','node','batch'),('e0','edge','relation'),('e1','edge','link_type'),('e2','edge','conditional_math_status'),('e3','edge','guard_ids'),('e4','edge','source_label'),('e5','edge','proof_certificate'),('e6','edge','source_verification_v132'),('e7','edge','physical_owner_status'),('e8','edge','targeted_frontier'),('e9','edge','extra_replay_hypotheses')]
def gml(nodeids,edges):
    root=ET.Element(tag('graphml'))
    for key,kind,label in keys:ET.SubElement(root,tag('key'),{'id':key,'for':kind,'attr.name':label,'attr.type':'string'})
    graph=ET.SubElement(root,tag('graph'),{'id':'BornHopfS3EffectiveMathV135','edgedefault':'directed'})
    for id in nodeids:
        x=node[id];n=ET.SubElement(graph,tag('node'),{'id':id})
        for k,v in [('n0',x['name']),('n1',x['object_type']),('n2',x.get('batch',''))]:ET.SubElement(n,tag('data'),{'key':k}).text=str(v)
    for edge in edges:
        n=ET.SubElement(graph,tag('edge'),{'id':edge['id'],'source':edge['from'],'target':edge['to']})
        status=F['relations'].get(edge['id'],{})
        owner='SOURCE_OR_PHYSICAL_OWNER_NOT_INDEPENDENTLY_DISCHARGED' if status else 'NOT_EVALUATED_BY_PROOF_OVERLAY'
        target='TARGETED_SOURCE_SELECTION_OPEN' if edge['id'] in F['source_boundary_pending_ids'] else ''
        source=edge.get('current_source_anchor') or edge.get('witness') or {}
        attrs=[('e0',edge['relation']),('e1',edge['link_type']),('e2',status.get('effective_mathematical_map_status',edge.get('verification',''))),
               ('e3',','.join(edge.get('requires_joint_inputs',[]))),('e4',source.get('label',source.get('claim_id',''))),('e5',status.get('certificate_ref','')),
               ('e6',edge.get('verification','')),('e7',owner),('e8',target),
               ('e9','; '.join(status.get('mathematical_replay_required_hypotheses',[])))]
        for k,v in attrs:ET.SubElement(n,tag('data'),{'key':k}).text='' if v is None else str(v)
    import io
    buf=io.BytesIO();ET.ElementTree(root).write(buf,encoding='utf-8',xml_declaration=True);return buf.getvalue()

def dot(nodeids,edges):
    lines=['digraph BornHopfS3MathV135 {',' graph [rankdir=LR];',' node [shape=box];']
    for id in nodeids:lines.append(' '+json.dumps(id)+' [label='+json.dumps(node[id]['name'])+'];')
    for e in edges:
        s=F['relations'].get(e['id'],{})
        if e['id'] in F['source_boundary_pending_ids']:state='MATH VERIFIED / OWNER OPEN'
        elif s:state='MATH VERIFIED / SOURCE GUARDS'
        else:state=e['relation']
        lines.append(' '+json.dumps(e['from'])+' -> '+json.dumps(e['to'])+' [label='+json.dumps(e['id']+': '+state)+'];')
    return ('\n'.join(lines)+'\n}\n').encode()
verified=[byid[i] for i in F['newly_verified_ids']]
vnodes=sorted({n for e in verified for n in (e['from'],e['to'])})
RECORDS={
 'graph/mathematical_structure_network_effective_v135.graphml':gml([x['id'] for x in O],E),
 'graph/mathematical_structure_network_effective_v135.dot':dot([x['id'] for x in O],E),
 'graph/batch24_scoped_math_and_owner_frontier.graphml':gml(vnodes,verified),
 'graph/batch24_scoped_math_and_owner_frontier.dot':dot(vnodes,verified)}
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--write',action='store_true');a.add_argument('--check',action='store_true');opts=a.parse_args()
    assert F['replay_count']==24 and set(F['newly_verified_ids'])==set(C['new_conditional_replayed_ids'])
    for name,data in RECORDS.items():
        p=R/name
        if opts.write:p.write_bytes(data)
        if opts.check:assert p.read_bytes()==data,name
        print(('WRITE' if opts.write else 'CHECK'),name,len(data))
    print('PASS graph 862 objects, 1392 same edges; 24 guarded replays, three source selections still open')
