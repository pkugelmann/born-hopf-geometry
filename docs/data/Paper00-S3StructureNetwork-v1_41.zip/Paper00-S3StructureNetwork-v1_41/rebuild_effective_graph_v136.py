#!/usr/bin/env python3
"""GraphML + DOT extension of v135 dual-axis network by exact harmonic/GP3 mathematics.
Preserves historical v132/v135 exports bytewise; imports only math objects and maps.
"""
from pathlib import Path
import json,copy,argparse,xml.etree.ElementTree as ET
R=Path(__file__).resolve().parent
read=lambda p:json.loads((R/p).read_text())
X=read('data/v136_math_extension.json');F=read('data/v136_frontier_resolution.json')
baseO=read('data/objects.json');baseE=read('data/mathematical_relations.json')
O=baseO+X['objects'];E=baseE+X['relations'];omap={a['id']:a for a in O}
NS='http://graphml.graphdrawing.org/xmlns';ET.register_namespace('',NS)
tag=lambda a:'{'+NS+'}'+a
old=ET.parse(R/'graph/mathematical_structure_network_effective_v135.graphml').getroot()

# Re-use the dual-axis v135 graph as an exact parent; append current-v136 scope tags without rewriting historical files.
def gml(focused=False):
 if not focused:
  root=copy.deepcopy(old); graph=root.find('g:graph',{'g':NS});graph.set('id','BornHopfS3EffectiveMathV136')
 else:
  root=ET.Element(tag('graphml'))
  for k in old.findall('g:key',{'g':NS}):root.append(copy.deepcopy(k))
  graph=ET.SubElement(root,tag('graph'),{'id':'BornHopfS3Batch25CurrentHarmonic','edgedefault':'directed'})
 for i,t,name in [('n9','node','current_branch_scope_v136'),('e10','edge','guard_id_v136'),('e11','edge','physical_owner_scope_v136')]:
  ET.SubElement(root,tag('key'),{'id':i,'for':t,'attr.name':name,'attr.type':'string'})
 ids=set()
 if focused:
  ids=set(a for e in X['relations'] for a in (e['from'],e['to']))
  for a in O:
   if a['id'] not in ids:continue
   n=ET.SubElement(graph,tag('node'),{'id':a['id']})
   for k,v in [('n0',a['name']),('n1',a['object_type']),('n2',a.get('batch',''))]:ET.SubElement(n,tag('data'),{'key':k}).text=v
   ET.SubElement(n,tag('data'),{'key':'n9'}).text='MATH_ONLY' if a['id'].startswith('geo:g36:') else 'INHERITED_GEO_CONTEXT'
 else:
  for a in X['objects']:
   n=ET.SubElement(graph,tag('node'),{'id':a['id']})
   for k,v in [('n0',a['name']),('n1',a['object_type']),('n2',a.get('batch',''))]:ET.SubElement(n,tag('data'),{'key':k}).text=v
   ET.SubElement(n,tag('data'),{'key':'n9'}).text='CONDITIONAL_PHYSICAL_OWNER' if a['conditional'] else 'INDEPENDENT_EXACT_FINITE_MATH'
 # Explicitly flag historical D4 edge in current graph (NOT a false graph-to-physics transition).
 if not focused:
  for ed in graph.findall('g:edge',{'g':NS}):
   if ed.get('id')=='G32-056':
    ET.SubElement(ed,tag('data'),{'key':'e11'}).text='HISTORICAL_D4_ONLY_ON_NEW_HARMONIC_BRANCH; GENERAL_E56_ROW_SCALE_STILL_VALID'
   elif ed.get('id') in ('G32-052','G32-072'):
    ET.SubElement(ed,tag('data'),{'key':'e11'}).text='PHYSICAL_SOURCE_SELECTION_STILL_OPEN'
 for e in X['relations']:
  ed=ET.SubElement(graph,tag('edge'),{'id':e['id'],'source':e['from'],'target':e['to']})
  for k,v in [('e0',e['relation']),('e1',e['link_type']),('e2',e['verification']),('e3',','.join(e.get('requires_joint_inputs',[]))),
              ('e4',e.get('source_label','')),('e5','data/v136_exact_harmonic_gp3_certificate.json'),('e6','NEW_V136_EXACT_REPLAY'),
              ('e7',e['physical_owner_status']),('e8','CURRENT_HARMONIC_PROPOSAL' if e['guard_id']=='HYP-G36-06' else ''),('e9',''),
              ('e10',e['guard_id']),('e11',e['physical_owner_status'])]:
   ET.SubElement(ed,tag('data'),{'key':k}).text=v
 import io
 buf=io.BytesIO();ET.ElementTree(root).write(buf,encoding='utf-8',xml_declaration=True)
 return buf.getvalue()

def dot(focused=False):
 eds=X['relations'] if focused else E
 nodes=sorted(set(i for e in eds for i in (e['from'],e['to']))) if focused else [o['id'] for o in O]
 lines=['digraph BornHopfS3MathV136 {','  graph [rankdir=LR];','  node [shape=box];']
 for ident in nodes:lines.append('  '+json.dumps(ident)+' [label='+json.dumps(omap[ident]['name'])+'];')
 for e in eds:lines.append('  '+json.dumps(e['from'])+' -> '+json.dumps(e['to'])+' [label='+json.dumps(e['id']+': '+e['relation'])+'];')
 return ('\n'.join(lines)+'\n}\n').encode()

assets={
 'graph/mathematical_structure_network_effective_v136.graphml':gml(),
 'graph/mathematical_structure_network_effective_v136.dot':dot(),
 'graph/batch25_current_neutral_harmonic_GP3.graphml':gml(True),
 'graph/batch25_current_neutral_harmonic_GP3.dot':dot(True)}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--write',action='store_true');p.add_argument('--check',action='store_true');args=p.parse_args()
 for nm,dat in assets.items():
  out=R/nm
  if args.write:out.write_bytes(dat)
  if args.check:assert out.read_bytes()==dat,nm
  print('CHECK' if args.check else 'WRITE',nm,len(dat))
 print('PASS effective mathematical extension',len(O),'nodes',len(E),'edges; inherited graph assets unchanged')
