#!/usr/bin/env python3
"""Re-run exact Clifford, Petersen, product-Hodge and finite-operator checks."""
import json,pathlib
from scripts.geometry_bridges_v127 import build
R=pathlib.Path(__file__).resolve().parent
saved=json.loads((R/'data/geometry_bridges_v127_instance.json').read_text())
assert build()==saved,'new exact instance fails mathematical regeneration'
o=json.loads((R/'data/objects.json').read_text());e=json.loads((R/'data/mathematical_relations.json').read_text());h=json.loads((R/'data/joint_input_relations.json').read_text())
newnodes={x['id'] for x in o if x.get('batch')=='v1_27'}
newedges=[x for x in e if x.get('batch')=='v1_27'];allnodes={x['id'] for x in o}
assert all(x['from'] in allnodes and x['to'] in allnodes for x in newedges)
assert all(x.get('source_relation')=='MATHEMATICAL_CONSTRUCTION_NOT_PROOF_EDGE' for x in newedges)
assert all(x.get('conditions_preserved') is True for x in newedges)
assert all(x.get('verification') for x in newedges)
assert not any('PHYSICAL' in x['relation'].upper() or 'DECAY_WIDTH' in x['relation'].upper() for x in newedges)
assert len(newnodes)==13
print('PASS batch16: quaternionic Clifford tangent, E36 sandwich, K K*=5I, M8 heat/swap, Hermite finite cutoff, two-mode CAR, scalar lattice, signed Petersen projectors, CP1 Hopf map')
