#!/usr/bin/env python3
"""Scoped new proof-graph overlay; no canonical DAG or physical result promotion."""
import json
from pathlib import Path
import networkx as nx
root=Path(__file__).resolve().parents[1]
cert=json.loads((root/'data/Paper00-SecondJetGaussIsospin-v1_1.json').read_text())
G=nx.DiGraph(name='20-pair second action jet and Gauss-safe 56 reference source')
nodes={
 'dodeca20':('20 directed 2T core pairs, 30-edge dodecahedron','INHERITED_CERTIFIED_GEOMETRY'),
 'spinlink':('Positive spin-link graph action on C2 x C20','INHERITED_COMPARISON_ACTION'),
 'V3':('Selected A5 actual 3 flavor triplet','INHERITED_CERTIFIED_GEOMETRY'),
 'jet1':('9 primitive spin-vector/triplet derivatives','EXACT_NEW'),
 'jet2':('Scalar + five flavor quadrupole contacts','EXACT_NEW'),
 'allorder15':('All-order 15-dimensional direct-action parity span','EXACT_NEW'),
 'lie35':('35-dimensional su6 commutator algebra','INHERITED_EXTENDED'),
 'schur4':('Rank-one source first nonzero Schur return order four','EXACT_NEW'),
 'B56':('Sym3(C2 spin x C3 flavor) source, rank 56','INHERITED_REPRESENTATION'),
 'N9':('Meson nonet 1+3+5','INHERITED_REPRESENTATION'),
 'nativeCAR':('Three-site rooted epsilon Wilson/CAR reference isometry','SOURCE_CERTIFIED_REFERENCE'),
 'haargauge':('Link-function Haar parent, link-dependent 56 source','EXACT_CONDITIONAL_CARRIER'),
 'gauss':('Local vertex SU3 Haar Gauss projector','INHERITED_SOURCE_CONDITIONAL'),
 'ward':('Onsite color-singlet vector flavor Ward charge','EXACT_SOURCE_CHART_COMPRESSION'),
 'axialrest':('Rest-upper Dirac spatial axial source equals 2 G','EXACT_REST_CHART_ONLY'),
 'mass':('Inherited running physical flavor mass M_f','PHYSICAL_CONDITION_NOT_EXECUTED'),
 'isospin':('Arbitrary complex light two-plane','EXACT_GEOMETRIC_IF_MASS_SELECTED'),
 'kappa':('kappa = tr(P_h P_h^T), one-scalar source orientation','EXACT_FUNCTIONAL_OF_SELECTED_PLANE'),
 'isostrength':('Six irrep-averaged isospin strengths and total 15','EXACT_CONDITIONAL_CHANNEL_GRAM'),
 'qcdaction':('Actual Gauss-reduced finite QCD action and source derivative','ACTUAL_ACTION_NOT_MATCHED'),
 'poles':('Actual hadron poles, chiral source residues, decay rates','OPEN_PHYSICAL_READOUT')}
for id,(lbl,status) in nodes.items():G.add_node(id,label=lbl,status=status,physical_pole=(id=='poles'))
edges=[
 ('dodeca20','spinlink','geometric_input','EXACT'),('dodeca20','V3','exact_projector','INHERITED_EXACT'),
 ('spinlink','jet1','first_derivative','EXACT'),('spinlink','jet2','second_derivative','EXACT'),
 ('V3','jet1','compression','EXACT'),('V3','jet2','compression','EXACT'),
 ('spinlink','allorder15','all_orders_parity','EXACT'),('jet1','lie35','Lie_commutators','EXACT'),
 ('jet2','N9','completes_geometric_5','EXACT_GEOMETRIC'),('jet2','schur4','second_order_leakage','EXACT'),
 ('jet1','schur4','zero_first_order_leakage','EXACT'),('V3','B56','primitive_three_particle_source','INHERITED_EXACT'),
 ('lie35','B56','faithful_primitive_three_particle_rep','EXACT_REPRESENTATION'),
 ('nativeCAR','haargauge','make_link_dependent','EXACT_ON_HAAR_PARENT'),('haargauge','gauss','Gauss_invariance','EXACT_ON_DECLARED_CARRIER'),
 ('B56','haargauge','domain','EXACT_ON_DECLARED_CARRIER'),('haargauge','ward','CAR_current_compression','EXACT_ON_DECLARED_CARRIER'),
 ('haargauge','axialrest','rest_gamma_projection','EXACT_REST_CHART'),('jet1','axialrest','matrix_identification','REST_CHART_ONLY'),
 ('mass','isospin','heavy_spectral_projector','CONDITIONAL_PHYSICAL_MASS'),('isospin','kappa','invariant_trace','EXACT'),
 ('kappa','isostrength','one_parameter_invariant','EXACT'),('B56','isostrength','primitive_transition_Gram','EXACT_REPRESENTATION'),
 ('qcdaction','poles','physical_spectral_output','OPEN'),('ward','qcdaction','bare_source_reference_test_only','DOES_NOT_ESTABLISH_ACTION'),
 ('axialrest','qcdaction','rest_chart_reference_test_only','DOES_NOT_ESTABLISH_ACTION'),
 ('schur4','poles','finite_nonabsorptive_not_width','DOES_NOT_ESTABLISH_PHYSICAL_POLE')]
for a,b,k,s in edges:G.add_edge(a,b,kind=k,status=s,physical_decay=False)
out=root/'graph/Paper00-SecondJetGaussIsospin-v1_1.graphml'
nx.write_graphml(G,out)
print('WROTE typed graph',G.number_of_nodes(),'nodes',G.number_of_edges(),'edges')
