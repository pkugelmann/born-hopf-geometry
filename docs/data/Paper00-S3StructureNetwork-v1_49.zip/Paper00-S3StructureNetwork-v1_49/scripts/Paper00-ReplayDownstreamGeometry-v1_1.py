#!/usr/bin/env python3
"""Replays the current finite math certificates, tests deterministic bytes.
This is an exact-instance computation, not a global E3/E4 source audit.
"""
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
NAMES=[
 ('CoreMembershipCompiler','CoreMembershipQuotient'),
 ('FiveCoreOrbitalCompiler','FiveCoreOrbitalAlgebra'),
 ('TripletCurrentCompiler','TripletCurrentSpace'),
 ('DodecahedralHodgeCurrentCompiler','DodecahedralHodgeCurrent'),
 ('CanonicalCliffordCompiler','CanonicalClifford'),
]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    for script,data in NAMES:
        code=ROOT/'scripts'/f'Paper00-{script}-v1_1.py'
        target=ROOT/'data'/f'Paper00-{data}-v1_1.json'
        assert target.is_file() and code.is_file()
        prior=sha(target)
        p=subprocess.run([sys.executable,str(code)],cwd=ROOT,capture_output=True,text=True,timeout=180)
        print(p.stdout.strip())
        if p.returncode:
            print(p.stderr)
            raise RuntimeError(f'{script} returned {p.returncode}')
        assert sha(target)==prior, f'data certificate is not deterministic: {data}'
        print('BYTE REPLAY PASS', data,prior)
    graph=ROOT/'scripts'/'Paper00-DownstreamGeometryGraphs-v1_1.py'
    targets=[ROOT/'graph'/f'Paper00-{n}-v1_1.graphml' for n in
             ('CoreMembershipTransport','DirectedPairOrbitalAlgebra','DodecahedralCellComplex','CanonicalCliffordTransitions')]
    before={str(p):sha(p) for p in targets}
    p=subprocess.run([sys.executable,str(graph)],cwd=ROOT,capture_output=True,text=True,timeout=90)
    if p.returncode:
        print(p.stderr)
        raise RuntimeError('GraphML replay failed')
    print(p.stdout.strip())
    assert all(sha(p)==before[str(p)] for p in targets)
    checks={
      'exact_600cell_groups_120_2I_5_2T_reconstructed':True,
      '20_pair_A5_commutant_orbital_count':8,
      '20_pair_triplet_current_basis_size':20,
      'two_generator_clifford_commutant_dimension':8,
      '20_pair_spherical_dodecahedron_Euler':2,
      'Hodge_first_betti':0,
      'nearest_edge_triplet_curl_direct_five_to_six_zero':True,
      'transition_block_hermitian_current_rank':4,
      'physical_decay_selection_or_rate_derived':False,
      'source_mapped_global_E3_E4_audit_performed':False,
    }
    result={'status':'PASS','scope':'FINITE EXACT INSTANCE; NO GLOBAL PROOF STATUS PROMOTION',
            'Python':sys.version.split()[0], 'checks':checks,
            'certificate_sha256':{n:sha(ROOT/'data'/f'Paper00-{n}-v1_1.json') for _,n in NAMES},
            'graph_sha256':{p.name:sha(p) for p in targets}}
    outfile=ROOT/'data'/'Paper00-DownstreamGeometryReplay-v1_1.json'
    outfile.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print('PASS exact finite 2I/A5/dodecahedron replay; ALL data & GraphML outputs deterministic')

if __name__=='__main__':main()
