#!/usr/bin/env python3
"""Exact 20-pair dodecahedral second source jet, first Schur return,
complex-isospin plane and Gauss/CAR source comparison certificate.

Arithmetic in Z[sqrt(5)] for all graph tensor/sector statements;
source gauge/CAR identity is algebraic and documented separately.
This is a geometric comparison, not a physical action occurrence proof.
"""
from pathlib import Path
from fractions import Fraction
import itertools, json
import numpy as np
import sympy as sp

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data'
OUT=DATA/'Paper00-SecondJetGaussIsospin-v1_1.json'
S=sp.sqrt(5)

def integer_pair(s):
    v=sp.expand(4*sp.sympify(s))
    a,b=int(v.coeff(S,0)),int(v.coeff(S,1))
    assert sp.simplify(v-a-b*S)==0
    return (a,b)
def p_add(x,y):return (x[0]+y[0],x[1]+y[1])
def p_sub(x,y):return (x[0]-y[0],x[1]-y[1])
def p_mul(x,y):return (x[0]*y[0]+5*x[1]*y[1],x[0]*y[1]+x[1]*y[0])
def p_cross(x,y):
    return [p_sub(p_mul(x[(i+1)%3],y[(i+2)%3]),p_mul(x[(i+2)%3],y[(i+1)%3])) for i in range(3)]
def pm(A,B):
    return np.stack((A[:,:,0]@B[:,:,0]+5*(A[:,:,1]@B[:,:,1]),
                     A[:,:,0]@B[:,:,1]+A[:,:,1]@B[:,:,0]),axis=-1)
def zexpr(pair,den):
    return sp.simplify((sp.Integer(pair[0])+sp.Integer(pair[1])*S)/den)
def coeffstr(v):return str(sp.simplify(v))

def main():
    tr=json.loads((DATA/'Paper00-TripletCurrentSpace-v1_1.json').read_text())
    orb=json.loads((DATA/'Paper00-FiveCoreOrbitalAlgebra-v1_1.json').read_text())
    raw=next(x for x in tr['basis_tensors'] if x['orbital_index']==0)
    U=np.array([[integer_pair(x) for x in row[2:]] for row in raw['components']],dtype=np.int64)
    assert U.shape==(20,3,2)
    edges=sorted({tuple(sorted(e)) for e in orb['basis_sparse_pairs'][7]})
    assert len(edges)==30
    A=np.zeros((20,20),dtype=np.int64)
    for i,j in edges:A[i,j]=A[j,i]=1
    assert np.all(A.sum(axis=0)==3)
    # 4*u_i=U_i; 16*(u_i cross u_j) = K_ij.
    k={(i,j):p_cross(U[i],U[j]) for i,j in edges}
    # 5*16*256=20480 is the denominator of Q^T(A k_a k_b)Q.
    # Isotropic exact rank-four tensor with only 2 independent invariants.
    tensor_checks=0
    for a,b,c,d in itertools.product(range(3),repeat=4):
        val=(0,0)
        for (i,j),v in k.items():
            v1=p_add(p_mul(U[i,c],U[j,d]),p_mul(U[j,c],U[i,d]))
            val=p_add(val,p_mul(v1,p_mul(v[a],v[b])))
        predicted=(0,512*(4*(a==b)*(c==d)-(a==c)*(b==d)-(a==d)*(b==c)))
        assert val==predicted,(a,b,c,d,val,predicted)
        tensor_checks+=1
    # Projectors via exact Lagrange polynomials p_r(A), all numerator/120.
    # Eigenvalues 3, sqrt5,-sqrt5,-2,0,1 for 1,3,3',4e,4o,5.
    poly={
      '1':[(0,0),(10,0),(-5,0),(-7,0),(1,0),(1,0)],
      '3':[(0,0),(0,-18),(-18,15),(15,6),(6,-3),(-3,0)],
      '3prime':[(0,0),(0,18),(-18,-15),(15,-6),(6,3),(-3,0)],
      '4_even':[(0,0),(-60,0),(80,0),(-8,0),(-16,0),(4,0)],
      '4_odd':[(120,0),(-100,0),(-64,0),(40,0),(8,0),(-4,0)],
      '5':[(0,0),(150,0),(25,0),(-55,0),(-5,0),(5,0)]}
    apows=[np.eye(20,dtype=np.int64)]
    for d in range(5):apows.append(apows[-1]@A)
    projectors={name:np.stack((sum(apows[d]*v[0] for d,v in enumerate(terms)),
                               sum(apows[d]*v[1] for d,v in enumerate(terms))),axis=-1)
                for name,terms in poly.items()}
    tot=sum(projectors.values())
    assert np.array_equal(tot[:,:,0],120*np.eye(20,dtype=np.int64)) and not np.any(tot[:,:,1])
    p3=np.stack((U[:,:,0]@U[:,:,0].T+5*(U[:,:,1]@U[:,:,1].T),
                 U[:,:,0]@U[:,:,1].T+U[:,:,1]@U[:,:,0].T),axis=-1)
    # p3/80 = projector_3/120
    assert np.array_equal(120*p3,80*projectors['3'])
    leakage={}
    for a in range(3):
        F=np.zeros((20,20,2),dtype=np.int64)
        for (i,j),v in k.items():
            w=p_mul(v[a],v[a]);F[i,j,:]=F[j,i,:]=w
        for name,Pr in projectors.items():
            num=pm(pm(pm(p3,F),Pr),F)
            numerator=(int(np.trace(num[:,:,0])),int(np.trace(num[:,:,1])))
            strength=zexpr(numerator,80*120*256**2)
            leakage.setdefault(name,[]).append(strength)
    for name,v in leakage.items():
        assert all(q==v[0] for q in v),(name,v)
    expect={'1':sp.S.Zero,'3':sp.Rational(9,80),'3prime':sp.Rational(1,80),
            '4_even':sp.S.Zero,'4_odd':sp.Rational(1,40),'5':sp.S.Zero}
    for key,e in expect.items():assert leakage[key][0]==e,(key,leakage[key][0],e)
    # Full-Hilbert sector sum check: 3/20, vs 9/80 + 1/80 + 1/40.
    assert sum((leakage[k][0] for k in poly),sp.S.Zero)==sp.Rational(3,20)
    # Isospin weights for arbitrary complex two-plane, formal n^T n invariant.
    kap=sp.Symbol('kappa',real=True)
    w3=(5-kap)/4;w5=(7+kap)/4
    channel3={'3->3':5,'3->3prime':0,'3->4':0,'5->3':3,'5->3prime':3,'5->4':4}
    channel5={'3->3':3,'3->3prime':3,'3->4':4,'5->3':1,'5->3prime':6,'5->4':8}
    channel_iso={key:sp.factor(w3*channel3[key]/3+w5*channel5[key]/5) for key in channel3}
    iso_expected={'3->3':(47-4*kap)/15,'3->3prime':3*(7+kap)/20,
                  '3->4':(7+kap)/5,'5->3':(8-kap)/5,
                  '5->3prime':(67+kap)/20,'5->4':(67+kap)/15}
    for key in channel3:assert sp.simplify(channel_iso[key]-iso_expected[key])==0
    assert sp.simplify(sum(channel_iso.values())-15)==0
    assert sp.simplify(w3+w5-3)==0
    # Test the complex-plane projector formula, including an isotropic line.
    eps=np.eye(3,dtype=np.complex128)
    las=[]
    for a in range(3):
        lam=np.zeros((3,3),dtype=complex)
        for b in range(3):
            for c in range(3):lam[b,c]=-1j*int(round(np.linalg.det(eps[[a,b,c]].real)))
        las.append(lam/np.sqrt(2))
    complex_cases=[np.array([1,0,0],dtype=complex),
                   np.array([1,1j,0],dtype=complex)/np.sqrt(2),
                   np.array([1,2+3j,-2j],dtype=complex)/np.linalg.norm([1,2+3j,-2j])]
    checks=[]
    for n in complex_cases:
        Ph=np.outer(n,n.conj());P=np.eye(3)-Ph
        p_iso=lambda X:P@X@P-.5*np.trace(P@X)*P
        direct=sum(np.trace(X@p_iso(X)).real for X in las)
        kappa=abs(n.T@n)**2
        assert abs(kappa-np.trace(Ph@Ph.T).real)<1.e-13
        assert abs(direct-(5-kappa)/4)<1.e-13
        checks.append({'kappa':round(float(kappa),12),'w3':round(float(direct),12)})
    # Additional SU3 color source control: 3 independently transported
    # legs remain normalized and gauge covariant (analytic proof is det=1).
    rng=np.random.default_rng(20261120)
    def su3():
        x=rng.standard_normal((3,3))+1j*rng.standard_normal((3,3))
        q,r=np.linalg.qr(x);q=q@np.diag(np.conj(np.diag(r))/np.abs(np.diag(r)))
        return q/np.linalg.det(q)**(1/3)
    def color_state(qs):
        e=np.zeros((3,3,3),dtype=complex)
        for idx in itertools.permutations(range(3)):
            sign=(-1)**sum(idx[a]>idx[b] for a in range(3) for b in range(a+1,3))
            e[idx]=sign/np.sqrt(6)
        return np.einsum('ia,jb,kc,abc->ijk',qs[0],qs[1],qs[2],e)
    site_links=[su3() for _ in range(3)]
    site_g=[su3() for _ in range(3)];root_g=su3()
    color=color_state(site_links)
    transformed=color_state([site_g[i]@site_links[i]@root_g.conj().T for i in range(3)])
    predicted=np.einsum('ia,jb,kc,abc->ijk',site_g[0],site_g[1],site_g[2],color)
    assert abs(np.vdot(color,color).real-1)<1e-12
    assert np.max(abs(transformed-predicted))<1e-12
    # Exact spin Dirac rest restriction (gamma^0 gamma^i gamma^5 = diag(sigma_i,sigma_i)).
    sx=np.array([[0,1],[1,0]],dtype=complex)
    sy=np.array([[0,-1j],[1j,0]],dtype=complex)
    sz=np.diag([1,-1]);sigmas=[sx,sy,sz]
    gamma0=np.block([[np.eye(2),np.zeros((2,2))],[np.zeros((2,2)),-np.eye(2)]])
    gamma5=np.block([[np.zeros((2,2)),np.eye(2)],[np.eye(2),np.zeros((2,2))]])
    R=np.vstack((np.eye(2),np.zeros((2,2))))
    for sigma in sigmas:
        gamk=np.block([[np.zeros((2,2)),sigma],[-sigma,np.zeros((2,2))]])
        assert np.max(abs(R.conj().T@gamma0@gamk@gamma5@R-sigma))<1e-14
    cert={
     'name':'Paper00-SecondJetGaussIsospin-v1_1',
     'scope':'Exact geometric 20-pair Dirichlet 2-jet and reference gauge/CAR source; not actual QCD action identification',
     'source_parent':'Paper00-S3StructureNetwork-v1_44',
     'math_field':'Z[sqrt(5)] exact integers after clearing 4^6 and 120 denominators',
     'exact_second_jet_tensor_checks':tensor_checks,
     'tensor_formula':'Q^T[A_(jk)*(u_j cross u_k)_a*(u_j cross u_k)_b]Q = sqrt(5)/40 * [4 delta_ab I_3-(E_ab+E_ba)]',
     'second_jet_hessian':'d^2 h / dB_ia dB_jb = delta_ij sqrt(5)/160 [4 delta_ab I-(E_ab+E_ba)]',
     'second_jet_expansion':'h(B)=(3-sqrt(5))I6+sum_ia B_ia S_i tensor lambda_a/2 +sqrt(5)/160 I2 tensor [2||B||_F^2 I3-B^T B]+O(B^3)',
     'second_jet_quintet_span':5,
     'first_order_P3_leakage':0,
     'exact_Faa_irrep_projected_strengths':{key:coeffstr(leakage[key][0]) for key in poly},
     'first_schur_order_in_b':4,
     'rank_one_source':'B_ia=b delta_i3 delta_a3, spin eigenvalues +/-1/2',
     'first_schur_mean_formula':'b^4/15360*[1/(z-3-sqrt(5))+2/(z-3)]+O(b^6)',
     'first_schur_mean_at_E0':'-sqrt(5)*b^4/30720+O(b^6), E0=3-sqrt(5)',
     'isospin_complex_plane_scalar':'kappa=|n^T n|^2=tr(P_h P_h^T), 0<=kappa<=1',
     'isospin_projected_weights':{'3':'(5-kappa)/4','5':'(7+kappa)/4'},
     'isospin_six_channels':{key:coeffstr(channel_iso[key]) for key in channel_iso},
     'isospin_total':'15 for every complex rank-two light-flavor plane',
     'isospin_plane_numerical_controls':checks,
     'gauss_reference_statement':'Haar-link wavefunction Psi_chi(U)=I^B(U)chi has local Gauss invariance and isometry; pointwise rooted CAR compression of on-site flavor bilinear equals dGamma3(F) independently of U',
     'gauss_color_reference_numerical_control':'independent site SU(3) and root SU(3) transformations, norm and tensor covariance pass (analytic proof by determinant and CAR)',
     'dirac_rest_spin_source_factor':'Rest upper Dirac P+ (gamma0 gammai gamma5) P+=sigma_i=2 S_i; conventional local spatial axial current compresses to 2 G_iA in this rest chart, not G_iA',
     'source_labels':['p10:prop:v3023-marked-baryon-source-overlap','p10:thm:v350-local-gauss-projector','p10:eq:minimal-source-operator-dictionary','p10:eq:native-source-operator-derivative','p11:cor:v369-axial-transition-benchmark'],
     'not_claimed':['actual microscopic physical QCD action selects dodecahedral spin links','Haar-link trial sector is invariant under physical Hamiltonian','rest Pauli current equals full relativistic axial correlator','meson Hessian contact is a first-order decay vertex','physical pole residues or decay widths','complete global geometric E3/E4 closure']
    }
    OUT.write_text(json.dumps(cert,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
    print('EXACT SECOND JET',tensor_checks,'tensor equalities; all 18 sector returns')
    print('Irrep strengths:',cert['exact_Faa_irrep_projected_strengths'])
    print('ISOSPIN',cert['isospin_six_channels'],'sum=15')
    print('GAUSS/CAR numerical controls and gamma normalization passed; written',OUT)

if __name__=='__main__':main()
