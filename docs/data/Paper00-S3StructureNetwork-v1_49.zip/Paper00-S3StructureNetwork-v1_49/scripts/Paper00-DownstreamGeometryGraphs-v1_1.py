#!/usr/bin/env python3
"""Separate visualization-only GraphML overlays for the v1_42 exact geometry.

Does not mutate canonical theorem-DAG nodes, edges, owners or statuses.
"""
import json
from pathlib import Path
import networkx as nx
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data';DEST=ROOT/'graph';DEST.mkdir(exist_ok=True)

def load(name):return json.loads((DATA/name).read_text())

def make():
    quo=load('Paper00-CoreMembershipQuotient-v1_1.json')['membership_quotient']
    B=quo['adjacency_B'];n=quo['class_sizes'];names=quo['class_names']
    G=nx.DiGraph(name='exact 600-cell five-class membership equitable quotient')
    for i,(name,ni) in enumerate(zip(names,n)):
        G.add_node(f'C{i}',node_type='equitable_class',label=name,cardinality=ni,physical_selection='none')
    for i in range(5):
        for j in range(5):
            if B[i][j]:
                G.add_edge(f'C{i}',f'C{j}',per_vertex_neighbors=B[i][j],ordered_edge_count=n[i]*B[i][j],type='exact_Cayley_adjacency')
    path=DEST/'Paper00-CoreMembershipTransport-v1_1.graphml';nx.write_graphml(G,path)
    assert len(G)==5 and nx.is_strongly_connected(G)
    orb=load('Paper00-FiveCoreOrbitalAlgebra-v1_1.json')
    H=nx.MultiDiGraph(name='complete A5-directed-pair orbital matrices')
    E=[(a,b) for a in range(5) for b in range(5) if a!=b]
    for i,(a,b) in enumerate(E):H.add_node(f'p{i}',node_type='ordered_core_pair',first_core=a,second_core=b,label=f'{a}->{b}')
    for k,O in enumerate(orb['basis_sparse_pairs']):
        for i,j in O:H.add_edge(f'p{i}',f'p{j}',key=f'M{k}',orbital_id=k,relationship='A5_orbital_entry')
    assert len(H)==20 and len(H.edges())==400
    path2=DEST/'Paper00-DirectedPairOrbitalAlgebra-v1_1.graphml';nx.write_graphml(H,path2)
    d=load('Paper00-DodecahedralHodgeCurrent-v1_1.json')['dodecahedron']
    S=nx.Graph(name='dodecahedron cell-incidence plus dual faces; not a physical decay graph')
    for i,v in enumerate(d['vertex_coordinates']):
        S.add_node(f'v{i}',node_type='dodecahedron_vertex',label=str(tuple(v['ordered_pair'])),x=v['u'][0],y=v['u'][1],z=v['u'][2],physical_selection='none')
    for k,(i,j) in enumerate(d['edges']):
        S.add_node(f'e{k}',node_type='dodecahedron_edge',label=f'{i}-{j}')
        S.add_edge(f'e{k}',f'v{i}',relationship='edge_tail_incidence')
        S.add_edge(f'e{k}',f'v{j}',relationship='edge_head_incidence')
    edge_id={tuple(sorted(e)):i for i,e in enumerate(d['edges'])}
    for k,face in enumerate(d['faces_oriented']):
        S.add_node(f'f{k}',node_type='pentagonal_face',label=f'face_{k}')
        for j in range(5):
            a,b=face[j],face[(j+1)%5]
            S.add_edge(f'f{k}',f'e{edge_id[tuple(sorted((a,b)))]}',relationship='face_boundary_incidence')
    assert len(S)==62 and len(S.edges())==120
    path3=DEST/'Paper00-DodecahedralCellComplex-v1_1.graphml';nx.write_graphml(S,path3)
    for graph,path in ((G,DEST/'Paper00-CoreMembershipTransport-v1_1.graphml'),(H,path2),(S,path3)):
        G2=nx.read_graphml(path,force_multigraph=graph.is_multigraph())
        assert len(G2.nodes())==len(graph.nodes()) and len(G2.edges())==len(graph.edges())
    # Representation-typing graph for canonical two-generator Clifford; these
    # are *operator* intertwiners, never decay probabilities or time arrows.
    C=nx.DiGraph(name='complete A5 spectral type and internal multiplicity Clifford')
    sp_labels=load('Paper00-DodecahedralHodgeCurrent-v1_1.json')['dodecahedron']['complete_irrep_spectral_resolution']
    for name,info in sp_labels.items():
        C.add_node(name,node_type='A5_irreducible_sector',dimension=info['dimension'],
                   dodecahedron_adjacency_eigenvalue=info['adjacency_eigenvalue'],
                   physical_decay_selection='OPEN')
    C.add_edge('4_even','4_odd',relationship='K_orientation_offdiagonal',physical_decay=False)
    C.add_edge('4_odd','4_even',relationship='K_orientation_offdiagonal',physical_decay=False)
    path4=DEST/'Paper00-CanonicalCliffordTransitions-v1_1.graphml'
    nx.write_graphml(C,path4)
    C2=nx.read_graphml(path4)
    assert len(C2)==6 and len(C2.edges())==2
    print('PASS 5-class transport graph, 8-orbital 20-state graph 62-cell Hodge-incidence graph and Clifford-sector graph; roundtrip GraphML')

if __name__=='__main__':make()
