#!/usr/bin/env python3
"""All 20 real A5-triplet covariant operator triples on directed core pairs.

The quaternion conjugation 2I -> SO(3) is constructed from the existing
exact Q(sqrt(5)) 600-cell coordinates. Its sign-insensitivity is verified.
For every orbital in E x E, the invariant vectors of its pair stabilizer
are transported to a full equivariant tensor. This is an exhaustive
representation-space construction, NOT an action-selected pion current.
"""
import collections
import itertools
import json
from fractions import Fraction as F
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'data'/'exceptional_600cell_instance.json'
ORB=ROOT/'data'/'Paper00-FiveCoreOrbitalAlgebra-v1_1.json'
OUT=ROOT/'data'/'Paper00-TripletCurrentSpace-v1_1.json'
Z=(F(0),F(0));ONE=(F(1),F(0))

def f(x):return (F(x),F(0))
def plus(x,y):return (x[0]+y[0],x[1]+y[1])
def neg(x):return (-x[0],-x[1])
def minus(x,y):return plus(x,neg(y))
def mul(x,y):return (x[0]*y[0]+5*x[1]*y[1],x[0]*y[1]+x[1]*y[0])
def scale(x,n):return(x[0]*n,x[1]*n)
def fdiv(x,y):
    denom=y[0]*y[0]-5*y[1]*y[1];assert denom!=0
    t=mul(x,(y[0],-y[1]));return (t[0]/denom,t[1]/denom)
def vsum(u,v):return tuple(plus(x,y) for x,y in zip(u,v))
def dot(u,v):
    r=Z
    for x,y in zip(u,v):r=plus(r,mul(x,y))
    return r

def qmul(q,p):
    a=plus(plus(mul(q[0],p[0]),neg(mul(q[1],p[1]))),plus(neg(mul(q[2],p[2])),neg(mul(q[3],p[3]))))
    b=plus(plus(mul(q[0],p[1]),mul(q[1],p[0])),plus(mul(q[2],p[3]),neg(mul(q[3],p[2]))))
    c=plus(plus(mul(q[0],p[2]),mul(q[2],p[0])),plus(mul(q[3],p[1]),neg(mul(q[1],p[3]))))
    d=plus(plus(mul(q[0],p[3]),mul(q[3],p[0])),plus(mul(q[1],p[2]),neg(mul(q[2],p[1]))))
    return (a,b,c,d)

def qinv(q):return(q[0],neg(q[1]),neg(q[2]),neg(q[3]))

def rotation(q):
    # R(q) = (w^2-|v|^2)I + 2vv^T + 2w[v]_cross,
    # representing q*(0,v)*conj(q) in the three imaginary slots.
    w=q[0];v=q[1:]
    beta=minus(mul(w,w),dot(v,v))
    cross=((Z,neg(v[2]),v[1]),(v[2],Z,neg(v[0])),(neg(v[1]),v[0],Z))
    return tuple(tuple(plus(plus(beta if a==b else Z,scale(mul(v[a],v[b]),2)),
                            scale(mul(w,cross[a][b]),2)) for b in range(3)) for a in range(3))

def mv(R,v):return tuple(dot(row,v) for row in R)

def matmul(A,B):return tuple(tuple(dot(A[i],tuple(B[k][j] for k in range(3))) for j in range(3)) for i in range(3))

def s(x):
    if x[1]==0:return str(x[0])
    return str(x[0])+('+' if x[1]>0 else '')+str(x[1])+'*sqrt(5)'


def main():
    data=json.loads(SOURCE.read_text());orb=json.loads(ORB.read_text())
    raw=[tuple(tuple(F(c,4) for c in component) for component in vert['qcoords']) for vert in data['vertices']]
    idx={q:i for i,q in enumerate(raw)};assert len(idx)==120
    mult=[[idx[qmul(raw[i],raw[j])] for j in range(120)] for i in range(120)]
    inverse=[idx[qinv(q)] for q in raw]
    H=[set(h) for h in data['conjugate_core_groups']]
    hs={frozenset(h):i for i,h in enumerate(H)}
    groupperm={}
    for g in range(120):
        p=[]
        for h in H:
            conj=frozenset(mult[mult[g][x]][inverse[g]] for x in h)
            p.append(hs[conj])
        perm=tuple(p)
        groupperm.setdefault(perm,[]).append(g)
    assert len(groupperm)==60 and all(len(v)==2 for v in groupperm.values())
    # The A5 triplet is the actual quaternionic adjoint, not an arbitrarily
    # chosen isomorphic representation.
    choice={p:min(ids) for p,ids in groupperm.items()}
    reps={p:rotation(raw[g]) for p,g in choice.items()}
    assert all(rotation(raw[ids[0]])==rotation(raw[ids[1]]) for ids in groupperm.values())
    I=tuple(tuple(ONE if i==j else Z for j in range(3)) for i in range(3))
    id_perm=tuple(range(5))
    assert reps[id_perm]==I
    for p,Rp in reps.items():
        for q,Rq in reps.items():
            comp=tuple(p[q[i]] for i in range(5))
            assert matmul(Rp,Rq)==reps[comp]
    E=[(a,b) for a in range(5) for b in range(5) if a!=b]
    eind={p:i for i,p in enumerate(E)}
    actions={p:[eind[(p[a],p[b])] for a,b in E] for p in choice}
    orbitals=[[tuple(ij) for ij in o] for o in orb['basis_sparse_pairs']]
    assert len(orbitals)==8
    bases=[];base_counts=[]
    for t,O in enumerate(orbitals):
        a,b=tuple(orb['orbital_representatives'][t][0]),tuple(orb['orbital_representatives'][t][1])
        src=(eind[a],eind[b])
        stabilizer=[p for p,act in actions.items() if (act[src[0]],act[src[1]])==src]
        assert len(stabilizer) in (1,3)
        if len(stabilizer)==1:
            vectors=[(ONE,Z,Z),(Z,ONE,Z),(Z,Z,ONE)]
        else:
            p=next(p for p in stabilizer if p!=id_perm)
            vec=raw[choice[p]][1:]
            assert any(x!=Z for x in vec)
            assert all(mv(reps[h],vec)==vec for h in stabilizer)
            vectors=[vec]
        assert len(vectors)==(3 if len(stabilizer)==1 else 1)
        base_counts.append(len(vectors))
        for z,seed in enumerate(vectors):
            vals={}
            for p,act in actions.items():
                dst=(act[src[0]],act[src[1]])
                val=mv(reps[p],seed)
                if dst in vals:assert vals[dst]==val
                vals[dst]=val
            assert set(vals)==set(O)
            # Verify full A5 tensor covariance, not just basis dimension.
            for p,act in actions.items():
                for (i,j),vec in vals.items():
                    assert vals[(act[i],act[j])]==mv(reps[p],vec)
            bases.append({'index':len(bases),'orbital_index':t,'seed_index':z,
                          'seed_vector':[s(x) for x in seed],
                          'stabilizer_order':len(stabilizer),
                          'supported_entries':len(vals),
                          'components':[[i,j,*[s(x) for x in val]] for (i,j),val in sorted(vals.items())]})
    assert base_counts==[1,3,1,3,3,3,3,3],base_counts
    assert sum(base_counts)==20
    # Symmetric and antisymmetric Hermitian current multiplicities via
    # exact character identities for Sym2(E) and exterior2(E).
    classes=collections.Counter()
    for p in choice:
        # Count by element order in A5, enough for 3 char on 5A/5B.
        order=1;t=p
        while t!=id_perm:
            order+=1;t=tuple(p[t[i]] for i in range(5))
        classes[order]+=1
    assert dict(classes)=={1:1,2:15,3:20,5:24}
    chars20={1:20,2:0,3:2,5:0};chars3={1:3,2:-1,3:0,5:None}
    chi_gsq={1:20,2:20,3:2,5:0}
    sym=(classes[1]*chars3[1]*(chars20[1]**2+chi_gsq[1])+
         classes[2]*chars3[2]*(chars20[2]**2+chi_gsq[2])+
         classes[3]*chars3[3]*(chars20[3]**2+chi_gsq[3]))//(2*60)
    anti=(classes[1]*chars3[1]*(chars20[1]**2-chi_gsq[1])+
          classes[2]*chars3[2]*(chars20[2]**2-chi_gsq[2])+
          classes[3]*chars3[3]*(chars20[3]**2-chi_gsq[3]))//(2*60)
    assert sym==8 and anti==12
    output={
        'name':'Paper00-TripletCurrentSpace-v1_1',
        'scope':'ALL A5-triplet-covariant triples on 20 directed five-core pairs, before physical current selection',
        '2I_group_elements':120,'A5_quotient_permutations':60,
        'representation':'quaternion adjoint q v q^-1 on imaginary quaternions, exact Q(sqrt(5))',
        'carrier':'20 ordered pairs, under conjugation permutation of five 2T subgroups',
        'orbitals':8,
        'pair_stabilizer_orders':[60//len(O) for O in orbitals],
        'fixed_triplet_space_dimensions_per_orbit':base_counts,
        'exhaustive_independent_triplet_tensor_basis_size':len(bases),
        'hermitian_triplet_current_dimensions':{'real_symmetric':sym,'imaginary_antisymmetric':anti,'total_real':sym+anti},
        'basis_tensors':bases,
        'proof':'For each A5 orbital on E x E, equivariant vector fields correspond bijectively to the stabilizer-fixed subspace of the quaternionic triplet. The 8 stabilizer orders are 3 or 1; hence 2*1+6*3=20. Full 60-element covariance was checked at all 400 pair-of-pair positions. Sym/antisym dimensions follow exact symmetric/exterior-square character identities.',
        'not_claimed':['unique physical pion/isotriplet realization','field derivative of same Born/QCD action','spin-chirality or electroweak Ward completeness','on-shell physical decay widths','physical time arrow']}
    OUT.write_text(json.dumps(output,indent=2,sort_keys=True)+'\n')
    print('PASS exact 3D 2I adjoint / all 60 A5 actions / twenty tensor currents')
    print('stabilizer vector dimensions',base_counts,'Hermitian symmetric',sym,'antisymmetric',anti)
    print('output:',OUT)

if __name__=='__main__':
    main()
