#!/usr/bin/env python3
"""Typed geometry/source DAG overlay for the 20 -> 3 -> 56 protected lift.
This is not the canonical proof DAG and does not assert actual physical action.
"""
from pathlib import Path
import json
import networkx as nx
root=Path(__file__).resolve().parents[1]
cert=json.loads((root/'data/Paper00-ProtectedFlavorLift-v1_1.json').read_text())
assert cert['exact_intertwining_tests']==540
G=nx.DiGraph(name='Protected local flavor source; geometry proved, physical matching conditional')
nodes={
 'binary_icosahedral_five_cores':('EXACT_INHERITED','2I five conjugate 2T cores'),
 'dodecahedron20':('EXACT_INHERITED','20 directed core pairs, 30 edges'),
 'neighbor_tight_frame':('EXACT_NEW','vertex-local second moment identity'),
 'local_lift_K':('EXACT_NEW','nearest-neighbor *-preserving M3 lift'),
 'A5_covariance':('EXACT_NEW','60 even permutations'),
 'local_quintet_uniqueness':('EXACT_SCOPED','unique protected real-symmetric quintet in one-hop class'),
 'local_triplet_uniqueness':('EXACT_SCOPED','unique protected imaginary-skew triplet in one-hop class'),
 'flavor3':('EXACT_INHERITED','normalized selected 3-dimensional A5 carrier'),
 'flavor_1_3_5':('EXACT_NEW','protected full Hermitian3=1+3+5 algebra'),
 'mass_family':('CONDITIONAL_INPUT','actual Hermitian three-flavor mass member selected upstream'),
 'mass_spectral_projectors':('EXACT_FAMILY_MAP','polynomial mass spectral projectors on protected corner'),
 'isospin_kappa':('EXACT_DEPENDENT_READOUT','kappa=tr(P_h P_h^T)'),
 'axial_source24':('EXACT_CONSTRUCTED_ACTION','local source-linear 24-axis finite Hamiltonian'),
 'baryon56':('EXACT_REFERENCE','symmetric 3-slot source gives 2G for 24 currents'),
 'reference_hessians':('EXACT_ACTION_DEPENDENT','linear-vs-spinlink different 2-jets and 56 tracial Hessian'),
 'gauss_trial':('CONDITIONAL_REFERENCE','link-function Wilson/CAR trial Gauss isometry'),
 'native_qcd_action':('OPEN_PHYSICAL_OCCURRENCE','actual local-Gauss finite QCD action and source derivatives'),
 'physical_poles':('OPEN_PHYSICAL_READOUT','interacting eigenstates, residues and outgoing channels'),
 'decay_widths':('OPEN_PHYSICAL_READOUT','partial widths and lifetimes')
}
for n,(status,label) in nodes.items():G.add_node(n,status=status,label=label)
edges=[
 ('binary_icosahedral_five_cores','dodecahedron20','EXACT'),
 ('dodecahedron20','neighbor_tight_frame','EXACT'),
 ('neighbor_tight_frame','local_lift_K','EXACT'),
 ('dodecahedron20','A5_covariance','EXACT'),
 ('A5_covariance','local_quintet_uniqueness','EXACT_SCOPED'),
 ('A5_covariance','local_triplet_uniqueness','EXACT_SCOPED'),
 ('local_quintet_uniqueness','local_lift_K','EXACT_SCOPED'),
 ('local_triplet_uniqueness','local_lift_K','EXACT_SCOPED'),
 ('local_lift_K','flavor_1_3_5','EXACT'),
 ('flavor3','flavor_1_3_5','EXACT'),
 ('local_lift_K','mass_spectral_projectors','EXACT_WHOLE_FAMILY'),
 ('mass_family','mass_spectral_projectors','CONDITIONAL_MEMBER'),
 ('mass_spectral_projectors','isospin_kappa','EXACT_DEPENDENT'),
 ('local_lift_K','axial_source24','EXACT_FOR_DEFINED_ACTION'),
 ('axial_source24','baryon56','EXACT_REFERENCE_LIFT'),
 ('axial_source24','reference_hessians','EXACT_ACTION_DEPENDENT'),
 ('baryon56','gauss_trial','CONDITIONAL_REFERENCE'),
 ('gauss_trial','native_qcd_action','PHYSICAL_MATCHING_OPEN'),
 ('reference_hessians','native_qcd_action','SOURCE_CONTACT_SELECTION_OPEN'),
 ('native_qcd_action','physical_poles','DYNAMICAL_SPECTRAL_OPEN'),
 ('physical_poles','decay_widths','RETARDED_CHANNEL_OPEN'),
]
for u,v,kind in edges:G.add_edge(u,v,kind=kind,physical_decay=False)
assert G.number_of_nodes()==19 and G.number_of_edges()==21
path=root/'graph/Paper00-ProtectedFlavorLift-v1_1.graphml'
nx.write_graphml(G,path)
print('WROTE',path.name,'nodes',len(G.nodes),'edges',len(G.edges))
