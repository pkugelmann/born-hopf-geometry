#!/usr/bin/env python3
"""Exact Q(sqrt(5)) finite 600-cell -> spin-flavor 56 baryon benchmark.
No numerical fitting; calculations use integer-pair algebra a+b*sqrt(5).
Source: certified Paper00-TripletCurrentSpace and FiveCoreOrbitalAlgebra.
"""
import itertools, json, math, collections
from fractions import Fraction
from pathlib import Path
import numpy as np
import sympy as sp
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data'
TRI=DATA/'Paper00-TripletCurrentSpace-v1_1.json'
ORB=DATA/'Paper00-FiveCoreOrbitalAlgebra-v1_1.json'
OUT=DATA/'Paper00-CurvatureSpinFlavorBridge-v1_1.json'
s5=sp.sqrt(5)

def mplus(x,y):return (x[0]+y[0],x[1]+y[1])
def mmul(x,y):return (x[0]*y[0]+5*x[1]*y[1],x[0]*y[1]+x[1]*y[0])
def divpair(x,d):
 assert x[0]%d==0 and x[1]%d==0,(x,d)
 return (x[0]//d,x[1]//d)
def pairmat(A,B):
 return np.stack((A[:,:,0]@B[:,:,0]+5*(A[:,:,1]@B[:,:,1]),
                  A[:,:,0]@B[:,:,1]+A[:,:,1]@B[:,:,0]),axis=-1)
def zero_pair(n):return np.zeros((n,n,2),dtype=np.int64)
def pairtrace(A):return (int(np.trace(A[:,:,0])),int(np.trace(A[:,:,1])))
def dgamma(M,ocs,ind):
 n=len(ocs);X=np.zeros((n,n),dtype=np.int64)
 for k,state in enumerate(ocs):
  for i in range(6):
   for j in range(6):
    if state[j]==0 or M[i,j]==0:continue
    if i==j:X[k,k]+=M[i,j]*state[j]
    else:
     target=list(state);target[j]-=1;target[i]+=1
     X[ind[tuple(target)],k]+=M[i,j]*state[j]
 return X

def main():
 tr=json.loads(TRI.read_text());orb=json.loads(ORB.read_text())
 orig=next(x for x in tr['basis_tensors'] if x['orbital_index']==0)
 # 4*u_i^a is integer pair (a,b) for a+b sqrt(5).
 U=[]
 for row in orig['components']:
  coords=[]
  for val in row[2:]:
   x=sp.expand(4*sp.sympify(val))
   a=int(x.coeff(s5,0));b=int(x.coeff(s5,1));assert a+b*s5==x
   coords.append((a,b))
  U.append(coords)
 assert len(U)==20
 E=[(a,b) for a in range(5) for b in range(5) if a!=b]
 idx={e:k for k,e in enumerate(E)}
 perms=[p for p in itertools.permutations(range(5)) if sum(p[i]>p[j] for i in range(5) for j in range(i+1,5))%2==0]
 assert len(perms)==60
 edges=sorted({tuple(sorted(ij)) for ij in orb['basis_sparse_pairs'][7]})
 assert len(edges)==30
 # Exact spherical fourth moment: A5 has no nontrivial invariant harmonic
 # at degrees 1, 2 or 4.  This directly constructs the normalized
 # 1+3+5 meson port via c, u_i dot v, and u_i^T Q u_i.
 for a in range(3):
  assert tuple(sum(U[i][a][j] for i in range(20)) for j in range(2))==(0,0)
  for b in range(3):
   t=(0,0)
   for i in range(20):t=mplus(t,mmul(U[i][a],U[i][b]))
   assert t==((80,0) if a==b else (0,0)),('second',a,b,t)
   for c in range(3):
    for d in range(3):
     k=(0,0)
     for i in range(20):k=mplus(k,mmul(mmul(U[i][a],U[i][b]),mmul(U[i][c],U[i][d])))
     factor=(int(a==b)*int(c==d)+int(a==c)*int(b==d)+int(a==d)*int(b==c))
     assert k==(192*factor,0),('fourth',a,b,c,d,k)
 # Fock monomial basis has integer-action second quantization, unlike
 # normalized boson basis; all trace identities are similarity invariant.
 ocs=[n for n in itertools.product(range(4),repeat=6) if sum(n)==3]
 ix={o:k for k,o in enumerate(ocs)};n=56;assert len(ocs)==56
 I=np.eye(n,dtype=np.int64)
 Splus=np.zeros((6,6),dtype=np.int64);Sminus=np.zeros((6,6),dtype=np.int64)
 for a in range(3):Splus[a,a+3]=1;Sminus[a+3,a]=1
 Sp=dgamma(Splus,ocs,ix);Sm=dgamma(Sminus,ocs,ix)
 Sz2=np.diag([sum(v[:3])-sum(v[3:]) for v in ocs]).astype(np.int64) # 2 Sz
 S2x4=Sz2@Sz2+2*(Sp@Sm+Sm@Sp)
 P8n=15*I-S2x4;P10n=S2x4-3*I; spin_den=12
 assert np.array_equal(P8n@P8n,12*P8n)
 assert np.array_equal(P10n@P10n,12*P10n)
 assert np.array_equal(P8n@P10n,np.zeros((56,56),dtype=np.int64))
 assert np.trace(P8n)==12*16 and np.trace(P10n)==12*40
 # Exact character projectors on the 56-dimensional symmetric cube of
 # the selected quaternionic real icosahedral triplet, no W56 supplied.
 dims={'1':1,'3':3,'3prime':3,'4':4,'5':5};D=60*2*4**3 # 7680
 Pnum={key:zero_pair(n) for key in dims}
 P3_20n=zero_pair(20) # 3/120 sum_g (2*chi_3(g)) P_20(g)
 Rlist=[]
 for g in perms:
  act=[idx[(g[a],g[b])] for a,b in E]
  R=[[None]*3 for _ in range(3)]
  for a in range(3):
   for b in range(3):
    c=(0,0)
    for i in range(20):c=mplus(c,mmul(U[act[i]][a],U[i][b]))
    R[a][b]=divpair(c,20) # 4*R^a_b (since U_i=U_num_i/4)
  Rlist.append(R)
  # Test orthogonality R^T R =I using integer-pairs /4.
  for i in range(3):
   for j in range(3):
    dot=(0,0)
    for k in range(3):dot=mplus(dot,mmul(R[k][i],R[k][j]))
    assert dot==((16,0) if i==j else (0,0)),(g,i,j,dot)
  # Sym^3 group action, 6 one-particle spin-flavor states.
  matrix=zero_pair(n)
  for k,ns in enumerate(ocs):
   js=[j for j,count in enumerate(ns) for _ in range(count)]
   assert len(js)==3
   for ii in itertools.product(range(3),repeat=3):
    is_=[3*(j//3)+ii[r] for r,j in enumerate(js)]
    out=tuple(is_.count(h) for h in range(6))
    v=(1,0)
    for r in range(3):v=mmul(v,R[ii[r]][js[r]%3])
    matrix[ix[out],k,0]+=v[0];matrix[ix[out],k,1]+=v[1]
  order=1;t=g;identity=tuple(range(5))
  while t!=identity:
   t=tuple(t[g[i]] for i in range(5));order+=1
  assert order in [1,2,3,5]
  ch3=divpair(tuple(sum(R[i][i][j] for i in range(3)) for j in range(2)),2) # χ3_num/2
  if order==5:ch3p=(ch3[0],-ch3[1])
  else:ch3p=ch3
  for i,j in enumerate(act):
   P3_20n[j,i,0]+=3*ch3[0]
   P3_20n[j,i,1]+=3*ch3[1]
  chars={
     '1':(2,0), '3':ch3, '3prime':ch3p,
     '4':(2*(sum(g[i]==i for i in range(5))-1),0),
     '5':(2*{1:5,2:1,3:-1,5:0}[order],0)}
  assert ch3==({1:(6,0),2:(-2,0),3:(0,0)}.get(order,ch3))
  for key in dims:
   a,b=chars[key];M=matrix
   Pnum[key][:,:,0]+=dims[key]*(a*M[:,:,0]+5*b*M[:,:,1])
   Pnum[key][:,:,1]+=dims[key]*(a*M[:,:,1]+b*M[:,:,0])
 assert np.array_equal(sum((Pnum[x] for x in dims),zero_pair(n))[:,:,0],D*I)
 assert not np.any(sum((Pnum[x] for x in dims),zero_pair(n))[:,:,1])
 assert np.array_equal(pairmat(P3_20n,P3_20n),120*P3_20n)
 assert pairtrace(P3_20n)==(360,0)
 # The face-curl triplet preserves the selected actual P3 flavor carrier
 # at first order: C_a P3=P3 C_a (not merely a small leakage).
 for a in range(3):
  curl=zero_pair(20)
  for k,l in edges:
   q=(0,0)
   for b,c in itertools.permutations(range(3),2):
    t=(a,b,c)
    if len(set(t))<3:continue
    par=(-1)**sum(t[ii]>t[jj] for ii in range(3) for jj in range(ii+1,3))
    v=mmul(U[k][b],U[l][c]);q=mplus(q,(par*v[0],par*v[1]))
   curl[k,l,:]=q;curl[l,k,:]=(-q[0],-q[1])
  assert np.array_equal(pairmat(P3_20n,curl),pairmat(curl,P3_20n)),('P3 curl leakage',a)
 for key,M in Pnum.items():
  assert np.array_equal(pairmat(M,M),D*M),(key,'projector')
  assert np.array_equal(M[:,:,0]@P8n,P8n@M[:,:,0])
  assert np.array_equal(M[:,:,1]@P8n,P8n@M[:,:,1])
 # A5 source-sector projectors, unnormalized integer pair numerator / (12*7680).
 Ps={};Pt={}
 for key in dims:
  for dest,spinmat,flag in [(Ps,P8n,'8'),(Pt,P10n,'10')]:
   dest[key]=np.stack((spinmat@Pnum[key][:,:,0],spinmat@Pnum[key][:,:,1]),axis=-1)
 rank8={k:pairtrace(Ps[k])[0]//(D*12) for k in dims}
 rank10={k:pairtrace(Pt[k])[0]//(D*12) for k in dims}
 assert rank8=={'1':0,'3':6,'3prime':0,'4':0,'5':10},rank8
 assert rank10=={'1':0,'3':12,'3prime':12,'4':16,'5':0},rank10
 # Currents: canonical geometric SO(3) angular matrices lambda_a=-i eps_a,
 # remaining five are the traceless Hermitian quadrupole directions.
 eps=[]
 for a in range(3):
  Eps=np.zeros((3,3),dtype=np.int64)
  for b,c in itertools.permutations(range(3),2):
   q=(a,b,c)
   if len(set(q))==3:Eps[b,c]=(-1)**sum(q[i]>q[j] for i in range(3) for j in range(i+1,3))
  eps.append(Eps)
 ed=np.eye(3,dtype=np.int64)
 def Eab(a,b):return np.outer(ed[a],ed[b])
 Q=[Eab(0,1)+Eab(1,0), Eab(0,2)+Eab(2,0), Eab(1,2)+Eab(2,1),
    Eab(0,0)-Eab(1,1), Eab(0,0)+Eab(1,1)-2*Eab(2,2)]
 sigma=[np.array([[0,1],[1,0]],dtype=np.int64),
        np.array([[0,-1],[1,0]],dtype=np.int64),
        np.array([[1,0],[0,-1]],dtype=np.int64)]
 N=[]
 for i in range(3):
  row=[]
  for a in range(8):row.append(dgamma(np.kron(sigma[i],(eps+Q)[a]),ocs,ix))
  N.append(row)
 d2=(D*12)**2*16
 # ζ_i^2 sign relative to real matrix N, and last-quintet normalization 1/3.
 def sgn(i,a):return (-1 if i!=1 else 1) if a<3 else (1 if i!=1 else -1)
 def tracecur(r,s,a):
  total=(0,0)
  for i in range(3):
   # all four matrices over Z[sqrt5] with spin denominators already deferred
   X=pairmat(Pt[r],np.stack((N[i][a],np.zeros((n,n),dtype=np.int64)),axis=-1))
   Y=pairmat(Ps[s],np.stack((N[i][a],np.zeros((n,n),dtype=np.int64)),axis=-1))
   Z=pairtrace(pairmat(X,Y));sign=sgn(i,a)
   total=(total[0]+sign*Z[0],total[1]+sign*Z[1])
  return total
 channels={};full_triplet=0;full_quintet=0
 for flavour_kind,inds in [('triplet',range(3)),('quintet',range(3,8))]:
  for src in ['3','5']:
   for dst in ['3','3prime','4']:
    a=b=0
    for f in inds:
     u,v=tracecur(dst,src,f)
     multiplier=3 if f<7 else 1 # last q direction normalizer 1/3; common denom 3*d2
     a+=multiplier*u;b+=multiplier*v
    assert b==0,(flavour_kind,src,dst,'irrational',b)
    assert a%(3*d2)==0,(flavour_kind,src,dst,'noninteger',a,3*d2)
    result=a//(3*d2)
    channels[f'{flavour_kind}|{src}->{dst}']=int(result)
    print(f'{flavour_kind:8s}: {src:>2s} -> {dst:<6s}: {result}')
    if flavour_kind=='triplet':full_triplet+=result
    else:full_quintet+=result
 assert full_triplet==15 and full_quintet==25 and full_triplet+full_quintet==40
 # Exact independent whole-source Casimir and off-diagonal contraction.
 # G_iA = zeta_{iA} N_iA/4; zeta squared = +/-1, last quintet
 # direction carries one additional 1/sqrt(3).  Clear denominators:
 #   48 sum_{i,A} G_iA^2 = sum 3*sgn*N^2 (A<7) + sgn*N^2 (A=7).
 casimir=np.zeros((n,n),dtype=np.int64)
 outer=np.zeros((n,n),dtype=np.int64)
 for aa in range(8):
  for ii in range(3):
   wt=(3 if aa<7 else 1)*sgn(ii,aa)
   T=N[ii][aa]
   casimir+=wt*(T@T)
   outer+=wt*(P8n@T@P10n@T@P8n)
 assert np.array_equal(casimir,19*P8n+14*P10n),'native 19/4, 7/2 Casimir'
 assert np.array_equal(outer,17280*P8n),'native 5/2 octet return'
 # Real-aligned flavor SU(2) pion source: lambda_2 (triplet) and
 # lambda_1, lambda_3 (two quintet directions), not the whole A5 triplet.
 # These indices are a=2,3,6 in our exact eight-generator basis.
 pionchannels={}
 for src in ['3','5']:
  for dst in ['3','3prime','4']:
   vals=[tracecur(dst,src,aa) for aa in (2,3,6)]
   t0=sum(v[0] for v in vals);t5=sum(v[1] for v in vals)
   assert t5==0
   fv=Fraction(t0,d2)
   expected=Fraction(channels[f'triplet|{src}->{dst}'],3)+Fraction(2*channels[f'quintet|{src}->{dst}'],5)
   assert fv==expected,(src,dst,fv,expected)
   pionchannels[f'{src}->{dst}']=str(fv)
 assert sum((Fraction(v) for v in pionchannels.values()),Fraction(0))==15
 # Exact tight-frame identity: each of the 8 orthonormal N9-octet source
 # directions has total 56 baryon 8->10 transition norm squared 5.
 # This checks all 64 cross-terms without presuming SU3 isotropy.
 def imul(z,w):return (z[0]*w[0]-z[1]*w[1],z[0]*w[1]+z[1]*w[0])
 def ifac(i,a):
  if a<3:return (1,0) if i==1 else (0,-1)
  else:return (0,1) if i==1 else (1,0)
 for a in range(8):
  for b in range(8):
   re=im=0
   for i in range(3):
    val=int(np.trace(P10n@N[i][a]@P8n@N[i][b]))
    z=imul(ifac(i,a),ifac(i,b))
    re+=z[0]*val;im+=z[1]*val
   assert im==0,(a,b,im)
   normlast=3 if a==b==7 else 1
   expected=5*16*12**2*normlast if a==b else 0
   assert re==expected,(a,b,re,expected)
 # Fundamental geometric su(3) quadratic Casimir = 4/3 I_3:
 fundamental=-3*sum(E@E for E in eps)+3*sum(B@B for B in Q[:4])+Q[4]@Q[4]
 assert np.array_equal(fundamental,16*np.eye(3,dtype=np.int64))
 assert [channels[f'triplet|{s}->{t}'] for s,t in [('3','3'),('5','3'),('5','3prime'),('5','4'),('3','3prime'),('3','4')]]==[5,3,3,4,0,0]
 assert [channels[f'quintet|{s}->{t}'] for s,t in [('3','3'),('5','3'),('3','3prime'),('5','3prime'),('3','4'),('5','4')]]==[3,1,3,6,4,8]
 # Elementary exact curl compression from the native 30 edge graph:
 # Q_i^a=u_i^a/sqrt(5); C_a=i A_ij (u_i cross u_j)_a.
 # Q^dag C_a Q is compared to -lambda_a/2 by clearing the exact common
 # 4^4 denominator in the four u factors, and the Q normalization /5.
 for ax in range(3):
  for b in range(3):
   for c in range(3):
    summ=(0,0)
    for k,l in edges:
     # axial cross in original coordinates: (U_k x U_l)/16
     cross=(0,0)
     for p,q in itertools.permutations(range(3),2):
      parity=(-1)**sum((ax,p,q)[i]>(ax,p,q)[j] for i in range(3) for j in range(i+1,3)) if len({ax,p,q})==3 else 0
      if parity:cross=mplus(cross,tuple(parity*x for x in mmul(U[k][p],U[l][q])))
     # Q^T C Q =i/5*sum_edges cross*(u_k^b u_l^c-u_l^b u_k^c)
     term1=mmul(U[k][b],U[l][c]);term2=mmul(U[l][b],U[k][c])
     diff=(term1[0]-term2[0],term1[1]-term2[1])
     summ=mplus(summ,mmul(cross,diff))
    # denominator: cross /16, outer u u /16, /5 = 1/1280
    expected=(640*eps[ax][b,c],0) # i*(eps_abc/2) = -lambda/2 since lambda=-i eps
    assert summ==expected,(ax,b,c,summ,expected)
 out={
 'name':'Paper00-CurvatureSpinFlavorBridge-v1_1','classification':'Exact Q(sqrt(5)) geometric comparison, no physical current identification',
 'parent_certificates':[TRI.name,ORB.name],
 'full_sym3_dimension':56,'full_A5_irrep_multiplicities':{'3':6,'3prime':4,'4':4,'5':2},
 '56_spin_1over2_dimension':16,'56_spin_3over2_dimension':40,
 'octet_irrep_ranks':rank8,'decuplet_irrep_ranks':rank10,
 'exact_curl_compression':'Q^dagger C_a Q= -(1/2)lambda_a, lambda_a[b,c]=-i epsilon[a,b,c], Q=U/sqrt(5)',
 'spinful_edge_link':'U_ij(B)=exp(i sum_{ia} B_{ia}(sigma_i/2)*(u_i cross u_j)_a)',
 'source_derivative':'d/dB_ia ((I_2 tensor Q)^dag L(B)(I_2 tensor Q))|0=(sigma_i/2) tensor (lambda_a/2)',
 'primitive_three_quark_lift':'dGamma_3 of spinful source derivative on Sym^3(C^2 tensor C^3)',
 'independent_exact_triplet_quintet_axial_strengths':{'triplet':full_triplet,'quintet':full_quintet,'total':full_triplet+full_quintet},
 'exact_su3_fundamental_C2':'sum_A F_A^2=4/3 I_3',
 'exact_mesonic_fourth_moment':'sum_i u_i^a u_i^b u_i^c u_i^d=3/4(delta_ab delta_cd+delta_ac delta_bd+delta_ad delta_bc)',
 'exact_mesonic_real_isometry':'Y(c I+T(v)+Q)_i=sqrt(3/20)c+sqrt(2/5)*(u_i dot v)+sqrt(2/3)*(u_i^T Q u_i), T(v)_{bc}=-i eps_{abc} v_a, Q real traceless symmetric',
 'mesonic_source_carrier':'N9=1+3+5 subset R^20, octet N8=3+5',
 'meson_to_56_baryon_transition_frame':'For orthonormal xi_A=sqrt(2)Y(F_A), sum_i Tr[(P10 M_i(xi_A)P8)^dagger(P10 M_i(xi_B)P8)]=5 delta_AB',
 'real_aligned_physical_isospin_selection':'For real light two-plane span(e0,e1), pion generators F_pi=(F_quintet_xy,F_triplet_z,F_quintet_diag1), one triplet plus two quintet directions',
 'real_aligned_isotriplet_irrep_channel_strengths':pionchannels,
 'first_order_flavor_carrier_reducing':'[P3,C_a]=0 on all 20-pair matrices exactly',
 'exact_56_casimir':'sum_{i,A} G_iA^2=(19/4)*P8+(7/2)*P10',
 'exact_octet_return':'sum_{i,A}P8 G_iA P10 G_iA P8=(5/2)*P8',
 'exact_irrep_channel_strengths':channels,
 'integer_pair_field':'Z[sqrt(5)] after clearing denominators; no floating-point steps',
 'reproducible_int_56_by_56_projectors':'60 A5 character sums of symmetric-cube representation in unnormalized monomial basis',
 'not_claimed':['Actual physical QCD/Born action equality','physical pion or octet axial field selection','Gauss reduced baryon pole identification','mass thresholds or decay widths']
 }
 OUT.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
 print('PASS exact quaternionic curl compression and 60 group irrep projectors')
 print('PASS 56 projector ranks, 24 axial tensor channel strengths, total 40')
 print('OUTPUT',OUT)
if __name__=='__main__':main()
