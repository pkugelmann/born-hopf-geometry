#!/usr/bin/env python3
"""Exact dodecahedral embedding, cochain Hodge complex and current firewall.

Depends only on the supplied 2I-derived orbitals/triplet-current certificates.
All identities are finite exact Q(sqrt(5)) mathematics, no particle widths.
"""
import collections
import itertools
import json
from pathlib import Path

import sympy as sp

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'data'/'Paper00-DodecahedralHodgeCurrent-v1_1.json'
ORB=ROOT/'data'/'Paper00-FiveCoreOrbitalAlgebra-v1_1.json'
TRI=ROOT/'data'/'Paper00-TripletCurrentSpace-v1_1.json'


def cross(x,y):
    return sp.Matrix([x[1]*y[2]-x[2]*y[1],x[2]*y[0]-x[0]*y[2],x[0]*y[1]-x[1]*y[0]])


def simplify(x):return sp.simplify(x)


def compact(x):return str(simplify(x))


def main():
    orb=json.loads(ORB.read_text());tr=json.loads(TRI.read_text())
    E=[(a,b) for a in range(5) for b in range(5) if a!=b]
    idx={e:i for i,e in enumerate(E)}
    origin=next(t for t in tr['basis_tensors'] if t['orbital_index']==0)
    U={int(i):sp.Matrix([sp.sympify(x),sp.sympify(y),sp.sympify(z)])
       for i,j,x,y,z in origin['components']}
    assert len(U)==len(set(tuple(v) for v in U.values()))==20
    assert {simplify(v.dot(v)) for v in U.values()}=={sp.Rational(3,4)}
    assert all(U[idx[(b,a)]]==-U[idx[(a,b)]] for a,b in E)
    # The nearest 30 undirected edges are orbital 7 of the 8-orbital algebra.
    edges=sorted({tuple(sorted(t)) for t in orb['basis_sparse_pairs'][7]})
    assert len(edges)==30
    nbr=[set() for _ in range(20)]
    for i,j in edges:nbr[i].add(j);nbr[j].add(i)
    assert {len(t) for t in nbr}=={3}
    assert all(simplify((U[i]-U[j]).dot(U[i]-U[j]))==(3-sp.sqrt(5))/2 for i,j in edges)
    pair_distances=collections.Counter(compact((U[i]-U[j]).dot(U[i]-U[j]))
                                       for i in range(20) for j in range(i+1,20))
    assert sorted(pair_distances.values())==[10,30,30,60,60]
    # Enumerate all simple 5-cycles; precisely the 12 pentagonal faces.
    faces=set()
    def dfs(path):
        if len(path)==5:
            if path[0] in nbr[path[-1]]:
                seq=tuple(path);rev=tuple(reversed(seq))
                faces.add(min(tuple(row[k:]+row[:k]) for row in (seq,rev) for k in range(5)))
            return
        for nxt in nbr[path[-1]]:
            if nxt not in path:dfs(path+[nxt])
    for i in range(20):dfs([i])
    faces=sorted(faces)
    assert len(faces)==12
    edge_frequencies=collections.Counter(tuple(sorted((f[k],f[(k+1)%5])))
                                          for f in faces for k in range(5))
    assert set(edge_frequencies)==set(edges) and set(edge_frequencies.values())=={2}
    # Global face orientation from pairwise opposite shared-edge traversals.
    face_arcs=[{(f[k],f[(k+1)%5]) for k in range(5)} for f in faces]
    face_orient={0:1};queue=[0]
    while queue:
        i=queue.pop(0)
        for j in range(12):
            if i==j:continue
            overlap={tuple(sorted(t)) for t in face_arcs[i]} & {tuple(sorted(t)) for t in face_arcs[j]}
            if not overlap:continue
            assert len(overlap)==1
            a,b=next(iter(overlap))
            signi=1 if (a,b) in face_arcs[i] else -1
            signj=1 if (a,b) in face_arcs[j] else -1
            desired=-face_orient[i]*signi*signj
            if j in face_orient:assert face_orient[j]==desired
            else:face_orient[j]=desired;queue.append(j)
    assert len(face_orient)==12
    edge_idx={e:k for k,e in enumerate(edges)}
    boundary1=sp.zeros(20,30) # oriented 1-cell -> final - initial vertices
    boundary2=sp.zeros(30,12) # oriented pentagonal 2-cell -> edge boundary
    A=sp.zeros(20)
    for k,(i,j) in enumerate(edges):
        boundary1[i,k]=-1;boundary1[j,k]=1;A[i,j]=A[j,i]=1
    centroids=[];face_fluxes=[]
    for k,f in enumerate(faces):
        face_flux=sp.zeros(3,1)
        center=sp.zeros(3,1)
        for m in range(5):
            i,j=f[m],f[(m+1)%5];lo,hi=sorted((i,j))
            boundary2[edge_idx[(lo,hi)],k]=face_orient[k]*(1 if (i,j)==(lo,hi) else -1)
            center+=U[i]/5
            face_flux+=face_orient[k]*cross(U[i],U[j])
        centroids.append(center);face_fluxes.append(face_flux)
    assert boundary1*boundary2==sp.zeros(20,12)
    assert boundary1.rank()==19 and boundary2.rank()==11
    assert 20-30+12==2
    L0=boundary1*boundary1.T
    L2=boundary2.T*boundary2
    L1=boundary1.T*boundary1+boundary2*boundary2.T
    assert L0==3*sp.eye(20)-A
    assert L1.rank()==30
    assert all(simplify(t.dot(t))==sp.Rational(1,4)+sp.sqrt(5)/10 for t in centroids)
    flux_norm_sq=(25-5*sp.sqrt(5))/8
    assert all(simplify(t.dot(t))==flux_norm_sq for t in face_fluxes)
    face_adj=5*sp.eye(12)-L2
    assert all(face_adj[k,k]==0 for k in range(12))
    assert all(face_adj[k,j] in (0,1) for k in range(12) for j in range(12))
    assert all(sum(face_adj[k,j] for j in range(12))==5 for k in range(12))
    lam=sp.Symbol('lambda')
    dodec_poly=sp.factor(A.charpoly(lam).as_expr())
    ico_poly=sp.factor(face_adj.charpoly(lam).as_expr())
    assert dodec_poly==lam**4*(lam-3)*(lam-1)**5*(lam+2)**4*(lam**2-5)**3
    assert ico_poly==(lam-5)*(lam+1)**5*(lam**2-5)**3
    assert sp.factor(L2.charpoly(lam).as_expr())==lam*(lam-6)**5*(lam**2-10*lam+20)**3
    # Whole 60-element A5 action of directed pairs, dodecahedral edges and faces.
    perms=[p for p in itertools.permutations(range(5)) if
           sum(p[i]>p[j] for i in range(5) for j in range(i+1,5))%2==0]
    assert len(perms)==60
    perm_actions={p:[idx[(p[a],p[b])] for a,b in E] for p in perms}
    for p,act in perm_actions.items():
        assert {tuple(sorted((act[i],act[j]))) for i,j in edges}==set(edges)
        assert {frozenset(act[i] for i in face) for face in faces}=={frozenset(f) for f in faces}
    # Identify the specific quaternionic triplet via one 5-cycle, then
    # recover its A5 character on all 60 elements by conjugacy.
    seed=[0,1,2]
    Uframe=sp.Matrix.hstack(*(U[i] for i in seed))
    assert Uframe.det()!=0
    identity=tuple(range(5))
    def compose(p,q):return tuple(p[q[i]] for i in range(5))
    def inverse(p):return tuple(p.index(i) for i in range(5))
    order={}
    for p in perms:
        n=1;t=p
        while t!=identity:
            n+=1;t=compose(p,t)
        order[p]=n
    g5=min(p for p in perms if order[p]==5)
    class5a={compose(compose(h,g5),inverse(h)) for h in perms}
    assert len(class5a)==12
    Q5=sp.simplify(sp.Matrix.hstack(*(U[perm_actions[g5][i]] for i in seed))*Uframe.inv())
    phi=(1+sp.sqrt(5))/2;phibar=(1-sp.sqrt(5))/2
    assert sp.simplify(Q5.trace())==phi
    chi3={p:({1:sp.S(3),2:sp.S(-1),3:sp.S(0)}[order[p]] if order[p]!=5
             else phi if p in class5a else phibar) for p in perms}
    assert chi3[identity]==3
    # Irrep character projectors: 20=1+(3)+(3')+2(4)+(5).
    P5=sp.zeros(20);P4=sp.zeros(20);P3=sp.zeros(20)
    for p,act in perm_actions.items():
        X=sp.zeros(20)
        for i,j in enumerate(act):X[j,i]=1
        c5={1:5,2:1,3:-1,5:0}[order[p]]
        c4=sum(p[i]==i for i in range(5))-1
        P5+=sp.Rational(5,60)*c5*X
        P4+=sp.Rational(4,60)*c4*X
        P3+=sp.Rational(3,60)*chi3[p]*X
    P3=sp.simplify(P3)
    Reverse=sp.zeros(20)
    for i,(a,b) in enumerate(E):Reverse[i,idx[(b,a)]]=1
    Podd=(sp.eye(20)-Reverse)/2
    P3p=sp.simplify(Podd-P4*Podd-P3)
    assert all(sp.simplify(P*P-P)==sp.zeros(20) for P in (P5,P4,P3,P3p))
    assert [P.trace() for P in (P5,P3,P3p)]==[5,3,3]
    assert sp.simplify(P3*P3p)==sp.zeros(20)
    assert all(sp.simplify(X)==sp.zeros(20) for X in (P5*Reverse-P5,P3*Reverse+P3,P3p*Reverse+P3p))
    # Adjacency resolves every irrep, including the two isomorphic 4's.
    Peven=(sp.eye(20)+Reverse)/2
    P4even=sp.simplify(P4*Peven)
    P4odd=sp.simplify(P4*Podd)
    P1=sp.simplify(Peven-P4even-P5)
    spectral_irreps={
        '1':(P1,sp.S(3)),
        '3_actual_quaternionic':(P3,sp.sqrt(5)),
        '3prime':(P3p,-sp.sqrt(5)),
        '4_even':(P4even,sp.S(-2)),
        '4_odd':(P4odd,sp.S(0)),
        '5':(P5,sp.S(1)),
    }
    assert sum((P for P,e in spectral_irreps.values()),sp.zeros(20))==sp.eye(20)
    assert sorted([int(P.trace()) for P,e in spectral_irreps.values()])==[1,3,3,4,4,5]
    for name,(P,energy) in spectral_irreps.items():
        assert sp.simplify(A*P-energy*P)==sp.zeros(20)
        assert sp.simplify(P*P-P)==sp.zeros(20)
    assert len(set(energy for P,energy in spectral_irreps.values()))==6
    # Two A5-covariant Hermitian first-order Peierls edge currents.
    grad=[sp.zeros(20) for _ in range(3)]
    axial=[sp.zeros(20) for _ in range(3)]
    for i,j in edges:
        gd=(U[i]-U[j])/2
        ax=cross(U[i],U[j])
        for k in range(3):
            grad[k][i,j]=gd[k];grad[k][j,i]=-gd[k]
            axial[k][i,j]=ax[k];axial[k][j,i]=-ax[k]
    assert all(C.T==-C for C in grad+axial)
    for k in range(3):
        D=sp.diag(*(U[i][k] for i in range(20)))
        assert grad[k]==(D*A-A*D)/2 # exact gauge gradient
    # Full covariance of u was independently checked on all 60 elements by
    # Paper00-TripletCurrentCompiler-v1_1.py. SO(3) equivariance of
    # differences and cross products follows algebraically; check a generator.
    sample_g=next(p for p in perms if order[p]==5)
    action=perm_actions[sample_g]
    T=sp.simplify(sp.Matrix.hstack(*(U[action[i]] for i in seed))*Uframe.inv())
    for i,j in edges:
        for family in (axial,grad):
            lhs=sp.Matrix([family[k][action[i],action[j]] for k in range(3)])
            rhs=T*sp.Matrix([family[k][i,j] for k in range(3)])
            assert sp.simplify(lhs-rhs)==sp.zeros(3,1)
    strengths={}
    for name,cur in [('gradient',grad),('axial_face_curl',axial)]:
        a=[]
        for P in (P3,P3p):
            sq=0
            for k in range(3):
                mat=P5*cur[k]*P
                sq+=sum(t*t for t in mat)
            a.append(simplify(sq))
        strengths[name]=[compact(t) for t in a]
    assert strengths['gradient']==['9/4 - 3*sqrt(5)/4','sqrt(5)/8 + 3/8']
    assert strengths['axial_face_curl']==['0','0']
    # A5 edge stabilizer: on each undirected edge a size-2 group swaps
    # endpoints and acts by -1 on the two-dimensional span {u_i-u_j,u_i x u_j}.
    i,j=edges[0]
    stabs=[p for p,act in perm_actions.items() if {act[i],act[j]}=={i,j}]
    assert len(stabs)==2
    swap=next(p for p in stabs if (perm_actions[p][i],perm_actions[p][j])==(j,i))
    Q=sp.Matrix.hstack(*(U[perm_actions[swap][v]] for v in seed))*Uframe.inv()
    assert simplify(Q.trace())==-1 and Q**2==sp.eye(3)
    assert sp.simplify(Q*(U[i]-U[j])+(U[i]-U[j]))==sp.zeros(3,1)
    assert sp.simplify(Q*cross(U[i],U[j])+cross(U[i],U[j]))==sp.zeros(3,1)
    assert sp.simplify(Q*(U[i]+U[j])-(U[i]+U[j]))==sp.zeros(3,1)
    assert cross(U[i]-U[j],cross(U[i],U[j]))!=sp.zeros(3,1)
    # Complete rank of the Hermitian 20-current space on the 5 -> (3+3')
    # transition block: 2 independent real symmetric plus 2 imaginary
    # antisymmetric reduced amplitude directions; 16 remain block-dark.
    tensors=[]
    for item in tr['basis_tensors']:
        F=[sp.zeros(20) for _ in range(3)]
        for x,y,*components in item['components']:
            for k in range(3):F[k][x,y]=sp.sympify(components[k])
        tensors.append(F)
    assert len(tensors)==20
    reference={'real_symmetric':tensors[0],'imaginary_antisymmetric':tensors[4]}
    response={}
    for key,ref in reference.items():
        sign=1 if key=='real_symmetric' else -1
        rows=[]
        for P in (P3,P3p):
            V=[P5*F*P for F in ref]
            norm=simplify(sum(sum(t*t for t in Vk) for Vk in V))
            assert norm>0
            row=[]
            for Fs in tensors:
                z=sp.S(0)
                for k in range(3):
                    for a in range(20):
                        for b in range(20):
                            w=(Fs[k][a,b]+sign*Fs[k][b,a])/2
                            if w:z+=V[k][a,b]*w
                row.append(simplify(z/norm))
            rows.append(row)
        response[key]=sp.Matrix(rows)
        assert response[key].rank()==2
    # The odd irrep dimensions are single-copy, hence each projected
    # real-equivariant 5->3 or 5->3' block has exactly one reduced number.
    # Hermitian currents allow both real and imaginary parts: 2+2=4.
    assert tr['hermitian_triplet_current_dimensions']=={'real_symmetric':8,'imaginary_antisymmetric':12,'total_real':20}
    outfile={
        'name':'Paper00-DodecahedralHodgeCurrent-v1_1',
        'scope':'EXACT finite 2I/A5/dodecahedron representation and cochain geometry; physical interaction NOT selected',
        'dodecahedron':{'vertices':20,'edges':30,'pentagonal_faces':12,
           'embedding_norm_squared':'3/4','antipodal_pair_reverse':True,
           'edge_orbital_index_zero_based':7,
           'all_undirected_squared_distances':dict(pair_distances),
           'adjacency_characteristic_polynomial':str(dodec_poly),
           'complete_irrep_spectral_resolution':{key:{'dimension':int(P.trace()),'adjacency_eigenvalue':compact(ev)} for key,(P,ev) in spectral_irreps.items()},
           'spectral_projectors_are_Lagrange_polynomials_in_adjacency':True,
           'vertex_coordinates':[{'ordered_pair':list(E[i]),'u':[compact(z) for z in U[i]]} for i in range(20)],
           'edges':[[i,j] for i,j in edges],
           'faces_oriented':[[int(v) for v in (faces[k] if face_orient[k]==1 else tuple(reversed(faces[k])))] for k in range(12)]},
        'dual_icosahedron':{'vertices':12,'degree':5,
           'adjacency_characteristic_polynomial':str(ico_poly),
           'dual_face_centroid_squared_norm':'1/4 + sqrt(5)/10'},
        'hodge':{'C0_dimension':20,'C1_dimension':30,'C2_dimension':12,
           'boundary1_rank':19,'boundary2_rank':11,'boundary1_boundary2_zero':True,
           'Betti':{'b0':1,'b1':0,'b2':1},
           'L0_characteristic_polynomial':str(sp.factor(L0.charpoly(lam).as_expr())),
           'L2_characteristic_polynomial':str(sp.factor(L2.charpoly(lam).as_expr())),
           'L1_positive_rank':30,
           'outward_oriented_boundary1_matrix':[[int(boundary1[i,j]) for j in range(30)] for i in range(20)],
           'outward_oriented_boundary2_matrix':[[int(boundary2[i,j]) for j in range(12)] for i in range(30)]},
        'current_tests':{'A5_covariant_antisymmetric_nearest_edge_triplet_dimensions':2,
           'basis':['u_i-u_j: exact pure gradient','u_i cross u_j: non-exact face-curvature'],
           'cross_face_flux_squared_all_faces':compact(flux_norm_sq),
           'cross_curvature_nonzero':True,
           'pair5_to_odd3_odd3prime_summed_HS_squared':strengths,
           'nearest_edge_flux_couples_pair5_to_odd6':False,
           'Peierls_gauge_warning':'Pure-gradient coupling is unitary conjugation of M7 and causes no physical spectrum change on its own',
           'current_space_real_dimension':20,
           'Hermitian_sym_anti_dimensions':[8,12],
           'projection_amplitude_real_rank':{'real_symmetric':2,'imaginary_antisymmetric':2,'combined':4,'dark_kernel_dimension':16},
           'reference_basis_tensor_indices_zero_based':{'real_symmetric':0,'imaginary_antisymmetric':4},
           'response_coefficients_2_by_20':{key:[[compact(v) for v in M.row(i)] for i in range(2)] for key,M in response.items()}},
        'scope_gates':{'physical_action_current':'OPEN','same_action_field_derivative':'OPEN',
           'strong_weak_electromagnetic_identification':'OPEN','poles_masses_phase_space':'OPEN',
           'branching_ratios_lifetimes':'OPEN',
           'whole_framework_geometric_exhaustiveness':'NOT ESTABLISHED'}
    }
    OUT.write_text(json.dumps(outfile,sort_keys=True,indent=2)+'\n')
    print('PASS exact dodecahedron 20/30/12; icosahedron; Hodge betti 1/0/1; 2 edge-current directions')
    print('PASS all six dodecahedral adjacency eigenvalues label separate A5 summands, including 4_even/4_odd')
    print('PASS nonzero face curvature and exact zero physical-target sector projection for canonical cross current')
    print('PASS triplet-current block reduced-amplitude ranks 2 symmetric + 2 antisymmetric; 16 dark')
    print('output:',OUT)


if __name__=='__main__':main()
