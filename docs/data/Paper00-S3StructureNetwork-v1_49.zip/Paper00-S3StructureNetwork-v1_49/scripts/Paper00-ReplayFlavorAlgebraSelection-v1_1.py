#!/usr/bin/env python3
"""Deterministic replay of exact algebra-selection and 28-state representation certificate."""
import json, subprocess, sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
subprocess.run([sys.executable,str(root/'scripts/Paper00-FlavorAlgebraSelectionCompiler-v1_1.py')],cwd=root,check=True)
r=json.loads((root/'data/Paper00-FlavorAlgebraSelection-v1_1.json').read_text())
assert r['defect_hilbert_schmidt_norm_squared']==124
assert r['defect_rank_Qsqrt5_exact']==17
assert r['defect_leading_17x17_minor_mod11']==7
assert r['harmonic_evaluation_mod11_determinant']==8
assert r['minimal_su3_dilation_with_Q_as_invariant_fundamental3']==28
assert r['exact_rotation_current_HS_squared_on_20_graph']==5
assert r['minimal28_current_compression_lower_bound_HS_squared']=='15/2'
print('PASS: exact flavor-algebra selection, harmonic evaluation and minimal-28 current no-go')
