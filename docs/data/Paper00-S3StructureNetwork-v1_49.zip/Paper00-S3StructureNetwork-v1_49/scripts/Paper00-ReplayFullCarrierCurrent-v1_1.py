#!/usr/bin/env python3
"""Replay exact full-current theorem and compare deterministic certificate."""
import json,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
cert=root/'data/Paper00-FullCarrierCurrent-v1_1.json'
previous=json.loads(cert.read_text())
subprocess.run([sys.executable,str(root/'scripts/Paper00-FullCarrierCurrentCompiler-v1_1.py')],check=True)
assert json.loads(cert.read_text())==previous
assert previous['tensor_degree_sufficient']==24
assert previous['dilated_carrier_dimension']==99470
assert previous['minimal_28_total_quintet_leak_squared']=='3482/105'
print('FULL CARRIER DETERMINISTIC REPLAY PASS')
