#!/usr/bin/env python3
"""Exact modular and Q(sqrt5) certificate for Born--Hopf five-core algebra selection and harmonic completion."""
import json,itertools
from pathlib import Path
import sympy as s
S=s.sqrt(5)
root=Path(__file__).resolve().parents[1]
A5=json.loads((root/'data/Paper00-TripletCurrentSpace-v1_1.json').read_text())
orb=json.loads((root/'data/Paper00-FiveCoreOrbitalAlgebra-v1_1.json').read_text())
raw=next(x for x in A5['basis_tensors'] if x['orbital_index']==0)

def pair(z):
 e=s.expand(4*s.sympify(z));a=int(e.coeff(S,0));b=int(e.coeff(S,1));assert e==a+b*S;return a,b
U=[[pair(z) for z in row[2:]] for row in raw['components']]
assert len(U)==20
edge=set(tuple(sorted(v)) for v in orb['basis_sparse_pairs'][7]);assert len(edge)==30
Adj=[[int((min(j,k),max(j,k)) in edge) for k in range(20)] for j in range(20)]
add=lambda x,y:(x[0]+y[0],x[1]+y[1]); neg=lambda x:(-x[0],-x[1]);sub=lambda x,y:add(x,neg(y))
mul=lambda x,y:(x[0]*y[0]+5*x[1]*y[1],x[0]*y[1]+x[1]*y[0])
scale=lambda x,n:(x[0]*n,x[1]*n)
def sums(items):
 a,b=0,0
 for x,y in items:a+=x;b+=y
 return (a,b)
zero=(0,0)
def J(a,b):
 return [[sub(mul(U[j][a],U[k][b]) if Adj[j][k] else zero,mul(U[j][a],U[j][b]) if j==k else zero) for k in range(20)] for j in range(20)]
def matmul(X,Y):return [[sums(mul(X[j][k],Y[k][i]) for k in range(20)) for i in range(20)] for j in range(20)]
JJ={(a,b):J(a,b) for a in range(3) for b in range(3)}
def defect(a,b):
 X=matmul(JJ[(a,b)],JJ[(b,a)]);Y=matmul(JJ[(b,a)],JJ[(a,b)])
 return [[sub(sub(X[j][k],Y[j][k]),scale(sub(JJ[(a,a)][j][k],JJ[(b,b)][j][k]),8)) for k in range(20)] for j in range(20)]
D=defect(0,1) # physical defect = D/64
assert D==[[D[k][j] for k in range(20)] for j in range(20)]
assert all(sums(mul(D[j][k],U[k][a]) for k in range(20))==zero for j in range(20) for a in range(3))
norm=sums(mul(D[j][k],D[j][k]) for j in range(20) for k in range(20));assert norm==(507904,0)
assert norm[0]//4096==124 and norm[0]%4096==0
p=11;sqrt5mod=4
v=[[ (x+sqrt5mod*y)%p for x,y in row] for row in U]
def rank_mod(M):
 mat=[[a%p for a in row] for row in M];nr=len(mat);nc=len(mat[0]);rank=0;piv=[]
 for c in range(nc):
  r=next((i for i in range(rank,nr) if mat[i][c]),None)
  if r is None:continue
  mat[rank],mat[r]=mat[r],mat[rank]
  inv=pow(mat[rank][c],-1,p);mat[rank]=[x*inv%p for x in mat[rank]]
  for i in range(nr):
   if i!=rank and mat[i][c]:
    fac=mat[i][c];mat[i]=[(x-fac*y)%p for x,y in zip(mat[i],mat[rank])]
  piv.append(c);rank+=1
  if rank==nr:break
 return rank,piv

def det_mod(M):
 mat=[[a%p for a in row] for row in M];n=len(mat);d=1
 for c in range(n):
  i=next((r for r in range(c,n) if mat[r][c]),None)
  if i is None:return 0
  if i!=c:mat[i],mat[c]=mat[c],mat[i];d=-d
  pivot=mat[c][c];d=d*pivot%p;inv=pow(pivot,-1,p)
  for r in range(c+1,n):
   fac=mat[r][c]*inv%p
   for k in range(c,n):mat[r][k]=(mat[r][k]-fac*mat[c][k])%p
 return d%p

def reduce_pair_mod(M):return [[(x+sqrt5mod*y)%p for x,y in row] for row in M]
Dm=reduce_pair_mod(D)
assert rank_mod(Dm)[0]==17
lead_det=det_mod([row[:17] for row in Dm[:17]]);assert lead_det==7
for a,b in [(0,1),(0,2),(1,2)]:assert rank_mod(reduce_pair_mod(defect(a,b)))[0]==17

# First-order flavor-rotation current K(lambda_a/2)=-C_a has exact HS norm^2 5.
# u=U/4, so u_j cross u_k = (U_j cross U_k)/16.
def cross3(x,y):
 return [sub(mul(x[(a+1)%3],y[(a+2)%3]),mul(x[(a+2)%3],y[(a+1)%3])) for a in range(3)]
curl_hs_numer=[]
for a in range(3):
 q=sums(scale(mul(cross3(U[j],U[k])[a],cross3(U[j],U[k])[a]),2) for j,k in edge)
 assert q==(1280,0),q
 curl_hs_numer.append(q[0])
# A minimal 28=3 + 25 SU3 completion necessarily contains the SO3 H3 block.
# The standard normalized SO3 generator lambda_a/2 restricted to H_l has
# HS norm^2 = l(l+1)(2l+1)/12. Thus H3 contributes 7, Q=fundamental H1 adds 1/2.
min_h3_hs2=s.Rational(3*4*7,12)
fundamental_hs2=s.Rational(1*2*3,12)
assert min_h3_hs2==7 and fundamental_hs2==s.Rational(1,2)
assert min_h3_hs2+fundamental_hs2>s.Rational(curl_hs_numer[0],256)

# A5 action on ordered pairs; exact permutation character [20,0,2,0,0]
perms=[g for g in itertools.permutations(range(5)) if sum(g[i]>g[j] for i in range(5) for j in range(i+1,5))%2==0]
assert len(perms)==60
counts={}
for g in perms:
 fixed=sum(g[a]==a for a in range(5));ch=fixed*(fixed-1)
 counts[ch]=counts.get(ch,0)+1
assert counts=={20:1,0:39,2:20}
phi=(1+S)/2; phip=(1-S)/2
classes=[1,15,20,12,12]
chars={'1':[1,1,1,1,1],'3':[3,-1,0,phi,phip],"3p":[3,-1,0,phip,phi],'4':[4,0,1,-1,-1],'5':[5,1,-1,0,0]}

def decomp_from_class_chars(ch):
 vals={k:s.simplify(sum(classes[i]*ch[i]*character[i] for i in range(5))*s.Rational(1,60)) for k,character in chars.items()}
 assert all(x.is_Integer for x in vals.values()),vals
 return {key:int(x) for key,x in vals.items()}
perm_decomp=decomp_from_class_chars([20,0,2,0,0]);assert perm_decomp=={'1':1,'3':1,'3p':1,'4':2,'5':1}

def schur(p0,q0,chi):
 # complete symmetric polynomials in eigenvalues (1,z,z^-1)
 h=[s.Integer(1)];mx=p0+q0+1
 for i in range(1,mx+1):h.append(s.expand(chi*h[i-1]-(chi*h[i-2] if i>1 else 0)+(h[i-3] if i>2 else 0)))
 return s.simplify(h[p0+q0]*h[q0]-(h[p0+q0+1]*h[q0-1] if q0 else 0))

def su3_decomp(p0,q0):
 dim=(p0+1)*(q0+1)*(p0+q0+2)//2
 character=[schur(p0,q0,x) for x in (3,-1,0,phi,phip)]
 return dim,decomp_from_class_chars(character)
assert su3_decomp(1,0)==(3,{'1':0,'3':1,'3p':0,'4':0,'5':0})
assert su3_decomp(3,0)==(10,{'1':0,'3':1,'3p':1,'4':1,'5':0})
assert su3_decomp(4,0)==(15,{'1':1,'3':0,'3p':0,'4':1,'5':2})
assert su3_decomp(3,1)==(24,{'1':0,'3':1,'3p':1,'4':2,'5':2})
assert su3_decomp(2,2)==(27,{'1':1,'3':0,'3p':1,'4':2,'5':3})
# Dynamic-programming proof of minimal dimension needed to cover target A5 multiplicities.
keys=['1','3','3p','4','5'];
reps={}
for ap in range(9):
 for aq in range(9):
  dim=(ap+1)*(aq+1)*(ap+aq+2)//2
  if dim<=28:
   dd=su3_decomp(ap,aq)[1];signature=tuple(dd[k] for k in keys)
   reps[(dim,signature)]=(ap,aq)
print('SU3 distinct restrictions <=28:',len(reps))

def min_dim(target):
 target=tuple(target)
 state={tuple([0]*5):0}
 for depth in range(30):
  new=dict(state)
  for vec,val in state.items():
   for (dim,adds),irrep in reps.items():
    nxt=tuple(min(target[i],vec[i]+adds[i]) for i in range(5));nn=val+dim
    if nn<new.get(nxt,1000):new[nxt]=nn
  if new==state:break
  state=new
 return state[target]
target_all=tuple(perm_decomp[k] for k in keys)
target_comp=(1,0,1,2,1) # W20 minus its canonical fundamental 3
assert min_dim(target_all)==25
assert min_dim(target_comp)==25
# Sym3 + Sym4 realizes 25, plus an invariant fundamental 3 gives minimal total 28

# Rational harmonic polynomial bases: kernel of ordinary Laplacian on homogeneous polynomials

def monomials(d):return [(a,b,d-a-b) for a in range(d+1) for b in range(d+1-a)]
def harmonic_basis(deg):
 mons=monomials(deg)
 if deg<2:return [[int(i==j) for i in range(len(mons))] for j in range(len(mons))],mons
 tgt=monomials(deg-2);ids={e:i for i,e in enumerate(tgt)}
 Z=s.zeros(len(tgt),len(mons))
 for j,exp in enumerate(mons):
  for a in range(3):
   if exp[a]>=2:
    nu=list(exp);nu[a]-=2;Z[ids[tuple(nu)],j]=exp[a]*(exp[a]-1)
 return [list(x) for x in Z.nullspace()],mons

def eval_harm(coeffs,exps,point):
 z=0
 for coeff,(a,b,c) in zip(coeffs,exps):
  num,den=int(s.numer(coeff)),int(s.denom(coeff)); assert den%p
  z+=num*pow(den,-1,p)*pow(point[0],a,p)*pow(point[1],b,p)*pow(point[2],c,p)
 return z%p

def eval_matrix(levels):
 cols=[]
 for ell in levels:
  B,exps=harmonic_basis(ell);assert len(B)==2*ell+1
  for f in B:cols.append([eval_harm(f,exps,pt) for pt in v])
 return [list(row) for row in zip(*cols)]
E20=eval_matrix([0,1,3,4]);assert len(E20)==len(E20[0])==20
assert rank_mod(E20)[0]==20
assert det_mod(E20)==8
E25=eval_matrix([0,1,2,3,4]);assert len(E25)==20 and len(E25[0])==25
assert rank_mod(E25)[0]==20
assert rank_mod(eval_matrix([0,1,2,3]))[0]==16
# The 25-dim SU3 Sym3 + Sym4 restricts to H0+H1+H2+H3+H4,
# the 28-dim SU3 Sym1+Sym3+Sym4 contains H0+H1+H3+H4 as an A5 module,
# and H1+H2 as its 8-dimensional complementary A5 module.
status={
 'file_id':'Paper00-FlavorAlgebraSelection-v1_1',
 'geometry_parent':'Paper00-S3StructureNetwork-v1_46',
 'scope':'EXACT_GEOMETRY_SELECTION_AND_MINIMAL_SU3_REPRESENTATION_DILATION; NOT_PHYSICAL_ACTION_MATCHING',
 'algebraic_defect':'D=[K(E12),K(E21)]-K(E11-E22)',
 'defect_integral_scaling':'64 D = J12 J21 - J21 J12 - 8(J11-J22), J_ab=8 K(E_ab)',
 'defect_hilbert_schmidt_norm_squared':124,
 'defect_unnormalized_norm_squared_4096_times':norm[0],
 'defect_annihilates_U_checks':60,
 'defect_rank_Qsqrt5_exact':17,
 'defect_rank_certification_prime':p,
 'sqrt5_mod_prime':sqrt5mod,
 'defect_leading_minor_range':'indices 0 through 16 (rows and columns)',
 'defect_leading_17x17_minor_mod11':lead_det,
 'defect_cartan_pair_ranks_mod11':{f'{a}{b}':rank_mod(reduce_pair_mod(defect(a,b)))[0] for a,b in [(0,1),(0,2),(1,2)]},
 'defect_common_kernel':'im(Q)=span of three column-vectors u^a/sqrt5; dimension 3',
 'basis_invariant_defect_energy':'E=sum_A<B ([K(F_A),K(F_B)]-K([F_A,F_B)])* ([...]), invariant under orthogonal change of orthonormal Herm3-traceless generators; ker E=im Q',
 'a5_directed_pairs_permutation_character':[20,0,2,0,0],
 'a5_irrep_decomposition':perm_decomp,
 'su3_sym3_restriction':su3_decomp(3,0)[1],
 'su3_sym4_restriction':su3_decomp(4,0)[1],
 'su3_24_restriction':su3_decomp(3,1)[1],
 'minimal_su3_dilation_of_W20_A5_only':25,
 'minimal_su3_dilation_with_Q_as_invariant_fundamental3':28,
 'harmonic_evaluation_grade_set':[0,1,3,4],
 'harmonic_evaluation_matrix_shape':[20,20],
 'harmonic_evaluation_mod11_determinant':8,
 'harmonic_evaluation_full_grade_set':[0,1,2,3,4],
 'full_harmonic_evaluation_shape':[20,25],
 'full_harmonic_evaluation_rank_mod11':20,
 'full_harmonic_evaluation_kernel_A5_module':'5 (one copy)',
 'minimal_28dim_completion':'SU3 Sym1(C3) (3) + Sym3(C3) (10) + Sym4(C3) (15); under SO3 H1+(H3+H1)+(H4+H2+H0)',
 'chosen_A5_submodule_of_28':'H1(from Sym1)+H3(from Sym3)+H0+H4(from Sym4) = 20',
 'eight_complementary_A5_modes':'H1(from Sym3)+H2(from Sym4) = 3+5 (8)',
 'exact_rotation_current_HS_squared_on_20_graph':5,
 'exact_rotation_current_HS_squared_numer_256':curl_hs_numer,
 'minimal_28_H3_block_HS_squared':7,
 'fundamental_3_block_HS_squared':'1/2',
 'minimal28_current_compression_lower_bound_HS_squared':'15/2',
 'minimal28_exact_current_match_status':'RULED_OUT: for either minimal 28 SU3 module with fixed fundamental3, all 3prime and both 4 A5 copies must lie inside the original 20, forcing the complete l3 harmonic SO3 block. Its normalized rotation generator contributes norm2=7, fundamental contributes 1/2, while K(lambda/2) has norm2=5.',
 'warning':'The 28-dim SU3 module is a minimal equivariant representation completion, but its normalized SU3 generators cannot compress to the particular one-hop K on all 20. A larger module or a modified off-carrier source/current is necessary for such a full algebraic dilation.',
 'physical_implication':'If native Gauss-compatible vector charge map equals K on a reducing graph sector, CAR current algebra requires the sector to be contained in the defect-free 3, but it does not prove the map occurs in actual QCD action'
}
out=root/'data/Paper00-FlavorAlgebraSelection-v1_1.json'
out.write_text(json.dumps(status,indent=2,ensure_ascii=False)+'\n')
print('EXACT DEFECT: rank 17, norm squared 124, leading minor det 7 mod 11')
print('EXACT A5 PERMUTATION',perm_decomp)
print('MINIMAL SU3 DILATIONS: 25 without Q, 28 preserving Q')
print('HARMONIC EVAL: det 8 mod 11; full 20x25 rank20')
print('WROTE',out)
