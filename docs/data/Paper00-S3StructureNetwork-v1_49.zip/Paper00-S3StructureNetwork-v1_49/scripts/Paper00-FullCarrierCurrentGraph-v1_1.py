#!/usr/bin/env python3
"""Typed, scoped geometry / full-carrier-current operator DAG (NOT proof DAG)."""
from pathlib import Path
import xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
ns='http://graphml.graphdrawing.org/xmlns'
ET.register_namespace('',ns)
G=ET.Element('{%s}graphml'%ns)
for field,domain in [('kind','node'),('status','node'),('relation','edge')]:
 ET.SubElement(G,'{%s}key'%ns,{'id':field,'for':domain,'attr.name':field,'attr.type':'string'})
g=ET.SubElement(G,'{%s}graph'%ns,{'id':'FullCarrierGeometricCurrents','edgedefault':'directed'})
nodes={
 'CORES':('2I five 2T cores and directed pairs','EXACT_INHERITED'),
 'D20':('20 vertex dodecahedral graph','EXACT_INHERITED'),
 'K':('one-hop K(H) nearest-neighbor current','EXACT_INHERITED'),
 'Q3':('protected fundamental flavor3','EXACT_INHERITED'),
 'W17':('complementary 17 A5 module','EXACT_INHERITED'),
 'T9':('nine pure-state flavor-tomography frame','EXACT_AUXILIARY_CHOICE'),
 'BS':('nine B_s Hermitian complementary blocks','EXACT_CONSTRUCTION'),
 'TB':('T=sum_s |B_s| < 24 I bound','EXACT_CERTIFICATE'),
 'J99':('99,470 dimensional finite unitary U3 dilation','EXACT_EXISTENCE_NOT_MINIMAL'),
 'KCOMP':('K(H)=J* Qhat(H) J on all 20','EXACT_COMPRESSION'),
 'SYM28':('28 dim Sym1+Sym3+Sym4 SU3 module','EXACT_INHERITED'),
 'P20':('20 dim selected harmonic projection in 28','EXACT_POLYNOMIAL_PROJECTOR'),
 'X8':('eight A5 auxiliary harmonic modes','EXACT'),
 'K28':('corrected nonlocal compression Ktilde28','EXACT_NOT_ORIGINAL_K'),
 'G28':('28 quintet leakage: 3482/105; triplet zero','EXACT'),
 'CAR':('native Paper VII-A vector/axial source derivative','PHYSICAL_MATCHING_OPEN'),
 'GAUSS':('native local Gauss and superselection embedding','PHYSICAL_REALIZATION_OPEN'),
 'DECAY':('physical retarded residues, branchings, lifetimes','PHYSICAL_DYNAMICS_OPEN')}
for ident,(kind,status) in nodes.items():
 n=ET.SubElement(g,'{%s}node'%ns,{'id':ident})
 for key,txt in [('kind',kind),('status',status)]:ET.SubElement(n,'{%s}data'%ns,{'key':key}).text=txt
edges=[('CORES','D20','geometric incidence'),('D20','K','one-hop local current'),('K','Q3','exact reducing fundamental'),('K','W17','complementary defect'),('Q3','T9','fixed flavor coordinates'),('T9','BS','dual tomography K(D_s)'),('W17','BS','matrix compression'),('BS','TB','exact second moments and Gershgorin'),('TB','J99','positive spectral coisometry'),('J99','KCOMP','unitary U3 tensor currents'),('K','KCOMP','exact all-H compression'),('SYM28','P20','SO3 Casimir polynomial'),('P20','X8','orthogonal complement'),('SYM28','K28','full SU3 generator compression'),('X8','G28','source leakage'),('K28','G28','exact all quintet norms'),('J99','CAR','native identification not supplied'),('SYM28','CAR','native identification not supplied'),('CAR','GAUSS','requires actual invariant physical embedding'),('GAUSS','DECAY','requires on shell current and retarded channels')]
for idx,(a,b,rel) in enumerate(edges):
 e=ET.SubElement(g,'{%s}edge'%ns,{'id':f'e{idx}','source':a,'target':b})
 ET.SubElement(e,'{%s}data'%ns,{'key':'relation'}).text=rel
out=root/'graph/Paper00-FullCarrierCurrent-v1_1.graphml'
ET.ElementTree(G).write(out,encoding='utf-8',xml_declaration=True)
print('wrote',out,'nodes',len(nodes),'edges',len(edges))
