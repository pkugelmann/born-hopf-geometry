#!/usr/bin/env python3
"""Publish typed geometry/current-port graph; NO physical decay edges."""
import json
from pathlib import Path
import networkx as nx
ROOT=Path(__file__).resolve().parents[1]
source=json.loads((ROOT/'data'/'Paper00-CurvatureSpinFlavorBridge-v1_1.json').read_text())
G=nx.MultiDiGraph(name='Exact dodecahedral curvature, meson N9, 56-state axial comparison')
foundations=[
 ('twoI','Five 2T cores in 2I','CERTIFIED_GEOMETRY'),
 ('pair20','20 ordered five-core pairs','CERTIFIED_GEOMETRY'),
 ('dodeca20','30-edge regular dodecahedron','CERTIFIED_GEOMETRY'),
 ('curl3','3 non-gradient Hermitian edge-curl currents','EXACT_NEW'),
 ('flavor3','Actual quaternionic A5 triplet V3','EXACT_NEW'),
 ('flavor8','Herm_0(C3)=3+5, su(3) operator algebra','EXACT_NEW'),
 ('spinlink','Positive SU2 spin-link Dirichlet graph action','NEW_COMPARISON_ACTION'),
 ('spinflavor6','C2_spin tensor C3_flavor','EXACT_NEW'),
 ('B56','Sym^3(C6) = octet16 + decuplet40','EXACT_NEW'),
 ('N9','N9 meson source: 1+3+5 from scalar/linear/quadratic harmonics','EXACT_NEW'),
 ('N8','Traceless meson source: 3+5','EXACT_NEW'),
 ('frame','N8 to baryon8-decuplet10 source tight frame (Gram 5 I8)','EXACT_NEW'),
 ('isospin','Real-selected light 2-plane: one 3 plus two 5 directions','CONDITIONAL_SELECTION'),
 ('CAR','Existing rooted 56-dimensional reference Wilson/CAR isometry','EXISTING_SOURCE_CONDITIONAL'),
 ('physical','Actual Gauss/Ward/poles/decay physical source selection','OPEN_PHYSICAL'),
]
for key,label,status in foundations:G.add_node(key,label=label,status=status,physical_pole=False)
relations=[
 ('twoI','pair20','ordered pair identification'),('pair20','dodeca20','orbital-7 nearest-edge graph'),
 ('dodeca20','curl3','orientation edge cross product'),('curl3','flavor3','Q-dagger C_a Q=-lambda_a/2'),
 ('flavor3','flavor8','Hermitian matrix product and traceless quadrupoles'),
 ('dodeca20','N9','isometry Y by fourth moment'),('N9','N8','tracefree projection'),
 ('curl3','spinlink','unitary spin-valued edge phase'),('spinlink','spinflavor6','field derivative after P3 compression'),
 ('spinflavor6','B56','primitive Sym^3 lift'),('flavor8','frame','full eight source-current basis'),
 ('N8','frame','Y inverse + normalized primitive lift'),('B56','frame','octet/decuplet projector'),
 ('N8','isospin','real light two-plane physical source chooses SU2'),
 ('B56','CAR','rooted gauge-covariant reference source placement'),
 ('CAR','physical','actual action-and-Gauss identification unproved'),
]
for a,b,label in relations:G.add_edge(a,b,kind='typed_map',label=label,physical_decay=False)
for src in ('3','5'):
 G.add_node('8_'+src,label='Octet A5 '+src,status='EXACT_REPRESENTATION',physical_pole=False)
for dst in ('3','3prime','4'):
 G.add_node('10_'+dst,label='Decuplet A5 '+dst,status='EXACT_REPRESENTATION',physical_pole=False)
for src in ('3','5'):
 for dst in ('3','3prime','4'):
  for cur in ('triplet','quintet'):
   strength=source['exact_irrep_channel_strengths'][f'{cur}|{src}->{dst}']
   G.add_edge('8_'+src,'10_'+dst,key=f'{cur}_{src}_{dst}',kind='squared_HS_current',current=cur,
              strength=str(strength),allowed=bool(strength),physical_decay=False,source_coupling_status='comparison_only')
  iso=source['real_aligned_isotriplet_irrep_channel_strengths'][f'{src}->{dst}']
  G.add_edge('8_'+src,'10_'+dst,key=f'isospin_{src}_{dst}',kind='conditional_isovector_summed_strength',
             current='real_aligned_isospin',strength=iso,allowed=True,physical_decay=False,
             source_coupling_status='physical_two_plane_not_selected')
OUT=ROOT/'graph'/'Paper00-CurvatureMesonBaryonPorts-v1_1.graphml';OUT.parent.mkdir(parents=True,exist_ok=True)
nx.write_graphml(G,OUT)
print('PASS graph nodes',G.number_of_nodes(),'edges',G.number_of_edges(),'file',OUT)
