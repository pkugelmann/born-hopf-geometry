#!/usr/bin/env python3
"""Deterministic replay of second jet, exact spectral leak and scoped graph."""
import hashlib,json,os,subprocess,sys
from pathlib import Path
import networkx as nx
root=Path(__file__).resolve().parents[1]
cert=root/'data/Paper00-SecondJetGaussIsospin-v1_1.json'
graph=root/'graph/Paper00-SecondJetGaussIsospin-v1_1.graphml'
old=(hashlib.sha256(cert.read_bytes()).hexdigest(),hashlib.sha256(graph.read_bytes()).hexdigest())
env=os.environ.copy();env['OPENBLAS_NUM_THREADS']='1'
for script in ('Paper00-SecondJetSourceCompiler-v1_1.py','Paper00-SecondJetSourceGraph-v1_1.py'):
 r=subprocess.run([sys.executable,str(root/'scripts'/script)],cwd=root,env=env,capture_output=True,text=True)
 assert r.returncode==0,(script,r.stdout,r.stderr)
now=(hashlib.sha256(cert.read_bytes()).hexdigest(),hashlib.sha256(graph.read_bytes()).hexdigest())
assert now==old,'certificate or graph non-deterministic'
x=json.loads(cert.read_text());g=nx.read_graphml(graph)
assert x['exact_second_jet_tensor_checks']==81
assert x['exact_Faa_irrep_projected_strengths']=={'1':'0','3':'9/80','3prime':'1/80','4_even':'0','4_odd':'1/40','5':'0'}
assert x['isospin_total']=='15 for every complex rank-two light-flavor plane'
assert x['dirac_rest_spin_source_factor'].startswith('Rest upper Dirac')
assert len(g.nodes)==21 and len(g.edges)==27,(len(g.nodes),len(g.edges))
assert not any(e.get('physical_decay',False) for _,_,e in g.edges(data=True))
assert g.nodes['poles']['status']=='OPEN_PHYSICAL_READOUT'
print('PASS 81 exact tensor components, 18 exact spectral returns, 6 isospin formulas, gauge/Dirac controls; deterministic graph+certificate')
