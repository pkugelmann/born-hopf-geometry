#!/usr/bin/env python3
"""Byte-identical regeneration and current-only graph scope replay."""
import hashlib,subprocess,sys,json,os
from pathlib import Path
import networkx as nx
ROOT=Path(__file__).resolve().parents[1]
CERT=ROOT/'data'/'Paper00-CurvatureSpinFlavorBridge-v1_1.json'
GRAPH=ROOT/'graph'/'Paper00-CurvatureMesonBaryonPorts-v1_1.graphml'
assert CERT.exists() and GRAPH.exists()
old=hashlib.sha256(CERT.read_bytes()).hexdigest();oldgraph=hashlib.sha256(GRAPH.read_bytes()).hexdigest()
env=os.environ.copy();env['OPENBLAS_NUM_THREADS']='1'
subprocess.run([sys.executable,str(ROOT/'scripts'/'Paper00-CurvatureSpinFlavorExactCompiler-v1_1.py')],check=True,cwd=ROOT,env=env,capture_output=True,text=True)
subprocess.run([sys.executable,str(ROOT/'scripts'/'Paper00-CurvatureMesonBaryonGraph-v1_1.py')],check=True,cwd=ROOT,env=env,capture_output=True,text=True)
assert hashlib.sha256(CERT.read_bytes()).hexdigest()==old,'certificate bytes differ'
assert hashlib.sha256(GRAPH.read_bytes()).hexdigest()==oldgraph,'graph bytes differ'
D=json.loads(CERT.read_text());G=nx.read_graphml(GRAPH)
assert G.number_of_nodes()==20 and G.number_of_edges()==34,(G.number_of_nodes(),G.number_of_edges())
assert all(not ed['physical_decay'] for u,v,ed in G.edges(data=True))
channels=[ed for u,v,ed in G.edges(data=True) if ed['kind']=='squared_HS_current']
assert len(channels)==12
assert sum(int(e['strength']) for e in channels if e['current']=='triplet')==15
assert sum(int(e['strength']) for e in channels if e['current']=='quintet')==25
assert sum(int(e['strength'])==0 for e in channels)==2
iso=[ed for u,v,ed in G.edges(data=True) if ed['kind']=='conditional_isovector_summed_strength']
assert len(iso)==6
from fractions import Fraction
assert sum((Fraction(e['strength']) for e in iso),Fraction(0))==15
assert D['independent_exact_triplet_quintet_axial_strengths']['total']==40
assert D['not_claimed'][0]=='Actual physical QCD/Born action equality'
print('PASS exact certificate deterministic, graph typed, 12 currents + 6 conditional SU2 strengths')
