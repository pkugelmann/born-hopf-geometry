#!/usr/bin/env python3
"""Exact nearest-edge, shift-preserving triplet source and all-sector spectral
selection on the native twenty directed-pair/dodecahedron carrier.

Source data and parent constructions: Paper00-S3StructureNetwork-v1_42.
Pure finite geometric comparison. NO physical current/pion identification.
"""
import json
from pathlib import Path

import sympy as sp
from sympy.physics.wigner import clebsch_gordan

ROOT=Path(__file__).resolve().parents[1]
DODEC=ROOT/'data'/'Paper00-DodecahedralHodgeCurrent-v1_1.json'
ORB=ROOT/'data'/'Paper00-FiveCoreOrbitalAlgebra-v1_1.json'
OUT=ROOT/'data'/'Paper00-MidpointTripletResponse-v1_1.json'
R=sp.sqrt(5)
X=sp.Symbol('x')

def simpl(x):
    return sp.simplify(sp.expand(x))
def ss(x):
    return str(simpl(x))

def main():
    data=json.loads(DODEC.read_text())['dodecahedron']
    orb=json.loads(ORB.read_text())
    U=[sp.Matrix([sp.sympify(z) for z in row['u']]) for row in data['vertex_coordinates']]
    assert len(U)==20 and all(simpl(u.dot(u))==sp.Rational(3,4) for u in U)
    edges={tuple(sorted(pair)) for pair in data['edges']}
    A=sp.zeros(20)
    for i,j in edges:A[i,j]=A[j,i]=1
    assert len(edges)==30 and all(sum(A[i,j] for j in range(20))==3 for i in range(20))
    assert all(sp.simplify(sum((A[i,j]*U[j] for j in range(20)),sp.zeros(3,1))-R*U[i])==sp.zeros(3,1) for i in range(20))
    eigs={'1':sp.S(3),'3':R,'3prime':-R,'4_even':-sp.S(2),'4_odd':sp.S(0),'5':sp.S(1)}
    dims={'1':1,'3':3,'3prime':3,'4_even':4,'4_odd':4,'5':5}
    orbitals=[[(int(i),int(j)) for i,j in o] for o in orb['basis_sparse_pairs']]
    assert len(orbitals)==8 and sum(map(len,orbitals))==400
    # Evaluate six Lagrange spectral idempotents using only integer
    # adjacency powers and eight orbit representative entries.
    powers=[sp.eye(20)]
    for n in range(1,6):powers.append(powers[-1]*A)
    pvals={}
    for label,lam in eigs.items():
        p=sp.prod((X-v)/(lam-v) for v in eigs.values() if v!=lam)
        coeff=[simpl(sp.expand(p).coeff(X,n)) for n in range(6)]
        assert all(simpl(p.subs(X,w)-(1 if lam==w else 0))==0 for w in eigs.values())
        values=[]
        for orbital in orbitals:
            pair=orbital[0]
            value=simpl(sum(coeff[k]*powers[k][pair[0],pair[1]] for k in range(6)))
            assert all(simpl(sum(coeff[k]*powers[k][i,j] for k in range(6))-value)==0 for i,j in orbital)
            values.append(value)
        pvals[label]=values
        d=simpl(sum(len(o)*v for o,v in zip(orbitals,values) if o[0][0]==o[0][1]))
        # Trace = sum all diagonal entries, not sum of orbital sizes.
        d=simpl(sum(values[k]*len(o) for k,o in enumerate(orbitals) if o[0][0]==o[0][1]))
        assert d==dims[label],(label,d)
    dots=[]
    for orbital in orbitals:
        i,j=orbital[0];d=simpl(U[i].dot(U[j]))
        assert all(simpl(U[i].dot(U[j])-d)==0 for i,j in orbital)
        dots.append(d)
    labels=list(eigs)
    S_D={};S_J={}
    for i,il in enumerate(labels):
        for jl in labels[i:]:
            d=simpl(sum(len(o)*pvals[il][k]*pvals[jl][k]*dots[k] for k,o in enumerate(orbitals)))
            assert (d==0 or d.is_positive),(il,jl,d)
            coeff=simpl((3+R-eigs[il]-eigs[jl])/2)
            s=simpl(coeff**2*d)
            S_D[(il,jl)]=d;S_J[(il,jl)]=s
    expected_D={('1','3'):sp.Rational(3,4),('3','5'):sp.Rational(3,2),
            ('3prime','4_even'):sp.S(2),('3prime','5'):sp.Rational(1,4),
            ('4_even','4_odd'):sp.S(1),('4_odd','5'):sp.S(2)}
    for key,d in S_D.items():assert d==expected_D.get(key,0),(key,d)
    assert S_J[('3','5')]==sp.Rational(3,2)
    assert S_J[('3prime','5')]==(3+R)/2
    expected_J={('3','5'):sp.Rational(3,2),
            ('3prime','4_even'):sp.Rational(45,2)+10*R,
            ('3prime','5'):(3+R)/2,
            ('4_even','4_odd'):(15+5*R)/2,
            ('4_odd','5'):(9+4*R)/2}
    for key,s in S_J.items():assert s==expected_J.get(key,0),(key,s)
    # Verify the complete 20x20 field derivative of the single Dirichlet
    # action, including the onsite contact/diagonal terms.
    J=[]
    for a in range(3):
        D=sp.diag(*[u[a] for u in U]);mat=sp.zeros(20)
        for i,j in edges:
            w=(U[i][a]+U[j][a])/2
            mat[i,i]+=w;mat[j,j]+=w
            mat[i,j]-=w;mat[j,i]-=w
        check=((3+R)*D-D*A-A*D)/2
        assert all(simpl(mat[i,j]-check[i,j])==0 for i in range(20) for j in range(20))
        assert all(sum(mat[i,j] for j in range(20))==0 for i in range(20))
        J.append(mat)
    total=simpl(sum(sum(mat[i,j]*mat[i,j] for i in range(20) for j in range(20)) for mat in J))
    assert total==75+30*R
    assert simpl(2*sum(S_J.values()))==total
    assert sum(A[i,i] for i in range(20))==0
    baseline_L_squared=9*20+sum(A[i,j]*A[j,i] for i in range(20) for j in range(20))
    assert baseline_L_squared==240
    # SU2 irreducible intertwiners: (3/2 tensor 1) -> 1/2,
    # fixed by Clebsch-Gordan coefficients up to overall phase.
    spins=[-sp.Rational(3,2),-sp.Rational(1,2),sp.Rational(1,2),sp.Rational(3,2)]
    ms=[-sp.Rational(1,2),sp.Rational(1,2)]
    qs=[-1,0,1]
    T={str(q):[[ss(clebsch_gordan(sp.Rational(3,2),1,sp.Rational(1,2),M,sp.S(q),m))
                  for m in ms] for M in spins] for q in qs}
    for n,m in enumerate(ms):
        for mprime in ms:
            overlap=sum(
              clebsch_gordan(sp.Rational(3,2),1,sp.Rational(1,2),M,sp.S(q),m)
             *clebsch_gordan(sp.Rational(3,2),1,sp.Rational(1,2),M,sp.S(q),mprime)
             for q in qs for M in spins)
            assert simpl(overlap)==(1 if m==mprime else 0)
    spin_factor=sp.S(2) # trace sum_q T_q^dagger T_q = trace I_2
    # The five-core pair-octet/paired decuplet flavors in W56:
    # F8=3(odd)+5(even), F10_pair=3(odd)+3prime(odd).
    spin_flavor=simpl(spin_factor*(S_J[('3','5')]+S_J[('3prime','5')]))
    assert spin_flavor==6+R
    # The source VII-B W56 chart admits two distinct normalized geometric
    # injections of its cubic 4 into pair-even and pair-odd 4 irreps.
    # A normalized mixture cos(theta) J_e + exp(i phase)sin(theta) J_o
    # contributes only via the odd 4, because J is R-odd and the only
    # nonzero 5-to-4 block is 5-even <-> 4-odd.
    cubic_odd_extra=simpl(spin_factor*S_J[('4_odd','5')])
    assert cubic_odd_extra==9+4*R
    full_span_upper=simpl(spin_flavor+cubic_odd_extra)
    assert full_span_upper==15+5*R
    ordered=sorted(labels,key=lambda x:float(sp.N(3-eigs[x])))
    downhill=[]
    for (il,jl),s in S_J.items():
        if s==0:continue
        h,l=(il,jl) if float(sp.N(3-eigs[il]))>float(sp.N(3-eigs[jl])) else (jl,il)
        gap=simpl(eigs[l]-eigs[h]) # energy high-low = lambda_adjacency_low - lambda_adjacency_high
        assert gap.is_positive,(h,l,gap)
        downhill.append({'from':h,'to':l,'energy_gap':ss(gap),'triplet_HS_squared':ss(s)})
    downhill=sorted(downhill,key=lambda item:(ordered.index(item['from']),ordered.index(item['to'])))
    # Exact Feshbach return on the natural P5 sector. Since J is odd under
    # antipodal reversal, P5*J*P5=0. Its first nonzero return is quadratic,
    # and the A5-averaged scalar susceptibility is a rational function with
    # exactly three (discrete) geometric target poles. No absorptive width.
    z=sp.Symbol('z')
    outgoing=[('3',S_J[('3','5')]),('3prime',S_J[('3prime','5')]),('4_odd',S_J[('4_odd','5')])]
    scalar_resolvent=sum(weight/(z-(3-eigs[k])) for k,weight in outgoing)
    average_trace_second_order=simpl(sum(weight/(2-(3-eigs[k])) for k,weight in outgoing)/15)
    assert average_trace_second_order==-(7+3*R)/24
    # For t in R^3 the (unnormalized) P5 trace is |t|^2/3 times
    # scalar_resolvent by A5 triplet isotropy; normalized by rank P5=5.
    nonzero_summary={'geometric_poles':{k:ss(3-eigs[k]) for k,w in outgoing},
       'triplet_summed_residues':{k:ss(w) for k,w in outgoing},
       'trace_sigma_quadratic_over_norm_t_squared':str(sp.factor(scalar_resolvent/3)),
       'mean_per_P5_state_sigma_quadratic_over_norm_t_squared':str(sp.factor(scalar_resolvent/15)),
       'mean_level_shift_at_z_2_second_order':ss(average_trace_second_order),
       'requires_continuum_to_get_irreversible_width':True}
    out={
      'name':'Paper00-MidpointTripletResponse-v1_1',
      'date':'2026-11-20',
      'scope':'Exact twenty-pair A5 dodecahedral local action response; NOT physical decay rates',
      'source_certificates':[DODEC.name,ORB.name],
      'action':'E_t(psi)=1/2 sum_{undirected edges ij}[1+t dot (u_i+u_j)/2]*abs(psi_i-psi_j)^2',
      'graph_operator':'L(t) with offdiag -w_ij(t), diag sum_neighbors w_ij(t); L(0)=3I-A',
      'field_derivative':'J_a=1/2*((3+sqrt(5))*D_a-D_a*A-A*D_a), D_a=diag(u_i^a)',
      'nearest_neighbor_hermitian_A5_triplet_dimensions':{
         'onsite_real_symmetric':1,'edge_real_symmetric':1,
         'edge_imaginary_antisymmetric_gradient':1,'edge_imaginary_antisymmetric_curl':1,
         'total':4,'shift_preserving_symmetric_Dirichlet':1},
      'operator_properties':{'A5_triplet_covariant':True,'Hermitian_real_symmetric':True,
           'constant_vector_J_a_zero':True,'non_pure_gauge':True,
           'strict_positive_conductance_for_norm_t_less_than':'sqrt(8/(3+sqrt(5)))',
           'trace_L0_squared':'240','trace_Lt_squared':'240+(25+10*sqrt(5))*norm(t)^2',
           'sum_a_trace_J_a_squared':ss(total)},
      'spectral_adjacency_eigenvalues':{k:ss(v) for k,v in eigs.items()},
      'Dirichlet_L0_levels':{k:ss(3-v) for k,v in eigs.items()},
      'rank_multiplicities':dims,
      'all_site_triplet_squared_strengths':{f'{i}|{j}':ss(s) for (i,j),s in S_D.items()},
      'all_action_derived_triplet_squared_strengths':{f'{i}|{j}':ss(s) for (i,j),s in S_J.items()},
      'nonzero_geometric_downhill_arrows':downhill,
      'exact_second_order_P5_Feshbach_return':nonzero_summary,
      'geometry_ratio_5_to_3_over_5_to_3prime':'3/(3+sqrt(5))',
      'spin_clebsch_gordan_components_3over2_times1_to_half':T,
      'spin_isometry_sum_q_Tq_dagger_Tq':'I_2',
      'conditional_W56_pair_flavor_current_triplet_spin_sum_HS_squared':ss(spin_flavor),
      'conditional_W56_with_cubic4_embedding':{
         'cubic4_embedding':'cos(theta)*J_even + exp(i*phase)*sin(theta)*J_odd',
         'full_triplet_spin_summed_offdiagonal_norm':'6+sqrt(5)+(9+4*sqrt(5))*sin(theta)^2',
         'minimal_even_cubic4_embedding':ss(spin_flavor),
         'maximal_odd_cubic4_embedding':ss(full_span_upper),
         'Dirichlet_lower_4_copy':'4_odd at energy 3, versus 4_even at energy 5',
         'physical_identification_of_source_spin_vertex':'not established'},
      'formal_retarded_green_derivative':'d(z-L(t))^-1/dt_a|0=(z-L0)^-1 J_a (z-L0)^-1',
      'proof_summary':'A5 site stabilizer C3 fixes one vector; edge stabilizer C2 fixes one symmetric midpoint and two antisymmetric directions. Edge Dirichlet row-sum imposes unique onsite completion. Spectral projector Lagrange polynomials, evaluated on all eight E20xE20 orbitals, give exact all-sector HS strengths. Nonconstant trace(L(t)^2) rules out pure-gauge unitary conjugation. The spin comparison uses only unit-normalized SU2 Clebsch-Gordan.',
      'not_claimed':['Born/QCD same-action physical field identity','pion isotriplet selection',
                     'full 56 spin and charge matching','physical energy mapping',
                     'pole residues or hadron masses','physical decay arrows or widths',
                     'E3/E4 global proof status'],
    }
    OUT.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
    print('PASS all eight orbitals, six spectral projectors, thirty edge action derivatives')
    print('PASS complete nonzero directed geometric transitions',[(x['from'],x['to'],x['triplet_HS_squared']) for x in downhill])
    print('PASS unique local source, non-gauge spectral change, spin-CG factor',ss(spin_flavor))
    print('PASS exact P5 Feshbach self-energy, mean second order shift',ss(average_trace_second_order))
    print('PASS spin-flavor 56-chart comparison interval',ss(spin_flavor),ss(full_span_upper))
    print('OUTPUT',OUT)
if __name__=='__main__':main()
