#!/usr/bin/env python3
"""Deterministically reproduce exact new local lift and graph certificates."""
from pathlib import Path
import subprocess,sys,os,hashlib,json
import networkx as nx
root=Path(__file__).resolve().parents[1]
C=root/'data/Paper00-ProtectedFlavorLift-v1_1.json'
G=root/'graph/Paper00-ProtectedFlavorLift-v1_1.graphml'
old=[hashlib.sha256(p.read_bytes()).hexdigest() for p in (C,G)]
env=os.environ.copy();env['OPENBLAS_NUM_THREADS']='1'
for name in ['Paper00-ProtectedFlavorLiftCompiler-v1_1.py','Paper00-ProtectedFlavorLiftGraph-v1_1.py']:
 p=subprocess.run([sys.executable,str(root/'scripts'/name)],cwd=root,env=env,capture_output=True,text=True)
 assert p.returncode==0,(name,p.stdout,p.stderr)
new=[hashlib.sha256(p.read_bytes()).hexdigest() for p in (C,G)]
assert new==old,(old,new)
c=json.loads(C.read_text());g=nx.read_graphml(G)
assert c['exact_tight_frame_tests']==180 and c['exact_intertwining_tests']==540 and c['exact_A5_action_tests']==60
assert c['exact_quintet_leakage_rank']==3
assert len(g.nodes)==19 and len(g.edges)==21
assert g.nodes['native_qcd_action']['status']=='OPEN_PHYSICAL_OCCURRENCE'
assert not any(e.get('physical_decay',False) for _,_,e in g.edges(data=True))
print('PASS exact local flavor lift, scoped one-hop uniqueness, 24 axial source directions, deterministic typed overlay')
