#!/usr/bin/env python3
"""Deterministic 6-sector/5-arrow exact dodecahedral response graph.
Math energy order only. No physical particle/decay label is assigned.
"""
import json
from pathlib import Path
import networkx as nx
ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'data'/'Paper00-MidpointTripletResponse-v1_1.json'
OUT=ROOT/'graph'/'Paper00-MidpointTripletTransitions-v1_1.graphml'

def main():
    cert=json.loads(SOURCE.read_text())
    graph=nx.DiGraph(name='geometric twenty-pair Dirichlet current, no physical selection')
    for label,eps in cert['Dirichlet_L0_levels'].items():
        graph.add_node(label,label=label,representation_dimension=cert['rank_multiplicities'][label],
                       dimensionless_L0_level=eps,physical_decay=False,
                       scope='exact A5/dodecahedral mathematical spectral sector')
    for edge in cert['nonzero_geometric_downhill_arrows']:
        graph.add_edge(edge['from'],edge['to'],
                       geometric_gap=edge['energy_gap'],
                       triplet_HS_squared=edge['triplet_HS_squared'],
                       derived_from='single Dirichlet edge-action derivative',
                       arrow_type='decreasing L0 eigenvalue',physical_decay=False)
    assert len(graph)==6 and len(graph.edges())==5
    assert nx.is_directed_acyclic_graph(graph)
    assert all(not graph.nodes[n]['physical_decay'] for n in graph)
    OUT.parent.mkdir(exist_ok=True)
    nx.write_graphml(graph,OUT)
    roundtrip=nx.read_graphml(OUT)
    assert len(roundtrip)==6 and len(roundtrip.edges())==5
    assert sorted(graph.edges())==sorted(roundtrip.edges())
    print('PASS 6 sector nodes, 5 exact geometric downhill edges, no physical claims')
    print('OUTPUT',OUT)
if __name__=='__main__':main()
