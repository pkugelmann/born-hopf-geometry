#!/usr/bin/env python3
"""Exact, dependency-free Q(sqrt5) certificate for nearest-neighbor Herm3 lift.
Reads frozen 20-pair algebra and unit dodecahedron from inherited certificates.
"""
from pathlib import Path
import json, itertools
from collections import defaultdict

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data'
A5=json.loads((DATA/'Paper00-TripletCurrentSpace-v1_1.json').read_text())
ORB=json.loads((DATA/'Paper00-FiveCoreOrbitalAlgebra-v1_1.json').read_text())
raw=next(x for x in A5['basis_tensors'] if x['orbital_index']==0)

# Pair arithmetic x0+x1 sqrt5, integer exact.
def add(x,y):return (x[0]+y[0], x[1]+y[1])
def sub(x,y):return (x[0]-y[0], x[1]-y[1])
def neg(x):return (-x[0],-x[1])
def mul(x,y):return (x[0]*y[0]+5*x[1]*y[1],x[0]*y[1]+x[1]*y[0])
def times(x,n):return (n*x[0],n*x[1])
def smul(x,y):return sum_pairs(mul(a,b) for a,b in zip(x,y))
def sum_pairs(seq):
 a,b=0,0
 for x,y in seq:a+=x;b+=y
 return a,b
def cross(x,y):
 return [sub(mul(x[(r+1)%3],y[(r+2)%3]),mul(x[(r+2)%3],y[(r+1)%3])) for r in range(3)]
# exact from raw strings by parse as linear polynomials, to avoid sympy
import sympy as sp
S=sp.sqrt(5)
def int_pair(val):
 expr=sp.expand(4*sp.sympify(val)); a=int(expr.coeff(S,0));b=int(expr.coeff(S,1))
 assert expr==a+b*S
 return a,b
U=[[int_pair(x) for x in row[2:]] for row in raw['components']]
N=len(U)
E=sorted({tuple(sorted(x)) for x in ORB['basis_sparse_pairs'][7]})
assert N==20 and len(E)==30
neighbors=[[] for _ in range(N)];A=[[0]*N for i in range(N)]
for j,k in E:A[j][k]=A[k][j]=1; neighbors[j].append(k);neighbors[k].append(j)

# tight-frame check in the raw 4*u-coordinates:
# sum_{k~j} U_k^a U_k^b = 8 delta_ab + U_j^a U_j^b.
checks=0
for j in range(20):
 assert len(neighbors[j])==3
 for a in range(3):
  for b in range(3):
   t=sum_pairs(mul(U[k][a],U[k][b]) for k in neighbors[j])
   goal=add((8 if a==b else 0,0),mul(U[j][a],U[j][b]))
   assert t==goal,(j,a,b,t,goal)
   checks+=1
print('tight frame exact checks',checks)
# K(H) equation: 8 K(E_ab) = A_jk U_ja U_kb - delta_jk U_ja U_jb.
inter_checks=0
for a in range(3):
 for b in range(3):
  J=[[sub(mul(U[j][a],U[k][b]) if A[j][k] else (0,0), mul(U[j][a],U[j][b]) if j==k else (0,0)) for k in range(20)] for j in range(20)]
  for j in range(20):
   for v in range(3):
    lhs=sum_pairs(mul(J[j][k],U[k][v]) for k in range(20))
    rhs=times(U[j][a],8) if v==b else (0,0)
    assert lhs==rhs,(a,b,j,v,lhs,rhs)
    inter_checks+=1
print('universal lift intertwining exact checks',inter_checks)

# Exact A5 equivariance: the directed pair action respects all 30 edges,
# and the selected real flavor triplet intertwiner R is reconstructed from U.
pairs=[(a,b) for a in range(5) for b in range(5) if a!=b]
index={k:i for i,k in enumerate(pairs)}
perms=[p for p in itertools.permutations(range(5)) if sum(p[i]>p[j] for i in range(5) for j in range(i+1,5))%2==0]
assert len(perms)==60
for g in perms:
 act=[index[(g[a],g[b])] for a,b in pairs]
 assert all(A[j][k]==A[act[j]][act[k]] for j in range(20) for k in range(20))
 # Rnum=4 R, with R^T R=I, on 4u=U.
 Rnum=[[sum_pairs(mul(U[act[j]][a],U[j][b]) for j in range(20)) for b in range(3)] for a in range(3)]
 assert all(x%20==0 and y%20==0 for row in Rnum for x,y in row)
 Rnum=[[(x//20,y//20) for x,y in row] for row in Rnum]
 for j in range(20):
  for a in range(3):
   assert sum_pairs(mul(Rnum[a][b],U[j][b]) for b in range(3))==times(U[act[j]][a],4)
print('exact A5 equivariance controls:',len(perms),'even permutations')

# Exact leakage rank witness for symmetric-traceless H=diag(1,-1,0).
# Local equivariant basis: J0 (edge sHs), J1 (edge dHd),
# J2 (edge dHcross), and D (vertex uHu); scaled by 16,16,32,16.
def H(x,y):return sub(mul(x[0],y[0]),mul(x[1],y[1]))
J=[[[ (0,0) for k in range(20)] for j in range(20)] for q in range(4)]
for j,k in E:
 s=[add(U[j][a],U[k][a]) for a in range(3)]
 d=[sub(U[j][a],U[k][a]) for a in range(3)]
 c=cross(U[j],U[k])
 ws=[H(s,s),H(d,d),H(d,c)]
 for q,w in enumerate(ws):
  for x,y,sgn in [(j,j,1),(k,k,1),(j,k,-1),(k,j,-1)]:
   J[q][x][y]=add(J[q][x][y],times(w,sgn))
for j in range(20):J[3][j][j]=H(U[j],U[j])

# Leakage: L_r = (80I-UU^T) J_r U (with fixed scaled J matrices)
L=[]
for q in range(4):
 V=[[sum_pairs(mul(J[q][j][k],U[k][b]) for k in range(20)) for b in range(3)] for j in range(20)]
 S3=[[sum_pairs(mul(U[j][a],V[j][b]) for j in range(20)) for b in range(3)] for a in range(3)]
 out=[[sub(times(V[j][b],80),sum_pairs(mul(U[j][a],S3[a][b]) for a in range(3))) for b in range(3)] for j in range(20)]
 L.append(out)
# exact kernel basis J0 - J1 - 4*(sqrt5-1)*D
alpha=(-4,4)
for j in range(20):
 for b in range(3):
  assert sub(sub(L[0][j][b],L[1][j][b]),mul(alpha,L[3][j][b]))==(0,0)
print('exact reduction null relation: J0-J1-4(sqrt5-1)D')
# seek 3x3 minor nonzero for columns J0,J1,J2 from same H.
Lnum=[ [L[q][j][b] for q in range(3)] for j in range(20) for b in range(3)]
for idx in itertools.combinations(range(60),3):
 M=[[Lnum[x][q] for q in range(3)] for x in idx]
 def det3(M):
  m=lambda a,b,c:mul(mul(M[0][a],M[1][b]),M[2][c])
  return sum_pairs([m(0,1,2),m(1,2,0),m(2,0,1),neg(m(0,2,1)),neg(m(1,0,2)),neg(m(2,1,0))])
 d=det3(M)
 if d!=(0,0):
  print('rank3 witness: row coordinates',[(x//3,x%3) for x in idx],'det=',d[0],'+',d[1],'sqrt(5)')
  break
else:raise AssertionError('expected rank3')

# Imaginary-antisymmetric nearest-neighbor triplet currents have exactly
# two independent orbital representatives: edge gradient and face curl.
# The curl is protected by the universal matrix lift. Exhibit nonzero
# gradient leakage for one triplet direction as the rank-one obstruction.
agrad=0
G=[[(sub(U[j][agrad],U[k][agrad]) if A[j][k] else (0,0)) for k in range(20)] for j in range(20)]
V=[[sum_pairs(mul(G[j][k],U[k][b]) for k in range(20)) for b in range(3)] for j in range(20)]
T=[[sum_pairs(mul(U[j][a],V[j][b]) for j in range(20)) for b in range(3)] for a in range(3)]
LG=[[sub(times(V[j][b],80),sum_pairs(mul(U[j][a],T[a][b]) for a in range(3))) for b in range(3)] for j in range(20)]
trip_witness=next(((j,b,LG[j][b]) for j in range(20) for b in range(3) if LG[j][b]!=(0,0)),None)
assert trip_witness
print('gradient triplet nonzero leakage witness',trip_witness)

certificate={
 'name':'Paper00-ProtectedFlavorLift-v1_1',
 'status':'EXACT_FINITE_GEOMETRY; PHYSICAL_OCCURRENCE_UNPROVED',
 'geometry':'Five A5-orbit 2T cores of binary icosahedral group; 20 directed core pairs and 30 dodecahedron nearest-neighbor edges',
 'field':'Z[sqrt(5)] integer pair arithmetic; u=(1/4)U',
 'theorem_neighbor_tight_frame':'sum_{k~j} u_k u_k^T = I_3/2 + u_j u_j^T',
 'exact_tight_frame_tests':checks,
 'theorem_local_lift':'K(H)_{jk}=2A_{jk}u_j^T H u_k -2 delta_jk u_j^T H u_j',
 'theorem_universal_intertwining':'K(H)Q=QH for every H in M3(C), Q_{ja}=u_j^a/sqrt(5)',
 'exact_intertwining_tests':inter_checks,
 'exact_A5_action_tests':len(perms),
 'covariance':'P(g) K(H) P(g)^T = K(R(g) H R(g)^T)',
 'hermitian_and_reducing':'H=H* implies K(H)=K(H)* and [K(H),QQ*]=0',
 'existing_curl_identification':'For lambda_a(b,c)=-i eps(a,b,c), K(lambda_a/2)=-C_a exactly',
 'local_quintet_class':'One vertex-harmonic and three independent undirected-edge-harmonic copies of A5 irrep 5, all real-symmetric and supported at distance <=1',
 'local_quintet_unique_protected_direction':'J0-J1-4(sqrt(5)-1)D=-2K(H), where J0,J1 are Dirichlet weighted by (u_j+u_k)^TH(u_j+u_k) and (u_j-u_k)^TH(u_j-u_k), and D=diag(u_j^T H u_j)',
 'exact_quintet_reduction_null_checks':60,
 'exact_quintet_leakage_rank':3,
 'exact_quintet_rank_witness_rows':[(x//3,x%3) for x in idx],
 'exact_quintet_rank_witness_det':{'integer':int(d[0]),'sqrt5':int(d[1])},
 'imag_skew_triplet_class':'Two independent oriented-edge triplet copies, gradient and curvature. Curvature is protected, gradient leaks.',
 'triplet_gradient_nonzero_leakage_witness':{'vertex':trip_witness[0],'column':trip_witness[1],'integer':trip_witness[2][0],'sqrt5':trip_witness[2][1]},
 'all_source_hamiltonian':'H(Phi)=I2 tensor (3I20-A)+sum_{i,A}Phi_iA S_i tensor K(F_A) with orthonormal su3 flavor generators F_A, tr(F_A F_B)=delta_AB/2',
 'source_first_derivative':'(I2 tensor Q*) dPhi H(Phi) (I2 tensor Q)=S_i tensor F_A; on Sym^3(C2 tensor C3): G_iA',
 'all_source_geometric_schur':'zero exactly because P3 reduces H(Phi) for every Phi',
 'comparison_action_boundary':'This source-linear local action and earlier nonlinear spin-link Dirichlet action agree at first order on triplet directions, but differ in higher contacts and in quintet first jets; actual native QCD occurrence unproved',
 'physical_matching':'Gauss+rest-CAR trial compression equals conventional 2G_iA for selected normalized axial source. Actual physical spectra, poles, vertices, Dirac dressing and continuum widths remain selection/dynamical obligations.',
 'kinematic_baryon_56_source':'H_56(a)=3(3-sqrt(5))I_56+2 sum_(iA) a_iA G_iA on the symmetric three-particle geometric source',
 'reference_56_susceptibility':'At zero source for linear H_56(a), d_a d_b log Tr exp(-t H_56) = (9/14)t^2 delta_ab; inherited Paper7B identity sum G_iA^2=(19/4)P8+(7/2)P10',
 'reference_6_susceptibility':'At zero source with physical normalization 2 S_i tensor F_A: linear source t^2/6 delta_ia,jb; nonlinear spin-link original with B=2a has t^2/6 - t sqrt(5)/12 diagonal triplet Hessian',
 'operator_algebra_quotient':'K(H1)K(H2)Q = Q H1 H2 = K(H1H2)Q; failure of multiplicativity acts only on P3 complement'

}
assert sp.Rational(16)*sp.Rational(19,4)+40*sp.Rational(7,2)==216
assert 216//24==9
assert sp.Rational(4*9,56)==sp.Rational(9,14)
assert sp.simplify((sp.Symbol('t')**2/sp.Integer(6))-(sp.Symbol('t')**2/sp.Integer(6)-sp.Symbol('t')*S/12)-sp.Symbol('t')*S/12)==0
out=DATA/'Paper00-ProtectedFlavorLift-v1_1.json'
out.write_text(json.dumps(certificate,indent=2,ensure_ascii=False)+'\n')
print('wrote',out)
