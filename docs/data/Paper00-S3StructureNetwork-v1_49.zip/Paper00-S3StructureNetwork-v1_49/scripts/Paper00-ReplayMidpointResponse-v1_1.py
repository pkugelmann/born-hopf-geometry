#!/usr/bin/env python3
"""Deterministic pure finite-geometry replay, not a global source E3/E4 audit."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data'/'Paper00-MidpointTripletResponse-v1_1.json'
GRAPH=ROOT/'graph'/'Paper00-MidpointTripletTransitions-v1_1.graphml'
CERT=ROOT/'data'/'Paper00-MidpointReplay-v1_1.json'

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    assert DATA.is_file() and GRAPH.is_file()
    before={str(f):sha(f) for f in [DATA,GRAPH]}
    for f in ['Paper00-MidpointSourceCompiler-v1_1.py','Paper00-MidpointTransitionGraph-v1_1.py']:
        run=subprocess.run([sys.executable,str(ROOT/'scripts'/f)],cwd=ROOT,
                           stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=120)
        print(run.stdout.strip())
        if run.returncode:
            print(run.stderr)
            raise RuntimeError(f+' failed')
    assert all(sha(f)==before[str(f)] for f in [DATA,GRAPH])
    data=json.loads(DATA.read_text())
    assert data['nearest_neighbor_hermitian_A5_triplet_dimensions']['total']==4
    assert len(data['nonzero_geometric_downhill_arrows'])==5
    assert data['exact_second_order_P5_Feshbach_return']['requires_continuum_to_get_irreversible_width']
    out={'status':'PASS','scope':'FINITE A5 DODECAHEDRAL COMPARISON; NO PHYSICAL CLAIM',
         'parent_exact_certificates':['Paper00-DodecahedralHodgeCurrent-v1_1.json','Paper00-FiveCoreOrbitalAlgebra-v1_1.json'],
         'verified':{'Hermitian_triplet_local_dimension':4,'unique_shift_preserving_symmetric_current':True,
          'six_exact_L0_levels':6,'nonzero_intersector_pairs':5,
          'second_order_5_Feshbach_return':True,'conditional_W56_spin_CG_extension':True,
          'physical_decay_width_derived':False,'whole_framework_source_audit_performed':False},
         'sha256':{'data':sha(DATA),'graph':sha(GRAPH)}}
    CERT.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print('PASS midpoint-source replay; exact certificate, graph deterministic')
if __name__=='__main__':main()
