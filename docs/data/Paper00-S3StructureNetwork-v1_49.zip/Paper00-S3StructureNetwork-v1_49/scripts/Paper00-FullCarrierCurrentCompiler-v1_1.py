#!/usr/bin/env python3
"""Constructive, exact finite U(3) compression and minimal-28 SU(3) current tests.

Sources: inherited exact 20-pair coordinates/orbital adjacency (v1_47).
Mathematics: Q(sqrt 5), complex-rational qutrit tomography, integer arithmetic,
rigorous outward rational intervals for spectral norm upper bound,
exact bosonic symmetric-tensor representation and Casimir projectors.

Does NOT claim a physical Born/QCD action selection.
"""
import json, math
from pathlib import Path
import numpy as np
import sympy as sp
root=Path(__file__).resolve().parents[1]
raw=json.loads((root/'data/Paper00-TripletCurrentSpace-v1_1.json').read_text())
orb=json.loads((root/'data/Paper00-FiveCoreOrbitalAlgebra-v1_1.json').read_text())
source=next(x for x in raw['basis_tensors'] if x['orbital_index']==0)['components']
SQ=sp.sqrt(5)
def qpair(z):
 e=sp.expand(4*sp.sympify(z)); a=int(e.coeff(SQ,0));b=int(e.coeff(SQ,1))
 assert e==a+b*SQ
 return a,b
U0=np.array([[qpair(z)[0] for z in row[2:]] for row in source],dtype=np.int64)
U1=np.array([[qpair(z)[1] for z in row[2:]] for row in source],dtype=np.int64)
edges=set(tuple(sorted(x)) for x in orb['basis_sparse_pairs'][7]);assert len(edges)==30
A=np.zeros((20,20),dtype=np.int64)
for i,j in edges:A[i,j]=A[j,i]=1
T=10*A-10*np.eye(20,dtype=np.int64)-np.ones((20,20),dtype=np.int64)
# Nine informationally complete pure states and exact Hilbert-Schmidt dual.
I=sp.eye(3);w=[I[:,i] for i in range(3)]
for a,b in ((0,1),(0,2),(1,2)):
 w.extend([(I[:,a]+I[:,b])/sp.sqrt(2),(I[:,a]+sp.I*I[:,b])/sp.sqrt(2)])
P=[sp.simplify(v*v.conjugate().T) for v in w]
Gram=sp.Matrix(9,9,lambda i,j:sp.trace(P[i]*P[j]));assert Gram.det()!=0
Gi=Gram.inv()
D=[sp.simplify(sum((Gi[i,j]*P[j] for j in range(9)),sp.zeros(3))) for i in range(9)]
assert all(sp.simplify(sp.trace(P[i]*D[j])-int(i==j))==0 for i in range(9) for j in range(9))
D0=[];D1=[]
for d in D:
 real=np.zeros((3,3),dtype=np.int64);imag=np.zeros((3,3),dtype=np.int64)
 for a in range(3):
  for b in range(3):
   x=sp.expand(2*d[a,b]);v=sp.simplify(sp.re(x));z=sp.simplify(sp.im(x))
   assert v.is_Integer and z.is_Integer,(a,b,x)
   real[a,b]=int(v);imag[a,b]=int(z)
 D0.append(real);D1.append(imag)

# B_s=K(D_s)-Q D_s Q* with Q_j=u_j/sqrt5, 160 B_s=M_s in Z[sqrt5,i].
# Exact (S_num=160² sum B_s²) using integer 20x20 matrix arithmetic.
S_components=[np.zeros((20,20),dtype=np.int64) for _ in range(4)]
B_norm2=[]
for k in range(9):
 r=D0[k];z=D1[k]
 x0=U0@r@U0.T+5*U1@r@U1.T
 x1=U0@r@U1.T+U1@r@U0.T
 y0=U0@z@U0.T+5*U1@z@U1.T
 y1=U0@z@U1.T+U1@z@U0.T
 a,b,c,d=[T*q for q in (x0,x1,y0,y1)]
 assert np.array_equal(a,a.T) and np.array_equal(b,b.T)
 assert np.array_equal(c,-c.T) and np.array_equal(d,-d.T)
 terms=[a@a+5*b@b-c@c-5*d@d,
        a@b+b@a-c@d-d@c,
        a@c+c@a+5*(b@d+d@b),
        a@d+d@a+b@c+c@b]
 for tgt,q in zip(S_components,terms):tgt+=q
 tr0,tr1=int(np.trace(terms[0])),int(np.trace(terms[1]))
 assert tr1==0 and tr0%25600==0
 B_norm2.append(tr0//25600)
assert B_norm2==[57,57,57,42,18,42,18,42,18]
assert all(np.array_equal(X,X.T) for X in S_components[:2])
assert all(np.array_equal(X,-X.T) for X in S_components[2:])
# Fully rational bound of sqrt5 and |matrix elements|, not floating-point Gershgorin.
scale=10**15
lo=math.isqrt(5*scale*scale);hi=lo+1
assert lo*lo<5*scale*scale<hi*hi
row_upper=[]
for i in range(20):
 value=0
 for j in range(20):
  a,b,c,d=(int(M[i,j]) for M in S_components)
  re=max(abs(a*scale+b*lo),abs(a*scale+b*hi))
  im=max(abs(c*scale+d*lo),abs(c*scale+d*hi))
  value+=math.isqrt(re*re+im*im)+1
 row_upper.append(value)
rowmax=max(row_upper)
assert rowmax<64*scale*25600
# Hence S=sum B_s² <64R; |B| <= 3 B²/16+4 R/3, so T=sum|B_s|<24R.
N=24
# Independent complex-matrix reconstruction of K(H) (not a proof of dilation by itself).
u=(U0.astype(float)+np.sqrt(5)*U1.astype(float))/4
Q=u/np.sqrt(5);R=np.eye(20)-Q@Q.T
assert np.linalg.norm(Q.T@Q-np.eye(3))<1e-12

def Klift(H):
 return 2*A*(u@H@u.T)-2*np.diag(np.einsum('ia,ab,ib->i',u,H,u))
Bs=[R@Klift(np.array(d.evalf(),dtype=complex))@R for d in D]
checks=[]
Es=[sp.eye(3)[:,i]*sp.eye(3)[j,:] for i in range(3) for j in range(3)]
for Hsym in Es:
 H=np.array(Hsym.tolist(),dtype=complex)
 recon=Q@H@Q.T+sum(np.trace(np.array(P[k].evalf(),dtype=complex)@H)*Bs[k] for k in range(9))
 checks.append(float(np.max(np.abs(Klift(H)-recon))))
assert max(checks)<1e-12

# Exact SU3 tensor currents and minimal harmonic 28 with canonical SO3 Casimir selection.
e=lambda a,b: sp.eye(3)[:,a]*sp.eye(3)[b,:]
rot=[-sp.I*(e(a,b)-e(b,a))/2 for a,b in ((0,1),(0,2),(1,2))]
quad=[(e(a,b)+e(b,a))/2 for a,b in ((0,1),(0,2),(1,2))]
quad.extend([(e(0,0)-e(1,1))/2,(e(0,0)+e(1,1)-2*e(2,2))/(2*sp.sqrt(3))])
F=rot+quad
assert all(sp.simplify(sp.trace(x*y)-sp.Rational(k==l,2))==0 for k,x in enumerate(F) for l,y in enumerate(F))

def boson(n,H):
 occ=[(a,b,n-a-b) for a in range(n+1) for b in range(n+1-a)]; idx={x:i for i,x in enumerate(occ)}
 Z=sp.zeros(len(occ))
 for j,v in enumerate(occ):
  for a in range(3):
   for b in range(3):
    if v[b]==0:continue
    w=list(v);w[b]-=1;w[a]+=1
    c=v[b] if a==b else sp.sqrt((v[a]+1)*v[b])
    Z[idx[tuple(w)],j]+=H[a,b]*c
 return Z
harmonic28={}
for n in (1,3,4):
 generators=[boson(n,x) for x in F]; dim=generators[0].rows
 C=sum((g*g for g in generators[:3]),sp.zeros(dim))
 Cas=sum((g*g for g in generators),sp.zeros(dim))
 assert Cas==sp.Rational(n*(n+3),3)*sp.eye(dim)
 if n==1:P20=sp.eye(dim)
 elif n==3:P20=sp.Rational(2,5)*(C-sp.Rational(1,2)*sp.eye(dim))
 else:P20=sp.eye(dim)-sp.Rational(4,21)*C*(5*sp.eye(dim)-C)
 assert P20*P20==P20 and all(P20*g==g*P20 for g in generators[:3])
 Pextra=sp.eye(dim)-P20
 leak=[sp.simplify(sp.trace(P20*g*Pextra*g*P20)) for g in generators]
 if n>1:
  assert len(set(leak[:3]))==1 and leak[0]==0
  assert len(set(leak[3:]))==1
 harmonic28[str(n)]={'representation_dimension':dim,'selected_rank':int(sp.trace(P20)),
 'auxiliary_rank':int(sp.trace(Pextra)),
 'so3_Casimir_eigenvalues':{str(x):int(y) for x,y in C.eigenvals().items()},
 'SU3_Casimir':str(sp.Rational(n*(n+3),3)),
 'triplet_leak_per_generator':str(leak[0]),
 'quintet_leak_per_generator':str(leak[3]),
 'five_quintet_total':str(sum(leak[3:]))}
assert harmonic28['3']['quintet_leak_per_generator']=='42/25'
assert harmonic28['4']['quintet_leak_per_generator']=='104/21'
assert sum(sp.Rational(harmonic28[str(n)]['representation_dimension']) for n in (1,3,4))==28
assert sum(int(harmonic28[str(n)]['selected_rank']) for n in (1,3,4))==20
assert sum(int(harmonic28[str(n)]['auxiliary_rank']) for n in (1,3,4))==8

certificate={
 'id':'Paper00-FullCarrierCurrent-v1_1',
 'parent':'Paper00-S3StructureNetwork-v1_47',
 'status':'EXACT_FINITE_REPRESENTATION_AND_COMPRESSION_CONSTRUCTION; NO_BH_PHYSICAL_ACTION_SELECTION',
 'one_hop_input':'K(H)_jk=2 A_jk u_j^T H u_k -2 delta_jk u_j^T H u_j',
 'protected_corner':'K(H)Q=QH, Q^*Q=I3, R=I20-QQ^*',
 'tomography_pure_states':'3 standard e_i plus (e_a+e_b)/sqrt2 and (e_a+i e_b)/sqrt2 for a<b',
 'tomography_Gram_determinant':str(Gram.det()),
 'dual_consistency_81_exact':True,
 'complementary_B_squared_HS':[int(x) for x in B_norm2],
 'sum_complementary_B_squared_HS':sum(B_norm2),
 'sqrt5_interval':{'floor':lo,'ceil':hi,'denominator':scale},
 'S=sum_B_squared_entrywise_Gershgorin_upper_exact':str(rowmax)+'/'+str(scale*25600),
 'Gershgorin_strictly_below_64':True,
 'operator_bound':'sum|B_s| <= (3/16) sum B_s^2 +12R <24R',
 'tensor_degree_sufficient':N,
 'tensor_irrep_dim':(N+1)*(N+2)//2,
 'number_of_positive_negative_tomography_blocks':18,
 'auxiliary_multiplicity':17,
 'dilated_carrier_dimension':3+17+18*17*((N+1)*(N+2)//2),
 'explicit_isometry':'Q^* on protected3; on R: n^-1/2 w_s^n tensor (B_s^+)^1/2 and bar(w_s)^n tensor (B_s^-)^1/2; plus (I17-T/n)^1/2 sink',
 'identity':'J* d-rho(H) J = K(H) for ALL Hermitian 3x3 H, and d-rho is exact U3 Lie algebra',
 'nine_matrix_unit_reconstruction_max_numeric_error':max(checks),
 'minimal_28_symmetric_tensor_decomposition':'Sym^1 V + Sym^3 V + Sym^4 V',
 'minimal_28_harmonic_projectors':'P3=(2/5)(C-1/2 I) on Sym3; P4=I-(4/21)C(5I-C) on Sym4; C=sum_{a=1}^3 d-rho(F_a)^2',
 'minimal_28_exact_tests':harmonic28,
 'minimal_28_total_quintet_leak_squared':str(5*(sp.Rational(42,25)+sp.Rational(104,21))),
 'minimal_28_per_rotation_compression_HS_squared':'45/2',
 'unchanged_onehop_per_rotation_HS_squared':'5',
 'minimal_28_status':'A5-equivariant representation completion only, with changed nonlocal off-corner 20 current; unlike universal dilation it does not compress the original K',
 'physical_status':'native Paper VII-A same-action, Gauss-realization, physical source jets, pole residues, and decay widths NOT ESTABLISHED',
 'equivariance_caveat':'99,470-dimensional tomography isometry is not shown to intertwine original A5 module with SU3 restriction; its compressed K is still A5-covariant. Minimal 28 harmonic embedding is A5-equivariant.'
}
(root/'data/Paper00-FullCarrierCurrent-v1_1.json').write_text(json.dumps(certificate,indent=2)+'\n')
print('EXACT: nine Hermitian qutrit duals; complement norms',B_norm2)
print('EXACT RATIONAL INTERVAL bound max row',certificate['S=sum_B_squared_entrywise_Gershgorin_upper_exact'])
print('FINISHED finite U3 dilation n24 ambient dimension',certificate['dilated_carrier_dimension'])
print('EXACT 28 leakage Gram',certificate['minimal_28_total_quintet_leak_squared'])
