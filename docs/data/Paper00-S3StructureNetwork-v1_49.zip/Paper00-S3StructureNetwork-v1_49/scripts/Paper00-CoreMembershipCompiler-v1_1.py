#!/usr/bin/env python3
"""Finite, exact 2I/2T/600-cell downstream geometry certificate.

Input is the already supplied exceptional_600cell_instance.json, *not* particle data.
No physical-action or decay selection is inferred. All graph edges are independently
reconstructed from exact Q(sqrt(5)) quaternion coordinates before use.
"""
import collections
import hashlib
import itertools
import json
import pathlib
import sys
from typing import Dict, List, Tuple

import sympy as sp

ROOT = pathlib.Path(__file__).resolve().parents[1]
SOURCE = ROOT / "data" / "exceptional_600cell_instance.json"
OUT = ROOT / "data" / "Paper00-CoreMembershipQuotient-v1_1.json"


def pair_mul(x, y):
    return (x[0]*y[0]+5*x[1]*y[1], x[0]*y[1]+x[1]*y[0])


def add(x, y):
    return (x[0]+y[0], x[1]+y[1])


def neg(x):
    return (-x[0], -x[1])


def quaternion_mul(x, y):
    # Coordinates (a+b sqrt(5))/4: numerator arithmetic divided by four.
    z0=add(add(pair_mul(x[0],y[0]),neg(pair_mul(x[1],y[1]))),add(neg(pair_mul(x[2],y[2])),neg(pair_mul(x[3],y[3]))))
    z1=add(add(pair_mul(x[0],y[1]),pair_mul(x[1],y[0])),add(pair_mul(x[2],y[3]),neg(pair_mul(x[3],y[2]))))
    z2=add(add(pair_mul(x[0],y[2]),pair_mul(x[2],y[0])),add(pair_mul(x[3],y[1]),neg(pair_mul(x[1],y[3]))))
    z3=add(add(pair_mul(x[0],y[3]),pair_mul(x[3],y[0])),add(pair_mul(x[1],y[2]),neg(pair_mul(x[2],y[1]))))
    numerator=(z0,z1,z2,z3)
    assert all(c % 4==0 for t in numerator for c in t), 'non-integral 2I product'
    return tuple((t[0]//4,t[1]//4) for t in numerator)


def quat_dot_num(x,y):
    return (sum(x[i][0]*y[i][0]+5*x[i][1]*y[i][1] for i in range(4)),
            sum(x[i][0]*y[i][1]+x[i][1]*y[i][0] for i in range(4)))


def inner(char1,char2,sizes):
    return sp.simplify(sum(s*sp.conjugate(x)*y for s,x,y in zip(sizes,char1,char2))/60)


def main():
    raw = SOURCE.read_bytes()
    data=json.loads(raw)
    vertices=data['vertices']
    assert [v['id'] for v in vertices]==list(range(120))
    q=[tuple(tuple(map(int,c)) for c in v['qcoords']) for v in vertices]
    lookup={v:i for i,v in enumerate(q)}
    assert len(lookup)==120
    assert all(quat_dot_num(v,v)==(16,0) for v in q)
    # independent nearest-neighbor reconstruction in exact Q(sqrt(5))
    rebuilt={(u,v) for u in range(120) for v in range(u+1,120)
             if quat_dot_num(q[u],q[v])==(4,4)}
    given={tuple(sorted((e['u'],e['v']))) for e in data['nearest_edges']}
    assert len(rebuilt)==len(given)==720 and rebuilt==given
    neighbors=[set() for _ in range(120)]
    for u,v in rebuilt:
        neighbors[u].add(v);neighbors[v].add(u)
    assert all(len(nei)==12 for nei in neighbors)
    # Exact quaternion group product, identity, inverses and Cayley structure.
    mul=[[None]*120 for _ in range(120)]
    for i in range(120):
        for j in range(120):
            result=quaternion_mul(q[i],q[j]); assert result in lookup
            mul[i][j]=lookup[result]
    unit=lookup[((4,0),(0,0),(0,0),(0,0))]
    minus_unit=lookup[((-4,0),(0,0),(0,0),(0,0))]
    assert all(mul[unit][i]==i==mul[i][unit] for i in range(120))
    assert all(mul[minus_unit][i]==mul[i][minus_unit] for i in range(120))
    inverses={i:lookup[(q[i][0],*tuple(neg(c) for c in q[i][1:]))] for i in range(120)}
    assert all(mul[i][inverses[i]]==unit==mul[inverses[i]][i] for i in range(120))
    S=neighbors[unit]
    assert len(S)==12 and {inverses[s] for s in S}==S
    assert all((j in neighbors[i]) == (mul[inverses[i]][j] in S)
               for i in range(120) for j in range(120)), 'not a 12-Cayley graph'
    # Verify five 2T groups, pair intersections C6, triple intersections central Z2.
    H=[set(h) for h in data['conjugate_core_groups']]
    assert len(H)==5 and all(len(h)==24 and unit in h for h in H)
    assert all(mul[i][j] in h for h in H for i in h for j in h)
    central=set.intersection(*H)
    assert central=={unit,minus_unit}
    assert all(len(set.intersection(*(H[j] for j in ids))) == (6 if len(ids)==2 else 2)
               for r in (2,3,4,5) for ids in itertools.combinations(range(5),r))
    all_conjugates={frozenset(mul[mul[g][h]][inverses[g]] for h in H[0]) for g in range(120)}
    assert all_conjugates=={frozenset(h) for h in H}
    memberships=[tuple(j for j,h in enumerate(H) if i in h) for i in range(120)]
    frequency=collections.Counter(map(len,memberships))
    assert dict(frequency)=={0:48,1:30,2:40,5:2}
    # The H-free 48 split as 24 near and 24 far, giving a new exact
    # noncoset 5-class equitable partition.
    names=['central','near_exterior','far_exterior','single_core','double_core']
    def cl(i):
        m=len(memberships[i])
        if m==5:return 0
        if m==0:return 1 if neighbors[i]&central else 2
        if m==1:return 3
        if m==2:return 4
        raise AssertionError('unexpected membership')
    classes=list(map(cl,range(120)))
    classes_vertices=[[i for i,c in enumerate(classes) if c==j] for j in range(5)]
    n=[len(v) for v in classes_vertices]
    assert n==[2,24,24,30,40]
    quotient=[]
    for group in classes_vertices:
        rows=[tuple(len(neighbors[v].intersection(w)) for w in classes_vertices) for v in group]
        assert len(set(rows))==1, 'five-class partition is not equitable'
        quotient.append(list(rows[0]))
    B=sp.Matrix(quotient)
    expected=[[0,12,0,0,0],[1,5,1,0,5],[0,1,1,5,5],
              [0,0,4,4,4],[0,3,3,3,3]]
    assert quotient==expected and all(sum(row)==12 for row in quotient)
    N=sp.diag(*n)
    W=N*B
    assert W==W.T
    # Distinguish the old five 24-vertex H0 cosets from the *new* five
    # unequal-size membership/adjacency cells (rank-one overlap only).
    unassigned=set(range(120));cosets=[]
    while unassigned:
        g=min(unassigned)
        coset={mul[g][h] for h in H[0]}
        assert len(coset)==24 and coset<=unassigned
        cosets.append(coset);unassigned-=coset
    assert len(cosets)==5
    cosB=[]
    for coset in cosets:
        all_rows={tuple(len(neighbors[v]&cell) for cell in cosets) for v in coset}
        assert len(all_rows)==1
        cosB.append(list(next(iter(all_rows))))
    assert all(cosB[i][j]==(0 if i==j else 3) for i in range(5) for j in range(5))
    # Characterize 5D invariant subspace and exact adjacency spectrum.
    x=sp.Symbol('x')
    cp=sp.factor(B.charpoly(x).as_expr())
    assert cp==x*(x-12)*(x+3)*(x*x-4*x-16)
    L=N*(12*sp.eye(5)-B)
    assert L==L.T and L*sp.ones(5,1)==sp.zeros(5,1)
    R=sp.zeros(5)
    invred=L[:4,:4].inv()
    for i in range(5):
        for j in range(i+1,5):
            delta=sp.zeros(5,1);delta[i]=1;delta[j]=-1
            volt=invred*delta[:4,:]
            R[i,j]=R[j,i]=sp.simplify((delta[:4,:].T*volt)[0])
    # Check projector preservation exactly, using integer 120P.
    for i in range(120):
        for j in range(120):
            # entry of 120*A*P vs 120*P*A
            left=sum(120//n[classes[j]] for k in neighbors[i] if classes[k]==classes[j])
            right=sum(120//n[classes[i]] for k in neighbors[j] if classes[k]==classes[i])
            assert left==right
    T=sp.zeros(120,10)
    for i in range(120):
        T[i,classes[i]]=1
        T[i,5+next(k for k,cell in enumerate(cosets) if i in cell)]=1
    combined_rank=T.rank()
    assert combined_rank==9, 'only constants shared by two 5D invariant partitions'
    # The A5 ordered pair representation and its exhaustive commutant.
    phi=(1+sp.sqrt(5))/2
    phibar=(1-sp.sqrt(5))/2
    sizes=[1,15,20,12,12]
    ch={'1':[1,1,1,1,1], '3':[3,-1,0,phi,phibar],
        '3prime':[3,-1,0,phibar,phi], '4':[4,0,1,-1,-1],
        '5':[5,1,-1,0,0]}
    pair=[20,0,2,0,0]
    sympair=[10,2,1,0,0]
    oddpair=[10,-2,1,0,0]
    def decompose(character):
        return {name:int(inner(char,character,sizes)) for name,char in ch.items()}
    mulchi=lambda u,v:[a*b for a,b in zip(u,v)]
    addchi=lambda *args:[sum(t) for t in zip(*args)]
    d_pair=decompose(pair)
    d_even=decompose(sympair)
    d_odd=decompose(oddpair)
    assert d_pair=={'1':1,'3':1,'3prime':1,'4':2,'5':1}
    assert d_even=={'1':1,'3':0,'3prime':0,'4':1,'5':1}
    assert d_odd=={'1':0,'3':1,'3prime':1,'4':1,'5':0}
    chi8=addchi(ch['3'],ch['5'])
    chi10=addchi(ch['3'],ch['3prime'],ch['4'])
    hom_10_8x8=inner(chi10,mulchi(chi8,chi8),sizes)
    hom_10_8x3=inner(chi10,mulchi(chi8,ch['3']),sizes)
    assert hom_10_8x8==11 and hom_10_8x3==4
    commutant_dimension=sum(m*m for m in d_pair.values())
    assert commutant_dimension==8
    d_2I=[1,2,2,3,3,4,4,5,6]
    assert sum(d*d for d in d_2I)==120
    # Exact subgroup and class membership certificate.
    output={
       'name':'Paper00-CoreMembershipQuotient-v1_1',
       'scope':'exact finite mathematical geometry on supplied marked 2I/600-cell; physical occurrence NOT asserted',
       'source_file':'data/exceptional_600cell_instance.json',
       'source_sha256':hashlib.sha256(raw).hexdigest(),
       'cross_checks':{
          'exact_coordinates_valid':True,
          'nearest_edges_rebuilt_exactly':True,
          'quaternion_products_rebuilt_exactly':True,
          'Cayley_12_generator_rule_checked_all_pairs':True,
          'five_order24_subgroups_closed':True,
          'all_2T_conjugates_exhausted':True,
          'five_cell_equitable_all_120_rows':True,
          'indicator_projector_commutes_with_adjacency':True,
          'coset_indicator_overlap_rank':combined_rank,
          'A5_characters_recomputed_exactly':True},
       'group':{'order_2I':120,'order_2T':24,'common_center':[int(x) for x in sorted(central)],
                'two_core_intersection':6,'all_three_or_more_core_intersection':2,
                'membership_frequencies':{str(k):v for k,v in sorted(frequency.items())},
                'cayley_generator_ids':sorted(S),'vertices':120,'edges':720},
       'coset_quotient':{'cell_sizes':[24]*5,'adjacency_5x5':cosB,'eigenvalue_multiplicities':{'12':1,'-3':4}},
       'membership_quotient':{
          'class_names':names,'class_sizes':n,'class_vertices':classes_vertices,
          'adjacency_B':quotient,'edge_count_matrix_NB':[[int(W[i,j]) for j in range(5)] for i in range(5)],
          'charpoly':str(cp),'eigenvalues':['12','-3','0','2+2*sqrt(5)','2-2*sqrt(5)'],
          'weighted_laplacian_N(12I-B)':[[int(L[i,j]) for j in range(5)] for i in range(5)],
          'shorted_class_effective_resistance':[[str(R[i,j]) for j in range(5)] for i in range(5)],
          'spectral_gap_12I_minus_B':'10-2*sqrt(5)',
          'equitable_partition_projector_rank':5,
          'commutes_with_full_120x120_adjacency':True,
          'geometric_heat_markov_kernel':'B/12',
          'class_stationary_weights':['2/120','24/120','24/120','30/120','40/120'],
          'cross_class_edges':sum(int(W[i,j]) for i in range(5) for j in range(i+1,5)),
          'within_class_edges':sum(int(W[i,i])//2 for i in range(5))},
       'operator_algebras':{
         'full_regular_2I_equivariant_endomorphism_dimension_complex':120,
         'regular_irrep_dimensions':d_2I,
         'A5_directed20_pair_irreducible_multiplicities':d_pair,
         'A5_directed20_pair_commutant_dimension_complex':commutant_dimension,
         'A5_even10_pair_decomposition':d_even,
         'A5_odd10_pair_decomposition':d_odd,
         'A5_Hom_10_to_8_tensor_8':int(hom_10_8x8),
         'A5_Hom_10_to_8_tensor_3':int(hom_10_8x3)},
       'status':{'reproducible_exact_integer_and_symbolic_identity':'PASS',
          'geometric_comparison_action':'explicit unit-edge magnetic Laplacian available mathematically',
          'action_owned_physical_current':'OPEN','baryon_partial_widths':'OPEN',
          'global_E3_E4_reauditing':'NOT_PERFORMED'}
    }
    OUT.write_text(json.dumps(output,indent=2,sort_keys=True)+'\n')
    print('PASS exact 2I group/Cayley graph/five cores/quotients/commutants')
    print('sizes',n,'B=',quotient,'spec=',output['membership_quotient']['eigenvalues'])
    print('resistance',output['membership_quotient']['shorted_class_effective_resistance'])
    print('A5 invariant pair commutant',commutant_dimension,'Hom dims',hom_10_8x8,hom_10_8x3)
    print('output:',OUT)

if __name__=='__main__':
    main()
