# Paper00 — Downstream geometry completion: explicit full-carrier flavor-current realizations (v1_7)

**Born–Hopf Geometry | 20 November 2026**  
**Supersedes:** `Paper00-DownstreamGeometryClosure-v1_6.md` in the structure-network release (historical research report remains unmodified outside the release).  
**Input corpus:** `Paper00-S3StructureNetwork-v1_47.zip` (exact 20-state coordinates/orbitals/nearest-neighbor current); `Paper00-PapersMinimal-v3_074(1).zip` (current Paper VII-A `Paper7A-QCDKernel-v1_183.tex`, Paper VII-B `Paper7B-QCDReadouts-v1_167.tex`).  
**Evidence:** independent algebraic proof and exact deterministic compiler `scripts/Paper00-FullCarrierCurrentCompiler-v1_1.py`, certificate `data/Paper00-FullCarrierCurrent-v1_1.json`.  
**Status:** exact existence/construction and representation-compression theorems; *neither a physical Born/QCD current selection nor a physical decay theorem.*

## Executive result

The obstruction identified in `v1_6` is **not a global geometric no-go**. Two mathematically distinct solutions exist.

**Solution A (exact one-hop current, larger carrier):** There is an explicit isometry \(\mathcal J:\mathbb C^{20}\to\mathcal V_{99470}\) and a genuine unitary \(U(3)\) representation on the finite carrier \(\mathcal V_{99470}\), whose infinitesimal Hermitian generators \(\widehat Q(H)\) compress **exactly** to the original nearest-neighbor geometric operators \(\mathscr K(H)\) for every Hermitian \(3\times3\) matrix \(H\). The canonical three-dimensional flavor sector is invariant under the entire enlarged \(U(3)\). A certified sufficient tensor degree is **24**. This is an **existence witness**, not a minimality result and not an \(A_5\)-equivariant embedding certificate.

**Solution B (minimal, \(A_5\)-equivariant 28-dimensional completion):** The inherited canonical \(\operatorname{Sym}^1(V)\oplus\operatorname{Sym}^3(V)\oplus\operatorname{Sym}^4(V)\) carries an exact \(SU(3)\) action and an \(A_5\)-equivariant copy of the 20 graph states. Its compressed current **must differ from** \(\mathscr K\) on the 17 off-flavor states. Its correction is fixed by symmetric-tensor representation theory. We compute **all 8-auxiliary leakage norms** exactly, showing the \(A_5\)-quintet currents—not the triplet rotations—mediate the missing Ward blocks.

Both realize the fundamental flavor-3 exactly. They solve different geometric requirements and **must not be conflated**. Actual Born/QCD action realization, Gauss-compatible physical embedding, pole residues, retarded daughter channels and lifetimes remain separate explicit tests.

## 1. Input data and exact protected split

The original 20 dodecahedral vectors \(u_j\in\tfrac14\mathbb Z[\sqrt5]^3\) and 30-edge adjacency \(A\) define

\[
\boxed{\mathscr K(H)_{jk}=2A_{jk}u_j^{\mathsf T}Hu_k-2\delta_{jk}u_j^{\mathsf T}Hu_j.}\tag{1.1}
\]

Let \(Q_{ja}=u_j^a/\sqrt5\), \(P=QQ^\dagger\), \(R=I_{20}-P\). The inherited neighboring-frame identity proves \(\mathscr K(H)Q=QH\) for **every complex** matrix \(H\), and \(\mathscr K(H)^\dagger=\mathscr K(H^\dagger)\). Hence

\[
\boxed{\mathscr K(H)=QHQ^\dagger+B(H),\qquad B(H)=R\mathscr K(H)R.}\tag{1.2}
\]

The flavor-three is already an invariant, reducing fundamental, while \(B(H)\) acts on the \(17\)-dimensional orthogonal complement. The previous defect \([\mathscr K(E_{12}),\mathscr K(E_{21})]-\mathscr K(E_{11}-E_{22})\) has rank 17, kernel precisely \(\operatorname{Ran}Q\), and HS norm squared 124. Such a defect is compatible with a compression of genuine Lie generators, because the omitted off-block charge products reconstruct it.

## 2. Nine-state informational completeness over the geometric flavor-three

For the standard basis \(e_1,e_2,e_3\) of the already derived \(V=\mathbb C^3\), choose the nine unit vectors

\[
\boxed{
\mathcal W=\{e_1,e_2,e_3\}\cup
\left\{(e_a+e_b)/\sqrt2,\ (e_a+i e_b)/\sqrt2:1\le a<b\le3\right\}.}\tag{2.1}
\]

Set \(P_s=w_sw_s^\dagger\). The \(9\times9\) real Gram \(G_{st}=\operatorname{tr}(P_sP_t)\) is invertible. Define the **exact dual**, with no external constants, by

\[
D_s=\sum_t(G^{-1})_{st}P_t,\quad
\operatorname{tr}(P_sD_t)=\delta_{st},\quad
H=\sum_s\operatorname{tr}(P_sH)D_s\quad(H=H^\dagger).\tag{2.2}
\]

The compiler verifies all 81 duality entries. All \(D_s\) are Hermitian with rational Gaussian entries. Define \(B_s=B(D_s)\) on the 17-dimensional reducing space. Consequently

\[
\boxed{B(H)=\sum_{s=1}^9\alpha_s(H)B_s,\qquad\alpha_s(H)=w_s^\dagger H w_s\in\mathbb R.}\tag{2.3}
\]

The exact squared HS norms, obtained by enumerating the 20 native coordinates and 30 native edges, are

\[
\boxed{(\operatorname{tr}B_s^2)_{s=1}^9=(57,57,57,42,18,42,18,42,18),\quad\sum_s\operatorname{tr}B_s^2=351.}\tag{2.4}
\]

No numerical rank approximation or fitted matrix elements are involved.

## 3. Explicit 99,470-dimensional unitary-representation dilation

Write spectral Jordan parts \(B_s=B_s^+-B_s^-\), with \(B_s^\pm=(|B_s|\pm B_s)/2\succeq0\), and \(T=\sum_s|B_s|\). For any integer \(n\) such that \(T\preceq nI_{17}\), define

\[
\mathcal V_n=
V\oplus\left[\bigoplus_{s=1}^9
  \Big((\operatorname{Sym}^nV\otimes\mathbb C^{17})
    \oplus(\operatorname{Sym}^n\bar V\otimes\mathbb C^{17})\Big)\right]
\oplus\mathbb C^{17}_{\rm singlet}.\tag{3.1}
\]

The unitary group \(U(3)\) acts as the fundamental on \(V\), as \(\operatorname{Sym}^nV\) and its conjugate on the paired auxiliary blocks, and trivially on the final singlet sink and all \(17\)-dimensional multiplicity spaces. Call its Hermitian infinitesimal generator \(\widehat Q_n(H)\) for \(H=H^\dagger\). It is a true Lie-algebra representation (with the usual factor of \(i\) for Hermitian commutators).

On the complementary 17-space define \(\mathcal J_\perp\) by its direct-sum components

\[
\boxed{\begin{aligned}
(\mathcal J_\perp x)_{s,+}
  &=n^{-1/2}w_s^{\otimes n}\otimes (B_s^+)^{1/2}x,\\
(\mathcal J_\perp x)_{s,-}
  &=n^{-1/2}\bar w_s^{\otimes n}\otimes (B_s^-)^{1/2}x,\\
(\mathcal J_\perp x)_{\rm singlet}
  &=(I_{17}-T/n)^{1/2}x.
\end{aligned}}\tag{3.2}
\]

Join this with the protected fundamental block via \(\mathcal Jx=(Q^\dagger x)\oplus\mathcal J_\perp(Rx)\), identifying \(Rx\) with the 17-space using any orthonormal chart.

**Theorem (exact compression).** If \(T\preceq nI\), then

\[
\boxed{\mathcal J^\dagger\mathcal J=I_{20},\qquad
\mathcal J^\dagger\widehat Q_n(H)\mathcal J=\mathscr K(H)\quad
\forall H=H^\dagger\in M_3(\mathbb C).}\tag{3.3}
\]

*Proof.* The squared norm of the paired components in (3.2) is \(n^{-1}\sum_s(B_s^++B_s^-)=T/n\), which the singlet component completes to \(I\). On a symmetric-tensor coherent vector, the \(n\)-fold generator has expectation
\(\langle w_s^{\otimes n},d\rho_n(H)w_s^{\otimes n}\rangle=n\alpha_s(H)\). Its conjugate counterpart has expectation \(-n\alpha_s(H)\). The two auxiliary compressions therefore sum to
\(\sum_s\alpha_s(H)(B_s^+-B_s^-)=B(H)\) by (2.3). The protected fundamental contributes \(QHQ^\dagger\). The singlet contributes zero. This proves both identities. \(\square\)

The full current commutator algebra now closes on \(\mathcal V_n\) *by its tensor representation*. The 20-state defect is carried by complementary products:

\[
\boxed{[\mathscr K(H_1),\mathscr K(H_2)]-\mathscr K([H_1,H_2])
=-\mathcal J^\dagger\widehat Q(H_1)(I-\mathcal J\mathcal J^\dagger)\widehat Q(H_2)\mathcal J
+\mathcal J^\dagger\widehat Q(H_2)(I-\mathcal J\mathcal J^\dagger)\widehat Q(H_1)\mathcal J.}\tag{3.4}
\]

Here the extension of the Hermitian generator map to arbitrary complex matrices is complex-linear, so (3.4) has the usual complex Lie bracket. In particular, there is no attempt to force the original nonzero defect to vanish on all 20 states.

## 4. Exact finite degree bound: n = 24

Let \(S=\sum_s B_s^2\succeq0\), which is supported on the complementary \(17\). In the fixed exact vertex basis, the compiler works entirely in \(\mathbb Z[\sqrt5,i]\) after clearing the factor \(160\) in each \(B_s\). It evaluates \(160^2S\) as four integer \(20\times20\) matrices and bounds every element absolute value by rational intervals obtained from
\[
\frac{2236067977499789}{10^{15}}<\sqrt5<\frac{2236067977499790}{10^{15}}.
\]

The **largest strictly outward-rounded absolute row sum** of \(S\) is bounded by the exact rational

\[
\boxed{\|S\|_\infty
\le\frac{1613056417009543376191}{25600000000000000000}
<64.}\tag{4.1}
\]

Since \(S\) is Hermitian, its operator norm is at most the row-sum bound. On the complementary space \(S\prec64 I\). The scalar square identity \((|x|-8/3)^2\ge0\), transferred by spectral functional calculus, gives

\[
|B_s|\preceq\frac3{16}B_s^2+\frac43I_{17}.
\]

Summing nine terms,
\[
\boxed{T=\sum_s|B_s|\preceq\frac3{16}S+12I_{17}\prec24I_{17}.}\tag{4.2}
\]

Thus **\(n=24\) is rigorously sufficient**. The underlying symmetric tensor has dimension \(\binom{24+2}{2}=325\), so the finite ambient dimension is

\[
\boxed{\dim\mathcal V_{24}=3+18\cdot325\cdot17+17=99\,470.}\tag{4.3}
\]

The proof does **not** say this degree or dimension is minimal; it is one explicit finite certificate. The nine tomography directions are a deterministic algebraic convenience, not a unique selection by the dodecahedron. The global \(U(3)\) charge compression is exact; an **\(A_5\)-equivariant intertwiner \(\mathcal J\)** identifying the auxiliary carrier's restricted action with the original geometric \(A_5\) permutation module has **not** been established for this choice of tomography embedding. The compressed \(\mathscr K\) itself retains its inherited \(A_5\) covariance. These are different statements.

## 5. The small canonical alternative: exact 28-state SU(3) currents with modified off-carrier matrix elements

For minimal representation completion, use the inherited exact \(A_5\)-equivariant 20-to-28 harmonic isometry \(\mathcal W\), and the full generators

\[
\boxed{\mathcal V_{28}=\operatorname{Sym}^1V\oplus\operatorname{Sym}^3V\oplus\operatorname{Sym}^4V,\quad
\widehat Q_{28}(H)=d\rho_1(H)\oplus d\rho_3(H)\oplus d\rho_4(H).}\tag{5.1}
\]

These obey the \(SU(3)\) algebra exactly and are generated by the ordinary bosonic occupation-basis rule

\[
d\rho_n(H)=\sum_{a,b=1}^3H_{ab}a_a^\dagger a_b,
\quad\sum_an_a=n.
\tag{5.2}
\]

Let the three normalized geometric rotation generators be \(F_a=-i(E_{bc}-E_{cb})/2\) (cyclic pairs), and put \(\mathcal C_n=\sum_{a=1}^3d\rho_n(F_a)^2\). The **selected 20-state harmonic projector** on \(\mathcal V_{28}\) is the direct sum of

\[
\boxed{P_1=I_3,\quad
P_3=\frac25\Big(\mathcal C_3-\frac12 I_{10}\Big),\quad
P_4=I_{15}-\frac4{21}\mathcal C_4(5I_{15}-\mathcal C_4).}\tag{5.3}
\]

They project respectively onto \(\mathcal H_1\), \(\mathcal H_3\), and \(\mathcal H_0\oplus\mathcal H_4\), giving \(3+7+10=20\). The complementary 8 are \(\mathcal H_1\) inside \(\operatorname{Sym}^3V\) and \(\mathcal H_2\) inside \(\operatorname{Sym}^4V\). This selected subspace carries precisely the original \(A_5\) module after the inherited harmonic evaluation/polar isometry.

Define the **corrected**, generally nonlocal graph current

\[
\boxed{\widetilde{\mathscr K}_{28}(H)=\mathcal W^\dagger P_{20}\widehat Q_{28}(H)P_{20}\mathcal W.}\tag{5.4}
\]

It is \(A_5\)-covariant; on the protected fundamental flavor-three it equals \(H\), exactly as the old one-hop lift. But it cannot agree with the old \(\mathscr K\) on all 20 vertices. For each normalized rotation generator,

\[
\boxed{\|\widetilde{\mathscr K}_{28}(F_a)\|_{HS}^2
=\underbrace{\tfrac12}_{\ell=1}
+\underbrace7_{\ell=3}
+\underbrace{15}_{\ell=4}
=\frac{45}{2}\ne5=\|\mathscr K(F_a)\|_{HS}^2.}\tag{5.5}
\]

The additional off-corner normalization is **fixed by representation theory**, not independently fitted. The earlier minimal-28 no-go is exactly reproduced and respected.

### Exact leakage into the eight modes

The algebra \(\operatorname{Herm}_0(V)=\mathbf3\oplus\mathbf5\) under \(SO(3)\) has two qualitatively different current types. The \(\mathbf3\) rotations commute with the projector (5.3), so they never leak into the auxiliary eight:

\[
\boxed{(I-P_{20})\widehat Q_{28}(F_a)P_{20}=0\quad(a\in\mathbf3).}\tag{5.6}
\]

The quintet generators (the three real symmetric off-diagonals and two normalized real traceless diagonals) have the following **exact individual** squared off-block strengths:

| Source representation block | Auxiliary angular harmonics | Per normalized quintet generator \(\|Q_8\widehat Q_{28}(F_A)P_{20}\|_{HS}^2\) |
|---|---|---:|
| \(\operatorname{Sym}^1V\) | none | 0 |
| \(\operatorname{Sym}^3V\) | \(\ell=1\), 3 dimensions | \(42/25\) |
| \(\operatorname{Sym}^4V\) | \(\ell=2\), 5 dimensions | \(104/21\) |

Therefore each of the five normalized quintet generators has total leakage \(3482/525\) and the complete quintet source has

\[
\boxed{\sum_{A\in\mathbf5}\|(I-P_{20})\widehat Q_{28}(F_A)P_{20}\|_{HS}^2
=\frac{3482}{105}.}\tag{5.7}
\]

These rational numbers were computed by direct **exact** symmetric-boson matrices (sizes 3, 10, 15), the exact polynomial Casimir projectors (5.3), and exact traces—no threshold-based spectral projector. They give a complete first-order Ward-leakage strength for this *specific* minimal representation choice. They are not physical decay strengths or continuum widths.

## 6. Explicit, source-linear comparison action and exact Ward identity

On either enlarged carrier choose a self-adjoint source-free geometric operator \(H_0\) and **one** source-dependent action

\[
\boxed{H_{\rm geom}[v]=H_0+\sum_{A=1}^8v_A\widehat Q(F_A),\qquad
\partial_{v_A}H_{\rm geom}[0]=\widehat Q(F_A).}\tag{6.1}
\]

For the 28 completion a wholly geometric reference \(H_0\) is available: transfer the original graph Laplacian \(L_{20}=3I-A\) to its selected isometric 20-subspace by \(\mathcal W\), and give the auxiliary harmonic \(\ell=1\) and \(\ell=2\) their Casimir values \(2\) and \(6\). This specifies a finite self-adjoint action with no fitted channel-specific constants. In the 99,470 construction a source-free extension may be similarly defined as \(\mathcal J L_{20}\mathcal J^\dagger\) plus a fixed self-adjoint auxiliary member; its choice is **not canonical** from the compression theorem.

The source derivatives of (6.1) obey the full flavor equal-time commutator algebra, while their compressed 20-state readouts are exactly (3.3) for the large construction and (5.4) for the minimal construction. Every Ward defect on the 20 comes from the complement by the exact identity (3.4).

**Action-scope warning:** this is an **explicit geometric comparison Hamiltonian**, not an identification with the native Born/QCD action. Source-linearity also sets second source contacts to zero; the actual Paper VII-A source Hessian has its own Duhamel/contact terms. The auxiliary Casimir energies are a defined geometric choice, not derived physical masses.

## 7. Exact native-paper interface and remaining selections

The current paper archive preserves `Paper7A-QCDKernel-v1_183.tex`. Its native source operator is

\[
\mathcal O_A^{BH}=\partial_{J_A}H_H[J]\big|_{J=0}
\quad\text{on the specified source/gauge carrier},
\]

at `p10:eq:native-source-operator-derivative`. Its conditional physical-action matching test `p10:def:v369-five-core-baryon-decay-action-test` requires **one and the same** gauge-covariant \(B(\Phi),H_Q(\Phi)\), compatible color/spin/flavor projectors, field derivatives, physical pole residues and daughter channels. Local Gauss is imposed by `p10:thm:v350-local-gauss-projector`. The rooted symmetric 56-state source isometry is `p10:prop:v3023-marked-baryon-source-overlap`.

**What is now constructed:** a full finite, Ward-exact flavor current whose compression is identically the old 20-state geometric current (Solution A), and a minimal \(A_5\)-equivariant full \(SU(3)\) representation with computed auxiliary couplings (Solution B). Each preserves the already proved fundamental flavor-three. The original `v1_6` Lie-defect now has explicit mathematical routes to a full algebra rather than being an unresolvable geometry obstruction.

**What is not constructed from the native action:** an isometry from either auxiliary representation into the *actual* locally Gauss-reduced finite-QCD Hilbert carrier with

\[
\boxed{\mathcal I^\dagger\mathcal O_A^{BH}\mathcal I
=\widehat Q(F_A)\quad\text{for all }A,}
\]

or the corresponding full first/second source jets, dynamical residues, thresholds and retarded decay channels. The high-dimensional tomography embedding has **not** been proved to intertwine the native \(A_5\) subgroup action on the auxiliary carrier; the 28 construction does, but changes the 17-state off-corner current. No comparison theorem selects one of these enlarged actions from the constitutional Born–Hopf axioms. These are **open physical-action/realization questions**, not mathematically solved by merely writing a self-adjoint Hamiltonian.

One additional potential mismatch must be kept explicit: the abstract symmetric-tensor powers in these constructions are representation carriers, **not identified with 24 physical quarks, 8 new bosons, gluons, or specific baryon-number sectors**. A CAR realization that preserves physical superselection and local Gauss is a separate typed task.

## 8. Verification scope and construction table

| Claim | Result | Evidence |
|---|---|---|
| Exact original 20-state lift and invariant flavor 3 | Retained | inherited v1_5/v1_6 certificates |
| Nine pure-state tomography / 81 duality identities | Exact | Q-rational SymPy Gram inversion |
| Nine complementary HS squares | `(57,57,57,42,18,42,18,42,18)` | integer \(\mathbb Z[\sqrt5,i]\) certificate |
| Norm bound for complementary positive parts | \(T\prec24I_{17}\) | rigorous outward rational Gershgorin and functional calculus |
| Finite \(U(3)\) dilation of **unchanged** one-hop current | Dimension 99,470, exact | explicit proof (3.2)–(3.3); independent matrix-unit reconstruction |
| Protected flavor 3 remains an invariant fundamental | Yes | direct sum, exact isometry |
| Minimal 28 full \(SU(3)\) representation | Yes | inherited v1_6 representation/harmonic certificate |
| 28 compression identical to original one-hop current | **No**, exact incompatibility | norm comparison \(45/2\ne5\) |
| Eight-mode leakage from triplet current | Zero | exact Casimir projector commutation |
| Eight-mode leakage per quintet | \(42/25+104/21=3482/525\) | exact bosonic-source traces |
| Native actual Born/QCD current equals either constructed full current | **Open** | Paper VII-A source/action matching condition |
| Physical hadron pole residues, partial widths, lifetimes | **Open** | no actual on-shell retarded same-action execution |

**Conclusion:** The existence of a Ward-exact full-carrier extension of the full 20-state one-hop flavor geometry is now mathematically closed by an explicit finite construction. The minimal 28-state representation gives a separate, much more economical but *off-carrier-modified* completion. Neither existence theorem supplies the missing native physical-action identification. That is the next precise boundary if the program aims to leave only physical selection open.
