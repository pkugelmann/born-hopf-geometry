# Source integration register v1_1

The approved `Paper00-DownstreamGeometryFrameworkChanges-v1_1` amendments have been
inserted into 5 current TeX/PDF manuscripts in `Paper00-PapersMinimal-v3_075.zip`.
The full finite-geometry replay has passed, but no independent E3/E4 review
has yet certified the new *paper-level* theorem dependencies.

The preferred compact 28-state `SU(3)` representation changes the off-flavor
20-state one-hop current. The separate 99,470-state dilation preserves that
current by compression but has not been shown to intertwine the original full
`A5` module. These are OR alternatives, not a jointly proven structure.
Physical current occurrence and pole/retarded readouts remain OPEN.

See `data/Paper00-DownstreamFrameworkSourceIntegration-v1_1.json` for source-hash
anchors. Original research certificate files are not modified.
